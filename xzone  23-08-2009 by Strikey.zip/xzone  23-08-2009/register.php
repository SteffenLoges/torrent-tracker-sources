<?
include "check_username.php";
require_once("include/bittorrent.php");
dbconn();
foreach($_POST as $key => $value) {
$value=trim($value);
if (get_magic_quotes_gpc()) $value = stripslashes($value);
$value=htmlspecialchars($value,ENT_QUOTES);
$_POST[$key]=$value;
$value=str_replace("\r","",$value);
$value=str_replace("\n","<br>",$value);
$msg[$key]=$value;
}
sajax_init();
sajax_export("check_user_exist");
sajax_handle_client_request();
function check_user_exist($username) {
$username = mysql_escape_string($username);
$suggest = array('2005', '2006', '2007', 'best');
$sql = "SELECT `username` FROM `users` WHERE `username` = '$username'";
$result = mysql_query($sql);
if(mysql_num_rows($result) > 0) {
$avail[0] = 'no';
$i = 2;
foreach($suggest AS $postfix) {
$sql = "SELECT `username` FROM `users` WHERE `username` = '".$username.$postfix."'";
$result = mysql_query($sql);
if(mysql_num_rows($result) < 1) {
$avail[$i] = $username.$postfix;
$i ++;
}
}
$avail[1] = $i - 1;
return $avail;
}
return array('yes');
}
stdhead("� егистрация");
$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $maxusers) {
stdmsg("Sorry", "Max users ot the tracker is already (" . number_format($maxusers) . ") try again letter.");
stdfoot();
die;
}
if ($_POST["registerfinish"]){
$registerfinish = 0 + htmlentities($_POST["registerfinish"]);
if ($registerfinish != 1){
stdmsg("Error", "I don't know data!");
stdfoot();
die;
}

if (!mkglobal("wantusername:wantpassword:passagain:email"))
die();

function validusername($username)
{
if ($username == "")
return false;

// The following characters are allowed in user names
$allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

for ($i = 0; $i < strlen($username); ++$i)
if (strpos($allowedchars, $username[$i]) === false)
return false;

return true;
}

if (empty($wantusername) || empty($wantpassword) || empty($email)){
stdmsg("Error!", "Don't leave any fields blank.\n");
stdfoot();
die;
}

$website = unesc($_POST["website"]);

if (strlen($wantusername) > 12){
stdmsg("Sorry", "username is too long (max is 12 chars)!\n");
stdfoot();
die;
}
if ($wantpassword != $passagain){
stdmsg("Sorry", "The passwords didn't match! Must've typoed. Try again.\n");
stdfoot();
die;
}
if (strlen($wantpassword) < 6){
stdmsg("Sorry", "Password is too short (min is 6 chars).\n");
stdfoot();
die;
}
if (strlen($wantpassword) > 40){
stdmsg("Sorry", "Password is too long (max is 40 chars).\n");
stdfoot();
die;
}
if ($wantpassword == $wantusername){
stdmsg("Sorry", "Password cannot be same as user name.\n");
stdfoot();
die;
}
if (!validemail($email)){
stdmsg("Sorry", "That doesn't look like a valid email address.\n");
stdfoot();
die;
}
if (strlen($website) > 40){
stdmsg("Sorry", "Web Site URL is too long (max is 40 chars).\n");
stdfoot();
die;
}
if (!validusername($wantusername)){
stdmsg("Sorry", "Invalid username.\n");
stdfoot();
die;
}
// check if email addy is already in use
$a = (@mysql_fetch_row(@mysql_query("select count(*) from users where email='$email'"))) or die(mysql_error());
if ($a[0] != 0) {
stdmsg("Sorry", "The e-mail address $email is already in use.\n");
stdfoot();
die;
}
hit_count();

$secret = mksecret();
$wantpasshash = md5($secret . $wantpassword . $secret);
$editsecret = mksecret();
$passkey= md5($wantusername.get_date_time().$wantpasshash);

$ret = mysql_query("INSERT INTO users (username, passhash, secret, editsecret, email, website, status, added, last_check) VALUES (" .
implode(",", array_map("sqlesc", array($wantusername, $wantpasshash, $secret, $editsecret, $email, $website, 'confirmed'))) .
",'" . get_date_time() . "', '" . get_date_time() . "')");

if (!$ret) {
if (mysql_errno() == 1062)
stdmsg("Sorry", "Username already exists!\n");
stdfoot();
}

$id = mysql_insert_id();
$dt = sqlesc(get_date_time());
$msg = sqlesc("<p>Before you start using torrentbits we urge you to read the <a href=\"rules.php\"><b>RULES</b></a> and the <a href=\"faq.php\"><b>FAQ</b></a>.</p>");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $id, $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
write_clog("The new registration username ($wantusername)", "white");
stdmsg("Registration successful!", "<p>This user account has already been confirmed. You can proceed to <a href=\"login.php\">log in</a> with it.</p>.\n");
stdfoot();
die;
}

if($_POST["do"] == "register"){
if($HTTP_POST_VARS["agree"] != "yes"){
stdmsg("Tracker Message!", "You did not click the 'I agree' checkbox. If you do agree to the terms and conditions, please ensure you check the box before continuing. If you do not agree to the terms and conditions, please<p>click <a href=\"index.php\">here</a> to cancel.");
stdfoot();
die;
}else
?>
<head>
&lt;script type="text/javascript">
<?php
sajax_show_javascript();
?>
function check_handle(result) {
if(result[0] == 'yes') {
document.getElementById('not_available').style.display = 'none';
document.getElementById('available').style.display = 'block';
}
else {
document.getElementById('available').style.display = 'none';
document.getElementById('not_available').style.display = 'block';
var str = 'Username already exists! <br />';
document.getElementById('not_available').innerHTML = str;
}
}

function check_user_exist() {
var username = document.getElementById('username').value;
x_check_user_exist(username, check_handle);
}

function switch_username(username) {
document.getElementById('username').value = username;
}
</script>

<style type="text/css">
#available {
display: none;
color: green;
}
#not_available {
display: none;
color: red;
}
</style>

</head>
<p>

<form method="post" action="<?$PHP_SELF?>">
<input type="hidden" value="1" name="registerfinish"/>
<center><table cellpadding="5" cellspacing="1" border="0" style="width:510px" class="tableinborder">
<tr>
<td class="tablea" align="right">Username:<font color="red">&nbsp;*</font></td>
<td class="tablea" align="left">
<input type="text" name="wantusername" id="username" size="40">
<input class="tableinborder" type="button" name="check" value="Check" onclick="check_user_exist(); return false;">
<div id="available">Username free for you!</div>
<div id="not_available">Username already exists!</div>
</td>
</tr>
<tr><td class="tablea" align="right" >Password:<font color="red">&nbsp;*</font></td><td class="tablea" align=left><input type="password" size="40" name="wantpassword" /></td></tr>
<tr><td class="tablea" align="right" >Password Again:<font color="red">&nbsp;*</font></td><td class="tablea" align=left><input type="password" size="40" name="passagain" /></td></tr>
<tr><td class="tablea" align="right" >Email:<font color="red">&nbsp;*</font></td><td class="tablea" align=left><input type="text" size="40" name="email" /></td></tr>
<tr><td class="tablea" align="right">Web Site:</td><td class="tablea" align=left><input type="text" size="40" name="website" /></td></tr>
<tr><td class="tablea" colspan="2">
<center>
<input class="tableinborder" type=submit value="Register!" style='height: 25px'>
</center>
</td></tr>
</table>
</form>
<?
stdfoot();
die();
}
?>
<div style="width:60%" align="center">
<fieldset class="fieldset">
<legend>Registration Terms & Rules</legend>
<form method="post" action="<?=$PHP_SELF?>">
<table cellpadding="4" cellspacing="0" border="0" style="width:100%" class="tableinborder">
<tr>
<td class="tablea">In order to proceed, you must agree to the following:</td></tr>
<tr>
<td class="tablea" style="font-size: 11px; font-style: normal; font-variant: normal; font-weight: normal; font-family: verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif">
<div class="page" style="BORDER-RIGHT: thin inset; PADDING-RIGHT: 6px; BORDER-TOP: thin inset; PADDING-LEFT: 6px; PADDING-BOTTOM: 6px; OVERFLOW: auto; BORDER-LEFT: thin inset; PADDING-TOP: 1px; BORDER-BOTTOM: thin inset; HEIGHT: 170px">
<!-- Begain Rulez -->
<p><strong>Tracker Terms & Rules</strong></p>
Please take a moment to review these rules detailed below. If you agree with
them and wish to proceed with the registration, simply click the &quot;Register&quot;
button below. To cancel this registration, simply hit the 'back' button on your
browser.<br>
<br>
Please remember that we are not responsible for any messages posted. We do not
vouch for or warrant the accuracy, completeness or usefulness of any message,
and are not responsible for the contents of any message.<br>
<br>
The messages express the views of the author of the message, not necessarily the
views of this bulletin board. Any user who feels that a posted message is
objectionable is encouraged to contact us immediately by email. We have the
ability to remove objectionable messages and we will make every effort to do so,
within a reasonable time frame, if we determine that removal is necessary.<br>
<br>
You agree, through your use of this service, that you will not use this bulletin
board to post any material which is knowingly false and/or defamatory,
inaccurate, abusive, vulgar, hateful, harassing, obscene, profane, sexually
oriented, threatening, invasive of a person's privacy, or otherwise violative of
any law.<br>
<br>
You agree not to post any copyrighted material unless the copyright is owned by
you or by this bulletin board.
<!-- End Rulez -->
</div>
</td></tr>
<tr><td class="tablea">
<div>
<label>
<input class="tablea" type="checkbox" name="agree" value="yes">
<input type="hidden" name="do" value="register">
<strong>I have read, understood and agree to these rules and conditions.</strong>
</label>
</div>
</td></tr>
</table>
</fieldset><p>
<center>
<input class="tableinborder" type="submit" value="Register">
</center>
</form>

<?
stdfoot();
?>