<?
/*
made by Juanma
request by TripleH
TBDev.net
*/
require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
stdhead(); //remove if you wanna add this into a block

$dt24 = gmtime() - 86400;
$dt24 = sqlesc(get_date_time($dt24));

$result = mysql_query("SELECT id, username, class, donor, parked, warned, enabled, last_access from users where last_access >= $dt24 order by last_access DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);

echo "<h2>Last 10 Visitors</h2>";

while ($row = mysql_fetch_array ($result))
{

$lastseen = $row["last_access"];
if ($lastseen == "0000-00-00 00:00:00")
  $lastseen = "Never";
else
  $lastseen .= " (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($lastseen)) . " ago)";

echo "<a href=userdetails.php?id=$row[id]>" . $row[username] . get_user_icons($row) . "</a> | Last Visit: $lastseen<br>";
}

 stdfoot();//remove if you wanna add this into a block
?>