<?

require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();
parked();

stdhead("Upload");

if (get_user_class() < UC_UPLOADER)
{
stdmsg("Sorry...", "You are not authorized to upload torrents.  (<a href=\"messages.php\">Read Inbox</a>)",false);
  stdfoot();
  exit;
}

if (strlen($CURUSER['passkey']) != 32) {

$CURUSER['passkey'] = md5($CURUSER['username'].get_date_time().$CURUSER['passhash']);

mysql_query("UPDATE users SET passkey='$CURUSER[passkey]' WHERE id=$CURUSER[id]");

}

?>
<div align=Center>
<form name=upload enctype="multipart/form-data" action="takeupload.php" method="post">
<input type="hidden" name="MAX_FILE_SIZE" value="<?=$max_torrent_size?>" />
<p>Your announce url is <b><?= $announce_urls[0] ?>?passkey=<?= $CURUSER['passkey'] ?></b></p>
<table border="1" cellspacing="0" cellpadding="10">
<tbody><tr><td colspan="2" style="text-align: center; background-color: transparent;">
<a href="javascript:showHideItems('rules');" style="border-bottom: 1px dotted rgb(234, 78, 0); text-decoration: none; color: rgb(234, 78, 0); font-weight: bold;">Read the uploading rules and guidelines before uploading!</a>
<div id="rules" style="display: none; text-align: left; width: 630px;" align="center">

<script type="text/javascript">
function showHideItems(myItem, myButton)
{
var myItem = document.getElementById(myItem);
var myButton = document.getElementById(myButton);
if (myItem.style.display != "block")
    {
    myItem.style.display = "block";
    swapImage(myButton,"minus");
    }
else
    {
    myItem.style.display = "none";
    swapImage(myButton,"plus");
    }
}

function swapImage(myImage, state)
{
if (state == "minus")
    {
    myImage.src = "pic/minus.gif";
    }
else
    {
    myImage.src = "pic/plus.gif";
    }
}
</script>
<span style="font-weight: bold; margin-left: 16pt;">General</span>
<ul>
<li>NU urcati torrente downloadate de pe <b>trackere din Romania</b>!
Daca considerati ca nu aveti alte surse de download, va rugam sa
postati pe forum si sa cereti invitatii/acces. Altfel, puteti sa cereti
demote!</li>
<li>Urcati decat scenereleases si raritati! Daca nu sunteti siguri de
autenticitatea fisierelor sau de unde provin acestea, va rugam
insistent sa nu le urcati. Calitatea este prioritara!
(Exista cateva exceptii: Movies/DVDR.RO, Movies/HD, Apps/Linux,
TV/Series, Apps/Mac si desigur raritatile/request-urile)</li>
<li>NU urcati scene releases mai vechi de 7 zile! Incercam sa oferim 0Day si raritati, pentru restul se pot folosi si alte metode.</li>
<li>Usurati munca unui moderator! Incercati sa completati Genre-ul si
Description-ul corect astfel incat interventia unui moderator sa nu fie
necesara.</li>
<li>In cazul in care aveti mai multe release-uri continand titluri similare, va rog sa faceti PACK-uri! <i>ex: Sezoane, Trilogii, MP3(avand acelasi artist), etc.</i></li>

<li>Este necesar seed-ul pana cand alti 3 leecheri au terminat
download-ul cu 100%! In cazul in care intervine ceva (v-a cazut netul
etc.) incercati sa anuntati alt uploader pentru a prelua torrentul.</li>
<li>NU urcati varianta NUKED a unui release dupa ce a fost urcat PROPER-ul (da, au fost niste cazuri).</li>
<li>Fiti activi pentru a evita demote-ul. Intrebati unde nu stiti sau
unde aveti dubii in privinta unor release-uri. Este mai bine decat sa
asteptati ca un moderator sa le stearga! Incercati sa urcati <b>cel putin 1 release pe zi</b>.</li>
<li>NU urcati materiale Romanesti de nici un fel.</li>
<li>NU urcati release-uri cu caracter exclusiv, ci puneti la punct pack-uri proprii! ex:(Afro Samurai S01 COMPLETE XviD-<b>TorrentLeech</b>, Fawlty Towers Seasons 1 and 2 XViD-<b>ScT</b>, Kill.Bill.Boxset.DVDR-<b>FTN</b> etc.)</li>

<li>Nu urcati nimic cu aceste terminatii: R55, PLM, MDSS, RSSM, MRQ,
JAVLIU, CK, UDG, DASHING, 2Bros, PONY, MDE, aXXo, THS, BTZ, BTZONE,
XWT, Stuffies, DPK, ROR (doar appz facute de ROR sunt acceptate),
FRESH. Acestea sunt niste "grupuri" care se fac de ras prin ceea ce
"produc", nu avem nevoie de faima lor.</li>
<li>Incercati sa nu dati "copy+paste" la NFO ci sa selectati ceea ce conteaza in completarea campului "Description".</li>
</ul>
<span style="font-weight: bold; margin-left: 16pt;">Movies/XviD</span>
<ul>
<li>NU urcati filme cu audio dublat(dubbed) <i>ex: SWEDISH, FINNISH, POLISH, GERMAN etc.</i>!</li>
</ul>
<span style="font-weight: bold; margin-left: 16pt;">Music/MP3</span>
<ul>
Nota: Release intern = release creat din surse proprii. Acestea vor avea doar tag-ul xTreMeZoNe.

<li><b>[TAG]</b><br>
Nu se modifica tag-ul release-urilor luate de la (si implicit facute
pentru) alte grupuri sau alte site-uri p2p (.ro sau externe), si anume
release-urile interne ale altor site-uri.
</li>
<li><b>[NFO] [SFV] [CUE] [FILE] [M3U] [FOLDER]</b><br><br>
<b>a) SINGLE</b><br>a01) Fisierul [NFO] trebuie sa aiba denumirea de
tip "00-artist_-_titlu-sursa-an-grup" unde sursa = CDS/CDM/CDR/Vinyl
etc. Pentru release-urile de tip lossless se va folosi
-LOSSLESS-CDS/CDM/CDR etc;<br>
a02) Fisierul [NFO] trebuie sa contina date despre: numele artistului,
numele release-ului, data cand a fost lansat produsul pe piata, data la
care a fost creat release-ul, calitatea release-ului, sursa (daca
aceasta este un magazin online), durata totala, marimea totala precum
si date despre continut (lista de melodii incluse in release, durata
fiecarei melodii). Notele suplimentare raman la latitudinea celui care
a creat release-ul;<br>
a03) Fisierul [SFV] trebuie sa aiba denumirea de tip "00-artist_-_titlu-sursa-an-grup";<br>
a04) Fisierul de tip [CUE] se creaza doar pentru release-urile de tip
LOSSLESS si trebuie sa aiba denumirea "00-artist_-_titlu-sursa-grup" si
sa contina date in concordanta cu fisierele audio incluse in release;<br>
a05) Fisierul audio trebuie sa aiba denumirea de tip
"0x-artist_-_titlu-grup" unde x = 1,2,3,4 etc. In cazul fisierelor
audio ce contin date suplimentare (remix, etc) se va folosi denumirea
0x-artist_-_-_titlu__remix-grup, unde remix = datele suplimentare;<br>
a06) Fisierul audio nu trebuie sa aiba erori sau imperfectiuni. In
cazul in care release-ul este de tip 0day, se va uploada, ramanand
posibilitatea de a fi Nuked in cazul in care sunt descoperite
imperfectiuni;<br>
a07) Fisierul audio trebuie sa contina atat ID3v1 cat si ID3v2 tag, iar campurile Year si Genre trebuie completate adecvat;<br>
a08) Fisierul [M3U] trebuie sa aiba denumirea de tip "00-artist_-_titlu-sursa-an-grup";<br>
a09) Folder-ul in care sunt stocate fisierele trebuie sa aiba denumirea de tip "Artist_-_Titlu-Sursa-An-Grup";<br>
a10) Desription trebuie sa contina TOATE informatiile din [NFO],
adaugarea notelor suplimentare ramanand la latitudinea celui care a
creat/uploadat release-ul;<br><br>
<b>b) ALBUM</b><br>
Se aplica regulile de la punctul (a), cu urmatoarele completari:<br>
b1) In cazul in care albumul contine mai mult de 1 CD, fisierele [NFO],
[SFV] vor avea denumirea "000-artist_-_titlu-sursa-an-grup" unde sursa
= CD/Bonus-CD;<br>
b2) Fisierul [CUE] va avea denumirea "01-artist_-_titlu-sursa-grup",
iar in cazul in care exista mai mult de 1 CD, denumirea va fi de tip
"x01-artist_-_titlu-sursa-grup" unde x = 1,2,3,4 etc in concordanta cu
fisierul audio. Pentru albumurile de tip MIXED, este obligatoriu sa
contina fisier [CUE];<br>

b3) Fisierul audio: se aplica regulile de la (b2) si (a07);<br>
b4) Fisierul [M3U] trebuie sa aiba denumirea
"00-artist_-_titlu-sursa-grup", iar in cazul in care exista mai mult de
1 CD, folderul va contine mai multe fisiere [M3U], cate unul pentru
fiecare cd, si unul pentru intregul release. Fisierul [M3U] pentru
release va avea denumirea "000-artist_-_titlu-sursa-grup", unde sursa =
2CD/3CD etc, iar cele pentru fiecare cd vor fi de tip
"x00-artist_-_titlu-cdx-grup", unde x = 1,2,3,4 etc;<br>
b5) Folderul: se aplica regulile de la (a09);<br>
<br>
<b>c) LIVESET / STUDIO MIX / RECORDED CONCERT / EVENT</b><br>
c1) Fisierul [NFO] trebuie sa aiba denumirea de tip
"00-artist_-_titlu-sursa-data-grup", unde sursa = SBD/DAT/SAT/CABLE sau
denumirea postului de radio care a transmis acel eveniment. Pentru
inregistrarile live, trebuie specificata locatia unde a avut loc
evenimentul (fisierul nfo, si cele aferente avand forma
"00-artist_-_live_at_xxxxx-sursa-data-grup"). In cazul in care
denumirea acelui post contine prea multe caractere, aceasta poate fi
eliminata din numele fisierului nfo;<br>
c2) Fisierul [SFV]: se aplica regulile de la (c1);<br>
c3) Fisierul [CUE] trebuie sa aiba denumirea
"01-artist_-_titlu-sursa-data-grup" in concordanta cu fisierul audio.
In cazul in care un release este nou (0sec), se permite lipsa
fisierului [CUE], daca prezenta sa nu este posibila;<br>
c4) Fisierul audio: se aplica regulile de la (c3) si (a07);<br>

c5) Fisierul [M3U]: se aplica regulile de la (a08) cu Data in loc de An;<br>
c6) Folderul trebuie sa aiba denumirea "Artist_-_Titlu-Sursa-Data-Grup";<br>
<br>
<b>d) DISCOGRAPHY</b><br>
d1) Fisierul [NFO] trebuie sa aiba denumirea
"00-artist_-_complete_discography-grup" si sa contina in ordine
cronologica numele albumelor regasite in folder precum si data la care
a fost realizat acel release, calitatea melodiilor, date despre
continut;<br>
d2) Fisierele [SFV] trebuie sa fie prezente pentru fiecare album/single
in parte si sa aiba denumirea corespunzatoare albumului/single-ului
respectiv;<br>
d3) Fisierele [CUE]: se aplica regulile de la (d2);<br>
d4) Fisierele audio: se aplica regulile de mai sus;<br>
d5) Fisierele [M3U]: se aplica regulile de mai sus, incluzand si (a07);<br>

d6) Release-ul de tip discografie va avea foldere separate pentru fiecare album/single denumit corespunzator;<br>
<br>
<b>e) PACK</b><br>
Se aplica regulile de la DISCOGRAPHY, cu precizarea ca fisierul [NFO]
sa aiba denumirea "00-titlul_packului-grup" si sa contina informatiile
necesare despre ce se regaseste in acel pack.
</li>
<li><b>[COMPLETARI]</b> <br>- Release-urile de tip discografie vor fi
urcate doar daca sunt complete (includ albume si single-uri). Pt a
verifica daca discografia este completa, se vor folosi site-urile
artistilor, http://www.discogs.com/ , sau alte site-uri specializate;<br>
- Pentru encodarea albumelor in format MP3 se va folosi "-V2 --vbr-new";<br>
- Pentru encodarea albumelor la calitate LOSSLESS se va folosi, pentru
formatul FLAC &lt;&lt; -5 -V -T "artist=%a" -T "title=%t" -T "album=%g"
-T "date=%y" -T "tracknumber=%n" -T "genre=%m" -T comment="%e" -T
"comment=EAC (Secure Mode)" %s &gt;&gt; sau orice valoarea &gt;5.
Pentru APE/WV/WAV, calitatea encodarii trebuie sa primeze, setarile
ramanand la discretia celui care face encodarea;<br>
- Albumele/Single-urile encodate la calitate LOSSLESS trebuie sa
contina, in folder, un fisier [LOG] cu datele din timpul encodarii;<br>
- Albumele encodate la calitate LOSSLESS trebuie prezentate sub forma unui singur fisier + cue;<br>
- Tag-ul AllGRP este destinat release-urilor ce provin din alte surse (pack-uri formate din release-uri scoase de alte grupuri);<br>
- Acest standard este, in mare parte, copiat dupa cel al scenei, cu anumite completari;<br>
- Se permit mici abateri de la standard, in masura in care acestea nu
afecteaza calitatea, datele continute, informatiile, si aspectul final
al unui release;<br>
- Acest standard se aplica atat pentru release-urile 0day cat si pentru cele mai vechi (REQ).
</li>
</ul>
<span style="font-weight: bold; margin-left: 16pt;">Movies/XXX</span>
<ul>
<li>NU urcati PORNACHE pentru oameni bolnavi: scat, pissing, shemale,
gay, transexuali sau cine stie ce bolnaviciuni mai scot aia pe afara.
Din asa ceva nu are nimeni de invatat nimic.</li>

</ul>

<?

tr("Torrent file", "<input type=file name=file size=80>\n", 1);
tr("Torrent name", "<input type=\"text\" name=\"name\" size=\"80\" /><br />(Taken from filename if not specified. <b>Please use descriptive names.</b>)\n", 1);
tr("Genre", "<input type=\"text\" name=\"description\" size=\"80\" /><b></b><br>Small Description for the uploaded file (Example: A good movie!!!)<br>This Description is shown in browse.php under the Torrentname.", 1);
tr("YouTube Video Link", "<input type=\"text\" name=\"tube\" size=\"80\" /><br />Formatul link-ului trebuie sa fie <b>http://www.youtube.com/watch?v=TYxbGgeeVmI...t;</b>\n", 1);
tr("Poster Image", "<input type=text name=poster size=80><br>(Direct link for a poster image to be shown on the details page)\n", 1);

tr("NFO file", "<input type=file name=nfo size=80><br>(<b>Required.</b> Can only be viewed by power users.)\n", 1);
print("</td></tr>\n");
tr("Description", "<textarea name=\"descr\" rows=\"10\" cols=\"80\"></textarea>" .
  "<br>Please use the <a  href=tags.php >Tags Page</a> to test your description if you are using fancy code. ", 1);

$s = "<select name=\"type\">\n<option value=\"0\">(choose one)</option>\n";

$cats = genrelist();
foreach ($cats as $row)
        $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";
$s .= "</select>\n";
tr("Type", $s, 1);

tr("Strip ASCII", "<input type=checkbox name=strip value=strip unchecked />   <a href=\"http://en.wikipedia.org/wiki/ASCII_art\" target=\"_blank\">what is this ?</a> (Remove ASCII Code from Description)", 1);
tr("Req&nbsp;Torrent", "<input type='checkbox' name='req'" . (($row["req"] == "yes") ? " checked='checked'" : "" ) . " value='1' />Check this if the torrent is in request list !", 1);

?>

<tr><td align="center" colspan="2"><input type="submit" class=btn value="Upload" /></td></tr>
</table>
</form>
<?

stdfoot();

?>