<?
require "include/bittorrent.php";

dbconn(false);

loggedinorreturn();

function bark($msg)
{
  stdhead();
  stdmsg("Error", $msg);
  stdfoot();
  exit;
}

function maketable($res)
{
  $ret = "<table class=main border=1 cellspacing=0 cellpadding=5>" .
    "<tr><td class=colhead align=center>Type</td><td class=colhead>Name</td><td class=colhead align=center>TTL</td><td class=colhead align=center>Size</td><td class=colhead align=right>Se.</td><td class=colhead align=right>Le.</td><td class=colhead align=center>Upl.</td>\n" .
    "<td class=colhead align=center>Downl.</td><td class=colhead align=center>Ratio</td></tr>\n";
  while ($arr = mysql_fetch_assoc($res))
  {
    if ($arr["downloaded"] > 0)
    {
      $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 3);
      $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
    }
    else
      if ($arr["uploaded"] > 0)
        $ratio = "Inf.";
      else
        $ratio = "---";
	$catimage = htmlspecialchars($arr["image"]);
	$catname = htmlspecialchars($arr["catname"]);
	$ttl = (28*24) - floor((gmtime() - sql_timestamp_to_unix_timestamp($arr["added"])) / 3600);
	if ($ttl == 1) $ttl .= "<br>hour"; else $ttl .= "<br>hours";
	$size = str_replace(" ", "<br>", mksize($arr["size"]));
	$uploaded = str_replace(" ", "<br>", mksize($arr["uploaded"]));
	$downloaded = str_replace(" ", "<br>", mksize($arr["downloaded"]));
	$seeders = number_format($arr["seeders"]);
	$leechers = number_format($arr["leechers"]);
    $ret .= "<tr><td style='padding: 0px'><img src=\"pic/$catimage\" alt=\"$catname\" width=42 height=42></td>\n" .
		"<td><a href=details.php?id=$arr[torrent]&amp;hit=1><b>" . htmlspecialchars($arr["torrentname"]) .
		"</b></a></td><td align=center>$ttl</td><td align=center>$size</td><td align=right>$seeders</td><td align=right>$leechers</td><td align=center>$uploaded</td>\n" .
		"<td align=center>$downloaded</td><td align=center>$ratio</td></tr>\n";
  }
  $ret .= "</table>\n";
  return $ret;
}



$id = 0 + $_GET["id"];

if (!is_valid_id($id))
  bark("Bad ID $id.");

$r = @mysql_query("SELECT * FROM users WHERE id=$id") or sqlerr();
$user = mysql_fetch_array($r) or bark("No user with ID $id.");
if ($user["status"] == "pending") die;
$r = mysql_query("SELECT id, name, added, seeders, leechers, category FROM torrents WHERE owner=$id ORDER BY name") or sqlerr();
if (mysql_num_rows($r) > 0)
{
  $torrents = "<table class=main border=1 cellspacing=0 cellpadding=5>\n" .
    "<tr><td class=colhead>Type</td><td class=colhead>Name</td><td class=colhead>Seeders</td><td class=colhead>Leechers</td></tr>\n";
  while ($a = mysql_fetch_assoc($r))
  {
		$r2 = mysql_query("SELECT name, image FROM categories WHERE id=$a[category]") or sqlerr(__FILE__, __LINE__);
		$a2 = mysql_fetch_assoc($r2);
		$cat = "<img src=\"/pic/$a2[image]\" alt=\"$a2[name]\">";
      $torrents .= "<tr><td style='padding: 0px'>$cat</td><td><a href=details.php?id=" . $a["id"] . "&hit=1><b>" . htmlspecialchars($a["name"]) . "</b></a><br>" . str_replace(" ", "&nbsp;", $a["added"]) . " (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($a["added"])) . " ago)</td>" .
        "<td align=right>$a[seeders]</td><td align=right>$a[leechers]</td></tr>\n";
  }
  $torrents .= "</table>";
}

if ($user["ip"] && (get_user_class() >= UC_MODERATOR || $user["id"] == $CURUSER["id"]))
{
  $ip = $user["ip"];
  $dom = @gethostbyaddr($user["ip"]);
  if ($dom == $user["ip"] || @gethostbyname($dom) != $user["ip"])
    $addr = $ip;
  else
  {
    $dom = strtoupper($dom);
    $domparts = explode(".", $dom);
    $domain = $domparts[count($domparts) - 2];
    if ($domain == "COM" || $domain == "CO" || $domain == "NET" || $domain == "NE" || $domain == "ORG" || $domain == "OR" )
      $l = 2;
    else
      $l = 1;
    $addr = "$ip ($dom)";
  }
}
$bandwidth = $user["bandwidth"];

if ($user[added] == "0000-00-00 00:00:00")
  $joindate = 'N/A';
else
  $joindate = "$user[added] (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($user["added"])) . " ago)";
$lastseen = $user["last_access"];
if ($lastseen == "0000-00-00 00:00:00")
  $lastseen = "never";
else
{
  $lastseen .= " (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($lastseen)) . " ago)";
}
  $res = mysql_query("SELECT COUNT(*) FROM comments WHERE user=" . $user[id]) or sqlerr();
  $arr3 = mysql_fetch_row($res);
  $torrentcomments = $arr3[0];
  $res = mysql_query("SELECT COUNT(*) FROM posts WHERE userid=" . $user[id]) or sqlerr();
  $arr3 = mysql_fetch_row($res);
  $forumposts = $arr3[0];

//if ($user['donated'] > 0)
//  $don = "<img src=pic/starbig.gif>";

$res = mysql_query("SELECT name,flagpic FROM countries WHERE id=$user[country] LIMIT 1") or sqlerr();
if (mysql_num_rows($res) == 1)
{
  $arr = mysql_fetch_assoc($res);
 $country = "<td class=embedded><img src=/pic/flag/$arr[flagpic] alt=\"$arr[name]\" style='margin-left: 8pt'></td>";
}


if ($user["donor"] == "yes") $donor = "<td class=embedded><img src=pic/starbig.gif alt='Donor' style='margin-left: 4pt'></td>";
if ($user["warned"] == "yes") $warned = "<td class=embedded><img src=pic/warnedbig.gif alt='Warned' style='margin-left: 4pt'></td>";

if ($user["gender"] == "Male") $gender = "<td class=embedded><img src=".$pic_base_url."man.gif alt='Male' style='margin-left: 4pt'></td>";
elseif ($user["gender"] == "Female") $gender = "<td class=embedded><img src=".$pic_base_url."kvinna.gif alt='Female' style='margin-left: 4pt'></td>";
elseif ($user["gender"] == "N/A") $gender = "<td class=embedded><img src=".$pic_base_url."na.gif alt='N/A' style='margin-left: 4pt'></td>";

$res = mysql_query("SELECT torrent,added,uploaded,downloaded,torrents.name as torrentname,categories.name as catname,size,image,category,seeders,leechers FROM peers LEFT JOIN torrents ON peers.torrent = torrents.id LEFT JOIN categories ON torrents.category = categories.id WHERE userid=$id AND seeder='no'") or sqlerr();
if (mysql_num_rows($res) > 0)
  $leeching = maketable($res);
$res = mysql_query("SELECT torrent,added,uploaded,downloaded,torrents.name as torrentname,categories.name as catname,size,image,category,seeders,leechers FROM peers LEFT JOIN torrents ON peers.torrent = torrents.id LEFT JOIN categories ON torrents.category = categories.id WHERE userid=$id AND seeder='yes'") or sqlerr();
if (mysql_num_rows($res) > 0)
  $seeding = maketable($res);

stdhead("Details for " . $user["username"]);
$enabled = $user["enabled"] == 'yes';
print("<p><table class=main border=0 cellspacing=0 cellpadding=0>".
"<tr><td class=embedded><h1 style='margin:0px'>$user[username]" . get_user_icons($user, true) . "</h1></td>$country</tr></table></p>\n");

if (!$enabled)
  print("<p><b>This account has been disabled</b></p>\n");
elseif ($CURUSER["id"] <> $user["id"])
{
  $r = mysql_query("SELECT id FROM friends WHERE userid=$CURUSER[id] AND friendid=$id") or sqlerr(__FILE__, __LINE__);
  $friend = mysql_num_rows($r);
  $r = mysql_query("SELECT id FROM blocks WHERE userid=$CURUSER[id] AND blockid=$id") or sqlerr(__FILE__, __LINE__);
  $block = mysql_num_rows($r);

  if ($friend)
    print("<p>(<a href=friends.php?action=delete&type=friend&targetid=$id>remove from friends</a>)</p>\n");
  elseif($block)
    print("<p>(<a href=friends.php?action=delete&type=block&targetid=$id>remove from blocks</a>)</p>\n");
  else
  {
    print("<p>(<a href=friends.php?action=add&type=friend&targetid=$id>add to friends</a>)");
    print(" - (<a href=friends.php?action=add&type=block&targetid=$id>add to blocks</a>)</p>\n");
  }
}

 if ($user["pcoff"] == 'yes')
{
print("<font size=\"2\" color=\"lightblue\"><b>PC at night is</b> </font> <img src=pic/on.png>");        }
   else
   {
  print("<font size=\"2\" color=\"lightgreen\"><b>PC at night is</b></font> <img src=pic/off.png>");
   }
   if ($user["anonymous"] == 'yes')
{

 if (get_user_class() < UC_MODERATOR) {


    print("<table width=\"500px\" border=1 cellspacing=0 cellpadding=7 class=main>");
    print("<tr><td colspan=\"2\" align=\"center\"><p><b>This account has been disabled (or not) <img src=pic/smilies/grin.gif border=0></b></p>
</td></tr>");

    print("<tr><td colspan=2 align=center><form method=get action=sendmessage.php><input type=hidden name=receiver value=" .
        $user["id"] . "><input type=submit value=\"Send message\" style='height: 23px'></form><form method=post action=report.php?user=$user[id]><input type=submit value=\"Report User\" style='height: 23px'></form></td>");
    if (get_user_class() < UC_MODERATOR && $user["id"] != $CURUSER["id"])
    {
        print("</table>");
        end_main_frame();
        exit;
    }
    print("</table><br>");
}
}
begin_main_frame();

?>
<table width=90% align=center border=1 cellspacing=0 cellpadding=5>
<tr><td class=rowhead2  width=1%>Flush Torrents</td><td align=left width=99%><?
print ("<h0><a href=takeflush.php?id=$id>Flush Torrents</a>!</h0>\n");?></td></tr>
<tr><td class=rowhead2  width=1%>Join&nbsp;date</td><td align=left width=99%><?=$joindate?></td></tr>
<tr><td class=rowhead2 >Last&nbsp;seen</td><td align=left><?=$lastseen?></td></tr>
<?
print("<tr><td colspan=4 align=center class=rowhead ><b><font color=red>Private Details</font></b></td></tr>\n");

if (get_user_class() >= UC_MODERATOR)
  print("<tr><td class=rowhead2  >Email</td><td align=left><a href=mailto:$user[email]>$user[email]</a></td></tr>\n");
if ($addr)
  print("<tr><td class=rowhead2 >Address</td><td align=left>$addr</td></tr>\n");

//  if ($user["id"] == $CURUSER["id"] || get_user_class() >= UC_MODERATOR)
//	{

$dayUpload   = $user["uploaded"];
$dayDownload = $user["downloaded"];

$seconds = mkprettytime(strtotime("now") - strtotime($user["added"]));
$days = explode("d ", $seconds);
if(sizeof($days) > 1) {
$dayUpload   = $user["uploaded"] / $days[0];
$dayDownload = $user["downloaded"] / $days[0];
}

$dayUpload   = $user["uploaded"];
$dayDownload = $user["downloaded"];

$seconds = mkprettytime(strtotime("now") - strtotime($user["added"]));
$days = explode("d ", $seconds);
if(sizeof($days) > 1) {
$dayUpload   = $user["uploaded"] / $days[0];
$dayDownload = $user["downloaded"] / $days[0];
}


?>
<tr><td class=rowhead2 >Uploaded</td><td align=left><?=mksize($user["uploaded"])?>&nbsp;<b>[</b>Daily: <?=mksize($dayUpload)?><b>]</b></td></tr>
<tr><td class=rowhead2 >Downloaded</td><td align=left><?=mksize($user["downloaded"])?>&nbsp;<b>[</b>Daily: <?=mksize($dayDownload)?><b>]</b></td></tr>
<?



if ($user["downloaded"] > 0)
{
  $sr = $user["uploaded"] / $user["downloaded"];
  if ($sr >= 4)
    $s = "w00t";
  else if ($sr >= 2)
    $s = "grin";
  else if ($sr >= 1)
    $s = "smile1";
  else if ($sr >= 0.5)
    $s = "noexpression";
  else if ($sr >= 0.25)
    $s = "sad";
  else
    $s = "cry";
  $sr = floor($sr * 1000) / 1000;
  $sr = "<table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font color=" . get_ratio_color($sr) . ">" . number_format($sr, 3) . "</font></td><td class=embedded>&nbsp;&nbsp;<img src=/pic/smilies/$s.gif></td></tr></table>";
  print("<tr><td class=rowhead2  style='vertical-align: middle'>Share ratio</td><td align=left valign=center style='padding-top: 1px; padding-bottom: 0px'>$sr</td></tr>\n");
}

?>
<tr>
<td class=rowhead2 ><b>Contact</b></td><td class=tablea align=left>
<?
if ($user["icq"])
    print("<img src=http://web.icq.com/whitepages/online?icq=$user[icq]&img=5  alt=icq border=0 /> $user[icq] <br>\n");
if ($user["msn"])
    print("<img src=pic/contact/msn.gif alt=msn border=0 /> $user[msn]<br>\n");
if ($user["aim"])
    print("<img src=pic/contact/aim.gif alt=aim border=0 /> $user[aim]<br>\n");
if ($user["yahoo"])
    print("<img src=pic/contact/yahoo.gif alt=yahoo border=0 /> $user[yahoo]<br>\n");
if ($user["skype"])
    print("<img src=pic/contact/skype.gif alt-skype border=0 /> $user[skype]\n");
?>  
</td>
</tr>
<?

//}

$speedu = mysql_query("SELECT sum(((p.uploaded - p.uploadoffset )) / (
unix_timestamp(p.last_action) - unix_timestamp(p.started))) AS speed FROM peers p INNER
JOIN users u ON p.userid=u.id WHERE u.id=$user[id]");
$tu=mysql_fetch_array($speedu);
$speeduu = mksize($tu["speed"])or sqlerr(__FILE__, __LINE__);

print("<tr><td class=rowhead2 ><font color=green>UL Speed</font></td><td
align=left>$speeduu</td></tr>\n");

$speedd = mysql_query("SELECT sum(((p.downloaded - p.downloadoffset )) / (
unix_timestamp(p.last_action) - unix_timestamp(p.started))) AS speed FROM peers p INNER
JOIN users u ON p.userid=u.id WHERE u.id=$user[id]");
$td=mysql_fetch_array($speedd);
$speeddd = mksize($td["speed"])or sqlerr(__FILE__, __LINE__);

print("<tr><td class=rowhead2 ><font color=green>DL Speed</font></td><td
align=left>$speeddd</td></tr>\n");


//if ($user['donated'] > 0 && (get_user_class() >= UC_MODERATOR || $CURUSER["id"] == $user["id"]))
//  print("<tr><td class=rowhead2 >Donated</td><td align=left>$$user[donated]</td></tr>\n");
print("<tr><td colspan=4 align=center class=rowhead ><b><font color=red>Public Details</font></b></td></tr>\n");


$UC = array("Staff Leader" => "pic/tech.jpg",
         "Owner" => "pic/owner.jpg",
         "SysOp" => "pic/sysop.jpg",
         "Administrator" => "pic/admin.jpg",
         "Moderator" => "pic/mod.jpg",
         "Power Uploader" => "pic/eup.jpg",
         "Uploader" => "pic/uploader.jpg",
         "VIP" => "pic/vip.jpg",
         "Power User" => "pic/power.jpg",
         "User" => "pic/user.jpg");
if ($user["avatar"])
        print("<tr><td class=rowhead2 >Avatar</td><td align=left><img width=\"150\" src=\"" . htmlspecialchars(trim($user["avatar"])) . "\"></td></tr>\n");
$uclass = $UC[get_user_class_name($user["class"])];  print("<tr><td class=rowhead2 >Class</td><td align=left><img src=$uclass></td></tr>\n");
if ($user['donated'] > 0 && (get_user_class() >= UC_MODERATOR || $CURUSER["id"] == $user["id"]))

  print("<tr><td class=rowhead2 ><font color=red><b>Donated</td><td align=left>".htmlspecialchars($user[donated])." E</b></font></td></tr>\n");

print("<tr><td class=rowhead2 >Invites</td><td align=left><a href=/invite.php>$user[invites]</a></td></tr>\n");
//===Warned Progress Bar by TripleH @ TBDEV.NET
if ($user["timeswarned"] == 0) {
$warnedbar = "<img src=pic/warn_0.png>";
} else if ($user["timeswarned"] == 1) {
$warnedbar = "<img src=pic/warn_1.png> - <b>30%</b>";
} else if ($user["timeswarned"] == 2) {
$warnedbar = "<img src=pic/warn_2.png> - <b>60%</b>";
} else if ($user["timeswarned"] == 3) {
$warnedbar = "<img src=pic/warn_3.png - <b>90% - <font class=small>Be careful! One more warning and your account will be disabled</font></b>";
} else if ($user["timeswarned"] > 3) {
$warnedbar = "<img src=pic/warn_max.png> - <b>100% - Disabled</b>";
}

print("<tr><td class=rowhead2 >Warned level</td><td align=left>$warnedbar <font class=small>(" . $user["timeswarned"] . " warning" . ($user["timeswarned"] > 1 ? "s" : "") . ")</font></td></tr>\n");
//===Warned Progress Bar by TripleH @ TBDEV.NET
print("<tr><td class=rowhead2 >Torrents comment</td>");
if ($torrentcomments && (($user["class"] >= UC_POWER_USER && $user["id"] == $CURUSER["id"]) || get_user_class() >= UC_MODERATOR))
{
   $seconds3 = mkprettytime(strtotime("now") - strtotime($user["added"]));
$days = explode("d ", $seconds3);
if(sizeof($days) > 1) {
$dayposts   = round(($torrentcomments / $days[0]), 1);
}
$comments = mysql_query("SELECT sum(comments) AS comments FROM torrents");
$seconds = round(($comments)/($torrentcomments), 3);
print("<td align=left><a href=userhistory.php?action=viewcomments&id=$user[id]>$torrentcomments</a> ($dayposts comments per day / $seconds% of total forum posts)</td></tr>\n");
}
else
print("<td align=left>$torrentcomments</td></tr>\n");
print("<tr><td class=rowhead2 >Posts</td>");
if ($forumposts && (($user["class"] >= UC_USER && $user["id"] == $CURUSER["id"]) || get_user_class() >= UC_MODERATOR))
{
   $seconds3 = mkprettytime(strtotime("now") - strtotime($user["added"]));
$days = explode("d ", $seconds3);
if(sizeof($days) > 1) {
$dayposts   = round(($forumposts / $days[0]), 1);
}
$postcount = mysql_query("SELECT sum(postcount) AS postcount FROM forums");
$seconds = round(($postcount)/($forumposts), 3);
print("<td align=left><a href=userhistory.php?action=viewposts&id=$user[id]>$forumposts</a> ($dayposts posts per day / $seconds% of total forum posts)</td></tr>\n");
}
else
print("<td align=left>$forumposts</td></tr>\n");

?>

<?
if ($torrents)
print("<tr valign=top><td class=rowhead2  width=20%>Uploaded Torrents</td><td align=left width=90%><a href=\"javascript: klappe_news('a".$array['id']."')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pica".$array['id']."\" alt=\"Show/Hide\"></a>   <u>[Show/Hide]</u><div id=\"ka".$array['id']."\" style=\"display: none;\"><p>$torrents</div></td></tr>\n");

if ($seeding)
print("<tr valign=top><td class=rowhead2  width=20%>Current Seeds</td><td align=left width=90%><a href=\"javascript: klappe_news('a1".$array['id']."')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pica1".$array['id']."\" alt=\"Show/Hide\"></a>   <u>[Show/Hide]</u><div id=\"ka1".$array['id']."\" style=\"display: none;\"><p>$seeding</div></td></tr>\n");

if ($leeching)
print("<tr valign=top><td class=rowhead2  width=20%>Current Leechs</td><td align=left width=90%><a href=\"javascript: klappe_news('a2".$array['id']."')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pica2".$array['id']."\" alt=\"Show/Hide\"></a>   <u>[Show/Hide]</u><div id=\"ka2".$array['id']."\" style=\"display: none;\"><p>$leeching</div></td></tr>\n");

if ($completed)
print("<tr valign=top><td class=rowhead2  width=20%>Completed Torrents</td><td align=left width=90%><a href=\"javascript: klappe_news('a3".$array['id']."')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pica3".$array['id']."\" alt=\"Show/Hide\"></a>   <u>[Show/Hide]</u><div id=\"ka3".$array['id']."\" style=\"display: none;\"><p>$completed</div></td></tr>\n");
 print("<tr valign=top><td align=left colspan=2 class=text >" . format_comment($user["info"]) . "</td></tr>\n");

if ($CURUSER["id"] != $user["id"])
	if (get_user_class() >= UC_MODERATOR)
  	$showpmbutton = 1;
	elseif ($user["acceptpms"] == "yes")
	{
		$r = mysql_query("SELECT id FROM blocks WHERE userid=$user[id] AND blockid=$CURUSER[id]") or sqlerr(__FILE__,__LINE__);
		$showpmbutton = (mysql_num_rows($r) == 1 ? 0 : 1);
	}
	elseif ($user["acceptpms"] == "friends")
	{
		$r = mysql_query("SELECT id FROM friends WHERE userid=$user[id] AND friendid=$CURUSER[id]") or sqlerr(__FILE__,__LINE__);
		$showpmbutton = (mysql_num_rows($r) == 1 ? 1 : 0);
	}
if ($showpmbutton)
	print("<tr><td colspan=2 align=center><form method=get action=sendmessage.php><input type=hidden name=receiver value=" .
		$user["id"] . "><input type=submit value=\"Send message\" style='height: 23px'></form></td></tr>");

print("</table>\n");

if (get_user_class() >= UC_MODERATOR && $user["class"] < get_user_class())
{
 begin_frame("Edit User", true);
 print("<form method=post action=modtask.php>\n");
 print("<input type=hidden name='action' value='edituser'>\n");
 print("<input type=hidden name='userid' value='$id'>\n");
 print("<input type=hidden name='returnto' value='userdetails.php?id=$id'>\n");
 print("<table class=main border=1 cellspacing=0 cellpadding=5 width = 88%>\n");
   print("<tr><td class=rowhead2 >Invites</td><td colspan=2 align=left><input type=text size=5 name=invites value=\"" . htmlspecialchars($user[invites]) . "\"></tr>\n"); 

 print("<tr><td class=rowhead2 >Title</td><td colspan=2 align=left><input type=text size=60 name=title value=\"" . htmlspecialchars($user[title]) . "\"></tr>\n");
$avatar = htmlspecialchars($user["avatar"]);
 print("<tr><td class=rowhead2 >Avatar&nbsp;URL</td><td colspan=2 align=left><input type=text size=60 name=avatar value=\"$avatar\"></tr>\n");
$signature = htmlspecialchars($user["signature"]);
print("<tr><td class=rowhead2 >Signature&nbsp;URL</td><td colspan=2 align=left><input type=text size=60 name=signature value=\"$signature\"></tr>\n");


if ($CURUSER["class"] < UC_ADMINISTRATOR)
print("<input type=hidden name=donor value=$user[donor]>\n");
else
{
print("<tr><td class=rowhead2 >Donor</td><td colspan=2 align=left><input type=radio name=donor value=yes" .($user["donor"] == "yes" ? " checked" : "").">Yes <input type=radio name=donor value=no" .($user["donor"] == "no" ? " checked" : "").">No</td></tr>\n");
}
if (get_user_class() > 5)
{
 print("<form method=post action=donated.php>\n");
 print("<tr><td class=rowhead2 >Donated</td><td colspan=2 align=left><input type=text size=5 name=donated value=\"" . htmlspecialchars($user[donated]) . "\"></tr>\n");
}
print("<tr><td class=rowhead2 >Account Parked</td><td colspan=2 align=left><input type=radio name=parked value=yes" .($user["parked"]=="yes" ? " checked" : "") . ">Yes <input type=radio name=parked value=no" .($user["parked"]=="no" ? " checked" : "") . ">No</td></tr>\n");

if (get_user_class() == UC_MODERATOR && $user["class"] > UC_VIP)
  printf("<input type=hidden name=class value=$user[class]\n");
else
{
  print("<tr><td class=rowhead2 >Class</td><td colspan=2 align=left><select name=class>\n");
  if (get_user_class() == UC_MODERATOR)
    $maxclass = UC_UPLOADER;
  else
    $maxclass = get_user_class() - 1;
  for ($i = 0; $i <= $maxclass; ++$i)
    print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
  print("</select></td></tr>\n");
}


$modcomment = htmlspecialchars($user["modcomment"]);
$supportfor = htmlspecialchars($user["supportfor"]);
print("<tr><td class=rowhead2 >Support</td><td colspan=2 align=left><input type=radio name=support value=yes" .($user["support"] == "yes" ? " checked" : "").">Yes <input type=radio name=support value=no" .($user["support"] == "no" ? " checked" : "").">No</td></tr>\n");
print("<tr><td class=rowhead2 >Support for:</td><td colspan=2 align=left><textarea cols=60 rows=6 name=supportfor>$supportfor</textarea></td></tr>\n");

if (get_user_class() < UC_MODERATOR) {
print("<tr><td class=rowhead2 >Comment</td><td colspan=2 align=left><textarea cols=60 rows=10 name=modcomment READONLY>$modcomment</textarea></td></tr>\n");
}
else {
print("<tr><td class=rowhead2 >Comment</td><td colspan=2 align=left><textarea cols=60 rows=10 name=modcomment >$modcomment</textarea></td></tr>\n");
}

print("<tr><td class=rowhead2 >Add&nbsp;Comment</td><td colspan=2 align=left><textarea cols=60 rows=2 name=addcomment ></textarea></td></tr>\n");
$info = htmlspecialchars($user["info"]);
print("<tr><td class=rowhead2 >User Info</td><td colspan=2 align=left><textarea cols=60 rows=6 name=info>$info</textarea></td></tr>\n");

$signature = htmlspecialchars($user["signature"]);
print("<tr><td class=rowhead2 >Forum Signature</td><td colspan=2 align=left><textarea cols=60 rows=6 name=signature>$signature</textarea></td></tr>\n");

$warned = $user["warned"] == "yes";

 print("<tr><td class=rowhead2 " . (!$warned ? " rowspan=2": "") . ">Warned</td>
 <td align=left width=20%>" .
 ( $warned
 ? "<input name=warned value='yes' type=radio checked>Yes<input name=warned value='no' type=radio>No"
 : "No" ) ."</td>");

if ($warned)
{
 $warneduntil = $user['warneduntil'];
 if ($warneduntil == '0000-00-00 00:00:00')
    print("<td align=center>(arbitrary duration)</td></tr>\n");
 else
 {
    print("<td align=center>Until $warneduntil");
    print(" (" . mkprettytime(strtotime($warneduntil) - gmtime()) . " to go)</td></tr>\n");
   }
 }
 else
 {
   print("<td>Warn for <select name=warnlength>\n");
   print("<option value=0>------</option>\n");
   print("<option value=1>1 week</option>\n");
   print("<option value=2>2 weeks</option>\n");
   print("<option value=4>4 weeks</option>\n");
   print("<option value=8>8 weeks</option>\n");
   print("<option value=255>Unlimited</option>\n");
   print("</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PM comment:</td></tr>\n");
   print("<tr><td colspan=2 align=left><input type=text size=60 name=warnpm></td></tr>");
 }
 print("<tr><td class=rowhead2 >Enabled</td><td colspan=2 align=left><input name=enabled value='yes' type=radio" . ($enabled ? " checked" : "") . ">Yes <input name=enabled value='no' type=radio" . (!$enabled ? " checked" : "") . ">No</td></tr>\n");
 print("</td></tr>");
if (get_user_class() > UC_MODERATOR)
{
 print("<form method=post action=changeusername.php>\n");
 print("<tr><td class=rowhead2 >Change Username</td><td colspan=2 align=left><input type=text size=25 name=username value=\"" . htmlspecialchars($user[username]) . "\"></tr>\n");
}
if (get_user_class() > UC_MODERATOR)
{
 print("<form method=post action=changemail.php>\n");
 print("<tr><td class=rowhead2 >Change E-mail</td><td colspan=2 align=left><input type=text size=80 name=email value=\"" . htmlspecialchars($user[email]) . "\"></tr>\n");
}
if (get_user_class() > UC_MODERATOR)
{
 print("<tr><td class=rowhead2 >Change Password</td><td colspan=2 align=left><input type=\"password\" name=\"chpassword\" size=\"50\" /></td></tr>\n");
print("<tr><td class=rowhead2 >Repeat Password</td><td colspan=2 align=left><input type=\"password\" name=\"passagain\" size=\"50\" /></td></tr>\n");
                print("<form method=post action=ratio.php>\n");
                print("<tr><td class=rowhead2 >Amount Uploaded</td><td colspan=2 align=left><input type=text size=60 name=uploaded value=\"" . htmlspecialchars($user[uploaded]) . "\"></tr>\n");
                print("<tr><td class=rowhead2 >Amount Downloaded</td><td colspan=2 align=left><input type=text size=60 name=downloaded value=\"" . 
                htmlspecialchars($user[downloaded]) . "\"></tr>\n");
                print("<tr><td class=rowhead2 >Passkey</td><td colspan=2 align=left><input name=resetkey value=yes type=checkbox> Reset passkey</td></tr>\n");
}

        

 print("<tr><td colspan=3 align=center><input type=submit class=btn value='Okay'></td></tr></form>\n");

 print("</table>\n");
 print("</form>\n");
 print("</table>\n");
         if (get_user_class() >= UC_OWNER)
        {
                begin_frame("Delete User", true);
                print(" <script LANGUAGE=JavaScript SRC=scripts/todger.js></SCRIPT>");
                $username = htmlspecialchars($user["username"]);
                print(" <form method=post action=delacctadmin.php name=deluser>
                <tr><td class=rowhead2 ><input name=username size=10 value=". $username ." type=hidden>
                <input name=delenable type=checkbox onClick=\"if (this.checked) {enabledel();}else{disabledel();}\"><input name=submit type=submit class=btn value=\"Delete\" disabled></td></tr></form>");
        }
                end_frame();
}
end_main_frame();
stdfoot();
?>
