loggedinorreturn();
if (get_user_class() < UC_MODERATOR)
stderr("Error", "Access denied.");
stdhead();

begin_frame("Invited Users");

/////////// by rulzmaker /////////////
$res2 = mysql_query("SELECT COUNT(*) FROM users WHERE invited_by > 0");
$row = mysql_fetch_array($res2);
$count = $row[0];
$perpage = 50;
list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" );
echo $pagertop;
/////////// by rulzmaker /////////////

echo '<table width="640" border="0" align="center" cellpadding="2" cellspacing="0">';
echo "<tr><td class=colhead align=left>User</td><td class=colhead>Invited by</td><td class=colhead>Ratio</td><td class=colhead>IP</td><td class=colhead>Date Joined</td><td class=colhead>Last Access</td><td class=colhead>Download</td><td class=colhead>Upload</td></tr>";

$result = mysql_query ("SELECT * FROM users WHERE invited_by > 0 AND status = 'confirmed' ORDER BY added DESC $limit");
if ($row = mysql_fetch_array($result)) {
do {
if ($row["uploaded"] == "0") { $ratio = "inf"; }
elseif ($row["downloaded"] == "0") { $ratio = "inf"; }
else {
$ratio = number_format($row["uploaded"] / $row["downloaded"], 3);
$ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
}
$invited_by = mysql_query("SELECT username FROM users WHERE id=$row[invited_by]");
$invited_by2 = mysql_fetch_array($invited_by);

echo "<tr><td><a href=userdetails.php?id=".$row["id"]."><b>".$row["username"]."</b></a></td><td><a href=userdetails.php?id=".$row["invited_by"].">".$invited_by2["username"]."</a></td><td><strong>".$ratio."</strong></td><td>".$row["ip"]."</td><td>".$row["added"]."</td><td>".$row["last_access"]."</td><td>".mksize($row["downloaded"])."</td><td>".mksize($row["uploaded"])."</td></tr>";


} while($row = mysql_fetch_array($result));
} else {print "<tr><td>Sorry, no records were found!</td></tr>";}
echo "</table>";
print($pagerbottom);
end_frame();
stdfoot();
?>