<?
require_once("include/bittorrent.php");
function bark($msg) {
 stdhead();
 stdmsg("Delete failed!", $msg);
 stdfoot();
 exit;
}
dbconn();
loggedinorreturn();
if (get_user_class() < UC_system)
 bark("You're not authorised to delete this torrent, please contact a staff member on this.\n");
$torrent = $_GET['torrent'];
$torrentname=$_GET['torrentname'];
$res = mysql_query("SELECT id FROM peers WHERE userid=$id and userid=$torrent");
$arr = mysql_fetch_array($res);
//mysql_query("DELETE FROM peers WHERE torrent=$torrent");
write_snatchlog("<a href=\"userdetails.php?id=$id\">Userid:$id</a> ,$torrentname was flushed by</font> $CURUSER[username]\n");
header("Refresh: 1; url=$BASEURL/userdetails.php?id=$id");
stderr('Success', "$torrentname was sucessfully flushed.</font><BR><font color=green><font>redirecting you back to userdetails</font>");
stdfoot();
?>