<?php
//imunit?tes scripts - danka - www.velkam.org - info@velkam.org
require_once("include/bittorrent.php");
stdhead();
if (get_user_class() < UC_ADMINISTRATOR)
{
stdmsg("Sorry...", "You have to be Administrator.");
stdfoot();
exit;
}
?>
<center><h3>New user has aded</h3></center><br>
<a href="imunitate.php">Press hear</a>
<?
$links = $_GET['links'];
$lietotajs = $_GET['lietotajs'];
$saraksts = "saraksts.txt";
$info = "<tr><td class=\"rowhead\"><center><a href=\"$links\">$lietotajs</a></center></td><br></tr>";
?>
<?
        
        $printer = fopen($saraksts, 'a');
        fwrite($printer,$info);
        fclose($printer);
?>
<?
stdfoot();
?>