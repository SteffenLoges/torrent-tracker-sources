<?
////////////////////////////////////////////////////////
// Bonus Mod by TvRecall.org
// Bonus Mod Updated by devin
// Version 0.3
// Updated 01/05/2006
// under GPL-License
// 2006.04.28 Bug fix maded by Nemesiz
///////////////////////////////////////////////////////

require_once('include/bittorrent.php');
session_start();

ob_start();

dbconn(false);
$action = $_GET['action'];

loggedinorreturn();

stdhead($CURUSER['username'] . "'s Bonus");

$bonus = number_format($CURUSER['seedbonus'], 1);
$userid = $CURUSER['id'];

//begin_frame("Seeder Bonus Exchange");
print("<table align=center width=600 border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");
print("<table class=tableb align=center width=600 border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");
?>
<tr><td align=center>Here you can exchange your Seeder-Bonus (current <?echo "$bonus";?>).
<br>
(If the buttons deactivated, you have not enough to trade.)
<br>
<?

print("<table border=1 cellspacing=0 cellpadding=5 width=500><tr>".
"<td class=tabletitle align=left>Option</td>".
"<td class=tabletitle align=left>Whats this about?</td>".
"<td class=tabletitle align=left>Points</td>".
"<td class=tabletitle align=left>Trade</td>".

"</tr>");

$res = mysql_query("SELECT * from bonus order by id");

while ($gets = mysql_fetch_assoc($res))
{
print("<tr class=tableb><td>".$gets["id"]."</td><td align='left'><b>".$gets["bonusname"]."</b><br>".$gets["description"]."</td><td align='right'>".$gets["points"]."</td>");
print("<form action=mybonus.php?action=exchange method=post>\n");
print("<input type=\"hidden\" name=\"bonus\" value=\"".$bonus."\">\n");
print("<input type=\"hidden\" name=\"userid\" value=\"".$userid."\">\n");
print("<input type=\"hidden\" name=\"points\" value=\"".$gets["points"]."\">\n");
print("<input type=\"hidden\" name=\"option\" value=\"".$gets["id"]."\">\n");
print("<input type=\"hidden\" name=\"art\" value=\"".$gets["art"]."\">\n");
if($bonus >= $gets["points"]) {
        print("<td><input type=submit name=submit value=\"Exchange!\"></td></form>");
} else {
        print("<td><input type=submit name=submit value=\"Exchange!\" disabled></td></form>");
}
}

print("</table><br><br><br>");
if ($action == "exchange") {

        $option = $_POST["option"];

        if(is_numeric($option)) {
                $userid = $CURUSER['id'];
                $modcomment = $CURUSER['modcomment'];
                $upload = $CURUSER['uploaded'];
                $bpoints = $CURUSER['seedbonus'];
                $invites = $CURUSER['invites'];

                $res = mysql_query("SELECT * FROM bonus WHERE id='$option'");
                $bytes = mysql_fetch_assoc($res);

                $points = $bytes["points"];
                $bonus = $bytes["bonus"];
                $art = $bytes["art"];

                $up = $upload+$bytes['menge'];
                $inv = $invites+$bytes['menge'];
                $seedbonus=number_format($bpoints-$points,1);

                if($bpoints >= $points) {
                        header("Location: $BASEURL/");

                        if($art == "traffic") {
                                $modcomment = gmdate("Y-m-d") . " - User has trade " .$points. " Points for traffic.\n " .$modcomment;
                                mysql_query("UPDATE users SET uploaded = '$up', seedbonus = '$seedbonus', modcomment = '$modcomment' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
                        } elseif($art == "invite") {
                                $modcomment = gmdate("Y-m-d") . " - User has trade " .$points. " Points for invites.\n " .$modcomment;
                                mysql_query("UPDATE users SET invites = '$inv', seedbonus = '$seedbonus' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
                        } else {
                                echo "No valid type";
                        }
                } else {
                        echo "not enough points to trade...";
                }
        }
}
//end_frame();
stdfoot();
?>