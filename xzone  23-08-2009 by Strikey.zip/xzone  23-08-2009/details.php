<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


function getagent($httpagent, $peer_id="")
{
if (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_B([0-9][0-9|*])(.+)$)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_CVS)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/^Java\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Azureus/<2.0.7.0";
elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/BitTorrent\/S-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "Shadow's/$matches[1]";
elseif (preg_match("/BitTorrent\/U-([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "UPnP/$matches[1]";
elseif (preg_match("/^BitTor(rent|nado)\\/T-(.+)$/", $httpagent, $matches))
return "BitTornado/$matches[2]";
elseif (preg_match("/^BitTornado\\/T-(.+)$/", $httpagent, $matches))
return "BitTornado/$matches[1]";
elseif (preg_match("/^BitTorrent\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC/$matches[1]";
elseif (preg_match("/^ABC ([0-9]+\.[0-9]+(\.[0-9]+)*)\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC/$matches[1]";
elseif (preg_match("/^Python-urllib\/.+?, BitTorrent\/([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "BitTorrent/$matches[1]";
elseif (preg_match("/^BitTorrent\/brst(.+)/", $httpagent, $matches))
return "Burst";
elseif (preg_match("/^RAZA (.+)$/", $httpagent, $matches))
return "Shareaza/$matches[1]";
elseif (preg_match("/Rufus\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Rufus/$matches[1]";
elseif (preg_match("/^Python-urllib\\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
return "G3 Torrent";
elseif (preg_match("/MLDonkey\/([0-9]+).([0-9]+).([0-9]+)*/", $httpagent, $matches))
return "MLDonkey/$matches[1].$matches[2].$matches[3]";
elseif (preg_match("/ed2k_plugin v([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "eDonkey/$matches[1]";
elseif (preg_match("/uTorrent\/([0-9]+)([0-9]+)([0-9]+)([0-9A-Z]+)/", $httpagent, $matches))
return "uTorrent/$matches[1].$matches[2].$matches[3].$matches[4]";
elseif (preg_match("/CT([0-9]+)([0-9]+)([0-9]+)([0-9]+)/", $peer_id, $matches))
return "cTorrent/$matches[1].$matches[2].$matches[3].$matches[4]";
elseif (preg_match("/Transmission\/([0-9]+).([0-9]+)/", $httpagent, $matches))
return "Transmission/$matches[1].$matches[2]";
elseif (preg_match("/KT([0-9]+)([0-9]+)([0-9]+)([0-9]+)/", $peer_id, $matches))
return "KTorrent/$matches[1].$matches[2].$matches[3].$matches[4]";
elseif (preg_match("/rtorrent\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
return "rTorrent/$matches[1]";
elseif (preg_match("/^ABC\/Tribler_ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "Tribler/$matches[1]";
elseif (preg_match("/^BitsOnWheels( |\/)([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "BitsOnWheels/$matches[2]";
elseif (preg_match("/BitTorrentPlus\/(.+)$/", $httpagent, $matches))
return "BitTorrent Plus!/$matches[1]";
elseif (ereg("^Deadman Walking", $httpagent))
return "Deadman Walking";
elseif (preg_match("/^eXeem( |\/)([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "eXeem$matches[1]$matches[2]";
elseif (preg_match("/^libtorrent\/(.+)$/", $httpagent, $matches))
return "libtorrent/$matches[1]";
elseif (substr($peer_id, 0, 12) == "d0c")
return "Mainline";
elseif (substr($peer_id, 0, 1) == "M")
return "Mainline/Decoded";
elseif (substr($peer_id, 0, 3) == "-BB")
return "BitBuddy";
elseif (substr($peer_id, 0, 8) == "-AR1001-")
return "Arctic Torrent/1.2.3";
elseif (substr($peer_id, 0, 6) == "exbc\08")
return "BitComet/0.56";
elseif (substr($peer_id, 0, 6) == "exbc\09")
return "BitComet/0.57";
elseif (substr($peer_id, 0, 6) == "exbc\0:")
return "BitComet/0.58";
elseif (substr($peer_id, 0,4) == "-BC0")
return "BitComet/0.".substr($peer_id,5,2);
elseif (substr($peer_id, 0, 7) == "exbc\0L")
return "BitLord/1.0";
elseif (substr($peer_id, 0, 7) == "exbcL")
return "BitLord/1.1";
elseif (substr($peer_id, 0, 3) == "346")
return "TorrenTopia";
elseif (substr($peer_id, 0, 8) == "-MP130n-")
return "MooPolice";
elseif (substr($peer_id, 0, 8) == "-SZ2210-")
return "Shareaza/2.2.1.0";
elseif (ereg("^0P3R4H", $httpagent))
return "Opera BT Client";
elseif (substr($peer_id, 0, 6) == "A310--")
return "ABC/3.1";
elseif (ereg("^XBT Client", $httpagent))
return "XBT Client";
elseif (ereg("^BitTorrent\/BitSpirit$", $httpagent))
return "BitSpirit";
elseif (ereg("^DansClient", $httpagent))
return "XanTorrent";

else
return "Unknow";
}

function dltable($name, $arr, $torrent)
{

        global $CURUSER;
        $s = "<b>" . count($arr) . " $name</b>\n";
        if (!count($arr))
                return $s;
        $s .= "\n";
        $s .= "<table width=100% class=main border=1 cellspacing=0 cellpadding=5>\n";
        $s .= "<tr><td class=colhead>User/IP</td>" .
          "<td class=colhead align=center>Connectable</td>".
          "<td class=colhead align=right>Uploaded</td>".
          "<td class=colhead align=right>Rate</td>".
          "<td class=colhead align=right>Downloaded</td>" .
          "<td class=colhead align=right>Rate</td>" .
          "<td class=colhead align=right>Ratio</td>" .
          "<td class=colhead align=right>Complete</td>" .
          "<td class=colhead align=right>Connected</td>" .
          "<td class=colhead align=right>Idle</td>" .
          "<td class=colhead align=left>Client</td></tr>\n";
        $now = time();
        $moderator = (isset($CURUSER) && get_user_class() >= UC_MODERATOR);
$mod = get_user_class() >= UC_MODERATOR;
        foreach ($arr as $e) {


                // user/ip/port
                // check if anyone has this ip
                ($unr = mysql_query("SELECT username, privacy FROM users WHERE id=$e[userid] ORDER BY last_access DESC LIMIT 1")) or die;
                $una = mysql_fetch_array($unr);
                                if ($una["privacy"] == "strong") continue;
                $s .= "<tr>\n";
                if ($una["username"])
                  $s .= "<td><a href=userdetails.php?id=$e[userid]><b>$una[username]</b></a></td>\n";
                else
                  $s .= "<td>" . ($mod ? $e["ip"] : preg_replace('/\.\d+$/', ".xxx", $e["ip"])) . "</td>\n";
                $secs = max(1, ($now - $e["st"]) - ($now - $e["la"]));
                $revived = $e["revived"] == "yes";
        $s .= "<td align=center>" . ($e[connectable] == "yes" ? "Yes" : "<font color=red>No</font>") . "</td>\n";
                $s .= "<td align=right>" . mksize($e["uploaded"]) . "</td>\n";
                $s .= "<td align=right><nobr>" . mksize(($e["uploaded"] - $e["uploadoffset"]) / $secs) . "/s</nobr></td>\n";
                $s .= "<td align=right>" . mksize($e["downloaded"]) . "</td>\n";
                if ($e["seeder"] == "no")
                        $s .= "<td align=right><nobr>" . mksize(($e["downloaded"] - $e["downloadoffset"]) / $secs) . "/s</nobr></td>\n";
                else
                        $s .= "<td align=right><nobr>" . mksize(($e["downloaded"] - $e["downloadoffset"]) / max(1, $e["finishedat"] - $e[st])) .        "/s</nobr></td>\n";
                if ($e["downloaded"])
                                {
                  $ratio = floor(($e["uploaded"] / $e["downloaded"]) * 1000) / 1000;
                    $s .= "<td align=\"right\"><font color=" . get_ratio_color($ratio) . ">" . number_format($ratio, 3) . "</font></td>\n";
                                }
                       else
                  if ($e["uploaded"])
                    $s .= "<td align=right>Inf.</td>\n";
                  else
                    $s .= "<td align=right>---</td>\n";
                $s .= "<td align=right>" . sprintf("%.2f%%", 100 * (1 - ($e["to_go"] / $torrent["size"]))) . "</td>\n";
                $s .= "<td align=right>" . mkprettytime($now - $e["st"]) . "</td>\n";
                $s .= "<td align=right>" . mkprettytime($now - $e["la"]) . "</td>\n";
                $s .= "<td align=left>" . htmlspecialchars(getagent($e["agent"], $e["peer_id"])) . "</td>\n";
                $s .= "</tr>\n";
        }
        $s .= "</table>\n";
        return $s;
}

dbconn(false);

loggedinorreturn();

$id = 0 + $_GET["id"];

if (!isset($id) || !$id)
        die();

$res = mysql_query("SELECT torrents.seeders, torrents.banned, torrents.leechers, torrents.info_hash, torrents.filename, LENGTH(torrents.nfo) AS nfosz, UNIX_TIMESTAMP() - UNIX_TIMESTAMP(torrents.last_action) AS lastseed, torrents.numratings, torrents.name, torrents.description, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, torrents.owner, torrents.save_as, torrents.descr, torrents.visible, torrents.size, torrents.added, torrents.views, torrents.hits, torrents.times_completed, torrents.id, torrents.type, torrents.numfiles, torrents.tube, torrents.poster, categories.name AS cat_name, users.username FROM torrents LEFT JOIN categories ON torrents.category = categories.id LEFT JOIN users ON torrents.owner = users.id WHERE torrents.id = $id")
        or sqlerr();
$row = mysql_fetch_array($res);

$owned = $moderator = 0;
        if (get_user_class() >= UC_MODERATOR)
                $owned = $moderator = 1;
        elseif ($CURUSER["id"] == $row["owner"])
                $owned = 1;
//}

if (!$row || ($row["banned"] == "yes" && !$moderator))
        stderr("Error", "No torrent with ID $id.");
else {
        if ($_GET["hit"]) {
                mysql_query("UPDATE torrents SET views = views + 1 WHERE id = $id");
                if ($_GET["tocomm"])
                        header("Location: $BASEURL/details.php?id=$id&page=0#startcomments");
                elseif ($_GET["filelist"])
                        header("Location: $BASEURL/details.php?id=$id&filelist=1#filelist");
                elseif ($_GET["toseeders"])
                        header("Location: $BASEURL/details.php?id=$id&dllist=1#seeders");
                elseif ($_GET["todlers"])
                        header("Location: $BASEURL/details.php?id=$id&dllist=1#leechers");
                else
                        header("Location: $BASEURL/details.php?id=$id");
                exit();
        }

        if (!isset($_GET["page"])) {
                stdhead("Details for torrent \"" . $row["name"] . "\"");

                if ($CURUSER["id"] == $row["owner"] || get_user_class() >= UC_MODERATOR)
                        $owned = 1;
                else
                        $owned = 0;

                $spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

                if ($_GET["uploaded"]) {
                        print("<h2>Successfully uploaded!</h2>\n");
                        print("<p><b>Torrent is changed to tracker standarts</b></p>\n");
                        print("<p>Please redownload torrent and start seeding. <b>Note</b> that the torrent won't be visible until you do that!</p>\n");
                }
                elseif ($_GET["edited"]) {
                        print("<h2>Successfully edited!</h2>\n");
                        if (isset($_GET["returnto"]))
                                print("<p><b>Go back to <a href=\"" . htmlspecialchars($_GET["returnto"]) . "\">whence you came</a>.</b></p>\n");
                }
                elseif (isset($_GET["searched"])) {
                        print("<h2>Your search for \"" . htmlspecialchars($_GET["searched"]) . "\" gave a single result:</h2>\n");
                }
elseif ($_GET["rated"]) {
 print("<h2>Rating added!</h2>\n");
}
elseif ($_GET["thanks"])
 print("<h2>Thanks added!</h2>\n");

$s=$row["name"];
$descrs = $row["description"];
                print("<h1>$s</h1>\n");
                print("<table width=750 border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");

                $url = "edit.php?id=" . $row["id"];
                if (isset($_GET["returnto"])) {
                        $addthis = "&amp;returnto=" . urlencode($_GET["returnto"]);
                        $url .= $addthis;
                        $keepget .= $addthis;
                }
                $editlink = "a href=\"$url\" class=\"sublink\"";

//                $s = "<b>" . htmlspecialchars($row["name"]) . "</b>";
//                if ($owned)
//                        $s .= " $spacer<$editlink>[Edit torrent]</a>";
//                tr("Name", $s, 1);
print("<tr><td class=heading align=right valign=top>Reclama</td><td align=left valign=top><center><a href=http://www.sharefilles.com/signup.php><img src=pic/shf.png border=0></a>&nbsp;&nbsp;&nbsp;</center></td></tr>
\n");
                print("<tr><td class=rowhead width=1%>Download</td><td width=99% align=left><a class=\"index\" href=\"download.php/$id/" . rawurlencode($row["filename"]) . "\">" . htmlspecialchars($row["filename"]) . "</a></td></tr>");
                if (!empty($row["description"]))
                print("<tr><td class=rowhead width=1%>Small Description</td><td width=99% align=left>$descrs</td></tr>");
                //                tr("Downloads&nbsp;as", $row["save_as"]);

                function hex_esc($matches) {
                        return sprintf("%02x", ord($matches[0]));
                }
                tr("Info hash", preg_replace_callback('/./s', "hex_esc", hash_pad($row["info_hash"])));
                if (!empty($row["descr"]))
                        tr("Description", str_replace(array("\n", "  "), array("<br>\n", "&nbsp; "), format_comment(htmlspecialchars($row["descr"]))), 1);
if (!empty($row["tube"]))
tr("Sample:", "<embed src='". str_replace("watch?v=", "v/", htmlspecialchars($row["tube"])) ."' type=\"application/x-shockwave-flash\" width=\"500\" height=\"410\"></embed>", 1);
else

tr("Trailer:", "<img src=pic/blank.gif class=tube>", 1);

if (!empty($row["poster"]))
tr("Poster:", "<img src=\"".$row["poster"]."\" onload=\"NcodeImageResizer.createOn(this);\">", 1);
else
tr("Picture:", "<img src=poster.jpg>", 1);
if (get_user_class() >= UC_POWER_USER && $row["nfosz"] > 0)

  print("<tr><td class=rowhead>NFO</td><td align=left><a href=viewnfo.php?id=$row[id]><b>View NFO</b></a> (" .
     mksize($row["nfosz"]) . ")</td></tr>\n");
                if ($row["visible"] == "no")
                        tr("Visible", "<b>no</b> (dead)", 1);
                if ($moderator)
                        tr("Banned", $row["banned"]);
                if (isset($row["cat_name"]))
                        tr("Type", $row["cat_name"]);
                else
                        tr("Type", "(none selected)");

                tr("Last&nbsp;seeder", "Last activity " . mkprettytime($row["lastseed"]) . " ago");
                tr("Size",mksize($row["size"]) . " (" . number_format($row["size"]) . " bytes)");
                $s = "";
                $s .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td valign=\"top\" class=embedded>";
                if (!isset($row["rating"])) {
                        if ($minvotes > 1) {
                                $s .= "none yet (needs at least $minvotes votes and has got ";
                                if ($row["numratings"])
                                        $s .= "only " . $row["numratings"];
                                else
                                        $s .= "none";
                                $s .= ")";
                        }
                        else
                                $s .= "No votes yet";
                }
                else {
                        $rpic = ratingpic($row["rating"]);
                        if (!isset($rpic))
                                $s .= "invalid?";
                        else
                                $s .= "$rpic (" . $row["rating"] . " out of 5 with " . $row["numratings"] . " vote(s) total)";
                }
                $s .= "\n";
                $s .= "</td><td class=embedded>$spacer</td><td valign=\"top\" class=embedded>";
                if (!isset($CURUSER))
                        $s .= "(<a href=\"login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;nowarn=1\">Log in</a> to rate it)";
                else {
                        $ratings = array(
                                        5 => "Kewl!",
                                        4 => "Pretty good",
                                        3 => "Decent",
                                        2 => "Pretty bad",
                                        1 => "Sucks!",
                        );
                        if (!$owned || $moderator) {
                                $xres = mysql_query("SELECT rating, added FROM ratings WHERE torrent = $id AND user = " . $CURUSER["id"]);
                                $xrow = mysql_fetch_array($xres);
                                if ($xrow)
                                        $s .= "(you rated this torrent as \"" . $xrow["rating"] . " - " . $ratings[$xrow["rating"]] . "\")";
                                else {
                                        $s .= "<form method=\"post\" action=\"takerate.php\"><input type=\"hidden\" name=\"id\" value=\"$id\" />\n";
                                        $s .= "<select name=\"rating\">\n";
                                        $s .= "<option value=\"0\">(add rating)</option>\n";
                                        foreach ($ratings as $k => $v) {
                                                $s .= "<option value=\"$k\">$k - $v</option>\n";
                                        }
                                        $s .= "</select>\n";
                                        $s .= "<input type=\"submit\" value=\"Vote!\" />";
                                        $s .= "</form>\n";
                                }
                        }
                }
                $s .= "</td></tr></table>";
                tr("Rating", $s, 1);


                tr("Added", $row["added"]);
                tr("Views", $row["views"]);
                tr("Hits", $row["hits"]);
                tr("Snatched", $row["times_completed"] . " time(s)");

		$keepget = "";

      $row["owner"] = "<a href=".$GLOBALS['DEFAULTBASEURL']."/userdetails.php?id=" . $row["owner"] . ">";

   $uprow = (isset($row["username"]) ? ("" . $row["owner"] . "<b>" . htmlspecialchars($row["username"]) . "</b></a>") : "<i>Anonymous</i>");
		if ($owned)
			$uprow .= " $spacer<$editlink><b>[Edit this torrent]</b></a>";

if (get_user_class() >= UC_MODERATOR){
tr("Upped by", $uprow, 1);
  }
else
if ($owned){
tr("Upped by", $uprow, 1);
}
else
tr("Upped by", "<i>[Anonymous]</i>", 1);
                if ($row["type"] == "multi") {
                        if (!$_GET["filelist"])
                                tr("Num files<br /><a href=\"details.php?id=$id&amp;filelist=1$keepget#filelist\" class=\"sublink\">[See full list]</a>", $row["numfiles"] . " files", 1);
                        else {
                                tr("Num files", $row["numfiles"] . " files", 1);

                                $s = "<table class=main border=\"1\" cellspacing=0 cellpadding=\"5\">\n";

                                $subres = mysql_query("SELECT * FROM files WHERE torrent = $id ORDER BY id");
$s.="<tr><td class=colhead>Path</td><td class=colhead align=right>Size</td></tr>\n";
                                while ($subrow = mysql_fetch_array($subres)) {
                                        $s .= "<tr><td>" . $subrow["filename"] .
                            "</td><td align=\"right\">" . mksize($subrow["size"]) . "</td></tr>\n";
                                }

                                $s .= "</table>\n";
                                tr("<a name=\"filelist\">File list</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[Hide list]</a>", $s, 1);
                        }
                }

                if (!$_GET["dllist"]) {
                        /*
                        $subres = mysql_query("SELECT seeder, COUNT(*) FROM peers WHERE torrent = $id GROUP BY seeder");
                        $resarr = array(yes => 0, no => 0);
                        $sum = 0;
                        while ($subrow = mysql_fetch_array($subres)) {
                                $resarr[$subrow[0]] = $subrow[1];
                                $sum += $subrow[1];
                        }
                        tr("Peers<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[See full list]</a>", $resarr["yes"] . " seeder(s), " . $resarr["no"] . " leecher(s) = $sum peer(s) total", 1);
                        */
                        tr("Peers<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[See full list]</a>", $row["seeders"] . " seeder(s), " . $row["leechers"] . " leecher(s) = " . ($row["seeders"] + $row["leechers"]) . " peer(s) total", 1);
                }
                else {
                        $downloaders = array();
                        $seeders = array();
                        $subres = mysql_query("SELECT seeder, finishedat, downloadoffset, uploadoffset, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, agent, peer_id, UNIX_TIMESTAMP(last_action) AS la, userid FROM peers WHERE torrent = $id") or sqlerr();
                        while ($subrow = mysql_fetch_array($subres)) {
                                if ($subrow["seeder"] == "yes")
                                        $seeders[] = $subrow;
                                else
                                        $downloaders[] = $subrow;
                        }

                        function leech_sort($a,$b) {
                                if ( isset( $_GET["usort"] ) ) return seed_sort($a,$b);
                                $x = $a["to_go"];
                                $y = $b["to_go"];
                                if ($x == $y)
                                        return 0;
                                if ($x < $y)
                                        return -1;
                                return 1;
                        }
                        function seed_sort($a,$b) {
                                $x = $a["uploaded"];
                                $y = $b["uploaded"];
                                if ($x == $y)
                                        return 0;
                                if ($x < $y)
                                        return 1;
                                return -1;
                        }

                        usort($seeders, "seed_sort");
                        usort($downloaders, "leech_sort");

                        tr("<a name=\"seeders\">Seeders</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[Hide list]</a>", dltable("Seeder(s)", $seeders, $row), 1);
                        tr("<a name=\"leechers\">Leechers</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[Hide list]</a>", dltable("Leecher(s)", $downloaders, $row), 1);
                }
                //.torrent file info link
                if (get_user_class() >= UC_MODERATOR)
                {
                tr("Torrent Info", "<a href=\"torrent_info.php?id=$id\">Torrent Info</a>", 1);
                }

tr("Report<br />Torrent", "Click <a href=report.php?type=Torrent&id=$id><b><font color=#ff0532>here</font></b></a> to report this torrent to staff for violation of the rules", 1);

$torrentid = $_GET["id"];
         $thanks_sql = mysql_query("SELECT * FROM thanks where torrentid=$torrentid");
   $thanks_all = mysql_numrows($thanks_sql);
   if ($thanks_all) {
   while($rows_t = mysql_fetch_array($thanks_sql)) {
   $thanks_userid = $rows_t["userid"];
   $user_sql = mysql_query("SELECT * FROM users where id=$thanks_userid");
   $rows_a = mysql_fetch_array($user_sql);
   $username_t = $rows_a["username"];
   $thanksby =  $thanksby."<a href='userdetails.php?id=$thanks_userid'>$username_t</a>, ";
   }
   $t_userid = $CURUSER["id"];
   $tsql = mysql_query("SELECT COUNT(*) FROM thanks where torrentid=$torrentid and userid=$t_userid");
   $trows = mysql_fetch_array($tsql);
   $t_ab = $trows[0];
   if ($t_ab == "0") {
   $thanksby = $thanksby." <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"Thanks!\">
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>";
   }
   else {
   $thanksby = $thanksby." <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"Thanks!\" disabled>
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>";
   }
   }
   else {
   $thanksby = "None yet.  
   <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"Thanks!\">
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>
   ";
   }
       tr("Thanks by:",$thanksby,1);

                print("</table></p>\n");

        }
        else {
                stdhead("Comments for torrent \"" . $row["name"] . "\"");
                print("<h1>Comments for <a href=details.php?id=$id>" . $row["name"] . "</a></h1>\n");
//                print("<p><a href=\"details.php?id=$id\">Back to full details</a></p>\n");
        }$res3 = mysql_query("select count(snatched.id) from snatched inner join users on snatched.userid = users.id inner join torrents on snatched.torrentid = torrents.id where snatched.torrentid =" . $_GET[id]) or die(mysql_error());
$row = mysql_fetch_array($res3);

$count = $row[0];
$perpage = 50;
list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] . "?id=" . $_GET[id] . "&" );

$res2 = mysql_query("select name from torrents where id = $_GET[id]");
$arr2 = mysql_fetch_assoc($res2);
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));


print("<h1 align=center>Snatch Details for <a href=details.php?id=$_GET[id]><b>$arr2[name]</b></a></h1>\n");
print("<p align=center>The users at the top finished the download most recently</p>");

echo $pagertop;

print("<table border=1 cellspacing=0 cellpadding=5 align=center>\n");
print("<tr><td class=colhead align=left>Username</td><td class=colhead align=left>Uploaded</td><td class=colhead align=left>Downloaded</td><td class=colhead align=left>Share Ratio</td><td class=colhead align=left>PM User</td><td class=colhead align=left><font color=red>Report User</font></td><td class=colhead align=left>On/Off</td><td class=colhead align=left>Seeding</td></tr>");

$res = mysql_query("select users.id, users.username, users.uploaded, users.downloaded, snatched.userid from snatched inner join users on snatched.userid = users.id inner join torrents on snatched.torrentid = torrents.id where snatched.torrentid =" . $_GET[id] . " ORDER BY snatched.id desc $limit");
while ($arr = mysql_fetch_assoc($res))
{

$res2 = mysql_query("SELECT id,donor,title,enabled,warned,last_access FROM users WHERE id=$arr[userid]") or sqlerr(__FILE__, __LINE__);
$arr2 = mysql_fetch_assoc($res2);

$res3 = mysql_query("SELECT * FROM peers WHERE torrent=$_GET[id] AND userid=$arr[userid]");
$arr3 = mysql_fetch_assoc($res3);

if ($arr["downloaded"] > 0)
{
$ratio = number_format($arr["uploaded"] / $arr["downloaded"], 3);
$ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
}
else
if ($arr["uploaded"] > 0)
$ratio = "Inf.";
else
$ratio = "---";
$uploaded =mksize($arr["uploaded"]);
$downloaded = mksize($arr["downloaded"]);

print("<tr><td><a href=userdetails.php?id=$arr[userid]><b>$arr[username]</b></a></td><td align=left>$uploaded</td><td align=left>$downloaded</td><td align=left>$ratio</td><td><form method=get action=sendmessage.php><input type=hidden name=receiver value=" .
$arr[userid]."><input type=submit value=\"P M: $arr[username]\" style='height: 22px'></form><form method=post action=report.php?user=$arr[userid]></td><td align=left><input type=submit value=\"Report: $arr[username]\" style='height: 23px'></form></td><td align=center>" . get_user_icons($arr2, true) .

"&nbsp; ".("'".$arr2['last_access']."'">$dt?"<img src=".$pic_base_url."online.gif border=0 alt=\"Online\">":"<img src=".$pic_base_url."offline.gif border=0 alt=\"Offline\">" )."</td>"."
<td align=center>" . ($arr3["seeder"] == "yes" ? "<b><font color=green>Yes</font>" : "<font color=red>No</font></b>") . "</td></tr>\n");
}
print("</table>\n");

echo $pagerbottom;


        print("<p><a name=\"startcomments\"></a></p>\n");

        $commentbar = "<p align=center><a class=index href=comment.php?action=add&amp;tid=$id>Add a full comment</a></p>\n";

$quickcomment = "<table style='border:1px solid #000000;'><tr>".
  "<td style='padding:10px;text-align:center;'><p><b>Quick Comment</b><br />".
  "<form name=comment method=\"post\" action=\"comment.php?action=add\">".
  "<textarea name=\"text\" rows=\"4\" cols=\"50\"></textarea>".
  "<input type=\"hidden\" name=\"tid\" value=\"$id\"/><br />".
  "<input type=\"submit\" class=btn value=\"Submit\" />".
  "</form></p></td></tr></table>";
        $subres = mysql_query("SELECT COUNT(*) FROM comments WHERE torrent = $id");
        $subrow = mysql_fetch_array($subres);
        $count = $subrow[0];

     if (!$count) {
 print($quickcomment);
 print("<h3>No comments yet</h3>\n");
}
        else {
                list($pagertop, $pagerbottom, $limit) = pager(20, $count, "details.php?id=$id&", array(lastpagedefault => 1));
  $subres = mysql_query("SELECT comments.id, text, user, comments.added, editedby, editedat, avatar, warned, ".
                 "username, title, class, donor, downloaded, uploaded FROM comments LEFT JOIN users ON comments.user = users.id WHERE torrent = " .
                 "$id ORDER BY comments.id $limit") or sqlerr(__FILE__, __LINE__);
             $allrows = array();
                while ($subrow = mysql_fetch_array($subres))
                        $allrows[] = $subrow;

		print($quickcomment);                
                print($commentbar);
                print($pagertop);

                commenttable($allrows);

                print($pagerbottom);
        }

        print($commentbar);
}

stdfoot();

?>