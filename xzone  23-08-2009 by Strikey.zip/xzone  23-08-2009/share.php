<?
require "include/bittorrent.php";
dbconn();
stdhead();
loggedinorreturn();

//set these variables-----------------------------------------------------------------
$domain = "xtra-torrents.ro";      //your domainname
$path = "upload-images/";   //path to your targetfolder
$path_after_domain = "upload-images/";   //path to your targetfolder for use in url
$max_size = 1000000000;          //maximum filesize
//------------------------------------------------------------------------------------

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><blink>XtrA Torrents - Image Upload</blink></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<style type="text/css">
<!--
.style1 {
	font-size: 11px;
	font-weight: bold;
	color: #FF0000;
}
-->
</style>
</head>
<body bgcolor="#1e1e1e">

<FORM ENCTYPE="multipart/form-data" ACTION="share.php" METHOD="POST">
      <p class="style1 " align="center"><b><font color="cccccc" size="2">XtrA Torrents - Image Host</font></b></p>
     <p class="style1 " align="center"> 
		<table border=1 cellspacing=0 cellpadding=8 width="100">
        <tr>
         <p class="style1 " align="center"> <td class=rowhead>
			<p align="center"><b><font color="#FFFFFF"><span lang="en">Image:</span></font></b></td>
          <td>
			<p class="style1 " align="center"><p align="center"><INPUT NAME="userfile" TYPE="file" id="userfile"></td>
        </tr>
        <tr>
          <p class="style1 " align="center"><td colspan=2 align=center><input name="submit" type="submit" id="submit" value="Upload"></td>
        </tr>
      </table>


<br>

<?

if (!isset($HTTP_POST_FILES['userfile'])) exit;

if (is_uploaded_file($HTTP_POST_FILES['userfile']['tmp_name'])) {

if ($HTTP_POST_FILES['userfile']['size']>$max_size) {
      echo "<font color=\"#FFFFFF\" face=\"Geneva, Arial, Helvetica, sans-serif\">File is too big !</font><br>\n"; exit; }
if (($HTTP_POST_FILES['userfile']['type']=="image/gif") || ($HTTP_POST_FILES['userfile']['type']=="image/png") || ($HTTP_POST_FILES['userfile']['type']=="image/jpeg") | ($HTTP_POST_FILES['userfile']['type']=="image/bmp")) {

      if (file_exists($path . $HTTP_POST_FILES['userfile']['name'])) {
              echo "<font color=\"#FFFFFF\" face=\"Geneva, Arial, Helvetica, sans-serif\">There already exists a file with this name, please rename your file and try again.</font><br>\n"; exit; }

      $res = copy($HTTP_POST_FILES['userfile']['tmp_name'], $path .$HTTP_POST_FILES['userfile']['name']);

      if (!$res) { echo "<font color=\"#FFFFFF\" face=\"Geneva, Arial, Helvetica, sans-serif\">Didn't work, please try again</font><br>\n"; exit; } else {
      ?>
<br>
<p>
<span lang="en"><b>
<font face="Geneva, Arial, Helvetica, sans-serif" color="#C0C0C0">Link</font></b></span><font color="#C0C0C0" face="Geneva, Arial, Helvetica, sans-serif"><b>:
</b></font><font color="#FFFFFF" face="Geneva, Arial, Helvetica, sans-serif"> <strong><font color="#990000"><a href="http://<? echo $domain; ?>/<? echo $path_after_domain; ?><? echo $HTTP_POST_FILES['userfile']['name']; ?>" target="_blank"><br>
http://<? echo $domain; ?>/<? echo $path_after_domain; ?><? echo $HTTP_POST_FILES['userfile']['name']; ?><br>
</a></font></strong><br>
</font><font color="#C0C0C0" face="Geneva, Arial, Helvetica, sans-serif"><b>HTML<span lang="ru"> 
</span>:</b></font><font color="#333333" face="Geneva, Arial, Helvetica, sans-serif"><br>
<font color="#FF0000"><strong>&lt;img src=&quot;http://<? echo $domain; ?>/<? echo $path_after_domain; ?><? echo $HTTP_POST_FILES['userfile']['name']; ?>&quot;&gt;</strong></font><br>
<br>
</font><font color="#C0C0C0" face="Geneva, Arial, Helvetica, sans-serif"><b>
<span lang="en">Forums</span>: </b></font>
<font color="#333333" face="Geneva, Arial, Helvetica, sans-serif"><strong> <font color="#990000"><br>
</font></strong></font><strong> 
<font color="#FF0000" face="Geneva, Arial, Helvetica, sans-serif">[img]http://<? echo $domain; ?>/<? echo $path_after_domain; ?><? echo $HTTP_POST_FILES['userfile']['name']; ?>[/img]</font></strong></p>
<?
}
echo "<font color=\"#C0C0C0\" face=\"Geneva, Arial, Helvetica, sans-serif\"><hr>";
echo "File Name: ".$HTTP_POST_FILES['userfile']['name']."<br>\n";
echo "File Size: ".$HTTP_POST_FILES['userfile']['size']." bytes<br>\n";
echo "File Type: ".$HTTP_POST_FILES['userfile']['type']."<br>\n";
echo "</font>";
echo "<br><br><img src=\"http://".$domain."/".$path_after_domain.$HTTP_POST_FILES['userfile']['name']."\">";
} else { echo "<font color=\"#C0C0C0\" face=\"Geneva, Arial, Helvetica, sans-serif\">You may only upload file types with the extensions .png / .gif / .jpg / .bmp /  !!!</font><br>\n"; exit; }

}

?></body></html><?
?>
