<?php
require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();
maxsysop ();
if (get_user_class() >= UC_SYSOP) {
if(isset($_POST["delmp"])) {
	$do="DELETE FROM messages WHERE id IN (" . implode(", ", $_POST[delmp]) . ")";
	$res=($do);
	
}
}
header("Refresh: 0; url=spam.php");
?>