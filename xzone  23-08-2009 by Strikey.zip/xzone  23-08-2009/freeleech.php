<?
ob_start("ob_gzhandler");
require "include/bittorrent.php";
dbconn();
loggedinorreturn();
if (get_user_class() < UC_ADMINISTRATOR)
{
stderr('Error', 'Access denied.');
}
if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
if ($HTTP_POST_VARS["setto"] == "")
{
newerr("Error", "Missing form data.",true,true);
}
$what=$HTTP_POST_VARS["setto"];

switch( $what )
{
case 1 : // Freeleech
$freeleech='yes';
break;
case 2 : // Normal
$freeleech='no';
break;
default : newerr("Error", "Please choose if free or not free!");
}
mysql_query("UPDATE torrents SET free=".sqlesc($freeleech).$where) or sqlerr(__FILE__, __LINE__);

header("Location: browse.php");
die;
}
stdhead("Change all torrents");
?>
<h1>Set All Torrents to Free Leech or Normal.Just Click FreeLeech and click ok.</h1>
<form method=post action=freeleech.php>
<table border=1 cellspacing=0 cellpadding=5>
<tr>
<td class=rowhead>Normal Or All Freeleech?</td>
<td>
<select name=setto>
<option value="0">---- Please Choose ----</option>
<option value="1">Freeleech</option>
<option value="2">Normal</option>
</select>
</td>
</tr>
<tr><td colspan=2 align=center><input type=submit value="Okay" class=btn></td></tr>
</table>
</form>
<?
stdfoot();
?>