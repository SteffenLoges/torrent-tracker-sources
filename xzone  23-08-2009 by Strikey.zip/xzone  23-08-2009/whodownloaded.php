<?php
require_once("include/bittorrent.php");
gzip();
dbconn();
loggedinorreturn();
maxsysop ();
iplogger();
parked();
$fileid = (int)$_GET['fileid'];
int_check($fileid,false,false,true,true);

$res = sql_query("SELECT * FROM attachmentdownloads WHERE fileid=".sqlesc($fileid)) or sqlerr(__FILE__, __LINE__);
if(mysql_num_rows($res) == "0")
	die("Nothing found!");
else {
print("<html><head><link rel=\"stylesheet\" href=\"$BASEURL/styles/style.css\" type=\"text/css\" media=\"screen\" /></head><body>\n");

print("<table border=1 width=100% cellspacing=0 cellpadding=2>\n");
print("<tr align=center><td class=colhead align=center>File ID</td>
 <td class=colhead align=center>File Name</td>
 <td class=colhead align=center>Downloaded by</td>  
 <td class=colhead align=center>Downloads</td>
 <td class=colhead align=center>Date</td></tr>\n");
	while ($arr = mysql_fetch_assoc($res)) {
		print("<tr><td align=center><font color=red>$arr[fileid]</font></td><td align=center><font color=red>".htmlspecialchars($arr[filename])."</font></td><td align=center><a href=\"#\" onclick=\"opener.location=('userdetails.php?id=$arr[userid]'); self.close();\"><font color=red>$arr[username]</font></a></td><td align=center><font color=red>$arr[downloads]</font></td><td align=center><font color=red>$arr[date]</font></td></tr>");
	}
	$res = sql_query("SELECT downloads FROM attachments WHERE id=".sqlesc($fileid)) or sqlerr(__FILE__, __LINE__);
	$arr = mysql_fetch_assoc($res);
	print("<tr><td colspan=5><div class=error><font color=blue>Total Downloads Of File: $arr[downloads]</font></div></td</tr>");
	print("</table></body></html>\n");
}
?>