<?

require_once("include/bittorrent.php");

dbconn();

loggedinorreturn();

if($_POST["nowarned"] == "nowarned")
{
if (get_user_class() < UC_MODERATOR)
stderr("Sorry", "Access denied.");

if (empty($_POST["desact"]) && empty($_POST["remove"]))
stderr("Error", "You Must Select A User.");

if (!empty($_POST["remove"]))
{
mysql_query("DELETE FROM cheaters WHERE id IN (" . implode(", ", $_POST["remove"]) . ")") or sqlerr(__FILE__, __LINE__);
}
}

header("Refresh: 0; url=cheaters.php");

?>