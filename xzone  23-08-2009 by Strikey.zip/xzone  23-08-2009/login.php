<html><head><title>XZone V2.0 BETA :: Login</title>


<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="login_files/login.css" type="text/css"></head><body>
<script type="text/javascript" src="login_files/wz_tooltip.js"></script><div style="padding: 0px; overflow: hidden; visibility: hidden; position: absolute; width: 0px; left: 0px; top: 0px;" id="WzTtDiV"></div>
<noscript><div style="position: absolute; padding: 360px; top: 2%;
left: 10%; z-index: 80002; border: #514B79 solid 1px; background-image:
url(pic/black.png); color: #FF0000"><div align="center"><strong><br
/>This page can not display properly without JavaScript.<br />Please
enable JavaScript and reload this page.<br /></strong></div></div></noscript>
<table class="mainouter" align="center" border="0" cellpadding="10" cellspacing="0" width="450">
<tbody><tr><td class="outer" style="padding-top: 10px; padding-bottom: 20px;" align="center">
<br><br><script type="text/javascript" src="login_files/useragreement.js"></script>
<script type="text/javascript" src="login_files/captcha.js"></script>
<table style="margin-top: 150px;" align="center" border="0" cellpadding="0" height="400" width="450"><tbody><tr><td class="front" align="center">
<form method="post" action="takelogin.php">
<div style="margin-bottom: 25px; margin-left: 10px;" align="center"></div>
<div style="margin-bottom: 5px;" align="center">You have <b><font color="green" size="4">6</font></b> remaining tries.</div>
<div style="margin-bottom: 10px;" align="center"><font size="1"><b>Username:</b></font> <input class="login" size="31" style="font-size: 12px;" name="username" type="text"></div>
<div style="margin-bottom: 10px; margin-left: 1px;" align="center"><font size="1"><b>Password:</b></font> <input class="login" size="31" style="font-size: 12px;" name="password" type="password"></div>
<div style="margin-bottom: 10px;" id="captchaimage" align="center"><a href="login.php" onclick="refreshimg(); return false;" title="Click to refresh image"><img class="cimage" src="login_files/GD_Security_image.jpg" alt="Captcha Image"></a></div>
<div style="margin-bottom: 10px; margin-left: 2px;" align="center"><font size="1"><b>Enter Code:</b></font> <input class="login" maxlength="6" size="30" style="font-size: 12px;" name="captcha" id="captcha" onblur="check(); return false;" type="text"></div>
<div style="margin-bottom: 10px;" align="center"><input value="Log in!" type="submit"></div>
<table border="0" cellpadding="4">
</table>
<input name="returnto" value="/" type="hidden">
</form>
<div align="center"><a href="login.php"><b>Login</b></a> | <a href="signup.php"><b>SignUp</b></a> | <a href="recover.php"><b>Recover</b></a></div>
</td></tr></tbody></table>
<div id="fadeinbox" style="opacity: 0;">
<div style="margin-top: 15px; margin-bottom: 40px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: bold; font-size: 15px; line-height: normal; font-size-adjust: none; font-stretch: normal; color: rgb(255, 0, 0);" align="center">ATENTIE! / ATENTION!</div>
<div style="margin-left: 5px; margin-bottom: 10px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: bold; font-size: 11px; line-height: normal; font-size-adjust: none; font-stretch: normal;" align="left">Romana:</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Acest
website este privat! Nici unul din fisierele care apar aici nu se afla
pe acest server (sunt excluse fisierele necesare ca acest website sa
functioneze corect).</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Link-urile sunt furnizate pe proprie raspundere de catre utilizatorii inregistrati.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Administratorii
website-ului xzone.hi2.ro (http://xzone.hi2.ro) nu pot fi trasi la
raspundere pentru ceea ce se posteaza sau pentru actiunile desfasurate
de catre utilizatorii website-ului.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Va
este interzis sa folositi acest website pentru a distribui orice fel de
material (date) daca nu aveti drepturi legale asupra detinerii si
transmiterii lui.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">In cazul in care observati un link protejat de lege va rugam sa ne contactati la admin@xzone.hi2.ro .<br>Orice
reclamatie inainte sa ne contactati va fi considerata drept un abuz
asupra website-ului xzone.hi2.ro (http://xzone.hi2.ro) si ne rezervam
dreptul de a cere despagubiri in valoare de 350.000 EURO persoanelor
implicate in comiterea acestui abuz.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Administratorii
website-ului xzone.hi2.ro (http://xzone.hi2.ro) nu pot verifica
continutul link-urilor valabile pe site fara a avea o reclamatie din
partea dvs. la admin@xzone.hi2.ro .</div>
<div style="text-align: left; margin-left: 15px; margin-bottom: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Este
obligatia dvs. sa va conformati acestor termeni de utilizare pentru a
putea folosi website-ul xzone.hi2.ro (http://xzone.hi2.ro).</div>
<div style="margin-left: 5px; margin-bottom: 10px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: bold; font-size: 11px; line-height: normal; font-size-adjust: none; font-stretch: normal;" align="left">English:</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">This
website is private! None of the files shown here are actually hosted on
this server (except for the necessary files this website needs to
operate correctly).</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">The links are provided solely by this website’s users.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">The
administrators of this website xzone.hi2.ro (http://xzone.hi2.ro)
cannot be held responsible for what its users post, or any other
actions of its users.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">You may not use this website to distribute or download any material when you do not have the legal rights to do so.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">In case you notice a link to a file copyrighted by law please contact us at admin@xzone.hi2.ro .<br>Any
complains before contacting us will be considered an abuse to our
website (http://xzone.hi2.ro) and we will demand compensation of
350.000 EURO from the people involved in committing this abuse.</div>
<div style="text-align: left; margin-left: 15px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Administrators
of xzone.hi2.ro (http://xzone.hi2.ro) can’t verify the content of the
links available on this website without receiving any complaints at
admin@xzone.hi2.ro .</div>
<div style="text-align: left; margin-left: 15px; margin-bottom: 30px; font-family: verdana; font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; line-height: normal; font-size-adjust: none; font-stretch: normal;">Usage of xzone.hi2.ro (http://xzone.hi2.ro) impose accepting the rules above.</div>
<div style="margin-bottom: 5px;" align="center"><a style="font-family: verdana; font-style: normal; font-variant: normal; font-weight: bold; font-size: 11px; line-height: normal; font-size-adjust: none; font-stretch: normal; color: rgb(0, 128, 0);" href="#" onclick="hidefadebox();return false">SUNT DE ACORD SI ACCEPT ACESTE REGULI! / I AGREE AND ACCEPT ALL THIS RULES!</a></div>
<div align="center"><a style="font-family: verdana; font-style: normal; font-variant: normal; font-weight: bold; font-size: 11px; line-height: normal; font-size-adjust: none; font-stretch: normal; color: rgb(255, 0, 0);" href="http://www.google.com/">NU SUNT DE ACORD CU ACESTE REGULI! / I DO NOT AGREE WITH THIS RULES !</a></div>
</div></td></tr></tbody></table></body></html>