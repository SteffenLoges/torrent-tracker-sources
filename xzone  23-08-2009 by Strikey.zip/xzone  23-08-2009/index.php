<?php
ob_start("ob_gzhandler");

require "include/bittorrent.php";

dbconn(true);
loggedinorreturn();

function mksize2($bytes)
{
if ($bytes < 1000 * 1024)
return number_format($bytes / 1024, 2);
elseif ($bytes < 1000 * 1048576)
return number_format($bytes / 1048576, 2);
elseif ($bytes < 1000 * 1073741824)
return number_format($bytes / 1073741824, 2);
else
return number_format($bytes / 1099511627776, 2);
}




$seeders = number_format($row['seeders']);
$leechers = number_format($row['leechers']);
$registered = number_format(get_row_count("users"));
$unverified = number_format($row['unconusers']);
$torrents = number_format($row['torrents']);
$torrentstoday = number_format($row['torrentstoday']);
$ratiounconn = $row['ratiounconn'];
$unconnectables = $row['unconnectables'];
$ratio = round(($row['ratio'] * 100));
$peers = number_format($row['peers']);
$totalonline = number_format($row['totalol']);
$donors = number_format($row['donors']);
$forumposts = number_format($row['forumposts']);
$forumtopics = number_format($row['forumtopics']);

$totaldown = mksize($row['totaldown']);
$totalup = mksize($row['totalup']);

$a = @mysql_fetch_assoc(@mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1")) or die(mysql_error());
if ($CURUSER)
$latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
else
$latestuser = $a['username'];


// Totalspeed mod
$resSpeed = mysql_query("SELECT seeders,leechers,id FROM torrents WHERE visible='yes' ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);
while ($rowTmp = mysql_fetch_array ($resSpeed)) {
$seedersTmp = $rowTmp['seeders'];
$leechersTmp = $rowTmp['leechers'];
$torrentId = $rowTmp['id'];
if ($seedersTmp >= 1 && $leechersTmp >= 1){
$spd = mysql_query("SELECT (t.size * t.times_completed + SUM(p.downloaded)) / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS totalspeed FROM torrents AS t LEFT JOIN peers AS p ON t.id = p.torrent AND p.torrent = '$torrentId' WHERE p.seeder = 'no' GROUP BY t.id ORDER BY added ASC") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_assoc($spd);
$tmpSpeed += $a["totalspeed"];
}
}

$dt = gmtime() - 60;
$dt = sqlesc(get_date_time($dt));
$result = mysql_query("SELECT SUM(last_access >= $dt) AS totalol FROM users") or sqlerr(__FILE__, __LINE__);

while ($row = mysql_fetch_array ($result))
{
$totalonline = $row["totalol"];
$rec = @mysql_fetch_array(@mysql_query("select * from onlinerec limit 1"));
if ($rec[users] < $totalonline) mysql_query("update onlinerec set users=$totalonline, date='".get_date_time()."' where users=$rec[users]");
}
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$res = mysql_query("SELECT id, username, class, donor, warned, enabled FROM users WHERE last_access >= $dt ORDER BY username") or print(mysql_error());
while ($arr = mysql_fetch_assoc($res))
{
if ($activeusers) $activeusers .= ",\n";
//// check active torrents ///////////////////////
$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . htmlspecialchars($arr["id"]) . " AND seeder='yes'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeseed = "$row[0]";

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . htmlspecialchars($arr["id"]) . " AND seeder='no'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeleech = "$row[0]";
//// end

if ($arr[added] == "0000-00-00 00:00:00")
$joindate = 'N/A';
else
$joindate = "<font color=grey>Member For</font> " . get_elapsed_time(sql_timestamp_to_unix_timestamp($arr["added"])) . "";

if ($arr["downloaded"] > 0)
{
$ratio = number_format($arr["uploaded"] / $arr["downloaded"], 3);
$ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
}
else
if ($arr["uploaded"] > 0)
$ratio = "Inf.";
else
$ratio = "---";

$uploaded = mksize($arr["uploaded"]);
$downloaded = mksize($arr["downloaded"]);
$username = $arr["username"];
$bonus = "$arr[seedbonus]";
$gender = "$arr[gender]";
if ($arr["avatar"])
$avatarover = $arr["avatar"];
elseif (!$arr["avatar"])
$avatarover = "/pic/default_avatar.gif";

switch ($arr["class"])
{


case UC_SL:
   $arr["username"] = "<font color=#FF8040>" . $arr["username"] . "</font>";
   break;
case UC_OWNER:
   $arr["username"] = "<font color=#C11B17>" . $arr["username"] . "</font>";
   break;
 case UC_SYSOP:
   $arr["username"] = "<font color=#800000>" . $arr["username"] . "</font>";
   break;

case UC_ADMINISTRATOR:
   $arr["username"] = "<font color=#FF5151>" . $arr["username"] . "</font>";
   break;
case UC_MODERATOR:
   $arr["username"] = "<font color=#005900>" . $arr["username"] . "</font>";
   break;
case UC_POWERUPLOADER:
   $arr["username"] = "<font color=#6464FF>" . $arr["username"] . "</font>";
   break;
case UC_UPLOADER:
   $arr["username"] = "<font color=#009F00>" . $arr["username"] . "</font>";
   break;
case UC_VIP:
   $arr["username"] = "<font color=#D4D42D>" . $arr["username"] . "</font>";
   break;

case UC_POWER_USER:
   $arr["username"] = "<font color=#D16587>" . $arr["username"] . "</font>";
   break;
case UC_USER:
   $arr["username"] = "<font color=#488AC7>" . $arr["username"] . "</font>";
   break;

}
$donator = $arr["donor"] === "yes";
if ($donator)
$activeusers .= "<nobr>";
$warned = $arr["warned"] === "yes";
if ($warned)
$activeusers .= "<nobr>";
if ($CURUSER)
$activeusers .= "<a href=userdetails.php?id={$arr["id"]}><b>{$arr["username"]}</b></a>";
else
$activeusers .= "<b>{$arr["username"]}</b>";

if ($arr['donated'] <= '10')
$donorpic = "star.gif";


if ($donator)
$activeusers .= "<img src=pic/{$donorpic} alt='Donated {$$arr["donor"]}'></nobr>";
if ($warned)
$activeusers .= "<img src={$pic_base_url}warned.gif alt='Warned {$$arr["warned"]}'></nobr>";
}
if (!$activeusers)
$activeusers = "There have been no active users in the last 15 minutes.";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$choice = $_POST["choice"];
if ($CURUSER && $choice != "" && $choice < 256 && $choice == floor($choice))
{
$res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
$arr = mysql_fetch_assoc($res) or die("No poll");
$pollid = $arr["id"];
$userid = $CURUSER["id"];
$res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid && userid=$userid") or sqlerr();
$arr = mysql_fetch_assoc($res);
if ($arr) die("Dupe vote");
mysql_query("INSERT INTO pollanswers VALUES(0, $pollid, $userid, $choice)") or sqlerr();
if (mysql_affected_rows() != 1)
stderr("Error", "An error occured. Your vote has not been counted.");
header("Location: $BASEURL/");
die;
}
else
stderr("Error", "Please select an option.");
}

// stat start
// stat - No. 1
function usertable($res) {
global $CURUSER;
?>
<tr><td class="colhead"><span>&nbsp;No. 1&nbsp; </span></td><td align="center" class="colhead"><img src="pic/smilies/thumbsup.gif" alt=""></td>
<?
$num = 0;
while ($a = mysql_fetch_assoc($res))
{
++$num;
$highlight = $USERID == $a["userid"] ? " bgcolor=#BBAF9B" : "";
if ($a["downloaded"])
{
$ratio = $a["uploaded"] / $a["downloaded"];
$color = get_ratio_color($ratio);
$ratio = number_format($ratio, 2);
if ($color)
$ratio = "<font color=$color>$ratio</font>";
}
else
$ratio = "Inf.";
print("<tr$highlight><td align=left$highlight><a href=userdetails.php?id=" .
$a["userid"] . "><b>" . $a["username"] . "</b></a>" .
"</td><td align=right$highlight>" . $ratio ."</td></tr>");
}}


// stat - countersink
function usertable2($res) {
global $CURUSER;
?>
<tr><td class="colhead"><span>&nbsp;countersink &nbsp; </span></td><td align="center" class="colhead"><img src="pic/smilies/thumbsdown.gif" alt=""></td>
<?
$num = 0;
while ($a = mysql_fetch_assoc($res)) {
++$num;
$highlight = $USERID == $a["userid"] ? " bgcolor=#BBAF9B" : "";
if ($a["downloaded"]) {
$ratio = $a["uploaded"] / $a["downloaded"];
$color = get_ratio_color($ratio);
$ratio = number_format($ratio, 2);
if ($color)
$ratio = "<font color=$color>$ratio</font>";
}
else
$ratio = "Inf.";
print("<tr$highlight><td align=left$highlight><a href=userdetails.php?id=" .
$a["userid"] . "><b>" . $a["username"] . "</b></a>" .
"</td><td align=right$highlight>" . $ratio ."</td></tr>");
}}

if (!$CURUSER) {
$ip = getip();
}

// stat - Full traffic mod
$resSpeed = mysql_query("SELECT seeders,leechers,id FROM torrents WHERE visible='yes' ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);
while ($rowTmp = mysql_fetch_array ($resSpeed)) {
$seeders = $row['seeders'];
$leechers = $row['leechers'];
$torrentId = $rowTmp['id'];
}

$registered = number_format(get_row_count("users"));
$unverified = number_format(get_row_count("users", "WHERE status='pending'"));
$torrents = number_format(get_row_count("torrents"));
$disabled = number_format(get_row_count("users", "WHERE enabled='no'"));
$r = mysql_query("SELECT value_u FROM avps WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = 0 + $a[0];
$r = mysql_query("SELECT value_u FROM avps WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = number_format(get_row_count("peers", "WHERE seeder='yes'"));
$leechers = number_format(get_row_count("peers", "WHERE seeder='no'"));
$peers = number_format($seeders + $leechers);
$uniqpeer = number_format(get_row_count("peers", "WHERE connectable='yes'"));
if ($leechers == 0)
$ratio = 0;
else
$ratio = round($seeders / $leechers * 100);
$totaldownloaded = mksize($row["totaldl"]);
$totaluploaded = mksize($row["totalul"]);
$USER = number_format(get_row_count("users", "WHERE class='".UC_USER."'"));
$PU = number_format(get_row_count("users", "WHERE class='".UC_POWER_USER."'"));
$dead = number_format(get_row_count("torrents", "WHERE visible='no'"));
$VIP = number_format(get_row_count("users", "WHERE class='".UC_VIP."'"));
$donated = number_format(get_row_count("users", "WHERE donor = 'yes'"));
$registered = number_format(get_row_count("users"));
$torrents = number_format(get_row_count("torrents"));
$posts = number_format(get_row_count("posts"));
$topics = number_format(get_row_count("topics"));
$todayreg= get_row_count('users', 'WHERE added > DATE_SUB(NOW(), INTERVAL 1 DAY)');
$r = mysql_query("SELECT value_u FROM avps WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = 0 + $a[0];
$r = mysql_query("SELECT value_u FROM avps WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$leechers = 0 + $a[0];
$seeders = number_format(get_row_count("peers", "WHERE seeder='yes'"));
$leechers = number_format(get_row_count("peers", "WHERE seeder='no'"));
$peers = number_format($seeders + $leechers);
$uniqpeer = number_format(get_row_count("peers", "WHERE connectable='yes'"));
if ($leechers == 0)
$null = 0;

{
$totalonline = $row["totalol"];
$rec = @mysql_fetch_array(@mysql_query("select * from onlinerec limit 1"));
if ($rec[users] < $totalonline) mysql_query("update onlinerec set users=$totalonline, date='".get_date_time()."' where users=$rec[users]");
}
// peer - seed - leech
$r = mysql_query("SELECT SUM(seeders) FROM torrents") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = 0 + $a[0];

$r = mysql_query("SELECT SUM(leechers) FROM torrents") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$leechers = 0 + $a[0];

if ($leechers == 0)
$ratio = 0;
else
$ratio = round($seeders / $leechers * 100);

$peers = round($seeders + $leechers);
$seeders = round($seeders);
$leechers = round($leechers);
$peers = ($leechers + $seeders);
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$result = mysql_query("SELECT SUM(last_access >= $dt) AS totalol FROM users") or sqlerr(__FILE__, __LINE__);

while ($row = mysql_fetch_array ($result))
{
$totalonline = $row["totalol"];
}

// totally download data


$result = mysql_query("SELECT SUM(downloaded) AS totaldl, SUM(uploaded) AS totalul FROM users") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_assoc($result);
$totaldownloaded = mksize($row["totaldl"]);
$totaluploaded = mksize($row["totalul"]);
//$totaldata = $totaldownloaded+$totaluploaded;
$totaldata = mksize($row["totaldl"]+$row["totalul"]);


// warned users
$warnedu = number_format(get_row_count("users", "WHERE warned='yes'"));


// full speed data
//$result = mysql_query("SELECT SUM(downspeed) AS totalds, SUM(upspeed) AS totalus FROM xbt_files_users") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_assoc($result);

$totaldownloadspeed = $row["totalds"];
$totaluploadspeed = $row["totalus"];
$totalspeed = $totaluploadspeed+$totaldownloadspeed;


// latest users mod
$a = @mysql_fetch_assoc(@mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1")) or die(mysql_error());
if ($CURUSER)
$latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
else
$latestuser = $a['username'];

// all the size of torrent
$qQ = mysql_query("SELECT size FROM torrents");
while($rts = mysql_fetch_assoc($qQ)) {
$alltsize = $alltsize + $rts[size];
}

$alltsize = mksize($alltsize);
// stat end!!!


loggedinorreturn();
/*
$a = @mysql_fetch_assoc(@mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1")) or die(mysql_error());
if ($CURUSER)
$latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
else
$latestuser = $a['username'];
*/

$registered = number_format(get_row_count("users" , "WHERE enabled='yes'"));
//$unverified = number_format(get_row_count("users", "WHERE status='pending'"));
$torrents = number_format(get_row_count("torrents"));
//$dead = number_format(get_row_count("torrents", "WHERE visible='no'"));

$r = mysql_query("SELECT value_u FROM avps WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = 0 + $a[0];
$r = mysql_query("SELECT value_u FROM avps WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$leechers = 0 + $a[0];
if ($leechers == 0)
$ratio = 0;
else
$ratio = round($seeders / $leechers * 100);
$peers = number_format($seeders + $leechers);
$seeders = number_format($seeders);
$leechers = number_format($leechers);

/*
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$res = mysql_query("SELECT id, username, class, donated FROM users WHERE last_access >= $dt ORDER BY username") or print(mysql_error());
while ($arr = mysql_fetch_assoc($res))
{
if ($activeusers) $activeusers .= ",\n";
switch ($arr["class"])
{
case UC_SYSOP:
case UC_ADMINISTRATOR:
case UC_MODERATOR:
$arr["username"] = "<font color=#A83838>" . $arr["username"] . "</font>";
break;
case UC_UPLOADER:
$arr["username"] = "<font color=#4040C0>" . $arr["username"] . "</font>";
break;
}
$donator = $arr["donated"] > 0;
if ($donator)
$activeusers .= "<nobr>";
if ($CURUSER)
$activeusers .= "<a href=userdetails.php?id=" . $arr["id"] . "><b>" . $arr["username"] . "</b></a>";
else
$activeusers .= "<b>$arr[username]</b>";
if ($donator)
$activeusers .= "<img src=\"{$pic_base_url}star.gif\" alt='Donated $$arr[donated]'></nobr>";
}
if (!$activeusers)
$activeusers = "There have been no active users in the last 15 minutes.";
*/





stdhead("Home");
echo "<font class=small>Welcome to our newest member, <b>$latestuser</b>!</font><br>\n";
if (!$CURUSER) {
$ip = getip();
$guests = mysql_query("SELECT ip FROM guests WHERE ip = '$ip'") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($guests) == 0)
mysql_query("INSERT INTO guests (ip, time_accessed) VALUES ('$ip', '" . get_date_time() . "')") or sqlerr(__FILE__, __LINE__);
}

$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$res = mysql_query("SELECT id FROM guests WHERE time_accessed < $dt");
if (mysql_num_rows($res) > 0)
{
while ($arr = mysql_fetch_assoc($res))
 {
 mysql_query("DELETE FROM guests WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
 }
}
$guests_online = number_format(get_row_count("guests"));

if ($guests_online != 1)
$_s = "s";
else
$_s = "";
print("<p><table align=center class=main width=740 cellspacing=0 cellpadding=5 border=0><tr><td class=clear align=center style='padding-bottom: 20px'><center><table width=100% class=main cellpadding=5>");

$res = mysql_query("SELECT * FROM news WHERE ADDDATE(added, INTERVAL 45 DAY) > NOW() ORDER BY added DESC LIMIT 4") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0)
{
$counter = 1;
while($array = mysql_fetch_array($res))
{


$user = mysql_fetch_assoc(mysql_query("SELECT username FROM users WHERE id = $array[userid]")) or sqlerr();



if($counter == "1"){
if (get_user_class() < UC_ADMINISTRATOR){
print("<tr><td width=650 valign=top class=embedded><p><table cellpadding=5 width=650 ><tr><td class=colhead><font color=#DC143C>&nbsp;&nbsp;Recent News </font></td></tr><tr><td class=dark><font color=#DC143C>&nbsp;" . gmdate("M-d-y",strtotime($array['added'])) . " - " ."<b>". $array['title'] . "</b></font></td></tr>
<tr><td style='padding-left: 20px;'><div id=\"ka".$array['id']."\" style=\"display: block;\"> ".format_comment($array["body"],0). "</div><br>
<b><p align=left>:: <b><a href=userdetails.php?id=" . $array['userid'] . ">$user[username]</a></b>");
}
if (get_user_class() >= UC_ADMINISTRATOR){
print("<tr><td width=650 valign=top class=embedded><p><table cellpadding=5 width=650 ><tr><td class=colhead>&nbsp;&nbsp;Recent News <font class=small>[<a class=altlink href=news.php>News page</a>]</font></td></tr><tr><td class=dark><font color=#DC143C>&nbsp;" . gmdate("M-d-y",strtotime($array['added'])) . " - " ."<b>". $array['title'] . "</b></font></td></tr>
<tr><td style='padding-left: 20px;'><div id=\"ka".$array['id']."\" style=\"display: block;\"> ".format_comment($array["body"],0). "</div><br>
<b><p align=left>:: <b><a href=userdetails.php?id=" . $array['userid'] . ">$user[username]</a></b>");
}
}
if($counter > "1"){
if (get_user_class() < UC_ADMINISTRATOR){
print("<tr><td width=650 valign=top class=embedded><p><table cellpadding=5 width=650 ><tr><td class=dark><font color=#DC143C>&nbsp;" . gmdate("M-d-y",strtotime($array['added'])) . " - " ."<b>". $array['title'] . "</b></font></td></tr>
<tr><td style='padding-left: 20px;'><div id=\"ka".$array['id']."\" style=\"display: block;\"> ".format_comment($array["body"],0). "</div><br>
<b><p align=left>:: <b><a href=userdetails.php?id=" . $array['userid'] . ">$user[username]</a></b>");
}
if (get_user_class() >= UC_ADMINISTRATOR){
print("<tr><td width=650 valign=top class=embedded><p><table cellpadding=5 width=650 ><tr><td class=dark><font color=#DC143C>&nbsp;" . gmdate("M-d-y",strtotime($array['added'])) . " - " ."<b>". $array['title'] . "</b></font></td></tr>
<tr><td style='padding-left: 20px;'><div id=\"ka".$array['id']."\" style=\"display: block;\"> ".format_comment($array["body"],0). "</div><br>
<b><p align=left>:: <b><a href=userdetails.php?id=" . $array['userid'] . ">$user[username]</a></b>");
}
}



$counter = $counter + 1;


if (get_user_class() >= UC_ADMINISTRATOR)
{
print(" <font size=\"-2\"> &nbsp; [<a class=altlink href=news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>E</b></a>]</font>");
print(" <font size=\"-2\">[<a class=altlink href=news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>D</b></a>]</font>");

}

print("</td></tr></table></p><p>");
}
print("</table>");
}

if ($CURUSER)
{
?>
<h2 align="center">Last Forum Posts</h2>
<table width=650  border=1 cellspacing=0 cellpadding=10><tr><td width=630  align=center>
<? latestforumposts(); ?>
</td></tr></table>

<?

// Get current poll
$res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
if($pollok=(mysql_num_rows($res)))
{
$arr = mysql_fetch_assoc($res);
$pollid = $arr["id"];
$userid = $CURUSER["id"];
$question = format_comment($arr["question"]);
$o = array( $arr["option1"], $arr["option2"], $arr["option3"], $arr["option4"],
$arr["option5"], $arr["option6"], $arr["option7"], $arr["option8"], $arr["option9"],
$arr["option10"], $arr["option11"], $arr["option12"], $arr["option13"], $arr["option14"],
$arr["option15"], $arr["option16"], $arr["option17"], $arr["option18"], $arr["option19"]);

// Check if user has already voted
$res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid AND userid=$userid") or sqlerr();
$arr2 = mysql_fetch_assoc($res);
}
print("<td width=200 valign=top class=embedded style='padding-left: 15px;'><table width=200 cellpadding=10>");
if (get_user_class() < UC_MODERATOR)
print("<tr><td class=colhead><font size=1>Poll</font></td></tr>");
if (get_user_class() >= UC_MODERATOR) {
print("<tr><td class=colhead><font size=1>Poll <font class=small>[<a class=altlink href=makepoll.php?returnto=main><b>New</b></a>]");
if($pollok) {
print(" [<a class=altlink href=makepoll.php?action=edit&pollid=$arr[id]&returnto=main><b>Edit</b></a>]\n");
print(" [<a class=altlink href=polls.php?action=delete&pollid=$arr[id]&returnto=main><b>Delete</b></a>]");
}
print("</font></td></tr><tr>");
}
//print("</td></tr></table>\n");
if($pollok) {
print("<tr><td align=left><div><font color=white><b>&raquo; $question</b></font></div>");

$voted = $arr2;
if ($voted)
{
// display results
if ($arr["selection"])
$uservote = $arr["selection"];
else
$uservote = -1;
// we reserve 255 for blank vote.
$res = mysql_query("SELECT selection FROM pollanswers WHERE pollid=$pollid AND selection < 20") or sqlerr();

$tvotes = mysql_num_rows($res);

$vs = array(); // array of
$os = array();

// Count votes
while ($arr2 = mysql_fetch_row($res))
$vs[$arr2[0]] += 1;

reset($o);
for ($i = 0; $i < count($o); ++$i)
if ($o[$i])
$os[$i] = array($vs[$i], $o[$i]);

function srt($a,$b)
{
if ($a[0] > $b[0]) return -1;
if ($a[0] < $b[0]) return 1;
return 0;
}

// now os is an array like this: array(array(123, "Option 1"), array(45, "Option 2"))
if ($arr["sort"] == "yes")
usort($os, srt);

print("<br><table width=100% border=0 cellspacing=0 cellpadding=0>\n");
$i = 0;
while ($a = $os[$i])
{
if ($i == $uservote)
$a[1] .= "&nbsp;*";
if ($tvotes == 0)
$p = 0;
else
$p = round($a[0] / $tvotes * 100);
if ($i % 2)
$c = "";
else
$c = " bgcolor=#ECE9D8";
print("<tr><td style='margin-bottom: 5px;' width=1% class=embedded><font size=1>" . $a[1] . "<div style='background:transparent; margin-bottom: 5px; padding: 4px;'><img style='vertical-align: -10%;' src='/pic/bar_left.gif'><img src=\"{$pic_base_url}bar.gif\" height=9 width=" . ($p * 1.5) . "><img style='vertical-align: -10%;' src='/pic/bar_right.gif'> $p%</font></div></td></tr>");
++$i;
}
print("</table>\n");
$tvotes = number_format($tvotes);
if ($voted)
print("<font size=1><center>Votes: $tvotes</center></font><br><div align=center ><small><a href=polls.php>Previous Polls</a>&nbsp;</small></div></td></tr></table></form><br>");
}
else
{
print("<form method=post action=index.php>\n");
$i = 0;
while ($a = $o[$i])
{
print("<input type=radio name=choice value=$i>$a<br>\n");
++$i;
}
print("<br>");
print("<input type=radio name=choice value=255>Blank vote (a.k.a. \"I just want to see the results!\")<br>\n");
print("<p align=center><input type=submit value='Vote!' class=btn></p></td></table><br />");
}

} else {
echo "<td width=300 valign=top class=embedded style='padding-left: 15px;'><table width=100% cellpadding=5>";
echo "<br><table width=100% border=0 cellspacing=0 cellpadding=0>\n";
echo"<p align=center><H3>No Active Polls</h3></p>\n";
echo "</table></table>";
}
}
?>


<table width=100% cellpadding=5><tr><td class=colhead><font size=1>Site Statistics</font></td></tr>
<tr><td><font color=#DC143C>Users Informations:</font>
<br><font size=1>Online Since: 5-07-2009<br>User Limit: <?= $maxusers; ?><br>Registered: <?=$registered?><br>Registered Today: <?=$todayreg?><br>Users Online: <?= $totalonline; ?><br>Guests Online: <?=$guests_online?><br>Unconfirmed users: <?= $unverified; ?><br>Warned: <?=$warnedu?><br>Disabled: <?=$disabled?><br>Donors: <?=$donated?><br>VIP's: <?=$VIP?><br>Power Users: <?=$PU?><br> </font>
<br><font color=#DC143C>Tracker Information:</font><br><font size=1>Torrents: <?= $torrents; ?><br>Dead Torrents: <?=$dead?><br>Peers: <?=$uniqpeer?><br>Forum Posts: <?=$posts?><br>Forum Topics: <?=$topics?><br>All the size of torrent: <?=$alltsize?><br>Total Uploaded: <?=$totaluploaded?><br>Total Downloaded: <?=$totaldownloaded?><br>Total Traffic: <?=$totaldata?></font>
<br><div class=colhead padding: 3px;'><a class=altlink style='font-weight: normal;' title='Click to show/hide list' href='javascript: klappe_news("a2")'><center><font color=ff0000>Disclaimer</font></center></a></div><div id='ka2' style='display: none;'><div style='background-color: #; padding: 3px;'><small>None of the files shown here are actually hosted on this server. The links are provided solely by this site's users.
The administrator of this site cannot be held responsible for what its users post, or any other actions of its users.
You may not use this site to distribute or download any material when you do not have the legal rights to do so.
It is your own responsibility to adhere to these terms.</small>

</font></div></div></td></tr></table>

</td></tr></table>

<h2 >Shoutbox</h2>
        <script language=javascript>
function SmileIT(smile,form,text){
   document.forms[form].elements[text].value = document.forms[form].elements[text].value+" "+smile+" ";
   document.forms[form].elements[text].focus();
}
</script>

<script LANGUAGE="JavaScript"><!--
function mySubmit() {
   setTimeout('document.shbox.reset()',100);
}
//--></SCRIPT>

<table width='85%' border='2' cellspacing='0' cellpadding='0'><td class=text>
<iframe src='shoutbox.php' width='100%' height='300' align='center' frameborder='0' name='sbox' marginwidth='0' marginheight='0'></iframe><br><br>
<form action='shoutbox.php' method='get' target='sbox' name='shbox' onSubmit="mySubmit()">
<p align="center">Message: <input type='text' name='shbox_text' size='80'> <input type='submit' value=' Shout '>
<input type='hidden' name='sent' value='yes'><br>
<center>
<a href="javascript: SmileIT('[b]text[/b]','shbox','shbox_text')"><b><font class="activeshbox">B</font></b></a>��
<a href="javascript: SmileIT('[i]text[/i]','shbox','shbox_text')"><b><i><font class="activeshbox">i</font></i></b></a>��
<a href="javascript: SmileIT('[u]text[/u]','shbox','shbox_text')"><b><u><font class="activeshbox">U</font></u></b></a>��
<a href="javascript: SmileIT('[url]http://[/url]','shbox','shbox_text')"><b><font class="activeshbox">url</font></b></a>��
<a href="javascript: SmileIT('[img]link[/img]','shbox','shbox_text')"><b><font class="activeshbox">img</font></b></a>��
<a href="javascript: SmileIT('[color=red]text[/color]','shbox','shbox_text')"><font color=red><b>TEXT</b></font></a>��
<a href="javascript: SmileIT('[color=grean]text[/color]','shbox','shbox_text')"><font color=grean><b>TEXT</b></font></a>��
<a href="javascript: SmileIT('[color=blue]text[/color]','shbox','shbox_text')"><font color=blue><b>TEXT</b></font></a>��
</br></br>
<a href="javascript: SmileIT(':-)','shbox','shbox_text')"><img border=0 src=pic/smilies/smile1.gif></a>
<a href="javascript: SmileIT(':-)','shbox','shbox_text')"><img border=0 src=pic/smilies/smile1.gif></a>
<a href="javascript: SmileIT(':smile:','shbox','shbox_text')"><img border=0 src=pic/smilies/smile2.gif></a>
<a href="javascript: SmileIT(':-D','shbox','shbox_text')"><img border=0 src=pic/smilies/grin.gif></a>
<a href="javascript: SmileIT(':evo:','shbox','shbox_text')"><img src=pic/smilies/evo.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':-|','shbox','shbox_text')"><img border=0 src=pic/smilies/noexpression.gif></a>
<a href="javascript: SmileIT(':-/','shbox','shbox_text')"><img border=0 src=pic/smilies/confused.gif></a>
<a href="javascript: SmileIT(':weep:','shbox','shbox_text')"><img src=pic/smilies/weep.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':-O','shbox','shbox_text')"><img src=pic/smilies/ohmy.gif border=0></a>
<a href="javascript: SmileIT(':sly:','shbox','shbox_text')"><img src=pic/smilies/sly.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':greedy:','shbox','shbox_text')"><img src=pic/smilies/greedy.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':sneaky:','shbox','shbox_text')"><img src=pic/smilies/sneaky.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':kiss:','shbox','shbox_text')"><img src=pic/smilies/kiss.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':geek:','shbox','shbox_text')"><img src=pic/smilies/geek.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':evil:','shbox','shbox_text')"><img src=pic/smilies/evil.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':shit:','shbox','shbox_text')"><img src=pic/smilies/shit.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':?:','shbox','shbox_text')"><img src=pic/smilies/question.gif width="18" height="18" border=0></a>
<a href="javascript: SmileIT(':!:','shbox','shbox_text')"><img src=pic/smilies/idea.gif width="18" height="18" border=0></a>
<center>
<a href="smilies.php"><b><u><font class="activechat">More Smilies</font></u></b></a> / <a href='shoutbox.php' target='sbox'><b><u><font color=grean>Refresh</font></u></b></a>
</td></tr></table></form>
 </center>
<center><h2><font face="Comic Sans MS">
&nbsp; Active users : [ <?=$totalonline?> ]  
</h2></center></font>

       <table width=80% border="1" align="center">
</tr>
</table>
<table width=85% border=1 cellspacing=0 cellpadding=8><tr>
  <td class=text>
<?=$activeusers?></td>

</tr></table>


<h2 align="center">Torrents stats</h2>
<table width="85%" border="1" cellpadding="8" cellspacing="0" align="center">
<tr><td align="center" >
<?
$res = mysql_query("SELECT id, seeders, poster, leechers, name from torrents ORDER BY seeders + leechers DESC LIMIT 10 ") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0) {
print("<center><table class=tableinborder border=2 cellspacing=0 cellpadding=5>\n");
print("<tr><td class=\"colhead\"><b><font color=red>Top 10 torrents</b></font></td><td class=\"colhead\"><img src=pic/arrowup.gif></a></td><td class=\"colhead\"><img src=pic/arrowdown.gif></td></tr>\n");
while ($arr = mysql_fetch_assoc($res)) {
$torrname = htmlspecialchars($arr['name']);
if (strlen($torrname) > 35)
$torrname = substr($torrname, 0,35) . "...";
$poster = $arr["poster"];
if (!empty($arr["poster"])){
$poster1 = "<table border=0 class=embedded cellspacing=0><td border=0 class=embedded align=center width=150 height=220><img src=$poster width=150 height=220></td>";
}
else{
$poster1 = "<table border=0 class=embedded cellspacing=0><td border=0 class=embedded align=center width=150 height=220><img src=/pic/noposter.png width=150 height=220></td>";
}

print("<tr><td class=tablea ><a onmouseover=\"{overlib('$poster1', WIDTH, 150, DELAY, 100);}\" onmouseout=\"return nd();\" href=\"details.php?id=".$arr['id']."&hit=1\" alt=\"".$arr['name']."\" title=\"".$arr['name']."\">".$torrname."</td><td >".$arr['seeders']."</a></td><td >".number_format($arr['leechers'])."</td></tr>\n");
}
print("</table>\n");
} else
print("no torrents here :(");
?>
</td><td style="width:15px;"></td>

<td align="center">
<?
$sql = "SELECT id, seeders, poster, leechers, name FROM torrents WHERE visible='yes' ORDER BY added DESC LIMIT 10";
$result = mysql_query($sql) or sqlerr(__FILE__, __LINE__);

if( mysql_num_rows($result) != 0 ){
print("<table border=1 cellspacing=0 cellpadding=5>");
print("<tr>");
print("<td class=colhead><b><font color=red>Last 10 torrents</b></font></td>");
print("<td class=colhead><img src=pic/arrowup.gif></td>");
print("<td class=colhead><img src=pic/arrowdown.gif></td>");
print("</tr>");

while( $arr = mysql_fetch_assoc($result) ){
$torrname = htmlspecialchars($arr['name']);
if (strlen($torrname) > 35)
$torrname = substr($torrname, 0,35) . "...";
$poster = $arr["poster"];
if (!empty($arr["poster"])){
$poster1 = "<table border=0 class=embedded cellspacing=0><td border=0 class=embedded align=center width=150 height=220><img src=$poster width=150 height=220></td>";
}
else{
$poster1 = "<table border=0 class=embedded cellspacing=0><td border=0 class=embedded align=center width=150 height=220><img src=/pic/noposter.png width=150 height=220></td>";
}
print("<tr>");
print("<a href=\"details.php?id=".$arr['id']."&hit=1\"><td><a href=\"details.php?id=".$arr['id']."&hit=1\" onmouseover=\"{overlib('$poster1', WIDTH, 150, DELAY, 100);}\" onmouseout=\"return nd();\"><b>".$torrname."</b></td></a>");
print("<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;" . $arr['seeders'] . "</td>");
print("<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;" . $arr['leechers'] . "</td>");
print("</tr>");
}
print("</table>");
}?>




<?
stdfoot();
?>