<?php
require "include/bittorrent.php";
dbconn();

loggedinorreturn();


stdhead("Speed Test");
begin_main_frame();

?>
<tr><td align=center>Speed Test requires at least version 7 of Flash. <a href="http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash">Please update your client</a><tr>
<center>
<iframe src="http://www.speedtest.net/mini/speedtest.swf?v=2.0.7" name="minitest" width="830" height="750" scrolling="no"></iframe>
</center>

<?
end_main_frame();
stdfoot();
?>