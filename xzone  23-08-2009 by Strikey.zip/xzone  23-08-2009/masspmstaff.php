<?
require "include/bittorrent.php";
dbconn();
loggedinorreturn();
if (get_user_class() < UC_MODERATOR)
stderr("Error", "Access denied.");
stdhead("Mass PM");
if ($_POST['message'] != "")
{
$num=0;
foreach( array_keys($_POST) as $x)
{
 if (substr($x,0,3) == "UC_"){
  $querystring .= " OR class = ".constant($x);
  $classnames .= substr($x,3).", ";
  $num++;
 }
}

if ($num == $_POST["numclasses"]){
 $res = mysql_query("SELECT id FROM users");
 $msg = $_POST['message']  . "\n\nNOTICE: This is a mass pm, it has been sent to everyone";
}else{
 $res = mysql_query("SELECT id FROM users where id = 1".$querystring) or sqlerr(__FILE__, __LINE__);
 $msg = $_POST['message']  . "\n\nNOTICE: This is a mass pm, it has been sent to the following classes: " . substr($classnames,0,(strlen($classnames)-2));
}

if ($_POST["fromsystem"] == "yes"){ $sender_id="0";}else{$sender_id = $CURUSER["id"];}

while($arr = mysql_fetch_row($res))
{
 mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES ($sender_id, $arr[0], '" . get_date_time() . "', " . sqlesc($msg) . ", $sender_id)") or sqlerr(__FILE__, __LINE__);
}

print("<b>Mass Private Message Dispatched.</b><br>");
}


?>
<h1>Mass PM</h1>
<form method=post action="masspmstaff.php">
<table border=1 cellspacing=0 cellpadding=5 class="main" >
<tr><td colspan=2 class="rowhead"><div align=left>Send To (check all that apply):</div></td></tr>
<tr><td colspan=2>
<?
$numclasses=0;
$constants = get_defined_constants ();
foreach( array_keys($constants) as $x)
{
if (substr($x,0,3) == "UC_"){
 echo "<input name=\"".$x."\" type=\"checkbox\" value=1 checked>".substr($x,3)."<br>";
 $numclasses++;
}
}
?>
<input type="hidden" name="numclasses" value="<? echo $numclasses; ?>" />
</td></tr>
<tr><td class="rowhead">Message</td><td><textarea cols=60 rows=6 name="message"></textarea></td></tr>
<tr><td class="rowhead">System</td><td><input type="checkbox" name="fromsystem" value="yes" />Say the message was sent by 'system'</td>
<tr><td align="center" colspan=2><input type="submit" value="Okay" class="btn" /></td></tr>
</table>
</form>
<? stdfoot(); ?>