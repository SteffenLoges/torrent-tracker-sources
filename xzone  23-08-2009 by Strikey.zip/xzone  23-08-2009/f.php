<?php
ob_start("ob_gzhandler");
require "include/bittorrent.php";
  dbconn(false);

  loggedinorreturn();
if ($CURUSER["forumban"] == "yes")
  stderr("Banned", "You have been banned from the forums.");
  $wherethisuser = where ($_SERVER["SCRIPT_FILENAME"],$CURUSER["id"]);

  iplogger();
	parked();
  $action = htmlspecialchars(trim($_GET["action"]));
  
  function forum_stats () {
	  global $showforumstats,$pic_base_url;
  if ($showforumstats == "yes") {
$forum_t = gmtime() - 180; //you can change this value to whatever span you want
$forum_t = sqlesc(get_date_time($forum_t));
$res = sql_query("SELECT id, username, class, warned, donor FROM users WHERE forum_access >= $forum_t ORDER BY forum_access DESC") or print(mysql_error());
while ($arr = mysql_fetch_assoc($res))
{
if ($forumusers) $forumusers .= ",\n";
switch ($arr["class"])
{
case UC_STAFFLEADER:
   $arr["username"] = "<font color=darkred>" . $arr["username"] . "</font>";
   break;
case UC_SYSOP:
   $arr["username"] = "<font color=#2587A7>" . $arr["username"] . "</font>";
   break;
case UC_ADMINISTRATOR:
   $arr["username"] = "<font color=#B000B0>" . $arr["username"] . "</font>";
   break;
case UC_MODERATOR:
   $arr["username"] = "<font color=#ff5151>" . $arr["username"] . "</font>";
   break;
case UC_UPLOADER:
   $arr["username"] = "<font color=#6464FF>" . $arr["username"] . "</font>";
   break;
case UC_VIP:
   $arr["username"] = "<font color=#009F00>" . $arr["username"] . "</font>";
   break;
case UC_CODE:
   $arr["username"] = "<font color=#f9g200>" . $arr["username"] . "</font>";
   break;
case UC_XTREME_USER:
   $arr["username"] = "<font color=#f9b200>" . $arr["username"] . "</font>";
   break;
case UC_POWER_USER:
   $arr["username"] = "<font color=#f9a200>" . $arr["username"] . "</font>";
   break;
}
$donator = $arr["donor"] === "yes";
if ($donator)
$forumusers .= "<nobr>";
$warned = $arr["warned"] === "yes";
if ($donator)
$forumusers .= "<nobr>";
if ($CURUSER)
$forumusers .= "<a href=userdetails.php?id={$arr["id"]}><b>{$arr["username"]}</b></a>";
else
$forumusers .= "<b>{$arr["username"]}</b>";
if ($donator)
$forumusers .= "<img src={$pic_base_url}star.gif alt='Donated {$$arr["donor"]}'></nobr>";
if ($warned)
$forumusers .= "<img src={$pic_base_url}warned.gif alt='Warned {$$arr["warned"]}'></nobr>";
}
if (!$forumusers)
$forumusers = "There have been no active users in the last 15 minutes.";
?>
<br>
<table width=737 border=1 cellspacing=0 cellpadding=5><tr>
<td class="colhead" align="left">Active Forum Users</td></tr>
</tr><td class=text>
<center><font color=red><b>Staff Leader</b></font> - <font color=#2587A7><b>SysOp</b></font> - <font color=#B000B0><b>Admin</b></font> - <font color=#ff5151><b>Moderator</b></font> - <font color=#6464FF><b>Uploader</b> - </font><font color=#009F00><b>VIP</b> - </font><font color=#f9a200><b>Power User</b> - </font><font color=cccccc><b>User</b></font></center>
<hr/>
<?=$forumusers?>
</td></tr></table>
<?
print("<table width=737 border=1 cellspacing=0 cellpadding=5>\n");

print("<tr><td class=colhead>Stats</td></tr>\n");

$registered = number_format(get_row_count("users", "WHERE enabled = 'yes'"));
$donated = number_format(get_row_count("users", "WHERE donor = 'yes'"));

$a = @mysql_fetch_assoc(@sql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1")) or die(mysql_error());
if ($CURUSER)
$latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
else
$latestuser = $a['username'];

$forumusers = number_format(get_row_count("users", "WHERE UNIX_TIMESTAMP(" . get_dt_num() . ") - UNIX_TIMESTAMP(forum_access) < 1200"));

$topiccount = sql_query("select sum(topiccount) as topiccount from forums");
$row1 = mysql_fetch_array($topiccount);
$topiccount = $row1[topiccount];

$postcount = sql_query("select sum(postcount) as postcount from forums");
$row2 = mysql_fetch_array($postcount);
$postcount = $row2[postcount];

print("<tr><td align=left>
&raquo;&nbsp;Our members have made <b><font color=#0000FF>" . $postcount . "</font></b> posts in <b><font color=#0000FF>" . $topiccount . "</font></b> topics,<BR>
&raquo;&nbsp;We have <b><font color=#0000FF>" . $registered . "</font></b> users,<BR>
&raquo;&nbsp;We have <b><font color=#0000FF>" . $donated . "</font></b> donors,<BR>
&raquo;&nbsp;Our newest member is <b>" . $latestuser . "</b>, <BR>
&raquo;&nbsp;<b><font color=#0000FF>" . $forumusers . "</font></b> online users in forum now.</td></tr>\n");

print("</table>");
}
}

  function catch_up()
  {
	//die("This feature is currently unavailable.");
    global $CURUSER;

    $userid = 0+$CURUSER["id"];

    $res = sql_query("SELECT id, lastpost FROM topics") or sqlerr(__FILE__, __LINE__);

    while ($arr = mysql_fetch_assoc($res))
    {
      $topicid = 0+$arr["id"];

      $postid = $arr["lastpost"];

      $r = sql_query("SELECT id,lastpostread FROM readposts WHERE userid=$userid and topicid=$topicid") or sqlerr(__FILE__, __LINE__);

      if (mysql_num_rows($r) == 0)
        sql_query("INSERT INTO readposts (userid, topicid, lastpostread) VALUES($userid, $topicid, $postid)") or sqlerr(__FILE__, __LINE__);

      else
      {
        $a = mysql_fetch_assoc($r);

        if ($a["lastpostread"] < $postid)
          sql_query("UPDATE readposts SET lastpostread=$postid WHERE id=" . $a["id"]) or sqlerr(__FILE__, __LINE__);
      }
    }
  }

  //-------- Returns the minimum read/write class levels of a forum

  function get_forum_access_levels($forumid)
  {
    $res = sql_query("SELECT minclassread, minclasswrite, minclasscreate FROM forums WHERE id=".mysql_real_escape_string($forumid)) or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($res) != 1)
      return false;

    $arr = mysql_fetch_assoc($res);

    return array("read" => $arr["minclassread"], "write" => $arr["minclasswrite"], "create" => $arr["minclasscreate"]);
  }

  //-------- Returns the forum ID of a topic, or false on error

  function get_topic_forum($topicid)
  {
    $res = sql_query("SELECT forumid FROM topics WHERE id=".mysql_real_escape_string($topicid)) or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($res) != 1)
      return false;

    $arr = mysql_fetch_row($res);

    return $arr[0];
  }

  //-------- Returns the ID of the last post of a forum

  function update_topic_last_post($topicid)
  {
    $res = sql_query("SELECT id FROM posts WHERE topicid=".mysql_real_escape_string($topicid)." ORDER BY id DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res) or die("No post found");

    $postid = $arr[0];

    sql_query("UPDATE topics SET lastpost=$postid WHERE id=".mysql_real_escape_string($topicid)) or sqlerr(__FILE__, __LINE__);
  }

  function get_forum_last_post($forumid)
  {
    $res = sql_query("SELECT lastpost FROM topics WHERE forumid=".mysql_real_escape_string($forumid)." ORDER BY lastpost DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res);

    $postid = $arr[0];

    if ($postid)
      return $postid;

    else
      return 0;
  }

  //-------- Inserts a quick jump menu

  function insert_quick_jump_menu($currentforum = 0)
  {
    print("<p align=center><form method=get action=? name=jump>\n");

    print("<input type=hidden name=action value=viewforum>\n");

    print("Quick jump: ");

    print("<select name=forumid onchange=\"if(this.options[this.selectedIndex].value != -1){ forms['jump'].submit() }\">\n");

    $res = sql_query("SELECT * FROM forums ORDER BY name") or sqlerr(__FILE__, __LINE__);

    while ($arr = mysql_fetch_assoc($res))
    {
      if (get_user_class() >= $arr["minclassread"])
        print("<option value=" . $arr["id"] . ($currentforum == $arr["id"] ? " selected>" : ">") . $arr["name"] . "\n");
    }

    print("</select>\n");

    print("<input type=submit value='Go!' class='btn'>\n");

    print("</form>\n</p>");
  }

  //-------- Inserts a compose frame

  function insert_compose_frame($id, $newtopic = true, $quote = false)
  {
    global $maxsubjectlength, $CURUSER;
?>
<!--     Preview forum post (ajaX) by xam v0.2    !-->
<!--     DO NOT EDIT BELOW!                            !-->
<script type="text/javascript" language="javascript">
   var http_request = false;
   function makePOSTRequest(url, parameters) {
      http_request = false;
      if (window.XMLHttpRequest) { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();
         if (http_request.overrideMimeType) {
             // set type accordingly to anticipated content type
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
         }
      } else if (window.ActiveXObject) { // IE
         try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } catch (e) {
            try {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
         }
      }
      if (!http_request) {
         alert('Cannot create XMLHTTP instance');
         return false;
      }
      
      http_request.onreadystatechange = alertContents;
      http_request.open('POST', url, true);
      http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http_request.setRequestHeader("Content-length", parameters.length);
      http_request.setRequestHeader("Connection", "close");
      http_request.send(parameters);
   }

   function alertContents() {
      if (http_request.readyState == 4) {
         if (http_request.status == 200) {
            //alert(http_request.responseText);
            result = http_request.responseText;
            document.getElementById('preview').innerHTML = result;            
         } else {
            alert('There was a problem with the request. Please report this to administrator.');
         }
      }
   }
  
   function get(obj) {
      var poststr = "body=" + encodeURI( document.getElementById("body").value );
      makePOSTRequest('preview.php', poststr);
   }
</script>
<!-- Preview forum post (ajaX) by xam v0.2 !-->
<?

    if ($newtopic)
    {
      $res = sql_query("SELECT name FROM forums WHERE id=".mysql_real_escape_string($id)) or sqlerr(__FILE__, __LINE__);

      $arr = mysql_fetch_assoc($res) or die("Bad forum id");

      $forumname = $arr["name"];

      print("<p align=center>New topic in <a href=?action=viewforum&forumid=$id>$forumname</a> forum</p>\n");
    }
    else
    {
      $res = sql_query("SELECT * FROM topics WHERE id=".mysql_real_escape_string($id)) or sqlerr(__FILE__, __LINE__);

      $arr = mysql_fetch_assoc($res) or stderr("Forum error", "Topic not found.");

      $subject = htmlspecialchars($arr["subject"]);

      print("<p align=center>Reply to topic: <a href=?action=viewtopic&topicid=$id>$subject</a></p>");
    }

    print ("<span name=\"preview\" id=\"preview\"></span>");
    begin_frame("Compose", true);

    print("<form method=post name=\"compose\" action=?action=post>\n");

    if ($newtopic)
      print("<input type=hidden name=forumid value=$id>\n");

    else
      print("<input type=hidden name=topicid value=$id>\n");

    begin_table();

    if ($newtopic)
      print("<tr><td class=rowhead>Subject</td>" .
        "<td align=left style='padding: 0px'><input type=text size=100 maxlength=$maxsubjectlength name=subject " .
        "style='border: 0px; height: 19px'></td></tr>\n");

    if ($quote)
    {
       $postid = 0+$_GET["postid"];
       int_check($postid);

	   $res = sql_query("SELECT posts.*, users.username FROM posts JOIN users ON posts.userid = users.id WHERE posts.id=$postid") or sqlerr(__FILE__, __LINE__);

	   if (mysql_num_rows($res) != 1)
	     stderr("Error", "No post with this ID");

	   $arr = mysql_fetch_assoc($res);
    }

    print("<tr><td class=rowhead>Body</td><td align=left style='padding: 0px'>");
   textbbcode("compose","body",($quote?(("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars(unesc($arr["body"]))."[/quote]")):""));
   print("<tr><td colspan=2 align=center><input type=submit class=btn2 value=Submit>\n");
   print("<input type=button class=btn2 name=button value=Preview  onclick=\"javascript:get(this.parentNode);\">");
   print("</td></tr>");   
   print("</td></tr>");

   end_table();

   print("</form>\n");

   //print("<p align=center><a href=tags.php target=_blank>Tags</a> | <a href=smilies.php target=_blank>Smilies</a></p>\n");

   end_frame();
       
       print("</form>\n");

		print("<p align=center><a href=tags.php target=_blank>Tags</a> | <a href=smilies.php target=_blank>Smilies</a></p>\n");

    end_frame();

    //------ Get 10 last posts if this is a reply

    if (!$newtopic)
    {
      $postres = sql_query("SELECT * FROM posts WHERE topicid=".mysql_real_escape_string($id)." ORDER BY id DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);

      begin_frame("10 last posts, in reverse order");

      while ($post = mysql_fetch_assoc($postres))
      {
        //-- Get poster details

        $userres = sql_query("SELECT * FROM users WHERE id=" . $post["userid"] . " LIMIT 1") or sqlerr(__FILE__, __LINE__);

        $user = mysql_fetch_assoc($userres);

      	$avatar = ($CURUSER["avatars"] == "yes" ? htmlspecialchars($user["avatar"]) : "");
	    $avatar = $user["avatar"];

        if (!$avatar)
          $avatar = "pic/default_avatar.png";

        print("<p class=sub>#" . $post["id"] . " by " . $user["username"] . " at " . display_date_time($post["utadded"] , $CURUSER[tzoffset] ) . " GMT</p>");

        begin_table(true);

        print("<tr><td height=250 width=150 align=center style='padding: 2px'>" . ($avatar ? "<img height=250 width=150 src=$avatar>" : "").
          "</td><td class=comment valign=top>" . format_comment($post["body"]) . "</td></tr>\n");

        end_table();

      }

      end_frame();

    }

  insert_quick_jump_menu();

  }

  //-------- Global variables

  $maxsubjectlength = 50;
  $postsperpage = $CURUSER["postsperpage"];
	if (!$postsperpage) $postsperpage = 25;
	
//-------- Action: Edit Forum

  if ($action == "editforum")
  {
    //stderr("Forum Error", "Not yet implemented.");

    stdhead("Edit forum");
    begin_main_frame();
    begin_frame("Edit Forum", "center");

    $forumid = 0 + $_GET["forumid"];
    $res = mysql_query("SELECT * FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);
    $forum = mysql_fetch_assoc($res);

    print("<form method=post action=?action=updateforum&forumid=$forumid>\n");
    begin_table();
    print("<tr><td class=rowhead>Forum name</td>" .
        "<td align=left style='padding: 0px'><input type=text size=60 maxlength=$maxsubjectlength name=name " .
        "style='border: 0px; height: 19px' value=\"$forum[name]\"></td></tr>\n".
        "<tr><td class=rowhead>Description</td>" .
        "<td align=left style='padding: 0px'><textarea name=description cols=68 rows=3 style='border: 0px'>$forum[description]</textarea></td></tr>\n".
        "<tr><td class=rowhead></td><td align=left style='padding: 0px'>&nbsp;Minimum <select name=readclass>");
    for ($i = 0; $i <= UC_SYSOP; ++$i)
    	print("<option value=$i" . ($i == $forum['minclassread'] ? " selected" : "") . ">" . get_user_class_name($i) . "</option>\n");
	print("</select> Class required to View<br>\n&nbsp;Minimum <select name=writeclass>");
    for ($i = 0; $i <= UC_SYSOP; ++$i)
    	print("<option value=$i" . ($i == $forum['minclasswrite'] ? " selected" : "") . ">" . get_user_class_name($i) . "</option>\n");
	print("</select> Class required to Post<br>\n&nbsp;Minimum <select name=createclass>");
    for ($i = 0; $i <= UC_SYSOP; ++$i)
    	print("<option value=$i" . ($i == $forum['minclasscreate'] ? " selected" : "") . ">" . get_user_class_name($i) . "</option>\n");
	print("</select> Class required to Create Topics</td></tr>\n".
    	"<tr><td colspan=2 align=center><input type=submit class=btn value='Submit'></td></tr>\n");
    end_table();
    print("</form>\n");

    end_frame();
    end_main_frame();
    stdfoot();
    die;
  }

//-------- Action: Update Forum

  if ($action == "updateforum")
  {
    $forumid = $_GET["forumid"];
    $name = $_POST["name"];
    $description = $_POST["description"];
    $minclassread = 0 + $_POST["readclass"];
    $minclasswrite = 0 + $_POST["writeclass"];
    $minclasscreate = 0 + $_POST["createclass"];

    if(!$forumid)
    	stderr("Error", "Forum ID not found.");
    if(!$name)
    	stderr("Error", "You must specify a name for the forum.");
    if(!$description)
    	stderr("Error", "You must provide a description for the forum.");

    $name = sqlesc($name);
    $description = sqlesc($description);

    mysql_query("UPDATE forums SET ".
    	"name=$name, ".
        "description=$description, ".
        "minclassread=$minclassread, ".
        "minclasswrite=$minclasswrite, ".
        "minclasscreate=$minclasscreate ".
      	"WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);

    header("Location: $BASEURL/forums.php");
  }

  //-------- Action: Delete Forum

  if ($action == "deleteforum")
  {
    $forumid = 0 + $_GET["forumid"];
    $confirmed = 0 + $_GET["confirmed"];

    if(!$forumid)
    	stderr("Error", "Forum ID not found.");
    if(!$confirmed)
    {
	    $rf = mysql_query("SELECT name FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);
	    $forum = mysql_fetch_assoc($rf);
        $rt = mysql_query("SELECT id FROM topics WHERE forumid=$forumid") or sqlerr(__FILE__, __LINE__);
        $topics = mysql_num_rows($rt);
        $posts = 0;
        while($topic = mysql_fetch_assoc($rt))
        {
	    	$rp = mysql_query("SELECT * FROM posts WHERE topicid=$topic[id]") or sqlerr(__FILE__, __LINE__);
	    	$posts += mysql_num_rows($rp);
        }
        stdhead("Delete forum");
        begin_main_frame();
        begin_frame("** WARNING! **");
        print("Deleting forum ID $forumid ($forum[name]) will also delete $posts posts in $topics topics. ".
        	"[<a class=altlink href=?action=deleteforum&forumid=$forumid&confirmed=1>ACCEPT</a>] ".
            "[<a class=altlink href=forums.php>CANCEL</a>]");
        end_frame();
        end_main_frame();
        stdfoot();
        die;
    }

    if ($CURUSER['class']>=UC_ADMINISTRATOR)
    {
	    $rt = mysql_query("SELECT id FROM topics WHERE forumid=$forumid") or sqlerr(__FILE__, __LINE__);
        while($topic = mysql_fetch_assoc($rt))
		    mysql_query("DELETE FROM posts WHERE topicid=$topic[id]") or sqlerr(__FILE__, __LINE__);
	    mysql_query("DELETE FROM topics WHERE forumid=$forumid") or sqlerr(__FILE__, __LINE__);
	    mysql_query("DELETE FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);
    	header("Location: $BASEURL/forums.php");
    }
    else
    	stderr("Error", "You are not authorised to perform this action!");
    die;
  }

  //-------- Action: New topic

  if ($action == "newtopic")
  {
    $forumid = 0+$_GET["forumid"];

    int_check($forumid,true);

    stdhead("New topic");

    begin_main_frame();

    insert_compose_frame($forumid);

    end_main_frame();

    stdfoot();

    die;
  }

  //-------- Action: Post

  if ($action == "post")
  {
    $forumid = $_POST["forumid"];
    	if (isset($forumid))
    		int_check($forumid,true);
    	
    $topicid = $_POST["topicid"];
    	if (isset($topicid))
    		int_check($topicid,true);

    $newtopic = $forumid > 0;

    $subject = $_POST["subject"];

    if ($newtopic)
    {
      $subject = trim($subject);

      if (!$subject)
        stderr("Error", "You must enter a subject.");

      if (strlen($subject) > $maxsubjectlength)
        stderr("Error", "Subject is limited.");
    }
    else
      $forumid = get_topic_forum($topicid) or die("Bad topic ID");
      if ($CURUSER["forumpost"] == 'no')
{
stdhead();
stdmsg("Sorry...", "You are not authorized to Post. (<a href=\"inbox.php#up\">Read Inbox</a>)",false);
stdfoot();
exit;
}

    //------ Make sure sure user has write access in forum

    $arr = get_forum_access_levels($forumid) or die("Bad forum ID");

    if (get_user_class() < $arr["write"] || ($newtopic && get_user_class() < $arr["create"]))
      stderr("Error", "Permission denied.");

    $body = trim($_POST["body"]);

    if ($body == "")
      stderr("Error", "No body text.");

    $userid = 0+$CURUSER["id"];
    
    // Anti Flood Code
   // To ensure that posts are not entered within 60 seconds limiting posts
   // to a maximum of 60 per hour.
if (get_user_class() < UC_MODERATOR) {
   if (strtotime($CURUSER['last_post']) > (strtotime($CURUSER['ctime']) - 60))
   {
       $secs = 60 - (strtotime($CURUSER['ctime']) - strtotime($CURUSER['last_post']));
       stderr("Error","Post Flooding Not Allowed. Please wait $secs second".($secs == 1 ? '' : 's')." before making another post.",false);
   }
}
   /////////////////////////////////////////////////////////////////////////

    if ($newtopic)
    {
      //---- Create topic
      
		//===add karma
		KPS("+","2.0",$userid);
		//===end

      $subject = sqlesc($subject);

      sql_query("INSERT INTO topics (userid, forumid, subject) VALUES($userid, $forumid, $subject)") or sqlerr(__FILE__, __LINE__);

      $topicid = mysql_insert_id() or stderr("Error", "No topic ID returned");
    }
    else
    {
      //---- Make sure topic exists and is unlocked

      $res = sql_query("SELECT * FROM topics WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

      $arr = mysql_fetch_assoc($res) or die("Topic id n/a");

      if ($arr["locked"] == 'yes' && get_user_class() < UC_MODERATOR)
        stderr("Error", "This topic is locked.");

      //---- Get forum ID

      $forumid = $arr["forumid"];
    }

    //------ Insert post

    $added = "'" . get_date_time() . "'";

    $body = sqlesc($body);

    sql_query("INSERT INTO posts (topicid, userid, added, body) " .
    "VALUES($topicid, $userid, $added, $body)") or sqlerr(__FILE__, __LINE__);

    $postid = mysql_insert_id() or die("Post id n/a");

    //------ Update topic last post

    update_topic_last_post($topicid);
    
    //===add karma
    KPS("+","1.0",$userid);
	//===end
    
    // Update last post sent
    sql_query("UPDATE users SET last_post = NOW() WHERE id = ".sqlesc($CURUSER['id'])) or sqlerr(__FILE__, __LINE__);

    //------ All done, redirect user to the post

    $headerstr = "Location: $BASEURL/forums.php?action=viewtopic&topicid=$topicid&page=last";

    if ($newtopic)
      header($headerstr);

    else
      header("$headerstr#$postid");

    die;
  }

  //-------- Action: View topic

  if ($action == "viewtopic")
  {
		//---------------------------------
		//---- Search Highlight v0.1 by xam
		//---------------------------------	
		$highlight = htmlspecialchars(trim($_GET["highlight"]));
		//---------------------------------
		//---- Search Highlight v0.1 by xam
		//---------------------------------
    $topicid = 0+$_GET["topicid"];

    $page = 0+$_GET["page"];

    int_check($topicid,true);

    $userid = $CURUSER["id"];

    //------ Get topic info

    $res = sql_query("SELECT * FROM topics WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_assoc($res) or stderr("Forum error", "Topic not found");

    $locked = ($arr["locked"] == 'yes');
    $subject = htmlspecialchars($arr["subject"]);
    $sticky = $arr["sticky"] == "yes";
    $forumid = $arr["forumid"];

	//------ Update hits column

    sql_query("UPDATE topics SET views = views + 1 WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    //------ Get forum

    $res = sql_query("SELECT * FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_assoc($res) or die("Forum = NULL");

    $forum = $arr["name"];

    if ($CURUSER["class"] < $arr["minclassread"])
		stderr("Error", "You are not permitted to view this topic.");

    //------ Get post count

    $res = sql_query("SELECT COUNT(*) FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res);

    $postcount = $arr[0];

    //------ Make page menu

    $pagemenu = "<p>\n";

    $perpage = $postsperpage;

    $pages = ceil($postcount / $perpage);

    if ($page[0] == "p")
  	{
	    $findpost = substr($page, 1);
	    $res = sql_query("SELECT id FROM posts WHERE topicid=$topicid ORDER BY added") or sqlerr(__FILE__, __LINE__);
	    $i = 1;
	    while ($arr = mysql_fetch_row($res))
	    {
	      if ($arr[0] == $findpost)
	        break;
	      ++$i;
	    }
	    $page = ceil($i / $perpage);
	  }

    if ($page == "last")
      $page = $pages;
    else
    {
      if($page < 1)
        $page = 1;
      elseif ($page > $pages)
        $page = $pages;
    }

    $offset = $page * $perpage - $perpage;

    for ($i = 1; $i <= $pages; ++$i)
    {
      if ($i == $page)
        $pagemenu .= "<font class=gray><b>$i</b></font>\n";

      else
        $pagemenu .= "<a href=?action=viewtopic&topicid=$topicid&page=$i><b>$i</b></a>\n";
    }

    if ($page == 1)
      $pagemenu .= "<br><font class=gray><b>&lt;&lt; Prev</b></font>";

    else
      $pagemenu .= "<br><a href=?action=viewtopic&topicid=$topicid&page=" . ($page - 1) .
        "><b>&lt;&lt; Prev</b></a>";

    $pagemenu .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

    if ($page == $pages)
      $pagemenu .= "<font class=gray><b>Next &gt;&gt;</b></font></p>\n";

    else
      $pagemenu .= "<a href=?action=viewtopic&topicid=$topicid&page=" . ($page + 1) .
        "><b>Next &gt;&gt;</b></a></p>\n";

    //------ Get posts

    $res = sql_query("SELECT * FROM posts WHERE topicid=$topicid ORDER BY id LIMIT $offset,$perpage") or sqlerr(__FILE__, __LINE__);

    stdhead("View topic");

    print("<a name=top><h1><a href=?action=viewforum&forumid=$forumid>$forum</a> &gt; $subject</h1>\n");

    print($pagemenu);

    //------ Print table

    begin_main_frame();

    begin_frame();

    $pc = mysql_num_rows($res);

    $pn = 0;

    $r = sql_query("SELECT lastpostread FROM readposts WHERE userid=" . $CURUSER["id"] . " AND topicid=$topicid") or sqlerr(__FILE__, __LINE__);

    $a = mysql_fetch_row($r);

    $lpr = $a[0];

    if (!$lpr)
      sql_query("INSERT INTO readposts (userid, topicid) VALUES($userid, $topicid)") or sqlerr(__FILE__, __LINE__);

    while ($arr = mysql_fetch_assoc($res))
    {
      ++$pn;

      $postid = $arr["id"];

      $posterid = $arr["userid"];

      $added = $arr["added"] . " GMT (" . (get_elapsed_time(sql_timestamp_to_unix_timestamp($arr["added"]))) . " ago)";

      //---- Get poster details
	$dt = gmtime() - 180;
	$dt = sqlesc(get_date_time($dt));
    $res2 = sql_query("SELECT username,class,avatar,donor,title,enabled,warned,uploaded,downloaded,signature,last_access FROM users WHERE id=$posterid") or sqlerr(__FILE__, __LINE__);

      $arr2 = mysql_fetch_assoc($res2);
      $uploaded = mksize($arr2["uploaded"]);
$downloaded = mksize($arr2["downloaded"]);
if ($arr2["downloaded"] > 0)

{

$ratio = $arr2['uploaded'] / $arr2['downloaded'];

$ratio = number_format($ratio, 3);

$color = get_ratio_color($ratio);

if ($color)

 $ratio = "<font color=$color>$ratio</font>";

}

else

if ($arr2["uploaded"] > 0)

    $ratio = "Inf.";

else

$ratio = "---";

$rem = sql_query("SELECT COUNT(*) FROM posts WHERE userid=" . $posterid) or sqlerr();
 $arr25 = mysql_fetch_row($rem);
 $forumposts = $arr25[0];
      
      $signature = $arr2[signature];
	  $signature = ($CURUSER["signatures"] == "yes" ? htmlspecialchars($arr2["signature"]) : "");

      $postername = $arr2["username"];

      if ($postername == "")
      {
        $by = "unknown[$posterid]";

        $avatar = "";
      }
      else
      {
//		if ($arr2["enabled"] == "yes")
	        $avatar = ($CURUSER["avatars"] == "yes" ? htmlspecialchars($arr2["avatar"]) : "");
//	    else
//			$avatar = "pic/disabled_avatar.gif";

        $title = $arr2["title"];

        if (!$title)
          $title = get_user_class_name($arr2["class"]);
          
 //Sort shit out
    if ($arr2["downloaded"] > 0)
      {
            $ratio = number_format($arr2["uploaded"] / $arr2["downloaded"], 3);
            $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
      }
      else
        if ($arr2["uploaded"] > 0)
          $ratio = "Inf.";
        else
          $ratio = "---";
    
  $uploaded = mksize($arr2["uploaded"]);
  $downloaded = mksize($arr2["downloaded"]);
    
    //add popup to display
  echo ("<div id=\"popup$posterid\" class=\"popup\"  align='left'>&nbsp;Downloaded: $downloaded
  &nbsp;Uploaded: $uploaded <br>&nbsp;Ratio: $ratio</div>\n");
  // end add popup to display


        $UC = array("Staff Leader" => "pic/staffleader.gif",
"SysOp" => "pic/sysop.jpg",
"Administrator" => "pic/admin.jpg",
"Moderator" => "pic/mod.jpg",
"Uploader" => "pic/uploader.jpg",
"VIP" => "pic/vip.jpg",
"Power User" => "pic/power.jpg",
"User" => "pic/user.jpg");
$uclass = $UC[get_user_class_name($arr2["class"])]; 
        $by = "<a onMouseOver='show($posterid)' onMouseOut='hide($posterid)' href=userdetails.php?id=$posterid><b>$postername</b></a>" . ($arr2["donor"] == "yes" ? "<img src=".
"pic/star.gif alt='Donor'>" : "") . ($arr2["enabled"] == "no" ? "<img src=".
"pic/disabled.gif alt=\"This account is disabled\" style='margin-left: 2px'>" : ($arr2["warned"] == "yes" ? "<a href=rules.php#warning class=altlink><img src=pic/warned.gif alt=\"Warned\" border=0></a>" : "")) . " ";
      }

      if (!$avatar)
        $avatar = "pic/default_avatar.png";

      print("<a name=$postid>\n");

      if ($pn == $pc)
      {
        print("<a name=last>\n");
        if ($postid > $lpr)
          sql_query("UPDATE readposts SET lastpostread=$postid WHERE userid=$userid AND topicid=$topicid") or sqlerr(__FILE__, __LINE__);
      }

      print("<p class=sub><table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded width=99%>#$postid by $by ($title) at $added");      

      print("</td><td class=embedded width=1%><a href=#top><img src=pic/p_up.gif border=0 alt='Top'></a></td></tr>");

      print("</table></p>\n");

      begin_table(true);

      $body = format_comment($arr["body"]);
      
		//---------------------------------
		//---- Search Highlight v0.1 by xam
		//---------------------------------
      	if ($highlight){
	      	$body = highlight($highlight,$body);
	      	}
		//---------------------------------
		//---- Search Highlight v0.1 by xam
		//---------------------------------

      if (is_valid_id($arr['editedby']))
      {
        $res2 = mysql_query("SELECT username FROM users WHERE id=$arr[editedby]");
        if (mysql_num_rows($res2) == 1)
        {
          $arr2 = mysql_fetch_assoc($res2);
          $body .= "<p><font size=1 class=small>Last edited by <a href=userdetails.php?id=$arr[editedby]><b>$arr2[username]</b></a> at $arr[editedat] GMT</font></p>\n";
        }
      }

      if ($signature)
 	  $body .= "<p style='vertical-align:bottom'><br>� � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �<br>" . format_comment($signature) . "</p>";
    
      "</td>";



      print("<tr valign=top><td width=150 align=center style='padding: 2px'>" .
       ($avatar ? "<img width=150 src=\"$avatar\"><br /><br /> <table 
width=\"90%\" class=\"infotable\" 
align=\"center\"><tr><td>&nbsp;<font 
color=cccccc><b>Posts:</b></font>&nbsp;<b>$forumposts<br
/></b>&nbsp;<font
color=cccccc><b>Uploaded:</b></font>&nbsp;<b>$uploaded<br 
/></b>&nbsp;<font 
color=cccccc><b>Downloaded:</b></font>&nbsp;<b>$downloaded</b><br /> &nbsp;<font color=1900D1><b>Ratio:</b></font>&nbsp;<b>$ratio</b></tr></td></table><br />" : ""). "</td><td class=comment>$body</td></tr>\n");
	print("<tr><td> ".
  ("'".$arr2['last_access']."'">$dt?"<img src=pic/user_online.gif border=0 alt=\"Online\">":"<img src=pic/user_offline.gif border=0 alt=\"Offline\">" )." <a href=\"sendmessage.php?receiver=".htmlspecialchars($posterid)."\"><img src=\"pic/pm.gif\" border=\"0\" alt=\"Send message to ".htmlspecialchars($postername)."\"></a> <a href=\"report.php?forumid=".htmlspecialchars($topicid)."&forumpost=".htmlspecialchars($postid)."\"><img src=\"pic/report.gif\" border=\"0\" alt=\"Report this post\"></a></td>");
	print("<td align=right>");
	if (!$locked || get_user_class() >= UC_MODERATOR)
				print("<a href=?action=quotepost&topicid=$topicid&postid=$postid><img src=\"pic/p_quote.gif\" border=\"0\" alt=\"Reply with Quote\"></a>");

$arr = get_forum_access_levels($forumid) or die;
if (get_user_class() >= $arr["write"])
	$maypost = true;

	if ($maypost)
	    {
		      print("<a href=?action=reply&topicid=$topicid><img src=\"pic/p_reply.gif\" border=\"0\" alt=\"Reply directly to this post\"></a>");
	    }
				
	if (get_user_class() >= UC_MODERATOR)
        print("<a href=?action=deletepost&postid=$postid><img src=\"pic/p_delete.gif\" border=\"0\" alt=\"Delete Post\"></a>");
	
	if (($CURUSER["id"] == $posterid && !$locked) || get_user_class() >= UC_MODERATOR)
        print("<a href=?action=editpost&postid=$postid><img src=\"pic/p_edit.gif\" border=\"0\" alt=\"Edit Post\"></a>");
	print("</td></tr>");
      end_table();
    }





    //------ Mod options

	  if (get_user_class() >= UC_MODERATOR)
	  {
	    attach_frame();

	    $res = sql_query("SELECT id,name,minclasswrite FROM forums ORDER BY name") or sqlerr(__FILE__, __LINE__);
	    print("<table border=0 cellspacing=0 cellpadding=0>\n");

	    print("<form method=post action=?action=setsticky>\n");
	    print("<input type=hidden name=topicid value=$topicid>\n");
	    print("<input type=hidden name=returnto value=$_SERVER[REQUEST_URI]>\n");
	    print("<tr><td class=embedded align=right>Sticky:</td>\n");
	    print("<td class=embedded><input type=radio name=sticky value='yes' " . ($sticky ? " checked" : "") . "> Yes <input type=radio name=sticky value='no' " . (!$sticky ? " checked" : "") . "> No\n");
	    print("<input type=submit value='Set' class=btn2></td></tr>");
	    print("</form>\n");

	    print("<form method=post action=?action=setlocked>\n");
	    print("<input type=hidden name=topicid value=$topicid>\n");
	    print("<input type=hidden name=returnto value=$_SERVER[REQUEST_URI]>\n");
	    print("<tr><td class=embedded align=right>Locked:</td>\n");
	    print("<td class=embedded><input type=radio name=locked value='yes' " . ($locked ? " checked" : "") . "> Yes <input type=radio name=locked value='no' " . (!$locked ? " checked" : "") . "> No\n");
	    print("<input type=submit value='Set' class=btn2></td></tr>");
	    print("</form>\n");

	    print("<form method=post action=?action=renametopic>\n");
	    print("<input type=hidden name=topicid value=$topicid>\n");
	    print("<input type=hidden name=returnto value=$_SERVER[REQUEST_URI]>\n");
	    print("<tr><td class=embedded align=right>Rename topic:</td><td class=embedded><input type=text name=subject size=60 maxlength=$maxsubjectlength value=\"" . htmlspecialchars($subject) . "\">\n");
	    print("<input type=submit value='Okay' class=btn2></td></tr>");
	    print("</form>\n");

	    print("<form method=post action=?action=movetopic&topicid=$topicid>\n");
	    print("<tr><td class=embedded>Move this thread to:&nbsp;</td><td class=embedded><select name=forumid>");

	    while ($arr = mysql_fetch_assoc($res))
	      if ($arr["id"] != $forumid && get_user_class() >= $arr["minclasswrite"])
	        print("<option value=" . $arr["id"] . ">" . $arr["name"] . "\n");

	    print("</select> <input type=submit value='Okay' class=btn2></form></td></tr>\n");
	    print("<tr><td class=embedded>Delete topic</td><td class=embedded>\n");
	    print("<form method=get action=forums.php>\n");
	    print("<input type=hidden name=action value=deletetopic>\n");
	    print("<input type=hidden name=topicid value=$topicid>\n");
	    print("<input type=hidden name=forumid value=$forumid>\n");
	    print("<input type=checkbox name=sure value=1>I'm sure\n");
	    print("<input type=submit value='Okay' class=btn2>\n");
	    print("</form>\n");
	    print("</td></tr>\n");
	    print("</table>\n");
	  }

  	end_frame();

  	end_main_frame();

  	print($pagemenu);

  	if ($locked && get_user_class() < UC_MODERATOR)
  		print("<p>This topic is locked; no new posts are allowed.</p>\n");

  	else
  	{
	    $arr = get_forum_access_levels($forumid) or die;

	    if (get_user_class() < $arr["write"])
	      print("<p><i>You are not permitted to post in this forum.</i></p>\n");

	    else
	      $maypost = true;
	  }
/*	  //------ "View unread" / "Add reply" buttons

	  print("<p><table class=main border=0 cellspacing=0 cellpadding=0><tr>\n");
	  print("<td class=embedded><form method=get action=?>\n");
	  print("<input type=hidden name=action value=viewunread>\n");
	  print("<input type=submit value='View Unread' class=btn2>\n");
	  print("</form></td>\n");

    if ($maypost)
    {
      print("<td class=embedded style='padding-left: 10px'><form method=get action=?>\n");
      print("<input type=hidden name=action value=reply>\n");
      print("<input type=hidden name=topicid value=$topicid>\n");
      print("<input type=submit value='Add Reply' class=btn2>\n");
      print("</form></td>\n");
    }
    print("</tr></table></p>\n");
*/
    //------ Forum quick jump drop-down

    insert_quick_jump_menu($forumid);

    stdfoot();

    die;
  }

  //-------- Action: Quote

	if ($action == "quotepost")
	{
		$topicid = 0+$_GET["topicid"];

		int_check($topicid,true);

    stdhead("Post reply");

    begin_main_frame();

    insert_compose_frame($topicid, false, true);

    end_main_frame();

    stdfoot();

    die;
  }

  //-------- Action: Reply

  if ($action == "reply")
  {
    $topicid = 0+$_GET["topicid"];

    int_check($topicid,true);

    stdhead("Post reply");

    begin_main_frame();

    insert_compose_frame($topicid, false);

    end_main_frame();

    stdfoot();

    die;
  }

  //-------- Action: Move topic


  if ($action == "movetopic")
  {
    $forumid = 0+$_POST["forumid"];

    $topicid = 0+$_GET["topicid"];

    if (!is_valid_id($forumid) || !is_valid_id($topicid) || get_user_class() < UC_MODERATOR)
      die;

    // Make sure topic and forum is valid

    $res = @sql_query("SELECT minclasswrite FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($res) != 1)
      stderr("Error", "Forum not found.");

    $arr = mysql_fetch_row($res);

    if (get_user_class() < $arr[0])
      die;

    $res = @sql_query("SELECT forumid FROM topics WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);
   if (mysql_num_rows($res) != 1)
     stderr("Error", "Topic not found.");
   $arr = mysql_fetch_row($res);
   $old_forumid=$arr[0];

   // get posts count
   $res = sql_query("SELECT COUNT(id) AS nb_posts FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);
   if (mysql_num_rows($res) != 1)
     stderr("Error", "Couldn't get posts count.");
   $arr = mysql_fetch_row($res);
   $nb_posts = $arr[0];

   // move topic
   if ($old_forumid != $forumid)
   {
     @sql_query("UPDATE topics SET forumid=$forumid WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);
     // update counts
     @sql_query("UPDATE forums SET topiccount=topiccount-1, postcount=postcount-$nb_posts WHERE id=$old_forumid") or sqlerr(__FILE__, __LINE__);
     @sql_query("UPDATE forums SET topiccount=topiccount+1, postcount=postcount+$nb_posts WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);
   }

    // Redirect to forum page

    header("Location: $BASEURL/forums.php?action=viewforum&forumid=$forumid");

    die;
  }

  //-------- Action: Delete topic

  if ($action == "deletetopic")
  {
    $topicid = 0+$_GET["topicid"];
    $forumid = 0+$_GET["forumid"];

    if (!is_valid_id($topicid) || get_user_class() < UC_MODERATOR)
      die;

    $sure = 0+$_GET["sure"];

    if (!$sure)
    {
      stderr("Delete topic", "Sanity check: You are about to delete a topic. Click\n" .
      "<a href=?action=deletetopic&topicid=$topicid&sure=1>here</a> if you are sure.",false);
    }

    sql_query("DELETE FROM topics WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    sql_query("DELETE FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);
    
    //===remove karma
    KPS("-","2.0",$CURUSER["id"]);
	//===end

    header("Location: $BASEURL/forums.php?action=viewforum&forumid=$forumid");

    die;
  }

  //-------- Action: Edit post

  if ($action == "editpost")
  {
    $postid = 0+$_GET["postid"];

    int_check($postid,true);

    $res = sql_query("SELECT * FROM posts WHERE id=$postid") or sqlerr(__FILE__, __LINE__);

		if (mysql_num_rows($res) != 1)
			stderr("Error", "No post with this ID");

		$arr = mysql_fetch_assoc($res);

    $res2 = sql_query("SELECT locked FROM topics WHERE id = " . $arr["topicid"]) or sqlerr(__FILE__, __LINE__);
		$arr2 = mysql_fetch_assoc($res2);

 		if (mysql_num_rows($res) != 1)
			stderr("Error", "No topic associated with this post ID");

		$locked = ($arr2["locked"] == 'yes');

    if (($CURUSER["id"] != $arr["userid"] || $locked) && get_user_class() < UC_MODERATOR)
      stderr("Error", "Denied!");

    if ($_SERVER['REQUEST_METHOD'] == 'POST')
    {
    	$body = $_POST['body'];

    	if ($body == "")
    	  stderr("Error", "Body cannot be empty!");

      $body = sqlesc($body);

      $editedat = sqlesc(get_date_time());

      sql_query("UPDATE posts SET body=$body, editedat=$editedat, editedby=$CURUSER[id] WHERE id=$postid") or sqlerr(__FILE__, __LINE__);

		$returnto = $_POST["returnto"];

			if ($returnto != "")
			{
				$returnto .= "&page=p$postid#$postid";
				header("Location: $returnto");
			}
			else
				stderr("Success", "Post was edited successfully.");
    }

    stdhead();

    print("<h1>Edit Post</h1>\n");
       
   print("<form name=edit method=post action=?action=editpost&postid=$postid>\n");
       
   print("<input type=hidden name=returnto value=\"" . htmlspecialchars($HTTP_SERVER_VARS["HTTP_REFERER"]) . "\">\n");

   print("<p align=center><table class=main border=1 cellspacing=0 cellpadding=5>\n");

   print("<tr><td class=rowhead>Body</td><td align=left style='padding: 0px'>");
       
   textbbcode("edit","body",htmlspecialchars(unesc($arr["body"])));
       
   print("</td></tr>\n");
       
   print("<tr><td align=center colspan=2><input type=submit value='".Okay."' class=btn2></td></tr>\n");

   print("</table>\n</p>");

   print("</form>\n");
       
       stdfoot();

  	die;
  }

  //-------- Action: Delete post

  if ($action == "deletepost")
  {
    $postid = 0+$_GET["postid"];

    $sure = 0+$_GET["sure"];

    if (get_user_class() < UC_MODERATOR || !is_valid_id($postid))
      die;

    //------- Get topic id

    $res = sql_query("SELECT topicid FROM posts WHERE id=$postid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res) or stderr("Error", "Post not found");

    $topicid = $arr[0];

    //------- We can not delete the post if it is the only one of the topic

    $res = sql_query("SELECT COUNT(*) FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res);

    if ($arr[0] < 2)
      stderr("Error", "Can't delete post; it is the only post of the topic. You should\n" .
      "<a href=?action=deletetopic&topicid=$topicid&sure=1>delete the topic</a> instead.\n",false);


    //------- Get the id of the last post before the one we're deleting

    $res = sql_query("SELECT id FROM posts WHERE topicid=$topicid AND id < $postid ORDER BY id DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);
		if (mysql_num_rows($res) == 0)
			$redirtopost = "";
		else
		{
			$arr = mysql_fetch_row($res);
			$redirtopost = "&page=p$arr[0]#$arr[0]";
		}

    //------- Make sure we know what we do :-)

    if (!$sure)
    {
      stderr("Delete post", "Sanity check: You are about to delete a post. Click\n" .
      "<a href=?action=deletepost&postid=$postid&sure=1>here</a> if you are sure.",false);
    }

    //------- Delete post

    sql_query("DELETE FROM posts WHERE id=$postid") or sqlerr(__FILE__, __LINE__);

    //------- Update topic

    update_topic_last_post($topicid);
    
    //===remove karma
    KPS("-","1.0",$CURUSER["id"]);
	//===end

    header("Location: $BASEURL/forums.php?action=viewtopic&topicid=$topicid$redirtopost");

    die;
  }

  //-------- Action: Lock topic

  if ($action == "locktopic")
  {
    $forumid = 0+$_GET["forumid"];
    $topicid = 0+$_GET["topicid"];
    $page = 0+$_GET["page"];

    if (!is_valid_id($topicid) || get_user_class() < UC_MODERATOR)
      die;

    sql_query("UPDATE topics SET locked='yes' WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    header("Location: $BASEURL/forums.php?action=viewforum&forumid=$forumid&page=$page");

    die;
  }

  //-------- Action: Unlock topic

  if ($action == "unlocktopic")
  {
    $forumid = 0+$_GET["forumid"];

    $topicid = 0+$_GET["topicid"];

    $page = 0+$_GET["page"];

    if (!is_valid_id($topicid) || get_user_class() < UC_MODERATOR)
      die;

    sql_query("UPDATE topics SET locked='no' WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    header("Location: $BASEURL/forums.php?action=viewforum&forumid=$forumid&page=$page");

    die;
  }

  //-------- Action: Set locked on/off

  if ($action == "setlocked")
  {
    $topicid = 0 + $_POST["topicid"];

    if (!$topicid || get_user_class() < UC_MODERATOR)
      die;

	$locked = sqlesc($_POST["locked"]);
    sql_query("UPDATE topics SET locked=$locked WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    header("Location: $_POST[returnto]");

    die;
  }

  //-------- Action: Set sticky on/off

  if ($action == "setsticky")
  {
    $topicid = 0 + $_POST["topicid"];

    if (!topicid || get_user_class() < UC_MODERATOR)
      die;

	$sticky = sqlesc($_POST["sticky"]);
    sql_query("UPDATE topics SET sticky=$sticky WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    header("Location: $_POST[returnto]");

    die;
  }

  //-------- Action: Rename topic

  if ($action == 'renametopic')
  {
  	if (get_user_class() < UC_MODERATOR)
  	  die;

  	$topicid = 0+$_POST['topicid'];

  	int_check($topicid,true);

  	$subject = $_POST['subject'];

  	if ($subject == '')
  	  stderr('Error', 'You must enter a new title!');

  	$subject = sqlesc($subject);

  	sql_query("UPDATE topics SET subject=$subject WHERE id=$topicid") or sqlerr();

  	$returnto = $_POST['returnto'];

  	if ($returnto)
  	  header("Location: $returnto");

  	die;
  }

  //-------- Action: View forum

  if ($action == "viewforum")
  {
    $forumid = 0+$_GET["forumid"];

    int_check($forumid,true);

    $page = 0+$_GET["page"];

    $userid = 0+$CURUSER["id"];

    //------ Get forum name

    $res = sql_query("SELECT name, minclassread FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_assoc($res) or die;

    $forumname = $arr["name"];

    if (get_user_class() < $arr["minclassread"])
      die("Not permitted");

    //------ Page links

    //------ Get topic count

    $perpage = $CURUSER["topicsperpage"];
	if (!$perpage) $perpage = 20;

    $res = sql_query("SELECT COUNT(*) FROM topics WHERE forumid=$forumid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res);

    $num = $arr[0];

    if ($page == 0)
      $page = 1;

    $first = ($page * $perpage) - $perpage + 1;

    $last = $first + $perpage - 1;

    if ($last > $num)
      $last = $num;

    $pages = floor($num / $perpage);

    if ($perpage * $pages < $num)
      ++$pages;

    //------ Build menu

    $menu = "<p align=center><b>\n";

    $lastspace = false;

    for ($i = 1; $i <= $pages; ++$i)
    {
    	if ($i == $page)
        $menu .= "<font class=gray>$i</font>\n";

      elseif ($i > 3 && ($i < $pages - 2) && ($page - $i > 3 || $i - $page > 3))
    	{
    		if ($lastspace)
    		  continue;

  		  $menu .= "... \n";

     		$lastspace = true;
    	}

      else
      {
        $menu .= "<a href=?action=viewforum&forumid=$forumid&page=$i>$i</a>\n";

        $lastspace = false;
      }
      if ($i < $pages)
        $menu .= "</b>|<b>\n";
    }

    $menu .= "<br>\n";

    if ($page == 1)
      $menu .= "<font class=gray>&lt;&lt; Prev</font>";

    else
      $menu .= "<a href=?action=viewforum&forumid=$forumid&page=" . ($page - 1) . ">&lt;&lt; Prev</a>";

    $menu .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

    if ($last == $num)
      $menu .= "<font class=gray>Next &gt;&gt;</font>";

    else
      $menu .= "<a href=?action=viewforum&forumid=$forumid&page=" . ($page + 1) . ">Next &gt;&gt;</a>";

    $menu .= "</b></p>\n";

    $offset = $first - 1;

    //------ Get topics data

    $topicsres = sql_query("SELECT * FROM topics WHERE forumid=$forumid ORDER BY sticky, lastpost DESC LIMIT $offset,$perpage") or
      stderr("SQL Error", mysql_error());

    stdhead("Forum");

    $numtopics = mysql_num_rows($topicsres);

    print("<h1>$forumname</h1>\n");

    if ($numtopics > 0)
    {
      print($menu);

      print("<table border=1 cellspacing=0 cellpadding=5 width=737>");

      print("<tr><td class=colhead align=left>Topic</td><td class=colhead>Replies</td><td class=colhead>Views</td>\n" .
        "<td class=colhead align=left>Author</td><td class=colhead align=left>Last&nbsp;post</td>\n");

      print("</tr>\n");

      while ($topicarr = mysql_fetch_assoc($topicsres))
      {
        $topicid = $topicarr["id"];

        $topic_userid = $topicarr["userid"];

        $topic_views = $topicarr["views"];

		$views = number_format($topic_views);

        $locked = $topicarr["locked"] == "yes";

        $sticky = $topicarr["sticky"] == "yes";

        //---- Get reply count

        $res = sql_query("SELECT COUNT(*) FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);

        $arr = mysql_fetch_row($res);

        $posts = $arr[0];

        $replies = max(0, $posts - 1);

        $tpages = floor($posts / $postsperpage);

        if ($tpages * $postsperpage != $posts)
          ++$tpages;

        if ($tpages > 1)
        {
          $topicpages = " (<img src=pic/multipage.gif>";

          for ($i = 1; $i <= $tpages; ++$i)
            $topicpages .= " <a href=?action=viewtopic&topicid=$topicid&page=$i>$i</a>";

          $topicpages .= ")";
        }
        else
          $topicpages = "";

        //---- Get userID and date of last post

        $res = sql_query("SELECT * FROM posts WHERE topicid=$topicid ORDER BY id DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

        $arr = mysql_fetch_assoc($res);

        $lppostid = 0 + $arr["id"];

        $lpuserid = 0 + $arr["userid"];

        $lpadded = "<nobr>" . display_date_time($arr["utadded"] , $CURUSER[tzoffset] ) . "</nobr>";

        //------ Get name of last poster

        $res = sql_query("SELECT * FROM users WHERE id=$lpuserid") or sqlerr(__FILE__, __LINE__);

        if (mysql_num_rows($res) == 1)
        {
          $arr = mysql_fetch_assoc($res);

          $lpusername = "<a href=userdetails.php?id=$lpuserid><b>$arr[username]</b></a>";
        }
        else
          $lpusername = "unknown[$topic_userid]";

        //------ Get author

        $res = sql_query("SELECT username FROM users WHERE id=$topic_userid") or sqlerr(__FILE__, __LINE__);

        if (mysql_num_rows($res) == 1)
        {
          $arr = mysql_fetch_assoc($res);

          $lpauthor = "<a href=userdetails.php?id=$topic_userid><b>$arr[username]</b></a>";
        }
        else
          $lpauthor = "unknown[$topic_userid]";

        //---- Print row

        $r = sql_query("SELECT lastpostread FROM readposts WHERE userid=$userid AND topicid=$topicid") or sqlerr(__FILE__, __LINE__);

        $a = mysql_fetch_row($r);

        $new = !$a || $lppostid > $a[0];

        $topicpic = ($locked ? ($new ? "lockednew" : "locked") : ($new ? "unlockednew" : "unlocked"));

        $subject = ($sticky ? "<font color=yellow>Sticky:</font> " : "") . "<a href=?action=viewtopic&topicid=$topicid><b>" .
        encodehtml($topicarr["subject"]) . "</b></a>$topicpages";

        print("<tr><td align=left><table border=0 cellspacing=0 cellpadding=0><tr>" .
        "<td class=embedded style='padding-right: 5px'><img src=pic/$topicpic.gif>" .
        "</td><td class=embedded align=left>\n" .
        "$subject</td></tr></table></td><td align=right>$replies</td>\n" .
        "<td align=right>$views</td><td align=left>$lpauthor</td>\n" .
        "<td align=left>$lpadded<br>by&nbsp;$lpusername</td>\n");

        print("</tr>\n");
      } // while

      print("</table>\n");

      print($menu);

    } // if
    else
      print("<p align=center>No topics found</p>\n");

    print("<p><table class=main border=0 cellspacing=0 cellpadding=0><tr valing=center>\n");

    print("<td class=embedded><img src=pic/unlockednew.gif style='margin-right: 5px'></td><td class=embedded>New posts</td>\n");

    print("<td class=embedded><img src=pic/locked.gif style='margin-left: 10px; margin-right: 5px'>" .
    "</td><td class=embedded>Locked topic</td>\n");

    print("</tr></table></p>\n");

    $arr = get_forum_access_levels($forumid) or die;

    $maypost = get_user_class() >= $arr["write"] && get_user_class() >= $arr["create"];

    if (!$maypost)
      print("<p><i>You are not permitted to start new topics in this forum.</i></p>\n");

    print("<p><table border=0 class=main cellspacing=0 cellpadding=0><tr>\n");

    print("<td class=embedded><form method=get action=?><input type=hidden " .
    "name=action value=viewunread><input type=submit value='View unread' class=btn2></form></td>\n");

    if ($maypost)
      print("<td class=embedded><form method=get action=?><input type=hidden " .
      "name=action value=newtopic><input type=hidden name=forumid " .
      "value=$forumid><input type=submit value='New topic' class=btn2 style='margin-left: 10px'></form></td>\n");

    print("</tr></table></p>\n");

    insert_quick_jump_menu($forumid);

    stdfoot();

    die;
  }

  //-------- Action: View unread posts

  if ($action == "viewunread")
  {
	//die("This feature is currently unavailable.");
    $userid = $CURUSER['id'];

    $maxresults = 25;

    $res = sql_query("SELECT id, forumid, subject, lastpost FROM topics ORDER BY lastpost") or sqlerr(__FILE__, __LINE__);

    stdhead();

    print("<h1>Topics with unread posts</h1>\n");

    $n = 0;

    $uc = get_user_class();

    while ($arr = mysql_fetch_assoc($res))
    {
      $topicid = $arr['id'];

      $forumid = $arr['forumid'];

      //---- Check if post is read
      $r = sql_query("SELECT lastpostread FROM readposts WHERE userid=$userid AND topicid=$topicid") or sqlerr(__FILE__, __LINE__);

      $a = mysql_fetch_row($r);

      if ($a && $a[0] == $arr['lastpost'])
        continue;

      //---- Check access & get forum name
      $r = sql_query("SELECT name, minclassread FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);

      $a = mysql_fetch_assoc($r);

      if ($uc < $a['minclassread'])
        continue;

      ++$n;

      if ($n > $maxresults)
        break;

      $forumname = $a['name'];

      if ($n == 1)
      {
        print("<table border=1 cellspacing=0 cellpadding=5>\n");

        print("<tr><td class=colhead align=left>Topic</td><td class=colhead align=left>Forum</td></tr>\n");
      }

      print("<tr><td align=left><table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>" .
      "<img src=pic/unlockednew.gif style='margin-right: 5px'></td><td class=embedded>" .
      "<a href=?action=viewtopic&topicid=$topicid&page=last#last><b>" . htmlspecialchars($arr["subject"]) .
      "</b></a></td></tr></table></td><td align=left><a href=?action=viewforum&forumid=$forumid><b>$forumname</b></a></td></tr>\n");
    }
    if ($n > 0)
    {
      print("</table>\n");

      if ($n > $maxresults)
        print("<p>More than $maxresults items found, displaying first $maxresults.</p>\n");

      print("<p><a href=?catchup><b>Catch up</b></a></p>\n");
    }
    else
      print("<b>Nothing found</b>");

    stdfoot();

    die;
  }

if ($action == "search")
{
	stdhead("Forum Search");
	unset($error);
	$error= false;
	$keywords = htmlspecialchars(trim($_GET["keywords"]));
	if ($keywords != "")
	{
		$perpage = 5;
		$page = max(1, 0 + $_GET["page"]);
		$extraSql 	= "body LIKE '%".mysql_real_escape_string($keywords)."%'";	
		$res = sql_query("SELECT COUNT(*) FROM posts WHERE $extraSql") or sqlerr(__FILE__, __LINE__);
		$arr = mysql_fetch_row($res);
		$hits = 0 + $arr[0];
		if ($hits == 0)
			$error = true;
		else
		{
			$pages = 0 + ceil($hits / $perpage);
			if ($page > $pages) $page = $pages;
			for ($i = 1; $i <= $pages; ++$i)
				if ($page == $i)
					$pagemenu1 .= "<font class=gray><b>$i</b></font>\n";
				else
					$pagemenu1 .= "<a href=\"forums.php?action=search&keywords=$keywords&page=$i\"><b>$i</b></a>\n";
			if ($page == 1)
				$pagemenu2 = "<font class=gray><b>&lt;&lt; Prev</b></font>\n";
			else
				$pagemenu2 = "<a href=\"forums.php?action=search&keywords=$keywords&page=" . ($page - 1) . "\"><b>&lt;&lt; Prev</b></a>\n";
			$pagemenu2 .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
			if ($page == $pages)
				$pagemenu2 .= "<font class=gray><b>Next &gt;&gt;</b></font>\n";
			else
				$pagemenu2 .= "<a href=\"forums.php?action=search&keywords=$keywords&page=" . ($page + 1) . "\"><b>Next &gt;&gt;</b></a>\n";
			$offset = ($page * $perpage) - $perpage;
			$res = sql_query("SELECT id, topicid,userid,added FROM posts WHERE  $extraSql LIMIT $offset,$perpage") or sqlerr(__FILE__, __LINE__);
			$num = mysql_num_rows($res);
			print("<p>$pagemenu1<br>$pagemenu2</p>");
			print("<table border=1 cellspacing=0 cellpadding=5 width=737>\n");
			print("<tr><td class=colhead>Post</td><td class=colhead align=left>Topic</td><td class=colhead align=left>Forum</td><td class=colhead align=left>Posted by</td></tr>\n");
			for ($i = 0; $i < $num; ++$i)
			{
				$post = mysql_fetch_assoc($res);
				$res2 = sql_query("SELECT forumid, subject FROM topics WHERE id=$post[topicid]") or
					sqlerr(__FILE__, __LINE__);
				$topic = mysql_fetch_assoc($res2);
				$res2 = sql_query("SELECT name,minclassread FROM forums WHERE id=$topic[forumid]") or
					sqlerr(__FILE__, __LINE__);
				$forum = mysql_fetch_assoc($res2);
				if ($forum["name"] == "" || $forum["minclassread"] > $CURUSER["class"])
				{
					--$hits;
					continue;
				}
				$res2 = sql_query("SELECT username FROM users WHERE id=$post[userid]") or
					sqlerr(__FILE__, __LINE__);
				$user = mysql_fetch_assoc($res2);
				if ($user["username"] == "")
					$user["username"] = "[$post[userid]]";
				//---------------------------------
				//---- Search Highlight v0.1 by xam
				//---------------------------------	
				print("<tr><td>$post[id]</td><td align=left><a href=?action=viewtopic&highlight=$keywords&topicid=$post[topicid]&page=p$post[id]#$post[id]><b>" . htmlspecialchars($topic["subject"]) . "</b></a></td><td align=left><a href=?action=viewforum&forumid=$topic[forumid]><b>" . htmlspecialchars($forum["name"]) . "</b></a><td align=left><b><a href=userdetails.php?id=$post[userid]>$user[username]</a></b><br>at $post[added]</tr>\n");
				//---------------------------------
				//---- Search Highlight v0.1 by xam
				//---------------------------------
			}
			print("</table>\n");
			print("<p>$pagemenu2<br>$pagemenu1</p>");			
			$found ="[<b><font color=red> Found $hits post" . ($hits != 1 ? "s" : "")." </font></b> ]";
			
		}
	}
?>
<style type="text/css">
<!--
.search{
	background-image:url(pic/search.gif);
	background-repeat:no-repeat;
	width:579px;
	height:95px;
	margin:5px 0 5px 0;
	text-align:left;
}
.search_title{
	color:#0062AE;
	background-color:#DAF3FB;
	font-size:12px;
	font-weight:bold;
	text-align:left;
	padding:7px 0 0 15px;
}

.search_table {
  border-collapse: collapse;
  border: none;
   background-color: #ffffff; 
}
-->
</style>
<div class="search">
  <div class="search_title">Search on Forums <?=($error ? "[<b><font color=red> Nothing Found</font></b> ]" : $found)?></div>
  <div style="margin-left: 53px; margin-top: 13px;">
<form method="get" action="forums.php" id="search_form" style="margin: 0pt; padding: 0pt; font-family: Tahoma,Arial,Helvetica,sans-serif; font-size: 11px;">
<input type="hidden" name="action" value="search">
      <table border="0" cellpadding="0" cellspacing="0" width="512" class="search_table">
        <tbody>
          <tr>
          <td style="padding-bottom: 3px; border: 0;" valign="top">by keyword</td>
          </tr>
          <tr>
          <td style="padding-bottom: 3px; border: 0;" valign="top">			
			<input name="keywords" type="text" value="<?=$keywords?>" size="75" /></td>
            <td style="padding-bottom: 3px; border: 0;" valign="top"><input name="image" type="image" style="vertical-align: middle; padding-bottom: 7px; margin-left: 1px;" src="pic/search_button.gif" /></td>
          </tr>
        </tbody>
      </table>
    </form>
  </div>
</div>
<?
	stdfoot();
	die;
}
if ($action == 'forumview')
{

  $forid = 0+$_GET["forid"];
// - Bleaches Edits
  mysql_query("UPDATE users SET forum_access='" . get_date_time() . "' WHERE id={$CURUSER["id"]}");// or die(mysql_error());
  $forums_res = mysql_query("SELECT * FROM forums WHERE forid=$forid ORDER BY name") or sqlerr(__FILE__, __LINE__);


  //------ Get forum name

    $res = mysql_query("SELECT name FROM overforums WHERE id=$forid") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_assoc($res) or die;

    $forumname = $arr["name"];

  stdhead("Forums");


  print("<h1><b><a href=forums.php>Forums</a></b> ->".$forumname."</h1>\n");

  print("<table border=1 cellspacing=0 cellpadding=5 width=737>\n");

  print("<tr><td class=colhead align=left>Forums</td><td class=colhead align=right>Topics</td>" .
  "<td class=colhead align=right>Posts</td>" .
  "<td class=colhead align=left>Last post</td></tr>\n");

  while ($forums_arr = mysql_fetch_assoc($forums_res))
  {
    if (get_user_class() < $forums_arr["minclassread"])
      continue;

    // Set forumid
    //mysql_query("UPDATE forums SET forumid=1") or sqlerr(__FILE__, __LINE__);

    //$forums_arr["Forumid"] = 1;

    //echo ($forum_arr["$forumid"]);
    //die('test');
    //$fid = $forums_arr["forid"];

    //if ($forums_arr["forid"] != $forid)
    // continue;


    $forumid = $forums_arr["id"];

    $forumname = htmlspecialchars($forums_arr["name"]);

    $forumdescription = htmlspecialchars($forums_arr["description"]);

if ($forums_arr["moders"])
$forumdescription .= "<br />".$forums_arr["moders"];

    $topiccount = number_format($forums_arr["topiccount"]);

    $postcount = number_format($forums_arr["postcount"]);
/*
    while ($topicids_arr = mysql_fetch_assoc($topicids_res))
    {
      $topicid = $topicids_arr['id'];

      $postcount_res = mysql_query("SELECT COUNT(*) FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);

      $postcount_arr = mysql_fetch_row($postcount_res);

      $postcount += $postcount_arr[0];
    }

    $postcount = number_format($postcount);
*/
    // Find last post ID

    $lastpostid = get_forum_last_post($forumid);

    // Get last post info

    $post_res = mysql_query("SELECT UNIX_TIMESTAMP(added) as utadded,topicid,userid FROM posts WHERE id=$lastpostid") or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($post_res) == 1)
    {
      $post_arr = mysql_fetch_assoc($post_res) or die("Bad forum last_post");

      $lastposterid = $post_arr["userid"];

      $lastpostdate = display_date_time($post_arr["utadded"] , $CURUSER[tzoffset] );

      $lasttopicid = $post_arr["topicid"];

      $user_res = mysql_query("SELECT username FROM users WHERE id=$lastposterid") or sqlerr(__FILE__, __LINE__);

      $user_arr = mysql_fetch_assoc($user_res);

      $lastposter = htmlspecialchars($user_arr['username']);

      $topic_res = mysql_query("SELECT subject FROM topics WHERE id=$lasttopicid") or sqlerr(__FILE__, __LINE__);

      $topic_arr = mysql_fetch_assoc($topic_res);

      $lasttopic = htmlspecialchars($topic_arr['subject']);

      $lastpost = "<nobr>$lastpostdate<br>" .
      "by <a href=userdetails.php?id=$lastposterid><b>$lastposter</b></a><br>" .
      "in <a href=?action=viewtopic&topicid=$lasttopicid&amp;page=p$lastpostid#$lastpostid><b>$lasttopic</b></a></nobr>";

      $r = mysql_query("SELECT lastpostread FROM readposts WHERE userid=$CURUSER[id] AND topicid=$lasttopicid") or sqlerr(__FILE__, __LINE__);

      $a = mysql_fetch_row($r);

      if ($a && $a[0] >= $lastpostid)
        $img = "unlocked";
      else
        $img = "unlockednew";
    }
    else
    {
      $lastpost = "N/A";
      $img = "unlocked";
    }
    print("<tr><td align=left><table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded style='padding-right: 5px'><img src=".
    "/pic/$img.gif></td><td class=embedded><a href=?action=viewforum&forumid=$forumid><b>$forumname</b></a>\n" .
    ($CURUSER['class']>=UC_ADMINISTRATOR ? "<font class=small> ".
    	"[<a class=altlink href=forums.php?action=editforum&forumid=$forumid>Edit</a>] ".
        "[<a class=altlink href=forums.php?action=deleteforum&forumid=$forumid>Delete</a>]</font>" : "").
    "<br>\n$forumdescription</td></tr></table></td><td align=right>$topiccount</td></td><td align=right>$postcount</td>" .
    "<td align=left>$lastpost</td></tr>\n");
  }
// End Table Mod
print("</table>");
forum_stats();
stdfoot();
///////////////////////////////
die();
}
  //-------- Handle unknown action

  if ($action != "")
    stderr("Forum Error", "Unknown action");

  //-------- Default action: View forums

  if (isset($_GET["catchup"]))
    catch_up();

  //-------- Get forums

  //-------- Get overforums --- being tested
  mysql_query("UPDATE users SET forum_access='" . get_date_time() . "' WHERE id={$CURUSER["id"]}");// or die(mysql_error());
  $forums2_res = mysql_query("SELECT * FROM overforums ORDER BY sort ASC") or sqlerr(__FILE__, __LINE__);

   stdhead("Forums");

      print("<h1><b>Tracker Forums</b></h1>\n");
      print("<table border=1 cellspacing=0 cellpadding=5 width=737>\n");

    while ($a = mysql_fetch_assoc($forums2_res))
        {
        $npost = 0;

    if (get_user_class() < $a["minclassview"])
      continue;

    $forid = $a["id"];

   $overforumname = $a["name"];

  print("<tr><td align=left class=colhead><a href=?action=forumview&forid=$forid><b><font color=white>".$overforumname."</font></b></a></td><td align=right class=colhead><font color=white><b>Topics</b></td>" .
  "<td align=right class=colhead><font color=white><b>Posts</b></font></td>" .
  "<td align=left class=colhead><font color=white><b>Last post</b></font></td></tr>\n");

                        $forums_res = mysql_query("SELECT * FROM forums WHERE forid=$forid ORDER BY forid ASC") or sqlerr(__FILE__, __LINE__);

  while ($forums_arr = mysql_fetch_assoc($forums_res))
  {
    if (get_user_class() < $forums_arr["minclassread"])
      continue;

    // Set forumid
    //mysql_query("UPDATE forums SET forumid=1") or sqlerr(__FILE__, __LINE__);

    //$forums_arr["Forumid"] = 1;

    //echo ($forum_arr["$forumid"]);
    //die('test');
    //$fid = $forums_arr["forid"];

    //if ($forums_arr["forid"] != $forid)
    // continue;


    $forumid = $forums_arr["id"];

    $forumname = htmlspecialchars($forums_arr["name"]);

    $forumdescription = htmlspecialchars($forums_arr["description"]);

if ($forums_arr["moders"])
$forumdescription .= "<br />".$forums_arr["moders"];

    $topiccount = number_format($forums_arr["topiccount"]);

    $postcount = number_format($forums_arr["postcount"]);
/*
    while ($topicids_arr = mysql_fetch_assoc($topicids_res))
    {
      $topicid = $topicids_arr['id'];

      $postcount_res = mysql_query("SELECT COUNT(*) FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);

      $postcount_arr = mysql_fetch_row($postcount_res);

      $postcount += $postcount_arr[0];
    }

    $postcount = number_format($postcount);
*/
    // Find last post ID

    $lastpostid = get_forum_last_post($forumid);

    // Get last post info

    $post_res = mysql_query("SELECT UNIX_TIMESTAMP(added) as utadded,topicid,userid FROM posts WHERE id=$lastpostid") or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($post_res) == 1)
    {
      $post_arr = mysql_fetch_assoc($post_res) or die("Bad forum last_post");

      $lastposterid = $post_arr["userid"];

      $lastpostdate = display_date_time($post_arr["utadded"] , $CURUSER[tzoffset] );

      $lasttopicid = $post_arr["topicid"];

      $user_res = mysql_query("SELECT username FROM users WHERE id=$lastposterid") or sqlerr(__FILE__, __LINE__);

      $user_arr = mysql_fetch_assoc($user_res);

      $lastposter = htmlspecialchars($user_arr['username']);

      $topic_res = mysql_query("SELECT subject FROM topics WHERE id=$lasttopicid") or sqlerr(__FILE__, __LINE__);

      $topic_arr = mysql_fetch_assoc($topic_res);

      $lasttopic = htmlspecialchars($topic_arr['subject']);

      $lastpost = "<nobr>$lastpostdate<br>" .
      "by <a href=userdetails.php?id=$lastposterid><b>$lastposter</b></a><br>" .
      "in <a href=?action=viewtopic&topicid=$lasttopicid&amp;page=p$lastpostid#$lastpostid><b>$lasttopic</b></a></nobr>";

      $r = mysql_query("SELECT lastpostread FROM readposts WHERE userid=$CURUSER[id] AND topicid=$lasttopicid") or sqlerr(__FILE__, __LINE__);

      $a = mysql_fetch_row($r);

      if ($a && $a[0] >= $lastpostid)
        $img = "unlocked";
      else
        $img = "unlockednew";
    }
    else
    {
      $lastpost = "N/A";
      $img = "unlocked";
    }
    print("<tr><td align=left><table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded style='padding-right: 5px'><img src=".
    "/pic/$img.gif></td><td class=embedded><a href=?action=viewforum&forumid=$forumid><b>$forumname</b></a>\n" .
    ($CURUSER['class']>=UC_ADMINISTRATOR ? "<font class=small> ".
    	"[<a class=altlink href=forums.php?action=editforum&forumid=$forumid>Edit</a>] ".
        "[<a class=altlink href=forums.php?action=deleteforum&forumid=$forumid>Delete</a>]</font>" : "").
    "<br>\n$forumdescription</td></tr></table></td><td align=right>$topiccount</td></td><td align=right>$postcount</td>" .
    "<td align=left>$lastpost</td></tr>\n");


  }

  }
// End Table Mod
print("</table>");
forum_stats();
print("<p align=center><a href=?action=search><b>Search</b></a> | <a href=?action=viewunread><b>View unread</b></a> | <a href=?catchup><b>Catch up</b></a> ".($CURUSER['class'] >= UC_MODERATOR ? "| <a href=forummanage.php#add><b>Add Forum</b></a>":"")."</p>");
stdfoot();
?>


