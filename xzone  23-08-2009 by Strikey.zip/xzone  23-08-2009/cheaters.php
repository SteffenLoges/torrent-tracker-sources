<?
require "include/bittorrent.php";

dbconn();

loggedinorreturn();

if (get_user_class() < UC_MODERATOR)
stderr("Sorry", "Access denied.");

stdhead("Cheaters");

begin_main_frame();
begin_frame("Cheating Users:", true);

// Will: added this for page links
$res = mysql_query("SELECT COUNT(*) FROM cheaters $limit") or sqlerr();
$row = mysql_fetch_array($res);
$count = $row[0];

list($pagertop, $pagerbottom, $limit) = pager(30, $count, "cheaters.php?");
print("$pagertop");
// end

?>
<script type="text/javascript" src="java_klappe.js"></script>

<form action="takecheaters.php" method=post>

<script language="JavaScript" type="text/javascript">
<!-- Begin
var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return "Uncheck All Disable"; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return "Check All Disable"; }
}

function check2(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return "Uncheck All Remove"; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return "Check All Remove"; }
}
// End -->
</script>

<?

print("<table width=100%>");

print("<table border=1 width=100% cellspacing=0 cellpadding=2>");
print("<tr align=center><td class=colhead>#</td>
<td class=colhead>User</td>
<td class=colhead>Added</td>
<td class=colhead>Torrent</td>
<td class=colhead>Client</td>
<td class=colhead>Speed</td>
<td class=colhead>Uploaded</td>
<td class=colhead>Time</td>
<td class=colhead>Leechers</td>
<td class=colhead>IP</td>
<td class=colhead>R</td></tr>\n");

$res = mysql_query("SELECT * FROM cheaters ORDER BY added DESC $limit") or sqlerr(__FILE__, __LINE__);
while ($arr = mysql_fetch_assoc($res))
{
$rrr = mysql_query("SELECT id, username, class, downloaded, uploaded FROM users WHERE id = $arr[userid]");
$aaa = mysql_fetch_assoc($rrr);

$rrr2 = mysql_query("SELECT name, leechers FROM torrents WHERE id = $arr[torrentid]");
$aaa2 = mysql_fetch_assoc($rrr2);

if($aaa["downloaded"] > 0)
{
$ratio = number_format($aaa["uploaded"] / $aaa["downloaded"], 3);
}
else
{
$ratio = "---";
}
$ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";

$uppd = mksize($arr["upthis"]);


print("<tr><td align=center width=10>$arr[id]</td>");
print("<td align=left><b><a href=userdetails.php?id=$aaa[id]>$aaa[username]</a></b></td>");
print("<td align=center>$arr[added]</td>");
print("<td align=center><u><a href=details.php?id=$arr[torrentid]>$arr[torrentid]</a></u></td>");
print("<td align=center>$arr[client]</td>");
print("<td align=center>$arr[rate]/s</td>");
print("<td align=center>$uppd</td>");
print("<td align=center>$arr[timediff] sec</td>");
print("<td align=center>$aaa2[leechers]</td>");
print("<td align=center>$arr[userip]</td>");
print("<td class=\"tableb\" valign=\"top\" width=10><input type=\"checkbox\" name=\"remove[]\" value=\"" . $arr["id"] . "\"/></td>");
}
if (get_user_class() >= UC_MODERATOR)
{
?>
<tr>
<td class="tableb" colspan="11" align="right">
<input type="button" value="Check All Remove" onclick="this.value=check(this.form.elements['remove[]'])"/> <input type="hidden" name="nowarned" value="nowarned"><input type="submit" name="submit" value="Apply Changes"></td>
</tr>
</table></form>
<?
}

// will: added this for page links
print("<br>$pagertop");
// end

end_frame();
end_main_frame();
stdfoot();
die;

?>