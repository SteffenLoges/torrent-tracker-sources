<?
require_once("include/bittorrent.php");


dbconn();

loggedinorreturn();

stdhead("Preview post");

$body = $HTTP_POST_VARS['body'];

begin_main_frame();

begin_frame("Preview Post", true);
?>
<table width="60%" border="1" cellspacing="0">
<tr>
<td align="center" style='border: 0;'>
<div align="left">
<p><?=format_comment($body)?></p>
</div>
<table class="main" width="300" cellspacing="0" cellpadding="5">
<form method="post" action="?">
<textarea name="body" cols="100" rows="10"><?=$body?></textarea><br>
<div align="left">
<input type="submit" class="btn" value="Preview">
</div>
</form>
</table></table>
</tr></td>
<?

end_frame();

end_main_frame();

stdfoot();

?>