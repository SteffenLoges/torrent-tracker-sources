<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


dbconn(false);

loggedinorreturn();
parked();


$cats = genrelist();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);

if (empty($cleansearchstr))
unset($cleansearchstr);

// sorting by MarkoStamcar

if ($_GET['sort'] && $_GET['type']) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
case '1': $column = "name"; break;
case '2': $column = "numfiles"; break;
case '3': $column = "comments"; break;
case '4': $column = "added"; break;
case '5': $column = "size"; break;
case '6': $column = "times_completed"; break;
case '7': $column = "seeders"; break;
case '8': $column = "leechers"; break;
case '9': $column = "owner"; break;
default: $column = "id"; break;
}
    switch($_GET['type']) {
  case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
  case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
  default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
    }


$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";


} else {

$orderby = "ORDER BY torrents.sticky ASC, torrents.id DESC";
$pagerlink = "";

}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
        $addparam .= "incldead=1&amp;";
        if (!isset($CURUSER) || get_user_class() < UC_ADMINISTRATOR)
                $wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
        $addparam .= "incldead=2&amp;";
                $wherea[] = "visible = 'no'";
}
        else
                $wherea[] = "visible = 'yes'";
if ($CURUSER["view_xxx"] != "yes")
 $wherea[] = "category != '34'";

$category = (int)$_GET["cat"];

$all = $_GET["all"];

if (!$all)
        if (!$_GET && $CURUSER["notifs"])
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $cat[id];
            if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }
        elseif ($category)
        {
          if (!is_valid_id($category))
            stderr("Error", "Invalid category ID $category");
          $wherecatina[] = $category;
          $addparam .= "cat=$category&amp;";
        }
        else
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $_GET["c$cat[id]"];
            if ($_GET["c$cat[id]"])
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }

if ($all)
{
        $wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
$wherea[] = "category = $wherecatina[0]";
$wherea[] = "category NOT IN (1,6,7,9,12,17,23,19,20,21,22,24,25,26,27,28,31,32,38,4,5,40,34)";
$wherebase = $wherea;

if (isset($cleansearchstr))
{
        $wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
        //$wherea[] = "0";
        $addparam .= "search=" . urlencode($searchstr) . "&amp;";
        //$orderby = "";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
        $where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
        $where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
        $wherea = $wherebase;
        //$orderby = "ORDER BY id DESC";
        $searcha = explode(" ", $cleansearchstr);
        $sc = 0;
        foreach ($searcha as $searchss) {
                if (strlen($searchss) <= 1)
                        continue;
                $sc++;
                if ($sc > 5)
                        break;
                $ssa = array();
                foreach (array("search_text", "ori_descr") as $sss)
                        $ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
                $wherea[] = "(" . implode(" OR ", $ssa) . ")";
        }
        if ($sc) {
                $where = implode(" AND ", $wherea);
                if ($where != "")
                        $where = "WHERE $where";
                $res = mysql_query("SELECT COUNT(*) FROM torrents $where");
                $row = mysql_fetch_array($res);
                $count = $row[0];
        }
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
        $torrentsperpage = 15;

    if ($addparam != "") {
 if ($pagerlink != "") {
  if ($addparam{strlen($addparam)-1} != ";") { // & = &amp;
    $addparam = $addparam . "&" . $pagerlink;
  } else {
    $addparam = $addparam . $pagerlink;
  }
 }
    } else {
 $addparam = $pagerlink;
    }

if ($count)
{
        list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browsemusic.php?" . $addparam);
        $query = "SELECT torrents.id, torrents.nuked, torrents.category, torrents.leechers, torrents.sticky, torrents.seeders, torrents.request, torrents.scene, torrents.free, torrents.name, torrents.double_upload, torrents.times_completed, torrents.size, torrents.added, torrents.comments,torrents.numfiles,torrents.filename,torrents.description,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
//        "IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
        "categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
        $res = mysql_query($query) or die(mysql_error());
}
else
        unset($res);
if (isset($cleansearchstr))
        stdhead("Search results for \"$searchstr\"");
else
        stdhead("Browse Torrents");

?>

<style type="text/css">
<!--

.search{
	background-image:url(pic/search.gif);
	background-repeat:no-repeat;
	width:579px;
	height:95px;
	margin:5px 0 5px 0;
	text-align:left;
}

.search_title{
	color:#0062AE;
	background-color:#;
	font-size:12px;
	font-weight:bold;
	text-align:left;
	paddg:7px 0 0 15px;
}

.search_table {
	border-collapse: collapse;
	border: none;
	background-color: #ffffff; 
}

a.catlink:link, a.catlink:visited{
	text-decoration: none;
}

a.catlink:hover {
	color: #A83838;
}
-->
</style>
<table class="categ" border="1" cellpadding="0" cellspacing="5" width="720">
  <tbody>
    <tr>
    <td width="700"><center>

	<form method="get" action="browsemusic.php">
	<b>Cauta:</b>
	<input name="search" size="40" value="" type="text"> 
    
	</select>
	<input value="Cauta!" type="submit">	
    <b></b>	
    <select name="incldead">
    <option value="0">active</option>
    <option value="1">dead too</option>
    <option value="2">only dead</option>
    <option value="3">Free Torrents</option>
    </select>

    <input value="Go!" type="submit">
	</form></center>
	</td>

</table>
<div id="kbrowse" style="display: none;"><table width=720 border="0" class=statusbar >

      <tr>
      <td colspan="2">
	  <table class="bot" id="cats" style="display: block;">	<tbody><tr>



	</tr>

	</tbody></table>

</td>
    </tr>
  </tbody>


</div>
</form>
<script language="JavaScript" src="suggest.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 520px; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>


          </tr>
        </tbody>
      </table>
    </form>
  </div>
</div>
<?


if (isset($cleansearchstr))
print("<h2>Search results for \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
        print($pagertop);

        torrenttable($res);

        print($pagerbottom);
}
else {
        if (isset($cleansearchstr)) {
                print("<h2>Nothing found!</h2>\n");
                print("<p>Try again with a refined search string.</p>\n");
        }
        else {
                print("<h2>Nothing here!</h2>\n");
                print("<p>Sorry pal :(</p>\n");
        }
}

?>
<br>

<?

stdfoot();

mysql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);

?>