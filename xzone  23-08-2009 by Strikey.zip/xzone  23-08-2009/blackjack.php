<?
require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
function get_user_name($userid){
$r = mysql_query("select username from users where id=$userid");
$a = mysql_fetch_array($r);
return "$a[username]";
}
/*function playerexists($userid){
$r = mysql_query("select count(*) from casino where userid=$userid");
$a = mysql_fetch_array($r);
if ($a[0] > 0) return true;
else return false;
}*/
$mb = 1024*1024*100;//bet size
if ($_POST["game"]){
$cardcountres = mysql_query("select count(id) from cards") or sqlerr(__FILE__, __LINE__);
$cardcountarr = mysql_fetch_array($cardcountres);
$cardcount = $cardcountarr[0];
if ($_POST["game"] == 'start'){

if($CURUSER["uploaded"] < $mb)
stderr("Sorry ".$CURUSER["username"],"You didn't uploaded ".mksize($mb));
$required_ratio = 0.3;
if ($CURUSER["downloaded"] > 0)
$ratio = number_format($CURUSER["uploaded"] / $CURUSER["downloaded"], 2);
else
if ($CURUSER["uploaded"] > 0)
$ratio = 999;
else
$ratio = 0;
if($ratio < $required_ratio)
stderr("Sorry ".$CURUSER["username"],"Your ratio is lower than ".$required_ratio);
$res = mysql_query("select count(*) from blackjack where userid=$CURUSER[id] and status='waiting'");
$arr = mysql_fetch_array($res);
if ($arr[0] > 0) {
stderr("Sorry","You'll have to wait until someone plays against you");
}else{
$res = mysql_query("select count(*) from blackjack where userid=$CURUSER[id] and status='playing'");
$arr = mysql_fetch_array($res);
if ($arr[0] > 0)
stderr("Sorry","You must finish your old game. <form method=post name=form action=$phpself><input type=hidden name=game value=cont><input type=submit value='Continue old game'></form>");}
$cardid = rand(1,$cardcount);
$cardres = mysql_query("select * from cards where id=$cardid") or sqlerr(__FILE__, __LINE__);
$cardarr = mysql_fetch_array($cardres);
mysql_query("insert into blackjack (userid, points, cards) values($CURUSER[id], $cardarr[points], $cardid)") or sqlerr(__FILE__, __LINE__);
stdhead();
print("<h1>Welcome, <a href=userdetails.php?id=$CURUSER[id]>$CURUSER[username]</a>!</h1>\n");
print("<table cellspacing=0 cellpadding=3 width=600>\n");
print("<tr><td colspan=2 cellspacing=0 cellpadding=5 >");
print("<form name=blackjack method=post action=$phpself>");
print("<table class=message width=100% cellspacing=0 cellpadding=5 bgcolor=white>\n");
print("<tr><td align=center><img src=pic/cards/".$cardarr["pic"]." border=0></td></tr>");
print("<tr><td align=center><b>Points = $cardarr[points]</b></td></tr>");
print("<tr><td align=center><input type=hidden name=game value=cont><input type=submit value='Hit me'></td></tr>");
print("</table><br>");
print("</form>");
print("</td></tr></table><br>");
stdfoot();
}
elseif ($_POST["game"] == 'cont'){

$playeres = mysql_query("select * from blackjack where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
$playerarr = mysql_fetch_array($playeres);
$showcards = "";
$cards = $playerarr["cards"];
$usedcards = explode(" ", $cards);
$arr = array();
foreach($usedcards as $array_list)
$arr[] = $array_list;
foreach($arr as $card_id)
{
$used_card = mysql_query("SELECT * FROM cards WHERE id='$card_id'") or sqlerr(__FILE__, __LINE__);
$used_cards = mysql_fetch_array($used_card);
$showcards .= "<img src=pic/cards/".$used_cards["pic"]." border=0> ";
$i++;
}
$cardid = rand(1,$cardcount);
while (in_array($cardid, $arr))
{
$cardid = rand(1,$cardcount);
}
$cardres = mysql_query("select * from cards where id=$cardid") or sqlerr(__FILE__, __LINE__);
$cardarr = mysql_fetch_array($cardres);
$showcards .= "<img src=pic/cards/".$cardarr["pic"]." border=0> ";
$points = $playerarr["points"] + $cardarr["points"];
$mysqlcards = "$playerarr[cards] $cardid";
mysql_query("update blackjack set points=points+$cardarr[points], cards='$mysqlcards' where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
if ($points == 21){
$waitres = mysql_query("select count(*) from blackjack where status='waiting'");
$waitarr = mysql_fetch_array($waitres);
if ($waitarr[0] > 0){
$r = mysql_query("select * from blackjack where status='waiting' order by date asc LIMIT 1");
$a = mysql_fetch_assoc($r);
if ($a["points"] != 21){
$winorlose = "you won ".mksize($mb);
mysql_query("update users set uploaded = uploaded + $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded - $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You lost ".mksize($mb)." to $CURUSER[username] (You had $a[points] points, $CURUSER[username] had 21 points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}else{
$winorlose = "nobody won";
}
stderr("Game over", "You have 21 points, your opponent was ".get_user_name($a["userid"]).", he had $a[points] points, $winorlose . <a href=blackjack.php>Play again</a>. ");
}
else{
mysql_query("update blackjack set status = 'waiting', date='".get_date_time()."' where userid = $CURUSER[id]") or sqlerr(__FILE__, __LINE__);
stderr("Game over", "You have 21 points, there's no other players, so you'll have to wait until someone will play against you. You will be PM'd about game results");
}
}
elseif ($points > 21) {
$waitres = mysql_query("select count(*) from blackjack where status='waiting'");
$waitarr = mysql_fetch_array($waitres);
if ($waitarr[0] > 0){
$r = mysql_query("select * from blackjack where status='waiting' order by date asc LIMIT 1");
$a = mysql_fetch_assoc($r);
if ($a["points"] == $points){
$winorlose = "nobody won";
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("Your opponent was $CURUSER[username], nobody won . <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);}
elseif ($a["points"] > $points){
$winorlose = "you won ".mksize($mb);
mysql_query("update users set uploaded = uploaded + $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded - $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You lost ".mksize($mb)." to $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $points points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
elseif ($a["points"] < $points){
$winorlose = "you lost ".mksize($mb);
mysql_query("update users set uploaded = uploaded - $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded + $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You won ".mksize($mb)." from $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $points points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
stderr("Game over", "You have $points points, your opponent was ".get_user_name($a["userid"]).", he had $a[points] points, $winorlose . <a href=blackjack.php>Play again</a>. ");
}
else
{
mysql_query("update blackjack set status = 'waiting', date='".get_date_time()."' where userid = $CURUSER[id]") or sqlerr(__FILE__, __LINE__);
stderr("Game over", "You have $points points, there's no other players, so you'll have to wait until someone will play against you. You will be PM'd about game results");
}
}

else{
stdhead();
print("<h1>Welcome, <a href=userdetails.php?id=$CURUSER[id]>$CURUSER[username]</a>!</h1>\n");
print("<table cellspacing=0 cellpadding=3 width=600>\n");
print("<tr><td colspan=2 cellspacing=0 cellpadding=5 >");
print("<table class=message width=100% cellspacing=0 cellpadding=5 bgcolor=white>\n");
print("<tr><td align=center>$showcards</td></tr>");
print("<tr><td align=center><b>Points = $points</b></td></tr>");
print("<form name=blackjack method=post action=$phpself>");
print("<tr><td align=center><input type=hidden name=game value=cont><input type=submit value='Hit me'></td></tr>");
print("</form>");
print("<form name=blackjack method=post action=$phpself>");
print("<tr><td align=center><input type=hidden name=game value=stop><input type=submit value='Enough'></td></tr>");
print("</form>");
print("</table><br>");
print("</td></tr></table><br>");
stdfoot();
}
}elseif ($_POST["game"] == 'stop')
{

$playeres = mysql_query("select * from blackjack where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
$playerarr = mysql_fetch_array($playeres);
$waitres = mysql_query("select count(*) from blackjack where status='waiting'");
$waitarr = mysql_fetch_array($waitres);
if ($waitarr[0] > 0){
$r = mysql_query("select * from blackjack where status='waiting' order by date asc LIMIT 1");
$a = mysql_fetch_assoc($r);
if ($a["points"] == $playerarr[points]){
$winorlose = "nobody won";
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("Your opponent was $CURUSER[username], nobody won . <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);}
elseif ($a["points"] < $playerarr[points] && $a[points] < 21){
$winorlose = "you won ".mksize($mb);
mysql_query("update users set uploaded = uploaded + $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded - $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You lost ".mksize($mb)." to $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $playerarr[points] points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
elseif ($a["points"] > $playerarr[points] && $a[points] < 21){
$winorlose = "you lost ".mksize($mb);
mysql_query("update users set uploaded = uploaded - $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded + $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You won ".mksize($mb)." from $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $playerarr[points] points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
elseif ($a["points"] == 21){
$winorlose = "you lost ".mksize($mb);
mysql_query("update users set uploaded = uploaded - $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded + $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You won ".mksize($mb)." from $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $playerarr[points] points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
elseif ($a["points"] < $playerarr[points] && $a[points] > 21){
$winorlose = "you lost ".mksize($mb);
mysql_query("update users set uploaded = uploaded - $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded + $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You won ".mksize($mb)." from $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $playerarr[points] points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
elseif ($a["points"] > $playerarr[points] && $a[points] > 21){
$winorlose = "you won ".mksize($mb);
mysql_query("update users set uploaded = uploaded + $mb where id=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("update users set uploaded = uploaded - $mb where id=$a[userid]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set win = win + $mb where userid=$CURUSER[id]") or sqlerr(__FILE__, __LINE__);
//mysql_query("update casino set lost = lost + $mb where userid=$a[userid]") or sqlerr(__FILE__, __LINE__);
mysql_query("delete from blackjack where userid=$CURUSER[id]");
mysql_query("delete from blackjack where userid=$a[userid]");
$dt = sqlesc(get_date_time());
$msg = sqlesc("You lost ".mksize($mb)." to $CURUSER[username] (You had $a[points] points, $CURUSER[username] had $playerarr[points] points). <a href=blackjack.php>Play again</a>.");
mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $a[userid], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
}
stderr("Game over", "You have $playerarr[points] points, your opponent was ".get_user_name($a["userid"]).", he had $a[points] points, $winorlose . <a href=blackjack.php>Play again</a>. ");
}
else
{
mysql_query("update blackjack set status = 'waiting', date='".get_date_time()."' where userid = $CURUSER[id]") or sqlerr(__FILE__, __LINE__);
stderr("Game over", "You have $playerarr[points] points, there's no other players, so you'll have to wait until someone will play against you. You will be PM'd about game results");
}
}
}
else
{
//if (playerexists($CURUSER[id]) == false)
//mysql_query("insert into casino (userid, win, lost) values($CURUSER[id], 0, 0)") or sqlerr(__FILE__, __LINE__);
stdhead();
print("<h1>BlackJack</h1>\n");
print("<table cellspacing=0 cellpadding=3 width=400>\n");
print("<tr><td colspan=2 cellspacing=0 cellpadding=5 align=center>");
//print("<h3><a href=players.php>Stats</a></h3>");
print("<table class=message width=100% cellspacing=0 cellpadding=10 bgcolor=white>\n");
print("<tr><td align=left><h3>Rules</h3>You must collect 21 points...</td></tr>");
print("</table><br>");
print("<form name=form method=post action=$phpself><input type=hidden name=game value=start><input type=submit class=btn value='Play'>");
print("</td></tr></table>");

stdfoot();
}
?>