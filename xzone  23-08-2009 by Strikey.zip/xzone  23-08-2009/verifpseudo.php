<?
//
// VERIFICATION EN LIVE DU PSEUDO
//

// CONNECION SQL
mysql_connect("localhost", "username_of_your_database_here", "password_of_your_database_here");
mysql_select_db("database_here");

// VERIFICATION
$result = mysql_query("SELECT username FROM users WHERE username='".$_GET["pseudo"]."'");
if(mysql_num_rows($result)>=1)
echo "1";
else
echo "2";
?>