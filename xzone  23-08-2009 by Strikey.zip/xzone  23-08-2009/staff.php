<?php
require "include/bittorrent.php";
global $pic_base_url;
dbconn();
loggedinorreturn();
if ($CURUSER["class"] > 11)
{
stdhead();
  stdmsg("FUCK OFF...", "STOP CHEATING MOTHER FUCKER");
  stdfoot();
  exit;
}
stdhead("Staff");
begin_main_frame();

    // Display Staff List to all users
	begin_frame("Staff");

    // Get current datetime
    $dt = get_date_time(gmtime() - 180);
	// Search User Database for Moderators and above and display in alphabetical order
    $res = mysql_query("SELECT * FROM users WHERE class>=".UC_UPLOADER.
    	" AND status='confirmed' ORDER BY username") or sqlerr();
    $num = mysql_num_rows($res);
    while ($arr = mysql_fetch_assoc($res))
    {
        $land = mysql_query("SELECT name,flagpic FROM countries WHERE id=$arr[country]") or sqlerr();
  $arr2 = mysql_fetch_assoc($land);
  $staff_table[$arr['class']]=$staff_table[$arr['class']].
        	            "<td class=embedded><a class=altlink href=userdetails.php?id=$arr[id]>$arr[username]</a><td class=embedded><img src=$pic_base_url/button_o".($arr[last_access]>$dt?"n":"ff")."line.gif></td>".
   		    "<td class=embedded><a href=sendmessage.php?receiver=$arr[id]>".
            "<img src=$pic_base_url/button_pm.gif border=0></a></td>".
            "<td class=embedded><img src=".$pic_base_url."/flag/$arr2[flagpic] border=0 width=19 height=12></td>\n";
        // Show 3 staff per row, separated by an empty column
        ++ $col[$arr['class']];
        if ($col[$arr['class']]<=2)
            $staff_table[$arr['class']]=$staff_table[$arr['class']]."<td class=embedded>&nbsp;</td>";
        else
        {
            $staff_table[$arr['class']]=$staff_table[$arr['class']]."</tr><tr height=25>";
            $col[$arr['class']]=0;
        }
	}
?>

<br>
<table width=700 cellspacing=0 align=center>

	<td class=embedded colspan=14>&nbsp;</td>
</tr>
<tr>
<? if (get_user_class() <= UC_POWERUPLOADER) { ?>

<? } ?>
		<? if (get_user_class() >= UC_MODERATOR) { ?> 

<td class=embedded colspan=14><b>Staff Leaders</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_SL]?>

</tr>
<tr>
	<td class=embedded colspan=14>&nbsp;</td>
</tr>


<tr>
<td class=embedded colspan=14><b>Owners</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_OWNER]?>
</tr><td class=embedded colspan=14><b>SysOps</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_SYSOP]?>
</tr>
<tr>
	<td class=embedded colspan=14>&nbsp;</td>
</tr>


<tr>
	<td class=embedded colspan=14><b>Administrators</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_ADMINISTRATOR]?>
</tr>
<tr>
	<td class=embedded colspan=14>&nbsp;</td>
</tr>
<tr>
	<td class=embedded colspan=14><b>Moderators</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_MODERATOR]?>
</tr>
<tr>
	<td class=embedded colspan=14>&nbsp;</td>
</tr>
<tr>
	<td class=embedded colspan=14><b>Power Uploaders</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_POWERUPLOADER]?>
</tr>
<tr>
	<td class=embedded colspan=14>&nbsp;</td>
</tr>
<tr>
	<td class=embedded colspan=14><b>Uploaders</b></td>
</tr>
<tr>
	<td class=embedded colspan=14><hr color="#04182c" size=1></td>
</tr>
<tr height=15>
	<?=$staff_table[UC_UPLOADER]?>
</tr>
<tr>
<? } ?>
    <!-- Define table column widths -->
<td class=embedded width="120">&nbsp;</td>
<td class=embedded width="18">&nbsp;</td>
<td class=embedded width="25">&nbsp;</td>
<td class=embedded width="25">&nbsp;</td>
<td class=embedded width="80">&nbsp;</td>
<td class=embedded width="120">&nbsp;</td>
<td class=embedded width="18">&nbsp;</td>
<td class=embedded width="25">&nbsp;</td>
<td class=embedded width="25">&nbsp;</td>
<td class=embedded width="80">&nbsp;</td>
<td class=embedded width="120">&nbsp;</td>
<td class=embedded width="18">&nbsp;</td>
<td class=embedded width="25">&nbsp;</td>
<td class=embedded width="25">&nbsp;</td>
</tr>
</table>
<?	
end_frame();

if (!$act) {
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
// LIST ALL FIRSTLINE SUPPORTERS
// Search User Database for Firstline Support and display in alphabetical order
$res = mysql_query("SELECT * FROM users WHERE support='yes' AND status='confirmed' ORDER BY username LIMIT 30") or sqlerr();
while ($arr = mysql_fetch_assoc($res))
{
 $land = mysql_query("SELECT name,flagpic FROM countries WHERE id=$arr[country]") or sqlerr();
 $arr2 = mysql_fetch_assoc($land);
 $firstline .= "<tr height=15><td class=embedded><a class=altlink href=userdetails.php?id=".$arr['id'].">".$arr['username']."</a></td>
 <td class=embedded> ".("'".$arr['last_access']."'">$dt?"<img src=".$pic_base_url."button_online.gif border=0 alt=\"online\">":"<img src=".$pic_base_url."button_offline.gif border=0 alt=\"offline\">" )."</td>".
 "<td class=embedded><a href=sendmessage.php?receiver=".$arr['id'].">"."<img src=".$pic_base_url."button_pm.gif border=0></a></td>".
 "<td class=embedded><img src=".$pic_base_url."/flag/$arr2[flagpic] border=0 width=19 height=12></td>".
 "<td class=embedded>".$arr['supportfor']."</td></tr>\n";
}

begin_frame("Firstline Support");
?>

<table width=710 cellspacing=0>
<tr>
<td class=embedded colspan=11>General support questions should preferably be directed to these users. Note that they are volunteers, giving away their time and effort to help you.
Treat them accordingly. <b>(Languages listed are those besides English.)</b><br><br><br></td></tr>
<!-- Define table column widths -->
<tr>
<td class=embedded width="100"><b>Username</b></td>&nbsp;
<td class=embedded align=center width="100"><b>Status</b></td>&nbsp;&nbsp;&nbsp;

<td class=embedded align=center width="100"><b>Contact</b></td>&nbsp;
 <td class=embedded align=center width="85"><b>Language</b></td>

<td class=embedded width="200"><b>Support for:</b></td>
</tr>


<tr>
<tr><td class=embedded colspan=11><hr color="#04182c" size=1></td></tr>

<?=$firstline?>

</tr>
</table>
<?
end_frame();
}
end_main_frame();
stdfoot();
?>