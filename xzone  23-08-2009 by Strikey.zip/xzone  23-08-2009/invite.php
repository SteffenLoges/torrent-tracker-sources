<?php
require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();
header("Content-Type: text/html; charset=iso-8859-1");
if ($CURUSER["class"] < UC_USER)
stderr("Access denied", "You must have be registered User in order to send invite.");

if ($CURUSER["invite_on"] == 'no')
stderr("Denied", "Your invite sending privileges has been disabled by the Staff!");





if (get_user_class() < UC_USER)
stderr("Denied", "You must be User+ in order to send an invite.");
$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $invites)
stderr("Denied", "We reached our user limit (" . number_format($invites) . ") . Try again later...");
$rez = $CURUSER["invites"];

if($CURUSER["invites"] == 0)
stderr("Denied","You don't have any invites!");
stdhead("Invites")

?>
<p>
<form method="post" action="takeinvite.php">
<h2>Caution.</h2>
Be careful on who you invite into this private community.<br />
<table border="0" class=detail width=655 cellspacing=0 cellpadding="10">
<tr valign=top><td align="right" class="heading">Information</td><td class=detail align=left><b> - You have <?print("<font color=red>$rez</font>"); ?> invite(s) left</b></td></tr>
<tr valign=top><td align="right" class="heading">Recipient's email:</td><td class=detail align=left><input type="text" size="40" name="email" />
<tr><td align="right" class="heading">Message: </td><td class=detail align=left><textarea name="mess" rows="10" cols="80">
IMPORTANT!

We do not want to see invite threads/posts on other boards! We will be actively scanning all the boards (yes, we're pretty sure we know of all of them) for these types of threads. Participating in these threads puts everyone here at risk and proves that you are not responsible enough to stay here. So:

ANYONE found participating in these threads will be banned. We will invesitgate all new signups and if they are found to be from one of these threads/posts, we will disable their account and the person who invited them.

Be discreet, invite people you trust. Thanks for your cooperation.

Example Message:
Hello,
I am inviting you to join XZone V2.4. This is a private community which has very knowledgable members. If you are interested in joining the community please read over the rules and confirm the invite.
Regards,
<?print($CURUSER[username]);?></textarea>
</td></tr>
<tr><td colspan="2" align="center"><input type=submit class="button" value="Send&nbsp;invite! (PRESS ONLY ONCE)"></td></tr>
</table>
</form>

<?
stdfoot();
?>