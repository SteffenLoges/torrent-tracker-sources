<?php
//imunit?tes scripts - danka - www.velkam.org - info@velkam.org
require_once("include/bittorrent.php");
stdhead();
if (get_user_class() < UC_MODERATOR)
{
stdmsg("Sorry..", "You need to by Moderator.");
stdfoot();
exit;
}
?>
<table width="450px" align="center">
<h3>Users with immunity</h3><br><h5>These users have immunity - <a href="jauns_imuni.php">New immunity user</a></h5>
<?include("saraksts.txt")?>
</td>

<?
stdfoot();
?>