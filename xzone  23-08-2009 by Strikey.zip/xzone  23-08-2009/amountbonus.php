<?php
require "include/bittorrent.php";
dbconn();
loggedinorreturn();
if (get_user_class() < UC_SYSOP)
stderr("Error", "Access denied.");
if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
    if ($_POST['doit'] == 'yes') {
    sql_query("UPDATE users SET seedbonus = seedbonus + 25.0 WHERE status='confirmed'");
    stderr("Bonus", "25.0 bonus point is sent to everyone...");
    die;
    }
        
    if ($HTTP_POST_VARS["username"] == "" || $HTTP_POST_VARS["seedbonus"] == "" || $HTTP_POST_VARS["seedbonus"] == "")
    stderr("Error", "Missing form data.");
    $username = sqlesc($HTTP_POST_VARS["username"]);
    $seedbonus = sqlesc($HTTP_POST_VARS["seedbonus"]);

    sql_query("UPDATE users SET seedbonus=seedbonus + $seedbonus WHERE username=$username") or sqlerr(__FILE__, __LINE__);
    $res = sql_query("SELECT id FROM users WHERE username=$username");
    $arr = mysql_fetch_row($res);
    if (!$arr)
    stderr("Error", "Unable to update account.");
    header("Location: $BASEURL/userdetails.php?id=".htmlspecialchars($arr[0]));
    die;
}
stdhead("Update Users Upload Amounts");
?>
<h1>Update Users Upload Amounts</h1>

<?begin_frame("Update Users Bonus Amounts",false,10,false);
echo "<form method=\"post\" action=\"amountbonus.php\">";
begin_table(true);
?>
<tr><td class="rowhead">User name</td><td class="row1"><input type="text" name="username" size="40"/></td></tr>
<tr><td class="rowhead">Bonus</td><td class="row1"><input type="text" name="seedbonus" size="5"/></td></tr>
<tr><td colspan="2" class="row1" align="center"><input type="submit" value="Okay" class="btn"/></td></tr>
<?end_table();?>
</form>
<?end_frame();?>
<?begin_frame("Send 25.0 bonus point to everyone",false,10,false);?>
<form action="amountbonus.php" method="post">
<?begin_table(true);?>
<tr><td class="row1" align="center">
Are you sure you want to give<br/> all confirmed users 25.0 extra bonus point?<br /><br />
<input type = "hidden" name = "doit" value = "yes" />
<input type="submit" value="Yes" />
</td></tr>
<? end_table();?>
</form>
<?end_frame();

stdfoot(); ?>
