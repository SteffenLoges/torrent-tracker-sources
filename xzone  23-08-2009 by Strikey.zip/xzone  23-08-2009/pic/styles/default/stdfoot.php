<?
function stdfoot() {
print("</center><br /><td class=\"cHs\" background=\"pic/right.gif\"></td></tr><tr><th align=\"left\" valign=\"top\" scope=\"row\"><img src=\"pic/bottom1.gif\"></th><td class=\"cHs\" height=\"34\" background=\"pic/bottom2.gif\"><center>$SITENAME is Powered by <a href=\"http://www.tbdev.net\">TBDev.Net</a></center></td><td class=\"cHs\" height=\"34\" align=\"right\" valign=\"top\"><img src=\"pic/bottom3.gif\"></td></tr></table></body><html>");
  ?>
<?
  print("</tr></table>\n");
  print("</body></html>\n");
}