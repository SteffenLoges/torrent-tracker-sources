<?
function stdfoot() {
  print("</td></tr></table></table>\n");
  ?><center></center>
  <center>
 
<div class="footer"><img class="footer" src="../pic/styles/light/bottom.jpg " usemap="#footer" alt="" style="border-style: none;"><map id="footer" name="footer">
<area shape="rect" alt="" coords="298,41,347,65" href="links.php">
<area shape="rect" alt="" coords="350,41,404,65" href="users.php">
<area shape="rect" alt="" coords="408,41,480,65" href="useragreement.php">
<area shape="rect" alt="" coords="489,41,543,65" href="topten.php">
<area shape="rect" alt="" coords="548,41,591,65" href="faq.php">
<area shape="rect" alt="" coords="594,41,639,65" href="rss.php">
<area shape="rect" alt="" coords="644,41,704,65" href="getrss.php">
</map>
</div>
<?
  print("</tr></table>\n");
  print("</body></html>\n");
}