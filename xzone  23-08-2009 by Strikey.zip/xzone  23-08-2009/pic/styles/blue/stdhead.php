
<html><head>




<script LANGUAGE="JavaScript">

<!-- Begin
var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return "Uncheck All"; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return "Check All"; }
}
//  End -->
</script>
<script type="text/javascript" src="overlib.js"></script><script type="text/javascript">

//Specify highlight behavior. "TD" to highlight table cells, "TR" to highlight the entire row:

var highlightbehavior="TD"
var ns6=document.getElementById&&!document.all

var ie=document.all
function changeto(e,highlightcolor){

source=ie? event.srcElement : e.target

if (source.tagName=="TABLE")

return

while(source.tagName!=highlightbehavior && source.tagName!="HTML")

source=ns6? source.parentNode : source.parentElement

if (source.style.backgroundColor!=highlightcolor&&source.id!="ignore")

source.style.backgroundColor=highlightcolor

}
function contains_ns6(master, slave) { //check if slave is contained by master

while (slave.parentNode)

if ((slave = slave.parentNode) == master)

return true;

return false;

}
function changeback(e,originalcolor){

if (ie&&(event.fromElement.contains(event.toElement)||source.contains(event.toElemen

t)||source.id=="ignore")||source.tagName=="TABLE")

return

else if (ns6&&(contains_ns6(source, e.relatedTarget)||source.id=="ignore"))

return

if (ie&&event.toElement!=source||ns6&&e.relatedTarget!=source)

source.style.backgroundColor=originalcolor

}
</script>
<script LANGUAGE="JavaScript">
<!-- Begin
var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return "Uncheck All"; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return "Check All"; }
}
//  End -->
</script>
<script type="text/javascript" src="java_klappe.js"></script>

<title><?= $title ?></title>



<link rel="stylesheet" href="/<?=$ss_uri?>" type="text/css">

</head>

<script type="text/javascript" src="ncode_imageresizer.js"></script>

<script type="text/javascript">

<!--

NcodeImageResizer.MODE = 'newwindow';

NcodeImageResizer.MAXWIDTH = 480;

NcodeImageResizer.MAXHEIGHT = 0;

NcodeImageResizer.Msg1 = 'Click this bar to view the full image.';

NcodeImageResizer.Msg2 = 'This image has been resized. Click this bar to view the full image.';

NcodeImageResizer.Msg3 = 'This image has been resized. Click this bar to view the full image.';

NcodeImageResizer.Msg4 = 'Click this bar to view the small image.';

//-->

</script>

<body>


<table align=center width=950px cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>
<td class=clear width=49%>
<!--
<table border=0 cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>

<td class=clear>
<img src=/pic/star20.gif style='margin-right: 10px'>
</td>
<td class=clear>
<font color=white><b>Current funds: <?=$FUNDS?></b></font>
</td>
</tr>
</table>
-->

</td>

</body>



<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>


</tr></table>
<div align=center>
<? if ($CURUSER) { ?>
<img src=/pic/styles/blue/header.png align=center border=0 usemap=#header_Map></div>

<?  

if ($CURUSER['stylesheet'] == "4") { ?>
<center><ul class="menu2">
<li><a href="index.php"><b>Home</b></a></li>
<li><a href="browse.php"><b>Browse</b></a></li>
<li><a href="viewrequests.php"><b>Requests</b></a></li>
<li><a href="upload.php"><b>Upload</b></a></li>
<li><a href="my.php"><b>Profile</b></a></li>

<li><a href="forums.php"><b>Forum</b></a></li>
<li><a href="topten.php"><b>Top 10</b></a></li>

<li><a href="rules.php"><b>Rules</b></a></li>
<li><a href="faq.php"><b>Faq</b></a></li>

<li><a href="staff.php"><b>Staff</b></a></li>
</ul></div></center>
</td>
</tr>
<? }
}?>

<?php
$w = " align=center class='width'";
//if ($_SERVER["REMOTE_ADDR"] == $_SERVER["SERVER_ADDR"]) ;

$time = date("H");
     if(($time >= 6) && ($time < 12)){        $hi = "<font color=>Neata</font>"; }
     if(($time >= 11) && ($time < 12)){      $hi = "<font color=>Neata</font>"; }
     if(($time >= 12) && ($time < 18)){      $hi = "<font color=>Buna ziua</font>"; }
     if(($time >= 17) && ($time < 18)){      $hi = "<font color=>Buna ziua</font>"; }
     if(($time >= 18) && ($time < 24)){      $hi = "<font color=>Buna seara</font>"; }
     if(($time >= 23) && ($time < 0)){        $hi = "<font color=>Buna seara</font>"; }
     if(($time >= 0) && ($time < 6)){          $hi = "<font color=>Buna seara</font>"; }

?>
<table class=mainouter width="950px" align="center" border="0" cellspacing="0" cellpadding="0">
<!------------- MENU ------------------------------------------------------------------------>
<? $fn = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], "/") + 1); ?>
</td>
</tr>
<tr><td align=center class=outer style="padding-top: 20px; padding-bottom: 20px">

<!-- /////// some vars for the statusbar;o) //////// -->

<? if ($CURUSER) { ?>

<?

$datum = gmdate("D, M d Y H:i", time() + (($CURUSER["timezone"] + $CURUSER["dst"]) * 60));

$uped = mksize($CURUSER['uploaded']);

$downed = mksize($CURUSER['downloaded']);

if ($CURUSER["downloaded"] > 0)

{

$ratio = $CURUSER['uploaded'] / $CURUSER['downloaded'];

$ratio = number_format($ratio, 3);

$color = get_ratio_color($ratio);

if ($color)

$ratio = "<font color=$color>$ratio</font>";

}

else

if ($CURUSER["uploaded"] > 0)

$ratio = "Inf.";

else

$ratio = "---";



if ($CURUSER['donor'] == "yes")

$medaldon = "<img src=pic/star.gif alt=donor title=donor>";



if ($CURUSER['warned'] == "yes")

$warn = "<img src=pic/warned.gif alt=warned title=warned>";



//// check for messages //////////////////

$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location IN ('in', 'both')") or print(mysql_error());

$arr1 = mysql_fetch_row($res1);

$messages = $arr1[0];

$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location IN ('in', 'both') AND unread='yes'") or print(mysql_error());

$arr1 = mysql_fetch_row($res1);

$unread = $arr1[0];

$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE sender=" . $CURUSER["id"] . " AND location IN ('out', 'both')") or print(mysql_error());

$arr1 = mysql_fetch_row($res1);

$outmessages = $arr1[0];

$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " && unread='yes'") or die("OopppsY!");

$arr1 = mysql_fetch_row($res1);

$unread = $arr1[0];

if ($unread)

$inboxpic = "<img height=14px style=border:none alt=inbox title='inbox (new messages)' src=pic/pn_inboxnew.gif>";

else

$inboxpic = "<img height=14px style=border:none alt=inbox title='inbox (no new messages)' src=pic/pn_inbox.gif>";





$usrclass = "&nbsp;<b>[</b>&nbsp;".get_user_class_name($CURUSER['class'])."&nbsp;<b>]</b>&nbsp;";
//// check active torrents ///////////////////////

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='yes'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeseed = $row[0];

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='no'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeleech = $row[0];
?>
<!-- //////// start the statusbar ///////////// -->

<table align=center cellpadding="3" cellspacing="0" border="0" style="width:850px">

<tr>

<td ><table align=center style="width:850px" cellspacing="0" cellpadding="0" border="0">

<tr>
<? 
                       $T2 = array(
"SysOp" => "sysop",
"Global Staff Member" => "admin",
"Staff Member" => "mod",
"Tracker Staff" => "trackerstaff",
"VIP" => "vip",
"TopTbdev Addict" => "addict",
"User" => "user");

$class_color2 = $T2[get_user_class_name($CURUSER["class"])];
?>
<td class="bottom" align="left"><span class="smallfont"><?=$hi?>,&nbsp;<b><a href="userdetails.php?id=<?=$CURUSER['id']?>"><?=$CURUSER['username']?></a></b><?=$medaldon?><?=$warn?><?=$usrclass;?> &nbsp;| <a class="menubarhover" href="subnet.php"><font color=>Network</font></a>  | Invites: <a href=/invite.php><?=$CURUSER['invites']?></a>  |<? if (get_user_class() >= UC_MODERATOR) { ?>   <a class="menubarhover" href="staffpanel.php"><font color=lightblue>Staff Panel</font></a> <?}?> | [<a href="logout.php"><font color=red>Logout</font></a>]<br/>

<font color=lightgreen>Ratio:</font> <?=$ratio?>&nbsp;|&nbsp;<font color=green>Uploaded:</font> <font color=white><?=$uped?></font>&nbsp;|&nbsp;<font color=red>Downloaded:</font> <font color=white><?=$downed?></font>&nbsp;|&nbsp;<font color=white>Active Torrents:&nbsp;</font></span> <img alt="Torrents seeding" title="Torrents seeding" src="pic/arrowup.gif">&nbsp;<font color=CCCCCC><span class="smallfont"><?=$activeseed?></span></font>&nbsp;&nbsp;<img alt="Torrents leeching" title="Torrents leeching" src="pic/arrowdown.gif">&nbsp;<font color=CCCCCC><span class="smallfont"><?=$activeleech?>&nbsp;&nbsp;<?=$connectable?>&nbsp;&nbsp;</b></span></font></td>
<td class="bottom" align="right"><span class="smallfont"><?=$datum?>&nbsp;<br/>

<?

if ($messages){

print("<span class=smallfont><a href=inbox.php>$inboxpic</a> $messages ($unread New)</span>");

if ($outmessages)

print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages</span>");

else

print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0</span>");

}

else

{

print("<span class=smallfont><a href=inbox.php><img height=14px style=border:none alt=inbox title=inbox src=pic/pn_inbox.gif></a> 0</span>");

if ($outmessages)

print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages</span>");

else

print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0</span>");

}

print("&nbsp;<a href=friends.php><img style=border:none alt=Buddylist title=Buddylist src=pic/buddylist.gif></a>&nbsp;");

?>

</span></td>



</tr>

</table></table>

<p>

<? }?>


<?

if ($unread)
{
print("<table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style=\"padding: 10px; background-image: url(pic/back_newpm.gif)\">\n");
  print("<b><a href=$BASEURL/inbox.php><font color=white>You have $unread new message" . ($unread > 1 ? "s" : "") . "!</font></a></b>");
  print("</td></tr></table></p>\n");
}

//=== report link for big red box thanks carphunter18 :)
if (get_user_class() >= UC_MODERATOR) {
$res_reports = mysql_query("SELECT COUNT(*) FROM reports WHERE delt_with = '0'");
$arr_reports = mysql_fetch_row($res_reports);
$num_reports = $arr_reports[0];
if ($num_reports > 0)
echo"<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background: #A60A15' align=center><b>Hey $CURUSER[username]! $num_reports Report" . ($num_reports > 1 ? "s" : "") . " to be dealt with<br>click <a href=reports.php>HERE</a> to view reports</b></td></tr></table></p>\n";
}


if (get_user_class() >= UC_MODERATOR) {
$res_bugs = mysql_query("SELECT COUNT(*) FROM bugs WHERE solved = 'no'");
$num_bugs = $arr_bugs[0];
if ($num_bugs > 0)
echo "<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background:red' align=center><b><a href='/bugs.php?action=bugs'>Hey <font class=$class_color2>".$CURUSER['username']."</font>! <u>".$num_bugs."</u> Bug".($num_bugs > 1 ? "s" : "")." to be dealt with ".($num_bugs > 1 ? "them" : "it").".</a></b></td></tr></table>\n";
}

?>