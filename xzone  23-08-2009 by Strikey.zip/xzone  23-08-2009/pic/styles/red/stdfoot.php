<?
function stdfoot() {
  print("</td></tr></table></table>\n");
  ?><center><img src=../pic/styles/red/footer.jpg border=none></center>
  <center>
 
<b><pre><font face="Arial"><a href=/users.php>Users</a>  |  <a href=/rss.php>Rss</a><? if (get_user_class() >= UC_MODERATOR) {?>  |  <a href=/log.php>Log</a>  <? }?>|  <a href=/getrss.php>GetRss</a>  |  <a href=/useragreement.php>Disclaimer</a> </center></b></pre></font>

<div style="absolute" align=center>

</div>
<br>
<br />
<?
  print("</tr></table>\n");
  print("</body></html>\n");
}