-- phpMyAdmin SQL Dump
-- version 2.11.9.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 23, 2009 at 03:10 PM
-- Server version: 5.0.81
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `strikeys_forum`
--

-- --------------------------------------------------------

--
-- Table structure for table `addedrequests`
--

CREATE TABLE IF NOT EXISTS `addedrequests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `requestid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`id`),
  KEY `userid` (`userid`),
  KEY `requestid_userid` (`requestid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `addedrequests`
--


-- --------------------------------------------------------

--
-- Table structure for table `adminpanel`
--

CREATE TABLE IF NOT EXISTS `adminpanel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `url` varchar(20) default NULL,
  `info` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2012 ;

--
-- Dumping data for table `adminpanel`
--

INSERT INTO `adminpanel` (`id`, `name`, `url`, `info`) VALUES
(2002, 'Add user', 'adduser.php', 'Add user'),
(2003, 'Unconfirmed users', 'uncon.php', 'View unconfirmed accounts'),
(2004, 'Announcement', 'announcement.php', 'Create important message for all tracker users'),
(2005, 'Traceroute', 'traceroute.php', 'Trace IP'),
(2006, 'FAQ management', 'faqmanage.php', 'Manage your FAQ page'),
(2007, 'Rules  management', 'modrules.php', 'Manage your Rules page'),
(2008, 'Freeleech', 'freeleech.php', 'Freeleech'),
(2009, 'Delete user', 'delacctadmin.php', 'Delete user without confirm');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE IF NOT EXISTS `announcement` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `body` text NOT NULL,
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `announcement`
--


-- --------------------------------------------------------

--
-- Table structure for table `attachmentdownloads`
--

CREATE TABLE IF NOT EXISTS `attachmentdownloads` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `filename` varchar(255) NOT NULL default '',
  `fileid` int(10) NOT NULL default '0',
  `username` varchar(50) NOT NULL default '',
  `userid` int(10) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `downloads` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `attachmentdownloads`
--


-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `topicid` int(10) unsigned NOT NULL default '0',
  `postid` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `size` bigint(20) unsigned NOT NULL default '0',
  `owner` int(10) unsigned NOT NULL default '0',
  `downloads` int(10) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `attachments`
--


-- --------------------------------------------------------

--
-- Table structure for table `avps`
--

CREATE TABLE IF NOT EXISTS `avps` (
  `arg` varchar(20) NOT NULL default '',
  `value_s` text NOT NULL,
  `value_i` int(11) NOT NULL default '0',
  `value_u` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `avps`
--

INSERT INTO `avps` (`arg`, `value_s`, `value_i`, `value_u`) VALUES
('lastcleantime', '', 0, 1248867897),
('last24', '', 328, 1246550216);

-- --------------------------------------------------------

--
-- Table structure for table `bans`
--

CREATE TABLE IF NOT EXISTS `bans` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `addedby` int(10) unsigned NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `first` int(11) default NULL,
  `last` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `first_last` (`first`,`last`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bans`
--


-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE IF NOT EXISTS `blocks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `blockid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`blockid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blocks`
--


-- --------------------------------------------------------

--
-- Table structure for table `bonus`
--

CREATE TABLE IF NOT EXISTS `bonus` (
  `id` int(5) NOT NULL auto_increment,
  `bonusname` varchar(50) NOT NULL default '',
  `points` decimal(4,1) NOT NULL default '0.0',
  `description` text NOT NULL,
  `art` varchar(10) NOT NULL default 'traffic',
  `menge` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bonus`
--

INSERT INTO `bonus` (`id`, `bonusname`, `points`, `description`, `art`, `menge`) VALUES
(1, '1.0GB Uploaded', 75.0, 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 1073741824),
(2, '2.5GB Uploaded', 150.0, 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 2684354560),
(3, '5GB Uploaded', 250.0, 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 5368709120);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `sort_index` int(10) unsigned NOT NULL default '0',
  `cat_desc` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`, `sort_index`, `cat_desc`) VALUES
(1, 'Appz', 'apps.png', 0, ''),
(4, 'Anime/Cartoon', 'Anime.png', 0, ''),
(5, 'E Books', 'ebook.png', 0, ''),
(7, 'Games - PC', 'games.png', 0, ''),
(9, 'Games - PS2', 'ps2.png', 0, ''),
(12, 'Games - PSP', 'psp.png', 0, ''),
(17, 'Games - Xbox', 'xbox.png', 0, ''),
(19, 'Linux/Unix', 'LINUX.png', 0, ''),
(20, 'MiSC', 'misc.png', 0, ''),
(22, 'Mobile', 'mobile.png', 0, ''),
(24, 'Movies / DVD-R', 'dvd.png', 0, ''),
(25, 'Movies / DVD-RO', 'dvdro.png', 0, ''),
(26, 'Movies / HDTV', 'HDTV.png', 0, ''),
(27, 'Movies/Oldies', 'Oldies.png', 0, ''),
(28, 'Movies/XVID', 'xvid.png', 0, ''),
(29, 'Music/MP3', 'music.png', 0, ''),
(30, 'Music/VIDEO', 'mvid.png', 0, ''),
(31, 'Sport', 'sport.png', 0, ''),
(32, 'TV/Episodes', 'eps.png', 0, ''),
(33, 'SVCD', 'svcd.png', 0, ''),
(34, 'XxX', 'xxx.png', 0, ''),
(38, 'Movies/XVID-RO', 'XVIDRO.PNG', 0, ''),
(40, 'Images', 'images.png', 0, ''),
(41, 'Wii', 'wii.png', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `cheaters`
--

CREATE TABLE IF NOT EXISTS `cheaters` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `userid` int(10) NOT NULL default '0',
  `torrentid` int(10) NOT NULL default '0',
  `client` varchar(255) NOT NULL default '',
  `rate` varchar(255) NOT NULL default '',
  `beforeup` varchar(255) NOT NULL default '',
  `upthis` varchar(255) NOT NULL default '',
  `timediff` varchar(255) NOT NULL default '',
  `userip` varchar(15) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cheaters`
--


-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `torrent` int(10) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `ori_text` text NOT NULL,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  `request` int(11) NOT NULL default '0',
  `offer` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user` (`user`),
  KEY `torrent` (`torrent`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `flagpic` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=200 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `flagpic`) VALUES
(1, 'Sweden', 'sweden.gif'),
(2, 'United States of America', 'usa.gif'),
(3, 'Russia', 'russia.gif'),
(4, 'Finland', 'finland.gif'),
(5, 'Canada', 'canada.gif'),
(6, 'France', 'france.gif'),
(7, 'Germany', 'germany.gif'),
(8, 'China', 'china.gif'),
(9, 'Italy', 'italy.gif'),
(10, 'Denmark', 'denmark.gif'),
(11, 'Norway', 'norway.gif'),
(12, 'United Kingdom', 'uk.gif'),
(13, 'Ireland', 'ireland.gif'),
(14, 'Poland', 'poland.gif'),
(15, 'Netherlands', 'netherlands.gif'),
(16, 'Belgium', 'belgium.gif'),
(17, 'Japan', 'japan.gif'),
(18, 'Brazil', 'brazil.gif'),
(19, 'Argentina', 'argentina.gif'),
(20, 'Australia', 'australia.gif'),
(21, 'New Zealand', 'newzealand.gif'),
(23, 'Spain', 'spain.gif'),
(24, 'Portugal', 'portugal.gif'),
(25, 'Mexico', 'mexico.gif'),
(26, 'Singapore', 'singapore.gif'),
(27, 'India', 'india.gif'),
(28, 'Albania', 'albania.gif'),
(29, 'South Africa', 'southafrica.gif'),
(30, 'South Korea', 'southkorea.gif'),
(31, 'Jamaica', 'jamaica.gif'),
(32, 'Luxembourg', 'luxembourg.gif'),
(33, 'Hong Kong', 'hongkong.gif'),
(34, 'Belize', 'belize.gif'),
(35, 'Algeria', 'algeria.gif'),
(36, 'Angola', 'angola.gif'),
(37, 'Austria', 'austria.gif'),
(38, 'Yugoslavia', 'yugoslavia.gif'),
(39, 'Western Samoa', 'westernsamoa.gif'),
(40, 'Malaysia', 'malaysia.gif'),
(41, 'Dominican Republic', 'dominicanrep.gif'),
(42, 'Greece', 'greece.gif'),
(43, 'Guatemala', 'guatemala.gif'),
(44, 'Israel', 'israel.gif'),
(45, 'Pakistan', 'pakistan.gif'),
(46, 'Czech Republic', 'czechrep.gif'),
(47, 'Serbia', 'serbia.gif'),
(48, 'Seychelles', 'seychelles.gif'),
(49, 'Taiwan', 'taiwan.gif'),
(50, 'Puerto Rico', 'puertorico.gif'),
(51, 'Chile', 'chile.gif'),
(52, 'Cuba', 'cuba.gif'),
(53, 'Congo', 'congo.gif'),
(54, 'Afghanistan', 'afghanistan.gif'),
(55, 'Turkey', 'turkey.gif'),
(56, 'Uzbekistan', 'uzbekistan.gif'),
(57, 'Switzerland', 'switzerland.gif'),
(58, 'Kiribati', 'kiribati.gif'),
(59, 'Philippines', 'philippines.gif'),
(60, 'Burkina Faso', 'burkinafaso.gif'),
(61, 'Nigeria', 'nigeria.gif'),
(62, 'Iceland', 'iceland.gif'),
(63, 'Nauru', 'nauru.gif'),
(64, 'Slovenia', 'slovenia.gif'),
(66, 'Turkmenistan', 'turkmenistan.gif'),
(67, 'Bosnia Herzegovina', 'bosniaherzegovina.gif'),
(68, 'Andorra', 'andorra.gif'),
(69, 'Lithuania', 'lithuania.gif'),
(70, 'Macedonia', 'macadonia.gif'),
(71, 'Netherlands Antilles', 'nethantilles.gif'),
(72, 'Ukraine', 'ukraine.gif'),
(73, 'Venezuela', 'venezuela.gif'),
(74, 'Hungary', 'hungary.gif'),
(75, 'Romania', 'romania.gif'),
(76, 'Vanuatu', 'vanuatu.gif'),
(77, 'Vietnam', 'vietnam.gif'),
(78, 'Trinidad & Tobago', 'trinidadandtobago.gif'),
(79, 'Honduras', 'honduras.gif'),
(80, 'Kyrgyzstan', 'kyrgyzstan.gif'),
(81, 'Ecuador', 'ecuador.gif'),
(82, 'Bahamas', 'bahamas.gif'),
(83, 'Peru', 'peru.gif'),
(84, 'Cambodia', 'cambodia.gif'),
(85, 'Barbados', 'barbados.gif'),
(86, 'Bangladesh', 'bangladesh.gif'),
(87, 'Laos', 'laos.gif'),
(88, 'Uruguay', 'uruguay.gif'),
(89, 'Antigua Barbuda', 'antiguabarbuda.gif'),
(90, 'Paraguay', 'paraguay.gif'),
(92, 'Union of Soviet Socialist Republics', 'ussr.gif'),
(93, 'Thailand', 'thailand.gif'),
(94, 'Senegal', 'senegal.gif'),
(95, 'Togo', 'togo.gif'),
(96, 'North Korea', 'northkorea.gif'),
(97, 'Croatia', 'croatia.gif'),
(98, 'Estonia', 'estonia.gif'),
(99, 'Colombia', 'colombia.gif'),
(100, 'Lebanon', 'lebanon.gif'),
(101, 'Latvia', 'latvia.gif'),
(102, 'Costa Rica', 'costarica.gif'),
(103, 'Egypt', 'egypt.gif'),
(104, 'Bulgaria', 'bulgaria.gif'),
(105, 'Isla de Muerte', 'jollyroger.gif'),
(106, 'Moldova', 'moldova.gif'),
(107, 'Armenia', 'armenia.gif'),
(108, 'Azerbaijan', 'azerbaijan.gif'),
(109, 'Bahrain', 'bahrain.gif'),
(110, 'Belarus', 'belarus.gif'),
(111, 'Benin', 'benin.gif'),
(112, 'Bhutan', 'bhutan.gif'),
(113, 'Bolivia', 'bolivia.gif'),
(114, 'Botswana', 'botswana.gif'),
(115, 'Brunei', 'brunei.gif'),
(116, 'Union of Myanmar', 'burma.gif'),
(117, 'Burundi', 'burund.gif'),
(118, 'Cameroon', 'cameroon.gif'),
(119, 'Central African Republic', 'centralafricanrep.gif'),
(120, 'Chad', 'chad.gif'),
(121, 'Comoros', 'comoros.gif'),
(122, 'Cyprus', 'cyprus.gif'),
(123, 'Democratic Republic of the Congo', 'demrepcongo.gif'),
(124, 'Djibouti', 'djiboutil.gif'),
(125, 'Dominica', 'dominica.gif'),
(126, 'El Salvador', 'elsalvado.gif'),
(127, 'Equatorial Guinea', 'eq_guinea.gif'),
(128, 'Eritrea', 'eritrea.gif'),
(129, 'Ethiopia', 'ethiopia.gif'),
(130, 'Fiji', 'fiji.gif'),
(131, 'Gabon', 'gabon.gif'),
(132, 'Gambia', 'gambia.gif'),
(133, 'Georgia', 'georgia.gif'),
(134, 'Ghana', 'ghana.gif'),
(135, 'Grenada', 'grenada.gif'),
(136, 'St. Vincent & the Grenadines', 'grenadines.gif'),
(137, 'Guinea-Bissau', 'guineabissau.gif'),
(138, 'Guinea', 'guineal.gif'),
(139, 'Guyana', 'guyana.gif'),
(140, 'Haiti', 'haiti.gif'),
(141, 'Hong Kong', 'hong_kong.gif'),
(142, 'Indonesia', 'indonesia.gif'),
(143, 'Iran', 'iran.gif'),
(144, 'Iraq', 'iraq.gif'),
(145, 'Ivory Coast', 'ivorycoast.gif'),
(146, 'Jordan', 'jordan.gif'),
(147, 'Kazakhstan', 'kazakhstan.gif'),
(148, 'Kenya', 'kenya.gif'),
(149, 'Kuwait', 'kuwait.gif'),
(150, 'Liberia', 'liberia.gif'),
(151, 'Libya', 'libya.gif'),
(152, 'Liechtenstein', 'liechtenstein.gif'),
(153, 'Macao', 'macau.gif'),
(154, 'Madagascar', 'madagascar.gif'),
(155, 'Malawi', 'malawi.gif'),
(156, 'Maldives', 'maldives.gif'),
(157, 'Mali', 'mali.gif'),
(158, 'Malta', 'malta.gif'),
(159, 'Mauritania', 'mauritania.gif'),
(160, 'Mauritius', 'mauritius.gif'),
(161, 'Micronesia', 'micronesia.gif'),
(162, 'Monaco', 'monaco.gif'),
(163, 'Mongolia', 'mongolia.gif'),
(164, 'Morocco', 'morocco.gif'),
(165, 'Mozambique', 'mozambique.gif'),
(166, 'Namibia', 'namibia.gif'),
(167, 'Nepal', 'nepal.gif'),
(168, 'Nicaragua', 'nicaragua.gif'),
(169, 'Niger', 'niger.gif'),
(170, 'North Korea', 'north_korea.gif'),
(171, 'Oman', 'oman.gif'),
(172, 'Panama', 'panama.gif'),
(173, 'Papua New Guinea', 'papuanewguinea.gif'),
(174, 'Qatar', 'qatar.gif'),
(175, 'Rwanda', 'rawanda.gif'),
(176, 'Sao Tome and Principe', 'sao_tome.gif'),
(177, 'Saudi Arabia', 'saudiarabia.gif'),
(178, 'Sierra Leone', 'sierraleone.gif'),
(179, 'Slovakia', 'slovakia.gif'),
(180, 'Solomon Islands', 'solomon_islands.gif'),
(181, 'Somalia', 'somalia.gif'),
(182, 'South Korea', 'south_korea.gif'),
(183, 'Sri Lanka', 'srilanka.gif'),
(184, 'St. Kitts & Nevis', 'stkitts_nevis.gif'),
(185, 'Saint Lucia', 'stlucia.gif'),
(186, 'Sudan', 'sudan.gif'),
(187, 'Suriname', 'suriname.gif'),
(188, 'Syria', 'syria.gif'),
(189, 'Tajikistan', 'tajikistan.gif'),
(190, 'Tanzania', 'tanzania.gif'),
(191, 'Tonga', 'tonga.gif'),
(192, 'Tunisia', 'tunisia.gif'),
(193, 'Tuvalu', 'tuvala.gif'),
(194, 'United Arab Emirates', 'uae.gif'),
(195, 'Uganda', 'uganda.gif'),
(196, 'Yemen', 'yemen.gif'),
(197, 'Zaire', 'zaire.gif'),
(198, 'Zambia', 'zambia.gif'),
(199, 'Zimbabwe', 'zimbabwe.gif');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `id` int(10) NOT NULL auto_increment,
  `type` set('categ','item') NOT NULL default 'item',
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `flag` set('0','1','2','3') NOT NULL default '1',
  `categ` int(10) NOT NULL default '0',
  `order` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES
(1, 'categ', 'Site information', '', '1', 0, 1),
(2, 'categ', 'User information', '', '1', 0, 2),
(3, 'categ', 'Stats', '', '1', 0, 3),
(4, 'categ', 'Uploading', '', '1', 0, 4),
(5, 'categ', 'Downloading', '', '1', 0, 5),
(6, 'categ', 'How can I improve my download speed?', '', '1', 0, 6),
(7, 'categ', 'My ISP uses a transparent proxy. What should I do?', '', '1', 0, 7),
(8, 'categ', 'Why can''t I connect? Is the site blocking me?', '', '1', 0, 8),
(9, 'categ', 'What if I can''t find the answer to my problem here?', '', '1', 0, 9),
(10, 'item', 'Totusi, ce este acest BitTorrent? Cum obtin fisierele?', 'Vizitati <a class=altlink href="http://www.btfaq.com/">Brian''s BitTorrent FAQ and Guide</a>', '1', 1, 1),
(11, 'item', 'Se pot face donatii? ', 'Deocamdata NU!\r\n', '1', 1, 2),
(12, 'item', ' De unde pot obtine o copie a codului sursa folosit de acest sait? ', 'Codul pe care se bazeaza cel folosit de noi il gasiti la <a class=altlink href="http://www.tbdev.net//">TBdev.net</a>\r\nVersiunea pe care o folosim este modificata dupa nevoile noastre si nu este disponibila public.\r\n', '1', 1, 3),
(13, 'item', 'Mi-am inregistrat un cont dar nu am primit e-mail de confirmare!', 'Asteptati pana va ajunge mailul si verificati in Bulk/Spam.', '1', 2, 1),
(14, 'item', 'Nu imi amintesc parola! Cum o pot afla?', 'Va rugam sa folositi  <a class=altlink href=recover.php>acest formular </a> pentru a primi un e-mail cu datele necesare autentificarii. Daca folositi GMail sau Yahoo este posibil ca mesajul sa ajunga in Spam/Bulk. Daca folositi Hotmail este posibil ca mesajul sa nu ajunga.\r\n', '1', 2, 2),
(15, 'item', 'Imi poti redenumi contul?', 'Conturile nu se pot redenumi. ', '1', 2, 3),
(16, 'item', 'Imi puteti sterge contul (confirmat)? ', 'Va rugam sa folositi <a href=delacct.php class=altlink>acest formular</a> pentru a va sterge contul.\r\n.', '1', 2, 4),
(17, 'item', 'Deci, ce este Ratioul meu? ', 'Alegeti optiunea <a class=altlink href=my.php>PROFILE</a>, din meniu si apoi pe numele dumneavoastra (in centrul paginii).\r\n\r\nValoarea din rubrica Share ratio reprezinta raportul dintre cantitatea de date uploadata si cea downloadata. Ratio este o masura a disponibilitatii dumneavoastra de a da inapoi comunitatii ceea ce v-a fost oferit si in consecinta trebuie sa fie apropiat de 1 sau supraunitar.\r\nEste important sa faceti deosebire intre ratioul total si ratioul fiecarui torrent pe care il seeduiti sau leechuiti. Ratioul total tine cont de totalul uploadului si al downloadului, din momentul in care v-ati inscris pe acest sit. Ratioul individual tine cont de valorile fiecarui torrent.\r\n<br>\r\n<br>Este posibil sa intalniti doua simboluri in locul numerelor:\r\n<br>\r\n<br>\r\n1. "Inf." este de fapt o prescurtare a cuvantului Infinit, ceea ce inseamna ca ati downloadat 0 Bytes si ati uploadat o valoare diferita de 0 ( Upload / Download = Inf. )\r\n<br>\r\n<br>\r\n2."---", care de fapt se traduce prin "Nu Este Disponibil" si apare atunci cand atat suma totala de upload si cea de download este 0 Bytes (Upload / Download = 0/0 - valoare nedeterminata). ', '1', 2, 5),
(18, 'item', 'De ce este IP-ul meu afisat pe pagina cu detalii personale? ', 'Doar dumneavoastra si moderatorii acestui sit pot vedea IP-ul sau adresa de e-mail. Utilizatorii obisnuiti nu vad aceste informatii. ', '1', 2, 6),
(19, 'item', 'Ajutor! Nu ma pot autentifica!? (Login of Death) ', 'Aceasta problema apare uneori cu o anumita versiune a MS Internet Explorer [IE]. Va rugam sa inchideti toate ferestrele IE, sa deschideti Internet Options din Control Panel si sa apasati pe butonul intitulat "Delete Cookies". Din acest moment ar trebui sa reusiti sa va autentificati.\r\n', '1', 2, 7),
(20, 'item', 'IP-ul meu este dinamic. Ce trebuie sa fac pentru a ramane autentificat? ', 'Tot ce trebuie sa faci este sa te asiguri ca esti autentificat cu IP-ul corect cand pornesti un torrent. Din acel moment, chiar daca IP-ul se schimba in timpul sesiunii, informatiile despre seed sau leech vor fi trimise corect si statistica va fi actualizata fara probleme. ', '1', 2, 8),
(21, 'item', 'De ce sunt afisat ca neconectabil si de ce ar trebui sa imi pese? ', 'Sistemul de pe acest sait a determinat ca sunteti in spatele unui firewall si nu puteti accepta conexiuni catre dumneavoastra.\r\n<br>\r\n<br>\r\nUtilizatorii nu se vor putea conecta la dumneavoastra, ci numai dumneavoastra la ei. Mai rau, daca sunt doi utilizatori in aceasta situatie, nu se vor putea conecta unul la altul.\r\n<br>\r\n<br>\r\nAceasta problema se poate rezolva prin deschiderea portului prin care sa acceptati conexiuni (acelasi pe care l-ati setat in clientul dumneavoastra) din firewall si/sau configurarea serverului de NAT pentru a folosi o forma simpla de NAT pentru acel port in loc de NAPT (procedura depinde de la router la router. Mai multe despre acest subiect pe saitul <a class=altlink href="http://portforward.com/">PortForward</a>)', '1', 2, 9),
(22, 'item', 'Ce sunt clasele utilizatorilor? ', '<table cellspacing=3 cellpadding=0>\r\n<tr>\r\n<td class=embedded width=100 bgcolor="#F5F4EA">&nbsp; <b>User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Clasa standard a membrilor noi.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b>Power User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Poate accesa fisiere NFO.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><img src="pic/star.gif" alt="Star"></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>A ajutat saitul  xzone.hi2.ro. </td>\r\n</tr>\r\n<tr>\r\n<td class=embedded valign=top bgcolor="#F5F4EA">&nbsp; <b>VIP</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Aceleasi privilegii ca si un Power User dar este considerat membru de elita al xzone.hi2.ro, este imun la scaderea automata a clasei.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b>Other</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Custom Title.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#4040c0">Uploader</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Ales in urma unei cereri de uploader pe o perioada determinata de timp in vederea testarii abilitatilor.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded valign=top bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">Moderator</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Poate edita sau sterge orice torrent uploadat. Poate modera comentariile utilizatorilor.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">Administrator</color></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Poate sa faca aproape orice, raspunde doar in fata unui SysOp.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">SysOp</color></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Administratorii sitului.</td>\r\n</tr>\r\n</table>', '1', 2, 10),
(23, 'item', 'Cum promovez? ', '<table cellspacing=3 cellpadding=0>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA" valign=top width=100>&nbsp; <b>Power User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Trebuie sa fiti membru de cel putin 4 saptamani, sa aveti uploadat cel putin 25GB si un ratio de cel putin 1.05.\r\nPromovarea este automata in momentul in care indepliniti aceste conditii. Veti fi automat coborat la clasa User in momentul in care ratio scade sub 0.95.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><img src="pic/star.gif" alt="Star"></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Atribuit persoanelor care au contribuit la dezvoltarea xzone.hi2.ro.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA" valign=top>&nbsp; <b>VIP</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Atribuit de administratori la discretia lor persoanelor care contribuie sau ajuta in mod special la buna functionare si dezvoltare a acestui sait.\r\n(Orice persoara care cere insistent statutul de VIP va fi automat descalificata)</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b>Other</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Atribuit de administratori la discretia lor ( in afara de clasele User si Power User).</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#4040c0">Uploader</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Ales in urma a unei cereri de uploader pe o perioada determinata de timp in vederea testarii abilitatilor (vedeti sectiunea Despre Upload pentru conditiile ce trebuiesc indeplinite pt a deveni Uploader).</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">Moderator</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Va rugam sa nu cereti acest status, moderatorii sunt alesi de catre administratorii acestui sait.</td>\r\n</tr>\r\n</table>', '1', 2, 11),
(25, 'item', 'De ce prietenul meu nu poate deveni membru al acestui sait?', 'Exista o limita a numarului de conturi. Daca aceasta este atinsa nu se mai admit inscrieri. Conturile inactive pentru mult timp sunt sterse automat si atunci prietenul tau se va putea inscrie. Nu exista un sistem de rezervare sau coada de asteptare, va rugam sa nu ne intrebati despre asa ceva.\r\n', '1', 2, 13),
(26, 'item', 'Cum adaug un avatar la profilul meu?', '\r\nIntai, gasiti o imagine care va place, si care se incadreaza in reguli. Apoi trebuie sa gasiti un loc unde sa o uploadati, cum ar fi http://imagehosting.ro/ sau http://imageshack.us). Tot ce ramane este sa copiati URL-ul imaginii uploadate in campul pentru avatar din profilul dvs.\r\n', '1', 2, 14),
(27, 'item', 'Cele mai cunoscute motive pentru care statisticile nu apar in timp real ', '<ul>\r\n<li>Utilizatorul triseaza.</li>\r\n<li>Serverul este aglomerat si face cu greu fata cerintelor. Incercati sa tineti sesiunea deschisa pana cand serverul raspunde. (Aglomerarea serverului cu updatari manuale consecutive nu este recomandata.)</li>\r\n<li>Folositi un client cu erori. Daca folositi un client experimental sau o versiune CVS o faceti pe propriul risc.</li>\r\n</ul>', '1', 3, 1),
(28, 'item', 'Cum se repara ', '<ul>\r\n<li>Daca un torrent pe care il leechuiti/seeduiti nu este listat in profilul dumneavoastra asteptati sau incercati updatarea manuala.</li>\r\n<li>Asigurati-va ca inchideti corect clientul, astfel incat trackerul sa primeasca mesajul "event=completed".</li>\r\n<li>Daca trackerul este picat nu va opriti din seeding. Cand trackerul isi va reveni clientul dumneavoastra va transmite statisticile corecte.</li>\r\n</ul>', '1', 3, 2),
(29, 'item', ' Pot utiliza orice client BitTorrent? ', 'Da. Tracker actualizeaza corect statisticile pentru toti clientii de bittorent. Totusi, recomandam sa ocoliti urmatorii clienti:<br>\r\n<br>\r\n? BitTorrent++,<br>\r\n? Nova Torrent,<br>\r\n? TorrentStorm.<br>\r\n<br>\r\nAcesti clienti nu raporteaza corect trackerului cand sesiunea de torent este anulata/terminata. Daca ii folositi atunci cativa MB s-ar putea sa nu fie numarati in statistici la sfarsit, si torentele ar putea sa fie inca listate la profilul dvs pentru un timp dupa ce ati inchis clientul.\r\n<br>\r\n<br>\r\nDe asemenea, clientii in versiune alfa si beta ar trebui evitati.', '1', 3, 3),
(30, 'item', 'De ce este listat de mai multe ori in profilul meu torrentul pe care il seeduiesc/leechuiesc? ', '\r\nDaca dintr-un motiv sau altul PC-ul cedeaza sau clientul P2P ingheata, raportarea catre tracker se va face eronat indicand faptul ca torrentul continua sa fie la seed/leech. Cel vechi nu va primi niciodata un mesaj "event=completed" sau "event=stop" si va fi listat pana la expirarea timpului de urmarire. Ignora-l, pentru ca va disparea intr-un final.', '1', 3, 4),
(31, 'item', 'Am finalizat sau anulat un torrent. De ce este inca listat in profilul meu? ', 'Unii clienti, mai ales TorrentStorm si Nova Torrent, nu raporteaza in mod corect trackerului cand anuleaza sau finalizeaza un torrent. In acel caz trackerul va astepta acest mesaj si astfel va lista torrentul ca in proces de seed/leech pana ce va trece un timp stabilit. Ignora-l, pentru ca va disparea intr-un final. ', '1', 3, 5),
(32, 'item', 'De ce vad uneori torrente pe care nu le leechuiesc in profilul meu!? ', '\r\nExista doua posibilitati in care in profilul tau vor aparea torrente pe care nu ii leechuiesti: cineva iti cunoaste parola si/sau passkeyul. Pentru a rezolva aceasta problema trebuie sa-ti schimbi parola si/sau sa dai un reset passkey. A se observa ca torrentele listate in profilul tau vor aparea intotdeauna in statisticile tale finale. In cazul resetarii passkeyului este necesar sa redownloadati toate fisierele .torrent luate de pe acest tracker si sa folositi optiunea \\"Resume\\" (sau cea similara) din clientul folosit de dumneavoastra.\r\n', '2', 3, 6),
(33, 'item', 'IP-uri multiple (Ma pot loga de pe calculatoare diferite?) ', 'Da, trackerul poate urmari sesiuni de la diferite IP-uri ale aceluiasi utilizator. Un torrent este asociat cu utilizatorul cand porneste si doar in acel moment IP-ul este relevant. Daca vrei sa faci seed/leech de la computerul A si computerul B cu acelasi cont va trebui sa accesezi situl de la computerul A, sa pornesti torrentul acolo, apoi sa repeti pasii la computerul B (nu exista limita de genul doua computere sau un torrent la fiecare computer, acesta este doar cel mai simplu exemplu). Nu este nevoie sa te loghezi din nou cand inchizi clientul BitTorrent. ', '2', 3, 7),
(34, 'item', 'Cum schimba NAT/ICS imaginea?', 'Acesta este un caz particular in care toate computerele din LAN apar lumii din exterior ca avand acelasi IP. Trebuie facuta diferenta intre doua cazuri:<br>\r\n<br>\r\n<b>1.</b> <i>1. Sunteti singurul utilizator Xzone din LAN</i><br>\r\n<br>\r\nDaca dispuneti de un IP routabil si folositi un router pentru NAT/ICS ar trebui utilizat acelasi cont Xzone la toate computerele. Nu aveti nevoie de cate un cont pentru fiecare computer/membru al familiei.<br>\r\n<br>\r\n<b>2.</b> <i>2. Exista mai multi utilizatori Xzone in LAN</i><br>\r\n<br>\r\nIntrucat fiecare utilizator este asociat cu un passkey unic statisticile se actualizeaza corect pentru fiecare in parte.\r\n<br>\r\n<br>\r\nIn ambele cazuri este recomandat sa incercati sa configurati un port forwarding sau sa rugati administratorul sa configureze routerul in asa fel incat pe un port sa se faca forwarding spre IP-ul dumneavoastra. Daca dispuneti de propriul router pe care il folositi pentru NAT/ICS cititi sectiunea De ce sunt afisat ca neconectabil si de ce ar trebui sa imi pese? si documentatia aferenta routerului. Pentru a configura serviciul ICS din sistemele de operare Windows citi aici: http://www.microsoft.com/downloads/details.aspx?FamilyID=1dcff3ce-f50f-4a34-ae67-cac31ccd7bc9&displaylang=e', '1', 3, 8),
(36, 'item', 'De ce nu pot sa fac upload la fisiere torrent? ', 'Pentru a asigura o calitate ridicata a materialelor puse pe tracker, doar persoanele autorizate (<font color="#4040c0"><b>Uploaders</b></font>) u dreptul de a face upload la fisiere torrent pe acest site. ', '1', 4, 1),
(37, 'item', 'Ce trebuie sa indeplinesc pentru a deveni <font color="#4040c0">Uploader</font> ?', 'Citeste <a class=altlink href="http://xzone.hi2.ro/forums.php?action=viewtopic&topicid=33">AICI</a>!', '1', 4, 2),
(38, 'item', 'Pot uploada fisierele torrent de pe acest site pe alte siteuri? ', 'Nu. Faceti parte din o comunitate inchisa, cu un numar limitat de membrii. Doar utilizatorii inregistrati pot folosi acest sit. Publicarea fisierelor torrent de pe acest sit pe alte situri este inutila deoarece majoritatea persoanelor care vor incerca sa downloadeze continutul nu vor reusi. In acest fel se creeaza o mare frustrare si rea-vointa fata de Xzone si, prin urmare, nu va fi tolerata.\r\n<br>\r\n<br>\r\nPlangerile referitoare la fisiere torrent primite de la administratorii altor siteuri vor avea ca rezultat blocarea accesului persoanei respective pe acest site.', '3', 4, 3),
(39, 'item', 'How do I use the files I''ve downloaded?', 'Check out <a class=altlink href=videoformats.php>this guide</a>.', '1', 5, 1),
(40, 'item', 'Downloaded a movie and don''t know what CAM/TS/TC/SCR means?', 'Check out <a class=altlink href=videoformats.php>this guide.', '1', 5, 2),
(41, 'item', 'Why did an active torrent suddenly disappear?', 'There may be three reasons for this:<br>\r\n(<b>1</b>) The torrent may have been out-of-sync with the site\r\n<a class=altlink href=rules.php>rules</a>.<br>\r\n(<b>2</b>) The uploader may have deleted it because it was a bad release.\r\nA replacement will probably be uploaded to take its place.<br>\r\n(<b>3</b>) Torrents are automatically deleted after 28 days.', '2', 5, 3),
(42, 'item', 'How do I resume a broken download or reseed something?', 'Open the .torrent file. When your client asks you for a location, choose the location of the existing file(s) and it will resume/reseed the torrent.\r\n', '1', 5, 4),
(43, 'item', 'Why do my downloads sometimes stall at 99%?', 'The more pieces you have, the harder it becomes to find peers who have pieces you are missing. That is why downloads sometimes slow down or even stall when there are just a few percent remaining. Just be patient and you will, sooner or later, get the remaining pieces.\r\n', '1', 5, 5),
(44, 'item', 'What are these "a piece has failed an hash check" messages?', 'Bittorrent clients check the data they receive for integrity. When a piece fails this check it is\r\nautomatically re-downloaded. Occasional hash fails are a common occurrence, and you shouldn''t worry.<br>\r\n<br>\r\nSome clients have an (advanced) option/preference to ''kick/ban clients that send you bad data'' or\r\nsimilar. It should be turned on, since it makes sure that if a peer repeatedly sends you pieces that\r\nfail the hash check it will be ignored in the future.', '1', 5, 6),
(45, 'item', 'The torrent is supposed to be 100MB. How come I downloaded 120MB?', 'See the hash fails topic. If your client receives bad data it will have to redownload it, therefore\r\nthe total downloaded may be larger than the torrent size. Make sure the &quot;kick/ban&quot; option is turned on\r\nto minimize the extra downloads.', '1', 5, 7),
(46, 'item', 'Why do I get a "Not authorized (xx h) - READ THE FAQ" error?', 'From the time that each <b>new</b> torrent is uploaded to the tracker, there is a period of time that\r\nsome users must wait before they can download it.<br>\r\nThis delay in downloading will only affect users with a low ratio, and users with low upload amounts.<br>\r\n<br>\r\n<table cellspacing=3 cellpadding=0>\r\n <tr>\r\n	<td class=embedded width="70">Ratio below</td>\r\n	<td class=embedded width="40" bgcolor="#F5F4EA"><font color="#BB0000"><div align="center">0.50</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded width="110">and/or upload below</td>\r\n	<td class=embedded width="40" bgcolor="#F5F4EA"><div align="center">5.0GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded width="50">delay of</td>\r\n	<td class=embedded width="40" bgcolor="#F5F4EA"><div align="center">48h</div></td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded>Ratio below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><font color="#A10000"><div align="center">0.65</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>and/or upload below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">6.5GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>delay of</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">24h</div></td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded>Ratio below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><font color="#880000"><div align="center">0.80</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>and/or upload below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">8.0GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>delay of</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">12h</div></td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded>Ratio below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><font color="#6E0000"><div align="center">0.95</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>and/or upload below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">9.5GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>delay of</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">06h</div></td>\r\n </tr>\r\n</table>\r\n<br>\r\n"<b>And/or</b>" means any or both. Your delay will be the <b>largest</b> one for which you meet <b>at least</b> one condition.<br>\r\n<br>\r\nThis applies to new users as well, so opening a new account will not help. Note also that this\r\nworks at tracker level, you will be able to grab the .torrent file itself at any time.<br>\r\n<br>\r\n<!--The delay applies only to leeching, not to seeding. If you got the files from any other source and\r\nwish to seed them you may do so at any time irrespectively of your ratio or total uploaded.<br>-->\r\nN.B. Due to some users exploiting the ''no-delay-for-seeders'' policy we had to change it. The delay\r\nnow applies to both seeding and leeching. So if you are subject to a delay and get the files from\r\nsome other source you will not be able to seed them until the delay has elapsed.', '3', 5, 8),
(47, 'item', 'Why do I get a "rejected by tracker - Port xxxx is blacklisted" error?', 'Your client is reporting to the tracker that it uses one of the default bittorrent ports\r\n(6881-6889) or any other common p2p port for incoming connections.<br>\r\n<br>\r\nTorrentBits does not allow clients to use ports commonly associated with p2p protocols.\r\nThe reason for this is that it is a common practice for ISPs to throttle those ports\r\n(that is, limit the bandwidth, hence the speed). <br>\r\n<br>\r\nThe blocked ports list include, but is not neccessarily limited to, the following:<br>\r\n<br>\r\n<table cellspacing=3 cellpadding=0>\r\n  <tr>\r\n	<td class=embedded width="80">Direct Connect</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">411 - 413</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">Kazaa</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">1214</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">eDonkey</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">4662</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">Gnutella</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">6346 - 6347</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">BitTorrent</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">6881 - 6889</div></td>\r\n </tr>\r\n</table>\r\n<br>\r\nIn order to use use our tracker you must  configure your client to use\r\nany port range that does not contain those ports (a range within the region 49152 through 65535 is preferable,\r\ncf. <a class=altlink href="http://www.iana.org/assignments/port-numbers">IANA</a>). Notice that some clients,\r\nlike Azureus 2.0.7.0 or higher, use a single port for all torrents, while most others use one port per open torrent. The size\r\nof the range you choose should take this into account (typically less than 10 ports wide. There\r\nis no benefit whatsoever in choosing a wide range, and there are possible security implications). <br>\r\n<br>\r\nThese ports are used for connections between peers, not client to tracker.\r\nTherefore this change will not interfere with your ability to use other trackers (in fact it\r\nshould <i>increase</i> your speed with torrents from any tracker, not just ours). Your client\r\nwill also still be able to connect to peers that are using the standard ports.\r\nIf your client does not allow custom ports to be used, you will have to switch to one that does.<br>\r\n<br>\r\nDo not ask us, or in the forums, which ports you should choose. The more random the choice is the harder\r\nit will be for ISPs to catch on to us and start limiting speeds on the ports we use.\r\nIf we simply define another range ISPs will start throttling that range also. <br>\r\n<br>\r\nFinally, remember to forward the chosen ports in your router and/or open them in your\r\nfirewall, should you have them.', '3', 5, 9),
(48, 'item', 'What''s this "IOError - [Errno13] Permission denied" error?', 'If you just want to fix it reboot your computer, it should solve the problem.\r\nOtherwise read on.<br>\r\n<br>\r\nIOError means Input-Output Error, and that is a file system error, not a tracker one.\r\nIt shows up when your client is for some reason unable to open the partially downloaded\r\ntorrent files. The most common cause is two instances of the client to be running\r\nsimultaneously:\r\nthe last time the client was closed it somehow didn''t really close but kept running in the\r\nbackground, and is therefore still\r\nlocking the files, making it impossible for the new instance to open them.<br>\r\n<br>\r\nA more uncommon occurrence is a corrupted FAT. A crash may result in corruption\r\nthat makes the partially downloaded files unreadable, and the error ensues. Running\r\nscandisk should solve the problem. (Note that this may happen only if you''re running\r\nWindows 9x - which only support FAT - or NT/2000/XP with FAT formatted hard drives.\r\nNTFS is much more robust and should never permit this problem.)', '3', 5, 10),
(49, 'item', 'What''s this "TTL" in the browse page?', 'The torrent''s Time To Live, in hours. It means the torrent will be deleted\r\nfrom the tracker after that many hours have elapsed (yes, even if it is still active).\r\nNote that this a maximum value, the torrent may be deleted at any time if it''s inactive.', '3', 5, 11),
(50, 'item', 'Do not immediately jump on new torrents', 'The download speed mostly depends on the seeder-to-leecher ratio (SLR). Poor download speed is\r\nmainly a problem with new and very popular torrents where the SLR is low.<br>\r\n<br>\r\n(Proselytising sidenote: make sure you remember that you did not enjoy the low speed.\r\n<b>Seed</b> so that others will not endure the same.)<br>\r\n<br>\r\nThere are a couple of things that you can try on your end to improve your speed:<br>\r\n<br>In particular, do not do it if you have a slow connection. The best speeds will be found around the\r\nhalf-life of a torrent, when the SLR will be at its highest. (The downside is that you will not be able to seed\r\nso much. It''s up to you to balance the pros and cons of this.)', '1', 6, 1),
(51, 'item', 'Limit your upload speed', 'The upload speed affects the download speed in essentially two ways:<br>\r\n<ul>\r\n    <li>Bittorrent peers tend to favour those other peers that upload to them. This means that if A and B\r\n	are leeching the same torrent and A is sending data to B at high speed then B will try to reciprocate.\r\n	So due to this effect high upload speeds lead to high download speeds.</li>\r\n\r\n    <li>Due to the way TCP works, when A is downloading something from B it has to keep telling B that\r\n        it received the data sent to him. (These are called acknowledgements - ACKs -, a sort of &quot;got it!&quot; messages).\r\n        If A fails to do this then B will stop sending data and wait. If A is uploading at full speed there may be no\r\n        bandwidth left for the ACKs and they will be delayed. So due to this effect excessively high upload speeds lead\r\n        to low download speeds.</li>\r\n</ul>\r\n\r\nThe full effect is a combination of the two. The upload should be kept as high as possible while allowing the\r\nACKs to get through without delay. <b>A good thumb rule is keeping the upload at about 80% of the theoretical\r\nupload speed.</b> You will have to fine tune yours to find out what works best for you. (Remember that keeping the\r\nupload high has the additional benefit of helping with your ratio.) <br>\r\n<br>\r\nIf you are running more than one instance of a client it is the overall upload speed that you must take into account.\r\nSome clients (e.g. Azureus) limit global upload speed, others (e.g. Shad0w''s) do it on a per torrent basis.\r\nKnow your client. The same applies if you are using your connection for anything else (e.g. browsing or ftp),\r\nalways think of the overall upload speed.', '1', 6, 2),
(52, 'item', 'Limit the number of simultaneous connections', 'Some operating systems (like Windows 9x) do not deal well with a large number of connections, and may even crash.\r\nAlso some home routers (particularly when running NAT and/or firewall with stateful inspection services) tend to become\r\nslow or crash when having to deal with too many connections. There are no fixed values for this, you may try 60 or 100\r\nand experiment with the value. Note that these numbers are additive, if you have two instances of\r\na client running the numbers add up.', '1', 6, 3),
(53, 'item', 'Limit the number of simultaneous uploads', 'Isn''t this the same as above? No. Connections limit the number of peers your client is talking to and/or\r\ndownloading from. Uploads limit the number of peers your client is actually uploading to. The ideal number is\r\ntypically much lower than the number of connections, and highly dependent on your (physical) connection.', '1', 6, 4),
(54, 'item', 'Just give it some time', 'As explained above peers favour other peers that upload to them. When you start leeching a new torrent you have\r\nnothing to offer to other peers and they will tend to ignore you. This makes the starts slow, in particular if,\r\nby change, the peers you are connected to include few or no seeders. The download speed should increase as soon\r\nas you have some pieces to share.', '1', 6, 5),
(55, 'item', 'Why is my browsing so slow while leeching?', 'Your download speed is always finite. If you are a peer in a fast torrent it will almost certainly saturate your\r\ndownload bandwidth, and your browsing will suffer. At the moment there is no client that allows you to limit the\r\ndownload speed, only the upload. You will have to use a third-party solution,\r\nsuch as <a class=altlink href="redir.php?url=http://www.netlimiter.com/">NetLimiter</a>.<br>\r\n<br>\r\nBrowsing was used just as an example, the same would apply to gaming, IMing, etc...', '1', 6, 6),
(56, 'item', 'What is a proxy?', 'Basically a middleman. When you are browsing a site through a proxy your requests are sent to the proxy and the proxy\r\nforwards them to the site instead of you connecting directly to the site. There are several classifications\r\n(the terminology is far from standard):<br>\r\n<br>\r\n\r\n\r\n<table cellspacing=3 cellpadding=0>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA" width="100">&nbsp;Transparent</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">A transparent proxy is one that needs no configuration on the clients. It works by automatically redirecting all port 80 traffic to the proxy. (Sometimes used as synonymous for non-anonymous.)</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Explicit/Voluntary</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">Clients must configure their browsers to use them.</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Anonymous</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">The proxy sends no client identification to the server. (HTTP_X_FORWARDED_FOR header is not sent; the server does not see your IP.)</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Highly Anonymous</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">The proxy sends no client nor proxy identification to the server. (HTTP_X_FORWARDED_FOR, HTTP_VIA and HTTP_PROXY_CONNECTION headers are not sent; the server doesn''t see your IP and doesn''t even know you''re using a proxy.)</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Public</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">(Self explanatory)</td>\r\n </tr>\r\n</table>\r\n<br>\r\nA transparent proxy may or may not be anonymous, and there are several levels of anonymity.', '1', 7, 1),
(57, 'item', 'How do I find out if I''m behind a (transparent/anonymous) proxy?', 'Try <a href=http://proxyjudge.org class="altlink">ProxyJudge</a>. It lists the HTTP headers that the server where it is running\r\nreceived from you. The relevant ones are HTTP_CLIENT_IP, HTTP_X_FORWARDED_FOR and REMOTE_ADDR.<br>\r\n<br>\r\n<br>\r\n<b>Why is my port listed as &quot;---&quot; even though I''m not NAT/Firewalled?</b><a name="prox3"></a><br>\r\n<br>\r\nThe TorrentBits tracker is quite smart at finding your real IP, but it does need the proxy to send the HTTP header\r\nHTTP_X_FORWARDED_FOR. If your ISP''s proxy does not then what happens is that the tracker will interpret the proxy''s IP\r\naddress as the client''s IP address. So when you login and the tracker tries to connect to your client to see if you are\r\nNAT/firewalled it will actually try to connect to the proxy on the port your client reports to be using for\r\nincoming connections. Naturally the proxy will not be listening on that port, the connection will fail and the\r\ntracker will think you are NAT/firewalled.', '1', 7, 2),
(58, 'item', 'Can I bypass my ISP''s proxy?', 'If your ISP only allows HTTP traffic through port 80 or blocks the usual proxy ports then you would need to use something\r\nlike <a href=http://www.socks.permeo.com>socks</a> and that is outside the scope of this FAQ.<br>\r\n<br>\r\nThe site accepts connections on port 81 besides the usual 80, and using them may be enough to fool some proxies. So the first\r\nthing to try should be connecting to www.torrentbits.org:81. Note that even if this works your bt client will still try\r\nto connect to port 80 unless you edit the announce url in the .torrent file.<br>\r\n<br>\r\nOtherwise you may try the following:<br>\r\n<ul>\r\n    <li>Choose any public <b>non-anonymous</b> proxy that does <b>not</b> use port 80\r\n	(e.g. from <a href=http://tools.rosinstrument.com/proxy  class="altlink">this</a>,\r\n	<a href=http://www.proxy4free.com/index.html  class="altlink">this</a> or\r\n	<a href=http://www.samair.ru/proxy  class="altlink">this</a> list).</li>\r\n\r\n    <li>Configure your computer to use that proxy. For Windows XP, do <i>Start</i>, <i>Control Panel</i>, <i>Internet Options</i>,\r\n	<i>Connections</i>, <i>LAN Settings</i>, <i>Use a Proxy server</i>, <i>Advanced</i> and type in the IP and port of your chosen\r\n	proxy. Or from Internet Explorer use <i>Tools</i>, <i>Internet Options</i>, ...<br></li>\r\n\r\n    <li>(Facultative) Visit <a href=http://proxyjudge.org  class="altlink">ProxyJudge</a>. If you see an HTTP_X_FORWARDED_FOR in\r\n	the list followed by your IP then everything should be ok, otherwise choose another proxy and try again.<br></li>\r\n\r\n    <li>Visit TorrentBits. Hopefully the tracker will now pickup your real IP (check your profile to make sure).</li>\r\n</ul>\r\n<br>\r\nNotice that now you will be doing all your browsing through a public proxy, which are typically quite slow.\r\nCommunications between peers do not use port 80 so their speed will not be affected by this, and should be better than when\r\nyou were &quot;unconnectable&quot;.', '1', 7, 3),
(59, 'item', 'How do I make my bittorrent client use a proxy?', 'Just configure Windows XP as above. When you configure a proxy for Internet Explorer you''re actually configuring a proxy for\r\nall HTTP traffic (thank Microsoft and their &quot;IE as part of the OS policy&quot; ). On the other hand if you use another\r\nbrowser (Opera/Mozilla/Firefox) and configure a proxy there you''ll be configuring a proxy just for that browser. We don''t\r\nknow of any BT client that allows a proxy to be specified explicitly.', '1', 7, 4),
(60, 'item', 'Why can''t I signup from behind a proxy?', 'It is our policy not to allow new accounts to be opened from behind a proxy.', '1', 7, 5),
(61, 'item', 'Does this apply to other torrent sites?', 'This section was written for TorrentBits, a closed, port 80-81 tracker. Other trackers may be open or closed, and many listen\r\non e.g. ports 6868 or 6969. The above does <b>not</b> necessarily apply to other trackers.', '1', 7, 6),
(62, 'item', 'Maybe my address is blacklisted?', 'The site blocks addresses listed in the (former) <a class=altlink href="http://methlabs.org/">PeerGuardian</a>\r\ndatabase, as well as addresses of banned users. This works at Apache/PHP level, it''s just a script that\r\nblocks <i>logins</i> from those addresses. It should not stop you from reaching the site. In particular\r\nit does not block lower level protocols, you should be able to ping/traceroute the server even if your\r\naddress is blacklisted. If you cannot then the reason for the problem lies elsewhere.<br>\r\n<br>\r\nIf somehow your address is indeed blocked in the PG database do not contact us about it, it is not our\r\npolicy to open <i>ad hoc</i> exceptions. You should clear your IP with the database maintainers instead.', '1', 8, 1),
(63, 'item', 'Your ISP blocks the site''s address', '(In first place, it''s unlikely your ISP is doing so. DNS name resolution and/or network problems are the usual culprits.)\r\n<br>\r\nThere''s nothing we can do.\r\nYou should contact your ISP (or get a new one). Note that you can still visit the site via a proxy, follow the instructions\r\nin the relevant section. In this case it doesn''t matter if the proxy is anonymous or not, or which port it listens to.<br>\r\n<br>\r\nNotice that you will always be listed as an &quot;unconnectable&quot; client because the tracker will be unable to\r\ncheck that you''re capable of accepting incoming connections.', '1', 8, 2),
(64, 'item', 'Alternate port (81)', 'Some of our torrents use ports other than the usual HTTP port 80. This may cause problems for some users,\r\nfor instance those behind some firewall or proxy configurations.\r\n\r\nYou can easily solve this by editing the .torrent file yourself with any torrent editor, e.g.\r\n<a href="http://sourceforge.net/projects/burst/" class="altlink">MakeTorrent</a>,\r\nand replacing the announce url torrentbits.org:81 with torrentbits.org:80 or just torrentbits.org.<br>\r\n<br>\r\nEditing the .torrent with Notepad is not recommended. It may look like a text file, but it is in fact\r\na bencoded file. If for some reason you must use a plain text editor, change the announce url to\r\ntorrentbits.org:80, not torrentbits.org. (If you''re thinking about changing the number before the\r\nannounce url instead, you know too much to be reading this.)', '2', 8, 3),
(65, 'item', 'You can try these:', 'Post in the <a class="altlink" href="forums.php">Forums</a>, by all means. You''ll find they\r\nare usually a friendly and helpful place,\r\nprovided you follow a few basic guidelines:\r\n<ul>\r\n<li>Make sure your problem is not really in this FAQ. There''s no point in posting just to be sent\r\nback here.\r\n<li>Before posting read the sticky topics (the ones at the top). Many times new information that\r\nstill hasn''t been incorporated in the FAQ can be found there.</li>\r\n<li>Help us in helping you. Do not just say "it doesn''t work!". Provide details so that we don''t\r\nhave to guess or waste time asking. What client do you use? What''s your OS? What''s your network setup? What''s the exact\r\nerror message you get, if any? What are the torrents you are having problems with? The more\r\nyou tell the easiest it will be for us, and the more probable your post will get a reply.</li>\r\n<li>And needless to say: be polite. Demanding help rarely works, asking for it usually does\r\nthe trick.', '1', 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `size` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `torrent` (`torrent`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `files`
--


-- --------------------------------------------------------

--
-- Table structure for table `forums`
--

CREATE TABLE IF NOT EXISTS `forums` (
  `sort` tinyint(3) unsigned NOT NULL default '0',
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `description` varchar(200) default NULL,
  `minclassread` tinyint(3) unsigned NOT NULL default '0',
  `minclasswrite` tinyint(3) unsigned NOT NULL default '0',
  `postcount` int(10) unsigned NOT NULL default '0',
  `topiccount` int(10) unsigned NOT NULL default '0',
  `minclasscreate` tinyint(3) unsigned NOT NULL default '0',
  `forid` tinyint(4) default '0',
  `moderators` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forums`
--


-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `friendid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`friendid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `friends`
--


-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE IF NOT EXISTS `guests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL default '',
  `time_accessed` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `guests`
--


-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sender` int(10) unsigned NOT NULL default '0',
  `receiver` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `msg` text,
  `unread` enum('yes','no') NOT NULL default 'yes',
  `poster` bigint(20) unsigned NOT NULL default '0',
  `location` enum('in','out','both') NOT NULL default 'in',
  PRIMARY KEY  (`id`),
  KEY `receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `modpanel`
--

CREATE TABLE IF NOT EXISTS `modpanel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `url` varchar(20) default NULL,
  `info` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1016 ;

--
-- Dumping data for table `modpanel`
--

INSERT INTO `modpanel` (`id`, `name`, `url`, `info`) VALUES
(1001, 'Warned users', 'warned.php', 'See warned users'),
(1002, 'Poll overview', 'polls.php', 'View polls'),
(1003, 'Make poll', 'makepoll.php', 'Create new poll'),
(1004, 'User list', 'users.php', 'View users'),
(1005, 'Stats', 'stats.php', 'Tracker stats'),
(1006, 'Test IP', 'testip.php', 'Test single IP'),
(1007, 'Duplicate IP', 'ipcheck.php', 'Duplicate IP users'),
(1008, 'Leechers', 'leechers.php', 'Show users with ratio under 0.40'),
(1009, 'IP ban', 'bans.php', 'Ban single IP'),
(1011, 'Check script', 'proxy.php', 'Possable proxy server user check script'),
(1012, 'Uploaders', 'uploaders.php', 'See your uploaders info'),
(1013, 'Ratio cheaters', 'cheaters.php', 'Check if someone is cheating on tracker'),
(1014, 'Maybe Cheaters', 'maybecheaters.php', 'Those users maybe are cheaters'),
(1015, 'Site Log', 'log.php', 'See the site Log');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `body` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `news`
--


-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `name` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `yeah` int(10) unsigned NOT NULL default '0',
  `against` int(10) unsigned NOT NULL default '0',
  `category` int(11) NOT NULL default '0',
  `comments` int(11) NOT NULL default '0',
  `allowed` enum('allowed','pending','denied') NOT NULL default 'pending',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `offers`
--


-- --------------------------------------------------------

--
-- Table structure for table `offervotes`
--

CREATE TABLE IF NOT EXISTS `offervotes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `offerid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `vote` enum('yeah','against') NOT NULL default 'yeah',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `offervotes`
--


-- --------------------------------------------------------

--
-- Table structure for table `onlinerec`
--

CREATE TABLE IF NOT EXISTS `onlinerec` (
  `users` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`users`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `onlinerec`
--


-- --------------------------------------------------------

--
-- Table structure for table `overforums`
--

CREATE TABLE IF NOT EXISTS `overforums` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `description` varchar(200) default NULL,
  `minclassview` tinyint(3) unsigned NOT NULL default '0',
  `forid` tinyint(3) unsigned NOT NULL default '1',
  `sort` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `overforums`
--


-- --------------------------------------------------------

--
-- Table structure for table `peers`
--

CREATE TABLE IF NOT EXISTS `peers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `peer_id` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `ip` varchar(64) NOT NULL default '',
  `port` smallint(5) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `to_go` bigint(20) unsigned NOT NULL default '0',
  `seeder` enum('yes','no') NOT NULL default 'no',
  `started` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL default 'yes',
  `userid` int(10) unsigned NOT NULL default '0',
  `agent` varchar(60) NOT NULL default '',
  `finishedat` int(10) unsigned NOT NULL default '0',
  `downloadoffset` bigint(20) unsigned NOT NULL default '0',
  `uploadoffset` bigint(20) unsigned NOT NULL default '0',
  `passkey` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `torrent_peer_id` (`torrent`,`peer_id`),
  KEY `torrent` (`torrent`),
  KEY `torrent_seeder` (`torrent`,`seeder`),
  KEY `last_action` (`last_action`),
  KEY `connectable` (`connectable`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `peers`
--


-- --------------------------------------------------------

--
-- Table structure for table `pollanswers`
--

CREATE TABLE IF NOT EXISTS `pollanswers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pollid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `selection` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`),
  KEY `selection` (`selection`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pollanswers`
--


-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

CREATE TABLE IF NOT EXISTS `polls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `question` varchar(255) NOT NULL default '',
  `option0` varchar(40) NOT NULL default '',
  `option1` varchar(40) NOT NULL default '',
  `option2` varchar(40) NOT NULL default '',
  `option3` varchar(40) NOT NULL default '',
  `option4` varchar(40) NOT NULL default '',
  `option5` varchar(40) NOT NULL default '',
  `option6` varchar(40) NOT NULL default '',
  `option7` varchar(40) NOT NULL default '',
  `option8` varchar(40) NOT NULL default '',
  `option9` varchar(40) NOT NULL default '',
  `option10` varchar(40) NOT NULL default '',
  `option11` varchar(40) NOT NULL default '',
  `option12` varchar(40) NOT NULL default '',
  `option13` varchar(40) NOT NULL default '',
  `option14` varchar(40) NOT NULL default '',
  `option15` varchar(40) NOT NULL default '',
  `option16` varchar(40) NOT NULL default '',
  `option17` varchar(40) NOT NULL default '',
  `option18` varchar(40) NOT NULL default '',
  `option19` varchar(40) NOT NULL default '',
  `sort` enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `polls`
--


-- --------------------------------------------------------

--
-- Table structure for table `postpollanswers`
--

CREATE TABLE IF NOT EXISTS `postpollanswers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pollid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `selection` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `postpollanswers`
--


-- --------------------------------------------------------

--
-- Table structure for table `postpolls`
--

CREATE TABLE IF NOT EXISTS `postpolls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `question` text NOT NULL,
  `option0` varchar(40) NOT NULL default '',
  `option1` varchar(40) NOT NULL default '',
  `option2` varchar(40) NOT NULL default '',
  `option3` varchar(40) NOT NULL default '',
  `option4` varchar(40) NOT NULL default '',
  `option5` varchar(40) NOT NULL default '',
  `option6` varchar(40) NOT NULL default '',
  `option7` varchar(40) NOT NULL default '',
  `option8` varchar(40) NOT NULL default '',
  `option9` varchar(40) NOT NULL default '',
  `option10` varchar(40) NOT NULL default '',
  `option11` varchar(40) NOT NULL default '',
  `option12` varchar(40) NOT NULL default '',
  `option13` varchar(40) NOT NULL default '',
  `option14` varchar(40) NOT NULL default '',
  `option15` varchar(40) NOT NULL default '',
  `option16` varchar(40) NOT NULL default '',
  `option17` varchar(40) NOT NULL default '',
  `option18` varchar(40) NOT NULL default '',
  `option19` varchar(40) NOT NULL default '',
  `sort` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `postpolls`
--


-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `topicid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `body` text,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `userid` (`userid`),
  FULLTEXT KEY `body` (`body`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `torrent` int(10) unsigned NOT NULL default '0',
  `user` int(10) unsigned NOT NULL default '0',
  `rating` tinyint(3) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`torrent`,`user`),
  KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratings`
--


-- --------------------------------------------------------

--
-- Table structure for table `readposts`
--

CREATE TABLE IF NOT EXISTS `readposts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `topicid` int(10) unsigned NOT NULL default '0',
  `lastpostread` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`id`),
  KEY `topicid` (`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `readposts`
--


-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `reported_by` int(10) unsigned NOT NULL default '0',
  `reporting_what` int(10) unsigned NOT NULL default '0',
  `reporting_type` enum('User','Comment','Request_Comment','Offer_Comment','Request','Offer','Torrent','Hit_And_Run','Post') NOT NULL default 'Torrent',
  `reason` text NOT NULL,
  `who_delt_with_it` int(10) unsigned NOT NULL default '0',
  `delt_with` tinyint(1) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `how_delt_with` text NOT NULL,
  `2nd_value` int(10) unsigned NOT NULL default '0',
  `when_delt_with` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `reports`
--


-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `request` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL default '0',
  `cat` int(10) unsigned NOT NULL default '0',
  `filledby` int(10) unsigned NOT NULL default '0',
  `filledurl` varchar(70) default NULL,
  `filled` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`),
  KEY `id_added` (`id`,`added`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `requests`
--


-- --------------------------------------------------------

--
-- Table structure for table `rules`
--

CREATE TABLE IF NOT EXISTS `rules` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `text` text NOT NULL,
  `public` enum('yes','no') NOT NULL default 'yes',
  `class` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `rules`
--

INSERT INTO `rules` (`id`, `title`, `text`, `public`, `class`) VALUES
(1, 'Reguli Generale -Incalcand aceste reguli puteti primi ban!', 'Nu uploadati torrentele noastre pe alte trackere!\r\n Nu sfidati dorintele exprimate ale moderatorilor!\r\n Fara comportament neadecvat in Forum sau PM-uri.\r\n BASHING-ul altor site-uri nu va fi tolerat.\r\n Fara comportament agresiv, neprietenos sau rasist oriunde pe acest site!\r\n Nu comentati deciziile Moderatorilor cum ar fi inchiderea, mutarea sau stergerea topicurilor.\r\n Fara link-uri catre Warez, site-uri de crack-uri si alte trackere romanesti pe acest site.\r\n Nu cereti sau postati seriale, CD key-uri , parole sau crack-uri pe acest site.\r\n Veti primi o singura avertizare! Dupa care urmeaza DISABLE!\r\n Conturile cu activitate zero (0 bytes download si 0 bytes upload) sunt sterse automat dupa 30 de zile.\r\n Conturile inactive sub VIP si fara parked sunt sterse automat dupa 40 de zile.\r\n Userii care au conturi multiple primesc automat DISABLE pe toate.\r\n Orice metoda de trisare ( Fake upload, Ghost leeching ) aduce dupa sine DISABLE + BAN IP indiferent de clasa pe care o are userul respectiv.\r\n Userii care [color=Red]VAND INVITATII [/color]primesc [color=Red]DISABLE[/color] si [color=Red]BAN[/color], este valabil si pentru [color=Red]TOTI USERII [/color]invitati de[color=Red] ACESTA [/color]daca [color=Red]NU[/color] suntem anuntati [color=Red]INAINTE[/color].\r\n', 'yes', 0),
(2, 'Reguli de download - Prin nerespectarea acestor reguli va veti pierde privilegiul de a downloada!', 'Ratiile [b]mici[/b] pot avea consecinte grave, inclusiv dezactivarea contului. ( [b]ratie mica[/b]  [color=Red]=[/color] [b]< 0.500 [/b])\r\n Fiecare [b]torrent[/b] trebuie tinut la seed[color=Red] minim 24 de ore [/color]dupa ce a fost descarcat.\r\n[b] Stergerea torrentului [/b]din clientul dvs. se poate face[b] numai daca [/b]aveti o ratie minima de [color=Red]1.000 per torrent[/color].\r\n Daca ati [b]inchis clientul [/b]bittorrent fara sa aveti [color=Red]timpul minim de seed [/color]specificat mai sus, se considera[color=Red] Hit & Run[/color].\r\n Daca ati [b]sters torrentul [/b]din clientul dvs. bittorrent fara sa aveti o ratie minima de [color=Red]1.000 per torrent[/color], se considera[color=Red] Hit & Run[/color].\r\n\r\n\r\n   [b]Clientii bittorrent acceptati[/b] acest tracker sunt urmatorii:\r\n  [b] µTorrent [/b]1.6.1, 1.7.6, 1.7.7 + ultimele versiuni.\r\n   [b]Azureus[/b] 2.5.0.4, 3.0.4.2 + ultimele versiuni.\r\n   Bittornado t-0.3.17, 0.3.18  + ultimele versiuni.\r\n   BitComet 0.70\r\n   Ktorrent 2.2.4, 2.2.5  + ultimele versiuni.\r\n   Deluge 0.5.8.2, 0.5.8.3  + ultimele versiuni.\r\n   Transmission 1.02 - 1.05  + ultimele versiuni', 'yes', 0),
(3, 'Reguli Forum - Va rugam respectati aceste reguli altfel veti primi un avertisment!', '[*] Fara comportament agresiv pe forum.\r\n[*] Nu distrugeti topicurile celorlalti (ex: SPAM, offtopic).\r\n[*] Limbile de conversatie acceptate sunt romana si engleza\r\n[*] Nu folositi un limbaj vulgar in posturi (si cu atat mai putin in titlu).\r\n[*] Nu postati link-uri warez sau site-uri de crack-uri.\r\n[*] Nu cereti seriale, CD key-uri, parole sau crack-uri.\r\n[*] Nu deschideÅ£i topic pt a face o cerere.\r\n[*] Nu va certati... (Topicurile cu certuri vor fi sterse.)\r\n[*] Nu folositi imagini mai mari de 800x600, si preferabil optimizate pentru web.\r\n[*] Fara posturi duble. Daca doriti sa postati din nou, iar postul dumneavoastra este ultimul in topic va rugam folositi functia EDIT, in loc sa postati din nou.\r\n[*] Aveti grija ca intrebarile dvs sa fie postate in topicul corespunzator.\r\n[*] Va rugam sa cititi [url=faq.php]FAQ[/url] inainte de a pune intrebari!', 'yes', 0),
(4, 'Reguli pentru avatar -Va rugam incercati sa respectati aceste reguli!', '[*] Formatele acceptate sunt .gif, .jpg si .png .\r\n[*] Redimensionati-va imaginile la o latime de 150 px iar marimea sa nu fie mai mare de 150 KB. \r\n[*] (Browserele le vor scala oricum: imaginile mai mici vor fi marite si nu vor arata bine;\r\n[*] imaginile mari vor consuma inutil bandwidth si CPU.)Deocamdata sunt doar niste reguli dar in curand veti fi obligati automat.\r\n[*] Nu folositi in avatarul dvs imagini cu continut pornografic, religios, sau o imagine care ofenseaza un alt User. ', 'yes', 0),
(5, 'Reguli la comentariile torrentilor - Incalcarea acestor reguli se sanctioneaza cu avertisment!', '[*] Respectati uploaderul!\r\n[*] Limitati-va comentariile la torrentul in cauza.\r\n[*] NU comentati un torrent daca nu aveti de gand sa il luati.\r\n[*] NU cereti subtitrari.Verificati site-urile de specialitate.\r\n[*] NU cereti free la torrente.\r\n[*] NU se accepta commenturi compuse DOAR din smiley face.\r\n[*] Retineti: torrentele nu sunt puse dupa gusturile dvs. daca nu va place un release, nu il luati!', 'yes', 0),
(8, 'Reguli de upload - Torentele care incalca aceste reguli pot fi sterse fara notificare!', '[*]  Toate uploadurile trebuie sa includa o descriere detaliata altfel veti primi un avertisment. Dupa 3 avertismente veti primi ban.\r\n[*]  Incercati sa tineti fisierele in formatul original.\r\n[*]  Torentele pre-release ar trebui etichetate cu *ALPHA* sau *BETA*.\r\n[*]  Nu includeti seriale, CD keyuri sau chestii similare la descriere(nu trebuie sa editati NFO!).\r\n[*]  Asigurati-va ca torentele dvs sunt bine seeduite pentru cel putin 24 de ore (sau pana cand au minim 3 seederi).\r\n[*]  Nu puneti data releasului in numele torentului.\r\n[*]  Stati activ! Riscati sa luati demote daca nu aveti torrente active.\r\n\r\n', 'yes', 0),
(6, 'Reguli de Moderare - Foloseste-ti cea mai buna judecata!', '[*] Cea mai importanta regula: "Foloseste-ti cea mai buna judecata!"\r\n[*] Nu-ti fie teama sa zici "NU" (gen "Regula lui Helshad")\r\n[*] Nu sfida alt moderator in public, mai degraba trimite-i un PM sau cere-i IM.\r\n[*] Fii tolerant, ofera-i userului sansa de a se "reface".\r\n[*] Nu actiona prematur, lasa userii sa greseasca si apoi ii corectezi.\r\n[*] Incearca sa corectezi "Off-Topicurile", decat sa inchizi topicul.\r\n[*] Muta topicurile decat sa le inchizi.\r\n[*] Fii tolerant cand moderezi ShoutBox-ul.\r\n[*] Daca inchizi un topic, da-ne o explicatie pentru care ai decurs la aceasta alegere.\r\n[*] Inainte sa dai DISABLE unui user, trimite-i un PM si, daca raspunde, pune-l pe 2 saptamani de asteptare.\r\n[*] Nu da Disable unui user atat timp cat el nu a atins 4 saptamani pe tracker.\r\n[*] INTODEAUNA pune un motiv (in cadrul de comentarii) in care sa scrii de ce acel user a fost banat/avertizat.', 'yes', 0),
(7, 'Optiuni de Moderare - Care sunt privilegiile mele ca Moderator?', '[*] Poti sa stergi si sa editezi forumurile.\r\n[*] Poti sa stergi si sa editezi torrentele.\r\n[*] Poti sa stergi si sa schimbi avatarele userilor.\r\n[*] Poti sa dai disable la useri.\r\n[*] Poti sa dai un post de VIP.\r\n[*] Poti edita title-ul unui VIP.\r\n[*] Poti vedea informatiile complete ale userilor.\r\n[*] Poti sa adaugi commenturi la useri( pentru ca alti administratori/moderatori sa citeasca).\r\n[*] In sfarsit, verifica pagina Staff din coltul drept!.', 'yes', 0),
(9, ' Hit&Run', 'Nu practicati[color=Red] hit&run [/color](h&r), torentele downloadate pot fi inchise doar daca au [color=Red]ratie 1[/color] sau timpul de seed pe torent este de[color=Red] 60 de ore[/color]. Torentele pot fi inchise dupa ce se acumuleaza [color=Red]minim 3 ore [/color]de la incheierea downloadului urmand ca ulterior sa reveniti la seed si timp de [color=Red]1 saptamana [/color]sa realizati [color=Red]ratia 1 [/color]sau cele [color=Red]60 de ore [/color]de seed. Daca stiti ca nu veti putea tine la seed acest timp minim inainte de a reveni, nu va mai deranjati sa-l luati. Il veti downloada mai tarziu cand stiti ca veti tine pc-ul mai mult deschis.\r\nIncalcarea acestei reguli duce la avertizare timp de 1 saptamana([URL=http://img263.imageshack.us/i/warned.gif/][IMG]http://img263.imageshack.us/img263/1285/warned.gif[/IMG][/URL]).\r\nIncalcarea acestei reguli pe un torrent [color=Red]freeleech[/color] duce la avertizare timp de 2 saptamani([URL=http://img263.imageshack.us/i/warned.gif/][IMG]http://img263.imageshack.us/img263/1285/warned.gif[/IMG][/URL]).\r\nIncalcarea acestei reguli in mod repetat poate duce la dezactivarea contului([URL=http://img521.imageshack.us/i/disabled.gif/][IMG]http://img521.imageshack.us/img521/2240/disabled.gif[/IMG][/URL]).\r\nClasa VIP([URL=http://img160.imageshack.us/i/starmyf.gif/][IMG]http://img160.imageshack.us/img160/2997/starmyf.gif[/IMG][/URL]) e exclusa de la regulile hit&run !', 'yes', 0),
(10, 'Regulament ShoutBox - Va rugam respectati aceste reguli sau o sa pierdeti dreptul de a posta !', ' Postarea [b]link-urilor [/b]care [b]NU[/b] au legatura cu site-ul XZone este [b]strict [/b][b]interzisa[/b] . ( aici sunt inclusele si[b] reclamele [/b])\r\n Postarea [b]id-urilor [/b]de instant messaging ( ex: Yahoo, Skype, etc ) sau a [b]email-urilor [/b][b]este strict interzisa[/b] ( Folositi Private Message )\r\n Folositi un [b]limbaj [/b]cat mai [b]civilizat[/b], fara injurii / jigniri la adresa[b] userilor [/b]sau [b]staff-ului[/b].\r\n [b]Cererea de invitatii sau voturi pentru request-uri este strict interzisa [/b][color=Red]WARN[/color]([IMG]http://img263.imageshack.us/img263/1285/warned.gif[/IMG])\r\n[b] Nerespectarea acestor reguli [/b]aduce dupa sine disable shoutbox,[b] warn [/b]sau in cel mai rau caz[b] disable account[/b]. ( durata primelor 2 sanctiuni este variabila 1 - 8 weeks )', 'yes', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id` smallint(6) NOT NULL auto_increment,
  `userid` smallint(6) NOT NULL default '0',
  `username` varchar(25) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  `text` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shoutbox`
--


-- --------------------------------------------------------

--
-- Table structure for table `sitelog`
--

CREATE TABLE IF NOT EXISTS `sitelog` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime default NULL,
  `txt` text,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sitelog`
--


-- --------------------------------------------------------

--
-- Table structure for table `snatched`
--

CREATE TABLE IF NOT EXISTS `snatched` (
  `id` int(11) NOT NULL auto_increment,
  `torrentid` int(11) default '0',
  `userid` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `snatched`
--


-- --------------------------------------------------------

--
-- Table structure for table `staffmessages`
--

CREATE TABLE IF NOT EXISTS `staffmessages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sender` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `msg` text,
  `subject` varchar(100) NOT NULL default '',
  `answeredby` int(10) unsigned NOT NULL default '0',
  `answered` tinyint(1) NOT NULL default '0',
  `answer` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `staffmessages`
--


-- --------------------------------------------------------

--
-- Table structure for table `stylesheets`
--

CREATE TABLE IF NOT EXISTS `stylesheets` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uri` varchar(255) NOT NULL default '',
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `stylesheets`
--

INSERT INTO `stylesheets` (`id`, `uri`, `name`) VALUES
(3, 'default2.css', 'Default'),
(1, 'coagulate.css', 'coagulate'),
(2, 'red.css', 'Red'),
(4, 'default.css', 'Default2'),
(5, 'starfall.css', 'Starfall');

-- --------------------------------------------------------

--
-- Table structure for table `subs`
--

CREATE TABLE IF NOT EXISTS `subs` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `cd` int(10) unsigned NOT NULL default '0',
  `frame` varchar(255) NOT NULL default '',
  `comment` text NOT NULL,
  `added` datetime default NULL,
  `size` int(10) unsigned NOT NULL default '0',
  `uppedby` int(10) unsigned NOT NULL default '0',
  `url` varchar(255) NOT NULL default '',
  `hits` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `subs`
--


-- --------------------------------------------------------

--
-- Table structure for table `sysoppanel`
--

CREATE TABLE IF NOT EXISTS `sysoppanel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `url` varchar(20) default NULL,
  `info` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3021 ;

--
-- Dumping data for table `sysoppanel`
--

INSERT INTO `sysoppanel` (`id`, `name`, `url`, `info`) VALUES
(3003, 'Mass mailer', 'massmail.php', 'Send mail to all tracker users'),
(3005, 'My_Sql stats', 'mysql_stats.php', 'See your MySql stats'),
(3006, 'Manage tracker categories', 'category.php', 'Manage your tracker torrent caregoties'),
(3008, 'Rest lost passwords', 'reset.php', 'Sysop''s reset users password, rest lost passwords'),
(3009, 'Edit forum', 'editforums.php', 'Edit your forum'),
(3010, 'PHP info', 'phpnfo.php', 'Check your PHP status'),
(3012, 'Do Cleanup', 'docleanup.php', 'Do cleanup functions'),
(3013, 'Optimize DB', 'optimize.php', 'This script will optimize your DB'),
(3016, 'Spam', 'spamstaff.php', 'Spam PM'),
(3017, 'Calculator GB', 'calc.php', 'Calculator GB'),
(3018, 'Mass PM', 'masspmstaff.php', 'Send PM to all users'),
(3020, 'Invites add', 'inviteadd.php', 'Invites add');

-- --------------------------------------------------------

--
-- Table structure for table `thanks`
--

CREATE TABLE IF NOT EXISTS `thanks` (
  `torrentid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `thanks`
--


-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `subject` varchar(40) default NULL,
  `locked` enum('yes','no') NOT NULL default 'no',
  `forumid` int(10) unsigned NOT NULL default '0',
  `lastpost` int(10) unsigned NOT NULL default '0',
  `sticky` enum('yes','no') NOT NULL default 'no',
  `views` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`),
  KEY `subject` (`subject`),
  KEY `lastpost` (`lastpost`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `topics`
--


-- --------------------------------------------------------

--
-- Table structure for table `torrents`
--

CREATE TABLE IF NOT EXISTS `torrents` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `info_hash` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `save_as` varchar(255) NOT NULL default '',
  `search_text` text NOT NULL,
  `descr` text NOT NULL,
  `ori_descr` text NOT NULL,
  `category` int(10) unsigned NOT NULL default '0',
  `size` bigint(20) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` enum('single','multi') NOT NULL default 'single',
  `numfiles` int(10) unsigned NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `views` int(10) unsigned NOT NULL default '0',
  `hits` int(10) unsigned NOT NULL default '0',
  `times_completed` int(10) unsigned NOT NULL default '0',
  `leechers` int(10) unsigned NOT NULL default '0',
  `seeders` int(10) unsigned NOT NULL default '0',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `visible` enum('yes','no') NOT NULL default 'yes',
  `banned` enum('yes','no') NOT NULL default 'no',
  `owner` int(10) unsigned NOT NULL default '0',
  `numratings` int(10) unsigned NOT NULL default '0',
  `ratingsum` int(10) unsigned NOT NULL default '0',
  `nfo` text NOT NULL,
  `description` varchar(120) NOT NULL default '',
  `free` enum('yes','no') default 'no',
  `scene` enum('yes','no') NOT NULL default 'no',
  `request` enum('yes','no') NOT NULL default 'no',
  `poster` varchar(255) NOT NULL default 'poster.jpg',
  `nuked` enum('yes','no') NOT NULL default 'no',
  `sticky` enum('yes','no') NOT NULL default 'no',
  `tube` varchar(80) NOT NULL default '',
  `double_upload` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `info_hash` (`info_hash`),
  KEY `owner` (`owner`),
  KEY `visible` (`visible`),
  KEY `category_visible` (`category`,`visible`),
  FULLTEXT KEY `ft_search` (`search_text`,`ori_descr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `torrents`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(40) NOT NULL default '',
  `old_password` varchar(40) NOT NULL default '',
  `passhash` varchar(32) NOT NULL default '',
  `secret` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `email` varchar(80) NOT NULL default '',
  `icq` varchar(255) NOT NULL default '',
  `msn` varchar(255) NOT NULL default '',
  `aim` varchar(255) NOT NULL default '',
  `yahoo` varchar(255) NOT NULL default '',
  `skype` varchar(255) NOT NULL default '',
  `status` enum('pending','confirmed') NOT NULL default 'pending',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL default '0000-00-00 00:00:00',
  `editsecret` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `privacy` enum('strong','normal','low') NOT NULL default 'normal',
  `stylesheet` int(10) default '1',
  `info` text,
  `acceptpms` enum('yes','friends','no') NOT NULL default 'yes',
  `ip` varchar(15) NOT NULL default '',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `avatar` varchar(100) NOT NULL default '',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `title` varchar(30) NOT NULL default '',
  `country` int(10) unsigned NOT NULL default '0',
  `notifs` varchar(100) NOT NULL default '',
  `modcomment` text NOT NULL,
  `enabled` enum('yes','no') NOT NULL default 'yes',
  `avatars` enum('yes','no') NOT NULL default 'yes',
  `donor` enum('yes','no') NOT NULL default 'no',
  `warned` enum('yes','no') NOT NULL default 'no',
  `warneduntil` datetime NOT NULL default '0000-00-00 00:00:00',
  `torrentsperpage` int(3) unsigned NOT NULL default '0',
  `topicsperpage` int(3) unsigned NOT NULL default '0',
  `postsperpage` int(3) unsigned NOT NULL default '0',
  `deletepms` enum('yes','no') NOT NULL default 'yes',
  `savepms` enum('yes','no') NOT NULL default 'no',
  `anonymous` enum('yes','no') NOT NULL default 'no',
  `parked` enum('yes','no') NOT NULL default 'no',
  `announce` enum('yes','no') NOT NULL default 'yes',
  `passkey` varchar(32) NOT NULL default '',
  `last_browse` int(11) NOT NULL default '0',
  `seedbonus` decimal(3,1) NOT NULL default '0.0',
  `signatures` enum('yes','no') NOT NULL default 'yes',
  `signature` varchar(225) NOT NULL default '',
  `support` enum('yes','no') NOT NULL default 'no',
  `supportfor` text NOT NULL,
  `pcoff` enum('yes','no') NOT NULL default 'yes',
  `gender` enum('Male','Female','N/A') NOT NULL default 'N/A',
  `last_post` datetime NOT NULL default '0000-00-00 00:00:00',
  `fader` enum('yes','no') NOT NULL default 'yes',
  `fadecolor` varchar(255) NOT NULL default 'FF0000',
  `view_xxx` enum('yes','no') NOT NULL default 'yes',
  `donated` int(5) unsigned NOT NULL default '0',
  `hideseed` enum('yes','no') NOT NULL default 'no',
  `timeswarned` int(10) NOT NULL default '0',
  `invites` int(10) NOT NULL default '5',
  `invited_by` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status_added` (`status`,`added`),
  KEY `ip` (`ip`),
  KEY `uploaded` (`uploaded`),
  KEY `downloaded` (`downloaded`),
  KEY `country` (`country`),
  KEY `last_access` (`last_access`),
  KEY `enabled` (`enabled`),
  KEY `warned` (`warned`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `users`
--

