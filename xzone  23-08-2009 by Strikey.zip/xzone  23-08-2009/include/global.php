<?

$smilies = array(
  ":-)" => "smile1.gif",
  ":smile:" => "smile2.gif",
  ":-D" => "grin.gif",
  ":lol:" => "laugh.gif",
  ":w00t:" => "w00t.gif",
  ":-P" => "tongue.gif",
  ";-)" => "wink.gif",
  ":-|" => "noexpression.gif",
  ":-/" => "confused.gif",
  ":-(" => "sad.gif",
  ":'-(" => "cry.gif",
  ":weep:" => "weep.gif",
  ":-O" => "ohmy.gif",
  ":o)" => "clown.gif",
  "8-)" => "cool1.gif",
  "|-)" => "sleeping.gif",
  ":innocent:" => "innocent.gif",
  ":whistle:" => "whistle.gif",
  ":unsure:" => "unsure.gif",
  ":closedeyes:" => "closedeyes.gif",
  ":cool:" => "cool2.gif",
  ":fun:" => "fun.gif",
  ":thumbsup:" => "thumbsup.gif",
  ":thumbsdown:" => "thumbsdown.gif",
  ":blush:" => "blush.gif",
  ":unsure:" => "unsure.gif",
  ":yes:" => "yes.gif",
  ":no:" => "no.gif",
  ":love:" => "love.gif",
  ":?:" => "question.gif",
  ":!:" => "excl.gif",
  ":idea:" => "idea.gif",
  ":arrow:" => "arrow.gif",
  ":arrow2:" => "arrow2.gif",
  ":hmm:" => "hmm.gif",
  ":hmmm:" => "hmmm.gif",
  ":huh:" => "huh.gif",
  ":geek:" => "geek.gif",
  ":look:" => "look.gif",
  ":rolleyes:" => "rolleyes.gif",
  ":kiss:" => "kiss.gif",
  ":shifty:" => "shifty.gif",
  ":blink:" => "blink.gif",
  ":smartass:" => "smartass.gif",
  ":sick:" => "sick.gif",
  ":crazy:" => "crazy.gif",
  ":wacko:" => "wacko.gif",
  ":alien:" => "alien.gif",
  ":wizard:" => "wizard.gif",
  ":wave:" => "wave.gif",
  ":wavecry:" => "wavecry.gif",
  ":baby:" => "baby.gif",
  ":angry:" => "angry.gif",
  ":ras:" => "ras.gif",
  ":sly:" => "sly.gif",
  ":devil:" => "devil.gif",
  ":evil:" => "evil.gif",
  ":evilmad:" => "evilmad.gif",
  ":sneaky:" => "sneaky.gif",
  ":axe:" => "axe.gif",
  ":slap:" => "slap.gif",
  ":wall:" => "wall.gif",
  ":rant:" => "rant.gif",
  ":jump:" => "jump.gif",
  ":yucky:" => "yucky.gif",
  ":nugget:" => "nugget.gif",
  ":smart:" => "smart.gif",
  ":shutup:" => "shutup.gif",
  ":shutup2:" => "shutup2.gif",
  ":crockett:" => "crockett.gif",
  ":zorro:" => "zorro.gif",
  ":snap:" => "snap.gif",
  ":beer:" => "beer.gif",
  ":beer2:" => "beer2.gif",
  ":drunk:" => "drunk.gif",
  ":strongbench:" => "strongbench.gif",
  ":weakbench:" => "weakbench.gif",
  ":dumbells:" => "dumbells.gif",
  ":music:" => "music.gif",
  ":stupid:" => "stupid.gif",
  ":dots:" => "dots.gif",
  ":offtopic:" => "offtopic.gif",
  ":spam:" => "spam.gif",
  ":oops:" => "oops.gif",
  ":lttd:" => "lttd.gif",
  ":please:" => "please.gif",
  ":sorry:" => "sorry.gif",
  ":hi:" => "hi.gif",
  ":yay:" => "yay.gif",
  ":cake:" => "cake.gif",
  ":hbd:" => "hbd.gif",
  ":band:" => "band.gif",
  ":punk:" => "punk.gif",
        ":rofl:" => "rofl.gif",
  ":bounce:" => "bounce.gif",
  ":mbounce:" => "mbounce.gif",
  ":thankyou:" => "thankyou.gif",
  ":gathering:" => "gathering.gif",
  ":hang:" => "hang.gif",
  ":chop:" => "chop.gif",
  ":rip:" => "rip.gif",
  ":whip:" => "whip.gif",
  ":judge:" => "judge.gif",
  ":chair:" => "chair.gif",
  ":tease:" => "tease.gif",
  ":box:" => "box.gif",
  ":boxing:" => "boxing.gif",
  ":guns:" => "guns.gif",
  ":shoot:" => "shoot.gif",
  ":shoot2:" => "shoot2.gif",
  ":flowers:" => "flowers.gif",
  ":wub:" => "wub.gif",
  ":lovers:" => "lovers.gif",
  ":kissing:" => "kissing.gif",
  ":kissing2:" => "kissing2.gif",
  ":console:" => "console.gif",
  ":group:" => "group.gif",
  ":hump:" => "hump.gif",
  ":hooray:" => "hooray.gif",
  ":happy2:" => "happy2.gif",
  ":clap:" => "clap.gif",
  ":clap2:" => "clap2.gif",
        ":weirdo:" => "weirdo.gif",
  ":yawn:" => "yawn.gif",
  ":bow:" => "bow.gif",
        ":dawgie:" => "dawgie.gif",
        ":cylon:" => "cylon.gif",
  ":book:" => "book.gif",
  ":fish:" => "fish.gif",
  ":mama:" => "mama.gif",
  ":pepsi:" => "pepsi.gif",
  ":medieval:" => "medieval.gif",
  ":rambo:" => "rambo.gif",
  ":ninja:" => "ninja.gif",
  ":hannibal:" => "hannibal.gif",
  ":party:" => "party.gif",
  ":snorkle:" => "snorkle.gif",
  ":evo:" => "evo.gif",
  ":king:" => "king.gif",
  ":chef:" => "chef.gif",
  ":mario:" => "mario.gif",
  ":pope:" => "pope.gif",
  ":fez:" => "fez.gif",
  ":cap:" => "cap.gif",
  ":cowboy:" => "cowboy.gif",
  ":pirate:" => "pirate.gif",
  ":pirate2:" => "pirate2.gif",
  ":rock:" => "rock.gif",
  ":cigar:" => "cigar.gif",
  ":icecream:" => "icecream.gif",
  ":oldtimer:" => "oldtimer.gif",
        ":trampoline:" => "trampoline.gif",
        ":banana:" => "bananadance.gif",
  ":smurf:" => "smurf.gif",
  ":yikes:" => "yikes.gif",
  ":osama:" => "osama.gif",
  ":saddam:" => "saddam.gif",
  ":santa:" => "santa.gif",
  ":indian:" => "indian.gif",
  ":pimp:" => "pimp.gif",
  ":nuke:" => "nuke.gif",
  ":jacko:" => "jacko.gif",
  ":ike:" => "ike.gif",
  ":greedy:" => "greedy.gif",
        ":super:" => "super.gif",
  ":wolverine:" => "wolverine.gif",
  ":spidey:" => "spidey.gif",
  ":spider:" => "spider.gif",
  ":bandana:" => "bandana.gif",
  ":construction:" => "construction.gif",
  ":sheep:" => "sheep.gif",
  ":police:" => "police.gif",
        ":detective:" => "detective.gif",
  ":bike:" => "bike.gif",
        ":fishing:" => "fishing.gif",
  ":clover:" => "clover.gif",
  ":horse:" => "horse.gif",
  ":shit:" => "shit.gif",
  ":soldiers:" => "soldiers.gif",
);

$privatesmilies = array(
  ":)" => "smile1.gif",
//  ";)" => "wink.gif",
  ":wink:" => "wink.gif",
  ":D" => "grin.gif",
  ":P" => "tongue.gif",
  ":(" => "sad.gif",
  ":'(" => "cry.gif",
  ":|" => "noexpression.gif",
  // "8)" => "cool1.gif",   we don't want this as a smilie...
  ":Boozer:" => "alcoholic.gif",
  ":deadhorse:" => "deadhorse.gif",
  ":spank:" => "spank.gif",
  ":yoji:" => "yoji.gif",
  ":locked:" => "locked.gif",
  ":grrr:" => "angry.gif",                         // legacy
  "O:-" => "innocent.gif",                        // legacy
  ":sleeping:" => "sleeping.gif",        // legacy
  "-_-" => "unsure.gif",                        // legacy
  ":clown:" => "clown.gif",
  ":mml:" => "mml.gif",
  ":rtf:" => "rtf.gif",
  ":morepics:" => "morepics.gif",
  ":rb:" => "rb.gif",
  ":rblocked:" => "rblocked.gif",
  ":maxlocked:" => "maxlocked.gif",
  ":hslocked:" => "hslocked.gif",
);

// Set this to the line break character sequence of your system
$linebreak = "\r\n";
function get_seed_time($st)
{
$secs = $st;
$mins = floor($st / 60);
$hours = floor($mins / 60);
$days = floor($hours / 24);
$week = floor($days / 7);
$month = floor($week / 4);

if ($month > 0) {
$week_elapsed = floor(($st - ($month * 4 * 7 * 24 * 60 * 60)) / (7 * 24 * 60 * 60));
$days_elapsed = floor(($st - ($week * 7 * 24 * 60 * 60)) / (24 * 60 * 60));
$hours_elapsed = floor(($st - ($days * 24 * 60 * 60)) / (60 * 60));
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "<font color=#FFFFFF><b>$month months. $week_elapsed weeks. $days_elapsed days. $hours_elapsed hours. $mins_elapsed minutes. $secs_elapsed Sec.</b></font>";
}
if ($week > 0) {
$days_elapsed = floor(($st - ($week * 7 * 24 * 60 * 60)) / (24 * 60 * 60));
$hours_elapsed = floor(($st - ($days * 24 * 60 * 60)) / (60 * 60));
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "<font color=#BA7D58><b>$week weeks. $days_elapsed days. $hours_elapsed hours. $mins_elapsed minutes. $secs_elapsed Sec.</b></font>";
}
if ($days > 0) {
$hours_elapsed = floor(($st - ($days * 24 * 60 * 60)) / (60 * 60));
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "<font color=#0057E7><b>$days days. $hours_elapsed hours. $mins_elapsed minutes. $secs_elapsed sec.</b></font>";
}
if ($hours > 0) {
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "<font color=#2A9C02><b>$hours hours. $mins_elapsed minutes. $secs_elapsed Seconds.</b></font>";
}
if ($mins > 0) {
$secs_elapsed = floor($st - $mins * 60);
return "<font color=#C2A900><b>$mins minutes. $secs_elapsed Sec.</b></font>";
}
if ($secs > 0) {
return "$secs Sec.";
}
return "<font color=red><b>0 Sec.</b></font>";
}
function parse_image($image) {
    $image = str_replace( " ", "%20", $image );

    $maxwidth = 620;
    $img_info = getimagesize($image);
    $alt = "Image is resized, click for full size.";

    if ($img_info[0] >  $maxwidth)
        return "<font size=\"1\"><strong>$alt</strong></font>\n<a href='$image' target='_blank'><img width='$maxwidth' src='$image' border='0' alt='$alt' /></a><br />";
    
    return "<img src='$image' border='0'/>";
} 

function get_row_count($table, $suffix = "")
{
  if ($suffix)
    $suffix = " $suffix";
  ($r = mysql_query("SELECT COUNT(*) FROM $table$suffix")) or die(mysql_error());
  ($a = mysql_fetch_row($r)) or die(mysql_error());
  return $a[0];
}

function stdmsg($heading, $text)
{
  print("<table class=main width=750 border=0 cellpadding=0 cellspacing=0><tr><td class=embedded>\n");
  if ($heading)
    print("<h2>$heading</h2>\n");
  print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n");
  print($text . "</td></tr></table></td></tr></table>\n");
}


function stderr($heading, $text)
{
  stdhead();
  stdmsg($heading, $text);
  stdfoot();
  die;
}

function sqlerr($file = '', $line = '')
{
  print("<table border=0 bgcolor=blue align=left cellspacing=0 cellpadding=10 style='background: blue'>" .
    "<tr><td class=embedded><font color=white><h1>SQL Error</h1>\n" .
  "<b>" . htmlspecialchars(mysql_error()) . ($file != '' && $line != '' ? "<p>in $file, line $line</p>" : "") . "</b></font></td></tr></table>");
  die;
}

// Returns the current time in GMT in MySQL compatible format.
function get_date_time($timestamp = 0)
{
  if ($timestamp)
    return date("Y-m-d H:i:s", $timestamp);
  else
    return gmdate("Y-m-d H:i:s");
}

function encodehtml($s, $linebreaks = true)
{
  $s = str_replace("<", "&lt;", str_replace("&", "&amp;", $s));
  if ($linebreaks)
    $s = nl2br($s);
  return $s;
}

function get_dt_num()
{
  return gmdate("YmdHis");
}

function format_urls($s)
{
return preg_replace(
   "/(\A|[^=\]'\"a-zA-Z0-9])((http|ftp|https|ftps|irc):\/\/[^<>\s]+)/i",
   "\\1<a target=_blank href=redir.php?url=\\2>\\2</a>", $s);
   }

function format_local_urls($s)
{
        return preg_replace(
    "/(<a href=redir\.php\?url=)((http|ftp|https|ftps|irc):\/\/(www\.)?torrentbits\.(net|org|com)(:8[0-3])?([^<>\s]*))>([^<]+)<\/a>/i",
    "<a href=\\2>\\8</a>", $s);
}

//Finds last occurrence of needle in haystack
//in PHP5 use strripos() instead of this
function _strlastpos ($haystack, $needle, $offset = 0)
{
        $addLen = strlen ($needle);
        $endPos = $offset - $addLen;
        while (true)
        {
                if (($newPos = strpos ($haystack, $needle, $endPos + $addLen)) === false) break;
                $endPos = $newPos;
        }
        return ($endPos >= 0) ? $endPos : false;
}

function format_quotes($s)
{
   preg_match_all('/\\[quote.*?\\]/', $s, $result, PREG_PATTERN_ORDER);
$openquotecount = count($openquote = $result[0]);
   preg_match_all('/\\[\/quote\\]/', $s, $result, PREG_PATTERN_ORDER);
$closequotecount = count($closequote = $result[0]);

   if ($openquotecount != $closequotecount) return $s; // quote mismatch. Return raw string...

   // Get position of opening quotes
$openval = array();
   $pos = -1;

   foreach($openquote as $val)
 $openval[] = $pos = strpos($s,$val,$pos+1);

   // Get position of closing quotes
   $closeval = array();
   $pos = -1;

   foreach($closequote as $val)
    $closeval[] = $pos = strpos($s,$val,$pos+1);


   for ($i=0; $i < count($openval); $i++)
 if ($openval[$i] > $closeval[$i]) return $s; // Cannot close before opening. Return raw string...


$s = str_replace("[quote]","<p class=sub><b>Quote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>",$s);
   $s = preg_replace("/\\[quote=(.+?)\\]/", "<p class=sub><b>\\1 wrote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>", $s);
   $s = str_replace("[/quote]","</td></tr></table><br>",$s);
   return $s;
}

function format_comment($text, $strip_html = true)
{
        global $smilies, $privatesmilies;

        $s = $text;

  // This fixes the extraneous ;) smilies problem. When there was an html escaped
  // char before a closing bracket - like >), "), ... - this would be encoded
  // to &xxx;), hence all the extra smilies. I created a new :wink: label, removed
  // the ;) one, and replace all genuine ;) by :wink: before escaping the body.
  // (What took us so long? :blush:)- wyz

        $s = str_replace(";)", ":wink:", $s);

        if ($strip_html)
                $s = htmlspecialchars($s);

        // [*]
        $s = preg_replace("/\[\*\]/", "<img src=\"".$GLOBALS['pic_base_url']."/list.gif\" class=\"listitem\" />", $s);

        // [b]Bold[/b]
        $s = preg_replace("/\[b\]((\s|.)+?)\[\/b\]/", "<b>\\1</b>", $s);

        // [i]Italic[/i]
        $s = preg_replace("/\[i\]((\s|.)+?)\[\/i\]/", "<i>\\1</i>", $s);

        // [u]Underline[/u]
        $s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/", "<u>\\1</u>", $s);

        // [u]Underline[/u]
        $s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/i", "<u>\\1</u>", $s);

//---------------------------------
//---- Image Resizer v0.1 by xam
//---------------------------------

        // [img]http://www/image.gif[/img]
        $s = preg_replace("/\[img\](http:\/\/[^\s'\"<>]+(\.(jpg|gif|png)))\[\/img\]/i", "<img border=\"0\" src=\"\\1\" alt=\"\" onload=\"NcodeImageResizer.createOn(this);\">", $s);

        // [img=http://www/image.gif]
        $s = preg_replace("/\[img=(http:\/\/[^\s'\"<>]+(\.(gif|jpg|png)))\]/i", "<img border=\"0\" src=\"\\1\" alt=\"\"  onload=\"NcodeImageResizer.createOn(this);\">", $s);

//---------------------------------
//---- Image Resizer v0.1 by xam
//---------------------------------

        // [color=blue]Text[/color]
        $s = preg_replace(
                "/\[color=([a-zA-Z]+)\]((\s|.)+?)\[\/color\]/i",
                "<font color=\\1>\\2</font>", $s);

        // [color=#ffcc99]Text[/color]
        $s = preg_replace(
                "/\[color=(#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])\]((\s|.)+?)\[\/color\]/i",
                "<font color=\\1>\\2</font>", $s);

        // [url=http://www.example.com]Text[/url]
        $s = preg_replace(
                "/\[url=([^()<>\s]+?)\]((\s|.)+?)\[\/url\]/i",
                "<a href=\"\\1\">\\2</a>", $s);

        // [url]http://www.example.com[/url]
        $s = preg_replace(
                "/\[url\]([^()<>\s]+?)\[\/url\]/i",
                "<a href=\"\\1\">\\1</a>", $s);

        // [size=4]Text[/size]
        $s = preg_replace(
                "/\[size=([1-7])\]((\s|.)+?)\[\/size\]/i",
                "<font size=\\1>\\2</font>", $s);

        // [font=Arial]Text[/font]
        $s = preg_replace(
                "/\[font=([a-zA-Z ,]+)\]((\s|.)+?)\[\/font\]/i",
                "<font face=\"\\1\">\\2</font>", $s);

//  //[quote]Text[/quote]
//  $s = preg_replace(
//    "/\[quote\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
//    "<p class=sub><b>Quote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\1</td></tr></table><br>", $s);

//  //[quote=Author]Text[/quote]
//  $s = preg_replace(
//    "/\[quote=(.+?)\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
//    "<p class=sub><b>\\1 wrote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\2</td></tr></table><br>", $s);

        // Quotes
        $s = format_quotes($s);

       // URLs
       $s = preg_replace('=([^\s]*)(www\.)=', ' http://www.', $s);
       $s = format_urls($s);

        // Linebreaks
        $s = nl2br($s);

        // [pre]Preformatted[/pre]
        $s = preg_replace("/\[pre\]((\s|.)+?)\[\/pre\]/i", "<tt><nobr>\\1</nobr></tt>", $s);

        // [nfo]NFO-preformatted[/nfo]
        $s = preg_replace("/\[nfo\]((\s|.)+?)\[\/nfo\]/i", "<tt><nobr><font face='MS Linedraw' size=2 style='font-size: 10pt; line-height: " .
                "10pt'>\\1</font></nobr></tt>", $s);

        // Maintain spacing
        $s = str_replace("  ", " &nbsp;", $s);

        reset($smilies);
        while (list($code, $url) = each($smilies))
                $s = str_replace($code, "<img border=0 src=\"/pic/smilies/$url\" alt=\"" . htmlspecialchars($code) . "\">", $s);

        reset($privatesmilies);
        while (list($code, $url) = each($privatesmilies))
                $s = str_replace($code, "<img border=0 src=\"/pic/smilies/$url\">", $s);

        $s = preg_replace(
        "/\[email\]([^()<>\s]+?)\[\/email\]/i",
        "<a href=mailto:\\1>\\1</a>", $s);

        // Video tag [video=url]

        // YouTube Vids
        $s = preg_replace("/\[video=[^\s'\"<>]*youtube.com.*v=([^\s'\"<>]+)\]/ims", "<object width=\"500\" height=\"410\"><param name=\"movie\" value=\"http://www.youtube.com/v/\\1\"></param><embed src=\"http://www.youtube.com/v/\\1\" type=\"application/x-shockwave-flash\" width=\"500\" height=\"410\"></embed></object>", $s);
        // Google Vids
        $s = preg_replace("/\[video=[^\s'\"<>]*video.google.com.*docid=(-?[0-9]+).*\]/ims", "<embed style=\"width:500px; height:410px;\" id=\"VideoPlayback\" align=\"middle\" type=\"application/x-shockwave-flash\" src=\"http://video.google.com/googleplayer.swf?docId=\\1\" allowScriptAccess=\"sameDomain\" quality=\"best\" bgcolor=\"#ffffff\" scale=\"noScale\" wmode=\"window\" salign=\"TL\"  FlashVars=\"playerMode=embedded\"> </embed>", $s);

        // [flash=] Tag by Nazaret2005

        $s = preg_replace("/\[flash\]([^()<>\s]+?)\[\/flash\]/i","<object><param name=movie value=\\1/><embed width=470 height=310 src=\\1></embed></object>", $s);

        // [audio] Tag by FuNk1Y

        $s = preg_replace("/\[audio\]([^()<>\s]+?)\[\/audio\]/i","<embed type=application/x-mplayer2 name=MediaPlayer1 width=300 height=68 autostart=0 showcontrols=1 showstatusbar=1 showaudiocontrols=1 showpositioncontrols=1 align=bottom volume=10 src=\\1></embed>", $s);

        $s = preg_replace( "#<(\s+?)?s(\s+?)?c(\s+?)?r(\s+?)?i(\s+?)?p(\s+?)?t#is", "&lt;script" , $s );
        $s = preg_replace( "#<(\s+?)?/(\s+?)?s(\s+?)?c(\s+?)?r(\s+?)?i(\s+?)?p(\s+?)?t#is", "&lt;/script", $s );
        $s = preg_replace( "/javascript/i" , "j&#097;v&#097;script", $s );
        $s = preg_replace( "/alert/i"      , "&#097;lert", $s );
        $s = preg_replace( "/about:/i"     , "&#097;bout:", $s );
        $s = preg_replace( "/onmouseover/i", "&#111;nmouseover", $s );
        $s = preg_replace( "/onclick/i"    , "&#111;nclick", $s );
        $s = preg_replace( "/onload/i"     , "&#111;nload", $s );
        $s = preg_replace( "/onsubmit/i"   , "&#111;nsubmit", $s );
        $s = preg_replace( "/<body/i"      , "&lt;body", $s );
        $s = preg_replace( "/<html/i"      , "&lt;html", $s );
        $s = preg_replace( "/document\./i" , "&#100;ocument.", $s );

        return $s;
}

define ('UC_USER', 0);
define ('UC_POWER_USER', 1);
define ('UC_VIP', 2);
define ('UC_UPLOADER', 3);
define ('UC_POWERUPLOADER', 4);
define ('UC_MODERATOR', 5);
define ('UC_ADMINISTRATOR', 6);
define ('UC_SYSOP', 7);
define ('UC_OWNER', 8);
define ('UC_SL', 9);


function get_user_class()
{
  global $CURUSER;
  return $CURUSER["class"];
}

function get_user_class_name($class)
{
  switch ($class)
  {
    case UC_USER: return "User";
    case UC_POWER_USER: return "Power User";
    case UC_VIP: return "VIP";
    case UC_UPLOADER: return "Uploader";
    case UC_POWERUPLOADER: return "Power Uploader";
    case UC_MODERATOR: return "Moderator";
    case UC_ADMINISTRATOR: return "Administrator";
    case UC_SYSOP: return "SysOp";
    case UC_OWNER: return "Owner";
    case UC_SL: return "Staff Leader";

  }
  return "";
}

function is_valid_user_class($class)
{
  return is_numeric($class) && floor($class) == $class && $class >= UC_USER && $class <= UC_SL;
}

function is_valid_id($id)
{
  return is_numeric($id) && ($id > 0) && (floor($id) == $id);
}

// Returns the current time in GMT in MySQL compatible format.
function display_date_time($timestamp = 0)
{
if ($timestamp)
   return date("Y-m-d H:i:s", $timestamp);
else
   return gmdate("Y-m-d H:i:s");
}

  //-------- Begins a main frame

  function begin_main_frame()
  {
    print("<table class=main width=750 border=0 cellspacing=0 cellpadding=0>" .
      "<tr><td class=embedded>\n");
  }

  //-------- Ends a main frame

  function end_main_frame()
  {
    print("</td></tr></table>\n");
  }

  function begin_frame($caption = "", $center = false, $padding = 10)
  {
    $tdextra = "";

    if ($caption)
      print("<h2>$caption</h2>\n");

    if ($center)
      $tdextra .= " align=center";

    print("<table width=100% border=1 cellspacing=0 cellpadding=$padding><tr><td$tdextra>\n");

  }

  function attach_frame($padding = 10)
  {
    print("</td></tr><tr><td style='border-top: 0px'>\n");
  }

  function end_frame()
  {
    print("</td></tr></table>\n");
  }

  function begin_table($fullwidth = false, $padding = 5)
  {
    $width = "";

    if ($fullwidth)
      $width .= " width=100%";
    print("<table class=main$width border=1 cellspacing=0 cellpadding=$padding>\n");
  }

  function end_table()
  {
    print("</td></tr></table>\n");
  }

  //-------- Inserts a smilies frame
  //         (move to globals)

  function insert_smilies_frame()
  {
    global $smilies, $BASEURL;

    begin_frame("Smilies", true);

    begin_table(false, 5);

    print("<tr><td class=colhead>Type...</td><td class=colhead>To make a...</td></tr>\n");

    while (list($code, $url) = each($smilies))
      print("<tr><td>$code</td><td><img src=$BASEURL/pic/smilies/$url></td>\n");

    end_table();

    end_frame();
  }


function sql_timestamp_to_unix_timestamp($s)
{
  return mktime(substr($s, 11, 2), substr($s, 14, 2), substr($s, 17, 2), substr($s, 5, 2), substr($s, 8, 2), substr($s, 0, 4));
}

  function get_ratio_color($ratio)
  {
    if ($ratio < 0.1) return "#ff0000";
    if ($ratio < 0.2) return "#ee0000";
    if ($ratio < 0.3) return "#dd0000";
    if ($ratio < 0.4) return "#cc0000";
    if ($ratio < 0.5) return "#bb0000";
    if ($ratio < 0.6) return "#aa0000";
    if ($ratio < 0.7) return "#990000";
    if ($ratio < 0.8) return "#880000";
    if ($ratio < 0.9) return "#770000";
    if ($ratio < 1) return "#660000";
        if (($ratio >= 1.0) && ($ratio < 2.0)) return "#006600";
    if (($ratio >= 2.0) && ($ratio < 3.0)) return "#007700";
    if (($ratio >= 3.0) && ($ratio < 4.0)) return "#008800";
    if (($ratio >= 4.0) && ($ratio < 5.0)) return "#009900";
    if (($ratio >= 5.0) && ($ratio < 6.0)) return "#00aa00";
    if (($ratio >= 6.0) && ($ratio < 7.0)) return "#00bb00";
    if (($ratio >= 7.0) && ($ratio < 8.0)) return "#00cc00";
    if (($ratio >= 8.0) && ($ratio < 9.0)) return "#00dd00";
    if (($ratio >= 9.0) && ($ratio < 10.0)) return "#00ee00";
    if ($ratio >= 10) return "#00ff00";
    return "#000000";
  }

  function get_slr_color($ratio)
  {
    if ($ratio < 0.025) return "#ff0000";
    if ($ratio < 0.05) return "#ee0000";
    if ($ratio < 0.075) return "#dd0000";
    if ($ratio < 0.1) return "#cc0000";
    if ($ratio < 0.125) return "#bb0000";
    if ($ratio < 0.15) return "#aa0000";
    if ($ratio < 0.175) return "#990000";
    if ($ratio < 0.2) return "#880000";
    if ($ratio < 0.225) return "#770000";
    if ($ratio < 0.25) return "#660000";
    if ($ratio < 0.275) return "#550000";
    if ($ratio < 0.3) return "#440000";
    if ($ratio < 0.325) return "#330000";
    if ($ratio < 0.35) return "#220000";
    if ($ratio < 0.375) return "#110000";
    return "#000000";
  }

function write_log($text)
{
  $text = sqlesc($text);
  $added = sqlesc(get_date_time());
  mysql_query("INSERT INTO sitelog (added, txt) VALUES($added, $text)") or sqlerr(__FILE__, __LINE__);
}

function get_elapsed_time($ts)
{
  $mins = floor((gmtime() - $ts) / 60);
  $hours = floor($mins / 60);
  $mins -= $hours * 60;
  $days = floor($hours / 24);
  $hours -= $days * 24;
  $weeks = floor($days / 7);
  $days -= $weeks * 7;
  $t = "";
  if ($weeks > 0)
    return "$weeks week" . ($weeks > 1 ? "s" : "");
  if ($days > 0)
    return "$days day" . ($days > 1 ? "s" : "");
  if ($hours > 0)
    return "$hours hour" . ($hours > 1 ? "s" : "");
  if ($mins > 0)
    return "$mins min" . ($mins > 1 ? "s" : "");
  return "< 1 min";
}

function auto_enter_cheater($userid, $rate, $upthis, $diff, $torrentid, $client, $ip, $last_up)
{
    mysql_query("INSERT INTO cheaters (added, userid, client, rate, beforeup, upthis, timediff, userip, torrentid) VALUES('" . get_date_time() . "', $userid, '$client', '$rate', '$last_up', '$upthis', '$diff', '$ip', '$torrentid')") or sqlerr(__FILE__, __LINE__);
}

function textbbcode($form,$text,$content="") {
?>
<script language=javascript>
var b_open = 0;
var i_open = 0;
var u_open = 0;
var color_open = 0;
var list_open = 0;
var quote_open = 0;
var html_open = 0;

var myAgent = navigator.userAgent.toLowerCase();
var myVersion = parseInt(navigator.appVersion);

var is_ie = ((myAgent.indexOf("msie") != -1) && (myAgent.indexOf("opera") == -1));
var is_nav = ((myAgent.indexOf('mozilla')!=-1) && (myAgent.indexOf('spoofer')==-1)
&& (myAgent.indexOf('compatible') == -1) && (myAgent.indexOf('opera')==-1)
&& (myAgent.indexOf('webtv') ==-1) && (myAgent.indexOf('hotjava')==-1));

var is_win = ((myAgent.indexOf("win")!=-1) || (myAgent.indexOf("16bit")!=-1));
var is_mac = (myAgent.indexOf("mac")!=-1);
var bbtags = new Array();
function cstat() {
var c = stacksize(bbtags);
if ( (c < 1) || (c == null) ) {c = 0;}
if ( ! bbtags[0] ) {c = 0;}
document.<?=$form?>.tagcount.value = "Close last, Open tags "+c;
}
function stacksize(thearray) {
for (i = 0; i < thearray.length; i++ ) {
if ( (thearray[i] == "") || (thearray[i] == null) || (thearray == 'undefined') ) {return i;}
}
return thearray.length;
}
function pushstack(thearray, newval) {
arraysize = stacksize(thearray);
thearray[arraysize] = newval;
}
function popstackd(thearray) {
arraysize = stacksize(thearray);
theval = thearray[arraysize - 1];
return theval;
}
function popstack(thearray) {
arraysize = stacksize(thearray);
theval = thearray[arraysize - 1];
delete thearray[arraysize - 1];
return theval;
}
function closeall() {
if (bbtags[0]) {
while (bbtags[0]) {
tagRemove = popstack(bbtags)
if ( (tagRemove != 'color') ) {
doInsert("[/"+tagRemove+"]", "", false);
eval("document.<?=$form?>." + tagRemove + ".value = ' " + tagRemove + " '");
eval(tagRemove + "_open = 0");
} else {
doInsert("[/"+tagRemove+"]", "", false);
}
cstat();
return;
}
}
document.<?=$form?>.tagcount.value = "Close last, Open tags 0";
bbtags = new Array();
document.<?=$form?>.<?=$text?>.focus();
}
function add_code(NewCode) {
document.<?=$form?>.<?=$text?>.value += NewCode;
document.<?=$form?>.<?=$text?>.focus();
}
function alterfont(theval, thetag) {
if (theval == 0) return;
if(doInsert("[" + thetag + "=" + theval + "]", "[/" + thetag + "]", true)) pushstack(bbtags, thetag);
document.<?=$form?>.color.selectedIndex = 0;
cstat();
}
function tag_url() {
var FoundErrors = '';
var enterURL = prompt("You must enter a URL", "http://");
var enterTITLE = prompt("You must enter a title", "");
if (!enterURL || enterURL=="") {FoundErrors += " " + "You must enter a URL,";}
if (!enterTITLE) {FoundErrors += " " + "You must enter a title";}
if (FoundErrors) {alert("Error!"+FoundErrors);return;}
doInsert("[url="+enterURL+"]"+enterTITLE+"[/url]", "", false);
}
function tag_list() {
var FoundErrors = '';
var enterTITLE = prompt("Enter item of the list. For end of the list, press 'cancel' or leave the next field empty ", "");
if (!enterTITLE) {FoundErrors += " " + "Enter item of the list. For end of the list, press 'cancel' or leave the next field empty";}
if (FoundErrors) {alert("Error!"+FoundErrors);return;}
doInsert("[*]"+enterTITLE+"", "", false);

}
function tag_image() {
var FoundErrors = '';
var enterURL = prompt("You must enter a full image URL", "http://");
if (!enterURL || enterURL=="http://") {
alert("Error!"+"You must enter a full image URL");
return;
}
doInsert("[img]"+enterURL+"[/img]", "", false);
}
function tag_email() {
var emailAddress = prompt("You must enter a E-mail", "");
if (!emailAddress) {
alert("Error!"+"You must enter a E-mail");
return;
}
doInsert("[email]"+emailAddress+"[/email]", "", false);
}
function doInsert(ibTag, ibClsTag, isSingle)
{
var isClose = false;
var obj_ta = document.<?=$form?>.<?=$text?>;
if ( (myVersion >= 4) && is_ie && is_win) {
if(obj_ta.isTextEdit){
obj_ta.focus();
var sel = document.selection;
var rng = sel.createRange();
rng.colapse;
if((sel.type == "Text" || sel.type == "None") && rng != null){
if(ibClsTag != "" && rng.text.length > 0)
ibTag += rng.text + ibClsTag;
else if(isSingle) isClose = true;
rng.text = ibTag;
}
}
else{
if(isSingle) isClose = true;
obj_ta.value += ibTag;
}
} else {
if(isSingle) isClose = true;
obj_ta.value += ibTag;
}
obj_ta.focus();
// obj_ta.value = obj_ta.value.replace(/ /, " ");
return isClose;
}
function em(theSmilie)
{
doInsert(" " + theSmilie + " ", "", false);
}

function winop()
{
windop = window.open("moresmiles.php?form=<?=$form?>&text=<?=$text?>","mywin","height=400,width=450,resizable=yes,scrollbars=yes");
}

function simpletag(thetag)
{
var tagOpen = eval(thetag + "_open");
if (tagOpen == 0) {
if(doInsert("[" + thetag + "]", "[/" + thetag + "]", true))
{
eval(thetag + "_open = 1");
eval("document.<?=$form?>." + thetag + ".value += '*'");
pushstack(bbtags, thetag);
cstat();
}
}
else {
lastindex = 0;
for (i = 0; i < bbtags.length; i++ ) {
if ( bbtags[i] == thetag ) {
lastindex = i;
}
}

while (bbtags[lastindex]) {
tagRemove = popstack(bbtags);
doInsert("[/" + tagRemove + "]", "", false)
if ((tagRemove != 'COLOR') ){
eval("document.<?=$form?>." + tagRemove + ".value = ' " + tagRemove + " '");
eval(tagRemove + "_open = 0");
}
}
cstat();
}
}
</script>
<?
print("<table width=600 cellspacing=0 cellpadding=5>\n");
?>
<td colSpan="2">
<table cellSpacing="1" cellPadding="2">
<tr>
<td class=embedded><input style="font-weight: bold;font-size:9px;" type=button name="b" value="B" onclick="javascript: simpletag('b')" /></td>
<td class=embedded><input class="codebuttons" style="font-style: italic;font-size:10px;" type=button name="i" value="I" onclick="javascript: simpletag('i')" /></td>
<td class=embedded><input class="codebuttons" style="text-decoration: underline;font-size:9px;" type=button name="u" value="U" onclick="javascript: simpletag('u')" /></td>
<td class=embedded><input class="codebuttons" style="font-size:10px;" type=button name='url' value='URL' onclick='tag_url()' />
<td class=embedded><input class="codebuttons" style="font-size:10px;" type=button name="IMG" value="IMG" onclick="javascript: tag_image()" /></td>
<td class=embedded><input type=button style="font-size:9px;" name="list" value="List" onclick="tag_list()" /></td>
<td class=embedded><input class="codebuttons" style="font-size:10px;" type=button name="quote" value="Quote" onclick="javascript: simpletag('quote')" /></td>
<td class=embedded><input style="width:180" style="font-size:9px;" type=button onclick='javascript:closeall();' name='tagcount' value="Close all tags">
</table>
</td>
<table width=600 cellspacing=0 cellpadding=5>
<td colSpan="2">
<table cellSpacing="1" cellPadding="2">
<tr>
<td class=embedded><select name='color' class='codebuttons' onchange="alterfont(this.options[this.selectedIndex].value, 'color')">
<option value='0'>------ Color -------</option>
<option style="BACKGROUND-COLOR: black" value="Black">Black
</option>
<option style="BACKGROUND-COLOR: sienna" value="Sienna">
Sienna</option>
<option style="BACKGROUND-COLOR: darkolivegreen" value="DarkOliveGreen">
Dark Olive Green</option>
<option style="BACKGROUND-COLOR: darkgreen" value="DarkGreen">
Dark Green</option>
<option style="BACKGROUND-COLOR: darkslateblue" value="DarkSlateBlue">
Dark Slate Blue</option>
<option style="BACKGROUND-COLOR: navy" value="Navy">Navy
</option>
<option style="BACKGROUND-COLOR: indigo" value="Indigo">
Indigo</option>
<option style="BACKGROUND-COLOR: darkslategray" value="DarkSlateGray">
Dark Slate Gray</option>
<option style="BACKGROUND-COLOR: darkred" value="DarkRed">
Dark Red</option>
<option style="BACKGROUND-COLOR: darkorange" value="DarkOrange">
Dark Orange</option>
<option style="BACKGROUND-COLOR: olive" value="Olive">Olive
</option>
<option style="BACKGROUND-COLOR: green" value="Green">Green
</option>
<option style="BACKGROUND-COLOR: teal" value="Teal">Teal
</option>
<option style="BACKGROUND-COLOR: blue" value="Blue">Blue
</option>
<option style="BACKGROUND-COLOR: slategray" value="SlateGray">
Slate Gray</option>
<option style="BACKGROUND-COLOR: dimgray" value="DimGray">
Dim Gray</option>
<option style="BACKGROUND-COLOR: red" value="Red">Red
</option>
<option style="BACKGROUND-COLOR: sandybrown" value="SandyBrown">
Sandy Brown</option>
<option style="BACKGROUND-COLOR: yellowgreen" value="YellowGreen">
Yellow Green</option>
<option style="BACKGROUND-COLOR: seagreen" value="SeaGreen">
Sea Green</option>
<option style="BACKGROUND-COLOR: mediumturquoise" value="MediumTurquoise">
Medium Turquoise</option>
<option style="BACKGROUND-COLOR: royalblue" value="RoyalBlue">
Royal Blue</option>
<option style="BACKGROUND-COLOR: purple" value="Purple">
Purple</option>
<option style="BACKGROUND-COLOR: gray" value="Gray">Gray
</option>
<option style="BACKGROUND-COLOR: magenta" value="Magenta">
Magenta</option>
<option style="BACKGROUND-COLOR: orange" value="Orange">
Orange</option>
<option style="BACKGROUND-COLOR: yellow" value="Yellow">
Yellow</option>
<option style="BACKGROUND-COLOR: lime" value="Lime">Lime
</option>
<option style="BACKGROUND-COLOR: cyan" value="Cyan">Cyan
</option>
<option style="BACKGROUND-COLOR: deepskyblue" value="DeepSkyBlue">
Deep Sky Blue</option>
<option style="BACKGROUND-COLOR: darkorchid" value="DarkOrchid">
Dark Orchid</option>
<option style="BACKGROUND-COLOR: silver" value="Silver">
Silver</option>
<option style="BACKGROUND-COLOR: pink" value="Pink">Pink
</option>
<option style="BACKGROUND-COLOR: wheat" value="Wheat">Wheat
</option>
<option style="BACKGROUND-COLOR: lemonchiffon" value="LemonChiffon">
Lemon Chiffon</option>
<option style="BACKGROUND-COLOR: palegreen" value="PaleGreen">
Pale Green</option>
<option style="BACKGROUND-COLOR: paleturquoise" value="PaleTurquoise">
Pale Turquoise</option>
<option style="BACKGROUND-COLOR: lightblue" value="LightBlue">
Light Blue</option>
<option style="BACKGROUND-COLOR: plum" value="Plum">Plum
</option>
<option style="BACKGROUND-COLOR: white" value="White">White
</option>
</select>
<td class=embedded>
<select name='font' class='codebuttons' onchange="alterfont(this.options[this.selectedIndex].value, 'font')">
<option value='0'>--------- Font ---------</option>
<option value="Arial">Arial</option>
<option value="Arial Black">Arial Black</option>
<option value="Arial Narrow">Arial Narrow</option>
<option value="Book Antiqua">Book Antiqua</option>
<option value="Century Gothic">Century Gothic</option>
<option value="Comic Sans MS">Comic Sans MS</option>
<option value="Courier New">Courier New</option>
<option value="Fixedsys">Fixedsys</option>
<option value="Franklin Gothic Medium">Franklin Gothic
Medium</option>
<option value="Garamond">Garamond</option>
<option value="Georgia">Georgia</option>
<option value="Impact">Impact</option>
<option value="Lucida Console">Lucida Console</option>
<option value="Lucida Sans Unicode">Lucida Sans Unicode
</option>
<option value="Microsoft Sans Serif">Microsoft Sans Serif
</option>
<option value="Palatino Linotype">Palatino Linotype</option>
<option value="System">System</option>
<option value="Tahoma">Tahoma</option>
<option value="Times New Roman">Times New Roman</option>
<option value="Trebuchet MS">Trebuchet MS</option>
<option value="Verdana">Verdana</option>
</select>
<td class=embedded>
<select name='size' class='codebuttons' onchange="alterfont(this.options[this.selectedIndex].value, 'size')">
<option value='0'>- Size -</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
</select>
</select>
</table>
</td>
</tr>
<tr>
<td><textarea name="<?=$text?>" rows="15" cols="80"><? echo $content; ?></textarea>
</td>
<td>
<table cellSpacing="1" cellPadding="3">
<tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-)')">
<img border=0 src=pic/smilies/smile1.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':smile:')">
<img border=0 src=pic/smilies/smile2.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-D')">
<img border=0 src=pic/smilies/grin.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':w00t:')">
<img border=0 src=pic/smilies/w00t.gif width="18" height="20"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-P')">
<img border=0 src=pic/smilies/tongue.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(';-)')">
<img border=0 src=pic/smilies/wink.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-|')">
<img border=0 src=pic/smilies/noexpression.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-/')">
<img border=0 src=pic/smilies/confused.gif width="18" height="18"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-(')">
<img border=0 src=pic/smilies/sad.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':\'-(')">
<img border=0 src=pic/smilies/cry.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':-O')">
<img border=0 src=pic/smilies/ohmy.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em('|-)')">
<img border=0 src=pic/smilies/sleeping.gif width="20" height="27"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':innocent:')">
<img border=0 src=pic/smilies/innocent.gif width="18" height="22"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':unsure:')">
<img border=0 src=pic/smilies/unsure.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':closedeyes:')">
<img border=0 src=pic/smilies/closedeyes.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':cool:')">
<img border=0 src=pic/smilies/cool2.gif width="20" height="20"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':thumbsdown:')">
<img border=0 src=pic/smilies/thumbsdown.gif width="27" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':blush:')">
<img border=0 src=pic/smilies/blush.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':yes:')">
<img border=0 src=pic/smilies/yes.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':no:')">
<img border=0 src=pic/smilies/no.gif width="20" height="20"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':love:')">
<img border=0 src=pic/smilies/love.gif width="19" height="19"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':?:')">
<img border=0 src=pic/smilies/question.gif width="19" height="19"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':!:')">
<img border=0 src=pic/smilies/excl.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':idea:')">
<img border=0 src=pic/smilies/idea.gif width="19" height="19"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':arrow:')">
<img border=0 src=pic/smilies/arrow.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':arrow2:')">
<img border=0 src=pic/smilies/arrow2.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':hmm:')">
<img border=0 src=pic/smilies/hmm.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':hmmm:')">
<img border=0 src=pic/smilies/hmmm.gif width="25" height="23"></a></td></tr><tr>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':huh:')">
<img border=0 src=pic/smilies/huh.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':rolleyes:')">
<img border=0 src=pic/smilies/rolleyes.gif width="20" height="20"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':kiss:')">
<img border=0 src=pic/smilies/kiss.gif width="18" height="18"></a></td>
<td class=embedded style='padding: 2px; margin: 1px'><a href="javascript: em(':shifty:')">
<img border=0 src=pic/smilies/shifty.gif width="20" height="20"></a></td></tr>
<td class=embedded style='padding: 2px; margin: 1px' colspan="4" align="center">
</head>
<body bgcolor="#EDEDED" text="#000000" link="#000000" topmargin="0" leftmargin="0">
</table>
<center>
<a href="javascript:winop();">More Smiles</a>
</td></tr></table>
</td>
<?
}

?>