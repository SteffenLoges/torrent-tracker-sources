<?

$mysql_host = "localhost";
$mysql_user = "Username";
$mysql_pass = "password";
$mysql_db = "database";

?>