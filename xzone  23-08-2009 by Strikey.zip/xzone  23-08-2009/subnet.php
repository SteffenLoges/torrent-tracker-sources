<?
require "include/bittorrent.php";
dbconn();
loggedinorreturn();
function ratios($up,$down, $color = True)
{
if ($down > 0)
{
$r = number_format($up / $down, 2);
if ($color)
$r = "<font color=".get_ratio_color($r).">$r</font>";
}
else
if ($up > 0)
$r = "Inf.";
else
$r = "---";
return $r;
}
$mask = "255.255.255.0";
$tmpip = explode(".",$CURUSER["ip"]);
$ip = $tmpip[0].".".$tmpip[1].".".$tmpip[2].".0";
$regex = "/^(((1?\d{1,2})|(2[0-4]\d)|(25[0-5]))(\.\b|$)){4}$/";
if (substr($mask,0,1) == "/")
{
$n = substr($mask, 1, strlen($mask) - 1);
if (!is_numeric($n) or $n < 0 or $n > 32)
{
stdmsg("Error", "Bad subnet mask.");
stdfoot();
die();
}
else
$mask = long2ip(pow(2,32) - pow(2,32-$n));
}
elseif (!preg_match($regex, $mask))
{
stdmsg("Error", "Bad subnet mask.");
stdfoot();
die();
}
$res = mysql_query("select id,username,class,last_access,added,uploaded,downloaded from users where enabled='yes' and status='confirmed'  and id<>$CURUSER[id] and INET_ATON(ip) & INET_ATON('$mask') = INET_ATON('$ip') & INET_ATON('$mask')") or sqlerr();
if (mysql_num_rows($res)){
stdhead("Network neighbourhood");

print("<table border=1 cellspacing=0 cellpadding=5>\n");
print("<tr><td class=colhead colspan=8>:: Network neighbourhood</td></tr><tr><td colspan=8>These users are your network neighbours, which means you will have the highest speed downloading from them.</td></tr>");
print("<tr><td class=colhead align=left>Username</td>
<td class=colhead>Uploaded</td><td class=colhead>Downloaded</td>
<td class=colhead>Ratio</td><td class=colhead>Registered</td>
<td class=colhead>Last Access</td><td class=colhead align=left>Class</td>
<td class=colhead>IP</td></tr>\n");
while($arr=mysql_fetch_assoc($res)){
print("<tr><td align=left><b><a href=userdetails.php?id=$arr[id]>$arr[username]</a></b></td>
<td>".mksize($arr["uploaded"])."</td>
<td>".mksize($arr["downloaded"])."</td>
<td>".ratios($arr["uploaded"],$arr["downloaded"])."</td>
<td>$arr[added]</td><td>$arr[last_access]</td>
<td align=left>".get_user_class_name($arr["class"])."</td>
<td>".$tmpip[0].".".$tmpip[1].".".$tmpip[2].".*</td></tr>\n");
}
print("</table>");
stdfoot();}
else
stderr("Info","There's no network neighbours found.");
?> 