<?
require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();

$id = 0 + $_GET["id"];

if (!is_valid_id($id))
stderr("Error", "It appears that you have entered an invalid id.");

$res = mysql_query("SELECT id, name FROM torrents WHERE id = $id") or sqlerr();
$arr = mysql_fetch_assoc($res);

if (!$arr)
stderr("Error", "It appears that there is no torrent with that id.");

$res = mysql_query("SELECT COUNT(*) FROM snatched WHERE torrentid = $id") or sqlerr();
$row = mysql_fetch_row($res);
$count = $row[0];
$perpage = 100;

if (!$count)
stderr("No snatches", "It appears that there are currently no snatches for the torrent <a href=details.php?id=$arr[id]>$arr[name]</a>.");

list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, "?");

stdhead("Snatches");
print("<h1>Snatches for torrent <a href=details.php?id=$arr[id]>$arr[name]</a></h1>\n");
print("<h2>Currently $row[0] snatch".($row[0] == 1 ? "" : "es")."</h2>\n");
if ($count > $perpage)
print("$pagertop");
print("<table border=0 cellspacing=0 cellpadding=5>\n");
print("<tr>\n");
print("<td class=colhead align=left>Username</td>\n");
print("<td class=colhead align=center>Connectable</td>\n");
print("<td class=colhead align=right>Uploaded</td>\n");
print("<td class=colhead align=right>Upspeed</td>\n");
print("<td class=colhead align=right>Downloaded</td>\n");
print("<td class=colhead align=right>Downspeed</td>\n");
print("<td class=colhead align=right>Ratio</td>\n");
print("<td class=colhead align=right>Completed</td>\n");
print("<td class=colhead align=right>Seed time</td>\n");
print("<td class=colhead align=right>Leech time</td>\n");
print("<td class=colhead align=center>Last action</td>\n");
print("<td class=colhead align=center>Completed at</td>\n");
print("<td class=colhead align=center>Client</td>\n");
print("<td class=colhead align=center>Port</td>\n");
print("</tr>\n");

$res = mysql_query("SELECT s.*, size, username, parked, warned, enabled, donor FROM snatched AS s INNER JOIN users ON s.userid = users.id INNER JOIN torrents ON s.torrentid = torrents.id WHERE torrentid = $id ORDER BY complete_date DESC $limit") or sqlerr();
while ($arr = mysql_fetch_assoc($res)) {

$upspeed = ($arr["upspeed"] > 0 ? mksize($arr["upspeed"]) : ($arr["seedtime"] > 0 ? mksize($arr["uploaded"] / ($arr["seedtime"] + $arr["leechtime"])) : mksize(0)));
$downspeed = ($arr["downspeed"] > 0 ? mksize($arr["downspeed"]) : ($arr["leechtime"] > 0 ? mksize($arr["downloaded"] / $arr["leechtime"]) : mksize(0)));
$ratio = ($arr["downloaded"] > 0 ? number_format($arr["uploaded"] / $arr["downloaded"], 3) : ($arr["uploaded"] > 0 ? "Inf." : "---"));
$completed = sprintf("%.2f%%", 100 * (1 - ($arr["to_go"] / $arr["size"])));

print("<tr>\n");
print("<td align=left><a href=userdetails.php?id=$arr[userid]>$arr[username]</a>".get_user_icons($arr)."</td>\n");
print("<td align=center>".($arr["connectable"] == "yes" ? "<font color=green>Yes</font>" : "<font color=red>No</font>")."</td>\n");
print("<td align=right>".mksize($arr["uploaded"])."</td>\n");
print("<td align=right>$upspeed/s</td>\n");
print("<td align=right>".mksize($arr["downloaded"])."</td>\n");
print("<td align=right>$downspeed/s</td>\n");
print("<td align=right>$ratio</td>\n");
print("<td align=right>$completed</td>\n");
print("<td align=right>".mkprettytime($arr["seedtime"])."</td>\n");
print("<td align=right>".mkprettytime($arr["leechtime"])."</td>\n");
print("<td align=center>$arr[last_action]</td>\n");
print("<td align=center>".($arr["complete_date"] == "0000-00-00 00:00:00" ? "Not completed" : $arr["complete_date"])."</td>\n");
print("<td align=center>$arr[agent]</td>\n");
print("<td align=center>$arr[port]</td>\n");
print("</tr>\n");
}
print("</table>\n");
if ($count > $perpage)
print("$pagerbottom");
stdfoot();
?>