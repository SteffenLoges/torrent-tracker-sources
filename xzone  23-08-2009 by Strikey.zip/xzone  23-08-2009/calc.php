
<?php
require 'include/bittorrent.php';
dbconn();
loggedinorreturn();
stdhead("BW Calculator");
if($CURUSER['class'] < UC_MODERATOR){
header("Location: 404.php");}
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
if(isset($_POST['value']))
{
if(isset($_POST['size']))
{
$values = Convert_to_bytes($_POST["value"], $_POST["size"], true);
?>
<table width="1%" border="0" cellpadding="5" cellspacing="1" cellpadding="0" align="center" >
<tr>
<td colspan="3" align="center" nowrap ><b>Coversion Result</b></td>
</tr>
<tr>
<td align="right" nowrap ><b>Bytes</b></td>
<td align="center" nowrap width="1%">=</td>
<td align="left" nowrap ><? echo $values[0];?></td>
</tr>
<tr>
<td align="right" nowrap ><b>KiloBytes</b></td>
<td align="center" nowrap width="1%">=</td>
<td align="left" nowrap ><? echo $values[1];?></td>
</tr>

<tr>
<td align="right" nowrap ><b>MegaBytes</b></td>
<td align="center" nowrap width="1%">=</td>
<td align="left" nowrap ><? echo $values[2];?></td>
</tr>
<tr>
<td align="right" nowrap ><b>GigaBytes</b></td>

<td align="center" nowrap width="1%">=</td>
<td align="left" nowrap ><? echo $values[3];?></td>
</tr>
<tr>
<td align="right" nowrap ><b>TeraBytes</b></td>
<td align="center" nowrap width="1%">=</td>
<td align="left" nowrap ><? echo $values[4];?></td>

</tr>
</table>
<br>
<?
}
else{
stderr("Error", "Missing post data");
}
}
else{
stderr("Error", "Missing post data");
}

?>

<?
}
?>

<p align=center> Get the value of this in B, KB, MB, GB, and TB </p>
<form method=post action=calc.php name=calc>
<input name=value type=text size=10 value="">&nbsp;<select name=size>
<option value="b">Bytes</option>
<option value="k">KiloBytes</option>
<option value="m">MegaBytes</option>
<option value="g">GigaBytes</option>
<option value="t">TeraBytes</option>
</select>
<br />
<input type=submit value='Do It' />
</form>

<?
stdfoot();
?>