<?
require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();
if (ereg("^[0-9]+$", !$id))
stderr("Error", "Hmmmmm?!");

if (get_user_class() >= UC_MODERATOR OR $CURUSER[id] == "$id")
{  
   $deadtime = deadtime();
   mysql_query("DELETE FROM peers WHERE last_action < FROM_UNIXTIME($deadtime) AND userid=" . $id) or sqlerr(__FILE__,__LINE__);
   $effected = mysql_affected_rows();
   if ($effected)
        stderr('Done', "$effected torrent" . ($effected ? 's' : '') . ' was cleaned.');
   else
        stderr("Error","There's no torrents to clean!");
}
else
{
   stderr("Error","You can only clean you'r own torrents!");
}
?>