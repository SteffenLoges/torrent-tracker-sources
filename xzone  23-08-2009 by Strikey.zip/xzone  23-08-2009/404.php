<html><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<title>404 Not Found</title>
<style type="text/css">
body {
        font-family: "Trebuchet MS", Trebuchet, arial, sans-serif;
        color: #ABA29C;
        margin-top: 270px;
        background-color: #1E1E1E;
}
#content p {
	font-size: 11px;
	line-height: 13px;
	letter-spacing: 1px;
        padding: 20px 10px 0 250px;
}
#content p strong {
        height: 25px;
        font-size: 12px;
	color: #FFFFFF;
}
</style>
</head><body>
<div align="center"><img src="404_files/404.gif" alt="404" width="273" height="176"></div>
<div id="content"><p><strong>OBJECT NOT FOUND!</strong><br><br>The requested URL was not found on this server.<br>If you entered the URL manually please check your spelling and try again.<br></p></div>
</body></html>