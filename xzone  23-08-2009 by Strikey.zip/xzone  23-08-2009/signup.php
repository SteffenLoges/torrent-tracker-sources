<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>



<title>Signup</title>
<link rel="stylesheet" type="text/css" href="signup2_files/default.css">

<script language="JavaScript">

<!-- Begin
var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return "Uncheck All"; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return "Check All"; }
}
//  End -->
</script>
<script type="text/javascript" src="signup2_files/java_klappe.js"></script>
<script type="text/javascript" src="signup2_files/popup.js"></script>
<script type="text/javascript" src="signup2_files/overlib.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" name="robots" charset="utf-8">
<!-- Block Errors start-->
<script language="javascript">
<!--
function blockError()
{
return true;
}
window.onerror = blockError;
-->
</script>
<!-- Block Errors end-->
<script type="text/javascript">

function closeit(box)
{
document.getElementById(box).style.display="none";
}

function showit(box)
{
document.getElementById(box).style.display="block";
}
</script>

<script language="javascript">
<!--
function Post()
{
document.compose.action = "?action=post"
document.compose.target = "";
document.compose.submit();
return true;
}
-->
</script>

<script type="text/javascript" src="signup2_files/wz_tooltip.htm"></script>
</head><body>

<table style="background: transparent none repeat scroll 0% 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;" cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td class="clear" width="49%">

<map id="default" name="default">
<area shape="rect" coords="799,6,900,47" href="http://games.bitshock.org/donate.php">
<area shape="rect" coords="809,217,897,255" href="http://games.bitshock.org/staff.php">
<area shape="rect" coords="747,217,804,255" href="http://games.bitshock.org/faq.php">
<area shape="rect" coords="657,217,744,255" href="http://games.bitshock.org/rules.php">
<area shape="rect" coords="557,217,654,255" href="http://games.bitshock.org/forums.php">
<area shape="rect" coords="446,217,554,255" href="http://games.bitshock.org/my.php">
<area shape="rect" coords="320,217,442,255" href="http://games.bitshock.org/viewrequests.php">
<area shape="rect" coords="214,217,318,255" href="http://games.bitshock.org/upload.php">
<area shape="rect" coords="214,217,318,255" href="http://games.bitshock.org/upload.php">
<area shape="rect" coords="96,217,211,255" href="http://games.bitshock.org/browse.php">
  <area shape="rect" coords="9,217,94,255" href="http://games.bitshock.org/index.php">
</map>



<table class="mainouter" align="center" border="0" cellpadding="0" cellspacing="0" width="800">

<!--  MENU -->

<tbody><tr><td class="outer" align="center">
<table class="main" border="0" cellpadding="5" cellspacing="0" width="800">
<tbody><tr>

</tr>
<tr><td class="outer" style="padding-top: 20px; padding-bottom: 20px;" align="center">






<script type="text/javascript">
function writediv(texte)
     {
     document.getElementById('pseudobox').innerHTML = texte;
     }

function verifPseudo(pseudo)
     {
     if(pseudo != '')
               {
               if(pseudo.length<1)
                         writediv('<span style="color:#cc0000"><b>'+pseudo+' - </b>The username is too short.</span>');
               else if(pseudo.length>12)
                         writediv('<span style="color:#cc0000"><b>'+pseudo+' - </b> This username is too long.</span>');
               else if(texte = file('http://www.unitedtorrents.net/verifpseudo.php?pseudo='+escape(pseudo)))
                         {
          if(texte == 1)
               writediv('<span style="color:#cc0000"><b>'+pseudo+' - </b> This username already exist.</span>');
          else if(texte == 2)
               writediv('<span style="color:#1A7917"><b>'+pseudo+' - </b> This username is free :D</span>');
          else if(!isNaN(pseudo.charAt(0)))
                writediv('<span style="color:#cc0000"><b>'+pseudo+' -</b> The username is not a valid username. The username can't start with number.</span>')
          else
               writediv('Enter an username.');
                         }
               }

     }

function file(fichier)
     {
     if(window.XMLHttpRequest) // FIREFOX
          xhr_object = new XMLHttpRequest();
     else if(window.ActiveXObject) // IE
          xhr_object = new ActiveXObject("Microsoft.XMLHTTP");
     else
          return(false);
     xhr_object.open("GET", fichier, false);
     xhr_object.send(null);
     if(xhr_object.readyState == 4) return(xhr_object.responseText);
     else return(false);
     }
</script>

<!--
<table width=500 border=1 cellspacing=0 cellpadding=10><tr><td align=left>
<h2 align=center>Proxy check</h2>
<b><font color=red>Important - please read:</font></b> We do not accept users connecting through public proxies. When you
submit the form below we will check whether any commonly used proxy ports on your computer is open. If you have a firewall it may alert of you of port
scanning activity. This is only our proxy-detector in action.
<b>The check takes up to 30 seconds to complete, please be patient.</b> The IP address we will test is <b>89.40.107.206</b>.
By proceeding with submitting the form below you grant us permission to scan certain ports on this computer.
</td></tr></table>
<p>
-->
Note: You need cookies enabled to sign up or log in.<p>
</p><form method="post" action="takesignup.php">
<table border="1" cellpadding="10" cellspacing="0">
<tbody><tr><td class="heading" align="right">Desired username:</td><td align="left"><input name="wantusername" size="40" onkeyup="verifPseudo(this.value)" type="text"></td></tr>
<tr><td class="heading" align="right">Pick a password:</td><td align="left"><input size="40" name="wantpassword" type="password"></td></tr>
<tr><td class="heading" align="right">Enter password again:</td><td align="left"><input size="40" name="passagain" type="password"></td></tr>
<tr><td class="heading" align="right">Security Image:</td><td align="left"><img src="signup2_files/img.png"></td></tr>

<tr><td class="heading" align="right">Security Code:</td><td align="left"><input name="vImageCodP" type="text">  <table border="0" cellpadding="0" cellspacing="0" width="250"><tbody><tr><td class="embedded"><font class="small">The security code is case sensitive.

</font></td></tr></tbody></table></td></tr>
<tr valign="top"><td class="heading" align="right">Email address:</td><td align="left"><input size="40" name="email" type="text">
<table border="0" cellpadding="0" cellspacing="0" width="250"><tbody><tr><td class="embedded"><font class="small">The email address must be valid.
You will receive a confirmation email which you need to respond to. The email address won't be publicly shown anywhere.</font></td></tr>
</tbody></table>
</td></tr><tr><td class="heading" align="right" valign="top">Gender</td><td align="left" valign="top"><input name="gender" value="Male" type="radio">Male<input name="gender" value="Female" type="radio">Female <font color="red">&nbsp;*</font></td></tr>
<tr><td class="heading" align="right" valign="top">Age (optional)</td><td align="left" valign="top"><input name="age" size="5" value="" type="text"> </td></tr>
<tr><td class="heading" align="right" valign="top">Website (optional)</td><td align="left" valign="top"><input name="website" size="40" value="" type="text"> </td></tr>

<tr><td class="heading" align="right"></td><td align="left">
<input name="rulesverify" value="yes" type="checkbox">I have read the site <a href="http://games.bitshock.org/rules.php" target="_blank" font="" color="red"> rules </a> page.<br>
<input name="faqverify" value="yes" type="checkbox"> I agree to read the <a href="http://games.bitshock.org/faq.php" target="_blank" font="" color="red"> FAQ </a> before asking questions.<br>
<input name="ageverify" value="yes" type="checkbox"> I am at least 13 years old.</td></tr>
<tr><td colspan="2" align="center"><input value="Sign up! (PRESS ONLY ONCE)" style="height: 25px;" type="submit"></td></tr>
</tbody></table>
</form>
    </td></tr></tbody></table>
  <map id="footer" name="footer">

  <area shape="rect" coords="617,127,702,163" href="http://games.bitshock.org/topten.php">
  <area shape="rect" coords="527,127,612,163" href="http://games.bitshock.org/users.php">
  <area shape="rect" coords="379,127,524,163" href="http://games.bitshock.org/useragreement.php">
  <area shape="rect" coords="271,127,378,163" href="http://games.bitshock.org/getrss.php">
  <area shape="rect" coords="206,127,266,163" href="http://games.bitshock.org/rss.php">
  </map>

</td></tr></tbody></table></body></html>