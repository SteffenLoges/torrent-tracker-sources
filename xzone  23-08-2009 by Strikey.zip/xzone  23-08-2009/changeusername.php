<?
require "include/bittorrent.php";
dbconn();
loggedinorreturn();
if (get_user_class() < UC_SYSOP)
stderr("Error", "Access denied.");
if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
if ($HTTP_POST_VARS["username"] == "" || $HTTP_POST_VARS["id"] == "" || $HTTP_POST_VARS["id"] == "")
stderr("Error", "Missing form data.");
$id = sqlesc($HTTP_POST_VARS["id"]);
$username = sqlesc($HTTP_POST_VARS["username"]);

$arr = mysql_fetch_row($res);
if (!$arr)
stderr("Error", "Unable to update account.");
header("Location: $BASEURL/userdetails.php?id=$arr[0]");
die;
}
stdhead("Change Usernames");
?>
<h1>Change UserNames</h1>
<form method=post action=changeusername.php>
<table border=1 cellspacing=0 cellpadding=5>
<tr><td class=rowhead>ID</td><td><input type=text name=id size=6></td></tr>
<tr><td class=rowhead>Username</td><td><input type=uploaded name=username size=25></td></tr>
<tr><td colspan=2 align=center><input type=submit value="Okay" class=btn></td></tr>
</table>
</form>
<? stdfoot(); ?>