<?
$rconpassword = "mypass";
?>
