<?
require "include/bittorrent.php";
dbconn();
loggedinorreturn();

// Reset Lost Password ACTION
if (get_user_class() < UC_SYSOP)
stderr("Error", "Permission denied Your Not A Sysop.");

if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
 $username = trim($_POST["username"]);
   $res = mysql_query("SELECT * FROM users WHERE username=" . sqlesc($username) . " ") or sqlerr();
$arr = mysql_fetch_assoc($res);


$id = $arr['id'];
$wantpassword="$username";
$secret = mksecret();
$wantpasshash = md5($secret . $wantpassword . $secret);
mysql_query("UPDATE users SET passhash ='$wantpasshash' where id=$id");
mysql_query("UPDATE users SET secret = '$secret' where id=$id");
write_log("Password Reset For $username by $CURUSER[username]");
 if (mysql_affected_rows() != 1)
   stderr("Error", "Unable to RESET PASSWORD on this account.");
 stderr("Success", "The account <b>$username</b> Password now is <b>$username</b>.");

}
stdhead("Reset User's Lost Password");
?>
<h1>Reset User's Lost Password</h1>
<table border=1 cellspacing=0 cellpadding=5>
<form method=post action=reset.php>
<tr><td class=rowhead>User name</td><td><input size=40 name=username></td></tr>

<tr><td colspan=2><input type=submit class=btn value='reset'></td></tr>
</form>
</table>
<?
stdfoot();
?>