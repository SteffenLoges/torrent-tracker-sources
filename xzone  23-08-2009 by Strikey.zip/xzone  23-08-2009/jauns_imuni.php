<?php
//imunit?tes scripts - danka - www.velkam.org - info@velkam.org
require_once("include/bittorrent.php");
stdhead();
if (get_user_class() < UC_ADMINISTRATOR)
{
stdmsg("Sorry...", "You need to by Administrator.");
stdfoot();
exit;
}
?>
<table width="450px" align="center">
<h3>Add new user</h3><br><h5>These users have immunity</h5>
<form align="left" name="jauns" action="jauns_dalibnieks_imunitate.php">
<p>Username - <small> example : danka <input name="lietotajs" type="text"></p></small>
<p>Link to user - <small> example : userdetails.php?id=1 <input name="links" type="text"></p></small>
<input name="submit"value="ADD"  /><br>
</td>

<?
stdfoot();
?>