<?php
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();
if (get_user_class() < UC_SYSOP)
	stderr("Error", "Permission denied.");

stdhead("Spam");
$res2 = sql_query("SELECT COUNT(*) FROM messages WHERE sender != 0 AND receiver != $CURUSER[id] AND sender != $CURUSER[id]");
$row = mysql_fetch_array($res2);
$count = $row[0];
$perpage = 10;
list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" );
echo $pagertop;
$res = sql_query("SELECT * FROM messages WHERE sender != 0 AND receiver != $CURUSER[id] AND sender != $CURUSER[id] ORDER BY id DESC $limit") or sqlerr(__FILE__, __LINE__);
print("<table border=1 cellspacing=0 cellpadding=5 width=737>\n");
print("<form method=\"post\" action=\"take-delmp.php\" name=\"form\">");
print("<tr><td class=colhead align=left>Sender</td><td class=colhead align=left>Receiver</td><td class=colhead align=left>Subject</td><td class=colhead align=left>Text</td><td class=colhead align=left>Date</td><td class=colhead>Delete</td></tr>\n");
while ($arr = mysql_fetch_assoc($res))
{
	$res2 = sql_query("SELECT username FROM users WHERE id=" . (int)$arr["receiver"]) or sqlerr(__FILE__,__LINE__);
	$arr2 = mysql_fetch_assoc($res2);
	$receiver = "<a href=userdetails.php?id=" . (int)$arr["receiver"] . "><b>" . $arr2["username"] . "</b></a>";
	$res3 = sql_query("SELECT username FROM users WHERE id=" . (int)$arr["sender"]) or sqlerr(__FILE__,__LINE__);
	$arr3 = mysql_fetch_assoc($res3);
	$sender = "<a href=userdetails.php?id=" . (int)$arr["sender"] . "><b>" . $arr3["username"] . "</b></a>";            
	$msg = format_comment($arr["msg"]);
	$added = format_comment($arr["added"]);
	print("<tr><td>$sender</td><td>$receiver</td><td>".htmlspecialchars($arr[subject])."</td><td align=left>$msg</td><td align=left>$added</td>");
	echo("<TD><INPUT type=\"checkbox\" name=\"delmp[]\" value=\"" . (int)$arr['id'] . "\"></TD>\n</TR>\n");
}
print("</table>");
print("<p><b>Times are in GMT.</b></p>\n");
?>
<input type="submit" value="Delete Selected!" class="btn"/>
<input type="button" value="Check all" onClick="this.value=check(form)" class="btn">
</form>
<?
print($pagerbottom);
stdfoot();
?>