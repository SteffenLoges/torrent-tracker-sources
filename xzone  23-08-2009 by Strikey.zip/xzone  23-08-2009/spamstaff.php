<?

ob_start("ob_gzhandler");



require "include/bittorrent.php";



dbconn(false);



loggedinorreturn();



if (get_user_class() < UC_SYSOP)

stderr("Sorry...", "Permission denied.");



stdhead("Spam");



//////////PAGER////////////

$res2 = mysql_query("SELECT COUNT(*) FROM messages $where");

$row = mysql_fetch_array($res2);

$count = $row[0];

$perpage = 50;

list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" );

echo $pagertop;

//////////END PAGER///////////

///////////SEARCH FUNCTION/////////////////
$ss = $_GET[ss];
$s = (int)$_GET["s"];
$d = $_GET["d"];

if (($d != "ASC") && ($d != "DESC")) $d = "ASC";

$where = " WHERE txt LIKE " . sqlesc("%$ss%");

$order = " ORDER BY sender";




print("<table border=1 cellspacing=0 width=115 cellpadding=5>\n");
print("<tr><td class=tabletitle align=left>Search Messages</td></tr>\n");
print("<tr><td class=tableb align=left><form method=\"get\" action=spamstaff.php>\n");
print("<input type=\"text\" name=\"ss\" size=\"40\" value=\"$_GET[ss]\">\n");
print("<input type=submit value=" . SEARCH . " style='height: 20px' /></form>\n");
print("</td></tr></table>\n");

$res = mysql_query("SELECT COUNT(*) FROM messenger $where $order");
$row = mysql_fetch_array($res2);
/////////////////////////END SEARCH///////////////////////




$res = mysql_query("SELECT * FROM messages ORDER BY id DESC $limit") or sqlerr(__FILE__, __LINE__);

print("<h1>Spam</h1>\n");

print("<table border=1 cellspacing=0 cellpadding=5>\n");

///////////////////////////////////////

?>

<form method="post" action="/take-delmp.php">

<?

///////////////////////////////////////

print("<tr><td class=colhead align=left>Sender</td><td class=colhead align=left>Receiver</td><td class=colhead align=left>Text</td><td class=colhead align=left>Date</td><td class=colhead>Delete</td></tr>\n");

while ($arr = mysql_fetch_assoc($res))

{

$res2 = mysql_query("SELECT username FROM users WHERE id=" . $arr["receiver"]) or sqlerr();

$arr2 = mysql_fetch_assoc($res2);

$receiver = "<a href=userdetails.php?id=" . $arr["receiver"] . "><b>" . $arr2["username"] . "</b></a>";

$res3 = mysql_query("SELECT username FROM users WHERE id=" . $arr["sender"]) or sqlerr();

$arr3 = mysql_fetch_assoc($res3);

$sender = "<a href=userdetails.php?id=" . $arr["sender"] . "><b>" . $arr3["username"] . "</b></a>";

if( $arr["sender"] == 0 )

$sender = "<font color=red><b>System</b></font>";

$msg = format_comment($arr["msg"]);

$added = format_comment($arr["added"]);

print("<tr><td align=center>$sender</td><td align=center>$receiver</td><td align=left>$msg</td><td align=center>$added</td>");

/////////////////////////////////////////////////////////////////////////////////

if ($_GET[check] == "yes") {

echo("<TD align=center><INPUT type=\"checkbox\" checked name=\"delmp[]\" value=\"" . $arr['id'] . "\"></TD>\n</TR>\n");

}

else {

echo("<TD align=center><INPUT type=\"checkbox\" name=\"delmp[]\" value=\"" . $arr['id'] . "\"></TD>\n</TR>\n");

}



/////////////////////////////////////////////////////////////////////////////////

}

print("</table>");

print("<p>Times are in GMT.</p>\n");

?>

<input type="submit" value="Delete!" />

</form>



<!------------------------------------------------->

<A href="spamstaff.php?&page=<? echo $_GET[page];?>action=<? echo $_GET[action]; ?>&box=<? echo $_GET[box]; ?>&check=yes">Check All</A>&nbsp;

<A href="spamstaff.php?&page=<? echo $_GET[page];?>action=<? echo $_GET[action]; ?>&box=<? echo $_GET[box]; ?>&check=no">Uncheck All</A>

<!------------------------------------------------->



<?

print($pagerbottom);

stdfoot();

?>