<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


dbconn(false);

loggedinorreturn();
parked();


$cats = genrelist();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);

if (empty($cleansearchstr))
unset($cleansearchstr);

// sorting by MarkoStamcar

if ($_GET['sort'] && $_GET['type']) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
case '1': $column = "name"; break;
case '2': $column = "numfiles"; break;
case '3': $column = "comments"; break;
case '4': $column = "added"; break;
case '5': $column = "size"; break;
case '6': $column = "times_completed"; break;
case '7': $column = "seeders"; break;
case '8': $column = "leechers"; break;
case '9': $column = "owner"; break;
default: $column = "id"; break;
}
    switch($_GET['type']) {
  case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
  case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
  default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
    }


$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";


} else {

$orderby = "ORDER BY torrents.sticky ASC, torrents.id DESC";
$pagerlink = "";

}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
        $addparam .= "incldead=1&amp;";
        if (!isset($CURUSER) || get_user_class() < UC_ADMINISTRATOR)
                $wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
        $addparam .= "incldead=2&amp;";
                $wherea[] = "visible = 'no'";
}
        else
                $wherea[] = "visible = 'yes'";
if ($CURUSER["view_xxx"] != "yes")
 $wherea[] = "category != '34'";

$category = (int)$_GET["cat"];

$all = $_GET["all"];

if (!$all)
        if (!$_GET && $CURUSER["notifs"])
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $cat[id];
            if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }
        elseif ($category)
        {
          if (!is_valid_id($category))
            stderr("Error", "Invalid category ID $category");
          $wherecatina[] = $category;
          $addparam .= "cat=$category&amp;";
        }
        else
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $_GET["c$cat[id]"];
            if ($_GET["c$cat[id]"])
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }

if ($all)
{
        $wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
$wherea[] = "category = $wherecatina[0]";
$wherebase = $wherea;

if (isset($cleansearchstr))
{
        $wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
        //$wherea[] = "0";
        $addparam .= "search=" . urlencode($searchstr) . "&amp;";
        //$orderby = "";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
        $where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
        $where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
        $wherea = $wherebase;
        //$orderby = "ORDER BY id DESC";
        $searcha = explode(" ", $cleansearchstr);
        $sc = 0;
        foreach ($searcha as $searchss) {
                if (strlen($searchss) <= 1)
                        continue;
                $sc++;
                if ($sc > 5)
                        break;
                $ssa = array();
                foreach (array("search_text", "ori_descr") as $sss)
                        $ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
                $wherea[] = "(" . implode(" OR ", $ssa) . ")";
        }
        if ($sc) {
                $where = implode(" AND ", $wherea);
                if ($where != "")
                        $where = "WHERE $where";
                $res = mysql_query("SELECT COUNT(*) FROM torrents $where");
                $row = mysql_fetch_array($res);
                $count = $row[0];
        }
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
        $torrentsperpage = 30;

    if ($addparam != "") {
 if ($pagerlink != "") {
  if ($addparam{strlen($addparam)-1} != ";") { // & = &amp;
    $addparam = $addparam . "&" . $pagerlink;
  } else {
    $addparam = $addparam . $pagerlink;
  }
 }
    } else {
 $addparam = $pagerlink;
    }

if ($count)
{
        list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);
        $query = "SELECT torrents.id, torrents.nuked, torrents.category, torrents.leechers, torrents.sticky, torrents.seeders, torrents.request, torrents.scene, torrents.free, torrents.name, torrents.double_upload, torrents.times_completed, torrents.size, torrents.added, torrents.comments,torrents.numfiles,torrents.filename,torrents.description,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
//        "IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
        "categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
        $res = mysql_query($query) or die(mysql_error());
}
else
        unset($res);
if (isset($cleansearchstr))
        stdhead("Search results for \"$searchstr\"");
else
        stdhead("Browse Torrents");

?>

<style type="text/css">
<!--

.search{
	background-image:url(pic/search.gif);
	background-repeat:no-repeat;
	width:579px;
	height:95px;
	margin:5px 0 5px 0;
	text-align:left;
}

.search_title{
	color:#0062AE;
	background-color:#;
	font-size:12px;
	font-weight:bold;
	text-align:left;
	padding:7px 0 0 15px;
}

.search_table {
	border-collapse: collapse;
	border: none;
	background-color: #ffffff; 
}

a.catlink:link, a.catlink:visited{
	text-decoration: none;
}

a.catlink:hover {
	color: #A83838;
}
-->
</style>
<table class="categ" border="1" cellpadding="0" cellspacing="5" width="720">
  <tbody>
    <tr>
    <td width="700"><center>

	<form method="get" action="browse.php">
	<b>Cauta:</b>
	<input name="search" size="40" value="" type="text"> 
    in
<select name="cat">

<option value="0">(Toate)</option>
<option value="6">Anime/Cartoon</option>
<option value="2">Appz</option>
<option value="13">Docs</option>
<option value="4">Games/PC</option>
<option value="17">Games/PS2</option>
<option value="22">Games/PS3</option>
<option value="23">Games/PSP</option>
<option value="24">Games/Wii</option>
<option value="25">Games/X360</option>
<option value="14">Images</option>
<option value="18">Hentai</option>
<option value="2">MiSC</option>
<option value="12">Mobile</option>
<option value="16">Movies/DVD-RO</option>
<option value="11">Movies/SVCD</option>
<option value="8">Movies/Oldies</option>
<option value="3">Movies/XVID</option>
<option value="7">Linux/Unix</option>
<option value="15">Music/Video</option>
<option value="5">Music/Mp3</option>
<option value="26">Movies/DVDR</option>
<option value="10">Tv/Episodes</option>
<option value="21">Tv/Boxsets</option>
<option value="9">XxX</option>

</select>

	</select>
	<input value="Cauta!" type="submit">	
    <b></b>	
    <select name="incldead">
    <option value="0">active</option>
    <option value="1">dead too</option>
    <option value="2">only dead</option>
    <option value="3">Free Torrents</option>
    </select>

    <input value="Go!" type="submit">
	</form></center>
	</td>
</td>
<td width=1% align=center><nobr><a href="javascript:klappe_news('browse')"><img border=0 src=pic/categories.png></a></td>
</tr>
</table>
<div id="kbrowse" style="display: none;"><table width=720 border="0" class=statusbar >

      <tr>
      <td colspan="2">
	  <table class="bot" id="cats" style="display: block;">	<tbody><tr>



<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c32" value="2" type="checkbox"><a class="catlink" href="/browse.php?cat=1">Appz</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c37" value="1" type="checkbox"><a class="catlink" href="/browse.php?cat=4">Anime/Cartoon</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c14" value="3" type="checkbox"><a class="catlink" href="/browse.php?cat=5">eBooks</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c4" value="4" type="checkbox"><a class="catlink" href="/browse.php?cat=7">Games/PC</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c42" value="5" type="checkbox"><a class="catlink" href="/browse.php?cat=9">Games/PS2</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c27" value="6" type="checkbox"><a class="catlink" href="/browse.php?cat=12">Games/PSP</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c28" value="7" type="checkbox"><a class="catlink" href="/browse.php?cat=17">Games/Xbox</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c43" value="8" type="checkbox"><a class="catlink" href="/browse.php?cat=19">Linux/Unix</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c44" value="9" type="checkbox"><a class="catlink" href="/browse.php?cat=20">MiSC</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c52" value="10" type="checkbox"><a class="catlink" href="/browse.php?cat=22">Mobile</a></td>

</tr><tr><td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c54" value="35" type="checkbox"><a class="catlink" href="/browse.php?cat=24">Movies/DVD-R</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c47" value="11" type="checkbox"><a class="catlink" href="/browse.php?cat=25">Movies/DVD-RO</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c46" value="12" type="checkbox"><a class="catlink" href="/browse.php?cat=26">Movies/HDTV</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c25" value="13" type="checkbox"><a class="catlink" href="/browse.php?cat=27">Movies/Oldies</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c50" value="14" type="checkbox"><a class="catlink" href="/browse.php?cat=28">Movies/XViD</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c41" value="15" type="checkbox"><a class="catlink" href="/browse.php?cat=33">Movies/SVCD</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c29" checked="checked" value="16" type="checkbox"><a class="catlink" href="/browsemusic.php">Music/Mp3</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c45" value="17" type="checkbox"><a class="catlink" href="/browsemusic.php">Music/Video</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c51" value="18" type="checkbox"><a class="catlink" href="/browse.php?cat=31">Sport</a></td>
<td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c51" value="19" type="checkbox"><a class="catlink" href="/browse.php?cat=32">Tv/Episodes</a></td>

</tr><tr><td class="bottom" style="padding-bottom: 2px; padding-left: 7px; text-align: left;"><input name="c34" value="20" type="checkbox"><a class="catlink" href="/browseadult.php">XxX</a></td>

<td class="bottom" rowspan="3">&nbsp;</td><td class="bottom" style="padding-left: 5px;"><div align="center">(<a href="/browse.php?all=1"><b>Show all</b></a>)</div></td>
	</tr>

	</tbody></table>

</td>
    </tr>
  </tbody>


</div>
</form>
<script language="JavaScript" src="suggest.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 520px; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>


          </tr>
        </tbody>
      </table>
    </form>
  </div>
</div>
<?


if (isset($cleansearchstr))
print("<h2>Search results for \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
        print($pagertop);

        torrenttable($res);

        print($pagerbottom);
}
else {
        if (isset($cleansearchstr)) {
                print("<h2>Nothing found!</h2>\n");
                print("<p>Try again with a refined search string.</p>\n");
        }
        else {
                print("<h2>Nothing here!</h2>\n");
                print("<p>Sorry pal :(</p>\n");
        }
}

?>
<br>

<?

stdfoot();

mysql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);

?>