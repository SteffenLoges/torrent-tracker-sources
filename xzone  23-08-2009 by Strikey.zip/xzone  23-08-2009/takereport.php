<?php

require_once("include/bittorrent.php");

hit_start();

dbconn();

if (!$_POST){
stdhead();
stdmsg("Oops","Dyou have to report something to use this page.");
stdhead();
}
else
if (!$_POST[reason])
{
stdhead();
stdmsg("Oops","You need to type a reason for your report");
stdfoot();
exit;
}

hit_count();

$reason = htmlspecialchars($_POST[reason]);
$time = date("Y-m-d H:i:s");
$typ = htmlspecialchars($_GET[typ]);
$repid = htmlspecialchars($_POST[reportid]);
$reporter = $CURUSER[id];

mysql_query("INSERT INTO report (reporter,reason,reportid,typ,tid) VALUES ('$reporter','$reason','$repid','$typ','$time')");


header("Refresh: 0; url=report.php?typ=klar");

hit_end();

?>