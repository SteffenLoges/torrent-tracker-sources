<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


dbconn(false);

loggedinorreturn();
 parked();

$cats = genrelist();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
unset($cleansearchstr);

// sorting by MarkoStamcar

if ($_GET['sort'] && $_GET['type']) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
case '1': $column = "name"; break;
case '2': $column = "numfiles"; break;
case '3': $column = "comments"; break;
case '4': $column = "added"; break;
case '5': $column = "size"; break;
case '6': $column = "times_completed"; break;
case '7': $column = "seeders"; break;
case '8': $column = "leechers"; break;
case '9': $column = "owner"; break;
default: $column = "id"; break;
}

switch($_GET['type']) {
case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
}


$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";

} else {

$orderby = "ORDER BY torrents.id DESC";
$pagerlink = "";

}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
$addparam .= "incldead=1&amp;";
if (!isset($CURUSER) || get_user_class() < UC_ADMINISTRATOR)
$wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
$addparam .= "incldead=2&amp;";
$wherea[] = "visible = 'no'";
}
else
$wherea[] = "visible = 'yes'";

$category = (int)$_GET["cat"];

$all = $_GET["all"];
$blah = $_GET['blah'];

if (!$all)
if (!$_GET && $CURUSER["notifs"])
{
$all = True;
foreach ($cats as $cat)
{
$all &= $cat[id];
if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
{
$wherecatina[] = $cat[id];
$addparam .= "c$cat[id]=1&amp;";
}
}
}
elseif ($category)
{
if (!is_valid_id($category))
stderr("Error", "Invalid category ID.");
$wherecatina[] = $category;
$addparam .= "cat=$category&amp;";
}
else
{
$all = True;
foreach ($cats as $cat)
{
$all &= $_GET["c$cat[id]"];
if ($_GET["c$cat[id]"])
{
$wherecatina[] = $cat[id];
$addparam .= "c$cat[id]=1&amp;";
}
}
}

if ($all)
{
$wherecatina = array();
$addparam = "";
}

if (count($wherecatina) > 1)
$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
$wherea[] = "category = $wherecatina[0]";
$wherea[] = "category NOT IN (1,6,7,9,12,17,23,19,20,21,22,24,25,26,27,28,29,30,31,32,38,4,5,40)";
$wherebase = $wherea;

if (isset($cleansearchstr)) {
if ($blah == 0) {
$wherea[] = "torrents.name LIKE (" . sqlesc($searchstr) . ")";
} elseif ($blah == 1) {
$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
} elseif ($blah == 2) {
$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
}
$addparam .= "search=" . urlencode($searchstr) . "&";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
$where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
$where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
$wherea = $wherebase;
$orderby = "ORDER BY id DESC";
$searcha = explode(" ", $cleansearchstr);
$sc = 0;
foreach ($searcha as $searchss) {
if (strlen($searchss) <= 1)
continue;
$sc++;
if ($sc > 5)
break;
$ssa = array();
if ($blah == 0) {
foreach (array("torrents.name") as $sss)
$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
$wherea[] = "(" . implode(" OR ", $ssa) . ")";
} elseif ($blah == 1) {
foreach (array("search_text", "ori_descr") as $sss)
$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
$wherea[] = "(" . implode(" OR ", $ssa) . ")";
} elseif ($blah == 2) {
foreach (array("search_text", "ori_descr") as $sss)
$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
$wherea[] = "(" . implode(" OR ", $ssa) . ")";
}
}
if ($sc) {
$where = implode(" AND ", $wherea);
if ($where != "")
$where = "WHERE $where";
$res = mysql_query("SELECT COUNT(*) FROM torrents $where");
$row = mysql_fetch_array($res);
$count = $row[0];
}
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
$torrentsperpage = 20;

if ($count)
{
	list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "adult.php?" . $addparam);
	$query = "SELECT torrents.id, torrents.category, torrents.leechers, torrents.seeders, torrents.request, torrents.name, torrents.times_completed, torrents.size, torrents.added, torrents.comments,torrents.numfiles,torrents.filename,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
//	"IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	"categories.name AS cat_name, categories.image AS cat_pic, users.username  FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
$res = mysql_query($query) or die(mysql_error());
}
else
unset($res);
if (isset($cleansearchstr))
stdhead("Search results for \"$searchstr\"");
else
stdhead();

?>

<STYLE TYPE="text/css" MEDIA=screen>

a.catlink:link, a.catlink:visited{
text-decoration: none;
}

a.catlink:hover {
color: #A83838;
}

</STYLE>
<form method="get" action="adult.php">
<br />
<table width="70%" class="coltable" cellspacing="1" cellpadding="4" border="1">
<tr>
<table class=bottom>

<tr>
<div align="center"><img src=pic/blank.gif class="xxx" width="95" height="95"></div>
<h1><font class="xxx18"><center>Adult Torrents</center></font></h3>
<td class=bottom>
<table class=bottom>

<tr>
<td width="760" align=center><nobr>
<b>��<? print("" . SEARCHFOR . "");?> </b><input type="text" id="searchinput" name="search" autocomplete="off" style="width: 240px;" ondblclick="suggest(event.keyCode,this.value);" onkeyup="suggest(event.keyCode,this.value);" onkeypress="return noenter(event.keyCode);" value="<?= htmlspecialchars($searchstr) ?>" />
<?= $deadchkbox ?>
<input type="submit" value="<? print("" . SEARCHFOR1 . "");?>!" style='height: 19px; width: 55px'>
</form>
<script language="JavaScript" src="suggest.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 520px; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>
<script language="JavaScript" src="suggest.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 520px; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>

</td></tr></table></table>
</br>
<?
if (isset($cleansearchstr))
print("<h2>" . SEARCHFROM . " \"" . htmlspecialchars($searchstr) . "\"</h2>\n");
?>
<div align=center><?
if ($count) {
   print($pagertop);
?></div><?
    torrenttable($res);?>
<div align=center><?
    print($pagerbottom);
    ?></div><?
	?>
	</br>
<div align=center><?
 print($pagertop);
    print($pagerbottom);
?></div><?
}
else {
	if (isset($cleansearchstr)) {
		print("<h2>" . NIMIK . "!</h2>\n");
	}
	else {
		print("<h2>Nothing here!</h2>\n");
		print("<p>Sorry pal :(</p>\n");
	}
}


stdfoot();
mysql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);
?>