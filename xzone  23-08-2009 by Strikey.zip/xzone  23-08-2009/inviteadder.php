
<?
require_once('include/bittorrent.php');
dbconn();
loggedinorreturn();
if (get_user_class() < UC_SYSOP)
stderr('Error', 'Access denied.');
if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
$class = $_POST['class'];

$res = mysql_query("SELECT id, invites FROM users WHERE class $class - 1)");
while($arr=mysql_fetch_assoc($res))
{
$curinvites = $arr["invites"];
if($_POST['inviteadd']){
$toadd = $_POST["inviteadd"];
$invites = ($curinvites + $toadd);
$shot = mysql_query("UPDATE users SET invites = $invites WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);

}elseif($_POST['inviteremove']){
$toremove = $_POST["inviteremove"];
$invites = ($curinvites - $toremove);
if($invites <= 0)
$shot = mysql_query("UPDATE users SET invites = 0 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
else
$shot = mysql_query("UPDATE users SET invites = $invites WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
}elseif($_POST['removeallinvites']){
$shot = mysql_query("UPDATE users SET invites = 0 WHERE class $class - 1)") or sqlerr(__FILE__, __LINE__);
}
}
if ($shot)
$res = mysql_query("SELECT id, invites FROM users WHERE class $class - 1)");
while($arr=mysql_fetch_assoc($res))
$userid = $arr["id"];
$added = sqlesc(get_date_time());
if($_POST['inviteadd']){
if($_POST['sendpm']){
$subject = sqlesc("Invite(s) added.");
$msg = sqlesc("We have added to your class, ".htmlspecialchars($toadd)." invite(s).");
mysql_query("INSERT INTO messages (sender, receiver, msg, added, subject) VALUES(0, $userid, $msg, $added, $subject)") or sqlerr(__FILE__, __LINE__);
}
stderr("Success!", "Successfully <b>added</b> <u><b>".htmlspecialchars($toadd)."</b></u> invite(s).<br>Go <a href=inviteadd1.php>back</a>.");
}elseif($_POST['inviteremove']){
if($_POST['sendpm']){
$subject = sqlesc("Invite(s) removed.");
$msg = sqlesc("We have removed from your class, ".htmlspecialchars($toremove)." invite(s).");
mysql_query("INSERT INTO messages (sender, receiver, msg, added, subject) VALUES(0, $userid, $msg, $added, $subject)") or sqlerr(__FILE__, __LINE__);
}
stderr("Success!", "Successfully <b>removed</b> <u><b>".htmlspecialchars($toremove)."</b></u> invite(s).<br>Go <a href=inviteadd1.php>back</a>.");
}elseif($_POST['removeallinvites']){
if($_POST['sendpmremoveallinvites']){
$subject = sqlesc("Invites removed from all classes.");
$msg = sqlesc("We have removed from all the class the invites.");
mysql_query("INSERT INTO messages (sender, receiver, msg, added, subject) VALUES(0, $userid, $msg, $added, $subject)") or sqlerr(__FILE__, __LINE__);
}
stderr("Success!", "Successfully <b>removed</b> from all the classes all the invites.<br>Go <a href=inviteadd1.php>back</a>.");
}else
stderr("Error", "Please select something.<br>Go <a href=inviteadd1.php>back</a>.");
}
stdhead("Add Invites");
?>
<p><table align="center" border=0 class=main cellspacing=0 cellpadding=0><tr>
<td class=embedded></td>
<td class=embedded style='padding-left: 10px'><font size=3><b>Update User's Invites</b></font></td>
</tr></table></p>
<form method="POST" action="inviteadd1.php">
<table width="60%" border="0" cellpadding="5" cellspacing="0">
<td colspan="2"><h2><b><center>Select Class(es):</center></b></h2></td>
<tr>
<td colspan="2"><table style="border: 0" width="100%" cellpadding="0" cellspacing="0">
<tr>
<td style="border: 0" width="20"><input type="radio" name="class" value=">=(1"></td>
<td style="border: 0">All Users</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(1"></td>
<td style="border: 0">User</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(2"></td>
<td style="border: 0">Power User</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(3"></td>
<td style="border: 0">Big Power User</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(4"></td>
<td style="border: 0">Uploader</td>
</tr>
<tr>
<td style="border: 0" width="20"><input type="radio" name="class" value="=(5"></td>
<td style="border: 0">Monster Power User</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(6"></td>
<td style="border: 0">VIP</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(7"></td>
<td style="border: 0">FLS</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(8"></td>
<td style="border: 0">Moderator</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(9"></td>
<td style="border: 0">Administrator</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(10"></td>
<td style="border: 0">SysOP</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(11"></td>
<td style="border: 0">Coder</td>

<td style="border: 0" width="20"><input type="radio" name="class" value="=(12"></td>
<td style="border: 0">Owner</td>
</tr>
</table>
</td>
</tr>

<tr>
<td colspan="2" align="center"><b>Number of Invites you want to <u>add</u>:</b><br><input type=text name=inviteadd size=3></td>
</tr>

<tr>
<td colspan="2" align="center"><b>Number of Invites you want to <u>remove</u>:</b><br><input type=text name=inviteremove size=3></td>
</tr>

<tr>
<td align=center><input type=submit value="Update" class=btn><br><font class="small">Please select a class.</font></td>
<td><center><b>Send PMs:</b><br><input type="checkbox" name="sendpm"></center></td>
</tr>

<tr>
<td align=center><input type=submit value="Remove all invites" class=btn name=removeallinvites><br><font class="small">Please select a class.</font>
<td align="center"><b>Send PMs:</b><br><input type="checkbox" name="sendpmremoveallinvites"></td>
</tr>

</form>
</td></tr>
</table>

<?
stdfoot();
?>