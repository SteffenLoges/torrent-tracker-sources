<?
require_once('include/bittorrent.php');

dbconn();

loggedinorreturn();

if (get_user_class() < UC_SYSOP)
stderr('Error', 'Access denied.');

$res = mysql_query("SELECT id, uploaded FROM users WHERE uploaded > 0") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_assoc($res);
$uploadd = ($arr["uploaded"] * 0.1);
if ($_POST['doit'] == 'yes') {
mysql_query("UPDATE users SET uploaded = uploaded + $uploadd");
header("Location: /staff.php");
}

stdhead('Mass upload');
?>

<h2>Give all users 10% extra of their upload?</h2>
<font size=1>Are you sure you want to give all users an extra upload?</font><br /><br />

<form action="addupload.php" method="post">
<table border=1 cellspacing=0 cellpadding=5><tr><td class="rowhead">
<input type = "hidden" name = "doit" value = "yes" />
<input type="submit" value="Yes" />
</td></tr></table>
</form>

<? stdfoot(); ?>