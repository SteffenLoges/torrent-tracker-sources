<?
require "include/bittorrent.php";
dbconn();
stdhead();


$sent = ($sent) ? $sent : $_POST["sent"];
$pincode = ($pincode) ? $pincode : $_POST["pincode"];
$username = "youraccountname";    //mobilemoneyaccount
$password = "yourpassword";
$output = "valid";

if (!$sent)
    {
    echo "<form method=post>\n<input type=hidden name=sent value=1>\n".
         "<p>Fill in the pincode and click OK:\n<br><br>".
         "<table>".
        "<tr><td><b>Pincode: &nbsp;</td>".
            "<td><input name=pincode maxlength=10 size=10></td></tr>\n".
         "<tr><td></td><td><input type=submit value=\" OK \"></td></tr>\n".
        "</form>\n";
    } else
if (!$pincode)
    {
    die ("No pincode entered!");
    } else
    {
    $code = $pincode;
    $url = "http://www.mobilemoney.com/validate.asp?username=$username&password=$password&pincode=$code&output=$output";
    $result = @implode("",file($url));

    if (!$result)
        {
        die ("The code cannot be validated at this moment, try again later.");
        } else
        {
        if (substr($result,0,2)=="1")
            {
            echo "Pincode is valid !";
            } else
            {
            //echo $url."<br>";
            die ($result);    // invalid code
            }
        }
    }
?>