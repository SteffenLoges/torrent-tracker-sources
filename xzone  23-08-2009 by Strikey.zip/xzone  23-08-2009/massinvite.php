<?
require_once('include/bittorrent.php');

dbconn();

loggedinorreturn();

if (get_user_class() < UC_ADMINISTRATOR)
        stderr('Error', 'Access denied.');


if ($_POST['doit'] == 'yes') {
mysql_query("UPDATE users SET invites = invites + 1");
header("Location: /staff.php");
}

stdhead('Mass invite');
?>

<h2>Give all users 1 invite?</h2>
<font size=1>Are you sure you want to give all users an extra invite?</font><br /><br />

<form action="massinvite.php" method="post">
<table border=1 cellspacing=0 cellpadding=5><tr><td class="rowhead">
<input type = "hidden" name = "doit" value = "yes" />
<input type="submit" value="Yes" />
</td></tr></table>
</form>

<? stdfoot(); ?>