<?php

require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();


if (get_user_class() < UC_MODERATOR) {
stdmsg("Err..","Permission denied.");
exit;
}


stdhead("Show reports");


if ($_POST) {

if(!is_valid_id($_POST[id])){ die(); }

if ($_POST[del]) {
mysql_query("Delete FROM report WHERE id='$_POST[id]' LIMIT 1");
}

if ($_POST[beh]){
mysql_query("UPDATE report SET behandla = 'yes' WHERE id = '$_POST[id]'");
}

if ($_POST[abeh]){
mysql_query("UPDATE report SET behandla = 'no' WHERE id = '$_POST[id]'");
}

}

print("<a href=/showreport.php?typ=torrent>Torrents</a> | <a href=/showreport.php?typ=req>Requests</a> | <a href=/showreport.php?typ=pm>PM</a> | <a href=/showreport.php?typ=inlagg>Posts</a> | <!--<a href=/showreport.php?typ=trad>Topics</a> | --><a href=/showreport.php?typ=komm>Comments</a> | <a href=/showreport.php?typ=user>Users</a> | <!--<a href=/showreport.php?typ=avatar>Avatarer</a>--><br><br><br>");

$typ = $_GET[typ];

switch($typ){
case torrent: /////////////////////////// Torrents start
echo "<table border=1 cellpadding=5>";
echo "<tr><td class=colhead>Id</td><td class=colhead>Torrent name</td><td class=colhead>Reason</td><td class=colhead>Reporter</td><td class=colhead>Delete</td><td class=colhead>Handle</td></tr>";
$res = mysql_query("SELECT * FROM report WHERE typ='$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$ar = mysql_query("SELECT id,name FROM torrents WHERE id = '$row[reportid]'");
$arr = mysql_fetch_array($ar);
$nam = mysql_query("SELECT id,username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
echo "<form method=post>";

echo "<tr>";
echo "<td>".$row[reportid]."</td>";
echo "<td><a href=details.php?id=".$row[reportid].">".$arr[name]."</a></td>";
echo "<td>".$row[reason]."</td>";
echo "<td><a href=userdetails.php?id=".$namn[id].">".$namn[username]."</a></td>";
echo "<td><input type=submit name=del value='Delete'></td>";
if($row[behandla] == 'no'){
echo "<td><input type=submit name=beh value=Handle></td>";
}else{
echo "<td bgcolor=green><input type=submit name=abeh value=Dehandle>";
}
echo "</tr>";
echo "<input type=hidden name=id value=".$row[id].">";
echo "</form>";
}
echo "</table>";
break; ////////////////////////////// Torrents slut
/*
case avatar: ////////////////////////// Avatarer start

echo "<table cellpadding=10 width=750><tr><td><center>";

$res = mysql_query("SELECT * FROM report WHERE typ='$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$nam = mysql_query("SELECT id,username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
echo "<form method=post>";

$ar = mysql_query("SELECT id,username,avatar FROM users WHERE id = '$row[reportid]'");
$arr = mysql_fetch_array($ar);

echo "<table cellpadding=5 class=main>";
tr("user","<a href=userdetails.php?id=".$arr[id].">".$arr[username]."</a>",1);
tr("Avatar","<img src=$arr[avatar]>",2);
tr("reason",$row[reason],2);
tr("Tid",$row[tid]);
tr("reporter","<a href=userdetails.php?id=".$namn[id].">".$namn[username]."</a>",2);
if($row[behandla] == 'no'){
tr("<input type=submit name=del value='Delete'>","<input type=submit name=beh value=handle>",1);
}else{
echo "<tr><td align=right><b><input type=submit name=del value='Delete'></b></td><td bgcolor=green><input type=submit name=abeh value=dehandle></td></tr>";
}
echo "<input type=hidden name=id value=".$row[id].">";
echo "</center></td></tr></table>";
echo "<br>";
echo "</form>";
}

echo "</table>";

break; ///////////////////////////// Avatarer slut
*/
case inlagg: //////////////////////////////// Inl�gg start
echo "<table border=1 cellpadding=10 width=750><tr><td><center>";
$res = mysql_query("SELECT * FROM report WHERE typ='$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$nam = mysql_query("SELECT id,username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
echo "<form method=post>";

$ar = mysql_query("SELECT topicid,userid,body FROM posts WHERE id = '$row[reportid]'");
$arr = mysql_fetch_array($ar);
$top = mysql_query("SELECT subject FROM topics WHERE id = '$arr[topicid]'");
$topic = mysql_fetch_array($top);
$wri = mysql_query("SELECT username FROM users WHERE id = '$arr[userid]'");
$writer = mysql_fetch_array($wri);

echo "<table border=1 cellpadding=5 class=main>";
tr("Topic","<a href=forums.php?action=viewtopic&topicid=$arr[topicid]>$topic[subject]</a>",1);
tr("Message",format_comment($arr[body]),1);
tr("Author","<a href=userdetails.php?id=$arr[userid]>$writer[username]</a>",1);
tr("reason",$row[reason]);
tr("reporter","<a href=userdetails.php?id=$row[reporter]>$namn[username]</a>",1);
if($row[behandla] == 'no'){
tr("<input type=submit name=del value='Delete'>","<input type=submit name=beh value=handle>",1);
}else{
echo "<tr><td align=right><b><input type=submit name=del value='Delete'></b></td><td bgcolor=green><input type=submit name=abeh value=dehandle></td></tr>";
}
echo "<input type=hidden name=id value=".$row[id].">";
echo "</table><br><br>";

echo "</form>";
}
echo "</center></td></tr></table>";
break; //////////////////////////// Inl�gg slut

case req: /////////////////////Req start

echo "<table border=1 cellpadding=5>";
echo "<tr><td class=colhead>Request</td><td class=colhead>user</td><td class=colhead>reason</td><td class=colhead>reporter</td><td class=colhead>Delete</td><td class=colhead>handle</td></tr>";
$res = mysql_query("SELECT * FROM report WHERE typ='$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$ar = mysql_query("SELECT * FROM requests WHERE id = '$row[reportid]'");
$arr = mysql_fetch_array($ar);
$req = mysql_query("SELECT id,username FROM users WHERE id = '$arr[userid]'");
$reqer = mysql_fetch_array($req);
$nam = mysql_query("SELECT id,username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
echo "<form method=post>";

echo "<tr>";
echo "<td><a href=".$arr[link].">".$arr[name]."</a> <a href=editrequest.php?action=edit&id=".$row[reportid]."><i> Modifiera</i></a></td>";
echo "<td><a href=userdetails.php?id=".$arr[userid].">".$reqer[username]."</a></td>";
echo "<td>".$row[reason]."</td>";
echo "<td><a href=userdetails.php?id=".$namn[id].">".$namn[username]."</a></td>";
echo "<td><input type=submit name=del value='Delete'></td>";
if($row[behandla] == 'no'){
echo "<td><input type=submit name=beh value=handle></td>";
}else{
echo "<td bgcolor=green><input type=submit name=abeh value=Avehandla>";
}
echo "</tr>";
echo "<input type=hidden name=id value=".$row[id].">";
echo "</form>";
}
echo "</table>";
break; ////////////////////////////Req slut
/*
case trad: //////////////////////////Tr�dar start
echo "<table border=1 cellpadding=5>";
echo "<tr><td class=colhead>Tr�d</td><td class=colhead>Skapad av</td><td class=colhead>reason</td><td class=colhead>reporter</td><td class=colhead>Delete</td><td class=colhead>handle</td></tr>";
$res = mysql_query("SELECT * FROM report WHERE typ='$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$top = mysql_query("SELECT subject,userid FROM topics WHERE id = '$row[reportid]'");
$topic = mysql_fetch_array($top);
$nam = mysql_query("SELECT id,username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
$skap = mysql_query("SELECT username FROM users WHERE id = '$topic[userid]'");
$skapad = mysql_fetch_array($skap);
echo "<form method=post>";

echo "<tr>";
echo "<td><a href=forums.php?action=viewtopic&topicid=$row[reportid]>$topic[subject]</a></td>";
echo "<td><a href=userdetails.php?id=".$topic[userid].">".$skapad[username]."</a></td>";
echo "<td>".$row[reason]."</td>";
echo "<td><a href=userdetails.php?id=".$row[reporter].">".$namn[username]."</a></td>";
echo "<td><input type=submit name=del value='Delete'></td>";
if($row[behandla] == 'no'){
echo "<td><input type=submit name=beh value=handle></td>";
}else{
echo "<td bgcolor=green><input type=submit name=abeh value=Avehandla></td>";
}
echo "</tr>";
echo "<input type=hidden name=id value=".$row[id].">";
echo "</form>";
}
echo "</table>";
break; //////////////////////////////Tr�dar slut
*/
case user: /////////////////////////////////User start
echo "<table cellpadding=5 border=1>";
echo "<td class=colhead>user</td><td class=colhead>reason</td><td class=colhead>reporter</td><td class=colhead>Delete</td><td class=colhead>handle</td></tr>";
$res = mysql_query("SELECT * FROM report WHERE typ='$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$nam = mysql_query("SELECT username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
$usr = mysql_query("SELECT username FROM users WHERE id = '$row[reportid]'");
$user = mysql_fetch_array($usr);
echo "<form method=post>";

echo "<tr>";
echo "<td><a href=userdetails.php?id=".$row[reportid].">".$user[0]."</a></td>";
echo "<td>".$row[reason]."</td>";
echo "<td><a href=userdetails.php?id=".$row[reporter].">".$namn[0]."</a></td>";
echo "<td><input type=submit name=del value='Delete'></td>";
if($row[behandla] == 'no'){
echo "<td><input type=submit name=beh value=handle></td>";
}else{
echo "<td bgcolor=green><input type=submit name=abeh value=dehandle></td>";
}
echo "</tr>";
echo "<input type=hidden name=id value=".$row[id].">";
echo "</form>";
}
break; ///////////////User slut

case pm: /////////////////////PM start
echo "<table border=1 cellpadding=10 width=750><tr><td><center>";
$res = mysql_query("SELECT * FROM report WHERE typ = '$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$nam = mysql_query("SELECT username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
$ar = mysql_query("SELECT receiver,sender,msg,title FROM messages WHERE id = '$row[reportid]'");
$arr = mysql_fetch_array($ar);
$rec = mysql_query("SELECT username FROM users WHERE id = '$arr[receiver]'");
$receiver = mysql_fetch_array($rec);
$sen = mysql_query("SELECT username FROM users WHERE id = '$arr[sender]'");
$sender = mysql_fetch_array($sen);
echo "<table cellpadding=5 class=main>";
echo "<form method=post>";

if ($arr[sender] == "0") { $sender[0] = "<b>System</b>"; }
if($sender[0] == "") { $sender[0] = "<i>Bortagen</i>"; }

tr("Mottagare","<a href=userdetails.php?id=".$arr[receiver].">".$receiver[0]."</a>",1);
tr("Avs�ndare","<a href=userdetails.php?id=".$arr[sender].">".$sender[0]."</a>",1);
tr("Titel",$arr[title]);
tr("PMet",format_comment($arr[msg]),1);
tr("reason",$row[reason]);
tr("reporter","<a href=userdetails.php?id=".$row[reporter].">".$namn[username]."</a>",1);

if($row[behandla] == 'no'){
tr("<input type=submit name=del value='Delete'>","<input type=submit name=beh value=handle>",1);
}else{
echo "<tr><td align=right><b><input type=submit name=del value='Delete'></b></td><td bgcolor=green><input type=submit name=abeh value=dehandle></td></tr>";
}
echo "<input type=hidden name=id value=".$row[id].">";
echo "</table><br><br>";
echo "</form>";
}

echo "</center></td></tr></table>";
break; ////////////////////////////PM slut

case komm: ////////////////////Kommentarer start
echo "<table border=1 cellpadding=10 width=750><tr><td><center>";
$res = mysql_query("SELECT * FROM report WHERE typ = '$typ' ORDER BY 'id' DESC");
while($row = mysql_fetch_array($res)){
$nam = mysql_query("SELECT username FROM users WHERE id = '$row[reporter]'");
$namn = mysql_fetch_array($nam);
$kom = mysql_query("SELECT user,text,torrent FROM comments WHERE id = '$row[reportid]'");
$komm = mysql_fetch_array($kom);
$usr = mysql_query("SELECT username FROM users WHERE id = '$komm[user]'");
$user = mysql_fetch_array($usr);
$torrent = mysql_fetch_array(mysql_query("SELECT name FROM torrents WHERE id = '$komm[torrent]'"));
echo "<table cellpadding=5 class=main>";
echo "<form method=post>";

tr("Torrent","<a href=details.php?id=".$komm[torrent].">".$torrent[name]."</a>",1);
tr("Kommentar",format_comment($komm[text]),1);
tr("F�rfattare","<a href=userdetails.php?id=".$komm[user].">".$user[username]."</a>",1);
tr("reason",$row[reason]);
tr("reporter","<a href=userdetails.php?id=".$row[reporter].">".$namn[username]."</a>",1);

if($row[behandla] == 'no'){
tr("<input type=submit name=del value='Delete'>","<input type=submit name=beh value=handle>",1);
}else{
echo "<tr><td align=right><b><input type=submit name=del value='Delete'></b></td><td bgcolor=green><input type=submit name=abeh value=dehandle></td></tr>";
}
echo "<input type=hidden name=id value=".$row[id].">";
echo "</table><br><br>";
echo "</form>";
}
echo "</table>";
break; //////////////////////////Kommentrarer slut

default: ////////////////////////////Framsida start
$pm = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'pm'"));
$torrents = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'torrent'"));
$req = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'req'"));
$inlagg = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'inlagg'"));
$users = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'user'"));
// $avatarer = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'avatar'"));
$kommentarer = mysql_num_rows(mysql_query("SELECT * FROM report WHERE typ = 'komm'"));

echo "<table cellpadding=5 border=1>";
tr("Torrents",$torrents);
tr("Requests",$req);
tr("PMs",$pm);
tr("Foruminl�gg",$inlagg);
tr("Kommentarer",$kommentarer);
tr("user",$users);
// tr("Avatarer",$avatarer);
echo "</table>";

break; ////////////////////////////////Framsida slut
}

stdfoot();
?>