<?
require "include/bittorrent.php";
dbconn();
stdhead();
?>
<span style="color:red">!Add your nfo here!</span>
<?
stdfoot();
?>