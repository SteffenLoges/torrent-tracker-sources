<?

  ob_start("ob_gzhandler");
  require "include/bittorrent.php";
  dbconn(false);
  loggedinorreturn();

if (get_user_class() < UC_MODERATOR)
stderr("Unauthorized", "Only staff can view the leechers list....");

  function usertable($res, $frame_caption)
  {
      global $CURUSER;
    begin_frame($frame_caption, true);
    begin_table();
?>

<p>A list of users with a ratio under 0.40 that have downloaded over 1GB.<br>
Sorted by join date (oldest first).</p>
<tr>
<td class=colhead align=left>User</td>
<td class=colhead>Uploaded</td>
<td class=colhead>Downloaded</td>
<td class=colhead align=right>Ratio</td>
<td class=colhead align=left>Joined</td>
</tr>
<?
    $num = 0;
    while ($a = mysql_fetch_assoc($res))
    {
      ++$num;
      $highlight = $CURUSER["id"] == $a["userid"] ? " bgcolor=#BBAF9B" : "";
      if ($a["downloaded"])
      {
        $ratio = $a["uploaded"] / $a["downloaded"];
        $color = get_ratio_color($ratio);
        $ratio = number_format($ratio, 2);
        if ($color)
          $ratio = "<font color=$color>$ratio</font>";
      }
      else
        $ratio = "Inf.";
      print("<tr$highlight><td align=left$highlight><a href=userdetails.php?id=" .
              $a["userid"] . "><b>" . $a["username"] . "</b>" .
              "</td><td align=right$highlight>" . mksize($a["uploaded"]) .
            "</td><td align=right$highlight>" . mksize($a["downloaded"]) .
              "</td><td align=right$highlight>" . $ratio .
              "</td><td align=left>" . gmdate("Y-m-d",strtotime($a["added"])) . " (" .
              get_elapsed_time(sql_timestamp_to_unix_timestamp($a["added"])) . " ago)</td></tr>");
    }
    end_table();
    end_frame();
  }

  stdhead("Ratio Under 0.40/1GB+ Downloaded");

    $mainquery = "SELECT id as userid, username, added, uploaded, downloaded, uploaded / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS upspeed, downloaded / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS downspeed FROM users WHERE enabled = 'yes'";

          $limit = 250;
        $order = "added ASC";
        //$order = "uploaded / downloaded ASC, downloaded DESC";
          $extrawhere = " AND uploaded / downloaded < 0.40 AND downloaded > 1073741824";
          $r = mysql_query($mainquery . $extrawhere . " ORDER BY $order " . " LIMIT $limit") or sqlerr();
          usertable($r, "Ratio Under 0.40/1GB+ Downloaded");

stdfoot();

?>