<?
require "include/bittorrent.php";
dbconn(false);

$pic_base_url = "http://localhost/pic/";

stdhead("Error 403");
print("Object not found!");
stdfoot();
?>