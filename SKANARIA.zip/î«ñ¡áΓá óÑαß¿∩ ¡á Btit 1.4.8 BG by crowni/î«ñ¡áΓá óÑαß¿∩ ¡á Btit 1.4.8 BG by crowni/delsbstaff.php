<?php

require ("include/functions.php");;
dbconn();


if ($CURUSER["id_level"] < 8)
        stderr("Error", "Permission denied.");

standardheader("ShoutBox leeren");

$res = mysql_query("TRUNCATE TABLE `shoutboxstaff`") or sqlerr();

echo ("ShoutBoxstaff a �t� vid�e avec succ�s");

?>