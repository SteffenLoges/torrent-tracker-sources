<?php
require_once ("include/functions.php");
require_once ("include/config.php");


dbconn();
standardheader("&#1054;&#1085;&#1083;&#1072;&#1081;&#1085; &#1058;&#1077;&#1083;e&#1074;&#1080;&#1079;&#1080;&#1103;");
block_begin("&#1054;&#1085;&#1083;&#1072;&#1081;&#1085; &#1058;&#1077;&#1083;e&#1074;&#1080;&#1079;&#1080;&#1103;");
?>

<br><div style="width:468px; border: dotted thin green;background-color:#ffffff">
<embed src="http://s3.amazonaws.com/fbncds/xmas-countdownf-fb.swf" width="1000" height="80" AllowScriptAccess="always" quality="high" bgcolor="#008500" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" style="border: dotted thin orangered"></embed></div><br>
<script type="text/javascript">
function song(){
document.getElementById('music1').innerHTML="<object classid='CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95' id='music1' name='mediaplayer' height='393' width='460'><param name='URL' value='"+document.getElementById('cancion').value+"'><embed type='application/x-mplayer2' id='music1' pluginspage='http://www.microsoft.com/Windows/Downloads/Contents/MediaPlayer/' name='mediaplayer' src='"+document.getElementById('cancion').value+"' autostart='true' showstatusbar='1' playcount='10' enablecontextmenu='0' height='393' width='460'></embed></object>";
}
</script>

<span id="music1">
<object width="320" height="290" classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" id="mediaplayer1">

<param name="Filename" value="kids.mpg">
<param name="AutoStart" value="True">
<param name="ShowControls" value="True">
<param name="ShowStatusBar" value="False">
<param name="ShowDisplay" value="False">
<param name="AutoRewind" value="True">
<embed type="application/x-mplayer2"
pluginspage="http://www.microsoft.com/Windows/Downloads/Contents/MediaPlayer/"
width="600" height="400" src="/support/dreamweaver/ts/documents/kids.mpg"
filename="kids.mpg" autostart="True"
showcontrols="True" showstatusbar="False"
showdisplay="False" autorewind="True"></embed>
</object>
</span>
<br /><br />
<select id="cancion" onchange="song()" size="1">
<option value="http://bgzona.info/tv_online.php">������</option>
<option value="mms://87.120.130.17/nova_live_q3.wmv">���� ��</option>
<option value="http://193.47.74.41/BTV">���</option>

<option value="mms://62.41.56.32/public_votv_fi">The Voice TV</option>
<option value="http://freebgtv.com/asx/tv2.asx">PRO BG</option>
<option value="mms://195.34.104.107/ReTV">RE TV</option>
<option value="mms://tvcosmos.ro:1234">TV Cosmos</option>
<option value="mms://93.103.4.16/playtv">Play TV</option>
<option value="http://miamitvmusic.com/miamitvmusic.asx">Miami TV Music</option>
<option value="mms://84.22.1.210/hiphoptv">HIP HOP TV</option>
<option value="mms://vipnrj.yacast.net/nrj_tvhit">NRJ HITS TV</option>
<option value="http://195.34.104.107/ReTV">RE:TV</option>

<option value="mms://212.25.37.148/EcoBulgariaTV">��� �������� ��</option>
<option value="mms://206.225.90.39:8080/">�������� ��</option>
<option value="mms://84.22.1.210/gypsy">������ ��</option>
<option value="mms://195.149.254.227:8080">��� ��</option>
<option value="http://195.24.89.251:1230/">��������� �����</option>
<option value="mms://87.120.130.6/vtk_direct_q1.wmv">VTK</option>
<option value="mms://212.25.37.148/WineTV">���� ��� ��</option>
<option value="mms://74.208.78.187/miamitvmusic">Miami Music TV</option>
<option value="mms://mms.cdn-tiscali.com/sportitalia">Sport Italia</option>

<option value="mms://194.116.83.15/New">Rock New</option>
<option value="mms://194.116.83.15/Soft and Ballads">Rock Ballads</option>
<option value="mms://www.streetclip.tv:1234/">Street Clip TV</option>
<option value="mms://ml2.gazeta.pl/kiss_tv">Kiss TV</option>
<option value="mms://www.omegatv.net/live">Omega TV</option>

<option value=">������ ������ �����</option>
<option value="http://filmi-bg.net/Spread-profesija-jigolo-2009.html">�������� ������</option>
<option value="http://filmi-bg.net/Extreme-Movie-neobiknoven-film.html">����������� ����</option>
<option value="http://filmi-bg.net/Saw-VI-ubijstven-pyzel-6.html ">��������� �����</option>
<option value="http://filmibg.net/The-Hunt-for-Gollum-lovyt-za-golym-2009.html">����� �� ����� 2009</option>
<option value="http://filmi-bg.net/Gamer-gejmyr.html ">Gamer ������</option>



</select>
</td></tr></table></td></tr></table><center>
</td></tr></table></center><br>
</body></head></html>