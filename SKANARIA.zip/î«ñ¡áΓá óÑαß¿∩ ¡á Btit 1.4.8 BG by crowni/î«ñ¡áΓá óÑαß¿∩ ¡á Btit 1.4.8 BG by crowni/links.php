<?php
require_once ("include/functions.php");
require_once ("include/config.php");
dbconn();
standardheader('Links');

block_begin("Links");
		print("\n<table class=\"lista\" width=\"90%\" align=\"center\" cellspacing=\"4\" cellpadding=\"4\">\n");
			$res = mysql_query("SELECT * FROM links ORDER BY lid");
			while($result=mysql_fetch_array($res)){
    	print("<tr><td><a href=\"".$result["url"]."\" target=\"_blank\">".$result["name"]."</a></td></tr>\n");
		}
		print("\n</table>");

block_end();
stdfoot();
?>
