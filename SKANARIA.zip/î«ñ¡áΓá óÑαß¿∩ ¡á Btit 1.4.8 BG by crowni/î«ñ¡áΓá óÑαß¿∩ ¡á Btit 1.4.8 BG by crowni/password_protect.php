<?php
global $BASEURL;

###############################################################
#Password Protection for a single file. Fixed by fatepower.
###############################################################
# Usage:
# Set usernames / passwords below between SETTINGS START and SETTINGS END.
# Open it in browser with "help" parameter to get the code
# so you can add this into more file (if you want).
#    Example: www.yourdomaion.com/password_protect.php?help
# Include protection string which it gave you into every file that needs to be protected
#
# Add following HTML code to your page where you want to have logout link
# <a href="http://www.example.com/path/to/protected/page.php?logout=1">Logout</a>
#
###############################################################

##################################################################
#  SETTINGS START
##################################################################

// Add login/password pairs below, like described above
// NOTE: all rows except last must have comma "," at the end of line
$LOGIN_INFORMATION = array(
  'gettorrent' => '1234567art',
  'root' => 'root'
);

// request login? true - show login and password boxes, false - password box only
define('USE_USERNAME', true);

// User will be redirected to this page after logout
// UPDATED, Not needed to be added becasue of the defined of the BASEURL
//define('LOGOUT_URL', 'http://www.yourdomainhere.com');

// time out after NN minutes of inactivity. Set to 0 to not timeout
define('TIMEOUT_MINUTES', 20);

// This parameter is only useful when TIMEOUT_MINUTES is not zero
// true - timeout time from last activity, false - timeout time from login
define('TIMEOUT_CHECK_ACTIVITY', true);

##################################################################
#  SETTINGS END
##################################################################


///////////////////////////////////////////////////////
// Do not change code below, if u not know what you do.
///////////////////////////////////////////////////////

// show usage example
if(isset($_GET['help'])) {
  die('Include following code into every page you would like to protect, at the very beginning (first line):<br>&lt;?php include("' . str_replace('\\','\\\\',__FILE__) . '"); ?&gt; ');
}

// timeout in seconds
$timeout = (TIMEOUT_MINUTES == 0 ? 0 : time() + TIMEOUT_MINUTES * 60);

// logout?
if(isset($_GET['logout'])) {
require_once ("include/functions.php");
  setcookie("verify", '', $timeout, '/'); // clear password;
//  header('Location: ' . LOGOUT_URL);
	redirect($BASEURL);
  exit();
}

if(!function_exists('showLoginPasswordProtect')) {

// show login form
function showLoginPasswordProtect($error_msg) {
?>
<html>
<head>
  <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
  <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
<body>
  <style>
    input { border: 1px solid black; }
  </style>
<table align="center" cellpadding="2" cellspacing="2" border="0" width="60%">
<tr>
<td align="center" class="lista">
  <form method="post">
	<br>
	<div><small>
	You are now entering a page that needs a extra login details. Be sure<br>
	that you are entering the correctly information.</small></div>
</td>
</tr>
</table>
    <br><div align=center><font color="red" size="3"><b><?php echo $error_msg; ?></b></font></div><br>
<table align="center" class="lista" border="0" cellpadding="10">
<tr>
<td class=embedded>
<h2><center>Login Form</center></h2>
<table align="center" class="lista" border="0" cellpadding="10">
<tr>
<?php if (USE_USERNAME) echo '<td align=right class=header>Username:</td><td class="lista"><input type="input" name="access_login" size="40" /></td></tr>'; ?>
<tr>
<td align="right" class="header">Password:</td>
<td class="lista"><input type="password" name="access_password" size="40" /></td>
</tr>
<tr>
<td align="left" class="header">Click Submit to Continue The Login:</td>
<td align="left" class="lista"><input type="submit" name="Submit" value="Submit" /></td>
</tr>
</table>
</table>
  </form>
  <br>
  </div>
</body>
</html>

<?php

block_end();
stdfoot();

  // stop at this point
  die();
}
}

// user provided password
if (isset($_POST['access_password'])) {

  $login = isset($_POST['access_login']) ? $_POST['access_login'] : '';
  $pass = $_POST['access_password'];
  if (!USE_USERNAME && !in_array($pass, $LOGIN_INFORMATION)
  || (USE_USERNAME && ( !array_key_exists($login, $LOGIN_INFORMATION) || $LOGIN_INFORMATION[$login] != $pass ) ) 
  ) {
    showLoginPasswordProtect("Incorrect password.");
  }
  else {
    // set cookie if password was validated
    setcookie("verify", md5($login.'%'.$pass), $timeout, '/');
    
    // Some programs (like Form1 Bilder) check $_POST array to see if parameters passed
    // So need to clear password protector variables
    unset($_POST['access_login']);
    unset($_POST['access_password']);
    unset($_POST['Submit']);
  }

}

else {

  // check if password cookie is set
  if (!isset($_COOKIE['verify'])) {
    showLoginPasswordProtect("");
  }

  // check if cookie is good
  $found = false;
  foreach($LOGIN_INFORMATION as $key=>$val) {
    $lp = (USE_USERNAME ? $key : '') .'%'.$val;
    if ($_COOKIE['verify'] == md5($lp)) {
      $found = true;
      // prolong timeout
      if (TIMEOUT_CHECK_ACTIVITY) {
        setcookie("verify", md5($lp), $timeout, '/');
      }
      break;
    }
  }
  if (!$found) {
    showLoginPasswordProtect("");
  }

}

?>