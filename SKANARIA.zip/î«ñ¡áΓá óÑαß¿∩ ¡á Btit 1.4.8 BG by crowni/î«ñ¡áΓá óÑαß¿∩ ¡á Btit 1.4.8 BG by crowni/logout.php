<?php

require_once("include/functions.php");
require_once("include/config.php");

logoutcookie();

header("Location: ./");

?>
