<?
require_once ("include/functions.php");
require_once ("include/config.php");

dbconn();

$poster = $_POST["poster"];
$cat = $_POST["cat"];
$name = $_POST["name"];
$description = $_POST["description"];
$quality = $_POST["quality"];
$video = $_POST["video"];
$audio = $_POST["audio"];
$time = $_POST["time"];
$url = $_POST["url"];
$genre = $_POST["genre"];
$director = $_POST["director"];
$staring = $_POST["staring"];
$lang = $_POST["lang"];
$imd = $_POST["imd"];
$poster = sqlesc($poster);
$cat = sqlesc($cat);
$name = sqlesc($name);
$description = sqlesc($description);
$quality = sqlesc($quality);
$genre = sqlesc($genre);
$director = sqlesc($director);
$staring = sqlesc($staring);
$video = sqlesc($video);
$audio = sqlesc($audio);
$lang = sqlesc($lang);
$time = sqlesc($time);
$url = sqlesc($url);
$imd = sqlesc($imd);

$added = sqlesc(get_date_time());
mysql_query("INSERT INTO realises (cat,poster, name, genre, director, staring,description, quality, video,audio,time,lang,url,imd,added) VALUES($cat, $poster,$name, $genre, $director,$staring, $description,$quality, $video, $audio,$time,$lang,$url,$imd,$added)") or sqlerr(__FILE__, __LINE__);
$id = mysql_insert_id();
header("Refresh: 0; url=index.php");
?> 