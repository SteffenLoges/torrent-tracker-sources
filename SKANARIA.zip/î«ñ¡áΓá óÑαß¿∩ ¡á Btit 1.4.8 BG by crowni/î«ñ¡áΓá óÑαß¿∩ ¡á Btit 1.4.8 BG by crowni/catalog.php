<?php
require_once ("include/functions.php");
require_once ("include/config.php");
require_once ("include/BDecode.php");

$scriptname = $_SERVER["PHP_SELF"];
$addparam = "";

dbconn();

standardheader('Catalog');
if(!$CURUSER || $CURUSER["can_download"]!="yes")
{	
	block_begin();
    err_msg(ERROR.NOT_AUTHORIZED." ".MNU_TORRENT."!",SORRY."...");
	block_end();
    stdfoot();
    exit();
}

block_begin(CATALOG);
// this is security addon if you don't have it don't uncomment.
// include ("include/escape.php");
if(isset($_GET["search"]))
{
    $trova = str_replace ("+"," ",$_GET["search"]);
} else {
    $trova = "";
}
?>
<script type="text/javascript">
<!--
var newwindow;
function popdetails(url)
{
  newwindow=window.open(url,'popdetails','height=500,width=500,resizable=yes,scrollbars=yes,status=yes');
  if (window.focus) {newwindow.focus()}
}
function poppeer(url)
{
  newwindow=window.open(url,'poppeers','height=400,width=700,resizable=yes,scrollbars=yes');
  if (window.focus) {newwindow.focus()}
}
// -->
</script>
<p align="center"><br>
<form action="<?=$scriptname;?>" method="get">

<table border="0" class="lista" style="border: solid 1px #ffffff" align="center">
  <tr>
  <td style="border: solid 1px #ffffff" class="block"><?=TORRENT_SEARCH;?></td>
  <td style="border: solid 1px #ffffff" class="block"><?=CATEGORY_FULL;?></td>
  <td style="border: solid 1px #ffffff" class="block"><?=TORRENT_STATUS;?></td>
  <td style="border: solid 1px #ffffff" class="block">&nbsp;</td>
  </tr>
  <tr>
  <td><input type="text" name="search" size="30" maxlength="50" value="<?=$trova;?>"></td>
  <td>
 <?
    $category = (!isset($_GET["category"])?0:max(0,$_GET["category"]));
    categories( $category );

    if(isset($_GET["active"]))
    {
        $active=max(0,$_GET["active"]);
    } else {
    // active or all torrents
        $active=1;
    }
    // all
    if($active==0)
    {
        $where = " WHERE 1=1";
        $addparam.="active=0";
    } // active only
    elseif($active==1){
        $where = " WHERE seeds > 0";
        $addparam.="active=1";
    } // dead only
    elseif($active==2){
        $where = " WHERE leechers+seeds = 0";
        $addparam.="active=2";
    }
  ?>
  </td>
  <td>
  <select name="active" size="1">
  <option value="0"<? if ($active==0) echo " selected=selected " ?>><? echo ALL; ?></option>
  <option value="1"<? if ($active==1) echo " selected=selected " ?>><? echo ACTIVE_ONLY; ?></option>
  <option value="2"<? if ($active==2) echo " selected=selected " ?>><? echo DEAD_ONLY; ?></option>
  </select>
  </td>
  <td><input type="submit" value="<? echo SEARCH; ?>"></td>
  </tr>
  </table>
</form>
</p>
<center><TABLE width=100%>
<TR>
<?
if ($category>0) {
   $where .= " AND category=" . $_GET["category"];
   $addparam.="&category=" . $_GET["category"];
}
global $pagertop, $pagerbottom, $query_select;
// Search
if (isset($_GET["search"])) {
   $testocercato = trim($_GET["search"]);
   $testocercato = explode(" ",$testocercato);
   if ($_GET["search"]!="")
      $search = "search=" . implode("+",$testocercato);
    for ($k=0; $k < count($testocercato); $k++) {
        $query_select .= " namemap.filename LIKE '%" . mysql_escape_string($testocercato[$k]) . "%'";
        if ($k<count($testocercato)-1)
           $query_select .= " AND ";
    }
    $where .= " AND " . $query_select;
}
// porn hack and the 30 is my porn category
 if($CURUSER['showporn']=='no'){
 $where .= " AND category != 30 ";
 }
// end

$res = mysql_query("SELECT COUNT(*) FROM summary LEFT JOIN namemap ON summary.info_hash = namemap.info_hash $where")
        or die(mysql_error());

$row = mysql_fetch_row($res);
$count = $row[0];
if (!isset($search)) $search = "";

if ($count) {
   if ($addparam != "") {
      if ($search != "")
         $addparam .= "&" . $search . "&";
      //else
          //$addparam .= "&";
   }
   else {
      if ($search != "")
         $addparam .=  $search . "&";
      else
          $addparam .= ""; // . "?";
      }

    $torrentperpage=max(0,$CURUSER["torrentsperpage"]);
    if ($torrentperpage==0)
        $torrentperpage=($ntorrents==0?15:$ntorrents);

    // getting order
    if (isset($_GET["order"]))
         $order=htmlspecialchars($_GET["order"]);
    else
        $order="data";

    if (isset($_GET["by"]))
        $by=htmlspecialchars($_GET["by"]);
    else
        $by="DESC";
    list($pagertop, $pagerbottom, $limit) = pager($torrentperpage, $count,  $scriptname."?" . $addparam.(strlen($addparam)>0?"&":"")."order=$order&by=$by&");

// Do the query with the uploader nickname
if ($SHOW_UPLOADER)
    $query = "SELECT summary.info_hash as hash, summary.seeds, summary.leechers, format( summary.finished, 0  ) as finished,  summary.dlbytes as dwned , namemap.filename, namemap.sub_url, namemap.url, namemap.info, namemap.anonymous, summary.speed, UNIX_TIMESTAMP( namemap.data ) as added, categories.image, categories.name as cname, namemap.category as catid, namemap.size, namemap.external, namemap.uploader, users.username as uploader FROM summary LEFT JOIN namemap ON summary.info_hash = namemap.info_hash LEFT JOIN categories ON categories.id = namemap.category LEFT JOIN users ON users.id = namemap.uploader $where ORDER BY $order $by $limit";

// Do the query without the uploader nickname
else
    $query = "SELECT summary.info_hash as hash, summary.seeds, summary.leechers, format( summary.finished, 0  ) as finished,  summary.dlbytes as dwned , namemap.filename, namemap.sub_url, namemap.url, namemap.info, summary.speed, UNIX_TIMESTAMP( namemap.data ) as added, categories.image, categories.name as cname, namemap.category as catid, namemap.size, namemap.external, namemap.uploader FROM summary LEFT JOIN namemap ON summary.info_hash = namemap.info_hash LEFT JOIN categories ON categories.id = namemap.category $where ORDER BY $order $by $limit";
// End the queries
   $results = mysql_query($query) or err_msg(ERROR,CANT_DO_QUERY.mysql_error()."<br>".$query);
}

$i = 0;

if ($by=="ASC")
    $mark="&nbsp;&#8593";
else
    $mark="&nbsp;&#8595";
// end code
?>
</TR>
<TR>
<TD colspan="2" align="center"> <? echo $pagertop ?></td></tr></table>
<center><br>
<?
if ($count) {
  if (!isset($values[$i % 2])) $writeout = "";
  else $writeout = $values[$i % 2];
  while ($data=mysql_fetch_array($results))
  {
// search for comments
//   $commentres = mysql_query("SELECT COUNT(*) as comments FROM comments WHERE info_hash='" . $data["hash"] . "'");
//   $commentdata = mysql_fetch_assoc($commentres);
//  echo "<TR>\n";
$res1 = mysql_query("SELECT image FROM namemap WHERE info_hash='" . $data["hash"] . "'")or die(mysql_error());
$row1 = mysql_fetch_array($res1);
?>
<TABLE width=95% style="border: solid 1px #ffffff" class="header" border="0">
  <tr>
    <td width="128" rowspan="2" valign="top" class="lista" style="border: solid 1px #ffffff"><div align="center">
<?   
if (!empty($row1["image"]))
{
$image1 = "".$row1["image"]."";
echo "<img src=\"$image1\" border='0' width=130>";
}
if (empty($row1["image"]))
   echo "<img src='images/noimg.gif' border='0' width=130>";
?>
</div></td>
    <td height="10" colspan="2" align=left valign=top class="lista" style="border: solid 1px #ffffff"><div align="left">
<?
$res1 = mysql_query("SELECT namemap.info_hash, namemap.filename, namemap.url,UNIX_TIMESTAMP(namemap.data) as data, namemap.size, namemap.comment, categories.name as cat_name, summary.seeds, summary.leechers, summary.finished, summary.speed, namemap.external, namemap.announce_url,UNIX_TIMESTAMP(namemap.lastupdate) as lastupdate, namemap.anonymous, users.id, users.username FROM namemap LEFT JOIN categories ON categories.id=namemap.category LEFT JOIN summary ON summary.info_hash=namemap.info_hash LEFT JOIN users ON users.id=namemap.uploader WHERE namemap.info_hash ='" . $data["hash"] . "'")
    or die(mysql_error());
$row1 = mysql_fetch_array($res1);
print("&nbsp;".TITLE.": <font size=2 color=#4E4E9C><b>" . $row1["filename"]. "</font></b>");
?>	
	</div></td>
    <td width="205" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
print("<font size=2 color=#003399>&nbsp;".SIZE.": </font>" . makesize($data["size"]) . "");
?>	
	</div></td>
    <td width="134" height="22" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
print ("<A HREF=\"details.php?id=".$data["hash"]."\" title=\"".VIEW_DETAILS.":\">".TORRENT_DETAIL."</a></div>");
?></td>
    <td width="19" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
if ($CURUSER["uid"]==$data["uploader"] || $CURUSER["edit_torrents"]=="yes")
     print("<a href=edit.php?info_hash=".$data["hash"]."&returnto=".urlencode("catalog.php").">".image_or_link("$STYLEPATH/edit.png","","".EDIT."")."</a>");
?>	
	</div></td>
  </tr>
  <tr>
    <td height="156" colspan="4" style="border: solid 1px #ffffff"><div align="left">
<?
if (!$row1)
   die("Bad ID!");
if (strlen($row1["comment"])> 300)
  {
  $extension = " ...";
  // 250 is the number of simbols to get from descr.
  $row1["comment"] = substr($row1["comment"], 0, 20000)."$extension";
}
echo "<table width=\"99%\" border=\"0\" align=\"center\">
<tr>
<td>";
  print("" . format_comment($row1["comment"]) . "");
echo "</td></tr></table>";
?>	
	</div></td>
    <td style="border: solid 1px #ffffff"><div align="center">
<?
  print("<A HREF=download.php?id=".$data["hash"]."&f=" . urlencode($data["filename"]) . ".torrent><img src=images/dcatalog.gif border=\"0\" alt=\"Download Torrent File\"></A>");
?>	
	</div></td>
  </tr>
  <tr>
    <td height="22" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
// if ($SHOW_UPLOADER && $data["anonymous"] == "true")
// echo "\t" . ANONYMOUS . "\n";
// elseif ($SHOW_UPLOADER && $data["anonymous"] == "false")
// echo "\tUp by : <a href=userdetails.php?id=" . $CURUSER["uploader"] . ">".StripSlashes($data['prefixcolor'].$data["uploader"].$data['suffixcolor'])."</a>\n";
$vres = mysql_query("SELECT sum(rating) as totrate, count(*) as votes FROM ratings WHERE infohash = '" . $data["hash"] . "'");
$vrow = @mysql_fetch_array($vres);
    if ($vrow && $vrow["votes"]>=1)
      {
        $totrate=round($vrow["totrate"]/$vrow["votes"],1);
      if ($totrate==5)
       $totrate="<img src=$STYLEPATH/5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
    elseif ($totrate>4.4 && $totrate<5)
       $totrate="<img src=$STYLEPATH/4.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
    elseif ($totrate>3.9 && $totrate<4.5)
       $totrate="<img src=$STYLEPATH/4.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
    elseif ($totrate>3.4 && $totrate<4)
       $totrate="<img src=$STYLEPATH/3.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
    elseif ($totrate>2.9 && $totrate<3.5)
       $totrate="<img src=$STYLEPATH/3.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
    elseif ($totrate>2.4 && $totrate<3)
       $totrate="<img src=$STYLEPATH/2.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
    elseif ($totrate>1.9 && $totrate<2.5)
       $totrate="<img src=$STYLEPATH/2.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
    elseif ($totrate>1.4 && $totrate<2)
       $totrate="<img src=$STYLEPATH/1.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
    else
       $totrate="<img src=$STYLEPATH/1.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
 }
else
   $totrate=NA;
?>
	</div></td>
    <td width="228" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
print("".RATING." :  $totrate");
?>	
	</div></td>
    <td width="215" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
print("<center>".SEEDERS." / ".LEECHERS.": <font color=#009300>" . $data["seeds"] . "</font> / <font color=#CC0000>" .$data["leechers"] . "\n</font>");
?>	
	</div></td>
    <td style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
echo "\t".ADDED.":  " . date("d/m/Y",$data["added"]) . "";
?>	
	</div></td>
    <td valign="baseline" style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
// sub_url hack, print image/link if have link added
// if you don't have it, comment next 4 lines
if ($data["sub_url"] == !NULL)
print("".SUB_TITLE." : ".($data["sub_url"]==""?"":"<a href=".unesc($data["sub_url"])." border=0 target=_blank>".image_or_link("$STYLEPATH/bgsub.gif","",SUB_TITLE)."</a>")."");
else 
echo "".SUB_TITLE." : ".NONE."";

?></div></td>
    <td style="border: solid 1px #ffffff" class="lista"><div align="center">
<?
 if ($CURUSER["uid"]==$data["uploader"] || $CURUSER["delete_torrents"]=="yes")
print("<a href=delete.php?info_hash=".$data["hash"]."&returnto=".urlencode("catalog.php").">".image_or_link("$STYLEPATH/delete.png","","".DELETE."")."</a>");
?>
	</div></td>
  </tr>
  <tr>
    <td height="22" colspan="6" class="block"  style="border: solid 1px #ffffff"></td>
</tr>
</table>
<TABLE width=95% style="border: solid 1px #ffffff" class="header" border="5">
<?
echo "</div></td></tr>";
	$i++;
 }
}
if ($i == 0 && $SHOW_UPLOADER)
?>
</table><br>
<TR><TD COLSPAN=2 align=center style="border: solid 1px #ffffff"><br><? echo $pagerbottom ?><br></TD></TR>
<?
block_end();
stdfoot();
?>