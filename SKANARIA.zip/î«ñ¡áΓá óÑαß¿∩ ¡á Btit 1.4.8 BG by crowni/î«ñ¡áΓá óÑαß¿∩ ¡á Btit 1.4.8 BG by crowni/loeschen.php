<? 
require ("include/functions.php");;
dbconn();
$id = $_GET['delete'];

 
    @mysql_connect($mysql_host, $mysql_user, $mysql_pass); 
    @$x=mysql_select_db($mysql_db); 

    $result  = mysql_query("DELETE FROM partner  
                WHERE ID='$id'");
?> 
<meta http-equiv="refresh" content="0 URL=addpartner.php">
<meta name="robots" content="noindex">