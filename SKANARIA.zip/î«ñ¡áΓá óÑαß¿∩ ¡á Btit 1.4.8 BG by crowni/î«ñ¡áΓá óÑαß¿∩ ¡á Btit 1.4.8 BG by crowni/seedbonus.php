<?
// SeedBonus Mod by CobraCRK   -   original ideea by TvRecall...
//cobracrk[at]yahoo.com
//www.extremeshare.org

require_once ("include/functions.php");
require_once ("include/config.php");

dbconn();

standardheader('Seed Bonus');

if ($CURUSER["view_torrents"]=="no")
   {
       err_msg(ERROR,NOT_AUTH_VIEW_NEWS);
       stdfoot();
       exit;
}
else
    {

block_begin("Seed Bonus");

?>
<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-size: x-large;
}
.style2 {font-size: x-large}
-->
</style>

<p align="center"><?php
$r=mysql_query("SELECT seedbonus FROM users WHERE id=$CURUSER[uid]");
$cc=mysql_result($r,0,"seedbonus");
echo "<br><center><h1>".BONUS_INFO1."$cc ).<br>".BONUS_INFO2."</h1></center>";

?></p>
<p>&nbsp;</p>
<table width="474" border="1" align="center" cellpadding="2" cellspacing="0">
  <tr>
    <td width="26"><?php echo OPTION; ?></td>
    <td width="319"><?php echo WHAT_ABOUT; ?></td>
    <td width="41"><?php echo POINTS; ?></td>
    <td width="62"><?php echo EXCHANGE; ?> </td>
  </tr>
  <?php
  $uid=$CURUSER['uid'];
  $r=mysql_query("SELECT * from users where id=$uid");
  $c=mysql_result($r,0,"seedbonus");
  $r=mysql_query("SELECT * FROM bonus");
  while($row = mysql_fetch_array($r)){  
  if($c<$row['points']) { $enb="disabled"; }
  echo "<form action=seedbonus_exchange.php?id=".$row['id']." method=post><tr>
    <td><h1><center>".$row['name']."</center></h1></td>
    <td><b>".$row['gb']." GB Upload</b><br>".BONUS_DESC."</td>
    <td>".$row['points']."</td>
    <td><input type=submit name=submit value=\"".EXCHANGE."!\" $enb></td>
  </tr></form>";

}
?>

</table>
<p align="center" class="style1">&nbsp;</p>
<p class="style2"><?
echo "<center><h1>".BONUS_INFO3."</h1></center>";
block_end();
}

stdfoot();
?>
</p>