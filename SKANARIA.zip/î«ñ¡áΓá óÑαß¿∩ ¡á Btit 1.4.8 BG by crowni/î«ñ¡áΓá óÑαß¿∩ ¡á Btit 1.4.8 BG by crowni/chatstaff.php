<?php
$msg = array (
  0 => 
  array (
    'pseudo' => 'Infernal',
    'texte' => 'test',
    'date' => 1233834237,
  ),
)
?>