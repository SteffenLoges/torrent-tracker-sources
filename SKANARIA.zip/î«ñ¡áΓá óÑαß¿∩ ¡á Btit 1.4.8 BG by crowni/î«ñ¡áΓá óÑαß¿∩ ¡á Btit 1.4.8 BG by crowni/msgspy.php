<?
// Message spy by TeeSee64

require_once("include/functions.php");
require_once("include/config.php");

dbconn(true);

standardheader("msgspy");


if (!$CURUSER || $CURUSER["admin_access"]!="yes")
   {
       err_msg(ERROR,NOT_ADMIN_CP_ACCESS);
       stdfoot();
       exit;
}


block_begin("Messages Spy");

$res2 = mysql_query("SELECT COUNT(*) FROM messages $where");
        $row = mysql_fetch_array($res2);
        $count = $row[0];
$perpage = 15;
    list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?msgspy=msgspy&" );
echo $pagertop;

$res = mysql_query("SELECT * FROM messages ORDER BY id DESC $limit") or sqlerr(__FILE__, __LINE__);
  print("<table border=1 cellspacing=0 cellpadding=3>\n");
  ///////////////////////////////////////
?>
<form method="post" action="<?$SITEURL?>take-deletepm.php">
<?
///////////////////////////////////////
  print("<tr><td class=table_head align=left>Sender</td><td class=table_head align=left>Receiver</td><td class=table_head align=left>Text</td><td class=table_head align=left>Date</td><td class=table_head>Delete</td></tr>\n");
  while ($arr = mysql_fetch_assoc($res))
  {
    $res2 = mysql_query("SELECT username FROM users WHERE id=" . $arr["receiver"]) or sqlerr();
    $arr2 = mysql_fetch_assoc($res2);
    $receiver = "<a href=userdetails.php?id=" . $arr["receiver"] . "><b>" . $arr2["username"] . "</b></a>";
    $res3 = mysql_query("SELECT username FROM users WHERE id=" . $arr["sender"]) or sqlerr();
    $arr3 = mysql_fetch_assoc($res3);
    $sender = "<a href=auserdetails.php?id=" . $arr["sender"] . "><b>" . $arr3["username"] . "</b></a>";
             if( $arr["sender"] == 2 )
             $sender = "<font color=red><b>System</b></font>";
    $msg = format_comment($arr["msg"]);
  $added = format_comment(date("d/m/Y", $arr["added"]));
  print("<tr><td align=left class=table_col1>$sender</td><td align=left class=table_col2>$receiver</td><td align=left class=table_col1>$msg</td><td align=left class=table_col2>$added</td>");
  
/////////////////////////////////////////////////////////////////////////////////
  if ($_GET[check] == "yes") {
    echo("</td><TD class=table_col1><INPUT type=\"checkbox\" checked name=\"delmp[]\" value=\"" . $arr['id'] . "\"></TD>\n</TR>\n");
   }
   else {
    echo("</td><TD class=table_col1><INPUT type=\"checkbox\" name=\"delmp[]\" value=\"" . $arr['id'] . "\"></TD>\n</TR>\n");
   }

  /////////////////////////////////////////////////////////////////////////////////
}
print("</table>");

print("<table align=center width=100%>");
print("<td align=right width=100%><input type=submit value=Delete!></table>");
print($pagerbottom);
print("<table align=center width=100%>");
print("<td align=center width=100%><a href=admincp.php>Terug</a></table>");
?>
</form>
<?
block_end();
stdfoot();
?>