<?

require_once ("include/functions.php");
require_once ("include/config.php");
//require_once ("include/shoutcast.php");
dbconn();


if (isset($_GET['del']))
{
if (is_numeric($_GET['del']))
{
$query = "SELECT * FROM shoutboxstaff WHERE msgid=".$_GET['del'];
$result = mysql_query($query);
}
else {
echo "<center>Invalid message ID</center>";
exit;}

$row = mysql_fetch_row($result);

if ($CURUSER["edit_news"]=="yes" || $CURUSER["delete_news"]=="yes")
{
$query = "DELETE FROM shoutboxstaff WHERE msgid=".$_GET['del'];
mysql_query($query);
}
}
//get the current theme


?><head>

<title>shoutboxstaff</title>
<link rel="stylesheet" href="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"] . "/" . $GLOBALS["ss_uri"]?>.css" type="text/css">
<style type="text/css">
A {font-size:13px; font-weight: bold}
.date {font-size: 7pt;}

</style>

<meta http-equiv="raffraichir" content="45; URL=/shoutboxstaff.php">
<!--<script type="text/javascript" src="http://www.ad4cash.de/script.php?s=2373"></script>
<script Language="JavaScript">
document.write ('<scr' + 'ipt Language="JavaScript" src="http://www.euros4click.de/showme.php?id=7804&rnd=' + Math.random() + '&popup=false&layer=true"></scr' + 'ipt>');
</script>-->
</head>
<body>
<?

		
		
if($_GET["sent"]=="yes")
{
mysql_query("SELECT * FROM users WHERE id=$CURUSER[uid]");
$userid=$CURUSER["uid"];
$user=$CURUSER["username"];
$date=time();
$message=trim($_GET["shbox_text"]);

mysql_query("INSERT INTO shoutboxstaff (msgid, userid, user, date, message) VALUES ('msgid'," . sqlesc($userid) . ", " . sqlesc($user) . ", $date, " . sqlesc($message) . ")") or sqlerr(__FILE__, __LINE__);
}

/* print("<table class=tableb border=1 cellspacing=0 bordercolor='blue' style='border-style:outset' width='100%'><tr>");
       if ($stats["streamstatus"] == 1) {
       echo "<td class=tablea width='100%' align='center'><center><p><b><a href=\"http://xxx:8000/listen.pls\"><font color=orange>Jetzt im Radio : ".htmlspecialchars($stats["songtitle"])." @ ".$stats["bitrate"]." kbps</font></a></b><p></center></td>";
       } else{
       echo "<td width=100%><center><b><font color=orange><marquee scrollamount=2 behavior=alternate sc>Radio1 : zur Zeit ist kein DJ auf Sendung!</marquee></font></b></center></td>";
       }
print("</tr></table>\n");

print("<table class=tableb border=1 cellspacing=0 bordercolor='blue' style='border-style:outset' width='100%'><tr>");
       if ($stats1["streamstatus"] == 1) {
       echo "<td class=tablea width='100%' align='center'><center><p><b><a href=\"http://xxx:8002/listen.pls\"><font color=orange>Jetzt im Guest Dj Radio : ".htmlspecialchars($stats1["songtitle"])." @ ".$stats1["bitrate"]." kbps</font></a></b><p></center></td>";
       } else{
       echo "<td width=100%><center><b><font color=orange><marquee scrollamount=2 behavior=alternate sc>Guest Dj Radio : zur Zeit ist kein DJ auf Sendung!</marquee></font></b></center></td>";
       }
print("</tr></table>\n"); */

$res = mysql_query("SELECT * FROM shoutboxstaff ORDER BY date DESC LIMIT 70") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) == 0)
print("\n");
 else
{
print("<tr>");
print("<table class=tablea border=0 cellspacing=0 cellpadding=2 width='100%' align='left'>\n");

while ($arr = mysql_fetch_assoc($res))
{
$res2 = mysql_query("SELECT users_level.prefixcolor AS prefixcolor, users_level.suffixcolor AS suffixcolor, users.id AS id, users.username AS username  FROM users INNER JOIN users_level ON users.id_level=users_level.id WHERE users.id=$arr[userid]") or sqlerr(__FILE__, __LINE__);
$arr2 = mysql_fetch_assoc($res2);


if ($CURUSER["id_level"] >= 8) {
$del="<font color=red><a href=shoutboxstaff.php?del=".$arr[msgid]."><font color=white>Erase<font color=red></a>";
}

if ($CURUSER["id_level"] >= 7) {
$del="<font color=red><a href=shoutboxstaff.php?del=".$arr[msgid]."><font color=white>Erase<font color=red></a>";
}

print("<tr><td><a href='userdetails.php?id=".$arr["userid"]."' target='_top'>".unesc($arr2["prefixcolor"]).unesc($arr["user"]).unesc($arr2["suffixcolor"])."</a>&nbsp;<font color='blanc'><span class='date'>(".strftime("%d.%m. %H:%M",$arr["date"]).")</span>: <font color='orange'><font class='text'>".format_comment($arr["message"])." $del</td></tr>\n");}
print("</table>");
}
block_end();?>

</body>
</html>