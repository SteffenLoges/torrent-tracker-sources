<?

require ("include/functions.php");
dbconn();

function insert_tag($name, $description, $syntax, $example, $remarks)
{
	$result = format_comment($example);
	print("<p class=sub><b>$name</b></p>\n");
	begin_table(TRUE);
	print("<tr valign=top><td width=15% class=tablea>Description:</td><td class=tableb>$description\n");
	print("<tr valign=top><td class=tablea>Syntax:</td><td class=tableb><tt>$syntax</tt>\n");
	print("<tr valign=top><td class=tablea>Exemple:</td><td class=tableb><tt>$example</tt>\n");
	print("<tr valign=top><td class=tablea>R�sultat:</td><td class=tableb>$result\n");
	if ($remarks != "")
		print("<tr><td class=tablea>description:</td><td class=tableb>$remarks\n");
	end_table();
}

standardheader("Tags");
block_begin("Tags");
$test = $_POST["test"];
?>
<p>Ce Tracker soutient une rang�e <i>BBCodes</i>, Tu peux utiliser pour donner un peu plus de "sifflement" � tes contributions etc.
 Tu peux utiliser ces codes dans des commentaires, descriptions de Torrent, signatures, 
 � PMs et dans des contributions de forum.</p>
 
 <form method=post action=?>
<p align="center">
<textarea name=test cols=60 rows=3><? print($test ? htmlspecialchars($test) : "")?></textarea><br><br>
<input type=submit value="Teste celui-ci BBCode!" style='height: 23px; margin-left: 5px'>
</p>
</form>
<?

if ($test != "")
  print("<p><b>Ton BBCode para�tra comme �a:</b><br><hr>" . format_comment($test) . "<hr></p>\n");

insert_tag(
	"gras",
	"texte en gras entre les parentheses.",
	"[b]<i>Text</i>[/b]",
	"[b]texte en gras.[/b]",
	""
);

insert_tag(
	"italique",
	"Mtexte en italique entre les parentheses.",
	"[i]<i>Text</i>[/i]",
	"[i]texte en italiques.[/i]",
	""
);

insert_tag(
	"souligner",
	"souligner le texte entre les parentheses.",
	"[u]<i>Text</i>[/u]",
	"[u]souligner le texte.[/u]",
	""
);

insert_tag(
	"couleur (Alt. 1)",
	"Si la couleur du texte enferm� change.",
	"[color=<i>couleur</i>]<i>Texte</i>[/color]",
	"[color=red]Ce texte est rouge.[/color]",
	"Quelles couleurs sont valables, d�pend du navigateur utilis�. Tu trouves un aper�u sur les noms de couleur valables � <a href=\"http://www.w3.org/TR/html4/types.html#type-color\">WorldWideWeb Consortium (W3C)</a>."
);

insert_tag(
	"couleur (Alt. 2)",
	"Si la couleur du texte enferm� change.",
	"[color=#<i>RGB</i>]<i>Texte</i>[/color]",
	"[color=#ff0000]Ce texte est rouge.[/color]",
	"<i>RGB</i> si Hexadezimalzahl de 6 chiffres doit �tre. Chaque fois deux lieux d�finissent la luminosit� des couleurs principales Rouge, des verts et le bleu (dans cet ordre). FF0000 est rouge, 00FF00 le plein vert et 0000DE PREMIERE QUALITE le bleu."
);

insert_tag(
	"taille",
	"Si la taille du texte indiqu� commande.",
	"[size=<i>n</i>]<i>text</i>[/size]",
	"[size=4]la taille et 4.[/size]",
	"<i>n</i> si un chiffre de 1 (le plus au minimum) jusqu'� 7 doit �tre (plus grand). La grandeur de standard est 2."
);

insert_tag(
	"Caract�re",
	"Si met le caract�re du texte enferm�.",
	"[font=<i>caractere</i>]<i>Text</i>[/font]",
	"[font=Impact]Salut le monde![/font]",
	"Tu peux indiquer plusieurs caract�res par la virgule de mani�re s�par�e. Pense s'il vous pla�t que chaque utilisateur n'a pas aussi install� Fonts que Tu utilises."
);

insert_tag(
	"Centre",
	"Indique le texte de mani�re centr�e.",
	"[center]<i>Texte</i>[/center]",
	"[center]texte centrer[/center]",
	""
);

insert_tag(
	"lien url (Alt. 1)",
	"mets le lien d'un site.",
	"[url]<i>URL</i>[/url]",
	"[url]http://www.example.com/[/url]",
	"Ce jour est superflu. Tous les URLs sont repr�sent�s automatiquement comme le lien."
);

insert_tag(
	"lien(Alt. 2)",
	"lien url.",
	"[url=<i>URL</i>]<i>lienText</i>[/url]",
	"[url=http://www.example.com/]Beispiellink[/url]",
	"Tu as besoin de ce jour seulement utilisent, si le texte indiqu� doit se distinguer de l'adresse de lien."
);

insert_tag(
	"Image (Alt. 1)",
	"Si un graphique ins�re.",
	"[img=<i>URL</i>]",
	"[img=http://tracker-netvision.ath.cx/".$GLOBALS["PIC_BASE_URL"]."cat_movies2.gif]",
	"URL doit avec <b>.gif</b>, <b>.jpg</b> oder <b>.png</b> enden."
);

insert_tag(
	"image (alt. 2)",
	"si un graphique insere.",
	"[img]<i>URL</i>[/img]",
	"[img]http://tracker-netvision.ath.cx/".$GLOBALS["PIC_BASE_URL"]."cat_movies2.gif[/img]",
	"url doit avec <b>.gif</b>, <b>.jpg</b> oder <b>.png</b> enden."
);

insert_tag(
	"Citation (Alt. 1)",
	"Si une citation ins�re.",
	"[quote]<i>texte citer</i>[/quote]",
	"[quote]Le renard marron rapide est envoy� sur le chien indolent.[/quote]",
	""
);

insert_tag(
	"citation (Alt. 2)",
	"insere une citation.",
	"[quote=<i>Autor</i>]<i>Zitierter text</i>[/quote]",
	"[quote=John Doe]Le renard marron rapide est envoy� sur le chien indolent.[/quote]",
	""
);

insert_tag(
	"Liste d'�num�ration",
	"Si une liste avec des symboles d'�num�ration indique.",
	"[list]<i>El�ments de listes</i>[/list]<br>[list=disc|circle|square]<i>El�ments de listes</i>[/list]",
	"[list=circle][*]Enum�ration avec des symboles de district[/list]",
	"Si aucun type de symbole n'est indiqu�, le symbole pr�r�gl� par le navigateur est utilis� pour les listes non tri�es."
);

insert_tag(
	"liste nummerote",
	"Si une liste num�rot�e indique.",
	"[list=1|a|A|i|I]<i>liste nummerote</i>[/list]",
	"[list=I][*]Punkt 1[*]Punkt 2[*]Punkt 3[*]Punkt 4[/list]",
	"\"1\" si une liste num�rot�e d�cimal indique, \"a\" und \"A\" si des lettres utilisent en plus apr�s le principe\"a., b., ..., aa., ab., ...\" und \"i\" bzw. \"I\" utilise les chiffres latins."
);

insert_tag(
	"Inscription de listes",
	"F�gt einen Inscription de listes hinzu.",
	"[*]<i>Texte</i>",
	"[list][*]Punkt 1[*]Punkt 2[/list]",
	"N'oublient pas, s'il vous pla�t, le jour [list], puisque autrement les inscriptions sont indiqu�es non correctement."
);

insert_tag(
	"Texte format�",
	"Le texte (Monospace) format�. Ne se rompt pas automatiquement.",
	"[pre]<i>Texte</i>[/pre]",
	"[pre]C'est le texte format� avec la largeur ferme.[/pre]",
	"Au caract�re utilis�, tous les signes (par exemple, le watt et I) ont la m�me largeur."
);

block_end();
stdfoot();
?>