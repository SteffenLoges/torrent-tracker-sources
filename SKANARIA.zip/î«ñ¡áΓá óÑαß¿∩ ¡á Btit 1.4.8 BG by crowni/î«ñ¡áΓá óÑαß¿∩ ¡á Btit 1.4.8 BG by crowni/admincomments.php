<?
require_once("include/functions.php");
require_once("include/config.php");

dbconn();

standardheader('Last 150 Comments');
block_begin("Last 150 Comments");

// comments...
$subres = mysql_query("SELECT comments.id, text, info_hash, UNIX_TIMESTAMP(added) as data, user, users.id as uid FROM comments LEFT JOIN users ON comments.user=users.username ORDER BY added DESC LIMIT 150");
if (!$subres || mysql_num_rows($subres)==0) {
       $s = "<br /><br />\n<table width=\"95%\" class=\"lista\">\n";
       $s .= "<tr>\n<td class=\"lista\" align=\"center\">".NO_COMMENTS."</td>\n</tr>\n";
       $s .= "</table>\n";
}
else {
     print("<br /><br />");
      $s = "<br /><br />\n<center><table width=95% class=lista>\n";
     while ($subrow = mysql_fetch_array($subres)) {
       $s .= "<tr><td class=\"header\"><a href=userdetails.php?id=".$subrow["uid"].">" . $subrow["user"] . "</td><td class=\"header\">" . date("d/m/Y H.i.s",$subrow["data"]-$offset) . "</td>\n";
       if ($CURUSER["delete_torrents"]=="yes")
         $s .= "<td class=\"header\" align=\"right\"><a onclick=\"return confirm('". str_replace("'","\'",DELETE_CONFIRM)."')\" href=\"comment.php?id=$id&cid=" . $subrow["id"] . "&action=delete\">".image_or_link("$STYLEPATH/delete.png","",DELETE)."</a>       <a href=details.php?id=".$subrow["info_hash"].">Go to Torrent</a></td>\n";
       $s .="</tr>\n";
       $s .= "<tr><td colspan=\"3\" class=\"lista\" align=\"center\">" . format_comment($subrow["text"]) . "</td></tr>\n";
        }
        $s .= "</table>\n";
}
print($s);

if ($GLOBALS["usepopup"])
    print("</div><br /><br /><center><a href=\"javascript: window.close();\">".CLOSE."</a>");
else
    print("</div><br /><br /><center><a href=\"javascript: history.go(-1);\">".BACK."</a>");
print("</center>\n");

block_end();
stdfoot();

?>