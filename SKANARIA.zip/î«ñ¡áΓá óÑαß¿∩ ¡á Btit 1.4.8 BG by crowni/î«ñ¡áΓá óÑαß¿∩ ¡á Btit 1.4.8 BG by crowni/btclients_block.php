<?
require_once ("include/functions.php");
require_once ("include/config.php");

global $BASEURL;

dbconn();

if (!$CURUSER || $CURUSER["view_torrents"]=="no")
{

}
else
{
block_begin("������ ������ �� ���������� :");



$bt_clients = mysql_query("SELECT * FROM bt_clients ORDER BY sort ASC")or sqlerr(__FILE__, __LINE__);
print("<table width=\"100%\">");
while($bt_clients_res = mysql_fetch_assoc($bt_clients))
{
$bt_name = $bt_clients_res["name"];
$bt_link = $bt_clients_res["link"];
$bt_image = $bt_clients_res["image"];
print("<tr><td align=\"center\"><a href=$bt_link target=\"_blank\"title=\"$bt_name\" border='0'><img border=\"0\" src=\"$bt_image\"></a><hr></td><td align=\"left\"></td></tr>");
}
print("</table>");
block_end();
}
?>