<?php
$msg = array (
  0 => 
  array (
    'pseudo' => 'lanselot',
    'texte' => 'hi all',
    'date' => 1266657609,
  ),
  1 => 
  array (
    'pseudo' => 'lanselot',
    'texte' => ':)',
    'date' => 1266657619,
  ),
  2 => 
  array (
    'pseudo' => 'lanselot',
    'texte' => ':D',
    'date' => 1266657636,
  ),
)
?>