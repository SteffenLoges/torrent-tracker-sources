<? 
require ("include/functions.php");;
dbconn();
$id2 = $_GET['delete'];

    $result  = mysql_query("DELETE FROM sponsor  
                WHERE ID2='$id2'");
?> 
<meta http-equiv="refresh" content="0 URL=addpartner.php">
<meta name="robots" content="noindex">