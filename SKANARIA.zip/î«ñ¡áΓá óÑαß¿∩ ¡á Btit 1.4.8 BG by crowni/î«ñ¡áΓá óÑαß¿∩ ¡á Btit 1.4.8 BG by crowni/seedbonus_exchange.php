<?php
// SeedBonus Mod by CobraCRK   -   original ideea by TvRecall...
//cobracrk[at]yahoo.com
//www.extremeshare.org
require_once ("include/functions.php");
require_once ("include/config.php");
dbconn();

$id=$_GET['id'];
if(is_null($id)||!is_numeric($id)||$CURUSER["view_torrents"]=="no"){
standardheader('Not allowed');
  err_msg(ERROR,"What tha hell do you want?");
       stdfoot();
       exit;
}

$r=mysql_query("SELECT * FROM bonus WHERE id=$id");
$p=mysql_result($r,0,"points");
$t=mysql_result($r,0,"traffic");
$uid=$CURUSER["uid"];
$r=mysql_query("SELECT seedbonus FROM users WHERE id=$uid");
$u=mysql_result($r,0,"seedbonus");
if($u<$p) {
standardheader('ERROR');
  err_msg(ERROR,"You don't have enough points");
       stdfoot();
       exit;
}else {
@mysql_query("UPDATE users SET uploaded=uploaded+$t,seedbonus=seedbonus-$p WHERE id=$uid");
header("Location: seedbonus.php");

}

?>


Read more: http://www.btiteam.org/smf/index.php?topic=5209.0#ixzz0YN0AFj7h


