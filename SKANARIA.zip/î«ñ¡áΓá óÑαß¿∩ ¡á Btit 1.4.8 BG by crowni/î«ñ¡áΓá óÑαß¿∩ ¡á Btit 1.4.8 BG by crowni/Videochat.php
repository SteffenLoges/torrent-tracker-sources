<?
require_once ("include/functions.php");
require_once ("include/config.php");

dbconn();

standardheader('Videochat');
block_begin("Videochat @ $SITENAME");

global $CURUSER, $STYLEPATH;

?>
<object width="776" height="511"><param name="movie" value="http://www.customvideochat.com/main.swf?chatID=Ug3JWm2StNLbUmFKQQBpVQ&styleCSS=http://www.customvideochat.com/skins/grey/grey.swf#1244217502&privateChat=1&1244217498"></param><param name="wmode" value="transparent"></param><param name="AllowScriptAccess" value="always"></param><embed src="http://www.customvideochat.com/main.swf?chatID=Ug3JWm2StNLbUmFKQQBpVQ&styleCSS=http://www.customvideochat.com/skins/grey/grey.swf#1244217502&privateChat=1&1244217498" type="application/x-shockwave-flash" wmode="transparent" AllowScriptAccess="always" width="776" height="511"></embed></object>



block_end();
stdfoot();

?>