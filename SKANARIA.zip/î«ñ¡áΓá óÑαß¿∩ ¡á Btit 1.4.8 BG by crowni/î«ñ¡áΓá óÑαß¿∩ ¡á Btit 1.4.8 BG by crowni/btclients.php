<?php
require_once ("include/functions.php");
require_once ("include/config.php");

dbconn();

global $BASEURL, $CURUSER;

standardheader("BTCLIENTS");

if (!$CURUSER || $CURUSER["admin_access"]!="yes")
   {
       err_msg(ERROR,NOT_ADMIN_CP_ACCESS);
       stdfoot();
       exit;
   }

if (isset($_GET["action"]))
$action = $_GET["action"];
else
$action = "";

if ($action == "new_btclient")
{
$client_name = sqlesc($_POST["client_name"]);
$client_link = sqlesc($_POST["client_link"]);
$client_image = $_FILES["client_image"]["name"];

$client_image_url = "images/btclients/$client_image";
$client_sort_res = mysql_query("SELECT sort FROM bt_clients ORDER BY sort DESC LIMIT 1");
$client_sort_arr = mysql_fetch_row($client_sort_res);
$client_sort = $client_sort_arr[0]+1;

if (($_FILES["client_image"]["type"] == "image/gif") || ($_FILES["client_image"]["type"] == "image/jpeg") || ($_FILES["client_image"]["type"] == "image/png" ) && ($_FILES["client_image"]["size"] < 1000))
{
if(move_uploaded_file($_FILES["client_image"]["tmp_name"],"$client_image_url"))
{
$insert_btclient = mysql_query("INSERT INTO bt_clients (name, link, image, sort) VALUES ($client_name,$client_link,\"$client_image\",\"$client_sort\")") or sqlerr(__FILE__, __LINE__);
redirect("btclients.php");
}
}
else
{
err_msg(ERROR,  FILE_UPLOAD_ERROR_2." $client_image_url ");
stdfoot();
exit;
}
}

if ($action == "delete_client")
{
$btclient_id = $_GET["btclient_id"];
mysql_query("DELETE FROM bt_clients WHERE id=$btclient_id") or sqlerr(__FILE__, __LINE__);
redirect("btclients.php");
}

if ($action == "confirm_delete")
{
$btclient_id = $_GET["btclient_id"];
print("<table class=\"lista\" width=\"100%\"><form action=?action=delete_client&btclient_id=$btclient_id method=post><tr><td class=\"header\" align=\"center\">".DELETE_CLIENT."</td></tr>");
print("<tr><td class=\"lista\" align=\"center\">".SURE_DELETE."</td><tr>");
print("<tr><td class=\"lista\" align=\"center\"><input type=submit name=confirm value=".FRM_CONFIRM."></tr></table");
exit;
}

block_begin(BTCLIENTS_INSERT);
print("<table class=\"lista\" width=\"100%\"><tr><form action=?action=new_btclient method=post enctype=multipart/form-data>");
print("<tr><td class=\"header\">Име</td><td class=\"lista\"><input type=\"text\" name=\"client_name\" size=\"40\"></td></tr>");
print("<tr><td class=\"header\">Сайт</td><td class=\"lista\"><input type=\"text\" name=\"client_link\" size=\"40\"></td></tr>");
print("<tr><td class=\"header\">Снимка</td><td class=\"lista\"><input type=\"file\" name=\"client_image\" size=\"40\"></td></tr>");
print("<tr><td class=\"lista\" align=\"center\" colspan=\"3\"><input type=submit name=confirm value=".FRM_CONFIRM."></td></tr></table>");
block_end();

block_begin(BTCLIENTS_LIST);
print("<table class=\"lista\" width=\"100%\"><tr><td class=\"header\">Снимка</td><td class=\"header\">Име</td><td class=\"header\">Сайт</td><td class=header>Позиция</td><td class=\"header\">Изтрий</td></tr>");
$bt_clients_res = mysql_query("SELECT * FROM bt_clients ORDER BY sort ASC");
if (!$bt_clients_res)
print("<tr><td class=\"lista\" align=\"center\" colspan=\"5\">Списъкът с торент клиенти е празен!</td><tr>");
else
{
while ($bt_clients_arr = mysql_fetch_assoc($bt_clients_res))
  {
  $btclient_id = $bt_clients_arr["id"];
  $btclient_name = $bt_clients_arr["name"];
  $btclient_link = $bt_clients_arr["link"];
  $btclient_sort = $bt_clients_arr["sort"];
  $btclient_image = $bt_clients_arr["image"];
  print("<tr><td class=\"lista\" align=\"center\"><img src='images/btclients/$btclient_image'></td><td class=\"lista\">$btclient_name</td><td class=\"lista\">$btclient_link</td><td class=\"lista\" align=\"center\">$btclient_sort</td><td class=\"lista\" align=\"center\"><a href=?action=confirm_delete&btclient_id=$btclient_id><img src=$STYLEPATH/delete.png border=0></a></td></tr>");
  }
}
print("</table>");
block_end();

stdfoot();
?>