<iframe src="http://arenabg.com/iframe_easy.php" width="700" style="margin:auto auto; display:block; width:900px;" frameborder="0" height="600" scrolling="No" background-color="black"></iframe>
