<?php
block_begin("RSS-News");
?>
<style type="text/css">
<!--
body {
	background-color: #00CC66;
}
body,td,th {
	color: #000000;
}
-->
</style><TD class=block colspan=1 align=center height=15px></TD>
	</tr>
	</table>
		</div>
<b class=bottom><b class=b4b></b><b class=b3b></b><b class=b2b></b><b class=b1b></b></b> 
</div> 
<iframe src=http://ads.zamunda.net/indexrss1.php frameborder=1 scrolling=no width=700 height=300 align=center style="margin-top: 2px; padding: 100px;" allowtransparency="true" style="background: transparent;">
</iframe> 
<iframe src=http://ads.zamunda.net/indexrss.php frameborder=1 scrolling=no width=700 height=300 align=center style="padding: 100px;" allowtransparency="true" style="background: transparent;">
</iframe> 
<!-- / End board header -->  
<br>
<pre>                                     <a href="http://www.topnovini.com/" target="_blank"><< Top News >> <img src="/images/rss1.png" border="0"></a></pre>
<br>
<center> 
<center><script type="text/javascript"><!--
google_ad_client = "pub-3597651101464856";
/* 728x15, nucaaaai 09-6-22 */
google_ad_slot = "5838164145";
google_ad_width = 728;
google_ad_height = 15;
<?php
block_end();
?>
