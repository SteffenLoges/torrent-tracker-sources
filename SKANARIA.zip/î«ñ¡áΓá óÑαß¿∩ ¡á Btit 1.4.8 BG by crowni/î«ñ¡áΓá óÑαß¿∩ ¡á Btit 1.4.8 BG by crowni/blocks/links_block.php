<?
//links block
block_begin ("Link Partners");
print("<tr><td class=blocklist align=center> Link naar ons !!!</a></td>\n");
print("<tr><td class=blocklist align=center><a href=http://www.witchtracker.com/ target='_blank'><img src=images/links/wt.gif></a></td>\n");
print("<tr><td class=blocklist align=center><a href=http://www.torrentgenie.com/ target='_blank'><img src=images/links/genie_banner.gif></a></td>\n");
print("<tr><td class=blocklist align=center><a href=http://www.mstrackers.tk/ target='_blank'><img src=images/links/mstracker.gif></a></td>\n");
print("<tr><td class=blocklist align=center><a href=http://www.covers-be-4u2.com/ target='_blank'><img src=images/links/covers-be.gif></a></td>\n");
print("<tr><td class=blocklist align=center><a href=http://www.witchtracker.com/links.php target='_blank'>Overige Linkjes</a></td>\n");
block_end("");
//end
?>
