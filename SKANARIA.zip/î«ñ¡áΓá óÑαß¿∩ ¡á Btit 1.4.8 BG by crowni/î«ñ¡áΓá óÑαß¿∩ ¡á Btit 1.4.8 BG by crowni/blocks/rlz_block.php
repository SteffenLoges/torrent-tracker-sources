<?
require_once ("include/functions.php");
require_once ("include/config.php");

dbconn();

$res = mysql_query("SELECT count(realises.id) FROM realises") or die(mysql_error());
$arr = mysql_fetch_array($res);
$count = $arr[0];
$perpage = 3;	
list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" . "&" );
$res = mysql_query("SELECT id,cat,poster,name,genre,director,staring,description,quality,
video,audio,time,url,imd,lang from realises ORDER BY id DESC $limit") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0) {
block_begin("������������");
echo $pagertop;
while ($arr = mysql_fetch_assoc($res)) {
print("<table width=100% ><tr>
<td align=center>
<table width=100% border=0 cellspacing=4 cellpadding=1 style=margin-bottom:10px; >
<tr bgcolor=#FFFFFF class=bottom>
<th><div align=left><font color=000000 size=1> " . ( $arr[name] )."</i></font> </div></th>
</tr><td><ul>
<TABLE cellSpacing=0 cellPadding=3 border=0 ><TBODY><TR vAlign=top><TD width=160>
<IMG src=$arr[poster] width=170 border=2></TD><TD><DIV align=left><IMG src=$arr[cat] align=right 
border=0><font size=1><B>".RLZ_GENRE.": </B>" . ( $arr[genre] )."<BR><B>".RLZ_DIRECTOR.":</B> " . ( $arr[director] )." </DIV>
<B>".RLZ_STARING.":</B> " . ( $arr[staring] )." </DIV>
<DIV align=left><HR align=left width=\85%\ color=#000000 SIZE=1></DIV><DIV align=left>
<B>".RLZ_DESCRIPTION.":</B><BR> " . ( $arr[description] )." </DIV><DIV align=left><HR align=left width=\85%\
color=#000000 SIZE=1></DIV><DIV align=left><B>".RLZ_QUALITY.":</B> " . ( $arr[quality] ) ." <BR>
<B>".RLZ_VIDEO.":</B> " . ( $arr[video] ) ."<BR><B>".RLZ_AUDIO.":</B> " . ( $arr[audio] ) ."<BR>
<B>".RLZ_DURATION.":</B> " . ( $arr[time] ) ." <BR><B>".RLZ_TRANSLATION.":</B> " . ( $arr[lang] ) ." </DIV>\n");
if ($arr["imd"])
print("<DIV align=right> [<A href=$arr[imd]>IMDB</A>] [<A href=$arr[url] target=_blank>".RLZ_DETAILS."</A>]
</TD></TR></TBODY></TABLE></td></tr></table></td></table>\n");
else
print("<DIV align=right> [<A href=$arr[url] target=_blank>Details</A>]
</TD></TR></TBODY></TABLE></td></tr></table></td></table>\n");
}
print("</table>\n");
} else
print("-- Nothing found! --\n");
?> 