<?
block_begin("������ ����");
require_once("include/functions.php");
dbconn();
$sql = "SELECT users_level.prefixcolor AS prefixcolor, users_level.suffixcolor AS suffixcolor, users.id AS id, users.username AS username FROM users INNER JOIN users_level ON users.id_level=users_level.id WHERE users.id>1 AND lastconnect BETWEEN (NOW() - INTERVAL 1 DAY )AND (NOW()) ORDER BY username";
$qry=mysql_query($sql);
print("<tr><td align=center class=lista><br>");
$counter = 0;
while ($res=mysql_fetch_array($qry))
{
    print("<a href=userdetails.php?id=$res[id]>".unesc($res["prefixcolor"]).unesc($res["username"]).unesc($res["suffixcolor"])."</a> ");
    $counter++;
}
print("<br> ����  ����������� :".$counter);

print("</td></tr>");
block_end();
?>
