<?

require_once ("include/functions.php");
require_once ("include/config.php");

global $CURUSER, $BASEURL;

if (!$CURUSER || $CURUSER["view_torrents"]=="no")
{
// do nothing
}
else
{
dbconn();

block_begin("������� ������");

$randtor_res = mysql_query("SELECT info_hash, filename, image, category, size, UNIX_TIMESTAMP(data) as data, uploader FROM namemap WHERE image!='' ORDER BY RAND() LIMIT 1") or sqlerr(__FILE__, __LINE__);
@$randtor_arr = mysql_fetch_assoc($randtor_res);
$randtor_image1 = $randtor_arr["image"]; 
$randtor_hash = $randtor_arr["info_hash"];
$randtor_filename = $randtor_arr["filename"];
$randtor_category = $randtor_arr["category"];
$catname_res = mysql_query("SELECT name FROM categories WHERE id=$randtor_category");
$catname_arr = mysql_fetch_row($catname_res);
$catname = $catname_arr[0];
$randtor_size = makesize($randtor_arr["size"], 2);
$randtor_date = $randtor_arr["data"];
$randtor_flink = $randtor_arr["forum_link"];
$randtor_uploader = $randtor_arr["uploader"];
$uploader_name_res = mysql_query("SELECT username FROM users WHERE id=$randtor_uploader");
$uploader_name_arr = mysql_fetch_row($uploader_name_res);
$uploader_name = $uploader_name_arr[0];
print("<table class=\"lista\" align=\"center\">");
print("<tr><td colspan=\"2\" class=\"lista\" align=\"center\"><a href=\"$BASEURL/details.php?id=$randtor_hash\"><img src=\"$randtor_image1\" border='0' width=130></a><hr></td></tr>");
print("<tr><td class=\"lista\"><b>- Uploader</b>:</td><td><a href=\"$BASEURL/userdetails.php?id=$randtor_uploader\">$uploader_name</td></tr>");
print("<tr><td class=\"lista\"><b>- ���������</b>:</td><td><a href=\"$BASEURL/torrents.php?category=$randtor_category\">$catname</a></td></tr>");
print("<tr><td class=\"lista\"><b>- �������</b>:</td><td>".date("d/m/Y H:i:s", $randtor_date)."</td></tr>");
print("<tr><td class=\"lista\"><b>- ��������</b>:</td><td>$randtor_size</td></tr>");
print("</table>");

block_end();
}
?>