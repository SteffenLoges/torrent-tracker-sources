<a href=torrents.php><font face=arial size=1><b>[ ������� ]</b></font></a>&nbsp;<a href=games.php><font face=arial size=1><b>[ ����]</b></font></a>&nbsp;<a href=seedbonus.php><font face=arial size=1><b>[ ���� ����� ]</b></font></a>&nbsp;<a href=Videochat.php target=_blank><font face=arial size=1><b>[ ����� ��� ]</b></font></a>&nbsp;<a href=colors.php target=_blank><font face=arial size=1><b>[ ������� ]</b></font></a>&nbsp; 
<a href="http://realtop.net/in.php?id=5757" target="_blank" title="���������� �� ���� ���� � RealTop"><img src="http://realtop.net/banners/realtop003.gif" border="0" alt="RealTop.net"></a>
    <table class=lista width=100%>
    <tr>
<?php

   global $CURUSER;

if (!$CURUSER)
   {
       // anonymous=guest
   print("<td class=header align=center>".WELCOME." ".GUEST."\n");
   print("<a href=login.php>(".LOGIN.")</a></td>");
   }
elseif ($CURUSER["uid"]==1)
       // anonymous=guest
    {
   print("<td class=header align=center>".WELCOME." " . $CURUSER["username"] ." \n");
   print("<a href=login.php>(".LOGIN.")</a></td>\n");
    }
else
    {
    print("<td class=header align=center>".WELCOME_BACK." " . $CURUSER["username"] ." \n");
    print("<td class=header align=center><img src='http://localhost//images/logout.png'><br><a href=logout.php>".LOGOUT."</a></td>\n");
    }

print("<td class=header align=center><img src='http://localhost//images/homepaged.gif'><br><a href=./>".MNU_INDEX."</a></td>\n");

if ($CURUSER["view_torrents"]=="yes")
    {
    print("<td class=header align=center><img src='http://localhost//images/torrents.png'><br><a href=torrents.php>".MNU_TORRENT."</a></td>\n");
	print("<td class=header align=center><img src='http://localhost//images/camera.png'><br><a href=Videochat.php>".��������."</a></td>\n");
	print("<td class=header align=center><img src='http://localhost//images/catalog.png'><br><a href=catalog.php>".CATALOG."</a></td>\n");
    print("<td class=header align=center><img src='http://localhost//images/stats.png'><br><a href=extra-stats.php>".MNU_STATS."</a></td>\n");
    }
if ($CURUSER["can_upload"]=="yes")
   print("<td class=header align=center><img src='http://localhost//images/upload.gif'><br><a href=uploadrules.php>".MNU_UPLOAD."</a></td>\n");
if ($CURUSER["view_users"]=="yes")
   print("<td class=header align=center><img src='http://localhost//images/people1.png'><br><a href=users.php>".MNU_MEMBERS."</a></td>\n");
if ($CURUSER["view_news"]=="yes")
   print("<td class=header align=center><img src='http://localhost//images/news.png'><br><a href=viewnews.php>".MNU_NEWS."</a></td>\n");
   print("<td class=header align=center><img src='http://localhost//images/staff.gif'><br><a href=staff.php>".STAFF."</a></td>\n");
if ($CURUSER["view_forum"]=="yes")
   {
   if ($GLOBALS["FORUMLINK"]=="" || $GLOBALS["FORUMLINK"]=="internal")
      print("<td class=header align=center><img src='http://localhost//images/forum.png'><br><a href=forum.php>".MNU_FORUM."</a></td>\n");
   else
       print("<td class=header align=center><a href=$GLOBALS[FORUMLINK] target=_blank>".MNU_FORUM."</a></td>\n");
    }

?>
</tr>
   
   </table>
   
   <table class=bottom align=center cellspacing="0" cellpadding="5" border="0">
<tr>
<td class=bottom width=1></td>
<td class=upnav><a href=""><font style='background: #F0F8FF; color: #0000FF;'><b>&nbsp;���������� ������� >>&nbsp;</b></font></td>
<td class=bottom width=1></td>
<td class=upnav><a href="http://gettorrent-bg.200u.com"><font style='background: #FFD700; color: #000000;'><b>&nbsp;����� ����&nbsp;</b></font></td>
<td class=bottom width=1></td>
<td class=upnav><a href="http://www.fakira-pro.hostzi.com"><font style='background: #9C0E43; color: #FFFFFF;'><b>&nbsp;��������&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://crowni.jalbum.net/gettattoo"><font style='background: #FF1493; color: #FFFFFF;'><b>&nbsp;����������&nbsp;</b></font></td>
<td class=bottom width=1></td>
<td class=upnav><a href="http://markoni-tube.hawster.com" target="_blank"><font style='background: #588D1D; color: #FFFFFF;'><b>&nbsp;�������&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://btiteam-bg.200u.com/" target="_blank"><font style='background: #00FFFF; color: #000000;'><b>&nbsp;Btiteam-BG&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://djagi.com/" target="_blank"><font style='background: #FF0000; color: #000000;'><b>&nbsp;Djadji-����&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://chechomir.100webspace.net/" target="_blank"><font style='background: #7FFF00; color: #000000;'><b>&nbsp;�������&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://zamunda.pomagalo.com/" target="_blank"><font style='background: #FFEBCD; color: #000000;'><b>&nbsp;��������&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://vbox7.com/" target="_blank"><font style='background: #8A2BE2; color: #000000;'><b>&nbsp;Vbox7&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://www.youtube.com/" target="_blank"><font style='background: #FF4500; color: #000000;'><b>&nbsp;Youtube&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://www.metacafe.com/" target="_blank"><font style='background: #FFD700; color: #000000;'><b>&nbsp;Metacafe&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://www.pornhub.com/" target="_blank"><font style='background: #FF00FF; color: #000000;'><b>&nbsp;XXX&nbsp;</b></font>
<td class=bottom width=1></td>
<td class=upnav><a href="http://blacksdition-tr.100webspace.net/" target="_blank"><font style='background: #D2691E; color: #000000;'><b>&nbsp;GetPhoto&nbsp;</b></font>
</tr>
</table>
<table class=mainouter width=100% border="1" cellspacing="0" cellpadding="5">

