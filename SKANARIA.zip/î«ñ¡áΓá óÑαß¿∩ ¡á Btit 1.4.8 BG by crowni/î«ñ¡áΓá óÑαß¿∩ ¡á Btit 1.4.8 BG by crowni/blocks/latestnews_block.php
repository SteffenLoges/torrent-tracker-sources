<?
global $CURUSER, $BASEURL, $STYLEPATH, $TGLOBALS;

block_begin("Latest News");
echo   "<marquee onmouseover=this.stop() onmouseout=this.start() scrollAmount=1 direction=up width='100%' height='140'>";
echo file_get_contents("news.txt");
echo "</marquee>";
block_end();
?>

