<?php
block_begin('&#1058;&#1098;&#1088;&#1089;&#1080; &#1074; Google');
?>

<FORM method=GET action="http://www.google.com/custom" target="_default">
<center><IMG SRC="http://www.google.com/logos/Logo_25blk.gif" border="0" ALT="Google">
<center><input type="text" name="q" value="" style="width:80%;">
<center><input type="submit" name="sa" value=" �����" style="width:10ex; margin:4px;">
</FORM>


<?php
block_end();
?>