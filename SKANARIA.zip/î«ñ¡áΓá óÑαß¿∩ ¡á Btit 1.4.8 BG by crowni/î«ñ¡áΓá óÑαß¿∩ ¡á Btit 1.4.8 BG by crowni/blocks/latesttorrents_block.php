<?php
require_once ("include/functions.php");
require_once ("include/config.php");
require_once ("include/blocks.php");
if (!$CURUSER || $CURUSER["view_torrents"]=="no")
   {
       // do nothing
   }
else
   {
   ?>
   <style type="text/css">
   img	{
   border:none;
   }
   </style>
   

   <script language=JavaScript>

var resizeDelay = 10;

var resizeIncrement = 5;

var imgCache = new Object();

function getCacheTag (imgElement) {
	return imgElement.src + "~" + imgElement.offsetLeft + "~" + imgElement.offsetTop;
}

function cachedImg (imgElement, increment) {
	this.img = imgElement;
	this.cacheTag = getCacheTag(imgElement);
	this.originalSrc = imgElement.src;
	
	var h = imgElement.height;
	var w = imgElement.width;
	this.originalHeight = h;
	this.originalWidth = w;
	
	increment = (!increment) ? resizeIncrement : increment;
	this.heightIncrement = Math.ceil(Math.min(1, (h / w)) * increment);
	this.widthIncrement = Math.ceil(Math.min(1, (w / h)) * increment);
}

function resizeImg (imgElement, percentChange, newImageURL) {

	var pct = (percentChange) ? percentChange / 100 : 1;

	var cacheTag = imgElement.getAttribute("cacheTag");
	if (!cacheTag) {
		cacheTag = getCacheTag(imgElement);
		imgElement.setAttribute("cacheTag", cacheTag);
	}

	var cacheVal = imgCache[cacheTag];
	if (!cacheVal) {
		imgCache[cacheTag] = new Array(new cachedImg(imgElement), pct);
	} else {
		cacheVal[1] = pct;
	}

	if (newImageURL)
		imgElement.src = newImageURL;

	resizeImgLoop(cacheTag);
	return true;
}

function resizeImgLoop (cacheTag) {
	var cacheVal = imgCache[cacheTag];
	if (!cacheVal)
		return false;
	
	var cachedImageObj = cacheVal[0];
	var imgElement = cachedImageObj.img;
	var pct = cacheVal[1];
	var plusMinus = (pct > 1) ? 1 : -1;
	var hinc = plusMinus * cachedImageObj.heightIncrement;
	var vinc = plusMinus * cachedImageObj.widthIncrement;
	var startHeight = cachedImageObj.originalHeight;
	var startWidth = cachedImageObj.originalWidth;
	
	var currentHeight = imgElement.height;
	var currentWidth = imgElement.width;
	var endHeight = Math.round(startHeight * pct);
	var endWidth = Math.round(startWidth * pct);
	
	if ( (currentHeight == endHeight) || (currentWidth == endWidth) )
		return true;

	var newHeight = currentHeight + hinc;
	var newWidth = currentWidth + vinc;
	if (pct > 1) {
		if ((newHeight >= endHeight) || (newWidth >= endWidth)) {
			newHeight = endHeight;
			newWidth = endWidth;
		}
	} else {
		if ((newHeight <= endHeight) || (newWidth <= endWidth)) {
			newHeight = endHeight;
			newWidth = endWidth;
		}
	}
	
	imgElement.height = newHeight;
	imgElement.width = newWidth;
	
	if ((newHeight == cachedImageObj.originalHeight) || (newWidth == cachedImageObj.originalwidth)) {
		imgElement.src = cachedImageObj.originalSrc;
	}
	setTimeout("resizeImgLoop('" + cacheTag + "')", resizeDelay);
}

</script>


   <?php
   block_begin(LAST_TORRENTS);

   print("<table class=\"lista\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" width=\">");
   print("<tr><td width=\"50px\"><marquee direction=\"left\" onmouseover=\"this.stop()\" onmouseout=\"this.start()\" scrollamount=\"5\" scrolldelay=\"1\">");
   $res = mysql_query("SELECT namemap.info_hash,namemap.filename, namemap.image, namemap.uploader as upname, users.username as uploader FROM namemap LEFT JOIN users ON users.id = namemap.uploader WHERE image !='' ORDER BY data DESC LIMIT 10");
   while($result=mysql_fetch_array($res))
   {
   print("<A HREF=\"details.php?id=".$result["info_hash"]."\" title=\"".VIEW_DETAILS.": ".$result["filename"]."\"><img src=\"".$result["image"]."\" height=\"150px\" onMouseOver='resizeImg(this, 200)'onMouseOut='resizeImg(this)'></A>");
   }
   print("</marquee></td></tr></table>");
block_end();
   }
?>