<?php
/*-------------------------------------------------------+
| Name: User Block Implementation
| Author: Tom�s A. (h2non) th2non@gmail.com
| Version: 1.1 Beta
| Software: BtiTracker by Btiteam (http://www.btiteam.org)
+--------------------------------------------------------+
| This source code is released as free software under the
| Affero GPL license. You can redistribute it and/or
| modify it under the terms of this license which you
| can read by viewing the included agpl.txt or online
| at www.gnu.org/licenses/agpl.html. Removal of this
| copyright header is strictly prohibited without
| written permission from the original author(s).
+--------------------------------------------------------/
| Needs to be done (next version):
| In the following implementation will try to show a default avatar if no avatar. 
| Other implementation posible is the links of the menu could be replaced by some pictures. 
| I hope that the next version of the block able to do so.
+--------------------------------------------------------/
| Version 1.1 Last Fixed Errors
| Fixed an error to link to "Your PM Box" (Thanks to DandyDon)
+--------------------------------------------------------*/

global $CURUSER, $user;



         block_begin("".BLOCK_USER."");



         if (!$CURUSER || $CURUSER["id"]==1)

            {

            // guest-anonymous, login require

            ?>

            <form action="/login.php" name="login" method="post">

            <table class="lista" border="0" align="center">
            <tr><td align="right" class="header"><?php echo USER_NAME?>:</td><td class="lista"><input type="text" size="10" name="uid" value="<?php $user ?>" maxlength="40" /></td></tr>

            <tr><td align="right" class="header"><?php echo USER_PWD?>:</td><td class="lista"><input type="password" size="10" name="pwd" maxlength="40" /></td></tr>
            <tr><td colspan="2"  class="header" align="center"><input type="submit" value="<?php echo FRM_LOGIN?>" /></td></tr>

            <tr><td class="header" align="center"><a href="../../../DOCUME%7E1/usuario/CONFIG%7E1/Temp/7zOA2.tmp/account.php"><?php echo ACCOUNT_CREATE?></a></td><td class="header" align="center"><a href="../../../DOCUME%7E1/usuario/CONFIG%7E1/Temp/7zOA2.tmp/recover.php"><?php echo RECOVER_PWD?></a></td></tr>
            </table>

            </form>

            <?php

            }

         else

             {

        // user information


             $style=style_list();

             $langue=language_list();
	$resuser=mysql_query("SELECT * FROM users WHERE id=".$CURUSER["uid"]);

	$rowuser=mysql_fetch_array($resuser);
	
	
	// If user is validate on the system, the server runs the next code
	

	if ($CURUSER["uid"]>1)	
			 
             print("</td>");
			 
			 //	Avatar show up the block and in the middle

 if ($CURUSER["avatar"] && $CURUSER["avatar"]!="")
             print("<tr><td align=center class=blocklist valign=middle><img border=0 src=".htmlspecialchars($CURUSER["avatar"])." </td>\n");

print("</tr>");

 			// End avatar code

			// Country Code 
			
			 $id = $CURUSER["uid"];
          $res=mysql_query("SELECT users.lip,users.username,users.downloaded,users.uploaded, UNIX_TIMESTAMP(users.joined) as joined, users.flag, countries.name, countries.flagpic FROM users LEFT JOIN countries ON users.flag=countries.id WHERE users.id=$id") or die(mysql_error());
          $row = mysql_fetch_array($res);
			 
			 	 
			 
			 print("<tr><td align=center class=blocklist colspan=2><img src=images/flag/".(!$row["flagpic"] || $row["flagpic"]==""?"unknown.gif":$row["flagpic"])." alt=".($row["flag"]==0 ? "unknow":unesc($row['name']))." /></td></tr>\n");
			 
			 
			 //End Country Code
			 
			 // Show another information with her styles
			 
			 print("<tr><td align=center class=blocklist <font color=\"#FF0000\">" .unesc($CURUSER["username"])."</td></tr>\n");
			 print("<tr><td align=center class=blocklist <font color=\"#006633\">".$CURUSER["level"]."</td></tr>\n");
			 
			 // End of user information
			 
			 // Now show upload/download balance with their custom images
			 				 
             print("<td align=center class=blocklist ><img src='images/upload.png' border='0' width='12' height='12'>".makesize($rowuser['uploaded'])."<img src='images/download.png' border='0' width='12' height='12'>".makesize($rowuser['downloaded']));
			 
			 // End 
			 
			 //  Now show the ratio			 
			 	 		 
			 print("<tr><td class=blocklist align=center><font size=1 color= \"#003366\">Ratio: ".($rowuser['downloaded']>0?number_format($rowuser['uploaded']/$rowuser['downloaded'],2):"---")."");
			 
	         //  End ratio code
			 
			 // Show IP client address
			 
			 if($_SERVER["HTTP_X_FORWARDED_FOR"]){
echo "<br>Proxy:{$_SERVER["REMOTE_ADDR"]}<br>";
echo "<br>IP:{$_SERVER["HTTP_X_FORWARDED_FOR"]}";
}else{
echo "<br>IP:{$_SERVER["REMOTE_ADDR"]}<br>";
} 
			 
            // If not run correctly, change the functions. End of code
			
			// Now show a little menu.

    
             print("</select>");

             print("</td></tr>\n<tr><td class=blocklist align=center>");

             print("</select>");

             print("</td>\n</form></tr>\n");

             print("\n<tr><td align=center class=blocklist>[<a href=usercp.php?uid=".$CURUSER["uid"].">".USER_CP."</a>] [<a href=logout.php>".LOGOUT."</a>]</td></tr>\n");

             print("\n<tr><td align=center class=blocklist>[<a href=usercp.php?uid=".$CURUSER["uid"]."&do=pm&action=list&what=inbox".">".MNU_UCP_PM."</a>]</td></tr>\n");
			 
			 print("<td class=blocklist align=center>[<a href=upload.php>".MNU_UPLOAD."</a>]</td>");
			 
			 if ($CURUSER["admin_access"]=="yes")

                print("\n<tr><td align=center class=blocklist><a href=admincp.php?user=".$CURUSER["uid"]."&code=".$CURUSER["random"].">".MNU_ADMINCP."</a></td></tr>\n");
			 print("<tr><td align=center class=blocklist>");
			 
			 
			 // Show last access
 			 
			 include("include/offset.php");
			 print("<font size=1 color= \"#000000\">".USER_LASTACCESS.":<br />".date("d/m/Y H:i:s",$CURUSER["lastconnect"]-$offset));

             print("</td></tr>\n<tr><form name=jump><td class=blocklist align=center>");
			 
			 // End of code

            }



         block_end();

?>