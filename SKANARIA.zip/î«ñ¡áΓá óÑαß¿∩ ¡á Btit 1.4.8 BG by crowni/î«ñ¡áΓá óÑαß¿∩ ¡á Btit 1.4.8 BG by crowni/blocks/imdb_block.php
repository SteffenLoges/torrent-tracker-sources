<?php
block_begin("Imdb Search",1,"center");
if(isset($_GET["search"]))
{
    $trova = htmlspecialchars(str_replace ("+"," ",$_GET["search"]));
} else {
    $trova = "";
}
?>
<script type="text/javascript">
<!--
var newwindow;
function popdetails(url)
{
  newwindow=window.open(url,'popdetails','height=500,width=500,resizable=yes,scrollbars=yes,status=yes');
  if (window.focus) {newwindow.focus()}
}
function poppeer(url)
{
  newwindow=window.open(url,'poppeers','height=400,width=700,resizable=yes,scrollbars=yes');
  if (window.focus) {newwindow.focus()}
}
// -->
</script>
<p align="center">
<form method='GET' action='http://www.imdb.com/find'>
<table  class="lista" align="center">
  <tr>
<td><?php echo _SEARCH_ ?>:</td>
<td><select name='s'>
<option selected='on' value='all'><?php echo _ALL_ ?></option>
<option value='tt'><?php echo _TITLES_ ?></option>
<option value='ep'>- <?php echo _TVEP_ ?></option>
<option value='nm'><?php echo _NAMES_ ?></option>
<option value='co'><?php echo _COMPANIES_ ?></option>
<option value='kw'><?php echo _KEYWORDS_ ?></option>
</select></td>
<td><input name='q' size='28'></td>
<td><input type='submit' value='<?php echo _SEARCH_ ?>!'></form></td>
 </tr>
  </table>
</form>
<?
block_end();
?>