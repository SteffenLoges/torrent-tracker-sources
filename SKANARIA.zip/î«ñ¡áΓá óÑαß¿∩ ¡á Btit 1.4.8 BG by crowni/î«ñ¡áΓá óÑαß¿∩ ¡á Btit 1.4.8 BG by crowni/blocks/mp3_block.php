<?
block_begin("MP3");
echo "<center>\n";
echo "<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" width=\"150\" height=\"141\" id=\"clock\" align=\"middle\">\n";
echo "<param name=\"movie\" value=\"mp3/player.swf\" />\n";
echo "<param name=\"quality\" value=\"high\" />\n";
echo "<param name=\"scale\" value=\"exactfit\" />\n";
echo "<param name=\"wmode\" value=\"transparent\" />\n";
echo "<param name=\"menu\" value=\"false\">\n";
echo "<embed src=\"mp3/player.swf\" quality=\"high\" scale=\"exactfit\" wmode=\"transparent\" width=\"150\" height=\"141\" name=\"clock\" align=\"middle\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" />\n";
echo "</object>\n";
block_end();
?>