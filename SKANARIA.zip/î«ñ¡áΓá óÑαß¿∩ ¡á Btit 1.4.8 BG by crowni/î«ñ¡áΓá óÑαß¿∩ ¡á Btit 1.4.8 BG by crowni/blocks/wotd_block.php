<?php
block_begin('&#1050;&#1072;&#1088;&#1090;&#1080;&#1085;&#1082;&#1072; &#1085;&#1072; &#1076;&#1077;&#1085;&#1103;');
?>

<table width=100% height=100% border=0 cellpadding=10 cellspacing=0><tr><td class=lista align='center'>
<script>
function gwGetPreview() {url = "http://www.gamewallpapers.com/wallpaperoftheday/getpreview.php"; ipwindow = window.open(url,"_blank","fullscreen=no,resizable=no,scrollbars=no,toolbar=no,height=316,width=400");}
</script>
<div id="gw_wallpaperoftheday"><a href="javascript:gwGetPreview();">
<img src="http://www.gamewallpapers.com/wallpaperoftheday/wallpaperoftheday.jpg" width="120" height="90" border="0" alt="Wallpaper of the day - click image for full download options" title="Wallpaper of the day - click image for full download options" onError="document.all.gw_wallpaperoftheday.style.visibility='hidden';">
</a></div>
</td></tr></table>

<?php
block_end();
?>
