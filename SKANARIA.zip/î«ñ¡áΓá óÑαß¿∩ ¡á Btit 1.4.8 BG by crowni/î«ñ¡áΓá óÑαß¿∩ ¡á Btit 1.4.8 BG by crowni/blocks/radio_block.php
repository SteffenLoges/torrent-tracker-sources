<?
//radio hack created by eipmoc'
block_begin(�����);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript"><!--
function song(){
document.getElementById('music1').innerHTML="<embed type='application/x-mplayer2' id='music2' pluginspage='http://www.microsoft.com/Windows/MediaPlayer/' src='"+document.getElementById('cancion').value+"' name='MediaPlayer1' width='150' height='75' controltype='2' showcontrols='1' showstatusbar='1' AutoStart='true'></embed>";
}
//-->
</script>
</head>
<div id="jukebox">JUKEBOX<br><br>
<select  id="cancion" onchange="song()" size="1"> 
   <option value="http://online.radioexpress.bg:8000/listen.pls">expres</option>
   <option value="http://whitesnake.com/media/100/northc.asx">Radio Wihtesnake</option>   
   <option value="http://dir.slusham.com/link.php?id=1128">alfa</option> 
   <option value="http://dir.slusham.com/link.php?id=399">atlantik</option> 
   <option value="http://dir.slusham.com/link.php?id=1303">bgradio</option>  
   <option value="http://dir.slusham.com/link.php?id=171">bravo</option>
   <option value="http://dir.slusham.com/link.php?id=4264">veronika</option>
   <option value="http://www.radioveselina.bg/iptvasx.php/veselina.asx?UX=7eefc9450a8745186f87dffcb544dda7HfwLq8QggkoayQjV">veselina</option>  
   <option value="http://dir.slusham.com/link.php?id=42">vitosha</option> value="http://dir.slusham.com/link.php?id=90">darik</option> value="http://dir.slusham.com/link.php?id=361">joy</option>
   <option value="http://dir.slusham.com/link.php?id=4467">the voice</option> value="http://dir.slusham.com/link.php?id=365">HMSU</option>
   <option value="http://dir.slusham.com/link.php?id=1817">radio 1</option> value="http://dir.slusham.com/link.php?id=2093">njoy</option>
   <option value="http://dir.slusham.com/link.php?id=1268">NRJ</option>
   <option value="http://dir.slusham.com/link.php?id=682">FM++</option> value="http://dir.slusham.com/link.php?id=972">ZROCK</option>
   <option value="http://dir.slusham.com/link.php?id=1568">kuku</option>
   <option value="http://dir.slusham.com/link.php?id=4809">melody</option>
   <option value="http://dir.slusham.com/link.php?id=688">mila gold</option>
   <option value="http://dir.slusham.com/link.php?id=1554">nazdrave</option>
   <option value="http://dir.slusham.com/link.php?id=1287">nova</option>
   <option value="http://dir.slusham.com/link.php?id=41">retro</option>
   <option value="http://dir.slusham.com/link.php?id=1913">plovdiv</option>
   <option value="http://dir.slusham.com/link.php?id=151">powernet</option>
   <option value="http://dir.slusham.com/link.php?id=243">city</option>
   <option value="http://dir.slusham.com/link.php?id=1616">tangra</option>
   <option value="http://dir.slusham.com/link.php?id=660">fresh</option>
   <option value="http://dir.slusham.com/link.php?id=719">hit</option>
   <option value="http://dir.slusham.com/link.php?id=1028">signal</option>
   <option value="http://dir.slusham.com/link.php?id=2427">party radio</option> 
   <option value="none">::Kies uw DJ ::</option>
   <option value="http://87.210.84.234:8000">TUFS</option>
   <option value="http://switch.streamgate.nl/cgi-bin/streamswitch?streamid=46&a=.asx">Radio3</option>
   <option value="http://217.196.35.12/asx/skyradio.asx">Skyradio</option>
   <option value="http://urltosong4playlist.m3u">Playlist 4</option>
   <option value="http://urltosong5playlist.m3u">Playlist 5</option>	
</select><br> 
<span id="music1"><embed type="application/x-mplayer2" id="music1"
pluginspage="http://www.microsoft.com/Windows/MediaPlayer/" 
src="" 
name="MediaPlayer1" 
width="200"
height="75"
controltype="2" 
showcontrols="1"
showstatusbar="1"
AutoStart="1">
</embed></span>
</div>
</body>
</html>
<?

block_end();

?> 