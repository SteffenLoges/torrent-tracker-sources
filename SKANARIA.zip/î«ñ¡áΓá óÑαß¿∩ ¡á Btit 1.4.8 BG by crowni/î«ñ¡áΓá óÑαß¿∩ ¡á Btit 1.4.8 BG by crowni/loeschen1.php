<? 
require ("include/functions.php");;
dbconn();
$id1 = $_GET['delete'];

    $result  = mysql_query("DELETE FROM toppartner  
                WHERE ID1='$id1'");
?> 
<meta http-equiv="refresh" content="0 URL=addpartner.php">
<meta name="robots" content="noindex">