<?
require_once ("include/functions.php");
require_once ("include/config.php");

dbconn();

standardheader('�������');
block_begin("�������");

global $CURUSER, $STYLEPATH;

?>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<style TYPE='text/css'>
body {
        font-family: "tahoma", "arial", "helvetica", "sans-serif";
        font-size: 10pt;
    }
    </style>
<table ALIGN="Center" BORDER="1">
<thead>
  <tr>
    <td WIDTH="35%" align="center"><p align="center"><strong>����</strong></td>
    <td align="center"><p align="center"><strong>���</strong></td>
    <td align="right"><strong>&nbsp;���&nbsp;</strong></td>

    <td align="right"><strong>&nbsp;�����&nbsp;</strong></td>
  </tr>
</thead>
<tbody>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F0F8FF">&nbsp;</td>
    <td>Aliceblue</td>
    <td align="right">#F0F8FF</td>

    <td align="right">15792383</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FAEBD7">&nbsp;</td>
    <td>Antiquewhite</td>
    <td align="right">#FAEBD7</td>
    <td align="right">16444375</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#00FFFF">&nbsp;</td>
    <td>Aqua</td>
    <td align="right">#00FFFF</td>
    <td align="right">65535</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#7FFFD4">&nbsp;</td>
    <td>Aquamarine</td>
    <td align="right">#7FFFD4</td>
    <td align="right">8388564</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#F0FFFF">&nbsp;</td>
    <td>Azure</td>
    <td align="right">#F0FFFF</td>
    <td align="right">15794175</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F5F5DC">&nbsp;</td>

    <td>Beige</td>
    <td align="right">#F5F5DC</td>
    <td align="right">16119260</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFE4C4">&nbsp;</td>
    <td>Bisque</td>

    <td align="right">#FFE4C4</td>
    <td align="right">16770244</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#000000">&nbsp;</td>
    <td>Black</td>
    <td align="right">#000000</td>

    <td align="right">0</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFEBCD">&nbsp;</td>
    <td>Blanchedalmond</td>
    <td align="right">#FFEBCD</td>
    <td align="right">16772045</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#0000FF">&nbsp;</td>
    <td>Blue</td>
    <td align="right">#0000FF</td>
    <td align="right">255</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#8A2BE2">&nbsp;</td>
    <td>Blueviolet</td>
    <td align="right">#8A2BE2</td>
    <td align="right">9055202</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#A52A2A">&nbsp;</td>
    <td>Brown</td>
    <td align="right">#A52A2A</td>
    <td align="right">10824234</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#DEB887">&nbsp;</td>

    <td>Burlywood</td>
    <td align="right">#DEB887</td>
    <td align="right">14596231</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#5F9EA0">&nbsp;</td>
    <td>Cadetblue</td>

    <td align="right">#5F9EA0</td>
    <td align="right">6266528</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#7FFF00">&nbsp;</td>
    <td>Chartreuse</td>
    <td align="right">#7FFF00</td>

    <td align="right">8388352</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#D2691E">&nbsp;</td>
    <td>Chocolate</td>
    <td align="right">#D2691E</td>
    <td align="right">13789470</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF7F50">&nbsp;</td>
    <td>Coral</td>
    <td align="right">#FF7F50</td>
    <td align="right">16744272</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#6495ED">&nbsp;</td>
    <td>Cornflower</td>
    <td align="right">#6495ED</td>
    <td align="right">6591981</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#FFF8DC">&nbsp;</td>
    <td>Cornsilk</td>
    <td align="right">#FFF8DC</td>
    <td align="right">16775388</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#DC143C">&nbsp;</td>

    <td>Crimson</td>
    <td align="right">#DC143C</td>
    <td align="right">14423100</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#00FFFF">&nbsp;</td>
    <td>Cyan</td>

    <td align="right">#00FFFF</td>
    <td align="right">65535</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#00008B">&nbsp;</td>
    <td>Darkblue</td>
    <td align="right">#00008B</td>

    <td align="right">139</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#008B8B">&nbsp;</td>
    <td>Darkcyan</td>
    <td align="right">#008B8B</td>
    <td align="right">35723</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#B8860B">&nbsp;</td>
    <td>Darkgoldenrod</td>
    <td align="right">#B8860B</td>
    <td align="right">12092939</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#A9A9A9">&nbsp;</td>
    <td>Darkgray</td>
    <td align="right">#A9A9A9</td>
    <td align="right">11119017</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#006400">&nbsp;</td>
    <td>Darkgreen</td>
    <td align="right">#006400</td>
    <td align="right">25600</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#BDB76B">&nbsp;</td>

    <td>Darkkhaki</td>
    <td align="right">#BDB76B</td>
    <td align="right">12433259</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#8B008B">&nbsp;</td>
    <td>Darkmagenta</td>

    <td align="right">#8B008B</td>
    <td align="right">9109643</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#556B2F">&nbsp;</td>
    <td>Darkolivegreen</td>
    <td align="right">#556B2F</td>

    <td align="right">5597999</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF8C00">&nbsp;</td>
    <td>Darkorange</td>
    <td align="right">#FF8C00</td>
    <td align="right">16747520</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#9932CC">&nbsp;</td>
    <td>Darkorchid</td>
    <td align="right">#9932CC</td>
    <td align="right">10040012</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#8B0000">&nbsp;</td>
    <td>Darkred</td>
    <td align="right">#8B0000</td>
    <td align="right">9109504</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#E9967A">&nbsp;</td>
    <td>Darksalmon</td>
    <td align="right">#E9967A</td>
    <td align="right">15308410</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#8FBC8B">&nbsp;</td>

    <td>Darkseagreen</td>
    <td align="right">#8FBC8B</td>
    <td align="right">9419915</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#483D8B">&nbsp;</td>
    <td>Darkslateblue</td>

    <td align="right">#483D8B</td>
    <td align="right">4734347</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#2F4F4F">&nbsp;</td>
    <td>Darkslategray</td>
    <td align="right">#2F4F4F</td>

    <td align="right">3100495</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#00CED1">&nbsp;</td>
    <td>Darkturquoise</td>
    <td align="right">#00CED1</td>
    <td align="right">52945</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#9400D3">&nbsp;</td>
    <td>Darkviolet</td>
    <td align="right">#9400D3</td>
    <td align="right">9699539</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#FF1493">&nbsp;</td>
    <td>Deeppink</td>
    <td align="right">#FF1493</td>
    <td align="right">16716947</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#00BFFF">&nbsp;</td>
    <td>Deepskyblue</td>
    <td align="right">#00BFFF</td>
    <td align="right">49151</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#696969">&nbsp;</td>

    <td>Dimgray</td>
    <td align="right">#696969</td>
    <td align="right">6908265</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#1E90FF">&nbsp;</td>
    <td>Dodgerblue</td>

    <td align="right">#1E90FF</td>
    <td align="right">2003199</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#B22222">&nbsp;</td>
    <td>Firebrick</td>
    <td align="right">#B22222</td>

    <td align="right">11674146</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFAF0">&nbsp;</td>
    <td>Floralwhite</td>
    <td align="right">#FFFAF0</td>
    <td align="right">16775920</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#228B22">&nbsp;</td>
    <td>Forestgreen</td>
    <td align="right">#228B22</td>
    <td align="right">2263842</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#FF00FF">&nbsp;</td>
    <td>Fuchia</td>
    <td align="right">#FF00FF</td>
    <td align="right">16711935</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#DCDCDC">&nbsp;</td>
    <td>Gainsboro</td>
    <td align="right">#DCDCDC</td>
    <td align="right">14474460</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F8F8FF">&nbsp;</td>

    <td>Ghostwhite</td>
    <td align="right">#F8F8FF</td>
    <td align="right">16316671</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFD700">&nbsp;</td>
    <td>Gold</td>

    <td align="right">#FFD700</td>
    <td align="right">16766720</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#DAA520">&nbsp;</td>
    <td>Goldenrod</td>
    <td align="right">#DAA520</td>

    <td align="right">14329120</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#808080">&nbsp;</td>
    <td>Gray</td>
    <td align="right">#808080</td>
    <td align="right">8421504</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#008000">&nbsp;</td>
    <td>Green</td>
    <td align="right">#008000</td>
    <td align="right">32768</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#ADFF2F">&nbsp;</td>
    <td>Greenyellow</td>
    <td align="right">#ADFF2F</td>
    <td align="right">11403055</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#F0FFF0">&nbsp;</td>
    <td>Honeydew</td>
    <td align="right">#F0FFF0</td>
    <td align="right">15794160</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF69B4">&nbsp;</td>

    <td>Hotpink</td>
    <td align="right">#FF69B4</td>
    <td align="right">16738740</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#CD5C5C">&nbsp;</td>
    <td>Indianred</td>

    <td align="right">#CD5C5C</td>
    <td align="right">13458524</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#4B0082">&nbsp;</td>
    <td>Indigo</td>
    <td align="right">#4B0082</td>

    <td align="right">4915330</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFFF0">&nbsp;</td>
    <td>Ivory</td>
    <td align="right">#FFFFF0</td>
    <td align="right">16777200</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F0E68C">&nbsp;</td>
    <td>Khaki</td>
    <td align="right">#F0E68C</td>
    <td align="right">15787660</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#E6E6FA">&nbsp;</td>
    <td>Lavender</td>
    <td align="right">#E6E6FA</td>
    <td align="right">15132410</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#FFF0F5">&nbsp;</td>
    <td>Lavenderblush</td>
    <td align="right">#FFF0F5</td>
    <td align="right">16773365</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#7CFC00">&nbsp;</td>

    <td>Lawngreen</td>
    <td align="right">#7CFC00</td>
    <td align="right">8190976</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFACD">&nbsp;</td>
    <td>Lemonchiffon</td>

    <td align="right">#FFFACD</td>
    <td align="right">16775885</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#ADD8E6">&nbsp;</td>
    <td>Lightblue</td>
    <td align="right">#ADD8E6</td>

    <td align="right">11393254</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F08080">&nbsp;</td>
    <td>Lightcoral</td>
    <td align="right">#F08080</td>
    <td align="right">15761536</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#E0FFFF">&nbsp;</td>
    <td>Lightcyan</td>
    <td align="right">#E0FFFF</td>
    <td align="right">14745599</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#FAFAD2">&nbsp;</td>
    <td>Lightgoldenrodyellow</td>
    <td align="right">#FAFAD2</td>
    <td align="right">16448210</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#90EE90">&nbsp;</td>
    <td>Lightgreen</td>
    <td align="right">#90EE90</td>
    <td align="right">9498256</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#D3D3D3">&nbsp;</td>

    <td>Lightgrey</td>
    <td align="right">#D3D3D3</td>
    <td align="right">13882323</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFB6C1">&nbsp;</td>
    <td>Lightpink</td>

    <td align="right">#FFB6C1</td>
    <td align="right">16758465</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFA07A">&nbsp;</td>
    <td>Lightsalmon</td>
    <td align="right">#FFA07A</td>

    <td align="right">16752762</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#20B2AA">&nbsp;</td>
    <td>Lightseagreen</td>
    <td align="right">#20B2AA</td>
    <td align="right">2142890</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#87CEFA">&nbsp;</td>
    <td>Lightskyblue</td>
    <td align="right">#87CEFA</td>
    <td align="right">8900346</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#778899">&nbsp;</td>
    <td>Lightslategray</td>
    <td align="right">#778899</td>
    <td align="right">7833753</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#B0C4DE">&nbsp;</td>
    <td>Lightsteelblue</td>
    <td align="right">#B0C4DE</td>
    <td align="right">11584734</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFFE0">&nbsp;</td>

    <td>Lightyellow</td>
    <td align="right">#FFFFE0</td>
    <td align="right">16777184</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#00FF00">&nbsp;</td>
    <td>Lime</td>

    <td align="right">#00FF00</td>
    <td align="right">65280</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#32CD32">&nbsp;</td>
    <td>Limegreen</td>
    <td align="right">#32CD32</td>

    <td align="right">3329330</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FAF0E6">&nbsp;</td>
    <td>Linen</td>
    <td align="right">#FAF0E6</td>
    <td align="right">16445670</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF00FF">&nbsp;</td>
    <td>Magenta</td>
    <td align="right">#FF00FF</td>
    <td align="right">16711935</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#800000">&nbsp;</td>
    <td>Maroon</td>
    <td align="right">#800000</td>
    <td align="right">8388608</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#66CDAA">&nbsp;</td>
    <td>Mediumaquamarine</td>
    <td align="right">#66CDAA</td>
    <td align="right">6737322</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#0000CD">&nbsp;</td>

    <td>Mediumblue</td>
    <td align="right">#0000CD</td>
    <td align="right">205</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#BA55D3">&nbsp;</td>
    <td>Mediumorchid</td>

    <td align="right">#BA55D3</td>
    <td align="right">12211667</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#9370DB">&nbsp;</td>
    <td>Mediumpurple</td>
    <td align="right">#9370DB</td>

    <td align="right">9662683</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#3CB371">&nbsp;</td>
    <td>Mediumseagreen</td>
    <td align="right">#3CB371</td>
    <td align="right">3978097</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#7B68EE">&nbsp;</td>
    <td>Mediumslateblue</td>
    <td align="right">#7B68EE</td>
    <td align="right">8087790</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#00FA9A">&nbsp;</td>
    <td>Mediumspringgreen</td>
    <td align="right">#00FA9A</td>
    <td align="right">64154</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#48D1CC">&nbsp;</td>
    <td>Mediumturquoise</td>
    <td align="right">#48D1CC</td>
    <td align="right">4772300</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#C71585">&nbsp;</td>

    <td>Mediumvioletred</td>
    <td align="right">#C71585</td>
    <td align="right">13047173</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#191970">&nbsp;</td>
    <td>Midnightblue</td>

    <td align="right">#191970</td>
    <td align="right">1644912</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F5FFFA">&nbsp;</td>
    <td>Mintcream</td>
    <td align="right">#F5FFFA</td>

    <td align="right">16121850</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFE4E1">&nbsp;</td>
    <td>Mistyrose</td>
    <td align="right">#FFE4E1</td>
    <td align="right">16770273</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFE4B5">&nbsp;</td>
    <td>Moccasin</td>
    <td align="right">#FFE4B5</td>
    <td align="right">16770229</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#FFDEAD">&nbsp;</td>
    <td>Navajowhite</td>
    <td align="right">#FFDEAD</td>
    <td align="right">16768685</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#000080">&nbsp;</td>
    <td>Navy</td>
    <td align="right">#000080</td>
    <td align="right">128</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FDF5E6">&nbsp;</td>

    <td>Oldlace</td>
    <td align="right">#FDF5E6</td>
    <td align="right">16643558</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#808000">&nbsp;</td>
    <td>Olive</td>

    <td align="right">#808000</td>
    <td align="right">8421376</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#6B8E23">&nbsp;</td>
    <td>Olivedrab</td>
    <td align="right">#6B8E23</td>

    <td align="right">7048739</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFA500">&nbsp;</td>
    <td>Orange</td>
    <td align="right">#FFA500</td>
    <td align="right">16753920</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF4500">&nbsp;</td>
    <td>Orangered</td>
    <td align="right">#FF4500</td>
    <td align="right">16729344</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#DA70D6">&nbsp;</td>
    <td>Orchid</td>
    <td align="right">#DA70D6</td>
    <td align="right">14315734</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#EEE8AA">&nbsp;</td>
    <td>Palegoldenrod</td>
    <td align="right">#EEE8AA</td>
    <td align="right">15657130</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#98FB98">&nbsp;</td>

    <td>Palegreen</td>
    <td align="right">#98FB98</td>
    <td align="right">10025880</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#AFEEEE">&nbsp;</td>
    <td>Paleturquoise</td>

    <td align="right">#AFEEEE</td>
    <td align="right">11529966</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#DB7093">&nbsp;</td>
    <td>Palevioletred</td>
    <td align="right">#DB7093</td>

    <td align="right">14381203</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFEFD5">&nbsp;</td>
    <td>Papayawhip</td>
    <td align="right">#FFEFD5</td>
    <td align="right">16773077</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFDAB9">&nbsp;</td>
    <td>Peachpuff</td>
    <td align="right">#FFDAB9</td>
    <td align="right">16767673</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#CD853F">&nbsp;</td>
    <td>Peru</td>
    <td align="right">#CD853F</td>
    <td align="right">13468991</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#FFC0CB">&nbsp;</td>
    <td>Pink</td>
    <td align="right">#FFC0CB</td>
    <td align="right">16761035</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#DDA0DD">&nbsp;</td>

    <td>Plum</td>
    <td align="right">#DDA0DD</td>
    <td align="right">14524637</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#B0E0E6">&nbsp;</td>
    <td>Powderblue</td>

    <td align="right">#B0E0E6</td>
    <td align="right">11591910</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#800080">&nbsp;</td>
    <td>Purple</td>
    <td align="right">#800080</td>

    <td align="right">8388736</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF0000">&nbsp;</td>
    <td>Red</td>
    <td align="right">#FF0000</td>
    <td align="right">16711680</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#BC8F8F">&nbsp;</td>
    <td>Rosybrown</td>
    <td align="right">#BC8F8F</td>
    <td align="right">12357519</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#4169E1">&nbsp;</td>
    <td>Royalblue</td>
    <td align="right">#4169E1</td>
    <td align="right">4286945</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#8B4513">&nbsp;</td>
    <td>Saddlebrown</td>
    <td align="right">#8B4513</td>
    <td align="right">9127187</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FA8072">&nbsp;</td>

    <td>Salmon</td>
    <td align="right">#FA8072</td>
    <td align="right">16416882</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F4A460">&nbsp;</td>
    <td>Sandybrown</td>

    <td align="right">#F4A460</td>
    <td align="right">16032864</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#2E8B57">&nbsp;</td>
    <td>Seagreen</td>
    <td align="right">#2E8B57</td>

    <td align="right">3050327</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFF5EE">&nbsp;</td>
    <td>Seashell</td>
    <td align="right">#FFF5EE</td>
    <td align="right">16774638</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#A0522D">&nbsp;</td>
    <td>Sienna</td>
    <td align="right">#A0522D</td>
    <td align="right">10506797</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#C0C0C0">&nbsp;</td>
    <td>Silver</td>
    <td align="right">#C0C0C0</td>
    <td align="right">12632256</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#87CEEB">&nbsp;</td>
    <td>Skyblue</td>
    <td align="right">#87CEEB</td>
    <td align="right">8900331</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#6A5ACD">&nbsp;</td>

    <td>Slateblue</td>
    <td align="right">#6A5ACD</td>
    <td align="right">6970061</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#708090">&nbsp;</td>
    <td>Slategray</td>

    <td align="right">#708090</td>
    <td align="right">7372944</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFAFA">&nbsp;</td>
    <td>Snow</td>
    <td align="right">#FFFAFA</td>

    <td align="right">16775930</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#00FF7F">&nbsp;</td>
    <td>Springgreen</td>
    <td align="right">#00FF7F</td>
    <td align="right">65407</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#4682B4">&nbsp;</td>
    <td>Steelblue</td>
    <td align="right">#4682B4</td>
    <td align="right">4620980</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#D2B48C">&nbsp;</td>
    <td>Tan</td>
    <td align="right">#D2B48C</td>
    <td align="right">13808780</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#008080">&nbsp;</td>
    <td>Teal</td>
    <td align="right">#008080</td>
    <td align="right">32896</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#D8BFD8">&nbsp;</td>

    <td>Thistle</td>
    <td align="right">#D8BFD8</td>
    <td align="right">14204888</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FF6347">&nbsp;</td>
    <td>Tomato</td>

    <td align="right">#FF6347</td>
    <td align="right">16737095</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#40E0D0">&nbsp;</td>
    <td>Turquoise</td>
    <td align="right">#40E0D0</td>

    <td align="right">4251856</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#EE82EE">&nbsp;</td>
    <td>Violet</td>
    <td align="right">#EE82EE</td>
    <td align="right">15631086</td>

  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#F5DEB3">&nbsp;</td>
    <td>Wheat</td>
    <td align="right">#F5DEB3</td>
    <td align="right">16113331</td>
  </tr>

  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFFFF">&nbsp;</td>
    <td>White</td>
    <td align="right">#FFFFFF</td>
    <td align="right">16777215</td>
  </tr>
  <tr>

    <td WIDTH="35%" BGCOLOR="#F5F5F5">&nbsp;</td>
    <td>Whitesmoke</td>
    <td align="right">#F5F5F5</td>
    <td align="right">16119285</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#FFFF00">&nbsp;</td>

    <td>Yellow</td>
    <td align="right">#FFFF00</td>
    <td align="right">16776960</td>
  </tr>
  <tr>
    <td WIDTH="35%" BGCOLOR="#9ACD32">&nbsp;</td>
    <td>Yellowgreen</td>

    <td align="right">#9ACD32</td>
    <td align="right">10145074</td>
  </tr>
</tbody>
</table>
</html>

<?php

global $CURUSER, $STYLEPATH;








block_end();
stdfoot();

?>