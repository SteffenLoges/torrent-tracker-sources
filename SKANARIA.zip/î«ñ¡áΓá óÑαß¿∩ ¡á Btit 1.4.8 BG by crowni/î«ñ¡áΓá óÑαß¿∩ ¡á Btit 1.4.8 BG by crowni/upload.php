<?php

require_once ("include/functions.php");
require_once ("include/config.php");
require_once ("include/BDecode.php");
require_once ("include/BEncode.php");

//// Configuration//
function_exists("sha1") or die('<FONT COLOR="red">".NOT_SHA."</FONT></BODY></HTML>');

dbconn();

standardheader('Uploads');

if (!$CURUSER || $CURUSER["can_upload"]=="no")
   {
       stderr(ERROR.NOT_AUTHORIZED_UPLOAD,SORRY."...");
   }

block_begin(MNU_UPLOAD);

print("<table class=\"lista\" border=\"0\" width=\"100%\">\n");
print("<tr><td align=center>");

if (isset($_FILES["torrent"]))
   {
   if ($_FILES["torrent"]["error"] != 4)
   {
      $fd = fopen($_FILES["torrent"]["tmp_name"], "rb") or die(FILE_UPLOAD_ERROR_1);
      is_uploaded_file($_FILES["torrent"]["tmp_name"]) or die(FILE_UPLOAD_ERROR_2);
      $length=filesize($_FILES["torrent"]["tmp_name"]);
      if ($length)
        $alltorrent = fread($fd, $length);
      else {
        err_msg(ERROR,FILE_UPLOAD_ERROR_3);
        print("</td></tr></table>");
        block_end();
        stdfoot();
        exit();

       }
      $array = BDecode($alltorrent);
      if (!isset($array))
         {
         echo "<FONT COLOR=\"red\">".ERR_PARSER."</FONT>";
         endOutput();
         exit;
         }
      if (!$array)
         {
         echo "<FONT COLOR=\"red\">".ERR_PARSER."</FONT>";
         endOutput();
         exit;
         }
    // if dht disabled ($DHT_PRIVATE=true), set private flag and save new info hash
    //if ($array["announce"]==$BASEURL."/announce.php" && $DHT_PRIVATE)
    if (in_array($array["announce"],$TRACKER_ANNOUNCEURLS) && $DHT_PRIVATE)
      {
      $array["info"]["private"]=1;
      $hash=sha1(BEncode($array["info"]));
      }
    else
      {
      $hash = sha1(BEncode($array["info"]));
      }
      fclose($fd);
      }

if (isset($_POST["filename"]))
   $filename=htmlspecialchars($_POST["filename"]);
else
    $filename = AddSlashes(htmlspecialchars($_FILES["torrent"]["name"]));

if (isset($_POST["image"]))
   $image = AddSlashes($_POST["image"]);
else
    $image = "";

if (isset($_POST["imdb_url"]))
   $imdb_url = AddSlashes($_POST["imdb_url"]);
else
    $imdb_url = "";

if (isset($_POST["sub_url"]))
   $sub_url = AddSlashes($_POST["sub_url"]);
else
    $sub_url = "";

if (isset($_POST["subs_sab"]))
   $sub_sab = AddSlashes($_POST["subs_sab"]);
else
    $subs_sab = "";

if (isset($_POST["youtube_video"]))
   $youtube_video = AddSlashes($_POST["youtube_video"]);
else
    $youtube_video = "";

if (isset($_POST["bgaudio"]))
   $bgaudio = AddSlashes($_POST["bgaudio"]);
else
    $bgaudio = "";

if (isset($_POST["gamerzhut_url"]))
   $gamerzhut_url = AddSlashes($_POST["gamerzhut_url"]);
else
    $gamerzhut_url = "";

if (isset($hash) && $hash) $url = $TORRENTSDIR . "/" . $hash . ".btf";
else $url = 0;

if (isset($_POST["info"]))
   $comment = AddSlashes($_POST["info"]);
else
    $comment = "";

if (isset($_POST["autoset"]))
   {
   if (strcmp($_POST["autoset"], "enabled") == 0)
      {
      if (strlen($filename) == 0 && isset($array["info"]["name"]))
         $filename = AddSlashes(htmlspecialchars($array["info"]["name"]));
      if (isset($array["comment"]))
         $info = AddSlashes($array["comment"]);
      else
          $info = "";
      }
   }

if (isset($array["info"]) && $array["info"]) $upfile=$array["info"];
    else $upfile = 0;

if (isset($upfile["length"]))
{
  $size = floatval($upfile["length"]);
}
else if (isset($upfile["files"]))
     {
// multifiles torrent
         $size=0;
         foreach ($upfile["files"] as $file)
                 {
                 $size+=floatval($file["length"]);
                 }
     }
else
    $size = "0";

if (!isset($array["announce"]))
     {
     err_msg(ERROR, "Announce is empty");
     print("</td></tr></table>");
     block_end();
     stdfoot();
     exit();
}

      $filename = ($filename);
      $url = ($url);
      $info = ($info);
      $gamerzhut_url = ($gamerzhut_url);
      $image = ($image);
      $subs_sab = ($subs_sab);
      $sub_url = ($sub_url);
      $youtube_video = ($youtube_video);
      $imdb_url = ($imdb_url);
      $bgaudio = ($bgaudio);
      $categoria = 0+$_POST["type"];
      $categoria = ($categoria);
      $comment = ($comment);
      $announce=$array["announce"];
      $anonyme=$_POST["anonymous"];

      if ($categoria==0)
         {
             err_msg(ERROR,WRITE_CATEGORY);
             print("</td></tr></table>");
             block_end();
             stdfoot();
             exit();
         }

      if ((strlen($hash) != 40) || !verifyHash($hash))
      {
         echo("<center><FONT COLOR=\"red\">".ERR_HASH."</FONT></center>");
         endOutput();
      }
//      if ($announce!=$BASEURL."/announce.php" && $EXTERNAL_TORRENTS==false)
      if (!in_array($announce,$TRACKER_ANNOUNCEURLS) && $EXTERNAL_TORRENTS==false)
         {
           err_msg(ERROR,ERR_EXTERNAL_NOT_ALLOWED);
           unlink($_FILES["torrent"]["tmp_name"]);
           print("</td></tr></table>");
           block_end();
           stdfoot();
           exit();
         }
//      if ($announce!=$BASEURL."/announce.php")
      if (in_array($announce,$TRACKER_ANNOUNCEURLS))
         $query = "INSERT INTO namemap (info_hash, filename, bgaudio, imdb_url, sub_url, youtube_video, image, gamerzhut_url, subs_sab, url, info, category, data, size, comment, uploader,anonymous) VALUES (\"$hash\", \"$filename\", \"$bgaudio\", \"$imdb_url\", \"$sub_url\", \"$youtube_video\", \"$image\", \"$gamerzhut_url\", \"subs_sab\", \"$url\", \"$info\",0 + $categoria,NOW(), \"$size\", \"$comment\",".$CURUSER["uid"].",$anonyme)";
      else
         $query = "INSERT INTO namemap (info_hash, filename, bgaudio, imdb_url, sub_url, youtube_video, image, gamerzhut_url, subs_sab, url, info, category, data, size, comment,external,announce_url, uploader,anonymous) VALUES (\"$hash\", \"$filename\", \"$bgaudio\", \"$imdb_url\", \"$sub_url\", \"$youtube_video\", \"$image\", \"$gamerzhut_url\", \"subs_sab\", \"$url\", \"$info\",0 + $categoria,NOW(), \"$size\", \"$comment\",\"yes\",\"$announce\",".$CURUSER["uid"].",$anonyme)";

      //echo $query;
      $status = makeTorrent($hash, true);
      quickQuery($query);
      if ($status)
         {
         move_uploaded_file($_FILES["torrent"]["tmp_name"] , $TORRENTSDIR . "/" . $hash . ".btf") or die(ERR_MOVING_TORR);
//         if ($announce!=$BASEURL."/announce.php")
        if (!in_array($announce,$TRACKER_ANNOUNCEURLS))
            {
                require_once("./include/getscrape.php");
                scrape($announce,$hash);
                print("<center>".MSG_UP_SUCCESS."<br /><br />\n");
                write_log("Uploaded new torrent $filename - EXT ($hash)","add");
            }
         else
             {
              if ($DHT_PRIVATE)
                   {
                   $alltorrent=bencode($array);
                   $fd = fopen($TORRENTSDIR . "/" . $hash . ".btf", "rb+");
                   fwrite($fd,$alltorrent);
                   fclose($fd);
                   }
                // with pid system active or private flag (dht disabled), tell the user to download the new torrent
                write_log("Uploaded new torrent $filename ($hash)","add");
                print("<center>".MSG_UP_SUCCESS."<br /><br />\n");
                if ($PRIVATE_ANNOUNCE || $DHT_PRIVATE)
                   print(MSG_DOWNLOAD_PID."<br /><a href=\"download.php?id=$hash&f=".urlencode($filename).".torrent\">".DOWNLOAD."</a><br /><br />");
             }
         print("<a href=\"torrents.php\">".RETURN_TORRENTS."</a></center>");
         print("</td></tr></table>");
         block_end();
         }
      else
          {
              err_msg(ERROR,ERR_ALREADY_EXIST);
              unlink($_FILES["torrent"]["tmp_name"]);
              print("</td></tr></table>");
              block_end();
              stdfoot();
          }
}
else
    endOutput();

function endOutput()
{
 global $BASEURL, $user_id, $TRACKER_ANNOUNCEURLS;
  ?>
  </CENTER>
  <?php
  echo "<center>".INSERT_DATA."<BR><BR>";
  //echo " ".ANNOUNCE_URL." <b>$BASEURL/announce.php</b><BR></center>";
  echo " ".ANNOUNCE_URL."<br /><b>";
  foreach ($TRACKER_ANNOUNCEURLS as $taurl)
        echo "$taurl<br />";
  echo "</b><BR></center>";
  ?>
  <FORM name="upload" method="post" ENCTYPE="multipart/form-data">
  <TABLE class="lista" align="center">
  <TR><TD class="header"><?php echo TORRENT_FILE ?>:</TD><TD class="lista">
  <?php
  if (function_exists("sha1"))
     echo '<INPUT TYPE="file" NAME="torrent">';
  else
      echo "<I>".NO_SHA_NO_UP."</I>";
  ?>
  </TD>
  </TR>
  <?php
  $s = "<select name=\"type\">\n<option value=\"0\">(".CHOOSE.")</option>\n";
  $cats = genrelist();
  foreach ($cats as $row)
  $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";
  $s .= "</select>\n";
  print("<TR><TD class=\"header\" >".CATEGORY_FULL.": </TD><TD class=\"lista\">" . $s . "</td></tr>");
  ?>
  <TR>
  <TD class="header"><?echo IMAGE_URL;?>: </TD>
  <TD class="lista" ><INPUT TYPE=text name="image" size=50 maxlength=2000></TD>
  </TR>
<tr>
   <td align="left" class="header"><?echo IMDB_URL;?>:</td>
   <td align="left" class="lista"><input type="text" size="50" name="imdb_url" maxlength="250" value=""/></td>
</tr>
<tr>
   <td align="left" class="header"><?echo YOU_TUBE;?>:</td>
   <td align="left" class="lista"><input type="text" size="50" name="youtube_video" maxlength="250" value=""/></td>
</tr>
  <TR>
  <TD class="header"><?php echo FILE_NAME;?>(<?php echo FACOLTATIVE;?>): </TD>
  <TD class="lista" ><INPUT TYPE="text" name="filename" size="50" maxlength="200" /></TD>
  </TR>
  <TR>
  <TD class="header" valign="top"><?php echo DESCRIPTION;?> (<?php echo FACOLTATIVE;?>): </TD>
  <TD class="lista" ><?php
  textbbcode("upload","info");
  ?></TD>
  </TR>
<tr>
   <td align="left" class="header"><?echo GAMERZHUT_URL;?>:</td>
   <td align="left" class="lista"><input type="text" size="50" name="gamerzhut_url" maxlength="250" value=""/></td>
</tr>
  <TR>
  <TD align="left" class="header"><?echo SUBS_SAB;?>: </td>
  <TD align="left" class="lista"><input type="text" size="50" name="subs_sab" maxlength="250" value=""/></td>
  </TR>
  <TR>
  <TD align="left" class="header"><?echo SUB_URL;?>: </td>
  <TD align="left" class="lista"><input type="text" size="50" name="sub_url" maxlength="250" value=""/></td>
  </TR>
  <?php
  print("<TR><TD colspan=\"2\"><INPUT TYPE=\"hidden\" name=\"user_id\" size=\"50\" value=\"$user_id\" /> </TD /></TR>");
//BGAudio Hack Start
print("<tr><TD class=\"header\" align=\"left\">".��������.":</TD><TD class=\"lista\" align=\"left\">");
print("<select name=\"bgaudio\" size=\"1\">");
print("<option value=\"false\"".$selected.">".NO."</option>");
print("<option value=\"true\"".$selected.">".YES."</option>");
print("</select></TD></tr>");
//BGAudio Hack Stop
  print('<TR><td class="header">'.TORRENT_ANONYMOUS.'</td><TD class="lista">&nbsp;&nbsp;'.NO.'<INPUT TYPE="radio" name="anonymous" value="false" checked />&nbsp;&nbsp;'.YES.'<INPUT TYPE="radio" name="anonymous" value="true" /></TD></TR>');
  if (function_exists("sha1"))
     echo '<TR><TD class="lista" align="center" colspan="2"><INPUT TYPE="checkbox" name="autoset" value="enabled" checked />'.TORRENT_CHECK.'</TD></TR>';
  ?>
  <TR>
  <TD align="right"><INPUT type="submit" value="<?php echo FRM_SEND ?>" /></TD>
  <TD align="left"><INPUT type="reset" value="<?php echo FRM_RESET ?>" /></TD>
  </TR>
  </TABLE>
  </FORM>
  <?php
  print("</td></tr></table>");
  block_end();
}
stdfoot();
?>