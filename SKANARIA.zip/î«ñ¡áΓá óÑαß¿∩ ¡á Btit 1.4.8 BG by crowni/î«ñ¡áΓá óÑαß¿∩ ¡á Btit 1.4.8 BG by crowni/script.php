<?php
require_once ("include/functions.php");
require_once ("include/config.php");
dbconn();
standardheader("����� �������");
block_begin("����� �������");

/*
                 @@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@  @@@@@@@@@@@  @@@@@@@@@@@@@@@@@@
                  ..@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@    @@@@@    @@@@@@@@@@@@@@@@@@@@
                    :@@@       :@@@   @@      @@@@      @@     @@@     @@      @@@@      @@
                    :@@@        :@@@  :       @@@@       :     @@@     :       @@@@       :
                    :@@@        :@@@          @@@@             @@@             @@@@
                    :@@@       :@@@           @@@@             @@@             @@@@
                    :@@@@@@@@@@@@             @@@@             @@@             @@@@
                    :@@@@@@@@@@@@             @@@@             @@@             @@@@
                    :@@@       :@@@           @@@@             @@@             @@@@
                    :@@@        :@@@@         @@@@             @@@             @@@@
                    :@@@        :@@@@         @@@@             @@@             @@@@
                    :@@@       :@@@@          @@@@             @@@             @@@@
                  ..@@@@@@@@@@@@@@            @@@@            @@@@@            @@@@
                 @@@@@@@@@@@@@@@@         @@@@@@@@@@@@     @@@@@@@@@@@     @@@@@@@@@@@@
*/

//Options

//Table Name
$table="videos";

//Categories
define("AUTOS_VEHICLES", "A���������");
define("COMEDY", "�������");
define("ENTERTAINMENT", "�������");
define("FILM_ANIMATION", "����� � ��������");
define("HOWTO_STYLE", "�����");
define("MUSIC", "M�����");
define("NEWS_POLITICS", "������ � ��������");
define("PEOPLE_BLOGS", "�����");
define("PETS_ANIMALS", "�������");
define("SPORTS", "�����");
define("TRAVEL_EVENTS", "�������");

//Options

function table_exists ($table, $database)
{
$tables = mysql_list_tables ($database);
while (list ($temp) = mysql_fetch_array ($tables))
{
if ($temp == $table)
{
return TRUE;
}
}
return FALSE;
}

if (table_exists($table, $database))
{
function check($link)
{
$check=@get_headers($link);
if (preg_match("|200|", $check[0]))
{
return TRUE;
}
else
{
return FALSE;
}
}

function category($action, $sez="")
{
$cat = array (array("A���������", "".AUTOS_VEHICLES.""),
              array("�������", "".COMEDY.""),
              array("�������", "".ENTERTAINMENT.""),
              array("����� � ��������", "".FILM_ANIMATION.""),
              array("�����", "".HOWTO_STYLE.""),
              array("M�����", "".MUSIC.""),
              array("������ � ��������", "".NEWS_POLITICS.""),
              array("�����", "".PEOPLE_BLOGS.""),
              array("�������", "".PETS_ANIMALS.""),
              array("�������", "".SPORTS.""),
              array("�������", "".TRAVEL_EVENTS.""));

if ($action=="translate")
{
for ($i=0; $i<count($cat); $i++)
{
$sez = str_replace($cat[$i][0], $cat[$i][1], $sez);
}
}
elseif ($action=="count")
{
$sez=count($cat);
}
elseif ($action=="cat_eng")
{
$sez=$cat[$sez][0];
}
elseif ($action=="cat_not_eng")
{
$sez=$cat[$sez][1];
}
return $sez;
}

function select()
{
$src.= "<select name=\"categorie\">";
$src.= "<option value=\"\">---";
for ($i=0; $i<category("count"); $i++)
{
$l+=1;
$src.= "<option value=$l>".category("cat_not_eng", $i)."";
}
$src.= "</select>";
return $src;
}

function all_embed($string, $type)
{
if ($type=="youtube")
{
$optional2="</object>";
$other="wmode=\"transparent\"";
$style="width=\"425\" height=\"350\"";
$total_link="http://www.youtube.com/v/".$string."";
$optional="<object width=\"425\" height=\"350\"><param name=\"movie\" value=\"$total_link\"></param><param name=\"wmode\" value=\"transparent\"></param>";
}
elseif ($type=="google")
{
$optional="";
$optional2="";
$other="id=\"VideoPlayback\" flashvars=\"\"";
$style="style=\"width:400px; height:326px;\"";
$total_link="http://video.google.com/googleplayer.swf?docId=".$string."&hl=en";
}
elseif ($type=="metacafe")
{
$optional="";
$optional2="";
$other="wmode=\"transparent\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\"";
$style="width=\"400\" height=\"345\"";
$total_link="http://www.metacafe.com/fplayer/".$string.".swf";
}
return "$optional<embed $style src=\"$total_link\" type=\"application/x-shockwave-flash\" $other></embed>$optional2";
}

function wsxedc ($search, $action="")
{
$query=mysql_query("SELECT * FROM ".$GLOBALS["table"]." WHERE id = '$search'");
if (mysql_num_rows($query)==1)
{
if ($action=="only_check")
{
return TRUE;
}
else
{
while ($elementi= mysql_fetch_object($query))
{
return "<center>".$elementi->title." (".category(translate, $elementi->category).")<br>".all_embed($elementi->id, $elementi->type)."<br>".($action=="get"?"":"<br>���� ����� ���� ���� ������!<br>")."<br></center>";
}
}
}
else
{
RETURN FALSE;
}
}

if ($_GET["action"]=="new")
{
$src.="<br><center><a href=\"".$_SERVER['PHP_SELF']."\"><b><size=2>�����</size></b></a></center>";
$src.= "<br><form method=\"post\" action=\"".$_SERVER['PHP_SELF']."?action=new\">
<center><input type=\"text\" name=\"video\"/>
<input class=\"codebuttons\" type=\"submit\" value=\"KA��!\"/></center>
</form><br>";
if(!empty($_POST['video']))
{
if (preg_match("#http://www.youtube.com/[watch\?]*v[=|/]([a-zA-Z0-9_\-]{11})#i",$_POST['video'],$id))
{
if (wsxedc($id[1], "only_check"))
{
$src.= wsxedc($id[1]);
}
else
{
if (check("http://www.youtube.com/watch?v=$id[1]"))
{
$sorgente_pagina = @file_get_contents("http://www.youtube.com/api2_rest?method=youtube.videos.get_details&dev_id=BnvzCjJ_Bzw&video_id=$id[1]");

preg_match("#<title>(.*)</title>.*#i", $sorgente_pagina, $title);
preg_match("#<channel>(.*)</channel>#i", $sorgente_pagina, $category);

$category[1]=preg_replace('/amp;/', '', $category[1]);

$db_category=addslashes(stripslashes("$category[1]"));
$src.="<center>$title[1] (".category(translate, $category[1]).")</center>";
$src.="<center>".all_embed($id[1], "youtube")."</center><br>";

$db_title=addslashes(stripslashes("$title[1]"));
$db_id=addslashes(stripslashes("$id[1]"));

mysql_query("INSERT INTO ".$table." (title, id, category, type) VALUES ('$db_title', '$db_id', '$db_category', 'youtube')");
}
else
{
$src.="<center>����� ����� ���� �� ���������� !</center><br>";
}
}
}
elseif (preg_match("#http://video.google.com/videoplay\?docid=([0-9\-]{17,20})#i",$_POST['video'],$id))
{
if (wsxedc($id[1], "only_check"))
{
$src.= wsxedc($id[1]);
}
else
{
if (check("http://video.google.com/videoplay?docid=$id[1]"))
{
$sorgente_pagina = @file_get_contents("http://video.google.com/videofeed?docid=$id[1]");

preg_match("#<item><title>(.*)</title><link>#i", $sorgente_pagina, $title);

$db_title=addslashes(stripslashes("$title[1]"));

if (preg_match("#<guid>http://www.youtube.com/watch\?v=(.+)</guid>#i", $sorgente_pagina, $optional))
{
if (wsxedc($optional[1], "only_check"))
{
$src.= wsxedc($optional[1]);
}
else
{
$db_id=addslashes(stripslashes("$optional[1]"));
$eventuale = @file_get_contents("http://www.youtube.com/api2_rest?method=youtube.videos.get_details&dev_id=BnvzCjJ_Bzw&video_id=$optional[1]");
preg_match("#<channel>(.*)</channel>#i", $eventuale, $category);
$category[1]=preg_replace('/amp;/', '', $category[1]);
$db_category=addslashes(stripslashes("$category[1]"));
$src.="<center>$title[1] (".category(translate, $category[1]).")<br>".all_embed($optional[1], "youtube")."</center><br>";
mysql_query("INSERT INTO ".$table." (title, id, category, type) VALUES ('$db_title', '$db_id', '$db_category', 'youtube')");
}
}
elseif (preg_match("#<guid>http://www.metacafe.com/watch/(.+)/(.+)/</guid>#i", $sorgente_pagina, $optional))
{
if (wsxedc($optional[1].'/'.$optional[2], "only_check"))
{
$src.= wsxedc($optional[1].'/'.$optional[2]);
}
else
{
$db_id=addslashes(stripslashes("$optional[1].'/'.$optional[2]"));
$eventuale = @file_get_contents("http://www.metacafe.com/watch/$optional[1].'/'.$optional[2]");
$src.= "<center>$title[1]<br>";
$src.= "<br><img src=\"http://www.metacafe.com/thumb/".$optional[1].".jpg\"><br>";
$src.= "<br><form method=\"post\" action=\"".$_SERVER['PHP_SELF']."?action=metacafe\">";
$src.= "<input type=\"hidden\" name=\"id\" value=\"$optional[1]\">";
$src.= "<input type=\"hidden\" name=\"id2\" value=\"$optional[2]\">";
$src.= "<input type=\"text\" name=\"title\" value=\"$title[1]\"/>";
$src.= select();
$src.= "<input class=\"codebuttons\" type=\"submit\" value=\"������ �����!\"/>";
$src.= "</form></center><br>";
}
}
elseif (preg_match("#<guid>http://video.google.com/videoplay\?docid=$id[1]</guid>#i", $sorgente_pagina, $optional))
{
preg_match("#&gt;&lt;img src=\"(.*)\" [a-z]*=\"[0-9]*\" [a-z]*=\"[0-9]*\" [a-z]*=\"[0-9]*\" /&gt;&lt;/a&gt;&lt;#i", $sorgente_pagina, $img);
$src.= "<center>$title[1]<br>";
$src.= "<img src=\"$img[1]\"><br>";
$src.= "<br><form method=\"post\" action=\"".$_SERVER['PHP_SELF']."?action=google\">";
$src.= "<input type=\"hidden\" name=\"img\" value=\"$img[1]\">";
$src.= "<input type=\"hidden\" name=\"id\" value=\"$id[1]\">";
$src.= "<input type=\"text\" name=\"title\" value=\"$title[1]\"/>";
$src.= select();
$src.= "<input class=\"codebuttons\" type=\"submit\" value=\"������ �����!\"/>";
$src.= "</form></center><br>";
}
else
{
$src.= "<center>T��� �� � google video.</center><br>";
}
}
else
{
$src.="<center>����� ����� ���� �� ����������.</center><br>";
}
}
}
elseif (preg_match("#http://www.metacafe.com/watch/([0-9]*)/([a-z0-9_]*)#", $_POST['video'], $id))
{
if (wsxedc($id[1].'/'.$id[2], "only_check"))
{
$src.= wsxedc($id[1].'/'.$id[2]);
}
else
{
if (check("http://www.metacafe.com/watch/".$id[1]."/".$id[2]."/"))
{
$sorgente_pagina = @file_get_contents("$_POST[video]");
preg_match("#<title>(.*) Video</title>.*#i", $sorgente_pagina, $title);
$src.= "<center>$title[1]<br>";
$src.= "<br><img src=\"http://www.metacafe.com/thumb/".$id[1].".jpg\"><br>";
$src.= "<br><form method=\"post\" action=\"".$_SERVER['PHP_SELF']."?action=metacafe\">";
$src.= "<input type=\"hidden\" name=\"id\" value=\"$id[1]\">";
$src.= "<input type=\"hidden\" name=\"id2\" value=\"$id[2]\">";
$src.= "<input type=\"text\" name=\"title\" value=\"$title[1]\"/>";
$src.= select();
$src.= "<input class=\"codebuttons\" type=\"submit\" value=\"������ �����!\"/>";
$src.= "</form></center><br>";
}
else
{
$src.="<center>����� ����� ���� �� ����������.</center><br>";
}
}
}
else
{
$src.="<center>�� ������ ������������� url.</center><br>";
}
}
else
{
$src.="<center><b><font size=2>������ ����� ����</font></b>&nbsp;<b><font color=red size=2>(����� ��������� ������ � video.google.com, metacafe.com, youtube.com)</font></b></center><br>";
}
}
elseif (!empty($_GET["id"]))
{
$src.= "<br><center><a href=\"".$_SERVER['PHP_SELF']."\"><b><size=2>�����</size></b></a></center><br>";
if (wsxedc($_GET[id], "only_check"))
{
$src.= wsxedc($_GET[id], "get");
}
else
{
if (strlen($_GET["id"])=="11")
{
if (check("http://www.youtube.com/watch?v=$_GET[id]"))
{
$src.="<center>".all_embed($_GET["id"], "youtube")."</center><br>";
}
else
{
$src.="<center>������ ID</center><br>";
}
}
elseif (strlen($_GET["id"])>16 && strlen($_GET["id"])<21)
{
if (check("http://video.google.com/videoplay?docid=$_GET[id]"))
{
$src.="<center>".all_embed($_GET["id"], "google")."<center><br>";
}
else
{
$src.="<center>������ ID</center><br>";
}
}
elseif (preg_match("#([0-9]*)/([a-z0-9_]*)#",$_GET["id"],$qaz))
{
if (check("http://www.metacafe.com/watch/".$qaz[1]."/".$qaz[2]."/"))
{
$title = str_replace("_", " ", $qaz[2]);
$title = ucwords($title);
$src.="<center>".$title."<br>".all_embed($_GET["id"], "metacafe")."<center><br>";
}
else
{
$src.="<center>������ ID</center><br>";
}
}
else
{
$src.="<center>������ ID</center><br>";
}
}
}
elseif ($_GET["action"]=="google")
{
if (!empty($_POST["title"]) && !empty($_POST["categorie"]))
{
$src.= "<center><br><a href=\"".$_SERVER['PHP_SELF']."\"><b><size=2>�����</size></b></a><br><br>";
$src.=all_embed($_POST["id"], "google");
$src.="<br><br>����� ������ ���� ������� �����.<br><br>";
$db_title=addslashes(stripslashes($_POST['title']));
$db_id=addslashes(stripslashes($_POST['id']));
$db_category=addslashes(stripslashes(category("cat_eng", $_POST["categorie"]-1)));
$db_img=addslashes(stripslashes($_POST['img']));
mysql_query("INSERT INTO ".$table." (title, id, category, type, image) VALUES ('$db_title', '$db_id', '$db_category', 'google', '$db_img')");
}
else
{
redirect("".$_SERVER['PHP_SELF']."?action=new");
}
}
elseif ($_GET["action"]=="metacafe")
{
if (!empty($_POST["title"]) && !empty($_POST["categorie"]))
{
$src.= "<center><br><a href=\"".$_SERVER['PHP_SELF']."\"><b><size=2>�����</size></b></a><br><br>";
$src.= "<center>".$_POST['title']."<br><br>".all_embed($_POST['id']."/".$_POST['id2'],"metacafe")."</center>";
$src.="<br>����� ������ ���� ������� �����.<br><br>";
$db_title=addslashes(stripslashes($_POST['title']));
$db_id=addslashes(stripslashes($_POST['id']."/".$_POST['id2']));
$db_category=addslashes(stripslashes(category("cat_eng", $_POST["categorie"]-1)));
$db_img=addslashes(stripslashes("http://www.metacafe.com/thumb/".$_POST['id'].".jpg"));
mysql_query("INSERT INTO ".$table." (title, id, category, type, image) VALUES ('$db_title', '$db_id', '$db_category', 'metacafe', '$db_img')");
}
else
{
redirect("".$_SERVER['PHP_SELF']."?action=new");
}
}
else
{
$src.= "<br><center><a href=\"".$_SERVER['PHP_SELF']."?action=new\"><img src=\"images/upvideo.jpg\"></a></center><br>";
for ($i=0; $i<category(count); $i++)
{
$c=0;
$src.= "<center><span style=\"font-size:30pt;line-height:100%\">".category(cat_not_eng, $i)."</span></center><br>";
$query2=mysql_query("SELECT * FROM ".$table." where category='".category(cat_eng, $i)."' ORDER BY `number` DESC");
$src.="<center><table border=\"1\"><tr>";
while ($elementi= mysql_fetch_object($query2))
{
$c++;
$z=$c-1;
if ($z%6==0)
{
$src.= "</tr>";
}
if ($elementi->type=="youtube")
{
$imgarray = array("1","2","3");
$img=$imgarray[rand(0,count($imgarray)-1)];
$real_img="http://img.youtube.com/vi/".$elementi->id."/".$img.".jpg";
}
else
{
$real_img=$elementi->image;
}
$src.= "<td><a title=\"$elementi->title (".category(cat_not_eng, $i).")\" href=\"".$_SERVER['PHP_SELF']."?id=".$elementi->id."\"><center>".substr($elementi->title, 0, 22)."...</center></a><center><a href=\"".$_SERVER['PHP_SELF']."?id=".$elementi->id."\"><img title=\"$elementi->title (".category(cat_not_eng, $i).")\" alt=\"$elementi->title (".category(cat_not_eng, $i).")\" border=\"0\" width=\"120\" height=\"90\" src=\"".$real_img."\"></center></a></td>";
}
if ($z%6==0)
{
$src.= "<tr>";
}
$src.="</tr></table></center>";
if (!$c)
{
$src.="<center>� ���� ��������� ���� �������</center>";
}
$src.="<hr>";
}
}
}
else
{
$src="<center>T�������� \"$table\" �� ����������.</center>";
}
print $src;
block_end();
stdfoot();
?>