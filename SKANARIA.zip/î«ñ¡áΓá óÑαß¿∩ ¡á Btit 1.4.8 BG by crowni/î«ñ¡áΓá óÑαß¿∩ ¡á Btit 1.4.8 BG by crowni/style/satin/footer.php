</td>
<?
if(mysql_query("SELECT * FROM blocks WHERE position='r'"))
right_menu();
?>
</td>
</tr>
<tr>
<td height="20%" colspan="3">
<br><table class="main" align="center" cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<table class="block" colspan="3" align="center" height="20"><h2 align="center">Disclaimer</h2></td>
<tr><td class=lista align=center>None of the files shown here are actually hosted on this server. The links are provided solely by this site's users. The administrators of this site <font color=#BBB><b><?=$SITENAME?></b></font> cannot be held responsible for what its users post, or any other actions of its users. You may not use this site to distribute or download any material when you do not have the legal rights to do so. It is your own responsibility to adhere to these terms. By registering on and/or using this website, it is assumed that you, the user, have read, understood, and agreed to all the terms and conditions set forth by the site owners.
<?
echo ("<p align=center><img src=./style/satin/btiteam.gif border=0></a></p>");
?>
</td></tr></table>
<table class="block" colspan="3" align="center" height="20"><h2 align="center">Style Provided By <a href=mailto:treetopclimber@gmail.com>TreetopClimber</a> � 2006</h2></td>
</tr>
</tbody>
</td></tr></table>


