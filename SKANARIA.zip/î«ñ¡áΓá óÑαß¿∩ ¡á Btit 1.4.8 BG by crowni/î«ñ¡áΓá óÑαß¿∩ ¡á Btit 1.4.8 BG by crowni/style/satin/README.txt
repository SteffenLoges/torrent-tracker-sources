I left the other images in the file if you would like to uncomment them and use them, 
its your choice but I like it transparent. You can see the nice picture in the background 
better that way.