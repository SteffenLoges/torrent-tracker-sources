</td>
<?php
right_menu();
?>
<?
    echo "		</td>\n";
echo "        <td width=\"29\" valign=\"top\" style=\"background-image: url(style/klima/images/bord_r.gif)\"><img src=\"style/klima/images/spacer.gif\" alt=\"\"  width=\"29\" height=\"1\" border=\"0\"></td>\n";
echo "	    </tr>\n";
echo "</table>\n\n\n";
?>
</tr>
<?php
echo "<table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "  <tr>\n";
echo "    <td><table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "      <tr>\n";
echo "        <td class=\"foot_01\"><img src=\"style/klima/images/foot_l.gif\" alt=\"\" width=\"71\" height=\"60\"></td>\n";
echo "        <td class=\"foot_01_tile\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>\n";
echo "        <td class=\"foot_01\"><img src=\"style/klima/images/foot_r.gif\" alt=\"\" width=\"71\" height=\"60\"></td>\n";
echo "      </tr>\n";
echo "    </table></td>\n";
echo "  </tr>\n";
echo "  <tr>\n";
echo "    <td><table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "      <tr>\n";
echo "        <td class=\"foot_03\"><img src=\"style/klima/images/foot_01.gif\" alt=\"\" width=\"12\" height=\"73\"></td>\n";
echo "        <td class=\"foot_03_tile\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>\n";
echo "        <td class=\"foot_03\"><img src=\"style/klima/images/foot_02.gif\" alt=\"\" width=\"12\" height=\"73\"></td>\n";
echo "      </tr>\n";
echo "    </table></td>\n";
echo "  </tr>\n";
echo "  <tr>\n";
echo "    <td class=\"foot_main\">\n";
?>
<center><font face="verdana" size="1" color="#FF9900"><?
//
// *************************************************************************************************************************************
//			PLEASE DO NOT REMOVE THE POWERED BY LINE, SHOW SOME SUPPORT! WE WILL NOT SUPPORT ANYONE WHO HAS THIS LINE EDITED OR REMOVED!
// *************************************************************************************************************************************
GLOBAL $time_start, $gzip, $PRINT_DEBUG,$tracker_version;
  $time_end=get_microtime();
  print("<p align=center>");
  if ($PRINT_DEBUG)
        print(" Script Execution time: ".number_format(($time_end-$time_start),4)." sec.  -  GZIP: $gzip <br />");
print("BtiTracker ($tracker_version) by <a href=\"http://www.btiteam.org\">Btiteam</a><br />");
print ("<a href=\"http://besttracker.info\" target=\"_blank\">Theme by Hack346</a></CENTER></p>");
//
// *************************************************************************************************************************************
//			PLEASE DO NOT REMOVE THE POWERED BY LINE, SHOW SOME SUPPORT! WE WILL NOT SUPPORT ANYONE WHO HAS THIS LINE EDITED OR REMOVED!
// *************************************************************************************************************************************

?></font></center>
<?
echo "</td>\n";
echo "  </tr>\n";
echo "  <tr>\n";
echo "    <td><table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "      <tr>\n";
echo "        <td class=\"foot_05\"><img src=\"style/klima/images/foot_03.gif\" alt=\"site engine\" width=\"202\" height=\"44\"></td>\n";
echo "        <td class=\"foot_05_tile\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>\n";
echo "        <td class=\"foot_05\"><a href=\"http://effectica.com\" target=\"_blank\"><img src=\"style/klima/images/foot_04.gif\" alt=\"theme by effectica\" title=\"theme by effectica\" width=\"202\" height=\"44\" border=\"0\"></a></td>\n";
echo "      </tr>\n";
echo "    </table></td>\n";
echo "  </tr>\n";
echo "</table>";
?>
</table>
</table>
</BODY>

