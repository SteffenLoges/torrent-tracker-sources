<?php
require_once("include/functions.php");
require_once("include/config.php");
require_once("include/blocks.php");

?>
<BODY LEFTMARGIN="0" TOPMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0" align="center">
<?php
echo "<!-- theme klima by effectica &copy; 2005 All Rights Reserved -->\n";
echo "<table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "  <tr>\n";
echo "    <td><table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "      <tr>\n";
echo "        <td class=\"head_01\"><img src=\"style/klima/images/bnr_01.gif\" alt=\"\" width=\"51\" height=\"187\"></td>\n";
echo "        <td class=\"head_02\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"50\" height=\"1\"></td>\n";
echo "        <td class=\"head_03\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_04\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_05\">&nbsp;</td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td class=\"head_14\"><img src=\"style/klima/images/bnr_09.gif\" alt=\"\" width=\"51\" height=\"83\"></td>\n";
echo "        <td class=\"head_15\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"50\" height=\"1\"></td>\n";
echo "        <td class=\"head_16\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_17\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_18\">&nbsp;</td>\n";
echo "      </tr>\n";
echo "    </table></td>\n";
echo "    <td align=\"center\" class=\"tdsup\"><table width=\"100%\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"tabsup\">\n";
echo "      <tr>\n";
echo "        <td><table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "          <tr>\n";
echo "            <td class=\"head_06\"><img src=\"style/klima/images/bnr_u_01_01.gif\" alt=\"\" width=\"51\" height=\"75\"></td>\n";
echo "            <td class=\"head_07\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "            <td class=\"head_08\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"102\" height=\"1\"></td>\n";
echo "            <td class=\"head_09\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"101\" height=\"1\"></td>\n";
echo "            <td class=\"head_10\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "            <td class=\"head_06\"><img src=\"style/klima/images/bnr_u_04_02.gif\" alt=\"\" width=\"51\" height=\"75\"></td>\n";
echo "          </tr>\n";
echo "        </table></td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td class=\"head_logo\"><img src=\"style/klima/images/bnr.gif\" alt=\"\" width=\"407\" height=\"72\"></td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td class=\"head_menu\">\n";
echo "<object type=\"application/x-shockwave-flash\" data=\"style/klima/images/menu_bnr.swf\" width=\"407\" height=\"123\">\n";
echo "<param name=\"movie\" value=\"style/klima/images/menu_bnr.swf\" />\n";
echo "</object>\n";
echo "			</td>\n";
echo "      </tr>\n";
echo "    </table></td>\n";
echo "    <td><table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
echo "      <tr>\n";
echo "        <td class=\"head_05\">&nbsp;</td>\n";
echo "        <td class=\"head_11\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_12\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_13\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_01\"><img src=\"style/klima/images/bnr_08.gif\" alt=\"\" width=\"51\" height=\"187\"></td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td class=\"head_18\">&nbsp;</td>\n";
echo "        <td class=\"head_19\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_20\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"51\" height=\"1\"></td>\n";
echo "        <td class=\"head_21\"><img src=\"style/klima/images/spacer.gif\" alt=\"\" width=\"50\" height=\"1\"></td>\n";
echo "        <td class=\"head_14\"><img src=\"style/klima/images/bnr_16.gif\" alt=\"\" width=\"51\" height=\"83\"></td>\n";
echo "      </tr>\n";
echo "    </table></td>\n";
echo "  </tr>\n";
echo "</table>";
?>

<tr><td height="100" colspan="2">
<?
   echo "<table width=\"100%\"  cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">\n";
echo "		<tr valign=\"top\">\n";
echo "		<td width=\"29\" valign=\"top\" style=\"background-image: url(style/klima/images/bord_l.gif)\"><img src=\"style/klima/images/spacer.gif\" width=\"29\" height=\"1\" border=\"0\" alt=\"\"></td>\n";
echo "		<td   valign=\"top\">\n";
?>
<?php
main_menu();
?>
<?
    echo "		</td>\n";
echo "        <td width=\"29\" valign=\"top\" style=\"background-image: url(style/klima/images/bord_r.gif)\"><img src=\"style/klima/images/spacer.gif\" alt=\"\"  width=\"29\" height=\"1\" border=\"0\"></td>\n";
echo "	    </tr>\n";
echo "</table>\n\n\n";
?>
</td></tr>
<table width="100%" height="100%"  border="0">
<tr>
<?
   echo "<table width=\"100%\"  cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">\n";
echo "		<tr valign=\"top\">\n";
echo "		<td width=\"29\" valign=\"top\" style=\"background-image: url(style/klima/images/bord_l.gif)\"><img src=\"style/klima/images/spacer.gif\" width=\"29\" height=\"1\" border=\"0\" alt=\"\"></td>\n";
echo "		<td   valign=\"top\">\n";
?>
<?php

side_menu();

?>

<td valign=top>

