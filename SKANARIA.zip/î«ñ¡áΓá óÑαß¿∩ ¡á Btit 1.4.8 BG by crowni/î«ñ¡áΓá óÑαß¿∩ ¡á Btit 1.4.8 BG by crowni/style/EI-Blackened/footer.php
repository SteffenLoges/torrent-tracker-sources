</td>
<?

if (substr($_SERVER['PHP_SELF'], -12)!="torrents.php")
if (substr($_SERVER['PHP_SELF'], -10)!="upload.php")
if (substr($_SERVER['PHP_SELF'], -9)!="forum.php") {
?>
<?php
right_menu();
?>
<?
} 
?>

<?
    echo "        </td>\n";
    echo "        <td style=\"width: 57px; background-image: url(style/EI-Blackened/images/right.jpg)\" valign=\"top\"><img src=\"style/EI-Blackened/images/spacer.gif\" alt=\"\" width=\"57\" height=\"13\" /></td>\n";
    echo "        </tr>\n";
    echo "</table>\n\n\n";
?>
</tr>
</table>
</table>
<?	

echo "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" background=\"style/EI-Blackened/images/fmm.jpg\">";
echo "  <tr>";
echo "    <td width=\"377\" height=\"359\" valign=\"top\"><table width=\"377\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" background=\"style/EI-Blackened/images/fl.jpg\" width=\"377\" height=\"359\">";
echo "        <tr>";
echo "          <td width=\"58\" height=\"166\">&nbsp;</td>";
echo "          <td width=\"163\">&nbsp;</td>";
echo "          <td width=\"156\">&nbsp;</td>";
echo "        </tr>";
?>
        <tr>
          <td height="115">&nbsp;</td>
          <td><font color="#FF9900"><?
echo "<div style=\"background-color:#000000; color:#ffffff; font-size: xx-small;\" align=\"center\">\n";
// *************************************************************************************************************************************
//			PLEASE DO NOT REMOVE THE POWERED BY LINE, SHOW SOME SUPPORT! WE WILL NOT SUPPORT ANYONE WHO HAS THIS LINE EDITED OR REMOVED!
// *************************************************************************************************************************************
GLOBAL $time_start, $gzip, $PRINT_DEBUG,$tracker_version;
  $time_end=get_microtime();
  print("<p align=center>");
  if ($PRINT_DEBUG)
        print(" Script Execution time: ".number_format(($time_end-$time_start),4)." sec.  -  GZIP: $gzip <br />");
print("BtiTracker ($tracker_version) by <a href=\"http://www.btiteam.org\">Btiteam</a><br />");
print ("<a href=\"http://besttracker.info\" target=\"_blank\">Theme by Hack346</a></CENTER></p>");
//
// *************************************************************************************************************************************
//			PLEASE DO NOT REMOVE THE POWERED BY LINE, SHOW SOME SUPPORT! WE WILL NOT SUPPORT ANYONE WHO HAS THIS LINE EDITED OR REMOVED!
// *************************************************************************************************************************************
echo "</div>";?></td>
        <td>&nbsp;</td>
        </tr>
<?
echo "        <tr>";
echo "          <td height=\"77\">&nbsp;</td>";
echo "          <td>&nbsp;</td>";
echo "          <td>&nbsp;</td>";
echo "        </tr>";
echo "      </table></td>";
echo "    <td width=\"100%\" align=\"center\" valign=\"top\"><p>&nbsp;</p>";
echo "      <p>&nbsp;</p>";
echo "      <p>&nbsp;</p>";
echo "      <br /></br />";
echo "      <br /></br />";
echo "      <br /></br />";
echo "      <p><font color=\"#999999\" size=\"1\"><br /><br />";
echo "   </font></p>";
echo "      </td>";
echo "    <td width=\"377\" valign=\"top\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
echo "        <tr>";
echo "          <td width=\"355\" height=\"359\" valign=\"top\"><img src=\"style/EI-Blackened/images/fr.jpg\" width=\"355\" height=\"359\"></td>";
echo "        </tr>";
echo "      </table></td>";
echo "  </tr>";
echo "  <tr>";
echo "    <td height=\"0\"></td>";
echo "    <td></td>";
echo "    <td></td>";
echo "  </tr>";
echo "  <tr>";
echo "    <td height=\"1\"><img src=\"style/EI-Blackened/images/spacer.gif\" alt=\"\" width=\"355\" height=\"1\"></td>";
echo "    <td></td>";
echo "    <td><img src=\"style/EI-Blackened/images/spacer.gif\" alt=\"\" width=\"355\" height=\"1\"></td>";
echo "  </tr>";
echo "</table>";
?>
</BODY>

