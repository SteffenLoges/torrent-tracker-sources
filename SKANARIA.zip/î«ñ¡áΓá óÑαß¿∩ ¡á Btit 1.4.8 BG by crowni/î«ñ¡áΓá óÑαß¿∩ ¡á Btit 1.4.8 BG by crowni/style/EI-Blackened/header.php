<?php
require_once("include/functions.php");
require_once("include/config.php");
require_once("include/blocks.php");

?>
<BODY LEFTMARGIN="0" TOPMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0" align="center">
<?
echo "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" background=\"style/EI-Blackened/images/hmm.jpg\">\n";

echo " <tr> \n";
echo "<td width=\"377\" height=\"359\" valign=\"top\"><object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444535933597700\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\"377\" height=\"359\">\n";
echo "       <param name=\"movie\" value=\"style/EI-Blackened/images/hlogo.swf?link1=" . 'index.php' . "&amp;link1text=". 'HOME' ."&amp;link2=" . 'forum.php' . "&amp;link2text=" . 'FORUM' . "&amp;link3=" . 'upload.php' . "&amp;link3text=" . 'UPLOAD' . "&amp;link4=" . 'torrents.php' . "&amp;link4text=" . 'DOWNLOADS' . "&amp;link5=" . 'users.php' . "&amp;link5text=" . 'MEMBERS'. "&amp;link6=" . 'viewnews.php' . "&amp;link6text=" . 'NEWS' . "\" />\n";
echo "       <param name=\"quality\" value=\"high\">\n";
echo "       <param name=\"Your Text Here&enddata=\"1\">\n";
echo "       <embed src=\"style/EI-Blackened/images/hlogo.swf?link1=". 'index.php' . "&amp;link1text=". 'HOME' ."&amp;link2=" . 'forum.php' . "&amp;link2text=" . 'FORUM' . "&amp;link3=" . 'upload.php' . "&amp;link3text=" . 'UPLOAD' . "&amp;link4=" . 'torrents.php' . "&amp;link4text=" . 'DOWNLOADS' . "&amp;link5=" . 'users.php' . "&amp;link5text=" . 'MEMBERS'. "&amp;link6=" . 'viewnews.php' . "&amp;link6text=" . 'NEWS' . "\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"377\" height=\"359\"></embed></object></td>\n";
echo "    <td width=\"100%\" align=\"center\" valign=\"top\"><img src=\"style/EI-Blackened/images/hm.jpg\" width=\"100\" height=\"359\"></td>\n";
echo "    <td width=\"361\" valign=\"top\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n";
echo "        <tr>\n";
echo "          <td width=\"355\" height=\"359\" valign=\"top\"><img src=\"style/EI-Blackened/images/hr.jpg\" width=\"355\" height=\"359\"></td>\n";
echo "        </tr>\n";
echo "      </table></td>\n";
echo "  </tr>\n";
echo "</table>";
?>
</td>
</tr>
<tr><td height="100" colspan="2">
<?
    echo "<table width=\"100%\"  cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">\n";
    echo "        <tr valign=\"top\">\n";
    echo "        <td style=\"width: 57px; background-image: url(style/EI-Blackened/images/left.jpg)\" valign=\"top\"><img src=\"style/EI-Blackened/images/spacer.gif\" width=\"57\" height=\"13\" border=\"0\" alt=\"\" /></td>\n";
    echo "        <td valign=\"top\">\n";
?>
<?php
main_menu();
?>
<?
    echo "        </td>\n";
    echo "        <td style=\"width: 57px; background-image: url(style/EI-Blackened/images/right.jpg)\" valign=\"top\"><img src=\"style/EI-Blackened/images/spacer.gif\" alt=\"\" width=\"57\" height=\"13\" /></td>\n";
    echo "        </tr>\n";
    echo "</table>\n\n\n";
?>
</td></tr>
<table width="100%" height="100%"  border="0">
<tr>
<?
    echo "<table width=\"100%\"  cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">\n";
    echo "        <tr valign=\"top\">\n";
    echo "        <td style=\"width: 57px; background-image: url(style/EI-Blackened/images/left.jpg)\" valign=\"top\"><img src=\"style/EI-Blackened/images/spacer.gif\" width=\"57\" height=\"13\" border=\"0\" alt=\"\" /></td>\n";
    echo "        <td valign=\"top\">\n";
?>
<?php

side_menu();

?>
<td valign=top>

