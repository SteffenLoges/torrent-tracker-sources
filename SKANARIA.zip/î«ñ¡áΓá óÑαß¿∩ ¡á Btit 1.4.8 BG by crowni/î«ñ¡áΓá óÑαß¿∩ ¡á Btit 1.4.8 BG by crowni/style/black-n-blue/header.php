<?
require_once("include/functions.php");
require_once("include/config.php");
require_once("include/blocks.php");

?>

<table width="100%" height="100%"  border="0" colspan="4">

 <tr><td align=center>
 <a href=./index.php><img border=0 src="<? echo $STYLEPATH ?>/bt.logo.gif"></a>
 </td>
    </tr>
    </table>

<?
main_menu();
?>
</td></tr>
<table width="100%" height="100%"  border="0" colspan="4">
<tr>
<?

side_menu();

?>
<td valign=top>

