<?
header ("Location: ../index.php");
?>