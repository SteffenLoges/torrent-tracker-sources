<?
require_once ("include/functions.php");
dbconn();

standardheader("Partners");
?>
<?
block_begin(TRACKERS_PARTNERS);?>
<br>
<?
$query = "SELECT * FROM partner ORDER BY RAND()";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id = $row['id'];
$titel = $row['titel'];
$desc3 = $row['desc3'];
$banner = $row['banner'];
$url = $row['link'];

echo ("<tr><td width=100% class=tablea><br><center><font color=darkseagreen><font size=3><b>".$titel."</b></font></center>
<br><center><font color=orange><font size=2><b>".DESCRIPTION_DESCRIPTION_OF_THE_PARTNERS.": ".$desc3."</b></font></center>
<center><table width=60% border=1 cellspacing=2 cellpadding=7><tr><td class=text></center>
<center><a href=".$url." target=_blank><IMG SRC=".$banner."  WIDTH=468 HEIGHT=60 border=2></a></center>
</td></tr></table><br/>");
}
block_end();

block_begin(TOP_TRACKERS_PARTNERS);?>
<br>
<?
$query = "SELECT * FROM toppartner ORDER BY RAND()";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id1 = $row['id1'];
$titel1 = $row['titel1'];
$desc1 = $row['desc1'];
$banner1 = $row['banner1'];
$url1 = $row['link1'];

echo ("<tr><td width=100% class=tablea><br><center><font color=red><font size=3><b>".$titel1."</b></font></center>
<br><center><font color=orange><font size=2><b>".DESCRIPTION_DESCRIPTION_OF_THE_PARTNERS.": ".$desc1."</b></font></center>
<center><table width=60% border=1 cellspacing=2 cellpadding=7><tr><td class=text></center>
<center><a href=".$url1." target=_blank><IMG SRC=".$banner1."  WIDTH=468 HEIGHT=60 border=2></a></center>
</td></tr></table><br/>");
}
block_end(); 

block_begin(SPONSORS);?>
<br>
<?
$query = "SELECT * FROM sponsor ORDER BY RAND()";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id2 = $row['id2'];
$titel2 = $row['titel2'];
$desc2 = $row['desc2'];
$banner2 = $row['banner2'];
$url2 = $row['link2'];

echo ("<tr><td width=100% class=tablea><br><center><font color=red><font size=3>".$titel2."</font></center>
<br><center><font color=orange><font size=2><b>".DESCRIPTION_DESCRIPTION_OF_THE_SPONSOR.": ".$desc2."</b></font></center>
<center><table width=60% border=1 cellspacing=2 cellpadding=7><tr><td class=text></center>
<center><a href=".$url2." target=_blank><IMG SRC=".$banner2."  WIDTH=468 HEIGHT=60 border=2></a></center>
</td></tr></table><br/>");
}
?>

<?
block_end();
stdfoot();
?>
