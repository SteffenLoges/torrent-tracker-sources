-- phpMyAdmin SQL Dump
-- version 2.6.4-pl3
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Време на генериране: 24 февруари 2010 в 16:50
-- Версия на сървъра: 5.1.30
-- Версия на PHP: 5.3.1
-- 
-- БД: `btit`
-- 

-- --------------------------------------------------------

-- 
-- Структура на таблица `addedrequests`
-- 

CREATE TABLE `addedrequests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `requestid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pollid` (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Дъмп (схема) на данните в таблицата `addedrequests`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `bannedip`
-- 

CREATE TABLE `bannedip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `added` int(11) NOT NULL DEFAULT '0',
  `addedby` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `first` bigint(11) unsigned DEFAULT NULL,
  `last` bigint(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `first_last` (`first`,`last`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Дъмп (схема) на данните в таблицата `bannedip`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `blocks`
-- 

CREATE TABLE `blocks` (
  `blockid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `position` char(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sortid` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`blockid`)
) ENGINE=MyISAM AUTO_INCREMENT=192 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=192 ;

-- 
-- Дъмп (схема) на данните в таблицата `blocks`
-- 

INSERT INTO `blocks` VALUES (1, 'menu', 'l', 1, 1);
INSERT INTO `blocks` VALUES (2, 'clock', 'r', 1, 1);
INSERT INTO `blocks` VALUES (3, 'forum', 'l', 4, 1);
INSERT INTO `blocks` VALUES (4, 'lastmember', 'r', 3, 1);
INSERT INTO `blocks` VALUES (6, 'trackerinfo', 'r', 6, 1);
INSERT INTO `blocks` VALUES (7, 'user', 'r', 3, 1);
INSERT INTO `blocks` VALUES (8, 'online', 'r', 2, 1);
INSERT INTO `blocks` VALUES (9, 'shoutbox', 'c', 2, 0);
INSERT INTO `blocks` VALUES (10, 'toptorrents', 'c', 5, 0);
INSERT INTO `blocks` VALUES (11, 'lasttorrents', 'c', 2, 0);
INSERT INTO `blocks` VALUES (12, 'news', 'c', 3, 0);
INSERT INTO `blocks` VALUES (13, 'mainmenu', 't', 2, 1);
INSERT INTO `blocks` VALUES (14, 'maintrackertoolbar', 't', 2, 1);
INSERT INTO `blocks` VALUES (15, 'mainusertoolbar', 't', 3, 1);
INSERT INTO `blocks` VALUES (16, 'serverload', 'c', 8, 0);
INSERT INTO `blocks` VALUES (17, 'poll', 'c', 7, 1);
INSERT INTO `blocks` VALUES (18, 'seedwanted', 'c', 2, 0);
INSERT INTO `blocks` VALUES (19, 'paypal', 'r', 4, 1);
INSERT INTO `blocks` VALUES (24, 'flirt4e', 'l', 4, 0);
INSERT INTO `blocks` VALUES (66, 'rlz', 'c', 4, 1);
INSERT INTO `blocks` VALUES (5, 'shoutboxstaff', 'c', 2, 1);
INSERT INTO `blocks` VALUES (102, 'mp3', 'l', 1, 1);
INSERT INTO `blocks` VALUES (103, 'latesttorrents', 'c', 3, 1);
INSERT INTO `blocks` VALUES (25, 'wotd', 'r', 4, 1);
INSERT INTO `blocks` VALUES (60, 'comment', 'l', 10, 1);
INSERT INTO `blocks` VALUES (97, 'online_radio', 'r', 8, 0);
INSERT INTO `blocks` VALUES (150, 'radio', 'r', 8, 1);
INSERT INTO `blocks` VALUES (160, 'google', 'l', 8, 1);
INSERT INTO `blocks` VALUES (190, 'random_tor', 'l', 9, 1);
INSERT INTO `blocks` VALUES (191, 'rss', 'c', 1, 0);
INSERT INTO `blocks` VALUES (20, 'links', 'r', 9, 0);

-- --------------------------------------------------------

-- 
-- Структура на таблица `bonus`
-- 

CREATE TABLE `bonus` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `points` decimal(4,1) NOT NULL DEFAULT '0.0',
  `traffic` bigint(20) unsigned NOT NULL DEFAULT '0',
  `gb` int(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Дъмп (схема) на данните в таблицата `bonus`
-- 

INSERT INTO `bonus` VALUES (3, '1', 30.0, 1073741824, 1);
INSERT INTO `bonus` VALUES (4, '2', 50.0, 2147483648, 2);
INSERT INTO `bonus` VALUES (5, '3', 100.0, 5368709120, 5);

-- --------------------------------------------------------

-- 
-- Структура на таблица `categories`
-- 

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sub` int(10) NOT NULL DEFAULT '0',
  `sort_index` int(10) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=32 ;

-- 
-- Дъмп (схема) на данните в таблицата `categories`
-- 

INSERT INTO `categories` VALUES (31, 'Äðóãè', 0, 18, 'cat_free.gif');
INSERT INTO `categories` VALUES (15, 'Ôèëìè/XviD', 0, 2, 'cat_movies_xvid.gif');
INSERT INTO `categories` VALUES (16, 'Ôèëìè/DVD-R', 0, 3, 'cat_movies_dvdr.gif');
INSERT INTO `categories` VALUES (17, 'Ôèëìè/HDTV', 0, 4, 'cat_hd.gif');
INSERT INTO `categories` VALUES (14, 'Òâ ñåð/TV', 0, 1, 'cat_episodes_tveps_xvid.gif');
INSERT INTO `categories` VALUES (13, 'Àíèìàöèÿ', 0, 0, 'cat_anime.gif');
INSERT INTO `categories` VALUES (18, 'Èãðè/PC-ISO', 0, 5, 'cat_games.gif');
INSERT INTO `categories` VALUES (19, 'Èãðè/PS2', 0, 6, 'cat_ps2.gif');
INSERT INTO `categories` VALUES (20, 'Èãðè/PS3', 0, 7, 'cat_ps3.gif');
INSERT INTO `categories` VALUES (21, 'Èãðè/PSP', 0, 8, 'cat_psp.gif');
INSERT INTO `categories` VALUES (22, 'Èãðè/XBOX', 0, 9, 'cat_x360.gif');
INSERT INTO `categories` VALUES (23, 'Ìóçèêà/MP3', 0, 10, 'cat_music_music.gif');
INSERT INTO `categories` VALUES (24, 'Ìóçèêà/Video', 0, 11, 'cat_music_videos.gif');
INSERT INTO `categories` VALUES (25, 'Ñïîðò/Sport', 0, 12, 'cat_sport.gif');
INSERT INTO `categories` VALUES (26, 'Ñîôòóåð/Software', 0, 13, 'cat_apps.gif');
INSERT INTO `categories` VALUES (27, 'Mobile/GSM', 0, 14, 'cat_apps_pda.gif');
INSERT INTO `categories` VALUES (28, 'Êíèãè/E-books', 0, 15, 'cat_ebooks.gif');
INSERT INTO `categories` VALUES (29, 'XXX', 0, 16, 'cat_xxx_porn.gif');
INSERT INTO `categories` VALUES (30, 'Ìèñòèêà', 0, 17, 'cat_misc.gif');

-- --------------------------------------------------------

-- 
-- Структура на таблица `comments`
-- 

CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `text` text COLLATE latin1_general_ci NOT NULL,
  `ori_text` text COLLATE latin1_general_ci NOT NULL,
  `user` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `editedby` int(10) unsigned NOT NULL DEFAULT '0',
  `editedat` int(10) unsigned NOT NULL DEFAULT '0',
  `info_hash` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `info_hash` (`info_hash`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

-- 
-- Дъмп (схема) на данните в таблицата `comments`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `countries`
-- 

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `flagpic` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `domain` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=245 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=245 ;

-- 
-- Дъмп (схема) на данните в таблицата `countries`
-- 

INSERT INTO `countries` VALUES (1, 'Sweden', 'se.png', 'SE');
INSERT INTO `countries` VALUES (2, 'United States of America', 'us.png', 'US');
INSERT INTO `countries` VALUES (3, 'American Samoa', 'as.png', 'AS');
INSERT INTO `countries` VALUES (4, 'Finland', 'fi.png', 'FI');
INSERT INTO `countries` VALUES (5, 'Canada', 'ca.png', 'CA');
INSERT INTO `countries` VALUES (6, 'France', 'fr.png', 'FR');
INSERT INTO `countries` VALUES (7, 'Germany', 'de.png', 'DE');
INSERT INTO `countries` VALUES (8, 'China', 'cn.png', 'CN');
INSERT INTO `countries` VALUES (9, 'Italy', 'it.png', 'IT');
INSERT INTO `countries` VALUES (10, 'Denmark', 'dk.png', 'DK');
INSERT INTO `countries` VALUES (11, 'Norway', 'no.png', 'NO');
INSERT INTO `countries` VALUES (12, 'United Kingdom', 'gb.png', 'GB');
INSERT INTO `countries` VALUES (13, 'Ireland', 'ie.png', 'IE');
INSERT INTO `countries` VALUES (14, 'Poland', 'pl.png', 'PL');
INSERT INTO `countries` VALUES (15, 'Netherlands', 'nl.png', 'NL');
INSERT INTO `countries` VALUES (16, 'Belgium', 'be.png', 'BE');
INSERT INTO `countries` VALUES (17, 'Japan', 'jp.png', 'JP');
INSERT INTO `countries` VALUES (18, 'Brazil', 'br.png', 'BR');
INSERT INTO `countries` VALUES (19, 'Argentina', 'ar.png', 'AR');
INSERT INTO `countries` VALUES (20, 'Australia', 'au.png', 'AU');
INSERT INTO `countries` VALUES (21, 'New Zealand', 'nz.png', 'NZ');
INSERT INTO `countries` VALUES (22, 'United Arab Emirates', 'ae.png', 'AE');
INSERT INTO `countries` VALUES (23, 'Spain', 'es.png', 'ES');
INSERT INTO `countries` VALUES (24, 'Portugal', 'pt.png', 'PT');
INSERT INTO `countries` VALUES (25, 'Mexico', 'mx.png', 'MX');
INSERT INTO `countries` VALUES (26, 'Singapore', 'sg.png', 'SG');
INSERT INTO `countries` VALUES (27, 'Anguilla', 'ai.png', 'AI');
INSERT INTO `countries` VALUES (28, 'Armenia', 'am.png', 'AM');
INSERT INTO `countries` VALUES (29, 'South Africa', 'za.png', 'ZA');
INSERT INTO `countries` VALUES (30, 'South Korea', 'kr.png', 'KR');
INSERT INTO `countries` VALUES (31, 'Jamaica', 'jm.png', 'JM');
INSERT INTO `countries` VALUES (32, 'Luxembourg', 'lu.png', 'LU');
INSERT INTO `countries` VALUES (33, 'Hong Kong', 'hk.png', 'HK');
INSERT INTO `countries` VALUES (34, 'Belize', 'bz.png', 'BZ');
INSERT INTO `countries` VALUES (35, 'Algeria', 'dz.png', 'DZ');
INSERT INTO `countries` VALUES (36, 'Angola', 'ao.png', 'AO');
INSERT INTO `countries` VALUES (37, 'Austria', 'at.png', 'AT');
INSERT INTO `countries` VALUES (38, 'Aruba', 'aw.png', 'AW');
INSERT INTO `countries` VALUES (39, 'Samoa', 'ws.png', 'WS');
INSERT INTO `countries` VALUES (40, 'Malaysia', 'my.png', 'MY');
INSERT INTO `countries` VALUES (41, 'Dominican Republic', 'do.png', 'DO');
INSERT INTO `countries` VALUES (42, 'Greece', 'gr.png', 'GR');
INSERT INTO `countries` VALUES (43, 'Guatemala', 'gt.png', 'GT');
INSERT INTO `countries` VALUES (44, 'Israel', 'il.png', 'IL');
INSERT INTO `countries` VALUES (45, 'Pakistan', 'pk.png', 'PK');
INSERT INTO `countries` VALUES (46, 'Czech Republic', 'cz.png', 'CZ');
INSERT INTO `countries` VALUES (47, 'Serbia and Montenegro', 'cs.png', 'CS');
INSERT INTO `countries` VALUES (48, 'Seychelles', 'sc.png', 'SC');
INSERT INTO `countries` VALUES (49, 'Taiwan', 'tw.png', 'TW');
INSERT INTO `countries` VALUES (50, 'Puerto Rico', 'pr.png', 'PR');
INSERT INTO `countries` VALUES (51, 'Chile', 'cl.png', 'CL');
INSERT INTO `countries` VALUES (52, 'Cuba', 'cu.png', 'CU');
INSERT INTO `countries` VALUES (53, 'Congo', 'cg.png', 'CG');
INSERT INTO `countries` VALUES (54, 'Afghanistan', 'af.png', 'AF');
INSERT INTO `countries` VALUES (55, 'Turkey', 'tr.png', 'TR');
INSERT INTO `countries` VALUES (56, 'Uzbekistan', 'uz.png', 'UZ');
INSERT INTO `countries` VALUES (57, 'Switzerland', 'ch.png', 'CH');
INSERT INTO `countries` VALUES (58, 'Kiribati', 'ki.gif', 'KI');
INSERT INTO `countries` VALUES (59, 'Philippines', 'ph.png', 'PH');
INSERT INTO `countries` VALUES (60, 'Burkina Faso', 'bf.png', 'BF');
INSERT INTO `countries` VALUES (61, 'Nigeria', 'ng.png', 'NG');
INSERT INTO `countries` VALUES (62, 'Iceland', 'is.png', 'IS');
INSERT INTO `countries` VALUES (63, 'Nauru', 'nr.png', 'NR');
INSERT INTO `countries` VALUES (64, 'Slovenia', 'si.png', 'SI');
INSERT INTO `countries` VALUES (65, 'Albania', 'al.png', 'AL');
INSERT INTO `countries` VALUES (66, 'Turkmenistan', 'tm.png', 'TM');
INSERT INTO `countries` VALUES (67, 'Bosnia and Herzegovina', 'ba.png', 'BA');
INSERT INTO `countries` VALUES (68, 'Andorra', 'ad.png', 'AD');
INSERT INTO `countries` VALUES (69, 'Lithuania', 'lt.png', 'LT');
INSERT INTO `countries` VALUES (70, 'India', 'in.png', 'IN');
INSERT INTO `countries` VALUES (71, 'Netherlands Antilles', 'an.png', 'AN');
INSERT INTO `countries` VALUES (72, 'Ukraine', 'ua.png', 'UA');
INSERT INTO `countries` VALUES (73, 'Venezuela', 've.png', 'VE');
INSERT INTO `countries` VALUES (74, 'Hungary', 'hu.png', 'HU');
INSERT INTO `countries` VALUES (75, 'Romania', 'ro.png', 'RO');
INSERT INTO `countries` VALUES (76, 'Vanuatu', 'vu.png', 'VU');
INSERT INTO `countries` VALUES (77, 'Viet Nam', 'vn.png', 'VN');
INSERT INTO `countries` VALUES (78, 'Trinidad & Tobago', 'tt.png', 'TT');
INSERT INTO `countries` VALUES (79, 'Honduras', 'hn.png', 'HN');
INSERT INTO `countries` VALUES (80, 'Kyrgyzstan', 'kg.png', 'KG');
INSERT INTO `countries` VALUES (81, 'Ecuador', 'ec.png', 'EC');
INSERT INTO `countries` VALUES (82, 'Bahamas', 'bs.png', 'BS');
INSERT INTO `countries` VALUES (83, 'Peru', 'pe.png', 'PE');
INSERT INTO `countries` VALUES (84, 'Cambodia', 'kh.png', 'KH');
INSERT INTO `countries` VALUES (85, 'Barbados', 'bb.png', 'BB');
INSERT INTO `countries` VALUES (86, 'Bangladesh', 'bd.png', 'BD');
INSERT INTO `countries` VALUES (87, 'Laos', 'la.png', 'LA');
INSERT INTO `countries` VALUES (88, 'Uruguay', 'uy.png', 'UY');
INSERT INTO `countries` VALUES (89, 'Antigua Barbuda', 'ag.png', 'AG');
INSERT INTO `countries` VALUES (90, 'Paraguay', 'py.png', 'PY');
INSERT INTO `countries` VALUES (91, 'Antarctica', 'aq.png', 'AQ');
INSERT INTO `countries` VALUES (92, 'Russian Federation', 'ru.png', 'RU');
INSERT INTO `countries` VALUES (93, 'Thailand', 'th.png', 'TH');
INSERT INTO `countries` VALUES (94, 'Senegal', 'sn.png', 'SN');
INSERT INTO `countries` VALUES (95, 'Togo', 'tg.png', 'TG');
INSERT INTO `countries` VALUES (96, 'North Korea', 'kp.png', 'KP');
INSERT INTO `countries` VALUES (97, 'Croatia', 'hr.png', 'HR');
INSERT INTO `countries` VALUES (98, 'Estonia', 'ee.png', 'EE');
INSERT INTO `countries` VALUES (99, 'Colombia', 'co.png', 'CO');
INSERT INTO `countries` VALUES (100, 'unknown', 'unknown.gif', 'AA');
INSERT INTO `countries` VALUES (101, 'Organization', 'org.png', 'ORG');
INSERT INTO `countries` VALUES (102, 'Aland Islands', 'ax.png', 'AX');
INSERT INTO `countries` VALUES (103, 'Azerbaijan', 'az.png', 'AZ');
INSERT INTO `countries` VALUES (104, 'Bulgaria', 'bg.png', 'BG');
INSERT INTO `countries` VALUES (105, 'Bahrain', 'bh.png', 'BH');
INSERT INTO `countries` VALUES (106, 'Burundi', 'bi.png', 'BI');
INSERT INTO `countries` VALUES (107, 'Benin', 'bj.png', 'BJ');
INSERT INTO `countries` VALUES (108, 'Bermuda', 'bm.png', 'BM');
INSERT INTO `countries` VALUES (109, 'Brunei Darussalam', 'bn.png', 'BN');
INSERT INTO `countries` VALUES (110, 'Bolivia', 'bo.png', 'BO');
INSERT INTO `countries` VALUES (111, 'Bhutan', 'bt.png', 'BT');
INSERT INTO `countries` VALUES (112, 'Bouvet Island', 'bv.png', 'BV');
INSERT INTO `countries` VALUES (113, 'Botswana', 'bw.png', 'BW');
INSERT INTO `countries` VALUES (114, 'Belarus', 'by.png', 'BY');
INSERT INTO `countries` VALUES (115, 'Cocos (Keeling) Islands', 'cc.png', 'CC');
INSERT INTO `countries` VALUES (116, 'Congo, the Democratic Republic of the', 'cd.png', 'CD');
INSERT INTO `countries` VALUES (117, 'Central African Republic', 'cf.png', 'CF');
INSERT INTO `countries` VALUES (118, 'Ivory Coast', 'ci.png', 'CI');
INSERT INTO `countries` VALUES (119, 'Cook Islands', 'ck.png', 'CK');
INSERT INTO `countries` VALUES (120, 'Cameroon', 'cm.png', 'CM');
INSERT INTO `countries` VALUES (121, 'Costa Rica', 'cr.png', 'CR');
INSERT INTO `countries` VALUES (122, 'Cape Verde', 'cv.png', 'CV');
INSERT INTO `countries` VALUES (123, 'Christmas Island', 'cx.png', 'CX');
INSERT INTO `countries` VALUES (124, 'Cyprus', 'cy.png', 'CY');
INSERT INTO `countries` VALUES (125, 'Djibouti', 'dj.png', 'DJ');
INSERT INTO `countries` VALUES (126, 'Dominica', 'dm.png', 'DM');
INSERT INTO `countries` VALUES (127, 'Egypt', 'eg.png', 'EG');
INSERT INTO `countries` VALUES (128, 'Western Sahara', 'eh.png', 'EH');
INSERT INTO `countries` VALUES (129, 'Eritrea', 'er.png', 'ER');
INSERT INTO `countries` VALUES (130, 'Ethiopia', 'et.png', 'ET');
INSERT INTO `countries` VALUES (131, 'Fiji', 'fj.png', 'FJ');
INSERT INTO `countries` VALUES (132, 'Falkland Islands (Malvinas)', 'fk.png', 'FK');
INSERT INTO `countries` VALUES (133, 'Micronesia, Federated States of', 'fm.png', 'FM');
INSERT INTO `countries` VALUES (134, 'Faroe Islands', 'fo.png', 'FO');
INSERT INTO `countries` VALUES (135, 'Gabon', 'ga.png', 'GA');
INSERT INTO `countries` VALUES (136, 'Grenada', 'gd.png', 'GD');
INSERT INTO `countries` VALUES (137, 'Georgia', 'ge.png', 'GE');
INSERT INTO `countries` VALUES (138, 'French Guiana', 'gf.png', 'GF');
INSERT INTO `countries` VALUES (139, 'Guernsey', 'gg.png', 'GG');
INSERT INTO `countries` VALUES (140, 'Ghana', 'gh.png', 'GH');
INSERT INTO `countries` VALUES (141, 'Gibraltar', 'gi.png', 'GI');
INSERT INTO `countries` VALUES (142, 'Greenland', 'gl.png', 'GL');
INSERT INTO `countries` VALUES (143, 'Gambia', 'gm.png', 'GM');
INSERT INTO `countries` VALUES (144, 'Guinea', 'gn.png', 'GN');
INSERT INTO `countries` VALUES (145, 'Guadeloupe', 'gp.png', 'GP');
INSERT INTO `countries` VALUES (146, 'Equatorial Guinea', 'gq.png', 'GQ');
INSERT INTO `countries` VALUES (147, 'South Georgia and the South Sandwich Islands', 'gs.png', 'GS');
INSERT INTO `countries` VALUES (148, 'Guam', 'gu.png', 'GU');
INSERT INTO `countries` VALUES (149, 'Guinea-Bissau', 'gw.png', 'GW');
INSERT INTO `countries` VALUES (150, 'Guyana', 'gy.png', 'GY');
INSERT INTO `countries` VALUES (151, 'Heard Island and McDonald Islands', 'hm.png', 'HM');
INSERT INTO `countries` VALUES (152, 'Haiti', 'ht.png', 'HT');
INSERT INTO `countries` VALUES (153, 'Indonesia', 'id.png', 'ID');
INSERT INTO `countries` VALUES (154, 'Isle of Man', 'im.png', 'IM');
INSERT INTO `countries` VALUES (155, 'British Indian Ocean Territory', 'io.png', 'IO');
INSERT INTO `countries` VALUES (156, 'Jersey', 'je.png', 'JE');
INSERT INTO `countries` VALUES (157, 'Jordan', 'jo.png', 'JO');
INSERT INTO `countries` VALUES (158, 'Kenya', 'ke.png', 'KE');
INSERT INTO `countries` VALUES (159, 'Comoros', 'km.png', 'KM');
INSERT INTO `countries` VALUES (160, 'Saint Kitts and Nevis', 'kn.png', 'KN');
INSERT INTO `countries` VALUES (161, 'Kuwait', 'kw.png', 'KW');
INSERT INTO `countries` VALUES (162, 'Cayman Islands', 'ky.png', 'KY');
INSERT INTO `countries` VALUES (163, 'Kazahstan', 'kz.png', 'KZ');
INSERT INTO `countries` VALUES (164, 'Lebanon', 'lb.png', 'LB');
INSERT INTO `countries` VALUES (165, 'Saint Lucia', 'lc.png', 'LC');
INSERT INTO `countries` VALUES (166, 'Liechtenstein', 'li.png', 'LI');
INSERT INTO `countries` VALUES (167, 'Sri Lanka', 'lk.png', 'LK');
INSERT INTO `countries` VALUES (168, 'Liberia', 'lr.png', 'LR');
INSERT INTO `countries` VALUES (169, 'Lesotho', 'ls.png', 'LS');
INSERT INTO `countries` VALUES (170, 'Latvia', 'lv.png', 'LV');
INSERT INTO `countries` VALUES (171, 'Libyan Arab Jamahiriya', 'ly.png', 'LY');
INSERT INTO `countries` VALUES (172, 'Morocco', 'ma.png', 'MA');
INSERT INTO `countries` VALUES (173, 'Monaco', 'mc.png', 'MC');
INSERT INTO `countries` VALUES (174, 'Moldova, Republic of', 'md.png', 'MD');
INSERT INTO `countries` VALUES (175, 'Madagascar', 'mg.png', 'MG');
INSERT INTO `countries` VALUES (176, 'Marshall Islands', 'mh.png', 'MH');
INSERT INTO `countries` VALUES (177, 'Macedonia, the former Yugoslav Republic of', 'mk.png', 'MK');
INSERT INTO `countries` VALUES (178, 'Mali', 'ml.png', 'ML');
INSERT INTO `countries` VALUES (179, 'Myanmar', 'mm.png', 'MM');
INSERT INTO `countries` VALUES (180, 'Mongolia', 'mn.png', 'MN');
INSERT INTO `countries` VALUES (181, 'Macao', 'mo.png', 'MO');
INSERT INTO `countries` VALUES (182, 'Northern Mariana Islands', 'mp.png', 'MP');
INSERT INTO `countries` VALUES (183, 'Martinique', 'mq.png', 'MQ');
INSERT INTO `countries` VALUES (184, 'Mauritania', 'mr.png', 'MR');
INSERT INTO `countries` VALUES (185, 'Montserrat', 'ms.png', 'MS');
INSERT INTO `countries` VALUES (186, 'Malta', 'mt.png', 'MT');
INSERT INTO `countries` VALUES (187, 'Mauritius', 'mu.png', 'MU');
INSERT INTO `countries` VALUES (188, 'Maldives', 'mv.png', 'MV');
INSERT INTO `countries` VALUES (189, 'Malawi', 'mw.png', 'MW');
INSERT INTO `countries` VALUES (190, 'Mozambique', 'mz.png', 'MZ');
INSERT INTO `countries` VALUES (191, 'Namibia', 'na.png', 'NA');
INSERT INTO `countries` VALUES (192, 'New Caledonia', 'nc.png', 'NC');
INSERT INTO `countries` VALUES (193, 'Niger', 'ne.png', 'NE');
INSERT INTO `countries` VALUES (194, 'Norfolk Island', 'nf.png', 'NF');
INSERT INTO `countries` VALUES (195, 'Nicaragua', 'ni.png', 'NI');
INSERT INTO `countries` VALUES (196, 'Nepal', 'np.png', 'NP');
INSERT INTO `countries` VALUES (197, 'Niue', 'nu.png', 'NU');
INSERT INTO `countries` VALUES (198, 'Oman', 'om.png', 'OM');
INSERT INTO `countries` VALUES (199, 'Panama', 'pa.png', 'PA');
INSERT INTO `countries` VALUES (200, 'French Polynesia', 'pf.png', 'PF');
INSERT INTO `countries` VALUES (201, 'Papua New Guinea', 'pg.png', 'PG');
INSERT INTO `countries` VALUES (202, 'Saint Pierre and Miquelon', 'pm.png', 'PM');
INSERT INTO `countries` VALUES (203, 'Pitcairn', 'pn.png', 'PN');
INSERT INTO `countries` VALUES (204, 'Palestinian Territory, Occupied', 'ps.png', 'PS');
INSERT INTO `countries` VALUES (205, 'Palau', 'pw.png', 'PW');
INSERT INTO `countries` VALUES (206, 'Qatar', 'qa.png', 'QA');
INSERT INTO `countries` VALUES (207, 'Reunion', 're.png', 'RE');
INSERT INTO `countries` VALUES (208, 'Rwanda', 'rw.png', 'RW');
INSERT INTO `countries` VALUES (209, 'Saudi Arabia', 'sa.png', 'SA');
INSERT INTO `countries` VALUES (210, 'Solomon Islands', 'sb.png', 'SB');
INSERT INTO `countries` VALUES (211, 'Sudan', 'sd.png', 'SD');
INSERT INTO `countries` VALUES (212, 'Saint Helena', 'sh.png', 'SH');
INSERT INTO `countries` VALUES (213, 'Svalbard and Jan Mayen', 'sj.png', 'SJ');
INSERT INTO `countries` VALUES (214, 'Slovakia', 'sk.png', 'SK');
INSERT INTO `countries` VALUES (215, 'Sierra Leone', 'sl.png', 'SL');
INSERT INTO `countries` VALUES (216, 'San Marino', 'sm.png', 'SM');
INSERT INTO `countries` VALUES (217, 'Somalia', 'so.png', 'SO');
INSERT INTO `countries` VALUES (218, 'Suriname', 'sr.png', 'SR');
INSERT INTO `countries` VALUES (219, 'Sao Tome and Principe', 'st.png', 'ST');
INSERT INTO `countries` VALUES (220, 'El Salvador', 'sv.png', 'SV');
INSERT INTO `countries` VALUES (221, 'Syrian Arab Republic', 'sy.png', 'SY');
INSERT INTO `countries` VALUES (222, 'Swaziland', 'sz.png', 'SZ');
INSERT INTO `countries` VALUES (223, 'Turks and Caicos Islands', 'tc.png', 'TC');
INSERT INTO `countries` VALUES (224, 'Chad', 'td.png', 'TD');
INSERT INTO `countries` VALUES (225, 'French Southern Territories', 'tf.png', 'TF');
INSERT INTO `countries` VALUES (226, 'Tajikistan', 'tj.png', 'TJ');
INSERT INTO `countries` VALUES (227, 'Tokelau', 'tk.png', 'TK');
INSERT INTO `countries` VALUES (228, 'Timor-Leste', 'tl.png', 'TL');
INSERT INTO `countries` VALUES (229, 'Tunisia', 'tn.png', 'TN');
INSERT INTO `countries` VALUES (230, 'Tonga', 'to.png', 'TO');
INSERT INTO `countries` VALUES (231, 'Tuvalu', 'tv.png', 'TV');
INSERT INTO `countries` VALUES (232, 'Tanzania, United Republic of', 'tz.png', 'TZ');
INSERT INTO `countries` VALUES (233, 'Uganda', 'ug.png', 'UG');
INSERT INTO `countries` VALUES (234, 'United States Minor Outlying Islands', 'um.png', 'UM');
INSERT INTO `countries` VALUES (235, 'Holy See (Vatican City State)', 'va.png', 'VA');
INSERT INTO `countries` VALUES (236, 'Saint Vincent and the Grenadines', 'vc.png', 'VC');
INSERT INTO `countries` VALUES (237, 'Virgin Islands, British', 'vg.png', 'VG');
INSERT INTO `countries` VALUES (238, 'Wallis and Futuna', 'wf.png', 'WF');
INSERT INTO `countries` VALUES (239, 'Yemen', 'ye.png', 'YE');
INSERT INTO `countries` VALUES (240, 'Mayotte', 'yt.png', 'YT');
INSERT INTO `countries` VALUES (241, 'Zambia', 'zm.png', 'ZM');
INSERT INTO `countries` VALUES (242, 'Zimbabwe', 'zw.png', 'ZW');
INSERT INTO `countries` VALUES (243, 'Iraq', 'iq.png', 'IQ');
INSERT INTO `countries` VALUES (244, 'Iran, Islamic Republic of', 'ir.png', 'IR');

-- --------------------------------------------------------

-- 
-- Структура на таблица `expected`
-- 

CREATE TABLE `expected` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `expect` varchar(225) DEFAULT NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date` varchar(255) NOT NULL DEFAULT '',
  `cat` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Дъмп (схема) на данните в таблицата `expected`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `forums`
-- 

CREATE TABLE `forums` (
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `minclassread` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `minclasswrite` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `postcount` int(10) unsigned NOT NULL DEFAULT '0',
  `topiccount` int(10) unsigned NOT NULL DEFAULT '0',
  `minclasscreate` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

-- 
-- Дъмп (схема) на данните в таблицата `forums`
-- 

INSERT INTO `forums` VALUES (0, 1, 'Ãëàâåí ôîðóì', '', 3, 3, 2, 2, 3);
INSERT INTO `forums` VALUES (0, 2, 'Òîðåíòè', 'Ñúçäàâàíè è úïëîóäâàíå íà òîðåíòè', 3, 3, 0, 0, 6);
INSERT INTO `forums` VALUES (0, 3, 'Ôèëìè', '', 3, 3, 0, 0, 3);
INSERT INTO `forums` VALUES (0, 4, 'Èãðè', '', 3, 3, 0, 0, 3);
INSERT INTO `forums` VALUES (0, 5, 'Ìóçèêà', '', 3, 3, 16, 1, 3);
INSERT INTO `forums` VALUES (0, 6, 'Ïðîãðàìè', '', 3, 3, 1, 1, 3);
INSERT INTO `forums` VALUES (0, 7, 'Ïðåäëîæåíèÿ è Îïëàêâàíèÿ', '', 3, 3, 0, 0, 3);
INSERT INTO `forums` VALUES (0, 8, 'Îáÿâè', '', 3, 3, 0, 0, 3);
INSERT INTO `forums` VALUES (0, 9, 'Êîø÷å', '', 3, 6, 0, 0, 6);

-- --------------------------------------------------------

-- 
-- Структура на таблица `free_leech_req`
-- 

CREATE TABLE `free_leech_req` (
  `info_hash` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `count` int(10) NOT NULL DEFAULT '1',
  `approved` enum('yes','no','undecided') COLLATE latin1_general_ci NOT NULL DEFAULT 'undecided',
  `requester_ids` text COLLATE latin1_general_ci NOT NULL,
  UNIQUE KEY `info_hash` (`info_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `free_leech_req`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `history`
-- 

CREATE TABLE `history` (
  `uid` int(10) DEFAULT NULL,
  `infohash` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `date` int(10) DEFAULT NULL,
  `uploaded` bigint(20) NOT NULL DEFAULT '0',
  `downloaded` bigint(20) NOT NULL DEFAULT '0',
  `active` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `agent` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  UNIQUE KEY `uid` (`uid`,`infohash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `history`
-- 

INSERT INTO `history` VALUES (8, '83cc039dff36ba32da95a2bf0448507819dfd4cc', NULL, 0, 0, 'no', 'uTorrent 2.0.0.0');
INSERT INTO `history` VALUES (12, '230c91fff8491c9af76b23823e967a328e06c0ce', NULL, 0, 0, 'no', 'uTorrent 2.0.0.0');

-- --------------------------------------------------------

-- 
-- Структура на таблица `language`
-- 

CREATE TABLE `language` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `language` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `language_url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

-- 
-- Дъмп (схема) на данните в таблицата `language`
-- 

INSERT INTO `language` VALUES (1, 'English', 'language/english.php');
INSERT INTO `language` VALUES (2, 'Polish', 'language/polish.php');
INSERT INTO `language` VALUES (3, 'Bulgarian', 'language/bulgarian.php');

-- --------------------------------------------------------

-- 
-- Структура на таблица `logs`
-- 

CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `added` int(10) DEFAULT NULL,
  `txt` text COLLATE latin1_general_ci,
  `type` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT 'add',
  `user` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM AUTO_INCREMENT=175 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=175 ;

-- 
-- Дъмп (схема) на данните в таблицата `logs`
-- 

INSERT INTO `logs` VALUES (1, 1257612832, 'Uploaded new torrent Zombieland.R5.LiNE.XviD-DEViSE (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (2, 1257613197, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (3, 1257613378, 'Uploaded new torrent Jennifers Body R5 Line XviD IMAGINE (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (4, 1257613389, 'Modified torrent ''Jennifers Body R5 Line XviD IMAGINE'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (5, 1257613894, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (6, 1257613904, 'Modified torrent ''Jennifers Body R5 Line XviD IMAGINE'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (7, 1257613910, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (8, 1257617600, 'Modified torrent ''Jennifers Body R5 Line XviD IMAGINE'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (9, 1257617669, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (10, 1257617675, 'Modified torrent ''Jennifers Body R5 Line XviD IMAGINE'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (11, 1257618173, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (12, 1257765803, 'Modified torrent ''Jennifers Body R5 Line XviD IMAGINE'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (13, 1257765813, 'Deleted torrent Jennifers Body R5 Line XviD IMAGINE (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (14, 1257766439, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (15, 1257766973, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (16, 1257767716, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (17, 1257768487, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (18, 1257769139, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (19, 1257771131, 'Premoted userid 3 from User to PowerUser', 'add', 'System');
INSERT INTO `logs` VALUES (20, 1257771465, 'Modified user aaa', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (21, 1257771470, 'Premoted userid 3 from User to PowerUser', 'add', 'System');
INSERT INTO `logs` VALUES (22, 1257771582, 'Modified user aaa', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (23, 1257771587, 'Premoted userid 3 from User to PowerUser', 'add', 'System');
INSERT INTO `logs` VALUES (24, 1257771671, 'Modified user aaa', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (25, 1257771675, 'Premoted userid 3 from User to PowerUser', 'add', 'System');
INSERT INTO `logs` VALUES (26, 1257773630, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (27, 1257773769, 'Uploaded new torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (28, 1257773849, 'Uploaded new torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (29, 1257774123, 'Uploaded new torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (30, 1257774146, 'Deleted torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (aaa)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (31, 1257774167, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (32, 1257775082, 'Uploaded new torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (33, 1257775110, 'Modified torrent ''A Perfect Getaway / Ia?oaeoiioi ayanoai (2009)'' (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (34, 1257775142, 'Deleted torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (aaa)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (35, 1257775374, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (36, 1257775413, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (37, 1257775454, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (38, 1257775500, 'Uploaded new torrent UP [ 2009 ] (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (39, 1257775512, 'Deleted torrent UP [ 2009 ] (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (aaa)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (40, 1257775564, 'Uploaded new torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (41, 1257775577, 'Deleted torrent A Perfect Getaway / Ia?oaeoiioi ayanoai (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (aaa)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (42, 1257775683, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (43, 1257775736, 'Uploaded new torrent UP [ 2009 ] (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (44, 1257775746, 'Deleted torrent UP [ 2009 ] (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (aaa)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (45, 1257775985, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (46, 1257775999, 'Deleted torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (test)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (47, 1257776582, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (48, 1257776834, 'Uploaded new torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (49, 1257776874, 'Deleted torrent Up / A iaaaoi (2009) (7c962bd224878f4b79eaa4a70a7622fc3c4520a8) Deleted by Xzone (aaa)', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (50, 1257778479, 'Modified torrent ''Zombieland.R5.LiNE.XviD-DEViSE'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (51, 1257779114, 'Deleted user aaa', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (52, 1257780892, 'Uploaded new torrent The Hangover / Iineaaieyo a?aainee caiie (2009) (04f361e39549edd0ed1a15307318372a6eb8f437)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (53, 1257780932, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (54, 1257781000, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (55, 1257781145, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (56, 1257781159, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (57, 1257781247, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (58, 1257781917, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (59, 1257782385, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (60, 1257782396, 'Modified torrent ''The Hangover / Iineaaieyo a?aainee caiie (2009)'' (04f361e39549edd0ed1a15307318372a6eb8f437)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (61, 1257783096, 'Uploaded new torrent Spread / I?ioaney ?eaiei (2009) (a221070d430c2004dce2309b6a14096be62be8ab)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (62, 1257783127, 'Modified torrent ''Spread / I?ioaney ?eaiei (2009)'' (a221070d430c2004dce2309b6a14096be62be8ab)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (63, 1257783183, 'Modified torrent ''Spread / I?ioaney ?eaiei (2009)'' (a221070d430c2004dce2309b6a14096be62be8ab)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (64, 1257785484, 'Uploaded new torrent Up / A iaaaoi (2009) (ce35e936cb98bd40c6dd81959a6b13740be7cc28)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (65, 1257785511, 'Modified torrent ''Up / A iaaaoi (2009)'' (ce35e936cb98bd40c6dd81959a6b13740be7cc28)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (66, 1257789760, 'Modified torrent ''Zombieland / Caiyoa ia ciiaeoaoa (2009)'' (f3b91cb3bd38b87c05422d03f49ddc2b99a581ca)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (67, 1257792130, 'Modified torrent ''Spread / I?ioaney ?eaiei (2009)'' (a221070d430c2004dce2309b6a14096be62be8ab)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (68, 1257792154, 'Modified torrent ''Spread / I?ioaney ?eaiei (2009)'' (a221070d430c2004dce2309b6a14096be62be8ab)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (69, 1257798682, 'Uploaded new torrent Need for Speed: Shift (RELOADED) (75578586eaa46319ed10e6d1b6609ecc2ff7e0da)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (70, 1257798717, 'Modified torrent ''Need for Speed: Shift (RELOADED)'' (75578586eaa46319ed10e6d1b6609ecc2ff7e0da)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (71, 1257799377, 'Modified torrent ''Need for Speed: Shift (RELOADED)'' (75578586eaa46319ed10e6d1b6609ecc2ff7e0da)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (72, 1257800986, 'Uploaded new torrent Inna - Hot (2009) (5190ad7b9c450543de602448d028cf5e99442dc1)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (73, 1257801092, 'Modified torrent ''Inna - Hot (2009)'' (5190ad7b9c450543de602448d028cf5e99442dc1)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (74, 1257803426, 'Uploaded new torrent Law Abiding Citizen / Niu?oiiinai i?ioeaiee (2009) (bffe4c428730472db60ffe600d1c281c10a08a0b)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (75, 1257803464, 'Modified torrent ''Law Abiding Citizen / Niu?oiiinai i?ioeaiee (2009)'' (bffe4c428730472db60ffe600d1c281c10a08a0b)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (76, 1257845164, 'Uploaded new torrent Aliens in the Attic / I?eoueoe ia oaaaia (2009) (f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (77, 1257845194, 'Modified torrent ''Aliens in the Attic / I?eoueoe ia oaaaia (2009)'' (f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (78, 1257850415, 'Uploaded new torrent Monsters Vs Aliens / ?oaiaeua n?auo ecauicaiie (2009) (2f76e45579f9e2311b5e230bd6d4056e2ab218a3)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (79, 1257850439, 'Modified torrent ''Monsters Vs Aliens / ?oaiaeua n?auo ecauicaiie (2009)'' (2f76e45579f9e2311b5e230bd6d4056e2ab218a3)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (80, 1257851506, 'Deleted user sss', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (81, 1257851512, 'Deleted user ddd', 'delete', 'Xzone');
INSERT INTO `logs` VALUES (82, 1257873145, 'Uploaded new torrent Heroes / Aa?ie S04E09 (4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (83, 1257873177, 'Modified torrent ''Heroes / Aa?ie S04E09'' (4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (84, 1257874593, 'Uploaded new torrent Gossi Girl / Ei?eaaioeaoa S03E09 (2dff62bc5666f4437bf04139f9f8fb49f5e898b8)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (85, 1257874620, 'Modified torrent ''Gossi Girl / Ei?eaaioeaoa S03E09'' (2dff62bc5666f4437bf04139f9f8fb49f5e898b8)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (86, 1257874633, 'Modified torrent ''Gossip Girl / Ei?eaaioeaoa S03E09'' (2dff62bc5666f4437bf04139f9f8fb49f5e898b8)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (87, 1257875250, 'Uploaded new torrent Jennifer''s Body / Oyeioi ia A?aieou? (2009) (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (88, 1257875277, 'Modified torrent ''Jennifer''s Body / Oyeioi ia A?aieou? (2009)'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (89, 1257876023, 'Uploaded new torrent The Curious Case of Benjamin Button / No?aiieyo neo?ae n Aaia?aiei Auoui (2008) (d728b5a0948af20af1842580dd527902e9ef7c9c)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (90, 1257876067, 'Modified torrent ''The Curious Case of Benjamin Button / No?aiieyo neo?ae n Aaia?aiei Auoui (2008)'' (d728b5a0948af20af1842580dd527902e9ef7c9c)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (91, 1257877486, 'Uploaded new torrent District 9 / Naeoi? 9 (2009) (e33c4b8b33ebba92f5ff42bddbc680bc145f8155)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (92, 1257877511, 'Modified torrent ''District 9 / Naeoi? 9 (2009)'' (e33c4b8b33ebba92f5ff42bddbc680bc145f8155)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (93, 1257878261, 'Modified torrent ''Law Abiding Citizen / Niu?oiiinai i?ioeaiee (2009)'' (bffe4c428730472db60ffe600d1c281c10a08a0b)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (94, 1257879230, 'Modified torrent ''Heroes / Aa?ie S04E09'' (4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (95, 1257958141, 'Modified torrent ''Jennifer''s Body / Oyeioi ia A?aieou? (2009)'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (96, 1257958277, 'Modified torrent ''Jennifer''s Body / Oyeioi ia A?aieou? (2009)'' (97b0ff538f9825cb8204de523b22e2bb88aff493)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (97, 1257962426, 'Modified torrent ''Gossip Girl / Ei?eaaioeaoa S03E09'' (2dff62bc5666f4437bf04139f9f8fb49f5e898b8)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (98, 1257965311, 'Uploaded new torrent Empire Earth II - RELOADED (a37afec032d8c10ee8ddeb67d9f84f3951c8ad66)', 'add', 'Xzone');
INSERT INTO `logs` VALUES (99, 1257965330, 'Modified torrent ''Empire Earth II - RELOADED'' (a37afec032d8c10ee8ddeb67d9f84f3951c8ad66)', 'modify', 'Xzone');
INSERT INTO `logs` VALUES (100, 1264945204, 'FAILED update external torrent (infohash: 83cc039dff36ba32da95a2bf0448507819dfd4cc) from http://skanaria-bg.100webspace.net/announce.php tracker (not connectable)', '', 'fakira');
INSERT INTO `logs` VALUES (101, 1264945204, 'Uploaded new torrent Ultimate Survival/Õðàíà â ïóñòîøòà - EXT (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'add', 'fakira');
INSERT INTO `logs` VALUES (102, 1264945711, 'FAILED update external torrent (infohash: 83cc039dff36ba32da95a2bf0448507819dfd4cc) from http://skanaria-bg.100webspace.net/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (103, 1264945918, 'FAILED update external torrent (infohash: 83cc039dff36ba32da95a2bf0448507819dfd4cc) from http://skanaria-bg.100webspace.net/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (104, 1264946134, 'FAILED update external torrent (infohash: 83cc039dff36ba32da95a2bf0448507819dfd4cc) from http://skanaria-bg.100webspace.net/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (105, 1264946232, 'Deleted torrent Ultimate Survival/Õðàíà â ïóñòîøòà (83cc039dff36ba32da95a2bf0448507819dfd4cc) Deleted by fakira (0538405384)', 'delete', 'fakira');
INSERT INTO `logs` VALUES (106, 1264960236, 'Uploaded new torrent ÐžÑ†ÐµÐ»ÑÐ²Ð°Ð½Ðµ Ð½Ð° Ð¿Ñ€ÐµÐ´ÐµÐ»Ð° (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'add', 'fakira');
INSERT INTO `logs` VALUES (107, 1264961004, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíà íà ïðåäåëà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (108, 1264961080, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíà íà ïðåäåëà-Õðàíà â ïóñòîøòà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (109, 1264961521, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíà íà ïðåäåëà-Õðàíà â ïóñòîøòà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (110, 1264961697, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíà íà ïðåäåëà-Õðàíà â ïóñòîøòà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (111, 1264961874, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíå íà ïðåäåëà-Õðàíà â ïóñòîøòà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (112, 1264961953, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíå íà ïðåäåëà-Õðàíà â ïóñòîøòà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (113, 1264962261, 'Modified torrent ''Ultimate Survivàl/Îöåëÿâàíå íà ïðåäåëà-Õðàíà â ïóñòîøòà'' (83cc039dff36ba32da95a2bf0448507819dfd4cc)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (114, 1264973910, 'Uploaded new torrent uTorrent 1.8.5 Build 17414 Stable.exe (02c70ff4ba5991523265b4698e6f499d01f39325)', 'add', 'fakira');
INSERT INTO `logs` VALUES (115, 1265048933, 'Uploaded new torrent 2012 Íàóêà èëè ñóåâåðèå / 2012 Science Or Superstition (2009) (0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1)', 'add', 'fakira');
INSERT INTO `logs` VALUES (116, 1265049073, 'Modified torrent ''2012 Íàóêà èëè ñóåâåðèå / 2012 Science Or Superstition (2009)'' (0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (117, 1265049211, 'Modified torrent ''2012 Íàóêà èëè ñóåâåðèå / 2012 Science Or Superstition (2009)'' (0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (118, 1265049350, 'Modified torrent ''2012 Íàóêà èëè ñóåâåðèå / 2012 Science Or Superstition (2009)'' (0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (119, 1265049913, 'Modified torrent ''uTorrent 1.8.5 Build 17414 Stable.exe'' (02c70ff4ba5991523265b4698e6f499d01f39325)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (120, 1265049984, 'Modified torrent ''uTorrent 1.8.5 Build 17414 Stable.exe'' (02c70ff4ba5991523265b4698e6f499d01f39325)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (121, 1265050049, 'Modified torrent ''uTorrent 1.8.5 Build 17414 Stable.exe'' (02c70ff4ba5991523265b4698e6f499d01f39325)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (122, 1265050519, 'Uploaded new torrent Äèàìàíòèòå / Diamanti NG BG Audio TVRiP (1b441cb99839f95cd25ae2aedc17e4266b6c088b)', 'add', 'fakira');
INSERT INTO `logs` VALUES (123, 1265051374, 'Uploaded new torrent Ultimate Survival/Ñåâåðåí ïîëÿðåí êðúã (74fa5ac7c1849a8e4d93fb548e055f136d5e1d82)', 'add', 'fakira');
INSERT INTO `logs` VALUES (124, 1265051568, 'Deleted torrent Ultimate Survival/Ñåâåðåí ïîëÿðåí êðúã (74fa5ac7c1849a8e4d93fb548e055f136d5e1d82) Deleted by fakira (à)', 'delete', 'fakira');
INSERT INTO `logs` VALUES (125, 1265108812, 'Uploaded new torrent ×îâåøêîòî òÿëî 1 / BBC - The Human Body Part 1 - Life Story (8147175e914d3ee41f5f5e436568ac5b6f61f23a)', 'add', 'fakira');
INSERT INTO `logs` VALUES (126, 1265108906, 'Deleted torrent ×îâåøêîòî òÿëî 1 / BBC - The Human Body Part 1 - Life Story (8147175e914d3ee41f5f5e436568ac5b6f61f23a) Deleted by fakira (a)', 'delete', 'fakira');
INSERT INTO `logs` VALUES (127, 1265110219, 'Uploaded new torrent Âðúçêàòà ñ Àòëàíòèäà / La Conexion Atlante  (2001) (8e9351468d3bdfe8d24858a04713737bc73ad719)', 'add', 'fakira');
INSERT INTO `logs` VALUES (128, 1265110346, 'Modified torrent ''Âðúçêàòà ñ Àòëàíòèäà / La Conexion Atlante  (2001)'' (8e9351468d3bdfe8d24858a04713737bc73ad719)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (129, 1265138368, 'Uploaded new torrent Ïðîìåíåòå Windows XP èçöÿëî äà ïðèëè÷à íà Windows 7 (3ae6ab04b357ee90020d5ee7ae288ae0de6282da)', 'add', 'fakira');
INSERT INTO `logs` VALUES (130, 1265138936, 'Modified torrent ''Ïðîìåíåòå Windows XP èçöÿëî äà ïðèëè÷à íà Windows 7'' (3ae6ab04b357ee90020d5ee7ae288ae0de6282da)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (131, 1265139202, 'Uploaded new torrent Ultimate Survival (74fa5ac7c1849a8e4d93fb548e055f136d5e1d82)', 'add', 'fakira');
INSERT INTO `logs` VALUES (132, 1265139486, 'Modified torrent ''Ultimate Survival-Ñåâåðåí ïîëÿðåí êðúã'' (74fa5ac7c1849a8e4d93fb548e055f136d5e1d82)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (133, 1265139553, 'Modified torrent ''Ultimate Survival-Ñåâåðåí ïîëÿðåí êðúã'' (74fa5ac7c1849a8e4d93fb548e055f136d5e1d82)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (134, 1265228551, 'Modified user kar98', 'modify', 'lanselot');
INSERT INTO `logs` VALUES (135, 1265318404, 'Uploaded new torrent ×îâåøêîòî òÿëî 1 / BBC - The Human Body Part 1 - Life Story (8147175e914d3ee41f5f5e436568ac5b6f61f23a)', 'add', 'fakira');
INSERT INTO `logs` VALUES (136, 1265318635, 'Modified torrent ''2012 Íàóêà èëè ñóåâåðèå / 2012 Science Or Superstition (2009)'' (0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (137, 1265318658, 'Modified torrent ''uTorrent 1.8.5 Build 17414 Stable.exe'' (02c70ff4ba5991523265b4698e6f499d01f39325)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (138, 1265318694, 'Modified torrent ''Ultimate Survival-Ñåâåðåí ïîëÿðåí êðúã'' (74fa5ac7c1849a8e4d93fb548e055f136d5e1d82)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (139, 1265318763, 'Modified torrent ''×îâåøêîòî òÿëî 1 / BBC - The Human Body Part 1 - Life Story'' (8147175e914d3ee41f5f5e436568ac5b6f61f23a)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (140, 1265319327, 'Uploaded new torrent Îöåëÿâàíå íà ïðåäåëà - Õàâàè / Ultimate Survival - Hawaii  (2f3fb6392670b1c1476deffd1f5b046ac03d131b)', 'add', 'fakira');
INSERT INTO `logs` VALUES (141, 1265319647, 'Modified torrent ''Îöåëÿâàíå íà ïðåäåëà - Õàâàè / Ultimate Survival - Hawaii'' (2f3fb6392670b1c1476deffd1f5b046ac03d131b)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (142, 1265319817, 'Modified torrent ''Îöåëÿâàíå íà ïðåäåëà - Õàâàè / Ultimate Survival - Hawaii'' (2f3fb6392670b1c1476deffd1f5b046ac03d131b)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (143, 1265460101, 'Uploaded new torrent Retro hits (f82f76e1bc03aca7f23cecdaf9b2be414a004999)', 'add', 'fakira');
INSERT INTO `logs` VALUES (144, 1265460450, 'Uploaded new torrent WWE The Music-A New Day Vol 10-(WEB)-2010 (5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3)', 'add', 'fakira');
INSERT INTO `logs` VALUES (145, 1265460972, 'Uploaded new torrent The Human Body Part 2 - Everyday Miracle (07de55a880bafe1e1b85ca4a60329b39b9f191e9)', 'add', 'fakira');
INSERT INTO `logs` VALUES (146, 1265461122, 'Modified torrent ''÷îâåøêîòî òÿëî-2/The Human Body Part 2 - Everyday Miracle'' (07de55a880bafe1e1b85ca4a60329b39b9f191e9)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (147, 1265486480, 'Uploaded new torrent Joan Jade and the Gates of Xibalba (fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2)', 'add', 'fakira');
INSERT INTO `logs` VALUES (148, 1265522013, 'Deleted user scheepers', 'delete', 'lanselot');
INSERT INTO `logs` VALUES (149, 1265743198, 'Modified user scheepers', 'modify', 'fakira');
INSERT INTO `logs` VALUES (150, 1265746139, 'Uploaded new torrent Epica - Unleashed avi (e4552ae9a6992556b26bebd79ccfb2a93f66634a)', 'add', 'fakira');
INSERT INTO `logs` VALUES (151, 1265832258, 'Modified torrent ''Retro hits'' (f82f76e1bc03aca7f23cecdaf9b2be414a004999)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (152, 1265920502, 'Uploaded new torrent Mickeys Mouse-Once Upon A Christmas - BG Audio (d81d86324d1a113e5043817f878a39b4ec11ae81)', 'add', 'fakira');
INSERT INTO `logs` VALUES (153, 1265981956, 'Uploaded new torrent WWE.Royal.Rumble.2010 (56ecd6559b00547d784eb06b68cae0bebed0cbb0)', 'add', 'fakira');
INSERT INTO `logs` VALUES (154, 1265988277, 'Modified torrent ''WWE.Royal.Rumble.2010'' (56ecd6559b00547d784eb06b68cae0bebed0cbb0)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (155, 1266007564, 'Uploaded new torrent Íàé-äîáðèòå âèäåî è àóäèî ïëåúðè (5b3f8e5644dde537e8e8df8dae5756f47c74fa25)', 'add', 'fakira');
INSERT INTO `logs` VALUES (156, 1266007718, 'Modified torrent ''Íàé-äîáðèòå âèäåî è àóäèî ïëåúðè'' (5b3f8e5644dde537e8e8df8dae5756f47c74fa25)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (157, 1266007809, 'Modified torrent ''Íàé-äîáðèòå âèäåî è àóäèî ïëåúðè'' (5b3f8e5644dde537e8e8df8dae5756f47c74fa25)', 'modify', 'fakira');
INSERT INTO `logs` VALUES (158, 1266160451, 'FAILED update external torrent (infohash: 402dd7c4e27d1d86ca6b3cd835e2c0164a083233) from http://gettorrent.awardspace.biz/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (159, 1266160451, 'Uploaded new torrent Kapitan.Petko.voivoda - EXT (402dd7c4e27d1d86ca6b3cd835e2c0164a083233)', 'add', 'lanselot');
INSERT INTO `logs` VALUES (160, 1266160891, 'Modified torrent ''Kapitan.Petko.voivoda'' (402dd7c4e27d1d86ca6b3cd835e2c0164a083233)', 'modify', 'lanselot');
INSERT INTO `logs` VALUES (161, 1266160893, 'FAILED update external torrent (infohash: 402dd7c4e27d1d86ca6b3cd835e2c0164a083233) from http://gettorrent.awardspace.biz/announce.php tracker (not connectable)', '', 'System');
INSERT INTO `logs` VALUES (162, 1266161494, 'FAILED update external torrent (infohash: 402dd7c4e27d1d86ca6b3cd835e2c0164a083233) from http://gettorrent.awardspace.biz/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (163, 1266165247, 'FAILED update external torrent (infohash: 402dd7c4e27d1d86ca6b3cd835e2c0164a083233) from http://gettorrent.awardspace.biz/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (164, 1266165357, 'Deleted torrent Kapitan.Petko.voivoda (402dd7c4e27d1d86ca6b3cd835e2c0164a083233) Deleted by lanselot (nevaliden)', 'delete', 'lanselot');
INSERT INTO `logs` VALUES (165, 1266248297, 'FAILED update external torrent (infohash: 402dd7c4e27d1d86ca6b3cd835e2c0164a083233) from http://gettorrent.awardspace.biz/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (166, 1266248297, 'Uploaded new torrent Êàïèòàí Ïåòêî Âîéâîäà - EXT (402dd7c4e27d1d86ca6b3cd835e2c0164a083233)', 'add', 'lanselot');
INSERT INTO `logs` VALUES (167, 1266250224, 'FAILED update external torrent (infohash: 402dd7c4e27d1d86ca6b3cd835e2c0164a083233) from http://gettorrent.awardspace.biz/announce.php tracker (not connectable)', '', 'lanselot');
INSERT INTO `logs` VALUES (168, 1266250396, 'Deleted torrent Êàïèòàí Ïåòêî Âîéâîäà (402dd7c4e27d1d86ca6b3cd835e2c0164a083233) Deleted by lanselot (íåâàëèäåí)', 'delete', 'lanselot');
INSERT INTO `logs` VALUES (169, 1266250783, 'Uploaded new torrent Êàïèòàí Ïåòêî Âîéâîäà (402dd7c4e27d1d86ca6b3cd835e2c0164a083233)', 'add', 'lanselot');
INSERT INTO `logs` VALUES (170, 1266356753, 'Uploaded new torrent Âèðòóàëíà Õèìè÷íà Ëàáîðàòîðèÿ 2.0 / A Virtual Chemistry Lab 2.0 (a7a8b68bae557cda7193e10467ecdfba5a5fce17)', 'add', 'fakira');
INSERT INTO `logs` VALUES (171, 1266424231, 'Uploaded new torrent Sizing up The universe / Ïîçíàòàòà âñåëåíà Èçìåðâàíå íà âñåëåíàòà (2009) (e07a628ac7ece96531ed02db15ba76c0ec9ba0a7)', 'add', 'fakira');
INSERT INTO `logs` VALUES (172, 1266427250, 'Uploaded new torrent 2012 / 2012 (2009) (594fc7244ed3b3c4e5eaf94af67afa99accdddf9)', 'add', 'fakira');
INSERT INTO `logs` VALUES (173, 1266593360, 'Uploaded new torrent Apokalipsis (230c91fff8491c9af76b23823e967a328e06c0ce)', 'add', 'jlachka');
INSERT INTO `logs` VALUES (174, 1266676814, 'Modified user mitaka79', 'modify', 'lanselot');

-- --------------------------------------------------------

-- 
-- Структура на таблица `messages`
-- 

CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0',
  `added` int(10) DEFAULT NULL,
  `subject` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `msg` text COLLATE latin1_general_ci,
  `readed` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `receiver` (`receiver`),
  KEY `sender` (`sender`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=31 ;

-- 
-- Дъмп (схема) на данните в таблицата `messages`
-- 

INSERT INTO `messages` VALUES (21, 1, 9, 1265059632, 'Welcome kar98', 'Çäðàâåé kar98,\\è äîáðå äîøúë â [b].::SKANARIA::.[/b]\\ æåëàåì òè ïðèÿòíè ìèãîâå ñúñ íàñ.', 'no');
INSERT INTO `messages` VALUES (24, 1, 11, 1265742001, 'Welcome scheepers', 'Çäðàâåé scheepers,\\è äîáðå äîøúë â [b].::SKANARIA::.[/b]\\ æåëàåì òè ïðèÿòíè ìèãîâå ñúñ íàñ.', 'yes');
INSERT INTO `messages` VALUES (23, 1, 10, 1265315310, 'Welcome scheepers', 'Çäðàâåé scheepers,\\è äîáðå äîøúë â [b].::SKANARIA::.[/b]\\ æåëàåì òè ïðèÿòíè ìèãîâå ñúñ íàñ.', 'yes');
INSERT INTO `messages` VALUES (25, 1, 12, 1265744552, 'Welcome jlachka', 'Çäðàâåé jlachka,\\è äîáðå äîøúë â [b].::SKANARIA::.[/b]\\ æåëàåì òè ïðèÿòíè ìèãîâå ñúñ íàñ.', 'no');
INSERT INTO `messages` VALUES (26, 1, 13, 1265828287, 'Welcome tishoyyy', 'Çäðàâåé tishoyyy,\\è äîáðå äîøúë â [b].::SKANARIA::.[/b]\\ æåëàåì òè ïðèÿòíè ìèãîâå ñúñ íàñ.', 'no');
INSERT INTO `messages` VALUES (29, 1, 14, 1266676660, 'Welcome mitaka79', 'Çäðàâåé mitaka79,è äîáðå äîøúë â [b]SKANARIA[/b] æåëàåì òè ïðèÿòíè ìèãîâå ñúñ íàñ.', 'yes');

-- --------------------------------------------------------

-- 
-- Структура на таблица `namemap`
-- 

CREATE TABLE `namemap` (
  `info_hash` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `filename` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `url` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `info` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `data` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `size` bigint(20) NOT NULL DEFAULT '0',
  `comment` text COLLATE latin1_general_ci,
  `category` int(10) unsigned NOT NULL DEFAULT '6',
  `external` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `announce_url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `uploader` int(10) NOT NULL DEFAULT '1',
  `lastupdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `anonymous` enum('true','false') COLLATE latin1_general_ci NOT NULL DEFAULT 'false',
  `lastsuccess` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `recommended` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `recomm_pic_url` text COLLATE latin1_general_ci,
  `free` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `bgaudio` enum('true','false') COLLATE latin1_general_ci NOT NULL DEFAULT 'false',
  `sub_url` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `imdb_url` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `youtube_video` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `bronze` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `image` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seedbox` enum('yes','no') COLLATE latin1_general_ci DEFAULT 'no',
  `gamerzhut_url` text COLLATE latin1_general_ci,
  `bgsub` enum('true','false') COLLATE latin1_general_ci NOT NULL DEFAULT 'false',
  `subs_sab` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `screen` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`info_hash`),
  KEY `filename` (`filename`),
  KEY `category` (`category`),
  KEY `uploader` (`uploader`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `namemap`
-- 

INSERT INTO `namemap` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 'Zombieland / Caiyoa ia ciiaeoaoa (2009)', 'torrents/f3b91cb3bd38b87c05422d03f49ddc2b99a581ca.btf', '', '2009-11-07 18:53:52', 742401933, '[i][size=3][b][color=#0099CC]Caiyoa ia ciiaeoaoa[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] O?ane, Eiiaaey\r\n[*] [color=#0099CC]?a?enui?:[/color] ?oaai Oea?u?\r\n[*] [color=#0099CC]A ?ieeoa:[/color] A?ane Aecaiau?a, Oae Oa?aenui, Aia Noioi, Aaeaaee A?aneei, Aee Iu?e e a?.\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color] 84 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] Ca naaa iyia\r\n\r\n[*] [color=#0099CC]?aeoeia a IMDB:[/color] 8.2/10, 23,882 aeana\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nAaia oioaeia ia?iaey ia oeeieoa ca ciiaeoa a noee \\"Iiuoa ia ?eaeoa iu?oae\\", eiyoi i?ineaayaa enoi?eyoa ia Eueuiaun (A?ane Aecaiau?a \\"Naeioi\\" ) e Oaeaoane (Oae Oa?aenui \\"Naaai aooe\\" ). Eueuiaun eia iaaeea oye ?eaio aa ayaa, io oiaa eiaoi ai ieaoe. Io a?oaa no?aia Oaeaoane iyia IEEAEAE no?aoiaa, a ai?e e aa eia, ii nei?i ae ae ia?eoae io eieeioi aa ei na ioaaaa! A aaei nayo caaeaayi io ciiaeoa, oace aaaiaoa na eaaaeieoa ioaeyaaue, ii naaa a aioei a?aiaoi, a eiaoi oa ua o?yaaa aa na eci?aayo i?aa iae-aieyiioi i?aaecaeeaoaenoai - aa ayaao/iuooaao CAAAII![/i]', 15, 'no', '', 2, '0000-00-00 00:00:00', 'false', '0000-00-00 00:00:00', 'yes', 'http://torrent51.com/bitbucket/p_80138.jpg', 'no', 'true', 'http://subs.unacs.bg/get.php?id=54424', 'http://www.imdb.com/title/tt0279600/', 'http://www.youtube.com/watch?v=M-cIjPOJdFM', 'yes', 'http://torrent51.com/bitbucket/p_80138.jpg', 'no', NULL, 'false', NULL, '');
INSERT INTO `namemap` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 'The Hangover / Iineaaieyo a?aainee caiie (2009)', 'torrents/04f361e39549edd0ed1a15307318372a6eb8f437.btf', '', '2009-11-09 17:34:52', 740729553, '[i][size=3][b][color=#0099CC]The Hangover / Iineaaieyo a?aainee caiie[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] Eiiaaey\r\n[*] [color=#0099CC]?a?enui?:[/color]  Oia Oeeein\r\n[*] [color=#0099CC]A ?ieeoa:[/color] A?aaee Eoiu?, A?unoei Aa?oa, Oaau? A?aui, A?ao?e Oaiai?, Iaee Oaenui, ?ae?ue Oa?en, Cae Aaeeoaiaeen, Aa Oaein e a?oae\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color]96 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n\r\n[*] [color=#0099CC]?aeoeia a IMDB:[/color] 8.1/10, 75,711 aeana\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nAaa aie i?aae naaoaaoa ne, Aua e o?eia iaaiae i?eyoaee caieiaaao ca Aaaan, ca aa ioi?acioaao a?aaineioi io ia?oe.\r\n\r\nIa noo?eioa neaa eoiiia oaoa?eoa iyiao ieeaeua niiiai io i?aaeoiaoa aa?a?.\r\n\r\nIaciaeii caui a aaiyoa ia aia?oaiaioa, a eieoi na ionaaiaee iaie?ao oeau?, a a eeea?a oanoiana?ii aaaa. Oiaa, eiaoi ia iiaao aa ioe?eyo a …Aua.\r\n\r\nO?eioi o?yaaa aa na ni?aae n oa?ea caaa?a aac aa eiao ieeaeaa eaay eaeai noaaa.\r\n\r\nOa ?aciieaaao n o?anii iaeei a?aia, a eiaoi aa na iieoao aa ne niiiiyo eaeai na a neo?eei, aa iii?aayo iauaoa e aa au?iao Aua a Ae Ae iaa?aia ca oa?aiiieyoa.[/i]', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt1119646/', 'http://www.youtube.com/watch?v=XB0pGnzsAZI', 'yes', 'http://www.iwatchstuff.com/2009/04/24/hangover-poster.jpg', 'no', NULL, 'false', NULL, '');
INSERT INTO `namemap` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 'Spread / I?ioaney ?eaiei (2009)', 'torrents/a221070d430c2004dce2309b6a14096be62be8ab.btf', '', '2009-11-09 18:11:36', 741919815, '[i][size=3][b][color=#0099CC]Spread / I?ioaney ?eaiei[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] Eiiaaey\r\n[*] [color=#0099CC]?a?enui?:[/color] Aaeaea Iaeaice\r\n[*] [color=#0099CC]A ?ieeoa:[/color]  Aooui Eu?u?, Ai Oa?e, Ia?aa?eoa Eaaeaaa, Naaanoeai Noai, Niiy ?ieoae, Ia?ey Eii?eoa Aeiini e a?oae\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color]98 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] Io eeiea iia iinoa?a\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nI?IOANE? ?EAIEI ?aceacaa enoi?eyoa ia ecia?aiey ?aiea? Ieee (Aooui Euo?u?), eieoi oniyaa aa na aiaa?a ai naaoa ia i?eaeeaae?iaaieoa aeaaiaa?aiea ia iii?anoaioi ne aaaio??e. Oie ie ?ace?eaa oaeieoa ne, aieaoi aaaa ia?oeoa e i?anieaa n aanaoee ?aie e a nuuioi a?aia ?eaaa ia oe?iea iiaa a oieeaoaneey aii ia Naiaioa (Ai Oa?e), aaaieaoea ia n?aaia auc?ano. Ane?ei au?ae aia?a, aieaoi aaei aai Ieee n?aua e?aneaaoa na?aeoui?ea Oaau? (Ia?aa?eoa Eaaeaaa), eiyoi, aac oie aa iiaice?a, ea?aa nuuaoa ea?a. Ia?ao aaaiaoa na caii?aa naiaia?acia iaai?aaa?a, eiyoi ae ioaa?aa a eoenicie ?anoi?aioe e ia eceneaie eoiiie, aieaoi enoeiaoa ca ?eaioa ei ae i?eio?aaaa aa ecae?ao ia?ao e?aiaoa e ia?eoa. Aauoiiaai io oeeie eaoi Oaiiiai, Caeonea a Oeoaie e Aia?eeainee ?eaiei, I?IOANE? ?EAIEI penoaa ia?aceoa ia naenoaeai eciaiiee e iaaiaeoa ?a?oae. [/i]\r\n\r\n[img=http://store.picbg.net/pubpic/59/42/f478309c63695942.jpg]\r\n[img=http://store.picbg.net/pubpic/16/2E/e7933eafde26162e.jpg]\r\n[img=http://store.picbg.net/pubpic/DE/A4/261e2c995a74dea4.jpg]', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', 'http://subs.unacs.bg/get.php?id=54079', 'http://www.imdb.com/title/tt1186370/', 'http://www.youtube.com/watch?v=_akR9vhcDHg', 'yes', 'http://91.196.126.51/posters/654531813e3dd816948624299f912f649a2f1fc4Spread.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 'Up / A iaaaoi (2009)', 'torrents/ce35e936cb98bd40c6dd81959a6b13740be7cc28.btf', '', '2009-11-09 18:51:24', 733543038, '[i][size=3][b][color=#0099CC]Up / A iaaaoi[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] Aieiaoey, I?eee??ainee\r\n[*] [color=#0099CC]?a?enui?:[/color] Ieo Aieou?\r\n[*] [color=#0099CC]A ?ieeoa:[/color]  Aa Aniu?, E?enoiou? Ieuiu?, A?ii ?acaiaa?aa?, Aae?ie Eeiai, A?i?aai Iaaae e a?oae\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color]96 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nA iiaey oeei ia Aenie e Ieena? “A iaaaoi” n ii?aaeoa io caaaaie i?eee??aiey 78-aiaeoieyo i?iaaaa? ia aaeiie Ea?e O?aa?eenai, eieoi iae-iae?ay oniyaa aa inuuanoae ia?oaoa ia ?eaioa ne ca aaeeei i?eee??aiea eaoi caau?caa oeeyae aaeiie ca euuaoa ne e ioeeoa n iay eui aeaaoa a?oiaea ia ??ia Aia?eea. Ii oie oau?aa eunii ioe?eaae, ?a iaaiaey iae-aieyi eioia? oaeii na a i?iiueiae ia iuoaoanoaeaoi: i?eeaeaii iioeienoe?ai 8-aiaeoai Ecneaaiaaoae ia aeaaoa i?e?iaa ia eia ?unae. Io iiieie?aiey ca Inea? ?a?enui? Ieo Aieou? („Oaeanuie” IIA), „A iaaaoi” ia Aenie e Ieena? ae eaie ia enoeinee niaoii i?eee??aiea a aaei caaaaai nayo, a eiiiaieyoa ia iae-iaaa?iyoiey oaiaai ia naaoa.[/i]\r\n\r\n[img=http://store.picbg.net/pubpic/37/1F/d44bd95a2cad371f.jpg]\r\n[img=http://store.picbg.net/pubpic/BB/9E/9a1e008c7747bb9e.jpg]\r\n[img=http://store.picbg.net/pubpic/37/21/103a4376aba23721.jpg]', 13, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt1049413/', '', 'yes', 'http://91.196.126.51/posters/d8a04f2ae443ee30176d0a87ae8c4094caaeaf5cUp.jpg', 'no', NULL, 'false', NULL, '');
INSERT INTO `namemap` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 'Need for Speed: Shift (RELOADED)', 'torrents/75578586eaa46319ed10e6d1b6609ecc2ff7e0da.btf', '', '2009-11-09 22:31:22', 5810782208, '[color=blue]##[/color] [color=red][size=2][b]I?iecaiaeoae[/b][/color][/size] : [b]Electronic Arts[/b]\r\n[color=blue]##[/color] [color=red][size=2][b]Naeo ia i?iecaiaeoaey[/b][/color][/size] : [b][url=http://www.ea.com/]I?iecaiaeoae[/url][/b]\r\n[color=blue]##[/color] [color=red][size=2][b]Nieiee io ea?aoa[/b][/color][/size] : [b][url=http://www.gamespot.com/pc/driving/needforspeedshift/images.html]Nieiee[/url][/b]\r\n[color=blue]##[/color] [color=red][size=2][b]Eiiaioa?[/b][/color][/size] : [b]Aaia io iae-ecaanoieoa nunoacaoaeie ea?e ioiiai na caa?uua oace anai n Need for Speed SHIFT. Caaeaaeaoi ioaa?aa ii?aaeoaoa a iiaa iiniea, iinoaayeee aeoaioa ia oieeiaa au?oo naieoa aaoiiiaeee, eieeioi au?oo onauaiaoi, ?a ea?a?eoa oioe?ao nunoacaoaeie aaoiiiaeee io iae-aenie eean. Ca iueiioi iioaiyia a ?eouia ia aenieinei?inoieoa nunoacaiey, a eieoi ieeio e aaoiiiaee na aeiaae ia naioeiao?e io iiaaaaoa e ia ieeeiao?e io eaoano?ioaoa, ?ac?aaio?eoeoa eciiecaao ?acee?ie aeaiaioe. Aaci?aoaaaioii aaoaeeiioi iiaaee?aia ia eoiaoi e eioa?ei?a, oaiaoieoa nei?inoe e ?aaie?oeiiiaoa aecoaeecaoey ia naaoeeiie aoaeoe, ii?a?aiey e onauaiaoi ca onei?aiea aoeaaeii i?aaee??aao aaia nei?ino iaai?a ieaioi ia Need for Speed ec?eayaaiaoi.\r\nTrue Driver’s Experience – ?aciiia?acea io aecoaeie aeaiaioe, eieoi i?aayo aaoaoi nunoacaoaeii onauaia ii-aaoaioe?ii io anyeiaa: o?eecia?ai aenieae, neioee?au aae?aieaoi ia aeaaaoa ia naieyo ieeio, aoaeoe a neaanoaea ia onei?aiea, oaio?iaa?ie neee e eia?oey, eaeoi e ecoyei iia iiaae ia oi?aaeaiea, aace?ai ia ainoiaa?ai oece?ai iiaae. Iiaia?aii AI –  ii-iai?aaiaoe e aueioaaue nunoacaiey, a eieoi aaoeoa eiii?ou?ii oi?aaeyaaie nuia?ieoe ua i?iiaiyo iiaaaaieaoi ne a caaeneiino io aaoeyo noee ia oioe?aia, aa?aneaiinooa e oyeinoiioi ae ea?aia, nucaaaaeee aeiaie?ii ieai ia o?oaiino, nuia?acaii n eiaeaeaoaeiinooa ia ea?a?eoa.\r\nDynamic Crash – ecoyei iiaa nenoaia, eiyoi eciiecaa iueiaoa iiu ia iineaaiioi iieieaiea oa?aoa?, ca aa i?anucaaaa iae-?aaeenoe?iioi onauaia ca eaoano?ioe, eiaoi noa ae?aaee ai iiiaioa a ii?aaeoaoa. Aaaiooaeieoa naeunuoe n a?oae nunoacaoaee eee iaaeoe ia naii ua ae ecaaayo ca e?aoei io nunoacaieaoi, ii e ua ae inoaayo iau?eaie e a?aiaiii aaci?eaioe?aie.\r\nIueia ia?niiaeecaoey – Need for Speed SHIFT aaaa ia ea?a?eoa aucii?iino aa iiaeoeoe?ao ii?oe anaee aniaeo aeceyoa, i?iecaiaeoaeiinooa, iano?ieeeoa e ai?e eioa?ei?a, i?aa?uuaeee aiceeioi a io?a?aiea ia naiyoa ee?iino e nunoacaoaeai oun.\r\nOioi?aaeenoe?ie aaoiiiaeee e o?anaoa –  aeeci 70 eeoaice?aie nunoacaoaeie aaoiiiaeea eaoi Pagani Zonda F, Audi RS4, Porsche 911 GT3 RSR e a?oae. Ianeaaaoa na ia oace ecoieoaeie oai?aiey ia nua?aiaiiioi aaoiiiaeeino?iaia e ei?aia?ai aaiee ia 15 ?aaeie eieaoee ii oaeey nayo eaoi Willow Springs e Laguna Seca, eaeoi e ia „ecieneaie” o?anaoa eaoi oaiou?a ia London eee Tokyo.[/b]\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Eceneaaiey[/b][/color][/size] :\r\nIia?aoeiiia nenoaia: Windows XP (SP3) / Vista (SP2) / Windows 7\r\nI?ioani?: Intel Core 2 Duo 1.6 GHz / AMD X2 3800+\r\nAeaai: 256 MB, with support for Pixel Shader 3.0 (ATI Radeon X1800 XT 512MB / NVIDIA GeForce 7800 GT 256MB)\r\n?AI: 1 GB (XP) / 1.5 GB (Vista / Windows 7)\r\nDVD ROM: DVD Drive[/b]\r\nNaiaiaii aeneiai i?ino?ainoai: 6 GB\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Einoaeaoey[/b][/color][/size] : \r\n[b]1. Ecia?e ia aene eee iaoioie n Daemon Tools.\r\n2. Einoaee?ae ea?aoa.\r\n3. Eiaaoi ae iienea na?eai iiia? eciiecaaeoa rld-nfss.exe, iaie?au na a iaiea Crack ia DVD-oi eee iyeie io neaaieoa iiia?a:\r\nH3WN-JJ9J-HCTG-BHC7-PRLD\r\nA933-X3T6-VNNZ-TVN2-8RLD\r\nAXSA-KP28-EE39-2EEY-FRLD\r\n96BK-4AJL-GLWR-ZGLA-YRLD\r\n\r\n4. Eiie?aeoa nuau??aieaoi ia iaiea Crack, iaie?aua na ia DVD-oi, a einoaeaoeiiiaoa ae?aeoi?ey ia ea?aoa.\r\n5. Ea?aeoa![/b]', 18, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'yes', 'http://upload-file.org/slike/200992159395019350.jpg', 'no', 'http://gamerzhut.com/games/video2.php?id=17170&t=low&gid=2782', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 'Inna - Hot (2009)', 'torrents/5190ad7b9c450543de602448d028cf5e99442dc1.btf', '', '2009-11-09 23:09:46', 176543378, '[color=#96C100]##[/color] [color=#C13A00][size=2][b]Eciueieoae/e[/b][/size][/color] : [b]Inna[/b]\r\n[color=#96C100]##[/color] [color=#C13A00][size=2][b]Aeaoi[/b][/size][/color] : [b]Hot[/b]\r\n[color=#96C100]##[/color] [color=#C13A00][size=2][b]Aiaeia[/b][/size][/color] : [b]2009[/b]\r\n[color=#96C100]##[/color] [color=#C13A00][size=2][b]A?aiao?aaia[/b][/size][/color] : [b] 44:23 ieiooe [/b]\r\n[color=#96C100]##[/color] [color=#C13A00][size=2][b]Aeo?aeo[/b][/size][/color] : [b] 320 kbps / 44100Hz /  Joint Stereo  [/b]\r\n[color=#96C100]##[/color] [color=#C13A00][size=2][b]O?aeeeno[/b][/size][/color]\r\n[b]01. Hot (03:41)\r\n02. Love (03:40)\r\n03. Days nights (03:42)\r\n04. Fever  (03:25)\r\n05. Left right (04:36)\r\n06. Amazing  (03:29)\r\n07. Don\\''t let the music die (03:48)\r\n08. On & on (04:38)\r\n09. Ladies (05:12)\r\n10. Deja vu (feat. Bob Taylor) (04:25)\r\n11. On & on (Chillout mix) (04:00)[/b]', 23, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'yes', 'http://www.covershut.com/covers/Inna---Hot-2009-Russia-Front-Cover-14281.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 'Law Abiding Citizen / Niu?oiiinai i?ioeaiee (2009)', 'torrents/bffe4c428730472db60ffe600d1c281c10a08a0b.btf', '', '2009-11-09 23:50:26', 749257358, '[color=red]##[/color] [color=blue][size=2][b]?ai?[/b][/size][/color] : [b]A?aia, O?eeu?[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]?a?enui?[/b][/size][/color] : [b]O. Aa?e A?ae[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]A ?ieeoa[/b][/size][/color] : [b]A?aeie Oien, A?a?a?a Auoeu?, E?enoei Noie, Iaeeue Aaiaui, Iaeeue U?ae, Aeiea Aaeaen, Eiei Ieeie, A?on Iaeaee, Eanee Aea, ?aa?eia Oie e a?oae[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]Au??aaa[/b][/size][/color] : [b]NAU[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]Aiaeia[/b][/size][/color] : [b]2009[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]A?aiao?aaia[/b][/size][/color] : [b]108 ieiooe[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]Noaoeo?e[/b][/size][/color] : [b]Io eeiea iia iinoa?a[/b]\r\n\r\n[color=red]##[/color] [color=blue][size=2][b]?ac?ia [/b][/size][/color] : [b]Euuaoa ia iaeeiiaaii aia?eeainei naiaenoai a ia?aia iin?aa aye aai! Nui?oaaoa e auua?yoa na a?ooaeii oaeoe i?e iae?a! Aauaoa Eeaea Oaeoui (A?a?a?a Auoeu?) ioaeyaa!\r\nIa neaa aueai oaeeoeoa na caeiaaie e n?auo oyo a caaaaaii aaei, i?ieo?i? a Iee ?aen (iineoaeyo ia \\"Inea?\\" A?aeie Oien). Oaouo ia ?aen ai i?eio?aaaa aa i?aaei?e ia aaei io aaaiaoa caiiaic?aie eaea i?enuaa a caiyia ia iaaiaeoa iieacaiey n?auo nuo?anoieea io!\r\nAiaeie ii-eunii nianeeeyo na i?anouiiee a iaia?ai iu?oua e Eeaea i?eciaaa aeiaoa ne, nei?i neaa oiaa ioi?aay e naiyoa caeaia eui i?ieo?i? ?aen, aa iii?aae ceeiaoa eiyoi a noi?ee eee aa iin?auia niu?ooa ia ee??iae oeao?e io ianoiyuey io i?ioan!\r\nIa neaa aueai Oaeoui oniyaa aa ecayaa io caoai?a, n eiaoi a a?aaa caii?aao ii?aaeoa io ecee??eoaeii a?ooaeie oaeenoaa, eieoi ia iiaao ieoi aa auaao i?iaiice?aie ieoi i?aaioa?aoaie! A?aauo na iioaiy a no?ao! Oaeeoa io nienuea ia Oaeoui iaaao aaia neaa a?oaa! Aeanoeoa na aacneeie aa ni?ao nioeiiaoa e oa?oaaiaoi ia oa?i?a io! Ia oia a i?ieo?i?uo ?aen....[/b]\r\n', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', 'http://subs.unacs.bg/get.php?id=54524', 'http://www.imdb.com/title/tt1197624/', 'http://www.youtube.com/watch?v=FMoP35u8oN0', 'yes', 'http://www.iwatchstuff.com/2009/08/20/law-abiding-citizen-poster.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 'Aliens in the Attic / I?eoueoe ia oaaaia (2009)', 'torrents/f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042.btf', '', '2009-11-10 11:26:04', 734568658, '[i][size=3][b][color=#0099CC]Aliens in the Attic / I?eoueoe ia oaaaia[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] I?eee??ainee, Naiaai, Oaioanoeea\r\n[*] [color=#0099CC]?a?enui?:[/color] A?ii Ooeo \r\n[*] [color=#0099CC]A ?ieeoa:[/color]  Aoee Oecaaee, ?iau?o Oioiai, Eaaei Ieeui, Ai?en ?iau?on, Inoei ?iau?o Auoeu? e a?oae\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color]86 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nAne?ei caii?aa n iaoai?eoai au?a ian?aa aaeaeoeeaoa, io eieoi iaaeaeia neea cai?aua aieyia ?ano caaaii n 4 ece?yue oiiee eui ieaiaoaoa Caiy! Ii nuuioi a?aia Naiaenoai Ieu?nuin io Ie?eaui, caaaii n o?eoa ne aaoa e i?eyoaey ia auua?y ei caieiaaao ia naiaeia ii?eaea a o?eaoa?ia euua iyeuaa a n?aaieoa uaoe. Eui oyo na i?enuaaeiyaao ?e?ioi Iaeo, neiuo io A?aee, noa?aoa ?ioc  e aeecia?eeoa A?o e Eee.\r\n\r\nI?ac iu?aaoa iiu iaoai?eoiey au?a a?uoeeoa euuaoa ia Ieu?nuin e eiiiaiey, a 4-oa ene?yue oiiee iaaao ia iie?eaa. Io ooooeeeoa ei ecnea?ao iao ecauicaiie;  ei?aaey eiiaiae? Neei, ioneoeanoey Oaecu?, ?aecu? - ?aiaoa aieiee e Nia?en aeoiiaaoey ecauicaiai. ?eee, aaa?aoi ia Aaouie Ieu?nuin a iu?aaoa ?a?oaa ia ecauicaiieoa, eieoi ai oeiiioece?ao e caii?aao aa eiio?iee?ao nuciaieaoi e aaenoaeyoa io. [/i]\r\n', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt0775552/', '', 'yes', 'http://91.196.126.51/posters/0aac193383f77b8ee7ca11d300768ea3369d755daliens.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 'Monsters Vs Aliens / ?oaiaeua n?auo ecauicaiie (2009)', 'torrents/2f76e45579f9e2311b5e230bd6d4056e2ab218a3.btf', '', '2009-11-10 12:53:35', 743992876, '[i][size=3][b][color=#0099CC]Monsters vs Aliens / ?oaiaeua n?auo ecauicaiie[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] Aieiaoey\r\n[*] [color=#0099CC]?a?enui?:[/color] ?ia Eaou?iai, Eii?aa Au?iui\r\n[*] [color=#0099CC]A ?ieeoa:[/color] Nao ?ia?ui, O? Ei?e, ?eec Oeau?nioi, Iie ?ua e a?oae\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color]94 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nEiaaoi ecauicaiia oeaeeecaoey iaiaaa Caiyoa, i?aaeoaenoaioi ia NAU aceia o?oaiioi ?aoaiea aa ecaeea ia iiiiu iae-iaoeie?ieoa caueoieoe, eieoi enoi?eyoa iiciaaa.\r\nIa o?iioiaaoa eeiey eceeca eiie?ia a?oia ?oaiaeua, eiyoi eia ca caaa?a aa niane ?iaaoeaoa ?ana. “?oaiaeua n?auo Ecauicaiie” nu?aoaaa iinoaeaeyoa ii aoi?ieeanieoa oaioanoe?ie oeeie n oaoiieiaeeoa ia auaauaoi, ca aa nucaaaa aaii oieeaeii 3D i?eee??aiea ca oyeioi naiaenoai!\r\nIiaaoa aieiaoeiiia eiiaaey io nucaaoaeeoa ia “O?ae” e “Iaaaaanea?” o?uaaa a noaiaa?oieoa e 3D eeiinaeiie ia 27 ia?o![/i]\r\n\r\n[img=http://upload-file.org/images/883162snapshot20090905011113.png]\r\n[img=http://upload-file.org/images/250189snapshot20090905011108.png]', 13, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt0892782', 'http://www.youtube.com/watch?v=7SfqWGmRffM', 'yes', 'http://i40.tinypic.com/2lyk2u.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 'Heroes / Aa?ie S04E09', 'torrents/4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6.btf', '', '2009-11-10 19:12:25', 366727168, '[i][size=3][b][color=#0099CC]Heroes / Aa?ie[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] A?aia, Oaioanoeea\r\n[*] [color=#0099CC]?a?enui?:[/color] Oei E?eia\r\n[*] [color=#0099CC]A ?ieeoa:[/color] A?ae Eieiui, Oaeaui Iaiaoea?, Naiaee ?aiaio?oe, Iaeei Aaioeieey, Iane Iea,A?aein Eaenii Ee, Aea?eui Ianaa?, A?aa A?uiau?a, Aee Ea?ou?, Caea?e Eoeioi e a?. \r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color] 42 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] Io eeiea iia iinoa?a\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\n\\"Aa?ie\\" a na?eae a eieoi na ?aceacaa eae iaeeiiaaie oi?a ii oaeey nayo ioe?eaao, ?a eiao na?uoanoanoaaie niiniaiinoe e eae oace i?iiaie iiaeeyaao ia ?eaioa ei. Oa ia naii ?acae?ao eaeai icia?aaa aa eiao noia?neee, ii e ioe?eaao caui oiaa na neo?aa n oyo. Iinoaiaiii oa na nuae?ao caaaii, ayaaeee io aioeaa?iy, eieoi enea aa iieo?e oyoiaoa noia? AIE. Nuaaaoa ei, a aa nianyo naaoa...[/i]', 14, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt0813715/', '', 'yes', 'http://thetvaddict.com/wp-content/uploads/2009/08/hereos_season4_poster.jpg', 'no', '', 'false', 'http://subs.sab.bz/index.php?act=download&attach_id=39887', '');
INSERT INTO `namemap` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 'Gossip Girl / Ei?eaaioeaoa S03E09', 'torrents/2dff62bc5666f4437bf04139f9f8fb49f5e898b8.btf', '', '2009-11-10 19:36:33', 367213092, '[i][size=3][b][color=#0099CC]Gossip Girl / Eio?eaaioeaoa[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] Eiiaaey, A?aia, ?iiaioe?ai\r\n[*] [color=#0099CC]?a?enui?:[/color] A?io Ooi?on, Noaoaie Naaea?\r\n[*] [color=#0099CC]A ?ieeoa:[/color]  E?enoui Aae, Aeaee Eaeaee, Eaeoui Ieenou?, ?aen E?iooi?a, Oaeeu? Iiinai \r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color] 42 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] Io eeiea iia iinoa?a\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nIeeie ia ciaa naiiee?iinooa ia Ee?ea?eaoa, ii ane?ee a oice ecee??eoaeai e nei?ai ii?i?ai e?ua ?ac?eoao ia iaeiey oaanaeo e oaenoiae nuiauaiey ca iineaaieoa neaiaaeie iiaeie. Ai?e iae-aeeceaoa i?eyoaeea ia Ne?eia - Aeau? Oieai?o, n eciaiaaa ?acae?a, ?a Ne?eia aiacaiii a i?ae?aoeea naiaoi aia?iaieii caoi?aiea a iaineii a Euiaeoeeuo e na a au?iaea a Iaioaoui. Ia a eanii aa i?ineaaeo i?eyoaenoaaoa, eiioeeeoeoa e aueiaieyoa a oice aiaao e nei?ai nayo, ii oueii oai Ee?ea?eaoa a a noeoeyoa ne. Iaeiaoa a?aciaua, ii ia?aeeaoa oeeinioey a: \\"Oe ne ieeie, i?aae aa caii?iao aa aiai?yo ca oaa. Oe ia iae?ao\\", ieoa oaeinoaaiaoa iaieioeaoi?ea.[/i]', 14, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt0397442/', '', 'yes', 'http://91.196.126.51/posters/b6d559394e1ab3ef6e362eb4a688962b4f88164dGossip_Girl_S03E01_HDTV_XviD-NoTV.jpg', 'no', '', 'false', 'http://subs.sab.bz/index.php?s=2bec87c5e8151a3157c072d31aa16d8a&act=download&attach_id=39920', '');
INSERT INTO `namemap` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 'Jennifer''s Body / Oyeioi ia A?aieou? (2009)', 'torrents/97b0ff538f9825cb8204de523b22e2bb88aff493.btf', '', '2009-11-10 19:47:30', 1520464072, '[i][size=3][b][color=#0099CC]Jennifer\\''s Body / Oyeioi ia A?aieou?[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] O?eeu?, O?ane, Eiiaaey\r\n[*] [color=#0099CC]?a?enui?:[/color] Ea?ei Eonaia\r\n[*] [color=#0099CC]A ?ieeoa:[/color] Iaaui Oien, Aiaiaa Neeo?ea, A?iie Neiuin, Aaai A?ioae, E?en I?ao, Aeenui A?aie e a?.\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2009\r\n[*] [color=#0099CC]A?aiao?aaia:[/color] 98 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n\r\n[*] [color=#0099CC]?aeoeia a IMDB:[/color] 5.6/10, 5,924 aeana\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nA?aieou? (Iaaui Oien) a aeiiacenoea iaeaaaia io cue aaiii a iaeei i?iaeioeaeii a?aa?a.\r\nOy ?eaaa aaieinoaai ?eaio. Io aaia no?aia a CEIOI ia o?eeeuaoi. Ecee??eoaeii e?aneaa, oa?anaaia io ane?ee, ai?aaeeaa e i?aacaoa, a io a?oaa no?aia a CEI-CEI!\r\nIo ene?yua e?anaaeoa oy au?ci i?aieiaaa a aieii nuuanoai, eiaoi na o?aie n ieuo! Naaa iii?aoaoa eieoi oaea e ia na eiaee oain n aacnu?aa?iaoa iaoea A?aieou?, aa?a EIAO oain n iiaioi e aiieia aa na i?aau?iao a... o?aia!\r\nIa oiia ia ane?ei oiaa, iae-aia?aoa e i?eyoaeea, eiyoi oye ?eaio a ?eayea a nyieaoa ia e?anaaeoaoa A?aieou? na caaia aa niane ieaaeoa iu?a a a?aaa, eaeoi e nianoaaiey ne i?eyoae ?ei![/i]\r\n\r\n[img=http://welcome.to.images213.pic-bg.net/images2/store/2dr6zgj_PNG5v0ZnPHrAD.png]\r\n[img=http://store.picbg.net/pubpic/04/73/8872e75940f60473.jpg]\r\n[img=http://welcome.to.images213.pic-bg.net/images2/store/or5ohl_PNGWQw369hjHj.png]', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt1131734/', '', 'yes', 'http://torrent51.com/bitbucket/Jennifers.Body.r5-imagine.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 'The Curious Case of Benjamin Button / No?aiieyo neo?ae n Aaia?aiei Auoui (2008)', 'torrents/d728b5a0948af20af1842580dd527902e9ef7c9c.btf', '', '2009-11-10 20:00:23', 1472350179, '[i][size=3][b][color=#0099CC]The Curious Case of Benjamin Button / No?aiieyo neo?ae n Aaia?aiei Auoui[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] A?aia, ?iiaioe?ai, Ienoa?ey\r\n[*] [color=#0099CC]?a?enui?:[/color] Aaeaea Oei?u?\r\n[*] [color=#0099CC]A ?ieeoa:[/color] A?aa Ieo, Eaeo Aeaioao, A?aenui Oeaieia, Oeeaa Noeioui, Aeean Eioaan\r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2008\r\n[*] [color=#0099CC]A?aiao?aaia:[/color] 163 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nOeeiuo “No?aiieyo neo?ae n Aaia?aiei Auoui” a aaaioe?ai ca aieaiey ae?ai ii ?aceaca ia O?ainen Neio Oeoa?a?aea. N??aouo na au?oe ieiei enoi?eyoa ia aaoa, eiaoi ii iaiaynieie i?e?eie na ?a?aa a oyei ia noa?ao. Aianoi aa inoa?yaa n oa?aiea ia a?aiaoi, oie na iiaieaayaa. Ca iyeie oiaa ae i?aanoaaeyaaei aacia?ii uanoea, ii ca Aaia?aiei Auoui a ?ieyoa (A?aa Ieo) na ieacaa enoeinei i?ieeyoea! Ia 50-aiaeoia auc?ano oie na ae?aaa a 30-aiaeoia ?aia ia eia Aaece a ?ieyoa (Eaeo Aeaioao), naeuneaaeee na n iaaucii?iinooa ia e?aia ia?ao aaaia aooe, eieoi iyia aa iiaao aa inoa?ayo caaaii. Iineaaeoeoa io no?aiiaoa ?iiaioe?ia aoa?a, eiyoi caii?aao ae?aaieoa, na niouaaaue e iaia?aoeie..[/i]\r\n\r\n[img=http://i39.tinypic.com/2hsb3ls.jpg]\r\n[img=http://i39.tinypic.com/bfrsh.jpg]', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt0421715/', '', 'yes', 'http://images.moviecollector.net/large/bb/bb_d__0_TheCuriousCaseOfBenjaminButton.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 'District 9 / Naeoi? 9 (2009)', 'torrents/e33c4b8b33ebba92f5ff42bddbc680bc145f8155.btf', '', '2009-11-10 20:24:46', 1474517480, '[i][size=3][b][color=#0099CC]District 9 / Naeoi? 9[/color][/b][/size]\r\n\r\n[*] [color=#0099CC]?ai?:[/color] A?aia, Aeoui, Oaioanoeoa, O?eeu?\r\n[*] [color=#0099CC]?a?enui?:[/color] Ieee Aeiieaii\r\n[*] [color=#0099CC]A ?ieeoa:[/color] Oa?eoi Eiiee, Oeeyi Aeai ?ia, A?aenui Eioi, Aaeaea A?aein, ?iau?o Oian, Aaiana Oaeooa \r\n[*] [color=#0099CC]Au??aaa:[/color] NAU\r\n[*] [color=#0099CC]Aiaeia:[/color] 2008\r\n[*] [color=#0099CC]A?aiao?aaia:[/color] 108 ieiooe\r\n[*] [color=#0099CC]Noaoeo?e:[/color] A oi?aioa\r\n[*] [color=#0099CC]Ea?anoai:[/color] [color=red]R5[/color]\r\n\r\n[color=#0099CC]?ac?ia:[/color] \r\nI?aae iiaa?a io aaaenao aiaeie ecauicaiieoa inuuanoaeoa iu?ae eiioaeo nun Caiyoa. ?iaaoeaoa ?ana i?aeaaoa a?a?anei iaiaaaiea eee iaaa?iyoai oaoiieiae?ai iai?aaue. Ieoi aaiioi ia na neo?e. Ecauicaiieoa na ieacaoa aa?aioe io naiy nayo. E aieaoi naaoiaieoa neee ?aoaaaoa eaeai aa i?aayo n oyo, nucaaieyoa ayoa ianoaiaie a?aieiii a eaaa? ai Eioaianao?a, ia?a?ai \\"Naeoi? 9\\".\r\n\r\nAian ou?iaieaoi ia ane?ee aa?a a ec?a?iaii. Eiio?ieuo au?oo ecauicaiieoa a iiao io ?anoiaoa ei?ii?aoey \\"Ioeoe Iaouiue ?iaeoaa\\" (II?), eiyoi ia a iiiai caa?e?aia ca aeaaiiieo?eaoi ei. II? ua ?aaeece?a ia?iiie ia?aeae, aei oniaa aa iaea?a iiuieoa i?u?ey ia i?eoueoeoa aa i?i?aaioyo. Ii ainaaa iyia oniao - aeoeaaoeyoa ei eceneaa ecauicaiia AIE.\r\n\r\nIai?a?aieaoi ia?ao ecauicaiie e oi?a aneaee?a, eiaaoi II? caii?aa aa ecnaeaa i?eoueoeoa io \\"Naeoi? 9\\", ca aa ae ianoaie a iiai iynoi, iiaic?eoaeii i?eee?aui ia eiioaio?aoeiiai eaaa?. Aaei io aaaioeoa ia II? - Aeeun aai aa? Ia?a (Oa?eoi Eiiee) na ca?acyaa n ecauicaiai ae?on, eieoi ua ai i?iiaie... aua anaee nienue ia aoiaoa.\r\n\r\nAeeun au?ci na i?aa?uua a iae-i?aneaaaaiey e oaiai ?iaae ia naaoa - oie a ee??uo eui oaeieoa ia ecauicaiiaoa oaoiieiaey. Eciee?ai e naiioai, ca iaai eia naii aaii iynoi, euaaoi ii?a aa na ne?ea – \\"Naeoi? 9\\". [/i]', 15, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'true', '', 'http://www.imdb.com/title/tt1136608/', '', 'yes', 'http://ia.media-imdb.com/images/M/MV5BMTM4OTI1OTM5NF5BMl5BanBnXkFtZTcwMzk5MTU1Mg@@._V1._SX400_SY1400_.jpg', 'no', '', 'false', NULL, '');
INSERT INTO `namemap` VALUES ('a37afec032d8c10ee8ddeb67d9f84f3951c8ad66', 'Empire Earth II - RELOADED', 'torrents/a37afec032d8c10ee8ddeb67d9f84f3951c8ad66.btf', '', '2009-11-11 20:48:31', 1380614598, '[color=blue]##[/color] [color=red][size=2][b]I?iecaiaeoae[/b][/color][/size] : [b]Mad Doc Software[/b]\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Naeo ia i?iecaiaeoaey[/b][/color][/size] : [b][url=http://www.rockstarnewengland.com/]I?iecaiaeoae[/url][/b]\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Nieiee io ea?aoa[/b][/color][/size] : [b][url=http://www.gamespot.com/pc/strategy/empireearth2/screenindex.html]Nieiee[/url][/b]\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Eiiaioa?[/b][/color][/size] : [b]Aa ne i?eciay, oace ea?a ia inoaae n ioai?aia onoa. Ia oieeiaa n ea?anoai iaa?a - n eiee?anoai ia oaoia. Ia a eaoi aa ia nui ae?aae ea?e n iiainoe a n?aaiaiea n i?aaoanoaaieea ne - a Empire Earth II (AA2) iaa?a oa na a oaeiaa eaaeiiia?acii eciaeeea, ?a iai?aai ia ciai io euaa ca caii?ia.\r\n\r\nIua n ioneaiaoi ia ea?aoa ynii ne ee?e, ?a ?ac?aaio?eoeoa io Mad Doc ii?aaaeaii ia na niaee ceiai nui i?ac ?aoe?eoa aiaeie io eceecaiaoi ia i?eaeiaea, a ci?ei na neaaeee ?acaeoeaoi ia aaeieiaono?eyoa. Eaeoi ii?a ae ciaaoa, Rise of Nations, io?i?aoi ia Microsoft Game Studios, oioaeii ioay iu?aey EE n eiiaaoeaieoa ne ea?aeie eiioaioee - iaua eaoi a?aaiaa, noieeoe, au??aaie a?aieoe, oieeaeii au?ai n uia?aeae e oaea iaoaoue. Caoiaa ?ac?aaio?eoeoa ia EE2 yaii na ?aoeee, ?a aei iaaeuneao io?i?aoi ne n ane?ee oace aeaiaioe e aiaaayo ueiea nie io naaa ne, ua na iieo?e iaui oieeaeii. I?ioeaii ia anyeaeaa eiaeea, ia na a iieo?eea iaia?a n a?icaa, ai?e iai?ioea!\r\n\r\nA iniiaaoa noie eaayoa ia Age of Empires - o?yaaa aa i?aaaaaoa aaia eca?aia io aan oeaeeecaoey i?ac i?aia?aeyoa ia aaeiaaoa e aa y i?aau?iaoa io noaai iaeioie, ?aoeee, ?a ua a iiiai oeo?i, aei na oaeinaao ii aeaaeoa n ii-?aiaoe eeiie, aua aenieioaoiieiae?ia iaoey, eiyoi o?a?aa i?iaeaieoa ne n iaoeneaia ia ya?aie eii?aoa. Aiooe aia?a, ii uii ?aoeoa aa i?aoai?eoa ia aaei eaaeoa ne ca naaoiaia aiieiaoey, aueiaoa io iiaiauaaaaiey ni?yii i?aaeoiaoa ?ano ua ae oaa?e eaoi ia?ai ?oe.\r\n\r\nIa iu?ai iynoi, iniiaiaoa ae na?aaa (oace, io eiyoi no?ieoa ?aaioieoe) io i?ino settlement a i?a?aniaea a oye a?aa, ieiei eieoi no?ieoa inoaiaeeoa iino?ieee. Ea?oaoa iue a ?acaaeaia ia ioaaeie oa?eoi?ee n a?aieoe ia?ao oyo, eieoi eiao ii-nei?i eiciaoe?ia ooieoey. E aaaoa eaae na ae?aeoie caaiee io Rise of Nations, ii oaeaa, iiaieiaaaia, ana aaii ia nia caaaeycaee. Iiaa oa?eoi?ey na caaeaayaa eaoi ?ac?ooeoa a?a?aneey a?aa a iay e iino?ieoa naie ia iaaiai iynoi. Ca oaeoa eiaoa ieiei noioeia ?acee?ie aieie aaeieoe - io iae-?aiieoa ia?iiinoe, eiiieoe e eaoaioeoe, i?ac ?aianainiae ioneaoa?e e oiiiaa, ai na?uoiiaa?ie iiaaiaieoe, iaaeaeie aiiaa?ae?iaa?e e oiaaue 10-iao?iae ?iaioe. Eaoi aiiueiaiea anyea aaia io ?aoe?eiaaanaooa oeaeeecaoee, iaia?eee iynoi a a?eoeaoa, eiao eaeoi oa?aeoa?ie aiione, oaea e oieeaeie aieie aaeieoe, iai?eia? aie?a?eoa i?e oo?oeoa eee aaaoeieoa i?e aaeioyieoa. Ii iaecaanoie i?e?eie na ecioniaoe iyeie no?oaa ie na ainoa aa?ie iaoee eaoi o?aiooceoa e ?oniaoeoa, a na aee??aie “a?aaieoa” aia?eeaioe![/b]\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Eceneaaiey[/b][/color][/size] :\r\nIia?aoeiiia nenoaia: Windows XP\r\nI?ioani?: Pentium 4 1.5MHz or equivalent\r\nAeaai: 64 MB\r\n?AI: 256 MB\r\nDVD ROM: DVD Drive[/b]\r\nNaiaiaii aeneiai i?ino?ainoai: 1.5 GB\r\n\r\n[color=blue]##[/color] [color=red][size=2][b]Einoaeaoey[/b][/color][/size] : \r\n[b]1. Ecia?e ia aene eee iaoioie n Daemon Tools.\r\n2. Einoaee?ae ea?aoa.\r\n3. Eiaaoi ae iienea na?eai iiia? auaaaaoa iyeie io neaaieoa:\r\nRUB7-WYG4-FEN5-RAB6-3594\r\nWAG4-NEF5-XEZ9-JYB9-6892\r\nLUP6-WAJ5-PAM9-WAB7-3825\r\nTAJ6-TYW8-FEG5-GUX3-3692\r\nNEL8-ZAM6-ZYD5-GAP2-5969\r\n\r\n4. Eiie?aeoa nuau??aieaoi ia iaiea Crack, iaie?aua na ia DVD-oi, a einoaeaoeiiiaoa ae?aeoi?ey ia ea?aoa.\r\n5. Ea?aeoa![/b]', 18, 'no', '', 2, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'yes', 'http://img.zamunda.net/bitbucket/boxshotaaa_uk_large.jpg', 'no', '', 'false', '', '');
INSERT INTO `namemap` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 'Ultimate Survivàl/Îöåëÿâàíå íà ïðåäåëà-Õðàíà â ïóñòîøòà', 'torrents/83cc039dff36ba32da95a2bf0448507819dfd4cc.btf', 'fakira', '2010-01-31 17:50:36', 618513756, '[size=3][color=red]## Â ðîëèòå :[/color][/size] Áåúð Ãðèëñ\r\n\r\n[size=3][color=red]## Æàíð : [/color][/size]Íàó÷íî - ïîïóëÿðåí\r\n\r\n[size=3][color=red]## Äúðæàâà : [/color][/size]Âåëèêîáðèòàíèÿ [img]http://store.picbg.net/pubpic/56/B5/6b076587adbe56b5.gif[/img]\r\n\r\n[size=3][color=red]## Ãîäèíà :[/color][/size] 2009\r\n\r\n[size=3][color=red]## Âðåìåòðàåíå :[/color][/size] 45 ìèíóòè [img]http://store.picbg.net/pubpic/61/BA/4c53232e0f8e61ba.gif[/img]\r\n\r\n[size=3][color=red]## Ñóáòèòðè :[/color][/size]Âãðàäåíè [img]http://store.picbg.net/pubpic/54/37/2163ae30049a5437.gif[/img]\r\n\r\n[size=3][color=red]## Ðåçþìå :[/color][/size] [img]http://store.picbg.net/pubpic/50/DA/026bf2b408d450da.gif[/img]Man vs Wild ïîçíàòî îùå êàòî Born Survivor: Bear Grylls è Ultimate Survival (íà áúëãàðñêè - "Îöåëÿâàíå íà ïðåäåëà" ) å òåëåâèçèîííî øîó çà îöåëÿâàíå, ñ âîäåù Áåúð Ãðèëñ, èçëú÷âàíî ïî Discovery Channel. Â øîóòî Ãðèëñ äåìîíñòðèðà è îáÿñíÿâà ðàçëè÷íè òåõíèêè çà îöåëÿâàíå â ðàçíîîáðàçíè îáëàñòè ïî Çåìÿòà. Âñåêè åïèçîä äîêóìåíòèðà íåãîâèòå óñèëèÿ äà îöåëåå è íàìåðè ïúò îáðàòíî êúì öèâèëèçàöèÿòà, êàòî ÷åñòî ñå íàëàãà äà íàïðàâè ïîäñëîí çà ïðåç íîùòà, ñ íàëè÷íèòå ñðåäñòâà íà îáëàñòòà. Ñúùî òàêà Áåúð ðàçêàçâà çà ðàçëè÷íè óñïåøíè è ïðîâàëèëè ñå îïèòè çà îöåëÿâàíå â ðàéîíà, êúäåòî ñå íàìèðà â ìîìåíòà. Âñåêè åïèçîä îòíåìà îêîëî åäíà ñåäìèöà çà äà ñå ðàçó÷è ðåãèîíà è îñîáåíîñòèòå ìó è îùå åäíà ñåäìèöà çà çàñíåìàíåòî íà åïèçîäà. Åêèïúò, êîéòî ïðèäðóæàâà Áåúð íÿìà ïðàâîòî äà ìó ïîìàãà îñâåí â ñèòóàöèÿ íà æèâîò è ñìúðò.\r\n\r\n[img]http://store.picbg.net/pubpic/28/2C/430d7f5e0571282c.gif[/img]', 14, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', 'http://www.imdb.com/title/tt0883772/', 'http://www.youtube.com/watch?v=IFJxabPfKqY', 'yes', 'http://store.picbg.net/pubpic/3B/3B/9a30275603d23b3b.jpeg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 'uTorrent 1.8.5 Build 17414 Stable.exe', 'torrents/02c70ff4ba5991523265b4698e6f499d01f39325.btf', 'fakira', '2010-01-31 21:38:30', 289584, '[color=yellow][size=3]Utorrent å ìàëúê, ìîùåí è åôåêòèâåí BitTorrent êëèåíò çà Windows. Ïîâå÷åòî îò ôóíêöèèòå, íàëè÷íè â äðóãè òîðåíò êëèåíòè ñå íàìèðàò è â Utorrent, âêëþ÷èòåëíî ïðèîðèòåòè íà òðàôèêà, ãðàôèêà, RSS àâòîìàòè÷íîòî èçòåãëÿíå è DHT ñâúðçàíîñò. Îñâåí òîâà, Utorrent èçïîëçâà ïðîòîêîë çà êðèïòèðàíå íà äàííè è ðàçìÿíà íà ïèúðè. Çà ðàçëèêà îò ìíîãî äðóãè òîðåíò êëèåíòè , Utorrent íå ðàçõèùàâà öåííè ñèñòåìíè ðåñóðñè, îáèêíîâåíî ñå èçïîëçâàò ïî-ìàëêî îò 6 MB ïàìåò, êîåòî âè ïîçâîëÿâà äà èçïîëçâàòå êîìïþòúðà ñè íîðìàëíî áåç èç÷àêâàíèÿ èëè çàâèñâàíèÿ íà ñèñòåìàòà âè.[/size][/color]', 26, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'yes', 'http://store.picbg.net/pubpic/E5/C3/ebe862038a11e5c3.gif', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', '2012 Íàóêà èëè ñóåâåðèå / 2012 Science Or Superstition (2009)', 'torrents/0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1.btf', '', '2010-02-01 18:28:53', 729784408, '[center][size=6][color=orange]2012 - Science or Superstition [/color][/size][/center]\r\n\r\n[center][size=4][color=limegreen]2012 - Íàóêà èëè ñóåâåðèå [/color][/size][/center]\r\n\r\nÐåæèñüîð:  Gary Baddeley\r\n\r\nÂ ðîëèòå: Dr. Anthony F. Aveni,Walter Cruttenden,Graham Hancock,John Major Jenkins,Lawrence E. Joseph,Jim Marrs,Alonso Mendez,Daniel Pinchbeck è äð.\r\n\r\nÆàíð: äîêóìåíòàëåí\r\n\r\nÑòðàíà: ÑÀÙ\r\n\r\nÃîäèíà: 2009\r\n\r\nÂðåìåòðàåíå: 01:18:38\r\n\r\nÅçèê: àíãëèéñêè\r\n\r\nÑóáòèòðè: â òîðåíòà\r\n\r\nÔîðìàò: avi\r\n\r\nÃîëåìèíà: 695,98ÌÂ\r\n\r\nÂèäåî: 48000Hz 126 kb/s tot , Joint Stereo LAME3.90 , MPEG-1 Layer 3\r\n\r\n\r\n21 äåêåìâðè 2012 : Êðàÿ íà äúëãîòî ëåòîáðîåíå îò ñëîæíèÿ êàëåíäàð íà äðåâíè Ìàè îò Öåíòðàëíà Àìåðèêà. Êíèãè è óåáñàéòîâå, ñïèñàíèÿ è ÷åëíè ñòàòèè âúâ âåñòíèöè îáñúæäàò âúçìîæíîñòòà, ðàçäåëåíè íà äâà ëàãåðà: åäíèòå âèæäàò àïîêàëèïñèñ è êðàÿ íà ñâåòà, à äðóãèòå - ïîäíîâÿâàíå è âúçðàæäàíå íà ñúçíàíèåòî.\r\n\r\nÄîáàâÿéêè îùå "äúðâà â îãúíÿ", íÿêîè ó÷åíè îòêðèâàò çàâèøàâàùè ñëó÷àè íà ïðèðîäíè êàòàñòðîôè, ñìÿòàéêè òîâà çà äîêàçàòåëñòâî êúì òåîðèÿòà çà êàòàñòðîôàëíèÿ êëèìàêñ 2012 ãîäèíà. Êàêâà ÷àñò îò äåáàòà å íàóêà, è êàêâà - ñóâåðèå? Â òîçè ôèëì âîäåùè ó÷åíè, ïèñàòåëè è èçñëåäîâàòåëè â îáëàñòòà ùå íè ðàçÿñíÿò êàêâî çíà÷è çà òÿõ òàçè äàòà, çàùî å âàæíà, è êàêâî äà î÷àêâàìå.\r\n', 30, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'yes', 'http://store.picbg.net/pubpic/F4/7E/2fef9c01bbd5f47e.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 'Äèàìàíòèòå / Diamanti NG BG Audio TVRiP', 'torrents/1b441cb99839f95cd25ae2aedc17e4266b6c088b.btf', '', '2010-02-01 18:55:19', 607274648, '[center][size=5][color=blue]Äèàìàíòèòå\r\nNaked Science Super Diamonds[/color][/size][/center]\r\n\r\nÄèàìàíòúò å íàé-òâúðäîòî âåùåñòâî, îòêðèòî íà ïëàíåòàòà çåìÿ è âåêîâå íàðåä å áèë ñðåä íàé-ïî÷èòàíèòå è òúðñåíè ìàòåðèàëè îò ÷îâå÷åñòâîòî. Â ïðîäúëæåíèå íà ãîäèíè òåçè ñêúïîöåííîñòè áèëè îáåêò íà âúçõèùåíèå çàðàäè êðàñîòàòà ñè è ñèìâîë íà ãîëÿìî áîãàòñòâî. Îáãúðíàòè îò ìèòîâå è äúëáîêî âêîðåíåíè â äðåâíèòå ëåãåíäè, â íàøè äíè íà áåçöåííèòå êàìúíè ñå ãëåäà ïî íîâ íà÷èí. Ïðåäàâàíåòî èçñëåäâà èñòîðèÿòà íà äèàìàíòèòå è õâúðëÿ ñâåòëèíà êàê òå ìîãàò äà ïðîìåíÿò áúäåùåòî. Ñðåùíàõìå ñå ñ ó÷åíè îò òðè êîíòèíåíòà, êîèòî îòêðèâàò òàéíèòå íà äèàìàíòèòå è ïîòåíöèàëúò çà ðåâîëþöèîííè òåõíîëîãèè. Êàòî ñêúïîöåííè êàìúíè çíàåì, ÷å ñòðóâàò ñêúïî, à êàòî ïðåäìåò çà íîâè òåõíîëîãèè ñà áåçöåííè.\r\n\r\nÔèëì íà National Geographic ñ äóáëàæ íà áúëãàðñêè åçèê.', 31, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/EE/BB/3bdff09bb59eeebb.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 'Âðúçêàòà ñ Àòëàíòèäà / La Conexion Atlante  (2001)', 'torrents/8e9351468d3bdfe8d24858a04713737bc73ad719.btf', '', '2010-02-02 11:30:16', 367698944, '[center][size=5][color=orange]ÂÐÚÇÊÀÒÀ Ñ ÀÒËÀÍÒÈÄÀ[/color][/size][/center]\r\n\r\nÏðåç 10 900 ã. ïð.Õð. Ñâåòîâíèÿò ïîòîï ðàçðóøèë åäíà öèâèëèçàöèÿ, êîÿòî ïðîöúôòÿâàëà 25 920 ãîäèíè.\r\nÖèâèëèçàöèÿòà íà àòëàíòèòå. 25 920 ãîäèíè — òîâà å âðåìåòî, çà êîåòî ñëúí÷åâàòà ñèñòåìà\r\nïðàâè åäíà öÿëà îáèêîëêà îêîëî ãàëàêòè÷åñêîòî öåíòðàëíîòî ñëúíöå, äíåñ òàçè îáèêîëêà ñå íàðè÷à\r\nÏðåöåñèÿ íà ðàâíîäåíñòâèÿòà. Åäèí ãîëÿì öèêúë îò 25 920 ãîäèíè âðåìå äîñòàòú÷íî,\r\nçà äà ìîæå ÷îâå÷åñòâîòî äà îôîðìè åäíà ñîöèàëíà ñòðóêòóðà, ïîçâîëÿâàùà íà ÷îâåêà äà ðàçâèâà\r\nïîçíàíèÿòà ñè çà âñåëåíàòà.Â êðàÿ íà òîçè ïåðèîä îôîðìåíàòà ñòðóêòóðà ñå ðàçðóøàâà äàâà âúçìîæíîñò\r\nçà íîâ ïúò íà ðàçâèòèå íîâà îðãàíèçàöèÿ çà ïîëó÷àâàíå íà îïèò íîâè íà÷èíè íà ðàçáèðàíå çà âñåëåíàòà.\r\n\r\nÒîâà áåøå åäíî âúëíóâàùî ïúòóâàíå, çà äà äîêàæåì ëåãåíäàòà çà\r\nèç÷åçíàëîòî îáùåñòâî íà àòëàíòèòå, äà ãè ïðåîòêðèåì ïîñðåäñòâîì\r\nñâåùåíèòå êíèãè íà ìíîãî êóëòóðè. Äà ðàçáåðåì, ÷å òÿõíîòî íàó÷íî\r\nè ðåëèãèîçíî íàñëåäñòâî å îðãàíèçèðàëî íà÷àëîòî íà øóìåðèòå è åãèïòÿíèòå.\r\nÄà ðàçáåðåì, ÷å Âñåëåíàòà èìà öèêëè íà êîèòî å ïîä÷èíåíî ÷îâå÷åñòâîòî\r\nè ñîöèàëíèòå ñòðóêòóðè.Äà âúçïðèåìåì òàçè ôîðìà\r\nçà ðàçáèðàíå íà æèâîòàêàòî åäèí ïðîöåñ â åâîëþöèÿòà,\r\nêúì ðàçáèðàíåòî íà Óíèâåðñóìà, òîëåðàíòíîñòòà è ëþáîâòà.\r\n\r\n', 31, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/24/85/b0e1f6ac9ca02485.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 'Ïðîìåíåòå Windows XP èçöÿëî äà ïðèëè÷à íà Windows 7', 'torrents/3ae6ab04b357ee90020d5ee7ae288ae0de6282da.btf', '', '2010-02-02 19:19:28', 45676448, 'Ñ òîçè ñêèí ìîæåòå äà ïðîìåíèòå èçöÿëî Windows-a ñè äà ñòàíå äîñóùò êàòî Windows 7.\r\n\r\nÊëèêâàòå íà Seven Remix XP 2.31.exe è èíñòàëèðàòå, ñëåä êàòî èíñòàëèðàòå ùå âè ïîïèòà äàëè äà ðåñòàðòèðàòå êîìïþòúðà, êàçâàòå ìó íå.Ñëåä êàòî ñòå èíñòàëèðàëè Seven Remix XP 2.31.exe å âðåìå äà èíñòàëèðàòå Seven Remix XP User32 Patch.exe êîåòî ñå íàìèðà â ïàïêà Patches.Èíñòàëèðàòå ãî è íåãî.Ñëåä òîâà îòâàðÿòå ïàïêà Seven Remix XP Mods è òúðñèòå Seven Remix SymplyMod v1.1 Installer.exe, èíñòàëèðàòå ãî è íåãî.Ðåñòàðòèðàòå è ñå ëþáóâàòå íà èçöÿëî ïðîìåíåíèÿ Windows.\r\nÑêèíà å òåñòâàí îò ìåí è íå ñúçäàâà íèêàêâè áúãîâå è ñè ðàáîòè ïåðôåêòíî.\r\n\r\n[img]http://store.picbg.net/pubpic/8F/39/e86bb03e3e418f39.jpg[/img]', 26, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/ED/CD/339a47a72a77edcd.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 'Ultimate Survival-Ñåâåðåí ïîëÿðåí êðúã', 'torrents/74fa5ac7c1849a8e4d93fb548e055f136d5e1d82.btf', '', '2010-02-02 19:33:22', 645974092, '[size=5][color=yellow]Ultimate Survival- Îöåëÿâàíå íà ïðåäåëà [/color][/size]\r\n\r\n## Â ðîëèòå : Áåúð Ãðèëñ\r\n\r\n## Æàíð : Íàó÷íî - ïîïóëÿðåí\r\n\r\n## Äúðæàâà : Âåëèêîáðèòàíèÿ\r\n\r\n## Ãîäèíà : 2009\r\n\r\n## Âðåìåòðàåíå : 45 ìèíóòè\r\n\r\n## Êà÷åñòâî : TVRip\r\n\r\n## Ðåçþìå : Man vs Wild ïîçíàòî îùå êàòî Born Survivor: Bear Grylls è Ultimate Survival (íà áúëãàðñêè - "Îöåëÿâàíå íà ïðåäåëà" ) å òåëåâèçèîííî øîó çà îöåëÿâàíå, ñ âîäåù Áåúð Ãðèëñ, èçëú÷âàíî ïî Discovery Channel. Â øîóòî Ãðèëñ äåìîíñòðèðà è îáÿñíÿâà ðàçëè÷íè òåõíèêè çà îöåëÿâàíå â ðàçíîîáðàçíè îáëàñòè ïî Çåìÿòà. Âñåêè åïèçîä äîêóìåíòèðà íåãîâèòå óñèëèÿ äà îöåëåå è íàìåðè ïúò îáðàòíî êúì öèâèëèçàöèÿòà, êàòî ÷åñòî ñå íàëàãà äà íàïðàâè ïîäñëîí çà ïðåç íîùòà, ñ íàëè÷íèòå ñðåäñòâà íà îáëàñòòà. Ñúùî òàêà Áåúð ðàçêàçâà çà ðàçëè÷íè óñïåøíè è ïðîâàëèëè ñå îïèòè çà îöåëÿâàíå â ðàéîíà, êúäåòî ñå íàìèðà â ìîìåíòà. Âñåêè åïèçîä îòíåìà îêîëî åäíà ñåäìèöà çà äà ñå ðàçó÷è ðåãèîíà è îñîáåíîñòèòå ìó è îùå åäíà ñåäìèöà çà çàñíåìàíåòî íà åïèçîäà. Åêèïúò, êîéòî ïðèäðóæàâà Áåúð íÿìà ïðàâîòî äà ìó ïîìàãà îñâåí â ñèòóàöèÿ íà æèâîò è ñìúðò.\r\n', 14, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', 'http://www.imdb.com/title/tt0883772/', '', 'yes', 'http://store.picbg.net/pubpic/E3/B9/b352c7af265ee3b9.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', '×îâåøêîòî òÿëî 1 / BBC - The Human Body Part 1 - Life Story', 'torrents/8147175e914d3ee41f5f5e436568ac5b6f61f23a.btf', '', '2010-02-04 21:20:04', 715291953, 'Ðåëèéç: TV-Rip\r\n\r\nÆàíð: Äîêóìåíòàëåí\r\n\r\nÄúðæàâà : Âåëèêîáðèòàíèÿ\r\n\r\nÃîäèíà : 1998\r\n\r\nÂðåìåòðàåíå : 00:49:10 ìèíóòè\r\n\r\nÐåçþìå : Ôèëì íà BBC çà àíàòîìèÿòà è æèâîòà íà ÷îâåêà.\r\n\r\n"...Åäíî íåùî å îáùî çà âñè÷êè õîðà íà Çåìÿòà.Âñè÷êè íèå æèâååì,äèøàìå è ñå õðàíèì â ÷îâåøêîòî òÿëî.Â ïðîäúëæåíèå íà äâå ãîäèíè èçñëåäâàõìå òîâà óíèêàëíî æèëèùå.È ùå âè ïîêàæåì êàêâî âèäÿõìå....Ùå îáõîäèì òÿëîòî ïðåç öåëèÿ ìó æèòåéñêè ïúò...Ùå âèäèì ÷îâåøêîòî òÿëî âúâ âñè÷êèòå ìó ôîðìè.Îò íà÷àëîòî äî êðàÿ,êîéòî î÷àêâà âñè÷êè íè..."', 31, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/E7/93/fe9f8621be0de793.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 'Îöåëÿâàíå íà ïðåäåëà - Õàâàè / Ultimate Survival - Hawaii', 'torrents/2f3fb6392670b1c1476deffd1f5b046ac03d131b.btf', '', '2010-02-04 21:35:27', 808405134, '[size=2][color=green]## Â ðîëèòå :[/color][/size] Áåúð Ãðèëñ\r\n[size=2][color=green]\r\n## Æàíð : [/color][/size]Íàó÷íî - ïîïóëÿðåí\r\n\r\n[size=2][color=green]## Äúðæàâà :[/color][/size] Âåëèêîáðèòàíèÿ\r\n\r\n[size=2][color=green]## Ãîäèíà : [/color][/size]2009\r\n\r\n[size=2][color=green]## Âðåìåòðàåíå :[/color][/size] 45 ìèíóòè\r\n\r\n[size=2][color=green]## Êà÷åñòâî :[/color][/size] TVRip\r\n\r\n[size=2][color=green]## Ðåçþìå : [/color][/size]Man vs Wild ïîçíàòî îùå êàòî Born Survivor: Bear Grylls è Ultimate Survival (íà áúëãàðñêè - "Îöåëÿâàíå íà ïðåäåëà" ) å òåëåâèçèîííî øîó çà îöåëÿâàíå, ñ âîäåù Áåúð Ãðèëñ, èçëú÷âàíî ïî Discovery Channel. Â øîóòî Ãðèëñ äåìîíñòðèðà è îáÿñíÿâà ðàçëè÷íè òåõíèêè çà îöåëÿâàíå â ðàçíîîáðàçíè îáëàñòè ïî Çåìÿòà. Âñåêè åïèçîä äîêóìåíòèðà íåãîâèòå óñèëèÿ äà îöåëåå è íàìåðè ïúò îáðàòíî êúì öèâèëèçàöèÿòà, êàòî ÷åñòî ñå íàëàãà äà íàïðàâè ïîäñëîí çà ïðåç íîùòà, ñ íàëè÷íèòå ñðåäñòâà íà îáëàñòòà. Ñúùî òàêà Áåúð ðàçêàçâà çà ðàçëè÷íè óñïåøíè è ïðîâàëèëè ñå îïèòè çà îöåëÿâàíå â ðàéîíà, êúäåòî ñå íàìèðà â ìîìåíòà. Âñåêè åïèçîä îòíåìà îêîëî åäíà ñåäìèöà çà äà ñå ðàçó÷è ðåãèîíà è îñîáåíîñòèòå ìó è îùå åäíà ñåäìèöà çà çàñíåìàíåòî íà åïèçîäà. Åêèïúò, êîéòî ïðèäðóæàâà Áåúð íÿìà ïðàâîòî äà ìó ïîìàãà îñâåí â ñèòóàöèÿ íà æèâîò è ñìúðò.\r\n', 14, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/0B/2C/61547e70746e0b2c.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 'Retro hits', 'torrents/f82f76e1bc03aca7f23cecdaf9b2be414a004999.btf', '', '2010-02-06 12:41:41', 497082359, '[img]http://store.picbg.net/pubpic/11/87/f1f3c908e5381187.jpg[/img]\r\n\r\nÎïèñàíèå:\r\n1.Nana - Lonely\r\n\r\n2.C-BLOCK--TIME IS TICKIN` AWAY\r\n\r\n3.Gala - Freed from Desire\r\n\r\n4.NANA - One Second\r\n\r\n5.Haddaway - Missing\r\n\r\n6.Cool Cut - Please Let Me Know\r\n\r\n7.Nana - Dreams\r\n\r\n8.DJ Bobo - Somebody Dance With Me\r\n\r\n9.Mr John - Get It On\r\n\r\n10.E-Type - Angels Crying\r\nè îùå 95 çàâëàäÿâàùè ïåñíè', 23, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', '', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 'WWE The Music-A New Day Vol 10-(WEB)-2010', 'torrents/5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3.btf', '', '2010-02-06 12:47:30', 110615911, '1. Adelitas Way - It''s A New Day (The Legacy) 3:04\r\n2. Cage 9 - I Am Perfection (Dolph Ziggler) 3:19\r\n3. Downstait - I Came To Play (The Miz) 4:57\r\n4. Story Of The Year - Just Close Your Eyes (Christian) 4:31\r\n5. WWE & Jim Johnston - Return The Hitman (Bret Hart) 5:37\r\n6. Sean Jenness - Written In My Face (Sheamus) 3:33\r\n7. Patsy Grime - Insatiable (Tiffany) 3:10\r\n8. Evan Jones - Domination (Ezekiel Jackson) 4:17\r\n9. Mutiny Within - Born To Win (Evan Bourne) 4:17\r\n10. Vinny And Ray & Marlyn Jimenez - Oh Puerto Rico (Primo) 3:32\r\n11. Watt White - Radio (Zack Ryder) 4:02\r\n12. Jimi Bell - New Foundation (The Hart Dynasty) 3:32\r\n13. Kim Sozzi - You Can Look (But You Can''t Touch) 3:47\r\n14. Maylene & The Sons of Disaster - Crank The Walls Down (Big 3:07\r\nShow / Chris Jericho)', 23, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/71/06/4dd1b511f98f7106.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', '÷îâåøêîòî òÿëî-2/The Human Body Part 2 - Everyday Miracle', 'torrents/07de55a880bafe1e1b85ca4a60329b39b9f191e9.btf', '', '2010-02-06 12:56:12', 717641849, '[img]http://store.picbg.net/pubpic/09/50/e1c86cffbd660950.jpg[/img]\r\n\r\n\r\n[size=3][color=yellow]Æàíð:[/color][/size] Äîêóìåíòàëåí\r\n\r\n[size=3][color=yellow]Äúðæàâà :[/color][/size] Âåëèêîáðèòàíèÿ\r\n\r\n[size=3][color=yellow]Ãîäèíà :[/color][/size] 1998\r\n\r\n[size=3][color=yellow]Âðåìåòðàåíå :[/color][/size] 00:49:30 ìèíóòè\r\n\r\n[size=3][color=yellow]Ðåçþìå :[/color][/size] Ôèëì íà BBC çà àíàòîìèÿòà è æèâîòà íà ÷îâåêà.\r\n\r\nÒîçè ôèëì å çà íåîáèêíîâåíàòà âðúçêà ìåæäó ìàéêàòà è áåáåòî,êîÿòî å â íà÷àëîòî íà âñåêè íîâ æèâîò. ', 31, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', '', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 'Joan Jade and the Gates of Xibalba', 'torrents/fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2.btf', '', '2010-02-06 20:01:20', 88174422, '  [center][size=5][color=red]Joan Jade and the Gates of Xibalba[/color][/size] [/center]\r\n\r\n[size=3][color=red]Ïðîèçâîäèòåë:[/color][/size] Alawar Entertainment\r\n\r\n[size=3][color=red]Æàíð:[/color][/size] Êóåñò, Ïðèêëþ÷åíñêè\r\n\r\n[size=3][color=red]Ãîäèíà:[/color][/size] 2010\r\n\r\n[size=3][color=red]Ñèñòåìíè èçèñêâàíèÿ:[/color][/size]\r\nOS: Windows XP, Vista, 7\r\nCPU: 1GHz\r\nRAM: 768 MB\r\nDirectX 7.1 or later\r\n110 MB hard drive space\r\n\r\n[size=3][color=red]Êîìåíòàð:[/color][/size]\r\nÒðè íåùà ñòîÿò ìåæäó âàñ è âàøèòå äåöà - äæóíãëàòà\r\nãúìæè îò îïàñíîñòè, ðóèíèòå íà äðåâíîòî ïëåìå íà Ìàèòå\r\nè ãðóïà ðàýáîéíèöè è âèå íÿìà äà ïîýâîëèòå íà íèêîé îò òÿõ\r\näà âè ñïðå! Âëåýòå â ðîëÿòà íà Äæîàí Äæåéä, àðõåîëîã íà\r\nãîäèíàòà è íåîáèêíîâåíà ìàéêà, êîÿòî òúðñè ñêðèòè ïðåäìåòè,\r\nðåøàâà ñëîæíè ïúýåëè è ïîáåæäàâà èýêóñíè ìèíè-èãðè\r\nåäíà ñëåä äðóãà. Ïî ïúòÿ ùå ïîñåòèòå êðàñèâè ìåñòà è ùå\r\níàó÷èòå èíòåðåñíè ôàêòè...\r\n\r\n[size=3][color=red]Íà÷èí íà èíñòàëàöèÿ:[/color][/size]\r\nÈíñòàëèðàòå îò setup.exe è èãðàåòå.', 18, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/43/10/edef57bf4ab34310.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 'Epica - Unleashed avi', 'torrents/e4552ae9a6992556b26bebd79ccfb2a93f66634a.btf', '', '2010-02-09 20:08:58', 56109060, '[center][size=5][color=orange]Epica - Unleashed[/color][/size][/center]\r\n\r\nÆàíð:symphonic metal\r\n\r\nÃîäèíà: 2009\r\n\r\nÍàðîäíîñò: The Netherland\r\n\r\nÔîðìàò: DVDRip\r\n\r\nÂèäåî: Width : 640 pixels\r\n\r\nÄèñïëåé : 16/9\r\n\r\nÐåçîëþöèÿ: 24 bits\r\n\r\nÀóäèî: AAC\r\n\r\n[img]http://store.picbg.net/pubpic/45/A3/a87cdfea8fa645a3.jpg[/img]', 24, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/A9/34/0d10d9d079dea934.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 'Mickeys Mouse-Once Upon A Christmas - BG Audio', 'torrents/d81d86324d1a113e5043817f878a39b4ec11ae81.btf', '', '2010-02-11 20:35:02', 684626111, '[size=5][color=orange]Mickeys mouse.Once upon a christmas - BG Audio / Ìèêè Ìàóñ: Âåäíúæ íà Êîëåäà[/color][/size]\r\n\r\n[size=3][color=yellow]Àóäèî:[/color][/size] Bulgarian/Áúëãàðñêî\r\n\r\n[size=3][color=yellow]Æàíð:[/color][/size] Animation, Children/Àíèìàöèÿ, Çà äåöà\r\n\r\n[size=3][color=yellow]Îïèñàíèå:[/color][/size]\r\n\r\nÍàé-ãîëåìèòå çâåçäè íà “Äèñíè” áëåñòÿò â òîçè íîâ âúëøåáåí ôèëì, êîéòî ñúñ ñèãóðíîñò ùå ñå ïðåâúðíå â êîëåäíà êëàñèêà! Ìèêè, Ìèíè è ñëàâíèòå èì ïðèÿòåëè Ãóôè, Äîíàëä, Äåéçè è Ïëóòî ñå ñúáèðàò çàåäíî, çà äà ñè ïðèïîìíÿò ëþáîâòà, ìàãèÿòà è èçíåíàäèòå â òðè èçïúëíåíè ñ ÷óäåñà èñòîðèè çà îòìèíàëè Êîëåäè.\r\nÑëåäâàéêè íàé-ïðåêðàñíèòå òðàäèöèè íà “Äèñíè”, Ìèíè è Ìèêè ðàçêàçâàò çà ãîäèíàòà, â êîÿòî è äâàìàòà ñå îòêàçâàò îò òîâà, êîåòî íàé-ìíîãî îáè÷àò çàðàäè äðóãèÿ è Êîëåäàòà ñòàâà íåçàáðàâèìà. Ãóôè è Ìàêñ ñïîäåëÿò çà ïîðåäèöàòà îò ñìåõîòâîðíè è ðàçòúðñâàùè ñúáèòèÿ... äîêàòî èäâàíåòî íà èñòèíñêèÿ Äÿäî Êîëåäà íå ïðåâðúùà ïðàçíèêà âúâ âúëøåáñòâî. Âðúùàéêè ñå íàçàä âúâ âðåìåòî, êîãàòî ñà ìå÷òàëè Êîëåäà äà å âñåêè äåí, ïëåìåííèöèòå íà Äîíàëä – Õþè, Äþè è Ëóè – ñè ñïîìíÿò êàê ìå÷òàòà èì å ïðåðàñíàëà â êîìè÷íà êàòàñòðîôà è ñà íàó÷èëè èñòèíñêîòî çíà÷åíèå íà êîëåäíèÿ ïðàçíèê\r\n', 13, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/87/1F/d32f704fa3f2871f.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 'WWE.Royal.Rumble.2010', 'torrents/56ecd6559b00547d784eb06b68cae0bebed0cbb0.btf', '', '2010-02-12 13:39:15', 1391196898, '[center][size=5][color=purple]WWE.Royal.Rumble.2010[/color][/size][/center]\r\n\r\n[size=5][color=limegreen]30-÷îâåêà,1-ïå÷åëè äà áúäå êðàëÿ íà ðèíãà \r\n\r\nàòëàíòà-31.1.2010ã.[/color][/size]', 15, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/2B/37/bcdc272d74772b37.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 'Íàé-äîáðèòå âèäåî è àóäèî ïëåúðè', 'torrents/5b3f8e5644dde537e8e8df8dae5756f47c74fa25.btf', '', '2010-02-12 20:46:04', 342998059, '[size=5][color=blue]Íàé-äîáðèòå âèäåî è àóäèî ïëåúðè[/color]\r\n[color=purple] ïëåúðèòå êîéòî âêëþ÷âà òîðåíòà[/color][/size]\r\n\r\n[size=3][color=brown]Âèäåî ïëåúðè:[/color][/size]\r\n-Bravo Player\r\n-BS.Player PRO 2.42 Build 1005\r\n-GOM Player 2.1.9.3754 Íà Áúëãàðñêè åçèê + Skins\r\n-GOM Player Portable version\r\n-iTunes 8.1.0.52\r\n-Kantaris Player\r\n-KMPlayer 2.9.4.1435 Final + Skins\r\n-Kmplayer for win 7\r\n-Miro HD Video player2.0.5\r\n-MOP Player\r\n-Mplayer\r\n-MV2 Player\r\n-Real Player\r\n-TVU Player\r\n-Vi Player\r\n-VLC Player\r\n-BS.Player 2.51 Final Portable\r\n\r\n[size=3][color=brown]Àóäèî ïëåúðè[/color][/size]\r\n-AIMP2.5\r\n-Winamp 5.572 Build 2830\r\n-JetAudio Portable 8.0.4\r\n-Winamp Pro 5.56 inclStreamaripper\r\n\r\n', 26, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'yes', 'http://store.picbg.net/pubpic/E0/6F/dabfefb81f88e06f.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 'Êàïèòàí Ïåòêî Âîéâîäà', 'torrents/402dd7c4e27d1d86ca6b3cd835e2c0164a083233.btf', '', '2010-02-15 16:19:43', 9346863104, '[color=red][size=3]## Ðåæèñüîð : Íåäåë÷î ×åðíåâ\r\n\r\n## Â ðîëèòå : Âàñèë Ìèõàéëîâ,Ïëàìåí Äîí÷åâ ,Ïåòúð ×åðíåâ...\r\n\r\n\r\n\r\n\r\n\r\n## Ãîäèíà : 1981\r\n\r\n## Âðåìåòðàåíå : 7.33\r\n\r\n## Ðåçþìå : 12 Åïèçîäè:\r\n\r\n\r\n\r\nÎÒÌÚÙÅÍÈÅÒÎ \r\n\r\nÕÀÉÄÓØÊÈ ÄÀÍÚÊ \r\n\r\nÕÀÉÄÓÒÈÍ \r\n\r\nÊÀÏÀÍÚÒ \r\n\r\nÁßÃÑÒÂÎÒÎ \r\n\r\nÐÓÑÈß ÄÎÉÄÅ \r\n\r\nÃÎÄÅÆÚÒ \r\n\r\nÒÎÏÎÃÐÀÔÈ \r\n\r\nÇÀÂÐÚÙÀÍÅÒÎ\r\n\r\nÑÐÅÙÈ\r\n\r\nÈ× ÊÀËÅ \r\n\r\nÏÎÁÐÀÒÈÌÚÒ \r\n\r\nÏÅÒÊÎ ËÅ, ÊÀÏÈÒÀÍÈÍÅ[/size][/color]', 14, 'no', '', 7, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', 'http://www.youtube.com/watch?v=np8-5Najgs8', 'no', 'http://img.zamunda.net/bitbucket/kapitan%20petko%20voivoda001.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 'Âèðòóàëíà Õèìè÷íà Ëàáîðàòîðèÿ 2.0 / A Virtual Chemistry Lab 2.0', 'torrents/a7a8b68bae557cda7193e10467ecdfba5a5fce17.btf', '', '2010-02-16 21:45:53', 18969695, '[size=5][color=yellow]Âèðòóàëíà Õèìè÷íà Ëàáîðàòîðèÿ 2.0 / A Virtual Chemistry Lab 2.0[/color][/size]\r\n\r\nÖåë íà ïðîåêòà\r\n\r\nÖåëòà íà òîçè ïðîåêò å äà ñå ñúçäàäå âèðòóàëíà ëàáîðàòîðèÿ ïî õèìèÿ â ïîìîù íà ó÷åíèöèòå, èçó÷àâàùè òîçè ïðåäìåò çà ïúðâà ãîäèíà è òåõíèòå ïðåïîäàâàòåëè. Ðàçðàáîòêàòà å ñúîáðàçåíà ñ ó÷åáíîòî ñúäúðæàíèå ïî õèìèÿ çà 7-ìè êëàñ, êúäåòî ñå èçó÷àâàò îñíîâèòå íà òîçè ïðåäìåò è äîáðîòî îâëàäÿâàíå íà ó÷åáíèÿ ìàòåðèàë å ïðåäïîñòàâêà çà óñïåøíî ïðåäñòàâÿíå ïðåç ñëåäâàùèòå ãîäèíè íà îáó÷åíèå. Ïðîäóêòúò å ïðåäíàçíà÷åí çà áúëãàðñêèòå ó÷åíèöè îò 7 êëàñ è åâåíòóàëíî òåõíèòå ó÷èòåëè, íî îòäåëíè íåãîâè êîìïîíåíòè, ïîðàäè ñâîÿ óíèâåðñàëåí õàðàêòåð, áèõà áèëè îò ïîëçà è íà ïî-ãîëåìè ó÷åíèöè.\r\n\r\nÎïèñàíèå\r\n\r\nÑ ïðîãðàìàòà ñå ðàáîòè èçêëþ÷èòåëíî èíòóèòèâíî – èìàìå âèðòóàëåí ðàáîòåí ïëîò è äâà ïàíåëà – ñúîòâåòíî çà âåùåñòâà è ëàáîðàòîðíè ñúäîâå. Çà äà èçâúðøèì äàäåíà ðåàêöèÿ å äîñòàòú÷íî äà èçêàðàìå íà ïëîòà ïîäõîäÿùèòå ñúäîâå è äà ñëîæèì â òÿõ íåîáõîäèìèòå âåùåñòâà. Ïðîãðàìàòà ñúäúðæà áàçà äàííè ñ ðåàêöèè, êàòî ïðèòåæàâà èçêëþ÷èòåëíî èíòåðåñíàòà âúçìîæíîñò äà âèçóàëèçèðà òåçè, êîèòî ñå èçó÷àâàò â 7-ìè êëàñ. Ïðèìåðíî, àêî íàïúëíèòå åäíî ëàáîðàòîðíî ñòúêëî ñ âîäà è ñëîæèòå â íåãî íàòðèé ùå âèäèòå â àíèìàöèÿ íå ñàìî íà÷èíà ïî êîéòî ïðîòè÷à áóðíàòà ðåàêöèÿ, íî è ñúâñåì òî÷íî íà÷èíúò ïî êîéòî ìîëåêóëèòå íà äâåòå âåùåñòâà ñè âçàèìîäåéñòâàò, çà äà ñå ïîëó÷è êðàéíèÿò ðåçóëòàò. Â îáùè ëèíèè íà÷èíúò, ïî êîéòî åêñïåðèìåíòèòå ñå îñúùåñòâÿâàò å èçêëþ÷èòåëíî ëåñåí è íàïîìíÿ èñòèíñêà ðàáîòà â ëàáîðàòîðèÿ.\r\n\r\nÏðîãðàìàòà èìà è àñèñòåíò, êîéòî ñúîáùàâà çà âñè÷êè ïðîìåíè, êîèòî íàñòúïâàò â ïðîãðàìàòà. Òîé å èçêëþ÷èòåëíî óìåëî íàïðàâåí, â òîí ñ èíòåðôåéñà íà ïðîãðàìàòà. Îòíîñíî èíòåðôåéñà ïî ïîäðàçáèðàíå å â åäèí ìíîãî ïðèÿòåí ñèí öâÿò, íî ïîòðåáèòåëÿ èìà ïúëåí êîíòðîë íàä íåãî è äîðè ìîæå äà ìó çàäàâà ïðîçðà÷íîñò. Ïðîãðàìàòà ïðåäëàãà ãîëÿì áðîé õèìè÷íè ïîñîáèÿ – êàòî ñå çàïî÷íå îò ìåíäåëååâàòà òàáëèöà è ñå ñòèãíå äî òàáëèöèòå çà ðàçñòâîðèìîñò, îêèñëèòåëíà è îòíîñèòåëíà àêòèâíîñò è äîðè õèìè÷åí ðå÷íèê. Äîðè è òå äà íå ñà äîñòàòú÷íè èìà áîãàò èçáîð îò äðóãè èíòåðåñíè ïðèëîæåíèÿ êàòî õèìè÷íèÿò ðåäàêòîð, êîéòî ïîçâîëÿâà äà ñúçäàâàòå è èçðàâíÿâàòå õèìè÷íè óðàâíåíèÿ, êîíâåðòîð çà ìåðíè åäèíèöè, êîéòî ïðåäëàãà êîíâåðñèÿ íà íåâåðîÿòíî êîëè÷åñòâî ìåðíè åäèíèöè. Îñâåí òÿõ èìà òåñò çà ïðîâåðêà íà çíàíèÿòà, íàó÷åí êàëêóëàòîð, ëàáîðàòîðíè óïðàæíåíèÿ è äíåâíèê (çà èçãîòâÿíå íà äîêëàäè îòíîñíî åêñïåðèìåíòèòå).\r\n\r\n\r\n# Ïðîãðàìàòà ïðåäëàãà ñëåäíèòå âúçìîæíîñòè\r\n\r\n# âèçóàëíî èçâúðøâàíå íà îïèòè ñ ðàçëè÷íè õèìè÷íè âåùåñòâà\r\n\r\n# ïîòðåáèòåëÿò èìà âúçìîæíîñò äà ïîñòàâÿ ëàáîðàòîðíè ñúäîâå âúðõó ðàáîòíàòà ïëîù, äà ñìåñâà äâå õèìè÷íè âåùåñòâà è äà íàáëþäàâà ïðîòè÷àùàòà ðåàêöèÿ, àêî òàêàâà ñúùåñòâóâà\r\n\r\n# ìîäåëíî ïðåäñòàâÿíå è ïðåñòàâÿíå ñ õèìè÷íî óðàâíåíèå íà ïðîòåêëàòà õèìè÷íà ðåàêöèÿ\r\n\r\n# ïðîòè÷àùàòà ðåàêöèÿ ñå ïðåäñòàâÿ ñ àíèìèðàí àòîìåí ìîäåë è èçðàâíåíî õèìè÷íî óðàâíåíèå\r\n\r\n# ïîëçâàíå íà "àñèñòåíò" çà óëåñíÿâàíå íà ðàáîòàòà ñ ïðîãðàìàòà\r\n\r\n# íàïúòñòâà ïîòðåáèòåëÿ ñ êîíêðåòíà èíôîðìàöèÿ çà äåéñòâèÿòà, êîèòî òðÿáâà äà ïðåäïðèåìå ïðè èçâúðøâàíå íà ðàçëè÷íèòå äåéíîñòè â "ëàáîðàòîðèÿòà"\r\n\r\n# ïîëçâàíå íà ðàçíîîáðàçíà ñïðàâî÷íà èíôîðìàöèÿ çà õèìè÷íèòå åëåìåíòè\r\n\r\n- ïåðèîäè÷íà ñèñòåìà íà õèìè÷íèòå åëåìåíòè – ïðåäëîæåíà å â ñòàíäàðòåí è ðàçãúðíàò âèä; ïðè êëèêâàíå âúðõó íÿêîé îò õèìè÷íèòå çíàöè ñå âèçóàëèçèðà ïîäðîáíà èíôîðìàöèÿ çà ñúîòâåòíèÿ åëåìåíò\r\n\r\n- òàáëèöà çà ðàçòâîðèìîñò – ïðåäîñòàâÿ èíôîðìàöèÿ çà òîâà äàëè äàäåíî õèìè÷íî ñúåäèíåíèå îáðàçóâà óòàéêà è êàêúâ å íåéíèÿò öâÿò\r\n\r\n- ðåä íà îòíîñèòåëíàòà è îêèñëèòåëíàòà àêòèâíîñò – ïðåäñòàâÿ îêèñëèòåëíàòà àêòèâíîñò íà íåìåòàëèòå è îòíîñèòåëíàòà àêòèâíîñò íà ìåòàëèòå\r\n\r\n# òåðìèíîëîãè÷åí ðå÷íèê - êðàòêè îïèñàíèÿ íà íàé-÷åñòî èçïîëçâàíè ïîíÿòèÿ\r\n\r\n# èíòåðàêòèâåí òåñò çà ñàìîïðîâåðêà - ñðåäñòâî, ÷ðåç êîåòî ïîòðåáèòåëèòå ìîãàò äà ïðîâåðÿò çíàíèÿòà ñè; â ïîëçà íà ó÷èòåëèòå, êîèòî áèõà èñêàëè äà ãî èçïîëçâàò çà îöåíÿâàíå íà ó÷åíèöèòå å ïðåäîñòàâåí è óäîáåí ðåäàêòîð, ñ ïîìîùòà íà êîéòî âúïðîñèòå ëåñíî ìîãàò äà ñå îáíîâÿâàò\r\n\r\n# èíòåðàêòèâíî ëàáîðàòîðíî óïðàæíåíèå - äàâà âúçìîæíîñò åäíîâðåìåííî äà ñå ïðàâÿò îïèòè è äà ñå ïðîÿâåðÿâàò çíàíèÿòà\r\n\r\n# ðåäàêòîð çà èçðàâíÿâàíå íà õèìè÷íè óðàâíåíèÿ - ðåøàâàíå íà õèìè÷íè óðàâíåíèÿ\r\n\r\n# êîíâåðòîð çà ïðåîáðàçóâàíå íà ìåðíè åäèíèöè\r\n\r\n# õèìè÷åí êàëêóëàòîð\r\n\r\n# ïîìîùíà ñèñòåìà\r\n\r\n[center][size=5][color=yellow]Ïðîñòî èíñòàëèðàéòå,ïðîãðàìàòà å íà áúëãàðñêè! ! ![/color][/size][/center]', 26, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/B8/4C/2d7748c124d9b84c.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 'Sizing up The universe / Ïîçíàòàòà âñåëåíà Èçìåðâàíå íà âñåëåíàòà (2009)', 'torrents/e07a628ac7ece96531ed02db15ba76c0ec9ba0a7.btf', '', '2010-02-17 16:30:31', 1471463914, '## Îò êîëåêöèÿòà íà: National Geographic\r\n\r\n## Æàíð: Íàó÷íîïîïóëÿðåí ôèëì, Äîêóìåíòàëåí\r\n\r\n## Ãîäèíà: 2009\r\n\r\n## Äúðæàâà: ÑÀÙ\r\n\r\n## Âðåìåòðàåíå: 47 ìèíóòè\r\n\r\n## Åçèê: Áúëãàðñêè\r\n\r\n## Ðåçþìå: Â ïîçíàòàòà íè âñåëåíà ðàçìåðúò èìà çíà÷åíèå.Îò íàøàòà îáøèðíà ñëúí÷åâà ñèñòåìà äî îãðîìíàòà íè ãàëàêòèêà è íåîáÿòíàòà øèð íà êîñìîñà.Äî ìàëêàòà ìîëåêóëà è áåçêðàéíî ìàëêèòå àòîìè êîèòî èçãðàæäàò âñè÷êî.Îò íàèñòèíà îãðîìíèòå íåùà äî íåîáîçðèìî ìàëêèòå.Âñåëåíàòà å ìÿñòî íà êðàéíèòå ðàçìåðè.Äîðè è äà ñòå íàÿñíî ñ ðàçìåðèòå íå ñòå ãè âèæäàëè îò òàçè ïåðñïåêòèâà.\r\n\r\n', 31, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/46/82/89e69d33e5114682.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', '2012 / 2012 (2009)', 'torrents/594fc7244ed3b3c4e5eaf94af67afa99accdddf9.btf', '', '2010-02-17 17:20:50', 3135371264, '## Ðåæèñüîð: Roland Emmerich\r\n\r\n## Â ðîëèòå: John Cusack, Amanda Peet, Chiwetel Ejiofor, Thandie Newton, Oliver Platt, Thomas McCarthy, Woody Harrelson, Danny Glover\r\n\r\n## Æàíð: Åêøúí, Äðàìà, Ôàíòàñòèêà\r\n\r\n## Äúðæàâà: ÑÀÙ\r\n\r\n## Ãîäèíà: 2009\r\n\r\n## Ñàéò íà ôèëìà:http://www.whowillsurvive2012.com/\r\n\r\n## Âðåìåòðàåíå: 143 ìèíóòè\r\n\r\n## Âãðàäåíè ñóáòèòðè\r\n\r\n## Ðåçþìå:\r\n\r\n2012 ã – Êðàÿò íà äíèòå èëè íà÷àëîòî íà íîâà åïîõà\r\n\r\n2012 å ãîäèíà, ñïîìåíàòà â ìíîãî ïðåäñêàçàíèÿ êàòî êðàÿ íà äíèòå çà ÷îâå÷åñòâîòî. Èçñëåäâàíèÿòà íà ìíîãî ñúâðåìåííè ó÷åíè ñúùî ñà äîñòèãíàëè äî èçâîäà, ÷å ïëàíåòàòà íè å îáðå÷åíà. Èñòèíà ëè å òîâà, è àêî å, êàê áè òðÿáâàëî äà èçæèâååì äíèòå äî èäâàíåòî íà òîçè ìîìåíò?\r\nÂúâ âñÿêà åäíà êóëòóðà è âúâ âñè÷êè îðòîäîêñàëíè ðåëèãèè ñå ñðåùà êîíöåïöèÿòà çà èäâàíåòî íà êðàÿ íà ñâåòà è çà íàñòúïâàíåòî íà îãðîìíè ïðîìåíè, çàñÿãàùè öÿëàòà ïëàíåòà. Ïî÷òè âñè÷êè ñâåäåíèÿ ñïîìåíàâàò, ÷å òîâà ùå ñå ñëó÷è â íà÷àëîòî íà 21 âåê. Ñïîðåä êàëåíäàðà íà ìàèòå êðàÿò íà ñâåòà ùå íàñòúïè òî÷íî íà 21 äåêåìâðè 2012 ã. Ïîäîáíà äàòà å ïðåäñêàçàíà è îò Íîñòðàäàìóñ, êàêòî è îò äðåâíàòà êèòàéñêà „Êíèãà íà ïðîìåíèòå” („È ×èíã”), êîÿòî ïðåäñêàçâà õîäà íà ïðîìåíèòå âúâ Âñåëåíàòà.\r\nÌàèòå ñà ñúçäàëè èçêëþ÷èòåëíî òî÷åí àñòðîíîìè÷åñêè êàëåíäàð, êîéòî ïî íèùî íå ìîæå äà ñå ñðàâíÿâà ñ òîçè, êîéòî èçïîëçâàìå äíåñ. Òå ñà óñïåëè äà ïðåäâèäÿò ñ ïðåöèçíà òî÷íîñò ñúáèòèÿ, ñëó÷èëè ñå ïîâå÷å îò õèëÿäà ãîäèíè ñëåä èç÷åçâàíåòî íà òÿõíàòà öèâèëèçàöèÿ. Èçíåíàäâàùî, ïîñëåäíèÿò äåí îò òåõíèÿ êàëåíäàð å äàòàòà 21 äåêåìâðè 2012 ã, êîéòî áåëåæè êðàÿ íà åïîõàòà íà „Ïåòîòî Ñëúíöå”. Íÿêîè õîðà ãî ðàçáèðàò êàòî êðàÿ íà ñâåòà, äîêàòî äðóãè ñìÿòàò, ÷å òîãàâà ùå íàñòúïè íà÷àëîòî íà íîâ ïåðèîä îò ÷îâåøêàòà èñòîðèÿ. ', 15, 'no', '', 8, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', 'http://store.picbg.net/pubpic/1B/A7/fc94429089321ba7.jpg', 'no', '', 'false', 'subs_sab', '');
INSERT INTO `namemap` VALUES ('230c91fff8491c9af76b23823e967a328e06c0ce', 'Apokalipsis', 'torrents/230c91fff8491c9af76b23823e967a328e06c0ce.btf', 'jlachka', '2010-02-19 15:29:20', 4711299922, 'posle', 15, 'no', '', 12, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 'no', NULL, 'no', 'false', '', '', '', 'no', '', 'no', '', 'false', 'subs_sab', '');

-- --------------------------------------------------------

-- 
-- Структура на таблица `news`
-- 

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news` blob NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

-- 
-- Дъмп (схема) на данните в таблицата `news`
-- 

INSERT INTO `news` VALUES (1, 0x5b695d5b625d5b73697a653d325dd2f0e0eae5f0e020ede0e1e8f0e020f1e5f0e8eee7ede820f5eef0e020e7e020faefebeef3e4faf0e82c20e6e5ebe0e5f9e8f2e520ede5eae020e4e020efeeeffaebedfff2205b75726c3d687474703a2f2f39332e3135352e3138322e39312f75706c6f61646572726571756573742e7068705dd2eee7e8205b2f75726c5df4eef0ecf3ebfff05b2f73697a655d5b2f625d5b2f695d, 2, '2009-11-09 20:50:42', 'Uieioau?e');

-- --------------------------------------------------------

-- 
-- Структура на таблица `partner`
-- 

CREATE TABLE `partner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titel` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Дъмп (схема) на данните в таблицата `partner`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `peers`
-- 

CREATE TABLE `peers` (
  `infohash` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `peer_id` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `bytes` bigint(20) NOT NULL DEFAULT '0',
  `ip` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'error.x',
  `port` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` enum('leecher','seeder') COLLATE latin1_general_ci NOT NULL DEFAULT 'leecher',
  `lastupdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sequence` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `natuser` enum('N','Y') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `client` varchar(60) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dns` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pid` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `with_peerid` varchar(101) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `without_peerid` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `compact` varchar(6) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`infohash`,`peer_id`),
  UNIQUE KEY `sequence` (`sequence`),
  KEY `pid` (`pid`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=382 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=382 ;

-- 
-- Дъмп (схема) на данните в таблицата `peers`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `poll_voters`
-- 

CREATE TABLE `poll_voters` (
  `vid` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `votedate` int(10) NOT NULL DEFAULT '0',
  `pid` mediumint(8) NOT NULL DEFAULT '0',
  `memberid` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`vid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Дъмп (схема) на данните в таблицата `poll_voters`
-- 

INSERT INTO `poll_voters` VALUES (3, '93.155.182.91', 1257783552, 2, '2');
INSERT INTO `poll_voters` VALUES (4, '95.42.70.216', 1265478792, 2, '7');

-- --------------------------------------------------------

-- 
-- Структура на таблица `polls`
-- 

CREATE TABLE `polls` (
  `pid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `startdate` int(10) DEFAULT NULL,
  `choices` text COLLATE latin1_general_ci,
  `starter_id` mediumint(8) NOT NULL DEFAULT '0',
  `votes` smallint(5) NOT NULL DEFAULT '0',
  `poll_question` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `status` enum('true','false') COLLATE latin1_general_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

-- 
-- Дъмп (схема) на данните в таблицата `polls`
-- 

INSERT INTO `polls` VALUES (2, 1257783544, 'a:8:{i:0;a:3:{i:0;i:0;i:1;s:5:"Ôèëìè";i:2;i:0;}i:1;a:3:{i:0;i:1;i:1;s:4:"Èãðè";i:2;i:0;}i:2;a:3:{i:0;i:2;i:1;s:6:"Ìóçèêà";i:2;i:0;}i:3;a:3:{i:0;i:3;i:1;s:8:"Ïðîãðàìè";i:2;i:0;}i:4;a:3:{i:0;i:4;i:1;s:7:"Ñåðèàëè";i:2;i:0;}i:5;a:3:{i:0;i:5;i:1;s:3:"õõõ";i:2;i:0;}i:6;a:3:{i:0;i:6;i:1;s:14:"Ìåòúë êîíöåðòè";i:2;i:0;}i:7;a:3:{i:0;i:7;i:1;s:12:"Ïóáëèöèñòèêà";i:2;i:0;}}', 2, 0, 'Êàêâè òîðåíòè ïðåäïî÷èòàòå äà ïðåîáëàäàâàò ?', 'true');

-- --------------------------------------------------------

-- 
-- Структура на таблица `posts`
-- 

CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `added` int(10) DEFAULT NULL,
  `body` text COLLATE latin1_general_ci,
  `editedby` int(10) unsigned NOT NULL DEFAULT '0',
  `editedat` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `userid` (`userid`),
  FULLTEXT KEY `body` (`body`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=32 ;

-- 
-- Дъмп (схема) на данните в таблицата `posts`
-- 

INSERT INTO `posts` VALUES (13, 13, 8, 1265229156, '[center][size=6][color=red]ÌÀÈÒÅ ÂÅÙÀßÒ[/color][/size][/center]\r\n\r\nÊàëåíäàðúò íà ìàèòå áðîè ïîñëåäíèòå 2 ãîäèíè äî Àïîêàëèïñèñà. \r\n×ðåç ñëîæíè àñòðîíîìè÷åñêè íàáëþäåíèÿ äðåâíèòå æðåöè îïðåäåëÿò 2012 ãîäèíà çà ôàòàëíà.\r\n\r\nÈçïúëíåíàòà ñúñ çàãàäêè öèâèëèçàöèÿ ïðèåìà, ÷å ñâåòúò ñúùåñòâóâà â ðàìêèòå íà ïåò âåëèêè öèêúëà. Èíà÷å êàçàíî, ïëàíåòàòà íè å óíèùîæàâàíà íÿêîëêî ïúòè. Ïúðâèÿò öèêúë çàâúðøâà ñúñ ðàçðóøèòåëíî çåìåòðåñåíèå, âòîðèÿò - ñ óíèùîæèòåëåí óðàãàí. Êðàÿò íà òðåòèÿ å ïðè÷èíåí îò îãíåí äúæä, èçñèïàë ñå îò êðàòåðèòå íà âóëêàíè. \r\n\r\nÍåâåðîÿòåí ïîòîï çàëè÷àâà âñè÷êî ÷åòâúðòèÿ ïúò. Â ìîìåíòà æèâååì â ïîñëåäíèÿ, ïåòè öèêúë, ñî÷è ëåòîáðîåíåòî íà ìàèòå. \r\n\r\nÊàìåííèÿò êàëåíäàð ïîðàçÿâà äíåøíèòå ó÷åíè ñúñ ñâîÿòà íåâåðîÿòíà òî÷íîñò. Ñïîðåä òÿõ çà òàçè ïðåöèçíîñò ñà áèëè íóæíè ïîíå 10 000 ãîäèíè íàáëþäåíèå íà äâèæåíèåòî íà íåáåñíèòå òåëà. Ñ ìîäåðíè óðåäè ñúâðåìåííàòà íàóêà å èç÷èñëèëà, ÷å ãîäèíàòà èìà 365,2422 äíè. Ìàèòå îùå â äðåâíîñòòà óñòàíîâÿâàò, ÷å òÿ èìà 365,2420 äíè. Ðàçëèêàòà å ìèíèìàëíà, êàòî ñå èìà ïðåäâèä, ÷å òå ïðîâåæäàëè íàáëþäåíèÿòà ñè îò êàìåííè îáñåðâàòîðèè. \r\n\r\nÌàèòå êàëêóëèðàò, ÷å êðàÿò íà íàøàòà åïîõà èäå íà 23 äåêåìâðè 2012 ãîäèíà.\r\n\r\nÑïîðåä òÿõ ñëåä ïîðåäíèÿ êàòàêëèçúì ùå íàñòúïè îáíîâëåíèå.\r\n\r\nÓ÷åíèòå ñìÿòàò îáà÷å, ÷å ïðåäñêàçàíèåòî íà äðåâíèòå àñòðîíîìè íÿìà äà ñå ñáúäíå. Çà ùàñòèå òå ùåäðî îòëàãàò êðàÿ íà ñâåòà çà ñëåä 5 ìèëèàðäà ãîäèíè.\r\n\r\nÒîãàâà Ñëúíöåòî ùå ñå ïðåâúðíå â ÷åðâåí ãèãàíò, êîéòî ùå èçïåïåëè Çåìÿòà è ùå ÿ ïðåâúðíå â ïîäîáèå íà Ìàðñ. \r\n\r\nÌåêñèêàíñêèÿò àñòðîíîì Àëôîíñî Àðåëÿíî, ïîòîìúê íà ìàèòå, ñúùî òâúðäè, ÷å íåãîâèòå äåäè íå ñà ïðàâè. Íà ïîñî÷åíàòà äàòà îáà÷å ùå ñå íàáëþäàâà íåîáèêíîâåíî êðàñèâî íåáåñíî ÿâëåíèå. Ùå ñòàíåì ñâèäåòåëè íà ñâîåîáðàçåí ïàðàä íà ïëàíåòèòå. Ìàðñ, Þïèòåð è Ñàòóðí ùå ñå ïîäðåäÿò íà åäíà ëèíèÿ è ùå îôîðìÿò îãðîìíà çâåçäà. Òàêà ùå çàïî÷íå íîâèÿò âåëèê öèêúë, ïðåäðå÷åí îò ìàèòå.\r\n\r\n[img]http://store.picbg.net/pubpic/EB/3F/aac509f9db50eb3f.jpg[/img]\r\n\r\n[size=4][color=yellow]Çà ïîâå÷å èíôîðìàöèÿ [/color][/size][url=http://skanaria.100webspace.net/details.php?id=0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1] [img]http://store.picbg.net/pubpic/C5/DF/68790b24500ac5df.gif[/img][/url]\r\n\r\n', 8, 1265230165);
INSERT INTO `posts` VALUES (14, 14, 8, 1265231515, '[size=3][color=orange]È ïî-òî÷íî – åâîëþöèÿ íà ñúçíàíèåòî! Íî íåêà êàæà íÿêîëêî íåùà ïðåäè òîâà…[/color][/size]\r\n\r\n[size=3][color=green]Öèâèëèçàöèÿòà íà äðåâíèòå ìàè, íàñåëÿâàëè íÿêîãà çåìèòå íà Öåíòðàëíà Àìåðèêà, ñå âîäè åäíà îò íàé-íàïðåäíàëèòå ïî îòíîøåíèå íà çíàíèÿòà çà âðåìåòî, à òåõíèÿò êàëåíäàð – íàé-òî÷íèÿò íà ïëàíåòàòà. Âêëþ÷âà ìíîãî âðåìåâè öèêëè îòíîñíî Âñåëåíàòà è Ñëúí÷åâàòà ñèñòåìà. Õðîíîëîãè÷íèòå èì ïîçíàíèÿ áèëè óäèâèòåëíè, êàòî íÿêîè îò òÿõ âñå îùå ïðåäñòîè äà ñå ðàçãàäàÿò.\r\n\r\nÊàêòî íÿêîè îò âàñ çíàÿò, âúïðîñòíèÿò êàëåíäàð èìà êðàé. Ò.å. ìîìåíò, â êîéòî ïðîñòî ñïèðà è íÿìà íèùî íàòàòúê. Ïðåäè âðåìå ÷åòîõ ìíîæåñòâî ñïåêóëàöèè ïî âúïðîñà, îò êîèòî íàé-èçâåñòíàòà áå, ÷å èäâà êðàÿò íà ñâåòà. Íå ñå èíòåðåñóâàõ äîïúëíèòåëíî, íî ñåãà îòíîâî ïèøà, çàùîòî ìè ïîïàäíà íåùî íîâî è èíòåðåñíî. \r\nÃëåäàõ òðè÷àñîâèÿò ôèëì íà ßí Ëóíãîëä (Ian Lungold) – „Êàëåíäàðà íà Ìàèòå – Åâîëþöèÿòà Ïðîäúëæàâà” (The Mayan Calendar – The Evolution Continues). À â êðàÿ ïèøåøå „Òîçè ôèëì íÿìà copyrights! Ìîëÿ ðàçïðîñòðàíÿâàéòå ñâîáîäíî è íàâñÿêúäå”.\r\n\r\nÅâîëþöèÿ íà ñúçíàíèåòî! Ñïîðåä êàëåíäàðà íà ìàèòå òÿ ïðîòè÷à íà öèêëè. Âúïðîñíèòå öèêëè ñà äåâåò íà áðîé è ñà ðàçêðèòè ñ ïîìîùòà íà àðõåîëîãè÷åñêà íàõîäêà (ñòúëá ñ íàäïèñè), êàòî êàëåíäàðúò å âå÷å ÷àñò îò îôèöèàëíàòà íàóêà.\r\n\r\nÌàèòå ðàçäåëÿò âñåêè åäèí îò òåçè öèêëè íà 13 ÷àñòè – 7 äíè è 6 íîùè (ñåäìèÿò íÿìà íîù, à âðåìåòðàåíåòî èì íå ñúâïàäà ñ íàøåòî). Âñÿêà „÷àñò” â öèêúëà áåëåæè íîâî ðàçâèòèå (ñêîê?) íà ñúçíàíèåòî. Çà ñðàâíåíèå ìîãà äà ïðåäëîæà ðàçëèêàòà ìåæäó ïîêîëåíèÿòà. Âñÿêî íîâî å íÿêàê ñè ïî-áúðçî âúçïðèåì÷èâî, îáðàáîòâàùî ïî-äîáðå èíôîðìàöèÿòà è ïðèëàãàùî ÿ â æèâîòà ïî-åôåêòèâíî (ðàçãðàíè÷åòå ñå îò èäèîò÷åòàòà, êîèòî âèíàãè ãè å èìàëî). \r\n\r\nÏî-ñúùèÿ íà÷èí å ðàçëèêàòà â ðàçâèòèåòî íà ðàçóìà ìåæäó îòäåëíèòå „÷àñòè” â öèêúëà. Äðóãî âàæíî å, ÷å ñïîðåä êàëåíäàðà âúâ âñåêè öèêúë ïðåç ïåòèÿò ìó äåí ñòàâà íåùî ìíîãî âàæíî è äîáðî, à íà ïåòàòà íîù íåùî ëîøî.\r\n\r\nÂñè÷êî èìà ñúçíàíèå! Ñåãà ùå îïèøà è ñàìèòå öèêëè, íî íÿìà äà å ìíîãî ïîäðîáíî. Öåëòà ìè å äà ñè ñúçäàäåòå íÿêàêâà èäåÿ çà êàêâî ñòàâà äóìà â òîçè êàëåíäàð. Ñúùî è äà äîïúëíÿ, ÷å â ìîìåíòà ñå íàìèðàìå êúì ñðåäàòà íà îñìèÿò „Ãàëàêòè÷åñêè” öèêúë, êîéòî å ïðåäïîñëåäåí. À åòî ãè è òÿõ:\r\n\r\nÖèêúë 1. “Êëåòú÷åí”\r\nÇàïî÷âà ïðåäè 16,4 ìèëèàðäà ãîäèíè ñúñ ñúáèòèåòî, êîåòî îôèöèàëíàòà íàóêà íàðè÷à “Ãîëåìèÿ âçðèâ” è å ñâúðçàí ñ ðàçâèòèåòî íà æèâîòà âúâ âèä íà îòäåëíè êëåòêè. Òîãàâà ñå çàðàæäà îñíîâíîòî ñúçíàíèå íà âñè÷êî è å íàðå÷åíî „Äåéñòâèå/Ðåàêöèÿ”, êîåòî ñúùî å îñíîâåí ôèçè÷åñêè çàêîí.\r\n* Âñÿêà åäíà îò òðèíàéñåòòå ÷àñòè â òîçè öèêúë å ñ ïðîäúëæèòåëíîñò îò îêîëî 1,26 ìèëèàðäà ãîäèíè. Âñè÷êî ñå ðàçâèâà ìíîãî áàâíî. Ïðåç ïåòèÿ „äåí” ñå ôîðìèðà ñëúí÷åâàòà ñèñòåìà, à ïðåç ïåòàòà „íîù” å ìåòåîðèòíàòà áîìáàðäèðîâêà âúðõó âñè÷êè ïëàíåòè è ëóíè (íàøàòà âñå îùå ñè ïàçè áåëåçèòå).\r\n\r\nÖèêúë 2. “Ìëåêîïèòàåùè”\r\nÇàïî÷âà ïðåäè 820 ìèëèîíà ãîäèíè êàòî å óñëîâíî íàðå÷åí òàêà, çàùîòî íàóêàòà äíåñ îïðåäåëÿ ïðèáëèçèòåëíî òîçè ïåðèîä çà íà÷àëî íà îáåäèíÿâàíåòî íà îòäåëíèòå êëåòêè â ïî-ñëîæíè îðãàíèçìè è ñïåöèàëèçàöèÿòà íà îòäåëíèòå êëåòêè â èçâúðøâàíåòî íà òî÷íî îïðåäåëåíà ôóíêöèÿ. Ñúçíàíèåòî åâîëþèðà â „Ñòèìóë/Îòãîâîð”, êîåòî å ïî-ñëîæíî îò ãîðíîòî.\r\n* Âñÿêà åäíà îò òðèíàéñåòòå ÷àñòè â òîçè öèêúë å ñ ïðîäúëæèòåëíîñò îò îêîëî 63,4 ìèëèîíà ãîäèíè. Ïðåç ïåòèÿ „äåí” æèâîòà åâîëþèðà è èçëèçà èçâúí âîäàòà íà ñóøàòà, à ïðåç ïåòàòà „íîù” 97% îò æèâîòà íà ïëàíåòàòà å èçòðåáåí.\r\n\r\nÖèêúë 3. “Ñåìåéñòâî”\r\nÇàïî÷âà ïðåäè 41 ìèëèîíà ãîäèíè è å íàðè÷àí òàêà, çàùîòî å å ñâúðçàí îñíîâíî ñ îáîñîáÿâàíåòî íà îòäåëíèÿ èíäèâèä îò îáùíîñòòà. Òîãàâà ñå ïîÿâÿâàò è ìàéìóíèòå. Ñúçíàíèåòî åâîëþèðà â „Ñòèìóë/Èíäèâèäóàëåí Îòãîâîð”. Òî çâó÷è ïîäîáíî íà ãîðíîòî, íî êàêâà å ðàçëèêàòà ìåæäó òúëïà è ñåìåéñòâî? Èíäèâèäóàëíîñòòà! Äà, ðàçëèêàòà â ñúçíàíèÿòà å îãðîìíà. Íàïðèìåð ñòå èìàëè ìîìåíòè, êîãàòî ñå ÷óâñòâàòå íàèñòèíà ïðåêðàñíî äà.. áúäåòå ñåáå ñè! Ñúùî ñòå èìàëè è ìîìåíòè, êîãàòî ñòå ñå ÷óâñòâàëè ÷àñò îò òúëïàòà – êîãàòî ñòå åäèí îò õèëÿäèòå ïî òðóáóíèòå íà ñïîðòíî ñúáèòèå èëè ïúê íà äúëãàòà îïàøêà â ìàãàçèíà. Çàìèñëåòå ñå êàêâî âè å áèëî ñúçíàíèåòî â ðàçëè÷íèòå ñèòóàöèè. Êàê ñòå ñå ÷óâñòàëè â åäèíèÿ è äðóãèÿ ìîìåíò? Ðàçëèêàòà å ãîëÿìà :) Öåëèÿ òîçè ïåðèîä îò 41 ìèëèîí ãîäèíè å ïîìîãíàë íà ñúçíàíèåòî äà ñå ñâúðçâà ñ äðóãè è äà ñè ñúçäàâà âçàèìîîòíîøåíèÿ.\r\n* Âñÿêà åäíà îò òðèíàéñåòòå ÷àñòè â òîçè öèêúë å ñ ïðîäúëæèòåëíîñò îò îêîëî 3,2 ìèëèîíà ãîäèíè. Ïðåç ïåòèÿ „äåí” æèâîòà îòíîâî åâîëþèðà íà ïî-âèñîêî ðàâíèùå, ïîÿâÿâà ñå öâåòíîòî çðåíèå (”color vision” òðÿáâà äà å òîâà, íàëè?), à ïðåç ïåòàòà „íîù” íà òîçè öèêúë âñå îùå íå å ÿñíî òî÷íî êàêâî å ñòàíàëî.\r\n\r\nÖèêúë 4. “Ïëåìåíåí” (îò ïëåìå)\r\nÇàïî÷âà ïðåäè 2 ìèëèîíà ãîäèíè, êîãàòî çà ïúðâè ïúò ñå ïîÿâÿâà ïëåìåòî. Ñúçíàíèåòî åâîëþèðà â „Ïðèëèêè/Ðàçëèêè”. Äîêàòî ïðåç âòîðèÿ öèêúë ñå ðàçâèâà ìîçúêà, ïðåç òðåòèÿ òîé ñå ðàçøèðÿâà/óâåëè÷àâà, òî â òîçè ÷åòâúðòè öèêúë ñå ðàçâèâà ðàçóìà. Òîâà äà âèæäàìå ïðèëèêè è ðàçëèêè, êàêòî è ñïîñîáíîñòòà äà âçåìàìå ðåøåíèÿ îòíîñíî ðàçëè÷íè íåùà, à íå ñàìî âúçìîæíîñòòà çà ðåàêöèÿ. Òîâà å îãðîìíà ñòúïêà íàïðåä â ñúçíàíèåòî.\r\n* Ïðåç ïåòèÿ „äåí” ÷îâåêúò îòêðèâà îãúíÿ, à ïðåç ïåòàòà „íîù” å áèë ëåäíèêîâèÿ ïåðèîä. Äîáðå ÷å ñà èìàëè îãúí, íàëè? ;) Ñúçíàíèåòî âèíàãè íè „äîñòàâÿ” íóæíèòå íåùà çà äà ìîæåì ïðîäúëæèì êúì ñëåäâàùàòà ñòúïêà.\r\n\r\nÖèêúë 5. „Êóëòóðåí” (îò êóëòóðà)\r\nÏåòèÿ åòàï íà ðàçâèòèå å çàïî÷íàë ïðåäè 102 õèëÿäè ãîäèíè. Òîãàâà âñå îùå ñìå æèâÿëè â ïåùåðèòå, íî çà ïúðâè ïúò ñå å ïîÿâèëà êóëòóðàòà. Íÿêúäå òî÷íî â íà÷àëîòî íà òîçè öèêúë ñìå çàïî÷íàëè äà ñè ãîâîðèì åäèí íà äðóã. Ñúçíàíèåòî åâîëþèðà â „Ïðè÷èíè”. À èìåííî – ïðè÷èíèòå çàùî íåùàòà ñà òàêèâà êàêâèòî ñà. Â ìèíàëèÿ ïåðèîä ñúçíàíèåòî ñå íàó÷è äà âçåìà ðåøåíèÿ, à â òîçè òî çàïî÷âà äà ðàçáèðà è ïðè÷èíèòå.\r\n* Ïðåç ïåòèÿ „äåí” ñå ïîÿâÿâà èçêóñòâîòî, à ïðåç ïåòàòà „íîù” òî å ñÿêàø íà çàäåí ïëàí. Èçêóñòâîòî å âúîáðàæåíèå è äîêàòî ïðåç „äåíÿ” õîðàòà ñà ãî èìàëè, ïðåç „íîùà” ñëåäâàùèòå ñà ãî íÿìàëè. Áèëî å òúìíà åðà çà èçêóñòâîòî.\r\n\r\nÖèêúë 6. „Íàöèîíàëåí”\r\nÇàïî÷âà ïðåç 3115 ãîäèíà ïðåäè íîâàòà åðà, êîãàòî çà ïúðâè ïúò Ãîðåí Åãèïåò ñå îáåäèíÿâà ñ Äîëåí Åãèïåò è ñå ôîðìèðà ïúðâàòà íàöèÿ íà Çåìÿòà. Ïî ñúùîòî âðåìå çà ïúðâè ïúò ñå ïîÿâÿâà è ïèñìåíîñòòà. Ñúçíàíèåòî åâîëþèðà â „Çàêîí”. È êàê íÿìà.. òî îïðåäåëåíî âå÷å å ïðåìèíàëî ïðåç „Ïðè÷èíè”. Âñåêè ÷îâåê ïåðñîíàëíî å äëúæåí äà ïîçíàâà âñåêè îò çàêîíèòå. Íåçíàíèåòî íå å èçâèíåíèå.\r\n* Ïðåç ïåòèÿ „äåí” ïîñëàíèåòî íà Èñóñ Õðèñòîñ „îáèêàëÿ” öÿëàòà ïëàíåòà, à ïðåç ïåòàòà „íîù” Ðèì ïàäà è çà Åâðîïà çàïî÷âàò 1000 ãîäèíè ìðàê. È íå ïîðàäè êàêâî äà å, à çàùîòî ñàìîòî ñúçíàíèå ñå å ïðîìåíèëî.\r\n\r\nÖèêúë 7. „Ïëàíåòàðåí”\r\nÇàïî÷âà ïðåç 1752 ã. è ñå íàðè÷à òàêà, çàùîòî ïî òîâà âðåìå ÷îâå÷åñòâîòî îñúçíàâà, ÷å îáèòàâà ïëàíåòà ñ êúëáîâèäíà ôîðìà. Òîâà å è ïåðèîäà íà çàïî÷âàíå íà èíäóñòðèàëíàòà ðåâîëþöèÿ. Ñúçíàíèåòî åâîëþèðà â „Ñèëà”. Â öåëèÿ òîçè öèêúë ñòàâà äóìà çà ñúçäàâàíåòî è óêðåïâàíåòî íà ìîù/ñèëà/âëàñò. Çàáåëÿçàëè ëè ñòå, ÷å èìà ìíîãî òàêàâà íàñúáðàíàòà â ìàëúê áðîé õîðà? Âåðîÿòíî òîâà íå âè õàðåñâà, íî òî å íîðìàëíî ñïîðåä êàëåíäàðà íà ìàèòå. Äîðè è Ñâåòîâíàòà Òúðãîâñêà Îðãàíèàçàöèÿ å âèä ïðîÿâëåíèå íà òîâà ñúçíàíèå, çà äà ñå óêðåïâà òàçè ñèëà/âëàñò, äà ÿ ôîêóñèðà. Õîðàòà „ãîðå” íå îñúçíàâàò, ÷å òîâà å ÷àñò îò åâîëþöèÿòà çà ðàçâèòèå íà ñúçíàíèåòî.. òå ìèñëÿò ñàìî çà ãîëåìèòå ñè áàíêîâè ñìåòêè :)\r\n* Ïðåç ïåòèÿ „äåí” ðàçáèðàìå, ÷å å=mc2, êàêòî è ãîñïîäèí Õàáúë îòêðèâà, ÷å æèâååì â áåçêðàéíà âñåëåíà, êúäåòî âñè÷êî å âúçìîæíî. Ïåòàòà “íîù” – âòîðàòà ñâåòîâíà âîéíà.\r\n\r\nÖèêúë 8. „Ãàëàêòè÷åñêè”\r\nÇàïî÷âàë å íà 5 ÿíóàðè 1999 ã. è ùå ïðîäúëæè äî 10 ôåâðóàðè 2011 ãîäèíà. Â òîçè ïåðèîä òðèíàéñåòòå åòàïà/÷àñòè ñà ñ ïðîäúëæèòåëíîñò îò ïî 360 äíè. Ñúçíàíèåòî åâîëþèðà â „Åòèêà”. Åòèêàòà å ðàçëè÷íà îò ìîðàëà – òÿ èäâà îòâúòðå, îò ñúðöåòî òè. Òÿ òè êàçâà êîå å ïðàâèëíî è êîå å ãðåøíî. Ìîðàëà îò äðóãà ñòðàíà å „ïðè÷èíè”. Ïðè÷èíè, êîèòî ñ âðåìåòî è êóëòóðàòà îáîñîáÿâàò „ïðàâèëíèòå è ãðåøíèòå” íåùà. Íåùî ðàçëè÷íî îò åòèêàòà. Äîêàòî ìîðàëà èäâà îòâúí è òå çàòðóïâà, åòèêàòà å â òåá ñàìèÿò. Öåëèÿò öèêúë å çà íåÿ è çà öÿëîñòòà (èíòåãðèòåò). Òå ñà òàêà äà ñå êàæå „íîâèíàòà íà äåíÿ”. Êàòî ñå îãëåäàòå êàêâî ñòàâà ïî ñâåòà íå ñòå ìíîãî äîâîëíè, íàëè? Âîéíè, òðàãåäèè è âñÿêàêâè ãðîçíè íåùà. Òîâà, êîåòî âñúùíîñò âèæäàòå å åäèí ñáëúñúê ìåæäó ñúçíàíèåòî íà „Ñèëàòà” ñúñ ñúçíàíèåòî íà „Åòèêàòà”. Òî÷íî êàêòî âúâ âñåêè åäèí îò ìèíàëèòå öèêëè – íîâîòî èäâàùî ñúçíàíèå äîìèíèðà íàä ïðåäèøíîòî è äå ôàêòî òîâà ñòàâà ïðåç ïåòèÿ „äåí” îò âñåêè öèêúë. Òîãàâà íîâîòî âçåìà íàäìîùèå íàä äîñåãàøíîòî. Çàáåëåæåòå ñúùî, ÷å íå ìîæå äà èìàòå åòèêà, àêî ïðåäè òîâà íÿìàòå íÿêàêâà ñèëà/âëàñò. Íàïðèìåð, àêî áÿãàòå çà äà ñè ñïàñèòå æèâîòà… åòè÷íîñòòà ùå å ïîñëåäíîòî íåùî, êîåòî ùå èìàòå. Íî êîãàòî ñòå íà „òâúðäà ïî÷âà” – òîãàâà ìîæå äà çàïî÷íåòå äà ñè ñúçäàâàòå åäíà öÿëîñò, ïðåäñòàâëÿâàùà åòèêà. Òî÷íî è çà òîâà ñúçíàíèåòî å òðÿáâàëî äà ïðåäîñòàâè ïúðâî „ñèëàòà”.\r\n* Ïåòèÿò „äåí” íà òîçè öèêúë çàïî÷âà ïðèáëèçèòåëíî îò 24 íîåìâðè 2006 è å äî 18 íîåìâðè 2007. Òîâà, êîåòî áè òðÿáâàëî äà ñòàíå â òîçè ïåðèîä, å äà ñå çàïîçíàåì ñ íàøèòå „ãàëàêòè÷åñêè ñúñåäè”. Ïëþñ âñè÷êèòå ìó òàì ïðåêðàñíè íîâè òåõíîëîãèè.\r\n\r\nÖèêúë 9. „Óíèâåðñàëíî ñúçíàíèå”\r\nÄåâåòèÿò öèêúë çàïî÷âà îò 10 ôåâðóàðè 2011 ã. è ùå ïðîäúëæè äî 28 íîåìâðè 2011 ã. Ñúñòîè ñå ñàìî îò 260 äíè, êàòî âñÿêà îò òðèíàéñåòòå ìó „÷àñòè” ùå å ïî 20 äåíà. Òîâà å ïî÷òè 20 ïúòè ïî-áúðçî îò ïðåäíèÿ öèêúë. Ðàçâèòèåòî íà åâîëþöèÿòà óâåëè÷àâà ñêîðîñòòà ñè íåïðåêúñíàòî! Â îñìèÿò öèêúë, â êîéòî ñå íàìèðàìå â ìîìåíòà, âñÿêà ÷àñò å ñ ïðîäúëæèòåëíîñò îò 360 äíè. Ñòàâàò âñå ïîâå÷å íåùà çà âñå ïî-ìàëêî âðåìå! Íÿìàòå ëè è âèå óñåùàíåòî, ÷å âðåìåòî ñÿêàø ëåòè? Ñåãà çíàåòå, ÷å íå å òàêà. Ïðîöåñà íà åâîëþöèÿ íà ñúçíàíèåòî ëåòè! È êîëêîòî ïîâå÷å íåùà ñå ñëó÷âàò òîëêîâà ïîâå÷å âúçìîæíîñòè ñå îòâàðÿò. Òîâà â åäèí ìîìåíò ùå äîâåäå è äî âúçìîæíîñò äà ïðàâèì òàêà íàðå÷åíèòå „÷óäåñà”.\r\n\r\nÈìà è åäèí ïðîáëåìåí ìîìåíò. Ñúçíàíèåòî íè ìîæå äà îáðàáîòè ìàêñèìóì 24 ìèñëè â ñåêóíäà, çàòîâà ôèëìèòå ñà íà 24 êàäúðà ïðèìåðíî. Òîâà „çàáúðçâàíå” íà ñúçíàíèåòî ùå äîâåäå äî ïî-ãîëÿì ñòðåñ ñ íàñòúïâàíåòî íà âñå ïîâå÷å „ïðîìåíè” îêîëî íàñ. Ïîâå÷åòî õîðà ñà ñå íàó÷èëè äà ñå àäàïòèðàò êúì íåãî, íî íå âñè÷êè.\r\n\r\nÑúçíàíèåòî íà òîçè öèêúë åâîëþèðà â „Ñúçíàòåëíî îáåäèíåíî ñúòâîðåíèå”. Òî÷íî çà íåãî å è öÿëàòà òàçè åâîëþöèÿ ïðåç ìèëèàðäèòå ãîäèíè – âñè÷êèòå öèêëè, ñúáèòèÿ è ò.í. Òîâà å âðåìåòî íà ïðèäîáèâàíå íà àáñîëþòíîòî è íåîãðàíè÷åíî ñúçíàíèå, íà áåçãðàíè÷íèòå âúçìîæíîñòè. Òîâà å è âåðîÿòíî ìîìåíòà, â êîéòî âñè÷êè „çàêëþ÷åíè” îáëàñòè íà ìîçúêà ùå ñå îòêëþ÷àò. Ùå ïîëçâàìå íå 3-10% îò íåãî, à ïúëíèòå 100%. Òî÷íî è çàòîâà ñìå òóê – äà äîñòèãíåì äî òîâà íèâî.\r\n\r\nÂåðîÿòíî ñè çàäàâàòå âúïðîñà „àêî íàèñòèíà å òàêà.. êàêâî òðÿáâà äà íàïðàâÿ çà äà äîñòèãíà äî òîâà íèâî íà ñúçíàíèå?”. Îòãîâîðà å ïðîñò – íèùî! Â ñìèñúë, ÷å íå âè òðÿáâà äà êóïóâàòå íèùî, íå âè òðÿáâà íàó÷èòå íåùî îïðåäåëåíî, íå âè òðÿáâà äà ìåäèòèðàòå.. íàêðàòêî íå òðÿáâà äà ïðàâèòå íèùî êîíêðåòíî, îñâåí ñúçíàòåëíî äà ó÷àâñòâàòå â òîçè ïðîöåñ íà îòâàðÿíå íà ïîâå÷å âúçìîæíîñòòè.\r\n\r\nÒîâà å âñè÷êî, êîåòî ñå èñêà îò íàñ ñïîðåä ìàèòå. Íå çíàì çà âàñ, íî àç ñå íàäÿâàì äà ñà ïðàâè ;)[/color][/size]', 8, 1265231580);
INSERT INTO `posts` VALUES (15, 15, 8, 1265826891, '[center][size=5][color=blue]ÍÀÑÒÐÎÉÊÈ ÍÀ AVAST! HOME/PRO 4.X.XXX – ÎÑÍÎÂÍÈ ÍÀÑÒÐÎÉÊÈ[/color][/size][/center]\r\n\r\n\r\n  Â òàçè ñòàòèÿ ùå ñå çàïîçíàåì ïîäðîáíî ñ îñíîâíèòå íàñòðîéêè íà avast! Home/Pro . È òàêà, äà çàïî÷âàìå – èìàòå íÿêîëêî âúçìîæíîñòè çà äîñòúï äî íàñòðîéêèòå íà ïðîãðàìàòà: ïúðâèÿò å ÷ðåç ìåíþòî íà Îáèêíîâåíèÿ Ïîòðåáèòåëñêè Èíòåðôåéñ (Ìåíþ - Íàñòðîéêè... ); âòîðèÿò å ÷ðåç ìåíþòî íà Ïîäðîáíèÿ Ïîòðåáèòåëñêè Èíòåðôåéñ (òîâà âàæè ñàìî çà Pro âåðñèÿòà - Ôàéë - Íàñòðîéêè...); è ïîñëåäíèÿò å ÷ðåç ìåíþòî íà ðåçèäåíòíàòà çàùèòà ( äåñåí áóòîí âúðõó èêîíàòà ñ áóêâàòà „à” â ñèñòåìíèÿ òðåé è ñëåä òîâà èçáèðàòå „Íàñòðîéêè íà ïðîãðàìà…” ).\r\n\r\n    Îñíîâíèÿò ïðîçîðåö ñ íàñòðîéêèòå å ðàçäåëåí íà íÿêîëêî ðàçäåëà, âñåêè îò êîèòî ñúäúðæà ïî íÿêîëêî îñíîâíè íàñòðîéêè. Ïúðâèÿò ðàçäåë, ñ êîéòî ùå ñå çàïîçíàåì å „Îáùè” íàñòðîéêè.\r\n\r\n[img]http://store.picbg.net/pubpic/63/36/fdb934d3e9026336.jpg[/img]\r\n\r\nÅòî è çíà÷åíèåòî íà âñÿêà åäíà îò íàñòðîéêèòå:\r\n\r\nÏðîâåðÿâàé ïàìåòòà ïðè ñòàðòèðàíå íà ïðîãðàìàòà - êîãàòî avast! ñå ñòàðòèðà ïðîâåðÿâà RAM ïàìåòòà çà âèðóñè. Àêî èñêàòå ìîæåòå äà èçêëþ÷èòå òàçè îïöèÿ, êîåòî ùå óñêîðè ñòàðòèðàíåòî íà ïðîãðàìàòà, íî è ùå íàìàëè øàíñîâåòå çà îòêðèâàíå íà âèðóñ â ïàìåòòà íà êîìïþòúðà, ïðåäè äà ñòàíå îïàñåí(ðàçðóøèòåëåí). Òàêà, ÷å å ïî-äîáðå äà îñòàâèòå òàçè íàñòðîéêà âêëþ÷åíà.\r\n\r\nÏðîâåðÿâàé äèñêåòèòå âúâ ôëîïèòî ïðè èçëèçàíå îò Windows - avast! íÿìà äà ðàçðåøè íà êîìïþòúðà äà ñå èçêëþ÷è èëè ðåñòàðòèðà àêî âúâ ôëîïèòî èìà äèñêåòà. Òîâà å çàùèòà ïðîòèâ áóóò âèðóñè.\r\n\r\nÏðîâåðÿâàé ÑÄ-òàòà ïðè èçëèçàíå îò Windows - èìà ñúùîòî äåéñòâèå êàêòî ïðè äèñêåòèòå.\r\n\r\nÏðîâåðÿâàé äðóãè ìîáèëíè ìåäèè ïðè èçëèçàíå îò Windows - èìà ñúùîòî äåéñòâèå êàêòî ïðè ïðåäíèòå äâå îïöèè. Ùå áúäàò ïðîâåðÿâàíè ïðåíîñèìè ìåäèè, íàïðèìåð ZIP óñòðîéñòâà è äð.\r\n\r\nÏîëçâàé êîæè çà Ðàçøèðåíèÿòà íà Åêñïëîðåðà - èçïîëçâàéêè òàçè îïöèÿ îêàçâàòå êàê äà áúäàò "äåêîðèðàíè" ïðîçîðöèòå íà Ðàçøèðåíèÿòà íà Åêñïëîðåðà, ïî ñòàíäàðòíèÿ íà÷èí (Windows) èëè ùå áúäå èçïîëçâàíà "äåêîðàöèÿòà" íà êîæàòà. Èçêëþ÷âàéêè òàçè îïöèÿ ìîæåòå äà óñêîðèòå èíèöèàëèçàöèÿòà íà áúðçèÿ ñêåíåð.\r\n\r\nÈçëåç îò Ðàçøèðåíèåòî íà Åêñïëîðåðà ïðè îòêðèâàíå íà âèðóñ - àêî èçïîëçâàòå áúðçèÿ ñêåíåð çà ïðîâåðêà íà íÿêîëêî ôàéëà, ïðîâåðêàòà ùå ñïðå ïðè îòêðèâàíåòî íà ïúðâèÿ âèðóñ. Àêî òàçè îïöèÿ å èçêëþ÷åíà, ùå áúäàò ïðîâåðåíè âñè÷êè ôàéëîâå. Ïðåïîðú÷èòåëíî å òàçè îïöèÿ äà áúäå èçêëþ÷åíà.\r\n\r\nÏîêàçâàé ðåçóëòàòè îò Ðàçøèðåíèåòî íà Åêñïëîðåðà - êîãàòî èçïîëçâàòå áúðçèÿ ñêåíåð, ùå áúäàò ïîêàçàíè ðåçóëòàòè äîðè è äà íå áúäå îòêðèò âèðóñ. Îñòàâåòå òàçè íàñòðîéêà âêëþ÷åíà.\r\n\r\nÏîêàçâàé èêîíàòà íà Explorer ðàçøèðåíèåòî - àêî òàçè îïöèÿ å îòáåëÿçàíà, ùå áúäå ïîêàçâàíà ìàëêà èêîíà äî òàçè íà avast!(â òðåé ìåíþòî) ïðè ìèíèìàëèçèðàíåòî íà áúðçèÿ ñêåíåð.\r\n\r\n \r\n\r\nÑëåäâà êàòåãîðèÿòà „Èçãëåä”\r\n\r\n[img]http://store.picbg.net/pubpic/95/75/f837105029809575.jpg[/img]\r\n\r\nÅòî è îïèñàíèå íà âñÿêà íàñòðîéêà:\r\n\r\nÏîêàçâàé èêîíàòà íà avast! â òðåÿ. Ñèíÿ èêîíà ñ áóêâàòà "a" ùå áúäå ïîêàçàíà â ñèñòåìíèÿ òðåé (äî ÷àñîâíèêà), îòðàçÿâàéêè ñòàòóñà íà avast! antivirus. Ïðåïîðú÷èòåëíî å òàçè îïöèÿ äà áúäå âêëþ÷åíà, çà äà èìàòå íàáëþäåíèå çà ðàáîòàòà íà ïðîãðàìàòà.\r\n\r\nÀíèìèðàíà èêîíà ïðè ñêàíèðàíå. Íåçàâèñèìî êàêâî äåéñòâèå ñå èçâúðøâà îò ðåçèäåíòíàòà çàùèòà íà avast! (ïðèìåðíî ïðîâåðÿâàíå íà åë. ïîùà, îòâàðÿíå íà ôàéë íà äèñêà, îòâàðÿíå íà èíòåðíåò ñòðàíèöà), èêîíàòà ùå ñå âúðòè, çà äà ïîêàçâà àêòèâíîñòòà íà avast!.\r\n\r\nÏîëçâàé ïîëóïðîçðà÷íè åôåêòè. Òàçè îïöèÿ (äîñòúïíà ïðè Windows 2000 èëè ïî-íîâ) ùå âêëþ÷è ñïåöèàëíèòå âèçóàëíè åôåêòè â Îáèêíîâåíèÿ Ïîòðåáèòåëñêè Èíòåðôåéñ. È ïî-òî÷íî òàçè îïöèÿ àêòèâèðà ïðîçðà÷íèòå åôåêòè â èíòåðôåéñà íà ïðîãðàìàòà, íàèñòèíà òîâà ïðàâè èíòåðôåéñà îùå ïî-õóáàâ, íî ïðè ïî-ñëàáè ìàøèíè ìîæå è äà ïðè÷èíè çàáàâÿíå, òàêà ÷å ïî-äîáðå äà îñòàâèòå òàçè îïöèÿ èçêëþ÷åía.\r\n\r\nÑëåäâà êàòåãîðèÿòà „Êëåòêà”\r\n\r\n[img]http://store.picbg.net/pubpic/8D/EE/4a0ad0435ad88dee.jpg[/img]\r\n\r\nÍà òàçè ñòðàíèöà ìîæåòå äà çàäàäåòå íÿêîè ïàðàìåòðè îòíàñÿùè ñå äî Êëåòêàòà çà Âèðóñè:\r\n\r\nÌàêñèìàëåí ðàçìåð íà Êëåòêàòà – òóê çàäàâàòå êàêâî äà áúäå ìàêñèìàëíîòî ïðîñòðàíñòâî, êîåòî ùå ìîæå äà ñå èçïîëçâà îò êëåòêàòà, çà äà çàïàìåòÿâà ïðàòåíèòå â íåÿ ôàéëîâå. Èìàéòå ïðåäâèä, ÷å àêî çàäàäåòå ïðåêàëåíî ìàëúê ðàçìåð, Êëåòêàòà ùå ñå íàïúëíè áúðçî è ñëåä êàòî ñå íàïúëíè íÿìà äà ìîæåòå äà ïðàùàòå ïîâå÷å ôàéëîâå òàì, çàòîâà ïî-äîáðå îñòàâàòå íàñòðîéêàòà êàêòî ñè å ïî ïîäðàçáèðàíå.\r\n\r\nÌàêñèìàëåí ðàçìåð çà ïðàùàíå – òóê çàäàâàòå ìàêñèìàëíèÿò ðàçìåð íà ôàéëà , êîéòî äà ìîæå äà áúäå èçïðàùàí çà àíàëèçèðàíå äî Alwil Software.\r\n\r\nÑëåäâà êàòåãîðèÿòà „Ïîòâúðæäåíèÿ”\r\n\r\n[img]http://store.picbg.net/pubpic/44/20/7c6797d0c31d4420.jpg[/img]\r\n\r\nÒóê ìîæåòå äà îòáåëåæèòå êàêâè ïðåäóïðåæäåíèÿ äà áúäàò ïîêàçâàíè ïî âðåìå íà ðàáîòàòà íà ïðîãðàìàòà. Ïðåïîðú÷èòåëíî å íà÷èíàåùèòå ïîòðåáèòåëè äà íå èçêëþ÷âàò íèòî åäíî îò ïðåäóïðåæäåíèÿòà.\r\n\r\nÑëåä òîâà èäâà ðåä íà êàòåãîðèÿòà „Åçèê” \r\n\r\n[img]http://store.picbg.net/pubpic/23/0C/91f533a567e0230c.jpg[/img]\r\n\r\nÒóê, ìîæåòå äà èíñòàëèðàòå è äà ïðåìàõâàòå äîïúëíèòåëíèòå åçèêîâè ïàêåòè. Âàæíî å äà çíàåòå, ÷å ïðè èíñòàëàöèÿ íà íîâ åçèê ñå èçèñêâà àêòèâíà èíòåðíåò âðúçêà.\r\n\r\nÊàòåãîðèÿòà „Çâóöè”\r\n\r\n[img]http://store.picbg.net/pubpic/9C/B6/67d24d6121709cb6.jpg[/img]\r\n\r\nÂ íÿêîè ñëó÷àè, çà äà âè èíôîðìèðà çà íåæî àvast! Èçïîëçâà çâóêîâè ñèãíàëè, îò òîçè ðàçäåë íà íàñòðîéêèòå ìîæåòå äà ïðîìåíèòå òåçè çâóöè ÷ðåç áóòîíà „Íàñòðîéêè…”. Ñúùî òàêà èìàòå âúçìîæíîñò è íàïúëíî äà ñïðåòå çâóöèòå êàòî îòáåëåæèòå íàñòðîéêàòà „Ñïðè ïîëçâàíåòî íà çâóöè îò avast!” . Äîïúëíèòåëíè çâóöè ìîæåòå äà èçòåãëèòå îò êàòåãîðèÿòà „Èçòåãëåòå avast! è…” íà ñàéòà.\r\n\r\nÊàòåãîðèÿòà „Âîäåíå íà äíåâíèê”\r\n\r\n[img]http://store.picbg.net/pubpic/AD/AA/67e99ee943f8adaa.jpg[/img]\r\n\r\nÏî âðåìå íà ðîáàòàòà ñè ïðîãðàìàòà ñúçäàâà ôàéëîâå ñ èíôîðìàöèÿ çà äåéñòâèÿòà ñè – äíåâíèê. Òóê ìîæåòå äà çàäàäåòå çà êîè âèäîâå ñúáèòèÿ äà áúäå ñúáèðàíà (çàïèñâàíà) èíôîðìàöèÿ â äíåâíèêà. Èìàòå âúçìîæíîñò è äà çàäàâàòå ëèìèò íà äíåâíèêà.\r\n\r\nÊàòåãîðèÿòà „Èçêëþ÷åíèÿ”\r\n\r\n[img]http://store.picbg.net/pubpic/D1/94/a04091c9a3d8d194.jpg[/img]\r\n\r\nÒóê èìàòå âúçìîæíîñò äà çàäàäåòå êîè ôîéëîâå/ïàïêè äà ÍÅ áúäàò ïðîâåðÿâàíè îò ïðîãðàìàòà. Òàçè îïöèÿ å ïîëåçíà êîãàòî íàïðèìåð èìàòå ïàïêà, êîÿòî èçïîëçâàòå ñàìî çà çàïèñâàíå, íàïðèìåð íà ñíèìêè – ïî òîçè íà÷èí ïðîãðàìàòà ùå ïðåñêî÷è òàçè ïàïêà è òîâà ùå ñå îòðàçè ïîëîæèòåëíî íà âðåìåòî çà ïðîâåðêà (òîåñò âðåìåòî çà ïðîâåðêà ùå íàìàëåå).\r\n\r\n            Ñúùî òàêà òàçè íàñòðîéêà å ïîëåçíà è â ñëó÷àéòå, êîãàòî ïðîãðàìàòà âè äàâà ãðåøíà àëàðìà – äîáàâàéêè ãðåøíî îòêðèòèÿ ôàéë òîé íÿìà äà áúäå ïðîâåðÿâàí. Ñúùî òàêà àêî ïîïàäíåòå íà òàêàâà „ãðåøíà òðåâîãà” ìîæåòå äà èçïðàòèòå ôàéëà íà Alwil Software , çà äà ìîãàò äà ïîïðàâÿò ãðåøíàòà àëàðìà (êàê ñòàâà òîâà ìîæåòå äà ïðîâåðèòå âúâ ôîðóìà íà ñàéòà).\r\n            \r\n\r\nÂàæíî å äà ñå îòáåëåæè, ÷å òîçè ñïèñúê ñ èçêëþ÷åíèÿ âàæè çà âñè÷êè êîìïîíåíòè íà ïðîãðàìàòà.\r\n\r\nÊàòåãîðèÿòà „Îáíîâÿâàíå (Ïðîñòî)”\r\n\r\n[img]http://store.picbg.net/pubpic/5E/DC/d0441f9b34cc5edc.jpg[/img]\r\n\r\nÒóê çàäàâàòå íàñòðîéêèòå çà îáíîâÿâàíåòî íà ïðîãðàìàòà. Èìàòå âúçìîæíîñò äà çàäàäåòå íàñòðîéêèòå çà îáíîâÿâàíå íà âèðóñíàòà áàçà äàííè è çà îáíîâÿâàíåòî íà ñàìàòà ïðîãðàìà. Åòî è ïðèíöèïà íà âñåêè åäèí îò òðèòå âèäà íàñòðîéêè:\r\n\r\nÀâòîìàòè÷íî. Òàçè îïöèÿ âè ïîäñèãóðÿâà, ÷å âàøàòà âèðóñíà ÁÄ èëè ïðîãðàìà ùå áúäå âèíàãè îáíîâåíà. Âñåêè ïúò, êîãàòî ñå ñâúðæåòå ñ èíòåðíåò, avast! ïðîâåðÿâà äàëè âàøàòà âèðóñíà ÁÄ èëè ïðîãðàìà å ïî-ñòàðà îò òàçè äîñòúïíà íà ñúðâúðà. Àêî òå ñà ðàçëè÷íè, ïðîãðàìàòà èçòåãëÿ ëèïñâàùàòà ÷àñò îò èíôîðìàöèÿòà íà âàøèÿ êîìïþòúð.\r\n\r\nÏèòàé êîãàòî èìà íîâà âåðñèÿ. Ïðèíöèïúò å ñúùèÿò êàêòî ïðè ïðåäíèÿ ñëó÷àé, íî îáíîâëåíèåòî íÿìà äà çàïî÷íå àâòîìàòè÷íî; ùå áúäåòå óâåäîìåíè ñàìî, ÷å èìà íîâà âåðñèÿ, è ùå çàâèñè èçöÿëî îò âàñ, äàëè ùå èçòåãëèòå îáíîâëåíèåòî âåäíàãà èëè ïî-êúñíî. Ïî ïîäðàçáèðàíå å èçáðàíà òàçè îïöèÿ.\r\n\r\nÐú÷íî. Îáíîâëåíèåòî íÿìà äà áúäå àâòîìàòèçèðàíî è âèå ùå òðÿáâà ðú÷íî äà èçâúðøâàòå îáíîâÿâàíèÿòà.\r\n\r\nÏðåïîðú÷èòåëíî å äâåòå íàñòðîéêè äà ñà íà „Àâòîìàòè÷íî”\r\n\r\n×ðåç áóòîíà „Ïîäðîáíî…” èìàòå âúçìîæíîñò è çà ïî-äåòàéëíè íàñòðîèêè. \r\n\r\n[img]http://store.picbg.net/pubpic/0C/C3/0e3382b909290cc3.jpg[/img]\r\n\r\nÐåæèì íà ðàáîòà. Òàçè îïöèÿ êîíòðîëèðà ïîâåäåíèåòî íà ðú÷íèòå îáíîâÿâàíèÿ. Àâòîìàòè÷íèòå îáíîâÿâàíèÿ ñà âèíàãè "òèõè".\r\n\r\nÍîðìàëåí. Êîãàòî áúäå èçâúðøåíî îáíîâÿâàíå, avast! ùå âè ïîêàæå Îáîáùåíèå çà ïðîòåêëîòî îáíîâÿâàíå. Ïî âàø èçáîð ìîæå äà áúäå ïîêàçàí è ïðîãðåñà íà îáíîâÿâàíå.\r\n\r\nÒèõ. Îáíîâÿâàíåòî ùå áúäå èçâúðøåíî èçöÿëî âúâ ôîíîâ ðåæèì, íÿìà äà áúäàò ïîêàçâàíè íèêàêâè ñúîáùåíèÿ.\r\n\r\nÍàñòðîéêè íà îáíîâÿâàíåòî:\r\n\r\nÏîêàæè ïðîãðåñà íà îáíîâÿâàíåòî. Ïî âðåìå íà îáíîâÿâàíåòî ùå áúäå ïîêàçàí ìàëúê ïðîçîðåö - òàì ìîæåòå äà ñëåäèòå çà ïðîãðåñà íà îáíîâÿâàíåòî.\r\n\r\nÏîêàæè èêîíà â òðåÿ. Ùå áúäå ïîêàçâàíà ìàëêà èêîíà â ñèñòåìíèÿ òðåé ïî âðåìå íà îáíîâÿâàíåòî.\r\n\r\nÏèòàé çà ðåñòàðòèðàíå ïðè íóæäà. Çà äà âëÿçàò â ñèëà íÿêîè îáíîâëåíèÿ ñå íóæäàåòå îò ðåñòàðò (ïî ïðèíöèò òîâà å ïðè îáíîâÿâàíèÿòà íà ñàìàòà ïðîãðàìà). Ïðè èçáîðà íà òàçè îïöèÿ ïðåäîòâðàòÿâàòå àâòîìàòè÷íèÿ ðåñòàðò íà âàøàòà îïåðàöèîííà ñèñòåìà - ùå ñå ïîÿâè ìàëúê ïðîçîðåö, êîéòî ùå âè ïîïèòà äàëè æåëàåòå ðåñòàðòà äà áúäå èçâúðøåí âåäíàãà èëè ïî-êúñíî.\r\n\r\nÏîêàæè ñúîáùåíèå ñëåä îáíîâÿâàíå. Êîãàòî áúäå èçâúðøåíî àâòîìàòè÷íî îáíîâÿâàíå, ùå áúäå ïîêàçàí ìàëúê ïðîçîðåö íàä ñèñòåìíèÿ ÷àñîâíèê, óâåäîìÿâàù çà èçâúðøåíîòî îáíîâÿâàíå.\r\n\r\nÏîêàæè ñúîáùåíèå ïðè ãðåøêà. Àêî âúçíèêíå ãðåøêà ïðè àâòîìàòè÷íèòå îáíîâëåíèÿ, ìàëúê ïðîçîðåö ùå âè èíôîðìèðà çà òîâà.\r\n\r\nÈíòåðâàë çà àâòî-îáíîâÿâàíå. Òóê ìîæåòå äà íàñòðîéâàòå èíòåðâàëà íà àâòîìàòè÷íèòå îáíîâÿâàíèÿ (òîåñò êîëêî ÷åñòî avast! äà ïðîâåðÿâà çà íàëè÷èå íà îáíîâëåíèÿ).\r\n\r\nPush iAVS.(òàçè íàñòðîéêà å äîñòúïíà ñàìî â Ïðîôåñèîíàëíàòà âåðñèÿ íà avast!) Òîâà å ñïåöèàëåí âèä îáíîâÿâàíå. Ïîíÿêîãà ìîæå äà å ìíîãî âàæíî äà èçâúðøèòå îáíîâÿâàíåòî êîëêîòî ñå ìîæå ïî-áúðçî (íàïðèìåð, êîãàòî íîâ âèðóñ çàïî÷íå äà ñå ðàçïðîñòðàíÿâà ìíîãî áúðçî). ×ðåç Push iAVS, å âúçìîæíî äà çàïî÷íåòå îáíîâÿâàíåòî ïðè ïîèñêâàíå îò ñïåöèàëèñòèòå íà ALWIL Software. Ïîèñêâàíåòî ñå èçâúðøâà ÷ðåç ñïåöèàëåí âèä e-mail ñúîáùåíèå. Êîãàòî avast!, ïðîâåðÿâàéêè âõîäÿùèòå e-mail ñúîáùåíèÿ, ðàçïîçíàå òîçè ñïåöèàëåí e-mail, ïðîãðàìàòà ùå çàïî÷íå àâòîìàòè÷íî îáíîâÿâàíå.\r\n\r\nÂêëþ÷è. Âêëþ÷âà Push iAVS ôóíêöèÿòà\r\n\r\nÄîáàâè èíôîðìàöèÿ çà èçâúðøåíèòå äåéñòâèÿ åë. ïîùà. Àêî èçáåðåòå òàçè îïöèÿ, avast! ùå äîáàâÿ áåëåæêà êúì òåçè ñúîáùåíèÿ(áåëåæêàòà ùå ñúäúðæà èíôîðìàöèÿ çà èçâúðøåíîòî îáíîâÿâàíå).\r\n\r\nÐåãèñòðàöèÿ... Óñëóãàòà Push iAVS (óñëóãàòà å äîñòúïíà åäèíñòâåíî â Ïðîôåñèîíàëíàòà Âåðñèÿ) òðÿáâà äà áúäå àêòèâèðàíà ÷ðåç ñïåöèàëíà ðåãèñòðàöèÿ. Ñëåä êàòî íàòèñíåòå âðúçêàòà, âúâ âàøèÿ áðàóçúð ùå áúäå îòâîðåí îíëàéí ôîðìóëÿð; òóê å íåîáõîäèìî äà âúâåäåòå e-mail àäðåñà íà êîéòî òðÿáâà äà áúäå èçïðàòåíî ñïåöèàëíîòî ñúîáùåíèå iAVS.\r\n\r\n \r\nÒîâà å, ñëåäâà êàòåãîðèÿòà „Îáíîâÿâàíå (Ñúåäèíåíèÿ)”\r\n\r\n[img]http://store.picbg.net/pubpic/5D/2D/915ed21556285d2d.jpg[/img]\r\n\r\n×ðåç òåçè íàñòðîéêè âèå ïîìàãàòå íà ïðîãðàìàòà êàê íàé-äîáðå äà ïðåöåíè äàëè èìà àêòèâíà èíòåðíåò âðúçêà – òóê îêàçâàòå âèäà íà âàøàòà âðúçêà ñ èíòåðíåò. Êàêòî çàáåëÿçâàòå èìà äâå îñíîâíè íàñòðîéêè: „Ñâúðçâàì ñå ñ èíòåðíåò ñàìî ÷ðåç ìîäåì” è „Êîìïþòúðúò ìè èìà ïîñòîÿííà âðúçêà ñ Èíòðåíåò” . Àêî èìàòå ïîñòîÿííà âðúçêà (îò ìèãà íà âêëþ÷âàíå íà êîìïþòúðà âè) èçáèðàòå âòîðàòà îïöèÿ, à àêî ñå ñâúðçâàòå ÷ðåç ìîäåì, ADSL, øèðîêîëåíòîâ äîñòúï, îòáåëÿçâàòå ïúðâàòà. Êàê äåéñòâà ìåõàíèçìúò”\r\n\r\n„Ñâúðçâàì ñå ñ èíòåðíåò ñàìî ÷ðåç ìîäåì” –  Ïî ïðèíöèï âåäíàãà ùîì êîìïþòúðúò áúäå ñòàðòèðàí (è çàåäíî ñ íåãî avast! ) ïðîãðàìàòà ñå îïèòâà äà ñå ñâúðæå ñúñ ñúðâúðèòå çà îáíîâÿâàíå (åñòåñòâåíî, àêî îáíîâÿâàíåòî å íàñòðîåíî íà àâòîìàòè÷íî) . Íî êîãàòî èçïîëçâàòå ìîäåì èëè ïîäîáíåí âèä âðúçêà , èíòåðíåò âðúçêàòà íå å àêòèâíà âåäíàãà ñëåä ñòàðòà íà êîìïþòúðà – òîâà âîäè è äî ìíîæåñòâîòî íåíóæíè îïèòè  íà ïðîãðàìàòà çà îáíîâÿâàíå. Àêî îòáåëåæèòå òàçè îïöèÿ, ïðîãðàìàòà ùå ñëåäè ñòàòóñà íà ìîäåìíèòå âðúçêè è ùîì ñòàòóñà ñå ïðîìåíè íà „îíëàéí”, ïðîãðàìàòà àâòîìàòè÷íî ùå èçâúðøè íóæíèòå îáíîâÿâàíèÿ.\r\n\r\n„Êîìïþòúðúò ìè èìà ïîñòîÿííà âðúçêà ñ Èíòðåíåò” – Ùå áúäå íàïðàâåí îïèò çà îáíîâÿâàíå, âåäíàãà ñëåä ñòàðòà íà ñèñòåìàòà.\r\n\r\nÀêî ïîëçâàòå ïðîêñè ñúðâúð çà äîñòúï äî èíòåðíåò , ùå ìîæåòå äà èçâúðøèòå íóæíèòå íàñòðîéêè êàòî ùðàêíåòå íà áóòîíà „Ïðîêñè…”\r\n\r\n \r\n\r\nÊàòåãîðèÿòà „Òðåâîãè”\r\n\r\n[img]×ðåç òåçè íàñòðîéêè âèå ïîìàãàòå íà ïðîãðàìàòà êàê íàé-äîáðå äà ïðåöåíè äàëè èìà àêòèâíà èíòåðíåò âðúçêà – òóê îêàçâàòå âèäà íà âàøàòà âðúçêà ñ èíòåðíåò. Êàêòî çàáåëÿçâàòå èìà äâå îñíîâíè íàñòðîéêè: „Ñâúðçâàì ñå ñ èíòåðíåò ñàìî ÷ðåç ìîäåì” è „Êîìïþòúðúò ìè èìà ïîñòîÿííà âðúçêà ñ Èíòðåíåò” . Àêî èìàòå ïîñòîÿííà âðúçêà (îò ìèãà íà âêëþ÷âàíå íà êîìïþòúðà âè) èçáèðàòå âòîðàòà îïöèÿ, à àêî ñå ñâúðçâàòå ÷ðåç ìîäåì, ADSL, øèðîêîëåíòîâ äîñòúï, îòáåëÿçâàòå ïúðâàòà. Êàê äåéñòâà ìåõàíèçìúò”\r\n\r\n„Ñâúðçâàì ñå ñ èíòåðíåò ñàìî ÷ðåç ìîäåì” –  Ïî ïðèíöèï âåäíàãà ùîì êîìïþòúðúò áúäå ñòàðòèðàí (è çàåäíî ñ íåãî avast! ) ïðîãðàìàòà ñå îïèòâà äà ñå ñâúðæå ñúñ ñúðâúðèòå çà îáíîâÿâàíå (åñòåñòâåíî, àêî îáíîâÿâàíåòî å íàñòðîåíî íà àâòîìàòè÷íî) . Íî êîãàòî èçïîëçâàòå ìîäåì èëè ïîäîáíåí âèä âðúçêà , èíòåðíåò âðúçêàòà íå å àêòèâíà âåäíàãà ñëåä ñòàðòà íà êîìïþòúðà – òîâà âîäè è äî ìíîæåñòâîòî íåíóæíè îïèòè  íà ïðîãðàìàòà çà îáíîâÿâàíå. Àêî îòáåëåæèòå òàçè îïöèÿ, ïðîãðàìàòà ùå ñëåäè ñòàòóñà íà ìîäåìíèòå âðúçêè è ùîì ñòàòóñà ñå ïðîìåíè íà „îíëàéí”, ïðîãðàìàòà àâòîìàòè÷íî ùå èçâúðøè íóæíèòå îáíîâÿâàíèÿ.\r\n\r\n„Êîìïþòúðúò ìè èìà ïîñòîÿííà âðúçêà ñ Èíòðåíåò” – Ùå áúäå íàïðàâåí îïèò çà îáíîâÿâàíå, âåäíàãà ñëåä ñòàðòà íà ñèñòåìàòà.\r\n\r\nÀêî ïîëçâàòå ïðîêñè ñúðâúð çà äîñòúï äî èíòåðíåò , ùå ìîæåòå äà èçâúðøèòå íóæíèòå íàñòðîéêè êàòî ùðàêíåòå íà áóòîíà „Ïðîêñè…”\r\n\r\n \r\n\r\nÊàòåãîðèÿòà „Òðåâîãè"\r\n\r\n[img]×ðåç òåçè íàñòðîéêè âèå ïîìàãàòå íà ïðîãðàìàòà êàê íàé-äîáðå äà ïðåöåíè äàëè èìà àêòèâíà èíòåðíåò âðúçêà – òóê îêàçâàòå âèäà íà âàøàòà âðúçêà ñ èíòåðíåò. Êàêòî çàáåëÿçâàòå èìà äâå îñíîâíè íàñòðîéêè: „Ñâúðçâàì ñå ñ èíòåðíåò ñàìî ÷ðåç ìîäåì” è „Êîìïþòúðúò ìè èìà ïîñòîÿííà âðúçêà ñ Èíòðåíåò” . Àêî èìàòå ïîñòîÿííà âðúçêà (îò ìèãà íà âêëþ÷âàíå íà êîìïþòúðà âè) èçáèðàòå âòîðàòà îïöèÿ, à àêî ñå ñâúðçâàòå ÷ðåç ìîäåì, ADSL, øèðîêîëåíòîâ äîñòúï, îòáåëÿçâàòå ïúðâàòà. Êàê äåéñòâà ìåõàíèçìúò”\r\n\r\n„Ñâúðçâàì ñå ñ èíòåðíåò ñàìî ÷ðåç ìîäåì” –  Ïî ïðèíöèï âåäíàãà ùîì êîìïþòúðúò áúäå ñòàðòèðàí (è çàåäíî ñ íåãî avast! ) ïðîãðàìàòà ñå îïèòâà äà ñå ñâúðæå ñúñ ñúðâúðèòå çà îáíîâÿâàíå (åñòåñòâåíî, àêî îáíîâÿâàíåòî å íàñòðîåíî íà àâòîìàòè÷íî) . Íî êîãàòî èçïîëçâàòå ìîäåì èëè ïîäîáíåí âèä âðúçêà , èíòåðíåò âðúçêàòà íå å àêòèâíà âåäíàãà ñëåä ñòàðòà íà êîìïþòúðà – òîâà âîäè è äî ìíîæåñòâîòî íåíóæíè îïèòè  íà ïðîãðàìàòà çà îáíîâÿâàíå. Àêî îòáåëåæèòå òàçè îïöèÿ, ïðîãðàìàòà ùå ñëåäè ñòàòóñà íà ìîäåìíèòå âðúçêè è ùîì ñòàòóñà ñå ïðîìåíè íà „îíëàéí”, ïðîãðàìàòà àâòîìàòè÷íî ùå èçâúðøè íóæíèòå îáíîâÿâàíèÿ.\r\n\r\n„Êîìïþòúðúò ìè èìà ïîñòîÿííà âðúçêà ñ Èíòðåíåò” – Ùå áúäå íàïðàâåí îïèò çà îáíîâÿâàíå, âåäíàãà ñëåä ñòàðòà íà ñèñòåìàòà.\r\n\r\nÀêî ïîëçâàòå ïðîêñè ñúðâúð çà äîñòúï äî èíòåðíåò , ùå ìîæåòå äà èçâúðøèòå íóæíèòå íàñòðîéêè êàòî ùðàêíåòå íà áóòîíà „Ïðîêñè…”\r\n\r\n \r\n\r\nÊàòåãîðèÿòà „Òðåâîãè"\r\n\r\n[img]http://store.picbg.net/pubpic/FB/D3/0d0ccab8a552fbd3.jpg[/img]\r\n\r\nÍàñòðîéêèòå â òàçè êàòåãîðèÿ ñà ãëàâíî â ïîìîù çà ñèñòåìíèòå àäìèíèñòðàòîðè – ïðè îòêðèò âèðóñ íà êîìïþòúðà, ìîæå äà áúäå èçïðàòåíî ñúîáùåíèå äî ñèñòåìíèÿ àäìèíèñòðàòîð è òîé äà ñå ïîãðèæè çà îòñòðàíÿâàíåòî íà ïîðáëåìà. Çàòîâà íÿìà äà îáúðíåì âíèìàíèå íà òàçè êàòåãîðèÿ . (àêî èìàòå íÿêàêâè âúïðîñè ïèòàéòå âúâ ôîðóìà)\r\n\r\nÊàòåãîðèÿòà „Äîêëàä”\r\n\r\n[img]http://store.picbg.net/pubpic/0D/81/a1db0b0ef7650d81.jpg[/img]\r\n\r\n    Îò òóê èìàòå âúçìîæíîñò äà âêëþ÷èòå íàñòðîéêàòà çà ñúçäàâàíå íà ïîäðîáíè äîêëàäè çà èçâúðøåíèòå ïðîâåðêè -  êîãà å ñòàðòèðàíà ïðîâåðêàòà, êîãà å ïðèêëþ÷èëà, êîè ôàéëîâå ñà áèëè ïðîâåðåíè, êîè ôàéëîâå ñà áèëè ïðîïóñíàòè è ò.í. Èìàòå è âúçìîæíîñò çà çàäàâàíå íà ïàïêà, êúäåòî äà áúäå çàïèñàí äîêëàäà. Íî âíèìàâàéòå, çàùîòî àêî îòáåëåæèòå äà áúäå çàïèñâàíà èíôîðìàöèÿ çà âñåêè ïðîâåðåí ôàéë, äîêëàäà ìîæå äà èçëåçå ÄÎÑÒÀ ãîëÿì.\r\n\r\n \r\n\r\nÊàòåãîðèÿòà „SMTP”\r\n\r\n[img]http://store.picbg.net/pubpic/88/57/f501fac3ec548857.jpg[/img]\r\n\r\nÒóê ìîæåòå äà âúâåäåòå âàøèòå ïàðàìåòðè çà SMTP ñúðâúðà. avast! èçïîëçâà òåçè íàñòðîéêè, çà äà èçïðàùà e-mail ñúîáùåíèÿ, â íÿêîëêî ñïåöèàëíè ñëó÷àÿ:\r\n\r\n    * Èçïðàùàíå íà ïðåäóïðåäèòåëíè ñúîáùåíèÿ êîãàòî áúäå îòêðèò âèðóñ.\r\n    * Èçïðàùàíå íà ôàéëîâå îò Êëåòêàòà äî ALWIL Software.\r\n    * Èçïðàùàíå íà äîêëàäè çà âúçíèêíàëà ãðåøêà íà avast! äî ALWIL Software. \r\n\r\nÒðÿáâà äà âúâåäåòå ñëåäíàòà èíôîðìàöèÿ:\r\n\r\n    * Àäðåñ íà ñúðâúðà - àäðåñà íà èçõîäÿùèÿ e-mail ñúðâúð (íàïðèìåð smtp.server.com èëè 192.168.1.25).\r\n    * Ïîðò - íîìåðúò íà ïîðòà (ñòîéíîñòòà ïî ïîäðàçáèðàíå å 25).\r\n    * Îò àäðåñ - àäðåñà íà èçïðàùà÷à ("Îò").\r\n\r\n \r\n\r\nÊàòåãîðèÿòà „Ðåøàâàíå íà ïðîáëåìè\r\n\r\n[img]http://store.picbg.net/pubpic/83/67/77a8a64ab0078367.jpg[/img]\r\n\r\nÅòî è ïðåäíàçíà÷åíèÿòà íà âñÿêà åäíà îò äâåòå îïöèè:\r\n\r\n    * Ïðîâåðè çà ïðèëîæåíèÿ ðàáîòåùè íà öÿë åêðàí (íàïð. èãðè) ïðåäè ïîêàçâàíå íà èçñêà÷àùè ïðîçîðöè. Â çàâèñèìîñò îò âàøèòå íàñòðîéêè avast! ìîæå äà ïîêàçâà íÿêîëêî ñúîáùåíèÿ (ïðèìåðíî ïðè, îáíîâÿâàíå íà âèðóñíàòà ÁÄ, êîãàòî ïðèñòèãàùàòà åëåêòðîííà ïîùà ñå ïðîâåðÿâà è äð.). Íîðìàëíî ñúîáùåíèÿòà ñå ïîêàçâàò íåçàâèñèìî êàêâî äåéñòâèå ñå èçâúðøâà â ìîìåíòà. Òîâà â íÿêîè ñëó÷àè ìîæå äà çàñåãíå ïðèëîæåíèÿ, êîèòî ðàáîòÿò â ðåæèì íà öÿë åêðàí (íàïðèìåð èãðè) - Windows ïðåìèíàâà îò öÿë åêðàí íà ïðîçîðå÷åí ðåæèì, êîãàòî ñúîáùåíèåòî ñå ïîêàçâà.\r\n      Àêî èçáåðåòå òàçè îïöèÿ, avast! ùå ïðîâåðè äàëè èìà ïðèëîæåíèå ðàáîòåùî íà öÿë åêðàí ïðåäè äà ïîêàæå ñúîáùåíèåòî; àêî å îòêðèòî àêòèâíî ïðèëîæåíèå ðàáîòåùî íà öÿë åêðàí, avast! íÿìà äà ïîêàçâà ñúîáùåíèåòî.\r\n    * Çàáàâè çàðåæäàíåòî íà avast! óñëóãèòå ñëåä äðóãèòå ñèñòåìíè óñëóãè. Íîðìàëíî, óñëóãèòå íà avast! antivirus ñå ñòàðòèðàò ñðàâíèòåëíî ðàíî ïðè çàðåæäàùèÿò ïðîöåñ. Â ðåäêè ñëó÷àè, òîâà ìîæå äà äîâåäå äî ïðîáëåìè ïðè ñòàðòèðàíåòî íà äðóãè ñèñòåìíè óñëóãè - êîåòî ïðèìåðíî ìîæå äà äîâåäå äî âðåìåííî çàìðúçâàíå (çà íÿêîëêî ñåêóíäè èëè ìèíóòè) íà ñèñòåìàòà. Òàçè îïöèÿ âè ïîçâîëÿâà äà çàáàâèòå ñòàðòèðàíåòî íà óñëóãèòå íà avast! antivirus - äà ñå ñòàðòèðàò ñëåä îáè÷àéíèòå ñèñòåìíè óñëóãè.\r\n    * Çàáðàíè ðóóòêèò ïðîâåðêà ïðè ñòàðòèðàíå íà ñèñòåìàòà. avast! ïðîâåðÿâà çà ðóóòêèò, êîãàòî ñòàðòèðàòå îïåðàöèîííàòà ñèñòåìà. Îòáåëåæåòå òóê àêî æåëàåòå äà èçêëþ÷èòå òîçè âèä ïðîâåðêà.\r\n    * Çàáðàíè äèðåêòíèÿ äîñòúï äî äèñêà ïðè íà÷àëíî ñòàðòèðàíå. Ïî âðåìå íà ïðåäñòàðòîâàòà ïðîâåðêà, avast! èçïîëçâà ñïåöèàëåí ìåòîä çà äîñòúï äî äèñêà, êîéòî ïîçâîëÿâà íà àíòèâèðóñíàòà äà îòêðèâà äîðè è âèðóñè, êîèòî êðèÿò ñâîèòå ôàéëîâå. Òóê ìîæåòå äà èçêëþ÷èòå òàçè âúçìîæíîñò - avast! ùå èçïîëçâà îáèêíîâåíèÿ ìåòîä çà äîñòúï äî äèñêà.\r\n    * Ñïðè ñàìîçàùèòíèÿ ìîäóë íà avast!. Íÿêîè âèðóñè èìàò âúçìîæíîñòòà äà èçêëþ÷âàò àíòèâèðóñíèÿ ñîôòóåð, êàòî èçêëþ÷âàò òåõíèòå ïðîöåñè, èçòðèâàò òåõíè âàæíè ôàéëîâå èëè ïðîñòî ãè ïðîìåíÿò. avast! ïðèòåæàâà ñàìîçàùèòåí ìåõàíèçúì, êîéòî ïðåäîòâðàòÿâà òåçè àòàêè, êàòî áëîêèðà îïàñíèòå îïåðàöèè. Çà äà èçêëþ÷èòå òîçè ñàìîçàùèòåí ìîäóë, îòáåëåæåòå òóê.\r\n    * Ïðîïóñíè ïðîâåðêàòà çà öèôðîâ ïîäïèñ íà çàðàçåí ôàéë. Çà äà ñå ïðåäîòâðàòÿò ãðåøíèòå àëàðìè, avast! ïðîâåðÿâà çàñå÷åíèÿ ôàéë çà öèôðîâ ïîäïèñ. Àêî ôàéëúò å çàñå÷åí êàòî çàðàçåí, íî ñúùåâðåìåííî ïðèòåæàâà è âàëèäåí öèôðîâ ïîäïèñ îò äîâåðåíà êîìïàíèÿ (ïðèìåðíî Microsoft), òî íàé-âåðîÿòíî òîâà å ãðåøíà àëàðìà è avast! ùå èãíîðèðà òîâà (ãðåøíî) îòêðèòèå. Àêî îòáåëåæèòå òàçè îïöèÿ, ùå èçêëþ÷èòå òàçè äîïúëíèòåëíà ïðîâåðêà - avast! ùå äîêëàäâà çà âñè÷êè îòêðèòè çàðàçè. \r\n\r\n \r\n\r\n    Òîâà å...íàäÿâàì ñå òîâà äà âè å îò ïîëçà. \r\n[img]http://store.picbg.net/pubpic/26/D5/67fbabd4636226d5.gif[/img]', 8, 1265829493);
INSERT INTO `posts` VALUES (16, 16, 8, 1266173275, '[center][size=5][color=blue]Õàðä ðîê[/color][/size][/center]\r\n\r\nÕàðä ðîêúò å âàðèàöèÿ íà ðîê ìóçèêàòà, ÷èéòî íàé-ðàííè êîðåíè ñà â ãàðàæíèÿ ðîê è ïñèõåäåëèÿòà îò ñðåäàòà íà 60-òå. Õàðàêòåðèçèðà ñå ñ ìîùíè äèñòåðíè åëåêòðè÷åñêè êèòàðè, áàñ êèòàðè, êëàâèøíè è áàðàáàíè. Òåðìèíúò "õàðä ðîê" ÷åñòî ñå èçïîëçâà çà îáõâàùàíå è íà äðóãè æàíðîâå êàòî àëòåðíàòèâåí ðîê, ãðúíäæ, õåâè ìåòúë è ïúíê ñ öåë äà ñå ðàçãðàíè÷àò îò ïîï ðîêà.\r\n\r\n-Õàðä ðîêà å ñèëíî ïîâëèÿí îò áëóñ ìóçèêàòà (íàé-÷åñòî èçïîëçâàíàòà ãàìà â õàðä ðîêà å ïåíòàòîíè÷åñêàòà, êîÿòî å òèïè÷íà áëóñ ãàìà). Çà ðàçëèêà îò ðîêåíäðîëà (êîéòî âçàéìñòâà îò "ñòàðèÿ" áëóñ), õàðä ðîêà èçïîëçâà åëåìåíòè îò "áðèòàíñêèÿ áëóñ" (ïðè íåãî ñå èçïîëçâàò ïîâå÷å ìîäåðíè èíñòðóìåíòè êàòî åëåêòðè÷åñêà êèòàðà, áàðàáàíè, êëàâèøíè è åëåêòðè÷åñêè áàñ). Î÷åâèäíà ðàçëèêà ñ òðàäèöèîííèÿ áëóñ å ðÿäêîòî îãðàíè÷àâàíå íà ïúðâè, ÷åòâúðòè è ïåòè àêîðä, íî ïðåîáëàäàâàùè â äâàíàäåñåòèÿ è øåñòíàäåñåòèÿ òàêò, êàòî ñà âêëþ÷åíè è äðóãè àêîðäè, îáèêíîâåíî ìàæîðíè.\r\n\r\n-Äîìèíèðàùè èíñòðóìåíòè â õàðä ðîêà ñà åëåêòðè÷åñêàòà êèòàðà, áàñ êèòàðàòà è áàðàáàíèòå. Ìíîãî å âàæíà ðîëÿòà íà êèòàðèñòà. Ïîâå÷åòî ãðóïè èìàò äâàìà ðàçëè÷íè êèòàðèñòà - åäèí âîäåù êèòàðèñò è åäèí ðèòúì êèòàðèñò. Âîäåùèÿ êèòàðèñò ñâèðè ñîëàòà, ðèôîâåòå è äð. Òåõíèêèòå çà óâåëè÷àâàíå íà ñêîðîñòòà íà ñâèðåíå ñå èçïîëçâàò øèðîêî îò âîäåùèòå êèòàðèñòè çà âúçìîæíî íàé-áúðçè ñîëà è ðèôîâå. Ðîëÿòà íà ðèòúì êèòàðèñòà å äà äîïúëâà âîäåùèÿ è äà îñèãóðÿâà ðèòìè÷åí è õàðìîíè÷åí àêîìïàíèìåíò íà îñòàíàëèòå èíñòðóìåíòè â ãðóïàòà. Ðîëÿòà íà áàñà è áàðàáàíèòå å âàæíà çà ñòðóêòóðàòà íà õàðä ðîê ìóçèêàòà.\r\n\r\n[size=5][color=blue]Ðàçãðàíè÷åíèå îò õåâè ìåòúëà [/color][/size]\r\n\r\nÏðåç 70-òå, õàðä ðîê âäúõíîâÿâà íîâ æàíð íàðå÷åí "õåâè ìåòúë". Ïîÿâÿâàíåòî ìó âîäè äî îáúðêâàíå ñðåä ðîê è ìåòúë ãðóïèòå, òúé êàòî ðàçëèêèòå ìåæäó òÿõ ñà ìíîãî ìàëêè è ðàçãðàíè÷àâàíåòî ÷åñòî îïèðà äî èìèäæà íà ãðóïàòà. Äâàòà æàíðà èìàò ðåäèöà îáùè ÷åðòè, íàïðèìåð ïèîíåðè â õåâè ìåòúëà êàòî Áëåê Ñàáàò, Ëåä Öåïåëèí è Äèéï Ïúðïúë ÷åñòî ñà ñ÷èòàíè è çà õåâè è çà ðîê ãðóïè, à ãðóïè êàòî AC/DC, Äú Õó è Âàí Õàëåí îáèêíîâåíî ñå ïðè÷èñëÿâàò êúì õàðä ðîêà.\r\n\r\nÇà äà å ïúëíî îáúðêâàíåòî, íàé-ïîïóëÿðíèÿ ñóáæàíð íà ìåòúëà ïðåç 80-òå - ãëåì ìåòúëà å ñèëíî ïîâëèÿí îò ðîê èçïúëíèòåëè êàòî Äåéâóä Áàóè, Êóèí, Àåðîñìèò è Êèñ. Îñíîâíàòà ðàçëèêà ìåæäó õåâè ìåòúëà è ãëåì ìåòúëà å â òåêñòîâåòå, èìèäæà è ìåëîäèÿòà. Õåâè ìåòúë òåêñòîâåòå ñå ðàçïðîñòèðàò ïî-äàëå÷ îò "îïëàêâàíåòî íà ðåàëíîñòòà" ïðè áëóñà è îáñúæäàò ñåðèîçíè, ôèëîñîôñêè è ïðîâîêàòèâíè èäåè. Èìèäæà íà ìåòúë ãðóïèòå ñå ñúñòîè îò ÷åðíè êîæè, òúìíè äðåõè è äæèíñè. Ìåëîäèèòå ñà îáèêíîâåíî â ìèíîð è êàòî öÿëî ìóçèêàòà íå å "ïðèìàìëèâà" è ïîâëèÿíà îò ïîïà, êàòî ïðè ãëåì ìåòúëà. Ãëåì ìåòúëèòå îò ñâîÿ ñòðàíà ñå ðàçïðîñòèðàò îò òåìàòà çà "ôàíòàñòè÷íîòî èçáÿãâàíå" ïðè ïîï ìóçèêàòà è òåêñòîâåòå èì ñå ôîêóñèðàò ïîâå÷å âúðõó äîáðîòî ïðåêàðâàíå, ïàðòèòàòà è âçàèìîîòíîøåíèÿòà. Èìèäæúò íà òåçè ãðóïè âêëþ÷âà îãðîìíî òîïèðàíè ïðè÷åñêè, âúçìóòèòåëíà åêèïèðîâêà è ìíîãî ãðèì.\r\n\r\n[size=5][color=orange]Ðàííè ãîäèíè (60-òå) [/color][/size]\r\n\r\nÊàêòî å ïîñî÷åíî ïî-ãîðå, åäíî îò îñíîâíèòå âëèÿíèÿ â õàðä ðîêà å áëóñúò è ïî-ñïåöèàëíî áðèòàíñêèÿò áëóñ. Áðèòàíñêèòå ðîê ãðóïè êàòî Êðèéì, Ðîëèíã Ñòîóíñ, Áèòúëñ, ßðäáúðäñ, Äú Õó è The Kinks ìîäèôèöèðàò ðîêåíäðîëà êàòî äîáàâÿò ïî-òåæêè çâóöè, òåæêè êèòàðíè ðèôîâå, íàäóòè áàðàáàíè è ñèëíè âîêàëè. Òîçè çâóê å îñíîâàòà íà õàðä ðîêà. Ðàííè ôîðìè íà õàðä ðîê ìîãàò äà ñå âèäÿò â "You Really Got Me" íà The Kinks, "Happenings Ten Years Time Ago" íà ßðäáúðäñ, "I Can See for Miles" íà Äú Õó è "Revolution" è "Helter Skelter" íà Áèòúëñ.\r\n\r\nÏî ñúùîòî âðåìå Äæèìè Õåíäðèêñ ñúçäàâà ôîðìà íà áëóñ-îðèåíòèðàí ïñèõåäåëè÷åí ðîê, êîÿòî êîìáèíèðà åëåìåíòè îò äæàç, áëóñ è ðîêåíäðîë ìóçèêàòà, ñúçäàâàéêè óíèêàëåí æàíð. Òîé å ïúðâèÿò êèòàðèñò, êîéòî åêñïåðèìåíòèðà ñ íîâè êèòàðíè åôåêòè êàòî ôèéäáåê è äèñòîðøúí, çàåäíî ñ Äåéâ Äåéâèñ îò The Kinks, Ïèò Òàóíçåíä îò Äú Õó, Åðèê Êëåïòúí îò Êðèéì è Äæåô Áåê îò ßðäáúðäñ.\r\n\r\nÕàðä ðîêúò ñå îôîðìÿ îêîí÷àòåëíî è ñòàâà èçâåñòåí â êðàÿ íà 60-òå. Ãðóïè êàòî Ëåä Çåïåëèí, êîèòî ñìåñâàò ðàííèÿ áðèòàíñêè ðîê, ñ ïî-òâúðäè ôîðìè íà áëóñ ðîê è åñèä ðîê. Äèéï Ïúðïúë ïîìàãàò çà íàëàãàíåòî íà õàðä ðîêà ñ ïúðâèòå ñè àëáóìè ("Shades of Deep Purple" 1968, "The Book of Taliesyn" 1968 è "Deep Purple" 1969), íî ïðàÿâò ãîëåìèÿ ñè ïðîáèâ ñ ÷åòâúðòèÿ "Deep Purple in Rock" (1970). Åïè÷åñêèÿò "Led Zeppelin I" (1969) íà Ëåä Çåïåëèí è "Live at Leeds" (1970) íà Äú Õó ñà ïðèìåðè çà ìóçèêà îò çàðàæäàíåòî íà õàðä ðîêà. Çàåìêèòå îò áëóñ ìóçêàòà òóê ñà î÷åâèäíè, êàòî èìà âêëþ÷åíè íÿêîëêî êàâúðà èçâåñòíè áëóñ ïåñíè.\r\n\r\n[size=5][color=yellow]Ïúðâàòà åðà (70-òå)[/color][/size]\r\n\r\nÒðåòèÿ àëáóì íà Ëåä Öåïåëèí, "Led Zeppelin III" âêëþ÷âà ïîâå÷å ôîëê ðîê åëåìåíòè îò âòîðèÿ, íî õåâè àñïåêòèòå â ìóçèêàòà èì îñòàâàò.\r\n\r\nÏðîìåíèòå â çâó÷åíåòî íà Äèéï Ïúðïúë ïðèêëþ÷âàò ñ "Machine Head", êîéòî ñå ñ÷èòà çà åäèí îò ïúðâèòå õåâè ìåòúë àëáóìè. Äâå ïåñíè îò òîçè àëáóì ñòàâàò èçêëþ÷èòåëíî èçâåñòíè, "Highway Star" è "Smoke On The Water". Òåõíèòå îñíîâíè ðèôîâå ñòàâàò çàïàçåíà ìàðêà íà Ïúðïúë. Íàçàðåò êîìåðñèàëèçèðàò æàíðà è ñúñ ñâîÿ íàé-äîáðå ïðîäàâàí àëáóì "Hair of the Dog" ïîâëèÿâàò íà ðåäèöà äðóãè ãðóïè.\r\n\r\nÏðåç 70-òå îò õàðä ðîêà ñå ðàçâèâàò ìíîæåñòâî äðóãè æàíðîâå. Ïðåç 1972ã, Àëèñ Êóïúð âêàðâà õåâè ìåòúëà â ìåéíñòðèéìà ñ àëáóìà ñè "School''s Out". Ñëåäâàùàòà ãîäèíà Àåðîñìèò, Êóèí è Ìîíòðîñ èçäàâàò äåáþòíèòå ñè àëáóìè, â êîèòî äåìîíñòðèðàò ðàçøèðÿâàùèòå ñå âàðèàöèè íà õàðä ðîê. Ïðåç 1974ã, Bad Company èçäàâàò äåáþòíèÿ ñè àëáóì, Rush èçäàâàò åäíîèìåííèÿ ñè àëáóì, à Êóèí èçäàâàò "Sheer Heart Attack" (ñúäúðæàù ïåñåíòà "Stone Cold Crazy", êîÿòî å ïîâëèÿëà íà òðàø ìåòúë ãðóïè êàòî Ìåòàëèêà è Ìåãàäåò). Êóèí èçïîëçâàò ìíîãîïëàñòîâè âîêàëè è êèòàðè è ñìåñâàò õàðä ðîê ñ ãëåì ðîê, õåâè ìåòúë, ïðîãðåñèâ ðîê è äîðè îïåðà. Êèñ èçäàâàò ïúðâèòå ñè òðè àëáóìà "Kiss ", "Hotter Than Hell" è "Dressed To Kill" çà ìàëêî ïîâå÷å îò ãîäèíà è ïîñòèãàò êîìåðñèàëåí óñïåõ ñ äâîéíèÿ êîíöåðòåí àëáóì "Alive!". Â ñðåäàòà íà 70-òå Àåðîñìèò èçäàâàò ðàçòúðñâàùèòå "Toys in the Attic" è "Rocks", êîéòî ñúäúðæàò è áëóñ è õàðä ðîê åëåìåíòè è ùå îêàæàò âëèÿíèå âúðõó ìóçèêàòà íà Ìåòàëèêà, Guns N'' Roses è M&#246;tley Cr&#252;e.\r\n\r\nÏðåç 1976ã, óìèðà êèòàðèñòà íà Äèéï Ïúðïúë Òîìè Áîóëèí è ãðóïàòà ñå ðàçïàäà. Ïðåç ñúùàòà ãîäèíà Áîñòúí èçäàâàò èçêëþ÷èòåëíî óñïåøíèÿ ñè äåáþòåí àëáóì. Õàðò ñà ïúðâàòà æåíñêà õàðä ðîê ãðóïà, êîÿòî èçäàâà àëáóì. Ïðåç 1978ã, îò ñâðúõäîçà óìèðà áàðàáàíèñòà íà Äú Õó Êèéò Ìóí. Ñ íàäèãàùàòà ñå äèñêî âúëíà â ÑÀÙ è ïúíê âúâ Âëèêîáðèòàíèÿ õàðä ðîêà çàïî÷âà äà ãóáè ïîïóëÿðíîñòòà ñè. Ñúùåâðåìåííî Áëåê Ñàáàò ñå îòäàëå÷àâàò îò ïúðâîíà÷àëíîòî ñè òåæêî çâó÷åíå ñ àëáóìè êàòî "Technical Ecstasy".\r\n\r\nÂàí Õàëåí å äðóãà âàæíà çà õàðä ðîêà ãðóïà, êîÿòî ñòàâà èçâåñòíà ïðåç 1978 ã. Ìóçèêàòà èì ñå îñíîâàâà îñíîâíî âúðõó êèòàðíèòå óìåíèÿ íà Åäè Âàí Õàëåí, êîéòî ñå îòëè÷àâà ñ äîáðà òåõíèêà. Ïðåç 1979ã, ðàçëè÷èÿòà ìåæäó õàðä ðîêà è õåâè ìåòúëà ñå âèæäàò âúâ âòîðèÿ àëáóì íà AC/DC "Highway to Hell". Ìóçèêàòà íà àâñòðàëèéöèòå ñå îñíîâàâà íà ðèòúì åíä áëóñ è ðàííèÿ õàðä ðîê îò 70-òå, à èìèäæà íà ãðóïàòà å â ñòèëà íà õåâè ìåòúëà.\r\n\r\n[size=5][color=maroon]Âòîðàòà åðà (80-òå)[/color][/size]\r\n\r\nÏðåç 1980ã, Ëåä Öåïåëèí ñå ðàçïàäàò ñëåä âíåçàïíàòà ñìúðò íà áàðàáàíèñòà Äæîí Áîíúì. Ïðåç ñúùàòà ãîäèíà óìèðà è âîêàëà íà AC/DC Áîí Ñêîò. Ñ òîâà ïðèêëþ÷âà ïúðâàòà âúëíà "êëàñè÷åñêè" õàðä ðîê ãðóïè. Íÿêîé ãðóïè êàòî Êóèí ñå îòäàëå÷àâàò îò õàðä ðîê çâó÷åíåòî è ñå îðèåíòèðàò êúì ïîï ðîêà. AC/DC çàïèñâàò "Back in Black" ñ íîâèÿ ñè âîêàë Áðàéúí Äæîíñúí. Àëáóìà ñòàâà ïåòèÿ íàé-ïðîäàâàò àëáóì â ÑÀÙ çà âñè÷êè âðåìåíà è âòîðèÿ íàé-ïðîäàâàí â ñâåòà. Îçè Îçáúðí èçäàâà ïúðâèÿ ñè ñîëîâ àëáóì, â êîéòî ó÷àñòâà è àìåðèêàíñêèÿ êèòàðèñò Ðàíäè Ðîóäñ.\r\n\r\nÏðåç 1981ã, Ìîòëè Êðþ èçäàâàò "Too Fast For Love", êîéòî ïðè÷ëèâà èíòåðåñ êúì ãëåì ìåòúë ñòèëà. Ãîäèíà ïî-êúñíî òîé å ïîïóëÿðèçèðàí è îò Twisted Sister è Quiet Riot.\r\n\r\nÏðåç 1983ã, Äåô Ëåïàðä èçäàâàò "Pyromania", êîéòî äîñòèãà âòîðî ìÿñòî â àìåðèêàíñêèòå êëàñàöèè. Ìóçèêàòà èì å ñìåñèöà îò ãëåì ðîê è õåâè ìåòúë, êîÿòî ïîâëèÿâà ìíîãî ãðóïè îò 80-òå. Ïðåç ñúùàòà ãîäèíà M&#246;tley Cr&#252;e èçäàâàò õèòîâèÿ "Shout at the Devil". Àëáóìúò íìà Âàí Õàëåí 1984 äîñòèãà #2 â êëàñàöèÿòà íà Áèëáîðä, à ñèíãúëúò "Jump", êîéòî å ñ÷èòàí çà åäíà îò íàé-ïîïóëÿðíèòå ðîê ïåñíè íà âñè÷êè âðåìåíà, äîñòèãà #1.\r\n\r\nÊðàÿ íà 80-òå å íàé-óñïåøíèÿ â êîìåðñèàëíî îòíîøåíèå ïåðèîä çà õàðä ðîêà. Ðåäèöà õàðä ðîê ãðóïè äîñòèãàò ïúðâèòå ìåñòà â ìóçèêàëíèòå êëàñàöèè. "Slippery When Wet" (1986) íà Áîí Äæîóâè îñòàâà îáùî 8 ñåäìèöè â êëàñàöèÿòà íà Áèëáîðä è ñòàâà ïúðâèÿ õàðä ðîê àëáóì ñ òðè ñèíãúëà â òîï 10, äâà îò êîèòî äîñòèãàò #1. Îñâåí òîâà ïåñåíòà íà øâåäèòå îò Þðúï "The Final Countdown" äîñòèãà #1 â 26 äúðæàâè.\r\n\r\nÏðåç 1987ã, íàé-âïå÷àòëÿâàùèòå àëáóìè â êëàñàöèèòå ñà "Appetite for Destruction" íà Guns N'' Roses, "Hysteria" íà Äåô Ëåïúðä (è äâàòà äîñòèãàò #1 â êëàñàöèÿòà íà Áèëáîðä), "Girls, Girls, Girls" íà M&#246;tley Cr&#252;e è åäíîèìåííèÿ àëáóì íà Óàéòñíåéê.Ïðåç ñëåäâàùàòà ãîäèíà íàé-ãîëÿì óñïåõ ïîñòèãàò "New Jersey" (ñ ïåò ñèíãúëà â òîï 10; íàé-ìíîãî çà õàðä ðîê àëáóì) íà Áîí Äæîóâè, "Pump" íà Àåðîñìèò è "Dr. Feelgood" íà M&#246;tley Cr&#252;e. Dinosaur Jr è Sonic Youth ïîñòèãàò óñïåõ íà úäíäúðãðàóíä ñöåíàòà â ÑÀÙ, à ïðåç 90-òå è íà ìåéíñòðèéìà.\r\n\r\n[size=5][color=red]Òðåòàòà åðà (90-òå)[/color][/size]\r\n\r\nÍà÷àëîòî íà 90-òå ñà äîìèíèðàíè îò Guns N'' Roses, Ìåòàëèêà è Âàí Õàëåí. Ìóëòè-ïëàòèíåíèÿ åäíîèìåíåí àëáóì íà Ìåòàëèêà (÷åñòî íàðè÷àí "×åðíèÿ àëáóì" ïîðàäè ÷åðíàòà ñè îáëîæêà), "Use Your Illusion I" and "Use Your Illusion II" íà Guns N'' Roses è "For Unlawful Carnal Knowledge" íà Âàí Õàëåí ñà èçäàäåíè ïðåç 1991ã è çàñèëâàò îùå ïîâå÷å ïîïóëÿðíîñòòà íà òåçè ãðóïè. Íî ïî òîâà âðåìå ìóçèêàòà è îòíîøåíèåòî íà ãðóïèòå ñòàâà âñå ïî-äåêàäåíòñêî. Ïðåç 1991ã ñå ïîÿâÿâà åäíà íîâà ôîðìà íà õàðä ðîêà - ãðúíäæ.\r\n\r\nÃðúíäæà êîìáèíèðà õàðäêîð ïúíê è õåâè ìåòúë è ñúçäàâà åäèí "ìðúñåí" çâóê, çà êîéòî ñå èçïîëçâà äèñòîðøúí, ôúç è ôèéäáåê. Âúïðåêè ÷å ïîâå÷åòî ãðúíäæ ãðóïè çâó÷àò äîñòà ðàçëè÷íî îò õàðä ðîêà â ìåéíñòðèéìà (êàòî íàïðèìåð Íèðâàíà, Ìúäõîíè è L7), ìàëöèíñòâî (êàòî Àëèñ èí ×åéíñ, Mother Love Bone, Ïúðë Äæåì è Ñàóíäãàðäúí) ñà ñèëíî ïîâëèÿíè îò ðîêà è ìåòúëà îò 70-òå è 80-òå. Âúïðåêè òîâà âñè÷êè ãðúíäæ áàíäè îòðè÷àò ìà÷î èìèäæà íà õàðä ðîêà ïî-òîâà âðåìå.\r\n\r\nÄîêàòî ïîïóëÿðíîñòòà íà íÿêîé ãðóïè (êàòî Ìåòàëèêà) ïðåìèíå îò 80-òå â 90-òå, äðóãè çàïî÷âàò äà ñìåñâàò õàðä ðîêà ñ åëåêòðèê âëèÿíèÿ. Òå çàïî÷âàò äà ñå íàðè÷àò àëòúðíàòúâ ìåòúë ãðóïè. Íÿêîè îò òÿé êàòî Ðåä Õîò ×èëè Ïåïúðñ, Ïðèìóñ, Ðåéäæ Àãåéíñò äú Ìúøèí, Living Colour, White Zombie ñìåñâàò ôúíê ñ ìåòúë, âúïðåêè ÷å ïîâå÷åòî îò òÿõ ñà ñúçäàäåíè ïðåç 80-òå. Faith No More è Mr. Bungle ñìåñâàò ðåäèöà æàíðîâå ñ õàðä ðîêà, âàðèðàùè îò ðàï äî ñîóë. Äðóãè óñïåøíè åêñïåðèìåíòàëíè õàðä ðîê ãðóïè ñà Helmet è The Afghan Whigs. Ñìåñèöàòà îò ðåòðî ãëåì-ìåòúë ïîìàãà íà The Darkness äà ñå èçêà÷àò äî ãîðàíàòà ïîëîâèíà íà êëàñàöèèòå â íà÷àëîòî íà íîâèÿ âåê. Òîãàâà íîâèòå ãðóïè â ìåéíäòðèéìà êàòî Jet, Wolfmother, White Stripes, The Answer, The Glitterati, The Datsuns è Towers of London ñà âñúùíîñò íîâèòå ðîê ãðóïè îò ñúæèâÿâàíåòî íà ãàðàæíèÿ ðîê.\r\n\r\nÍàé-ãîëåìèòå õàðä ðîê ãðóïè â ïîñëåäíèòå ãîäèíè ñà ñóïåðãðóïè êàòî Velvet Revolver è Audioslave. Ïîñëåäíèòå ñà ñúñòàâåíè îò èíñòðóìåíòàëèñòèòå íà Rage Against the Machine è áèâøèÿ ôðîíòìåí íà Soundgarden Êðèñ Êîðíåë, íî ñå ðàçïàäàò ïðåç 2007 ã. Velvet Revolver ñå ñúñòîè îò áèâøèòå ÷ëåíîâå íà Guns N'' Roses ñ âîêàëà Ñêîò Óåéëúíä (îò Stone Temple Pilots). Òåçè ãðóïè ñúæèâÿâàò õàðä ðîê ñöåíàòà è ñå îñúùåñòâÿâàò ïîâòîðíè ñúáèðàíèÿ è ïîñëåäâàëè òóðíåòà íà Rage Against the Machine, Stone Temple Pilots, Living Colour, Âàí Õàëåí, Áëåê Ñàáàò, à ëåãåíääàðíèòå Ëåä Öåïåëèí èçíàñÿò åäèí êîíöåðò è âúçðàæäàò èíòåðåñà êúì ïðåäèøíèòå åðè.\r\n\r\n[size=5][color=purple]Íÿêîè èçâåñòíè õàðä ðîê ãðóïè [/color][/size]\r\n\r\n    * Deep Purple\r\n    * Led Zeppelin\r\n    * Black Sabbath\r\n    * Whitesnake\r\n    * Alice Cooper\r\n    * AC/DC\r\n    * Scorpions\r\n    * Aerosmith\r\n    * Rainbow\r\n    * Kiss\r\n    * Def Leppard\r\n    * Nazareth\r\n    * Foreigner\r\n    * Guns N'' Roses\r\n    * Ozzy Osbourne', 0, 0);
INSERT INTO `posts` VALUES (17, 16, 8, 1266173523, '[size=5][color=orange]Ïðèìåð íà ìóçèêàëíèòå ãèãàíòè...[/color][/size]\r\n\r\n[size=5][color=orange]Deep Purple - Smoke On The Water [/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=2WX_4FNoto4]', 8, 1266174000);
INSERT INTO `posts` VALUES (18, 16, 8, 1266173918, '[size=5][color=red]Led Zeppelin - Stairway To Heaven[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=0kNEo8OxrT8]', 0, 0);
INSERT INTO `posts` VALUES (19, 16, 8, 1266174173, '[size=5][color=navy]Black Sabbath Paranoid[/color][/size]\r\nòîâà ñå ñëóøà íà óñèëåíè òîêîëîíè äî êðàé çà äà ïî÷óñòâàìå åôåêòà ÿêî :thumbsup:\r\n\r\n[video=http://www.youtube.com/watch?v=_aIhh9nFYv4]', 0, 0);
INSERT INTO `posts` VALUES (20, 16, 8, 1266174425, '[size=5][color=red]Òàçè ãðóïà å èñòîðèÿ â ìóçèêàòà ïðîñòî óíèêàëíà...[/color][/size]\r\n\r\n[size=5][color=limegreen]Whitesnake - Here I Go Again[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=i3MXiTeH_Pg]', 0, 0);
INSERT INTO `posts` VALUES (21, 16, 8, 1266174691, '[size=5][color=beige]Alice Cooper - Poison[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=lD2NuB6OLf4]', 0, 0);
INSERT INTO `posts` VALUES (22, 16, 8, 1266175054, '[size=3][color=teal]Òîâà å íàé äîáðàòà õàðä ðîê ãðóïà çà ìîìåíòà îò âñè÷êè êîèòî ñà èçáðîåíè,íåçàâèñèìî îò ìíåíèåòî íà íÿêîé àêî èñêà äà ìå êîðèãèðà,àç ñå ïîçîâàâàì íà ñâåòîâíàòà ñòàòèñòèêà è ñúì â òå÷åíèå ñ òàçè ìóçèêà,çàáàâëÿâàéòå ñå ñêîðî ùå áúäàò è â Áúëãàðèÿ.[/color][/size]\r\n\r\n[size=5][color=maroon]AC/DC - Thunderstruck[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=zvoeeq-BH4w]', 0, 0);
INSERT INTO `posts` VALUES (23, 16, 8, 1266175680, '[size=5][color=navy]Scorpions - Send Me An Angel[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=1UUYjd2rjsE]', 0, 0);
INSERT INTO `posts` VALUES (24, 16, 8, 1266175800, '[size=5][color=limegreen]Aerosmith - I Don''t Wanna Miss a Thing[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=Vo_0UXRY_rY]', 0, 0);
INSERT INTO `posts` VALUES (25, 16, 8, 1266175958, '[size=6][color=yellow]Âåëèêà êëàñèêà..[/color][/size]\r\n\r\n[size=5][color=green]rainbow can''t let you go[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=tcwWdLnLCnI]', 0, 0);
INSERT INTO `posts` VALUES (26, 16, 8, 1266176206, '[size=6][color=green]Kiss - Forever[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=C8LSQNdkXPY]', 0, 0);
INSERT INTO `posts` VALUES (27, 16, 8, 1266176417, '[size=5][color=purple]Def Leppard - Pour Some Sugar On Me[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=6652YIBzByk&feature=fvst]', 0, 0);
INSERT INTO `posts` VALUES (28, 16, 8, 1266176518, '[size=5][color=blue]Nazareth - Love Hurts[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=L2BjJbKQkgc]', 0, 0);
INSERT INTO `posts` VALUES (29, 16, 8, 1266176689, '[size=5][color=navy]Foreigner-I Want to Know What Love Is[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=gz2cUX0CNA8]', 0, 0);
INSERT INTO `posts` VALUES (30, 16, 8, 1266176836, '[size=5][color=yellow]Guns N'' Roses - Don''t Cry[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=zRIbf6JqkNc&feature=fvst]', 0, 0);
INSERT INTO `posts` VALUES (31, 16, 8, 1266176992, '[size=5][color=red]Ozzy Osbourne-Dreamer[/color][/size]\r\n\r\n[video=http://www.youtube.com/watch?v=YbJqswLi3uE]', 8, 1266177095);

-- --------------------------------------------------------

-- 
-- Структура на таблица `ratings`
-- 

CREATE TABLE `ratings` (
  `infohash` char(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `userid` int(10) unsigned NOT NULL DEFAULT '1',
  `rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `added` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `infohash` (`infohash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `ratings`
-- 

INSERT INTO `ratings` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 7, 5, 1265050227);
INSERT INTO `ratings` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 7, 5, 1265228052);
INSERT INTO `ratings` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 7, 5, 1265453792);
INSERT INTO `ratings` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 7, 5, 1266006221);
INSERT INTO `ratings` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 7, 5, 1266147090);
INSERT INTO `ratings` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 7, 5, 1266159212);
INSERT INTO `ratings` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 8, 5, 1266262293);
INSERT INTO `ratings` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 7, 5, 1266699129);

-- --------------------------------------------------------

-- 
-- Структура на таблица `readposts`
-- 

CREATE TABLE `readposts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `topicid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpostread` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `topicid` (`topicid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=32 ;

-- 
-- Дъмп (схема) на данните в таблицата `readposts`
-- 

INSERT INTO `readposts` VALUES (31, 7, 13, 13);
INSERT INTO `readposts` VALUES (30, 7, 16, 30);
INSERT INTO `readposts` VALUES (29, 8, 16, 31);
INSERT INTO `readposts` VALUES (28, 7, 15, 15);
INSERT INTO `readposts` VALUES (27, 8, 15, 15);
INSERT INTO `readposts` VALUES (26, 7, 14, 14);
INSERT INTO `readposts` VALUES (25, 8, 14, 14);
INSERT INTO `readposts` VALUES (24, 8, 13, 13);

-- --------------------------------------------------------

-- 
-- Структура на таблица `realises`
-- 

CREATE TABLE `realises` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat` text NOT NULL,
  `poster` text NOT NULL,
  `name` text NOT NULL,
  `genre` text NOT NULL,
  `director` text NOT NULL,
  `staring` text NOT NULL,
  `description` text NOT NULL,
  `quality` text NOT NULL,
  `video` text NOT NULL,
  `audio` text NOT NULL,
  `time` text NOT NULL,
  `lang` text NOT NULL,
  `url` text NOT NULL,
  `imd` text NOT NULL,
  `added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8 AUTO_INCREMENT=206 ;

-- 
-- Дъмп (схема) на данните в таблицата `realises`
-- 

INSERT INTO `realises` VALUES (202, 'http://93.155.182.91/torrents.php?category=15', 'http://torrent51.com/bitbucket/p_80138.jpg', 'Zombieland.R5.LiNE.XviD-DEViSE', 'O?ane, Eiiaaey', '?oaai Oea?u?', 'A?ane Aecaiau?a, Oae Oa?aenui, Aia Noioi, Aaeaaee A?aneei, Aee Iu?e e a?.', 'Aaia oioaeia ia?iaey ia oeeieoa ca ciiaeoa a noee "Iiuoa ia ?eaeoa iu?oae", eiyoi i?ineaayaa enoi?eyoa ia Eueuiaun (A?ane Aecaiau?a "Naeioi" ) e Oaeaoane (Oae Oa?aenui "Naaai aooe" ). Eueuiaun eia iaaeea oye ?eaio aa ayaa, io oiaa eiaoi ai ieaoe. Io a?oaa no?aia Oaeaoane iyia IEEAEAE no?aoiaa, a ai?e e aa eia, ii nei?i ae ae ia?eoae io eieeioi aa ei na ioaaaa! A aaei nayo caaeaayi io ciiaeoa, oace aaaiaoa na eaaaeieoa ioaeyaaue, ii naaa a aioei a?aiaoi, a eiaoi oa ua o?yaaa aa na eci?aayo i?aa iae-aieyiioi i?aaecaeeaoaenoai - aa ayaao/iuooaao CAAAII!', 'R5', '640x272, 1023 kbps, XviD', 'MP3, 128 kbps', '01:24:04', 'Aueaa?nee noaoeo?e', 'http://93.155.182.91/details.php?id=f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 'http://www.imdb.com/title/tt0279600/', '0000-00-00 00:00:00');
INSERT INTO `realises` VALUES (203, 'http://93.155.182.91/torrents.php?category=15', 'http://www.iwatchstuff.com/2009/04/24/hangover-poster.jpg', 'The.Hangover.DVDRip.XviD-DoNE', 'Eiiaaey', 'Oia Oeeein', 'A?aaee Eoiu?, A?unoei Aa?oa, Oaau? A?aui, A?ao?e Oaiai?, Iaee Oaenui, ?ae?ue Oa?en, Cae Aaeeoaiaeen, Aa Oaein e a?oae', 'Aaa aie i?aae naaoaaoa ne, Aua e o?eia iaaiae i?eyoaee caieiaaao ca Aaaan, ca aa ioi?acioaao a?aaineioi io ia?oe.\r\n\r\nIa noo?eioa neaa eoiiia oaoa?eoa iyiao ieeaeua niiiai io i?aaeoiaoa aa?a?.\r\n\r\nIaciaeii caui a aaiyoa ia aia?oaiaioa, a eieoi na ionaaiaee iaie?ao oeau?, a a eeea?a oanoiana?ii aaaa. Oiaa, eiaoi ia iiaao aa ioe?eyo a …Aua.\r\n\r\nO?eioi o?yaaa aa na ni?aae n oa?ea caaa?a aac aa eiao ieeaeaa eaay eaeai noaaa.\r\n\r\nOa ?aciieaaao n o?anii iaeei a?aia, a eiaoi aa na iieoao aa ne niiiiyo eaeai na a neo?eei, aa iii?aayo iauaoa e aa au?iao Aua a Ae Ae iaa?aia ca oa?aiiieyoa.', 'DVDRip', '640x272, 881 kbps, XviD', 'MP3, 128 kbps', '01:36:23', 'Aueaa?nee noaoeo?e', 'http://93.155.182.91/details.php?id=04f361e39549edd0ed1a15307318372a6eb8f437', 'http://www.imdb.com/title/tt1119646/', '0000-00-00 00:00:00');
INSERT INTO `realises` VALUES (204, 'http://93.155.182.91/torrents.php?category=15', 'http://91.196.126.51/posters/654531813e3dd816948624299f912f649a2f1fc4Spread.jpg', 'Spread / I?ioaney ?eaiei (2009)', 'Eiiaaey', 'Aaeaea Iaeaice', '. Aooui Eu?u?, Ai Oa?e, Ia?aa?eoa Eaaeaaa, Naanoeai Noai, Niiy ?ieoae, Ia?ey Eii?eoa Aeiini e a?oae', 'I?IOANE? ?EAIEI ?aceacaa enoi?eyoa ia ecia?aiey ?aiea? Ieee (Aooui Euo?u?), eieoi oniyaa aa na aiaa?a ai naaoa ia i?eaeeaae?iaaieoa aeaaiaa?aiea ia iii?anoaioi ne aaaio??e. Oie ie ?ace?eaa oaeieoa ne, aieaoi aaaa ia?oeoa e i?anieaa n aanaoee ?aie e a nuuioi a?aia ?eaaa ia oe?iea iiaa a oieeaoaneey aii ia Naiaioa (Ai Oa?e), aaaieaoea ia n?aaia auc?ano. Ane?ei au?ae aia?a, aieaoi aaei aai Ieee n?aua e?aneaaoa na?aeoui?ea Oaau? (Ia?aa?eoa Eaaeaaa), eiyoi, aac oie aa iiaice?a, ea?aa nuuaoa ea?a. Ia?ao aaaiaoa na caii?aa naiaia?acia iaai?aaa?a, eiyoi ae ioaa?aa a eoenicie ?anoi?aioe e ia eceneaie eoiiie, aieaoi enoeiaoa ca ?eaioa ei ae i?eio?aaaa aa ecae?ao ia?ao e?aiaoa e ia?eoa. Aauoiiaai io oeeie eaoi Oaiiiai, Caeonea a Oeoaie e Aia?eeainee ?eaiei, I?IOANE? ?EAIEI penoaa ia?aceoa ia naenoaeai eciaiiee e iaaiaeoa ?a?oae. ', 'DVDRip', '624x256, 953kbps, XviD', 'MP3, 132 kbps', '01:37:12', 'Aueaa?nee noaoeo?e', 'http://93.155.182.91/details.php?id=a221070d430c2004dce2309b6a14096be62be8ab', 'http://www.imdb.com/title/tt1186370/', '0000-00-00 00:00:00');
INSERT INTO `realises` VALUES (205, 'http://93.155.182.91/torrents.php?category=15', 'http://www.iwatchstuff.com/2009/08/20/law-abiding-citizen-poster.jpg', 'Law Abiding Citizen / Niu?oiiinai i?ioeaiee (2009)', 'Aeoui, O?eeu?, A?aia', 'O. Aa?e A?ae', 'A?aeie Oien, A?a?a?a Auoeu?, E?enoei Noie, Iaeeue Aaiaui, Iaeeue U?ae, Aeiea Aaeaen, Eiei Ieeie, A?on Iaeaee, Eanee Aea, ?aa?eia Oie e a?oae', 'Euuaoa ia iaeeiiaaii aia?eeainei naiaenoai a ia?aia iin?aa aye aai! Nui?oaaoa e auua?yoa na a?ooaeii oaeoe i?e iae?a! Aauaoa Eeaea Oaeoui (A?a?a?a Auoeu?) ioaeyaa!\r\nIa neaa aueai oaeeoeoa na caeiaaie e n?auo oyo a caaaaaii aaei, i?ieo?i? a Iee ?aen (iineoaeyo ia "Inea?" A?aeie Oien). Oaouo ia ?aen ai i?eio?aaaa aa i?aaei?e ia aaei io aaaiaoa caiiaic?aie eaea i?enuaa a caiyia ia iaaiaeoa iieacaiey n?auo nuo?anoieea io!\r\nAiaeie ii-eunii nianeeeyo na i?anouiiee a iaia?ai iu?oua e Eeaea i?eciaaa aeiaoa ne, nei?i neaa oiaa ioi?aay e naiyoa caeaia eui i?ieo?i? ?aen, aa iii?aae ceeiaoa eiyoi a noi?ee eee aa iin?auia niu?ooa ia ee??iae oeao?e io ianoiyuey io i?ioan!\r\nIa neaa aueai Oaeoui oniyaa aa ecayaa io caoai?a, n eiaoi a a?aaa caii?aao ii?aaeoa io ecee??eoaeii a?ooaeie oaeenoaa, eieoi ia iiaao ieoi aa auaao i?iaiice?aie ieoi i?aaioa?aoaie! A?aauo na iioaiy a no?ao! Oaeeoa io nienuea ia Oaeoui iaaao aaia neaa a?oaa! Aeanoeoa na aacneeie aa ni?ao nioeiiaoa e oa?oaaiaoi ia oa?i?a io! Ia oia a i?ieo?i?uo ?aen....', 'TS', '640x228, 827 Kbps, XviD', 'LINE MP3, 128kbps', '01:42:31', 'Aueaa?nee noaoeo?e', 'http://93.155.182.91/details.php?id=bffe4c428730472db60ffe600d1c281c10a08a0b', 'http://www.imdb.com/title/tt1197624/', '0000-00-00 00:00:00');

-- --------------------------------------------------------

-- 
-- Структура на таблица `requests`
-- 

CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `request` varchar(225) DEFAULT NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fulfilled` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `cat` int(10) unsigned NOT NULL DEFAULT '0',
  `filled` varchar(255) DEFAULT NULL,
  `filledby` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Дъмп (схема) на данните в таблицата `requests`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `shoutboxstaff`
-- 

CREATE TABLE `shoutboxstaff` (
  `msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL DEFAULT '0',
  `message` text,
  `date` int(11) NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgid`),
  KEY `msgid` (`msgid`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

-- 
-- Дъмп (схема) на данните в таблицата `shoutboxstaff`
-- 

INSERT INTO `shoutboxstaff` VALUES (19, 'fakira', '[img]http://store.picbg.net/pubpic/56/C6/34d1a586430d56c6.gif[/img]', 1266178643, 8);
INSERT INTO `shoutboxstaff` VALUES (22, 'fakira', ':-D', 1266178756, 8);
INSERT INTO `shoutboxstaff` VALUES (24, 'lanselot', '[img]http://www.golisnimki.com/thumbs/1084.jpg[/img]', 1266247342, 7);
INSERT INTO `shoutboxstaff` VALUES (25, 'lanselot', ':-D', 1266247351, 7);
INSERT INTO `shoutboxstaff` VALUES (27, 'lanselot', '[img]http://www.fun-6.com/snimki/sme6ni-snimki/drugi/sme6ni/boski.gif[/img]', 1266247488, 7);
INSERT INTO `shoutboxstaff` VALUES (28, 'lanselot', '[url=http://www.fun-6.com/sme6ni-kartinki-2.htm]ñàéò çà ñìåøíè ñíèìêè[/url]', 1266247680, 7);
INSERT INTO `shoutboxstaff` VALUES (30, 'fakira', ':yikes:', 1266262191, 8);
INSERT INTO `shoutboxstaff` VALUES (31, 'lanselot', '[video=http://www.youtube.com/watch?v=IWDALIOzXNk]', 1266262390, 7);
INSERT INTO `shoutboxstaff` VALUES (32, 'fakira', '[video=http://www.youtube.com/watch?v=iSTBlbylMzM]', 1266263224, 8);
INSERT INTO `shoutboxstaff` VALUES (33, 'lanselot', '[video=http://www.youtube.com/watch?v=h7xF51AFkys]', 1266263761, 7);

-- --------------------------------------------------------

-- 
-- Структура на таблица `sponsor`
-- 

CREATE TABLE `sponsor` (
  `id2` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titel2` varchar(255) DEFAULT NULL,
  `banner2` varchar(255) DEFAULT NULL,
  `link2` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id2`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Дъмп (схема) на данните в таблицата `sponsor`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `style`
-- 

CREATE TABLE `style` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `style` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `style_url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=19 ;

-- 
-- Дъмп (схема) на данните в таблицата `style`
-- 

INSERT INTO `style` VALUES (13, 'black', './style/black');
INSERT INTO `style` VALUES (12, 'Dark', './style/dark');
INSERT INTO `style` VALUES (9, 'SKANARIA', './style/great');
INSERT INTO `style` VALUES (14, 'Klima', './style/klima');
INSERT INTO `style` VALUES (15, 'diablo', './style/diablo');
INSERT INTO `style` VALUES (17, 'satin', './style/satin');
INSERT INTO `style` VALUES (18, 'Gris', './style/Gris');

-- --------------------------------------------------------

-- 
-- Структура на таблица `summary`
-- 

CREATE TABLE `summary` (
  `info_hash` char(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dlbytes` bigint(20) unsigned NOT NULL DEFAULT '0',
  `seeds` int(10) unsigned NOT NULL DEFAULT '0',
  `leechers` int(10) unsigned NOT NULL DEFAULT '0',
  `finished` int(10) unsigned NOT NULL DEFAULT '0',
  `lastcycle` int(10) unsigned NOT NULL DEFAULT '0',
  `lastSpeedCycle` int(10) unsigned NOT NULL DEFAULT '0',
  `speed` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`info_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `summary`
-- 

INSERT INTO `summary` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 0, 0, 0, 0, 1267029907, 1257966964, 0);
INSERT INTO `summary` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 0, 0, 0, 0, 1267029907, 1257966964, 0);
INSERT INTO `summary` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 0, 0, 0, 0, 1267029908, 1257966963, 0);
INSERT INTO `summary` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 0, 0, 0, 0, 1267029908, 1257966964, 0);
INSERT INTO `summary` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 0, 0, 0, 0, 1267029908, 1257966963, 0);
INSERT INTO `summary` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 0, 0, 0, 0, 1267029908, 1257966962, 0);
INSERT INTO `summary` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 0, 0, 0, 0, 1267029908, 1257966963, 0);
INSERT INTO `summary` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 0, 0, 0, 0, 1267029908, 1257966961, 0);
INSERT INTO `summary` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 0, 0, 0, 0, 1267029908, 1257966963, 0);
INSERT INTO `summary` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 0, 0, 0, 0, 1267029908, 1257966962, 0);
INSERT INTO `summary` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 0, 0, 0, 0, 1267029908, 1257966961, 0);
INSERT INTO `summary` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 0, 0, 0, 0, 1267029908, 1257966962, 0);
INSERT INTO `summary` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 0, 0, 0, 0, 1267029908, 1257966964, 0);
INSERT INTO `summary` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 0, 0, 0, 0, 1267029908, 1257966961, 0);
INSERT INTO `summary` VALUES ('a37afec032d8c10ee8ddeb67d9f84f3951c8ad66', 0, 0, 0, 0, 1267029908, 1257967168, 0);
INSERT INTO `summary` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 0, 0, 0, 0, 1267029908, 1266523842, 0);
INSERT INTO `summary` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 0, 0, 0, 0, 1267029908, 1266525357, 0);
INSERT INTO `summary` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 0, 0, 0, 0, 1267029908, 1266523827, 0);
INSERT INTO `summary` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 0, 0, 0, 0, 1267029908, 1266525357, 0);
INSERT INTO `summary` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 0, 0, 0, 0, 1267029908, 1266523832, 0);
INSERT INTO `summary` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 0, 0, 0, 0, 1267029908, 1266525354, 0);
INSERT INTO `summary` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 0, 0, 0, 0, 1267029908, 1266525354, 0);
INSERT INTO `summary` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 0, 0, 0, 0, 1267029908, 1266525354, 0);
INSERT INTO `summary` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 0, 0, 0, 0, 1267029908, 1266525354, 0);
INSERT INTO `summary` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 0, 0, 0, 0, 1267029908, 1266525355, 0);
INSERT INTO `summary` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 0, 0, 0, 0, 1267029908, 1266520994, 0);
INSERT INTO `summary` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 0, 0, 0, 0, 1267029908, 1266525354, 0);
INSERT INTO `summary` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 0, 0, 0, 0, 1267029908, 1266525357, 0);
INSERT INTO `summary` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 0, 0, 0, 0, 1267029908, 1266525354, 0);
INSERT INTO `summary` VALUES ('230c91fff8491c9af76b23823e967a328e06c0ce', 0, 0, 0, 0, 1267029908, 1266593486, 0);

-- --------------------------------------------------------

-- 
-- Структура на таблица `tasks`
-- 

CREATE TABLE `tasks` (
  `task` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `last_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`task`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `tasks`
-- 

INSERT INTO `tasks` VALUES ('sanity', 1267029906);
INSERT INTO `tasks` VALUES ('update', 1267029856);

-- --------------------------------------------------------

-- 
-- Структура на таблица `thanks`
-- 

CREATE TABLE `thanks` (
  `infohash` char(40) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Дъмп (схема) на данните в таблицата `thanks`
-- 

INSERT INTO `thanks` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 7);
INSERT INTO `thanks` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 7);
INSERT INTO `thanks` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 7);

-- --------------------------------------------------------

-- 
-- Структура на таблица `timestamps`
-- 

CREATE TABLE `timestamps` (
  `info_hash` char(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sequence` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bytes` bigint(20) unsigned NOT NULL DEFAULT '0',
  `delta` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sequence`),
  KEY `sorting` (`info_hash`)
) ENGINE=MyISAM AUTO_INCREMENT=2614 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2614 ;

-- 
-- Дъмп (схема) на данните в таблицата `timestamps`
-- 

INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 405, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 491, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 424, 0, 1800);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 493, 0, 1801);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 429, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 488, 0, 1801);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 442, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 462, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 276, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 278, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 274, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 283, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 285, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 284, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 290, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 294, 0, 1803);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 292, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 293, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 298, 0, 1803);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 303, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 308, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 302, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 306, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 312, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 310, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 311, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 317, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 319, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 320, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 321, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 324, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 328, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 329, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 330, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 333, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 338, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 339, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 337, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 343, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 346, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 349, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 348, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 347, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 350, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 359, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 363, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 357, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 358, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 356, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 362, 0, 1825);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 372, 0, 1825);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 368, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 369, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 367, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 366, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 371, 0, 1804);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 370, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 381, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 377, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 382, 0, 1825);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 379, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 376, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 378, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 380, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 392, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 387, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 389, 0, 1800);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 400, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 391, 0, 1800);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 388, 0, 1800);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 386, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 393, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 419, 0, 65535);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 399, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 404, 0, 1802);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 403, 0, 1802);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 406, 0, 1843);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 418, 0, 65535);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 420, 0, 65535);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 422, 0, 65535);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 426, 0, 1800);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 415, 0, 65535);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 439, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 432, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 436, 0, 1801);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 434, 0, 1801);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 438, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 433, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 445, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 425, 0, 1800);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 452, 0, 1802);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 447, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 450, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 448, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 461, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 440, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 466, 0, 1800);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 471, 0, 1801);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 465, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 464, 0, 1801);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 455, 0, 1801);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 476, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 473, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 478, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 481, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 477, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 480, 0, 1801);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 469, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 490, 0, 1801);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 492, 0, 1801);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 484, 0, 1801);
INSERT INTO `timestamps` VALUES ('a37afec032d8c10ee8ddeb67d9f84f3951c8ad66', 494, 0, 1857);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 487, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 277, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 279, 0, 1800);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 280, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 281, 0, 1854);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 288, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 287, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 286, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 295, 0, 1803);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 296, 0, 1803);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 297, 0, 1802);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 304, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 307, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 305, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 314, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 313, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 316, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 323, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 326, 0, 1809);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 325, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 334, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 332, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 335, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 341, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 340, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 344, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 352, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 353, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 361, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 401, 0, 1802);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 451, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 458, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 459, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 475, 0, 1801);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 482, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 273, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 275, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 282, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 289, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 291, 0, 1801);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 299, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 300, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 301, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 309, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 315, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 318, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 322, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 327, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 331, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 336, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 342, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 345, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 351, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 354, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 355, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 360, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 364, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 365, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 373, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 374, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 375, 0, 1801);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 383, 0, 1801);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 384, 0, 1846);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 385, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 390, 0, 1800);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 394, 0, 1837);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 395, 0, 1802);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 396, 0, 1801);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 397, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 398, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 402, 0, 1802);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 407, 0, 1801);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 408, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 409, 0, 1801);
INSERT INTO `timestamps` VALUES ('2dff62bc5666f4437bf04139f9f8fb49f5e898b8', 410, 0, 65535);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 411, 0, 65535);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 412, 0, 65535);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 413, 0, 65535);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 414, 0, 65535);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 416, 0, 65535);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 417, 0, 65535);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 421, 0, 65535);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 423, 0, 65535);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 427, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 428, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 430, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 431, 0, 1801);
INSERT INTO `timestamps` VALUES ('ce35e936cb98bd40c6dd81959a6b13740be7cc28', 435, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 437, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 441, 0, 1801);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 443, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 444, 0, 1801);
INSERT INTO `timestamps` VALUES ('75578586eaa46319ed10e6d1b6609ecc2ff7e0da', 446, 0, 1801);
INSERT INTO `timestamps` VALUES ('d728b5a0948af20af1842580dd527902e9ef7c9c', 449, 0, 1801);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 453, 0, 1802);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 454, 0, 1802);
INSERT INTO `timestamps` VALUES ('4a930cf9a19b2ff5aaf1f2ca395126dc29d947b6', 456, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 457, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 460, 0, 1801);
INSERT INTO `timestamps` VALUES ('04f361e39549edd0ed1a15307318372a6eb8f437', 463, 0, 1801);
INSERT INTO `timestamps` VALUES ('e33c4b8b33ebba92f5ff42bddbc680bc145f8155', 467, 0, 1800);
INSERT INTO `timestamps` VALUES ('f92b3cb2cd4ba9d771e1f9e156180eaefcbe9042', 468, 0, 1800);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 470, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 472, 0, 1801);
INSERT INTO `timestamps` VALUES ('bffe4c428730472db60ffe600d1c281c10a08a0b', 474, 0, 1801);
INSERT INTO `timestamps` VALUES ('f3b91cb3bd38b87c05422d03f49ddc2b99a581ca', 479, 0, 1801);
INSERT INTO `timestamps` VALUES ('5190ad7b9c450543de602448d028cf5e99442dc1', 483, 0, 1801);
INSERT INTO `timestamps` VALUES ('97b0ff538f9825cb8204de523b22e2bb88aff493', 485, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f76e45579f9e2311b5e230bd6d4056e2ab218a3', 486, 0, 1801);
INSERT INTO `timestamps` VALUES ('a221070d430c2004dce2309b6a14096be62be8ab', 489, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2377, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2354, 0, 1802);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2396, 0, 1802);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2064, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2490, 0, 1803);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2438, 0, 146);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2449, 0, 65535);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2475, 0, 1803);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2440, 0, 146);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2460, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2509, 0, 1805);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2533, 0, 1799);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2515, 0, 1799);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2510, 0, 1805);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2534, 0, 1799);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2553, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2479, 0, 1803);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2519, 0, 1795);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2524, 0, 1799);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2550, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2546, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2516, 0, 1799);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2581, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2552, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2591, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2568, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2590, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2598, 0, 1526);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2562, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2578, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2566, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2587, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2600, 0, 1524);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2238, 0, 1800);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2575, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2594, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2203, 0, 107);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2607, 0, 1525);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2200, 0, 1799);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2259, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2233, 0, 1805);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2258, 0, 1801);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2248, 0, 1802);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2217, 0, 1800);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2267, 0, 1799);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2254, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2236, 0, 1806);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2299, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2252, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2316, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2232, 0, 1806);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2300, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1971, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2279, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2297, 0, 1799);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2250, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2312, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2272, 0, 1802);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2291, 0, 1801);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2278, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2294, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2301, 0, 1800);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2335, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2339, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2341, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2321, 0, 1802);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2331, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2344, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2309, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2322, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2311, 0, 1801);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2360, 0, 1802);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2327, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2365, 0, 1799);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2308, 0, 1802);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2313, 0, 1801);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2381, 0, 1802);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2364, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2342, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2375, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2352, 0, 1802);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2369, 0, 1799);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2336, 0, 1801);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2400, 0, 1801);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2419, 0, 65535);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2399, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2405, 0, 254);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2372, 0, 1800);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2433, 0, 65535);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2420, 0, 65535);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2382, 0, 1801);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2379, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2392, 0, 1800);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2401, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2027, 0, 1804);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2409, 0, 250);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2404, 0, 256);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2403, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2406, 0, 258);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2452, 0, 151);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2009, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2471, 0, 1801);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2442, 0, 147);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2470, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2436, 0, 65535);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2464, 0, 1797);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2422, 0, 65535);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2473, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2424, 0, 65535);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2459, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2472, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2269, 0, 1802);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2514, 0, 1812);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2444, 0, 65535);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2487, 0, 1803);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2492, 0, 1803);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2513, 0, 1812);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2478, 0, 1803);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2503, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2526, 0, 1799);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2518, 0, 1799);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2541, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2571, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2502, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2536, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2570, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2611, 0, 1527);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2593, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2556, 0, 1798);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2561, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2220, 0, 1800);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2260, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2606, 0, 1513);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2241, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2235, 0, 1807);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2224, 0, 1800);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2240, 0, 1802);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2234, 0, 1807);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2262, 0, 1802);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2324, 0, 1799);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2257, 0, 1802);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2287, 0, 1800);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2276, 0, 1802);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2319, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2273, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2289, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2296, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2310, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2329, 0, 1800);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2334, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1970, 0, 1801);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2326, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2314, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2363, 0, 1800);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2362, 0, 1800);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2349, 0, 1804);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2359, 0, 1800);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2367, 0, 1798);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2333, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2387, 0, 1801);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2371, 0, 1800);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2361, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2398, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2380, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2373, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2434, 0, 65535);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2402, 0, 1802);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2397, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2426, 0, 65535);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2418, 0, 992);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2437, 0, 200);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2416, 0, 258);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2425, 0, 65535);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2474, 0, 1800);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2447, 0, 65535);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2542, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2446, 0, 148);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2430, 0, 65535);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2407, 0, 258);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2454, 0, 151);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2045, 0, 1799);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2497, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2429, 0, 65535);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2431, 0, 65535);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2461, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2499, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2448, 0, 149);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2063, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2469, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2468, 0, 1798);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2482, 0, 1803);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2476, 0, 1803);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2462, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2483, 0, 1803);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2494, 0, 1803);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2489, 0, 1803);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2508, 0, 1805);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2480, 0, 1803);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2532, 0, 1799);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2512, 0, 1812);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2527, 0, 1798);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2548, 0, 1804);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2565, 0, 1801);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2574, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2549, 0, 1798);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2520, 0, 1795);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2535, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2544, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2528, 0, 1798);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2540, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2523, 0, 1799);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2551, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2507, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2560, 0, 1801);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2545, 0, 1804);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2573, 0, 1801);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2537, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2547, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2209, 0, 1801);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2602, 0, 1527);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2609, 0, 1527);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2559, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2572, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2213, 0, 1800);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2204, 0, 1802);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2585, 0, 1802);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2589, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2605, 0, 1527);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2219, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2564, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2214, 0, 1800);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2186, 0, 1798);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2595, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2206, 0, 1800);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2237, 0, 1798);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2230, 0, 1806);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2612, 0, 1527);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2266, 0, 1799);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2610, 0, 1515);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2229, 0, 1806);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2246, 0, 1802);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2253, 0, 1801);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2280, 0, 1801);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2251, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2243, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2242, 0, 1802);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2239, 0, 1802);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2271, 0, 1800);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2286, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2274, 0, 1802);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2256, 0, 1803);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2282, 0, 1802);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2263, 0, 1802);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2295, 0, 1801);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2270, 0, 1802);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2298, 0, 1801);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2338, 0, 1800);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2306, 0, 1802);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2281, 0, 1803);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2303, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2293, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2302, 0, 1800);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2318, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2355, 0, 1802);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2385, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1969, 0, 189);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2389, 0, 1801);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2353, 0, 1802);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2384, 0, 1804);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2408, 0, 251);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2428, 0, 65535);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2394, 0, 1802);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2411, 0, 249);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2417, 0, 254);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2511, 0, 1812);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2466, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2506, 0, 1801);
INSERT INTO `timestamps` VALUES ('230c91fff8491c9af76b23823e967a328e06c0ce', 2613, 0, 126);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2539, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2521, 0, 1795);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2522, 0, 1799);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2576, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2588, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2586, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2583, 0, 1801);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2228, 0, 1806);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2592, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2223, 0, 1801);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2261, 0, 1800);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2244, 0, 1803);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2277, 0, 1802);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2249, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2283, 0, 1799);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2340, 0, 1801);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2323, 0, 1802);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2317, 0, 1800);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2315, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2351, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2330, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2358, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2357, 0, 1802);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2383, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2378, 0, 1802);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2412, 0, 257);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2423, 0, 65535);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2395, 0, 1802);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2410, 0, 249);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2421, 0, 65535);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2445, 0, 149);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2453, 0, 151);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2496, 0, 1801);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2451, 0, 147);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2504, 0, 1802);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2481, 0, 1803);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2495, 0, 1801);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2517, 0, 1799);
INSERT INTO `timestamps` VALUES ('02c70ff4ba5991523265b4698e6f499d01f39325', 2493, 0, 1803);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2555, 0, 65535);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2530, 0, 1802);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2531, 0, 1799);
INSERT INTO `timestamps` VALUES ('2f3fb6392670b1c1476deffd1f5b046ac03d131b', 2529, 0, 1799);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2596, 0, 1526);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2569, 0, 1801);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2558, 0, 1798);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2577, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2603, 0, 1525);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2227, 0, 1807);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2608, 0, 1524);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2255, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2275, 0, 1802);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2292, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2290, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2337, 0, 1801);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2370, 0, 1800);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2356, 0, 1802);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2374, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2390, 0, 1800);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2455, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2498, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2477, 0, 1803);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2491, 0, 1803);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2486, 0, 1803);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1972, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1973, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1974, 0, 1801);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 1975, 0, 1800);
INSERT INTO `timestamps` VALUES ('402dd7c4e27d1d86ca6b3cd835e2c0164a083233', 2343, 0, 65535);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2350, 0, 1803);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2393, 0, 1802);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2435, 0, 145);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2427, 0, 65535);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2456, 0, 1801);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2441, 0, 144);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2458, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2439, 0, 146);
INSERT INTO `timestamps` VALUES ('d81d86324d1a113e5043817f878a39b4ec11ae81', 2579, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2584, 0, 1802);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2563, 0, 1801);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2580, 0, 1801);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2599, 0, 1527);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2597, 0, 1524);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2211, 0, 1801);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2225, 0, 1806);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2226, 0, 1807);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2231, 0, 1806);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2245, 0, 1802);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2247, 0, 1802);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2264, 0, 1800);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2265, 0, 1799);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2268, 0, 1800);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2284, 0, 1802);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2285, 0, 1801);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2288, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2304, 0, 1803);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2305, 0, 1802);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2307, 0, 1802);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2320, 0, 1801);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2325, 0, 1801);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2328, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2332, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2345, 0, 1802);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2346, 0, 1804);
INSERT INTO `timestamps` VALUES ('0cd24137c3222ebe5509f6e55c6abe7eb6cae7b1', 2347, 0, 1804);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2348, 0, 1804);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2366, 0, 1798);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2368, 0, 1799);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2376, 0, 1801);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2386, 0, 1802);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2388, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2391, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2413, 0, 254);
INSERT INTO `timestamps` VALUES ('e4552ae9a6992556b26bebd79ccfb2a93f66634a', 2414, 0, 258);
INSERT INTO `timestamps` VALUES ('5b3f8e5644dde537e8e8df8dae5756f47c74fa25', 2415, 0, 250);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2432, 0, 65535);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2443, 0, 147);
INSERT INTO `timestamps` VALUES ('74fa5ac7c1849a8e4d93fb548e055f136d5e1d82', 2450, 0, 149);
INSERT INTO `timestamps` VALUES ('1b441cb99839f95cd25ae2aedc17e4266b6c088b', 2457, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2463, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2465, 0, 1801);
INSERT INTO `timestamps` VALUES ('8147175e914d3ee41f5f5e436568ac5b6f61f23a', 2467, 0, 1801);
INSERT INTO `timestamps` VALUES ('e07a628ac7ece96531ed02db15ba76c0ec9ba0a7', 2484, 0, 1803);
INSERT INTO `timestamps` VALUES ('594fc7244ed3b3c4e5eaf94af67afa99accdddf9', 2485, 0, 1803);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2488, 0, 1803);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2500, 0, 1801);
INSERT INTO `timestamps` VALUES ('3ae6ab04b357ee90020d5ee7ae288ae0de6282da', 2501, 0, 1801);
INSERT INTO `timestamps` VALUES ('56ecd6559b00547d784eb06b68cae0bebed0cbb0', 2505, 0, 1802);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2525, 0, 1799);
INSERT INTO `timestamps` VALUES ('fb3fcd7802e224ebd8b68f72dc6ced476a3e16e2', 2538, 0, 1801);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2543, 0, 1801);
INSERT INTO `timestamps` VALUES ('83cc039dff36ba32da95a2bf0448507819dfd4cc', 2554, 0, 1801);
INSERT INTO `timestamps` VALUES ('a7a8b68bae557cda7193e10467ecdfba5a5fce17', 2557, 0, 1801);
INSERT INTO `timestamps` VALUES ('5388ec7bd53b72e44a25cbcd2b307b91b5d3dda3', 2567, 0, 1801);
INSERT INTO `timestamps` VALUES ('8e9351468d3bdfe8d24858a04713737bc73ad719', 2582, 0, 1801);
INSERT INTO `timestamps` VALUES ('07de55a880bafe1e1b85ca4a60329b39b9f191e9', 2601, 0, 1513);
INSERT INTO `timestamps` VALUES ('f82f76e1bc03aca7f23cecdaf9b2be414a004999', 2604, 0, 1526);

-- --------------------------------------------------------

-- 
-- Структура на таблица `timezone`
-- 

CREATE TABLE `timezone` (
  `difference` varchar(4) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `timezone` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`difference`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Дъмп (схема) на данните в таблицата `timezone`
-- 

INSERT INTO `timezone` VALUES ('-12', '(GMT - 12:00 hours) Enitwetok, Kwajalien');
INSERT INTO `timezone` VALUES ('-11', '(GMT - 11:00 hours) Midway Island, Samoa');
INSERT INTO `timezone` VALUES ('-10', '(GMT - 10:00 hours) Hawaii');
INSERT INTO `timezone` VALUES ('-9', '(GMT - 9:00 hours) Alaska');
INSERT INTO `timezone` VALUES ('-8', '(GMT - 8:00 hours) Pacific Time (US &amp; Canada)');
INSERT INTO `timezone` VALUES ('-7', '(GMT - 7:00 hours) Mountain Time (US &amp; Canada)');
INSERT INTO `timezone` VALUES ('-6', '(GMT - 6:00 hours) Central Time (US &amp; Canada), Mexico City');
INSERT INTO `timezone` VALUES ('-5', '(GMT - 5:00 hours) Eastern Time (US &amp; Canada), Bogota, Lima');
INSERT INTO `timezone` VALUES ('-4', '(GMT - 4:00 hours) Atlantic Time (Canada), Caracas, La Paz');
INSERT INTO `timezone` VALUES ('-3.5', '(GMT - 3:30 hours) Newfoundland');
INSERT INTO `timezone` VALUES ('-3', '(GMT - 3:00 hours) Brazil, Buenos Aires, Falkland Is.');
INSERT INTO `timezone` VALUES ('-2', '(GMT - 2:00 hours) Mid-Atlantic, Ascention Is., St Helena');
INSERT INTO `timezone` VALUES ('-1', '(GMT - 1:00 hours) Azores, Cape Verde Islands');
INSERT INTO `timezone` VALUES ('0', '(GMT) Casablanca, Dublin, London, Lisbon, Monrovia');
INSERT INTO `timezone` VALUES ('1', '(GMT + 1:00 hours) Brussels, Copenhagen, Madrid, Paris');
INSERT INTO `timezone` VALUES ('2', '(GMT + 2:00 hours) Kaliningrad, South Africa');
INSERT INTO `timezone` VALUES ('3', '(GMT + 3:00 hours) Baghdad, Riyadh, Moscow, Nairobi');
INSERT INTO `timezone` VALUES ('3.5', '(GMT + 3:30 hours) Tehran');
INSERT INTO `timezone` VALUES ('4', '(GMT + 4:00 hours) Abu Dhabi, Baku, Muscat, Tbilisi');
INSERT INTO `timezone` VALUES ('4.5', '(GMT + 4:30 hours) Kabul');
INSERT INTO `timezone` VALUES ('5', '(GMT + 5:00 hours) Ekaterinburg, Karachi, Tashkent');
INSERT INTO `timezone` VALUES ('5.5', '(GMT + 5:30 hours) Bombay, Calcutta, Madras, New Delhi');
INSERT INTO `timezone` VALUES ('6', '(GMT + 6:00 hours) Almaty, Colomba, Dhakra');
INSERT INTO `timezone` VALUES ('7', '(GMT + 7:00 hours) Bangkok, Hanoi, Jakarta');
INSERT INTO `timezone` VALUES ('8', '(GMT + 8:00 hours) Hong Kong, Perth, Singapore, Taipei');
INSERT INTO `timezone` VALUES ('9', '(GMT + 9:00 hours) Osaka, Sapporo, Seoul, Tokyo, Yakutsk');
INSERT INTO `timezone` VALUES ('9.5', '(GMT + 9:30 hours) Adelaide, Darwin');
INSERT INTO `timezone` VALUES ('10', '(GMT + 10:00 hours) Melbourne, Papua New Guinea, Sydney');
INSERT INTO `timezone` VALUES ('11', '(GMT + 11:00 hours) Magadan, New Caledonia, Solomon Is.');
INSERT INTO `timezone` VALUES ('12', '(GMT + 12:00 hours) Auckland, Fiji, Marshall Island');

-- --------------------------------------------------------

-- 
-- Структура на таблица `topics`
-- 

CREATE TABLE `topics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `locked` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `forumid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` int(10) unsigned NOT NULL DEFAULT '0',
  `sticky` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `subject` (`subject`),
  KEY `lastpost` (`lastpost`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=17 ;

-- 
-- Дъмп (схема) на данните в таблицата `topics`
-- 

INSERT INTO `topics` VALUES (13, 8, 'ÌÀÈÒÅ', 'no', 1, 13, 'no', 7);
INSERT INTO `topics` VALUES (14, 8, 'Êàëåíäàðà íà ìàèòå… íå êðàé, à åâîëþöèÿ', 'no', 1, 14, 'no', 4);
INSERT INTO `topics` VALUES (15, 8, ' AVAST! HOME/PRO 4..– ÎÑÍÎÂÍÈ ÍÀÑÒÐÎÉÊÈ', 'no', 6, 15, 'no', 10);
INSERT INTO `topics` VALUES (16, 8, 'Õàðä ðîê - Ìóçèêà....', 'no', 5, 31, 'no', 44);

-- --------------------------------------------------------

-- 
-- Структура на таблица `toppartner`
-- 

CREATE TABLE `toppartner` (
  `id1` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titel1` varchar(255) DEFAULT NULL,
  `banner1` varchar(255) DEFAULT NULL,
  `link1` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id1`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Дъмп (схема) на данните в таблицата `toppartner`
-- 


-- --------------------------------------------------------

-- 
-- Структура на таблица `users`
-- 

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `password` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `id_level` int(10) NOT NULL DEFAULT '1',
  `random` int(10) DEFAULT '0',
  `email` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `language` tinyint(4) NOT NULL DEFAULT '1',
  `style` tinyint(4) NOT NULL DEFAULT '1',
  `joined` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastconnect` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lip` bigint(11) DEFAULT '0',
  `downloaded` bigint(20) DEFAULT '0',
  `uploaded` bigint(20) DEFAULT '0',
  `avatar` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `pid` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `flag` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `topicsperpage` tinyint(3) unsigned NOT NULL DEFAULT '15',
  `postsperpage` tinyint(3) unsigned NOT NULL DEFAULT '15',
  `torrentsperpage` tinyint(3) unsigned NOT NULL DEFAULT '15',
  `cip` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `time_offset` varchar(4) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `temp_email` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seedbonus` decimal(5,1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id_level` (`id_level`),
  KEY `pid` (`pid`),
  KEY `cip` (`cip`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=16 ;

-- 
-- Дъмп (схема) на данните в таблицата `users`
-- 

INSERT INTO `users` VALUES (14, 'mitaka79', '18ae196003a01984549f548ffd926957', 7, 812598, 'owner@mitaka79.com', 3, 9, '2010-02-20 14:37:40', '2010-02-20 17:47:33', 1331969805, 0, 0, NULL, '320e9060f07c65006bc6f63600669e66', 104, 15, 15, 15, '79.100.63.13', '0', '', 0.0);
INSERT INTO `users` VALUES (9, 'kar98', 'cf65f8e3fef438c362c839e7aa0ca04c', 5, 412934, 'kar98k@ab.bg', 3, 18, '2010-02-01 21:27:12', '2010-02-01 21:36:08', 1314525862, 0, 0, NULL, '25ba8abef380e6238d55c636b7010078', 104, 15, 15, 15, '78.90.18.166', '0', '', 0.0);
INSERT INTO `users` VALUES (12, 'jlachka', 'ad0d40d6fcff4ca2d996d289d1a294ba', 3, 130495, 'ronaldo_18@abv.bg', 3, 9, '2010-02-09 19:42:32', '2010-02-19 15:32:32', 1596671123, 0, 0, NULL, '61c7d3c4074fc3717c68d547bd8bf9f8', 104, 15, 15, 15, '95.43.68.147', '0', '', 0.0);
INSERT INTO `users` VALUES (11, 'scheepers', '630f9e6355c1e75fc0c77d4f4026b0f0', 4, 974702, 'ivo_steelrock@abv.bg', 3, 18, '2010-02-09 19:00:01', '2010-02-09 19:04:37', 1412872958, 0, 0, NULL, 'b69e6bdb4367ab46569518d41009d56d', 104, 15, 15, 15, '84.54.186.254', '0', '', 0.0);
INSERT INTO `users` VALUES (7, 'lanselot', 'b4e5769de73ddc212fa8c24da2f87679', 8, 196079, 'crowni@mail.bg', 3, 9, '2010-01-31 12:35:06', '2010-02-24 16:45:14', 1520097656, 0, 0, 'http://1370.pg-server.de/include/images/avatars/212.gif', '04caf07a1455a74bfc9d3c6868843806', 104, 15, 15, 15, '90.154.217.120', '0', '', 0.0);
INSERT INTO `users` VALUES (8, 'fakira', '6cd3a01271850ebc99a481da7c2186a8', 8, 342033, 'fakira_amt@abv.bg', 3, 9, '2010-01-31 12:37:57', '2010-02-21 19:24:25', 1596671683, 0, 0, 'http://store.picbg.net/pubpic/DB/42/7a90a0dab3d3db42.gif', '907ae26e42a75c179bb8188cf781bc1a', 104, 15, 15, 15, '95.43.70.195', '0', '', 0.0);
INSERT INTO `users` VALUES (13, 'tishoyyy', 'cba0b62cbddba2ce2a12bb56b0ffff6f', 3, 779182, 'tishoyyy@abv.bg', 3, 18, '2010-02-10 18:58:07', '2010-02-10 18:59:56', 1467911156, 0, 0, NULL, '064a4075ba5aba833a7fa26bcbf8cd6a', 104, 15, 15, 15, '87.126.139.244', '0', '', 0.0);
INSERT INTO `users` VALUES (15, 'nasko', 'a27ba4a10b3df58cc52bf0ef685ec2dc', 3, 515783, 'nasko_masura@abv.bg', 3, 9, '2010-02-21 10:59:37', '2010-02-24 12:47:17', 1490416642, 0, 0, NULL, '447cd4169eb03cf80d0b4eac86207c07', 104, 15, 15, 15, '88.213.244.2', '0', '', 0.0);

-- --------------------------------------------------------

-- 
-- Структура на таблица `users_level`
-- 

CREATE TABLE `users_level` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_level` int(11) NOT NULL DEFAULT '0',
  `level` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `view_torrents` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `edit_torrents` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `delete_torrents` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `view_users` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `edit_users` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `delete_users` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `view_news` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `edit_news` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `delete_news` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `can_upload` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `can_download` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `view_forum` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `edit_forum` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `delete_forum` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `predef_level` enum('guest','validating','member','uploader','vip','moderator','admin','owner') COLLATE latin1_general_ci NOT NULL DEFAULT 'guest',
  `can_be_deleted` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'yes',
  `admin_access` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `prefixcolor` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `suffixcolor` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `WT` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `base` (`id`),
  KEY `id_level` (`id_level`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

-- 
-- Дъмп (схема) на данните в таблицата `users_level`
-- 

INSERT INTO `users_level` VALUES (1, 1, 'Guest', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'guest', 'no', 'no', '<b><i>', '', 0);
INSERT INTO `users_level` VALUES (2, 2, 'Validating', 'no', 'no', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'validating', 'no', 'no', '<b><i>', '', 0);
INSERT INTO `users_level` VALUES (3, 3, 'Member', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'no', 'no', 'member', 'no', 'no', '<span style=''color:#000000''><b><i>', '</span>', 0);
INSERT INTO `users_level` VALUES (4, 4, 'Uploader', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'yes', 'no', 'no', 'uploader', 'no', 'no', '<span style=''color:grey''><b><i>', '', 0);
INSERT INTO `users_level` VALUES (5, 5, 'VIP', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'no', 'no', 'vip', 'no', 'no', '<span style=''color:purple''><b><i>', '', 0);
INSERT INTO `users_level` VALUES (6, 6, 'Moderator', 'yes', 'yes', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'moderator', 'no', 'no', '<span style=''color: #428D67''><b><i>', '</span>', 0);
INSERT INTO `users_level` VALUES (7, 7, 'Administrator', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'admin', 'no', 'no', '<span style=''color:#FF8000''><b><i>', '</span>', 0);
INSERT INTO `users_level` VALUES (8, 8, 'Owner', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'owner', 'no', 'yes', '<span style=''color:red''><b><i>', '', 0);
INSERT INTO `users_level` VALUES (9, 4, 'Power User', 'yes', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'no', 'yes', 'yes', 'no', 'no', '', 'yes', 'no', '<span style=''color:#33CC33''><b><i>', '</span>', 0);
