<?php
// Unconfirmed Hack //
// Made by JBoy //
// 8 Februari 2007 //
require_once ("include/functions.php");
require_once ("include/config.php");
dbconn();

if (!$CURUSER || $CURUSER["mod_access"]=="no" || $CURUSER["edit_users"]=="no")
   {
	require_once "include/functions.php";
	require_once "include/config.php";
	standardheader(UN_HACK);
	block_begin(ERROR);
	err_msg(ERROR);
	print ("<br>");
	block_end();
	stdfoot();
   }
else
   {

standardheader(UNCONFIRMED);
block_begin(UNCONFIRMED);
global $CURUSER, $STYLEPATH;
?>
<table align="center" class=lista width=80%>
<tr><td class="lista" align="center"><?php echo UNCONFIRME;?></td></tr>
</table>
        <br>
		
<?php // unconfirmed users // ?>

		<table align="center" class=lista width=80%>
        <tr>
		<td class=header align=center><?php echo ID;?></td>
        <td class=header align=center><?php echo NAME;?></td>
		<td class=header align=center><?php echo EMAIL;?></td>
		<td class=header align=center><?php echo Ip;?></td>
		<td class=header align=center><?php echo Provider;?></td>
        <td class=header align=center width=60><? echo USER_LEVEL;?></td>
        <td class=header align=center><?php echo PEER_COUNTRY;?></td>
        <td class=header align=center><?php echo Datum;?></td>
		<td class=header align=center><?php echo EDIT;?></td>
		<td class=header align=center><?php echo Trace;?></td>
        <?php
 
        $query1="select prefixcolor, suffixcolor, users.id, users.cip,users.email, username,level,UNIX_TIMESTAMP(joined) AS joined,UNIX_TIMESTAMP(lastconnect) AS lastconnect, flag, flagpic, name FROM users INNER JOIN users_level ON users.id_level=users_level.id LEFT JOIN countries ON users.flag=countries.id WHERE users.id_level=2 ORDER BY users.username ASC";
        $rusers=mysql_query($query1);
        if (mysql_num_rows($rusers)==0) {
		?>
        <tr><td class=lista colspan=6><?php echo NOBODY?></td></tr>
        <?php
		}
		else
            {
                while ($row_user=mysql_fetch_array($rusers))
                      {
        print("<tr>\n");
		print("<td class=lista>".$row_user["id"]."</td>");
        print("<td class=lista><a href=userdetails.php?id=".$row_user["id"].">".unesc($row_user["prefixcolor"]).unesc($row_user["username"]).unesc($row_user["suffixcolor"])."</a></td>");
		 print("<td class=lista><a href=\"mailto:".$row_user["email"]."\">".$row_user["email"]."</a></td>");
		 	print("<td class=lista>".($row_user["cip"])."</td>");
		 $hostname2 = gethostbyaddr($row_user["cip"]);
		print("<td class=lista>".$hostname2."</td>");
		
		
        print("<td class=lista align=center>".$row_user["level"]."</td>");
        print("<td class=lista>". ( $row_user["flag"] == 0 ? "<img src='images/flag/unknown.gif' alt='".UNKNOWN."' title='".UNKNOWN."' />" : "<img src='images/flag/" . $row_user['flagpic'] . "' alt='" . $row_user['name'] . "' title='" . $row_user['name'] . "' />")."</td>");
        print("<td class=lista align=center>".($row_user["joined"]==0 ? NOT_AVAILABLE : date("d/m/Y H:i:s",$row_user["joined"]))."</td>");
        $last = $row_user['lastconnect'];
		print("<td class=lista><a href=account.php?act=mod&uid=".$row_user["id"]."&returnto=userdetails.php?id=".$row_user["id"].">".image_or_link("$STYLEPATH/edit.png","",EDIT)."</a></td>");
		print("<td class=lista><a href=http://ip-lookup.net/?ip=".$row_user["cip"]."&returnto=userdetails.php?id=".$row_user["id"].">".image_or_link("$STYLEPATH/trac.png","",IP_Lookup)."</a></td>");
		
		}
	}
}
        print("</table>\n</div>\n<br />");
		
		
		
		
		
		
			?>

<?php
// End Unconfirmed Hack //
// Made by JBoy //
// 8 Februari 2007 //
block_end();
stdfoot();
?> 