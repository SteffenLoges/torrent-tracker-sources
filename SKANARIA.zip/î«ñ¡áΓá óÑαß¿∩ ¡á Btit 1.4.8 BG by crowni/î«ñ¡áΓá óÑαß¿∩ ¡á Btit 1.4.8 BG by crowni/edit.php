<?php
require_once("include/functions.php");
require_once("include/config.php");

dbconn();

standardheader('Edit Torrents');

$scriptname = $_SERVER["PHP_SELF"];
$link = $_GET["returnto"];

if ($link=="")
   $link="torrents.php";

// save editing and got back from where i come

if ((isset($_POST["comment"])) && (isset($_POST["name"]))){

   if ($_POST["action"]==FRM_CONFIRM) {

   if ($_POST["name"]=='')
        {
        err_msg("Error!","You must specify torrent name.");
        stdfoot();
        exit;
   }

   if ($_POST["comment"]=='')
        {
        err_msg("Error!","You must specify description.");
        stdfoot();
        exit;
   }

   $fname=sqlesc(htmlspecialchars($_POST["name"]));
   $image=sqlesc(htmlspecialchars($_POST["image"]));
   $torhash=AddSlashes($_POST["info_hash"]);
//Bronze Torrents Hack
$bronze=$_POST['bronze'];
   if(is_null($bronze)) {
   		$br="bronze='no', ";
	} else {
		if($bronze==1) { 
		$br="bronze='yes', ";
   		}
   }
   write_log("Modified torrent $fname ($torhash)","modify");
   echo "<center>".PLEASE_WAIT."</center>";
   mysql_query("UPDATE namemap SET $br image=$image, filename=$fname, gamerzhut_url='" . AddSlashes($_POST["gamerzhut_url"]) . "', youtube_video='" . AddSlashes($_POST["youtube_video"]) . "', imdb_url='" . AddSlashes($_POST["imdb_url"]) . "', subs_sab='" . AddSlashes($_POST["subs_sab"]) . "', sub_url='" . AddSlashes($_POST["sub_url"]) . "', bgaudio='" . AddSlashes($_POST["bgaudio"]) . "', comment='" . AddSlashes($_POST["comment"]) . "', category=" . intval($_POST["category"]) . " WHERE info_hash='" . $torhash . "'");
   print("<script LANGUAGE=\"javascript\">window.location.href=\"$link\"</script>");
   exit();
   }

   else {
        print("<script LANGUAGE=\"javascript\">window.location.href=\"$link\"</script>");
        exit();
   }
}

// view torrent's details
if (isset($_GET["info_hash"])) {

  $query ="SELECT namemap.info_hash, namemap.bronze as bronze, namemap.filename, namemap.image, namemap.bgaudio, namemap.sub_url, namemap.subs_sab, namemap.imdb_url, namemap.youtube_video, namemap.gamerzhut_url, namemap.url, UNIX_TIMESTAMP(namemap.data) as data, namemap.size, namemap.comment, namemap.category as cat_name, summary.seeds, summary.leechers, summary.finished, summary.speed, namemap.uploader FROM namemap LEFT JOIN categories ON categories.id=namemap.category LEFT JOIN summary ON summary.info_hash=namemap.info_hash WHERE namemap.info_hash ='" . AddSlashes($_GET["info_hash"]) . "'";
  $res = mysql_query($query) or die(CANT_DO_QUERY.mysql_error());
  $results = mysql_fetch_array($res);

  if (!$results)
     err_msg(ERROR,TORRENT_EDIT_ERROR);

  else {

  block_begin(EDIT_TORRENT);

  if (!$CURUSER || ($CURUSER["edit_torrents"]=="no" && $CURUSER["uid"]!=$results["uploader"]))
     {
         err_msg(ERROR,CANT_EDIT_TORR);
         block_end();
         stdfoot();
         exit();
     }
?>

<div align="center">
<form action="<?php echo $scriptname."?returnto=$link"; ?>" method="post" name="edit">
<table class=lista>
<tr>
<td align=right class=header><?php echo FILE_NAME; ?>: </td><td class=lista><input type="text" name="name" value="<?php echo $results["filename"]; ?>" size="60" /></td>
</tr>
<tr>
<td align=right class=header>IMG: </td><td class=lista><a href=<?php echo $results["image"]; ?>><image src="<?php echo $results["image"]; ?>" border='0'></a></td>
</tr>
<tr>
<td align=right class=header>Edit IMG: </td><td class=lista><input type="text" name="image" value="<?php echo $results["image"]; ?>" size="60" /></td>
</tr>
<tr>
   <td align="left" class="header"><?echo SUBS_SAB;?>: </td>
   <td align="left" class="lista"><input type="text" size="50" name="subs_sab" maxlength="250" value="<? echo $results["subs_sab"]; ?>"/></td>
</tr>
<tr>
   <td align="left" class="header"><?echo SUB_URL;?>: </td>
   <td align="left" class="lista"><input type="text" size="50" name="sub_url" maxlength="250" value="<? echo $results["sub_url"]; ?>"/></td>
</tr>
<tr>
   <td align="left" class="header"><?echo IMDB_URL;?>: </td>
   <td align="left" class="lista"><input type="text" size="50" name="imdb_url" maxlength="250" value="<? echo $results["imdb_url"]; ?>"/></td>
</tr>
<tr>
   <td align="left" class="header"><?echo YOU_TUBE;?>: </td>
   <td align="left" class="lista"><input type="text" size="50" name="youtube_video" maxlength="250" value="<? echo $results["youtube_video"]; ?>"/></td>
</tr>
<tr>
   <td align="center" class="header"><?echo GAMERZHUT_URL;?>: </td>
   <td align="left" class="lista"><input type="text" size="50" name="gamerzhut_url" maxlength="250" value="<? echo $results["gamerzhut_url"]; ?>"/></td>
</tr>
<tr>
<td align=right class=header><?php echo INFO_HASH;?>:</td><td class=lista ><?php echo $results["info_hash"];  ?></td>
</tr><tr>
<td align=right class="header"><?php echo DESCRIPTION; ?>:</td><td class=lista><?php textbbcode("edit","comment",unesc($results["comment"])) ?></td>
</tr><tr>

<?php
       echo "<td align=right class=\"header\" >".CATEGORY_FULL." : </td><td class=\"lista\" align=\"left\">";

    categories($results["cat_name"]);

      echo "</td>";
//Bronze Torrents Hack
if($CURUSER["edit_torrents"]=="yes") {
if($results["bronze"] == "yes") { $chks=" checked='checked' "; }
print("<tr><TD class=\"header\" >Bronze Torrent: </TD><TD class=\"lista\"><input type='checkbox' name='bronze'" . $chks . " value='1' /> Bronze Torrent (You get the 1/3 of you donwloaded)</td></tr>");}
//BGAudio Hack Start
if ($results["bgaudio"] == "true") {
$selected=" selected=\"selected\""; }
else {
$selected=""; }
print("<tr><TD class=\"header\" align=\"right\">��������: </TD><TD class=\"lista\" align=\"left\">");
print("<select name=\"bgaudio\" size=\"1\">");
print("<option value=\"false\"".$selected.">".NO."</option>");
print("<option value=\"true\"".$selected.">".YES."</option>");
print("</select></TD></tr>");
//BGAudio Hack Stop
include("include/offset.php");

?>

</tr><tr>
<td align=right class="header"><?php echo SIZE; ?>:</td><td class="lista" ><?php echo makesize($results["size"]); ?></td>
</tr><tr>
<td align=right class="header"><?php echo ADDED; ?>:</td><td class="lista" ><?php echo date("d/m/Y",$results["data"]-$offset); ?></td>
</tr><tr>
<td align=right class="header"><?php echo DOWNLOADED; ?>:</td><td class="lista" ><?php echo $results["finished"]." ".X_TIMES; ?></td>
</tr><tr>
<td align=right class="header"><?php echo PEERS; ?>:</td><td class="lista" ><?php echo SEEDERS .": " .$results["seeds"].",".LEECHERS .": ". $results["leechers"]."=". ($results["leechers"]+$results["seeds"]). " ". PEERS; ?></td>
</tr>
<tr><td><INPUT TYPE=hidden NAME="info_hash" SIZE=40 VALUE=<?php echo $results["info_hash"];  ?>></TD><td></td></tr>
<tr><td ALIGN=RIGHT></td>
</table>
<table><td ALIGN=right>
<INPUT type="submit" value="<?php echo FRM_CONFIRM; ?>" name="action" />
</TD>
<td>
<INPUT type="submit" value="<?php echo FRM_CANCEL;?>" name="action" /></td>
</form>
</table>
</tr>
</div>

<?php
  }  // results

  block_end();

} // info_hash

stdfoot();

?>
