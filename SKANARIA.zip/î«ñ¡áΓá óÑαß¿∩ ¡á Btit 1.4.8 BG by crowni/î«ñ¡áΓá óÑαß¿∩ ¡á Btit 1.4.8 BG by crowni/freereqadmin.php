<?php

require_once("include/functions.php");

dbconn();

if(!$CURUSER || $CURUSER["admin_access"]=="no")
{
    standardheader("Access Denied");
    block_begin("Access Denied");
    err_msg(ERROR,"You do not have permission to access this page");
    block_end();
    stdfoot();
    exit();
}

standardheader("Free Leech Request Admin");

(isset($_GET["act"])?$act=$_GET["act"]:$act="");
(isset($_GET["id"])?$id=mysql_real_escape_string($_GET["id"]):$id="");

if($act=="approve" && $id!="")
{
    @mysql_query("UPDATE namemap SET free='yes' WHERE info_hash='$id'");
    @mysql_query("UPDATE free_leech_req SET approved='yes' WHERE info_hash='$id'");    
}
elseif($act=="decline")
{
    @mysql_query("UPDATE namemap SET free='no' WHERE info_hash='$id'");
    @mysql_query("UPDATE free_leech_req SET approved='no' WHERE info_hash='$id'"); 
}
elseif($act=="nuke")
{
    @mysql_query("UPDATE namemap SET free='no' WHERE info_hash='$id'");
    @mysql_query("DELETE FROM free_leech_req WHERE info_hash='$id'"); 
}

?>
<script type="text/javascript">
<!--
var newwindow;
function popdetails(url)
{
  newwindow=window.open(url,'popdetails','height=500,width=500,resizable=yes,scrollbars=yes,status=yes');
  if (window.focus) {newwindow.focus()}
}
function poppeer(url)
{
  newwindow=window.open(url,'poppeers','height=400,width=700,resizable=yes,scrollbars=yes');
  if (window.focus) {newwindow.focus()}
}
// -->
</script>
<?php

$query ="SELECT flr.*, n.filename, UNIX_TIMESTAMP(n.data) added, n.size, ";
$query.="n.uploader, u.username uploader_username, s.seeds, s.leechers, ";
$query.="s.finished, n.category, c.name, c.image, ul.prefixcolor, ul.suffixcolor ";
$query.="FROM free_leech_req flr ";
$query.="LEFT JOIN namemap n ON flr.info_hash=n.info_hash ";
$query.="LEFT JOIN users u ON n.uploader=u.id ";
$query.="LEFT JOIN summary s ON s.info_hash=flr.info_hash ";
$query.="LEFT JOIN categories c ON n.category=c.id ";
$query.="LEFT JOIN users_level ul ON u.id_level=ul.id ";
$query.="ORDER BY added DESC";

$res=mysql_query($query);
if(mysql_num_rows($res)>0)
{
    block_begin("Free Leech Request Admin");
    while($row=mysql_fetch_assoc($res))
    {
        if($row["approved"]=="undecided")
        {
            $table["undecided"][]="<tr><td class='lista' align='center'><a href='torrents.php?category=".$row["category"]."'><img border=0 src='images/categories/".$row["image"]."'></a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:popdetails('details.php?id=".$row["info_hash"]."');":"details.php?id=".$row["info_hash"])."\">".$row["filename"]."</a></td><td class='lista' align='center'>".date("d/m/Y",$row["added"])."</td><td class='lista' align='center'>".makesize($row["size"])."</td><td class='lista' align='center'><a href='userdetails.php?id=".$row["uploader"]."'>".stripslashes($row[prefixcolor]).$row["uploader_username"].stripslashes($row[suffixcolor])."</a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('peers.php?id=".$row["info_hash"]."');":"peers.php?id=".$row["info_hash"])."\"><font color='".linkcolor($row["seeds"])."'>".$row["seeds"]."</font></a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('peers.php?id=".$row["info_hash"]."');":"peers.php?id=".$row["info_hash"])."\"><font color='".linkcolor($row["leechers"])."'>".$row["leechers"]."</font></a></td><td class='lista' align='center'>".(($row["finished>0"])?"<a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('torrent_history.php?id=".$row["info_hash"]."');":"torrent_history.php?id=".$row["info_hash"])."\">".$row["finished"]."</a>":"---")."</td><td class='lista' align='center'>".$row["count"]."</td><td class='lista' align='center'><a onclick='return confirm(\"Are you sure you want to approve this torrent for Free Leech?\")' href='".$_SERVER["PHP_SELF"]."?act=approve&amp;id=".$row["info_hash"]."'><img border=0 src='images/smilies/thumbsup.gif' alt='Approve request'></a></td><td class='lista' align='center'><a onclick='return confirm(\"Are you sure you want to decline this torrent for Free Leech?\")' href='".$_SERVER["PHP_SELF"]."?act=decline&amp;id=".$row["info_hash"]."'><img border=0 src='images/smilies/thumbsdown.gif' alt='Decline request'></a></td><td class='lista' align='center'><a onclick='return confirm(\"Are you sure you want to nuke (clear all votes) for this torrent?\")' href='".$_SERVER["PHP_SELF"]."?act=nuke&amp;id=".$row["info_hash"]."'><img border=0 src='images/smilies/nuke.gif' alt='Nuke request'></a></td></tr>";
        }
        elseif($row["approved"]=="yes")
        {
            $table["approved"][]="<tr><td class='lista' align='center'><a href='torrents.php?category=".$row["category"]."'><img border=0 src='images/categories/".$row["image"]."'></a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:popdetails('details.php?id=".$row["info_hash"]."');":"details.php?id=".$row["info_hash"])."\">".$row["filename"]."</a></td><td class='lista' align='center'>".date("d/m/Y",$row["added"])."</td><td class='lista' align='center'>".makesize($row["size"])."</td><td class='lista' align='center'><a href='userdetails.php?id=".$row["uploader"]."'>".stripslashes($row[prefixcolor]).$row["uploader_username"].stripslashes($row[suffixcolor])."</a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('peers.php?id=".$row["info_hash"]."');":"peers.php?id=".$row["info_hash"])."\"><font color='".linkcolor($row["seeds"])."'>".$row["seeds"]."</font></a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('peers.php?id=".$row["info_hash"]."');":"peers.php?id=".$row["info_hash"])."\"><font color='".linkcolor($row["leechers"])."'>".$row["leechers"]."</font></a></td><td class='lista' align='center'>".(($row["finished>0"])?"<a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('torrent_history.php?id=".$row["info_hash"]."');":"torrent_history.php?id=".$row["info_hash"])."\">".$row["finished"]."</a>":"---")."</td><td class='lista' align='center'>".$row["count"]."</td><td class='lista' align='center'><a onclick='return confirm(\"Are you sure you want to nuke (clear all votes) for this torrent? **WARNING** doing this on an approved torrent will also set the torrent back to a regular torrent\")' href='".$_SERVER["PHP_SELF"]."?act=nuke&amp;id=".$row["info_hash"]."'><img border=0 src='images/smilies/nuke.gif' alt='Nuke request'></a></td></tr>";
        }
        elseif($row["approved"]=="no")
        {
            $table["declined"][]="<tr><td class='lista' align='center'><a href='torrents.php?category=".$row["category"]."'><img border=0 src='images/categories/".$row["image"]."'></a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:popdetails('details.php?id=".$row["info_hash"]."');":"details.php?id=".$row["info_hash"])."\">".$row["filename"]."</a></td><td class='lista' align='center'>".date("d/m/Y",$row["added"])."</td><td class='lista' align='center'>".makesize($row["size"])."</td><td class='lista' align='center'><a href='userdetails.php?id=".$row["uploader"]."'>".stripslashes($row[prefixcolor]).$row["uploader_username"].stripslashes($row[suffixcolor])."</a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('peers.php?id=".$row["info_hash"]."');":"peers.php?id=".$row["info_hash"])."\"><font color='".linkcolor($row["seeds"])."'>".$row["seeds"]."</font></a></td><td class='lista' align='center'><a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('peers.php?id=".$row["info_hash"]."');":"peers.php?id=".$row["info_hash"])."\"><font color='".linkcolor($row["leechers"])."'>".$row["leechers"]."</font></a></td><td class='lista' align='center'>".(($row["finished>0"])?"<a href=\"".(($GLOBALS["usepopup"])?"javascript:poppeer('torrent_history.php?id=".$row["info_hash"]."');":"torrent_history.php?id=".$row["info_hash"])."\">".$row["finished"]."</a>":"---")."</td><td class='lista' align='center'>".$row["count"]."</td><td class='lista' align='center'><a onclick='return confirm(\"Are you sure you want to approve this torrent for Free Leech?\")' href='".$_SERVER["PHP_SELF"]."?act=approve&amp;id=".$row["info_hash"]."'><img border=0 src='images/smilies/thumbsup.gif' alt='Approve request'></a></td><td class='lista' align='center'><a onclick='return confirm(\"Are you sure you want to nuke (clear all votes) for this torrent?\")' href='".$_SERVER["PHP_SELF"]."?act=nuke&amp;id=".$row["info_hash"]."'><img border=0 src='images/smilies/nuke.gif' alt='Nuke request'></a></td></tr>";
        }        
    }
    if(isset($table["undecided"]))
    {
        print("<br /><center><strong><u><font size=3>Undecided</font></u></strong></center><br />");
        print("<table align='center' width='90%'><tr>");
        print("<td class='header' align='center'>".CATEGORY."</td>");
        print("<td class='header' align='center'>".FILE."</td>");
        print("<td class='header' align='center'>".ADDED."</td>");
        print("<td class='header' align='center'>".SIZE."</td>");
        print("<td class='header' align='center'>".UPLOADER."</td>");
        print("<td class='header' align='center'>S</td>");
        print("<td class='header' align='center'>L</td>");
        print("<td class='header' align='center'>C</td>");
        print("<td class='header' align='center'>".VOTES."</td>");
        print("<td class='header' align='center'>Approve</td>");
        print("<td class='header' align='center'>Decline</td>");
        print("<td class='header' align='center'>Nuke</td></tr>");

        foreach($table["undecided"] as $v)
        {
            print($v);
        }
        print("</table>");
    }
    if(isset($table["approved"]))
    {
        print("<br /><center><strong><u><font size=3>Approved</font></u></strong></center><br />");
        print("<table align='center' width='90%'><tr>");
        print("<td class='header' align='center'>".CATEGORY."</td>");
        print("<td class='header' align='center'>".FILE."</td>");
        print("<td class='header' align='center'>".ADDED."</td>");
        print("<td class='header' align='center'>".SIZE."</td>");
        print("<td class='header' align='center'>".UPLOADER."</td>");
        print("<td class='header' align='center'>S</td>");
        print("<td class='header' align='center'>L</td>");
        print("<td class='header' align='center'>C</td>");
        print("<td class='header' align='center'>".VOTES."</td>");
        print("<td class='header' align='center'>Nuke</td></tr>");

        foreach($table["approved"] as $v)
        {
            print($v);
        }
        print("</table>");
    } 
    if(isset($table["declined"]))
    {
        print("<br /><center><strong><u><font size=3>Declined</font></u></strong></center><br />");
        print("<table align='center' width='90%'><tr>");
        print("<td class='header' align='center'>".CATEGORY."</td>");
        print("<td class='header' align='center'>".FILE."</td>");
        print("<td class='header' align='center'>".ADDED."</td>");
        print("<td class='header' align='center'>".SIZE."</td>");
        print("<td class='header' align='center'>".UPLOADER."</td>");
        print("<td class='header' align='center'>S</td>");
        print("<td class='header' align='center'>L</td>");
        print("<td class='header' align='center'>C</td>");
        print("<td class='header' align='center'>".VOTES."</td>");
        print("<td class='header' align='center'>Approve</td>");
        print("<td class='header' align='center'>Nuke</td></tr>");

        foreach($table["declined"] as $v)
        {
            print($v);
        }
        print("</table>");
    } 
    print("<br />");
    block_end();
}
else
{
    block_begin("Nothing to see");
    err_msg(ERROR,"No torrents have been voted for yet.");
    block_end();
    stdfoot();
    exit();
}


stdfoot();

?>