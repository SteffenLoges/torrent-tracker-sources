<?php
require_once ("include/functions.php");
require_once ("include/config.php");

$scriptname = htmlspecialchars($_SERVER["PHP_SELF"]);
$addparam = "";

dbconn();

standardheader('Torrents');

if(!$CURUSER || $CURUSER["view_torrents"]!="yes")
{
    err_msg(ERROR.NOT_AUTHORIZED." ".MNU_TORRENT."!",SORRY."...");
    stdfoot();
    exit();
}

block_begin(MNU_TORRENT);


if(isset($_GET["search"]))
{
    $trova = htmlspecialchars(str_replace ("+"," ",$_GET["search"]));
} else {
    $trova = "";
}
?>
<? $popup_mode = $_COOKIE["NO_INFO_POPUPS"];?>

<script type="text/javascript">
<!--

<? if ($popup_mode == 0){?>
var popup_mode = 1;
<?}else{?>
var popup_mode = 0;
<?}?> 

function popup_change(){
var expdate = new Date();
expdate.setTime (expdate.getTime() + (5 * 365 * 24 * 60 * 60 * 1000));
setCookie("NO_INFO_POPUPS", popup_mode, expdate, "/", "84.238.170.214/tracker", 0);
var thelink = document.getElementById("popup_change_link");
if (popup_mode){
thelink.innerHTML = "";
}
else{
thelink.innerHTML = "";
}
popup_mode = (popup_mode + 1) % 2;
nd();
}
-->
</script>
<script type="text/javascript">
<!--
var newwindow;
function popdetails(url)
{
  newwindow=window.open(url,'popdetails','height=500,width=500,resizable=yes,scrollbars=yes,status=yes');
  if (window.focus) {newwindow.focus()}
}
function poppeer(url)
{
  newwindow=window.open(url,'poppeers','height=400,width=700,resizable=yes,scrollbars=yes');
  if (window.focus) {newwindow.focus()}
}
// -->
</script>
<p align="center">
<form action="<?php $scriptname;?>" method="get">
  <table border="0" class="lista" align="center">
  <tr>
  <td class="block"><?php echo TORRENT_SEARCH;?></td>
  <td class="block"><?php echo CATEGORY_FULL;?></td>
  <td class="block"><?php echo TORRENT_STATUS;?></td>
  <td class="block">Options</td>
  <td class="block">&nbsp;</td>
  </tr>
  <tr>
  <td><input type="text" name="search" size="30" maxlength="50" value="<?php $trova;?>"></td>
  <td><?php
    $category = (!isset($_GET["category"])?0:explode(";",$_GET["category"]));
    // sanitize categories id
    if (is_array($category))
        $category = array_map("intval",$category);
    else
        $category = 0;

    categories( $category[0] );

    if(isset($_GET["active"]))
    {
        $active=intval($_GET["active"]);
    } else {
        $active=1;
    }
	if(isset($_GET["options"]))
    {
        $options=max(0,$_GET["options"]);
    } else {
        $options=0;
    }
    // all
    if($active==0)
    {
        $where = " WHERE 1=1";
        $addparam.="active=0";
    } // active only
    elseif($active==1){
        $where = " WHERE leechers+seeds > 0";
        $addparam.="active=1";
    } // dead only
    elseif($active==2){
        $where = " WHERE leechers+seeds = 0";
        $addparam.="active=2";
} // Bronze Torrent
    elseif($active==3){
        $where = " WHERE bronze = 1";
        $addparam.="active=3";
    }
  ?>
  </td>
  <td>
  <select name="active" size="1">
  <option value="0"<?php if ($active==0) echo " selected=selected " ?>><?php echo ALL; ?></option>
  <option value="1"<?php if ($active==1) echo " selected=selected " ?>><?php echo ACTIVE_ONLY; ?></option>
  <option value="3"<?php if ($active==3) echo " selected=selected " ?>><?php echo BRONZE; ?></option>
  <option value="2"<?php if ($active==2) echo " selected=selected " ?>><?php echo DEAD_ONLY; ?></option>
  </select>
  </td>
  <td>
  <select name="options" size="1">
  <option value="0"<? if ($options==0) echo " selected=selected " ?>>Title Only</option>
  <option value="1"<? if ($options==1) echo " selected=selected " ?>>Title & Desc.</option>
  </select>
  </td>
  <td><input type="submit" value="<?php echo SEARCH; ?>"></td>

<td width=10 align=center><nobr></td>
   </tr>
   <div id="kbrowse" style="display: none;"><table width=100% border="0" class=statusbar >
 <tr>
 <br>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c21 type="checkbox" value=1>
                  <a href="?search=&category=13"><b>��������</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c27 type="checkbox" value=1>
                  <a href="?search=&category=14"><b>�������/TV</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c72 type="checkbox" value=1>
                  <a href="?search=&category=15"><b>�����/XviD</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c73 type="checkbox" value=1>
                  <a href="?search=&category=16"><b>�����/DVD-R</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c75 type="checkbox" value=1>
                  <a href="?search=&category=17"><b>�����/HDTV</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c45 type="checkbox" value=1>
                  <a href="?search=&category=18"><b>����/PC-ISO</b></a></td>
</tr><tr><div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c47 type="checkbox" value=1>
                  <a href="?search=&category=19"><b>����/PS2</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c67 type="checkbox" value=1>
                  <a href="?search=&category=20"><b>����/PS3</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c70 type="checkbox" value=1>
                  <a href="?search=&category=21"><b>����/PSP</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c48 type="checkbox" value=1>
                  <a href="?search=&category=22"><b>����/XBOX</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c49 type="checkbox" value=1>
                  <a href="?search=&category=23"><b>������/MP3</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c71 type="checkbox" value=1>
                  <a href="?search=&category=24"><b>�����/�������</b></a></td>
</tr><tr><div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c37 type="checkbox" value=1>
                  <a href="?search=&category=25"><b>�����</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c64 type="checkbox" value=1>
                  <a href="?search=&category=26"><b>��������</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c50 type="checkbox" value=1>
                  <a href="?search=&category=27"><b>Mobile/GSM</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c52 type="checkbox" value=1>
                  <a href="?search=&category=28"><b>�����</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c53 type="checkbox" value=1>
                  <a href="?search=&category=29"><b>XXX</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c54 type="checkbox" value=1>
                  <a href="?search=&category=30"><b>Windows</b></a></td>
</tr><tr><div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c56 type="checkbox" value=1>
                  <a href="?search=&category=31"><b>Linux</b></a></td>
<div align=center><td align=left class="bottom" style="padding-bottom: 2px;padding-left: 7px">
                  <input name=c57 type="checkbox" value=1>
                  <a href="?search=&category=32"><b>MAC</b></a></td>

</tr>
<td></td>
<td></td>
</div>
  


  </tr>
  </table>
</form>
</p>
<TABLE width="100%" >
<TR>
<?php

/* Rewrite, part 1: encode "WHERE" statement only. */

// echo "Totale torrents trovati: $count";
// selezione categoria
if ($category[0]>0) {
   $where .= " AND category IN (".implode(",",$category).")"; // . $_GET["category"];
   $addparam.="&amp;category=".implode(";",$category); // . $_GET["category"];
}
global $pagertop, $pagerbottom, $query_select;
// Search
if (isset($_GET["search"])) {
   $testocercato = trim($_GET["search"]);
   $testocercato = explode(" ",$testocercato);
   if ($_GET["search"]!="")
      $search = "search=" . implode("+",$testocercato);
    for ($k=0; $k < count($testocercato); $k++) {
        $query_select .= " (namemap.filename LIKE '%" . mysql_escape_string($testocercato[$k]) . "%'";
        if ($options>0)
            $query_select .= " OR namemap.comment LIKE '%" . mysql_escape_string($testocercato[$k]) . "%')";
            else
            $query_select .= ")";
        if ($k<count($testocercato)-1)
           $query_select .= " AND ";
    }
    $where .= " AND " . $query_select;
}

// FINE RICERCA

// conteggio dei torrents...

$res = mysql_query("SELECT COUNT(*) FROM summary LEFT JOIN namemap ON summary.info_hash = namemap.info_hash $where")
        or die(mysql_error());

$row = mysql_fetch_row($res);
$count = $row[0];
if (!isset($search)) $search = "";

if ($count) {
   if ($addparam != "") {
      if ($search != "")
         $addparam .= "&amp;" . $search . "&amp;";
      //else
          //$addparam .= "&";
   }
   else {
      if ($search != "")
         $addparam .=  $search . "&amp;";
      else
          $addparam .= ""; //$scriptname . "?";
      }

    $torrentperpage=intval($CURUSER["torrentsperpage"]);
    if ($torrentperpage==0)
        $torrentperpage=($ntorrents==0?15:$ntorrents);

    // getting order
/******************************************************************************
    if (isset($_GET["order"]))
         $order=htmlspecialchars(mysql_escape_string($_GET["order"]));
    else
        $order="data";

    if (isset($_GET["by"]))
        $by=htmlspecialchars(mysql_escape_string($_GET["by"]));
    else
        $by="DESC";
******************************************************************************/

// Fixed possible SQL injection (thanks to jeremie78)
   $accepted_orders = array('speed', 'dwned', 'finished', 'leechers','seeds', 'size', 'data', 'filename', 'cname');
   $order = (isset($_GET['order']) && in_array($_GET['order'],$accepted_orders)) ? $_GET['order'] : 'data';
   $by = (isset($_GET["by"]) && $_GET["by"]=='ASC') ? 'ASC' : 'DESC';

//


     list($pagertop, $pagerbottom, $limit) = pager($torrentperpage, $count,  $scriptname."?" . $addparam.(strlen($addparam)>0?"&amp;":"")."options=$options&amp;order=$order&amp;by=$by&amp;");

// Do the query with the uploader nickname
if ($SHOW_UPLOADER)
    $query = "SELECT namemap.bronze as bronze, summary.info_hash as hash, summary.seeds, summary.leechers, summary.finished as finished,  summary.dlbytes as dwned , namemap.filename, namemap.bgaudio, namemap.gamerzhut_url, namemap.url, namemap.info, namemap.anonymous, summary.speed, UNIX_TIMESTAMP( namemap.data ) as added, categories.image, categories.name as cname, namemap.category as catid, namemap.size, namemap.comment, namemap.image as img, namemap.external, namemap.uploader as upname, users.username as uploader, prefixcolor, suffixcolor FROM summary LEFT JOIN namemap ON summary.info_hash = namemap.info_hash LEFT JOIN categories ON categories.id = namemap.category LEFT JOIN users ON users.id = namemap.uploader LEFT JOIN users_level ON users.id_level=users_level.id $where ORDER BY $order $by $limit";

// Do the query without the uploader nickname
else
    $query = "SELECT namemap.bronze as bronze, summary.info_hash as hash, summary.seeds, summary.leechers, summary.finished as finished,  summary.dlbytes as dwned , namemap.filename, namemap.bgaudio, namemap.gamerzhut_url, namemap.url, namemap.info, summary.speed, UNIX_TIMESTAMP( namemap.data ) as added, categories.image, categories.name as cname, namemap.category as catid, namemap.size, namemap.comment, namemap.image as img, namemap.external, namemap.uploader FROM summary LEFT JOIN namemap ON summary.info_hash = namemap.info_hash LEFT JOIN categories ON categories.id = namemap.category $where ORDER BY $order $by $limit";
// End the queries
   $results = mysql_query($query) or err_msg(ERROR,CANT_DO_QUERY.mysql_error()."<br>".$query);
}

$i = 0;

if ($by=="ASC")
    $mark="&nbsp;&#8593";
else
    $mark="&nbsp;&#8595";

?>
</TR>
<TR>
<TD COLSPAN=3 align=center> <? echo $pagertop ?></td>
</tr>
<? if($popup_mode == 1) {
$help_balons = "������ ��������� ������";
}
else { $help_balons = "����� ��������� ������";}
?>
<td style="padding-right:5px; text-align: right;" width=30%>
<a href="javascript:;" onmouseover="if(popup_mode){overlib('��� �� ������� �� ������� ���������� ������ �� ��� ������ �� �� ���������. ', CAPTION, '���������/�������� �� ��������');}" onmouseout="return nd();" class="popup_change" id="popup_change_link" onclick="return popup_change();"><? echo $help_balons; ?></a>
</td>
</tr>

<TR>
<TABLE width="100%" class="lista">
<!-- Column Headers  -->
<TR>
<?php
?>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=cname&amp;by=".($order=="cname" && $by=="ASC"?"DESC":"ASC")."\">".CATEGORY."</a>".($order=="cname"?$mark:""); ?></TD>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=filename&amp;by=".($order=="filename" && $by=="ASC"?"DESC":"ASC")."\">".FILE."</a>".($order=="filename"?$mark:""); ?></TD>
<TD align="center" class="header"><?php echo COMMENT; ?></TD>
<TD align="center" class="header"><?php echo RATING; ?></TD>
<?php
if (intval($CURUSER["WT"])>0)
    print("<TD align=\"center\" class=\"header\">".WT."</TD>");
?>
<TD align="center" class="header"><?php echo DOWN; ?></TD>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=data&amp;by=".($order=="data" && $by=="ASC"?"DESC":"ASC")."\">".ADDED."</a>".($order=="data"?$mark:""); ?></TD>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=size&amp;by=".($order=="size" && $by=="DESC"?"ASC":"DESC")."\">".SIZE."</a>".($order=="size"?$mark:""); ?></TD>
<?php
if ($SHOW_UPLOADER)
    print ("<TD align=\"center\" class=\"header\">".UPLOADER."</TD>");
?>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=seeds&amp;by=".($order=="seeds" && $by=="DESC"?"ASC":"DESC")."\">".SHORT_S."</a>".($order=="seeds"?$mark:""); ?></TD>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=leechers&amp;by=".($order=="leechers" && $by=="DESC"?"ASC":"DESC")."\">".SHORT_L."</a>".($order=="leechers"?$mark:""); ?></TD>
<TD align="center" class="header"><?php echo "<a href=\"$scriptname?$addparam".(strlen($addparam)>0?"&amp;":"")."order=finished&amp;by=".($order=="finished" && $by=="ASC"?"DESC":"ASC")."\">".SHORT_C."</a>".($order=="finished"?$mark:""); ?></TD>
<!--
<TD align="center" class="header"></TD>
<TD align="center" class="header"></TD>
-->
</TR>
<TR>

<?php
if ($SHOW_UPLOADER && intval($CURUSER["WT"])>0)
    echo "<TD colspan=\"15\" class=\"lista\"></TD>";
elseif ($SHOW_UPLOADER || intval($CURUSER["WT"])>0)
    echo "<TD colspan=\"14\" class=\"lista\"></TD>";
else
    echo "<TD colspan=\"13\" class=\"lista\"></TD>";
?>
</TR>
<?php
function limit_text( $text, $limit )
{
 if( strlen($text)>$limit )
 {
   $text = substr( $text,0,$limit );
   $text = substr( $text,0,-(strlen(strrchr($text,' '))) ).' ...';
 }
 return $text;
}
if ($count) {
  if (!isset($values[$i % 2])) $writeout = "";
  else $writeout = $values[$i % 2];
  while ($data=mysql_fetch_array($results))
  {
$com = limit_text(mysql_real_escape_string(format_comment($data["comment"])), 120);
//BGAudio Hack Start
  if ($data["bgaudio"] == "true") {
    $bgaudio = '<img title="������ � � ��������� ��������" src="images/subs.gif" />';
  }
  else {   $bgaudio='';
  }
 
  //BGAudio Hack Stop
if($data['bronze']=="yes") {
		$bronze = '<img title="1/3 �� ���������" src="images/bronze.gif" />';	 
	} else { $bronze=""; }
   // search for comments
   $commentres = mysql_query("SELECT COUNT(*) as comments FROM comments WHERE info_hash='" . $data["hash"] . "'");
   $commentdata = mysql_fetch_assoc($commentres);
   echo "<TR>\n";
   echo "\t<td align=\"center\" class=\"lista\"><a href=torrents.php?category=$data[catid]>".image_or_link(($data["image"]==""?"":"images/categories/" . $data["image"]),"",$data["cname"])."</td>";
   if ($GLOBALS["usepopup"])
       echo "\t<TD align=\"left\" class=\"lista\"><A HREF=\"javascript:popdetails('details.php?id=".$data["hash"]."');\" title=\"".VIEW_DETAILS.": ".$data["filename"]."\">".$data["filename"]."</A>".($data["external"]=="no"?"":" (<span style=\"color:red\">EXT</span>)")."  ".$bronze."  ".($data["gamerzhut_url"]==""?"":"".image_or_link("./images/gamerzhut.gif","",GamerzHut)."")."  ".$bgaudio."</td>";
   else
       echo "\t<TD align=\"left\" class=\"lista\">&nbsp;&nbsp;<A HREF=\"details.php?id=".$data["hash"]."\" onmouseover=\"if(popup_mode){ overlib('<table><tr><td COLSPAN=2 style=\'font-size: 12px;\'>"; if (!empty($data["img"])){ echo"<img src=\'".$data["img"]."\' width=\'150\' />"; } echo"</td><td style=\'vertical-align: top;\'>".htmlentities($com, ENT_QUOTES, "cp1251")."</td></tr></table>', CAPTION, '<div style=\'font-weight:bold; font-size: 12px;\'> ".$data["filename"]."</div>');}\" onmouseout=\"return nd();\">".$data["filename"]." </A>".($data["external"]=="no"?"":" (<span style=\"color:red\">EXT</span>)")."   ".$bronze."  ".($data["gamerzhut_url"]==""?"":"".image_or_link("./images/gamerzhut.gif","",GamerzHut)."")."  ".$bgaudio."</td>";
   if ($commentdata) {
      if ($commentdata["comments"]>0)
        {
         if ($GLOBALS["usepopup"])
              echo "\t<TD align=\"center\" class=\"lista\"><A HREF=\"javascript:popdetails('details.php?id=".$data["hash"]."#comments');\" title=\"".VIEW_DETAILS.": ".$data["filename"]."\">" . $commentdata["comments"] . "</A></td>";
         else
             echo "\t<TD align=\"center\" class=\"lista\"><A HREF=\"details.php?id=".$data["hash"]."#comments\" title=\"".VIEW_DETAILS.": ".$data["filename"]."\">".$commentdata["comments"]."</A></td>";
        }
     else
         echo "\t<TD align=\"center\" class=\"lista\">--</td>";
   }
   else echo "\t<TD align=\"center\" class=\"lista\">--</td>";

   // Rating
   $vres = mysql_query("SELECT sum(rating) as totrate, count(*) as votes FROM ratings WHERE infohash = '" . $data["hash"] . "'");
   $vrow = @mysql_fetch_array($vres);
   if ($vrow && $vrow["votes"]>=1)
      {
      $totrate=round($vrow["totrate"]/$vrow["votes"],1);
      if ($totrate==5)
         $totrate="<img src=$STYLEPATH/5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
      elseif ($totrate>4.4 && $totrate<5)
         $totrate="<img src=$STYLEPATH/4.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
      elseif ($totrate>3.9 && $totrate<4.5)
         $totrate="<img src=$STYLEPATH/4.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
      elseif ($totrate>3.4 && $totrate<4)
         $totrate="<img src=$STYLEPATH/3.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
      elseif ($totrate>2.9 && $totrate<3.5)
         $totrate="<img src=$STYLEPATH/3.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
      elseif ($totrate>2.4 && $totrate<3)
         $totrate="<img src=$STYLEPATH/2.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
      elseif ($totrate>1.9 && $totrate<2.5)
         $totrate="<img src=$STYLEPATH/2.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
      elseif ($totrate>1.4 && $totrate<2)
         $totrate="<img src=$STYLEPATH/1.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
      else
         $totrate="<img src=$STYLEPATH/1.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\"  />";
      }
   else
       $totrate=NA;

   echo "\t<TD align=\"center\" class=\"lista\">$totrate</td>\n";
    // end rating

    //waitingtime
    // display only if the curuser have some WT restriction
    if (intval($CURUSER["WT"])>0)
        {
        $wait=0;
        $resuser=mysql_query("SELECT * FROM users WHERE id=".$CURUSER["uid"]);
        $rowuser=mysql_fetch_array($resuser);
        $wait=0;
        if (intval($rowuser['downloaded'])>0) $ratio=number_format($rowuser['uploaded']/$rowuser['downloaded'],2);
        else $ratio=0.0;
//        $res2 =mysql_query("SELECT * FROM namemap WHERE info_hash='".$data["hash"]."'");
//        $added=mysql_fetch_array($res2);
        $vz = $data["added"];
        $timer = floor((time() - $vz) / 3600);
        if($ratio<1.0 && $rowuser['id']!=$data["uploader"]){
            $wait=$CURUSER["WT"];
        }
        $wait -=$timer;

        if ($wait<=0)$wait=0;
       if (strlen($data["hash"]) > 0)
            echo "\t<td align=\"center\" class=\"lista\">".($wait>0?$wait." h":"---")."</td>\n"; // WT
    //end waitingtime
    }
       echo "\t<TD align=\"center\" class=\"lista\"><A HREF=download.php?id=".$data["hash"]."&amp;f=" . urlencode($data["filename"]) . ".torrent>".image_or_link("images/download.gif","","torrent")."</A></TD>\n";

   include("include/offset.php");
   echo "\t<td align=\"center\" class=\"lista\">" . date("d/m/Y",$data["added"]-$offset) . "</td>\n"; // data
   echo "\t<td align=\"center\" class=\"lista\">" . makesize($data["size"]) . "</td>\n";
//Uploaders nick details
if ($SHOW_UPLOADER && $data["anonymous"] == "true")
echo "\t<td align=\"center\" class=\"lista\">" . ANONYMOUS . "</td>\n";
elseif ($SHOW_UPLOADER && $data["anonymous"] == "false")
echo "\t<td align=\"center\" class=\"lista\"><a href=userdetails.php?id=" . $data["upname"] . ">".StripSlashes($data['prefixcolor'].$data["uploader"].$data['suffixcolor'])."</a></td>\n";
//Uploaders nick details
   if ($data["external"]=="no")
      {
       if ($GLOBALS["usepopup"])
         {
         echo "\t<td align=\"center\" class=\"".linkcolor($data["seeds"])."\"><a href=\"javascript:poppeer('peers.php?id=".$data["hash"]."');\" title=\"".PEERS_DETAILS."\">" . $data["seeds"] . "</a></td>\n";
         echo "\t<td align=\"center\" class=\"".linkcolor($data["leechers"])."\"><a href=\"javascript:poppeer('peers.php?id=".$data["hash"]."');\" title=\"".PEERS_DETAILS."\">" .$data["leechers"] . "</a></td>\n";
         if ($data["finished"]>0)
            echo "\t<td align=\"center\" class=\"lista\"><a href=\"javascript:poppeer('torrent_history.php?id=".$data["hash"]."');\" title=\"History - ".$data["filename"]."\">" . number_format($data["finished"],0) . "</a></td>";
         else
             echo "\t<td align=\"center\" class=\"lista\">---</td>";
         }
       else
         {
         echo "\t<td align=\"center\" class=\"".linkcolor($data["seeds"])."\"><a href=\"peers.php?id=".$data["hash"]."\" title=\"".PEERS_DETAILS."\">" . $data["seeds"] . "</a></td>\n";
         echo "\t<td align=\"center\" class=\"".linkcolor($data["leechers"])."\"><a href=\"peers.php?id=".$data["hash"]."\" title=\"".PEERS_DETAILS."\">" .$data["leechers"] . "</a></td>\n";
         if ($data["finished"]>0)
            echo "\t<td align=\"center\" class=\"lista\"><a href=\"torrent_history.php?id=".$data["hash"]."\" title=\"History - ".$data["filename"]."\">" . number_format($data["finished"],0) . "</a></td>";
         else
             echo "\t<td align=\"center\" class=\"lista\">---</td>";
         }
      }
   else
       {
       // linkcolor
       echo "\t<td align=\"center\" class=\"".linkcolor($data["seeds"])."\">" . $data["seeds"] . "</td>";
       echo "\t<td align=\"center\" class=\"".linkcolor($data["leechers"])."\">" .$data["leechers"] . "</td>";
       if ($data["finished"]>0)
          echo "\t<td align=\"center\" class=\"lista\">" . number_format($data["finished"],0) . "</td>";
       else
           echo "\t<td align=\"center\" class=\"lista\">---</td>";
   }

/*
  // edit and delete picture/link
  if ($CURUSER["uid"]==$data["uploader"] || $CURUSER["edit_torrents"]=="yes")
     print("<td class=\"lista\" align=\"center\"><a href=edit.php?info_hash=".$data["hash"]."&amp;returnto=".urlencode("torrents.php").">".image_or_link("$STYLEPATH/edit.gif","",EDIT)."</a></td>");
  else
      print("<td class=\"lista\" align=\"center\">&nbsp;</td>");

  if ($CURUSER["uid"]==$data["uploader"] || $CURUSER["delete_torrents"]=="yes")
     print("<td class=\"lista\" align=\"center\"><a href=delete.php?info_hash=".$data["hash"]."&amp;returnto=".urlencode("torrents.php").">".image_or_link("$STYLEPATH/delete.gif","",DELETE)."</a></td>");
  else
      print("<td class=\"lista\" align=\"center\">&nbsp;</td>");
*/
   echo "</TR>\n";
   $i++;
  }
} // if count

if ($i == 0 && $SHOW_UPLOADER)
         echo "<TR><TD class=\"lista\" colspan=\"17\" align=\"center\">".NO_TORRENTS."</TD></TR>";
elseif ($i == 0 && !$SHOW_UPLOADER) echo "<TR><TD class=\"lista\" colspan=\"16\" align=\"center\">".NO_TORRENTS."</TD></TR>";

?>
</TR>
</TABLE>
<TR><TD colspan="2" align="center"> <?php echo $pagerbottom ?></TD></TR>

<?php

block_end();
stdfoot();
?>