<?
require_once ("include/functions.php");
require_once ("include/config.php");

dbconn(true);
standardheader('Delete and Edite Index Releases');

if (!$CURUSER || ($CURUSER["edit_torrents"]=="no" && $CURUSER["uid"]!=$results["uploader"]))
   {
	block_begin('Delete and Edite Index Releases');   
	err_msg(ERROR,ERR_PERM_DENIED);
	block_end();
    stdfoot();
	exit;
}
if ($action == 'delete')
{
        $id = 0 + $_GET["id"];
        if (!is_valid_id($id))
        err_msg("������","�� ������ id");
        $returnto = $_GET["returnto"];
        $sure = $_GET["sure"];
        if (!$sure)
            err_msg("�������","������������� ������ �������? ��������\n<a href=?action=delete&id=$id&returnto=$returnto&sure=1>�����</a> ���� �������.");
        mysql_query("DELETE FROM indexrelases WHERE id=$id") or sqlerr(__FILE__, __LINE__);
        if ($returnto != "")
            header("Location: $returnto");
        else
        $warning = "������� �������.";
}
if ($action == 'edit')
{
        $id = 0 + $_GET["id"];
        if (!is_valid_id($id))
          err_msg("������","�� ������ id");
        $res = mysql_query("SELECT * FROM indexrelases WHERE id=$id") or sqlerr(__FILE__, __LINE__);
        if (mysql_num_rows($res) != 1)
           err_msg("������", "��� �������� � ID $id.");
        $arr = mysql_fetch_array($res);
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
                $name = $_POST['name'];
                if ($name == "")
           err_msg("������", "������� ��������!");
                $cover = $_POST['cover'];
                if ($cover == "")
                   err_msg("������", "������� ����� ��������!");
				$director = $_POST['director'];	
				if($director == "")
				err_msg("Error","Enter Director's Name!");
				$genre = $_POST['genre'];	
				if($genre == "")
				    err_msg("Error","Enter Genre of the Movie!");
				$country = $_POST['country'];	
				if($country == "")
				err_msg("Error","Enter Country of the Movie!");
				$year = $_POST['year'];	
				if($year == "")
			       err_msg("Error","Enter Year of Movie!");
				 $actors= $_POST['actors'];
				 if($actors == "")
				   err_msg("Error","Enter actors name's!");
                $description = $_POST['description'];
                if ($description == "")
               err_msg("������", "������� ��������!");
				$quality = $_POST['quality'];
				if ($quality == "")
				    stderr("Error",  "Enter the quality!");
				$video = $_POST['video'];
				if ($video == "")
				    stderr("Error", "Enter video!");
				$audio = $_POST['audio'];
                if ($audio == "")
                  err_msg("Error", "Enter Audio?!");
               $time = $_POST['time'];
               if ($time == "")
                   err_msg("Error", "Enter Duration?!");
               $lang = $_POST['lang'];
               if ($lang == "")
                   err_msg("Error", "Enter translation?!");
                $link = $_POST['link'];
                if ($link == "")
                   err_msg("������", "������� ������ �� �������� � ���������!");
				$imdb = $_POST['imdb'];
				if ($imdb ==  "")
				err_msg("Error", "Enter IMDB link!");
                $forum_link = $_POST['forum_link'];
                if ($forum_link == "")
                   err_msg("������", "������� ������ �� ������!");
                $category = $_POST['category'];
                if ($category == "" || $category == 0)
                   err_msg("������", "������� ���������!");
                $name = sqlesc($name);
                $cover = sqlesc($cover);
				$director = sqlesc($director);
				$genre = sqlesc($genre);
				$country = sqlesc($country);
				$year = sqlesc($year);
				$actors = sqlesc($actors);
                $description = sqlesc($description);
				$quality = sqlesc($quality);
				$video = sqlesc($video);
                $audio = sqlesc($audio);
                $time = sqlesc($time);
                $lang = sqlesc($lang);
                $link = sqlesc($link);
				$imdb = sqlesc($imdb);
                $forum_link = sqlesc($forum_link);
                mysql_query("UPDATE indexrelases SET name = $name, cover = $cover, director = $director,genre = $genre,country = $country ,year = $year,actors = $actors, description = $description, quality = $quality,video = $video , audio = $audio,time = $time , lang = $lang, link = $link, imdb = $imdb, forum_link = $forum_link, category = $category WHERE id=$id") or sqlerr(__FILE__, __LINE__);
                $returnto = $_POST['returnto'];
                if ($returnto != "")
                   header("Location: $returnto");
                else
                   $warning = "������,������..........";
        }
        stdhead("Editing Movie");
        print ("<h2>Editing Movie</h2>");
        print ("<table width=600 border=1 cellspacing=0 cellpadding=10><tr><td class=text>");
        print("<form method=post action=?action=edit&id=$id>\n");
        print("<table border=0 cellspacing=0 cellpadding=5>\n");
        print("<input type=hidden name=returnto value=$returnto></td></tr>\n");
        tr("Name: ", "<input type=\"text\" name=\"name\" size=\"80\" maxlength=\"250\" value=\"" . $arr["name"] . "\"/>\n", 1);
        tr("Poster: ", "<input type=\"text\" name=\"cover\" size=\"80\" maxlength=\"250\" value=\"" . $arr["cover"] . "\"/>", 1);
		tr("Director: ", "<input type=\"text\" name=\"director\" size=\"80\" maxlength=\"250\" value=\"" . $arr["director"] . "\"/>", 1);
		tr("Genre: ", "<input type=\"text\" name=\"genre\" size=\"80\" maxlength=\"250\" value=\"" . $arr["genre"] . "\"/>", 1);
		tr("Country: ", "<input type=\"text\" name=\"country\" size=\"80\" maxlength=\"250\" value=\"" . $arr["country"] . "\"/>", 1);
		tr("Year: ", "<input type=\"text\" name=\"year\" size=\"80\" maxlength=\"250\" value=\"" . $arr["year"] . "\"/>", 1);
		tr("Actors: ", "<input type=\"text\" name=\"actors\" size=\"80\" maxlength=\"250\" value=\"" . $arr["actors"] . "\"/>", 1);
        tr("Description:","<textarea name=description cols=78 rows=20>" . $arr["description"] . "</textarea>\n",1);
	    tr("Quality: ", "<input type=\"text\" name=\"quality\" size=\"80\" maxlength=\"250\" value=\"" . $arr["quality"] . "\"/>", 1);
		 tr("Video: ", "<input type=\"text\" name=\"video\" size=\"80\" maxlength=\"250\" value=\"" . $arr["video"] . "\"/>", 1);
		 tr("Audio: ", "<input type=\"text\" name=\"audio\" size=\"80\" maxlength=\"250\" value=\"" . $arr["audio"] . "\"/>", 1);
		 tr("Time: ", "<input type=\"text\" name=\"time\" size=\"80\" maxlength=\"250\" value=\"" . $arr["time"] . "\"/>", 1);
		 tr("Language: ", "<input type=\"text\" name=\"lang\" size=\"80\" maxlength=\"250\" value=\"" . $arr["lang"] . "\"/>", 1);
        tr("Torrent: ", "<input type=\"text\" name=\"link\" size=\"80\" value=\"" . $arr["link"] . "\" maxlength=\"250\"/>\n", 1);
		tr("IMDB: ", "<input type=\"text\" name=\"imdb\" size=\"80\" value=\"" . $arr["imdb"] . "\" maxlength=\"250\"/>\n", 1);
        tr("Forum: ", "<input type=\"text\" name=\"forum_link\" size=\"80\" value=\"" . $arr["forum_link"] . "\" maxlength=\"250\"/>\n", 1);
        $s = "<select name=\"category\" id=\"type\">\n<option value=\"0\">(�������)</option>\n";
        $cats = genrelist();
        foreach ($cats as $row)
        {
                $i++;
                $s .= "<option value=\"" . $row["id"] . "\"" .  ($row["id"]==$arr["category"]?"selected":"") . ">" . htmlspecialchars($row["name"]) . "</option>\n";
        }
        $s .= "</select>\n";
        tr("Type", $s, 1);
        print("<tr><td></td><td align=center><input type=submit value='Change' class=btn></td></tr>\n");
        print("</table>\n");
        print("</form>\n");

  block_end();

} // index delete and edit page converted to btit by divx

stdfoot();

?>