<?
require_once("include/functions.php");
require_once("include/config.php");

dbconn();

///////////////////// Neue Funktionen hinzuf�gen \\\\\\\\\\\\\\\\\\\\\\\\\\\\
if ($CURUSER["id_level"] >= 8) {
if($_GET['pa_name']) {
$pa_name = $_GET['pa_name'];
$pa_desc3 = $_GET['pa_desc3'];
$pa_banurl = $_GET['pa_banurl'];
$pa_url = $_GET['pa_url'];
$editid = $_GET['editid'];
if ($editid) {
$query = "UPDATE partner SET
titel = '$pa_name',
desc3 = '$pa_desc3',
banner = '$pa_banurl',
link = '$pa_url' where id = $editid";
}
else
{
$query = "INSERT INTO partner SET
titel = '$pa_name',
desc3 = '$pa_desc3',
banner = '$pa_banurl',
link = '$pa_url'";
}
$sql = mysql_query($query);
if($sql) {
$success = TRUE;
} else {
$success = FALSE;
}
}
if($success == TRUE) {
header("Location:  " . $_SERVER['PHP_SELF'] . "");

} 
}

///////////////////// Neue Funktionen hinzuf�gen \\\\\\\\\\\\\\\\\\\\\\\\\\\\
if ($CURUSER["id_level"] >= 8) {
if($_GET['pa_name1']) {
$pa_name1 = $_GET['pa_name1'];
$pa_desc1 = $_GET['pa_desc1'];
$pa_banurl1 = $_GET['pa_banurl1'];
$pa_url1 = $_GET['pa_url1'];
$editid1 = $_GET['editid1'];
if ($editid1) {
$query = "UPDATE toppartner SET
titel1 = '$pa_name1',
desc1 = '$pa_desc1',
banner1 = '$pa_banurl1',
link1 = '$pa_url1' where id1 = $editid1";
}
else
{
$query = "INSERT INTO toppartner SET
titel1 = '$pa_name1',
desc1 = '$pa_desc1',
banner1 = '$pa_banurl1',
link1 = '$pa_url1'";
}
$sql = mysql_query($query);
if($sql) {
$success = TRUE;
} else {
$success = FALSE;
}
}
if($success == TRUE) {
header("Location:  " . $_SERVER['PHP_SELF'] . "");

} 
}

///////////////////// Neue Funktionen hinzuf�gen \\\\\\\\\\\\\\\\\\\\\\\\\\\\
if ($CURUSER["id_level"] >= 8) {
if($_GET['pa_name2']) {
$pa_name2 = $_GET['pa_name2'];
$pa_desc2 = $_GET['pa_desc2'];
$pa_banurl2 = $_GET['pa_banurl2'];
$pa_url2 = $_GET['pa_url2'];
$editid2 = $_GET['editid2'];
if ($editid2) {
$query = "UPDATE sponsor SET
titel2 = '$pa_name2',
desc2 = '$pa_desc2',
banner2 = '$pa_banurl2',
link2 = '$pa_url2' where id2 = $editid2";
}
else
{
$query = "INSERT INTO sponsor SET
titel2 = '$pa_name2',
desc2 = '$pa_desc2',
banner2 = '$pa_banurl2',
link2 = '$pa_url2'";
}
$sql = mysql_query($query);
if($sql) {
$success = TRUE;
} else {
$success = FALSE;
}
}
if($success == TRUE) {
header("Location:  " . $_SERVER['PHP_SELF'] . "");

} 
}

standardheader('Add-Partner');


if ($CURUSER["id_level"] <= 7) 
{
  print"(Sorry..., Zutritt verweigert!!!)";
  stdfoot();
  exit;
}

///////////////////// Neue Optionen hinzuf�gen \\\\\\\\\\\\\\\\\\\\\\\\\\\\
if ($CURUSER["id_level"] >= 8) {
block_begin(TRACKERS_PARTNERS);
?>
<?
print("<br />");
print("<br />");

if ($_GET['editid']) {

$editid = $_GET['editid'];
$query = "SELECT * FROM partner where id = '".$editid."'";
$sql = mysql_query($query);
$row = mysql_fetch_array($sql);
$id = $row['id'];
$titel = $row['titel'];
$desc3 = $row['desc3'];
$banner = $row['banner'];
$url = $row['link'];
}
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=\"tablea\" cellspacing=\"0\" cellpadding=\"5\" width=\"80%\">");
echo("<tr><td>".NAME_OF_PARTNER.": </td><td align='left'><input type='text' size='50' value='".$titel."' name='pa_name'/></td></tr>");
echo("<tr><td>".DESCRIPTION_DESCRIPTION_OF_THE_PARTNERS.": </td><td align='left'><input type='text' size='50' value='$desc3' name='pa_desc3'/></td></tr>");
echo("<tr><td>".BANNER_URL.": </td><td align='left'><input type='text' size='50' value='$banner' name='pa_banurl'/></td></tr>");
echo("<tr><td>".LINK_TO_SITE.": </td><td align='left'><input type='text' size='50' value='$url' name='pa_url'/></td></tr>");
echo("<div align='center'><input type='hidden' name='editid' value='$id'/></div>");
echo("<tr><td></td><td><div align='left'><input value='".ADD."' type='submit'/></div></td></tr>");
echo("</table>");
echo("</form>");
}
block_end();
if ($CURUSER["id_level"] >= 8) {
block_begin(TOP_TRACKERS_PARTNERS);?>
<?

print("<br />");
print("<br />");

if ($_GET['editid1']) {

$editid1 = $_GET['editid1'];
$query = "SELECT * FROM toppartner where id1 = '".$editid1."'";
$sql = mysql_query($query);
$row = mysql_fetch_array($sql);
$id1 = $row['id1'];
$titel1 = $row['titel1'];
$desc1 = $row['desc1'];
$banner1 = $row['banner1'];
$url1 = $row['link1'];
}
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=\"tablea\" cellspacing=\"0\" cellpadding=\"5\" width=\"80%\">");
echo("<tr><td>".NAME_OF_PARTNER.": </td><td align='left'><input type='text' size='50' value='".$titel1."' name='pa_name1'/></td></tr>");
echo("<tr><td>".DESCRIPTION_DESCRIPTION_OF_THE_PARTNERS.": </td><td align='left'><input type='text' size='50' value='$desc1' name='pa_desc1'/></td></tr>");
echo("<tr><td>".BANNER_URL.": </td><td align='left'><input type='text' size='50' value='$banner1' name='pa_banurl1'/></td></tr>");
echo("<tr><td>".LINK_TO_SITE.": </td><td align='left'><input type='text' size='50' value='$url1' name='pa_url1'/></td></tr>");
echo("<div align='center'><input type='hidden' name='editid1' value='$id1'/></div>");
echo("<tr><td></td><td><div align='left'><input value='".ADD."' type='submit'/></div></td></tr>");
echo("</table>");
echo("</form>");
}
block_end();
if ($CURUSER["id_level"] >= 8) {
block_begin(SPONSORS);?>

<?

print("<br />");
print("<br />");

if ($_GET['editid2']) {

$editid2 = $_GET['editid2'];
$query = "SELECT * FROM sponsor where id2 = '".$editid2."'";
$sql = mysql_query($query);
$row = mysql_fetch_array($sql);
$id2 = $row['id2'];
$titel2 = $row['titel2'];
$desc2 = $row['desc2'];
$banner2 = $row['banner2'];
$url2 = $row['link2'];
}
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=\"tablea\" cellspacing=\"0\" cellpadding=\"5\" width=\"80%\">");
echo("<tr><td>".NAME_OF_SPONSOR.": </td><td align='left'><input type='text' size='50' value='".$titel2."' name='pa_name2'/></td></tr>");
echo("<tr><td>".DESCRIPTION_DESCRIPTION_OF_THE_SPONSOR.": </td><td align='left'><input type='text' size='50' value='$desc2' name='pa_desc2'/></td></tr>");
echo("<tr><td>".BANNER_URL.": </td><td align='left'><input type='text' size='50' value='$banner2' name='pa_banurl2'/></td></tr>");
echo("<tr><td>".LINK_TO_SITE.": </td><td align='left'><input type='text' size='50' value='$url2' name='pa_url2'/></td></tr>");
echo("<div align='center'><input type='hidden' name='editid2' value='$id2'/></div>");
echo("<tr><td></td><td><div align='left'><input value='".ADD."' type='submit'/></div></td></tr>");
echo("</table>");
echo("</form>");
}
block_end();
block_begin(TRACKERS_PARTNERS);?>
<br><br>
<?
$query = "SELECT * FROM partner";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id = $row['id'];
$titel = $row['titel'];
$desc3 = $row['desc3'];
$banner = $row['banner'];
$url = $row['link'];

echo ("<tr><td width=100% class=tablea><br><center><font color=red><font size=3>".$titel."</font></center>
<br><center><font color=orange><font size=2>".DESCRIPTION_DESCRIPTION_OF_THE_PARTNERS.": ".$desc3."</font></center>
<table width=100% border=0 cellspacing=0 cellpadding=10><tr><td class=text>
<center><a href=".$url." target=_blank><IMG SRC=".$banner."  WIDTH=560 HEIGHT=100 border=0></a></center>
</td><div align='center'><a href='". $_SERVER['PHP_SELF'] . "?editid=$id'>[".EDIT."]</a> | <a href='loeschen.php?delete=$id'>[".DELETE."]</a></div></tr></table><br/>");
}


///////////////////// Neue Optionen hinzuf�gen \\\\\\\\\\\\\\\\\\\\\\\\\\\\
block_end();
block_begin(TOP_TRACKERS_PARTNERS);?>
<br><br>
<?
$query = "SELECT * FROM toppartner";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id1 = $row['id1'];
$titel1 = $row['titel1'];
$desc1 = $row['desc1'];
$banner1 = $row['banner1'];
$url1 = $row['link1'];

echo ("<tr><td width=100% class=tablea><br><center><font color=red><font size=3>".$titel1."</font></center>
<br><center><font color=orange><font size=2>".DESCRIPTION_DESCRIPTION_OF_THE_PARTNERS.": ".$desc1."</font></center>
<table width=100% border=0 cellspacing=0 cellpadding=10><tr><td class=text>
<center><a href=".$url1." target=_blank><IMG SRC=".$banner1."  WIDTH=560 HEIGHT=100 border=0></a></center>
</td><div align='center'><a href='". $_SERVER['PHP_SELF'] . "?editid1=$id1'>[".EDIT."]</a> | <a href='loeschen1.php?delete=$id1'>[".DELETE."]</a></div></tr></table><br/>");
}

///////////////////// Neue Optionen hinzuf�gen \\\\\\\\\\\\\\\\\\\\\\\\\\\\
block_end();
block_begin(SPONSORS);?>
<br><br>
<?
$query = "SELECT * FROM sponsor";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id2 = $row['id2'];
$titel2 = $row['titel2'];
$desc2 = $row['desc2'];
$banner2 = $row['banner2'];
$url2 = $row['link2'];

echo ("<tr><td width=100% class=tablea><br><center><font color=red><font size=3>".$titel2."</font></center>
<br><center><font color=orange><font size=2>".DESCRIPTION_DESCRIPTION_OF_THE_SPONSOR.": ".$desc2."</font></center>
<table width=100% border=0 cellspacing=0 cellpadding=10><tr><td class=text>
<center><a href=".$url2." target=_blank><IMG SRC=".$banner2."  WIDTH=560 HEIGHT=100 border=0></a></center>
</td><div align='center'><a href='". $_SERVER['PHP_SELF'] . "?editid2=$id2'>[".EDIT."]</a> | <a href='loeschen2.php?delete=$id2'>[".DELETE."]</a></div></tr></table><br/>");
}

block_end();
stdfoot();
?>