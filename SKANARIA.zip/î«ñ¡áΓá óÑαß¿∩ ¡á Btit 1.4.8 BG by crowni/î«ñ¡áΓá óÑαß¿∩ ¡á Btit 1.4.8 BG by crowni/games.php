<?php
/********
Copyright � 2007 BTITeam.org. All Rights Reserved. 
PB Edition 1.5 Copyright � 2007 PantheraBits.com. All Rights Reserved. 
Do not remove the Copyright in footer!
********/
require_once ("include/functions.php");
require_once ("include/config.php");


dbconn();
if ($CURUSER["view_news"]=="yes")
{
standardheader('Games');
block_begin("Games");
global $CURUSER, $STYLEPATH;
?>

<?php
print("<table border=1 cellspacing=0 cellpadding=0 align=center><tr>"); 

print("<td width=502 valign=top>"); 

print("<table width=502 border=1>"); 
?>
<style type="text/css">
<!--
.style3 {font-size: 12px}
-->
</style>




<center>
<p>Games<br>
<span class="style3">Please Choose A Game From The Right</span> </p>
</center>
<tr><td 

<br>
<tr><td>
</form> <iframe src="" name="games" width="570" height="570" scrolling="no"></iframe></td></tr>
<marquee onmouseover=this.stop() onmouseout=this.start() scrollAmount=2.0 direction=across width='100%' height='75'> 
</table></td> 

<?php 

//print("</table></td>"); 
print("<td width=150 valign=top><table border=1>"); 

print("<tr><td class=colhead width=150 height=18>$CURUSER[username]'s Avatar</td></tr>"); 
if ($CURUSER[avatar]) 
print("<tr><td><img width=125 src=" . htmlspecialchars($CURUSER["avatar"]) . "></td></tr>"); 
else 
print("<tr><td><img width=125 src=pic/default_avatar.gif></td></tr>"); 
print("<tr><td class=colhead width=150 height=18>Games</td></tr>"); 

print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5371.swf target=games>Play High Speed Chase</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/4535.swf target=games>Play Achilles</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5523.swf target=games>Play Twelve Towers</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5329.swf target=games>Play Glamour Parking</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5528.swf target=games>Play Celebrity Snapshot</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5517.swf target=games>Play Mort the Sniper</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/3919.swf target=games>Play Magic Fingers</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5084.swf target=games>Play Governor of Poker</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5254.swf target=games>Play Oiligarchy</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/1687.swf target=games>Play Solitaire</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5524.swf target=games>Play Blast Billiards Gold</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5010.swf target=games>Play Moto Rush</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/1560.swf target=games>Play Mini Putt</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/4200.swf target=games>Play Desert Rally</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/1786.swf target=games>Play Mahjongg</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/3164.swf target=games>Play PacXon</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/1851.swf target=games>Play Tanks</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5504.swf target=games>Play Warlords Heroes</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5455.swf target=games>Play Spy Guy Escape</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/2986.swf target=games>Play Trapped</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/4687.swf target=games>Play Mafia Driver</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/4460.swf target=games>Play Last Requests</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5511.swf target=games>Play DJ Fest 2</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/4408.swf target=games>Play 3D Logic 2</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/3657.swf target=games>Play Doom Rider</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/4383.swf target=games>Play Age of War</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/1200.swf target=games>Play Alien</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/5363.swf target=games>Play Charger Escape</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/3506.swf target=games>Play Stunt Bike Draw</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.addictinggames.com/D78AQSAKQLQWI9/3060.swf target=games>Play Dark Cut</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=chess.php>Play Chess</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=mustafa.php>Play Mustafa</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=snake.php>Play Snake</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=hangman.php>Play Hangman</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/commando.swf target=games>Play commando</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/sonic.swf target=games>Play sonic</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/battlefield2.swf target=games>Play battlefield2</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/dirtbike.swf target=games>Play dirtbike</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/kittencannon.swf target=games>Play kittencannon</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/supermariobros.swf target=games>Play supermariobros</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/miniputt.swf target=games>Play MiniPutt</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/basejumping.swf target=games>Play Base Jumping</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/gridlock.swf target=games>Play Gridlock</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/flashpoker.swf target=games>Play Poker</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/3dworm.swf target=games>Play 3D Worm</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/classicbreakout.swf target=games>Play Breakout</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.onemorelevel.com/games3/archer.swf target=games>Play Archer</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://209.200.250.151/manual/topgun6.swf target=games>Play Top Gun</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.onemorelevel.com/games/Pacman.swf target=games>Play PacMan</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://www.onemorelevel.com/games/snakes5.dcr target=games>Play Snake 3D</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/dunebashing.swf target=games>Play dunebashing</td></tr>"); 
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/3dswat.swf target=games>Play 3Dslat</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/driversed2.swf target=games>Play Test Driving</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/battlemage.swf target=games>Play battlemage</td></tr>");            
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/flashstrike.swf target=games>Play Counter Stricke</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/fearunlimited.swf target=games>Play Fear Unlimited</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/cubefield.swf target=games>Play Cubefield</td></tr>");
print("<tr><td align=left>&nbsp;&nbsp;<a href=http://gamesloth.us/hosted/alias2.swf target=games>Play Alias2</td></tr>");


print("</table>"); 
print("</td></tr></table>"); 

}
	else
	{
    err_msg(ERROR.NOT_AUTHORIZED."!",SORRY."...");
	}

block_end();
stdfoot();
?>