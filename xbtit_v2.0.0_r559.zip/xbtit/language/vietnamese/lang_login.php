<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["INSERT_USERNAME"]="b&#7841;n ph&#7843;i &#273;i&#7873;n t&#234;n th&#224;nh vi&#234;n v&#224;o!"; 
$language["INSERT_PASSWORD"]=" b&#7841;n ph&#7843;i &#273;i&#7873;n m&#7853;t m&#7843; v&#224;o!"; 
?>