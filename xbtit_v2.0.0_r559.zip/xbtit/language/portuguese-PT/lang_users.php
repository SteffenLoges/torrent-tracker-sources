<?php

// ARQUIVO EM PORTUGUÊS USERS.PHP 

$language["FIND_USER"]       = "Localizar Utilizador";
$language["USER_LEVEL"]      = "Rank do Utilizador";
$language["ALL"]             = "Todos";
$language["SEARCH"]          = "Procurar";
$language["USER_NAME"]       = "Nome de Utilizador";
$language["USER_LEVEL"]      = "Rank do Utilizador";
$language["USER_JOINED"]     = "Registado em";
$language["USER_LASTACCESS"] = "Último acesso";
$language["USER_COUNTRY"]    = "País";
$language["RATIO"]           = "Média";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Editar";
$language["DELETE"]          = "Apagar";
$language["NO_USERS_FOUND"]  = "Nenhum utilizador encontrado!";
$language["UNKNOWN"]         = "Desconhecido";

?>
