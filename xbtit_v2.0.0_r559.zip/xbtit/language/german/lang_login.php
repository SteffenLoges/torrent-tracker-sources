<?php
$language["INSERT_USERNAME"]="Benutzernamen eingeben!";
$language["INSERT_PASSWORD"]="Passwort eingeben!";
?>