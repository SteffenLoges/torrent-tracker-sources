<?php
$language["DELETE_READED"]="Verwijderen";
$language["USER_LANGUE"]="Taal";
$language["USER_STYLE"]="Style";
$language["CURRENTLY_PEER"]="U bent momenteel bezig met seeden of leechen van torrent(s).";
$language["STOP_PEER"]="U moet uw cli�nt stoppen.";
$language["USER_PWD_AGAIN"]="Herhaal wachtwoord";
$language["EMAIL_FAILED"]="Versturen van email is mislukt!";
$language["NO_SUBJECT"]="Geen onderwerp";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>U moet uw wachtwoord invullen om veranderingen op te kunnen slaan.</strong></font>";
$language["ERR_PASS_WRONG"]="Wachtwoord is leeg of incorrect, uw profiel kan niet worden geupdate.";
$language["MSG_DEL_ALL_PM"]="Als u PMs selecteert die nog niet gelezen zijn, zullen ze niet verwijdert worden";
$language["ERR_PM_GUEST"]="U kunt geen Gast een PM sturen of naar uzelf!";
?>