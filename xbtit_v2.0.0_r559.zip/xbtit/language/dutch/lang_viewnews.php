<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Gepost Door";
$language["POSTED_DATE"] = "Datum Gepost";
$language["TITLE"]       = "Titel";
$language["ADD"]         = "Toevoegen";

?>