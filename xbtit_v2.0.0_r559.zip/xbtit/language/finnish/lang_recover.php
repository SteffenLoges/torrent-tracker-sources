<?php
$language["ERR_NO_EMAIL"]="Anna toimiva s&auml;hk&ouml;postiosoite";
$language["ERR_INV_EMAIL"]="Sinun pit�� antaa toimiva s&auml;hk&ouml;postiosoite";
$language["ERR_NO_CAPTCHA"]="Anna kuvakoodi";
$language["IMAGE_CODE"]="Kuvakoodi";
$language["SECURITY_CODE"]="Vastaa kysymykseen";
$language["RECOVER_EMAIL_1"]="\nJoku, Toivottavasti sin�, Pyysi resetoimaan salasanan joka on yhdistetty t�h�n  (%s) S�hk�postiosoitteeseen.\n\nPyynt� l�hetty %s.\n\nJos ei n�in ole, niin �l� v�lit� t�st� mailista. �L� VASTAA.\n\nJos haluat resetoida salasanan, seuraa linkki�:\n\n%s\n\nT�m�n j�lkeen sinulle l�hetet��n uusi salasana s�hk�postitse.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nPyynn�st�si teimme uuden salasanan.\n\nT�ss� k�ytt�j�tilisi t�m�nhetkiset tiedot:\n\n    K�ytt�j�nimi: %s\n    Salasana: %s\n\nVoit kirjautua sis��n osoitteessa %s\n\n--\n%s";
?>