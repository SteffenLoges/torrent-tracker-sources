<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Postato da";
$language["POSTED_DATE"] = "Postato In Data";
$language["TITLE"]       = "Titolo";
$language["ADD"]         = "Aggiungi";

?>