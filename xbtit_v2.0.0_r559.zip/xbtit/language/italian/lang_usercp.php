<?php
$language["DELETE_READED"]="Elimina";
$language["USER_LANGUE"]="Lingua";
$language["USER_STYLE"]="Stile";
$language["CURRENTLY_PEER"]="Sei attualmente in distribuzione o in ricezione di qualche torrent.";
$language["STOP_PEER"]="Devi bloccare il tuo client(stop peer).";
$language["USER_PWD_AGAIN"]="Ripeti la password";
$language["EMAIL_FAILED"]="L'invio della mail è fallito!";
$language["NO_SUBJECT"]="Nessun soggetto";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Devi inserire la tua password per cambiare i settaggi soprastanti.</strong></font>";
$language["ERR_PASS_WRONG"]="Password vuota o errata, non posso aggiornare il profilo.";
$language["MSG_DEL_ALL_PM"]="Se selezioni i PM che non sono letti, non verranno cancellati";
?>