<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["INSERT_USERNAME"]="Devi inserire il nome utente!";
$language["INSERT_PASSWORD"]="Devi inserire la password!";
?>