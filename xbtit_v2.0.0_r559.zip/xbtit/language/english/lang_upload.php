<?php
$language['NOT_SHA']='SHA1 function not available. You need PHP 4.3.0 or better.';
$language['NOT_AUTHORIZED_UPLOAD']='You&rsquo;re not authorized to upload!';
$language['FILE_UPLOAD_ERROR_1']='Cant read uploaded file';
$language['FILE_UPLOAD_ERROR_3']='File is zero sized';
$language['FACOLTATIVE']='optional';
$language['FILE_UPLOAD_ERROR_2']='File Upload Error';
$language['ERR_PARSER']='There seems to be an error in your torrent. The parser did not accept it.';
$language['WRITE_CATEGORY']='You must specify the torrent category...';
$language['DOWNLOAD']='Download';
$language['MSG_UP_SUCCESS']='Upload successful! The torrent has been added.';
$language['MSG_DOWNLOAD_PID']='PID system active get your torrent with your PID';
$language['EMPTY_DESCRIPTION']='You must enter a description!';
$language['EMPTY_ANNOUNCE']='Announce is empty';
$language['FILE_UPLOAD_ERROR_1']='Cant read uploaded file';
$language['FILE_UPLOAD_ERROR_2']='File Upload Error';
$language['FILE_UPLOAD_ERROR_3']='File is zero sized';
$language['NO_SHA_NO_UP']='File uploading not available - no SHA1 function.';
$language['NOT_SHA']='SHA1 function not available. You need PHP 4.3.0 or better.';
$language['ERR_PARSER']='There seems to be an error in your torrent. The parser did not accept it.';
$language['WRITE_CATEGORY']='You must specify the torrent category...';
$language['ERR_HASH']='Info hash MUST be exactly 40 hex bytes.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='External torrents not allowed';
$language['ERR_MOVING_TORR']='Error moving torrent...';
$language['ERR_ALREADY_EXIST']='This torrent may already exist in our database.';
$language['MSG_DOWNLOAD_PID']='PID system active get your torrent with your PID';
$language['MSG_UP_SUCCESS']='Upload successful! The torrent has been added.';
?>