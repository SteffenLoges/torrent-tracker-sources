<?php
$language['DELETE_READED']='Eliminar';
$language['USER_LANGUE']='Idioma';
$language['USER_STYLE']='Estilo';
$language['CURRENTLY_PEER']='Estas compartiendo estos torrents.';
$language['STOP_PEER']='Debes parar tu cliente bittorrent.';
$language['USER_PWD_AGAIN']='Repetir contrase�a';
$language['EMAIL_FAILED']='El envio del email fall�!';
$language['NO_SUBJECT']='Sin asunto';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>Debes poner tu contrase�a para realizar los cambios.</strong></font>';
$language['ERR_PASS_WRONG']='Contrase�a vacia o incorrecta, no se puede actualizar tu perfil.';
$language['MSG_DEL_ALL_PM']='Si seleccionas mensajes no leidos, estos no se eliminaran';
$language['ERR_PM_GUEST']='No puedes enviar mensajes privados a invitados o a ti mismo!';
?>