<?php
$language['SUBFORUM']='SubForo';
$language['SUBFORUMS']='<b>SubForos</b>';
$language['NEW_TOPIC']='Nuevo Topic';
$language['NO_TOPICS']='No hay topics.';
$language['LOCKED']='Topic cerrado';
$language['LOCKED_NEW']='Topic cerrado (Nuevo)';
$language['UNLOCKED']='No hay nuevas respuestas';
$language['UNLOCKED_NEW']='Nuevas respuestas';
$language['ERR_CANT_START_TOPICS']='No tienes permiso para escribir un nuevo mensaje en este foro.';
$language['BAD_FORUM_ID']='ID del Foro incorrecta';
$language['MOD_OPTION']='Opciones de Moderaci�n';
$language['SET_STICKY']='Crear/Eliminar nota';
$language['SET_LOCKED']='Bloquear/Desbloquear Topic';
$language['RENAME_TOPIC']='Renombrar topic';
$language['DELETE_TOPIC']='Eliminar topic';
$language['MOVE_TOPIC']='Mover este topico a';
$language['MOVE']='Mover';
$language['ADD_REPLY']='Contestar';
$language['BAD_TOPIC_ID']='ID de topic erronea';
$language['LAST_10_POSTS']='10 ultimos post, en orden inverso';
$language['LAST_EDITED_BY']='Editado por ultima vez por';
$language['ERR_POST_ID_NA']='El ID del post es N/A';
$language['ERR_FORUM_TOPIC']='Foro o Topic ID erroneo.';
$language['ERR_POST_NOT_FOUND']='Post no encontrado';
$language['ERR_POST_UNIQUE']='No se puede eliminar el post; es el �nico post en el topic. Tu puedes';
$language['ERR_POST_UNIQUE_2']='eliminar el topic';
$language['ERR_POST_UNIQUE_3']='en vez de';
$language['TOPIC_LOCKED']='Este topic esta cerrado; no se pueden escribir nuevos posts en el.';
$language['TOPIC_NOT_FOUND']='No se han encontrado topics';
$language['TOPIC_UNREAD_POSTS']='Post sin leer';
$language['POST']='Post';
$language['SEARCH_AGAIN']='Buscar de nuevo';
$language['SEARCH_HELP']='Introducir una palabra para buscar.<br />Palabras de menos de 3 letras son ignoradas.';
$language['SEARCHED_FOR']='Buscado por';

?>