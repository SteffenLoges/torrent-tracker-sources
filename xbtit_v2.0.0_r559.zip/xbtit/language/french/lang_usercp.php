<?php
$language["DELETE_READED"]="Supprimer";
$language["USER_LANGUE"]="Language";
$language["USER_STYLE"]="Style";
$language["CURRENTLY_PEER"]="Vous �tes en train de seeder ou de leecher certain torrent.";
$language["STOP_PEER"]="Vous devez arr�ter votre client.";
$language["USER_PWD_AGAIN"]="Confirmer le mot de passe";
$language["EMAIL_FAILED"]="L'envoi de ce courriel a echou� !";
$language["NO_SUBJECT"]="Aucun sujet";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Vous devez entrer votre mot de passe pour modifier les param�tres ci-dessus.</strong></font>";
$language["ERR_PASS_WRONG"]="Mot de passe vide ou incorrect, impossible de mettre � jour le profil.";
$language["MSG_DEL_ALL_PM"]="Si vous s�lectionnez des MP qui ne sont pas lus, ils ne seront pas supprim�s";
$language["ERR_PM_GUEST"]="D�sol�, vous ne pouvez pas envoyer de MP � un invit� ou � vous-m�me !";
?>