<?php
$language["BLOCK_USER"]="Korisnicki info";
$language["BLOCK_INFO"]="Tracker Info";
$language["BLOCK_MENU"]="Glavni meni";
$language["BLOCK_CLOCK"]="Sat";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Zadnji korisnik";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Online Danas";
$language["BLOCK_SHOUTBOX"]="Shout Box";
$language["BLOCK_TOPTORRENTS"]="Top Torrenti";
$language["BLOCK_LASTTORRENTS"]="Zadnji upload";
$language["BLOCK_NEWS"]="Zadnje vijesti";
$language["BLOCK_SERVERLOAD"]="Server Load";
$language["BLOCK_POLL"]="Anketa";
$language["BLOCK_SEEDWANTED"]="Potreban seed";
$language["BLOCK_PAYPAL"]="Podrzite nas";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Glavni tracker alati/meni/stat";
$language["BLOCK_MAINUSERTOOLBAR"]="Korisnicki alati/meni/stat";
$language["WELCOME_LASTUSER"]=" Dobrodosli na nas tracker ";
$language["BLOCK_MINCLASSVIEW"]="Minimum rang koji moze vidjeti";
?>