<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["USERNAME"]           = "Korisnik";
$language["EMAIL"]              = "E-mail";
$language["LAST_IP"]            = "Zadnji Ip";
$language["USER_LEVEL"]         = "Rang";
$language["USER_JOINED"]        = "Prijava";
$language["USER_LASTACCESS"]    = "Zadnja posjeta";
$language["PEER_COUNTRY"]       = "Zemlja";
$language["USER_LOCAL_TIME"]    = "Lokalno vrijeme";
$language["DOWNLOADED"]         = "D-Load";
$language["UPLOADED"]           = "Up-Load";
$language["RATIO"]              = "Ratio";
$language["FORUM"]              = "Forum";
$language["POSTS"]              = "Postova";
$language["POSTS_PER_DAY"]      = "%s postova po danu";
$language["TORRENTS"]           = "Torrenata";
$language["FILE"]               = "Fajl";
$language["ADDED"]              = "Dodato";
$language["SIZE"]               = "Velicina";
$language["SHORT_S"]            = "S";
$language["SHORT_L"]            = "L";
$language["SHORT_C"]            = "C";
$language["NO_TORR_UP_USER"]    = "Nema uploada!";
$language["ACTIVE_TORRENT"]     = "Aktivni torrenti";
$language["PEER_STATUS"]        = "Status";
$language["NO_ACTIVE_TORR"]     = "Nema aktivnih torrenata!";
$language["PEER_CLIENT"]        = "Klijent";
$language["EDIT"]               = "Izmjeni";
$language["DELETE"]             = "Izbrisi";
$language["PM"]                 = "PM";
$language["BACK"]               = "natrag";
$language["NO_HISTORY"]         = "Nema download istorije...";
?>