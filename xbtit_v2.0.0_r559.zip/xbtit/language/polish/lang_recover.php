<?php
$language["ERR_NO_EMAIL"]="Musisz wpisać adres email";
$language["ERR_INV_EMAIL"]="Musisz wpisać prawidłowy adres email";
$language["ERR_NO_CAPTCHA"]="Musisz wpisać Kod obrazka";
$language["IMAGE_CODE"]="Kod obrazka";
$language["SECURITY_CODE"]="Odpowiedz na pytanie";
$language["RECOVER_EMAIL_1"]="\Ktoś, prawdopodobnie Ty, poprosił o zresetowanie hasła dla konta przypisanego do tego adresu email (%s) .\n\nProśba ta została wysłana z IP %s.\n\nJeżeli to nie ty poprosiłeś o zresetowanie hasła zignoruj ten email. Prosimy na niego nie odpowiadać.\n\nJeśli chcesz potwierdzić prośbę o zresetowanie hasła, proszę kliknąć w poniższy link:\n\n%s\n\nGdy to zrobisz, twoje hasło zostanie zresetowane i wysłane zostanie nowe na ten sam adres email.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nZgodnie z twoją prośbą wygenerowane zostało dla Ciebie nowe hasło do twojego konta.\n\nPoniżej znajdują się nowe dane potrzebne do zalogowania się na konto:\n\n    Nick: %s\n    Hasło: %s\n\nMożesz się teraz zalogować %s\n\n--\n%s";
?>