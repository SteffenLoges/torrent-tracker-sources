﻿<?php
// USERDETAILS.PHP LANGUAGE FILE
$language['USERNAME']='Nume utilizator';
$language['EMAIL']='E-mail';
$language['LAST_IP']='Ultimul IP';
$language['USER_LEVEL']='Rang';
$language['USER_JOINED']='Înscris';
$language['USER_LASTACCESS']='Ultima Accesare';
$language['PEER_COUNTRY']='Ţară';
$language['USER_LOCAL_TIME']='Ora Locală';
$language['DOWNLOADED']='Download';
$language['UPLOADED']='Upload';
$language['RATIO']='Raţie';
$language['FORUM']='Forum';
$language['POSTS']='Mesaje';
$language['POSTS_PER_DAY']='%s mesaje per zi';
$language['TORRENTS']='Torrente';
$language['FILE']='Fişier';
$language['ADDED']='Adăugat';
$language['SIZE']='Dimensiune';
$language['SHORT_S']='S';
$language['SHORT_L']='L';
$language['SHORT_C']='C';
$language['NO_TORR_UP_USER']='Acest Utilizator nu a facut Upload la nici un torrent inca!';
$language['ACTIVE_TORRENT']='Torrente active';
$language['PEER_STATUS']='Status';
$language['NO_ACTIVE_TORR']='Niciun torrent activ';
$language['PEER_CLIENT']='Client';
$language['EDIT']='Editează';
$language['DELETE']='Şterge';
$language['PM']='Mesaj Privat';
$language['BACK']='Înapoi';
$language['NO_HISTORY']='Nu exista istorie...';
?>