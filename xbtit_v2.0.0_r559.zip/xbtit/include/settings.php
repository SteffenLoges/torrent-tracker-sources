<?php

$dbhost = "localhost";
$dbuser = "";
$dbpass = "";
$database = "";
$TABLE_PREFIX = "";

?>