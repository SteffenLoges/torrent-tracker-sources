<?

require_once("bittorrent.php");

function docleanup() {

	global $torrent_dir, $signup_timeout, $max_dead_torrent_time, $autoclean_interval;

	set_time_limit(0);
	ignore_user_abort(1);

	do {
		$res = mysql_query("SELECT id FROM torrents");
		$ar = array();
		while ($row = mysql_fetch_array($res)) {
			$id = $row[0];
			$ar[$id] = 1;
		}

		if (!count($ar))
			break;

		$dp = @opendir($torrent_dir);
		if (!$dp)
			break;

		$ar2 = array();
		while (($file = readdir($dp)) !== false) {
			if (!preg_match('/^(\d+)\.torrent$/', $file, $m))
				continue;
			$id = $m[1];
			$ar2[$id] = 1;
			if (isset($ar[$id]) && $ar[$id])
				continue;
			$ff = $torrent_dir . "/$file";
			unlink($ff);
		}
		closedir($dp);

		if (!count($ar2))
			break;

		$delids = array();
		foreach (array_keys($ar) as $k) {
			if (isset($ar2[$k]) && $ar2[$k])
				continue;
			$delids[] = $k;
			unset($ar[$k]);
		}
		if (count($delids))
			mysql_query("DELETE FROM torrents WHERE id IN (" . join(",", $delids) . ")");

		$res = mysql_query("SELECT torrent FROM peers GROUP BY torrent");
		$delids = array();
		while ($row = mysql_fetch_array($res)) {
			$id = $row[0];
			if (isset($ar[$id]) && $ar[$id])
				continue;
			$delids[] = $id;
		}
		if (count($delids))
			mysql_query("DELETE FROM peers WHERE torrent IN (" . join(",", $delids) . ")");

		$res = mysql_query("SELECT torrent FROM files GROUP BY torrent");
		$delids = array();
		while ($row = mysql_fetch_array($res)) {
			$id = $row[0];
			if ($ar[$id])
				continue;
			$delids[] = $id;
		}
		if (count($delids))
			mysql_query("DELETE FROM files WHERE torrent IN (" . join(",", $delids) . ")");
	} while (0);

	$deadtime = deadtime();
	mysql_query("DELETE FROM peers WHERE last_action < FROM_UNIXTIME($deadtime)");

	$deadtime -= $max_dead_torrent_time;
	mysql_query("UPDATE torrents SET visible='no' WHERE visible='yes' AND forcevisible='no' AND last_action < FROM_UNIXTIME($deadtime)");

	$deadtime = time() - $signup_timeout;
	mysql_query("DELETE FROM users WHERE status = 'pending' AND added < FROM_UNIXTIME($deadtime) AND last_login < FROM_UNIXTIME($deadtime) AND last_access < FROM_UNIXTIME($deadtime) AND last_access != '0000-00-00 00:00:00'");

 	$deadtime = time() - $signup_timeout;
	$user = mysql_query("SELECT invited_by FROM users WHERE status = 'pending' AND added < FROM_UNIXTIME($deadtime) AND last_access = '0000-00-00 00:00:00'");
	$arr = mysql_fetch_assoc($user);
         if (mysql_num_rows($user) > 0)
 	{
         $invites = mysql_query("SELECT invites FROM users WHERE id = $arr[invited_by]");
	$arr2 = mysql_fetch_assoc($invites);
         if ($arr2[invites] < 10)
	{
         $invites = $arr2[invites] +1;
	mysql_query("UPDATE users SET invites='$invites' WHERE id = $arr[invited_by]");
	}
         mysql_query("DELETE FROM users WHERE status = 'pending' AND added < FROM_UNIXTIME($deadtime) AND last_access = '0000-00-00 00:00:00'");
         }

	$torrents = array();
	$res = mysql_query("SELECT torrent, seeder, COUNT(*) AS c FROM peers GROUP BY torrent, seeder");
	while ($row = mysql_fetch_assoc($res)) {
		if ($row["seeder"] == "yes")
			$key = "seeders";
		else
			$key = "leechers";
		$torrents[$row["torrent"]][$key] = $row["c"];
	}

	$res = mysql_query("SELECT torrent, COUNT(*) AS c FROM comments GROUP BY torrent");
	while ($row = mysql_fetch_assoc($res)) {
		$torrents[$row["torrent"]]["comments"] = $row["c"];
	}

	$fields = explode(":", "comments:leechers:seeders");
	$res = mysql_query("SELECT id, seeders, leechers, comments FROM torrents");
	while ($row = mysql_fetch_assoc($res)) {
		$id = $row["id"];
		$torr = $torrents[$id];
		foreach ($fields as $field) {
			if (!isset($torr[$field]))
				$torr[$field] = 0;
		}
		$update = array();
		foreach ($fields as $field) {
			if ($torr[$field] != $row[$field])




				$update[] = "$field = " . $torr[$field];
		}
		if (count($update))
			mysql_query("UPDATE torrents SET " . implode(",", $update) . " WHERE id = $id");
	}


	//delete requests
	$secs = 21*86400;
	$dt = sqlesc(get_date_time(gmtime() - $secs));
	$res = mysql_query("SELECT id FROM requests WHERE added < $dt");
	mysql_query("DELETE FROM addedrequests WHERE requestid = $res");
	mysql_query("DELETE FROM requests WHERE added < $dt");

	//delete inactive user accounts
	$secs = 28*86400;
	$dt = sqlesc(get_date_time(gmtime() - $secs));
	$maxclass = UC_USER;
	$res = mysql_query("SELECT id FROM users WHERE parked='no' AND status='confirmed' AND class <= $maxclass AND last_access < $dt");
	while ($arr = mysql_fetch_assoc($res))
	{
    mysql_query("DELETE FROM users WHERE id=arr[id]");
    mysql_query("DELETE FROM messages WHERE receiver=arr[id]");
    mysql_query("DELETE FROM friends WHERE userid=arr[id]");
}

	//delete old/ no upload accounts
	$secs = 28*86400;
	$dt = sqlesc(get_date_time(gmtime() - $secs));
	$maxclass = UC_USER;
	$res = mysql_query("SELECT id FROM users WHERE uploaded < 10 AND class <= $maxclass AND added < $dt");
	while ($arr = mysql_fetch_assoc($res))
	{
    mysql_query("DELETE FROM users WHERE id=arr[id]");
    mysql_query("DELETE FROM messages WHERE receiver=arr[id]");
    mysql_query("DELETE FROM friends WHERE userid=arr[id]");
}

     //delete 4 week old messages

     $secs = 28*86400;
     $dt = sqlesc(get_date_time(gmtime() - $secs));
     mysql_query("DELETE FROM messages WHERE added < $dt");

	//delete parked user accounts
    $secs = 56*86400; // change the time to fit your needs
    $dt = sqlesc(get_date_time(gmtime() - $secs));
    $maxclass = UC_USER;
	$res = mysql_query("SELECT id FROM users WHERE parked='yes' AND status='confirmed' AND class <= $maxclass AND last_access < $dt");
	while ($arr = mysql_fetch_assoc($res))
	{
    mysql_query("DELETE FROM users WHERE id=arr[id]");
    mysql_query("DELETE FROM messages WHERE receiver=arr[id]");
    mysql_query("DELETE FROM friends WHERE userid=arr[id]");
}

	// lock topics where last post was made more than x days ago
	$secs = 14*86400;
	$res = mysql_query("SELECT topics.id FROM topics LEFT JOIN posts ON topics.lastpost = posts.id AND topics.sticky = 'no' WHERE " . gmtime() . " - UNIX_TIMESTAMP(posts.added) > $secs") or sqlerr(__FILE__, __LINE__);
	while ($arr = mysql_fetch_assoc($res))
		mysql_query("UPDATE topics SET locked='yes' WHERE id=$arr[id]") or sqlerr(__FILE__, __LINE__);

  //remove expired warnings
  $res = mysql_query("SELECT id FROM users WHERE warned='yes' AND warneduntil < NOW() AND warneduntil <> '0000-00-00 00:00:00'") or sqlerr(__FILE__, __LINE__);
  if (mysql_num_rows($res) > 0)
  {
    $dt = sqlesc(get_date_time());
    $msg = sqlesc("Your warning has been removed. Please keep in your best behaviour from now on.\n");
    while ($arr = mysql_fetch_assoc($res))
    {
      mysql_query("UPDATE users SET warned = 'no', warneduntil = '0000-00-00 00:00:00' WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
      mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
    }
  }

   
/////////////////////////////////////////////Automatic Demotion to Peasant Stuff///////////////////////////////
/////////Update last_check for classes great than 1/////////
    $res = mysql_query("SELECT id FROM users WHERE class > 1") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $dt = sqlesc(get_date_time());
        while ($arr = mysql_fetch_assoc($res))
        {
        mysql_query("UPDATE users SET last_check = '" . get_date_time() . "' WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
        }
    }
/////////Update last_check for users who downloaded less than 1 GB/////////
    $limit = 1*1024*1024*1024;
    $res = mysql_query("SELECT id FROM users WHERE class = 1 AND downloaded < $limit") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $dt = sqlesc(get_date_time());
        while ($arr = mysql_fetch_assoc($res))
        {
        mysql_query("UPDATE users SET last_check = '" . get_date_time() . "', maxtorrents = 5 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
        }
    }
/////////Promote peasant user if ratio is above .3/////////
    $minratio = 0.30;
    $res = mysql_query("SELECT id FROM users WHERE class = 0 AND uploaded / downloaded >= $minratio") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $dt = sqlesc(get_date_time());

        $msg = sqlesc("Congratulations, you have been auto-promoted to <b>User</b> again.You can now stand without shame of your fellow compadres. You are allowed to have 10 active torrents.\n");
        while ($arr = mysql_fetch_assoc($res))
        {
            mysql_query("UPDATE users SET last_check = '" . get_date_time() . "', class = 1, maxtorrents = 10, warned = 'no', leechwarn = 'no' WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
            mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
        }
    }
/////////Warn user of demotion to peasant if they have downloaded over 1 GB, ratio is below .3 for 1 weeks/////////
    $limit = 1*1024*1024*1024;
    $dt = sqlesc(get_date_time(gmtime() - 86400*7));
    $minratio = 0.30;
    $res = mysql_query("SELECT id FROM users WHERE class = 1 AND downloaded > $limit AND last_check < $dt AND uploaded / downloaded < $minratio AND leechwarn = 'no'") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $dt = sqlesc(get_date_time());
        $msg = sqlesc("You will be auto-demoted from User to Peasant in another week because your ratio has dropped below $minratio for a week. You are only allowed to have 5 active torrents.\n");
        while ($arr = mysql_fetch_assoc($res))
        {
	   mysql_query("UPDATE users SET leechwarn = 'yes', maxtorrents = 5, warned = 'yes' WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
            mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
        }
    }
/////////Demote user to peasant if they have downloaded over 1 GB, ratio is below .3 for 2 weeks/////////
    $limit = 1*1024*1024*1024;
    $secs = 14*86400;
    $dt = sqlesc(get_date_time(gmtime() - $secs));
    $minratio = 0.30;
    $res = mysql_query("SELECT id FROM users WHERE class = 1 AND downloaded > $limit AND last_check < $dt AND uploaded / downloaded < $minratio") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $dt = sqlesc(get_date_time());
        $msg = sqlesc("You have been auto-demoted from User to Peasant because your share ratio has dropped below $minratio for 2 weeks. Your account will be automatically deleted in 2 weeks if your ratio is not above $minratio. You are only allowed to have 2 active torrents.\n");
        while ($arr = mysql_fetch_assoc($res))
        {
            mysql_query("UPDATE users SET class = 0, maxtorrents = 2 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
            mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
        }
    }
//////////disable peasant accounts////////////
	$secs = 28*86400;
	$dt = sqlesc(get_date_time(gmtime() - $secs));
	mysql_query("UPDATE users SET enabled  = 'no' WHERE class = 0 AND last_check < $dt");
/////////Update last_check for users with ratio above .30 and have warning/////////
    $minratio = 0.30;
    $res = mysql_query("SELECT id FROM users WHERE class = 1 AND leechwarn = 'yes' AND uploaded / downloaded > $minratio") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $msg = sqlesc("Congratulations, your warning has automatically been removed.You are allowed to have 10 active torrents again.\n");
        $dt = sqlesc(get_date_time());
        while ($arr = mysql_fetch_assoc($res))
        {
        mysql_query("UPDATE users SET last_check = '" . get_date_time() . "', maxtorrents = 10, leechwarn = 'no', warned = 'no' WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
        mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
        }
    }
/////////Update last_check for users with ratio above .30 & downloaded over 1 GB/////////
    $limit = 1*1024*1024*1024;
    $minratio = 0.30;
    $res = mysql_query("SELECT id FROM users WHERE class = 1 AND uploaded / downloaded > $minratio AND downloaded >= $limit") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
        $dt = sqlesc(get_date_time());
        while ($arr = mysql_fetch_assoc($res))
        {
        mysql_query("UPDATE users SET last_check = '" . get_date_time() . "', maxtorrents = 20 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
        }
    }
///////////////////////////////////////End of Automatic Demotion to Peasant Stuff////////////////////////////

//////////////////////////////////////Start of Invites///////////////////////////////////////////////

function autoinvites($length, $minlimit, $maxlimit, $minratio, $invites)
       {
	$time = sqlesc(get_date_time(gmtime() - (($length)*86400)));
 	$minlimit = $minlimit*1024*1024*1024;
	$maxlimit = $maxlimit*1024*1024*1024;
	$res = mysql_query("SELECT id, invites FROM users WHERE class > 0 AND enabled = 'yes' AND downloaded >= $minlimit AND downloaded < $maxlimit AND uploaded / downloaded >= $minratio AND warned = 'no' AND invites < 10 AND invitedate < $time") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0)
    {
        while ($arr = mysql_fetch_assoc($res))
        {
if ($arr[invites] == 9)
$invites = 1;
elseif ($arr[invites] == 8 && $invites == 3)
$invites = 2;
  mysql_query("UPDATE users SET invites = invites+$invites, invitedate = NOW() WHERE id=$arr[id]") or sqlerr(__FILE__, __LINE__);
 }
}
}
autoinvites(10,1,4,.90,1);
autoinvites(10,4,7,.95,2);
autoinvites(10,7,10,1.00,3);
autoinvites(10,10,100000,1.05,4);


//////////////////////////////////////End of Invites///////////////////////////////////////////////
	// promote power users
	$limit = 10*1024*1024*1024;
	$minratio = 1.05;
	$maxdt = sqlesc(get_date_time(gmtime() - 86400*28));
	$res = mysql_query("SELECT id FROM users WHERE class = 1 AND uploaded >= $limit AND uploaded / downloaded >= $minratio AND added < $maxdt") or sqlerr(__FILE__, __LINE__);
	if (mysql_num_rows($res) > 0)
	{
		$dt = sqlesc(get_date_time());
		$msg = sqlesc("Congratulations, you have been auto-promoted to [b]Power User[/b]. :)\nYour account can not be deleted automatically. You are allowed to have 100 active torrents.\n");
		while ($arr = mysql_fetch_assoc($res))
		{
			mysql_query("UPDATE users SET class = 2, invites = 5, maxtorrents = 100 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
			mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
		}
	}

	// demote power users
	$minratio = 0.95;
	$res = mysql_query("SELECT id FROM users WHERE class = 2 AND uploaded / downloaded < $minratio") or sqlerr(__FILE__, __LINE__);
	if (mysql_num_rows($res) > 0)
	{
		$dt = sqlesc(get_date_time());
		$msg = sqlesc("You have been auto-demoted from [b]Power User[/b] to [b]User[/b] because your share ratio has dropped below $minratio. You are allowed to have 10 active torrents.\n");
		while ($arr = mysql_fetch_assoc($res))
		{
			mysql_query("UPDATE users SET class = 1, maxtorrents = 10, invites = 0 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
			mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
		}
	}

	// Update stats
	$seeders = get_row_count("peers", "WHERE seeder='yes'");
	$leechers = get_row_count("peers", "WHERE seeder='no'");
	mysql_query("UPDATE avps SET value_u=$seeders WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
	mysql_query("UPDATE avps SET value_u=$leechers WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);

	// update forum post/topic count
	$forums = mysql_query("select id from forums");
	while ($forum = mysql_fetch_assoc($forums))
	{
		$postcount = 0;
		$topiccount = 0;
		$topics = mysql_query("select id from topics where forumid=$forum[id]");
		while ($topic = mysql_fetch_assoc($topics))
		{

			$res = mysql_query("select count(*) from posts where topicid=$topic[id]");
			$arr = mysql_fetch_row($res);
			$postcount += $arr[0];
			++$topiccount;
		}
		mysql_query("update forums set postcount=$postcount, topiccount=$topiccount where id=$forum[id]");
	}

        /////////////////////////////////delete inactive torrents/////////////////////////////////////
	$days = 3;
	$dt = sqlesc(get_date_time(gmtime() - ($days * 86400)));
	$res = mysql_query("SELECT id, name FROM torrents WHERE seeders = 0 AND last_action < $dt");
	while ($arr = mysql_fetch_assoc($res))
	{
		@unlink("$torrent_dir/$arr[id].torrent");
		mysql_query("DELETE FROM torrents WHERE id=$arr[id]");
		mysql_query("DELETE FROM peers WHERE torrent=$arr[id]");
		mysql_query("DELETE FROM comments WHERE torrent=$arr[id]");
		mysql_query("DELETE FROM files WHERE torrent=$arr[id]");
		mysql_query("DELETE FROM ratings WHERE torrent=$arr[id]");
		write_log("Torrent $arr[id] ($arr[name]) was deleted by system (older than $days days)");
	}
}

?>