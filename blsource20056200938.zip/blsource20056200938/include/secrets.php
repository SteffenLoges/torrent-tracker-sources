<?

$mysql_host = "localhost";  /////location of database, usually localhost
$mysql_user = "usernameof_database";  ///username of database
$mysql_pass = "PaSsw0rd"; ////pass of database
$mysql_db = "database_name"; ////name of database

?>
