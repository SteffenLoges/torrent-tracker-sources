<?
/*****************************

Hannes' ShoutBox v1.0
http://tracker.czhannes.com

*****************************/

require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();

?> 
<html><head>
<title>ShoutBox by Hannes</title>
<style type="text/css">
A {color: #000000; font-weight: bold; }
A:hover {color: #FF0000;}
.small {font-size: 7.5pt; font-family: tahoma; }
.date {font-size: 7pt;}
</style>
</head>
<body>
<?

$secs = 24 * 60 * 60;

mysql_query("DELETE FROM shoutbox WHERE " . time() . " - date > $secs") or sqlerr(__FILE__, __LINE__);

if ($_GET["sent"]=="yes")
{
$userid=$CURUSER["id"];
$username=$CURUSER["username"];
$date=time();
$text=trim($_GET["shbox_text"]);

mysql_query("INSERT INTO shoutbox VALUES ('','$userid','$username','$date','$text')") or sqlerr(__FILE__, __LINE__);


}

if ($act=="del")
{
mysql_query("DELETE FROM shoutbox WHERE id='$id' LIMIT 1") or sqlerr(__FILE__, __LINE__);
header("Location: shoutbox.php");
}

$res = mysql_query("SELECT * FROM shoutbox ORDER BY date DESC") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) == 0)
print("<b>Shoutbox is empty</b>\n");
else
{
print("<table border=0 cellspacing=0 cellpadding=2 width='100%' align='left' class='small'>\n");
while ($arr = mysql_fetch_assoc($res))
{
$del="";
if ($CURUSER["id"]==1 || $CURUSER["id"]==$arr["userid"]) $del="[<a href='shoutbox.php?act=del&id=".$arr["id"]."'>del</a>]";
print("<tr><td><a href='userdetails.php?id=".$arr["userid"]."' target='_top'>".$arr["username"]."</a> <span class='date'>(".strftime("%d.%m. %H:%M",$arr["date"]).")</span>: ".$arr["text"]." $del</td></tr>\n");
}
print("</table>");
}

?>
</body>
</html>