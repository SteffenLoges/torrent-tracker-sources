<?

	ob_start("ob_gzhandler");

require "include/bittorrent.php";
require "rconpasswords.php";
dbconn(true);
hit_count();

if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
  $choice = $_POST["choice"];
  if ($CURUSER && $choice != "" && $choice < 256 && $choice == floor($choice))
  {
    $res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
    $arr = mysql_fetch_assoc($res) or die("No poll");
    $pollid = $arr["id"];
    $userid = $CURUSER["id"];
    $res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid && userid=$userid") or sqlerr();
    $arr = mysql_fetch_assoc($res);
    if ($arr) die("Dupe vote");
    mysql_query("INSERT INTO pollanswers VALUES(0, $pollid, $userid, $choice)") or sqlerr();
    if (mysql_affected_rows() != 1)
      stderr("Error", "An error occured. Your vote has not been counted.");
    header("Location: $BASEURL/");
    die;
  }
  else
    stderr("Error", "Please select an option.");
}
/*
/////////////////////////////////////// Totalspeed mod//////////////////////////////////////////////
$resSpeed = mysql_query("SELECT seeders,leechers,id FROM torrents WHERE visible='yes' ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);
while ($rowTmp = mysql_fetch_array ($resSpeed)) {
 $seedersTmp = $rowTmp['seeders'];
 $leechersTmp = $rowTmp['leechers'];
 $torrentId = $rowTmp['id'];
 if ($seedersTmp >= 1 && $leechersTmp >= 1){
  $spd = mysql_query("SELECT (t.size * t.times_completed + SUM(p.downloaded)) / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS totalspeed FROM torrents AS t LEFT JOIN peers AS p ON t.id = p.torrent AND p.torrent = '$torrentId' WHERE p.seeder = 'no' GROUP BY t.id ORDER BY added ASC") or sqlerr(__FILE__, __LINE__);
  $a = mysql_fetch_assoc($spd);
  $tmpSpeed += $a["totalspeed"];
 }
}
$totalspeed=mksize($tmpSpeed ) . "/s";
/////////////////////////////////////// End of Totalspeed mod//////////////////////////////////////////////
*/
if ($CURUSER)
{
$a = @mysql_fetch_assoc(@mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1")) or die(mysql_error());
if ($CURUSER)
{
$file2 = "$CACHE/index/newestuser.txt";
$expire = 2*60; // 2 minutes
if (file_exists($file2) && filemtime($file2) > (time() - $expire)) {
    $newestuser = unserialize(file_get_contents($file2));
} else {

$res = mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1") or die(mysql_error());
while ($user = mysql_fetch_array($res) ) {
        $newestuser[] = $user;
    }
    $OUTPUT = serialize($newestuser);
    $fp = fopen($file2,"w");
    fputs($fp, $OUTPUT);
    fclose($fp);
} // end else
foreach ($newestuser as $a)
{
  $latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
}
}

$file = "$CACHE/index/stats.txt";
$expire = 10*60; // 10 minutes
if (file_exists($file) &&
    filemtime($file) > (time() - $expire)) {
$a=unserialize(file_get_contents($file));
$male = $a[1];
$female= $a[2];
$registered = $a[3];
$unverified = $a[4];
$torrents = $a[5];
$ratio = $a[6];
$peers = $a[7];
$seeders = $a[8];
$leechers = $a[9];
} else {
$male = number_format(get_row_count("users", "WHERE gender='Male'"));  
$female = number_format(get_row_count("users", "WHERE gender='Female'"));
$registered = number_format(get_row_count("users"));
$unverified = number_format(get_row_count("users", "WHERE status='pending'"));
$torrents = number_format(get_row_count("torrents"));
//$dead = number_format(get_row_count("torrents", "WHERE visible='no'"));

$r = mysql_query("SELECT value_u FROM avps WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = 0 + $a[0];
$r = mysql_query("SELECT value_u FROM avps WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$leechers = 0 + $a[0];
$seeders = get_row_count("peers", "WHERE seeder='yes'");
$leechers = get_row_count("peers", "WHERE seeder='no'"); 
if ($leechers == 0)
  $ratio = 0;
else
  $ratio = round($seeders / $leechers * 100);
$peers = number_format($seeders + $leechers);
$seeders = number_format($seeders);
$leechers = number_format($leechers);
$stats1 = array(1 => "$male", "$female", "$registered","$unverified","$torrents","$ratio","$peers","$seeders","$leechers");
$stats2 = serialize($stats1);
$fh = fopen($file, "w");
fwrite($fh,$stats2);
fclose($fh);
}

}
stdhead();
if ($CURUSER)
{
echo "<font class=small>Welcome to our newest member, <b>$latestuser</b>!</font>\n";
}
print("<table width=737 class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>");

print("<h2>Recent news");
if (get_user_class() >= UC_ADMINISTRATOR)
	print(" - <font class=small>[<a class=altlink href=news.php><b>News page</b></a>]</font>");
print("</h2>\n");
$file5 = "$CACHE/index/news.txt";
$expire = 30; // 3 minutes
if (file_exists($file5) && filemtime($file5) > (time() - $expire)) {
    $news2 = unserialize(file_get_contents($file5));
} else {
$res = mysql_query("SELECT * FROM news WHERE ADDDATE(added, INTERVAL 45 DAY) > NOW() ORDER BY added DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);
while ($news1 = mysql_fetch_array($res) ) {
        $news2[] = $news1;
    }
    $OUTPUT = serialize($news2);
    $fp = fopen($file5,"w");
    fputs($fp, $OUTPUT);
    fclose($fp);
}
 // end else;
if ($news2)
{
	print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n<ul>");
	foreach ($news2 as $array)
	{
	  print("<li>" . gmdate("Y-m-d",strtotime($array['added'])) . " - " . $array['body']);
    if (get_user_class() >= UC_ADMINISTRATOR)
    {
    	print(" <font size=\"-2\">[<a class=altlink href=news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>E</b></a>]</font>");
    	print(" <font size=\"-2\">[<a class=altlink href=news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>D</b></a>]</font>");
    }
    print("</li>");
  }
  print("</ul></td></tr></table>\n");
}

?>

<? if ($CURUSER)
{
  // Get current poll
$file4 = "$CACHE/index/poll.txt";
$expire = 3*60; // 3 minutes
if (file_exists($file4) && filemtime($file4) > (time() - $expire)) {
    $poll2 = unserialize(file_get_contents($file4));
} else {
  $res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
while ($poll1 = mysql_fetch_array($res) ) {
        $poll2[] = $poll1;
    }
    $OUTPUT = serialize($poll2);
    $fp = fopen($file4,"w");
    fputs($fp, $OUTPUT);
    fclose($fp);
} // end else
foreach ($poll2 as $arr)
{
  $pollid = $arr["id"];
  $userid = $CURUSER["id"];
  $question = $arr["question"];
  $o = array($arr["option0"], $arr["option1"], $arr["option2"], $arr["option3"], $arr["option4"],
    $arr["option5"], $arr["option6"], $arr["option7"], $arr["option8"], $arr["option9"],
    $arr["option10"], $arr["option11"], $arr["option12"], $arr["option13"], $arr["option14"],
    $arr["option15"], $arr["option16"], $arr["option17"], $arr["option18"], $arr["option19"]);

  // Check if user has already voted
  $res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid && userid=$userid") or sqlerr();
  $arr2 = mysql_fetch_assoc($res);

  print("<h2>Poll");

  if (get_user_class() >= UC_MODERATOR)
  {
  	print("<font class=small>");
		print(" - [<a class=altlink href=makepoll.php?returnto=main><b>New</b></a>]\n");
  	print(" - [<a class=altlink href=makepoll.php?action=edit&pollid=$arr[id]&returnto=main><b>Edit</b></a>]\n");
		print(" - [<a class=altlink href=polls.php?action=delete&pollid=$arr[id]&returnto=main><b>Delete</b></a>]");
		print("</font>");
	}
	print("</h2>\n");
	print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>\n");
  print("<table class=interiortable  border=1 cellspacing=0 cellpadding=0><tr><td class=text>");
  print("<p align=center><b>$question</b></p>\n");
  $voted = $arr2;
  if ($voted)
  {
    // display results
    if ($arr["selection"])
      $uservote = $arr["selection"];
    else
      $uservote = -1;
		// we reserve 255 for blank vote.
    $res = mysql_query("SELECT selection FROM pollanswers WHERE pollid=$pollid AND selection < 20") or sqlerr();

    $tvotes = mysql_num_rows($res);

    $vs = array(); // array of
    $os = array();

    // Count votes
    while ($arr2 = mysql_fetch_row($res))
      $vs[$arr2[0]] += 1;

    reset($o);
    for ($i = 0; $i < count($o); ++$i)
      if ($o[$i])
        $os[$i] = array($vs[$i], $o[$i]);

    function srt($a,$b)
    {
      if ($a[0] > $b[0]) return -1;
      if ($a[0] < $b[0]) return 1;
      return 0;
    }

    // now os is an array like this: array(array(123, "Option 1"), array(45, "Option 2"))
    if ($arr["sort"] == "yes")
    	usort($os, srt);
    print("<table class=poll width=100% border=0 cellspacing=0 cellpadding=0>\n");
    $i = 0;
    while ($a = $os[$i])
    {
      if ($i == $uservote)
        $a[1] .= "&nbsp;*";
      if ($tvotes == 0)
      	$p = 0;
      else
      	$p = round($a[0] / $tvotes * 100);
      if ($i % 2)
        $c = "";
      else
        $c = "";
      print("<tr><td width=1% class=embedded$c><nobr>" . $a[1] . "&nbsp;&nbsp;</nobr></td><td width=99% class=embedded$c>" .
        "<img class=pollleft src=/pic/blankpoll.gif><img class=poll src=/pic/blankpoll.gif height=9 width=" . ($p * 3) .
        "><img class=pollright src=/pic/blankpoll.gif> $p%</td></tr>\n");
      ++$i;
    }
    print("</table>\n");
	$tvotes = number_format($tvotes);
    print("<p align=center>Votes: $tvotes</p>\n");
  }
  else
  {
    print("<form method=post action=index.php>\n");
    $i = 0;
    while ($a = $o[$i])
    {
      print("<input type=radio name=choice value=$i>$a<br>\n");
      ++$i;
    }
    print("<br>");
    print("<input type=radio name=choice value=255>Blank vote (a.k.a. \"I just want to see the results!\")<br>\n");
    print("<p align=center><input type=submit value='Vote!' class=btn></p>");
}
  }
?>
</td></tr></table>
<?
if ($voted)
  print("<p align=center><a href=polls.php>Previous polls</a></p>\n");
?>
<a class=link href=/forums.php?action=viewtopic&topicid=1271>Comments about Poll</a>

</td></tr></table>

<?
}
?>
<? if (!$CURUSER)
{ ?>
<h2>Login</h2>
<form method="post" action="takelogin.php">
<table width=100%border=1 cellspacing=0 cellpadding=10>
<tr><td class=rowhead>Username:</td><td align=left><input type="text" size=40 name="username" />
<td class=rowhead>Password:</td><td align=right><input type="password" size=40 name="password" /></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Log in!" class=btn><td class=rowhead>Duration:</td><td align=left><input type=checkbox name=logout value='yes' checked>Log me out after 15 minutes inactivity</td></tr>
</table>
<? 
?>
</form>
<p>Don't have an account? <a href="signup.php">Sign up</a> right now!</p>
<?}
?>
<? if ($CURUSER)
{ ?>
<h2>Stats</h2>
<table width=100%border=1 cellspacing=0 cellpadding=10><tr><td align=center>
<table class=interiortable border=1 cellspacing=0 cellpadding=5>
<tr><td class=rowhead>Max users</td><td align=right><?=$invites?></td></tr>
<tr><td class=rowhead>Registered users</td><td align=right><?=$registered?></td></tr>

<tr><td class=rowhead>Unconfirmed users</td><td align=right><?=$unverified?></td></tr>
<tr><td class=rowhead>Male users</td><td align=right><?=$male?></td></tr>
<tr><td class=rowhead>Female users</td><td align=right><?=$female?></td></tr> 
<tr><td class=rowhead>Torrents</td><td align=right><?=$torrents?></td></tr>
<? if (isset($peers)) { ?>
<tr><td class=rowhead>Peers</td><td align=right><?=$peers?></td></tr>
<tr><td class=rowhead>Seeders</td><td align=right><?=$seeders?></td></tr>
<tr><td class=rowhead>Leechers</td><td align=right><?=$leechers?></td></tr>
<tr><td class=rowhead>Seeder/leecher ratio (%)</td><td align=right><?=$ratio?></td></tr>

<? } ?>
   </table>
<?
print("<p align=center><font class=small>Updated ".date('Y-m-d H:i:s', filemtime($file))."</font></p>");
?>
</td><td align=center>
<table width=175 class=interiortable border=1 cellspacing=0 cellpadding=4>
<tr><td class=rowcenter colspan=2>Last 10 visitors</td></tr>
<?
$file = "$CACHE/index/lastten.txt";

$expire = 30; // 30 seconds
if (file_exists($file) && filemtime($file) > (time() - $expire)) {
    $records = unserialize(file_get_contents($file));
} else {
$result = mysql_query("SELECT username,class,last_access,id FROM users WHERE last_access != '0000-00-00 00:00:00' ORDER BY last_access DESC LIMIT 10");
    while ($record = mysql_fetch_array($result) ) {
        $records[] = $record;
    }
    $OUTPUT = serialize($records);
    $fp = fopen($file,"w");
    fputs($fp, $OUTPUT);
    fclose($fp);
} // end else

foreach ($records as $arr)
{
   switch ($arr["class"])
   {
case UC_SYSOP:
case UC_ADMINISTRATOR:
     $arr["username"] = "<font color=#FF0000>" . $arr["username"] . "</font>";
     break;
case UC_MODERATOR:
     $arr["username"] = "<font color=#6B001A>" . $arr["username"] . "</font>";
     break;
case UC_UPLOADER:
     $arr["username"] = "<font color=#9A6258>" . $arr["username"] . "</font>";
     break;
case UC_VIP:
     $arr["username"] = "<font color=#FF6600>" . $arr["username"] . "</font>";
     break;
 case UC_POWER_USER:
     $arr["username"] = "<font color=#4F3157>" . $arr["username"] . "</font>";
     break;
   }
   $time = gmtime() - sql_timestamp_to_unix_timestamp($arr[last_access]);
   if ($CURUSER)
      echo "<tr><td style=\"border-right: none; padding-left: 5px\"><a href=userdetails.php?id=".$arr[id]."><b>".$arr[username]."</b></a></td><td style=\"border-left: none; padding-right: 5px\">".mkprettytime($time)." ago</td></tr>";
   else
      echo "<tr><td style=\"border-right: none; padding-left: 5px\"><b>".$arr[username]."</b></td><td style=\"border-left: none; padding-right: 5px\">".mkprettytime($time)." ago</td></tr>";
}
?>
</table>
<?
print("<p align=center><font class=small>Updated ".date('Y-m-d H:i:s', filemtime($file))."</font></p>");
?>
</td></tr></table>
<?
$file3 = "$CACHE/index/active.txt";
$expire = 30; // 30 seconds
if (file_exists($file3) && filemtime($file3) > (time() - $expire)) {
    $active3 = unserialize(file_get_contents($file3));
} else {
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$active1 = mysql_query("SELECT id, username, class, donor FROM users WHERE last_access >= $dt ORDER BY username") or print(mysql_error());
while ($active2 = mysql_fetch_array($active1) ) {
        $active3[] = $active2;
    }
    $OUTPUT = serialize($active3);
    $fp = fopen($file3,"w");
    fputs($fp, $OUTPUT);
    fclose($fp);
} // end else

foreach ($active3 as $arr)
{
  if ($activeusers) $activeusers .= ",\n";
  switch ($arr["class"])
  {
case UC_SYSOP:
case UC_ADMINISTRATOR:
     $arr["username"] = "<font color=#FF0000>" . $arr["username"] . "</font>";
     break;
case UC_MODERATOR:
     $arr["username"] = "<font color=#6B001A>" . $arr["username"] . "</font>";
     break;
case UC_UPLOADER:
     $arr["username"] = "<font color=#9A6258>" . $arr["username"] . "</font>";
     break;
case UC_VIP:
     $arr["username"] = "<font color=#FF6600>" . $arr["username"] . "</font>";
     break;
 case UC_POWER_USER:
     $arr["username"] = "<font color=#4F3157>" . $arr["username"] . "</font>";
     break;
  }
 $donator = $arr["donor"];
  if ($donator == "yes")
    $activeusers .= "<nobr>";
  if ($CURUSER)
    $activeusers .= "<a href=userdetails.php?id=" . $arr["id"] . "><b>" . $arr["username"] . "</b></a>";
  else
   $activeusers .= "<b>$arr[username]</b>";
  if ($donator == 'yes')
    $activeusers .= "<img src=/pic/star.gif alt='Donated
$$arr[donated]'></nobr>";



} 
if (!$activeusers)
  $activeusers = "There have been no active users lately.";

?>


<h2>Active users</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=stats>
<?=$activeusers?>

</td></tr></table>
<?}
?>
<h2>Server load</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>
<table class=interiortable border=0 width=402><tr><td style='padding: 0px; background-repeat: repeat-x'>
<? $percent = min(100, round(exec('ps ax | grep -c apache') / 256 * 30 ));
echo "<br>Our Tracker Load: ($percent %)(these stats are an approximation)<table class=interiortable border=0 width=400><tr><td style='padding: 0px; background-image: url(pic/loadbarbg.gif); background-repeat: repeat-x'>";

    if ($percent <= 70) $pic = "pic/loadbargreen.gif";
     elseif ($percent <= 90) $pic = "pic/loadbaryellow.gif";
      else $pic = "pic/loadbarred.gif";
           $width = $percent * 8;
echo "<img height=15 width=$width src=\"/$pic\" alt='$percent%'></td></tr></table>";
echo "" . trim(exec('uptime')) . "<br>";


  $percent = min(100, round(exec('ps ax | grep -c apache') / 256 * 150));
echo "<br>Global Server Load (All websites on current host servers): ($percent %)<table class=interiortable border=0 width=400><tr><td style='padding: 0px; background-image: url(pic/loadbarbg.gif); background-repeat: repeat-x'>";

    if ($percent <= 70) $pic = "pic/loadbargreen.gif";
     elseif ($percent <= 90) $pic = "pic/loadbaryellow.gif";
      else $pic = "pic/loadbarred.gif";
           $width = $percent * 8;
echo "<img height=15 width=$width src=\"$pic\" alt='$percent%'></td></tr></table>"; ?>



</td></tr></table>
</td></tr></table>

<p><font class=small>Disclaimer:None of the files shown here are actually hosted on this server. The links are provided solely by this site's users. These BitTorrent files are meant for the distribution of backup files. By downloading the BitTorrent file, you are claiming that you own the original file. The administrator of this site (http://bytelist.freestarthost.com)  holds NO RESPONSIBILITY if these files are misused in any way and cannot be held responsible for what its users post, or any other actions of its users.. For controversial reasons, if you are affiliated with any government, ANTI-Piracy group or any other related group, or were formally a worker of one you CANNOT download any of these BitTorrent files. If you download these files you are not agreeing to these terms and you are violating code 431.322.12 of the Internet Privacy Act signed by Bill Clinton in 1995 and that means that you CANNOT threaten our ISP(s) or any person(s) or company storing these files, and cannot prosecute any person(s) affiliated with this page which includes family, friends or individuals who run or enter this web site. If you do not agree to these terms, please do not use this service or you will face consequences. You may not use this site to distribute or download any material when you do not have the legal rights to do so.
It is your own responsibility to adhere to these terms.</font></p>

<p align=center>
<a href=http://www.downhillbattle.org/defense/><img src=/pic/supportfilesharing.gif border=0 alt="P2P Legal Defense Fund"><a href=http://www.eff.org/share//><img src=/pic/EFF.gif border=0 alt="P2P & Civil Liberties"></a>
</p>

</td></tr></table>


<?
if ($CURUSER) {
stdfoot();
} else {
	stdf00t();
}
hit_end();
?>
