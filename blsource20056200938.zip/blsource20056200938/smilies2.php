<?
require_once "include/bittorrent.php";
dbconn(false);
loggedinorreturn();

if ($CURUSER)
{
 $ss_a = @mysql_fetch_array(@mysql_query("select uri from stylesheets where id=" . $CURUSER["stylesheet"]));
 if ($ss_a) $ss_uri = $ss_a["uri"];
}
if (!$ss_uri)
{
 ($r = mysql_query("SELECT uri FROM stylesheets WHERE id=1")) or die(mysql_error());
 ($a = mysql_fetch_array($r)) or die(mysql_error());
 $ss_uri = $a["uri"];
}
?>

<html>
<head>
<script language="JavaScript">
   <!--
   function Smiliespm(Smilie) {
    opener.document.Form.msg.value += Smilie;
    focus(opener);
   }
   //-->
  </script>
<title>Clickable Smilies</title>
<link rel="stylesheet" href="/<?=$ss_uri?>" type="text/css">
</head>

<table width="100%" border=1 cellspacing="2" cellpadding="2">
<h2>Smilies</h2>
<tr align=center>
<?
$ctr=0;
while(list($key,$value) = each($smilies))
{

print("   <td><span title=\"".$key."\" class=popup><a href=\"javascript:Smiliespm('".$key."')\"><img src=\"/pic/smilies/".$value."\" border=0></a></span></td>\n");
$ctr++;
if(!($ctr % 3)) print("  </tr><tr align=center>");
}
?>
</tr>
</table>
<div align="center">
<a class=altlink_green href="javascript: window.close()"><? echo CLOSE; ?></a>
</div>
</body>
</html>