
<?
require "include/bittorrent.php";

dbconn(false);

loggedinorreturn();

/*===========================================================================*/
/*                                                                           */
/*                   Signature output script v0.09 build 2                   */
/*                               by psor 2004                                */
/*                             License: GNU-GPL                              */
/*                                                                           */
/*                Thanx goes to: archondark, stimpy and Merides              */
/*                                                                           */
/*===========================================================================*/

// gzip says hello //
ob_start("ob_gzhandler");
// change the haeder and params //
Header('Content-type: image/jpeg');
Header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
Header('Expires: Thu, 19 Nov 1981 08:52:00 GMT');
Header('Pragma: no-cache');

/* FUNCTIONS */

// make it readable for humans //
function mksize($bytes) {
    if ($bytes < 1000 * 1024) return number_format($bytes / 1024, 2) . " KB";
    elseif ($bytes < 1000 * 1048576) return number_format($bytes / 1048576, 2) . " MB";
    elseif ($bytes < 1000 * 1073741824) return number_format($bytes / 1073741824, 2) . " GB";
    else return number_format($bytes / 1099511627776, 2) . " TB";
}


/* CONFIGURATION-VARS */

// get hash //
$hash = $_GET["hash"];
// URL to signature key //
$sigurl = 'http://yourdomain.com/yourpath';
// path to the font to use //
//$font = 'D:\\WINDOWS\\Fonts\\verdana.ttf';
$font = '/usr/share/fonts/truetype/ttf-bitstream-vera/Vera.ttf';
// fontsize //
$size = 8;
// text top margin //
$top = 20;
// text left margin //
$left = 8;
// bg-pic //
$pic = 'path_to_the_bgimage(png)';

// create the image //
$image = @imagecreatefrompng($pic);

// set the colours //
$cool  = @imagecolorallocate($image, 200, 200, 250);
$black = @imagecolorallocate($image, 0, 0, 0);
$white = @imagecolorallocate($image, 255, 255, 255);
$red   = @imagecolorallocate($image, 255, 0, 0);
$grey  = @imagecolorallocate($image, 204, 204, 204);
$green = @imagecolorallocate($image, 206, 129, 18);
$blue  = @imagecolorallocate($image, 0, 0, 255);


/* EXECUTE */

// get the file calc the traffic, set the font and print text //
$fp=@fopen("$sigurl/$hash.txt", "rb");
if (!$fp) {
    $left = 80;
    @ImageTTFText($image, $size, 0, $left, $top, $white, $font, "Kein, oder falscher Signatur Key angegeben!");
} else {
        $data_info = @fread($fp,1024);
        @fclose($fp);
        $buffer = explode(",",$data_info);
        $info_stats_tracker[0] = mksize($buffer[0]);
    $info_stats_tracker[1] = mksize($buffer[1]);
    if ($buffer[1] > 0){
          $sr = $buffer[0] / $buffer[1];
          $sr = floor($sr * 1000) / 1000;
      }
    $info_stats_tracker[2] = number_format($sr, 3);
    $info_stats_tracker[3] = $buffer[2];
    $output = ("User: $info_stats_tracker[3], Uploaded: $info_stats_tracker[0], Downloaded: $info_stats_tracker[1], Ratio: $info_stats_tracker[2]");
    @ImageTTFText($image, $size, 0, $left, $top, $white, $font, $output);
        $top = $top + 15;
}
// output and destroy
@imagepng($image);
@imagedestroy($image);

?>