<?

require_once("include/bittorrent.php");

dbconn();

loggedinorreturn();

if (get_user_class() < UC_USER) die;

stdhead();
?>
<table class=main width=750 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>
<h2>Uploading Guide</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>
<p>This is a guide explaining how to upload torrents using the BitTorrent client Azureus.</p>
<ol>
<li>Download Azureus from here: '<a href=http://azureus.sourceforge.net/ target=_blank>Azureus</a>'.</li>
<li>Go to the preferences (Azureus->Preferences).</li>
<li>In the "Server" page change the "Incoming TCP listen port" to a non Peer-to-Peer port (6879 will work).</li>
If you have a firewall make sure this port range is open in both directions.
<li>Time to create a torrent to upload (File->Create a Torrent).</li>
<li>In the "Announce URL" put "<b><?= $announce_urls[0] ?>?passkey=<?= $CURUSER['passkey'] ?></b>" then click "Next".</li>
<li>Click the "Browse" button and find the file you want to share then click "Next".</li>
<li>Check to see if the right file is selected and click "Finish".</li>
<li>Voila, the torrent will be created where the file is.</li>
<li>Login to the site '<a href=/  target=_blank>BrokenStones</a>' and go to the "Upload" section.</li>
<li>In the "Torrent file" area click the "Browse" button and find the torrent file then click "Open".</li>
<li>In the "Torrent name" area type the name of the file if the name on the torrent is not descriptive.</li>
<li>In the "Description" area type a thorough description of the file. Make sure the description is complete and includes all relevant information. DO NOT POST SERIALS/CRACKS. </li>
<li>In the "Type" area choose the type of file by clicking on the pull down menu. Make sure the file is under the correct type.</li>
<li>Check over the following steps and if everything is correct click the "Do it!" button.</li>
<li>Time to seed the torrent: download the torrent off the site, click "Open"(File->Open->.torrent File), and find the downloaded torrent. You will not be able to seed the torrent created by the client because of the passkey that needs to be embedded in the torrent.</li>
<p>It will take a couple minutes for your torrent to appear in the "Browse" section. If you have any trouble following these instructions be sure to check the "FAQ" section for additional tips with different clients and so forth! If you still can not seem to upload torrents ask in the forum.</p>
</td></tr></table>
</td></tr></table>
<?

?>
<table class=main width=750 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>
<h2>Rules</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>
<p>Torrents violating these rules may be deleted without notice.</p>
<ol>
<li>You must have legal rights to the file you are uploading.</li>
<li>All uploads must include a detailed description.<br>Please refer to topic: <a href=/forums.php?action=viewtopic&topicid=1191>Poor descriptions</a></li>
<li>No nasty files!</li>
<li>All files must be in a legitiment format so they are functional.</li>
<li>Pre-release stuff should be labeled with an *ALPHA* or *BETA* tag.</li>
<li>Make sure not to include any serial numbers, CD keys or similar in the description (you do <b>not</b> need to edit the NFO!)..
<li>Make sure your torrents are well-seeded for at least 24 hours.</li>
<li>Do not include the release date in the torrent name.</li>
</ol>
<p>If you have something interesting that somehow violate these rules, ask a mod and we might make an exception.</p>
</td></tr></table>
</td></tr></table>
<?
  stdfoot();
?>