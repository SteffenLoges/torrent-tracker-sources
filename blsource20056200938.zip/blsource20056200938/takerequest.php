<?

require_once("include/bittorrent.php");

hit_start();

dbconn();
loggedinorreturn();
function bark($msg) {
 stdhead();
stdmsg("Request failed!", $msg);
 stdfoot();
 exit;
}

hit_count();

$userid = 0 + $_POST["userid"];
if (!validfilename($requesttitle))
	bark("Invalid filename!");
$request = $requesttitle;
$descr = unesc($_POST["descr"]);
if (!$descr)
  bark("You must enter a description!");
$cat = (0 + $_POST["category"]);
if (!is_valid_id($cat))
	bark("You must select a category to put the request in!");
$userid = sqlesc($userid);
$request = sqlesc($request);
$descr = sqlesc($descr);
$cat = sqlesc($cat);


mysql_query("INSERT INTO requests (hits,userid, cat, request, descr, added) VALUES(1,$CURUSER[id], $cat, $request, $descr, '" . get_date_time() . "')") or sqlerr(__FILE__,__LINE__);


$id = mysql_insert_id();

@mysql_query("INSERT INTO addedrequests VALUES(0, $id, $CURUSER[id])") or sqlerr();

write_log("Request ($request) was added to the Request section by " . $CURUSER["username"]);

header("Refresh: 0; url=requests.php");

hit_end();

?>