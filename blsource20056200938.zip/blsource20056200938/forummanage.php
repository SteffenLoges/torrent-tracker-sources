<?
ob_start("ob_gzhandler");
require "include/bittorrent.php";
dbconn();
loggedinorreturn();
stdhead("Forum Management Tools");
begin_main_frame();

// DELETE FORUM ACTION
if ($_GET['action'] == "del") {
if (get_user_class() < UC_MODERATOR)
    stderr("Error", "Toegang Geweigerd.");

if (!$id) { header("Location: $BASEURL/forummanage.php"); die();}

$result = mysql_query ("SELECT * FROM topics where forumid = '".$_GET['id']."'");
if ($row = mysql_fetch_array($result)) {
do {
mysql_query ("DELETE FROM posts where topicid = '".$row["id"]."'") or sqlerr(__FILE__, __LINE__);
} while($row = mysql_fetch_array($result));
}
mysql_query ("DELETE FROM topics where forumid = '".$_GET['id']."'") or sqlerr(__FILE__, __LINE__);
mysql_query ("DELETE FROM forums where id = '".$_GET['id']."'") or sqlerr(__FILE__, __LINE__);

header("Location: $BASEURL/forummanage.php");
die();
}

//EDIT FORUM ACTION
if ($_POST['action'] == "editforum") {
if (get_user_class() < UC_MODERATOR)
    stderr("Error", "Toegang Geweigerd.");

if (!$name && !$desc && !$id) { header("Location: $BASEURL/forummanage.php"); die();}

mysql_query("UPDATE forums SET sort = '" . $_POST['sort'] . "', name = " . sqlesc($_POST['name']). ", description = " . sqlesc($_POST['desc']). ", minclassread = '" . $_POST['readclass'] . "', minclasswrite = '" . $_POST['writeclass'] . "', minclasscreate = '" . $_POST['createclass'] . "' where id = '".$_POST['id']."'") or sqlerr(__FILE__, __LINE__);
header("Location: $BASEURL/forummanage.php");
die();
}

//ADD FORUM ACTION
if ($_POST['action'] == "addforum") {
if (get_user_class() < UC_MODERATOR)
    stderr("Error", "Toegang Geweigerd.");

if (!$name && !$desc) { header("Location: $BASEURL/forummanage.php"); die();}

mysql_query("INSERT INTO forums (sort, name,  description,  minclassread,  minclasswrite, minclasscreate) VALUES(" . $_POST['sort'] . ", " . sqlesc($_POST['name']). ", " . sqlesc($_POST['desc']). ", " . $_POST['readclass'] . ", " . $_POST['writeclass'] . ", " . $_POST['createclass'] . ")") or sqlerr(__FILE__, __LINE__);

header("Location: $BASEURL/forummanage.php");
die();
}

// SHOW FORUMS WITH FORUM MANAGMENT TOOLS
begin_frame("Forums");
?>
<script language="JavaScript">
<!--
function confirm_delete(id)
{
   if(confirm('Weet je zeker dat je dit forum wilt verwijderen?'))
   {
      self.location.href='<? $PHP_SELF; ?>?action=del&id='+id;
   }
}
//-->
</script>
<?
echo '<table width="700"  border="0" align="center" cellpadding="2" cellspacing="0">';
echo "<tr><td class=colhead align=left>Naam</td><td class=colhead>Topics</td><td class=colhead>Posts</td><td class=colhead>Lezen</td><td class=colhead>Posten</td><td class=colhead>Cre�er topic</td><td class=colhead>Bewerk</td></tr>";
$result = mysql_query ("SELECT  * FROM forums ORDER BY sort ASC");
if ($row = mysql_fetch_array($result)) {
do {
//if ($row["uploaded"] == "0" || $row["downloaded"] == "0") { $ratio = "inf"; } else {
//$ratio = $row["uploaded"] / $row["downloaded"];
//$ratio = number_format($ratio, 2);
//}    
echo "<tr><td><a href=forums.php?action=viewforum&forumid=".$row["id"]."><b>".$row["name"]."</b></a><br>".$row["description"]."</td>";
echo "<td>".$row["topiccount"]."</td><td>".$row["postcount"]."</td><td>minimaal " . get_user_class_name($row["minclassread"]) . "</td><td>minimaal " . get_user_class_name($row["minclasswrite"]) . "</td><td>minimaal " . get_user_class_name($row["minclasscreate"]) . "</td><td align=center nowrap><b><a href=\"".$PHP_SELF."?act=editforum&id=".$row["id"]."\">Bewerk</a>&nbsp;|&nbsp;<a href=\"javascript:confirm_delete('".$row["id"]."');\"><font color=red>Verwijder</font></a></b></td></tr>";
          
          
} while($row = mysql_fetch_array($result));
} else {print "<tr><td>Sorry, Niks Gevonden!</td></tr>";}      
echo "</table>";
?>
<br><br>
<form method=post action="<?=$PHP_SELF;?>">
<table width="600"  border="0" cellspacing="0" cellpadding="3" align="center">
<tr align="center">
    <td colspan="2" class=colhead>Maak nieuw forum</td>
  </tr>
  <tr>
    <td><b>Forum naam</td>
    <td><input name="name" type="text" size="20" maxlength="60"></td>
  </tr>
  <tr>
    <td><b>Forum omschrijving  </td>
    <td><input name="desc" type="text" size="30" maxlength="200"></td>
  </tr>
    <tr>
    <td><b>Minimale lees rang </td>
    <td>
    <select name=readclass>\n
    <?
         $maxclass = get_user_class();
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
    </select>
    </td>
  </tr>
  <tr>
    <td><b>Minimale post rang </td>
    <td><select name=writeclass>\n
    <?
          $maxclass = get_user_class();
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
    </select></td>
  </tr>
  <tr>
    <td><b>Minimale cre�er topic rang </td>
    <td><select name=createclass>\n
    <?
        $maxclass = get_user_class();
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
    </select></td>
  </tr>
    <tr>
    <td><b>Forum rang </td>
    <td>
    <select name=sort>\n
    <?
$res = mysql_query ("SELECT sort FROM forums");
$nr = mysql_num_rows($res);
        $maxclass = $nr + 1;
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i>$i \n");
?>
    </select>
    
    
    </td>
  </tr>
  
  <tr align="center">
    <td colspan="2"><input type="hidden" name="action" value="addforum"><input type="submit" name="Submit" value="Maak forum"></td>
  </tr>
</table>

<?
end_frame(); ?>

<? if ($act == "editforum") {

//EDIT PAGE FOR THE FORUMS
$id = $_GET["id"];
begin_frame("Bewerk Forum");
$result = mysql_query ("SELECT * FROM forums where id = '$id'");
if ($row = mysql_fetch_array($result)) {
do {
?>

<form method=post action="<?=$PHP_SELF;?>">
<table width="600"  border="0" cellspacing="0" cellpadding="3" align="center">
<tr align="center">
    <td colspan="2" class=colhead>Bewerk forum: <?=$row["name"];?></td>
  </tr>
  <tr>
    <td><b>Forum naam</td>
    <td><input name="name" type="text" size="20" maxlength="60" value="<?=$row["name"];?>"></td>
  </tr>
  <tr>
    <td><b>Forum omschrijving  </td>
    <td><input name="desc" type="text" size="30" maxlength="200" value="<?=$row["description"];?>"></td>
  </tr>
    <tr>
    <td><b>Minimale lees rang </td>
    <td>
    <select name=readclass>\n
    <?
         $maxclass = get_user_class();
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($row["minclassread"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
    </select>
    </td>
  </tr>
  <tr>
    <td><b>Minimale post rang </td>
    <td><select name=writeclass>\n
    <?
          $maxclass = get_user_class();
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($row["minclasswrite"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
    </select></td>
  </tr>
  <tr>
    <td><b>Minimale cre�er topic rang </td>
    <td><select name=createclass>\n
    <?
        $maxclass = get_user_class();
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($row["minclasscreate"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
    </select></td>
  </tr>
    <tr>
    <td><b>Forum rang </td>
    <td>
    <select name=sort>\n
    <?
$res = mysql_query ("SELECT sort FROM forums");
$nr = mysql_num_rows($res);
        $maxclass = $nr + 1;
      for ($i = 0; $i <= $maxclass; ++$i)
        print("<option value=$i" . ($row["sort"] == $i ? " selected" : "") . ">$i \n");
?>
    </select>
    
    
    </td>
  </tr>
  
  <tr align="center">
    <td colspan="2"><input type="hidden" name="action" value="editforum"><input type="hidden" name="id" value="<?=$id;?>"><input type="submit" name="Submit" value="Bewerk forum"></td>
  </tr>
</table>

<?
} while($row = mysql_fetch_array($result));
} else {print "Sorry, niks gevonden!";}      
end_frame();
end_main_frame();
}
stdfoot();
?>