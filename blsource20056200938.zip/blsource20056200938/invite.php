<?

require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();
if (get_user_class() < UC_USER)
	stderr("Error", "Access denied.");
$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $invites)
	stderr("Sorry", "The current user account limit (" . number_format($invites) . ") has been reached. Inactive accounts are pruned all the time, please check back again later...");
 if($CURUSER["invites"] == 0)
      stderr("Sorry","No invites!");
stdhead("Invite");
$msg = "IMPORTANT!

We do not want to see invite threads/posts on other boards! We will be actively scanning all the boards (yes, we're pretty sure we know of all of them) for these types of threads. Participating in these threads puts everyone here at risk and proves that you are not responsible enough to stay here. So:

ANYONE found participating in these threads will be banned. We will invesitgate all new signups and if they are found to be from one of these threads/posts, we will disable their account and the person who invited them.

Be discreet, invite people you trust. Thanks for your cooperation.

Example Message:
Hello,
I am inviting you to join $SITENAME. This is a private community which has very knowledgable members. If you are interested in joining the community please read over the rules and confirm the invite.
Regards,
$CURUSER[username]";
?>
<p>
<form method="post" action="takeinvite.php">
<table border="1" cellspacing=0 cellpadding="10">
<h3>Invite</h3>
<tr><td align="right" class="heading">Email address:</td><td align=left><input type="text" size="40" name="email" />
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>The email address must be valid.
They will receive a confirmation email which they need to respond to.</td></tr>
</font></td></tr></table>
<tr><td align="right" class="heading">Message:</td><td align=left><textarea name="mess" rows="20" cols="80"><?=$msg ?></textarea>
</td></tr>
<tr><td colspan="2" align="center"><input type=submit value="Invite! (PRESS ONLY ONCE)" style='height: 25px'></td></tr>
</table>
</form>
<?

stdfoot();

?>
