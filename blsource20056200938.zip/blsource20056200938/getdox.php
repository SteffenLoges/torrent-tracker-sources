<?
require "include/bittorrent.php";
dbconn();
if (!$CURUSER)
{
Header("Location: $BASEURL/");
die;
}
$filename = substr($HTTP_SERVER_VARS["PATH_INFO"], strrpos($HTTP_SERVER_VARS["PATH_INFO"], "/") + 1);
if (!$filename)
die("File name missing\n");
if (get_user_class() < UC_POWER_USER && filesize("$DOXPATH/$filename") > 1024*1024)
die("Sorry, you need to be a power user or higher to download files larger than 1.00 MB.\n");
$filename = sqlesc($filename);
$res = mysql_query("SELECT * FROM dox WHERE filename=$filename") or sqlerr();
$arr = mysql_fetch_assoc($res);
if (!$arr)
 die("Not found\n");
mysql_query("UPDATE dox SET hits=hits+1 WHERE id=$arr[id]") or sqlerr();
$file = "$DOXPATH/$arr[filename]";
header("Content-Length: " . filesize($file));
header("Content-Type: application/octet-stream");
readfile($file);
?>