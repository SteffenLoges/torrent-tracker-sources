<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");

hit_start();

dbconn(false);

loggedinorreturn();
parked();
hit_count();

$cats = genrelist();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
	unset($cleansearchstr);

if(isset($_GET["sort"]))
{
  $type = $_GET['sort'];
	  if (!is_valid_type($type))
	  {
		$msg = sqlesc("Invalid type: $type. Username: $CURUSER[username]\n");
		$dt = sqlesc(get_date_time());
  		mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(" . $CURUSER["id"] . ", 10, '" . get_date_time() . "' , $msg, 0 )") or sqlerr(__FILE__, __LINE__);
		stderr("Error", "Invalid type: $type.");
	  }

$sort = $_GET['d'];
	  if (!is_valid_sort($sort))
	  {
		$msg = sqlesc("Invalid sort: $sort. Username: $CURUSER[username]\n");
		$dt = sqlesc(get_date_time());
  		mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(" . $CURUSER["id"] . ", 10, '" . get_date_time() . "' , $msg, 0 )") or sqlerr(__FILE__, __LINE__);
		stderr("Error", "Invalid sort: $sort.");
	  }
$orderby = "ORDER BY $type $sort";
}
else
$orderby = "ORDER BY torrents.id DESC";


$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
	$addparam .= "incldead=1&amp;";
	if (!isset($CURUSER) || get_user_class < UC_ADMINISTRATOR)
		$wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
	$addparam .= "incldead=2&amp;";
		$wherea[] = "visible = 'no'";
}
	else
		$wherea[] = "visible = 'yes'";

$category = $_GET["cat"];

$all = $_GET["all"];

if (!$all)
	if (!$_GET && $CURUSER["notifs"])
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $cat[id];
	    if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
	    {
	      $wherecatina[] = $cat[id];
	      $addparam .= "c$cat[id]=1&amp;";
	    }
	  }
	}
	elseif ($category)
	{
	  if (!is_valid_id($category))
	    stderr("Error", "Invalid category ID $category.");
	  $wherecatina[] = $category;
	  $addparam .= "cat=$category&amp;";
	}
	else
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $_GET["c$cat[id]"];
	    if ($_GET["c$cat[id]"])
	    {
	      $wherecatina[] = $cat[id];
	      $addparam .= "c$cat[id]=1&amp;";
	    }
	  }
	}

if ($all)
{
	$wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
	$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
	$wherea[] = "category = $wherecatina[0]";

$wherebase = $wherea;

if (isset($cleansearchstr))
{
	$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
	//$wherea[] = "0";
	$addparam .= "search=" . urlencode($searchstr) . "&amp;";
	if(isset($_GET["sort"]))
		{
  $type = $_GET['sort'];
	  if (!is_valid_type($type))
	  {
		$msg = sqlesc("Invalid type: $type. Username: $CURUSER[username]\n");
		$dt = sqlesc(get_date_time());
  		mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(" . $CURUSER["id"] . ", 10, '" . get_date_time() . "' , $msg, 0 )") or sqlerr(__FILE__, __LINE__);
		stderr("Error", "Invalid type: $type.");
	  }

$sort = $_GET['d'];
	  if (!is_valid_sort($sort))
	  {
		$msg = sqlesc("Invalid sort: $sort. Username: $CURUSER[username]\n");
		$dt = sqlesc(get_date_time());
  		mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(" . $CURUSER["id"] . ", 10, '" . get_date_time() . "' , $msg, 0 )") or sqlerr(__FILE__, __LINE__);
		stderr("Error", "Invalid sort: $sort.");
	  }
$orderby = "ORDER BY $type $sort";

		}
	else
	$orderby = "ORDER BY torrents.id DESC";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
	$where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
	$where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
	$wherea = $wherebase;
	if(isset($_GET["sort"]))
		{
  $type = $_GET['sort'];
	  if (!is_valid_type($type))
	  {
		$msg = sqlesc("Invalid type: $type. Username: $CURUSER[username]\n");
		$dt = sqlesc(get_date_time());
  		mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(" . $CURUSER["id"] . ", 10, '" . get_date_time() . "' , $msg, 0 )") or sqlerr(__FILE__, __LINE__);
		stderr("Error", "Invalid type: $type.");
	  }

$sort = $_GET['d'];
	  if (!is_valid_sort($sort))
	  {
		$msg = sqlesc("Invalid sort: $sort. Username: $CURUSER[username]\n");
		$dt = sqlesc(get_date_time());
  		mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(" . $CURUSER["id"] . ", 10, '" . get_date_time() . "' , $msg, 0 )") or sqlerr(__FILE__, __LINE__);
		stderr("Error", "Invalid sort: $sort.");
	  }
$orderby = "ORDER BY $type $sort";

		}
	else
	$orderby = "ORDER BY torrents.id DESC";
	$searcha = explode(" ", $cleansearchstr);
	$sc = 0;
	foreach ($searcha as $searchss) {
		if (strlen($searchss) <= 1)
			continue;
		$sc++;
		if ($sc > 5)
			break;
		$ssa = array();
		foreach (array("search_text", "ori_descr") as $sss)
			$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
		$wherea[] = "(" . implode(" OR ", $ssa) . ")";
	}
	if ($sc) {
		$where = implode(" AND ", $wherea);
		if ($where != "")
			$where = "WHERE $where";
		$res = mysql_query("SELECT COUNT(*) FROM torrents $where");
		$row = mysql_fetch_array($res);
		$count = $row[0];
	}
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
	$torrentsperpage = 15;

if ($count)
{
	list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);
if (!$searchstr && $torrentsperpage ==15 && !isset($_GET["page"]) && !isset($_GET["incldead"]) && !isset($_GET["cat"]) && !$addparam)
$file = "$CACHE/browse/type-".$orderby.".txt";
else
$file = false;
$expire = 60; // 60 seconds
if (file_exists($file) && filemtime($file) > (time() - $expire)) {
    $records = unserialize(file_get_contents($file));
} else {

	$query = "SELECT torrents.id, torrents.category, torrents.leechers, torrents.seeders, torrents.name, torrents.times_completed, torrents.size, torrents.added,UNIX_TIMESTAMP(torrents.added) as utadded,torrents.comments,torrents.numfiles,torrents.filename,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
   "IF(torrents.numratings < $minvotes, 0, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, categories.stylesheet AS cat_stylesheet, users.username," .
   "categories.name AS cat_name, categories.image AS cat_pic, categories.stylesheet AS cat_stylesheet, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	"categories.name AS cat_name, categories.image AS cat_pic, categories.stylesheet AS cat_stylesheet, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
$result = mysql_query($query)
        or die (mysql_error());
    while ($record = mysql_fetch_array($result) ) {
        $records[] = $record;
    }
	if (!$searchstr && $torrentsperpage ==15 && !isset($_GET["page"]) && !isset($_GET["incldead"]) && !isset($_GET["cat"]) && !$addparam) {
    	$OUTPUT = serialize($records);
    	$fp = fopen($file,"w");
    	fputs($fp, $OUTPUT);
    	fclose($fp);
	}
} // end else
}
else
	unset($res);
if (isset($cleansearchstr))
	stdhead("Search results for \"$searchstr\"");
else
	stdhead();

?>

<STYLE TYPE="text/css" MEDIA=screen>

  a.catlink:link, a.catlink:visited{
		text-decoration: none;
	}

	a.catlink:hover {
		color: #A83838;
	}

</STYLE>

<form method="get" action="browse.php">
<table class=bottom>
<tr>
<td class=bottom>
	<table class=bottom>
	<tr>

<?
$i = 0;
foreach ($cats as $cat)
{
	$catsperrow = 7;
	print(($i && $i % $catsperrow == 0) ? "</tr><tr>" : "");







	print("<td class=bottom style=\"padding-bottom: 2px;padding-left: 7px\"><input name=c$cat[id] type=\"checkbox\" " . (in_array($cat[id],$wherecatina) ? "checked " : "") . "value=1><a class=catlink href=browse.php?cat=$cat[id]>" . htmlspecialchars($cat[name]) . "</a></td>\n");
	$i++;
}

$alllink = "<div align=left>(<a href=browse.php?all=1><b>Show all</b></a>)</div>";

$ncats = count($cats);
$nrows = ceil($ncats/$catsperrow);
$lastrowcols = $ncats % $catsperrow;

if ($lastrowcols != 0)
{
	if ($catsperrow - $lastrowcols != 1)
		{
			print("<td class=bottom rowspan=" . ($catsperrow  - $lastrowcols - 1) . ">&nbsp;</td>");
		}
	print("<td class=bottom style=\"padding-left: 5px\">$alllink</td>\n");
}
?>
	</tr>
	</table>
</td>

<td class=bottom>
<table class=browse>
	<tr>
		<td class=bottom style="padding: 1px;padding-left: 10px">
			<select name=incldead>
<option value="0">active</option>
<option value="1"<? print($_GET["incldead"] == 1 ? " selected" : ""); ?>>including dead</option>
<option value="2"<? print($_GET["incldead"] == 2 ? " selected" : ""); ?>>only dead</option>
			</select>
  	</td>
<?
if ($ncats % $catsperrow == 0)
	print("<td class=bottom style=\"padding-left: 15px\" rowspan=$nrows valign=center align=right>$alllink</td>\n");
?>

  </tr>
  <tr>
  	<td class=bottom style="padding: 1px;padding-left: 10px">
  	<div align=center>
  		<input type="submit" class=btn value="Go!"/>
  	</div>
  	</td>
  </tr>
  </table>
</td>
</tr>
</table>


<?

?>
<table width=100% class=browse border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>

<form method="get" action=browse.php>
<p align="center">
Search:
<input type="text" name="search" size="40" value="<?= htmlspecialchars($searchstr) ?>" />
<?
?>
<input type="submit" value="Search!" />
</form>
</td>
</tr>
</table>
<?

if (isset($cleansearchstr))
print("<h3>Search results for \"" . htmlspecialchars($searchstr) . "\"</h3>\n");

if ($count) {
	print($pagertop);

	torrenttable($records, "browse.php?" . $addparam);

	print($pagerbottom);
}
else {
	if (isset($cleansearchstr)) {
		print("<h3>Nothing found!</h3>\n");
		print("<p>Try again with a refined search string.</p>\n");
	}
	else {
		print("<h3>Nothing here!</h3>\n");
		print("<p>Sorry pal :(</p>\n");
	}
}
mysql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);

stdfoot();

hit_end();

?>