<?
require "include/bittorrent.php";

dbconn();

loggedinorreturn();

stdhead("Requests Page");

print("<h1>Requests Section</h1>\n");



$order = "hits DESC";
$res = mysql_query("SELECT users.downloaded, users.uploaded, users.username, requests.filled, requests.filledurl, requests.filledby, requests.id, requests.userid, requests.request, requests.added, UNIX_TIMESTAMP(requests.added) as utadded, requests.hits, categories.name as cat, categories.stylesheet as stylesheet FROM requests inner join categories on requests.cat = categories.id inner join users on requests.userid = users.id  ORDER BY $order LIMIT 5") or sqlerr();
$num = mysql_num_rows($res);

print("<table class=main><tr><td class=embedded>\n");
print("To add a vote for a request, click on the link of the request.\n");
print("<table border=1 width=100% cellspacing=0 cellpadding=5>\n");
print("<tr><td class=colhead align=left>Requests (top 5 requested)</td><td class=colhead align=center>Category</td><td class=colhead align=center width=150>Added</td><td class=colhead align=center>Added By</td><td class=colhead align=center>Filled?</td><td class=colhead align=center>Filled By</td><td class=colhead align=center width=50>Votes</td></tr>\n");
for ($i = 0; $i < $num; ++$i)
{



 $arr = mysql_fetch_assoc($res);
$timezone = display_date_time($arr["utadded"] , $CURUSER[tzoffset] );
if ($arr["downloaded"] > 0)
   {
     $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
     $ratio = "<font color=" . get_ratio_color($ratio) . "><b>$ratio</b></font>";
   }
   else if ($arr["uploaded"] > 0)
       $ratio = "Inf.";
   else
       $ratio = "---";


$res2 = mysql_query("SELECT username from users where id=" . $arr[filledby]);
$arr2 = mysql_fetch_assoc($res2);  
if ($arr2[username])
$filledby = $arr2[username];
else
$filledby = " ";      
$addedby = "<td style='padding: 0px' align=center><a href=userdetails.php?id=$arr[userid]><b>$arr[username] ($ratio)</b></a></td>";
$filled = $arr[filledurl];
if ($arr[filled] == yes)
$filled = "<a href=$filled><font color=green><b>Yes</b></font></a>";
else
$filled = "<a href=reqdetails.php?id=$arr[id]><font color=red><b>No</b></font></a>";
 print("<tr><td align=left><a href=reqdetails.php?id=$arr[id]><b>$arr[request]</b></a></td>" .
 "<td align=center><img class=\"" . $arr[stylesheet ] . "\" src=/pic/blank2.gif></td><td align=center>$timezone</td>$addedby<td>$filled</td><td><a href=userdetails.php?id=$arr[filledby]><b>$arr2[username]</b></a></td><td align=center><a href=votesview.php?requestid=$arr[id]><b>$arr[hits]</b></a><br><a class=\"sublink\" href=addrequest.php?id=$arr[id]><b>[Add vote]</b></a></td></tr>\n");
}

print("<tr><td align=right colspan=7><form method=\"get\" action=viewrequests.php><input type=\"submit\" value=\"Show All\" style='height: 18px' /></td></tr>\n");
print("</table>\n");
?>
</form> 
<?
print("<br>\n");

print("<table border=1 width=100% cellspacing=0 cellpadding=5>\n");


$where = "WHERE userid = " . $CURUSER["id"] . "";
$res2 = mysql_query("SELECT *,UNIX_TIMESTAMP(added) as utadded FROM requests $where ORDER BY hits DESC") or sqlerr();
$num2 = mysql_num_rows($res2);
// ------------------ 

while ($arr = @mysql_fetch_assoc($res2)) { 
{
    $cres = mysql_query("SELECT id,username FROM users WHERE id=$arr[userid]");
    if (mysql_num_rows($cres) == 1)
    {
      $carr = mysql_fetch_assoc($cres);
      $addedby = "$carr[username]";
    }
$timezone = display_date_time($arr["utadded"] , $CURUSER[tzoffset] );
if ($CURUSER["id"]==$arr[userid])
{
?> 
<form method="post" action="takedelownreq.php"> 
<tr><td class="colhead" align="left">Requests</td><td class="colhead" align="left">Added</td><td class="colhead" align="left">Votes</td><td class="colhead">Del</td></tr> 
<? 
  }
echo "<tr><td align=\"left\"><b>" . $arr[request] . "</b></td><td align=\"left\">" . $timezone . "</td><td align=\"center\">" . $arr[hits] . "</td><td><input type=\"checkbox\" name=\"delreq[]\" value=\"" . $arr[id] . "\" /></td></tr>"; 
} 
?> 
<tr><td colspan="5" align="right"><input type="submit" value="Do it!" /></td></tr> 
</form> 
<? 
}
print("</table>");

print("<br>\n"); ?>

<table border="1" width="100%" cellspacing="0" cellpadding="5">
<tr><td class=colhead align=left>Search Requests (before adding a request)</td></tr>
<tr><td align=left><form method=get action=viewrequests.php>
<input type="text" name="search" size="40" value="<?= htmlspecialchars($searchstr) ?>" />
in
<select name="cat">
<option value="0">(all types)</option>
<?


$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
   $catdropdown .= "<option value=\"" . $cat["id"] . "\"";
   if ($cat["id"] == $_GET["cat"])
       $catdropdown .= " selected=\"selected\"";
   $catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}
?>
<?= $catdropdown ?>
</select>
<input type="submit" value="Search!" style='height: 18px' />
</form>
</td></tr></table>
<br>
<table border="1" width="100%" cellspacing="0" cellpadding="5">
<tr><td class=colhead align=left>Search Torrents (before adding a request)</td></tr>
<tr><td align=left><form method="get" action=browse.php>
<input type="text" name="search" size="40" value="<?= htmlspecialchars($searchstr) ?>" />
in
<select name="cat">
<option value="0">(all types)</option>
<?


$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
   $catdropdown .= "<option value=\"" . $cat["id"] . "\"";
   if ($cat["id"] == $_GET["cat"])


       $catdropdown .= " selected=\"selected\"";
   $catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

$deadchkbox = "<input type=\"checkbox\" name=\"incldead\" value=\"1\"";
if ($_GET["incldead"])
   $deadchkbox .= " checked=\"checked\"";
$deadchkbox .= " /> including dead torrents\n";

?>
<?= $catdropdown ?>
</select>
<?= $deadchkbox ?>
<input type="submit" value="Search!" style='height: 18px' />
</form>
</td></tr></table>
<? print("<br>\n");
if ($CURUSER["downloaded"])
$ratio=$CURUSER["uploaded"]/$CURUSER["downloaded"];
else
$ratio=0;
if ($ratio>= 0)
{
print("<form method=post action=takerequest.php><a name=add id=add></a>\n");
print("<table border=1 width=100% cellspacing=0 cellpadding=5>\n");

print("<tr><td class=colhead align=left>Request: Will be deleted after 3 weeks! (please use descriptive names)<tr>\n");
print("<tr><td align=left><b> Title: </b><input type=text size=40 name=requesttitle>");
?>

<select name="category">
<option value="0">(Select a Category)</option>
<?

$res2 = mysql_query("SELECT id, name FROM categories order by name");
$num = mysql_num_rows($res2);
$catdropdown2 = "";
for ($i = 0; $i < $num; ++$i)
   {
 $cats2 = mysql_fetch_assoc($res2);  
     $catdropdown2 .= "<option value=\"" . $cats2["id"] . "\"";
     $catdropdown2 .= ">" . htmlspecialchars($cats2["name"]) . "</option>\n";
   }

?>
<?= $catdropdown2 ?>
</select>

<? print("<br>\n");



print("<tr><td align=center>Additional Information<br><textarea name=descr rows=5 cols=100></textarea>\n");
print("<tr><td align=center><input type=submit value=Submit! style='height: 22px'>\n");
print("</form>\n");
print("</table>\n");
}
print("</td></tr></table>\n");
stdfoot();
die;

?>