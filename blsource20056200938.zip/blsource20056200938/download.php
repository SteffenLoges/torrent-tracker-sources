<?
/**
*@ Thanks to Wilba from tbsource for providing the base code for this script.
*/
require_once("include/bittorrent.php");
global $CURUSER;

dbconn();

$id = (int)$_GET["id"];
$name = $_GET["name"];

if (!$id)
httperr();

function loginfailed($reason) {
header('WWW-Authenticate: Basic realm="CoreDownload"');
header('HTTP/1.0 401 Unauthorized');
# print($reason);
print('You are required to log in to download');
exit;
}

#Added by Xan - HTTP authentication
#for users downloading with wget or something similar
if (!$CURUSER) {
if (!isset($_SERVER['PHP_AUTH_USER'])) loginfailed("No user specified");
else {
$res = mysql_query("SELECT * FROM users WHERE username = " . sqlesc($_SERVER['PHP_AUTH_USER']) . " AND status = 'confirmed'");
$CURUSER = mysql_fetch_array($res);

if (!$CURUSER) loginfailed("User not found " . $_SERVER['PHP_AUTH_USER']);
if ($CURUSER["passhash"] != md5($CURUSER["secret"] . $_SERVER['PHP_AUTH_PW'] . $CURUSER["secret"])) loginfailed("Invalid password");
if ($CURUSER["enabled"] == "no") loginfailed("Not enabled");
}
}

$res = mysql_query("SELECT name FROM torrents WHERE id = $id") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_assoc($res);

$fn = "$torrent_dir/$id.torrent";
///PASSKEY///
require_once "include/benc.php";
if (strlen($CURUSER['passkey']) != 32) {
   $CURUSER['passkey'] = md5($CURUSER['username'].get_date_time().$CURUSER['passhash']);
   mysql_query("UPDATE users SET passkey='$CURUSER[passkey]' WHERE id=$CURUSER[id]");
}
///ENCODE PASSKEY

$dict = bdec_file($fn, (1024*1024));
$dict['value']['announce']['value'] = "$BASEURL/announce.php?passkey=$CURUSER[passkey]";
$dict['value']['announce']['string'] = strlen($dict['value']['announce']['value']).":".$dict['value']['announce']['value'];
$dict['value']['announce']['strlen'] = strlen($dict['value']['announce']['string']);
if (!$row || !is_file($fn) || !is_readable($fn))
httperr();

mysql_query("UPDATE torrents SET hits = hits + 1 WHERE id = $id");

header("Content-Type: application/x-bittorrent");
/*header("Content-Type: application/force-download");*/
header("Content-Disposition: attachment; filename=".$_GET["name"]."");
print(benc($dict));

?>