<?
require "include/bittorrent.php";
dbconn();
loggedinorreturn();

// DELETE FORUM ACTION
if ($_GET['action'] == "del") {
if (get_user_class() < UC_ADMINISTRATOR)
	stderr("Error", "Permission denied.");

if (!$id) { header("Location: $PHP_SELF?act=forum"); die();}

$result = mysql_query ("SELECT * FROM topics where forumid = '".$_GET['id']."'");
if ($row = mysql_fetch_array($result)) {
do { 
mysql_query ("DELETE FROM posts where topicid = '".$row["id"]."'") or sqlerr(__FILE__, __LINE__);
} while($row = mysql_fetch_array($result));
}
mysql_query ("DELETE FROM topics where forumid = '".$_GET['id']."'") or sqlerr(__FILE__, __LINE__);
mysql_query ("DELETE FROM forums where id = '".$_GET['id']."'") or sqlerr(__FILE__, __LINE__);

header("Location: $PHP_SELF?act=forum");
die();
}

//EDIT FORUM ACTION
if ($_POST['action'] == "editforum") {
if (get_user_class() < UC_ADMINISTRATOR)
	stderr("Error", "Permission denied.");

if (!$name && !$desc && !$id) { header("Location: $PHP_SELF?act=forum"); die();}

mysql_query("UPDATE forums SET sort = '" . $_POST['sort'] . "', name = " . sqlesc($_POST['name']). ", description = " . sqlesc($_POST['desc']). ", minclassread = '" . $_POST['readclass'] . "', minclasswrite = '" . $_POST['writeclass'] . "', minclasscreate = '" . $_POST['createclass'] . "' where id = '".$_POST['id']."'") or sqlerr(__FILE__, __LINE__);
header("Location: $PHP_SELF?act=forum");
die();
}

//ADD FORUM ACTION
if ($_POST['action'] == "addforum") {
if (get_user_class() < UC_ADMINISTRATOR)
	stderr("Error", "Permission denied.");

if (!$name && !$desc) { header("Location: $PHP_SELF?act=forum"); die();}

mysql_query("INSERT INTO forums (sort, name,  description,  minclassread,  minclasswrite, minclasscreate) VALUES(" . $_POST['sort'] . ", " . sqlesc($_POST['name']). ", " . sqlesc($_POST['desc']). ", " . $_POST['readclass'] . ", " . $_POST['writeclass'] . ", " . $_POST['createclass'] . ")") or sqlerr(__FILE__, __LINE__);

header("Location: $PHP_SELF?act=forum");
die();
}

//ADD IP TO BAN LIST ACTION
if ($_POST['action'] == "ban") {
if (get_user_class() < UC_ADMINISTRATOR)
	stderr("Error", "Permission denied.");

if (!$first && !$last) { header("Location: $PHP_SELF?act=ban"); die();}
$first = ip2long($_POST['first']);
$last = ip2long($_POST['last']);
mysql_query("INSERT INTO bans (first, last, comment, added, addedby) VALUES(" . $first . ", " . $last. ", " . sqlesc($_POST['comment']). ", '" . get_date_time() . "', " . $CURUSER["id"] . ")") or sqlerr(__FILE__, __LINE__);

header("Location: $PHP_SELF?act=ban");
die();
}

//DELETE IP FROM BAN LIST
if ($_GET['action'] == "ipdel") {
if (get_user_class() < UC_ADMINISTRATOR)
	stderr("Error", "Permission denied.");

if (!$id) { header("Location: $PHP_SELF?act=ban"); die();}
mysql_query ("DELETE FROM bans where id = '".$_GET['id']."'") or sqlerr(__FILE__, __LINE__);
header("Location: $PHP_SELF?act=ban");
die();
}

stdhead("Staff");
begin_main_frame();
?>


<?
if (!$act) {
 
 // LIST ALL ADMINISTRATORS AND MODERATORS 
 $dt = gmtime() - 180;
 $dt = sqlesc(get_date_time($dt));
 // Search User Database for Moderators and above and display in alphabetical order
 $res = mysql_query("SELECT * FROM users WHERE class>=".UC_UPLOADER.
   " AND status='confirmed' ORDER BY username" ) or sqlerr();
 while ($arr = mysql_fetch_assoc($res))
 {
   $staff_table[$arr['class']]=$staff_table[$arr['class']].
     "<td class=embedded><a class=altlink href=userdetails.php?id=".$arr['id'].">".
     $arr['username']."</a></td><td class=embedded> ".("'".$arr['last_access']."'">$dt?"<img src=pic/online.gif border=0 alt=pic\"Online\">":"<img src=pic/offline.gif border=0 alt=\"Offline\">" )."</td>".
     "<td class=embedded><a href=sendmessage.php?receiver=".$arr['id'].">".
     "<img src=pic/button_pm.gif border=0 alt=\"Send PM\"></a></td>";
   // Show 3 staff per row, separated by an empty column
   ++ $col[$arr['class']];
   if ($col[$arr['class']]<=2)
     $staff_table[$arr['class']]=$staff_table[$arr['class']]."<td class=embedded>&nbsp;</td>";
   else
   {
     $staff_table[$arr['class']]=$staff_table[$arr['class']]."</tr><tr height=15>";
     $col[$arr['class']]=0;
   }
 }
begin_frame("Staff");
?>
All software support questions and those already answered in the <a href=faq.php><b>FAQ</b></a> will be ignored.<br>
<br>
<table width=725 cellspacing=0 align=center>
<tr>
 <!-- Define table column widths -->
   <td class=embedded width="125">&nbsp;</td>
   <td class=embedded width="25">&nbsp;</td>
   <td class=embedded width="35">&nbsp;</td>
   <td class=embedded width="85">&nbsp;</td>
   <td class=embedded width="125">&nbsp;</td>
   <td class=embedded width="25">&nbsp;</td>
   <td class=embedded width="35">&nbsp;</td>
   <td class=embedded width="85">&nbsp;</td>
   <td class=embedded width="125">&nbsp;</td>
   <td class=embedded width="25">&nbsp;</td>
   <td class=embedded width="35">&nbsp;</td>
 </tr>
 <tr><td class=embedded colspan=11><b>SysOp</b></td></tr>
 <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
 <tr height=15>
<?=$staff_table[UC_SYSOP]?>
 </tr>
 <tr><td class=embedded colspan=11>&nbsp;</td></tr>
 <tr><td class=embedded colspan=11><b>Administrators</b></td></tr>
 <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
 <tr height=15>
<?=$staff_table[UC_ADMINISTRATOR]?>
 </tr>
 <tr><td class=embedded colspan=11>&nbsp;</td></tr>
 <tr><td class=embedded colspan=11><b>Moderators</b></td></tr>
 <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
 <tr height=15>
<?=$staff_table[UC_MODERATOR]?>
 </tr>
 <tr><td class=embedded colspan=11>&nbsp;</td></tr>
 <tr><td class=embedded colspan=11><b>Uploaders</b></td></tr>
 <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
 <tr height=15>
<?=$staff_table[UC_UPLOADER]?>
 </tr>
</table></table>
<? 
}
   /* Display Site Owner Tools if user is SysOp */
    if (get_user_class() >= UC_SYSOP)
    {
        begin_frame("SysOp Tools<font color=#004E98> - Viewable by SysOp only.</font>"); ?>
<table width=640 cellspacing=3>
<tr>
	<td class=embedded><a class=altlink href=sqlcmdex.php>Execute Raw SQL </a></td>
	<td class=embedded>MAY BE DANGEROUS!!!</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=adminstuff.php>Category/Forums Management</a></td>
	<td class=embedded>Allows SysOp to manage categories, and forums on-site.</td>
</tr>
</table>
<?      end_frame();
    }

	/* Display Site Owner Tools if user is Administrator */
    if (get_user_class() >= UC_ADMINISTRATOR)
    {
        begin_frame("Admin Tools<font color=#004E98> - Viewable by Admin only.</font>"); ?>
<table width=640 cellspacing=3>
<tr>
	<td class=embedded><a class=altlink href=makepoll.php>Create Poll</a></td>
	<td class=embedded>Create a new poll</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=bitbucket-upload.php>BitBucket</a></td>
	<td class=embedded>Upload pics make sure size and format are correct. One per person</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=unco.php>Unconfirmed Users</a></td>
	<td class=embedded>Shows unconfirmed users</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=peasant.php>Peasants</a></td>
	<td class=embedded>Users demoted to Peasant</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=<?=$PHP_SELF;?>?act=ban>Ban IP</a></td>
	<td class=embedded>Ban ip or ip range from the site</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=<?=$PHP_SELF;?>?act=forum>Manage Forums</a></td>
	<td class=embedded>Add, edit and delete your forums</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=news.php>News page</a></td>
	<td class=embedded>Add, edit and remove news items from the homepage</td>
</tr>
</table>
<?      end_frame();
    }
?>

<? if (get_user_class() >= UC_MODERATOR) { 
// LIST OF THE MOD TOOLS (ONLY VISIBLE WHEN YOU ARE MOD, ELSE YOU ONLY SEE LIST OF MODS
	
begin_frame("Staff tools - <font color=#004E98>Viewable by Mods only.</font>"); ?>


<table width=640 cellspacing=3>
<tr>
	<td class=embedded><a class=altlink href=<?=$PHP_SELF;?>?act=upstats>Uploading Stats</a></td>
	<td class=embedded>List upload activity and category activity</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=delreq.php>Delete Req</a></td>
	<td class=embedded>Delete torrent request(s)</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=<?=$PHP_SELF;?>?act=last>Newest users</a></td>
	<td class=embedded>100 newest user accounts</td>
</tr>
<tr>
	<td class=embedded><a class=altlink href=adduser.php>Add User</a></td>
	<td class=embedded>Create new user account</td>
</tr>
</table>

<? end_frame();
?>
<?
?>
<br>
<? if (get_user_class() >= UC_MODERATOR) {
?>

<form method=get action=usersearch.php>
<table align="center" width="100%" border="1" cellspacing="0" cellpadding="5">
<tr>

  <td valign="middle" class=rowhead>Name:</td>

  <td<?=$_GET['n']?$highlight:""?>><input name="n" type="text" value="<?=$_GET['n']?>" size=35></td>

  <td valign="middle" class=rowhead>Ratio:</td>
  <td<?=$_GET['r']?$highlight:""?>><select name="rt">
    <?
	$options = array("equal","above","below","between");
	for ($i = 0; $i < count($options); $i++){
	    echo "<option value=$i ".(($_GET['rt']=="$i")?"selected":"").">".$options[$i]."</option>\n";
	}
	?>
    </select>
    <input name="r" type="text" value="<?=$_GET['r']?>" size="5" maxlength="4">
    <input name="r2" type="text" value="<?=$_GET['r2']?>" size="5" maxlength="4"></td>

  <td valign="middle" class=rowhead>Member status:</td>
  <td<?=$_GET['st']?$highlight:""?>><select name="st">
    <?
	$options = array("(any)","confirmed","pending");
	for ($i = 0; $i < count($options); $i++){
	    echo "<option value=$i ".(($_GET['st']=="$i")?"selected":"").">".$options[$i]."</option>\n";
	}
    ?>
    </select></td></tr>
<tr><td valign="middle" class=rowhead>Email:</td>
  <td<?=$_GET['em']?$highlight:""?>><input name="em" type="text" value="<?=$_GET['em']?>" size="35"></td>

  <td valign="middle" class=rowhead>IP:</td>
  <td<?=$_GET['ip']?$highlight:""?>><input name="ip" type="text" value="<?=$_GET['ip']?>" maxlength="17"></td>

  <td valign="middle" class=rowhead>Account status:</td>
  <td<?=$_GET['as']?$highlight:""?>><select name="as">
    <?
    $options = array("(any)","enabled","disabled");
    for ($i = 0; $i < count($options); $i++){
      echo "<option value=$i ".(($_GET['as']=="$i")?"selected":"").">".$options[$i]."</option>\n";
    }
    ?>
    </select></td></tr>
<tr>
  <td valign="middle" class=rowhead>Comment:</td>
  <td<?=$_GET['co']?$highlight:""?>><input name="co" type="text" value="<?=$_GET['co']?>" size="35"></td>
  <td valign="middle" class=rowhead>Mask:</td>
  <td<?=$_GET['ma']?$highlight:""?>><input name="ma" type="text" value="<?=$_GET['ma']?>" maxlength="17"></td>
  <td valign="middle" class=rowhead>Class:</td>
  <td<?=($_GET['c'] && $_GET['c'] != 1)?$highlight:""?>><select name="c"><option value='1'>(any)</option>
  <?
  $class = $_GET['c'];
  if (!is_valid_id($class))
  	$class = '';
  for ($i = 2;;++$i) {
		if ($c = get_user_class_name($i-2))
       	 print("<option value=" . $i . ($class && $class == $i? " selected" : "") . ">$c</option>\n");
	  else
	   	break;
	}
	?>
    </select></td></tr>
<tr>

    <td valign="middle" class=rowhead>Joined:</td>

  <td<?=$_GET['d']?$highlight:""?>><select name="dt">
    <?
	$options = array("on","before","after","between");
	for ($i = 0; $i < count($options); $i++){
	  echo "<option value=$i ".(($_GET['dt']=="$i")?"selected":"").">".$options[$i]."</option>\n";
	}
    ?>
    </select>

    <input name="d" type="text" value="<?=$_GET['d']?>" size="12" maxlength="10">

    <input name="d2" type="text" value="<?=$_GET['d2']?>" size="12" maxlength="10"></td>


  <td valign="middle" class=rowhead>Uploaded:</td>

  <td<?=$_GET['ul']?$highlight:""?>><select name="ult" id="ult">
    <?
    $options = array("equal","above","below","between");
    for ($i = 0; $i < count($options); $i++){
  	  echo "<option value=$i ".(($_GET['ult']=="$i")?"selected":"").">".$options[$i]."</option>\n";
    }
    ?>
    </select>

    <input name="ul" type="text" id="ul" size="8" maxlength="7" value="<?=$_GET['ul']?>">

    <input name="ul2" type="text" id="ul2" size="8" maxlength="7" value="<?=$_GET['ul2']?>"></td>
  <td valign="middle" class="rowhead">Donor:</td>

  <td<?=$_GET['do']?$highlight:""?>><select name="do">
    <?
    $options = array("(any)","Yes","No");
	for ($i = 0; $i < count($options); $i++){
	  echo "<option value=$i ".(($_GET['do']=="$i")?"selected":"").">".$options[$i]."</option>\n";
    }
    ?>
	</select></td></tr>
<tr>

<td valign="middle" class=rowhead>Last seen:</td>

  <td <?=$_GET['ls']?$highlight:""?>><select name="lst">
  <?
  $options = array("on","before","after","between");
  for ($i = 0; $i < count($options); $i++){
    echo "<option value=$i ".(($_GET['lst']=="$i")?"selected":"").">".$options[$i]."</option>\n";
  }
  ?>
  </select>

  <input name="ls" type="text" value="<?=$_GET['ls']?>" size="12" maxlength="10">

  <input name="ls2" type="text" value="<?=$_GET['ls2']?>" size="12" maxlength="10"></td>
	  <td valign="middle" class=rowhead>Downloaded:</td>

  <td<?=$_GET['dl']?$highlight:""?>><select name="dlt" id="dlt">
  <?
	$options = array("equal","above","below","between");
	for ($i = 0; $i < count($options); $i++){
	  echo "<option value=$i ".(($_GET['dlt']=="$i")?"selected":"").">".$options[$i]."</option>\n";
	}
	?>
    </select>

    <input name="dl" type="text" id="dl" size="8" maxlength="7" value="<?=$_GET['dl']?>">

    <input name="dl2" type="text" id="dl2" size="8" maxlength="7" value="<?=$_GET['dl2']?>"></td>

	<td valign="middle" class=rowhead>Warned:</td>

	<td<?=$_GET['w']?$highlight:""?>><select name="w">
  <?
  $options = array("(any)","Yes","No");
	for ($i = 0; $i < count($options); $i++){
		echo "<option value=$i ".(($_GET['w']=="$i")?"selected":"").">".$options[$i]."</option>\n";
  }
  ?>
	</select></td></tr>

<tr>  <td valign="middle" class=rowhead>Passkey:</td>
  <td<?=$_GET['pass']?$highlight:""?>><input name="pass" type="text" value="<?=$_GET['pass']?>" size="35"></td>
  <td valign="middle" class=rowhead>Active only:</td>
	<td<?=$_GET['ac']?$highlight:""?>><input name="ac" type="checkbox" value="1" <?=($_GET['ac'])?"checked":"" ?>></td>
  <td valign="middle" class=rowhead>Disabled IP: </td>
  <td<?=$_GET['dip']?$highlight:""?>><input name="dip" type="checkbox" value="1" <?=($_GET['dip'])?"checked":"" ?>></td>
  </tr>
<tr><td colspan="6" align=center><input name="submit" type=submit class=btn></td></tr>
</table>
<br><br>
</form>

<? end_frame(); } ?>
<br>
<? if ($act == "upstats") {

//SHOWS THE STATISTICS OF THE UPLOADERS
$res = mysql_query("SELECT COUNT(*) FROM torrents") or sqlerr(__FILE__, __LINE__);
$n = mysql_fetch_row($res);
$n_tor = $n[0];

$res = mysql_query("SELECT COUNT(*) FROM peers") or sqlerr(__FILE__, __LINE__);
$n = mysql_fetch_row($res);
$n_peers = $n[0];

$uporder = $_GET['uporder'];
$catorder = $_GET["catorder"];

if ($uporder == "lastul")
	$orderby = "last DESC, name";
elseif ($uporder == "torrents")
	$orderby = "n_t DESC, name";
elseif ($uporder == "peers")
	$orderby = "n_p DESC, name";
else
	$orderby = "name";

$query = "SELECT u.id, u.username AS name, MAX(t.added) AS last, COUNT(DISTINCT t.id) AS n_t, COUNT(p.id) as n_p
	FROM users as u LEFT JOIN torrents as t ON u.id = t.owner LEFT JOIN peers as p ON t.id = p.torrent WHERE u.class > 0
	GROUP BY u.id ORDER BY $orderby";

$res = mysql_query($query) or sqlerr(__FILE__, __LINE__);

if (mysql_num_rows($res) == 0)
	stdmsg("Sorry...", "No uploaders.");
else
{
	begin_frame("Uploader Activity", True);
	begin_table();
	print("<tr>\n
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=uploader&amp;catorder=$catorder\" class=colheadlink>Uploader</a></td>\n
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=lastul&amp;catorder=$catorder\" class=colheadlink>Last Upload</a></td>\n
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=torrents&amp;catorder=$catorder\" class=colheadlink>Torrents</a></td>\n

	<td class=colhead>Perc.</td>\n
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=peers&amp;catorder=$catorder\" class=colheadlink>Peers</a></td>\n
	<td class=colhead>Perc.</td>\n
	</tr>\n");
	while ($uper = mysql_fetch_array($res))
	{
		print("<tr><td><a href=userdetails.php?id=".$uper['id']."><b>".$uper['name']."</b></a></td>\n");
		print("<td " . ($uper['last']?(">".$uper['last']." (".get_elapsed_time(sql_timestamp_to_unix_timestamp($uper['last']))." ago)"):"align=center>---") . "</td>\n");
		print("<td align=right>" . $uper['n_t'] . "</td>\n");
		print("<td align=right>" . ($n_tor > 0?number_format(100 * $uper['n_t']/$n_tor,1)."%":"---") . "</td>\n");
		print("<td align=right>" . $uper['n_p']."</td>\n");
		print("<td align=right>" . ($n_peers > 0?number_format(100 * $uper['n_p']/$n_peers,1)."%":"---") . "</td></tr>\n");
	}
	end_table();
	end_frame();
}

if ($n_tor == 0)
	stdmsg("Sorry...", "No categories defined!");
else
{
  if ($catorder == "lastul")
		$orderby = "last DESC, c.name";
	elseif ($catorder == "torrents")
		$orderby = "n_t DESC, c.name";
	elseif ($catorder == "peers")
		$orderby = "n_p DESC, name";
	else
		$orderby = "c.name";

  $res = mysql_query("SELECT c.name, MAX(t.added) AS last, COUNT(DISTINCT t.id) AS n_t, COUNT(p.id) AS n_p
	FROM categories as c LEFT JOIN torrents as t ON t.category = c.id LEFT JOIN peers as p
	ON t.id = p.torrent GROUP BY c.id ORDER BY $orderby") or sqlerr(__FILE__, __LINE__);

	begin_frame("Category Activity", True);
	begin_table();
	print("<tr><td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=$uporder&amp;catorder=category\" class=colheadlink>Category</a></td>
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=$uporder&amp;catorder=lastul\" class=colheadlink>Last Upload</a></td>
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=$uporder&amp;catorder=torrents\" class=colheadlink>Torrents</a></td>
	<td class=colhead>Perc.</td>
	<td class=colhead><a href=\"" . $_SERVER['PHP_SELF'] . "?uporder=$uporder&amp;catorder=peers\" class=colheadlink>Peers</a></td>

	<td class=colhead>Perc.</td></tr>\n");
	while ($cat = mysql_fetch_array($res))
	{
		print("<tr><td class=rowhead>" . $cat['name'] . "</b></a></td>");
		print("<td " . ($cat['last']?(">".$cat['last']." (".get_elapsed_time(sql_timestamp_to_unix_timestamp($cat['last']))." ago)"):"align = center>---") ."</td>");
		print("<td align=right>" . $cat['n_t'] . "</td>");
		print("<td align=right>" . number_format(100 * $cat['n_t']/$n_tor,1) . "%</td>");
		print("<td align=right>" . $cat['n_p'] . "</td>");
		print("<td align=right>" . ($n_peers > 0?number_format(100 * $cat['n_p']/$n_peers,1)."%":"---") . "</td>\n");
	}
	end_table();
	end_frame();
}



end_frame(); }?>

<? if ($act == "last") {
begin_frame("Latest users");

echo '<table width="640"  border="0" align="center" cellpadding="2" cellspacing="0">';
echo "<tr><td class=colhead align=left>User</td><td class=colhead>Ratio</td><td class=colhead>IP</td><td class=colhead>Date Joined</td><td class=colhead>Last Access</td><td class=colhead>Download</td><td class=colhead>Upload</td></tr>";

$result = mysql_query ("SELECT  * FROM users WHERE enabled =  'yes' AND status = 'confirmed' ORDER BY added DESC limit 100");
if ($row = mysql_fetch_array($result)) {
do { 
if ($row["uploaded"] == "0") { $ratio = "inf"; }
elseif ($row["downloaded"] == "0") { $ratio = "inf"; }
else {
$ratio = number_format($row["uploaded"] / $row["downloaded"], 3);

$ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
}
echo "<tr><td><a href=userdetails.php?id=".$row["id"]."><b>".$row["username"]."</b></a></td><td><strong>".$ratio."</strong></td><td>".$row["ip"]."</td><td>".$row["added"]."</td><td>".$row["last_access"]."</td><td>".mksize($row["downloaded"])."</td><td>".mksize($row["uploaded"])."</td></tr>";
		  
		  
} while($row = mysql_fetch_array($result));
} else {print "<tr><td>Sorry, no records were found!</td></tr>";}	  
echo "</table>";
end_frame(); }?>


<? if ($act == "forum") {

// SHOW FORUMS WITH FORUM MANAGMENT TOOLS
begin_frame("Forums");
?>
<script language="JavaScript">
<!--
function confirm_delete(id)
{
   if(confirm('Are you sure you want to delete this forum?'))
   {
      self.location.href='<? $PHP_SELF; ?>?action=del&id='+id;
   }
}
//-->
</script>
<?
echo '<table width="700"  border="0" align="center" cellpadding="2" cellspacing="0">';
echo "<tr><td class=colhead align=left>Name</td><td class=colhead>Topics</td><td class=colhead>Posts</td><td class=colhead>Read</td><td class=colhead>Write</td><td class=colhead>Create topic</td><td class=colhead>Modify</td></tr>";
$result = mysql_query ("SELECT  * FROM forums ORDER BY sort ASC");
if ($row = mysql_fetch_array($result)) {
do { 
//if ($row["uploaded"] == "0" || $row["downloaded"] == "0") { $ratio = "inf"; } else {
//$ratio = $row["uploaded"] / $row["downloaded"];
//$ratio = number_format($ratio, 2);
//}	
echo "<tr><td><a href=forums.php?action=viewforum&forumid=".$row["id"]."><b>".$row["name"]."</b></a><br>".$row["description"]."</td>";
echo "<td>".$row["topiccount"]."</td><td>".$row["postcount"]."</td><td>minimal " . get_user_class_name($row["minclassread"]) . "</td><td>minimal " . get_user_class_name($row["minclasswrite"]) . "</td><td>minimal " . get_user_class_name($row["minclasscreate"]) . "</td><td align=center nowrap><b><a href=\"".$PHP_SELF."?act=editforum&id=".$row["id"]."\">EDIT</a>&nbsp;|&nbsp;<a href=\"javascript:confirm_delete('".$row["id"]."');\"><font color=red>DELETE</font></a></b></td></tr>";
		  
		  
} while($row = mysql_fetch_array($result));
} else {print "<tr><td>Sorry, no records were found!</td></tr>";}	  
echo "</table>";
?>
<br><br>
<form method=post action="<?=$PHP_SELF;?>">
<table width="600"  border="0" cellspacing="0" cellpadding="3" align="center">
<tr align="center">
    <td colspan="2" class=colhead>Make new forum</td>
  </tr>
  <tr>
    <td><b>Forum name</td>
    <td><input name="name" type="text" size="20" maxlength="60"></td>
  </tr>
  <tr>
    <td><b>Forum description  </td>
    <td><input name="desc" type="text" size="30" maxlength="200"></td>
  </tr>
    <tr>
    <td><b>Minimun read permission </td>
    <td>
    <select name=readclass>\n
    <?
	     $maxclass = get_user_class();
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
	</select>
    </td>
  </tr>
  <tr>
    <td><b>Minimun write permission </td>
    <td><select name=writeclass>\n
    <?
	      $maxclass = get_user_class();
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
	</select></td>
  </tr>
  <tr>
    <td><b>Minimun create topic permission </td>
    <td><select name=createclass>\n
    <?
	    $maxclass = get_user_class();
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
	</select></td>
  </tr>
    <tr>
    <td><b>Forum rank </td>
    <td>
    <select name=sort>\n
    <?
$res = mysql_query ("SELECT sort FROM forums");
$nr = mysql_num_rows($res);
	    $maxclass = $nr + 1;
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i>$i \n");
?>
	</select>
    
    
    </td>
  </tr>
  
  <tr align="center">
    <td colspan="2"><input type="hidden" name="action" value="addforum"><input type="submit" name="Submit" value="Make forum"></td>
  </tr>
</table>

<?
end_frame(); }?>

<? if ($act == "editforum") {

//EDIT PAGE FOR THE FORUMS
$id = $_GET["id"];
begin_frame("Edit Forum");
$result = mysql_query ("SELECT * FROM forums where id = '$id'");
if ($row = mysql_fetch_array($result)) {
do { 
?>

<form method=post action="<?=$PHP_SELF;?>">
<table width="600"  border="0" cellspacing="0" cellpadding="3" align="center">
<tr align="center">
    <td colspan="2" class=colhead>edit forum: <?=$row["name"];?></td>
  </tr>
  <tr>
    <td><b>Forum name</td>
    <td><input name="name" type="text" size="20" maxlength="60" value="<?=$row["name"];?>"></td>
  </tr>
  <tr>
    <td><b>Forum description  </td>
    <td><input name="desc" type="text" size="30" maxlength="200" value="<?=$row["description"];?>"></td>
  </tr>
    <tr>
    <td><b>Minimun read permission </td>
    <td>
    <select name=readclass>\n
    <?
	     $maxclass = get_user_class();
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($row["minclassread"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
	</select>
    </td>
  </tr>
  <tr>
    <td><b>Minimun write permission </td>
    <td><select name=writeclass>\n
    <?
	      $maxclass = get_user_class();
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($row["minclasswrite"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
	</select></td>
  </tr>
  <tr>
    <td><b>Minimun create topic permission </td>
    <td><select name=createclass>\n
    <?
	    $maxclass = get_user_class();
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($row["minclasscreate"] == $i ? " selected" : "") . ">$prefix" . get_user_class_name($i) . "\n");
?>
	</select></td>
  </tr>
    <tr>
    <td><b>Forum rank </td>
    <td>
    <select name=sort>\n
    <?
$res = mysql_query ("SELECT sort FROM forums");
$nr = mysql_num_rows($res);
	    $maxclass = $nr + 1;
	  for ($i = 0; $i <= $maxclass; ++$i)
	    print("<option value=$i" . ($row["sort"] == $i ? " selected" : "") . ">$i \n");
?>
	</select>
    
    
    </td>
  </tr>
  
  <tr align="center">
    <td colspan="2"><input type="hidden" name="action" value="editforum"><input type="hidden" name="id" value="<?=$id;?>"><input type="submit" name="Submit" value="Edit forum"></td>
  </tr>
</table>

<?
} while($row = mysql_fetch_array($result));
} else {print "Sorry, no records were found!";}	  
end_frame(); }?>


<? if ($act == "ban") {

// BAN IP PAGE WITH OVERVIEW FROM BANNED IP'S
begin_frame("Ban IP");
?>

<form method=post action="<?=$PHP_SELF;?>">
<table width="450"  border="0" cellspacing="0" cellpadding="3" align="center">
<tr align="center">
    <td colspan="2" class=colhead>Ban IP</td>
  </tr>
  <tr>
    <td><b>IP (range)</td>
    <td><input name="first" type="text" size="15" maxlength="16"> to <input name="last" type="text" size="15" maxlength="16"></td>
  </tr>
  <tr>
    <td><b>Comments  </td>
    <td><input name="comment" type="text" size="30" maxlength="200"></td>
  </tr>
     
  <tr align="center">
    <td colspan="2"><input type="hidden" name="action" value="ban"><input type="submit" name="Submit" value="Ban ip"></td>
  </tr>
</table>
<br><br>
<script language="JavaScript">
<!--
function confirm_delete(id)
{
   if(confirm('Are you sure you want UNBAN this ip (range)?'))
   {
      self.location.href='<? $PHP_SELF; ?>?action=ipdel&id='+id;
   }
}
//-->
</script>
<?
echo '<table width="640"  border="0" align="center" cellpadding="2" cellspacing="0">';
echo "<tr><td class=colhead align=left>IP (range)</td><td class=colhead>added</td><td class=colhead>added by</td><td class=colhead>comments</td><td class=colhead>Modify</td></tr>";

$result = mysql_query ("SELECT  * FROM bans ORDER BY added DESC");
if ($row = mysql_fetch_array($result)) {
do { 
$res = mysql_query ("SELECT username FROM users where id = '".$row["addedby"]."' limit 1");
$rw = mysql_fetch_array($res);


if ($row["last"] == $row["first"]) { $range = long2ip($row["first"]); }
else { $range = long2ip($row["first"])." - ". long2ip($row["last"]); }
echo "<tr><td><b>".$range."</b></td><td>".$row["added"]."</td><td><a href=\"userdetails.php?id=".$row["addedby"]."\"><b>".$rw["username"]."</a></td><td>".$row["comment"]."</td><td><a href=\"javascript:confirm_delete('".$row["id"]."');\"><b><font color=red>DELETE</font></a></b></td></tr>";
		  
		  
} while($row = mysql_fetch_array($result));
} else {print "<tr><td colspan=5 align=center><b>Sorry, no records were found!</td></tr>";}	  
echo "</table>";
end_frame(); } }

if (get_user_class() >= UC_USER) { 

if (!$act) { 
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
// LIST ALL FIRSTLINE SUPPORTERS 
// Search User Database for Firstline Support and display in alphabetical order
$res = mysql_query("SELECT * FROM users WHERE support='yes' AND status='confirmed' ORDER BY username LIMIT 10") or sqlerr();
while ($arr = mysql_fetch_assoc($res))
{
$land = mysql_query("SELECT name,flagpic FROM countries WHERE id=$arr[country]") or sqlerr();
$arr2 = mysql_fetch_assoc($land);
$firstline .= "<tr height=15><td class=embedded><a class=altlink href=userdetails.php?id=".$arr['id'].">".$arr['username']."</a></td>
<td class=embedded> ".("'".$arr['last_access']."'">$dt?"<img src=".$pic_base_url."button_online.gif border=0 alt=\"online\">":"<img src=".$pic_base_url."button_offline.gif border=0 alt=\"offline\">" )."</td>".
"<td class=embedded><a href=sendmessage.php?receiver=".$arr['id'].">"."<img src=".$pic_base_url."button_pm.gif border=0></a></td>".
"<td class=embedded><img src=".$pic_base_url."/flag/$arr2[flagpic] border=0 width=19 height=12></td>".
"<td class=embedded>".$arr['supportfor']."</td></tr>\n";
}


begin_frame("Firstline Support");
?>

<table width=725 cellspacing=0>
<tr>
<td class=embedded colspan=11>General support questions should preferably be directed to these users. Note that they are volunteers, giving away their time and effort to help you. 
Treat them accordingly. (Languages listed are those besides English.)<br><br><br></td></tr>
<!-- Define table column widths -->
<tr>
<td class=embedded width="30"><b>Username</b></td>
<td class=embedded width="5"><b>Active</b></td>
<td class=embedded width="5"><b>Contact</b></td>
<td class=embedded width="85"><b>Language</b></td>
<td class=embedded width="200"><b>Support for:</b></td>
</tr>


<tr>
<tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>

<?=$firstline?>

</tr>
</table>
<? 
end_frame();
}

?>
<? 
end_main_frame();
stdfoot();
}
?>