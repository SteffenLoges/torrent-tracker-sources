<?

require_once("include/bittorrent.php");
hit_start();

dbconn(false);

hit_count();

loggedinorreturn();
parked(); 

stdhead("Upload");

if (get_user_class() < UC_PEASANT)
{
  stdmsg("Sorry...", "Down for maintenance.");
  stdfoot();
  exit;
}

?>
<div align=Center>
<form name=upload enctype="multipart/form-data" action="takeupload.php" method="post">
<input type="hidden" name="MAX_FILE_SIZE" value="<?=$max_torrent_size?>" />
<p>The tracker's announce url is <b><?= $announce_urls[0] ?></b></p>
<p>Please read the <b><a href=ulguide.php>uploading rules and guidelines</a><!-- <font color=red>[Updated 21/9]</font>--></b></p>
<!--<p><b>Only upload torrents you're going to seed!</b> Uploaded torrents won't be visible on the main page until you start seeding them.</p>--><!--<p><b>Download the torrents off the site to start seeding!</b></p>-->
<?
print("<table class=message  cellspacing=0 cellpadding=5>\n");
tr("Torrent file", "<input type=file name=file size=80>\n", 1);
print("<tr><td class=rowhead>");
print("<table align=right><tr><td class=rowhead style='border: 0;'><b>Non-Audio file</b></td></tr>");
print("<tr><td class=rowhead style='border: 0;'><input name=\"filetype\" type=\"radio\" value=\"2\" checked></td></tr>\n");
print("</table></td>");
print("<td align=center>");
print("<table align=center cellpadding=5><tr>");
  print("<td class=embedded>Torrent name&nbsp;</td><td class=embedded><input type=\"text\" name=\"name\" size=\"80\" /><br>(Taken from filename if not specified. <b>Please use descriptive names.</b>)</td>");
print("</tr></table><br>");
print("<table align=center><tr>");
  print("<td class=embedded>&nbsp;NFO file&nbsp;</td><td class=embedded><input type=\"file\" name=\"nfo\" size=60><br>(<b>Optional</b>.)</td>");
print("</tr></table>");
print("</td></tr>\n");
print("<tr><td class=rowhead>");
print("<table align=right><tr><td class=rowhead style='border: 0;'><b>Audio file</b></td></tr>");
print("<tr><td class=rowhead style='border: 0;'><input name=\"filetype\" type=\"radio\" value=\"1\" ></td></tr>\n");
print("</table></td>");
print("<td align=center>");
print("<table align=center cellpadding=5><tr>");
  print("<td class=embedded>Artist&nbsp;</td><td class=embedded><input type=\"text\" size=\"40\" name=\"artist\"></td>");
  print("<td class=embedded>&nbsp;Album&nbsp;</td><td class=embedded><input type=\"text\" size=\"40\" name=\"album\"></td>");
print("</tr></table><br>");
print("<table align=center cellpadding=5><tr>");
  print("<td class=embedded>Year&nbsp;</td><td class=embedded><input type=\"text\" size=\"20\" name=\"year\"></td>");
  print("<td class=embedded>&nbsp;Format&nbsp;</td><td class=embedded><input type=\"text\" size=\"20\" name=\"format\"></td>");
print("<td class=embedded>&nbsp;Bitrate&nbsp;</td><td class=embedded><input type=\"text\" size=\"10\" name=\"bitrate\">&nbsp;kbps</td>");
print("</tr></table><br>");
print("<table align=center><tr>");
  print("<td class=embedded>&nbsp;NFO file&nbsp;</td><td class=embedded><input type=\"file\" name=\"nfo2\" size=60><br></td>");
print("</tr></table>");
print("</td></tr>\n");

print("<tr><td class=rowhead style='padding: 3px'>Description</td><td>");
 textbbcode("upload","descr",($quote?(("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars(unesc($arr["body"]))."[/quote]")):""));
print("</td></tr>\n");

$s = "<select name=\"type\">\n<option value=\"0\">(choose one)</option>\n";

$cats = genrelist();
foreach ($cats as $row)
	$s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";

$s .= "</select>\n";
tr("Type", $s, 1);

?>
<tr><td align="center" colspan="2"><input type="submit" class=btn value="Do it!" /></td></tr>
</table>
</form>
<?

stdfoot();
hit_end();

?>
