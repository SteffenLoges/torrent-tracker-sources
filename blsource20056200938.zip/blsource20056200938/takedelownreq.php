<?
require_once("include/bittorrent.php");
function bark($msg) {
	genbark($msg, "Job failed!");
}
dbconn();
loggedinorreturn();

if (empty($_POST["delreq"])) 
    bark("Don't leave any fields blank."); 

$do="DELETE FROM requests WHERE id IN (" . implode(", ", $_POST[delreq]) . ")"; 
$do2="DELETE FROM addedrequests WHERE requestid IN (" . implode(", ", $_POST[delreq]) . ")";
$res2=mysql_query($do2);
$res=mysql_query($do);

header("Refresh: 0; url=/requests.php");
?>