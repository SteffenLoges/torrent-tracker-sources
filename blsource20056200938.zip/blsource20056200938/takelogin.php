<?

require_once("include/bittorrent.php");

hit_start();

if (!mkglobal("username:password"))
	die();

dbconn();

hit_count();

function bark($text = "Username or password incorrect. If you have an account here please use the recovery system or try again. <a href=recover.php> Retrieve Password!</a>")
{
  stderr("Login failed!", $text);
}

$res = mysql_query("SELECT id, passhash, logintype, secret, enabled FROM users WHERE username = " . sqlesc($username) . " AND status = 'confirmed'");
$row = mysql_fetch_array($res);

if (!$row)
	bark();

if ($row["passhash"] != md5($row["secret"] . $password . $row["secret"]))
	bark();

if ($row["enabled"] == "no")
	bark("This account has been disabled.");

logincookie($row["id"], $row["passhash"]);
if ($row['logintype']=="secure")
  mysql_query("UPDATE users SET loginhash='".md5(getip().$row['passhash'])."' WHERE id=$row[id]");
if (!empty($_POST["returnto"]))
	header("Location: $BASEURL$_POST[returnto]");
else
	header("Location: $BASEURL/my.php");

hit_end();

?>