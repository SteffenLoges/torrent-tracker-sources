<?php

	ob_start("ob_gzhandler");

require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();

$nick = ($CURUSER ? $CURUSER["username"] : ("Guest" . rand(1000, 9999)));

stdhead();
begin_main_frame();
begin_frame("IRC");

?>
<p> Thanks to kaskudoo we will be trying our first IRC channel. Here is how you can connect:

All you need is a IRC client (for example Colloquy - the one i am using) it is free and available here: <a class=altlink href=http://colloquy.info/index.html>http://colloquy.info/index.html</a>
it is in development, but it looks really really nice and i hope its free for the next few month =)
anyways, you might just want to give it a try ..... just:
<li>- download and run the client</li>
<li>- connect to EFnet (EFnet is in the drop down list of servers in Colloquy OR address is i think: irc.efnet.net)</li>
<li>- join the channel Brokenstones (just click on join channel and type Brokenstones)</li>
<li>- We should be there :-)</li>

<?

end_frame();
begin_frame("Direct Connect");

?>
<p>I do have a little experience with this and would like to startup a hub soon but until then here are some hubs: <a href=dchub://theonez.no-ip.com>Axis of Evil</a> & <a href=dchub://mac.myftp.org> GroundZero</a>.</p> 
<p>But before you can connect to the hubs you must have a client which can be download here: <a href=http://www.neo-modus.com/>MeoModus</a> for a more advance client search the web. I will be adding info in faq & links shortly.</p>
<?
end_frame();
end_main_frame();
stdfoot();
?>