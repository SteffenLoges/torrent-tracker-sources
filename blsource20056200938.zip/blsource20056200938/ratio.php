<?php

    ob_start("ob_gzhandler");

  require "include/bittorrent.php";
  dbconn(false);
  loggedinorreturn();

  if (get_user_class() < UC_USER)
    stderr("Error", "Permission denied.");

  function usertable($res, $frame_caption)
  {
      global $CURUSER;
    begin_frame($frame_caption, true);
    begin_table();
?>
<tr>
<td class=colhead>Rank</td>
<td class=colhead align=left>User</td>
<td class=colhead align=right>Ratio</td>
<td class=colhead align=left>Joined</td>

</tr>
<?
    $num = 0;
    while ($a = mysql_fetch_assoc($res))
    {
      ++$num;
      $highlight = $CURUSER["id"] == $a["userid"] ? " bgcolor=#BBAF9B" : "";
      if ($a["downloaded"])
      {
        $ratio = $a["uploaded"] / $a["downloaded"];
        $color = get_ratio_color($ratio);
        $ratio = number_format($ratio, 2);
        if ($color)
          $ratio = "<font color=$color>$ratio</font>";
      }
      else
        $ratio = "Inf.";
      print("<tr$highlight><td align=center>$num</td><td align=left$highlight><a href=userdetails.php?id=" .
              $a["userid"] . "><b>" . $a["username"] . "</b>" .
              "</td><td align=right$highlight>" . $ratio .
              "</td><td align=left>" . gmdate("Y-m-d",strtotime($a["added"])) . " (" .
              get_elapsed_time(sql_timestamp_to_unix_timestamp($a["added"])) . " ago)</td></tr>");
    }
    end_table();
    end_frame();
  }

  stdhead("Top Worst Share Ratio's");
  begin_main_frame();
    $type = 0 + $_GET["type"];
    if (!in_array($type,array(1,2,3,4)))
        $type = 1;
    $limit = 0 + $_GET["lim"];
    $subtype = $_GET["subtype"];

    $pu = get_user_class() >= UC_POWER_USER;

  if (!$pu)
      $limit = 10;

  if ($type == 1)
  {
    $mainquery = "SELECT id as userid, username, added, uploaded, downloaded, uploaded / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS upspeed, downloaded / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS downspeed FROM users WHERE enabled = 'yes'";

      if (!$limit || $limit > 250)
          $limit = 10;

      {
            $order = "uploaded / downloaded ASC, downloaded DESC";
          $extrawhere = " AND downloaded > 103741824";
          $r = mysql_query($mainquery . $extrawhere . " ORDER BY $order " . " LIMIT $limit") or sqlerr();
          usertable($r, "Top $limit Worst Share Ratio's <font class=small>(with minimum 100 MB downloaded)</font>" . ($limit == 10 && $pu ? " <font class=small> - [<a href=ratio.php?type=1&amp;lim=100&amp;subtype=wsh>Top 100</a>] - [<a href=ratio.php?type=1&amp;lim=250&amp;subtype=wsh>Top 250</a>]</font>" : ""));
      }
  }
  end_main_frame();
  print("<p><font class=small><a href=ratio.php>Top 10</a></font>");
  print("<p><font class=small>Started recording account xfer stats on 2004-06-22</font></p>");
  stdfoot();
?> 


