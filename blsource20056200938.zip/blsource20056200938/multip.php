<?
 require "include/bittorrent.php";
 dbconn(false);

 loggedinorreturn();
 stdhead("Multiple IPs");

if (get_user_class() < 4)
{
print("<h1>Staff Only</h1>");
die();
}

$res2 = mysql_query("SELECT count(ip) as count FROM users GROUP BY ip HAVING COUNT(ip)>2 AND sum(downloaded) > 0") or sqlerr(__FILE__, __LINE__);
while ($arr2 = mysql_fetch_assoc($res2))
   {
    $count = $count+1;
   
   }
 
$perpage = 100;

 list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" );

$res = mysql_query("SELECT  sum(uploaded) as uploaded, sum(downloaded) as downloaded, ip, sum(uploaded)/sum(downloaded) as ratio, count(ip) as count FROM users GROUP BY ip HAVING COUNT(ip)>2 AND sum(downloaded) > 0 ORDER BY ratio asc $limit") or sqlerr(__FILE__, __LINE__);
print("<h1>Multiple IPs</h1>\n");

if (mysql_num_rows($res) == 0)
   print("<b><font color=red>Nothing to show</font></b>\n");
 else
 {


echo $pagertop;
   print("<table border=1 cellspacing=0 cellpadding=5>\n");
   print("<tr><td class=colhead align=left>IP</td><td class=colhead align=left>Combined Ratio</td><td class=colhead align=left>Count</td><td class=colhead align=left>Enabled</td><td class=colhead align=left>Disabled</td></tr>\n");
   while ($arr = mysql_fetch_assoc($res))
   {
     if($arr[ip]!="")
 {
$host = @gethostbyaddr($arr[ip]);
if(!(stristr($host, "aol")) && !(stristr($host, "cache"))&& !(stristr($host, "proxy")))
{
 $r = mysql_query("SELECT count(id) FROM users WHERE enabled = 'no' AND ip = '$arr[ip]' UNION SELECT count(id) FROM users WHERE enabled = 'yes' AND ip = '$arr[ip]'") or sqlerr();
$a = mysql_fetch_row($r);
$disabled = number_format(0 + $a[0]);
$a = mysql_fetch_row($r);
$enabled = number_format(0 + $a[0]);
 $nip = ip2long($arr[ip]);
       $auxres = mysql_query("SELECT COUNT(*) FROM bans WHERE $nip >= first AND $nip <= last") or sqlerr(__FILE__, __LINE__);
       $array = mysql_fetch_row($auxres);
      if ($array[0] == 0)
       $ipstr = "<font color=darkgreen><b>Not Banned</b></font>";
     else
       $ipstr = "<a href='/testip.php?ip=" . $arr[ip] . "'><font color='#FF0000'><b>IP Banned</b></font></a>";
   if ($arr["downloaded"] > 0)
   {
     $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 3);
     $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
   }
   else
     if ($arr["uploaded"] > 0)
       $ratio = "Inf.";
     else
       $ratio = "---";

     print("<tr><td><a href=usersearch.php?ip=$arr[ip]>$arr[ip]</a> ($host) - $ipstr</td><td>$ratio<td>$arr[count]</td><td><font color=darkgreen><b>$enabled</b></font></td><td><font color=red><b>$disabled</b></font></td></tr>\n");}
}}
   print("</table>");
 }
 print("<p>Times are in GMT.</p>\n");
echo $pagerbottom;
 stdfoot();
 
?>