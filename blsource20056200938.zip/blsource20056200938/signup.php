<?

require_once("include/bittorrent.php");
include("vImage.php");
$vImage = new vImage();
dbconn();

$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $maxusers)
	stderr("Sorry", "We are a private site now and require an invite to join. Please do not request to be invited on non-invite forums, thanks.");


stdhead("Signup");

?>
<!--
<table width=500 border=1 cellspacing=0 cellpadding=10><tr><td align=left>
<h2 align=center>Proxy check</h2>
<b><font color=red>Important - please read:</font></b> We do not accept users connecting through public proxies. When you
submit the form below we will check whether any commonly used proxy ports on your computer is open. If you have a firewall it may alert of you of port
scanning activity. This is only our proxy-detector in action.
<b>The check takes up to 30 seconds to complete, please be patient.</b> The IP address we will test is <b><?= $HTTP_SERVER_VARS["REMOTE_ADDR"]; ?></b>.
By proceeding with submitting the form below you grant us permission to scan certain ports on this computer.
</td></tr></table>
<p>
-->
Note: You need cookies enabled to sign up or log in.
<p>
<form method="post" action="takesignup.php">
<table border="1" cellspacing=0 cellpadding="10">
<tr><td align="right" class="heading">Desired username:</td><td align=left><input type="text" size="40" name="wantusername" /></td></tr>
<tr><td align="right" class="heading">Pick a password:</td><td align=left><input type="password" size="40" name="wantpassword" /></td></tr>
<tr><td align="right" class="heading">Enter password again:</td><td align=left><input type="password" size="40" name="passagain" /></td></tr>
<tr><td align="right" class="heading">Security Image:</td><td align=left><img src="img.php?size=6"></td></tr>

<tr><td align="right" class="heading">Security Code:</td><td align=left><? $vImage->showCodBox(1); ?> <table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>The security code is case sensitive.

</font></td></tr></table></td></tr>
<tr valign=top><td align="right" class="heading">Email address:</td><td align=left><input type="text" size="40" name="email" />
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>The email address must be valid.
You will receive a confirmation email which you need to respond to. The email address won't be publicly shown anywhere.</td></tr>
</font></td></tr></table>
<? tr("Gender",
"<input type=radio name=gender" . ($CURUSER["gender"] == "Male" ? " checked" : "") . " value=Male>Male
<input type=radio name=gender" .  ($CURUSER["gender"] == "Female" ? " checked" : "") . " value=Female>Female <font color=red>&nbsp;*</font>"
,1);
tr("Age (optional)", "<input type=\"text\" name=\"age\" size=5 value=\"" . htmlspecialchars($CURUSER["age"]) . "\" /> ", 1);
tr("Website (optional)", "<input type=\"text\" name=\"website\" size=40 value=\"" . htmlspecialchars($CURUSER["website"]) . "\" /> ", 1); ?>
</td></tr>
<tr><td align="right" class="heading"></td><td align=left><input type=checkbox name=rulesverify value=yes> I have read the site <a href=/rules.php/ target=_blank font color=red>rules</a> page.<br>
<input type=checkbox name=faqverify value=yes> I agree to read the <a href=/faq.php/ target=_blank font color=red>FAQ</a> before asking questions.<br>
<input type=checkbox name=ageverify value=yes> I am at least 13 years old.</td></tr>
<tr><td colspan="2" align="center"><input type=submit value="Sign up! (PRESS ONLY ONCE)" style='height: 25px'></td></tr>
</table>
</form>
<?

stdfoot();

?>
