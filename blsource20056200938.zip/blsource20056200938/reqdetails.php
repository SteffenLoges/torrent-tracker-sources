<?
require "include/bittorrent.php";

dbconn();

loggedinorreturn();

stdhead("Request Details");
$id = $_GET["id"];
$res = mysql_query("SELECT *,UNIX_TIMESTAMP(added) as utadded FROM requests WHERE id = $id") or sqlerr();
$num = mysql_fetch_array($res);
$timezone = display_date_time($num["utadded"] , $CURUSER[tzoffset] );
$s = $num["request"];

print("<h1>Details Of $s</h1>\n");

print("<table width=\"500\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");
print("<tr><td align=left>Request</td><td width=90% align=left>$num[request]</td></tr>");
if ($num["descr"])
print("<tr><td align=left>Info</td><td width=90% align=left>$num[descr]</td></tr>");
print("<tr><td align=left>Added</td><td width=90% align=left>$timezone</td></tr>");

$cres = mysql_query("SELECT username FROM users WHERE id=$num[userid]");
   if (mysql_num_rows($cres) == 1)
   {
     $carr = mysql_fetch_assoc($cres);
     $username = "$carr[username]";
   }
print("<tr><td align=left>Requested&nbsp;By</td><td width=90% align=left>$username</td></tr>");
print("<tr><td align=left>Vote for this request</td><td width=50% align=left><a href=addrequest.php?id=$id><b>Vote</b></a></tr></tr>");

if ($num["filled"] == no)
{
print("<form method=get action=reqfilled.php>");
print("<tr><td align=left>Filled Request</td><td>Enter the <b>full</b> URL of the torrent i.e. http://wahoo.freestarthost.com/details.php?id= (just copy/paste from another window/tab) or modify the existing URL to have the correct ID number</td></tr>");
print("</table>");
print("<input type=text size=80 name=filledurl value=http://wahooh.freestarthost.com/details.php?id=>\n");
print("<input type=hidden value=$id name=requestid>");
print("<input type=submit value=\"Fill Request\" style='height: 22px'>\n</form>");
print("<p></p><form method=\"get\" action=\"requests.php#add\"><input type=\"submit\" value=\"Add Request\" style='height: 22px' /></form>");
}
if ($num["filled"] == yes)
{
print("</table>");
}
if (get_user_class() >= UC_MODERATOR)
{
print("<form method=post action=takereqedit.php?id=$id>\n");
print("<h1>Edit Request</h1>\n");
print("<table width=\"500\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");
print("<tr><td align=left>Request:  <input type=text size=40 value=$num[request] name=requesttitle>");
print("<tr><td align=left>Info:  <br><textarea name=descr rows=5 cols=90>$num[descr]</textarea>\n");
?>
<?
$res2 = mysql_query("SELECT id, name FROM categories order by name");
$num2 = mysql_num_rows($res2);
$catdropdown2 = "";
for ($i = 0; $i < $num2; ++$i)
   {
 $cats2 = mysql_fetch_assoc($res2);  
     $catdropdown2 .= "<option value=\"" . $cats2["id"] . "\"";
		if ($cats2["id"] == $num["cat"])
			$catdropdown2 .= " selected=\"selected\"";
     $catdropdown2 .= ">" . htmlspecialchars($cats2["name"]) . "</option>\n";
   }

?>
<select name="category">
<?= $catdropdown2 ?>
</select>
<? print("<br>\n");
if ($num[filled] == yes)
$msg = $num[filledurl];
else
$msg = "http://wahooh.freestarthost.com/details.php?id=";
print("<tr><td align=left>Filled by id:  <input type=text size=40 value=$num[filledby] name=filledby>");
print("<tr><td align=left>Torrent url:  <input type=text size=80 name=filledurl value=$msg>\n");
print("<tr><td align=left>Filled: <input type=checkbox name=filled" . ($num[filled]  == "yes" ? " checked" : "") . ">");
print("<tr><td align=center><input type=submit value=Edit Request! style='height: 22px'>\n");
print("</form>\n");
print("</table>\n");
}

stdfoot();
die;

?>