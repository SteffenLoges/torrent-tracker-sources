<?php
ob_start("ob_gzhandler");
require_once("include/bittorrent.php");
hit_start();
dbconn();
loggedinorreturn();

stdhead("Requests Page");

begin_main_frame();

print("<h1>Requests Section</h1>\n");
print("<p><a href=requests.php>Make a request</a>&nbsp;&nbsp;<a href=viewrequests.php?requestorid=$CURUSER[id]>View my requests</a></p>");
print("<p>Sort by <a href=" . $_SERVER[PHP_SELF] . "?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=votes>Votes</a>, <a href=". $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=request>Request Name</a>, or <a href=" . $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=added>Date Added</a></p>");
print("<p><a href=". $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&sort=" . $_GET[sort] . "&filter=true>Hide Filled</a></p>");
$categ = $_GET["category"];
$requestorid = $_GET["requestorid"];
$sort = $_GET["sort"];
$search = $_GET["search"];
$filter = $_GET["filter"];

$search = " AND requests.request like '%$search%' ";


if ($sort == "votes")
$sort = " order by hits desc ";
else if ($sort == "request")
$sort = " order by request ";
else
$sort = " order by added desc ";


if ($filter == "true")
$filter = " AND requests.filledby = 0 ";
else
$filter = "";


if ($requestorid <> NULL)
{
if (($categ <> NULL) && ($categ <> 0))
 $categ = "WHERE requests.cat = " . $categ . " AND requests.userid = " . $requestorid;
else
 $categ = "WHERE requests.userid = " . $requestorid;
}

else if ($categ == 0)
$categ = '';
else
$categ = "WHERE requests.cat = " . $categ;

/*
if ($categ == 0)
$categ = 'WHERE requests.cat > 0 ';
else
$categ = "WHERE requests.cat = " . $categ;
*/


$res = mysql_query("SELECT count(requests.id) FROM requests inner join categories on requests.cat = categories.id inner join users on requests.userid = users.id  $categ $filter $search") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];


$perpage = 25;

 list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" . "category=" . $_GET["category"] . "&sort=" . $_GET["sort"] . "&" );

echo $pagertop;

$res = mysql_query("SELECT users.downloaded, users.uploaded, users.username, requests.filled, requests.filledurl, requests.filledby, requests.id, requests.userid, requests.request, requests.added, UNIX_TIMESTAMP(requests.added) as utadded, requests.hits, categories.name as nam,  categories.id as catid, categories.name as cat, categories.stylesheet as stylesheet FROM requests inner join categories on requests.cat = categories.id inner join users on requests.userid = users.id  $categ $filter $search $sort $limit") or sqlerr();
$num = mysql_num_rows($res);



print("<form method=get action=viewrequests.php>");
?>
<select name="category">
<option value="0">(Show All)</option>
<?

$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
   $catdropdown .= "<option value=\"" . $cat["id"] . "\"";
   $catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

?>
<?= $catdropdown ?>
</select>
<?
print("<input type=submit align=center value=View style='height: 22px'>\n");
print("</form>\n<p></p>");

print("<form method=get action=viewrequests.php>");
print("<b>Search Requests: </b><input type=text size=40 name=search>");
print("<input type=submit align=center value=Search style='height: 22px'>\n");
print("</form><p></p><br />");





print("<form method=post action=takedelreq.php>");
print("<table border=1 width=737 cellspacing=0 cellpadding=5>\n");
print("<tr><td class=colhead align=left>Requests</td><td class=colhead align=center>Category</td><td class=colhead align=center width=125>Added</td><td class=colhead align=center>Added By</td><td class=colhead align=center>Filled?</td><td class=colhead align=center>Filled By</td><td class=colhead align=center width=50>Votes</td>\n");
if (get_user_class() >= UC_MODERATOR )
{
print("<td class=colhead align=center>Del</td>\n");
}
print("</tr>\n");

for ($i = 0; $i < $num; ++$i)
{



 $arr = mysql_fetch_assoc($res);

if ($arr["downloaded"] > 0)
   {
     $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
     $ratio = "<font color=" . get_ratio_color($ratio) . "><b>$ratio</b></font>";
   }
   else if ($arr["uploaded"] > 0)
       $ratio = "Inf.";
   else
       $ratio = "---";

$timezone = display_date_time($arr[utadded] , $CURUSER[tzoffset] );
$res2 = mysql_query("SELECT username from users where id=" . $arr[filledby]);
$arr2 = mysql_fetch_assoc($res2);  
if ($arr2[username])
$filledby = $arr2[username];
else
$filledby = " ";      
$addedby = "<td style='padding: 0px' align=center><a href=userdetails.php?id=$arr[userid]><b>$arr[username] ($ratio)</b></a></td>";
$filled = $arr[filled];
if ($arr[filled] == yes)
$filled = "<a href=$filled><font color=green><b>Yes</b></font></a>";
else
$filled = "<a href=reqdetails.php?id=$arr[id]><font color=red><b>No</b></font></a>";
 print("<tr><td align=left><a href=reqdetails.php?id=$arr[id]><b>$arr[request]</b></a></td>" .
 "<td align=center><img  class=\"" . $arr[stylesheet] . "\" src=/pic/blank2.gif></td><td align=center>$timezone</td>$addedby<td>$filled</td><td><a href=userdetails.php?id=$arr[filledby]><b>$arr2[username]</b></a></td><td align=center><a href=votesview.php?requestid=$arr[id]><b>$arr[hits]</b></a><br><a class=\"sublink\" href=addrequest.php?id=$arr[id]><b>[Add vote]</b></a></td>\n");
if (get_user_class() >= UC_MODERATOR )
{
print("<td><input type=\"checkbox\" name=\"delreq[]\" value=\"" . $arr[id] . "\" /></td>\n");
}
print("</tr>\n");
}




print("</table></table>\n");
if (get_user_class() >= UC_MODERATOR )
{
print("<p><input type=submit value=Delete></p>");
}
print("</form>");

echo $pagerbottom;

stdfoot();

die;

?>