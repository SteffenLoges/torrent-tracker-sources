<?
 require "include/bittorrent.php";

 dbconn(false);

 loggedinorreturn();

 if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
 {
   if (get_user_class() < UC_VIP)
     die;
 
   $file = $_FILES['file'];

   if (!$file || $file["size"] == 0 || $file["name"] == "")
     stderr("Error", "Nothing received! The selected file may have been too large.");

   if (file_exists("$DOXPATH/$file[name]"))
    stderr("Error", "A file with the name <b>$file[name]</b> already exists!");

   $title = trim($HTTP_POST_VARS["title"]);
   if ($title == "")
   {
     $title = substr($file["name"], 0, strrpos($file["name"], "."));
     if (!$title)
       $title = $file["name"];
   }
   
   $r = mysql_query("SELECT id FROM dox WHERE title=" . sqlesc($title)) or sqlesc();
   if (mysql_num_rows($r) > 0)
     stderr("Error", "A file with the title <b>" . htmlspecialchars($title) . "</b> already exists!");

   $url = $HTTP_POST_VARS["url"];
   
if ($url != "")
    if (substr($url, 0, 7) != "http://" && substr($url, 0, 6) != "ftp://")
  stderr("Error", "The URL <b>" . htmlspecialchars($url) . "</b> does not seem to be valid.");

if (!move_uploaded_file($file["tmp_name"], "$DOXPATH/$file[name]"))
 stderr("Error", "Failed to move uploaded file. You should contact an administrator about this error.");

   setcookie("doxurl", $url, 0x7fffffff);
   
   $title = sqlesc($title);
   $filename = sqlesc($file["name"]);
   $added = sqlesc(get_date_time());
   $uppedby = $CURUSER["id"];
   $size = $file["size"];
   $url = sqlesc($url);

   mysql_query("INSERT INTO dox (title, filename, added, uppedby, size, url) VALUES($title, $filename, $added, $uppedby, $size, $url)") or sqlerr();

   header("Location: $BASEURL/dox.php");
die;
 }

 if (get_user_class() >= UC_VIP)
 {
   $delete = $HTTP_GET_VARS["delete"];
   if (is_valid_id($delete))
   {
    $r = mysql_query("SELECT filename,uppedby FROM dox WHERE id=$delete") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($r) == 1)
    {
         $a = mysql_fetch_assoc($r);
      if (get_user_class() >= UC_MODERATOR || $a["uppedby"] == $CURUSER["id"])
      {
        mysql_query("DELETE FROM dox WHERE id=$delete") or sqlerr(__FILE__, __LINE__);
        if (!unlink("$DOXPATH/$a[filename]"))
             stderr("Warning", "Unable to unlink file: <b>$a[filename]</b>. You should contact an administrator about this error.");
      }
    }
   }
 }

 stdhead("Dox");

 print("<h1>Dox</h1>\n");

 $res = mysql_query("SELECT * FROM dox ORDER BY added DESC") or sqlerr();
 if (mysql_num_rows($res) == 0)
   print("<p>Sorry, nothing here pal :(</p>");
 else
 {
   print("<p><table border=1 cellspacing=0 width=750 cellpadding=5>\n");
   print("<tr><td class=colhead align=left>Title</td><td class=colhead>Date</td><td class=colhead>Time</td>" .
     "<td class=colhead>Size</td><td class=colhead>Hits</td><td class=colhead>Upped by</td></tr>\n");

   $mod = get_user_class() >= UC_MODERATOR;

   while ($arr = mysql_fetch_assoc($res))
   {
    $r = mysql_query("SELECT username FROM users WHERE id=$arr[uppedby]") or sqlerr();
    $a = mysql_fetch_assoc($r);
    $title = "<td align=left><a href=getdox.php/$arr[filename]><b>" . htmlspecialchars($arr["title"]) . "</b></a>" .
      ($mod || $arr["uppedby"] == $CURUSER["id"] ? " <font size=1 class=small><a href=?delete=$arr[id]>[Delete]</a></font>" : "") ."</td>\n";
    $added = "<td>" . substr($arr["added"], 0, 10) . "</td><td>" . substr($arr["added"], 10) . "</td>\n";
    $size = "<td>" . mksize($arr['size']) . "</td>\n";
    $hits = "<td>" . number_format($arr['hits']) . "</td>\n";
    $uppedby = "<td><a href=userdetails.php?id=$arr[uppedby]><b>$a[username]</b></a></td>\n";
     print("<tr>$title$added$size$hits$uppedby</tr>\n");
   }
   print("</table></p>\n");
   print("<p>Files are automatically deleted after 14 days</p>\n");
 }

 if (get_user_class() >= UC_UPLOADER)
 {
  $url = $HTTP_COOKIE_VARS["doxurl"];
   $maxfilesize = ini_get("upload_max_filesize");
  begin_main_frame();
  begin_frame("Upload", true);
  print("<form enctype=multipart/form-data method=post action=?>\n");
  print("<table class=main border=1 cellspacing=0 width=700 cellpadding=5>\n");
   print("<tr><td class=rowhead>File</td><td align=left><input type=file name=file size=60><br>(Maximum file size: $maxfilesize.)</td></tr>\n");
   print("<tr><td class=rowhead>Title</td><td align=left><input type=text name=title size=60><br>(Optional, taken from file name if not specified.)</td></tr>\n");

/*
   print("<tr><td class=rowhead>Download URL</td><td align=left><input type=text name=url size=60 value=\"$url\"><br><table width=340 ".
     "class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>(Optional, specifies a primary FTP/HTTP download location. You can substitute ".
     "the file name part with an asterisk (*)</b>, e.g. http://www.URSITE.com/files/*)</td></tr></table></td></tr>\n");
*/
   print("<tr><td colspan=2 align=center><input type=submit value='Upload file' class=btn></td></tr>\n");
   print("</table>\n");
  print("</form>\n");
  end_frame();
  end_main_frame();
 }

stdfoot();
?>