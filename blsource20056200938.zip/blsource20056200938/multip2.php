<?php
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();

if (get_user_class() < UC_MODERATOR)
 stderr("Error", "Permission denied");

stdhead();

$res = mysql_query("SELECT ip1.* FROM users ip1, users ip2 WHERE ip1.ip = ip2.ip AND ip1.id != ip2.id ORDER BY username, ip ASC") or sqlerr();

if (mysql_num_rows($res) == 0)
  stdmsg("Warning","No users were found with matching IP's.");
 else
{
echo "<table border=1 cellspacing=0 cellpadding=3>\n";
   echo "<tr><td class=colhead align=left>ID</td>".
    "<td class=colhead align=left>Username</td>".
       "<td class=colhead align=left>Email</td>".
       "<td class=colhead align=left>Joined</td>".
       "<td class=colhead align=left>Last Access</td>".
       "<td class=colhead align=left>IP</td>".
       "<td class=colhead align=left>Class</td>".
       "<td class=colhead align=left>Ratio</td>".
       "<td class=colhead align=left>Uploaded</td>".
       "<td class=colhead align=left>Downloaded</td></tr>";
       
   while ($user = mysql_fetch_array($res))
 {
 if ($user['added'] == '0000-00-00 00:00:00')
  $user['added'] = '---';
 if ($user['last_access'] == '0000-00-00 00:00:00')
  $user['last_access'] = '---';
 
 if ($user["downloaded"] > 0)
  {
  $ratio = number_format($user["uploaded"] / $user["downloaded"], 2);
  $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
  }
 else
  if ($user["uploaded"] > 0)
  $ratio = "Inf.";
 else
  $ratio = "---";
 
 echo "<tr><td><div align=center>" . $user['id'] . "</div></td>".
 "<td><b><a href='userdetails.php?id=" . $user['id'] . "'>" . $user['username']."</a></b></td>" .
         "<td><div align=center>" . $user['email'] . "</div></td>
         <td><div align=center>" . $user['added'] . "</div></td>
         <td><div align=center>" . $user['last_access'] . "</div></td>
         <td bgcolor=red><div align=center>" . $user['ip'] . "</div></td>
         <td><div align=center>" . $user['class'] . "</div></td>
         <td><div align=center>" . $ratio . "</div></td>
         <td><div align=center>" . mksize($user['uploaded'])."</div></td>
         <td><div align=center>" . mksize($user['downloaded'])."</div></td></tr>";

 }
   echo "</table>";
}

stdfoot();
?>