<?
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();
$id = $_GET["id"];
if (get_user_class() < UC_USER || !is_valid_id($id))
  die;

$r = mysql_query("SELECT name,nfo FROM torrents WHERE id=$id") or sqlerr();
$a = mysql_fetch_assoc($r) or die("Puke");
$nfo = htmlspecialchars($a["nfo"]);
$nfo2 = format_urls($nfo);
stdhead();
?>
<h1>NFO for <a href=details.php?id=$id><?=$a[name] ?></a></h1>
<table border=1 cellspacing=0 cellpadding=5><tr><td>
<pre width=150><font face='MS Linedraw' size=2 style='font-size: 10pt; line-height: 10pt'><?=$nfo2 ?></font></pre>
</td></tr></table>
<?
stdfoot();
?>