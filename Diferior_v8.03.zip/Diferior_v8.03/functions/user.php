<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class user
	{

		# Uses
		# $_SESSION [ 'logged' ], $_SESSION [ 'userinfo' ], $_SESSION [ 'permissions' ], 
		# $_SESSION [ 'lastlogin' ], $_SESSION [ 'user' ], $_SESSION [ 'pass' ],
		# $_SESSION [ 'preferences' ]
		
		# db object
		private $db = null;
		
		# Input validated? (must be validated before registering new user)
		private $is_validated = false;
		
		# Temporary variables to make registration process easier
		private $user, $pass, $email;
		
		
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
			if ( !isset ( $_SESSION [ 'logged' ] ) )
			{
				$_SESSION [ 'logged' ] = false;	
			}
		}
		
		
		# Is logged?
		public function is_logged ()
		{
			if ( $_SESSION [ 'logged' ] === true )
			{
				return true;
			}
			else 
			{
				return false;	
			}
		}
		
		
		# Login
		public function login ( $user = null, $pass = null, &$validated = true )
		{
			if ( $user == null && $pass == null )
			{
				$user = $_SESSION [ 'user' ];	
			}
			
			$qr = "SELECT 
						users.*, users_permissions.*, users_preferences.*
				   FROM users 
				   		LEFT JOIN users_permissions ON (users_permissions.user='". $user ."') 
				   		LEFT JOIN users_preferences ON (users_preferences.user='". $user ."')
				   WHERE users.name='". $user ."' 
				   LIMIT 1";
			$res = $this -> db -> get_row ( $qr );
			
			# User does not exist
			if ( $this -> db -> num_rows () == 0 )
			{
				return false;	
			}
			
			# Restore 'user' value (if no permissions / preferences were found it is nulled)
			$res [ 'name' ] = $user;
			
			# Check pass
			if ( $pass != null )
			{
				$hashed = md5 ( md5 ( $pass ) );
			}
			else 
			{
				$hashed = $_SESSION [ 'pass' ];
			}
			
			if ( $res [ 'pass' ] != $hashed )
			{
				# Reminder pass
				if ( time () < $res [ 'reminder_sent' ] + 86400 )
				{
					if ( $res [ 'reminder_pass' ] == $hashed  )
					{
						# Everything's fine, set reminder pass as main pass
						$this -> update ( array ( 'pass' => $hashed, 'reminder_pass' => null, 'reminder_sent' => null ), $user );
					}
					else 
					{
						# No luck
						return false;	
					}
				}
				else 
				{
					# Reminder pass expired
					return false;
				}
			}
			
			# Email validated?
			if ( $res [ 'email_validate' ] != null )
			{
				$validated = false;
				return false;	
			}
			
			# All is good
			$_SESSION [ 'logged' ] = true;
			$_SESSION [ 'user' ] = $res [ 'name' ];
			$_SESSION [ 'pass' ] = $hashed;
			$_SESSION [ 'userinfo' ] = $res;
			$_SESSION [ 'lastlogin' ] = $res [ 'lastlogin' ];
			$_SESSION [ 'permissions' ] = array ( 
													'view_ip' 			=>	( $res [ 'view_ip' ] != null 			? $res [ 'view_ip' ]	 		: 0 ),
													'make_posts' 		=>	( $res [ 'make_posts' ] != null 		? $res [ 'make_posts' ] 		: 0 ),
													'delete_comments' 	=> 	( $res [ 'delete_comments' ] != null	? $res [ 'delete_comments' ] 	: 0 ),
													'add_downloads' 	=>	( $res [ 'add_downloads' ] != null		? $res [ 'add_downloads' ] 		: 0 ),
													'view_nfo'		 	=>	( $res [ 'view_nfo' ] != null			? $res [ 'view_nfo' ]	 		: VIEW_NFO ),
													'edit_posts'		=>	( $res [ 'edit_posts' ] != null			? $res [ 'edit_posts' ]	 		: 0 ),
													'edit_downloads'	=>	( $res [ 'edit_downloads' ] != null		? $res [ 'edit_downloads' ]		: 0 ),
													'see_anonymous'		=>	( $res [ 'see_anonymous' ] != null		? $res [ 'see_anonymous' ]		: 0 ),
													'approve_downloads'	=>	( $res [ 'approve_downloads' ] != null	? $res [ 'approve_downloads' ]	: 0 ),
													'cheater_list'		=>	( $res [ 'cheater_list' ] != null		? $res [ 'cheater_list' ]		: 0 ),
													'ban_users'			=>	( $res [ 'ban_users' ] != null			? $res [ 'ban_users' ]			: 0 ),
													'edit_users'		=>	( $res [ 'edit_users' ] != null			? $res [ 'edit_users' ]			: 0 ),
													'view_log'			=>	( $res [ 'view_log' ] != null			? $res [ 'view_log' ]			: 0 ),
													'forum_moderator'	=>	( $res [ 'forum_moderator' ] != null	? $res [ 'forum_moderator' ]	: 0 ),
													'admin'				=>	( $res [ 'admin' ] != null				? $res [ 'admin' ]				: 0 ),
												);
			$_SESSION [ 'preferences' ] = array (
													'start_page' 		=> ( $res [ 'start_page' ] != null 			? $res [ 'start_page' ] 		: 0 ),
													'blog_no'			=> ( $res [ 'blog_no' ] != null 			? $res [ 'blog_no' ] 			: BLOG_POSTS ),
													'downloads_no'		=> ( $res [ 'downloads_no' ] != null 		? $res [ 'downloads_no' ] 		: DL_POSTS ),
													'comments_no'		=> ( $res [ 'comments_no' ] != null 		? $res [ 'comments_no' ] 		: COMMENTS_PAGE ),
													'forum_threads_no'	=> ( $res [ 'forum_threads_no' ] != null	? $res [ 'forum_threads_no' ] 	: FORUM_THREADS_PAGE ),
													'forum_posts_no'	=> ( $res [ 'forum_posts_no' ] != null 		? $res [ 'forum_posts_no' ] 	: FORUM_POSTS_PAGE ),
													'private_no'		=> ( $res [ 'private_no' ] != null 			? $res [ 'private_no' ] 		: PM_PAGE ),
													'downloads_type'	=> ( $res [ 'downloads_type' ] != null 		? $res [ 'downloads_type' ] 	: 0 ),
													'comments_dir'		=> ( $res [ 'comments_dir' ] != null 		? $res [ 'comments_dir' ]	 	: 0 ),
													'forum_posts_dir'	=> ( $res [ 'forum_posts_dir' ] != null 	? $res [ 'forum_posts_dir' ] 	: 0 ),
													'language'			=> ( $res [ 'language' ] != null 			? $res [ 'language' ] 			: LANG_DEFAULT ),
													'template'			=> ( $res [ 'template' ] != null 			? $res [ 'template' ] 			: DEFAULT_TEMPLATE ),
												);
			
			# Get private message counts
			if ( FUNC_PM )
			{
				$pms = $this -> db -> get_all ( "SELECT COUNT(*) AS total FROM private WHERE `to`='". $_SESSION [ 'user' ] ."' UNION SELECT COUNT(*) FROM private WHERE `to`='". $_SESSION [ 'user' ] ."' AND unread=1" );
				if ( !isset ( $pms [ 0 ] [ 'total' ] ) ) $pms [ 0 ] [ 'total' ] = 0;
				if ( !isset ( $pms [ 1 ] [ 'total' ] ) ) $pms [ 1 ] [ 'total' ] = 0;
			}
			
			# Update lastlogin, IP and private message counters
			$update_arr = array ( 'lastlogin' => time (), 'ip' => ( STORE_USER_IP ? $_SERVER [ 'REMOTE_ADDR' ] : md5 ( $_SERVER [ 'REMOTE_ADDR' ] ) ) );
			if ( FUNC_PM )
			{
				$update_arr [ 'private_total' ] = $pms [ 0 ] [ 'total' ]; 
				$update_arr [ 'private_new' ] = $pms [ 1 ] [ 'total' ];	
			}
			$this -> update ( $update_arr );
			
			# Kuriam faila, kad antra karta is eiles nenaujintu info
			$this -> refresh_info ( false );
			
			return true;
		}
		
		
		# Validates input data (this method can be modified according to needs, I was too lazy to make a separate config)
		 # Returns array with error messages
		 # Empty array - no errors
		public function validate_data ( $user, $pass1, $pass2, $email1, $email2, $email_only = false, $email_dupe = true, $email_change = false )
		{
			$blacklist = array ( 'admin', 'user', 'moderator', 'anonymous', 'guest', 
								 'administratorius', 'vartotojas', 'moderatorius', 'anonimas', 'svecias' );
			
			$text = & core::get_object ( 'text' );
			$l = & core::get_object ( 'language' );
			
			$err = array ();
			
			# If not only email needs checking
			if ( !$email_only )
			{
				$strl_user = strlen ( $user );
				$strl_pass = strlen ( $pass1 );
			
				if ( $strl_user < 3 || $strl_user > 20 )
					$err [] = $l -> t ( 'user_username_len' );
				
				if ( !$text -> validate ( $user, 'username' ) )
					$err [] = $l -> t ( 'user_username_symbols' );
				
				if ( $pass1 != $pass2 )
					$err [] = $l -> t ( 'user_pass_match' );
				
				if ( $strl_pass < 6 || $strl_pass > 20 )
					$err [] = $l -> t ( 'user_pass_len' );
					
				if ( $user == $pass1 )
					$err [] = $l -> t ( 'user_name_pass_match' );
				
				if ( in_array ( strtolower ( $user ), $blacklist ) )
					$err [] = $l -> t ( 'user_blacklisted' );	
			}
				
			# Email checks
			if ( strtolower ( $email1 ) != strtolower ( $email2 ) )
				$err [] = $l -> t ( 'user_emails_match' );
				
			if ( !$text -> validate ( $email1, 'email' ) || strlen ( $email1 ) > 32 )
				$err [] = $l -> t ( 'user_email_invalid' );
				
			# Username/email already in DB?
			if ( empty ( $err ) && $email_dupe )
			{
				$user = trim ( $user );
				$email1 = trim ( $email1 );
				$res = $this -> user_exists ( $user, $email1 );
				if ( $res )
				{
					$url = core::get_object ( 'url' );
					
					if ( !$email_only )
					{
						if ( strtolower ( $res [ 'name' ] ) == strtolower ( $user ) )
							$err [] = $l -> t ( 'user_occupied' );
					}
						
					if ( strtolower ( $res [ 'email' ] ) == strtolower ( $email1 ) )
					{
						if ( !$email_change )
						{
							$err [] = $l -> t ( 'user_email_exists_reminder', $url -> make ( 'user', 'reminder' ) );
						}
						else 
						{
							$err [] = $l -> t ( 'user_email_exists' );
						}
					}
				}
			}
				
			# All is well
			if ( !$email_only && empty ( $err ) )
			{
				$this -> user = $user;
				$this -> pass = $pass1;
				$this -> email = $email1;
				
				$this -> is_validated = true;
			}
			
			return $err;
		}
		
		
		# Username (or email) already exists in db
		public function user_exists ( $user, $email = null )
		{
			if ( trim ( $user ) == null ) return false;
			
			return $this -> db -> get_row ( "SELECT name, email, private_total FROM users WHERE name='". $user ."'". ( $email != null ? " OR email='". $email ."'" : null ) );
		}
		
		
		# Register
		public function register ( $user = null, $pass = null, $email = null )
		{
			if ( $this -> is_validated )
			{
				if ( $user == null ) $user = & $this -> user;
				if ( $pass == null ) $pass = & $this -> pass;
				if ( $email == null ) $email = & $this -> email;
				
				$validate = ( FUNC_USER_VALIDATION ? md5 ( $email . uniqid () ) : null );
				$data = array ( 'name' => $user, 'pass' => md5 ( md5 ( $pass ) ), 'email' => $email, 
							    'email_validate' => $validate, 'registered' => time (), 'lastlogin' => 0,
							    'torrents_limit' => 2 );
				
				# Register!
				$insertid = $this -> db -> insert_array ( 'users', $data );
				
				# Duplicate username (can't insert)
				if ( $insertid <= 0 )
				{
					return false;	
				}
				
				# Send validation email
				if ( FUNC_USER_VALIDATION ) 
				{	
					$this -> send_validate_email ( $user, $email, $validate );
				}
				
				return true;
			}
			else 
			{
				throw new error ( 'Registration data not validated!' );	
			}
		}

		
		# Send validate (activation) email
		public function send_validate_email ( $user, $email, $hash, $changemail = false )
		{
			$url = core::get_object ( 'url' );
			$l = core::get_object ( 'language' );
			
			$mail_subject = $l -> t ( 'user_validate_email_title', PAGE_NAME );
			
			if ( $changemail == false )
			{
				$act_link = $url -> make ( 'user', 'activate', $hash );
				$mail_body = $l -> t ( 'user_validate_email_body', $user, $_SERVER [ 'REMOTE_ADDR' ], PAGE_NAME, $act_link );
			}
			else 
			{
				$act_link = $url -> make ( 'user', 'profile', 'email', 'validate', $hash );
				$mail_body = $l -> t ( 'user_validate_email_body_change', $user, $_SERVER [ 'REMOTE_ADDR' ], PAGE_NAME, $act_link );
			}
			
			mail ( $email, $mail_subject, $mail_body, 'From: '. MAIL_FROM ."\r\nReply-To: ". ADMIN_EMAIL ."\r\nX-Mailer: ". PAGE_NAME .' mailer'  );
		}
		
		
		# Validate email
		public function validate_email ( $hash )
		{
			if ( !preg_match ( "#^[a-zA-Z0-9]+\$#", $hash ) )
			{
				return false;	
			}
			
			$affected = $this -> db -> update ( "UPDATE users SET email_validate='' WHERE email_validate='". $hash ."' LIMIT 1" );
			if ( $affected > 0 )
			{
				return true;	
			}
			else 
			{
				return false;
			}
		}
		
		
		# Change email
		public function change_email ( $hash )
		{
			if ( !preg_match ( "#^[a-zA-Z0-9]+\$#", $hash ) )
			{
				return false;	
			}
			
			$affected = $this -> db -> update ( "UPDATE users SET email=email_change, email_change='', email_validate_change='' WHERE email_validate_change='". $hash ."' LIMIT 1" );
			if ( $affected > 0 )
			{
				return true;	
			}
			else 
			{
				return false;
			}
		}
		
		
		# Validate captcha (used for user authentication mainly)
		public function validate_captcha ( $captcha )
		{
			$l = & core::get_object ( 'language' );
			
			$err = array ();
			
			if ( !isset ( $_SESSION [ 'captcha' ] ) )
			{
				$err [] = $l -> t ( 'user_captcha_old' );	
			}
			else 
			{
				if ( strtolower ( $_SESSION [ 'captcha' ] ) != strtolower ( $captcha ) )	
				{
					if ( !isset ( $_SESSION [ 'captcha_attempts' ] ) )
					{
						$_SESSION [ 'captcha_attempts' ] = 1;	
					}
					else 
					{
						$_SESSION [ 'captcha_attempts' ]++;	
					}
					
					if ( $_SESSION [ 'captcha_attempts' ] == 5 )
					{
						unset ( $_SESSION [ 'captcha' ] );
						unset ( $_SESSION [ 'captcha_attempts' ] );
						$err [] = $l -> t ( 'user_captcha_retry' );
					}
					else 
					{
						$err [] = $l -> t ( 'user_captcha_wrong' );
					}
				}
				else 
				{
					unset ( $_SESSION [ 'captcha' ] );	
					unset ( $_SESSION [ 'captcha_attempts' ] );
				}
			}	
			
			return $err;
		}
		
		
		# Update user info
		public function update ( $data, $user = null )
		{
			if ( $user == null )
			{
				$user = $_SESSION [ 'user' ];	
			}
			
			$updated = $this -> db -> update_array ( 'users', $data, "name='". $user ."'" );
			if ( $updated > 0 && isset ( $_SESSION [ 'userinfo' ] ) && $user == $_SESSION [ 'user' ] )
			{
				$_SESSION [ 'userinfo' ] = array_merge ( $_SESSION [ 'userinfo' ], $data );
			}
			
			return ( $updated > 0 ? true : false );
		}
		
		
		# Update user preferences
		public function update_prefs ( $data, $user = null )
		{
			if ( $user == null )
			{
				$user = $_SESSION [ 'user' ];	
			}
			
			$updated = $this -> db -> update_array ( 'users_preferences', $data, "user='". $user ."'" );
			if ( $updated > 0 && isset ( $_SESSION [ 'preferences' ] ) )
			{
				$_SESSION [ 'preferences' ] = array_merge ( $_SESSION [ 'preferences' ], $data );
			}
			else
			{
				$diff = array_diff_assoc ( $_SESSION [ 'preferences' ], $data );
				if ( !empty ( $diff ) )
				{
					$data [ 'user' ] = $user;
					$this -> db -> insert_array ( 'users_preferences', $data );
					unset ( $data [ 'user' ] );
					$_SESSION [ 'preferences' ] = array_merge ( $_SESSION [ 'preferences' ], $data );
				}
			}
			return false;	
		}
		
		
		# Send password reminder
		public function pass_reminder ( $email )
		{
			# Get username by email
			$user = $this -> db -> get_one ( "SELECT name FROM users WHERE email='". $email ."'" );
			if ( $this -> db -> num_rows () == 0 ) 
			{
				return false;
			}
			
			$text = & core::get_object ( 'text' );
			$pass = $text -> random ( 10 );
			
			$l = & core::get_object ( 'language' );
			
			$mail_subject = $l -> t ( 'user_pass_reminder_subject', PAGE_NAME );
			$mail_body = $l -> t ( 'user_pass_reminder_body', $user, $_SERVER [ 'REMOTE_ADDR' ], PAGE_NAME, $pass );
			
			$this -> update ( array ( 'reminder_pass' => md5 ( md5 ( $pass ) ), 'reminder_sent' => time () ), $user );
			
			mail ( $email, $mail_subject, $mail_body, 'From: '. MAIL_FROM ."\r\nReply-To: ". ADMIN_EMAIL ."\r\nX-Mailer: ". PAGE_NAME .' mailer'  );
		}
		
		
		# Get user info
		public function get_info ( $user )
		{
			$text = & core::get_object ( 'text' );
			
			$strl_user = strlen ( $user );
			if ( $strl_user < 3 || $strl_user > 20 || !$text -> validate ( $user, 'username' ) )
			{
				return false;
			}

			$res = $this -> db -> get_row ( "SELECT * FROM users WHERE name='". $user ."'" );
			if ( !empty ( $res ) )
			{
				return $res;	
			}		
			else 
			{
				return false;	
			}
		}
		
		
		# Get user status
		public function get_status ( $info )
		{
			$l = & core::get_object ( 'language' );
			
			$status = $info [ 'status' ];
			
			if ( $status == null )
			{
				$messages = $info [ 'blogposts' ] *10 + $info [ 'downloadposts' ] *5 + $info [ 'comments' ] + $info [ 'forumposts' ];
				$days = ( time () - $info [ 'registered' ] ) / 86400;	
				if ( $days > 7 )
				{
					$status = $l -> t ( 'user_status_1' );
					
					if ( $messages >= 300 )
						$status = $l -> t ( 'user_status_2' );
					elseif ( $messages >= 200 )
						$status = $l -> t ( 'user_status_3' );
					elseif ( $messages >= 100 )
						$status = $l -> t ( 'user_status_4' );
					elseif ( $messages >= 75 )
						$status = $l -> t ( 'user_status_5' );
					elseif ( $messages >= 50 )
						$status = $l -> t ( 'user_status_6' );
					elseif ( $messages >= 25 )
						$status = $l -> t ( 'user_status_7' );
					elseif ( $messages >= 15 )
						$status = $l -> t ( 'user_status_8' );
					elseif ( $messages >= 5 )
						$status = $l -> t ( 'user_status_9' );
				}
				else 
				{
					$status = $l -> t ( 'user_status_new' );
				
					if ( $messages >= 100 )
						$status = $l -> t ( 'user_status_flooder' );
				}
			}	
			
			return $status;
		}
		
		
		# Refresh userinfo
		public function refresh_info ( $login = true, $force = false )
		{
			if ( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] == true )	
			{
				$user = & $_SESSION [ 'user' ];
				
				# Refresh timeout decided by file modification time (TMP/userinfo/$user[0]/$user[1]/$user[2]/$user)
				
				$path = TMP .'/userinfo/'. $user [ 0 ] .'/'. $user [ 1 ] .'/'. $user [ 2 ] .'/';
				if ( !file_exists ( $path ) )
				{
					mkdir ( $path, 0777, true );	
				}
				
				$path .= $user;
				if ( $force || !file_exists ( $path ) || ( filemtime ( $path ) + USERINFO_REFRESH ) < time () )
				{
					# Naujinam
					if ( $login )
					{
						$this -> login ();
					}
					
					touch ( $path );
				}	
			}
		}
		
		
		# Validates userinfo data (this method can be modified according to needs, I was too lazy to make a separate config)
		 # Returns array with error messages
		 # Empty array - no errors
		public function validate_userinfo ( $name, $gender, $year, $month, $day, $location, & $avatar, & $page, $skype, $msn, $icq, $yahoo, $gtalk )
		{
			$text = & core::get_object ( 'text' );
			$l = & core::get_object ( 'language' );
			
			$err = array ();
			
			$strl_name = strlen ( $name );
			$strl_location = strlen ( $location );
			$strl_skype = strlen ( $skype );
			$strl_msn = strlen ( $msn );
			$strl_icq = strlen ( $icq );
			$strl_yahoo = strlen ( $yahoo );
			$strl_gtalk = strlen ( $gtalk );
			
			if ( $name != null && ( $strl_name < 2 || $strl_name > 64 || !$text -> validate ( $name, 'literal' ) ) )
				$err [] = $l -> t ( 'user_info_name' );
			
			if ( $gender != null && ( $gender != 1 && $gender != 2 && $gender != 3 ) )
				$err [] = $l -> t ( 'user_info_gender' );
				
			if ( $year != null && ( $year < 1900 || $year > date ( 'Y' ) ) )
				$err [] = $l -> t ( 'user_info_date_year' );
				
			if ( $month != null && ( $month < 1 || $month > 12 ) )
				$err [] = $l -> t ( 'user_info_date_month' );
				
			if ( $day != null && ( $day < 1 || $day > 31 ) )
				$err [] = $l -> t ( 'user_info_date_day' );				
				
			if ( $location != null && ( $strl_location < 3 || $strl_location > 60 || !$text -> validate ( $location, 'literal' ) ) )
				$err [] = $l -> t ( 'user_info_location' );	
				
			if ( $avatar != null )
			{
				if ( !preg_match ( "#^http://#i", $avatar ) ) $avatar = 'http://'. $avatar;	
				$strl_avatar = strlen ( $avatar );
				if ( $strl_avatar < 10 || $strl_avatar > 150 || !$text -> validate ( $avatar, 'imageurl' ) )
					$err [] = $l -> t ( 'user_info_avatar' );
			}
			
			if ( $page != null )
			{
				if ( !preg_match ( "#^\w+://#i", $page ) ) $page = 'http://'. $page;	
				$strl_page = strlen ( $page );
				if ( $strl_page < 10 || $strl_page > 60 || !$text -> validate ( $page, 'url' ) )
					$err [] = $l -> t ( 'user_info_page' );
			}
			
			if ( $skype != null && ( $strl_skype < 3 || $strl_skype > 60 || !$text -> validate ( $skype, 'username' ) ) )
				$err [] = $l -> t ( 'user_info_skype' );
			
			if ( $msn != null && ( $strl_msn < 3 || $strl_msn > 60 || !$text -> validate ( $msn, 'email' ) ) )
				$err [] = $l -> t ( 'user_info_msn' );	
				
			if ( $icq != null && ( $strl_icq < 6 || $strl_icq > 15 || !is_numeric ( $icq ) ) )
				$err [] = $l -> t ( 'user_info_icq' );	
				
			if ( $yahoo != null && ( $strl_yahoo < 3 || $strl_yahoo > 60 || !$text -> validate ( $yahoo, 'email' ) ) )
				$err [] = $l -> t ( 'user_info_yahoo' );
				
			if ( $gtalk != null && ( $strl_gtalk < 3 || $strl_gtalk > 60 || !$text -> validate ( $gtalk, 'email' ) ) )
				$err [] = $l -> t ( 'user_info_gtalk' );		
			
			return $err;
		}
		
		
		# Gets entries from permissions table
		public function get_permissions ()
		{
			$res = $this -> db -> get_all ( "SELECT * FROM users_permissions" );	
			return $res;
		}
		
	}

?>