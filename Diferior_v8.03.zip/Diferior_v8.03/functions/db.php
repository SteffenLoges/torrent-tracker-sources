<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


# Check if included via index.php
if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


class db
{
	
	/*
		This class currently only supports MySQL.
		Automatically enables UTF-8 support for query results. Comment it out if not required.
	*/
	
	private $db = null;
	private $cache = array ();
	private $res = null;
	
	private $query_count = 0;
	private $query_time = 0;
	
	private $prefix = 'dif_';
	
	public function __construct ()
	{
	}
	
	
	public function __destruct ()
	{
		# Disconnect
		if ( $this -> db != null )
			$this -> disconnect ();
	}
	
	
	public function connect ( $force = false, $host = null, $user = null, $pass = null, $database = null, $return = false )
	{
		# Already connected
		if ( $this -> db != null && !$force ) 
			return false;

		if ( $host == null ) $host = DB_HOST;
		if ( $user == null ) $user = DB_USER;
		if ( $pass == null ) $pass = DB_PASS;

		if ( defined ( 'DB_PREFIX' ) )
		{
			$this -> prefix = DB_PREFIX;	
		}
		
		error::toggle_silent ( true );
		$this -> db = mysql_connect ( $host, $user, $pass );
		error::toggle_silent ( false );
		if ( $this -> db === false )
		{
			if ( $return == false )
			{
				throw new error ( 'Error occured while trying to connect to MySQL server.' );	
			}
			else 
			{
				return false;	
			}
		}
		
		if ( $database == null ) $database = DB_NAME;
		$res = mysql_select_db ( $database );
		if ( $res === false )
		{
			if ( $return == false )
			{
				throw new error ( 'Error occured while trying to connect to MySQL server.' );	
			}
			else 
			{
				return false;	
			}
		}
		
		$this -> query ( "SET NAMES 'utf8'" );
		
		return true;
	}
	
	
	public function disconnect ()
	{
		mysql_close ( $this -> db );
	}
	
	
	public function get_db ()
	{
		return $this -> db;
	}
	
	
	private function is_error ( $res = null, $qr = null )
	{
		$mysql_error = mysql_error ( $this -> db );
		
		if ( $mysql_error == null )
		{
			return $res;
		}
		else
		{ 
			throw new error ( 'MySQL Error ('. mysql_errno ( $this -> db ) .'): '. $mysql_error );//. ( $qr != null ? '<br/><br/>'. $qr : null ) );
		}
	}
	
	
	public function query ( $qr, $cache = false )
	{
		$this -> connect ();
		
		if ( $cache && isset ( $this -> cache [ $qr ] ) )
		{
			return $this -> cache [ $qr ];
		}
		
		if ( GENERATION_TIME )
		{
			$qr_start = microtime ();
			$qr_start = array_sum ( explode ( ' ', $qr_start ) );	
		}
		
		$qr = $this -> rewrite_query ( $qr );
		
		$res = mysql_query ( $qr, $this -> db );
		
		/*
			$fl = fopen ( '/tmp/sqlog', 'a' );
			fputs ( $fl, $qr ."\n" );
			fclose ( $fl );
		*/
		
	 	$this -> res = $this -> is_error ( $res, $qr );
	 	
	 	if ( GENERATION_TIME )
		{
			$qr_end = microtime ();
			$qr_end = array_sum ( explode ( ' ', $qr_end ) );
			$qr_diff = $qr_end - $qr_start;
			$this -> query_time += $qr_diff;
			$this -> query_count++;	
		}
	 	
	 	if ( $cache )
	 	{
		  	$this -> cache [ $qr ] = $this -> res;
	 	}
			  	
		return $this -> res;
	}
	
	
	public function rewrite_query ( $qr )
	{
		# Currently used for adding table prefixes
		
		$tables = 'blog_categories|blog_comments|blog_posts|blog_queue|counters|dl_categories|'.
				  'dl_comments|dl_downloads|dl_subcategories|forum_boards|forum_categories|'.
				  'forum_posts|forum_threads|hits_out|log|online|private|sessions|users|users_permissions|'.
				  'users_preferences|xbt_announce_log|xbt_cheat|xbt_config|xbt_deny_from_hosts|'.
				  'xbt_files_users|xbt_scrape_log|xbt_snatched';
		
		if ( $qr [ strlen ( $qr ) -1 ] != "'" ) 
		{
			$addq = true;
			$qr .= "'";
		}
		
		# Do not use preg_match_all, for some reason it refuses to work with long queries (~30kb+)
		//if ( preg_match_all ( "#.*?[^\\\\]?'#s", $qr, $tmp_chunks ) )
		if ( preg_match ( "#.*?[^\\\\]?'#s", $qr ) )
		{
			$tmp_chunks = $this -> quote_split ( $qr );
		
			//throw new error ($tmp_chunks);	
			$chunks = array ();
			foreach ( $tmp_chunks as $v )
			{
				//$lower = strlen ( $v ) -1;
				//$chunks [] = ( isset ( $v [ $lower ] ) && $v [ $lower ] == "'" ? substr ( $v, 0, -1 ) : $v );
				$chunks [] = $v;
			}
			unset ( $tmp_chunks );
			
			# Loop through every second chunk
			for ( $i = 0, $max = count ( $chunks ); $i < $max; $i+=2 )
			{
				$chunks [ $i ] = preg_replace ( '#(`|=|\(|,|\s+)('. $tables .')(`|,|\.|\s+|\b)#', '\1'. $this -> prefix .'\2\3', $chunks [ $i ] );
			}
			
			$qr = implode ( "'", $chunks ) . ( !isset ( $addq ) ? "'" : null );
		}
		else 
		{
			 $qr = preg_replace ( '#('. $tables .'[\.\s+])#', $this -> prefix .'\1', $qr );
		}
		
		return $qr;
	}
	
	
	private function quote_split ( $txt )
	{ 
		$res = array ();
		$offset = null;
		$count = substr_count ( $txt, "'" );
		$arr_pos = 0;
		for ( $i = 0; $i < $count; $i++ )
		{
			$pos = strpos ( $txt, "'", $offset );
			$chunk = substr ( $txt, 0, $pos );
			if ( !isset ( $res [ $arr_pos ] ) ) $res [ $arr_pos ] = null;
			
			if ( $pos == 0 || $txt [ $pos -1 ] != '\\' )
			{
				$res [ $arr_pos ] .= $chunk;
				$arr_pos++;
			}
			elseif ( $txt [ $pos -1 ] == '\\' )
			{
				$res [ $arr_pos ] .= $chunk . "'";
			}
			$txt = substr ( $txt, $pos+1 );	
		}
		
		if ( $txt != null )
		{
			$res [] = $txt;	
		}
		
		return $res;
	}
	
	
	public function set_prefix ( $pfx )
	{
		$this -> prefix = $pfx;
	}
	
	
	public function fetch ( $res = null )
  	{
     	if ( $res == null ) 
     	{
     		$res = $this -> res;
     	}
     	
     	$fid = mysql_fetch_array ( $res );
     	
     	return $fid;
  	}
  
  	
 	public function fetch_assoc ( $res = null )
  	{
  	   	if ( $res == null ) 
    	{
     		$res = $this -> res;
     	}
     	
  	   	$fid = mysql_fetch_assoc ( $res );

  	   	return $fid;
  	}  
  
  	
 	public function num_rows ( $res = null )
  	{
  	   	if ( $res == null ) 
    	{
     		$res = $this -> res;
     	}
     	
  	   	$nr = mysql_num_rows ( $res );
  	   	
  	   	return $nr;
  	}
  
  	
 	public function insert_id ()
 	{ 
    	return mysql_insert_id ( $this -> db );
	}
  
	
 	public function affected_rows ()
  	{
  		return mysql_affected_rows ( $this -> db );
  	}  
	
	
	public function get_one ( $qr, $cache = false )
	{
		if ( !preg_match ( "#LIMIT 1\$#i", $qr ) ) 
		{
			$qr .= ' LIMIT 1';
		}
		
		$query = $this -> query ( $qr, $cache );
		$fetch = $this -> fetch ( $query );
		
		return ( isset ( $fetch [ 0 ] ) ? $fetch [ 0 ] : null );
	}
	
	
	public function get_row ( $qr, $cache = false )
	{
		if ( !preg_match ( "#LIMIT 1\$#i", $qr ) ) 
		{
			$qr .= ' LIMIT 1';
		}
		
		$query = $this -> query ( $qr, $cache );
		$fetch = $this -> fetch_assoc ( $query );

		return $fetch;
	}
	
	
	public function get_all ( $qr, $cache = false )
	{
		$query = $this -> query ( $qr, $cache );
		
		$ret = array ();
		while ( $fetch = $this -> fetch_assoc ( $query ) )
		{
			$ret[] = $fetch;
		}
		
		return $ret;
	}
	
	
	public function insert ( $qr )
	{
		$this -> query ( $qr );
		return $this -> insert_id ();
	}

	
	public function insert_array ( $table, $data )
	{
		$query = 'INSERT INTO '.$table.' SET ';
		
		$count = count ( $data );
		
		foreach ( $data as $k => $v )
		{
			$query .= '`'. $k .'`=\''.$v.'\', ';
		}
		
		$query = substr ( $query, 0, strlen ( $query )-2 ) .' ';
		
		$this -> query ( $query );
		return $this -> insert_id ();
	}
	
	
	public function update ( $qr )
	{
		$this -> query ( $qr );
		return $this -> affected_rows ();
	}
	
	
	public function update_array ( $table, $data, $where )
	{
		$query = 'UPDATE '.$table.' SET ';
		
		foreach ( $data as $k => $v )
		{
			$query .= '`'. $k .'`=\''.$v.'\', ';
		}
		
		$query = substr ( $query, 0, strlen ( $query )-2 ) .' ';
		
		$query .= 'WHERE '.$where;

		$this -> query ( $query );
		return $this -> affected_rows ();
	}
	
	
	public function delete ( $qr )
	{
		$this -> query ( $qr );
		return $this -> affected_rows ();
	}
	
	
	public function escape ( $txt, $force = false, $trim = true, $quotesonly = false )
	{
		if ( $trim )
		{
			$txt = trim ( $txt );
		}
		
		# Not needed anymore, since script strips slashes from GPC arrays if they are present
		//if ( !$force && get_magic_quotes_gpc() )
		//{
		//	return $txt;	
		//}
		
		if ( $quotesonly )
		{
			return strtr ( $txt, array ( '\'' => '\\\'', "\"" => "\\\"" ) );	
		}
		
		$this -> connect ();
		
		return mysql_real_escape_string ( $txt, $this -> db );
	}

	
	# Returns number of executed queries and their total duration
	public function get_debug_info ()
	{
		return array ( $this -> query_count, $this -> query_time );
	}
	
}

	
?>