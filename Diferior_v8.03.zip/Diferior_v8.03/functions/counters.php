<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );

	
	class counters
	{
		
		private $db;
		
		
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
		}
		
		
		# Simple visits counter
		public function simple ( $cid = 'title', $register = true, $return = true )
		{
			$date = date ( 'md' );
			
			$res = $this -> db -> get_row ( "SELECT day_visits, day_date, total FROM counters WHERE cid='". $cid ."'" );
			
			if ( $this -> db -> num_rows () > 0 )
			{
				if ( $register )
				{
					if ( $res [ 'day_date' ] == $date ) $res [ 'day_visits' ]++; else $res [ 'day_visits' ] = 1;
					$res [ 'total' ]++;
					$this -> db -> update_array ( 'counters', 
									array ( 'day_visits' => $res [ 'day_visits' ], 'day_date' => $date, 'total' => $res [ 'total' ] ), 
									"cid='". $cid ."'" );
				}
				return ( $return ? array ( 'today' => $res [ 'day_visits' ], 'total' => $res [ 'total' ] ) : true );
			}
			else 
			{
				# Counter does not exist
				$this -> db -> insert_array ( 'counters', array ( 'cid' => $cid, 'day_visits' => 1, 'day_date' => $date, 'total' => 1 ) );	
				return ( $return ? array ( 'today' => 1, 'total' => 1 ) : true );
			}
		}
		
		
		# Online
		public function online ( $cid = 'title', $register = true, $return = true, $online_tm = 300 )
		{
			# Prune check every ... sec
			$prune_tm = 120;
			
			if ( $register )
			{
				# Prune time check by file modification time (TMP/online/$cid)
				$path = TMP .'/online/'. $cid; 
				if ( !file_exists ( $path ) || ( filemtime ( $path ) + $prune_tm ) < time () )
				{
					# Prune
					$expired = time () - $online_tm;
					$this -> db -> query ( "DELETE FROM online WHERE cid='". $cid ."' AND atime<". $expired );
					touch ( $path );
				}
				
				# Update / insert entry
				$uid = md5 ( $_SERVER [ 'REMOTE_ADDR' ] . ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ) );
				$rows = $this -> db -> update ( "UPDATE online SET atime='". time () ."'".
							( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] ? ", user='". $_SESSION [ 'user' ] ."'" : null )
							." WHERE cid='". $cid ."' AND uid='". $uid ."'" );
				if ( $rows == 0 )
				{
					$this -> db -> query ( "INSERT INTO online SET cid='". $cid ."', uid='". $uid ."', atime='". time () ."'". 
						( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] ? ", user='". $_SESSION [ 'user' ] ."'" : null ) );
				}
			} 
			
			# Online number
			if ( $return )
			{
				$res = $this -> db -> get_one ( "SELECT COUNT(DISTINCT uid) FROM online WHERE cid='". $cid ."'" );
				return $res;
			}
			else
			{
				return true;	
			}
		}
		
		
		# Online list
		public function online_list ( $cid = 'title' )
		{
			$res = $this -> db -> get_all ( "SELECT DISTINCT user, atime FROM online WHERE cid='". $cid ."' ORDER BY atime DESC" );
			
			return $res;
		}
			
	}

?>