<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class log
	{

		# Objects
		private $db;
		
		
		# Constructor
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
		}
		
		
		# Write to log
		public function write ( $user, $action, $url, $title, $comments = null )
		{
			if ( !LOG ) return;
			
			if ( $user == null )
			{
				$user = $_SESSION [ 'user' ];	
			}
			
			# Convert to save a couple of bytes
			switch ( $action )
			{
				default:		$action = ( is_numeric ( $action ) ? $action : 0 ); break;
				case 'approve':	$action = 1; break;
				case 'edit':	$action = 2; break;
				case 'delete':	$action = 3; break;
			}
			
			$user = $this -> db -> escape ( $user );
			$url = $this -> db -> escape ( $url );
			$title = $this -> db -> escape ( $title );
			$comments = $this -> db -> escape ( $comments );
			
			$this -> db -> insert_array ( 'log', array ( 'tstamp' => time (), 'user' => $user, 'action' => $action, 'url' => $url, 'title' => $title, 'comments' => $comments ) );
		}
		
		
		# Get log portion
		public function get ( $page )
		{
			# How many entries to retrieve
			$from = $page * LOG_PAGE - LOG_PAGE;
			
			$qr = "SELECT tstamp, user, action, url, title, comments FROM log ORDER BY tstamp DESC LIMIT ". $from .", ". LOG_PAGE;
			$res = $this -> db -> get_all ( $qr );
			
			return $res;
		}
	}

?>