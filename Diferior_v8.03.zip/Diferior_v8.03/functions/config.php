<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	# This class is responsible for updating conf.php file
	
	class config
	{
		
		# Path to config file
		private $file;
		
		# Buffer
		private $buffer;
		
		
		public function __construct ()
		{
			
		}
		
		
		# Load config file
		public function load_file ( $file = null )
		{
			if ( $file == null )
			{
				$file = DIR .'/conf.php';
			}
			
			if ( !file_exists ( $file ) || !is_readable ( $file ) || !is_writable ( $file ) )
			{
				throw new error ( 'Could not open config file for modification. Please chmod \'conf.php\' to 0777 and try again.' );
			}
			
			$this -> file = $file;	
			$this -> buffer = file_get_contents ( $file );
		}
		
		
		# Save edited config file
		public function save_buffer ()
		{
			$res = file_put_contents ( $this -> file, $this -> buffer );
			if ( $res !== false ) return true; else return false;
		}
		
		
		# Update config option value in buffer
		public function buf_option ( $option, $value )
		{
			$option = preg_quote ( $option );
			
			if ( preg_match ( "#((\s*define\s*\(\s*['\"]". $option ."['\"]\s*,).+?(\);\s*))#s", $this -> buffer, $m ) )
			{
				if ( !is_bool ( $value ) )
				{
					if ( is_numeric ( $value ) )
					{
						$val = ' '. $value .' ';
					}
					else 
					{
						$val = " '". str_replace ( "'", "\'", $value ) ."' ";
					}
				}
				else 
				{
					$val = ' '. ( $value ? 'true' : 'false' ) .' ';	
				}
				$repl = $m [ 2 ] . $val . $m [ 3 ];
				$this -> buffer = str_replace ( $m [ 1 ], $repl, $this -> buffer );
			}
			else 
			{
				throw new error ( 'Config option \''. $option .'\' not found.' );	
			}
		}
		
		
		# Update single option and save
		public function update_single ( $option, $value )
		{
			$this -> buf_option ( $option, $value );
			return $this -> save_buffer ();
		}
		
		
		# Update multiple options passed via associative array and save
		public function update_array ( $arr )
		{
			foreach ( $arr as $k => $v )
			{
				$this -> buf_option ( $k, $v );	
			}
			
			return $this -> save_buffer ();
		}
		
	}
	
?>