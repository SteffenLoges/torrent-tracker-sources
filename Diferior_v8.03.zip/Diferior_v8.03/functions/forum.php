<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class forum
	{
		
		private $db, $cache, $text, $user = null;
		

		function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
			$this -> cache = & core::get_object ( 'cache' );
			$this -> text = & core::get_object ( 'text' );
			$this -> user = & core::get_object ( 'user' );
		}
		
		
		# Get forum boards list
		public function get_boards ( $emptycats = false, $newposts = true )
		{
			$qr = "SELECT cat.clid, cat.title AS cat, cat.id AS cid,
						  boards.id, boards.flid, boards.title, boards.description, boards.threads, boards.posts, 
						  boards.last_thread, boards.last_tlid, boards.last_user, boards.last_tstamp
				   FROM forum_boards AS boards
				   		LEFT JOIN forum_categories AS cat ON ( boards.cat = cat.id )
				   ORDER BY cat.position, boards.position";
			
			$res = $this -> db -> get_all ( $qr );
			
			$cat_ids = array ();
			
			foreach ( $res as $k => $v )
			{
				if ( $newposts )
				{
					if ( $v [ 'last_tstamp' ] >= time () - THREAD_TIMEOUT && ( !isset ( $_COOKIE [ 'forum_'. $v [ 'id' ] ] ) || $_COOKIE [ 'forum_'. $v [ 'id' ] ] < $v [ 'last_tstamp' ] ) )
					{
						$res [ $k ] [ 'newposts' ] = true;		
					}	
					else 
					{
						$res [ $k ] [ 'newposts' ] = false;
					}
				}
				
				if ( $emptycats )
				{
					$cat_ids [] = $v [ 'cid' ];
				}
			}
			
			if ( $emptycats )
			{
				$where_id = "id!='". implode ( "' AND id!='", $cat_ids ) ."'";
				$qr = 'SELECT clid, title AS cat, id AS cid FROM forum_categories WHERE '. $where_id .' ORDER BY position';
				$res2 = $this -> db -> get_all ( $qr );
				$res = array_merge ( $res, $res2 );
			}
			
			return $res;
		}
		
		
		# Get forum id from clid and flid (this *lid stuff is fun!)
		public function get_forum_id ( $clid, $flid, $extra=null )
		{
			$clid = $this -> db -> escape ( $clid );
			$flid = $this -> db -> escape ( $flid );
			
			$qr = "SELECT forum_boards.id ". $extra ."
				   FROM forum_boards 
				   		LEFT JOIN forum_categories ON ( forum_boards.cat = forum_categories.id )
				   WHERE forum_categories.clid='". $clid ."' AND forum_boards.flid='". $flid ."'";
			
			$res = $this -> db -> get_row ( $qr );
			
			return $res;
		}
		
		
		# Get forum threads
		public function get_threads ( $forum, $page = null, & $page_count = null )
		{
			# Number of threads to retrieve
			//if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'forum_threads_no' ] == 0 )
				{
					$page_count = FORUM_THREADS_PAGE;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'forum_threads_no' ];
				}
				
				$from = $page * $page_count - $page_count;
			}
			
			$qr = "SELECT id, tlid, title, description, pinned, closed, posts, last_user, last_tstamp 
				   FROM forum_threads 
				   WHERE forum='". $forum ."'
				   ORDER BY pinned DESC, last_tstamp DESC
				   LIMIT ". $from .", ". $page_count;
			
			$res = $this -> db -> get_all ( $qr );
			
			foreach ( $res as $k => $v )
			{
				if ( $v [ 'last_tstamp' ] >= time () - THREAD_TIMEOUT && ( !isset ( $_COOKIE [ 'thread_'. $v [ 'id' ] ] ) || $_COOKIE [ 'thread_'. $v [ 'id' ] ] < $v [ 'last_tstamp' ] ) )
				{
					$res [ $k ] [ 'newposts' ] = true;		
				}	
				elseif ( $v [ 'last_tstamp' ] < time () - THREAD_TIMEOUT )
				{
					setcookie ( 'thread_'. $v [ 'id' ], null, time () - 3600, '/', SESS_COOKIE_DOMAIN );
					$res [ $k ] [ 'newposts' ] = false;
				}
				else 
				{
					$res [ $k ] [ 'newposts' ] = false;
				}
			}
			
			return $res;
		}
		
		
		# Get forum thread count
		public function get_thread_count ( $forum )
		{
			$qr = "SELECT threads FROM forum_boards WHERE id='". $forum ."'";
			
			$res = $this -> db -> get_one ( $qr );
			
			return $res;	
		}
		
		
		# Get thread id from clid, flid and tlid
		public function get_thread_id ( $clid, $flid, $tlid, $extra=null )
		{
			$clid = $this -> db -> escape ( $clid );
			$flid = $this -> db -> escape ( $flid );
			
			$qr = "SELECT forum_threads.id ". $extra ."
				   FROM forum_threads
				   		LEFT JOIN forum_boards ON ( forum_threads.forum = forum_boards.id )
				   		LEFT JOIN forum_categories ON ( forum_boards.cat = forum_categories.id )
				   WHERE forum_categories.clid='". $clid ."' AND forum_boards.flid='". $flid ."' AND forum_threads.tlid='". $tlid ."'";
			
			$res = $this -> db -> get_row ( $qr );
			
			return $res;
		}		
		
		
		# Get posts in thread
		public function get_posts ( $thread, $page = null, & $page_count = null )
		{
			# Number of posts to retrieve
			//if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'forum_posts_no' ] == 0 )
				{
					$page_count = FORUM_THREADS_PAGE;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'forum_posts_no' ];
				}
				
				$from = $page * $page_count - $page_count;
			}
			
			$qr = "SELECT forum_posts.id, forum_posts.author, forum_posts.content, forum_posts.tstamp, forum_posts.edit_tstamp,
						  users.pr_avatar, users.downloaded, users.uploaded, users.status, users.blogposts, users.downloadposts, 
						  users.comments, users.forumposts, users.banned, users.warned, users.registered
				   FROM forum_posts
				   		  LEFT JOIN users ON (forum_posts.author = users.name)
				   WHERE forum_posts.thread='". $thread ."'
				   ORDER BY forum_posts.tstamp ". ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'forum_posts_dir' ] == 0 ? null : 'DESC' ) ."
				   LIMIT ". $from .", ". $page_count;
			
			$res = $this -> db -> get_all ( $qr );
			
			return $res;
		}
		
		
		# Get single post body and author
		public function get_post ( $post_id )
		{
			$qr = "SELECT forum_posts.author, forum_posts.content, forum_threads.tlid, forum_boards.flid, forum_categories.clid
				   FROM forum_posts
				   		LEFT JOIN forum_threads ON ( forum_posts.thread = forum_threads.id )
				   		LEFT JOIN forum_boards ON ( forum_threads.forum = forum_boards.id )
				   		LEFT JOIN forum_categories ON ( forum_boards.cat = forum_categories.id )
				   WHERE forum_posts.id='". $post_id ."'";
			
			$res = $this -> db -> get_row ( $qr );
			
			return $res;
		}
		
		
		# Publish a new thread
		public function new_thread ( $fid, $name, $description, $text )
		{
			# Forum id okay?
			if ( !is_numeric ( $fid ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			$name = $this -> db -> escape ( $name );
			$description = $this -> db -> escape ( $description );
			$text = $this -> db -> escape ( substr (  $text, 0, POST_LIMIT_LEN ) );
			
			# Forum exists?
			$qr = "SELECT forum_boards.flid, forum_categories.clid,
						  forum_boards.threads, forum_boards.posts
				   FROM forum_boards 
				   		LEFT JOIN forum_categories ON ( forum_boards.cat = forum_categories.id )
				   WHERE forum_boards.id='". $fid ."'";
			
			$info = $this -> db -> get_row ( $qr );
			
			if ( !$info )
			{
				error::line(__LINE__);
				return false;
			}
			
			$tlid = $this -> text -> make_lid ( $name );
				
			# Tlid available?
			$this -> check_tlid ( $tlid, $fid );
			
			# Posting time
			$tstamp = time ();
			
			$qr = "INSERT INTO forum_threads SET
				   forum='". $fid ."', tlid='". $tlid ."', author='". $_SESSION [ 'user' ] ."', 
				   title='". $name ."', description='". $description ."', posts='1', last_user='". $_SESSION [ 'user' ] ."', last_tstamp='". $tstamp ."'";
			$res = $this -> db -> insert ( $qr );
			
			if ( $res )
			{
				$qr = "INSERT INTO forum_posts SET
					   thread='". $res ."', author='". $_SESSION [ 'user' ] ."', content='". $text ."', tstamp='". time () ."', post_no='1'";
				$res2 = $this -> db -> insert ( $qr );
				
				if ( $res2 )
				{
					# Update userinfo
					$dp = $_SESSION [ 'userinfo' ] [ 'forumposts' ] +1;
					$this -> user -> update ( array ( 'forumposts' => $dp, 'last_thread' => $tstamp, 'last_post' => $tstamp ) );
					
					# Update forum info
					$info [ 'threads' ]++;
					$info [ 'posts' ]++;
					$info [ 'tlid' ] = $tlid;
					$data = array (
						'threads' => $info [ 'threads' ],
						'posts' => $info [ 'posts' ],
						'last_thread' => $name,
						'last_tlid' => $tlid,
						'last_user' => $_SESSION [ 'user' ],
						'last_tstamp' => $tstamp,
					);
					$this -> db -> update_array ( 'forum_boards', $data, "id='". $fid ."'" );
					
					return $info;
				}
				else 
				{
					$this -> db -> delete ( "DELETE FROM forum_threads WHERE id='". $res ."'" );
					error::line(__LINE__);
					return false;
				}
			}
			else 
			{
				error::line(__LINE__);
				return false;
			}
		}
		
		
		# Checks if tlid is available, if not, looks for available
		public function check_tlid ( &$tlid, $forum )
		{
			$res = $this -> db -> get_all ( "SELECT tlid FROM forum_threads WHERE tlid LIKE '". $tlid ."%' AND forum='". $forum ."'");
			if ( !empty ( $res ) )
			{
				$i = 2;
				while ( $this -> search_plid_arr ( $tlid .'-'. $i, $res ) === true )
				{
					$i++;
				}
				$tlid = $tlid .'-'. $i;
			}
			else 
			{
				return true;	
			}
		}

		
		# Plid in array?
		public function search_plid_arr ( $plid, $arr, $type = 'thread' )
		{
			switch ( $type )
			{
				default: $key = 'tlid'; break;
				case 'category': $key = 'clid'; break;
				case 'board': $key = 'flid'; break;
			}
			
			foreach ( $arr as $v )
			{
				if ( $v [ $key ] == $plid )
				{
					return true;	
				}	
			}
			error::line(__LINE__);
			return false;	
		}			

		
		# Post reply
		public function post_reply ( $tid, $text, & $closed = false )
		{
			# Thread id okay?
			if ( !is_numeric ( $tid ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			$text = $this -> db -> escape ( substr (  $text, 0, POST_LIMIT_LEN ) );
			
			# Thread exists?
			$qr = "SELECT forum_boards.flid, forum_categories.clid,
						  forum_boards.posts,
						  forum_threads.posts AS tposts, forum_threads.forum, forum_threads.tlid, forum_threads.title,
						  forum_threads.closed
				   FROM forum_threads
					 	LEFT JOIN forum_boards ON ( forum_threads.forum = forum_boards.id )
					 	LEFT JOIN forum_categories ON ( forum_boards.cat = forum_categories.id )
				   WHERE forum_threads.id='". $tid ."'";

			$info = $this -> db -> get_row ( $qr );
			
			if ( !$info )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Thread not closed?
			if ( $info [ 'closed' ] == 1 && ( !isset ( $_SESSION [ 'permissions' ] ) || $_SESSION [ 'permissions' ] [ 'forum_moderator' ] != 1 ) )
			{
				# Can`t post
				$closed = true;
				error::line(__LINE__);
				return false;
			}
			
			# Posting time
			$tstamp = time ();
			
			$post_no = $info [ 'tposts' ] +1;
			
			$qr = "INSERT INTO forum_posts SET
				   thread='". $tid ."', author='". $_SESSION [ 'user' ] ."', content='". $text ."', tstamp='". $tstamp ."', post_no='". $post_no ."'";
			$res = $this -> db -> insert ( $qr );
			
			if ( $res )
			{
				# Update userinfo
				$dp = $_SESSION [ 'userinfo' ] [ 'forumposts' ] +1;
				$this -> user -> update ( array ( 'forumposts' => $dp, 'last_post' => $tstamp ) );
					
				# Update forum info
				$info [ 'posts' ]++;
				$data = array (
					'posts' => $info [ 'posts' ],
					'last_thread' => $this -> db -> escape ( $info [ 'title' ] ),
					'last_tlid' => $info [ 'tlid' ],
					'last_user' => $_SESSION [ 'user' ],
					'last_tstamp' => $tstamp,
				);
				$this -> db -> update_array ( 'forum_boards', $data, "id='". $info [ 'forum' ] ."'" );
				
				# Update thread info
				$info [ 'tposts' ]++;
				$data = array (
					'posts' => $info [ 'tposts' ],
					'last_user' => $_SESSION [ 'user' ],
					'last_tstamp' => $tstamp,
				);
				$this -> db -> update_array ( 'forum_threads', $data, "id='". $tid ."'" );
				
				return $info;
			}
			else 
			{
				error::line(__LINE__);
				return false;
			}
		}

		
		# Edit post
		public function edit_post ( $id, $text )
		{
			$text = $this -> db -> escape ( substr (  $text, 0, POST_LIMIT_LEN ) );
			
			if ( trim ( $text ) == null )
			{
				return false;	
			}
			
			# Edit timestamp
			$tstamp = time ();
			
			$qr = "UPDATE forum_posts SET
				  	content='". $text ."', edit_tstamp='". $tstamp ."'
				  WHERE id='". $id ."'";
			$res = $this -> db -> update ( $qr );
			
			if ( $res )
			{
				return true;
			}
			else 
			{
				error::line(__LINE__);
				return false;
			}
		}
		
		
		# Remove thread posts
		public function delete_replies ( $ids, $thread )
		{
			# Validation stuff
			if ( !is_numeric ( $thread ) )
			{
				error::line(__LINE__);
				return 0;
			}
			
			if ( empty ( $ids ) )
			{
				error::line(__LINE__);
				return 0;	
			}
			
			$qr = "SELECT forum FROM forum_threads WHERE id='". $thread ."'";
			$forum = $this -> db -> get_one ( $qr );
			if ( !$forum )
			{
				error::line(__LINE__);
				return 0;	
			}
			
			# Build WHERE part of SQL query
			$where = "id='";
			foreach ( $ids as $v )
			{
				if ( !is_numeric ( $v ) )
				{
					error::line(__LINE__);
					return 0;	
				}	
				else 
				{
					$where .= $v ."' OR id='";
				}
			}
			$where = substr ( $where, 0, -9 );
			$where .= "'";
			
			$qr = 'DELETE FROM forum_posts WHERE '. $where;

			$affected = $this -> db -> delete ( $qr );
			
			if ( $affected == 0 )
			{
				error::line(__LINE__);
				return 0;	
			}
			
			# Update numbers
			$this -> db -> update ( "UPDATE forum_boards, forum_threads 
									SET forum_boards.posts=forum_boards.posts-". $affected .", forum_threads.posts=forum_threads.posts-". $affected ." 
									WHERE forum_boards.id='". $forum ."' AND forum_threads.id='". $thread ."'" );
			
			return $affected;			
		}
		
		
		# Lock / unlock thread
		public function lock_thread ( $tid, $status = 1 )
		{
			if ( !is_numeric ( $tid ) )
			{
				error::line(__LINE__);
				return 0;
			}
			
			$qr = "UPDATE forum_threads SET closed='". $status ."' WHERE id='". $tid ."'";
			$affected = $this -> db -> update ( $qr );
			return $affected;
		}
		
		
		# Pin / unpin thread
		public function pin_thread ( $tid, $status = 1 )
		{
			if ( !is_numeric ( $tid ) )
			{
				error::line(__LINE__);
				return 0;
			}
			
			$qr = "UPDATE forum_threads SET pinned='". $status ."' WHERE id='". $tid ."'";
			$affected = $this -> db -> update ( $qr );
			return $affected;
		}
		
		
		# Remove thread
		public function delete_thread ( $tid )
		{
			# Tid okay?
			if ( !is_numeric ( $tid ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Gets info
			$qr = "SELECT forum_threads.tlid, forum_boards.last_tlid, forum_boards.id
				   FROM forum_threads
				   		LEFT JOIN forum_boards ON (forum_threads.forum=forum_boards.id)
				   WHERE forum_threads.id='". $tid ."'";
			$info = $this -> db -> get_row ( $qr );
			
			if ( !$info )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Remove thread
			$qr = "DELETE FROM forum_threads WHERE id='". $tid ."'";
			$affected = $this -> db -> delete ( $qr );
			
			if ( $affected == 0 )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Remove thread replies
			$qr = "DELETE FROM forum_posts WHERE thread='". $tid ."'";
			$affected = $this -> db -> delete ( $qr );
			
			# If last post thread data is equal to removed thread, null the last post info
			if ( $info [ 'tlid' ] == $info [ 'last_tlid' ] )
			{
				$qr = "UPDATE forum_boards SET last_thread='', last_tlid='', last_user='', last_tstamp=0 WHERE id='". $info [ 'id' ] ."'";
				$this -> db -> update ( $qr );	
			}
			
			# Update board numbers
			$qr = "UPDATE forum_boards SET threads=threads-1, posts=posts-". $affected ." WHERE id='". $info [ 'id' ] ."'";
			$this -> db -> update ( $qr );
			
			return true;
		}
		
		
		# Checks if *lid is available, if occupied looks for unoccupied by appending a number
		public function check_plid ( &$plid, $cat, $board = false )
		{
			if ( $board )
			{
				$res = $this -> db -> get_all ( "SELECT flid FROM forum_boards WHERE flid LIKE '". $plid ."%' AND cat='". $cat ."'" );
			}
			else 
			{
				$res = $this -> db -> get_all ( "SELECT clid FROM forum_categories WHERE clid LIKE '". $plid ."%'" );
			}
				
			if ( !empty ( $res ) )
			{
				$i = 2;
				while ( $this -> search_plid_arr ( $plid .'-'. $i, $res, ( $board ? 'board' : 'category' ) ) === true )
				{
					$i++;
				}
				$plid = $plid .'-'. $i;
			}
			else 
			{
				return true;	
			}
		}
		
		
		# Delete categories, boards, threads and replies
		public function del_cats ( $cats )
		{
			$where_cat = "cat='". implode ( "' OR cat='", $cats ) ."'";
			$where_id = "id='". implode ( "' OR id='", $cats ) ."'";

			$board_ids = array ();
			$thread_ids = array ();
			$boards = $this -> db -> get_all ( 'SELECT id FROM forum_boards WHERE '. $where_cat );
			
			if ( !empty ( $boards ) )
			{
				foreach ( $boards as $v )
				{
					$board_ids [] = $v [ 'id' ];
				}
				
				$where_forum = "forum='". implode ( "' OR forum='", $board_ids ) ."'";
				$threads = $this -> db -> get_all ( 'SELECT id FROM forum_threads WHERE '. $where_forum );
				
				if ( !empty ( $threads ) )
				{
					foreach ( $threads as $v2 )
					{
						$thread_ids [] = $v2 [ 'id' ];
					}
					
					# Remove replies
					$where_thread = "thread='". implode ( "' OR thread='", $thread_ids ) ."'";
					$this -> db -> delete ( 'DELETE FROM forum_posts WHERE '. $where_thread );
					# Remove threads
					$where_thread_id = "id='". implode ( "' OR id='", $thread_ids ) ."'";
					$this -> db -> delete ( 'DELETE FROM forum_threads WHERE '. $where_thread_id );
				}
			}
			
			# Remove boards
			$this -> db -> delete ( 'DELETE FROM forum_boards WHERE '. $where_cat );
			# Remove categories
			$this -> db -> delete ( 'DELETE FROM forum_categories WHERE '. $where_id );
			
			return true;
		}
		
		
		# Delete boards, threads and replies
		public function del_boards ( $sub )
		{
			$where_id = "id='". implode ( "' OR id='", $sub ) ."'";
			$where_forum = "forum='". implode ( "' OR forum='", $sub ) ."'";

			# Get threads
			$threads = $this -> db -> get_all ( 'SELECT id FROM forum_threads WHERE '. $where_forum );
			
			if ( !empty ( $threads ) )
			{
				foreach ( $threads as $v )
				{
					$thread_ids [] = $v [ 'id' ];
				}
				
				# Remove replies
				$where_thread = "thread='". implode ( "' OR thread='", $thread_ids ) ."'";
				$this -> db -> delete ( 'DELETE FROM forum_posts WHERE '. $where_thread );
				# Remove threads
				$where_thread_id = "id='". implode ( "' OR id='", $thread_ids ) ."'";
				$this -> db -> delete ( 'DELETE FROM forum_threads WHERE '. $where_thread_id );
			}
			
			# Remove boards
			$this -> db -> delete ( 'DELETE FROM forum_boards WHERE '. $where_id );
			
			return true;
		}
		
		
		# Update forum categories
		public function update_cats ( $cats )
		{
			$where_id = "id='". implode ( "' OR id='", array_keys ( $cats ) ) ."'";
			$res = $this -> db -> get_all ( 'SELECT id, clid, title FROM forum_categories WHERE '. $where_id );
			foreach ( $res as $v )
			{
				$cats [ $v [ 'id' ] ] [ 'lid' ] = $v [ 'clid' ];	
				$cats [ $v [ 'id' ] ] [ 'old_name' ] = $v [ 'title' ];	
			}		
			
			foreach ( $cats as $id => $v )
			{
				if ( trim ( $v [ 'name' ] ) != null )
				{
					if ( $v [ 'name' ] != $v [ 'old_name' ] ) 
					{
						$lid = $this -> text -> make_lid ( $v [ 'name' ] );
						$this -> check_plid ( $lid, null, false );
					}
					else 
					{
						$lid = $v [ 'lid' ];	
					}
					$name = $this -> db -> escape ( $v [ 'name' ] );
					$position = $v [ 'pos' ];
					
					# Do it!
					$this -> db -> update ( "UPDATE forum_categories SET clid='". $lid ."', title='". $name ."', position='". $position ."' WHERE id='". $id ."'" );	
				}
			}
		}
		
		
		# Update boards
		public function update_boards ( $subcats )
		{
			$where_id = "id='". implode ( "' OR id='", array_keys ( $subcats ) ) ."'";
			$res = $this -> db -> get_all ( 'SELECT id, flid, title, cat FROM forum_boards WHERE '. $where_id );
			foreach ( $res as $v )
			{
				$subcats [ $v [ 'id' ] ] [ 'lid' ] = $v [ 'flid' ];	
				$subcats [ $v [ 'id' ] ] [ 'old_name' ] = $v [ 'title' ];	
				$subcats [ $v [ 'id' ] ] [ 'cat' ] = $v [ 'cat' ];	
			}		
			
			foreach ( $subcats as $id => $v )
			{
				if ( trim ( $v [ 'name' ] ) != null && isset ( $v [ 'old_name' ] ) )
				{
					if ( $v [ 'name' ] != $v [ 'old_name' ] ) 
					{
						$lid = $this -> text -> make_lid ( $v [ 'name' ] );
						$this -> check_plid ( $lid, $v [ 'cat' ], true );
					}
					else 
					{
						$lid = $v [ 'lid' ];	
					}
					$name = $this -> db -> escape ( $v [ 'name' ] );
					$descr = $this -> db -> escape ( $v [ 'descr' ] );
					$position = $v [ 'pos' ];
					
					# Do it!
					$this -> db -> update ( "UPDATE forum_boards SET flid='". $lid ."', title='". $name ."', description='". $descr ."', position='". $position ."' WHERE id='". $id ."'" );	
				}
			}
		}
		
		
		# Create new category at the botom of categories list
		public function create_cat ( $name )
		{
			$lid = $this -> text -> make_lid ( $name );
			$this -> check_plid ( $lid, null, false );
			$name = $this -> db -> escape ( $name );
			# Could'n find a way to do this with only one query :(
			$pos = $this -> db -> get_one ( 'SELECT MAX(position) FROM forum_categories' );
			if ( $pos == false ) $pos = 1; else $pos++;
			$this -> db -> insert ( "INSERT INTO forum_categories SET clid='". $lid ."', title='". $name ."', position=". $pos );
			
			return true;
		}	
		
		
		# Create new board
		public function create_board ( $cat, $name, $descr )
		{
			$cat_lid = $this -> db -> get_one ( 'SELECT clid FROM forum_categories WHERE id='. $cat );
			
			if ( $cat_lid == false ) return false;
			
			$lid = $this -> text -> make_lid ( $name );
			$this -> check_plid ( $lid, $cat, true );
			$name = $this -> db -> escape ( $name );
			$descr = $this -> db -> escape ( $descr );
			# Could'n find a way to do this with only one query :(
			$pos = $this -> db -> get_one ( 'SELECT MAX(position) FROM forum_boards WHERE cat='. $cat );
			if ( $pos == false ) $pos = 1; else $pos++;
			$this -> db -> insert ( "INSERT INTO forum_boards SET cat='". $cat ."', flid='". $lid ."', title='". $name ."', description='". $descr ."', position=". $pos );
			
			return true;
		}	
		
	}

?>