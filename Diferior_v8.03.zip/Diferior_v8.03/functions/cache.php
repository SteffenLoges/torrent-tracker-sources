<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


/*
	Requires cache_lite from PEAR (http://pear.php.net/package/Cache_Lite)
*/

	class cache
	{
		
		private $cache_dir;
		private $cache_id;
		
		private $force;
		
		
		# Load cache_lite class and set required variables
		public function __construct ()
		{
			if ( CACHE || CACHE_POSTS || CACHE_SEARCH || CACHE_TITLE || CACHE_RSS || CACHE_TAGS )
			{
				require_once ( 'Cache/Lite.php' );
				$this -> cache_dir = CACHE_DIR .'/';
			}
		}
		
		
		# Set variables and create 'cache' object
		public function init ( $cache_id, $lifetime = 60, $force = false )
		{
			$this -> force = $force;
			
			if ( CACHE === false && $this -> force == false ) return true;
			
			if ( $cache_id != null ) 
			{
				$this -> cache_id = $cache_id;
			}
			else 
			{
				if ( !isset ( $this -> cache_id ) )
				{
					throw new error ( 'Unspecified cache_id' );	
				}	
			}
			
			$this -> load_cache ( $lifetime );
			
			return $this -> cache;	
		}
		
		
		# Create 'cache' object
		public function load_cache ( $lifetime = 0 )
		{
			$options = array (
    				 		 	'cacheDir' => $this -> cache_dir,
    							'lifeTime' => $lifetime
							 );			
			
			$this -> cache = new Cache_Lite ( $options );	
		}
		
		
		# Change 'cache' lifetime
		public function change_lifetime ( $lifetime, &$cache = null )
		{
			if ( $cache == null )
			{
				if ( isset ( $this -> cache ) )
				{
					$cache = & $this -> cache;	
				}	
				else 
				{
					throw new error ( 'Tried to change lifetime of unitialized cache object' );	
				}
			}
			
			$cache -> setLifeTime ( $lifetime );	
		}
		
		
		# Retrieves cached content, false if expired
		public function get ( $cache_id = null )
		{
			if ( CACHE === false && $this -> force == false ) return false;
			
			if ( $cache_id == null )
			{
				$cache_id = $this -> cache_id;	
			}
			
			return $this -> cache -> get ( $cache_id );
		}
		
		
		# Saves content to cache
		public function save ( $content )
		{
			if ( CACHE === false && $this -> force == false ) return true;
			
			return $this -> cache -> save ( $content );
		}
		
		
		# Removes cache
		public function remove ( $id )
		{
			if ( CACHE === false && $this -> force == false ) return true;
			
			if ( !isset ( $this -> cache ) )
			{
				$this -> load_cache ();
			}

			return $this -> cache -> remove ( $id );	
		}
		
	}
?>