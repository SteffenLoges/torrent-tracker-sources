<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Handles cron-related tasks.

	class cron
	{

		# Cron-lock file. If it is present and it's last modification time is no longer than 10 minutes, simulated cron is running fine.
		private $f_lock;
		
		# Cron-check file. Decision whether to perform cron-checks is made depending on it's last modification time.
		private $f_check;
		
		# If file is present, simulated cron will immediately halt
		private $f_kill;
		
		public function __construct ()
		{
			$this -> f_lock =  TMP .'/cron-lock';
			$this -> f_check =  TMP .'/cron-check';
			$this -> f_kill =  TMP .'/cron-kill';
		}
		
		
		# Check whether to perform cron uptime checks
		public function check ()
		{
			if ( !file_exists ( $this -> f_check ) || ( filemtime ( $this -> f_check ) + CRON_CHECK_TIMEOUT ) < time () )
			{
				# Perform checks
			
				if ( !SIMULATE_CRON )
				{
					# Simulated cron off, make sure it is not running. Not much more to do.
					touch ( $this -> f_kill );
				}
				else 
				{
					# Make sure simulated cron can be run
					if ( file_exists ( $this -> f_kill ) )
					{
						unlink ( $this -> f_kill );	
					}
					
					$this -> check_if_up ();
				}	
				
				# Update last access time
				touch ( $this -> f_check );
			}
		}
		
		
		# Check if simulated cron is up. If not - run it.
		private function check_if_up ()
		{
			# Doesn't exist or older than 10 min (600 sec)
			if ( !file_exists ( $this -> f_lock ) || ( time () - filemtime ( $this -> f_lock ) ) > 600 )
			{
				$this -> spawn_cron ();	
			}
		}
		
		
		# Starts simulated cron script via local socket.
		private function spawn_cron ()
		{
			# Generate URL
			$url = & core::get_object ( 'url' );
			$def_add_sid = $url -> add_sid;
			$def_sid = $url -> sid;
			$url -> add_sid = true;
			$url -> sid = 'nosid';
			$full_path = $url -> make ( 'cron', 'start' );
			$url -> add_sid = $def_add_sid;
			$url -> sid = $def_sid;
			
			# Get a list of functions disabled in php configuration
			$disabled_functions = explode ( ',', ini_get ( 'disable_functions' ) );
			
			# fsockopen() is ok
			if ( !in_array ( 'fsockopen', $disabled_functions ) )
			{
				# The cool way
				
				# Max 5 sec. Don't make user wait too long in case there is some kind of problem.
				$errno = null;
				$errstr = null;
				$sock = fsockopen ( $_SERVER [ 'SERVER_ADDR' ], $_SERVER [ 'SERVER_PORT' ], $errno, $errstr, 3 );
				
        		if ( $sock )
        		{
					stream_set_timeout ( $sock, 2 );
					
					if ( !preg_match ( "#^\w+://". preg_quote ( $_SERVER [ 'HTTP_HOST' ] ) ."(.*)\$#i", $full_path, $m ) )
					{
						throw new error ( "Can't spawn cron process. Please contact site staff." );	
					}
					$path = $m [ 1 ];
					
        		    fwrite ( $sock, "GET ". $path ." HTTP/1.0\r\nHost: ". $_SERVER [ 'HTTP_HOST' ] ."\r\n\r\n" );
        		        
        		    fclose ( $sock );
        		}
			}	
			else 
			{
				# The simple way :/
				
				ini_set ( 'default_socket_timeout', 5 ); 
				file_get_contents ( $full_path, null, null, null, 1 );
			}
		}
		
		
		# Runs cron process
		public function start ()
		{
			# Only respond if spawned locally and not yet running
			if ( !$this -> check_spawn () ) die ();
			
			# Keep running in the background
			ignore_user_abort ();
			set_time_limit ( 0 );
			
			$run = 1;
			
			while ( 1 )
			{
				# No kill request?
				if ( file_exists ( $this -> f_kill ) )
				{
					if ( file_exists ( $this -> f_lock ) )
					{
						unlink ( $this -> f_lock );
					}
					die ();
				}
				
				# Update modification time
				touch ( $this -> f_lock );
				
				# Execute every 5 min
				$this -> task_cleanup ( true );
				
				if ( $run == 6 )
				{
					# Execute every 30 min
					$this -> task_warn ( true );
					$this -> task_scrape ( true );
					$run = 1;	
				}
				else 
				{
					$run++;
				}
				
				# Sleep for 5 mins
				sleep ( 300 );	
			}
		}
		
		
		# Check if spawned by server
		private function check_spawn ()
		{
			if ( $_SERVER [ 'REMOTE_ADDR' ] == '127.0.0.1' || $_SERVER [ 'REMOTE_ADDR' ] == $_SERVER [ 'SERVER_ADDR' ] )
			{
				if ( !file_exists ( $this -> f_lock ) )
				{
					return true;
				}
				else 
				{
					die ( 'Cron already running.' );	
				}
			}
			else 
			{
				die ( 'No remote spawning.' );	
			}
		}
		
		
		# Perform cleanup tasks (5min cron)
		public function task_cleanup ( $silent = false )
		{
			$db = & core::get_object ( 'db' );
			
			# Clean old peers
			$res = $db -> delete ( 'DELETE FROM xbt_files_users WHERE active=0 OR mtime+2700<NOW()' );
			if ( !$silent && $res > 0 ) echo 'Deleted '. $res ." old peers.\n";
			
			# Clean not activated user accounts
			$timeout = time () - 86400;
			$res = $db -> delete ( "DELETE FROM users WHERE email_validate!='' AND registered<". $timeout );
			if ( !$silent && $res > 0 ) echo 'Deleted '. $res ." not activated user accounts.\n";
			
			# Clean supposedly deleted (flagged for removal) torrent downloads
			$timeout = time () - 1800;
			$res = $db -> delete ( "DELETE FROM dl_downloads WHERE flags=1 AND updated<". $timeout );
			if ( !$silent && $res > 0 ) echo 'Deleted '. $res ." flagged torrent downloads.\n";
			
			# Refresh forums stats (todo)
			/*$res = $this -> db -> get_all ( "SELECT id FROM forum_boards" );
			foreach ( $res as $v )
			{
				//$info = $db -> get_row ( "SELECT COUNT(DISTINCT forum_threads.id AS threads, COUNT(DISTINCT forum_posts.id) AS posts FROM forum_threads, forum_posts WHERE forum_threads.forum=" );	
			}*/
		}
		
		
		# Issue low ratio warnings, etc (30min cron)
		public function task_warn ( $silent = false )
		{
			if ( TRACKER_ANONYMOUS )
			{
				# Public tracker is ratio-free, no need to scan anything
				return;	
			}
			
			$db = & core::get_object ( 'db' );
			
			$res = $db -> query ( 'SELECT uid, name, warned, warn_time FROM users 
									WHERE downloaded>0 AND uploaded/downloaded<='. RATIO_WARNING .' AND can_leech=\'1\' AND (registered+'. AUTOWARN_IMMUNE_TIME .')<'. time () );
	
			# Loop through selected users
			while ( $row = $db -> fetch_assoc ( $res ) )
			{
				# If user is not warned, warn
				if ( $row [ 'warned' ] == 0 )
				{
					$db -> update_array ( 'users', array ( 'warned' => 1, 'warn_time' => time () ), 'uid='. $row [ 'uid' ] );
					if ( !$silent ) echo "AutoWarning: ". $row [ 'name' ] ."\n";	
				}
				else 
				{
					# 1209600 sec = 2 weeks
					if ( $row [ 'warn_time' ] + 1209600 < time () )
					{
						$db -> update_array ( 'users', array ( 'can_leech' => 0 ), 'uid='. $row [ 'uid' ] );
						if ( !$silent ) echo "TorrentBan: ". $row [ 'name' ] ."\n";
					}
				}
			}
			
			# Remove warning and restore leeching functions if ratio is OK
			//$res = $db -> update_array ( 'users', array ( 'warned' => 0, 'can_leech' => 1 ), 'downloaded>0 AND uploaded/downloaded>'. RATIO_WARNING .' AND warned=\'1\'' );
			$res = $db -> update ( "UPDATE users SET warned=warned_manual, can_leech=can_leech_manual WHERE downloaded>0 AND uploaded/downloaded>". RATIO_WARNING ." AND warned='1'" );
			if ( !$silent && $res > 0 ) echo "Removed warnings: ". $res ."\n";	
		}
		
		
		# Scrape torrents
		public function task_scrape ( $silent = false )
		{
			if ( !PERFORM_SCRAPE || !FUNC_DOWNLOADS_TORRENT || SCRAPE_URL == TRACKER_URL )
			{
				# Nothing to do
				return;	
			}
			
			$bittorrent = & core::get_object ( 'bittorrent' );
			$db = & core::get_object ( 'db' );
			
			# Scrape every 60 min to reduce some load
			$timeout = 3600;
			$res = $db -> get_all ( "SELECT info_hash FROM dl_downloads WHERE (last_scrape+". $timeout .")<". time () ." AND info_hash!='' ORDER BY posted DESC LIMIT ". SCRAPE_TORRENTS_MAX );
			
			foreach ( $res as $k => $v )
			{
				# Scrape and update peer numbers
				$stats = $bittorrent -> scrape ( SCRAPE_URL, $v [ 'info_hash' ] );
				$stats = $stats [ 'files' ] [ $v [ 'info_hash' ] ];
				$seeders = $stats [ 'complete' ];
				$leechers = $stats [ 'incomplete' ];
				$no = $db -> update ( "UPDATE dl_downloads SET seeders='". $seeders ."', leechers='". $leechers ."', last_scrape='". time () ."' WHERE info_hash='". $v [ 'info_hash' ] ."'" );
				if ( !$silent ) echo "Scraped ". $no ." torrent(s)\n";
			}
		}
		
	}
	
?>