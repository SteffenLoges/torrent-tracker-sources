<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class blog
	{

		# Objects
		private $db, $cache, $text, $user;

		
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
			$this -> cache = & core::get_object ( 'cache' );
			$this -> text = & core::get_object ( 'text' );
			$this -> user = & core::get_object ( 'user' );
		}
		
		
		# Get categories
		public function get_cats ()
		{
			$this -> cache -> init ( 'menu', 1800 );
			$res = $this -> cache -> get ();
			if ( $res === false )
			{
				$res = $this -> db -> get_all ( "SELECT lid, name, color, id FROM blog_categories ORDER BY position" );
				$this -> cache -> save ( serialize ( $res ) );
			}
			else 
			{
				$res = unserialize ( $res );	
			}
			return $res;
		}
		
		
		# Get posts
		public function get_posts ( $cat = null, $page = null, & $page_count = null )
		{
			# How many posts to retrieve
			if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'blog_no' ] == 0 )
				{
					$page_count = BLOG_POSTS;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'blog_no' ];
				}
				
				$from = $page * $page_count - $page_count;
			}
			
			# Show all cats?
			if ( $cat == 'all' )
			{
				$cat = null;	
			}
			
			if ( $cat != null && !$this -> text -> validate ( $cat, 'lid' ) )
			{
				return false;
			}
			
			# Initialize cache
			$this -> cache -> init ( 'get_posts_'. $cat . ( $page != null ? '_'. $page : null ), 120 );
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				# Return cached result
				return unserialize ( $cached );	
			}
			
			# Get numeric cat id from literal
			$cat = $this -> get_cat_info ( $cat );
			
			# Generate and execute SQL query
			$qr = "SELECT 'b', blog_categories.name, blog_categories.lid, bp.plid, bp.posted, bp.updated, 
						  bp.header, bp.subheader, bp.author, bp.content, bp.comments, bp.parse_html, bp.id, bp.tags
				   FROM blog_posts AS bp
				   		LEFT JOIN blog_categories ON ( bp.cat = blog_categories.id )
				   ". ( $cat != null ? "WHERE bp.cat='". $cat ."'" : null ) ." 
				   ORDER BY bp.posted DESC
				   ". ( $page != null ? "LIMIT {$from}, ". $page_count : null );
			
			$res = $this -> db -> get_all ( $qr );
			
			# No posts
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			$this -> cache -> save ( serialize ( $res ) );
			
			return $res;
		}
		
		
		# Ger numeric cat id from literal (or some other, depending on the argument)
		public function get_cat_info ( $cat, $field = 'id' )
		{
			if ( $cat != null )
			{
				$cat = $this -> db -> get_one ( "SELECT ". $field ." FROM blog_categories WHERE lid='". $cat ."'" );	
				
				# Category does not exist
				if ( $this -> db -> num_rows () == 0 )
				{
					return null;	
				}
			}
			
			return $cat;
		}
		
		
		# Get post count in category
		public function get_post_count ( $cat = null )
		{
			# Get numeric cat id
			$cat = $this -> get_cat_info ( $cat );
			
			# Get post no
			$ret = $this -> db -> get_one ( "SELECT COUNT(*) FROM blog_posts". ( $cat != null ? " WHERE cat='". $cat ."'" : null ) );
			
			return $ret;
		}
		
		
		# Get post (by lid and plid)
		public function get_post ( $post, $cat, $queue = false )
		{
			if ( !$this -> text -> validate ( $post, 'plid' ) || !$this -> text -> validate ( $cat, 'lid' ) )
			{
				return false;
			}
			
			# Get numeric cat id
			$cat = $this -> get_cat_info ( $cat );
			
			# Generate and execute SQL query
			$qr = "SELECT blog_categories.name, blog_categories.lid, bp.plid, ". 
						  ( $queue == false ? 'bp.posted, bp.updated' : 'bp.post_date, bp.human_date' ) .", 
						  bp.header, bp.subheader, bp.author, bp.content, bp.comments, bp.parse_html, bp.copyright,
						  bp.id, '". $cat ."' AS cid, bp.tags
				   FROM ". ( $queue == false ? 'blog_posts' : 'blog_queue' ) ." AS bp
				   		LEFT JOIN blog_categories ON ( bp.cat = blog_categories.id )
				   WHERE bp.cat='". $cat ."' AND bp.plid='". $post ."'
				   LIMIT 1";
			
			$res = $this -> db -> get_row ( $qr );
			
			# Post does not exist
			if ( $this -> db -> num_rows () == 0 )
			{
				return false;
			}
			
			return $res;
		}
		
		
		# Post exists?
		public function post_exists ( $id )
		{
			$this -> db -> get_one ( "SELECT id FROM blog_posts WHERE id='". $id ."' LIMIT 1" );
			if ( $this -> db -> num_rows () > 0 )
			{
				return true;
			}
			else 
			{
				return false;	
			}
		}
		
		
		# Calculates $no days from today and gets number of posts in queue for those days
		public function get_queue_dates ( $no )
		{
			$dates = array ();
			
			for ( $i = 1; $i <= $no; $i++ )
			{
				$dates [] = date ( "ymd", strtotime ( "+{$i} days" ) );
			}
			
			# Build query
			$where = implode ( '\' OR human_date=\'', $dates );
			$qr = "SELECT human_date FROM blog_queue WHERE human_date='". $where ."'";
			$res = $this -> db -> get_all ( $qr );

			
			# Post count
			$tmp = array ();
			foreach ( $res as $v )
			{
				$v = $v [ 'human_date' ];
				if ( !isset ( $tmp [ $v ] ) )
				{
					$tmp [ $v ] = 1;
				}
				else 
				{
					$tmp [ $v ]++;	
				}
			}
			
			# Dates and post counts
			$sch = array ();
			foreach ( $dates as $v )
			{
				$year = substr ( $v, 0, 2 );
				$mon = substr ( $v, 2, 2 );
				$day = substr ( $v, 4, 2 );
				$date = date ( 'y/m/d', mktime ( 0, 0, 0, $mon, $day, $year ) );
				$sch [] = array ( 'date' => $date, 'no' => ( isset ( $tmp [ $v ] ) ? $tmp [ $v ] : 0 ) );
			}
			
			return $sch;
		}
		
		
		# Create new post. Posts to page or queue, depending on $time
		public function new_post ( $cat, $header, $subheader, $text, $schedule, $usehtml, $copyright, $time = null, $author = null, $tags = null )
		{
			# Halt if null
			if ( $cat == null || $header == null ) 
			{
				return false;
			}
			
			# Escape variables
			$header = $this -> db -> escape ( $header );
			$subheader = $this -> db -> escape ( $subheader );
			$text = $this -> db -> escape ( $text );	
			$tags = $this -> db -> escape ( $tags );	
			
			# Cat id
			if ( $time == null )
			{
				$cat_id = $this -> get_cat_info ( $cat );
			}
			else 
			{
				$cat_id = $cat;
			}
			
			# Plid
			$plid = $this -> text -> make_lid ( $header );
			
			# Scheduler
			if ( $schedule == 'schedule_quick' )
			{
				list ( $year, $month, $day ) = explode ( '/', $_POST [ 'scheduler' ] );
				$post_date = mktime ( 0, 0, 0, $month, $day, $year );
				$human_date = str_replace ( '/', null, $_POST [ 'scheduler' ] );
			}
			elseif ( $schedule == 'schedule' )
			{
				$year = $_POST [ 'Date_Year' ];
				$month = $_POST [ 'Date_Month' ];
				$day = $_POST [ 'Date_Day' ];
				$hour = $_POST [ 'Time_Hour' ];
				$minute = $_POST [ 'Time_Minute' ];
				$second = $_POST [ 'Time_Second' ];
				$post_date = mktime ( $hour, $minute, $second, $month, $day, $year );
				$human_date = date ( 'ymd', $post_date );
			}
			
			# Check if plid is available
			if ( $time == null )
			{
				$this -> check_plid ( $plid, $cat_id );
			}
			
			# Post author
			if ( $author == null )
			{
				$author = $_SESSION [ 'user' ];	
			}
			
			# Prepare tags
			$tags_str = $this -> prepare_tags ( $tags );
			
			# Query
			$qr = 'INSERT INTO '. ( $schedule == 'now' ? 'blog_posts' : 'blog_queue' ) ."
				SET cat='". $cat_id ."', plid='". $plid ."', header='". $header ."', subheader='". $subheader ."', 
				author='". $author ."', content='". $text ."', comments=0, 
				parse_html=". ( $usehtml == 'html' || $usehtml == 1 ? 1 : 0 ) .", copyright=". ( $copyright ? 1 : 0 ) 
			    . ( FUNC_TAGS ? ", tags='". $tags_str ."', " : ', ' ) . 
				( $schedule == 'now' ? 
						"posted='". ( $time == null ? time() : $time ) ."', updated=0" : 
						"post_date='". $post_date ."', human_date='". $human_date ."'" );

			if ( $time == null )
			{
				# Upload attachments
				$res = $this -> upload_files ( $cat, $plid );
				
				# :(
				if ( $res == false ) return false;
			}
			
			# So far so good, files uploaded, insert SQL
			$res = $this -> db -> insert ( $qr );
			
			if ( $res != 0 )
			{
				# Clear cache
				$this -> cache -> remove ( 'get_posts__1' );
				
				# Update userinfo
				if ( !isset ( $_SESSION [ 'user' ] ) || $author != $_SESSION [ 'user' ] )
				{
					$uinfo = $this -> user -> get_info ( $author );
					$dp = $uinfo [ 'blogposts' ] +1;
				}
				else 
				{
					$dp = $_SESSION [ 'userinfo' ] [ 'blogposts' ] +1;	
				}
				$this -> user -> update ( array ( 'blogposts' => $dp ), $author );
				
				return true; 
			}
			else 
			{
				return false;
			}
		}
		
		
		# Edit post (posted or queue)
		public function edit_post ( $id, $cat, $header, $subheader, $text, $schedule, $usehtml, $copyright, $queue = false, $real_plid = null, $real_lid = null, $lid_id = null, $tags = null )
		{
			# Escape variables
			$header = $this -> db -> escape ( $header );
			$subheader = $this -> db -> escape ( $subheader );
			$text = $this -> db -> escape ( $text );	
			
			# Cat id
			$cat_id = $this -> get_cat_info ( $cat );
			
			# Plid
			$plid = $this -> text -> make_lid ( $header );
			
			# Scheduler
			if ( $schedule == 'schedule_quick' )
			{
				list ( $year, $month, $day ) = explode ( '/', $_POST [ 'scheduler' ] );
				$post_date = mktime ( 0, 0, 0, $month, $day, $year );
				$human_date = str_replace ( '/', null, $_POST [ 'scheduler' ] );
			}
			elseif ( $schedule == 'schedule' )
			{
				$year = $_POST [ 'Date_Year' ];
				$month = $_POST [ 'Date_Month' ];
				$day = $_POST [ 'Date_Day' ];
				$hour = $_POST [ 'Time_Hour' ];
				$minute = $_POST [ 'Time_Minute' ];
				$second = $_POST [ 'Time_Second' ];
				$post_date = mktime ( $hour, $minute, $second, $month, $day, $year );
				$human_date = date ( 'ymd', $post_date );
			}
			
			# Check if plid is available
			if ( $cat_id != $lid_id || $plid != $real_plid )
			{
				$this -> check_plid ( $plid, $cat_id );
			}
			
			# Prepare tags
			$tags_str = $this -> prepare_tags ( $tags );
			
			# Query
			$qr = 'UPDATE '. ( $queue == false ? 'blog_posts' : 'blog_queue' ) ."
				SET cat='". $cat_id ."', plid='". $plid ."', header='". $header ."', subheader='". $subheader ."',
				content='". $text ."', parse_html=". ( $usehtml == 'html' || $usehtml == 1 ? 1 : 0 ) .", copyright=". ( $copyright ? 1 : 0 ) 
			    . ( FUNC_TAGS ? ", tags='". $tags_str ."' " : ' ' ) . 
				( $queue == false ? ', updated='. time () : null ) .' '.
				( $queue == true && $schedule != 'now' ? ", post_date='". $post_date ."', human_date='". $human_date ."'" : 
					( $queue == false && $schedule != 'now' ? ", posted='". $post_date ."'" : null ) ) .
				" WHERE id='". $id ."'";		
				
			# Move attachments
			$res = $this -> move_files ( $real_lid, $real_plid, $cat, $plid );
				
			# :(
			if ( $res == false ) return false;
			
			# Delete attachments
			$res = $this -> delete_files ( $cat, $plid, ( isset ( $_POST [ 'filedel' ] ) ? $_POST [ 'filedel' ] : array () ) );			
						
			# :(
			if ( $res == false ) return false;
			
			# Upload attachments
			$res = $this -> upload_files ( $cat, $plid );
			
			# :(
			if ( $res == false ) return false;
			
			# So far so good, files uploaded, update SQL
			$res = $this -> db -> update ( $qr );
			
			
			# Clear cache
			if ( !$queue )
			{
				$this -> cache -> remove ( 'get_posts__1' );
				$this -> cache -> remove ( 'bpost_'. $id );
			}
			
			return true; 
		}
		
		
		# Upload files / images
		private function upload_files ( $cat, $plid )
		{
			$path = DIR .'/'. DIR_POSTS .'/'. $cat .'/'. $plid;
			if ( !file_exists ( $path ) )
			{
				mkdir ( $path, 0777, true );
			}
			
			if ( !isset ( $_FILES [ 'upl' ] ) )
			{
				# Nothing to upload
				return true;	
			}
			
			foreach ( $_FILES [ 'upl' ] [ 'error' ] as $key => $error) 
			{
    			if ( $error == UPLOAD_ERR_OK ) 
    			{
        			$tmp_name = $_FILES [ 'upl' ] [ 'tmp_name' ] [ $key ];
        			$name = $_FILES [ 'upl' ] [ 'name' ] [ $key ];
        			$ret = move_uploaded_file ( $tmp_name, $path .'/'. $name );
        			if ( preg_match ( "#^image/#i", $_FILES [ 'upl' ] [ 'type' ] [ $key ] ) )
        			{
        				$this -> add_watermark ( $path .'/'. $name );
        			}
    			}
    			else 
    			{
    				return false;
    			}
			}
		
			return true;	
		}
		
		
		# Delete attachments
		private function delete_files ( $cat, $plid = null, $files = null, $del_dir = false )
		{
			$path = DIR .'/'. DIR_POSTS .'/'. $cat . ( $plid != null ? '/'. $plid : null );
			
			if ( $files != null )
			{
				foreach ( $files as $v ) 
				{
					$file = $path .'/'. $v;
					if ( substr_count ( $file, '..' ) == 0 && file_exists ( $file ) )
					{
    					unlink ( $file );
					}
				}
			}
			elseif ( $del_dir )
			{
				# Delete whole $plid dir	
				return $this -> del_dir ( $path );
			}
		
			return true;	
		}
		
		
		# Remove directory and it's contents
		function del_dir ( $fl )
		{
			if ( !file_exists ( $fl ) ) return true;
			
			if ( is_dir ( $fl ) )
			{
				$dir = opendir ( $fl );
				while ( ( $el = readdir ( $dir ) ) !== false )
				{
					if ( $el != '.' && $el != '..' )
					{
						$res = $this -> del_dir ( $fl .'/'. $el );
						if ( $res === false ) return false;
					}
				}
				closedir ( $dir );
				$res = rmdir ( $fl );
				if ( $res === false ) return false;
			}	
			else 
			{
				$res = unlink ( $fl );	
				if ( $res === false ) return false;
			}
			
			return true;
		}
		
		
		# Move attachments
		private function move_files ( $real_lid, $real_plid, $cat, $plid )
		{
			$from = DIR .'/'. DIR_POSTS .'/'. $real_lid .'/'. $real_plid;
			$to = DIR .'/'. DIR_POSTS .'/'. $cat .'/'. $plid;
			$dir_to = substr ( $to, 0, strrpos ( $to, '/' ) );
			
			if ( !file_exists ( $from ) )
			{
				return true;	
			}
			
			if ( !file_exists ( $dir_to ) )
			{
				mkdir ( $dir_to, 0777 );	
			}
			
			return rename ( $from, $to );
		}
		
		
		# Prepare tags
		public function prepare_tags ( $tags )
		{
			if ( !FUNC_TAGS ) return null;
			
			$tags = trim ( $tags, ',' );
			
			# Remove url-unfriendly characters
			$tags = strtr ( $tags, array ( '/' => null, '#' => null, '?' => null ) );
			
			# Remove duplicate tags
			$list = explode ( ',', $tags );
			$list = array_map ( 'trim', $list );
			$list = array_unique ( $list );
			
			# Generate a tag string for easy mysql lookup
			$tags = ','. implode ( ',', $list ) .',';
			
			return $tags;
		}
		
		
		# Split MySQL tags string into a tag array
		public function split_tags ( &$posts, $single_post = false )
		{
			if ( $single_post ) $posts = array ( $posts );
			
			foreach ( $posts as $k => $v )
			{
				if ( $v [ 'tags' ] == null || $v [ 'tags' ] == ',,' )
				{
					# No tags
					$posts [ $k ] [ 'tags' ] = array ();	
				}
				else 
				{
					$posts [ $k ] [ 'tags' ] = explode ( ',', trim ( htmlspecialchars ( $posts [ $k ] [ 'tags' ] ), ',' ) );	
				}
			}
			
			if ( $single_post ) $posts = $posts [ 0 ];
		}
		
		
		# Get blog and download tags
		public function get_tags ( &$blog_tags = array (), &$blog_max = 0, &$dl_tags = array (), &$dl_max = 0 )
		{
			# Todo: CACHE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			if ( !FUNC_TAGS ) return;
			
			$this -> cache -> init ( 'tags', 1800, CACHE_TAGS );
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				list ( $blog_tags, $blog_max, $dl_tags, $dl_max ) = unserialize ( $cached );
				return;
			}
			
			$blog_max = 0;
			$dl_max = 0;
			
			$qr = "(SELECT 'b' AS t, tags FROM blog_posts WHERE tags!=',,' AND tags!='' ORDER BY posted DESC LIMIT 50) UNION ALL (SELECT 'd' AS t, tags FROM dl_downloads WHERE tags!=',,' AND tags!='' ORDER BY posted DESC LIMIT 50)";
			$res = $this -> db -> get_all ( $qr );
			
			foreach ( $res as $item )
			{
				$arr = ( $item [ 't' ] == 'b' ? 'blog' : 'dl' );
				$tags = explode ( ',', trim ( $item [ 'tags' ], ',' ) );
				
				foreach ( $tags as $v )
				{
					if ( !isset ( ${ $arr .'_tags' } [ $v ] ) )
					{
						${ $arr .'_tags' } [ $v ] = 1;	
						if ( ${ $arr .'_max' } == 0 )
						{
							${ $arr .'_max' } = 1;
						}
					}
					else 
					{
						${ $arr .'_tags' } [ $v ]++;
						if ( ${ $arr .'_tags' } [ $v ] > ${ $arr .'_max' } )
						{
							${ $arr .'_max' } = ${ $arr .'_tags' } [ $v ];	
						}
					}
				}
			}
			
			$res = array ( $blog_tags, $blog_max, $dl_tags, $dl_max );
			$this -> cache -> save ( serialize ( $res ) );
		}
		
		
		# Deletes post
		public function delete_post ( $id, $queue, &$returninfo = null )
		{
			if ( !is_numeric ( $id ) )
			{
				error::line(__LINE__);
				return false;	
			}
			
			# Gets lid, plid, author
			$info = $this -> get_plid_lid ( $id, $queue, ', b.author, b.header' );
			if ( !$info ) 
			{
				error::line(__LINE__);
				return false;	
			}
			
			# User okay?
			if ( $info [ 'author' ] != $_SESSION [ 'user' ] && $_SESSION [ 'permissions' ] [ 'edit_posts' ] != 1 )
			{
				error::line(__LINE__);
				return false;	
			}
			
			# Delete attachments
			$res = $this -> delete_files ( $info [ 'lid' ], $info [ 'plid' ], null, true );
			if ( $res == false )
			{
				error::line(__LINE__);
				return false;	
			}
			
			$table = ( $queue ? 'blog_queue' : 'blog_posts' );
			
			# Deletes db entry
			$ret = $this -> db -> delete ( "DELETE FROM ". $table ." WHERE id='". $id ."'" );	
			
			# Delete comments
			$this -> db -> delete ( "DELETE FROM blog_comments WHERE post='". $id ."'" );
			
			if ( $ret > 0 )
			{
				# Update author userinfo
				$bp = $this -> db -> get_one ( "SELECT blogposts FROM users WHERE name='". $info [ 'author' ] ."'" );
				$bp--;
				$this -> user -> update ( array ( 'blogposts' => $bp ), $info [ 'author' ] );
			}
			else 
			{
				error::line(__LINE__);
				return false;	
			}
			
			$returninfo [ 'lid' ] = $info [ 'lid' ];
			$returninfo [ 'plid' ] = $info [ 'plid' ];
			$returninfo [ 'header' ] = $info [ 'header' ];
			
			return true;
		}

			
		# Check if any posts have to be posted from queue
		public function check_queue ()
		{
			# Check every ... sec
			$check_tm = 120;
			
			# Check timeout by file modification time (TMP/queue)
			$path = TMP .'/queue'; 
			if ( !file_exists ( $path ) || ( filemtime ( $path ) + $check_tm ) < time () )
			{	
				$res = $this -> db -> get_all ( 'SELECT * FROM blog_queue WHERE post_date<='. time () );
				if ( !empty ( $res ) )
				{
					foreach ( $res as $v )
					{
						$this -> new_post ( $v [ 'cat' ], $v [ 'header' ], $v [ 'subheader' ], $v [ 'content' ], 'now', 
									$v [ 'parse_html' ], $v [ 'copyright' ], $v [ 'post_date' ], $v [ 'author' ] );
									
						$this -> db -> delete ( "DELETE FROM blog_queue WHERE id='". $v [ 'id' ] ."'" );
					}
				}
				touch ( $path );	
			}
		}
		
		
		# Get plid and lid from id (sounds fun)
		public function get_plid_lid ( $id, $queue = false, $other = null )
		{
			$res = $this -> db -> get_row ( 'SELECT blog_categories.lid, b.plid '. $other .'
											 FROM '. ( $queue == false ? 'blog_posts' : 'blog_queue' ) .' AS b
												LEFT JOIN blog_categories ON (b.cat = blog_categories.id)
											 WHERE b.id='. $id );
			
			return $res;	
		}
		
		
		# Get post info
		public function get_post_info ( $field, $id, $queue = false )
		{
			$res = $this -> db -> get_row ( 'SELECT '. $field .' FROM '. ( $queue == false ? 'blog_posts' : 'blog_queue' ) .' WHERE id='. $id );
			return $res;
		}
		
		
		# Get post attachments
		public function get_attachments ( $post, $cat )
		{
			$path = DIR .'/'. DIR_POSTS .'/'. $cat .'/'. $post;
			
			$ret = array ();
			
			if ( !file_exists ( $path ) ) return $ret;
			
			if ( $h = opendir ( $path) ) 
			{
    			while ( ( $f = readdir ( $h ) ) !== false ) 
    			{
        			if ( $f != '.' && $f != '..') 
        			{
        				$ret [] = $f;
        			}
    			}
    			closedir ( $h );
			}
			
			return $ret;
		}
		
		
		# Checks if plid is available. If occupied, search for unoccupied by attaching a number. Update: now can check if category lid is available.
		public function check_plid ( &$plid, $cat, $category = false )
		{
			if ( !$category )
			{
				$res1 = $this -> db -> get_all ( "SELECT plid FROM blog_posts WHERE plid LIKE '". $plid ."%' AND cat='". $cat ."'" );
				$res2 = $this -> db -> get_all ( "SELECT plid FROM blog_queue WHERE plid LIKE '". $plid ."%' AND cat='". $cat ."'" );
				$res = array_merge ( $res1, $res2 );
			}
			else 
			{
				$res = $this -> db -> get_all ( "SELECT lid FROM blog_categories WHERE lid LIKE '". $plid ."%'" );
			}
			
			if ( !empty ( $res ) )
			{
				$i = 2;
				while ( $this -> search_plid_arr ( $plid .'-'. $i, $res, $category ) === true )
				{
					$i++;
				}
				$plid = $plid .'-'. $i;
			}
			else 
			{
				return true;	
			}
		}
		
		
		# If plid is in array
		public function search_plid_arr ( $plid, $arr, $category )
		{
			$key = ( $category ? 'lid' : 'plid' );
			foreach ( $arr as $v )
			{
				if ( $v [ $key ] == $plid )
				{
					return true;	
				}	
			}
			return false;
		}
		
		
		# Get user posts
		public function get_user_posts ( $user = null, $updatecounter = true )
		{
			if ( $user == null )
			{
				$user = $_SESSION [ 'user' ];	
			}
			
			# Build and execute SQL query
			$qr = "(SELECT 'p' AS type, bp.id, blog_categories.name, blog_categories.lid, bp.plid, bp.posted, bp.updated, 
						  bp.header, bp.subheader, bp.comments
				   FROM blog_posts AS bp
				   		LEFT JOIN blog_categories ON ( bp.cat = blog_categories.id )
				        WHERE bp.author='". $user ."')
				   UNION
				   (SELECT 'q' AS type, bq.id, blog_categories.name, blog_categories.lid, bq.plid, bq.post_date, bq.human_date, 
						  bq.header, bq.subheader, bq.comments
				   FROM blog_queue AS bq
				   		LEFT JOIN blog_categories ON ( bq.cat = blog_categories.id )
				        WHERE bq.author='". $user ."')
				   ORDER BY posted DESC";
					
			$res = $this -> db -> get_all ( $qr );
			
			# No posts
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			# Update user posts counter
			if ( $updatecounter )
			{
				$bp_count = $this -> db -> get_one ( "SELECT COUNT(*) FROM blog_posts WHERE author='". $user ."'" );
				$this -> user -> update ( array ( 'blogposts' => $bp_count ), $user );
			}
			
			return $res;	
		}
		
		
		# Watermark image
		public function add_watermark ( $path )
		{
			# If watermarking is disabled, exit function
			if ( !BLOG_WATERMARK )	return;
			
			# If '_nowatermark' is in image name, exit function
			if ( strpos ( $path, '_nowatermark' ) !== false ) return;
			
			# Exit if watermark does not exist.
			if ( !file_exists ( WATERMARK_PATH ) ) return;
			
			# Load gd wrapper class
			if ( !isset ( $this -> gd ) )
			{
				$this -> gd = & core::load_file ( 'gd' );
			}
			
			# Load watermark image
			$wtr = $this -> gd -> create_img ( WATERMARK_PATH );
			
			# Load image
			$im = $this -> gd -> create_img ( $path );
			
			# Get size
			list ( $width, $height ) = $this -> gd -> get_dimensions ();
			
			# If size is okay
			if ( $width >= WATERMARK_MINWIDTH && $height >= WATERMARK_MINHEIGHT )
			{
				$this -> gd -> add_watermark ( $wtr );
				$this -> gd -> output ( null, $path );
			}
		}
		
		
		# Get posts and downloads (homepage)
		public function get_posts_downloads ( $page = null, & $page_count = null, & $post_count = null )
		{
			# How many elements to get?
			if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'blog_no' ] == 0 )
				{
					$page_count = BLOG_POSTS;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'blog_no' ];
				}
				
				$from = $page * $page_count - $page_count;
			}
			
			# Initialize cache
			$this -> cache -> init ( 'get_posts_downloads_'. ( $page != null ? '_'. $page : null ), 60, CACHE_TITLE );
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				# Return cached result
				$res = unserialize ( $cached );
				$post_count = $res [ 1 ];
				return $res [ 0 ];	
			}
			
			# Build and execute SQL
			$qr = null;
			
			if ( FUNC_BLOG )
			{
				$qr .= "(SELECT 'b', blog_categories.name, blog_categories.lid, 'sub_name', 'sub_lid', 
					   		  bp.id, bp.plid, bp.posted, bp.updated, 
							  bp.header, bp.subheader, bp.author, bp.content, bp.comments, bp.tags, 
							  bp.parse_html, 'anonymous', 'info_hash'
					   FROM blog_posts AS bp
					   		LEFT JOIN blog_categories ON ( bp.cat = blog_categories.id )
					   )";
			}
			
			if ( FUNC_BLOG && FUNC_DOWNLOADS )
			{
				$qr .= ' UNION ';	
			}
			
			if ( FUNC_DOWNLOADS )
			{
				$qr .= "(SELECT 'd' AS b, dl_categories.name, dl_categories.lid, dl_subcategories.name AS sub_name, dl_subcategories.lid AS sub_lid,
						  dl.fid AS id, dl.plid, dl.posted, dl.updated,
						  dl.header, dl.subheader, dl.user AS author, dl.content, dl.comments, dl.tags, 
						  '0' AS parse_html, dl.anonymous, dl.info_hash
				   FROM dl_downloads AS dl
				   		LEFT JOIN dl_categories ON ( dl.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl.subcat = dl_subcategories.id )
				   	WHERE dl.confirmed='1' ";
				
				if ( !FUNC_DOWNLOADS_HTTP )
				{
					$qr .= "AND dl.info_hash!=''";	
				}
				elseif ( !FUNC_DOWNLOADS_TORRENT )
				{
					$qr .= "AND dl.dl_links!=''";
				}
				
				$qr .= ")";
			}
				   
			$qr .= "ORDER BY posted DESC ". ( $page != null ? "LIMIT {$from}, ". $page_count : null );
			
			$res = $this -> db -> get_all ( $qr );
			
			# Zero results
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			# Entry count
			$qr = 'SELECT ';
			if ( FUNC_BLOG ) $qr .= 'COUNT(DISTINCT blog_posts.id)';
			if ( FUNC_BLOG && FUNC_DOWNLOADS ) $qr .= ', ';
			if ( FUNC_DOWNLOADS ) $qr .= 'COUNT(DISTINCT dl_downloads.fid)';
			$qr .= ' FROM ';
			if ( FUNC_BLOG ) $qr .= 'blog_posts';
			if ( FUNC_BLOG && FUNC_DOWNLOADS ) $qr .= ', ';
			if ( FUNC_DOWNLOADS ) 
			{
				$qr .= 'dl_downloads WHERE dl_downloads.confirmed=\'1\'';
				
				if ( !FUNC_DOWNLOADS_HTTP )
				{
					$qr .= "AND dl_downloads.info_hash!=''";	
				}
				elseif ( !FUNC_DOWNLOADS_TORRENT )
				{
					$qr .= "AND dl_downloads.dl_links!=''";
				}
			}
			
			//$qr = "SELECT COUNT(DISTINCT blog_posts.id), COUNT(DISTINCT dl_downloads.fid) FROM blog_posts, dl_downloads WHERE dl_downloads.confirmed='1'";

			$post_count = $this -> db -> get_row ( $qr );
			$post_count = array_sum ( $post_count );
			
			if ( CACHE_TITLE )
			{
				$this -> cache -> save ( serialize ( array ( $res, $post_count ) ) );
			}
			
			return $res;
		}		
		
		
		# Get last headlines
		public function get_last_posts ( $number = 5 )
		{		
			# Initialize cache
			$this -> cache -> init ( 'infobanner_blog', 60, CACHE_INFOBANNER );	
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				# Return cached result
				$res = unserialize ( $cached );	
			}
			else 
			{
				$qr = 'SELECT blog_categories.lid, blog_posts.plid, blog_posts.header 
				       FROM blog_posts
				       	LEFT JOIN blog_categories ON (blog_posts.cat=blog_categories.id)
				       ORDER BY blog_posts.posted DESC
				       LIMIT '. $number;
				$res = $this -> db -> get_all ( $qr );
				
				if ( CACHE_INFOBANNER )
				{
					$this -> cache -> save ( serialize ( $res ) );
				}
			}
			
			return $res;
		}
		
		
		# Delete categories, blog posts and their comments by category ids
		public function del_cats ( $ids )
		{
			$where_cat = "cat='". implode ( "' OR cat='", $ids ) ."'";
			$where_id = "id='". implode ( "' OR id='", $ids ) ."'";
			
			# Get category post ids, delete posts and comments
			$posts = $this -> db -> get_all ( 'SELECT id FROM blog_posts WHERE '. $where_cat );
			if ( !empty ( $posts ) )
			{
				$posts_arr = array ();
				foreach ( $posts as $v )
				{
					$posts_arr [] = $v [ 'id' ];	
				}
				
				# Delete posts
				$this -> db -> delete ( 'DELETE FROM blog_posts WHERE '. $where_cat );
				$this -> db -> delete ( 'DELETE FROM blog_queue WHERE '. $where_cat );
				
				# Delete comments
				if ( !empty ( $posts_arr ) )
				{
					$where_post = "post='". implode ( "' OR post='", $posts_arr ) ."'";
					$this -> db -> delete ( 'DELETE FROM blog_comments WHERE '. $where_post );
				}
			}
			
			# Get plids and delete attachments
			$plids = $this -> db -> get_all ( 'SELECT lid FROM blog_categories WHERE '. $where_id );
			foreach ( $plids as $v )
			{
				$this -> delete_files ( $v [ 'lid' ], null, null, true );
			}
			
			# Delete categories
			$this -> db -> delete ( 'DELETE FROM blog_categories WHERE '. $where_id );
			
			return true;
		}
		
		
		# Update category names and/or positions
		public function update_cats ( $cats )
		{
			$where_id = "id='". implode ( "' OR id='", array_keys ( $cats ) ) ."'";
			$res = $this -> db -> get_all ( 'SELECT id, lid, name FROM blog_categories WHERE '. $where_id );
			foreach ( $res as $v )
			{
				$cats [ $v [ 'id' ] ] [ 'lid' ] = $v [ 'lid' ];	
				$cats [ $v [ 'id' ] ] [ 'old_name' ] = $v [ 'name' ];	
			}		
			
			foreach ( $cats as $id => $v )
			{
				if ( trim ( $v [ 'name' ] ) != null )
				{
					if ( $v [ 'name' ] != $v [ 'old_name' ] ) 
					{
						$lid = $this -> text -> make_lid ( $v [ 'name' ] );
						$this -> check_plid ( $lid, null, true );
					}
					else 
					{
						$lid = $v [ 'lid' ];	
					}
					$name = $this -> db -> escape ( $v [ 'name' ] );
					$position = $v [ 'pos' ];
					
					# Rename attachments directory
					if ( $v [ 'lid' ] != $lid && file_exists ( DIR .'/'. DIR_POSTS .'/'. $v [ 'lid' ] ) )
					{
						rename ( DIR .'/'. DIR_POSTS .'/'. $v [ 'lid' ], DIR .'/'. DIR_POSTS .'/'. $lid );
					}
					
					# Do it!
					$this -> db -> update ( "UPDATE blog_categories SET lid='". $lid ."', name='". $name ."', position='". $position ."' WHERE id='". $id ."'" );	
				}
			}
		}
		
		
		# Create new category at the botom of blog categories list
		public function create_cat ( $name )
		{
			$lid = $this -> text -> make_lid ( $name );
			$this -> check_plid ( $lid, null, true );
			$name = $this -> db -> escape ( $name );
			# Could'n find a way to do this with only one query :(
			$pos = $this -> db -> get_one ( 'SELECT MAX(position) FROM blog_categories' );
			if ( $pos == false ) $pos = 1; else $pos++;
			$this -> db -> insert ( "INSERT INTO blog_categories SET lid='". $lid ."', name='". $name ."', position=". $pos );
			
			return true;
		}

			
		
	}

?>