<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


# Check if included via index.php
if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


/*
	PHP GD functions wrapper. Some advanced stuff.
	I wrote this class long time ago. It's not pretty, but it works.
*/
class gd
{
		
	private $im;
	private $type;
	private $im_x;
	private $im_y;
	private $bgcol;
	
	
	# Create GD stream
	 # $background [ 0 ] - rrr, [ 1 ] - ggg, [ 2 ] - bbb, random if null
	public function create ( $width = 80, $height = 33, $type = 'png', $truecolor = false, $background = array () )
	{
		$this -> im = ( $truecolor ? imagecreatetruecolor ( $width, $height ) : imagecreate( $width, $height ) );
		$this -> type = $type;
		$this -> im_x = $width;
		$this -> im_y = $height;
		
		if ( empty ( $background ) )
		{
			$background [ 0 ] = rand ( 125, 255 );
			$background [ 1 ] = rand ( 125, 255 );
			$background [ 2 ] = rand ( 125, 255 );
		}

		$this -> bgcol = $background;
		
		$bgcol = imagecolorallocate ( $this -> im, $background [ 0 ], $background [ 1 ], $background [ 2 ] );	
		imagerectangle ( $this -> im, 0, 0, $this -> im_x, $this -> im_y, $bgcol );
	}
	
	
	# Create GD stream from image file
	public function create_img ( $resource )
	{
		# Dumb, but fast check
		
		$ext = explode( '.', $resource );
		
		$res_c = count ( $ext );
		
		if ( $res_c > 1 )
		{
		   $ext = $ext [ $res_c -1 ];
		}
		else
		{ 
			throw new error ( 'Invalid image type (check file extension)' );
		}
		
		switch ( strtolower ( $ext ) )
		{
			case 'jpg':
				$this -> type = 'jpg';
			break;
			
			case 'png':
					$this -> type = 'png';
				break;
				
			case 'gif':
					$this -> type = 'gif';
				break;
				
			default:
					throw new error ( 'Unsupported image format' );
				break;	
		}
		
		switch ( $this -> type )
		{
			case 'jpg':
					$this -> im = imagecreatefromjpeg ( $resource );
				break;
				
			case 'png':
					$this -> im = imagecreatefrompng ( $resource );
				break;
				
			case 'gif':
					$this -> im = imagecreatefromgif ( $resource );
				break;
		}
		
		if ( $this -> im === false )
		{
			return $false;	
		}
		
		$this -> im_x = imagesx ( $this -> im );
		$this -> im_y = imagesy ( $this -> im );
		
		return $this -> im;
		//return true;
	}
	
	
	# Draws text onto image
	 # $string - text string
	 # $size - size (duh)
	 # $color - array (rrr, ggg, bbb)
	 # $x - number for specific position, string for random
	 # $y - number for specific position, string for random
	 # $font - ttf font, 'default' for default GD font
	 # $angle - (only if ttf font supplied) number for specific angle, string for random
	public function text ( $string, $size = 10, $color = array ( 0, 0, 0 ), $x = 'r', $y = 'r', $font = 'default', $angle = 0 )
	{
		$im_x = $this -> im_x;
		$im_y = $this -> im_y;
		
		$font_size = imagefontwidth ( $size ) ;
		
		$col = imagecolorallocate( $this -> im, $color[0], $color[1], $color[2] );
		
		# Angle
		if ( !is_integer( $angle ) && $font != 'default' )
		{
			# No need to overdo, +-5 degrees
			$angle = rand ( -5, 5 );
			$bbox = imagettfbbox( $size, $angle, $font, $string );
			$ttf_size_x = $bbox [2] - $bbox [0];
			$ttf_size_y = $bbox [3] - $bbox [5];
		} 
		elseif ( ( !is_integer( $x ) || !is_integer( $y ) ) && $font != 'default' )
		{
			# Get text width and height from bounding box for random positioning
			$bbox = imagettfbbox( $size, $angle, $font, $string );
			$ttf_size_x = $bbox [2] - $bbox [0];
			$ttf_size_y = $bbox [3] - $bbox [5];
		}
		
		# x
		if ( is_integer ( $x ) ) 
			$text_x = $x; 
		   else 
		    {
		    	if ($font == 'default')
		    	{
		    		# Default GD font
		    		$text_x = rand ( 4, $im_x - strlen($string) * $font_size - 4 );
		    	}
		    	else 
		    	{
		    		# TTF
		    		$text_x = rand ( 4, $im_x - $ttf_size_x - 4 );
		    	}
		    }
		    
		# y
		if ( is_integer ( $y ) ) 
			$text_y = $y; 
		   else 
		    {
		    	if ($font == 'default')
		    	{
		    		# Default GD font
		    		$text_y = rand ( 4, $im_y - imagefontheight( $size ) - 4 );
		    	}
		    	else 
		    	{
		    		 $text_y = rand ( $ttf_size_y + 4, $im_y - 4);
		    	}
		    }		    
		

		    
		# Grand finale :)
		if ( $font == 'default' )
		{
			imagestring( $this -> im, $size, $text_x, $text_y, $string, $col );
		}
		else 
		{
			imagettftext( $this -> im, $size, $angle, $text_x, $text_y, $col, $font, $string);
		}
	}
	
	
	# Add random trash (lines and dots) to image. Useful for distorting captcha or generating random images.
	public function trash ( $amount_lines = 10, $amount_pixels = 100 )
	{
		  # Lines
		  for ($i=0; $i<$amount_lines; $i++)
   			{
   			 	$col = ImageColorAllocate ( $this -> im, rand ( 0, 255 ), rand ( 0, 255 ), rand ( 0, 255 ) );
    			$rx = rand ( 0, $this -> im_x );
    			$ry = rand ( 0, $this -> im_y );
    			$rx2 = rand ( 0, $this -> im_x );
    			$ry2 = rand ( 0, $this -> im_y );
    			imageline ( $this -> im, $rx, $ry, $rx2, $ry2, $col );
   			}   
   			
   		  # Dots
		  for ($i=0; $i<$amount_pixels; $i++)
   			{
    			$col = ImageColorAllocate ( $this -> im, rand ( 0, 255 ), rand ( 0, 255 ), rand( 0, 255 ) );
    			$rx = rand ( 0, $this -> im_x );
    			$ry = rand ( 0, $this -> im_y );
    			imagesetpixel ( $this -> im, $rx, $ry, $col);
    			//imagefilledrectangle ( $this -> im, $rx, $ry, $rx, $ry, $col);
   			}     		  
	} 
	
	
	# Output image
	 # If $type == null, output default format
	public function output ( $type = null, $save_path = null )
	{
		if ( $type != null ) $this -> type = $type;
		
		# Check for browser supported image types
		if ( $this -> type == 'auto' )
		{
			$http_accept = ( isset ( $_SERVER [ 'HTTP_ACCEPT' ] ) ? $_SERVER [ 'HTTP_ACCEPT' ] : null ) ;
			
			# PNG
        	if ( strpos ( $http_accept, 'image/png' ) !== false )
        	{
        		$this -> type = 'png';
        	}
        	# JPG
        	elseif ( strpos ( $http_accept, 'image/jpeg' ) !== false )
        	{
        		$this -> type = 'jpg';
        	}
        	# GIF
        	elseif ( strpos ( $http_accept, 'image/gif' ) !== false )
        	{	
        		$this -> type = 'gif';
        	}
        	# Fallback to GIF (no http_accept headers does not mean no supported imagetypes)
        	else 
        	{
        		$this -> type = 'gif';
        	}
		}
		
		if ( $save_path == null )
		{
        	header ( 'Cache-Control: no-store, no-cache, must-revalidate' );
        	header ( 'Pragma: no-cache' );
		}
		
        switch ( $this -> type )
        {
        	case 'jpg':
        			if ( $save_path == null )
        			{
        				header ( 'Content-type: image/jpeg' );
        			}
        			$res = imagejpeg ( $this -> im, $save_path, 100 );
        		break;
        		
        	case 'png':
					if ( $save_path == null )
        			{
        				header ( 'Content-type: image/png' );
        			}
        			$res = imagepng ( $this -> im, $save_path );
        		break;
        		
        	case 'gif':
					if ( $save_path == null )
        			{
        				header ( 'Content-type: image/gif' );
        			}
        			$res = imagegif ( $this -> im, $save_path );
        		break;
        		
        	case 'wbmp':
					if ( $save_path == null )
        			{
        				header ( 'Content-type: image/vnd.wap.wbmp' );
        			}
        			$res = imagewbmp ( $this -> im, $save_path );
        		break;
        	
        	default:
        			throw new error ( 'Invalid output image type specified' );
        		break;	
        }

        imagedestroy ( $this -> im );
        
        return $res;		
	}
	
	
	# Attempt to find most common color in image
	 # $accuracy - how many % of image to analyze
	 # returns array ( rrr, ggg, bbb )
	public function color_dom ( $accuracy = 20 )
	{
		$tot = $this -> im_x * $this -> im_y;
		$chunk = $tot / 100 * $accuracy;
		$no_chunks = $tot / $chunk;
		
		$r_tot = 0;
		$g_tot = 0;
		$b_tot = 0;
		
		for ($i = 0; $i < $no_chunks; $i++)
		{
				$rand = rand ( $i*$chunk, ($i+1)*$chunk );
				$y = floor ( $rand / $this -> im_x );
				$x = $rand - $y * $this -> im_x;
				$rgb = ImageColorAt( $this -> im, $x, $y );
				$cols = imagecolorsforindex ( $this -> im, $rgb );
				$r = $cols [ 'red' ];
				$g = $cols [ 'green' ];
				$b = $cols [ 'blue' ];
				$r_tot += $r;
				$g_tot += $g;
				$b_tot += $b;
		}
		
		$avg_r = floor ( $r_tot / $no_chunks );
		$avg_g = floor ( $g_tot / $no_chunks );
		$avg_b = floor ( $b_tot / $no_chunks );
		return array ( $avg_r, $avg_g, $avg_b );
	}
	
	
	# Returns inverted color
	 # If $bg == true, then $r, $g, $b default to background values (for convenience)
	public function diff_color( $r, $g, $b, $bg = false )
	{
		if ( $bg )
		{
			$r = $this -> bgcol [ 0 ];
			$g = $this -> bgcol [ 1 ];
			$b = $this -> bgcol [ 2 ];	
		}
		
		$r = 255 - $r;
		$g = 255 - $g;
		$b = 255 - $b;
		
		return array ( $r, $g, $b );
	}
	
	
	# Return GD image width and height
	public function get_dimensions ()
	{
		return array ( $this -> im_x, $this -> im_y );
	}

	
	# Add a watermark
	public function add_watermark ( $wtr )
	{
    	$lwidth  = imagesx ( $wtr );
    	$lheight = imagesy ( $wtr );
    	$src_x = $this -> im_x - ( $lwidth + 5 );
    	$src_y = $this -> im_y - ( $lheight + 5 );
    	
    	imagealphablending ( $this -> im, true );
    	imagecopy ( $this -> im, $wtr, $src_x, $src_y, 0, 0, $lwidth, $lheight );
	}
	
}
?>