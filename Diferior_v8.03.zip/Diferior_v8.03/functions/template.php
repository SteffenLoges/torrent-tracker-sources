<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	require_once ( SMARTY_PATH );
	
	class template extends Smarty
	{
	
		# References to various objects
		private static $url,  $text, $language, $user;
		
		# Show images?
		private static $show_images = true;
		
		
		# Constructor
		public function __construct ()
		{
			$this -> Smarty ();
			
			self::$url = & core::get_object ( 'url' );
			self::$text = & core::get_object ( 'text' );
			self::$language = & core::get_object ( 'language' );
			self::$user = & core::get_object ( 'user' );
   	 	
			$this -> compile_dir = SMARTY_COMPILE_DIR;
	
			$this -> template_dir = SMARTY_TEMPLATES_DIR;
	
			$this -> register_function ( 'link', array ( $this, 'generate_link' ) );
			$this -> register_function ( 'img', array ( $this, 'show_image' ) );
			$this -> register_function ( 'errno', array ( $this, 'err_line' ) );
			$this -> register_function ( 't', array ( $this, 'translate' ) );
			$this -> register_function ( 'get_user_status', array ( $this, 'get_user_status' ) );
			
			$this -> register_modifier ( 'link', array ( $this, 'generate_link' ) );
			$this -> register_modifier ( 'translate', array ( $this, 'translate' ) );
			$this -> register_modifier ( 'c', array ( $this, 'convert' ) );
			$this -> register_modifier ( 'c_r', array ( $this, 'convert_r' ) );
			$this -> register_modifier ( 'parse_post', array ( $this, 'parse_post' ) );
			$this -> register_modifier ( 'paging', array ( $this, 'get_paging' ) );
			$this -> register_modifier ( 'quotes', array ( $this, 'replace_quotes' ) );
			$this -> register_modifier ( 'page', array ( $this, 'wrap_pages' ) );
			$this -> register_modifier ( 'format_size', array ( $this, 'format_size' ) );
			$this -> register_modifier ( 'colorize', array ( $this, 'colorize' ) );
			$this -> register_modifier ( 'get_age', array ( $this, 'get_age' ) );
			$this -> register_modifier ( 'nice_date', array ( $this, 'nice_date' ) );
			
			$this -> load_filter ( 'output', 'trimwhitespace' );
		}
	
   	 
    	# Generate link
    	 # Arguments must be separated by slashes (/)
    	public static function generate_link ( $params )
    	{
    		if ( is_array ( $params ) )
    		{
    			$args = & $params [ 'url' ];	
    			
    			if ( isset ( $params [ 'addsid' ] ) )
    			{
    				$curr = self::$url -> add_sid;
    				self::$url -> add_sid = $params [ 'addsid' ];
    			}
    		}
    		else 
    		{
    			$args = & $params;
    		}
    		
    		$url = self::$url -> make ( explode ( '/', $args ) );
    		
    		if ( isset ( $curr ) )
    		{
    			self::$url -> add_sid = $curr;
    		}

    		return $url;
    	}
    
    
    	# Generate <img> tag
    	 # {img src="http://..." alt="..."}
    	public static function show_image ( $args )
    	{
    		if ( self::$show_images )
    		{
    			$arg_str = null;
    			
    			foreach ( $args as $k => $v )
    			{
    				$arg_str .= ' '. $k .'="'. $v .'"';
    			}
    			
    			return '<img'. $arg_str .' />';
    		}
    		else 
    		{
    			return ( isset ( $args [ 'alt' ] ) ? $args [ 'alt' ] : null );
    		}
    	}
     
    	
    	# Convert some symbols to HTML entities
    	public static function convert ( $args )
    	{
    		return self::$text -> convert ( $args );
    	}
    	
    	
    	# Convert HTML entities back to symbols
    	public static function convert_r ( $args )
    	{
    		return self::$text -> convert_r ( $args );
    	}
    	
    
    	# Parse text (bbcode, etc)
    	public static function parse_post ( $txt, $cat = null, $post = null, $parse_html = false, $preview = false, $shorten = false, 
    										$id = null, $mobile = false, $paragraph = 'p', $readall = null )
    	{
    		return self::$text -> parse_post ( $txt, $cat, $post, $parse_html, $preview, $shorten, $id, $mobile, $paragraph, $readall );
    	}
    	
    	
    	# Replace quotes
    	public static function replace_quotes ( $txt )
    	{
    		return self::$text -> replace_quotes ( $txt );
    	}
    	
    	
    	# Change $show_images value
    	public function change_images ( $state )
    	{
    		self::$show_images = $state;	
    	}
    	 
    
    	# Assigns variables to Smarty from associative array
    	public function assign_all ( $arr )
    	{
    		foreach ( $arr as $k => $v )
    		{
    		   $this -> assign ( $k, $v );	
    		}
    	}    
    
    	
		# Returns numbers for smart paging
		 # page - current page
		 # pages - total pages
		 # midlen - `number of pages in the middle`/2
		 # maxpages - if $pages < $maxpages, then all pages will be output
		public static function get_paging ( $page, $pages, $midlen = 2, $maxpages = 5 )
		{
			$res = array ();
	
			# $pages < $maxpages
	        if ( $pages < $maxpages )
	        {
	        	for ( $i = 1; $i <= $pages; $i++ )
	        	{
	         		$res [] = $i;
	         	}
	        }
	        else
	        {
	        	# 1st page
	        	if ( $page != 1 ) 
	        	{
	        		$res [] = 1;
	        	}
	
	        	# Lower pages
	        	$left=false;
	        	for ( $i = $page - $midlen; $i < $page; $i++ )
	        	{
	        		if ( $left == false )
	        		{
	        			if ( $i > 2 ) $res [] = 'sep';
	        			$left = true;
	        		}
	        		
	        		if ( $i > 1 ) 
	        		{
	        			$res [] = $i;
	        		}
    	    	}
	
	        	# Current page
	        	$res [] = $page;
		
	        	# Upper pages
	        	for ( $i = $page +1; $i <= $page + $midlen; $i++ )
	        	{
	        		if ( $i < $pages ) 
	        		{
	        			$res [] = $i;
	        		}
	
	        		if ( ( $i == $page + $midlen ) && ( $i < $pages -1 ) )
	        		{
	        			$res [] = 'sep';
	        		}
	        	}
		
	        	# Last page
	        	if ( $page != $pages ) 
	        	{
	        		$res [] = $pages;
	        	}
	        }
	        
	        return $res;	
		}
		
		
		# Convert bytes into user-friendly string
		public static function format_size ( $filesize )
		{
			$i = 0;
  			$sfx = array ( 'B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB' );
  			
  			while ( ( $filesize / 1024 ) > 1 ) 
  			{
   				$filesize = $filesize / 1024;
   				$i++;
  			}
  			
  			return substr ( $filesize, 0, strpos ( $filesize, '.' ) +4 ) .' '. $sfx [ $i ];
		}
		
		
		# Color number. Lowest = red, highest = green and numbers inbetween accordingly.
		public static function colorize ( $no, $max, $reverse = false, $only_color = false )
		{
			$no_orig = $no;
				
			if ( $no == 0 )
			{
				$red = 'ff';
				$green = '00';
			}
			elseif ( $max == 0 )
			{
				$red = '00';
				$green = 'ff';
			}
			else 
			{
				if ( $no > $max ) $no = $max;
				
				$green = ( 255 / $max ) * $no;
				$red = 255 - $green;
				
				if ( $reverse )
				{
					$red_tmp = $green;
					$green = $red;
					$red = $red_tmp;
					unset ( $red_tmp ); 	
				}
				
				$green = sprintf ( '%02x', $green );
				$red = sprintf ( '%02x', $red );
			}
			
			if ( $only_color )
			{
				return '#'. $red . $green .'00';
			}
			
			return '<span style="color: #'. $red . $green .'00">'. $no_orig .'</span>';
		}
		
		
		# Gets human age from birthdate in MySQL DATE (YYYY-MM-DD) format
		public static function get_age ( $date ) 
		{
			$parts = explode ( '-', $date );
      		$age = date ( 'Y' ) - $parts [ 0 ]; 
      		if ( $parts [ 1 ] > date ( 'm' ) ) 
      		{
      			$age--;
      		}
      		elseif ( $parts [ 1 ] == date ( 'm' ) )
      		{ 
         		if ( $parts [ 2 ] > date ( 'd' ) )
         		{ 
         	   		$age--;
         		}
      		} 
      		return $age; 
   		}
   		
   		
   		# Generates a pretty date string from MySQL DATE (YYYY-MM-DD)
		public static function nice_date ( $date ) 
		{
			$str = null;
			
			$parts = explode ( '-', $date );
			
			$str .= $parts [ 0 ] .' ';
			
			switch ( $parts [ 1 ] )
			{
				case '01': $str .= self::$language -> t ( 'template_date_01' );	break;
				case '02': $str .= self::$language -> t ( 'template_date_02' );	break;
				case '03': $str .= self::$language -> t ( 'template_date_03' );	break;
				case '04': $str .= self::$language -> t ( 'template_date_04' ); break;
				case '05': $str .= self::$language -> t ( 'template_date_05' );	break;
				case '06': $str .= self::$language -> t ( 'template_date_06' );	break;
				case '07': $str .= self::$language -> t ( 'template_date_07' );	break;
				case '08': $str .= self::$language -> t ( 'template_date_08' );	break;
				case '09': $str .= self::$language -> t ( 'template_date_09' );	break;
				case '10': $str .= self::$language -> t ( 'template_date_10' );	break;
				case '11': $str .= self::$language -> t ( 'template_date_11' );	break;
				case '12': $str .= self::$language -> t ( 'template_date_12' );	break;
			}
			
			$str .= ' '. (int)$parts [ 2 ];
			
			if ( $parts [ 2 ] >= 11 && $parts [ 2 ] <= 20 )
			{
				$day_last = 0;	
			}
			else 
			{
				$day_last = $parts [ 2 ] % 10;
			}
			switch ( $day_last )
			{
				default:
						$str .= self::$language -> t ( 'template_date_day_th' );
					break;
					
				case 1:
						$str .= self::$language -> t ( 'template_date_day_st' );
					break;
					
				case 2:
						$str .= self::$language -> t ( 'template_date_day_nd' );
					break;
					
				case 3:
						$str .= self::$language -> t ( 'template_date_day_rd' );
					break;
			}
			
			return $str;
   		}
   		
   		
		# Translates text
    	public static function translate ( $params ) 
    	{
    		# Allow using as modifier
    		if ( is_string ( $params ) ) 
    		{
    			$params = array ( 'k' => $params );
    			
    			$args = func_get_args();
    			unset ( $args [ 0 ] );
    		}
    		else 
    		{
 				if ( isset ( $params [ 'a' ] ) )
				{
					$args = explode ( '|', $params [ 'a' ] );
				} 
				else	 
				{	
					$args = array ();
				}
    		}
    		
			return self::$language -> t ( $params [ 'k' ], $args );
    	}
   		
    	
    	# Gets user status according to userinfo
    	public static function get_user_status ( $params )
    	{
    		return self::$user -> get_status ( $params [ 'info' ] );
    	}
    	
    	
   		# Format error code (using 'return false' line)
   		public static function err_line ()
   		{
   			return '(#'. error::get_line () .')';
   		}
}
?>