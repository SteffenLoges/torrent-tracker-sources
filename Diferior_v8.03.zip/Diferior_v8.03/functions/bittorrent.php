<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );

	
	// Encoding and decoding based off tbsource. Hats off.

	class bittorrent
	{
		
		private $encoded = null;
		
		
		public function _construct ()
		{
			
		}
		
		
		# Encodes element to bittorrent format
		public function encode ( $el )
		{
			$this -> encoded = null;
			$this -> encode_auto ( $el );
			$ret = $this -> encoded;
			unset ( $this -> encoded );
			return $ret;
		}
		
		
		# Detects type and encoding
		public function encode_auto ( $el )
		{
			if ( is_array ( $el ) )
			{
				if ( isset ( $el [ 0 ] ) || empty ( $el ) )
				{
					return $this -> encode_list ( $el );
				}
				else
				{
					return $this -> encode_dict ( $el );
				}
			}
			else 
			{
				return $this -> encode_entry ( $el );
			}
		}
		
		
		# Encodes list
		function encode_list ( $arr )
		{
			$this -> encoded .= 'l';
		
			# The empty list is defined as array ();
			if ( empty ( $arr ) )
			{
				$this -> encoded .= 'e';
				return;
			}
			
			for ( $i = 0; isset ( $arr [ $i ] ); $i++ )
			{
				$this -> encode_auto ( $arr [ $i ] );
			}
			
			$this -> encoded .= 'e';
		}

		
		# Encodes dictionary
		function encode_dict ( $arr )
		{
			$this -> encoded .= 'd';
			
			if ( is_bool ( $arr ) )
			{
				$this -> encoded .= 'e';
				return;
			}
			
			# NEED TO SORT!
			$arr2 = $this -> make_sorted ( $arr );
			
			foreach ( $arr2 as $k => $v )
			{
				$this -> encode_entry ( $k, true);
				$this -> encode_auto ( $v );
			}
			
			$this -> encoded .= 'e';
			
			return;
		}
		
		
		# Dictionary keys must be sorted. foreach tends to iterate over the order
		# the array was made, so we make a new one in sorted order. :)
		function make_sorted ( $arr )
		{
			$i = 0;
		
			# Shouldn't happen!
			if ( empty ( $arr ) )
			{
				return $array;
			}
		
			foreach ( $arr as $k => $v )
			{
				$keys [ $i++ ] = $k;
			}
			
			sort ( $keys );
			
			for ( $i = 0; isset ( $keys [ $i ] ); $i++ )
			{
				$return [ $keys [ $i ] ] = $arr [ $keys [ $i ] ];
			}
			
			return $return;
		}
		
		
		# Encodes strings, integers and empty dictionaries.
		# $unstrip is set to true when decoding dictionary keys
		function encode_entry( $el, $unstrip = false )
		{
			if ( is_bool ( $el ) )
			{
				$this -> encoded .= 'de';
				return;
			}
			
			if ( is_int ( $el ) || is_float ( $el ) )
			{
				$this -> encoded .= 'i'. $el .'e';
				return;
			}
			
			if ( $unstrip )
			{
				$el = stripslashes ( $el );
			}

			$len = strlen ( $el );
			$this -> encoded .= $len .':'. $el;
		}

		
		#######################################################################
		#######################################################################
		
		
		# Decodes bt string to array
		public function decode ( $str )
		{
			return $this -> decode_entry ( $str );
		}
		
		
		# Decodes entry
		function decode_entry ( $str, $offset = 0 )
		{
			if ( $str [ $offset ] == 'd' )
			{
				return $this -> decode_dict ( $str, $offset );
			}
			
			if ( $str [ $offset ] == 'l' )
			{
				return $this -> decode_list ( $str, $offset );
			}
			
			if ( $str [ $offset ] == 'i' )
			{
				$offset++;
				return $this -> decode_number ( $str, $offset );
			}
			
			# String value: decode number, then grab substring
			$info = $this -> decode_number ( $str, $offset );
			
			if ( $info [ 0 ] === false )
			{
				return array ( false );
			}
			
			$ret [ 0 ] = substr ( $str, $info [ 1 ], $info [ 0 ] );
			$ret [ 1 ] = $info [ 1 ] + strlen ( $ret [ 0 ] );
			
			return $ret;
		}	
		
		
		# Decodes dictionary
		function decode_dict ( $str, $offset = 0 )
		{
			if ( $str [ $offset ] == 'l' )
			{
				return $this -> decode_list ( $str, $offset );
			}
			
			if ( $str [ $offset ] != 'd' )
			{
				return false;
			}
			
			$ret = array ();
			
			$offset++;
			
			while ( true )
			{	
				if ( $str [ $offset ] == 'e' )
				{
					$offset++;
					break;
				}
				
				$left = $this -> decode_entry ( $str, $offset );
				
				if ( !$left [ 0 ] )
				{
					return false;
				}
				
				$offset = $left [ 1 ];
				
				if ( $str [ $offset ] == 'd' )
				{
					# Recurse
					$value = $this -> decode_dict ( $str, $offset );
					
					if ( !$value [ 0 ] )
					{
						return false;
					}
					
					$ret [ addslashes ( $left [ 0 ] ) ] = $value [ 0 ];
					
					$offset = $value [ 1 ];
					
					continue;
				}
				elseif ( $str [ $offset ] == 'l' )
				{
					$value = $this -> decode_list ( $str, $offset );
					
					if ( !$value [ 0 ] && is_bool ( $value [ 0 ] ) )
					{
						return false;
					}
					
					$ret [ addslashes ( $left [ 0 ] ) ] = $value [ 0 ];
					$offset = $value [ 1 ];
				}
				else
				{
		 			$value = $this -> decode_entry ( $str, $offset );
		 			
					if ( $value [ 0 ] === false )
					{
						return false;
					}
					
					$ret [ addslashes ( $left [ 0 ] ) ] = $value [ 0 ];
					
					$offset = $value [ 1 ];
				}
			}
			
			if ( empty ( $ret ) )
			{
				$final [ 0 ] = true;
			}
			else
			{
				$final [ 0 ] = $ret;
			}
			
			$final [ 1 ] = $offset;
		   	return $final;
		}
		
		
		# Decodes list
		function decode_list ( $str, $offset )
		{
			$i = 0;
			
			if ( $str [ $offset++ ] != 'l' )
			{
				return array ( false );
			}
			
			$ret = array ();
			
			while (true)
			{
				if ( $str [ $offset ] == 'e' )
				{
					break;
				}
				
				$value = $this -> decode_entry ( $str, $offset );
				
				if ( $value [ 0 ] === false )
				{
					return array(false);
				}
				
				$ret [ $i ] = $value [ 0 ];
				$offset = $value [ 1 ];
				$i ++;
			}

			# The empy list is an empty array. Seems fine.
			$final [ 0 ] = $ret;
			$final [ 1 ] = $offset +1;
			return $final;
		}

		
		# Decodes number
		function decode_number ( $str, $offset )
		{
			$ret [ 0 ] = 0;
		
			# Funky handling of negative numbers and zero
			$negative = false;
			
			if ( $str [ $offset ] == '-' )
			{
				$negative = true;
				$offset++;
			}
			
			if ( $str [ $offset ] == '0' )
			{
				$offset++;
				if ( $negative )
				{
					return array ( false );
				}
				
				if ( $str [ $offset ] == ':' || $str [ $offset ] == 'e' )
				{
					$offset++;
					$ret [ 0 ] = 0;
					$ret [ 1 ] = $offset;
					return $ret;
				}
				
				return array ( false );
			}
			
			while ( true )
			{		
				if ( $str [ $offset ] >= '0' && $str [ $offset ] <= '9' )
				{
					$ret [ 0 ] *= 10;
					
					# Added 2005.02.21 - VisiGod
		        	# Changing the type of variable from integer to double to prevent a numeric overflow     
		        	settype ( $ret [ 0 ], 'double' );
		        	   
		        	# Added 2005.02.21 - VisiGod
					$ret [ 0 ] += ord ( $str [ $offset ] ) - ord ( '0' );
					$offset++;
				}
				elseif ( $str [ $offset ] == 'e' || $str [ $offset ] == ':' )
				{
					# Tolerate : or e because this is a multiuse function
					$ret [ 1 ] = $offset +1;
					if ( $negative )
					{
						if ( $ret [ 0 ] == 0 )
						{
							return array ( false );
						}
						
						$ret [ 0 ] = -$ret [ 0 ];
					}
					return $ret;
				}
				else
				{
					return array ( false );
				}
			}
		}

		
		#######################################################################
		#######################################################################
		
		
		public function error ( $msg )
		{
			header ( 'Content-Type: text/plain' );
			header ( 'Pragma: no-cache' );
			echo $this -> encode ( array ( 'failure reason' => $msg ) );
			die ();
		}

		
		#######################################################################
		#######################################################################
		
		
		# Perform scrape on tracker
		public function scrape ( $url, $info_hash )
		{
			$info_hash_esc = urlencode ( $info_hash );
			
			# Remove http:// from url
			if ( preg_match ( "#^(\w+)://(.*)\$#i", $url, $m ) )
			{
				if ( strtolower ( $m [ 1 ] ) != 'http' )
				{
					return false;
				}
				else 
				{
					$url = $m [ 2 ];
				}	
			}
				
			ini_set ( 'default_socket_timeout', 5 ); 
			error::toggle_silent ( true );
			$cont = file_get_contents ( 'http://'. $url .'?info_hash='. $info_hash_esc );
			error::toggle_silent ( false );
			if ( $cont === false ) return false;
			
			$arr = $this -> decode ( $cont );
			$arr = $arr [ 0 ];
			
			return $arr;
		}
	}

?>