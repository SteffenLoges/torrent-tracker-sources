<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class comments
	{

		# Objects
		private $db, $text, $blog, $downloads;
		
		
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
			$this -> text = & core::get_object ( 'text' );	
			$this -> cache = & core::get_object ( 'cache' );	
			$this -> blog = & core::get_object ( 'blog' );	
			$this -> downloads = & core::get_object ( 'downloads' );	
		}
		
		
		# Gets comments
		public function get ( $post = null, $page = null, & $page_count = null, $table = 'blog_comments' )
		{
			if ( !is_numeric ( $post ) && $post != null )
			{
				return false;
			}
			
			# How many comments?
			if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'comments_no' ] == 0 )
				{
					$page_count = COMMENTS_PAGE;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'comments_no' ];
				}
				
				$from = $page * $page_count - $page_count;
				if ( $from < 0 )
				{
					return array ();	
				}
			}
			
			if ( $post != null )
			{
				# Build SQL
				$qr = "SELECT {$table}.id, {$table}.anonymous, {$table}.author, {$table}.email, {$table}.ip, {$table}.posted, {$table}.content,
							  users.pr_avatar, users.downloaded, users.uploaded, users.status, users.blogposts, users.downloadposts, 
							  users.comments, users.forumposts, users.banned, users.warned, users.registered
					   FROM ". $table ." 
					   		  LEFT JOIN users ON ({$table}.author = users.name)
					   WHERE {$table}.post='". $post ."' 
					   ORDER BY {$table}.id ". ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'comments_dir' ] == 0 ? null : 'DESC' ) ."
					   LIMIT ".$from.", ". $page_count;
			}
			else
			{
				# RSS feed
				if ( $table == 'blog_comments' )
				{
					$qr = "SELECT blog_comments.id, blog_comments.anonymous, blog_comments.author, blog_comments.email, blog_comments.ip,
								  blog_comments.posted, blog_comments.content,
								  blog_posts.plid, blog_posts.header, blog_categories.lid, blog_posts.comments, blog_posts.id AS bpid
						   FROM blog_comments
						   		LEFT JOIN blog_posts ON ( blog_comments.post = blog_posts.id )
						   		LEFT JOIN blog_categories ON ( blog_posts.cat = blog_categories.id )
						   ORDER BY blog_comments.id DESC 
						   LIMIT 20";
				}
				elseif ( $table == 'dl_comments' )
				{
					$qr = "SELECT dl_comments.id, dl_comments.anonymous, dl_comments.author, dl_comments.email, dl_comments.ip,
								  dl_comments.posted, dl_comments.content,
								  dl_downloads.plid, dl_downloads.header, dl_categories.lid, dl_subcategories.lid AS sublid, dl_downloads.comments, 
								  dl_downloads.fid AS bpid
						   FROM dl_comments
						   		LEFT JOIN dl_downloads ON ( dl_comments.post = dl_downloads.fid )
						   		LEFT JOIN dl_categories ON ( dl_downloads.cat = dl_categories.id )
						   		LEFT JOIN dl_subcategories ON ( dl_downloads.subcat = dl_subcategories.id )
						   ORDER BY dl_comments.id DESC 
						   LIMIT 20";
				}
				else 
				{
					return array ();	
				}
			}
			
			$res = $this -> db -> get_all ( $qr );
			
			# Zero comments
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			//$this -> cache -> save ( serialize ( $res ) );
			
			return $res;
		}
		
		
		# Posts comment
		public function post ( $post, $txt, $table )
		{
			# Validation
			if ( !is_numeric ( $post ) )
			{
				return false;
			}
			
			# Validate user
			if ( !isset ( $_SESSION [ 'logged' ] ) || $_SESSION [ 'logged' ] == false )
			{
				if ( !FUNC_ANONYMOUS_COMMENTS )
				{
					# Not logged in, anonymous comments disabled
					error::line(__LINE__);
					return false;
				}
				else 
				{
					# Anonymous comment	
					$anonymous = true;
					
					$l = & core::get_object ( 'language' );
					$user = & core::get_object ( 'user' );
					
					$err = array ();
					
					$user_p = trim ( $_POST [ 'c_user' ] );
					$email_p = trim ( $_POST [ 'c_email' ] );
					$captcha_p = trim ( $_POST [ 'captcha' ] );
					
					$strl_user = strlen ( $user_p );
			
					if ( $strl_user < 3 || $strl_user > 20 )
						$err [] = $l -> t ( 'user_username_len' );
					
					if ( !$this -> text -> validate ( $user_p, 'username' ) )
						$err [] = $l -> t ( 'user_username_symbols' );
				
					if ( !$this -> text -> validate ( $email_p, 'email' ) || strlen ( $email_p ) > 32 )
						$err [] = $l -> t ( 'user_email_invalid' );
						
					if ( $user -> user_exists ( $user_p ) )
						$err [] = $l -> t ( 'comments_anonymous_reg_username' );
						
					# Captcha
					$err2 = $user -> validate_captcha ( $captcha_p );
					$err = array_merge ( $err, $err2 );	
						
					if ( empty ( $err ) )
					{
						setcookie ( 'comments_user', $user_p, time () + 86400, '/', SESS_COOKIE_DOMAIN );
						setcookie ( 'comments_email', $email_p, time () + 86400, '/', SESS_COOKIE_DOMAIN );
						$author = $user_p;
					}
					else 
					{
						return $err;	
					}
				}
			}
			else 
			{
				# Logged in user
				$anonymous = false;
				$author = $_SESSION [ 'user' ];
			}
			
			if ( $table == 'blog_comments' && !$this -> blog -> post_exists ( $post ) )
			{
				error::line(__LINE__);
				return false;
			}
			elseif ( $table == 'dl_comments' && !$this -> downloads -> dl_exists ( $post ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			$data = array (
				'post' => $post,
				'anonymous'	=>	$anonymous,
				'author' => $author,
				'email'	=>	( $anonymous ? $email_p : null ),
				'ip'	=>	$_SERVER [ 'REMOTE_ADDR' ],
				'posted' => time (),
				'content' => $this -> db -> escape ( substr ( $txt, 0, COMMENT_LIMIT_LEN ) ),
			);
			
			$id = $this -> db -> insert_array ( $table, $data );	
			
			if ( $id == 0 )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Updates number of comments in parent entry
			if ( $table == 'blog_comments' )
			{
				$this -> db -> update ( "UPDATE blog_posts". ( !$anonymous ? ", users" : null ) ."
									     SET blog_posts.comments=blog_posts.comments+1". ( !$anonymous ? ", users.comments=users.comments+1" : null ) ."
									     WHERE blog_posts.id='". $post ."'". ( !$anonymous ? " AND users.name='". $_SESSION [ 'user' ] ."'" : null ) );
			}
			elseif ( $table == 'dl_comments' )
			{
				$this -> db -> update ( "UPDATE dl_downloads". ( !$anonymous ? ", users" : null ) ."
									     SET dl_downloads.comments=dl_downloads.comments+1". ( !$anonymous ? ", users.comments=users.comments+1" : null ) ."
									     WHERE dl_downloads.fid='". $post ."'". ( !$anonymous ? " AND users.name='". $_SESSION [ 'user' ] ."'" : null ) );
			}
			else 
			{
				throw new error ( 'Invalid comment table.' );
			}
			
			return $id;
		}
		
		
		# Deletes comments
		public function delete ( $ids, $post, $table )
		{
			# Validation
			if ( !is_numeric ( $post ) )
			{
				error::line(__LINE__);
				return 0;
			}
			
			if ( empty ( $ids ) )
			{
				error::line(__LINE__);
				return 0;	
			}
			
			if ( $table == 'blog_comments' && !$this -> blog -> post_exists ( $post ) )
			{
				error::line(__LINE__);
				return 0;
			}
			elseif ( $table == 'dl_comments' && !$this -> downloads -> dl_exists ( $post ) )
			{
				error::line(__LINE__);
				return 0;
			}
			
			# Construct WHERE query
			$where = "id='";
			foreach ( $ids as $v )
			{
				if ( !is_numeric ( $v ) )
				{
					error::line(__LINE__);
					return 0;	
				}	
				else 
				{
					$where .= $v ."' OR id='";
				}
			}
			$where = substr ( $where, 0, -9 );
			$where .= "'";
			
			$qr = 'DELETE FROM '. $table .' WHERE '. $where;
			
			$affected = $this -> db -> delete ( $qr );
			
			if ( $affected == 0 )
			{
				error::line(__LINE__);
				return 0;	
			}
			
			# Updates number in parent entry
			$this -> db -> update ( 'UPDATE '. ( $table == 'blog_comments' ? 'blog_posts' : 'dl_downloads' ) ."
								     SET comments=comments-". $affected ."
								     WHERE ". ( $table == 'dl_comments' ? 'f' : null ) ."id='". $post ."'" );
			
			return $affected;
		}
		
				
		# Retrieves latest comments
		public function get_last ( $number = 5 )
		{		
			# Initialize cache
			$this -> cache -> init ( 'infobanner_comments', 60, CACHE_INFOBANNER );	
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				# Gets cached result
				$res = unserialize ( $cached );	
			}
			else 
			{
				$qr = '(SELECT dl_comments.posted, dl_comments.author, dl_downloads.plid, dl_downloads.header, dl_categories.lid, dl_subcategories.lid AS sublid
					   FROM dl_comments
							LEFT JOIN dl_downloads ON ( dl_comments.post = dl_downloads.fid )
							LEFT JOIN dl_categories ON ( dl_downloads.cat = dl_categories.id )
							LEFT JOIN dl_subcategories ON ( dl_downloads.subcat = dl_subcategories.id ))
					   UNION
					   (SELECT blog_comments.posted, blog_comments.author, blog_posts.plid, blog_posts.header, blog_categories.lid, \'\'
					   FROM blog_comments
					   		LEFT JOIN blog_posts ON ( blog_comments.post = blog_posts.id )
					   		LEFT JOIN blog_categories ON ( blog_posts.cat = blog_categories.id ))
				       ORDER BY posted DESC
				       LIMIT '. $number;
				$res = $this -> db -> get_all ( $qr );
				
				if ( CACHE_INFOBANNER )
				{
					$this -> cache -> save ( serialize ( $res ) );
				}
			}
			
			return $res;
		}
	}

?>