<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	class pm
	{

		# DB object
		private $db;
		
		
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
		}
		
		
		# Gets PMs
		public function get_list ( $page, & $page_count )
		{
			# Number of messages to retrieve
			//if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'private_no' ] == 0 )
				{
					$page_count = PM_PAGE;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'private_no' ];
				}
				
				$from = $page * $page_count - $page_count;
			}
			
			$qr = "SELECT id, unread, `from`, title, tstamp FROM private WHERE `to`='". $_SESSION [ 'user' ] ."' ORDER BY tstamp DESC LIMIT ". $from .', '. $page_count;
			
			$res = $this -> db -> get_all ( $qr );
			
			return $res;
		}
		
		
		# Get single PM
		public function get ( $id, $mark = true )
		{
			# PM id okay?
			if ( !is_numeric ( $id ) )
			{
				error::line(__LINE__);
				return false;
			}	
			
			# Gets PM
			$qr = "SELECT unread, `from`, `to`, title, content, tstamp FROM private WHERE id='". $id ."'";
			$res = $this -> db -> get_row ( $qr );
			
			if ( !$res )
			{
				# PM does not exist
				error::line(__LINE__);
				return false;
			}
			
			if ( strtolower ( $res [ 'to' ] ) != strtolower ( $_SESSION [ 'user' ] ) )
			{
				# PM sent to somebody else
				//throw new error ( 'Respect privacy, you douche' ); // Extreme measure
				error::line(__LINE__);
				return false;
			}
			
			# Mark as read if needed
			if ( $mark && $res [ 'unread' ] === '1' )
			{
				$upd = $this -> db -> update ( 'UPDATE private SET unread=0 WHERE id='. $id );	
				if ( $upd && $_SESSION [ 'userinfo' ] [ 'private_new' ] > 0 ) 
				{
					$pm_no = $_SESSION [ 'userinfo' ] [ 'private_new' ] -1;
					core::get_object ( 'user' ) -> update ( array ( 'private_new' => $pm_no ) );
				}
			}
			
			return $res;
		}
		
		
		# Send PM
		public function send ( $to, $title, $text )
		{
			$user = & core::get_object ( 'user' );
			
			$to = $this -> db -> escape ( $to );
			$title = $this -> db -> escape ( $title );
			$text = $this -> db -> escape ( $text );
			$text = substr ( $text, 0, PM_LIMIT_LEN );
			
			# Title and text filled?
			if ( trim ( $title ) == null || trim ( $text ) == null )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Make sure user exists and we're not trying to PM ourselves
			$userinfo = $user -> user_exists ( $to );
			if ( !$userinfo || strtolower ( $to ) == strtolower ( $_SESSION [ 'user' ] ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			# PM box not full?
			if ( $userinfo [ 'private_total' ] >= PM_LIMIT )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Everything OK, send PM
			$qr = "INSERT INTO private SET unread=1, `from`='". $_SESSION [ 'user' ] ."', `to`='". $to ."', title='". $title ."', content='". $text ."', tstamp='". time () ."'";
			$res = $this -> db -> insert ( $qr );
			
			# Inserted, update counter
			if ( $res )
			{
				$this -> db -> update ( "UPDATE users SET private_new=private_new+1, private_total=private_total+1 WHERE name='". $to ."'" );
				core::get_object ( 'user' ) -> update ( array ( 'last_pm' => time () ) );
			}
			else 
			{
				error::line(__LINE__);
				return false;
			}
			
			# All done
			return true;
		}
		
		
		# Delete PM
		public function delete ( $id )
		{
			# PM okay?
			if ( !$this -> get ( $id ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			$qr = "DELETE FROM private WHERE id='". $id ."' AND `to`='". $_SESSION [ 'user' ] ."'";
			$res = $this -> db -> delete ( $qr );
			
			if ( $res )
			{
				$pmno = $_SESSION [ 'userinfo' ] [ 'private_total' ] -1;
				core::get_object ( 'user' ) -> update ( array ( 'private_total' => $pmno ) );
				return true;	
			}
			else 
			{
				return false;	
			}
		}
		
		
		# Delete all PMs
		 # `$unread = false` won't delete unread PMs
		public function delete_all ( $unread = false )
		{
			$qr = "DELETE FROM private WHERE `to`='". $_SESSION [ 'user' ] ."'". ( $unread == false ? ' AND unread=0' : null );
			$res = $this -> db -> delete ( $qr );
			
			if ( $res )
			{
				if ( $unread == true )
				{
					$pmno = 0;
				}
				else 
				{
					$pmno = $_SESSION [ 'userinfo' ] [ 'private_total' ] - $res;
				}
				core::get_object ( 'user' ) -> update ( array ( 'private_total' => $pmno ) );
				return true;	
			}
			else 
			{
				return false;	
			}
		}
		
	}
	
?>