<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class downloads
	{

		# Objects
		private $db, $cache, $text, $bittorrent, $user;
		
		
		public function __construct ()
		{
			$this -> db = & core::get_object ( 'db' );
			$this -> cache = & core::get_object ( 'cache' );
			$this -> text = & core::get_object ( 'text' );
			$this -> bittorrent = & core::load_file ( 'bittorrent' );
			$this -> user = & core::get_object ( 'user' );
		}
		
		
		# Get categories
		public function get_cats ( $incl_subcats = false )
		{
			# Including subcategories
			if ( $incl_subcats )
			{
				$this -> cache -> init ( 'menu_dl_inclsub', 1800 );
				$cached = $this -> cache -> get ();
				if ( $cached === false )
				{
					$cats = $this -> get_cats ();
					$subcats = $this -> get_subcats ();	
					
					$res = array ();
					
					foreach ( $cats as $k => $v )
					{
						# Copy entry
						$res [ $k ] = $v;
						
						# Look for subcats
						foreach ( $subcats as $ks => $vs )
						{
							if ( $vs [ 'cat' ] == $v [ 'id' ] )
							{
								# Eureka
								$res [ $k ] [ 'subcats' ] [] = $vs;	
							}	
						}
					}
					
					$this -> cache -> save ( serialize ( $res ) );
				}
				else 
				{
					$res = unserialize ( $cached );	
				}
				
				return $res;
			}
			else 
			{
				# No subcats
				//$this -> cache -> init ( 'menu_dl', 1800 );
				//$res = $this -> cache -> get ();
				//if ( $res === false )
				//{
					$res = $this -> db -> get_all ( "SELECT lid, name, color, id FROM dl_categories ORDER BY position" );
					$this -> cache -> save ( serialize ( $res ) );
				//}
				//else 
				//{
				//	$res = unserialize ( $res );	
				//}
				
				return $res;
			}
		}
		
		
		# Get subcategories
		public function get_subcats ( $cat = null )
		{
			if ( $cat != null )
			{
				$this -> cache -> init ( 'menu_dl_sub_'. $cat, 1800 );
				$res = $this -> cache -> get ();
			}
			
			if ( $cat == null || $res === false )
			{
				$res = $this -> db -> get_all ( "SELECT lid, name, id, cat FROM dl_subcategories ". ( $cat != null ? "WHERE cat='". $cat ."'" : null ) ." ORDER BY position" );
				
				if ( $cat == null )
				{
					return $res;
				}
				
				$this -> cache -> save ( serialize ( $res ) );
			}
			else 
			{
				$res = unserialize ( $res );	
			}
			
			return $res;
		}
		
		
		# Get numeric cat id (or some other, depending on argument) from literal
		public function get_cat_info ( $cat, $field = 'id' )
		{
			if ( $cat != null )
			{
				$cat = $this -> db -> get_one ( "SELECT ". $field ." FROM dl_categories WHERE lid='". $cat ."'" );	
				
				# Category does not exist
				if ( $this -> db -> num_rows () == 0 )
				{
					return null;	
				}
			}
			
			return $cat;
		}
		
		
		# Get numeric subcat id (or some other, depending on argument) from literal
		public function get_subcat_info ( $subcat, $cat, $field = 'id' )
		{
			if ( $subcat != null )
			{
				$subcat = $this -> db -> get_one ( "SELECT ". $field ." FROM dl_subcategories WHERE cat='". $cat ."' AND lid='". $subcat ."'" );
				
				# Category does not exist
				if ( $this -> db -> num_rows () == 0 )
				{
					return null;	
				}
			}
			
			return $subcat;
		}
			
		
		# Get downloads list
		public function get ( $cat = null, $subcat = null, $page = null, $sort = null, $desc = true, & $cat_subcat = null, & $page_count = null, $extra = null )
		{
			# How many entries to retrieve
			if ( $page != null )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'downloads_no' ] == 0 )
				{
					$page_count = DL_POSTS;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'downloads_no' ];
				}
				
				$from = $page * $page_count - $page_count;
			}
			
			# Show all cats
			if ( $cat == 'all' )
			{
				$cat = null;	
			}
			
			if ( $cat != null && !$this -> text -> validate ( $cat, 'lid' ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Show all subcats
			if ( $subcat == 'all' )
			{
				$subcat = null;	
			}
			
			if ( $subcat != null && !$this -> text -> validate ( $subcat, 'lid' ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Init cache
			$this -> cache -> init ( 'get_downloads_'. $cat .'_'. $subcat .'_'. ( $page != null ? '_'. $page : null ), 120 );
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				# Return cached result
				return unserialize ( $cached );	
			}
			
			# Get numeric cat and subcat ids
			$cat = $this -> get_cat_info ( $cat );
			$subcat = $this -> get_subcat_info ( $subcat, $cat );
			$cat_subcat = array ( $cat, $subcat );
			
			# Downloads type (http/torrents)
			$cat_browse = $this -> get_cat_browse_sql ( $cat );
			
			# Sorting
			if ( !is_bool($desc) ) $desc = false;
			switch ( $sort )
			{
				default:
						$order = 'dl.posted DESC';	
					break;
					
				case 'id':
						$order = 'dl.fid'. ($desc?' DESC':null);
					break;
				
				case 'type':
						$order = 'dl.'. ($desc?'dl_links':'info_hash') .' DESC, dl.fid DESC';
					break;		
					
				case 'header':
				case 'seeders':
				case 'leechers':
				case 'fsize':
				case 'comments':
				case 'user':
						$order = 'dl.'. $sort . ($desc?' DESC':null);
					break;	
			}
			
			# Build and run SQL query
			$qr = "SELECT dl_categories.name, dl_categories.lid, dl_subcategories.name AS sub_name, dl_subcategories.lid AS sub_lid,
						  dl.fid, dl.plid, dl.posted,
						  dl.header, dl.subheader, dl.user, dl.anonymous, dl.comments, 
						  dl.dl_links, dl.leechers, dl.seeders, dl.info_hash, dl.fsize, dl.tags 
						  ". $extra ."
				   FROM dl_downloads AS dl
				   		LEFT JOIN dl_categories ON ( dl.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl.subcat = dl_subcategories.id )
				   	WHERE confirmed='1'
				   ". ( $cat != null ? "AND dl.cat='". $cat ."'" : null ) ." 
				   ". ( $subcat != null ? "AND dl.subcat='". $subcat ."'" : null ) ." 
				   ". $cat_browse ."
				   ORDER BY ". $order ."
				   ". ( $page != null ? "LIMIT {$from}, ". $page_count : null );
			
			$res = $this -> db -> get_all ( $qr );
			
			# No posts
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			$this -> cache -> save ( serialize ( $res ) );
			
			return $res;
		}
		
		
		# Get downloads count in categories
		public function get_count ( $cat = null, $subcat = null )
		{
			# Get numeric cat and subcat ids
			if ( $cat == 'all' ) $cat = null;
			if ( $cat != null && !is_numeric ( $cat ) )
			{
				$cat = $this -> get_cat_info ( $cat );
			}
			
			if ( $subcat == 'all' ) $subcat = null;
			if ( $subcat != null && !is_numeric ( $subcat ) )
			{
				$subcat = $this -> get_subcat_info ( $subcat, $cat );
			}
			
			# Downloads type (http/torrents)
			$cat_browse = $this -> get_cat_browse_sql ( $cat );
			
			# Get downloads count
			$ret = $this -> db -> get_one ( "SELECT COUNT(*) FROM dl_downloads
											WHERE confirmed='1'
											". ( $cat != null ? " AND cat='". $cat ."'" : null ) . 
											   ( $subcat != null ? " AND subcat='". $subcat ."'" : null ) .
											   $cat_browse
										  );
			
			return $ret;
		}
		
		
		# Downloads type (http/torrents)
		public function get_cat_browse_sql ()
		{
			#  0 - all
			#  1 - torrentai
			#  2 - http
			$type = ( isset ( $_SESSION [ 'preferences' ] ) ? $_SESSION [ 'preferences' ] [ 'downloads_type' ] : 0 );
			
			# Admin override
			if ( !FUNC_DOWNLOADS_TORRENT ) $type = 2;
			if ( !FUNC_DOWNLOADS_HTTP ) $type = 1;
			
			if ( $type != 0 )
			{
				$cat_browse = 'AND ';
				
				if ( $type == 1 )
				{
					$cat_browse .= 'info_hash!=\'\'';
				}
				elseif ( $type == 2 )
				{
					$cat_browse .= 'dl_links!=\'\'';
				}
			}
			else 
			{
				$cat_browse = null;	
			}
			
			return $cat_browse;
		}
		
		
		# Get download
		public function get_dl ( $name, $cat, $subcat, $scrape = false )
		{
			if ( !$this -> text -> validate ( $name, 'plid' ) || !$this -> text -> validate ( $cat, 'lid' ) || !$this -> text -> validate ( $subcat, 'lid' ) )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Get numeric cat and subcat ids
			$cat = $this -> get_cat_info ( $cat );
			$subcat = $this -> get_subcat_info ( $subcat, $cat );
			
			# Build and run SQL query
			$qr = "SELECT dl_categories.name, dl_categories.lid, dl_subcategories.name AS sub_name, dl_subcategories.lid AS sub_lid,
						  dl.fid, dl.plid, dl.posted, dl.updated, dl.content,
						  dl.header, dl.subheader, dl.user, dl.anonymous, dl.comments, dl.nfo,
						  dl.dl_links, dl.leechers, dl.seeders, dl.last_scrape, dl.info_hash, dl.fsize, dl.completed, dl.files,
						  ". $cat ." AS cat, ". $subcat ." AS subcat, dl.confirmed, dl.tags
				   FROM dl_downloads AS dl
				   		LEFT JOIN dl_categories ON ( dl.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl.subcat = dl_subcategories.id )
				   WHERE dl.cat='". $cat ."' AND dl.plid='". $name ."' AND dl.subcat='". $subcat ."'
				   LIMIT 1";
			
			$res = $this -> db -> get_row ( $qr );
			
			# Post does not exist
			if ( $this -> db -> num_rows () == 0 )
			{
				error::line(__LINE__);
				return false;
			}
			
			# Refresh number of peers if needed (every 30 min)
			if ( $scrape && $res [ 'info_hash' ] != null && $res [ 'last_scrape' ] + 1800 < time () )
			{
				# Scraping
				if ( PERFORM_SCRAPE && SCRAPE_URL != TRACKER_URL )
				{
					$stats = $this -> bittorrent -> scrape ( SCRAPE_URL, $res [ 'info_hash' ] );
					
					if ( $stats !== false )
					{
						$stats = $stats [ 'files' ] [ $res [ 'info_hash' ] ];
						$res [ 'seeders' ] = $stats [ 'complete' ];
						$res [ 'leechers' ] = $stats [ 'incomplete' ];
					}
					else 
					{
						$res [ 'seeders' ] = 0;
						$res [ 'leechers' ] = 0;
					}
					
					$this -> db -> update ( "UPDATE dl_downloads SET seeders='". $res [ 'seeders' ] ."', leechers='". $res [ 'leechers' ] ."', last_scrape='". time () ."' WHERE info_hash='". $res [ 'info_hash' ] ."'" );	
				}
				# PHP tracker
				elseif ( TRACKER_TYPE == 'PHP' )
				{
					$stats = $this -> db -> get_all ( "SELECT `left` FROM xbt_files_users WHERE fid='". $res [ 'fid' ] ."' AND active='1'" );
					
					if ( $stats !== false )
					{
						$res [ 'seeders' ] = 0;
						$res [ 'leechers' ] = 0;
						foreach ( $stats as $v )
						{
							if ( $v [ 'left' ] == 0 )
							{
								$res [ 'seeders' ]++;
							}
							else 
							{
								$res [ 'leechers' ]++;	
							}	
						}
					}
					else 
					{
						$res [ 'seeders' ] = 0;
						$res [ 'leechers' ] = 0;
					}
					
					$this -> db -> update ( "UPDATE dl_downloads SET seeders='". $res [ 'seeders' ] ."', leechers='". $res [ 'leechers' ] ."', last_scrape='". time () ."' WHERE info_hash='". $res [ 'info_hash' ] ."'" );	
				}	
			}
			
			# Unconfirmed download
			if ( $res [ 'confirmed' ] != 1 && 
					( 
						( !isset ( $_SESSION [ 'user' ] ) || $res [ 'user' ] != $_SESSION [ 'user' ] ) 
						&&
						( !isset ( $_SESSION [ 'permissions' ] ) || $_SESSION [ 'permissions' ] [ 'approve_downloads' ] != 1 ) 
					) 
				)
			{
				error::line(__LINE__);
				return false;
			}
			
			return $res;	
		}
		
		
		# Get peer list
		public function get_peers ( $fid, $type = null )
		{
			if ( !is_numeric ( $fid ) )
			{
				error::line(__LINE__);
				return false;	
			}
			
			switch ( $type )
			{
				default: $type_sql = null; break;
				case 'seeders': $type_sql = 'AND xbt_files_users.left=0'; break;
				case 'leechers': $type_sql = 'AND xbt_files_users.left>0'; break;
			}
			
			$qr = "SELECT users.name, 
						  xbt_files_users.downloaded, xbt_files_users.uploaded, xbt_files_users.left
				   FROM xbt_files_users
				   		LEFT JOIN users ON ( users.uid = xbt_files_users.uid )
				   WHERE xbt_files_users.fid='". $fid ."' AND xbt_files_users.active=1 ". $type_sql ."
				   ORDER BY xbt_files_users.mtime DESC
				   LIMIT ". TRACKER_PEER_MAX;
			
			$res = $this -> db -> get_all ( $qr );
			
			if ( $type == 'seeders' || $type == 'leechers' )
			{
				return $res;	
			}
			
			$seeders = array ();
			$leechers = array ();
			
			foreach ( $res as $v )
			{
				if ( $v [ 'left' ] == 0 )	
				{
					$seeders [] = $v;
				}
				elseif ( $v [ 'left' ] > 0 )
				{
					$leechers [] = $v;
				}
			}
			
			return array (
							'seeders' => $seeders,
							'leechers' => $leechers,
						);
		}
		
		
		# Get path to .torrent file
		public function get_torrent_path ( $cat, $subcat, $file )
		{
			if ( strlen ( $file ) < 3 ) 
			{
				error::line(__LINE__);
				return false;
			}
			
			$path = DIR_TORRENT .'/'. $cat .'/'. $subcat .'/'. $file [ 0 ] .'/'. $file [ 1 ] .'/'. $file [ 2 ] .'/'. $file .'.torrent';
			
			return $path;
		}
		
		
		# Output torrent by changing announce_url and comment
		public function output_torrent ( $path, $torrent_pass, $bitlet = false, $cat = null, $subcat = null, $plid = null )
		{
			# Duh
			if ( !file_exists ( $path ) )
			{
				error::line(__LINE__);
				return false;	
			}
			
			# If confirmed
			if ( $cat != null && $subcat != null && $plid != null )
			{
				$cat = $this -> get_cat_info ( $cat );
				$subcat = $this -> get_subcat_info ( $subcat, $cat );
				$res = $this -> db -> get_row ( "SELECT user, confirmed FROM dl_downloads WHERE cat='". $cat ."' AND plid='". $plid ."' AND subcat='". $subcat ."'" );
				
				# Unconfirmed
				if ( $res [ 'confirmed' ] != 1 && 
						( 
							( !isset ( $_SESSION [ 'user' ] ) || $res [ 'user' ] != $_SESSION [ 'user' ] ) 
							&&
							( !isset ( $_SESSION [ 'permissions' ] ) || $_SESSION [ 'permissions' ] [ 'approve_downloads' ] != 1 ) 
						) 
					)
				{
					throw new error ( core::get_object ( 'language' ) -> t ( 'downloads_err_unconfirmed' ) );	
				}
			}
			
			$content = file_get_contents ( $path );
			
    		$c_arr = $this -> bittorrent -> decode ( $content );
    		$c_arr = $c_arr [ 0 ];

    		if ( $bitlet )
    		{
    			# Calculate filesize and generate filelist
				if ( !isset ( $c_arr [ 'info' ] [ 'files' ] ) )
				{
					# Single file
					$fsize = $c_arr [ 'info' ] [ 'length' ];
				}
				else 
				{
					# Filelist
					$fsize = 0;
					foreach ( $c_arr [ 'info' ] [ 'files' ] as $v )
					{
						$fsize += $v [ 'length' ];
					}
				}
				
				if ( $fsize > BITLET_FSIZE )
				{
					throw new error ( core::get_object ( 'language' ) -> t ( 'downloads_err_bitlet_notorrent' ) );	
				}
    		}
    		
			# Set announce url
			if ( isset ( $c_arr [ 'announce-list' ] ) ) unset ( $c_arr [ 'announce-list' ] );
    		//$c_arr [ 'announce' ] = TRACKER_URL .'/'. ( $torrent_pass != null ? $torrent_pass .'/' : null ) .'announce';
    		$announce = str_replace ( '{torrent_pass}', ( $torrent_pass != null ? $torrent_pass : null ), TRACKER_URL );
    		$announce = preg_replace ( '#/{2,}#', '/', $announce );
    		$announce = str_replace ( ':/', '://', $announce );
    		$c_arr [ 'announce' ] = $announce;
			
			# Set comment
			$c_arr [ 'comment' ] = TORRENT_COMMENT;
			$c_arr [ 'comment.utf-8' ] = TORRENT_COMMENT;
    		
    		$content = $this -> bittorrent -> encode ( $c_arr );

    		$f = substr ( $path, strrpos ( $path, '/' ) +1 );
    		
    		header ( 'Content-Type: application/x-bittorrent' );
    		header ( 'Content-Disposition: attachment; filename="'. $f .'"' );
    		header ( 'Content-Length: '. strlen ( $content ) );
    		
    		echo $content;
    		
    		die ();
		}
		
		
		# Add download
		public function new_download ( $subcat, $header, $subheader, $text, $links, $anonymous, $confirmed, $tags = null )
		{
			# Halt if null
			if ( $subcat == null || $header == null ) 
			{
				error::line(__LINE__);
				return false;
			}
			
			# Escape variables
			$header = $this -> db -> escape ( $header );
			$subheader = $this -> db -> escape ( $subheader );
			$text = $this -> db -> escape ( $text );
			$links = $this -> db -> escape ( $links, false, true, true );	
			
			# Cat, subcat id
			if ( !is_numeric ( $subcat ) ) 
			{
				error::line(__LINE__);
				return false;
			}
			$cat = $this -> db -> get_row ( "SELECT dl_subcategories.cat, dl_categories.lid, dl_subcategories.lid AS sublid 
											 FROM dl_subcategories
											 	LEFT JOIN dl_categories ON ( dl_categories.id=dl_subcategories.cat )
											 WHERE dl_subcategories.id='". $subcat ."'" );
			if ( !$cat )
			{
				error::line(__LINE__);
				return false;	
			}
			
			$cat [ 'subcat' ] = $subcat;
			
			# Author
			$author = $_SESSION [ 'user' ];	
			
			# Filesize
			$fsize = 0;
			
			# Takes care of .torrent file
			$info_hash = $this -> upload_torrent ( $cat, $plid, $fsize, $flist );
			
			if ( $info_hash === false ) 
			{
				error::line(__LINE__);
				return false;	
			}
			
			# Nor .torrent nor http links available
			if ( $info_hash == null && $links == null )
			{
				error::line(__LINE__);
				return false;	
			}
			
			# Remove unneeded whitespace in links and calculate http links filesize
			if ( $links != null )
			{
				$links = str_replace ( "\r", null, $links );
				$links = preg_replace ( "#\n{2,}#", "\n", $links );
				if ( $info_hash == null )
				{
					$fsize = $this -> get_links_fsize ( $links );
				}
			}
			
			if ( $info_hash == null )
			{
				# Plid
				$plid = $this -> text -> make_lid ( $header );
			
				# Checks if plid is available
				$this -> check_plid ( $plid, $cat [ 'cat' ], $cat [ 'subcat' ] );
				
				# Filelist
				$flist = null;
			}
			
			$nfo = $this -> upload_nfo ();
			
			//$cat = $cat [ 'cat' ];
			
			# Prepare tags
			$blog = & core::get_object ( 'blog' );
			$tags_str = $blog -> prepare_tags ( $tags );
			
			# Query
			$qr = "INSERT INTO dl_downloads SET 
					confirmed='". ( $confirmed ? '1' : '0' ) ."',
					cat='". $cat [ 'cat' ] ."', subcat='". $subcat ."', plid='". $plid ."', 
					posted='". time () ."', updated='0', 
					header='". $header ."', subheader='". $subheader ."', user='". $author ."', anonymous='". ( $anonymous ? '1' : '0' ) ."',
					content='". $text ."', comments='0', nfo='". $nfo ."', 
					dl_links='". $links ."', info_hash='". $info_hash ."', 
					fsize='". $fsize ."', files='". $flist ."'"
			   		. ( FUNC_TAGS ? ", tags='". $tags_str ."'" : null );

			# So far so good, files uploaded, insert SQL
			$res = $this -> db -> insert ( $qr );
			
			if ( $res != 0 )
			{
				# Clear cache
				$this -> cache -> remove ( 'get_downloads___1' );
				$this -> cache -> remove ( 'get_posts_downloads_1' );
				
				# Update userinfo
				$dp = $_SESSION [ 'userinfo' ] [ 'downloadposts' ] +1;
				$this -> user -> update ( array ( 'downloadposts' => $dp ) );
				
				if ( $info_hash != null )
				{
					return core::get_object('url') -> make ( 'torrents', $cat [ 'lid' ], $cat [ 'sublid' ], $plid .'.torrent' );
				}
				else 
				{
					return true;	
				}
			}
			else 
			{
				error::line(__LINE__);
				return false;
			}
		}
		
		
		# Edit download
		public function edit_download ( $id, $subcat, $header, $subheader, $text, $links, $plid, $lid, $lid_id, $sublid, $sublid_id, $anonymous, $tags = null, &$returninfo = null )
		{
			# Halt if null
			if ( $subcat == null || $header == null ) 
			{
				error::line(__LINE__);
				return false;
			}
			
			# Escape variables
			$header = $this -> db -> escape ( $header );
			$subheader = $this -> db -> escape ( $subheader );
			$text = $this -> db -> escape ( $text );
			$links = $this -> db -> escape ( $links, false, true, true );	
			
			# Cat, subcat id
			if ( !is_numeric ( $subcat ) ) 
			{
				error::line(__LINE__);
				return false;
			}
			$cat = $this -> db -> get_row ( "SELECT dl_subcategories.cat, dl_categories.lid, dl_subcategories.lid AS sublid 
											 FROM dl_subcategories
											 	LEFT JOIN dl_categories ON ( dl_categories.id=dl_subcategories.cat )
											 WHERE dl_subcategories.id='". $subcat ."'" );
			if ( !$cat )
			{
				error::line(__LINE__);
				return false;	
			}
			
			$cat [ 'subcat' ] = $subcat;
			
			# Author
			//$author = $_SESSION [ 'user' ];	
			
			# Get info_hash and other info
			$info = $this -> db -> get_row ( "SELECT info_hash, plid, cat, subcat, header, nfo, confirmed FROM dl_downloads WHERE fid='". $id ."'" );
			
			if ( !$info )
			{
				error::line(__LINE__);
				return false;	
			}
			
			# Neither .torrent not http links available
			if ( $info [ 'info_hash' ] == null && $links == null )
			{
				error::line(__LINE__);
				return false;		
			}
			
			# Remove unneeded whitespace and calculate http links filesize
			if ( $links != null )
			{
				$links = str_replace ( "\r", null, $links );
				$links = preg_replace ( "#\n{2,}#", "\n", $links );
				if ( $info [ 'info_hash' ] == null )
				{
					$fsize = $this -> get_links_fsize ( $links );
				}
			}
			
			$plid_old = $plid;
			
			if ( $info [ 'info_hash' ] == null )
			{
				# Takes care of .torrent file
				$info_hash = $this -> upload_torrent ( $cat, $info [ 'plid' ], $fsize, $flist );
				
				if ( $info_hash === false ) 
				{
					error::line(__LINE__);
					return false;	
				}
				
				$new_torrent = true;
			}
			else 
			{
				$info_hash = $info [ 'info_hash' ];	
			}
			
			if ( $info_hash == null )
			{
				# Plid
				$plid = $this -> text -> make_lid ( $header );
			
				# Checks if plid is available
				if ( !preg_match ( "#^". $plid ."(\-[0-9]+)?\$#", $info [ 'plid' ] ) || $cat [ 'cat' ] != $info [ 'cat' ] || $subcat != $info [ 'subcat' ] )
				{
					$this -> check_plid ( $plid, $cat [ 'cat' ], $cat [ 'subcat' ] );
				}
				else 
				{
					$plid = $info [ 'plid' ];	
				}
			}
			else 
			{
				$plid = $info [ 'plid' ];
			}
			
			$nfo = $this -> upload_nfo ();
			
			if ( $info [ 'nfo' ] != null && $nfo != null )
			{
				$path = DIR_NFO .'/'. $info [ 'nfo' ] [ 0 ] .'/'. $info [ 'nfo' ] [ 1 ] .'/'. $info [ 'nfo' ] [ 2 ] .'/'. $info [ 'nfo' ] .'.nfo';
				if ( file_exists ( $path ) )
				{
					unlink ( $path );	
				}
			}
			
			# If confirmed pending download
			if ( isset ( $_POST [ 'confirm' ] ) && $info [ 'confirmed' ] != 1 && $_SESSION [ 'permissions' ] [ 'approve_downloads' ] == 1 )
			{
				$confirm = true;
			}
			else 
			{
				$confirm = false;	
			}
			
			# Prepare tags
			$blog = & core::get_object ( 'blog' );
			$tags_str = $blog -> prepare_tags ( $tags );
			
			$returninfo [ 'confirm' ] = $confirm;
			$returninfo [ 'lid' ] = $cat [ 'lid' ];
			$returninfo [ 'sublid' ] = $cat [ 'sublid' ];
			$returninfo [ 'plid' ] = $plid;
			$returninfo [ 'header' ] = $header;
			
			# Query
			$qr = "UPDATE dl_downloads SET 
					cat='". $cat [ 'cat' ] ."', subcat='". $subcat ."', plid='". $plid ."', 
					header='". $header ."', subheader='". $subheader ."',
					anonymous='". ( $anonymous ? '1' : '0' ) ."',
					content='". $text ."', ". ( $nfo != null ? "nfo='". $nfo ."'," : null ) ."
					dl_links='". $links ."'
					". ( $confirm ? ", posted='".time()."', updated='0', confirmed='1'" : ", updated='". time() ."'" ) ."
					". ( isset ( $fsize ) ? ", fsize='". $fsize ."'" : null ) ."
					". ( isset ( $flist ) ? ", files='". $flist ."'" : null ) ."
					". ( isset ( $new_torrent ) ? ", info_hash='". $info_hash ."'" : null ) ."
					". ( FUNC_TAGS ? ", tags='". $tags_str ."'" : null ) ."
				   WHERE fid='". $id ."'";
			
			# Move .torrent file
			if ( $info [ 'info_hash' ] != null )
			{
				$res = $this -> move_torrent ( $lid, $sublid, $plid_old, $cat [ 'lid' ], $cat [ 'sublid' ], $plid );
				if ( $res === false )
				{
					error::line(__LINE__);
					return false;		
				}
			}
			
			# So far so good
			$res = $this -> db -> update ( $qr );
			
			if ( $res != 0 )
			{
				# Clear cache
				$this -> cache -> remove ( 'get_downloads___1' );
				$this -> cache -> remove ( 'get_posts_downloads_1' );
				
				return true; 
			}
			else 
			{
				error::line(__LINE__);
				return false;	
			}
		}
		
		
		# Checks if plid is available, if occupied looks for unoccupied by appending a number
		public function check_plid ( &$plid, $cat, $subcat, $category = false, $subcategory = false )
		{
			if ( $category )
			{
				$res = $this -> db -> get_all ( "SELECT lid FROM dl_categories WHERE lid LIKE '". $plid ."%'" );
			}
			elseif ( $subcategory )
			{
				$res = $this -> db -> get_all ( "SELECT lid FROM dl_subcategories WHERE lid LIKE '". $plid ."%' AND cat='". $cat ."'" );
			}
			else 
			{
				$res = $this -> db -> get_all ( "SELECT plid FROM dl_downloads WHERE plid LIKE '". $plid ."%' AND cat='". $cat ."' AND subcat='". $subcat ."'" );
			}
				
			if ( !empty ( $res ) )
			{
				$i = 2;
				while ( $this -> search_plid_arr ( $plid .'-'. $i, $res, $category || $subcategory ) === true )
				{
					$i++;
				}
				$plid = $plid .'-'. $i;
			}
			else 
			{
				return true;	
			}
		}
		
		
		# If plid is in array
		public function search_plid_arr ( $plid, $arr, $category )
		{
			$key = ( $category?'lid':'plid' );
			foreach ( $arr as $v )
			{
				if ( $v [ $key ] == $plid )
				{
					return true;	
				}	
			}
			error::line(__LINE__);
			return false;	
		}
		
		
		# Uploads .torrent file
		public function upload_torrent ( $cat, &$plid, &$fsize, &$flist )
		{
			if ( !isset ( $_FILES [ 'torrent' ] ) || $_FILES [ 'torrent' ] [ 'tmp_name' ] == null 
				|| !preg_match ( "#\.torrent\$#i", $_FILES [ 'torrent' ] [ 'name' ] ) )
			{
				# Not uploaded
				return null;	
			}
			
			if ( !file_exists ( $_FILES [ 'torrent' ] [ 'tmp_name' ] ) || !is_uploaded_file ( $_FILES [ 'torrent' ] [ 'tmp_name' ] ) )
			{
				# Error while uploading
				error::line(__LINE__);
				return false;	
			}
			
			# Get contents and delete file
			$content = file_get_contents ( $_FILES [ 'torrent' ] [ 'tmp_name' ] );
			unlink ( $_FILES [ 'torrent' ] [ 'tmp_name' ] );
			
			# Decode bittorrent encoded contents into array
			$c_arr = $this -> bittorrent -> decode ( $content );
			$c_arr = $c_arr [ 0 ];
			
			# Get name
			$name = $c_arr [ 'info' ] [ 'name' ];
			
			# Set announce url
			if ( isset ( $c_arr [ 'announce-list' ] ) ) unset ( $c_arr [ 'announce-list' ] );
			$c_arr [ 'announce' ] = TRACKER_URL;
			
			# Set private
    		$c_arr [ 'info' ] [ 'private' ] = ( TRACKER_ANONYMOUS ? 0 : 1 );
			
			# Set comment
			$c_arr [ 'comment' ] = TORRENT_COMMENT;
			$c_arr [ 'comment.utf-8' ] = TORRENT_COMMENT;
			
			# Calculate filesizes and build filelist
			if ( !isset ( $c_arr [ 'info' ] [ 'files' ] ) )
			{
				# Single file
				$fsize = $c_arr [ 'info' ] [ 'length' ];
				$flist = $name .'|'. $fsize;
			}
			else 
			{
				# Filelist
				$fsize = 0;
				$flist = '';
				foreach ( $c_arr [ 'info' ] [ 'files' ] as $v )
				{
					$fsize += $v [ 'length' ];
					$flist .= implode ( '/', $v [ 'path' ] ) .'|'. $v [ 'length' ] ."\n";
				}
			}
			
			$flist = $this -> db -> escape ( $flist, true );
			
			# Generate info_hash
			//$info_hash = sha1 ( $this -> bittorrent -> encode ( $c_arr [ 'info' ] ) );
			//$info_hash = '0x'. $info_hash;
			$info_hash = pack ( 'H*', sha1 ( $this -> bittorrent -> encode ( $c_arr [ 'info' ] ) ) );
			
			if ( strlen ( $info_hash ) != 20 )
			{
				# Invalid info_hash
				error::line(__LINE__);
				return false;		
			}
			
			$info_hash = $this -> db -> escape ( $info_hash, true, false );
			
			# Plid
			$plid = $this -> text -> make_lid ( $name );
			
			# Checks if plid is available
			$this -> check_plid ( $plid, $cat [ 'cat' ], $cat [ 'subcat' ] );
			
			# Get path to store .torrent file
			$path = $this -> get_torrent_path ( $cat [ 'lid' ] , $cat [ 'sublid' ], $plid );
			
			# Get / create dir
			$dir = substr ( $path, 0, strrpos ( $path, '/' ) );
			if ( !file_exists ( $dir ) ) 
			{
				mkdir ( $dir, 0777, true );
			}
			
			# Generate .torrent file contents
			$content = $this -> bittorrent -> encode ( $c_arr );
			
			# Create .torrent file
			$succ = file_put_contents ( $path, $content );
			if ( $succ === false )
			{
				error::line(__LINE__);
				return false;		
			}
			
			return $info_hash;
		}
		
		
		# Move .torrent file
		public function move_torrent ( $lid, $sublid, $plid, $lid_new, $sublid_new, $plid_new )
		{
			$from = $this -> get_torrent_path ( $lid , $sublid, $plid );
			$to = $this -> get_torrent_path ( $lid_new , $sublid_new, $plid_new );
			
			//$dir_from = substr ( $from, 0, strrpos ( $from, '/' ) );
			$dir_to = substr ( $to, 0, strrpos ( $to, '/' ) );
			
			if ( !file_exists ( $dir_to ) ) 
			{
				mkdir ( $dir_to, 0777, true );
			}
			
			return rename ( $from, $to );
		}
		
		
		# Get total fsize from http links
		public function get_links_fsize ( &$links )
		{
			$fsize = 0;
			$mirrors = 1;
			$links_arr = explode ( "\n", $links );
			$mirror_size = false;
			foreach ( $links_arr as $k => $v )
			{
				$v = trim ( $v );
				
				if ( preg_match ( "#^\-\-+\$#", $v ) )
				{
					# Mirror separator	
					$mirror = true;
				}
				else 
				{
					# Link
					$mirror = false;
					
					if ( !preg_match ( "#^(\w+:[/\\\]{2})(.*)\$#", $v, $url ) )
					{
						$pfx = 'http://';
					}
					else 
					{
						$ending = substr ( $url [ 1 ], -2 );
						if ( $ending == '//' )
						{
							$pfx = null;	
						}
						else 
						{
							$pfx = substr ( $url [ 1 ], 0, -2 ) .'//';
							$v = $url [ 2 ];
						}
					}
					$v = $pfx . $v;
					$links_arr [ $k ] = $v;
				}
				
				if ( preg_match ( "#(.*)\|([0-9\.]+)([bkmg]?)[b]?\s*\$#i", $v, $m ) )
				{
					$bytes = $m [ 2 ];
					switch ( $m [ 3 ] )
					{
						case 'g':
								$bytes *= 1024;
						case 'm':
								$bytes *= 1024;
						case 'k':
								$bytes *= 1024;
							break;
					}
					$fsize = $fsize + $bytes;	
					$links_arr [ $k ] = $m [ 1 ] .'|'. $bytes;
					$mirror_size = true;
				}
				elseif ( $mirror )
				{
					if ( $mirror_size )
					{
						$mirrors++;
						$mirror_size = false;
					}
				}
			}	
			$fsize = ceil ( $fsize / $mirrors );
			$links = implode ( "\n", $links_arr );
			return $fsize;
		}
		
		
		# Get plid, lid and sublid from id (sounds fun)
		public function get_plid_lid_sublid ( $id, $other = null )
		{
			$res = $this -> db -> get_row ( 'SELECT dl_categories.lid, dl_subcategories.lid AS sublid, dl_downloads.plid '. $other .'
											 FROM dl_downloads
												LEFT JOIN dl_categories ON ( dl_downloads.cat = dl_categories.id )
												LEFT JOIN dl_subcategories ON ( dl_downloads.subcat = dl_subcategories.id )
											 WHERE dl_downloads.fid='. $id );
			
			return $res;	
		}
		
		
		# Get user downloads
		public function get_user_downloads ( $user = null, $updatecounter = true )
		{
			if ( $user == null )
			{
				$user = $_SESSION [ 'user' ];	
			}
			
			# Build and execute SQL query
			$qr = "SELECT dl.fid, dl_categories.name, dl_categories.lid, 
			 	   		dl_subcategories.name AS subname, dl_subcategories.lid AS sublid,
				   		dl.plid, dl.posted, dl.updated, 
						dl.header, dl.subheader, dl.comments, dl.confirmed
				   FROM dl_downloads AS dl
				   		LEFT JOIN dl_categories ON ( dl.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl.subcat = dl_subcategories.id )
				   WHERE dl.user='". $user ."'
				   ORDER BY dl.posted DESC";
					
			$res = $this -> db -> get_all ( $qr );
			
			# Zero posts
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			# Update user downloads counter
			if ( $updatecounter )
			{
				$this -> user -> update ( array ( 'downloadposts' => count ( $res ) ), $user );
			}
			
			return $res;	
		}
		
		
		# Get unconfirmed downloads
		public function get_pending_downloads ( $limit = 0, $extra = null )
		{
			# Build and execute SQL query
			$qr = "SELECT dl.fid, dl_categories.name, dl_categories.lid, 
			 	   		dl_subcategories.name AS subname, dl_subcategories.lid AS sublid,
				   		dl.plid, dl.posted, dl.updated, 
						dl.header, dl.subheader, dl.comments
						". $extra ."
				   FROM dl_downloads AS dl
				   		LEFT JOIN dl_categories ON ( dl.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl.subcat = dl_subcategories.id )
				   WHERE dl.confirmed!='1'
				   ORDER BY dl.posted DESC
				   ". ( $limit != 0 ? 'LIMIT '. $limit : null );
					
			$res = $this -> db -> get_all ( $qr );
			
			# Zero posts
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			return $res;	
		}
				
		
		# Get cheater list
		public function get_cheater_list ( $limit = 0, $extra = null )
		{
			# Build and execute SQL query
			$qr = "SELECT users.name, users.can_leech, users.banned, 
						  xbt_cheat.id, xbt_cheat.ipa, xbt_cheat.upspeed, xbt_cheat.tstamp, xbt_cheat.uploaded 
						  ". $extra ."
				   FROM xbt_cheat
				   		LEFT JOIN users ON ( users.uid = xbt_cheat.uid )
				   ORDER BY xbt_cheat.tstamp DESC
				   ". ( $limit != 0 ? 'LIMIT '. $limit : null );
				
			$res = $this -> db -> get_all ( $qr );
			
			# Zero posts
			if ( $this -> db -> num_rows () == 0 )
			{
				$res = array ();
			}
			
			return $res;	
		}		
		
		
		# Deletes entries from xbt_cheat according to $_POST values
		public function delete_cheater_entries ()
		{
			$qr = "DELETE FROM xbt_cheat WHERE ";
			$where = null;
			foreach ( $_POST as $k => $v )
			{
				if ( preg_match ( "#^ch([0-9]+)\$#", $k, $m ) )
				{
					$where .= ( $where != null ? "' OR " : null ) ."id='". $m [ 1 ];
				}
			}
			
			# Nothing to do
			if ( $where == null )
			{
				return true;	
			}
			else 
			{
				$res = $this -> db -> delete ( $qr . $where ."'" );
				if ( $res > 0 )
				{
					return true;	
				}	
				else 
				{
					error::line(__LINE__);
					return false;	
				}
			}
		}
		
		
		# Download exists?
		public function dl_exists ( $id )
		{
			$this -> db -> get_one ( "SELECT fid FROM dl_downloads WHERE fid='". $id ."' AND confirmed='1' LIMIT 1" );
			if ( $this -> db -> num_rows () > 0 )
			{
				return true;
			}
			else 
			{
				error::line(__LINE__);
				return false;		
			}
		}
		
		
		# Deletes download
		public function delete_download ( $id, &$returninfo = null )
		{
			if ( !is_numeric ( $id ) )
			{
				error::line(__LINE__);
				return false;	
			}
			
			# Gets lid, sublid, plid, info_hash, author
			$info = $this -> get_plid_lid_sublid ( $id, ', dl_downloads.info_hash, dl_downloads.user, dl_downloads.nfo, dl_downloads.confirmed, dl_downloads.header' );
			if ( !$info ) 
			{
				error::line(__LINE__);
				return false;	
			}
			
			# User okay?
			if ( $info [ 'user' ] != $_SESSION [ 'user' ] && $_SESSION [ 'permissions' ] [ 'edit_downloads' ] != 1 )
			{
				if ( $info [ 'confirmed' ] != 1 && $_SESSION [ 'permissions' ] [ 'approve_downloads' ] ==1 )
				{
					# Everything is fine, keep going
				}
				else 
				{
					error::line(__LINE__);
					return false;	
				}
			}
			
			# Deletes .nfo
			if ( $info [ 'nfo' ] != null )
			{
				$path = DIR_NFO .'/'. $info [ 'nfo' ] [ 0 ] .'/'. $info [ 'nfo' ] [ 1 ] .'/'. $info [ 'nfo' ] [ 2 ] .'/'. $info [ 'nfo' ] .'.nfo';
				if ( file_exists ( $path ) )
				{
					unlink ( $path );	
				}
			}
			
			# Deletes db entry / marks torrent for deletion
			if ( $info [ 'info_hash' ] == null || TRACKER_TYPE != 'XBTT' )
			{
				# Deletes
				$ret = $this -> db -> delete ( "DELETE FROM dl_downloads WHERE fid='". $id ."'" );	
			}
			else 
			{
				# Marks for deletion
				$ret = $this -> db -> update ( "UPDATE dl_downloads SET flags='1', updated='". time () ."' WHERE fid='". $id ."'" );
				
				# Remove .torrent file
				$path = $this -> get_torrent_path ( $info [ 'lid' ] , $info [ 'sublid' ], $info [ 'plid' ] );
				if ( file_exists ( $path ) )
				{
					unlink ( $path );
				}
			}
			
			# Delete comments
			$this -> db -> delete ( "DELETE FROM dl_comments WHERE post='". $id ."'" );
			
			if ( $ret > 0 )
			{
				# Update author userinfo
				$dp = $this -> db -> get_one ( "SELECT downloadposts FROM users WHERE name='". $info [ 'user' ] ."'" );
				$dp--;
				$this -> user -> update ( array ( 'downloadposts' => $dp ), $info [ 'user' ] );
			}
			else 
			{
				error::line(__LINE__);
				return false;	
			}
			
			$returninfo [ 'lid' ] = $info [ 'lid' ];
			$returninfo [ 'sublid' ] = $info [ 'sublid' ];
			$returninfo [ 'plid' ] = $info [ 'plid' ];
			$returninfo [ 'header' ] = $info [ 'header' ];
			
			return true;
		}
		
		
		# Uploads .nfo
		public function upload_nfo ()
		{
			if ( !isset ( $_FILES [ 'nfo' ] ) || $_FILES [ 'nfo' ] [ 'tmp_name' ] == null )
			{
				# Not uploaded
				return null;	
			}
			
			if ( !file_exists ( $_FILES [ 'nfo' ] [ 'tmp_name' ] ) || !is_uploaded_file ( $_FILES [ 'nfo' ] [ 'tmp_name' ] ) )
			{
				# Error while uploading
				return null;
			}
			
			if ( !preg_match ( "#^(.*)\.[a-z]+\$#i", $_FILES [ 'nfo' ] [ 'name' ], $m ) )
			{
				$fname = $_FILES [ 'nfo' ] [ 'name' ];	
			}
			else 
			{
				$fname = $m [ 1 ];	
			}
			
			$fname = $this -> text -> make_lid ( $fname );
			
			if ( strlen ( $fname ) < 3 )
			{
				$iter = 3 - strlen ( $fname );
				for ( $i = 0; $i < $iter; $i++ )
				{
					$fname .= '_';	
				}	
			}
			
			$dir = DIR_NFO .'/'. $fname [ 0 ] .'/'. $fname [ 1 ] .'/'. $fname [ 2 ];
			$path = $dir .'/'. $fname .'.nfo';
			
			if ( !file_exists ( $dir ) )
			{
				mkdir ( $dir, 0777, true );	
			}
			
			if ( file_exists ( $path ) )
			{
				$fname = $this -> get_unique_fname ( $dir, $fname, '.nfo' );
				//$fname = $fname . rand ( 1, 9999 );
				$path = $dir .'/'. $fname .'.nfo';	
			}
			
			$res = move_uploaded_file ( $_FILES [ 'nfo' ] [ 'tmp_name' ], $path );
			
			if ( $res )
			{
				return $fname;
			}
			else 
			{
				return null;	
			}
		}	
		
		
		# Generates unique filename
		public function get_unique_fname ( $dir, $fname, $suffix = null )
		{
			$fl = $fname .'-1';
			$i = 2;
			while ( file_exists ( $dir .'/'. $fl . $suffix ) )
			{
				if ( $i == 1000 )
				{
					throw new error ( core::get_object ( 'language' ) -> t ( 'downloads_err_nfo_changename' ) );	
				}
				$fl = $fname .'-'. $i;
				$i++;
			}
			
			return $fl;
		}	
		
				
		# Get top downloads
		public function get_top ( $number = 5 )
		{		
			# Init cache
			$this -> cache -> init ( 'infobanner_downloads', 60, CACHE_INFOBANNER );	
			$cached = $this -> cache -> get ();
			if ( $cached !== false )
			{
				# Return cached result
				$res = unserialize ( $cached );	
			}
			else 
			{
				$qr = "SELECT cid FROM counters WHERE cid LIKE 'download_%' AND day_date='". date ( 'md' ) ."' ORDER BY day_visits DESC LIMIT ". $number;
				$top = $this -> db -> get_all ( $qr );
				
				$res = array ();
				$top_where = null;
				foreach ( $top as $v )
				{
					$v = str_replace ( 'download_', null, $v [ 'cid' ] );
					if ( $top_where == null )
					{
						$top_where = "dl.fid='". $v ."'";
					}
					else 
					{
						$top_where .= " OR dl.fid='". $v ."'";
					}
					
					$res [ $v ] = array ();
				}
				
				$qr = 'SELECT dl_categories.lid, 
			 	   	   		  dl_subcategories.lid AS sublid,
				   	   		  dl.plid,
					   		  dl.header,
					   		  dl.confirmed, dl.fid
				   	   FROM dl_downloads AS dl
				   		   LEFT JOIN dl_categories ON ( dl.cat = dl_categories.id )
				   		   LEFT JOIN dl_subcategories ON ( dl.subcat = dl_subcategories.id )
				   	   '. ( $top_where != null ? 'WHERE '. $top_where : null ) .'
				       ORDER BY dl.posted DESC
				       LIMIT '. $number;
				$dls = $this -> db -> get_all ( $qr );
				
				foreach ( $dls as $v )
				{
					$res [ $v [ 'fid' ] ] = $v;
				}
				
				if ( CACHE_INFOBANNER )
				{
					$this -> cache -> save ( serialize ( $res ) );
				}
			}
			
			return $res;
		}
		
		
		# Delete downloads categories, subcategories, downloads, download comments, .torrent and .nfo files
		public function del_cats ( $cats )
		{
			$where_cat = "cat='". implode ( "' OR cat='", $cats ) ."'";
			$where_cat2 = "dl_downloads.cat='". implode ( "' OR dl_downloads.cat='", $cats ) ."'";
			$where_id = "id='". implode ( "' OR id='", $cats ) ."'";

			$comment_ids = array ();
			$qr = 'SELECT dl_downloads.fid, dl_downloads.nfo, dl_downloads.info_hash, dl_downloads.plid,
						dl_categories.name, dl_categories.lid, 
			 	   		dl_subcategories.name AS subname, dl_subcategories.lid AS sublid
				   FROM dl_downloads
				   		LEFT JOIN dl_categories ON ( dl_downloads.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl_downloads.subcat = dl_subcategories.id )
				   WHERE '. $where_cat2;
			$dl = $this -> db -> get_all ( $qr );
			
			if ( !empty ( $dl ) )
			{
				foreach ( $dl as $v )
				{
					$comment_ids [] = $v [ 'fid' ];
					
					# Delete .nfo
					if ( $v [ 'nfo' ] != null )
					{
						$path = DIR_NFO .'/'. $v [ 'nfo' ] [ 0 ] .'/'. $v [ 'nfo' ] [ 1 ] .'/'. $v [ 'nfo' ] [ 2 ] .'/'. $v [ 'nfo' ] .'.nfo';
						if ( file_exists ( $path ) )
						{
							unlink ( $path );	
						}
					}
					
					# Check if torrent or ordinary download
					$del = array ();
					$flag = array ();
					if ( $v [ 'info_hash' ] == null )
					{
						$del [] = $v [ 'fid' ];
					}
					else 
					{
						$flag [] = $v [ 'fid' ];
						$path = $this -> get_torrent_path ( $v [ 'lid' ] , $v [ 'sublid' ], $v [ 'plid' ] );
						unlink ( $path );
					}
					
					if ( !empty ( $del ) )
					{
						$where_del_fid = "fid='". implode ( "' OR fid='", $del ) ."'";
						$this -> db -> delete ( 'DELETE FROM dl_downloads WHERE '. $where_del_fid );
					}
					
					if ( !empty ( $flag ) )
					{
						$where_flag_fid = "fid='". implode ( "' OR fid='", $flag ) ."'";
						$this -> db -> update ( 'UPDATE dl_downloads SET flags=1, updated='. time () .' WHERE '. $where_flag_fid );
					}
				}
				
				# Delete comments
				$where_post = "post='". implode ( "' OR post='", $comment_ids ) ."'";
				$this -> db -> delete ( 'DELETE FROM dl_comments WHERE '. $where_post );
			}
			
			# Delete .torrents
			$plids = $this -> db -> get_all ( 'SELECT lid FROM dl_categories WHERE '. $where_id );
			foreach ( $plids as $v )
			{
				core::get_object ( 'blog' ) -> del_dir ( DIR_TORRENT .'/'. $v [ 'lid' ] );
			}
			
			# Remove subcategories
			$this -> db -> delete ( 'DELETE FROM dl_subcategories WHERE '. $where_cat );
			# Remove categories
			$this -> db -> delete ( 'DELETE FROM dl_categories WHERE '. $where_id );
			
			return true;
		}
		
		
		# Delete subcategories, downloads, .torrent and .nfo files
		public function del_subcats ( $sub )
		{
			$where_cat = "subcat='". implode ( "' OR subcat='", $sub ) ."'";
			$where_cat2 = "dl_downloads.subcat='". implode ( "' OR dl_downloads.subcat='", $sub ) ."'";
			$where_id = "id='". implode ( "' OR id='", $sub ) ."'";
			$where_id2 = "dl_subcategories.id='". implode ( "' OR dl_subcategories.id='", $sub ) ."'";

			$comment_ids = array ();
			$qr = 'SELECT dl_downloads.fid, dl_downloads.nfo, dl_downloads.info_hash, dl_downloads.plid,
						dl_categories.name, dl_categories.lid, 
			 	   		dl_subcategories.name AS subname, dl_subcategories.lid AS sublid
				   FROM dl_downloads
				   		LEFT JOIN dl_categories ON ( dl_downloads.cat = dl_categories.id )
				   		LEFT JOIN dl_subcategories ON ( dl_downloads.subcat = dl_subcategories.id )
				   WHERE '. $where_cat2;
			$dl = $this -> db -> get_all ( $qr );
			
			if ( !empty ( $dl ) )
			{
				foreach ( $dl as $v )
				{
					$comment_ids [] = $v [ 'fid' ];
					
					# Delete .nfo
					if ( $v [ 'nfo' ] != null )
					{
						$path = DIR_NFO .'/'. $v [ 'nfo' ] [ 0 ] .'/'. $v [ 'nfo' ] [ 1 ] .'/'. $v [ 'nfo' ] [ 2 ] .'/'. $v [ 'nfo' ] .'.nfo';
						if ( file_exists ( $path ) )
						{
							unlink ( $path );	
						}
					}
					
					# Check if torrent or ordinary download
					$del = array ();
					$flag = array ();
					if ( $v [ 'info_hash' ] == null )
					{
						$del [] = $v [ 'fid' ];
					}
					else 
					{
						$flag [] = $v [ 'fid' ];
					}
					
					if ( !empty ( $del ) )
					{
						$where_del_fid = "fid='". implode ( "' OR fid='", $del ) ."'";
						$this -> db -> delete ( 'DELETE FROM dl_downloads WHERE '. $where_del_fid );
					}
					
					if ( !empty ( $flag ) )
					{
						$where_flag_fid = "fid='". implode ( "' OR fid='", $flag ) ."'";
						$this -> db -> update ( 'UPDATE dl_downloads SET flags=1, updated='. time () .' WHERE '. $where_flag_fid );
					}
				}
				
				# Delete comments
				$where_post = "post='". implode ( "' OR post='", $comment_ids ) ."'";
				$this -> db -> delete ( 'DELETE FROM dl_comments WHERE '. $where_post );
			}
			
			# Delete .torrents
			$plids = $this -> db -> get_all ( 'SELECT dl_categories.lid, dl_subcategories.lid AS sublid 
			 								   FROM dl_subcategories 
			 								   		LEFT JOIN dl_categories ON ( dl_subcategories.cat = dl_categories.id )
			 								   WHERE '. $where_id2 );
			foreach ( $plids as $v )
			{
				core::get_object ( 'blog' ) -> del_dir ( DIR_TORRENT .'/'. $v [ 'lid' ] .'/'. $v [ 'sublid' ] );
			}
			
			# Remove subcategories
			$this -> db -> delete ( 'DELETE FROM dl_subcategories WHERE '. $where_id );
			
			return true;
		}
		
		
		# Update download categories
		public function update_cats ( $cats )
		{
			$where_id = "id='". implode ( "' OR id='", array_keys ( $cats ) ) ."'";
			$res = $this -> db -> get_all ( 'SELECT id, lid, name FROM dl_categories WHERE '. $where_id );
			foreach ( $res as $v )
			{
				$cats [ $v [ 'id' ] ] [ 'lid' ] = $v [ 'lid' ];	
				$cats [ $v [ 'id' ] ] [ 'old_name' ] = $v [ 'name' ];	
			}		
			
			foreach ( $cats as $id => $v )
			{
				if ( trim ( $v [ 'name' ] ) != null )
				{
					if ( $v [ 'name' ] != $v [ 'old_name' ] ) 
					{
						$lid = $this -> text -> make_lid ( $v [ 'name' ] );
						$this -> check_plid ( $lid, null, null, true );
					}
					else 
					{
						$lid = $v [ 'lid' ];	
					}
					$name = $this -> db -> escape ( $v [ 'name' ] );
					$position = $v [ 'pos' ];
					
					# Rename torrents directory
					if ( $v [ 'lid' ] != $lid && file_exists ( DIR_TORRENT .'/'. $v [ 'lid' ] ) )
					{
						rename ( DIR_TORRENT .'/'. $v [ 'lid' ], DIR_TORRENT .'/'. $lid );
					}
					
					# Do it!
					$this -> db -> update ( "UPDATE dl_categories SET lid='". $lid ."', name='". $name ."', position='". $position ."' WHERE id='". $id ."'" );	
				}
			}
		}
		
		
		# Update subcategories
		public function update_subcats ( $subcats )
		{
			$where_id = "dl_subcategories.id='". implode ( "' OR dl_subcategories.id='", array_keys ( $subcats ) ) ."'";
			$res = $this -> db -> get_all ( 'SELECT dl_subcategories.id, dl_subcategories.lid AS sublid, dl_subcategories.name,
													dl_categories.lid, dl_categories.id AS cid
											 FROM dl_subcategories 
											 	LEFT JOIN dl_categories ON ( dl_subcategories.cat = dl_categories.id )
											 WHERE '. $where_id );
			foreach ( $res as $v )
			{
				$subcats [ $v [ 'id' ] ] [ 'cid' ] = $v [ 'cid' ];
				$subcats [ $v [ 'id' ] ] [ 'lid' ] = $v [ 'lid' ];
				$subcats [ $v [ 'id' ] ] [ 'sublid' ] = $v [ 'sublid' ];	
				$subcats [ $v [ 'id' ] ] [ 'old_name' ] = $v [ 'name' ];	
			}		
			
			foreach ( $subcats as $id => $v )
			{
				if ( trim ( $v [ 'name' ] ) != null && isset ( $v [ 'old_name' ] ) )
				{
					if ( $v [ 'name' ] != $v [ 'old_name' ] ) 
					{
						$lid = $this -> text -> make_lid ( $v [ 'name' ] );
						$this -> check_plid ( $lid, $v [ 'cid' ], null, false, true );
					}
					else 
					{
						$lid = $v [ 'sublid' ];	
					}
					$name = $this -> db -> escape ( $v [ 'name' ] );
					$position = $v [ 'pos' ];
					
					# Rename torrents directory
					if ( $v [ 'sublid' ] != $lid && file_exists ( DIR_TORRENT .'/'. $v [ 'lid' ] .'/'. $v [ 'sublid' ] ) )
					{
						rename ( DIR_TORRENT .'/'. $v [ 'lid' ] .'/'. $v [ 'sublid' ], DIR_TORRENT .'/'. $v [ 'lid' ] .'/'. $lid );
					}
					
					# Do it!
					$this -> db -> update ( "UPDATE dl_subcategories SET lid='". $lid ."', name='". $name ."', position='". $position ."' WHERE id='". $id ."'" );	
				}
			}
		}
		
		
		# Create new category at the botom of download categories list
		public function create_cat ( $name )
		{
			$lid = $this -> text -> make_lid ( $name );
			$this -> check_plid ( $lid, null, null, true );
			$name = $this -> db -> escape ( $name );
			# Could'n find a way to do this with only one query :(
			$pos = $this -> db -> get_one ( 'SELECT MAX(position) FROM dl_categories' );
			if ( $pos == false ) $pos = 1; else $pos++;
			$this -> db -> insert ( "INSERT INTO dl_categories SET lid='". $lid ."', name='". $name ."', position=". $pos );
			
			return true;
		}	
		
		
		# Create new subcategory 
		public function create_subcat ( $cat, $name )
		{
			$cat_lid = $this -> db -> get_one ( 'SELECT lid FROM dl_categories WHERE id='. $cat );
			
			if ( $cat_lid == false ) return false;
			
			$lid = $this -> text -> make_lid ( $name );
			$this -> check_plid ( $lid, $cat, null, false, true );
			$name = $this -> db -> escape ( $name );
			# Could'n find a way to do this with only one query :(
			$pos = $this -> db -> get_one ( 'SELECT MAX(position) FROM dl_subcategories WHERE cat='. $cat );
			if ( $pos == false ) $pos = 1; else $pos++;
			$this -> db -> insert ( "INSERT INTO dl_subcategories SET cat='". $cat ."', lid='". $lid ."', name='". $name ."', position=". $pos );
			
			return true;
		}		
		
		
	}

?>