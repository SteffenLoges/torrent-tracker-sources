<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class nfo
	{

		public function __construct ()
		{
			
		}
		
		
		# Get and output .nfo file contents
		public function get ( $nfo )
		{
			$l = & core::get_object ( 'language' );
			
			# Output format
			if ( strlen ( $nfo ) < 7 || !preg_match ( "#^(.*)\.(nfo|txt|png)\$#i", $nfo, $m ) )
			{
				throw new error ( $l -> t ( 'nfo_invalid_file' ) );	
			}
			else
			{
				$nfo = $m [ 1 ] .'.nfo';
				$type = $m [ 2 ];
			}
			
			$path = DIR_NFO .'/'. $nfo [ 0 ] .'/'. $nfo [ 1 ] .'/'. $nfo [ 2 ] .'/'. $nfo;
			$path_img = DIR_NFO .'/'. $nfo [ 0 ] .'/'. $nfo [ 1 ] .'/'. $nfo [ 2 ] .'/'. $m [ 1 ] .'.png';
			if ( !file_exists ( $path ) )
			{
				throw new error ( $l -> t ( 'nfo_invalid_file' ) );	
			}	
			
			# If png output format requested, check if image is already generated
			if ( $type == 'png' )
			{
				if ( file_exists ( $path_img ) )
				{
					header ( 'Content-type: image/png' );
					readfile ( $path_img );
					return;
				}
			}
			
			header ( 'Cache-Control: no-store, no-cache, must-revalidate' );
			
			# Output according to format
			switch ( $type )
			{
				default:
						# .nfo
						header ( 'Content-Type: application/octet-stream; charset=utf-8' );
						header ( 'Content-Disposition: attachment; filename="'. $nfo .'"' );
						readfile ( $path );
					break;
					
				case 'txt':
						# .txt
						header ( 'Content-Type: text/plain; charset=utf-8'  );
						readfile ( $path );
					break;
					
				case 'png':
						# .png
						$this -> generate_image ( $path, $path_img );
					break;
			}
		}
		
		
		# Generates .png image from text
		public function generate_image ( $path, $save )
		{
			# Read file and remove \r
			$content = file_get_contents ( $path );
			$content = str_replace ( "\r", null, $content );
			
			# Get height by counting lines
			$lines = explode ( "\n", $content );
			$line_count = count ( $lines );
			
			# Get width by looking for longest line
			$char_count = 0;
			foreach ( $lines as $v )
			{
				$strlen = strlen ( rtrim ( $v, "\n" ) );
				if ( $strlen > $char_count )
				{
					$char_count = $strlen;
				}
			}
			
			# Single symbol width and height
			$fontx = 5;
			$fonty = 12;
			
			# Load nfo font from image
			$font = imagecreatefrompng ( NFO_FONT );
			
			# Width and height
			$width = $char_count * $fontx;
			$height = $line_count * $fonty;
			
			if ( $width > 1600 ) $width = 1600;
			
			# Create image
			$im = imagecreatetruecolor ( $width, $height );
			
			# Font and background colors
			$bg = imagecolorallocate ( $im, 255, 255, 255 );
			$fontcol = 5 * $fonty;
			
			imagefill ( $im, 0, 0, $bg );
			
			$x = 0;
			$y = 0;
			
			# Fill image with text
			for ( $l = 0; $l < $line_count; $l++ )
			{
				$x = 0;
				
				$strlen = strlen ( $lines [ $l ] );
				for ( $c = 0; $c < $strlen; $c++ )
				{
					$char = $lines [ $l ] [ $c ];
					if ( $char !== "\n" )
					{
						$offset = ord ( $char ) * $fontx;
						imagecopy ( $im, $font, $x, $y, $offset, $fontcol, $fontx, $fonty );
						$x += $fontx;
					}
				}
				
				$y += $fonty;
			}
			
			# Save image
			imagepng ( $im, $save );
			header ( 'Content-type: image/png' );
			imagepng ( $im );
			imagedestroy($im);
		}
		
	}

?>