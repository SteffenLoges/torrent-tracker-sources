<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class url
	{

		# Url-rewriting
		private $rewriting = true;
		
		# Arguments separator
		private $arg_glue = '/';
		
		# URL file extension (for SEO stuff)
		private $arg_extension = 'html';
		
		# Arguments string
		private $arg_string;
		
		# Arguments array
		private $args;
		
		# Append SID to URL?
		public $add_sid = true;
		
		# SID (Session ID)
		public $sid = null;
		
		
		# Parses URL into arguments
		public function __construct ()
		{
			# Retrieve subdomain (wildcard domain must be configured to utilize this feature)
			$slpos = strpos ( URL, '/' );
			if ( $slpos !== false )
			{
				$hostname = substr ( URL, 0, $slpos );
			}
			else 
			{
				$hostname = URL;	
			}
			if ( preg_match ( '#^(.+?)\.'. $hostname .'#', $_SERVER [ 'HTTP_HOST' ], $m ) )
			{
				$this -> subdomain = strtolower ( $m [ 1 ] );
			}
			else 
			{
				$this -> subdomain = null;	
			}

			# Get the request (arguments) part of URL
			$host = preg_quote ( ( $this -> subdomain != null ? $this -> subdomain .'.' : null ) . URL );
			$args = preg_replace ( '#^'. $host .'#i', null, $_SERVER [ 'HTTP_HOST' ] . $_SERVER [ 'REQUEST_URI' ] );
			$args = trim ( $args, '/' );

			# Set rewriting state
			$this -> rewriting = URL_REWRITING;
			
			# Remove question mark from URL. Needed for correctly parsing arguments if rewriting is disabled.
			if ( /*!$this -> rewriting && */isset ( $args [ 0 ] ) && $args [ 0 ] == '?' && substr ( $args, 0, 8 ) != '?sessid=' )
			{
				$args = substr ( $args, 1 );
			}
			
			# Removes extension
			if ( !preg_match ( "#^out/#", $args ) && $this -> arg_extension != null && preg_match ( "#^(.*?)\.". $this -> arg_extension ."(\?sessid=[^\?&]*)?([\?&].*)?\$#", $args, $m ) )
			{
				$args = $m [ 1 ] . ( isset ( $m [ 2 ] ) ? $m [ 2 ] : null );
			}
			
			# If URL_TYPE == 1, move subdomain to the beginning of arguments string
			if ( URL_TYPE == 1 && $this -> subdomain != null && $this -> subdomain != 'wap' && $this -> subdomain != 'm' && $this -> subdomain != 'mobile' )
			{
				$args = $this -> subdomain . $this -> arg_glue . $args;
			}
			
			# Get SID from URL (if present)
			$args = $this -> get_sid_url ( $args );
			
			$this -> arg_string = $args;
			
			# If no arguments available, no need to execute any further.
			if ( $args == null ) return;
			
			# If arguments are set, explode them into array by $this -> arg_glue
			$args = explode ( $this -> arg_glue, $args );
			
			$this -> args = $args;
		}
		
		
		# Returns argument array
		public function get_args ()
		{
			return $this -> args;
		}
		
		
		# Returns subdomain
		public function get_subdomain ()
		{
			return $this -> subdomain;
		}
		
		
		# Removes and sets SID from URL (?sessid=...)
		private function get_sid_url ( $str )
		{
			if ( preg_match ( "#\?sessid=([a-zA-Z0-9]+)#", $str, $m ) )
			{
				$this -> sid = $m [ 1 ];
				$str = str_replace ( '?sessid='. $m [ 1 ], null, $str );
				return $str;
			}
			else 
			{
				return $str;	
			}
		}
		
		
		# Generates URL from passed arguments
		 # null will be replaced into current URL, _ will be replaced into null, __ will be ignored, argument separator will not be included before argument starting with #
		 # e.g. make ( null, '#top' ) -> http://example.com/current/url#top
		public function make ( $arg = null )
		{
			# Build function argument array
			if ( !is_array ( $arg ) )
			{
				$arg_str = func_get_args();
			}
			else 
			{
				$arg_str = & $arg;	
			}

			foreach ( $arg_str as $k => $v )
			{
				# Encode spaces into +
				$arg_str [ $k ] = str_replace ( ' ', '+', $v );
				
				if ( $v == null )
				{
					$arg_str [ $k ] = $this -> arg_string;	
				}
				elseif ( $v == '_' )
				{
					$arg_str [ $k ] = null;	
				}
				elseif ( $v == '__' )
				{
					unset ( $arg_str [ $k ] );	
				}
			}
			
			# URL format 
			 # 1 - view.domain.com/arg1/arg2
			 # 2 - domain.com/view/arg1/arg2
			if ( URL_TYPE == 1 )
			{
				$subdomain = ( $arg_str [ 0 ] != null ? $arg_str [ 0 ] .'.' : null );
				unset ( $arg_str [ 0 ] );
			}
			else 
			{
				$subdomain = null;
			}
			
			$arg_str = implode ( $this -> arg_glue, $arg_str );
			$arg_str = str_replace ( $this -> arg_glue . '#', '#', $arg_str );
				
			# If no extension is specified when building URL, add $this -> arg_extension
			if ( $this -> arg_extension != null && $arg_str != null && strpos ( $arg_str, '.' ) === false && substr ( $arg_str, -1 ) != '/' )
			{
				$spos = strpos ( $arg_str, '#' );
				if ( $spos > 0 )
				{
					$arg_str = str_replace ( '#', '.'. $this -> arg_extension . '#', $arg_str );
				}
				elseif ( $spos === false )
				{
					$arg_str .= '.'. $this -> arg_extension;	
				}	
			}
			
			# Build the complete URL
			if ( isset ( $_SERVER [ 'HTTPS' ] ) && $_SERVER [ 'HTTPS' ] != null )
			{
				$protocol = 'https';	
			}
			else 
			{
				$protocol = 'http';	
			}
			if ( isset ( $_SERVER [ 'SERVER_PORT' ] ) && $_SERVER [ 'SERVER_PORT' ] != 80 && ( $protocol != 'https' && $_SERVER [ 'SERVER_PORT' ] != 443 ) )
			{
				$port = ':'. $_SERVER [ 'SERVER_PORT' ];
			}
			else 
			{
				$port = null;
			}
			$url = $protocol .'://'. $subdomain . URL . $port . '/'. ( !$this -> rewriting && $arg_str != null ? '?' : null ) . $arg_str;
			
			# If SID is passed through URL
			if ( $this -> add_sid )
			{
				$sidstr = '?sessid='.$this->sid;
				# If # is present, add SID before it, otherwise add SID to the URL end
				$hashpos = strpos ( $url, '#' );
				if ( $hashpos !== false )
				{
					$url = substr ( $url, 0, $hashpos ) . $sidstr . substr ( $url, $hashpos );
				}
				else 
				{
					$url .= $sidstr;	
				}
			}
			
			return $url;
		}
		
		
	}

?>