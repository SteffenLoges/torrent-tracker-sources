<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class search 
	{

		# Objects
		private $db, $cache;
		
		
		public function __construct ()
		{
			$this -> db = &core::get_object ( 'db' );
			$this -> cache = & core::get_object ( 'cache' );
		}
		
		
		# Filters out invalid (too short, etc) keywords
		public function check_keywords ( $str, $remove_short = true )
		{
			$keywords_tmp = explode ( ' ', $str );
			$keywords = array ();
			$i = 0;
			foreach ( $keywords_tmp as $v )
			{
				if ( !in_array ( $v, $keywords ) && $i < 10 )
				{
					if ( ( $remove_short && strlen ( trim ( $v ) ) >= 3 ) || !$remove_short )
					{
						$keywords [] = '*'. trim ( $v, ' *' ) .'*';
						$i++;
					}
				}	
			}
			return $keywords;
		}
		
		
		# Checks cache for specific keywords
		public function check_cache ( $keywords, $type, $sort, $desc, $dl_cats )
		{
			if ( CACHE_SEARCH )
			{
				$id = 'search_'. $type .'_'. md5 ( implode ( $keywords ) ) . ( $sort != null ? '_'. $sort .'_'. ( $desc ? 'desc' : 'asc' ) : null ) .'_'. md5 ( implode ( '-', $dl_cats ) );
				$this -> cache -> init ( $id, 600, CACHE_SEARCH );
 				$cached = $this -> cache -> get ();
 				if ( $cached !== false )
 				{
 					return unserialize ( $cached );	
 				}
			}

			return false;	
		}
		
		
		# Build MySQL fulltext based search query
		public function fulltext ( $keywords, $type, $sort, $desc, $dl_cats )
		{
			$keywords = "'". $this -> db -> escape ( implode ( ' ', $keywords ) ) ."'";
			
			if ( $type == 'blog' )
			{

				# Function disabled
				if ( !FUNC_BLOG ) throw new error ( $l -> t ( 'err_func_disabled' ) );
	
				$qr = 'SELECT t.header, t.subheader, t.author, t.posted, t.updated, t.plid, blog_categories.name, blog_categories.lid,
				  	   MATCH ( t.header, t.subheader, t.content ) AGAINST ( '. $keywords .' ) AS relevancy
					   FROM blog_posts AS t 
					   	LEFT JOIN blog_categories ON ( blog_categories.id = t.cat )
					   WHERE MATCH ( t.header, t.subheader, t.content ) AGAINST ( '. $keywords .' IN BOOLEAN MODE ) 
					   ORDER BY relevancy DESC';
			}
			elseif ( $type == 'blog_tag' )
			{

				# Function disabled
				if ( !FUNC_BLOG || !FUNC_TAGS ) throw new error ( $l -> t ( 'err_func_disabled' ) );
	
				$keywords = str_replace ( '*', null, $keywords );
				$keywords = trim ( $keywords, '\'' );
				$qr = "SELECT t.header, t.subheader, t.author, t.posted, t.updated, t.plid, blog_categories.name, blog_categories.lid
					   FROM blog_posts AS t 
					   	LEFT JOIN blog_categories ON ( blog_categories.id = t.cat )
					   WHERE tags LIKE '%,". $keywords .",%'
					   ORDER BY posted DESC";
			}
			elseif ( $type == 'downloads' || $type == 'downloads_tag' )
			{
				# Function disabled
				if ( !FUNC_DOWNLOADS ) throw new error ( $l -> t ( 'err_func_disabled' ) );
				
				# Sorting
				if ( !is_bool($desc) ) $desc = false;
				switch ( $sort )
				{
					default:
							if ( $type == 'downloads' )
							{
								$order = 'relevancy DESC';	
							}
							else 
							{
								$order = 'posted DESC';	
							}
						break;
						
					case 'id':
							$order = 't.fid'. ($desc?' DESC':null);
						break;
					
					case 'type':
							$order = 't.'. ($desc?'dl_links':'info_hash') .' DESC, t.fid DESC';
						break;		
						
					case 'header':
					case 'seeders':
					case 'leechers':
					case 'fsize':
					case 'comments':
					case 'user':
							$order = 't.'. $sort . ($desc?' DESC':null);
						break;	
				}
				
				$downloads = & core::get_object ( 'downloads' );
				$cat_browse = $downloads -> get_cat_browse_sql ();
				
				$checked_cats = null;
				if ( !empty ( $dl_cats ) )
				{
					foreach ( $dl_cats as $k => $v )
					{
						if ( !is_numeric ( $v ) )
						{
							unset ( $dl_cats [ $k ] );	
						}	
					}
					if ( !empty ( $dl_cats ) )
					{
						$checked_cats = "AND (t.subcat='" . implode ( "' OR t.subcat='", $dl_cats ) ."')";
					}
				}
				
				if ( $type == 'downloads' )
				{
					$qr = 'SELECT t.header, t.subheader, t.user, t.anonymous, t.posted, t.updated, t.info_hash, t.dl_links, t.seeders, t.leechers, t.comments, t.fsize, t.plid,
								  dl_categories.name, dl_categories.lid, dl_subcategories.name AS subname, dl_subcategories.lid AS sublid,
					  	   MATCH ( t.header, t.subheader, t.content ) AGAINST ( '. $keywords .' ) AS relevancy
						   FROM dl_downloads AS t 
						   	LEFT JOIN dl_categories ON ( dl_categories.id = t.cat )
						   	LEFT JOIN dl_subcategories ON ( dl_subcategories.id = t.subcat )
						   WHERE confirmed=\'1\' AND MATCH ( t.header, t.subheader, t.content ) AGAINST ( '. $keywords .' IN BOOLEAN MODE ) 
						   '. $checked_cats .'
						   '. $cat_browse .'
						   ORDER BY '. $order;
				}
				else
				{
					# downloads_tag
					if ( !FUNC_TAGS ) throw new error ( $l -> t ( 'err_func_disabled' ) );
					
					$keywords = str_replace ( '*', null, $keywords );
					$keywords = trim ( $keywords, '\'' );
					$qr = "SELECT t.header, t.subheader, t.user, t.anonymous, t.posted, t.updated, t.info_hash, t.dl_links, t.seeders, t.leechers, t.comments, t.fsize, t.plid,
								  dl_categories.name, dl_categories.lid, dl_subcategories.name AS subname, dl_subcategories.lid AS sublid
						   FROM dl_downloads AS t 
						   	LEFT JOIN dl_categories ON ( dl_categories.id = t.cat )
						   	LEFT JOIN dl_subcategories ON ( dl_subcategories.id = t.subcat )
						   WHERE confirmed='1' AND tags LIKE '%,". $keywords .",%'
						   ". $cat_browse ."
						   ORDER BY ". $order;
				}
			}
			elseif ( $type == 'users' )
			{
				$qr = 'SELECT name, MATCH ( name ) AGAINST ( '. $keywords .' ) AS relevancy
					   FROM users WHERE MATCH ( name ) AGAINST ( '. $keywords .' IN BOOLEAN MODE ) ORDER BY relevancy DESC';
			}
			elseif ( $type == 'forums' )
			{

				# Function disabled
				if ( !FUNC_FORUMS ) throw new error ( $l -> t ( 'err_func_disabled' ) );
				
				$qr = "SELECT forum_posts.author, forum_threads.tlid, forum_threads.title, forum_threads.description, forum_boards.flid, forum_boards.title AS board, forum_categories.clid, forum_categories.title AS cat,
							  forum_posts.tstamp, forum_posts.edit_tstamp, forum_posts.post_no,
							MATCH ( forum_posts.content ) AGAINST ( ". $keywords ." ) AS relevancy
				  		FROM forum_posts
				   			LEFT JOIN forum_threads ON ( forum_posts.thread = forum_threads.id )
				   			LEFT JOIN forum_boards ON ( forum_threads.forum = forum_boards.id )
				   			LEFT JOIN forum_categories ON ( forum_boards.cat = forum_categories.id )
				   		WHERE MATCH ( forum_posts.content ) AGAINST ( ". $keywords ." IN BOOLEAN MODE ) 
					  	 ORDER BY relevancy DESC";
			}
			
			$qr .= ' LIMIT '. SEARCH_RESULTS_LIMIT;
			
			$res = $this -> db -> get_all ( $qr );
			
			if ( CACHE_SEARCH )
			{
				$this -> cache -> save ( serialize ( $res ) );
			}
			
			return $res;
		}
	}

?>