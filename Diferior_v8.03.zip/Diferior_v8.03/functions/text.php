<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


# Check if included via index.php
if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


class text
{

	
	# Converts symbols into HTML entities
 	public function convert ( $string, $reverse = false )                                  
  	{
    	$convert = array (
    	// Lithuanian
    	"Ą" => "&#260;",
    	"ą" => "&#261;",
    	"Č" => "&#268;",
    	"č" => "&#269;",
    	"Ė" => "&#278;",
    	"ė" => "&#279;",
    	"Ę" => "&#280;",
    	"ę" => "&#281;",
    	"Į" => "&#302;",
    	"į" => "&#303;",
    	"Š" => "&#352;",
    	"š" => "&#353;",
    	"Ū" => "&#362;",
    	"ū" => "&#363;",
    	"Ų" => "&#370;",
    	"ų" => "&#371;",
    	"Ž" => "&#381;",
    	"ž" => "&#382;",
    	// Russian
    	"Ў" => "&#1038;",
    	"Џ" => "&#1039;",
    	"А" => "&#1040;",
    	"Б" => "&#1041;",
    	"В" => "&#1042;",
    	"Г" => "&#1043;",
    	"Д" => "&#1044;",
    	"Е" => "&#1045;",
    	"Ж" => "&#1046;",
    	"З" => "&#1047;",
    	"И" => "&#1048;",
    	"Й" => "&#1049;",
    	"К" => "&#1050;",
    	"Л" => "&#1051;",
    	"М" => "&#1052;",
    	"Н" => "&#1053;",
    	"О" => "&#1054;",
    	"П" => "&#1055;",
    	"Р" => "&#1056;",
    	"С" => "&#1057;",
    	"Т" => "&#1058;",
    	"У" => "&#1059;",
    	"Ф" => "&#1060;",
    	"Х" => "&#1061;",
    	"Ц" => "&#1062;",
    	"Ч" => "&#1063;",
    	"Ш" => "&#1064;",
    	"Щ" => "&#1065;",
    	"Ъ" => "&#1066;",
    	"Ы" => "&#1067;",
    	"Ь" => "&#1068;",
    	"Э" => "&#1069;",
    	"Ю" => "&#1070;",
    	"Я" => "&#1071;",
    	"а" => "&#1072;",
    	"б" => "&#1073;",
    	"в" => "&#1074;",
    	"г" => "&#1075;",
    	"д" => "&#1076;",
    	"е" => "&#1077;",
    	"ж" => "&#1078;",
    	"з" => "&#1079;",
    	"и" => "&#1080;",
    	"й" => "&#1081;",
    	"к" => "&#1082;",
    	"л" => "&#1083;",
    	"м" => "&#1084;",
    	"н" => "&#1085;",
    	"о" => "&#1086;",
    	"п" => "&#1087;",
    	"р" => "&#1088;",
    	"с" => "&#1089;",
    	"т" => "&#1090;",
    	"у" => "&#1091;",
    	"ф" => "&#1092;",
    	"х" => "&#1093;",
    	"ц" => "&#1094;",
    	"ч" => "&#1095;",
    	"ш" => "&#1096;",
    	"щ" => "&#1097;",
    	"ъ" => "&#1098;",
    	"ы" => "&#1099;",
    	"ь" => "&#1100;",
    	"э" => "&#1101;",
    	"ю" => "&#1102;",
    	"я" => "&#1103;",             
    	);
    	
    	if ( $reverse )
    	{
    		$convert = array_flip ( $convert );
    		$string = strtr ( $string, $convert );
    		
    		# Quickly replace remaining HTML entities
    		$string = html_entity_decode ( $string, ENT_NOQUOTES );
    		
    		return $string;
    	}
    	else 
    	{
    		$string = strtr ( $string, $convert );
    		
    		return $string;
    	}
  	}

  	
  	# Converts HTML entities back into symbols (alias to $this -> convert (), for compatibility issues)
 	public function convert_r ( $string )                                     
  	{
    	return $this -> convert ( $string, true );
  	}  


  	# Generates random pronounceable string
	public function pronounceable ( $len = 6 )
 	{
   		$l1 = array ( "w", "r", "t", "p", "s", "d", "f", "g", "h", "j", "k", "l", "z", "c", "v", "b", "n", "m" );
   		$l2 = array ( "e", "y", "u", "i", "o", "a" );
   		$l3 = array ( "r", "t", "p", "s", "d", "f", "g", "h", "k", "l", "z", "v", "b", "n", "m" );
   	
   		$cl1 = count ( $l1 ) -1;
   		$cl2 = count ( $l2 ) -1;
   		$cl3 = count ( $l3 ) -1;
   	
   		$last = rand ( 1, 2 );
   	
   		$str = null;
   	
   		for ( $i = 0; $i < $len -1; $i++ )
   		{
   			if ( $last == 1) 
   			{
   				$rnr = rand ( 1, 3 );
   		
   				if ( $i < $len / 2 ) 
   				{
   					$rnr = 3;
   				}
   			
   				if ( $rnr == 1 || $rnr == 2 )
   				{
   					$str .= $l1 [ rand ( 0, $cl1 ) ];
   					$last = 1;
   				} 
   				else 
   				{
   					$str .= $l2 [ rand ( 0, $cl2 ) ];
   					$last = 2;
   				}
   			} 
   			else 
   			{
   				$str .= $l1 [ rand ( 0, $cl1 ) ];
   				$last = 1;
   			}
   		}
   
   		if ( in_array ( $str [ strlen ( $str ) -1 ], $l2 ) ) 
   		{
   			$str .= $l3 [ rand ( 0, $cl3 ) ];
   		}
   		else 
   		{
   			$str .= $l2 [ rand ( 0, $cl2 ) ];
   		}
   	
   		return $str;	
 	}	
	
 
 	# Generates random string
 	public function random ( $len = 6, $lower = false )
 	{
 		$possible = str_shuffle ( "qwertyuiopasdfghjkzxcvbnmQWERTYUPASDFGHJKLZXCVBNM23456789" );
 		$strlen = 56; // <-- strlen($possible) -1;
 		
 		$str = null;
 		
 		for ( $i = 0; $i < $len; $i++ )
 		{
 			$str .= $possible [ rand ( 1, $strlen ) -1 ];
 		}
 		
 		return ( $lower ? strtolower ( $str ) : $str );	
 	}
 	
 	
 	# Pre-parses text (blog posts, comments, you name it)
 	# This function has to be tidied up :/
 	public function parse_post ( $txt, $cat = null, $post = null, $parse_html = false, $preview = false, $shorten = false, 
 								 $id = null, $mobile = false, $paragraph = 'p', $readall = null )
 	{
 		if ( CACHE_POSTS )
 		{
 			$cache = & core::get_object ( 'cache' );
 			$cache -> init ( 'bpost_'. $id .'_'. ( $shorten ? 'short' : 'full' ) .'_'. ( $mobile ? 'mob' : 'web' ), 120, CACHE_POSTS );
 			$cached = $cache -> get ();
 			if ( $cached !== false )
 			{
 				return $cached;	
 			}
 			else 
 			{
 				$res = $this -> do_parse_post ( $txt, $cat, $post, $parse_html, $preview, $shorten, $mobile, $paragraph, $readall );
 				$cache -> save ( $res );
 				return $res;	
 			}
 		}
 		else 
 		{
 			return $this -> do_parse_post ( $txt, $cat, $post, $parse_html, $preview, $shorten, $mobile, $paragraph, $readall );
 		}
 	}
 	
 	
  	# Does the actual text parsing (escaping, bbcode, etc)
  	public function do_parse_post ( $txt, $cat = null, $post = null, $parse_html = false, $preview = false, $shorten = false, 
  									$mobile = false, $paragraph = 'p', $readall = null )
  	{
  		# Get language object
  		if ( !isset ( $this -> lang_obj ) )
  		{
  			$this -> lang_obj =	& core::get_object ( 'language' );
  		}
  		$l = & $this -> lang_obj;
  		
  		# Blog post attachment URL
  		$attachment_dir = 'http://'. URL .'/'. DIR_POSTS .'/'. $cat .'/'. $post.'/';	
  		
  		$txt = trim ( $txt );
  		
  		# Text length
  		$txt_len = strlen ( $txt );
  		
  		# If $shorten == true and [break] is set, return everything up to it
  		$pos = stripos ( $txt, '[break]' );
  		if ( $pos !== false )
  		{
  			if ( $shorten )
  			{
  				$txt = trim ( substr ( $txt, 0, $pos ) );	
  				# Add ... after shortened text?
  				if ( $txt_len == $pos +7 )
  				{
  					$shorten_add = false;
  				}
  				else 
  				{
  					$shorten_add = true;
  					$shorten_add_dots = false;	
  				}
  			}
  			else
  			{
  				$txt = str_ireplace ( '[break]', null, $txt );
  			}
  		}
  		else 
  		{
  			if ( $shorten && $txt_len > 700 )
  			{
  				$txt = $this -> shorten ( $txt, 700, null );
  				$shorten_add = true;
  			}
  			else 
  			{
  				$shorten_add = false;	
  			}
  		}
  		  		
  		# Escape HTML (if HTML parsing is disabled)
  		if ( $parse_html == false )
  		{
  			$txt = htmlspecialchars ( $txt );
  		}
  		
  		# Add \r where missing
  		$txt = preg_replace ( "[^\r?]\n", "\r\n", $txt );
  		
   		# Quotes &#8222; &#8220;
   		$txt = $this -> replace_quotes ( $txt );
   		
  		# [b] [i] [u] [size] [color]
  		$txt = preg_replace ( "#\[b\](.*?)\[/b\]#i", "<b>\\1</b>", $txt );
  		$txt = preg_replace ( "#\[i\](.*?)\[/i\]#i", "<i>\\1</i>", $txt );
  		$txt = preg_replace ( "#\[u\](.*?)\[/u\]#i", "<span class=\"bbcode_u\">\\1</span>", $txt );
  		$txt = preg_replace ( "#\[size=([0-9]+)\](.*?)\[/size\]#i", "<span style=\"font-size: \\1px\">\\2</span>", $txt );
  		$txt = preg_replace ( "#\[color=\#?([0-9abcdef]{3,6})\](.*?)\[/color\]#i", "<span style=\"color: #\\1\">\\2</span>", $txt );
  		
  		# (c) (r) (tm)
   		$txt = preg_replace( "#\(c\)#i", "&copy;", $txt );
   		$txt = preg_replace( "#\(tm\)#i", "&#153;", $txt );
   		$txt = preg_replace( "#\(r\)#i", "&reg;", $txt );
  		
   		# Unicode 
   		$txt = preg_replace( "#&amp;\#([0-9]+);#s", "&#\\1;", $txt );
   		
  		# URL, email
  			# [url]X://www...[/url] 
   			$txt = preg_replace( "#\[url\]\s*([\w]+?://[\w\#$%&~/.\-;:=,?@\[\]+]*?)\s*\[/url\]#is", '<a href="\1" rel="external">\1</a>', $txt );

   			# [url]www....[/url] 
   			$txt = preg_replace( "#\[url\]\s*((?:www|ftp)\.[\w\#$%&~/.\-;:=,?@\[\]+]*?)\s*\[/url\]#is", '<a href="http://\1" rel="external">\1</a>', $txt );

   			# [url=X://www....]...[/url] 
   			$txt = preg_replace( "#\[url=([\w]+?://[\w\#$%&~/.\-;:=,?@\[\]+]*?)\]([^?\n\r\t].*?)\[/url\]#is", '<a href="\1" rel="external">\2</a>', $txt );

   			# [url=www....]...[/url] 
   			$txt = preg_replace( "#\[url=((?:www|ftp)\.[\w\#$%&~/.\-;:=,?@\[\]+]*?)\]([^?\n\r\t].*?)\[/url\]#is", '<a href="http://\1" rel="external">\2</a>', $txt );

   			# [email]x@y.z[/email] 
   			$txt = preg_replace( "#\[email\]\s*([a-z0-9&\-_.]+?@[\w\-]+\.([\w\-\.]+\.)?[\w]+)\s*\[/email\]#is", '<a href="mailto:\1" rel="external">\1</a>', $txt );

    		# [email=x@y.z]...[/email] 
   			$txt = preg_replace( "#\[email=([a-z0-9&\-_.]+?@[\w\-]+\.([\w\-\.]+\.)?[\w]+)\]([^?\n\r\t].*?)\[/email\]#is", '<a href="mailto:\1" rel="external">\3</a>', $txt );
  		
   		# Url auto-replace
   		$txt = ' '. $txt .' ';
   		$txt = preg_replace ( "#(\s)([\w]+?://[\w\#$%&~/.\-;:=,?@\[\]+]+)(\s)#is", '\1<a href="\2" rel="external">\2</a>\3', $txt );	
   		$txt = trim ( $txt );	
   		
   		# Smilies
   		$txt = $this -> parse_smilies ( $txt );		
   			
   		if ( $cat != null && $post != null )
   		{
   			# Attached images
   			if ( !$mobile )
   			{
   				if ( $cat != 'forum' && $post != 'forum' )
   				{
   					$txt = preg_replace ( "#\[img=([a-z0-9\._\-\(\)]+)\s*(.*?)\]([^\[]+)\[/img\]#sie", '$this->bbcode_img ( \''. $attachment_dir .'\', \'\\1\', \'\\3\', \'\\2\' )', $txt );
   				}
   				$txt = preg_replace ( "#\[img\]http://([\w\#$%&~/.\-;:=,?@\[\]+]*?(?:\.jpg|\.gif|\.png))\[/img\]#si", '<img src="http://\1" alt="'. $l -> t ( 'bbcode_image' ) .'" />', $txt );
   			}
   			else 
   			{
   				$txt = preg_replace ( "#\[img=([a-z0-9\._\-\(\)]+).*?\]([^\[]+)\[/img\]#si", '<img src="http://'. URL .'/images/mobile/image.gif" alt="'. $l -> t ( 'bbcode_image_short' ) .':" /><a href="'.$attachment_dir.'\1">\2</a>', $txt );
   			}
   			
   			# Attached files
   			if ( $cat != 'forum' && $post != 'forum' )
   			{
   				$txt = preg_replace ( "#\[file=([a-z0-9\._\-\(\) ]+)\]([^\[]+)\[/file\]#si", '<a href="'.$attachment_dir.'\1">\2</a>', $txt );
   			}
   			
   			$txt_lower = strtolower ( $txt );

   			# Quote
   			if ( substr_count ( $txt_lower, '[quote]' ) == substr_count ( $txt_lower, '[/quote]' ) )
   			{
   				$txt = preg_replace ( '#\[quote\]\s*#is', '[quote]', $txt );
   				$txt = preg_replace ( '#\s*\[/quote\]#is', '[/quote]', $txt );
   				$txt = str_ireplace ( '[quote]', '<span class="post_quote">', $txt );	
   				$txt = str_ireplace ( '[/quote]', '</span>', $txt );	
   			}
   			
   			# Code
   			if ( substr_count ( $txt_lower, '[code]' ) == substr_count ( $txt_lower, '[/code]' ) )
   			{
				$txt = preg_replace ( "#\[code\]\s*(.*?)\s*\[/code\]#sie", "'<span class=\"post_code\">'. \$this -> highlight_code ( '\\1' ) .'</span>'", $txt );
   			}
   			
   			unset ( $txt_lower );
   			
   			# Advertisement (can be implemented into blog posts if needed)
   			if ( $cat != 'forum' && $post != 'forum' )
   			{
   				$txt = preg_replace ( "#\[_ad\]#i", null, $txt, 1 );
   			}
   		}
   		
   		if ( $shorten && $shorten_add )
   		{
   			if ( $readall == null )
   			{
   				$readall = core::get_object ( 'url' ) -> make ( 'read', $cat, $post );
   			}
   			$txt .= ( !isset ( $shorten_add_dots ) || $shorten_add_dots == true ? '...' : null ) .' <a href="'. $readall .'">['. $l -> t ( 'bbcode_read_more' ) .']</a>';	
   		}
   		
   		# Remove newline excess
   		$txt = preg_replace ( "#[\r\n]{3,}#", "\r\n\r\n", $txt );
   		
   		# Separate paragraphs and replace double newlines into <br/>s
   		if ( $cat != null && $post != null && $cat != 'forum' && $post != 'forum' )
   		{
   			$txt = str_replace ( "\r\n\r\n", '<br/><br/>'. ( $paragraph != null ? '</'. $paragraph .'><'. $paragraph .'>' : null ) , $txt );
   		}
   		
   		# Change remaining newlines
  		$txt = trim ( $txt );
   		$txt = str_replace ( "\r\n", '<br/>', $txt );
  		
  		$txt = $this -> text_wrap ( $txt );
  		
  		return $txt;
  	}
  	
  	
  	# Highlight PHP code
  	public function highlight_code ( $txt )
  	{
  		$txt = htmlspecialchars_decode ( $txt );
  		
  		if ( substr ( $txt, 0, 2 ) != '<?' ) 
  		{
  			$txt = '<?php '. $txt .' ?>';
  			$added_tags = true;
  		}
  		
  		$txt = preg_replace ( "#<img src=\\\\\"[^\\\\]+\\\\\" alt=\\\\\"([^\\\\]+)\\\\\" name=\\\\\"smilie_img\\\\\" class=\\\\\"smilie\\\\\" />#s", '\1', $txt );
  		
  		$txt = strtr ( $txt, array ( '&#8222;' => '"', '&#8220;' => '"' ) );
  		$txt = highlight_string ( $txt, true );
  		$txt = strtr ( $txt, array ( '<code>' => null, '</code>' => null, '&nbsp;' => ' ', '<br />' => ' ' ) );
  		
  		# Remove php tags if added automatically
  		if ( isset ( $added_tags ) )
  		{
  			if ( preg_match ( "#^<span style=\"color: \#000000\">\s<span style=\"color: \#0000BB\">&lt;\?php </span>(.*)<span style=\"color: \#0000BB\">\?&gt;</span>\s</span>\$#i", $txt, $m ) )
  			{
  				$txt = '<span style="color: #000000"> '. $m [ 1 ] .' </span>';	
  			}
  		}
  		
  		return $txt; 
  	}
  	
  	
  	# Quotes &#8222; &#8220;
  	public function replace_quotes ( $txt )
  	{
   		$txt = preg_replace ( "#(?:&quot;|,,)(.+?)&quot;#m", '&#8222;\1&#8220;', $txt );
   		return $txt;
  	}
  	
   		
  	# Image in text (bbcode)
  	public function bbcode_img ( $atdir, $img, $txt, $args )
  	{
  		$args = strtolower ( $args );
  		$args = strtr ( $args, array ( '&#8222;' => '"', '&#8220;' => '"' ) );
  		
  		$float = true;
  		
  		if ( substr_count ( $args, 'float=left' ) )
  		{
  			$fl_left = true;
  		}
  		elseif ( substr_count ( $args, 'float=right' ) )
  		{
  			$fl_left = false;
  		}
  		else 
  		{
  			$float = false;	
  		}
  		
  		$ret = '<img src="'. $atdir . $img .'" alt="'. $txt . '"'. ( $float ? ( $fl_left ? ' class="fl_left"' : ' class="fl_right"' ) : null ) .'/>';
  		
  		if ( preg_match ( "#title=[\\\\\"']+([^\\\\\"']+)[\\\\\"']+#", $args, $m ) )
  		{
  			$ret = '<div class="post_img'. ( $float ? ( $fl_left ? ' fl_left' : ' fl_right' ) : ' fl_left' ) .'">'. $ret .'<div>'. $m [ 1 ] .'</div></div>';
  		}
  		
  		return $ret;
  	}
  	
  	
  	# Easy variable validation by template
  	public function validate ( $str, $template )
  	{
  		switch ( $template )
  		{
  			
  			default:
  					throw new error ( 'Invalid validation template' );
  				break;	
  				
  			case 'lid':
  			case 'plid':
  					return (bool)preg_match ( "#^[a-zA-Z0-9\-_]+\$#", $str );
  				break;
  				
  			case 'username':
  					return (bool)preg_match ( "#^[a-zA-Z0-9_\-\+\.,:@%\^\*=\[\]{}]+\$#", $str );
  				break;
  				
  			case 'email':
  					return (bool)preg_match ( "#^[a-z0-9&\-_.]+?@[\w\-]+\.([\w\-\.]+\.)?[\w]+\$#i", $str );
  				break;
  				
  			case 'literal':
  					return (bool)preg_match ( "#^[ąčęėįšųūžĄČĘĖĮŠŲŪŽa-z0-9, ]+\$#i", $str );
  				break;
  				
  			case 'url':
  					return (bool)preg_match ( "#^[\w]+?://[\w\#$%&~/.\-;:=,?@\[\]+]*?\$#i", $str );
  				break;
  				
  			case 'imageurl':
  					return (bool)preg_match ( "#^http://[\w\#$%&~/.\-;:=,?@\[\]+]*?(?:\.jpg|\.gif|\.png)\$#i", $str );
  				break;
  				
  		}	
  	}
  	
  	
  	# Create *lid format string (lettersnumbers-)
  	public function make_lid ( $txt )
  	{
  		$repl = array (
  			// Lithuanian
  			'ą' => 'a',
  			'č' => 'c',
  			'ę' => 'e',
  			'ė' => 'e',
  			'į' => 'i',
  			'š' => 's',
  			'ų' => 'u',
  			'ū' => 'u',
  			'ž' => 'z',
  			'Ą' => 'a',
  			'Č' => 'c',
  			'Ę' => 'e',
  			'Ė' => 'e',
  			'Į' => 'i',
  			'Š' => 's',
  			'Ų' => 'u',
  			'Ū' => 'u',
  			'Ž' => 'z',
  			// Russian
    		'Ў' => 'u',
    		'Џ' => 'c',
    		'А' => 'a',
    		'Б' => 'b',
    		'В' => 'v',
    		'Г' => 'g',
    		'Д' => 'd',
    		'Е' => 'e',
    		'Ж' => 'zh',
    		'З' => 'z',
    		'И' => 'i',
    		'Й' => 'j',
    		'К' => 'k',
    		'Л' => 'l',
    		'М' => 'm',
    		'Н' => 'n',
    		'О' => 'o',
    		'П' => 'p',
    		'Р' => 'r',
    		'С' => 's',
    		'Т' => 't',
    		'У' => 'u',
    		'Ф' => 'f',
    		'Х' => 'h',
    		'Ц' => 'ts',
    		'Ч' => 'ch',
    		'Ш' => 'sh',
    		'Щ' => 'shch',
    		'Ъ' => '',
    		'Ы' => 'y',
    		'Ь' => '',
    		'Э' => 'e',
    		'Ю' => 'ju',
    		'Я' => 'ja',
    		'а' => 'a',
    		'б' => 'b',
    		'в' => 'v',
    		'г' => 'g',
    		'д' => 'd',
    		'е' => 'e',
    		'ж' => 'zh',
    		'з' => 'z',
    		'и' => 'i',
    		'й' => 'j',
    		'к' => 'k',
    		'л' => 'l',
    		'м' => 'm',
    		'н' => 'n',
    		'о' => 'o',
    		'п' => 'p',
    		'р' => 'r',
    		'с' => 's',
    		'т' => 't',
    		'у' => 'u',
    		'ф' => 'f',
    		'х' => 'h',
    		'ц' => 'ts',
    		'ч' => 'ch',
    		'ш' => 'sh',
    		'щ' => 'shch',
    		'ъ' => '',
    		'ы' => 'y',
    		'ь' => '',
    		'э' => 'e',
    		'ю' => 'ju',
    		'я' => 'ja',    			
  		);
  		$txt = strtr ( strtolower ( $txt ), $repl );
  		$txt = preg_replace ( "#[^a-z0-9\-_]+#", '-', $txt );
  		$txt = trim ( $txt, '-' );
  		if ( $txt == null ) $txt = '-';
  		return $txt;
  	}
  	
  	
  	# Decode unicode URL (from php.net comments)
  	public function decode_unicode_url ( $str )
	{
  		$res = null;
  		
  		$i = 0;
  		$max = strlen ( $str ) - 6;
  		while ( $i <= $max )
  		{
    		$character = $str [ $i ];
    		if ( $character == '%' && $str [ $i + 1 ] == 'u' )
    		{
    			$value = hexdec ( substr ( $str, $i + 2, 4 ) );
      			$i += 6;

      			if ( $value < 0x0080 ) // 1 byte: 0xxxxxxx
      			{
        			$character = chr ( $value );
      			}
      			elseif ($value < 0x0800) // 2 bytes: 110xxxxx 10xxxxxx
      			{
       	 			$character =
            					chr ( ( ( $value & 0x07c0 ) >> 6 ) | 0xc0 )
          					  . chr ( ( $value & 0x3f ) | 0x80 );
      			}
      			else // 3 bytes: 1110xxxx 10xxxxxx 10xxxxxx
      			{
        			$character =
         					    chr ( ( ( $value & 0xf000 ) >> 12 ) | 0xe0 )
          					  . chr ( ( ( $value & 0x0fc0 ) >> 6 ) | 0x80 )
          					  . chr ( ( $value & 0x3f ) | 0x80 );
      			}
    		}
    		else
    		{
      			$i++;
    		}

    		$res .= $character;
  		}

  		return $res . substr ( $str, $i );
	}
  	
	
	# Wordwrap long lines
	public function text_wrap ( $text, $size = 80, $sep = ' ' ) 
	{
   		$new_text = null;
   		$tmp = null;
   		$text_1 = explode ( '>', $text );
   		$sizeof = sizeof ( $text_1 );
   		for ( $i = 0; $i < $sizeof; $i++ ) 
   		{
       		$text_2 = explode ( '<', $text_1 [ $i ] );
       		if ( !empty ( $text_2 [ 0 ] ) ) 
       		{
           		$tmp = preg_replace ( '#([^\n .]{'. $size .'})#i', '\\1'.$sep, $text_2 [ 0 ] );
           		
           		# Restore HTML entities
           		if ( preg_match_all ( '#&\#\d+?\s+?\d*?;#', $tmp, $m ) )
           		{
           			foreach ( $m [ 0 ] as $v )
           			{
           				$tmp = str_replace ( $v, str_replace ( ' ', null, $v ), $tmp );
           			}
           		}
           		
           		$new_text .= $tmp;
         	}
       		if ( !empty ( $text_2 [ 1 ] ) ) 
       		{
           		$new_text .= '<' . $text_2 [ 1 ] . '>';  
       		}
   		}
   		return $new_text;
	} 
	
	
	# Substr til the end of the word
	public function shorten ( $text, $length = 64, $tail = '...' ) 
	{
		$text = trim ( $text );
		$txtl = strlen ( $text );
		if ( $txtl > $length ) 
		{
			for ( $i = 1; $text [ $length - $i ] != ' '; $i++ ) 
			{
				if ( $i == $length )
				{
					return substr ( $text, 0, $length ) . $tail;
				}
			}
			$text = substr ( $text, 0, $length - $i + 1 ) . $tail;
		}
		return $text;
	}
	
	
	# Parse smilies
	public function parse_smilies ( $txt, $callback = false )
	{
		if ( $callback )
		{
			$smilies = $this -> get_smilies ();
		
			$dir = 'http://'. URL .'/tpl_resources/'. $_SESSION [ 'template_dir' ] .'/images/smilies/';
			return '<img src="'. $dir . $smilies [ $txt ] .'.gif" alt="'. $txt .'" name="smilie_img" class="smilie" />';	
		}
		
		/*
			# Uncomment and run this block of code to generate new regex if any smilies have been altered in get_smilies method.
			$smilies_keys = array_map ( 'preg_quote', array_keys ( $smilies ) );
			$regex = "#(?<!\w)(". implode ( '|', $smilies_keys ) .")(?!\w)#se";
			throw new error ($regex);
		*/
		
		// Smilies list ([hook: smilies list])
		$regex = '#(?<!\w|&\#8222;)(\:\)|\:\(\(|\:\(|\:DD|\:D|\:o|0_0|o_o|O_O|\:P|\:confused\:|B\)|\:shy\:|&gt;\:\(|o_O|O_o|\:angry\:|\:mad\:|&gt;_&gt;|-_-|8D|\:\||&gt;_&lt;|8\)|\:-\(|x\(|\:-\)|&lt;_&lt;|\:/|\:wacko\:|\^_\^|;\)|\:\\\\)(?!\w|&\#8220;)#se';
		$txt = preg_replace ( $regex, '$this -> parse_smilies ( "\1", true )', $txt );
		
		return $txt;
	}

	
	# Return array of smilies
	public function get_smilies ( $unique = false )
	{
		// ([hook: smilie array])
		$smilies = array (
				':)' => 'smile',
				':((' => 'crying',
				':(' => 'sad',
				':DD' => 'laugh',
				':D' => 'biggrin',
				':o' => 'amazed',
				'0_0' => 'blink',
				'o_o' => 'blink',
				'O_O' => 'blink',
				':P' => 'cheesy',
				':confused:' => 'confused',
				'B)' => 'cool',
				':shy:' => 'embarrased',
				'&gt;:(' => 'evil',
				'o_O' => 'huh',
				'O_o' => 'huh',
				':angry:' => 'mad',
				':mad:' => 'mad',
				'&gt;_&gt;' => 'notrust',
				'-_-' => 'noworry',
				'8D' => 'nuts',
				':|' => 'oh',
				'&gt;_&lt;' => 'push',
				'8)' => 'rolleyes',
				':-(' => 'sad-2',
				'x(' => 'sick',
				':-)' => 'smile-2',
				'&lt;_&lt;' => 'suspicious',
				':/' => 'unsure',
				':wacko:' => 'wacko',
				'^_^' => 'wink',
				';)' => 'wink',
				':\\' => 'worried',
			);
			
		if ( $unique )
		{
			$smilies = array_unique ( $smilies );
		}
			
		return $smilies;
	}
	
}

?>