<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class contact 
	{

		# Objects
		private $text, $language;
		
		
		public function __construct ()
		{
			$this -> text = & core::get_object ( 'text' );
			$this -> language = & core::get_object ( 'language' );
		}
		
		
		# Sends email
		public function email ( $email, $topic, $message )
		{
			# Message not empty?
			if ( trim ( $message ) == null )
			{
				return array ( $this -> language -> t ( 'contact_err_message_empty' ) );
			}
			
			# Email empty?
			if ( $email == null )
			{
				if ( $_SESSION [ 'logged' ] && $_SESSION [ 'userinfo' ] [ 'email_validate' ] == null )
				{
					$email = $_SESSION [ 'userinfo' ] [ 'email' ];
				}
				else 
				{
					return array ( $this -> language -> t ( 'contact_err_email_empty' ) );
				}	
			}
			
			# Validate e-mail address
			if ( !$this -> text -> validate ( $email, 'email' ) || strlen ( $email ) > 32 )
			{
				return array ( $this -> language -> t ( 'contact_err_email_invalid' ) );	
			}
			
			# Set topic
			if ( $topic < 1 || $topic > 4 )
			{
				return array ( $this -> language -> t ( 'contact_err_topic_invalid' ) );
			}
			
			if ( $topic == 1 )
				$topic_str = $this -> language -> t ( 'contact_topic_article' );
			elseif ( $topic == 2 )
				$topic_str = $this -> language -> t ( 'contact_topic_abuse' );
			elseif ( $topic == 3 )
				$topic_str = $this -> language -> t ( 'contact_topic_bug' );
			elseif ( $topic == 4 )
				$topic_str = $this -> language -> t ( 'contact_topic_other' );
				
			# Remove excess whitespace
			$message = preg_replace ( "#[\n\r]{3,}#", "\n\n", $message );
			$message = preg_replace ( "#\s{3,}#", "  ", $message );	
				
			# Add information about user
			$message .= "\n\n======================================\n". $this -> language -> t ( 'contact_body_info' ) .":\n======================================\n";
 		    $message .= ( $_SESSION [ 'logged' ] ? $this -> language -> t ( 'contact_body_user' ) .': '. $_SESSION [ 'user' ] ."\n" : null )
 		           	 . $this -> language -> t ( 'contact_body_email' ) .': '. $email ."\n"
 		           	 . $this -> language -> t ( 'contact_body_date' ) .': '. date ( "y-m-d H:i:s" ) ."\n";
 		    $message .= "======================================\n"
 		           	 . ( isset ( $_SERVER [ 'HTTP_ACCEPT' ] ) 					? 'HTTP_ACCEPT: '. $_SERVER [ 'HTTP_ACCEPT' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_ACCEPT_CHARSET' ] ) 			? 'HTTP_ACCEPT_CHARSET: '. $_SERVER [ 'HTTP_ACCEPT_CHARSET' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_ACCEPT_ENCODING' ] ) 			? 'HTTP_ACCEPT_ENCODING: '. $_SERVER [ 'HTTP_ACCEPT_ENCODING' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_ACCEPT_LANGUAGE' ] ) 			? 'HTTP_ACCEPT_LANGUAGE: '. $_SERVER [ 'HTTP_ACCEPT_LANGUAGE' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) 				? 'HTTP_USER_AGENT: '. $_SERVER [ 'HTTP_USER_AGENT' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_X_FORWARDED_FOR' ] ) 			? 'HTTP_X_FORWARDED_FOR: '. $_SERVER [ 'HTTP_X_FORWARDED_FOR' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'REMOTE_ADDR' ] ) 					? 'REMOTE_ADDR: '. $_SERVER [ 'REMOTE_ADDR' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_VIA' ] ) 						? 'HTTP_VIA: '. $_SERVER [ 'HTTP_VIA' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_X_NETWORK_INFO' ] ) 			? 'HTTP_X_NETWORK_INFO: '. $_SERVER [ 'HTTP_X_NETWORK_INFO' ] ."\n" : null )
 		           	 . ( isset ( $_SERVER [ 'HTTP_PROFILE' ] ) 					? 'HTTP_PROFILE: '. $_SERVER [ 'HTTP_PROFILE' ] ."\n" : null )
 		           	 . "======================================\n";	
				
 		    $res = mail ( ADMIN_EMAIL, PAGE_NAME .': '. $topic_str, $message, "From: ". $this -> language -> t ( 'contact_from', PAGE_NAME ) ." <$email>\r\nReply-To: $email"  );
 		    if ( $res )
 		    {
				return array ();
 		    }
 		    else 
 		    {
 		    	return array ( $this -> language -> t ( 'contact_err_send' ) );	
 		    }
		}
		
	}

?>