<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class wap
	{

		
		public function __construct ()
		{
			
		}
		
		
		public function is_wap ()
		{
			//$_SESSION [ 'web' ] = false;
			$subdomain = core::get_object ( 'url' ) -> get_subdomain ();
			$subdomain = strtolower ( $subdomain );
			if ( $subdomain == 'wap' || $subdomain == 'm' || $subdomain == 'mobile' )
			{
				$_SESSION [ 'template' ] = 'mobile';	
				return true;
			}
			
			if ( isset ( $_SESSION [ 'template' ] ) && $_SESSION [ 'template' ] == 'mobile' )
			{
				return true;
			}
			else
			{
				return false;
			}
			
			/*
			$browser = substr ( trim ( ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ) ), 0, 4 );
			
          	if (	$browser=='Noki' || // Nokia phones and emulators
                    $browser=='Eric' || // Ericsson WAP phones and emulators
                    $browser=='WapI' || // Ericsson WapIDE 2.0
                    $browser=='Sony' || // SonyEriccsson
                    $browser=='SIE-' || // Siemens
                    $browser=='MC21' || // Ericsson MC218
                    $browser=='AUR ' || // Ericsson R320
                    $browser=='R380' || // Ericsson R380
                    $browser=='UP.B' || // UP.Browser
                    $browser=='WinW' || // WinWAP browser
                    $browser=='UPG1' || // UP.SDK 4.0
                    $browser=='upsi' || // another kind of UP.Browser ??
                    $browser=='QWAP' || // unknown QWAPPER browser
                    $browser=='Jigs' || // unknown JigSaw browser
                    $browser=='Java' || // unknown Java based browser
                    $browser=='Alca' || // unknown Alcatel-BE3 browser (UP based?)
                    $browser=='MITS' || // unknown Mitsubishi browser
                    $browser=='MOT-' || // unknown browser (UP based?)
                    $browser=='My S' || // unknown Ericsson devkit browser ?
                    $browser=='WAPJ' || // Virtual WAPJAG www.wapjag.de
                    $browser=='fetc' || // fetchpage.cgi Perl script from www.wapcab.de
                    $browser=='ALAV' || // yet another unknown UP based browser ?
                    //$browser=='Oper' || // opera
                    $browser=='Wapa')
               {
                       return true;
               } 
               else 
               {   
                       return false;
               }*/
		}
		
	}

?>