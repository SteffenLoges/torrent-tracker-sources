<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	class language
	{
		# Language file (DIR_LANGUAGES/file.php)
		private $language = null;
		
		# Dictionary (array of keys and values)
		private $dict = array ();
		
		# Default dictionary. Loaded only if requested string is not available in other language. Also known as plan B.
		private $dict_default = array ();
		
		
		# Constructor
		public function __construct ()
		{
			$this -> set ();
			$this -> load ();
		}
		
		
		# Sets language using passed argument / session variable / IP
		public function set ( $lang = null )
		{
			# Passed argument
			if ( $lang != null )
			{
				$this -> language = $lang;	
			}
			# Session variable
			elseif ( isset ( $_SESSION [ 'preferences' ] [ 'language' ] ) ) 
			{
				$this -> language = $_SESSION [ 'preferences' ] [ 'language' ];
			}
			else
			{
				# If autodetect is enabled
				if ( LANG_AUTODETECT )
				{
					if ( function_exists ( 'geoip_country_code_by_name' ) )
					{
						error::toggle_silent ( true );
						$country = geoip_country_code_by_name ( $_SERVER [ 'REMOTE_ADDR' ] );
						error::toggle_silent ( false );
						$this -> language = strtolower ( $country );
					}
					else 
					{
						throw new error ( 'GeoIP library missing. Please install and configure it or disable LANG_AUTODETECT in config.' );	
					}
				}
				else 
				{
					# Default language
					$this -> language = LANG_DEFAULT;	
				}
			}	
			
			$this -> language = $this -> check ();
		}
		
		
		# Checks if language exists
		public function check ( $lang = null )
		{
			if ( $lang == null ) $lang = $this -> language;
			
			if ( $lang != null && file_exists ( DIR_LANGUAGES .'/'. $lang .'.php' ) )
			{
				# K
				return $lang;	
			}
			else 
			{
				return LANG_DEFAULT;
			}
		}
		
		
		# Load dictionary
		private function load ( $lang = null )
		{
			if ( $lang == null ) $lang = $this -> language;
			require_once ( DIR_LANGUAGES .'/'. $lang .'.php' );
			if ( isset ( $this -> defdict ) )
			{
				$this -> dict_default = & $dict;	
			}
			else 
			{
				$this -> dict =	& $dict;
			}
		}
		
		
		# Translate
		public function t ( $key )
		{
			if ( !isset ( $this -> defdict ) )
			{
				$dict = & $this -> dict; 	
			}
			else 
			{
				if ( empty ( $this -> dict_default ) )
				{
					$this -> load ( LANG_DEFAULT );	
				}
				$dict = & $this -> dict_default;	
			}
			
			if ( isset ( $dict [ $key ] ) )
			{
				$str = $dict [ $key ];
				
				# Replace arguments
				$arg_count = 0;
				for ( $i = 1, $max = func_num_args(); $i < $max; $i++ )
				{
					$arg = func_get_arg ( $i );
					if ( !empty ( $arg ) )
					{
						if ( !is_array ( $arg ) )
						{
							$arg_count++;
							$str = str_replace ( '{a:'. $arg_count .'}', $arg, $str );	
						}
						else 
						{
							foreach ( $arg as $arg_el )
							{
								$arg_count++;
								$str = str_replace ( '{a:'. $arg_count .'}', $arg_el, $str );	
							}	
						}
					}
				}
				
				return $str;
			}
			else 
			{
				if ( !isset ( $this -> defdict ) && $this -> language != LANG_DEFAULT )
				{
					$this -> defdict = true;
					# Recursion
					$args = func_get_args ();
					$res = call_user_func_array ( array ( $this, 't' ), $args );
					unset ( $this -> defdict );
					return $res;
				}

				# No translation found.
				return $key;
			}	
		}
		
	}
	
?>