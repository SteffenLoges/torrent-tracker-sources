<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


# Check if included via index.php
if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


class session
{
	private $session_id = null;
	
	private $db;
	
	
	
	# Constructor
	public function __construct ()
	{
		
	}
	
	
	# Initialize and start session
	public function init ()
	{
		# If session set automatically, destroy and set a proper one
		$this -> destroy();	
		
		# Whether to handle sessions via MySQL
		if ( SESS_HANDLER_DB )
		{
			$this -> db = & core::get_object ( 'db' );
			session_set_save_handler ( 
										array ( $this, 'h_open' ),
                        				array ( $this, 'h_close' ),
                       					array ( $this, 'h_read' ),
                       					array ( $this, 'h_write' ),
                       					array ( $this, 'h_destroy' ),
                       					array ( $this, 'h_gc' )
                       				  );	
		}
		
		# Set lifetime and save path
		ini_set ( 'session.gc_maxlifetime', SESS_LIFETIME );
		session_save_path ( SESS_DIR );
		
		# Do not pass SID through cookies automatically
		ini_set ( 'session.use_cookies', false );
		
		# Get 'url' class
		$url = & core::get_object ( 'url' ); 
		
		# If SID transfer method is set to 'auto' and cookie exists, use it, otherwise - URL.
		if ( strtolower ( SESS_METHOD ) == 'auto' )
		{
			$auto = true;
			if ( isset ( $_COOKIE [ 'sessid' ] ) )
			{
				$method = 'cookie';
			}
			else 
			{
				$method = 'url';
			}
		}
		else 
		{
			$auto = false;	
			$method = SESS_METHOD;
		}
		
		# SID from URL
		if ( strtolower ( $method ) == 'url' )
		{
			$this -> session_id = & $url -> sid;
		}
		else 
		{
			# SID from cookie
			if ( isset ( $_COOKIE [ 'sessid' ] ) )
			{
				if ( $this -> sid_check ( $_COOKIE [ 'sessid' ] ) )
				{
					$this -> session_id = $_COOKIE [ 'sessid' ];
				}
			}
			
			# Do not pass SID through URL
			$url -> add_sid = false;
		}
		
		# Do not add sid to url if page is being prepared for static caching
		if ( CACHE_STATIC != null )
		{
			$url -> add_sid = false;	
		}
		
		if ( $this -> session_id != null )
		{
			session_id ( $this -> session_id );
		}
			
		if ( $this -> session_id != 'nosid' && CACHE_STATIC == null ) 
		{
			$this -> start ();
		
			# Check if session was not hijacked
			if ( isset ( $_SESSION [ 'useragent' ] ) && isset ( $_SESSION [ 'ip' ] ) )
			{
				# Had to disable useragent check for BitLet compatibility
				if ( /*$_SESSION [ 'useragent' ] != $_SERVER [ 'HTTP_USER_AGENT' ] ||*/ $_SESSION [ 'ip' ] != $_SERVER [ 'REMOTE_ADDR' ] )
				{
					# Stolen session
					$this -> destroy ();
					$this -> start ();
				}
			}
			else 
			{
				$_SESSION [ 'ip' ] = $_SERVER [ 'REMOTE_ADDR' ];	
				$_SESSION [ 'useragent' ] = ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null );
			}
		}
		
		# If SID transfer method is 'auto', attempt to set cookie.
		if ( $auto && $this -> session_id != 'nosid' )
		{
			setcookie ( 'sessid', session_id (), time () +SESS_LIFETIME, '/', SESS_COOKIE_DOMAIN );
		}
		
		# Set URL arguments that were used previously (probably should move this to url class)
		if ( isset ( $_SESSION [ 'curr_args' ] ) )
		{
			$_SESSION [ 'prev_args' ] = $_SESSION [ 'curr_args' ];
		}
		$_SESSION [ 'curr_args' ] = $url -> get_args ();
		
		$url -> sid = session_id ();
		
	}
	
	
	# Destructor
	public function __destruct()
	{
		session_write_close ();
	}
	
	
	# Starts a new session
	private function start ()
	{
		$this -> check_path ();
		$res = session_start ();
	}
	
	
	# Checks if session path is readable and writable
	private function check_path ()
	{
		if ( !is_readable ( SESS_DIR ) || !is_writable ( SESS_DIR ) )
		{
			throw new error ( 'Could not start a new session. Please make sure that '. str_replace ( DIR .'/', null, SESS_DIR ) .' is chmodded to 0777' );	
		}
	}
	
	
	# Check if SID is valid
	private function sid_check ( $session_id )
	{
		if ( $session_id == 'nosid' ) 
			return true;
			
		if ( !SESS_HANDLER_DB && file_exists ( SESS_DIR .'/sess_'. $session_id ) )
		{
			return true;
		}
		elseif ( SESS_HANDLER_DB && preg_match ( "#^[a-zA-Z0-9_]+\$#", $session_id ) )
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
	
	
	# Destroy session
	public function destroy()
	{
		if ( isset ( $_SESSION ) )
		{
			//if ( !empty ( $_SESSION ) )
			//{
				if ( @session_destroy () ) 
				return true; 
				else 
				return false;
			//} 
			//else 
			//return false;
		} 
		else 
		return false;
	}
	
    
    
    ### MySQL session handler functions

    # Open the session
    public function h_open ()
    {
    	return true;
    }
    
    
    # Close the session
    public function h_close () 
    {
        return true;
    }

    
    # Read the session
    public function h_read ( $sid ) 
    {
        $sid = $this -> db -> escape ( $sid );
        $res = $this -> db -> get_one ( "SELECT data FROM sessions WHERE sid='". $sid ."'" );
        if ( $res )
        {
        	return $res;
        }
        else 
        {
        	return null;
        }
    }

    
    # Write the session
    public function h_write ( $sid, $data ) 
    {
    	$sid = $this -> db -> escape ( $sid );
    	$data = $this -> db -> escape ( $data );
        return $this -> db -> query ( "REPLACE INTO sessions SET sid='". $sid ."', data='". $data ."', tstamp='". time () ."'" );
    }


    # Destoroy the session
    public function h_destroy ( $sid ) 
    {
        $sid = $this -> db -> escape ( $sid );
        return $this -> db -> query ( "DELETE FROM sessions WHERE sid='". $sid ."'" );
	}


	# Garbage Collector
    public function h_gc ( $max ) 
    {
        $timeout = time () - $max;
        return $this -> db -> query ( "DELETE FROM sessions WHERE tstamp<". $timeout );
    }
	
}
?>