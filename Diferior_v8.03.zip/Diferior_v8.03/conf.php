<?php
	
	/*
		This file should not be edited in text editor. Use installer to set-up Diferior and AdminCP to configure it.
	*/

	#################################################
	
		# Page name
		define ( 'PAGE_NAME', 'My Site' );
		
		# Page slogan or description
		define ( 'PAGE_SLOGAN', 'Powered by Diferior' );
	
	#################################################
	
		# Site URL (without http:// and ending slash)
		define ( 'URL', $_SERVER [ 'HTTP_HOST' ] . str_replace ( '/index.php', null, $_SERVER [ 'PHP_SELF' ] ) );
		
		# Tracker URL (full). {torrent_pass} will be replaced into user's torrent pass if private tracker is configured.
		//define ( 'T'RACKER_URL', 'http://'. $_SERVER [ 'HTTP_HOST' ] .':2710/{torrent_pass}/announce' );
		//define ( 'T'RACKER_URL', 'http://'. URL .'/tracker/announce.php?torrent_pass={torrent_pass}' );
		define ( 'TRACKER_URL', 'http://'. URL .'/tracker/announce.php?torrent_pass={torrent_pass}' );
		
		# Scrape URL
		define ( 'SCRAPE_URL', preg_replace ( '#/announce([^/]*)$#', '/scrape\1', TRACKER_URL ) );
		
		# Enable url-rewriting. This must be enabled if mod_rewrite is configured correctly and working properly.
		define ( 'URL_REWRITING', true );

	#################################################
	
		# MySQL server hostname (if you are not sure, it's probably 'localhost')
		define ( 'DB_HOST', 'localhost' );
		
		# MySQL username and password
		define ( 'DB_USER', '' );
		define ( 'DB_PASS', '' );
		
		# DB name
		define ( 'DB_NAME', 'diferior' );
		
		# Table prefix
		define ( 'DB_PREFIX', 'dif_' );	
		
	#################################################
	
		# Send mail from this address
		define ( 'MAIL_FROM', 'donotreply@'. $_SERVER [ 'HTTP_HOST' ] );
		
		# Administrator contact e-mail
		define ( 'ADMIN_EMAIL', '' );
		
	#################################################

		# Timezone (see http://php.net/manual/en/timezones.php for options)
		define ( 'DEFAULT_TIMEZONE', 'GMT' );
		
	#################################################
	
		# Default language
		define ( 'LANG_DEFAULT', 'en' );
		
		# Attempt to autodetect language? (requires GeoIP (http://php.net/geoip) and it's ip2country database installed and working)
		define ( 'LANG_AUTODETECT', false );
		
	#################################################
	
		# Default template (id)
		define ( 'DEFAULT_TEMPLATE', 'skio' );
	
	#################################################
	
		# Enable blog?
		define ( 'FUNC_BLOG', true );
		
		# Enable download system?
		define ( 'FUNC_DOWNLOADS', true );
		
		# Enable HTTP link downloads?
		define ( 'FUNC_DOWNLOADS_HTTP', true );
		
		# Enable torrent downloads?
		define ( 'FUNC_DOWNLOADS_TORRENT', true );
		
		# Show downloads on site title?
		define ( 'TITLE_DOWNLOADS', true );
		
		# Enable forums?
		define ( 'FUNC_FORUMS', true );
		
		# Enable contact form?
		define ( 'FUNC_CONTACT', true );
		
		# Enable RSS?
		define ( 'FUNC_RSS', true );
		
		# Enable visit and online counters (site title)?
		define ( 'FUNC_COUNTERS', true );
		
		# Enable new user e-mail validation?
		define ( 'FUNC_USER_VALIDATION', true );
		
		# Enable anonymous comments?
		define ( 'FUNC_ANONYMOUS_COMMENTS', true );
		
		# Enable tagging for blog posts and downloads?
		define ( 'FUNC_TAGS', false );
		
		# Enable private messages?
		define ( 'FUNC_PM', true );
	
	#################################################
	
		# Perform scrape (must be enabled if using external tracker or local tracker that does not log number of seeders/leechers in dl_downloads table)
		define ( 'PERFORM_SCRAPE', false );
		
		# Max number of torrents to scrape at once
		define ( 'SCRAPE_TORRENTS_MAX', 100 );
		
	#################################################
	
	#------ ADVANCED OPTIONS BELOW THIS LINE -------#
		
	#################################################	
		
		# System path to site root
		define ( 'DIR', dirname ( __FILE__ ) );

		# Temporary directory (webserver readable and writable)
		define ( 'TMP', DIR .'/temp' );
		
		# Path to function files directory
		define ( 'DIR_FUNCTIONS', DIR .'/functions' );
		
		# Path to views directory
		define ( 'DIR_VIEWS', DIR .'/views' );
		
		# Path to language files directory
		define ( 'DIR_LANGUAGES', DIR .'/languages' );
		
		# Path to blog post attachment directory (without DIR prefix, webserver readable and writable)
		define ( 'DIR_POSTS', 'post_files' );
		
		# Path to .torrent files directory (webserver readable and writable)
		define ( 'DIR_TORRENT', DIR .'/torrents' );
		
		# Path to .nfo files directory (webserver readable and writable)
		define ( 'DIR_NFO', DIR .'/nfo' );
		
	#################################################
		
		# Path to Smarty.class.php
		define ( 'SMARTY_PATH', 'smarty/Smarty.class.php' );
	 
		# Path to compiled templates folder
		define ( 'SMARTY_COMPILE_DIR', TMP .'/cpl_templates' );
		
		# Path to templates directory
		define ( 'SMARTY_TEMPLATES_DIR', DIR .'/templates' );
		
	#################################################
	
		# Error reporting level
		 # 0 - Only error messages are displayed, without revealing any sensitive data
		 # 1 - Errors displayed without revealing system path
		 # 2 - Errors displayed with full system path
		 # 3 - Display file trace
		 # 4 - Displays included file paths
		define ( 'ERR_LEVEL', 0 );
	
		# File path for error logging (leave null to disable logging)
		define ( 'ERR_FILE', null );
	
	#################################################
	
		# Save session data in DB. If clean URLs are used, setting to true is A MUST.
		define ( 'SESS_HANDLER_DB', false );
	
		# Session file lifetime (172800 sec = 48 h)
		define ( 'SESS_LIFETIME', 172800 );
		
		# Session save path
		define ( 'SESS_DIR', TMP .'/sessions' );
		
		# SID transfer method ('auto', 'url' or 'cookie')
		define ( 'SESS_METHOD', 'auto' );
		
		# Domain for setting cookies
		define ( 'SESS_COOKIE_DOMAIN', '.'. $_SERVER [ 'HTTP_HOST' ] );
	
	#################################################
	
		# Simulate cron? Disable if you have manually added appropriate entries to your crontab file.
		define ( 'SIMULATE_CRON', true );
		
		# Simulated PHP cron uptime checking timeout. It's most likely not to go down, so no need to be overly paranoid.
		define ( 'CRON_CHECK_TIMEOUT', 1800 );
	
	#################################################
	
		# URL format. 
		 # 1 - view.domain.com/arg1/arg2 (experimental, requires wildcard DNS entry set up and httpd configured accordingly)
		 # 2 - domain.com/view/arg1/arg2 (prefered)
		define ( 'URL_TYPE', 2 );
	
	#################################################
		
		# Default number of blog posts per page
		define ( 'BLOG_POSTS', 10 );
		
		# Default number of downloads per page
		define ( 'DL_POSTS', 20 );
		
		# Search results per page
		define ( 'SEARCH_RESULTS', 20 );
		
		# Search result limit
		define ( 'SEARCH_RESULTS_LIMIT', 200 );
		
		# Default number of comments per page
		define ( 'COMMENTS_PAGE', 10 );
		
		# Default number of forum threads per page
		define ( 'FORUM_THREADS_PAGE', 20 );
		
		# Default number of forum posts per page
		define ( 'FORUM_POSTS_PAGE', 10 );
		
		# Default number of private messages per page
		define ( 'PM_PAGE', 20 );
	
	#################################################
	
		# Max comment length
		define ( 'COMMENT_LIMIT_LEN', 100000 );
		
		# Max forum post length
		define ( 'POST_LIMIT_LEN', 100000 );
		
		# Max private message length
		define ( 'PM_LIMIT_LEN', 100000 );
	
	#################################################
		
		# Enable caching in various places, like blog post list, downloads list, etc (useful only for sites that receive A LOT traffic, otherwise not recommended)
		define ( 'CACHE', false );
	
		# Directory to keep cached files
		define ( 'CACHE_DIR', TMP .'/cache' );
	
		# Directory to keep static-cached files
		define ( 'CACHE_STATIC_DIR', DIR .'/static' );
		define ( 'CACHE_STATIC_URL', URL .'/static' );
		
		# Set to true to cache blog posts (independent from CACHE value)
		define ( 'CACHE_POSTS', false );
	
		# Set to true to cache search results (independent from CACHE value, recommended to turn on)
		define ( 'CACHE_SEARCH', true );
		
		# Set to true to cache homepage (joint blog post / downloads list) (independent from CACHE value, recommended to turn on)
		define ( 'CACHE_TITLE', true );
		
		# Set to true to cache RSS (independent from CACHE value, recommended to turn on)
		define ( 'CACHE_RSS', true );
		
		# Set to true to cache blog and download tag clouds (independent from CACHE value, recommended to turn on)
		define ( 'CACHE_TAGS', true );
		
		# Interval to cache userinfo in session
		define ( 'USERINFO_REFRESH', 300 );
		
	#################################################
	
		# Output generation time (for benchmarking / performance purposes)?
		define ( 'GENERATION_TIME', true );	
	
	#################################################
	
		# Torrent comment (set automatically when uploading .torrent file)
		define ( 'TORRENT_COMMENT', 'http://'. URL );
		
		# Min ratio (if user ratio < RATIO_WARNING, warning will be issued)
		define ( 'RATIO_WARNING', '0.3' );
		
		# Time user will be immune to ratio autowarning after registration (172800 (sec) = 48 h)
		define ( 'AUTOWARN_IMMUNE_TIME', 172800 );
		
		# BitLet enabled for files smaller than this number (in bytes) (52428800 B = 50 M, 1073741824 B = 1 G)
		define ( 'BITLET_FSIZE', 1073741824 );
		
	#################################################
	
		# Max avatar width (in pixels)
		define ( 'AVATAR_MAXWIDTH', 150 );
		
		# Max avatar height (in pixels)
		define ( 'AVATAR_MAXHEIGHT', 150 );
		
		# Max avatar size (in bytes) (204800 B = 200 K)
		define ( 'AVATAR_MAXSIZE', 204800 );
		
	#################################################
	
		# Set to true to watermark blog attachment images?
		define ( 'BLOG_WATERMARK', false );
		
		# Min image width and height to watermark (in pixels) (image will not be watermarked if width < WATERMARK_MINWIDTH or height < WATERMARK_MINHEIGHT)
		define ( 'WATERMARK_MINWIDTH', 400 );
		define ( 'WATERMARK_MINHEIGHT', 300 );
		
		# Path to watermark image
		define ( 'WATERMARK_IMAGE', 'watermark.png' );
		
		# System path
		define ( 'WATERMARK_PATH', DIR .'/tpl_resources/watermark/'. WATERMARK_IMAGE );
		# URL, without http://
		define ( 'WATERMARK_URL', URL .'/tpl_resources/watermark/'. WATERMARK_IMAGE );
	
	#################################################
	
		# Font for NFO image generation
		define ( 'NFO_FONT', DIR .'/resources/nfo_font.png' );
		
		# Set to true to allow ordinary users view NFO files (otherwise only those with permission to do so will be able to view NFOs)
		define ( 'VIEW_NFO', true );
		
	#################################################
	
		# Log moderator actions (editing, removing, approving, etc)?
		define ( 'LOG', true );
		
		# Log entries per page
		define ( 'LOG_PAGE', 50 );
	
	#################################################
	
		# How many seconds have to pass since thread's last message so it will be marked as old (172800 (sec) = 48 h)?
		define ( 'THREAD_TIMEOUT', 172800 );
		
		# Thread AntiFlood interval (3600 (sec) = 1 h)
		define ( 'FORUM_THREAD_ANTIFLOOD', 300 );
		
		# Post AntiFlood interval (120 (sec) = 2 min)
		define ( 'FORUM_POSTS_ANTIFLOOD', 120 );
		
	#################################################
	
		# PM box limit
		define ( 'PM_LIMIT', 100 );
		
		# PM AntiFlood interval (30 (sec) = 0.5 min)
		define ( 'PM_ANTIFLOOD', 30 );
	
	#################################################
	
		# Enables public anonymous bittorrent tracker support. 
		# Set `anonymous_scrape`, `anonymous_announce`, `anonymous_connect` to 1 in `xbt_config` mysql table and restart xbt (if using XBTT backend, that is).
		define ( 'TRACKER_ANONYMOUS', false );
		
		# Tracker type. 'PHP', 'XBTT' or 'Other'
		define ( 'TRACKER_TYPE', 'PHP' );
		
		# Max number peers (seeders+leechers) to prefetch when listing torrent details
		define ( 'TRACKER_PEER_PRE', 40 );
		
		# Max number peers (seeders+leechers) to allow listing
		define ( 'TRACKER_PEER_MAX', 200 );
	
	#################################################
	
		# Log user IP addresses (if disabled, md5 hash of IP address will be logged instead)
		define ( 'STORE_USER_IP', false );
	
	#################################################
?>
