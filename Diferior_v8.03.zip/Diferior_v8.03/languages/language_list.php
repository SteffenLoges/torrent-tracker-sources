<?php

	$language_list = array (
		array ( 'title' => 'English', 'own_title' => 'English', 'author' => 'UnrealX', 'file' => 'en' ),
		array ( 'title' => 'Lithuanian', 'own_title' => 'Lietuvių', 'author' => 'UnrealX', 'file' => 'lt' ),
	);

?>