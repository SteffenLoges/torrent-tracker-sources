// This needs to be rewritten... badly

function cat_mvup(id)
{
	if ( id == 1 ) return;
	
	var src = document.getElementById ( 'ch_'+id );
	var dst = document.getElementById ( 'ch_'+(id-1) );
	
	var src_cont = src.innerHTML.replace ( 'cat_mvup('+id+')', 'cat_mvup('+(id-1)+')' )
								.replace ( 'cat_mvdn('+id+')', 'cat_mvdn('+(id-1)+')' )
								.replace ( 'value="position_'+id+'"', 'value="position_'+(id-1)+'"' )
								.replace ( eval('/cat_sub_mvup\\('+id+',/g'), 'cat_sub_mvup('+(id-1)+',' )
								.replace ( eval('/cat_sub_mvdn\\('+id+',/g'), 'cat_sub_mvdn('+(id-1)+',' )
								.replace ( eval('/subch_'+id+'_/g'), 'subch_'+(id-1)+'_' );
	var dst_cont = dst.innerHTML.replace ( 'cat_mvup('+(id-1)+')', 'cat_mvup('+id+')' )
								.replace ( 'cat_mvdn('+(id-1)+')', 'cat_mvdn('+id+')' )
								.replace ( 'value="position_'+(id-1)+'"', 'value="position_'+id+'"' )
								.replace ( eval('/cat_sub_mvup\\('+(id-1)+',/g'), 'cat_sub_mvup('+id+',' )
								.replace ( eval('/cat_sub_mvdn\\('+(id-1)+',/g'), 'cat_sub_mvdn('+id+',' )
								.replace ( eval('/subch_'+(id-1)+'_/g'), 'subch_'+id+'_' );
	
	src.innerHTML = dst_cont;
	dst.innerHTML = src_cont;
	
	var src_subcount = eval ( 'admin_subcat_count_'+id );
	var dst_subcount = eval ( 'admin_subcat_count_'+(id-1) );
	eval ( 'admin_subcat_count_'+id+'='+dst_subcount );
	eval ( 'admin_subcat_count_'+(id-1)+'='+src_subcount );
}


function cat_mvdn(id)
{
	if ( id == admin_cat_count ) return;
	
	var src = document.getElementById ( 'ch_'+id );
	var dst = document.getElementById ( 'ch_'+(id+1) );
	
	var src_cont = src.innerHTML.replace ( 'cat_mvup('+id+')', 'cat_mvup('+(id+1)+')' )
								.replace ( 'cat_mvdn('+id+')', 'cat_mvdn('+(id+1)+')' )
								.replace ( 'value="position_'+id+'"', 'value="position_'+(id+1)+'"' )
								.replace ( eval('/cat_sub_mvup\\('+id+',/g'), 'cat_sub_mvup('+(id+1)+',' )
								.replace ( eval('/cat_sub_mvdn\\('+id+',/g'), 'cat_sub_mvdn('+(id+1)+',' )
								.replace ( eval('/subch_'+id+'_/g'), 'subch_'+(id+1)+'_' );
	var dst_cont = dst.innerHTML.replace ( 'cat_mvup('+(id+1)+')', 'cat_mvup('+id+')' )
								.replace ( 'cat_mvdn('+(id+1)+')', 'cat_mvdn('+id+')' )
								.replace ( 'value="position_'+(id+1)+'"', 'value="position_'+id+'"' )
								.replace ( eval('/cat_sub_mvup\\('+(id+1)+',/g'), 'cat_sub_mvup('+id+',' )
								.replace ( eval('/cat_sub_mvdn\\('+(id+1)+',/g'), 'cat_sub_mvdn('+id+',' )
								.replace ( eval('/subch_'+(id+1)+'_/g'), 'subch_'+id+'_' );
	
	src.innerHTML = dst_cont;
	dst.innerHTML = src_cont;
	
	var src_subcount = eval ( 'admin_subcat_count_'+id );
	var dst_subcount = eval ( 'admin_subcat_count_'+(id+1) );
	eval ( 'admin_subcat_count_'+id+'='+dst_subcount );
	eval ( 'admin_subcat_count_'+(id+1)+'='+src_subcount );
}


function cat_sub_mvup(id,subid)
{
	if ( subid == 1 ) return;
	
	var src = document.getElementById ( 'subch_'+id+'_'+subid );
	var dst = document.getElementById ( 'subch_'+id+'_'+(subid-1) );
	
	var src_cont = src.innerHTML.replace ( 'cat_sub_mvup('+id+','+subid+')', 'cat_sub_mvup('+id+','+(subid-1)+')' )
								.replace ( 'cat_sub_mvdn('+id+','+subid+')', 'cat_sub_mvdn('+id+','+(subid-1)+')' )
								.replace ( 'value="subposition_'+subid+'"', 'value="subposition_'+(subid-1)+'"' );
	var dst_cont = dst.innerHTML.replace ( 'cat_sub_mvup('+id+','+(subid-1)+')', 'cat_sub_mvup('+id+','+subid+')' )
								.replace ( 'cat_sub_mvdn('+id+','+(subid-1)+')', 'cat_sub_mvdn('+id+','+subid+')' )
								.replace ( 'value="subposition_'+(subid-1)+'"', 'value="subposition_'+subid+'"' );
	
	src.innerHTML = dst_cont;
	dst.innerHTML = src_cont;
}


function cat_sub_mvdn(id,subid)
{
	if ( subid == eval('admin_subcat_count_'+id) ) return;
	
	var src = document.getElementById ( 'subch_'+id+'_'+subid );
	var dst = document.getElementById ( 'subch_'+id+'_'+(subid+1) );
	
	var src_cont = src.innerHTML.replace ( 'cat_sub_mvup('+id+','+subid+')', 'cat_sub_mvup('+id+','+(subid+1)+')' )
								.replace ( 'cat_sub_mvdn('+id+','+subid+')', 'cat_sub_mvdn('+id+','+(subid+1)+')' )
								.replace ( 'value="subposition_'+subid+'"', 'value="subposition_'+(subid+1)+'"' );
	var dst_cont = dst.innerHTML.replace ( 'cat_sub_mvup('+id+','+(subid+1)+')', 'cat_sub_mvup('+id+','+subid+')' )
								.replace ( 'cat_sub_mvdn('+id+','+(subid+1)+')', 'cat_sub_mvdn('+id+','+subid+')' )
								.replace ( 'value="subposition_'+(subid+1)+'"', 'value="subposition_'+subid+'"' );
	
	src.innerHTML = dst_cont;
	dst.innerHTML = src_cont;
}


function tracker_choose (type, change_url)
{
	var anonymous = document.getElementById ( 'anonymous' );
	var announce = document.getElementById ( 'announce' );
	var scrape = document.getElementById ( 'scrape' );
	
	if ( type == 0 )
	{
		anonymous.disabled=true;
		announce.disabled=true;
		scrape.disabled=true;
		//anonymous.value=1;
	}
	else if ( type == 1 )
	{
		anonymous.disabled=false;
		announce.disabled=false;
		scrape.disabled=false;
		//anonymous.value=0;
		if ( change_url )
		{
			announce.value=announce_url_php;
			scrape.value=scrape_url_php;
		}
	}
	else if ( type == 2 )
	{
		anonymous.disabled=false;
		announce.disabled=false;
		scrape.disabled=false;
		//anonymous.value=0;
		if ( change_url )
		{
			announce.value=announce_url_xbtt;
			scrape.value=scrape_url_xbtt;
		}
	}
	else if ( type == 3 )
	{
		anonymous.disabled=true;
		announce.disabled=false;
		scrape.disabled=false;
		anonymous.value=1;
		if ( change_url )
		{
			announce.value='http://open.tracker.thepiratebay.org/announce';
			scrape.value='http://open.tracker.thepiratebay.org/scrape';
		}
	}
}