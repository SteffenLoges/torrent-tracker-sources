// Preview upload
function preview_upload ()
{
	var obj = document.getElementById ( 'preview_box' );
	var cntnr = document.getElementById ( 'post_container' );
	cntnr.style.visibility = 'visible';
	cntnr.style.height = 'auto';
	obj.innerHTML = '<p><img src="../images/wait.gif" alt="..." /> Loading...</p>';
	
	http = getHTTPObject ();
	http.open ( 'POST', upload_preview_url, true );
	http.onreadystatechange = handle_preview;
	http.setRequestHeader ( 'Content-Type', 'application/x-www-form-urlencoded' );
	var post_content = document.getElementById ( 'txt' );
	var category = document.getElementsByName ( 'category' ) [ 0 ];
	var header = document.getElementsByName ( 'header' ) [ 0 ];
	var usehtml = document.getElementsByName ( 'usehtml' ) [ 0 ];
	var data = 'content='+ escape ( post_content.value ) +'&cat='+ category.value +'&post='+ escape ( header.value);
	http.send( data );
}