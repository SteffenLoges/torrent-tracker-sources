// Fetch seeder/leecher list

var seed_fetched = false;
var leech_fetched = false;

function fetch_peers ( type, id )
{
	exp_flist ( type+'_list', type+'_link' );	

	if ( eval ( type+'_fetched' ) == false )
	{
		http = getHTTPObject ();
		var post_url = eval('file_req_'+type+'_url');
		http.open ( 'POST', post_url, true );
		http.onreadystatechange = eval('handle_fetch_'+type);
		http.setRequestHeader ( 'Content-Type', 'application/x-www-form-urlencoded' );
		http.send( 'fid='+id );
	}
}

// Handle response (I have to look for a way to join these two functions together)
function handle_fetch_seed () 
{
	if ( http.readyState == 4 ) 
	{
		seed_fetched = true;
		var obj = document.getElementById ( 'seed_list' );
		obj.innerHTML = '<div class="flist_file">'+ http.responseText +'</div>';
		obj.style.height = '500px';
		obj.style.overflow = 'auto';
		target_height_seed_list = 500;
		expanded_flist_seed_list = false;
		exp_flist ( 'seed_list', 'seed_link' );
	}
}
function handle_fetch_leech () 
{
	if ( http.readyState == 4 ) 
	{
		leech_fetched = true;
		var obj = document.getElementById ( 'leech_list' );
		obj.innerHTML = '<div class="flist_file">'+ http.responseText +'</div>';
		obj.style.height = '500px';
		obj.style.overflow = 'auto';
		target_height_leech_list = 500;
		expanded_flist_leech_list = false;
		exp_flist ( 'leech_list', 'leech_link' );
	}
}