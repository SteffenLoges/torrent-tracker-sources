try 
{
	document.addEventListener ( 'click', handleClick, false );
} catch ( e ) 
{
	if ( document.attachEvent ) 
	{
		document.attachEvent ( 'onclick', handleClick );
	} 
	else 
	{
		document.onclick = handleClick;
	}
}

// Handle mouse clicks
function handleClick ( e ) 
{
	var event = e || window.event;
	
	if ( event.ctrlKey || event.shiftKey || event.altKey ) 
	{
		return true;
	}
	
	if ( event.which && event.which != 1) 
	{
		return true;
	}

	var target = event.target || event.srcElement;
	
	while ( target && !/^a$/i.test ( target.nodeName ) ) 
	{
		target = target.parentNode;
	}

	if ( !target || !target.getAttribute ( 'rel' ) ) 
	{
		return true;
	}

	var rel = target.getAttribute ( 'rel' );
	var href = target.getAttribute ( 'href' );
	
	switch ( rel ) 
	{
		default:
				return true;
			break;
	
		case 'external':
				window.open ( href );
			break;
			
		case 'download':
				window.open ( external_pfx + href );
			break;
	
		case 'external_dif':
				window.open ( href + '/in/' +  ( escape ( main_url ) ) );
			break;
	}

    try { event.preventDefault (); } catch ( e ) {}
    return false;
}

	
// Clear input if default value is set
function emptydef ( obj, defval )
{
	if ( obj.value == defval ) obj.value = '';	
}


// Reload captcha
function reload_image ( obj )
{
	var d = new Date ();
	obj.src=obj.src.replace ( /\/[0-9]+\.jpg/, '/'+d.getTime()+'.jpg' );
}


// Find object X and Y positions (by Peter-Paul Koch & Alex Tingle)
function findPosX ( obj )
{
	var curleft = 0;
	if ( obj.offsetParent )
	{
		while ( 1 ) 
		{
			curleft += obj.offsetLeft;
			if ( !obj.offsetParent )
			{
				break;
			}
			obj = obj.offsetParent;
		}
	}
	else if ( obj.x )
	{
		curleft += obj.x;
	}
	return curleft;
}

function findPosY ( obj )
{
	var curtop = 0;
	if ( obj.offsetParent )
	{
		while ( 1 )
		{
			curtop += obj.offsetTop;
			if ( !obj.offsetParent )
			{
				break;
			}
			obj = obj.offsetParent;
		}
	}
	else if ( obj.y )
	{
		curtop += obj.y;
	}
	return curtop;
}


// Submit comment
function comment_submit ( allow_anonymous )
{
	if ( allow_anonymous || logged ) 
	{
		// Logged in, continue
		document.getElementById ( 'comment_form' ).submit ();	
	}
	else
	{
		var holder = document.getElementById ( 'comment_login' );
		var button = document.getElementById ( 'comment_button' );
		holder.style.visibility = 'visible';
		holder.style.left = findPosX ( button ) +'px';
		holder.style.top = findPosY ( button ) +'px';
		default_comment_button_value = button.value;
		button.value = '';
	}
}


// Hide login warning in comment form
function comment_warning ()
{
	var holder = document.getElementById ( 'comment_login' );
	var button = document.getElementById ( 'comment_button' );
	holder.style.visibility = 'hidden';
	button.value = default_comment_button_value;
}


// Expand banner
function exp_flist ( obj_name, link_name )
{
		// Global
		eval ( 'obj_'+obj_name+' = document.getElementById ( obj_name )' );	
			
		if ( eval('typeof(fsize_first_'+obj_name+')' ) == 'undefined' )
		{
			eval ( 'target_height_'+obj_name+' = obj_'+obj_name+'.style.height.replace ( \'px\', \'\' )' );
			eval ( 'fsize_first_'+obj_name+'=false' );
			eval ( 'flist_size_'+obj_name+'=0' );
		}
		
		// Private
		var link = document.getElementById ( link_name );
		if ( eval ( 'typeof(expanded_flist_'+obj_name+')' ) != 'undefined' && eval ( 'expanded_flist_'+obj_name ) )
		{
			// Collapse
			clearInterval ( eval ( 'tmr_'+obj_name ) );
			link.innerHTML = banner_txt_expand;
			eval ( 'expanded_flist_'+obj_name+' = false' );
			eval ( 'tmr_'+obj_name+' = setInterval ( \'detract_flist(\\\'\'+obj_name+\'\\\')\', 40 )' );
			
			if ( typeof ( dl_search_box ) != 'undefined' ) create_cookie ( 'dl_search_collapsed', 'true', 7 );
		}
		else
		{
			// Expand
			if ( eval ( 'typeof ( tmr_'+obj_name+' )' ) != 'undefined' ) clearInterval (eval ( 'tmr_'+obj_name ));
			link.innerHTML = banner_txt_collapse;
			eval ( 'expanded_flist_'+obj_name+'=true' );
			eval ( 'obj_'+obj_name+'.style.display = \'block\'' );
			eval ( 'obj_'+obj_name+'.style.height = flist_size_'+obj_name+'+\'px\'' );
			eval ( 'tmr_'+obj_name+' = setInterval ( \'expand_flist(\\\'\'+obj_name+\'\\\')\', 40 )' );
			
			if ( typeof ( dl_search_box ) != 'undefined' ) create_cookie ( 'dl_search_collapsed', null, -1 );
		}
}


function expand_flist ( obj_name )
{
	eval ( 'flist_size_'+obj_name+' += 4' );
	
	var lft = eval ( 'target_height_'+obj_name+' - flist_size_'+obj_name );
	eval ( 'flist_size_'+obj_name+' += lft/(target_height_'+obj_name+'/flist_size_'+obj_name+') ');
	
	if ( eval ( 'flist_size_'+obj_name+' >= target_height_'+obj_name ) )
	{
		eval ( 'flist_size_'+obj_name+' = target_height_'+obj_name );
		clearInterval ( eval ( 'tmr_'+obj_name ) );	
	}
	
	eval ( 'obj_'+obj_name+'.style.height = flist_size_'+obj_name+' +\'px\'' );
}


function detract_flist ( obj_name )
{
	eval ( 'flist_size_'+obj_name+' -= 4' );
	
	if ( eval ( 'flist_size_'+obj_name ) <= 0 )
	{
		eval ( 'flist_size_'+obj_name+' = 0' );
		eval ( 'obj_'+obj_name+'.style.display = \'none\'' );
		eval ( 'obj_'+obj_name+'.style.height = target_height_'+obj_name+' +\'px\'' );
		clearInterval ( eval ( 'tmr_'+obj_name ) );	
	}
	else
	{
		var lft = eval ( 'target_height_'+obj_name+' - flist_size_'+obj_name );
		eval ( 'flist_size_'+obj_name+' -= lft/(target_height_'+obj_name+'/flist_size_'+obj_name+')' );
		eval ( 'obj_'+obj_name+'.style.height = flist_size_'+obj_name+' +\'px\'' );
	}
}


// Open popup
function popup ( url )
{
	window.open ( url, 'popup', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=400, height=500');
	//popup.opener = self;
}


// Save caret position
function storeCaret ( textEl ) 
{
	if ( textEl.createTextRange )
	{
		textEl.caretPos = document.selection.createRange().duplicate();
	}
}


// Insert text at caret
function insertAtCaret ( textEl, text ) 
{
	if (textEl.createTextRange && textEl.caretPos) 
	{
		var caretPos = textEl.caretPos;
		caretPos.text = ( caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text );
	}
	else
	{
		textEl.value  = text;
	}
}


// Add text to input
function add_bbcode ( text, id ) 
{
	var txtarea = document.getElementById ( id );
	if ( txtarea.createTextRange && txtarea.caretPos ) 
	{
		insertAtCaret ( txtarea, text );
		txtarea.focus();
	} 
	else 
	{
		txtarea.value  += text;
		txtarea.focus();
	}
}


// Get HTTP object (AJAX)
//function get_http_obj () 
//{
//	return getHTTPObject ();
//}



// Get HTTP request object (AJAX)
function getHTTPObject () 
{
	var xmlhttp;
	/*@cc_on
	@if ( @_jscript_version >= 5 )
	try 
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) 
	{
		try 
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) 
		{
			xmlhttp = false;
		}
	}
	@else
		xmlhttp = false;
	@end @*/
	if ( !xmlhttp && typeof XMLHttpRequest != 'undefined' ) 
	{
		try 
		{
			xmlhttp = new XMLHttpRequest();
		} catch (e) 
		{
			xmlhttp = false;
		}
	}
	return xmlhttp;
}


// http://www.quirksmode.org/js/cookies.html
function create_cookie ( name, value, days ) 
{
	if ( days ) 
	{
		var date = new Date ();
		date.setTime ( date.getTime () + ( days*86400000 ) );
		var expires = '; expires='+ date.toGMTString ();
	}
	else 
	{
		var expires = '';
	}
	document.cookie = name +'=' + value + expires +'; path=/';
}

function read_cookie ( name ) 
{
	var nameEQ = name + '=';
	var ca = document.cookie.split (';');
	for ( var i = 0; i < ca.length; i++ ) 
	{
		var c = ca [ i ];
		while ( c.charAt ( 0 ) == ' ') c = c.substring ( 1, c.length );
		if ( c.indexOf ( nameEQ ) == 0 ) return c.substring ( nameEQ.length, c.length );
	}
	return null;
}