var clientInfo = navigator.userAgent.toLowerCase();
var isIE = ( clientInfo.indexOf("msie") != -1 );
var isWin = ( (clientInfo.indexOf("win")!=-1) || (clientInfo.indexOf("16bit") != -1) );


// Add input for file attachments
var inputs = 0;
function add_file_input ()
{
	var obj = document.getElementById ( 'upload_container' );
	var newobj = document.createElement ( 'div' );
	newobj.setAttribute ( 'id', 'up'+inputs  );
	newobj.innerHTML = '<input type="file" name="upl[]" /> <a href="javascript:del_file_input(\'up'+inputs+'\')">[x]</a><br/>';
  	inputs++;
  	obj.appendChild ( newobj );
}


// Remove added input
function del_file_input ( id )
{
	var obj = document.getElementById ( 'upload_container' );
	var input = document.getElementById ( id );
	obj.removeChild ( input );
}


// Add simple bbcode tag
function simple_bbcode ( obj, tag )
{
	var txt = document.getElementById ( 'txt' );
	var ieSel = ( isIE && isWin && document.selection.createRange().text!='' );
	var mozSel = ( !isIE && !isWin && txt.selectionEnd - txt.selectionStart > 0 );
	if ( ieSel || mozSel )
	{
		createBBtag ( '['+tag+']', '[/'+tag+']', 'txt' );	
	}
	else
	{
		if ( eval ( 'typeof(bbcode_'+tag+') == \'undefined\'' ) )
		{
			eval ( 'bbcode_'+tag+'=false' );
		}
		
		if ( eval ( 'bbcode_'+tag) )
		{
			// Close
			add_bbcode ( '[/'+tag+']' );
			obj.value = obj.value.substr(0, obj.value.length-2);
			eval ( 'bbcode_'+tag+'=false');
		}
		else
		{
			// Open
			add_bbcode ( '['+tag+']' );
			obj.value = obj.value+' *';
			eval ( 'bbcode_'+tag+'=true');
		}
	}
	storeCaret(txt);
}


// Add text to input
function add_bbcode ( text ) 
{
	var txtarea = document.getElementById ( 'txt' );
	if ( txtarea.createTextRange && txtarea.caretPos ) 
	{
		insertAtCaret ( txtarea, text );
		txtarea.focus();
	} 
	else 
	{
		txtarea.value  += text;
		txtarea.focus();
	}
}


// Got this off google. Looks like IPB JS, but I'm not sure.
function createBBtag( openerTag , closerTag , areaId ) 
{
	if(isIE && isWin) 
	{
		createBBtag_IE( openerTag , closerTag , areaId );
	}
	else 
	{
		createBBtag_nav( openerTag , closerTag , areaId );
	}
	return;
}

function createBBtag_IE ( openerTag , closerTag , areaId ) 
{
	var txtArea = document.getElementById( areaId );
	var aSelection = document.selection.createRange().text;
	var range = txtArea.createTextRange();
	if(aSelection) 
	{
		document.selection.createRange().text = openerTag + aSelection + closerTag;
		txtArea.focus();
		range.move('textedit');
		range.select();
	}
	else 
	{
		var oldStringLength = range.text.length + openerTag.length;
		txtArea.value += openerTag + closerTag;
		txtArea.focus();
		range.move('character',oldStringLength);
		range.collapse(false);
		range.select();
	}
	return;
}

function createBBtag_nav( openerTag , closerTag , areaId ) 
{
	var txtArea = document.getElementById( areaId );
	if (txtArea.selectionEnd && (txtArea.selectionEnd - txtArea.selectionStart > 0) ) 
	{
		var preString = (txtArea.value).substring(0,txtArea.selectionStart);
		var newString = openerTag + (txtArea.value).substring(txtArea.selectionStart,txtArea.selectionEnd) + closerTag;
		var postString = (txtArea.value).substring(txtArea.selectionEnd);
		txtArea.value = preString + newString + postString;
		txtArea.focus();
	}
	else 
	{
		var offset = txtArea.selectionStart;
		var preString = (txtArea.value).substring(0,offset);
		var newString = openerTag + closerTag;
		var postString = (txtArea.value).substring(offset);
		txtArea.value = preString + newString + postString;
		txtArea.selectionStart = offset + openerTag.length;
		txtArea.selectionEnd = offset + openerTag.length;
		txtArea.focus();
	}
	return;
}

// Move caret to input end
function setCaretToEnd ( control ) 
{
	var length = control.value.length;
	if ( control.createTextRange ) 
	{
		var range = control.createTextRange();
		range.collapse(false);
		range.select();
	}
	else if ( control.setSelectionRange ) 
	{
		control.focus();
		control.setSelectionRange(length, length);
	}
	control.scrollTop = length;
}


// Save caret position (+hide img/file popup)
function storeCaret ( textEl ) 
{
	if ( textEl.createTextRange )
	{
		textEl.caretPos = document.selection.createRange().duplicate();
	}
	
	document.getElementById ( 'popup_container' ).style.visibility = 'hidden';
}


// Insert text at caret position
function insertAtCaret ( textEl, text ) 
{
	if (textEl.createTextRange && textEl.caretPos) 
	{
		var caretPos = textEl.caretPos;
		caretPos.text = ( caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text );
	}
	else
	{
		textEl.value  = text;
	}
}


// Show popup for img/file insertion
function show_bbcode ( obj, type )
{
	var popup = document.getElementById ( 'popup_container' );
	var post_form = document.getElementById ( 'post_form' );
	
	var html = '';
	
	for ( i = 0; i < post_form.elements.length; i++ )
	{
		if ( post_form.elements [ i ].type == 'file' )
		{
			var ext = post_form.elements [ i ].value.substr ( -3 ).toLowerCase();
			var fval = post_form.elements[i].value;
			fval = fval.substr ( fval.lastIndexOf('/') +1 );
			fval = fval.substr ( fval.lastIndexOf('\\') +1 );
			if ( type == 'img' && ( ext == 'jpg' || ext == 'png' || ext == 'gif' ) )
			{
				html += '<a href="javascript:add_bbcode(\'[img='+ fval +']Picture[/img]\')">'+ fval +'</a><br/>';
			}
			else if ( type == 'file' && ext != 'jpg' && ext != 'png' && ext != 'gif' && fval != '' )
			{
				html += '<a href="javascript:add_bbcode(\'[file='+ fval +']Download[/file]\')">'+ fval +'</a><br/>';
			}
		}
	}
	
	if ( html == '' )
	{
		html = '&#8212;';	
	}
	
	popup.innerHTML = html;
	popup.style.top = findPosY ( obj )+23 +'px';
	popup.style.left = findPosX ( obj ) +'px';
	popup.style.visibility = 'visible';
}


// Preview post
function preview_post ()
{
	var obj = document.getElementById ( 'preview_box' );
	var cntnr = document.getElementById ( 'post_container' );
	cntnr.style.visibility = 'visible';
	cntnr.style.height = 'auto';
	obj.innerHTML = '<p><img src="../images/wait.gif" alt="..." /> Loading...</p>';
	
	http = getHTTPObject ();
	http.open ( 'POST', post_preview_url, true );
	http.onreadystatechange = handle_preview;
	http.setRequestHeader ( 'Content-Type', 'application/x-www-form-urlencoded' );
	var post_content = document.getElementById ( 'txt' );
	var category = document.getElementsByName ( 'category' ) [ 0 ];
	var header = document.getElementsByName ( 'header' ) [ 0 ];
	var usehtml = document.getElementsByName ( 'usehtml' ) [ 0 ];
	var data = 'content='+ escape ( post_content.value ) +'&cat='+ category.value +'&post='+ escape ( header.value) +'&parse_html='+ usehtml.checked;
	http.send( data );
}


// Handle preview response
function handle_preview () 
{
	if ( http.readyState == 4 ) 
	{
		document.getElementById ( 'preview_box' ).innerHTML = '<p>'+ http.responseText +'</p>';
		location.href='#preview';
	}
}