<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/

	# Set script version
	define ( 'VERSION', '8.03' );
	
	# Only allow calling other scripts via index.php
	define ( 'VIA_INDEX', true );
	
	# Check if everything is in place
	require_once ( './requirements.php' );

	# Default error reporting level (don`t show)
	error_reporting ( 0 );
	
	# If accessing from localhost, try loading separate config file (useful for developing)
	if ( $_SERVER [ 'HTTP_HOST' ] == 'localhost' && file_exists ( './conf.localhost.php' ) ) 
	{
		require_once ( './conf.localhost.php' ); 
	}
	
	# Multisite?
	if ( file_exists ( './multisite.php' ) )
	{
		require_once ( './multisite.php' );	
	}
	else 
	{
		# Load standard config
		require_once ( './conf.php' );
	}

	# Make sure register_globals didn't clutter $GLOBALS
	if ( ini_get ( 'register_globals' ) )
	{
		# From http://php.net/manual/en/faq.misc.php#faq.misc.registerglobals
		
    	if ( isset ( $_REQUEST [ 'GLOBALS' ] ) || isset ( $_FILES [ 'GLOBALS' ] ) ) 
    	{
        	die ( 'GLOBALS overwrite attempt detected' );
    	}

    	$whitelist = array ( 'GLOBALS', '_GET', '_POST', '_COOKIE', '_REQUEST', '_SERVER', '_ENV', '_FILES' );

    	$input = array_merge ( $_GET, $_POST, $_COOKIE, $_SERVER, $_ENV, $_FILES, ( isset ( $_SESSION ) && is_array ( $_SESSION ) ? $_SESSION : array () ) );
    
    	foreach ( $input as $k => $v ) 
    	{
    	    if ( !in_array ( $k, $whitelist ) && isset ( $GLOBALS [ $k ] ) ) 
    	    {
    	        unset ( $GLOBALS [ $k ] );
    	    }
    	}
	}
	
	# Check if page is in static-cache
	require_once ( './static.php' );
	
	# Set include path for pear packages
	//set_include_path ( DIR_FUNCTIONS .'/pear' . PATH_SEPARATOR . get_include_path () );
	set_include_path ( DIR_FUNCTIONS .'/pear' );
	
	# Default timezone
	date_default_timezone_set ( DEFAULT_TIMEZONE );

	# Execution time (for debugging purposes mainly)
	$dbg_start = microtime ();
	
	# Load class for error handling
	require_once ( './error.php' );
	
	# Set custom error and exception handlers
	set_error_handler ( array ( 'error', 'php_error_handler' ) );
	set_exception_handler ( array ( 'error', 'php_exception_handler' ) );
	
	# Get rid of magic_quotes
	ini_set ( 'magic_quotes_runtime', 0 );
	if ( get_magic_quotes_gpc() )
	{
		function array_map_r ( $cback, $arr )
		{
		    $res = array();
		    
		    foreach( $arr as $k => $v )
		    {
		        $res [ $k ] = ( is_array ( $v ) ? array_map_r ( $cback, $v ) : $cback ( $v ) );
		    }
		        
		    return $res;
		}
		$_GET = array_map_r ( 'stripslashes', $_GET );
		$_POST = array_map_r ( 'stripslashes', $_POST );
		$_COOKIE = array_map_r ( 'stripslashes', $_COOKIE );
	}
	
	try 
	{
	
		# Load core class (singleton)
		require_once ( './core.php' );
		
		if ( !file_exists ( './install/lock' ) )
		{
			# Diferior (seems to be) installed, pass execution to ./exec.php
			require_once ( './exec.php' );
		}
		else 
		{
			# Run installer
			ob_start ();
			require_once ( './install/installer.php' );	
		}
			
		ob_end_flush();
		
	}
	catch ( error $e )
	{
		
		error::display_error ( $e );
		
	}

?>