<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	# Check if valid post data is present. If so, save data into session variable and redirect user to next step.
	
	$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
	switch ( $args [ 1 ] )
	{
		default:
				# Invalid step
				header ( 'location: '. $url -> make ( '_' ) );
			break;	
			
		case 1:
				# Nothing to validate
				$nstep = $args [ 1 ] +1;
				if ( $_SESSION [ 'installer_step' ] < $nstep ) 
				{
					$_SESSION [ 'installer_step' ] = $nstep;
				}
				$session -> __destruct ();
				header ( 'location: '. $url -> make ( '_' ) );
			break;
			
		case 2:
				# Check permissions
				$check = array (
							DIR .'/conf.php',
							DIR .'/install/lock',
							DIR_FUNCTIONS .'/pear',
							DIR_NFO,
							DIR .'/'. DIR_POSTS,
							TMP,
							CACHE_DIR,
							SMARTY_COMPILE_DIR,
							TMP .'/online',
							SESS_DIR,
							TMP .'/userinfo',
							DIR_TORRENT,
							CACHE_STATIC_DIR,
				);
				foreach ( $check as $v )
				{
					if ( !check_files ( $v ) )
					{
						# Trouble
						$_SESSION [ 'installer_step' ] = $args [ 1 ];
						header ( 'location: '. $url -> make ( '_' ) );
						die ();
					}
				}
				# Seems to be fine, progress
				$nstep = $args [ 1 ] +1;
				if ( $_SESSION [ 'installer_step' ] < $nstep ) 
				{
					$_SESSION [ 'installer_step' ] = $nstep;
				}
				$session -> __destruct ();
				header ( 'location: '. $url -> make ( '_' ) );
			break;
			
		case 3:
				# MySQL login
				$db = & core::load_file ( 'db' );
				
				$_SESSION [ 'installer_mysql_host' ] = ( isset ( $_POST [ 'host' ] ) ? $_POST [ 'host' ] : null );
				$_SESSION [ 'installer_mysql_username' ] = ( isset ( $_POST [ 'username' ] ) ? $_POST [ 'username' ] : null );
				$_SESSION [ 'installer_mysql_password' ] = ( isset ( $_POST [ 'password' ] ) ? $_POST [ 'password' ] : null );
				$_SESSION [ 'installer_mysql_database' ] = ( isset ( $_POST [ 'database' ] ) ? $_POST [ 'database' ] : null );
				$_SESSION [ 'installer_mysql_prefix' ] = ( isset ( $_POST [ 'prefix' ] ) ? $_POST [ 'prefix' ] : null );
				
				# Check if can login
				$res = $db -> connect ( false, $_SESSION [ 'installer_mysql_host' ], 
									$_SESSION [ 'installer_mysql_username' ], $_SESSION [ 'installer_mysql_password' ],
									$_SESSION [ 'installer_mysql_database' ], true );
									
				if ( $res && preg_match ( "#^[a-zA-Z0-9_]+\$#", $_SESSION [ 'installer_mysql_prefix' ] ) )
				{
					unset ( $_SESSION [ 'installer_mysql_error' ] );
					$nstep = $args [ 1 ] +1;
					if ( $_SESSION [ 'installer_step' ] < $nstep ) 
					{
						$_SESSION [ 'installer_step' ] = $nstep;
					}
				}
				else 
				{
					$_SESSION [ 'installer_mysql_error' ] = true;	
					$_SESSION [ 'installer_step' ] = $args [ 1 ];
				}
				$session -> __destruct ();
				header ( 'location: '. $url -> make ( '_' ) );
			break;
			
		case 4:
				# Admin user setup
				$text = & core::load_file ( 'text' );
				
				$_SESSION [ 'installer_admin_username' ] = ( isset ( $_POST [ 'admin_name' ] ) ? $_POST [ 'admin_name' ] : null );
				$_SESSION [ 'installer_admin_pass1' ] = ( isset ( $_POST [ 'admin_pass1' ] ) ? $_POST [ 'admin_pass1' ] : null );
				$_SESSION [ 'installer_admin_pass2' ] = ( isset ( $_POST [ 'admin_pass2' ] ) ? $_POST [ 'admin_pass2' ] : null );
				$_SESSION [ 'installer_admin_email1' ] = ( isset ( $_POST [ 'admin_email1' ] ) ? $_POST [ 'admin_email1' ] : null );
				$_SESSION [ 'installer_admin_email2' ] = ( isset ( $_POST [ 'admin_email2' ] ) ? $_POST [ 'admin_email2' ] : null );
				
				# Check if fields are filled correctly
				if ( trim ( $_SESSION [ 'installer_admin_username' ] ) == null || trim ( $_SESSION [ 'installer_admin_pass1' ] ) == null || trim ( $_SESSION [ 'installer_admin_email1' ] ) == null
				     || $_SESSION [ 'installer_admin_pass1' ] != $_SESSION [ 'installer_admin_pass2' ] || strtolower ( $_SESSION [ 'installer_admin_email1' ] ) != strtolower ( $_SESSION [ 'installer_admin_email2' ] ) 
				     || strlen ( $_SESSION [ 'installer_admin_username' ] ) < 3 || strlen ( $_SESSION [ 'installer_admin_username' ] ) > 20 || !$text -> validate ( $_SESSION [ 'installer_admin_username' ], 'username' ) )
				{
					$res = false;	
				}
				else 
				{
					$res = true;	
				}
				     	
									
				if ( $res )
				{
					unset ( $_SESSION [ 'installer_admin_error' ] );
					$nstep = $args [ 1 ] +1;
					if ( $_SESSION [ 'installer_step' ] < $nstep ) 
					{
						$_SESSION [ 'installer_step' ] = $nstep;
					}
				}
				else 
				{
					$_SESSION [ 'installer_admin_error' ] = true;	
					$_SESSION [ 'installer_step' ] = $args [ 1 ];
				}
				$session -> __destruct ();
				header ( 'location: '. $url -> make ( '_' ) );
			break;
			
		case 5:
				# PEAR setup
				if ( /*!check_pear ( true ) ||*/ !check_cachelite ( true ) )
				{
					# Trouble
					$_SESSION [ 'installer_step' ] = $args [ 1 ];
					header ( 'location: '. $url -> make ( '_' ) );
					die ();
				}
				# Seems to be fine, progress
				$nstep = $args [ 1 ] +1;
				if ( $_SESSION [ 'installer_step' ] < $nstep ) 
				{
					$_SESSION [ 'installer_step' ] = $nstep;
				}
				$session -> __destruct ();
				header ( 'location: '. $url -> make ( '_' ) );
			break;	
			
		case 6:
				# Smarty setup
				if ( !check_smarty ( true ) )
				{
					# Trouble
					$_SESSION [ 'installer_step' ] = $args [ 1 ];
					header ( 'location: '. $url -> make ( '_' ) );
					die ();
				}
				# Seems to be fine, progress
				$nstep = $args [ 1 ] +1;
				if ( $_SESSION [ 'installer_step' ] < $nstep ) 
				{
					$_SESSION [ 'installer_step' ] = $nstep;
				}
				$session -> __destruct ();
				header ( 'location: '. $url -> make ( '_' ) );
			break;
			
		case 7:
				# Configuration
				/*
				unset ( $_SESSION [ 'installer_mysql_host' ] );
				unset ( $_SESSION [ 'installer_mysql_username' ] );
				unset ( $_SESSION [ 'installer_mysql_password' ] );
				unset ( $_SESSION [ 'installer_mysql_database' ] );
				unset ( $_SESSION [ 'installer_admin_pass2' ] );
				unset ( $_SESSION [ 'installer_admin_email1' ] );
				unset ( $_SESSION [ 'installer_admin_email2' ] );
				*/
				
				# Login
				/*$db = & core::get_object ( 'db' );
				$user = & core::load_file ( 'user' );
				$user -> login ( $_SESSION [ 'installer_admin_username' ], $_SESSION [ 'installer_admin_pass1' ] );
				*/
				
				error::toggle_silent ( true );
				$del = unlink ( DIR .'/install/lock' );
				error::toggle_silent ( false );
				
				if ( !$del ) die ( 'Please manually remove \''. DIR .'/install/lock\' and refresh this page.' );
				
				/*
				unset ( $_SESSION [ 'installer_admin_username' ] );
				unset ( $_SESSION [ 'installer_admin_pass1' ] );
				*/
				
				header ( 'location: '. $url -> make ( '_' ) );
			break;
	}
	
	die ();
?>