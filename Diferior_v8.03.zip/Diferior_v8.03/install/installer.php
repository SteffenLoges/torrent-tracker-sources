<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	
	if ( !is_readable ( SESS_DIR ) || !is_writable ( SESS_DIR ) )
	{
		throw new error ( 'Please chmod \'temp/sessions\' to 0777 and try again.' );	
	}

	$url		= & core::load_file ( 'url' );
	$session 	= & core::load_file ( 'session' );
	if ( SESS_HANDLER_DB )
	{
		$db = & core::load_file ( 'db' );
	}
	$session -> init ();
		
	$args = $url -> get_args ();
	$args [ 0 ] = ( isset ( $args [ 0 ] ) ? $args [ 0 ] : null );
	$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
	
	# Go-pear installer (not needed anymore, but I figured if it's already there, why bother removing :)
	if ( $args [ 0 ] == 'go-pear' )
	{
		error::toggle_silent ( true );
		require_once ( DIR .'/install/go-pear/go-pear.php' );	
		die ();
	}
	
	# url rewriting check
	if ( $args [ 0 ] == 'install' && $args [ 1 ] == 'check_url_rewrite.php' )
	{
		$_SESSION [ 'installer_urlrewrite_check' ] = true;
		$session -> __destruct ();
		header ( 'location: '. $url -> make ( '_' ) );
		die ();	
	}
	
	# url rewriting not checked
	if ( !SESS_HANDLER_DB && !isset ( $_SESSION [ 'installer_urlrewrite_check' ] ) )
	{
		header ( 'location: '. $url -> make ( 'install', 'check_url_rewrite.php' ) );
		die ();	
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Diferior installation script</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="Cache-Control" content="no-cache"/>
<style type="text/css" media="all">
@import "http://<?php echo URL; ?>/tpl_resources/installer/style.css";
</style>
</head>
<body>

	<?php
		require_once ( './install/functions.php' );
		
		# Check for step
		if ( !isset ( $_SESSION [ 'installer_step' ] ) )
		{
			$_SESSION [ 'installer_step' ] = 1;
		}
				
		if ( $args [ 0 ] == 'check' )
		{
			require_once ( './install/check_step.php' );
		}
		
		if ( $args [ 0 ] == 'revisit' )
		{
			$step = ( isset ( $args [ 1 ] ) && is_numeric ( $args [ 1 ] ) && $args [ 1 ] <= $_SESSION [ 'installer_step' ] ? $args [ 1 ] : $_SESSION [ 'installer_step' ] );
		}
		else 
		{
			$step = $_SESSION [ 'installer_step' ];
		}
		
		switch ( $step )
		{
			default:
					$title = 'Welcome!';
				break;
				
			case 2:
					$title = 'Filesystem setup';
				break;
				
			case 3:
					$title = 'MySQL setup';
				break;
				
			case 4:
					$title = 'Admin user setup';
				break;
				
			case 5:
					$title = 'PEAR setup';
				break;
				
			case 6:
					$title = 'Smarty setup';
				break;
				
			case 7:
					$title = 'Configuring CMS';
				break;
		}
	?>

<div class="header">
	<span class="fl_left">Step: <?php echo $step; ?> / 7</span>
	<span class="fl_right">
		<?php 
			if ( $_SESSION [ 'installer_step' ] > 1 )
			{
				echo '<b>Previous steps:</b> ';
				for ( $i = 1; $i <= $_SESSION [ 'installer_step' ]; $i++ ) 
				{ 
					echo '<a href="'. $url -> make ( 'revisit', $i ) .'">'. $i .'</a> '; 
				}
			} 
		?>
	</span>
</div>
	

<div class="holder">
	<div class="title"><?php echo $title; ?></div>
	<form action="<?php echo $url->make('check', $step); ?>" method="post">
	<div class="content">
		<?php
			switch ( $step )
			{
				default:
						// Welcome
						echo '<p>Welcome to <a href="http://diferior.com" target="_blank">Diferior CMS</a> setup! 
								This interactive wizard will help you set-up your copy of the script. 
								If everything goes well, you will have a fully working copy of CMS within minutes! Cool, no?</p>
							  <p>Please follow written instructions carefully. Once you have done what the screen asks, click
							  	\'Next &#187;\' at the bottom.</p>
							  <p>If you make a mistake and want to go back to previous screen, use menu at the top of the page to
							  	quickly jump to wanted step.</p>
							  <br/>
							  <p>Shall we begin?</p>';
					break;
					
				case 2:
						// Filesystem setup
						echo '<p>Checking if file permissions are set correctly:<br/><br/>';
						$check = array (
							DIR .'/conf.php',
							DIR .'/install/lock',
							DIR_FUNCTIONS .'/pear',
							DIR_NFO,
							DIR .'/'. DIR_POSTS,
							TMP,
							CACHE_DIR,
							SMARTY_COMPILE_DIR,
							TMP .'/online',
							SESS_DIR,
							TMP .'/userinfo',
							DIR_TORRENT,
							CACHE_STATIC_DIR,
						);
						foreach ( $check as $v )
						{
							$short = str_replace ( DIR, null, $v );
							if ( check_files ( $v )	)
							{
								# Readable and writable	
								echo '<div><span style="color: #0f0;">PASS</span> <span class="float">'. $short .'</span></div>';
							}
							else 
							{
								# Trouble
								echo '<div><span style="color: #f00;">ERROR</span> <span class="float">'. $short .'</span></div>';
							}
						}
						echo '</p><p>If you have even one error message above, chmod required files/directories to 0777 manually before continuing.</p>';
					break;
					
				case 3:
						// MySQL setup
						echo '<p>Diferior requires MySQL database to function properly. If you are unsure what that is or where to get one, 
								contact your hosting support.</p>
							  <p>Setup will NOT create a new database or user. If they do not exist, you must create them yourself via your hosting panel.</p>
							  <p><b style="color: #f00">Important!</b> Diferior will replace any existing tables. It is HIGHLY advised to install it into a clean database.</p>
							  <p>Please enter your MySQL login data below.</p>
							  <div><span>Username:</span>
							  		<input type="text" name="username" value="'. ( isset ( $_SESSION [ 'installer_mysql_username' ] ) ? $_SESSION [ 'installer_mysql_username' ] : 'diferior_user' ) .'" /></div>
							  <div><span>Password:</span>
							  		<input type="password" name="password" value="" /></div><br/>
							  <div><span>Database name:</span>
							  		<input type="text" name="database" value="'. ( isset ( $_SESSION [ 'installer_mysql_database' ] ) ? $_SESSION [ 'installer_mysql_database' ] : 'diferior' ) .'" /></div>
							  <div><span>Table prefix:</span>
							  		<input type="text" name="prefix" value="'. ( isset ( $_SESSION [ 'installer_mysql_prefix' ] ) ? $_SESSION [ 'installer_mysql_prefix' ] : 'dif_' ) .'" /></div>
							  <div><span>Host:</span>
							  		<input type="text" name="host" value="'. ( isset ( $_SESSION [ 'installer_mysql_host' ] ) ? $_SESSION [ 'installer_mysql_host' ] : 'localhost' ) .'" /></div>';
						if ( isset ( $_SESSION [ 'installer_mysql_error' ] ) )
						{
							echo '<br/><br/><div class="error">Could not connect to MySQL server or specified database using specified login data. Please try again.</div>';	
						}
					break;
					
				case 4:
						// Admin user setup
						echo '<p>Setup your admin user details and contact information. Please make sure all fields are filled in correctly.</p>
							  <div><span>Username:</span>
							  		<input type="text" name="admin_name" value="'. ( isset ( $_SESSION [ 'installer_admin_username' ] ) ? $_SESSION [ 'installer_admin_username' ] : 'Admin' ) .'" /></div><br/>
							  <div><span>Password:</span>
							  		<input type="password" name="admin_pass1" value="" /></div>
							  <div><span>Repeat password:</span>
							  		<input type="password" name="admin_pass2" value="" /></div><br/>
							  <div><span>Email:</span>
							  		<input type="text" name="admin_email1" value="'. ( isset ( $_SESSION [ 'installer_admin_email1' ] ) ? $_SESSION [ 'installer_admin_email1' ] : '' ) .'" /></div>
							  <div><span>Repeat email:</span>
							  		<input type="text" name="admin_email2" value="'. ( isset ( $_SESSION [ 'installer_admin_email2' ] ) ? $_SESSION [ 'installer_admin_email2' ] : '' ) .'" /></div>';
						if ( isset ( $_SESSION [ 'installer_admin_error' ] ) )
						{
							echo '<br/><br/><div class="error">Some kind of error occured. Please double-check that no fields are left empty, password/email pairs match, username is between 3 and 20 symbols and contains no special symbols.</div>';	
						}
					break;
					
				case 5:
						// PEAR setup
						echo '<p>Diferior is quite powerful and functional software. To make it\'s development process easier some 3rd party libraries are used.
						         Thankfully these libraries are fairly easy to acquire and install. Installer will now attempt to check if required libraries are
						         already present in current environment. If not, libraries will be downloaded and installed automatically.</p>';
						
						/* Bundled cache_lite package has PEAR dependency removed, so this is no longer required.
						if ( check_pear () )
						{
							# K
							echo '<div><span style="color: #0f0;">PASS</span> <a class="float" href="http://pear.php.net" target="_blank">PEAR</a></div>';
						}
						else 
						{
							# Trouble
							echo '<div><span style="color: #f00;">ERROR</span> <a class="float" href="'. $url -> make ( 'go-pear' ) .'" target="_blank">PEAR</a></div>';
						}*/
						
						if ( check_cachelite ()	)
						{
							# K	
							echo '<div><span style="color: #0f0;">PASS</span> <a class="float" href="http://pear.php.net/cache_lite" target="_blank">cache_lite 1.7.2</a></div>';
						}
						else 
						{
							# Trouble
							echo '<div><span style="color: #f00;">ERROR</span> <a class="float" href="http://pear.php.net/cache_lite" target="_blank">cache_lite 1.7.2</a></div>';
						}
						
						echo '<p>If you see any error messages above, please download and install these packages from <a href="http://pear.php.net" target="_blank">PEAR</a> manually.</p>';
					break;
					
				case 6:
						// Smarty setup
						echo '<p>Diferior utilizes <a href="http://smarty.php.net" target="_blank">Smarty</a> templating engine to generate templates.
						         This step will attempt to check if Smarty is available in current hosting environment and if not, will attempt to download and install it.</p>';
						
						if ( check_smarty () )
						{
							# K
							echo '<div><span style="color: #0f0;">PASS</span> <a class="float" href="http://smarty.php.net" target="_blank">Smarty 2.6.x</a></div>';
						}
						else 
						{
							# Trouble
							echo '<div><span style="color: #f00;">ERROR</span> <a class="float" href="http://smarty.php.net/quick_start.php" target="_blank">Smarty 2.6.x</a></div>';
						}
						
						echo '<p>If you see an error message above, download and install <a href="http://smarty.php.net/quick_start.php" target="_blank">Smarty 2.6.x</a> manually before continuing.</p>';
					break;
					
				case 7:
						// Configuring CMS
						echo '<p>Congratulations, you\'re almost there! Setup will now finish configuring your Diferior installation.</p>';
						
						if ( install_sql () )
						{
							# K
							echo '<div><span style="color: #0f0;">PASS</span> <span class="float">MySQL database setup</span></div>';
						}
						else 
						{
							# Trouble
							echo '<div><span style="color: #f00;">ERROR</span> <span class="float">MySQL database setup</span></div>';
						}
						
						if ( install_user () )
						{
							# K
							echo '<div><span style="color: #0f0;">PASS</span> <span class="float">Admin user setup</span></div>';
						}
						else 
						{
							# Trouble
							echo '<div><span style="color: #f00;">ERROR</span> <span class="float">Admin user setup</span></div>';
						}
						
						if ( install_config () )
						{
							# K
							echo '<div><span style="color: #0f0;">PASS</span> <span class="float">Generating configuration file</span></div>';
						}
						else 
						{
							# Trouble
							echo '<div><span style="color: #f00;">ERROR</span> <span class="float">Generating configuration file</span></div>';
						}
						
						# Generate XBT config
						install_xbt ();
						
						echo '<p>If no error messages appear above you can safely continue to login and further customize Diferior. Have fun ;)</p><br/>
							  <p>If you ever need to run this installer again, just reupload whole \'install\' directory.</p>';
					break;
			}
		?>
	</div>
	<input type="submit" value="Next &#187;" class="submit"/>
	</form>
</div>

</body>
</html>