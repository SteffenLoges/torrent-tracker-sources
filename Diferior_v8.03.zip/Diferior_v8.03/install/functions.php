<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	# Functions required by installer. Various checks, etc.
	
	
	# Check if file or directory (relative to script's main directory) is readable and writable
	function check_files ( $f )
	{
		if ( file_exists ( $f ) && is_readable ( $f ) && is_writable ( $f ) )
		{
			return true;
		}
		else 
		{
			error::toggle_silent ( true );
			$res = chmod ( $f, 0777 );
			error::toggle_silent ( false );
			
			if ( $res )
			{
				return true;
			}
			else 
			{
				return false;
			}	
		}
	}

	
	# Check if PEAR is installed
	function check_pear ( $passive = false )
	{
		$include_path = ini_get ( 'include_path' );
		$include_path = explode ( PATH_SEPARATOR, $include_path );
		foreach ( $include_path as $v )
		{
			if ( $v != '.' )
			{
				if ( file_exists ( $v. '/PEAR.php' ) )
				{
					# PEAR installed
					return true;
				}
				elseif ( !$passive && file_exists ( $v .'/PEAR/PEAR.php' ) )
				{
					# Pear installed, but in wrong directory (most likely via go-pear). Fix that.
					return fix_pear ( $v );
				}	
			}
		} 

		return false;	
	}
	
	
	# Fix go-pear installation of PEAR
	function fix_pear ( $fl )
	{
		rename ( $fl .'/PEAR', $fl .'/PEAR_tmp' );
		
		$dir = opendir ( $fl .'/PEAR_tmp/' );
		while ( ( $el = readdir ( $dir ) ) !== false )
		{
			if ( $el != '.' && $el != '..' )
			{
				$res = rename ( $fl .'/PEAR_tmp/'. $el, $fl .'/'. $el );
				if ( $res === false ) return false; // :(
			}
		}
		closedir ( $dir );
			
		return true;
	}
	
	
	# Check if cache_lite 1.7.2 or later is installed
	function check_cachelite ( $passive = false )
	{
		$include_path = ini_get ( 'include_path' );
		$include_path = explode ( PATH_SEPARATOR, $include_path );
		foreach ( $include_path as $v )
		{
			if ( $v != '.' && file_exists ( $v. '/Cache/Lite.php' ) )
			{
				return true;	
			}
		} 

		if ( $passive )
		{
			return false;
		}
		
		$res = install_cachelite ();	
		
		if ( $res == false )
		{
			# Cleanup	
			del_dir ( DIR_FUNCTIONS .'/pear/Cache' );
		}
		
		return $res;
	}
	
	
	# Attempt to install cache_lite
	function install_cachelite ()
	{
		# Prepare directory structure
		error::toggle_silent ( true );
		if ( !mkdir ( DIR_FUNCTIONS .'/pear/Cache', 0777 ) ) return false;
		if ( !mkdir ( DIR_FUNCTIONS .'/pear/Cache/Lite', 0777 ) ) return false;
		error::toggle_silent ( false );
		
		# Download source files from php.net
		if ( !dl_file ( 'http://cvs.php.net/viewvc.cgi/pear/Cache_Lite/Lite.php?view=co', DIR_FUNCTIONS .'/pear/Cache/Lite.php' ) ) return false;
		if ( !dl_file ( 'http://cvs.php.net/viewvc.cgi/pear/Cache_Lite/Lite/Output.php?view=co', DIR_FUNCTIONS .'/pear/Cache/Lite/Output.php' ) ) return false;
		if ( !dl_file ( 'http://cvs.php.net/viewvc.cgi/pear/Cache_Lite/Lite/Function.php?view=co', DIR_FUNCTIONS .'/pear/Cache/Lite/Function.php' ) ) return false;
		if ( !dl_file ( 'http://cvs.php.net/viewvc.cgi/pear/Cache_Lite/Lite/File.php?view=co', DIR_FUNCTIONS .'/pear/Cache/Lite/File.php' ) ) return false;
		
		return true;
	}
	
	
	# Download remote file
	function dl_file ( $src_f, $dest_f )
	{
		// Source
		$src = fopen ( $src_f, 'r' );
		if ( $src == false ) return false;
		// Destination
		$dest = fopen ( $dest_f, 'w' );
		if ( $dest == false ) return false;

		// Download
		while ( !feof ( $src ) )
		{
			$chunk = fread ( $src, 1024 );
			fputs ( $dest, $chunk );
		}
		
		// Close files
		fclose ( $src );
		fclose ( $dest );
			
		return true;
	}
	
	
	# Check if smarty is installed
	function check_smarty ( $passive = false )
	{
		$include_path = ini_get ( 'include_path' );
		$include_path = explode ( PATH_SEPARATOR, $include_path );
		foreach ( $include_path as $v )
		{
			if ( $v != '.' && file_exists ( $v .'/'. SMARTY_PATH ) )
			{
				return true;	
			}
		} 

		if ( $passive )
		{
			return false;
		}
		
		return false;
		$res = install_smarty ();	
		
		if ( $res == false )
		{
			# Cleanup	
			del_dir ( DIR_FUNCTIONS .'/pear/smarty' );
		}
		
		return $res;
	}
	
	
	# Attempts to install smarty from php.net
	function install_smarty ()
	{
		# Not sure how to implement this one...
		return true;
	}
	
	
	# Remove directory and it's contents
	function del_dir ( $fl )
	{
		if ( !file_exists ( $fl ) ) return;
		
		if ( is_dir ( $fl ) )
		{
			$dir = opendir ( $fl );
			while ( ( $el = readdir ( $dir ) ) !== false )
			{
				if ( $el != '.' && $el != '..' )
				{
					del_dir ( $fl .'/'. $el );
				}
			}
			closedir ( $dir );
			rmdir ( $fl );
		}	
		else 
		{
			unlink ( $fl );	
		}
	}
	
	# Populate MySQL database with setup data
	function install_sql ()
	{
		$db = & core::load_file ( 'db' );
		
		# Check if can login
		$res = $db -> connect ( false, $_SESSION [ 'installer_mysql_host' ], 
							$_SESSION [ 'installer_mysql_username' ], $_SESSION [ 'installer_mysql_password' ],
							$_SESSION [ 'installer_mysql_database' ], true );
		$db -> set_prefix ( $_SESSION [ 'installer_mysql_prefix' ] );
							
		if ( !$res ) return false;
		
		# Import SQL backups
		import_sql ( DIR .'/install/sql/tables.sql' );
		import_sql ( DIR .'/install/sql/data.sql' );
		
		return true;
	}
	
	function import_sql ( $path )
	{
		$fl = fopen ( $path, 'r' );
		$query = null;
		
		while ( !feof ( $fl ) )
		{
			$chunk = fgets ( $fl );
			
			// Skip comments and empty lines
			if ( trim ( $chunk ) != null && substr ( $chunk, 0, 2 ) != '--' )
			{
				parse_sql_chunk ( $query, $chunk );
			}
		}
		
		if ( $query != null ) 
		{
			exec_sql ( $query );
		}
		
		fclose ( $fl );	
	}
	
	# Parse SQL chunk
	function parse_sql_chunk ( &$query, $chunk )
	{
		$pos = strpos ( $chunk, ';' );
		
		if ( $pos === false )
		{
			# Add to query
			$query .= $chunk;
		}
		else 
		{
			# Check if semicolon is a query separator or string
			$str = $query . substr ( $chunk, 0, $pos );
			$open = false;
			
			for ( $i = 0, $max = strlen ( $str ); $i < $max; $i++ )
			{
				$s = $str [ $i ];
				
				if ( ( $s == '\'' || $s == '"' ) && $open === false )
				{
					$open = $s;	
				}	
				elseif ( $open !== false && $s === $open )
				{
					$open = false;	
				}
			}
			
			if ( $open !== false )
			{
				# String	
				$end = substr ( $chunk, $pos );
				$pos_end = strpos ( $end, $open );
				$query = $str;
				$query .= substr ( $end, 0, $pos_end );
				$chunk = substr ( $end, $pos_end +1 );
				parse_sql_chunk ( $query, $chunk );
			}
			else 
			{
				# Query separator
				$query = $str;
				exec_sql ( $query );
				$query = null;	
				$chunk = substr ( $chunk, $pos +1 );
				parse_sql_chunk ( $query, $chunk );
			}
		}
				
	}
	
	# Execute SQL query
	function exec_sql ( $sql )
	{
		if ( trim ( $sql ) == null ) return;
		
		$db = & core::get_object ( 'db' );
		
		$db -> query ( $sql );
	}
	
	# Add admin user
	function install_user ()
	{
		$db = & core::get_object ( 'db' );
		
		$data = array ( 'name' => $_SESSION [ 'installer_admin_username' ], 'pass' => md5 ( md5 ( $_SESSION [ 'installer_admin_pass1' ] ) ), 
						'email' => $_SESSION [ 'installer_admin_email1' ], 
					    'email_validate' => '', 'registered' => time (), 'lastlogin' => 0, 'torrents_limit' => 2, 'status' => 'Administrator' );
		
		# Add user
		$insertid = $db -> insert_array ( 'users', $data );
		
		# Can't insert
		if ( $insertid <= 0 )
		{
			return false;	
		}
		
		$data = array (
			'user'	=>	$_SESSION [ 'installer_admin_username' ],
			'view_ip'	=>	1,
			'make_posts'	=>	1,
			'delete_comments'	=>	1,
			'add_downloads'	=>	1,
			'view_nfo'	=>	1,
			'edit_posts'	=>	1,
			'edit_downloads'	=>	1,
			'see_anonymous'	=>	1,
			'approve_downloads'	=>	1,
			'cheater_list'	=>	1,
			'ban_users'	=>	1,
			'edit_users'	=>	1,
			'view_log'	=>	1,
			'forum_moderator'	=>	1,
			'admin'	=>	1,
		);
		
		$db -> insert_array ( 'users_permissions', $data );
		
		return true;
	}
	
	# Regenerate config file
	function install_config ()
	{
		$config = & core::load_file ( 'config' );
		$config -> load_file ();
		
		$options = array (
			'DB_HOST'	=>	$_SESSION [ 'installer_mysql_host' ],
			'DB_USER'	=>	$_SESSION [ 'installer_mysql_username' ],
			'DB_PASS'	=>	$_SESSION [ 'installer_mysql_password' ],
			'DB_NAME'	=>	$_SESSION [ 'installer_mysql_database' ],
			'DB_PREFIX'	=>	$_SESSION [ 'installer_mysql_prefix' ],
			'MAIL_FROM'	=>	$_SESSION [ 'installer_admin_email1' ],
			'ADMIN_EMAIL'	=>	$_SESSION [ 'installer_admin_email1' ],
			'SESS_HANDLER_DB'	=>	true,
		);
		
		$config -> update_array ( $options );
		
		return true;
	}
	
	# Generate XBT config file
	 # (Bad idea, since mod_rewrite might be unavailable, in which case xbt_tracker.conf is easily readable by anybody) 
	function install_xbt ()
	{
		return;
		
		$conf = DIR .'/install/tracker/xbt/Tracker/xbt_tracker.conf';
		if ( check_files ( $conf ) )
		{
			$contents = "mysql_host = ". $_SESSION [ 'installer_mysql_host' ] ."\nmysql_user = ". $_SESSION [ 'installer_mysql_username' ] ."\nmysql_password = ". $_SESSION [ 'installer_mysql_password' ] ."\nmysql_database = ". $_SESSION [ 'installer_mysql_database' ] ."\nmysql_table_prefix = ". $_SESSION [ 'installer_mysql_prefix' ];
			file_put_contents ( $conf, $contents );
		}
	}
?>