-- 
-- Table structure for table `blog_categories`
-- 

DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE `blog_categories` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `lid` varchar(32) collate utf8_unicode_ci NOT NULL,
  `name` varchar(32) collate utf8_unicode_ci NOT NULL,
  `color` varchar(6) collate utf8_unicode_ci NOT NULL,
  `position` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `lid` (`lid`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `blog_comments`
-- 

DROP TABLE IF EXISTS `blog_comments`;
CREATE TABLE `blog_comments` (
  `id` int(7) unsigned NOT NULL auto_increment,
  `post` int(5) unsigned NOT NULL,
  `anonymous` tinyint(1) unsigned NOT NULL default '0',
  `author` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email` varchar(32) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  `posted` int(15) NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `post` (`post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `blog_posts`
-- 

DROP TABLE IF EXISTS `blog_posts`;
CREATE TABLE `blog_posts` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `cat` int(3) unsigned NOT NULL,
  `plid` varchar(255) collate utf8_unicode_ci NOT NULL,
  `posted` int(15) unsigned NOT NULL,
  `updated` int(15) unsigned NOT NULL,
  `header` varchar(255) collate utf8_unicode_ci NOT NULL,
  `subheader` varchar(255) collate utf8_unicode_ci NOT NULL,
  `author` varchar(32) collate utf8_unicode_ci NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  `comments` int(4) unsigned NOT NULL,
  `parse_html` tinyint(1) NOT NULL default '0',
  `copyright` tinyint(1) NOT NULL default '1',
  `tags` varchar(400) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`,`plid`),
  KEY `posted` (`posted`),
  KEY `tags` (`tags`(333)),
  FULLTEXT KEY `header` (`header`,`subheader`,`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `blog_queue`
-- 

DROP TABLE IF EXISTS `blog_queue`;
CREATE TABLE `blog_queue` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `cat` int(3) unsigned NOT NULL,
  `plid` varchar(255) collate utf8_unicode_ci NOT NULL,
  `post_date` int(15) unsigned NOT NULL,
  `human_date` varchar(6) collate utf8_unicode_ci NOT NULL,
  `header` varchar(255) collate utf8_unicode_ci NOT NULL,
  `subheader` varchar(255) collate utf8_unicode_ci NOT NULL,
  `author` varchar(32) collate utf8_unicode_ci NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  `comments` int(4) unsigned NOT NULL,
  `parse_html` tinyint(1) NOT NULL default '0',
  `copyright` tinyint(1) NOT NULL default '1',
  `tags` varchar(400) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `post_date` (`post_date`),
  KEY `human_date` (`human_date`),
  KEY `tags` (`tags`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `counters`
-- 

DROP TABLE IF EXISTS `blog_counters`;
CREATE TABLE `counters` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `cid` varchar(32) collate utf8_unicode_ci NOT NULL,
  `day_visits` int(7) unsigned NOT NULL,
  `day_date` varchar(4) collate utf8_unicode_ci NOT NULL,
  `total` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `dl_categories`
-- 

DROP TABLE IF EXISTS `dl_categories`;
CREATE TABLE `dl_categories` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `lid` varchar(32) collate utf8_unicode_ci NOT NULL,
  `name` varchar(32) collate utf8_unicode_ci NOT NULL,
  `color` varchar(6) collate utf8_unicode_ci NOT NULL,
  `position` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `lid` (`lid`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `dl_comments`
-- 

DROP TABLE IF EXISTS `dl_comments`;
CREATE TABLE `dl_comments` (
  `id` int(7) unsigned NOT NULL auto_increment,
  `post` int(5) unsigned NOT NULL,
  `anonymous` tinyint(1) unsigned NOT NULL default '0',
  `author` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email` varchar(32) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  `posted` int(15) NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `post` (`post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `dl_downloads`
-- 

DROP TABLE IF EXISTS `dl_downloads`;
CREATE TABLE `dl_downloads` (
  `fid` int(11) unsigned NOT NULL auto_increment,
  `confirmed` smallint(1) NOT NULL default '0',
  `cat` int(3) unsigned NOT NULL,
  `subcat` int(3) unsigned NOT NULL,
  `plid` varchar(255) collate utf8_unicode_ci NOT NULL,
  `posted` int(15) unsigned NOT NULL,
  `updated` int(15) unsigned NOT NULL,
  `header` varchar(78) collate utf8_unicode_ci NOT NULL,
  `subheader` varchar(39) collate utf8_unicode_ci NOT NULL,
  `user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `anonymous` tinyint(1) NOT NULL default '0',
  `content` text collate utf8_unicode_ci NOT NULL,
  `comments` int(4) unsigned NOT NULL,
  `nfo` varchar(64) collate utf8_unicode_ci NOT NULL,
  `dl_links` text collate utf8_unicode_ci NOT NULL,
  `info_hash` blob NOT NULL,
  `leechers` int(11) unsigned NOT NULL default '0',
  `seeders` int(11) unsigned NOT NULL default '0',
  `last_scrape` int(15) unsigned NOT NULL,
  `completed` int(11) unsigned NOT NULL default '0',
  `balance` int(11) NOT NULL,
  `flags` int(11) NOT NULL default '0',
  `freetorrent` int(11) NOT NULL default '0',
  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ctime` timestamp NOT NULL default '0000-00-00 00:00:00',
  `fsize` bigint(16) unsigned NOT NULL,
  `files` text collate utf8_unicode_ci NOT NULL,
  `tags` varchar(400) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`fid`),
  KEY `info_hash` (`info_hash`(20)),
  KEY `posted` (`posted`),
  KEY `confirmed` (`confirmed`,`cat`,`plid`,`subcat`),
  KEY `tags` (`tags`(333)),
  KEY `last_scrape` (`last_scrape`),
  FULLTEXT KEY `header` (`header`,`subheader`,`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `dl_subcategories`
-- 

DROP TABLE IF EXISTS `dl_subcategories`;
CREATE TABLE `dl_subcategories` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `cat` int(3) unsigned NOT NULL,
  `lid` varchar(32) collate utf8_unicode_ci NOT NULL,
  `name` varchar(32) collate utf8_unicode_ci NOT NULL,
  `position` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `position` (`position`),
  KEY `cat` (`cat`,`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `forum_boards`
-- 

DROP TABLE IF EXISTS `forum_boards`;
CREATE TABLE `forum_boards` (
  `id` int(4) unsigned NOT NULL auto_increment,
  `cat` int(3) unsigned NOT NULL,
  `flid` varchar(70) collate utf8_unicode_ci NOT NULL,
  `title` varchar(70) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `position` int(4) unsigned NOT NULL,
  `threads` int(6) unsigned NOT NULL,
  `posts` int(7) unsigned NOT NULL,
  `last_thread` varchar(70) collate utf8_unicode_ci NOT NULL,
  `last_tlid` varchar(70) collate utf8_unicode_ci NOT NULL,
  `last_user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `last_tstamp` int(12) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `position` (`position`),
  KEY `cat` (`cat`),
  KEY `flid` (`flid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `forum_categories`
-- 

DROP TABLE IF EXISTS `forum_categories`;
CREATE TABLE `forum_categories` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `clid` varchar(50) collate utf8_unicode_ci NOT NULL,
  `title` varchar(50) collate utf8_unicode_ci NOT NULL,
  `position` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `position` (`position`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `forum_posts`
-- 

DROP TABLE IF EXISTS `forum_posts`;
CREATE TABLE `forum_posts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `thread` int(6) unsigned NOT NULL,
  `author` varchar(32) collate utf8_unicode_ci NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  `post_no` int(5) unsigned NOT NULL,
  `tstamp` int(12) unsigned NOT NULL,
  `edit_tstamp` int(12) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `thread` (`thread`),
  KEY `tstamp` (`tstamp`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `forum_threads`
-- 

DROP TABLE IF EXISTS `forum_threads`;
CREATE TABLE `forum_threads` (
  `id` int(6) unsigned NOT NULL auto_increment,
  `forum` int(4) unsigned NOT NULL,
  `tlid` varchar(70) collate utf8_unicode_ci NOT NULL,
  `author` varchar(32) collate utf8_unicode_ci NOT NULL,
  `title` varchar(70) collate utf8_unicode_ci NOT NULL,
  `description` varchar(150) collate utf8_unicode_ci NOT NULL,
  `pinned` tinyint(1) unsigned NOT NULL default '0',
  `closed` tinyint(1) unsigned NOT NULL default '0',
  `posts` int(5) unsigned NOT NULL,
  `last_user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `last_tstamp` int(12) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `tlid` (`tlid`),
  KEY `pinned` (`pinned`,`last_tstamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `hits_out`
-- 

DROP TABLE IF EXISTS `hits_out`;
CREATE TABLE `hits_out` (
  `url` varchar(255) collate utf8_unicode_ci NOT NULL,
  `hits` int(6) unsigned NOT NULL,
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `log`
-- 

DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `tstamp` int(11) unsigned NOT NULL,
  `user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `action` tinyint(2) unsigned NOT NULL,
  `url` varchar(255) collate utf8_unicode_ci NOT NULL,
  `title` varchar(78) collate utf8_unicode_ci NOT NULL,
  `comments` varchar(255) collate utf8_unicode_ci NOT NULL,
  KEY `tstamp` (`tstamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `online`
-- 

DROP TABLE IF EXISTS `online`;
CREATE TABLE `online` (
  `cid` varchar(32) collate utf8_unicode_ci NOT NULL,
  `uid` varchar(32) collate utf8_unicode_ci NOT NULL,
  `user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `atime` int(20) unsigned NOT NULL,
  KEY `cid` (`cid`,`uid`),
  KEY `atime` (`atime`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `private`
-- 

DROP TABLE IF EXISTS `private`;
CREATE TABLE `private` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `unread` tinyint(1) unsigned NOT NULL default '1',
  `from` varchar(32) collate utf8_unicode_ci NOT NULL,
  `to` varchar(32) collate utf8_unicode_ci NOT NULL,
  `title` varchar(70) collate utf8_unicode_ci NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  `tstamp` int(12) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `to` (`to`,`unread`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `sessions`
-- 

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `sid` varchar(255) character set latin1 collate latin1_general_ci NOT NULL,
  `data` varchar(7000) collate utf8_unicode_ci NOT NULL,
  `tstamp` int(15) unsigned NOT NULL,
  UNIQUE KEY `sid` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `uid` int(8) unsigned NOT NULL auto_increment,
  `name` varchar(32) collate utf8_unicode_ci NOT NULL,
  `pass` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email_validate` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email_change` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email_validate_change` varchar(32) collate utf8_unicode_ci NOT NULL,
  `registered` int(15) unsigned NOT NULL,
  `lastlogin` int(15) unsigned NOT NULL,
  `reminder_pass` varchar(32) collate utf8_unicode_ci NOT NULL,
  `reminder_sent` int(15) unsigned NOT NULL,
  `status` varchar(255) collate utf8_unicode_ci NOT NULL,
  `blogposts` int(5) unsigned NOT NULL,
  `downloadposts` int(5) unsigned NOT NULL,
  `comments` int(5) unsigned NOT NULL,
  `forumposts` int(5) unsigned NOT NULL,
  `private_new` int(5) unsigned NOT NULL,
  `private_total` int(5) unsigned NOT NULL,
  `ip` varchar(32) collate utf8_unicode_ci NOT NULL,
  `pr_name` varchar(64) collate utf8_unicode_ci NOT NULL,
  `pr_gender` tinyint(1) unsigned NOT NULL,
  `pr_birth` date NOT NULL,
  `pr_location` varchar(60) collate utf8_unicode_ci NOT NULL,
  `pr_avatar` varchar(150) collate utf8_unicode_ci NOT NULL,
  `pr_page` varchar(60) collate utf8_unicode_ci NOT NULL,
  `pr_skype` varchar(60) collate utf8_unicode_ci NOT NULL,
  `pr_msn` varchar(60) collate utf8_unicode_ci NOT NULL,
  `pr_icq` int(15) unsigned NOT NULL,
  `pr_yahoo` varchar(60) collate utf8_unicode_ci NOT NULL,
  `pr_gtalk` varchar(60) collate utf8_unicode_ci NOT NULL,
  `last_thread` int(15) unsigned NOT NULL,
  `last_post` int(15) unsigned NOT NULL,
  `last_pm` int(15) unsigned NOT NULL,
  `banned` tinyint(1) NOT NULL default '0',
  `warned` tinyint(1) NOT NULL default '0',
  `warned_manual` tinyint(1) NOT NULL default '0',
  `warn_time` int(15) unsigned NOT NULL,
  `can_leech` tinyint(4) NOT NULL default '1',
  `can_leech_manual` tinyint(4) NOT NULL default '1',
  `wait_time` int(11) NOT NULL,
  `peers_limit` int(11) NOT NULL,
  `torrents_limit` int(11) NOT NULL default '2',
  `torrent_pass` char(32) collate utf8_unicode_ci NOT NULL,
  `torrent_pass_secret` bigint(20) NOT NULL,
  `downloaded` bigint(20) NOT NULL,
  `uploaded` bigint(20) NOT NULL,
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `name` (`name`),
  KEY `email_validate` (`email_validate`),
  KEY `downloaded` (`downloaded`,`can_leech`,`registered`),
  FULLTEXT KEY `name_2` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `users_permissions`
-- 

DROP TABLE IF EXISTS `users_permissions`;
CREATE TABLE `users_permissions` (
  `user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `view_ip` tinyint(1) NOT NULL default '0',
  `make_posts` tinyint(1) NOT NULL default '0',
  `delete_comments` tinyint(1) NOT NULL default '0',
  `add_downloads` tinyint(1) NOT NULL default '0',
  `view_nfo` tinyint(1) NOT NULL default '0',
  `edit_posts` tinyint(1) NOT NULL default '0',
  `edit_downloads` tinyint(1) NOT NULL default '0',
  `see_anonymous` tinyint(1) NOT NULL default '0',
  `approve_downloads` tinyint(1) NOT NULL default '0',
  `cheater_list` tinyint(1) NOT NULL default '0',
  `ban_users` tinyint(1) NOT NULL default '0',
  `edit_users` tinyint(1) NOT NULL default '0',
  `view_log` tinyint(1) NOT NULL default '0',
  `forum_moderator` tinyint(1) NOT NULL default '0',
  `admin` tinyint(1) NOT NULL default '0',
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `users_preferences`
-- 

DROP TABLE IF EXISTS `users_preferences`;
CREATE TABLE `users_preferences` (
  `user` varchar(32) collate utf8_unicode_ci NOT NULL,
  `start_page` varchar(200) collate utf8_unicode_ci NOT NULL,
  `blog_no` smallint(2) unsigned NOT NULL,
  `downloads_no` smallint(2) unsigned NOT NULL,
  `comments_no` smallint(2) unsigned NOT NULL,
  `forum_threads_no` smallint(2) unsigned NOT NULL,
  `forum_posts_no` smallint(2) unsigned NOT NULL,
  `private_no` smallint(2) unsigned NOT NULL,
  `downloads_type` smallint(1) unsigned NOT NULL,
  `comments_dir` smallint(1) unsigned NOT NULL,
  `forum_posts_dir` smallint(1) unsigned NOT NULL,
  `language` varchar(32) collate utf8_unicode_ci NOT NULL,
  `template` varchar(32) collate utf8_unicode_ci NOT NULL,
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `xbt_announce_log`
-- 

DROP TABLE IF EXISTS `xbt_announce_log`;
CREATE TABLE `xbt_announce_log` (
  `id` int(11) NOT NULL auto_increment,
  `ipa` int(10) unsigned NOT NULL,
  `port` int(11) NOT NULL,
  `event` int(11) NOT NULL,
  `info_hash` blob NOT NULL,
  `peer_id` blob NOT NULL,
  `useragent` varchar(20) collate latin1_general_ci NOT NULL,
  `downloaded` bigint(20) NOT NULL,
  `left0` bigint(20) NOT NULL,
  `uploaded` bigint(20) NOT NULL,
  `uid` int(11) NOT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Table structure for table `xbt_cheat`
-- 

DROP TABLE IF EXISTS `xbt_cheat`;
CREATE TABLE `xbt_cheat` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `ipa` int(10) unsigned NOT NULL,
  `peer_id` blob NOT NULL,
  `upspeed` bigint(20) NOT NULL,
  `tstamp` int(11) NOT NULL,
  `uploaded` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `xbt_config`
-- 

DROP TABLE IF EXISTS `xbt_config`;
CREATE TABLE `xbt_config` (
  `name` varchar(255) collate latin1_general_ci NOT NULL,
  `value` varchar(255) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Table structure for table `xbt_deny_from_hosts`
-- 

DROP TABLE IF EXISTS `xbt_deny_from_hosts`;
CREATE TABLE `xbt_deny_from_hosts` (
  `begin` int(11) NOT NULL,
  `end` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Table structure for table `xbt_files_users`
-- 

DROP TABLE IF EXISTS `xbt_files_users`;
CREATE TABLE `xbt_files_users` (
  `fid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `announced` int(11) NOT NULL,
  `completed` int(11) NOT NULL,
  `downloaded` bigint(20) NOT NULL,
  `left` bigint(20) NOT NULL,
  `uploaded` bigint(20) NOT NULL,
  `upspeed` bigint(20) NOT NULL,
  `downspeed` bigint(20) NOT NULL,
  `timespent` bigint(20) NOT NULL,
  `useragent` varchar(40) collate utf8_unicode_ci NOT NULL,
  `connectable` tinyint(4) NOT NULL default '1',
  `peer_id` varchar(200) collate utf8_unicode_ci NOT NULL,
  `ipa` int(11) NOT NULL,
  `port` int(5) unsigned NOT NULL,
  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  UNIQUE KEY `uid_2` (`uid`,`fid`,`ipa`),
  KEY `active` (`active`),
  KEY `fid` (`fid`,`active`,`left`),
  KEY `uid_3` (`uid`,`active`,`left`),
  KEY `fid_2` (`fid`,`peer_id`,`ipa`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Table structure for table `xbt_scrape_log`
-- 

DROP TABLE IF EXISTS `xbt_scrape_log`;
CREATE TABLE `xbt_scrape_log` (
  `id` int(11) NOT NULL auto_increment,
  `ipa` int(11) NOT NULL,
  `info_hash` blob,
  `uid` int(11) NOT NULL,
  `mtime` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Table structure for table `xbt_snatched`
-- 

DROP TABLE IF EXISTS `xbt_snatched`;
CREATE TABLE `xbt_snatched` (
  `uid` int(11) NOT NULL default '0',
  `tstamp` int(11) NOT NULL,
  `fid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;