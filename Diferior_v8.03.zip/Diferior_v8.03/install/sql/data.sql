-- 
-- Dumping data for table `blog_categories`
-- 

INSERT INTO `blog_categories` (`id`, `lid`, `name`, `color`, `position`) VALUES 
(1, 'sample-category-1', 'Sample category #1', '', 1),
(2, 'sample-category-2', 'Sample category #2', '', 2),
(3, 'sample-category-3', 'Sample category #3', '', 3);

-- 
-- Dumping data for table `blog_posts`
-- 

INSERT INTO `blog_posts` (`id`, `cat`, `plid`, `posted`, `updated`, `header`, `subheader`, `author`, `content`, `comments`, `parse_html`, `copyright`) VALUES 
(1, 1, 'sample-post', 1196709138, 0, 'Sample post', 'Sample subheader', 'Diferior', 'Congratulations on successfully completing installation of [url=http://diferior.com][size=20]Diferior[/size][/url]!\r\n\r\nTo further customize the system use admin panel. You can also add, remove and edit categories, forums using it.[break]', 0, 0, 0);

-- 
-- Dumping data for table `dl_categories`
-- 

INSERT INTO `dl_categories` (`id`, `lid`, `name`, `color`, `position`) VALUES 
(1, 'anime', 'Anime', '', 1),
(2, 'software', 'Software', '', 2),
(3, 'books', 'Books', '', 3),
(4, 'games', 'Games', '', 4),
(5, 'video', 'Video', '', 5),
(6, 'music', 'Music', '', 6),
(7, 'mobile', 'Mobile', '', 7),
(8, 'xxx', 'XXX (18+)', 'ff0000', 8),
(9, 'other', 'Other', '', 9);

-- 
-- Dumping data for table `dl_subcategories`
-- 

INSERT INTO `dl_subcategories` (`cat`, `lid`, `name`, `position`) VALUES 
(1, 'en-dub-subs', 'EN dub/subs', 1),
(1, 'lt-dub-subs', 'LT dub/subs', 2),
(1, 'manga', 'Manga', 3),
(1, 'ost', 'OST', 4),
(1, 'other', 'Other', 5),
(2, 'windows', 'Windows', 1),
(2, 'linux', 'Linux', 2),
(2, 'macos', 'MacOS', 3),
(2, 'other', 'Other', 4),
(3, 'lt', 'LT', 1),
(3, 'en', 'EN', 2),
(3, 'ru', 'RU', 3),
(3, 'other', 'Other', 4),
(4, 'pc', 'PC', 1),
(4, 'ps1', 'PS1', 2),
(4, 'ps2', 'PS2', 3),
(4, 'ps3', 'PS3', 4),
(4, 'psp', 'PSP', 5),
(4, 'xbox', 'Xbox', 6),
(4, 'xbox-360', 'Xbox 360', 7),
(4, 'gc', 'GC', 8),
(4, 'wii', 'Wii', 9),
(4, 'ds', 'DS', 10),
(4, 'other', 'Other', 11),
(5, 'movies-en', 'Movies EN', 1),
(5, 'movies-ru', 'Movies RU', 2),
(5, 'movies-lt', 'Movies LT', 3),
(5, 'hd', 'HD', 4),
(5, 'music-videos', 'Music videos', 5),
(5, 'tv', 'TV', 6),
(5, 'sport', 'Sport', 7),
(5, 'other', 'Other', 8),
(6, 'lt', 'LT', 1),
(6, 'en', 'EN', 2),
(6, 'ru', 'RU', 3),
(6, 'ost', 'OST', 4),
(6, 'other', 'Other', 5),
(7, 'software', 'Software', 1),
(7, 'games', 'Games', 2),
(7, 'other', 'Other', 3),
(8, 'video', 'Video', 1),
(8, 'pics', 'Pics', 2),
(8, 'other', 'Other', 3),
(9, 'other', 'Other', 1);

-- 
-- Dumping data for table `forum_categories`
-- 

INSERT INTO `forum_categories` (`id`, `clid`, `title`, `position`) VALUES 
(1, 'category-1', 'Category #1', 1),
(2, 'category-2', 'Category #2', 2);

-- 
-- Dumping data for table `forum_boards`
-- 

INSERT INTO `forum_boards` (`cat`, `flid`, `title`, `description`, `position`, `threads`, `posts`, `last_thread`, `last_tlid`, `last_user`, `last_tstamp`) VALUES 
(1, 'sample-board-1', 'Sample board #1', 'Sample description #1', 1, 0, 0, '', '', '', 0),
(1, 'sample-board-2', 'Sample board #2', 'Sample description #2', 2, 0, 0, '', '', '', 0),
(1, 'sample-board-3', 'Sample board #3', 'Sample description #3', 3, 0, 0, '', '', '', 0),
(2, 'sample-board-4', 'Sample board #4', 'Sample description #4', 1, 0, 0, '', '', '', 0),
(2, 'sample-board-5', 'Sample board #5', 'Sample description #5', 2, 0, 0, '', '', '', 0),
(2, 'sample-board-6', 'Sample board #6', 'Sample description #6', 3, 0, 0, '', '', '', 0);

-- 
-- Dumping data for table `xbt_config`
-- 

INSERT INTO `xbt_config` (`name`, `value`) VALUES 
('scrape_interval', '1800'),
('redirect_url', ''),
('read_db_interval', '60'),
('read_config_interval', '60'),
('pid_file', 'xbt_tracker.pid'),
('offline_message', ''),
('log_scrape', '0'),
('log_announce', '0'),
('log_access', '0'),
('listen_port', '2710'),
('listen_ipa', '*'),
('listen_check', '0'),
('gzip_scrape', '1'),
('gzip_debug', '1'),
('gzip_announce', '1'),
('full_scrape', '1'),
('debug', '0'),
('daemon', '1'),
('clean_up_interval', '60'),
('auto_register', '0'),
('anonymous_scrape', '0'),
('anonymous_announce', '0'),
('anonymous_connect', '0'),
('announce_interval', '1800'),
('write_db_interval', '60'),
('update_files_method', '2'),
('cheater', '1'),
('freetorrent', '0'),
('snatched', '0');