typedef unsigned char byte;
