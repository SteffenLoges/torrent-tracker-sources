<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/



# This file will only be accessed by user if url rewrite is not configured correctly.

//error_reporting ( E_ALL );

//require_once ( '../conf.localhost.php' );

if ( !file_exists ( './lock' ) )
{
	die ( 'Diferior is already installed.' );	
}

define ( 'VIA_INDEX', true );
	
require_once ( dirname(__FILE__).'/../conf.php' );
require_once ( dirname(__FILE__).'/../error.php' );
require_once ( dirname(__FILE__).'/../core.php' );

# Set error and exception handlers
set_error_handler ( array ( 'error', 'php_error_handler' ) );
set_exception_handler ( array ( 'error', 'php_exception_handler' ) );
	
try 
{

	if ( URL_REWRITING )
	{
		# Attempt to disable url-rewriting
		$config = & core::load_file ( 'config' );
		$config -> load_file ( dirname(__FILE__).'/../conf.php' );
		$config -> update_single ( 'URL_REWRITING', false );
		
		$url = $_SERVER [ 'HTTP_HOST' ] . str_replace ( '/install/check_url_rewrite.php', null, $_SERVER [ 'PHP_SELF' ] );
		
		header ( 'location: http://'. $url );
		die ();	
	}
	else
	{
		# Not good
		throw new error ( 'Some kind of error occured. This might be a bug. You should report it to http://diferior.com' );
	}
	
	//throw new error ( 'URL rewriting is not configured.<br/>For Diferior to function correctly it is necessary for server to support mod_rewrite or equivalent httpd module. Please see included .htaccess file in diferior root directory for mod_rewrite configuration. You might consider moving it\'s contents to webserver configuration file or contacting your hosting support.' );
	
}
catch ( error $e )
{
	
	error::display_error ( $e );
	
}

?>