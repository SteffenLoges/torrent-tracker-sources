<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	error_reporting ( E_ALL );

	class error extends Exception 
	{
		
		private static $silent = false, $line_no = 0;
		
		
		
		public function __construct ( $message = null, $code = 0 ) 
		{
			if ( is_array ( $message ) )
			{
				$message = '<pre>'. htmlspecialchars (  print_r ( $message, 1 ) ) .'</pre>';	
			}
	    	parent::__construct ( $message, $code );
	   	}
	
	   	
	   	# Handles PHP errors
	   	public static function php_error_handler ( $errno, $errstr, $errfile, $errline )
	   	{
	   		if ( !self::$silent ) 
	   		{
	   			throw new error ( "<b>$errstr</b> (<b>#$errno</b>) in <b>$errfile</b> on line <b>$errline</b>" );
	   		}
	   	}
	   	
	   	
	   	# Handles exceptions
	   	public static function php_exception_handler ( $e )
	   	{
	   		die ( $e -> getMessage () );
	   	}	
   	
   	
   		# Displays error
   		public static function display_error ( $e )
   		{
   			if ( self::$silent ) return null; 
   			
   			# If logging errors is enabled
   			if ( ERR_FILE != null && ERR_FILE != DIR )
   			{
   				$log_file = ERR_FILE;
   				$fl = fopen ( $log_file, 'a' );
   				if ( flock ( $fl, LOCK_EX ) ) 
 				{
 					$error_message = 
 							"-------------------------\n".
 							# Date and IP
 							date ( 'm d - H:i:s' ) ."\nIP: ". $_SERVER [ 'REMOTE_ADDR' ] . 
 							# If proxy is used, pass proper IP
 							( isset ( $_SERVER [ 'HTTP_X_FORWARDED_FOR' ] ) ? ' ('. $_SERVER [ 'HTTP_X_FORWARDED_FOR' ] .')' : null ) .
 							# Browser
 							"\nUserAgent: ". ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ) .
 							# Error
 							"\nFile: ". $e -> getFile () .
 							"\nLine: ". $e -> getLine () .
 							"\nCode: ". $e -> getCode () .
 							"\nMessage: ". $e -> getMessage () .
 							"\n\n";
   					fputs ( $fl, $error_message );
				} 
   				fclose ( $fl );	
   			}
   		

			//if ( ERR_LEVEL > 0 ) 
			//{
				
				self::toggle_silent ( true );
				@ob_end_clean ();
				ob_start ();
				
				header ( 'Content-Type: text/html; charset=utf-8' );
				header ( 'Cache-Control: no-store, no-cache, must-revalidate' );
	
				echo '
				<html>
					<head>
					<title>Error occured</title>
				
					<style type="text/css">
						* 
						{ 
							margin: 0; 
							padding: 0; 
							border: 0;
							font-family: Arial;
						 }
						
						body 
						{ 
							background: #F0F0F1; 
							padding: 10px;
						}
						
						.box
						{
							border: 2px solid #909078;
							background: #D8F0C1;
						}
						
						.box div
						{
							padding: 4px;
							margin: 6px;
							border: 1px solid #787860;
							background: #C0D8A7;
							color: #787860;
							font-size: 1.1em;
						}
						
						.box div b
						{
							font-weight: 700;
							color: #ec1313;
						}
						
						.box div.sub
						{
							font-size: 1em;
						}
						
						.box div.plain
						{
							margin: 10px;
							font-size: 1em;
							border: 0;
							padding: 0;
							background: 0;
						}
					</style>
					</head>
								
					<body>';
		
					echo '<div class="box">
						<div><b>'. ( ERR_LEVEL >=2 ? $e -> getMessage () : str_replace ( DIR, null, $e -> getMessage () ) ) .'</b></div>';
					
					if ( ERR_LEVEL >= 1 )
					{
						echo '
							<div class="sub">
							Line: '. $e -> getLine () .'<br/>
							'. ( ERR_LEVEL >=2 ? 'File: '. $e -> getFile () .'<br/>' : null ) .'
							Code: '. $e -> getCode () .'
							</div>
						</div>';
					}
		
					if ( ERR_LEVEL >= 3 ) 
					{
						echo '<br/><div class="box"><div>Trace</div>';
						
						foreach ( $e -> getTrace () as $value )
						{
							echo '<div class="sub">
							File: '. ( isset ( $value [ 'file' ] ) ? $value [ 'file' ] : 'No file' ) .'<br/>
							Class: '. ( isset ( $value [ 'class' ] ) ? $value [ 'class' ] : 'No class' ) .'<br/>
							Function: '. ( isset ( $value [ 'function' ] ) ? $value [ 'function' ] : 'No function' ) .'<br/>
							Line: '. ( isset ( $value [ 'line' ] ) ? $value [ 'line' ] : 'No line' )
							.'</div>';
						}
						
						echo '</div>';
					}
					
					if ( ERR_LEVEL >= 4 ) 
					{
					
						echo '<br/><div class="box"><div>Included files</div><div class="plain">';
						
						foreach ( get_included_files() as $value )
						{
							echo $value .'<br/>';
						}
						
						echo '</div></div>';			
					}		
				
				echo '
					</body>
				</html>';
				
			//}
		}
		
		
		# Possiblity to ignore some error messages
		public static function toggle_silent ( $mode )
		{
				if ( !is_bool ( $mode ) )
					$mode = false;
					
				self::$silent = $mode;
		}
		
		
		# Sets 'return false' line
		public static function line ( $line )
		{
			self::$line_no = $line;	
		}
		
		
		# Returns 'return false' line
		public static function get_line ()
		{
			return self::$line_no;	
		}
	
	}
?>