<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	# Load GD functions wrapper class
	$gd = core::load_file ( 'gd' );
	
	if ( !isset ( $_SESSION [ 'captcha' ] ) )
	{
		$_SESSION [ 'captcha' ] = $text -> pronounceable ();
	}
	$code = $_SESSION [ 'captcha' ];
	
	# Captcha type
	if ( isset ( $args [ 1 ] ) && $args [ 1 ] == 's' )
	{
		# Small	
		$gd -> create ( 200, 20 );
		$y = rand ( 11, 17 );
		$rotation = 0;
	}
	else 
	{
		# Big	
		$gd -> create ( 660, 30 );
		$y = 'r';
		$rotation = 'r';
	}
		
	$col = $gd -> diff_color ( 0, 0, 0, true );
	$gd -> text ( $code, rand ( 10, 11 ), array ( rand(0, $col[0]), rand(0, $col[1]), rand(0, $col[2]) ), 'r', $y, DIR.'/resources/captcha.ttf', $rotation );
	//$gd -> trash ( 0, 25 );
	$gd -> output ('auto');
	
	$session -> __destruct ();

	# Suicide
	die ();

?>