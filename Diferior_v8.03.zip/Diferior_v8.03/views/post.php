<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_BLOG ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	# User allowed to post?
	if ( !isset ( $_SESSION [ 'logged' ] ) || $_SESSION [ 'logged' ] !== true || $_SESSION [ 'permissions' ] [ 'make_posts' ] != 1 )
	{
		$S [ 'err' ] = true;	
	}
	else 
	{
		$S [ 'err' ] = false;	
	}

	if ( !$S [ 'err' ] )
	{
		$S [ 'stylesheets' ] [] = 'post.css';
		$S [ 'javascripts' ] [] = 'post.js';
	
		$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
		$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
	
		switch ( $args [ 1 ] )
		{
			default:
					$args [ 1 ] = null;
				break;
				
			case 'new':
			case 'edit':
					if ( $args [ 2 ] != 2 && $args [ 2 ] != 'preview' )
					{
						# Prepare dummy post (for preview template initialization)
						$S [ 'dummy_post' ] = array ( 0 => array (
							'b' => 'b', 'name' => null, 'lid' => null, 'plid' => null, 'posted' => time(), 'updated' => 0,
							'header' => null, 'subheader' => null, 'author' => $_SESSION [ 'user' ], 'content' => null, 'comments' => 0, 
							'parse_html' => 0, 'id' => 0, 'tags' => ''
						) );
						
						if ( $args [ 1 ] == 'edit' )
						{
							if ( preg_match ( "#^(p|q)([0-9]+)\$#", $args [ 2 ], $m ) )
							{
								# Get post id
								$S [ 'post_table' ] = $m [ 1 ];
								$S [ 'post_id' ] = $m [ 2 ];
								
								# Get plid and lid
								$res = $blog -> get_plid_lid ( $m [ 2 ], ( $m [ 1 ] == 'p' ? false : true ) );
								
								# Post exists?
								if ( !empty ( $res ) )
								{
									# Get post info
									$S [ 'post' ] = $blog -> get_post ( $res [ 'plid' ], $res [ 'lid' ], ( $m [ 1 ] == 'p' ? false : true ) );
									
									# User is the author (or has permissions to edit it)
									if ( $S [ 'post' ] [ 'author' ] == $_SESSION [ 'user' ] || $_SESSION [ 'permissions' ] [ 'edit_posts' ] == 1 )
									{
										# Get attachments 
										$S [ 'files' ] = $blog -> get_attachments ( $res [ 'plid' ], $res [ 'lid' ] );
										
										# Parse tags
										if ( FUNC_TAGS )
										{
											$blog -> split_tags ( $S [ 'post' ], true );
											$S [ 'post' ] [ 'tags' ] = implode ( ',', $S [ 'post' ] [ 'tags' ] );
										}
										
										# Update preview post info
										$S [ 'dummy_post' ] [ 0 ] = $S [ 'post' ];
										$S [ 'dummy_post' ] [ 0 ] [ 'b' ] = 'b';
										$S [ 'dummy_post' ] [ 0 ] [ 'updated' ] = time ();
										
										# For posts in queue
										if ( !isset ( $S [ 'dummy_post' ] [ 0 ] [ 'posted' ] ) )
										{
											$S [ 'dummy_post' ] [ 0 ] [ 'posted' ] = $S [ 'post' ] [ 'post_date' ];
										}
									}
									else 
									{
										$S [ 'err' ] = true;
									}
								}
								else 
								{
									$S [ 'err' ] = true;	
								}
							}
							else 
							{
								$S [ 'err' ] = true;
							}
						}
						
						$S [ 'sch_dates' ] = $blog -> get_queue_dates ( 20 );
					}
					elseif ( $args [ 2 ] == 'preview' )
					{
						$content = ( isset ( $_POST [ 'content' ] ) ? $_POST [ 'content' ] : null );
						$cat = ( isset ( $_POST [ 'cat' ] ) ? $_POST [ 'cat' ] : null );
						$post = ( isset ( $_POST [ 'post' ] ) ? $_POST [ 'post' ] : null );
						$parse_html = ( isset ( $_POST [ 'parse_html' ] ) ? $_POST [ 'parse_html' ] : true );
						if ( $parse_html == 'true' ) 
						{
							$parse_html = false;
						}
						else 
						{
							$parse_html = true;	
						}
						
						if ( $post == null )
						{
							$post = 'test';
						}
						else
						{
							$post = $text -> make_lid ( $text -> decode_unicode_url ( $post ) );
						}
						
						$content = $text -> convert ( $text -> decode_unicode_url ( $content ) );
						
						//if ( get_magic_quotes_gpc() )
						//{
						//	$content = stripslashes ( $content );
						//	$post = stripslashes ( $post );	
						//}
						
						$content = str_replace ( "\n", "\r\n", $content );
						$content = str_replace ( "\r\r", "\r", $content );
						
						echo $text -> do_parse_post ( $content, $cat, $post, $parse_html, true );
						die ();
					}
					else 
					{
						$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
						
						if ( $args [ 1 ] == 'edit' )
						{
							# Editing
							if ( preg_match ( "#^(p|q)([0-9]+)\$#", $args [ 3 ], $m ) )
							{
								# Get post author
								//$res = $blog -> get_post_info ( 'author, plid, cat', $m [ 2 ], ( $m [ 1 ] == 'p' ? false : true ) );
								$res = $blog -> get_plid_lid ( $m [ 2 ], ( $m [ 1 ] == 'p' ? false : true ), ',b.author, blog_categories.id' );
								$author = & $res [ 'author' ];
								$plid = & $res [ 'plid' ];
								$lid = & $res [ 'lid' ];
								$lid_id = & $res [ 'id' ];
								if ( $author == $_SESSION [ 'user' ] || $_SESSION [ 'permissions' ] [ 'edit_posts' ] == 1 )
								{
									$S [ 'res' ] = $blog -> edit_post ( $m [ 2 ], $_POST [ 'category' ], $_POST [ 'header' ], $_POST [ 'subheader' ], 
										$_POST [ 'post_content' ], $_POST [ 'schedule' ], $_POST [ 'usehtml' ], ( isset ( $_POST [ 'copyright' ] ) ? true : false ),
										( $m [ 1 ] == 'p' ? false : true ), $plid, $lid, $lid_id, ( FUNC_TAGS ? $_POST [ 'tags' ] : null ) );
								}
								else 
								{
									$S [ 'res' ] = false;	
								}
							}
							else 
							{
								$S [ 'res' ] = false;	
							}
						}
						else 
						{	
							# New post
							$S [ 'res' ] = $blog -> new_post ( $_POST [ 'category' ], $_POST [ 'header' ], $_POST [ 'subheader' ], 
								$_POST [ 'post_content' ], $_POST [ 'schedule' ], $_POST [ 'usehtml' ], ( isset ( $_POST [ 'copyright' ] ) ? true : false ), 
								null, null, ( FUNC_TAGS ? $_POST [ 'tags' ] : null ) );
						}
					}
				break;
				
				
			case 'list':
					$S [ 'posts' ] = $blog -> get_user_posts ();
				break;
				
				
			case 'delete':
					$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
					
					if ( $args [ 3 ] == 2 )
					{
						if ( preg_match ( "#^(p|q)([0-9]+)\$#", $args [ 2 ], $m ) )
						{
							$S [ 'res' ] = $blog -> delete_post ( $m [ 2 ], ( $m [ 1 ] == 'q' ? true : false ), $returninfo );
							if ( $S [ 'res' ] == true ) 
							{
								//$log -> write ( null, 'delete', implode ( '/', array ( 'file', $returninfo [ 'lid' ], $returninfo [ 'sublid' ], $returninfo [ 'plid' ] ) ), $returninfo [ 'header' ] );
							}
						}
						else 
						{
							$S [ 'res' ] = false;	
						}
					}
				break;	
		}
	}

?>