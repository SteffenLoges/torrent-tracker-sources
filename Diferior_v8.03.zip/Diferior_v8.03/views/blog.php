<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	if ( $view == 'cat' || $view == 'blog' || isset ( $start_page ) )
	{
		if ( isset ( $args [ 1 ] ) )
		{
			$cat = $db -> escape ( $args [ 1 ] );
		}
		else 
		{
			$cat = 'all';
		}
		
		if ( isset ( $args [ 2 ] ) )
		{
			if ( preg_match ( "#^page([0-9]+)\$#", $args [ 2 ], $m ) )
			{
				$page = $m [ 1 ];
			}
			else 
			{
				$page = 1;	
			}
		}
		else 
		{
			$page = 1;	
		}
		
		if ( !isset ( $start_page ) )
		{
			# Get category name
			$S [ 'header' ] = $blog -> get_cat_info ( $cat, 'name' );
			if ( $S [ 'header' ] == null )
			{
				$S [ 'header' ] = $l -> t ( 'blog_newest_entries' );	
			}
		}
	}
	else 
	{
		$cat = null;
		$page = 1;	
	}
	
	if ( !isset ( $start_page ) || !FUNC_DOWNLOADS || !TITLE_DOWNLOADS )
	{
		# Blog
		if ( FUNC_BLOG )
		{
			$S [ 'posts' ] = $blog -> get_posts ( $cat, $page, $S [ 'page_count' ] );
			$S [ 'post_count' ] = $blog -> get_post_count ( $cat );
			if ( FUNC_TAGS && $S [ 'posts' ] !== false )
			{
				$blog -> split_tags ( $S [ 'posts' ] );
			}
		}
		else 
		{
			$S [ 'posts' ] = array ();
			$S [ 'post_count' ] = 0;
			$S [ 'page_count' ] = 0;	
		}
	}
	else 
	{
		# Title
		$S [ 'posts' ] = $blog -> get_posts_downloads ( $page, $S [ 'page_count' ], $S [ 'post_count' ] );
		$S [ 'start_page' ] = true;
		if ( FUNC_TAGS )
		{
			$blog -> split_tags ( $S [ 'posts' ] );
		}
	}
	
	$S [ 'page' ] = & $page;
	$S [ 'cat' ] = & $cat;
	
?>