<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


# Check if included via index.php
if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

# Function disabled
if ( !FUNC_RSS ) die ( $l -> t ( 'err_func_disabled' ) );


$action = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );

if ( preg_match ( "#^(pending|cheaters)\-([^-]+)\-([a-z0-9]+)\.xml\$#", $action, $m ) )
{
	$action = $m [ 1 ] .'.xml';
}

# No sid in URLs
$url -> add_sid = false;
		
switch ( $action )
{
	default:
			$S [ 'readers' ] = array (
				'blog'				=>	$counters -> online ( 'rss_blog.xml', false, true ),
				'downloads'			=>	$counters -> online ( 'rss_downloads.xml', false, true ),
				'blog_comments'		=>	$counters -> online ( 'rss_blog_comments.xml', false, true ),
				'download_comments'	=>	$counters -> online ( 'rss_download_comments.xml', false, true ),
			);
		break;
		
	case 'index.xml':
	case 'blog.xml':
	case 'downloads.xml':
	case 'blog_comments.xml':
	case 'download_comments.xml':
	case 'pending.xml':
	case 'cheaters.xml':
		if ( $action == 'index.xml' || $action == 'blog.xml' )
		{
			# Function disabled
			if ( !FUNC_BLOG ) die ( $l -> t ( 'err_func_disabled' ) );
			
			$type = $l -> t ( 'rss_type_blog' );
		}
		elseif ( $action == 'downloads.xml' )
		{
			# Function disabled
			if ( !FUNC_DOWNLOADS ) die ( $l -> t ( 'err_func_disabled' ) );
			
			$type = $l -> t ( 'rss_type_downloads' );
		}
		elseif ( $action == 'blog_comments.xml' )
		{
			# Function disabled
			if ( !FUNC_BLOG ) die ( $l -> t ( 'err_func_disabled' ) );
			
			$type = $l -> t ( 'rss_type_blog_comments' );
		}
		elseif ( $action == 'download_comments.xml' )
		{
			# Function disabled
			if ( !FUNC_DOWNLOADS ) die ( $l -> t ( 'err_func_disabled' ) );
			
			$type = $l -> t ( 'rss_type_download_comments' );
		}
		elseif ( $action == 'pending.xml' )
		{
			# Function disabled
			if ( !FUNC_DOWNLOADS ) die ( $l -> t ( 'err_func_disabled' ) );
			
			$type = $l -> t ( 'rss_type_unconfirmed_downloads' );
			
			if ( !isset ( $m [ 2 ] ) ) throw new error ( $l -> t ( 'rss_err_access_denied' ) );
			$nm = $db -> get_one ( "SELECT users_permissions.approve_downloads FROM users LEFT JOIN users_permissions ON (users.name=users_permissions.user) WHERE users.name='". $m [ 2 ] ."' AND users.pass='". $m [ 3 ] ."'" );
			if ( $nm != 1 ) throw new error ( $l -> t ( 'rss_err_access_denied' ) );
		}
		elseif ( $action == 'cheaters.xml' )
		{
			# Function disabled
			if ( !FUNC_DOWNLOADS ) die ( $l -> t ( 'err_func_disabled' ) );
			
			$type = $l -> t ( 'rss_type_cheaters' );
			
			if ( !isset ( $m [ 2 ] ) ) throw new error ( $l -> t ( 'rss_err_access_denied' ) );
			$nm = $db -> get_one ( "SELECT users_permissions.cheater_list FROM users LEFT JOIN users_permissions ON (users.name=users_permissions.user) WHERE users.name='". $m [ 2 ] ."' AND users.pass='". $m [ 3 ] ."'" );
			if ( $nm != 1 ) throw new error ( $l -> t ( 'rss_err_access_denied' ) );
		}
		
		$counters -> online ( 'rss_'. $action, true, false, 43200 );
		
		header("Content-Type: application/rss+xml; charset=utf-8");

		echo '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet href="http://'.URL.'/tpl_resources/'. $tpl .'/style/feed.css" type="text/css" media="screen"?>
<rss xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd" xmlns:feedburner="http://rssnamespace.org/feedburner/ext/1.0" version="2.0">
<channel>
<title>'. PAGE_NAME .' &#8212; '. $type .'</title>
<link>http://'. URL .'</link>
<description>'. PAGE_SLOGAN .'</description>
<atom10:link xmlns:atom10="http://www.w3.org/2005/Atom" rel="self" href="'. $url -> make ( 'rss', $action ) .'" type="application/rss+xml" />
';

		# Init cache
		$cache -> init ( 'rss_'. $action, 60, CACHE_RSS );	
		$cached = $cache -> get ();
		if ( $cached !== false )
		{
			# Return cached result
			echo $cached;	
		}
		else 
		{
			$output = null;
			
			switch ( $action )
			{
				# Blog posts
				case 'index.xml':
				case 'blog.xml':
						$posts = $blog -> get_posts ( null, 1 );
			
						foreach ( $posts as $p )
						{
							$link = $url -> make ( 'read', $p [ 'lid' ], $p [ 'plid' ] );
							$descr = $text -> parse_post ( $p [ 'content' ], $p [ 'lid' ], $p [ 'plid' ], $p [ 'parse_html' ], false, true, $p [ 'id' ], false, 'p', $link );
							$output .= '<item>
											<category>'. htmlspecialchars ( $p [ 'name' ] ) .'</category>
											<title>'. $text -> replace_quotes ( htmlspecialchars ( $p [ 'header' ] ) ) .'</title>
											<dc:creator>'. $p [ 'author' ] .'</dc:creator>
											<description>'. htmlspecialchars ( $descr ) .'</description>
											<pubDate>'. date ( DATE_RFC822, $p [ 'posted' ] ) .'</pubDate>
											<link>'. $link .'</link>
										</item>';
						}
						
						if ( CACHE_RSS )
						{
							$cache -> save ( $output );
						}
					break;
					
					
				# Downloads
				case 'downloads.xml':
						$downloads = $downloads -> get ( null, null, 1, null, true, $tmp1, $tmp2, ',dl.content' );
			
						foreach ( $downloads as $p )
						{
							$link = $url -> make ( 'file', $p [ 'lid' ], $p [ 'sub_lid' ], $p [ 'plid' ] );
							$shorten = ( stripos ( $p [ 'content' ], '[break]' ) !== false );
							$descr = $text -> parse_post ( $p [ 'content' ], $p [ 'lid' ], $p [ 'plid' ], false, false, $shorten, $p [ 'fid' ], false, null, $link );
							$output .= '<item>
											<category>'. htmlspecialchars ( $p [ 'name' ] ) .' &#187; '. htmlspecialchars ( $p [ 'sub_name' ] ) .'</category>
											<title>'. $text -> replace_quotes ( htmlspecialchars ( $p [ 'header' ] ) ) .'</title>
											<dc:creator>'. ( $p [ 'anonymous' ] ? $l -> t ( 'rss_download_author_anonymous' ) : $p [ 'user' ] ) .'</dc:creator>
											<description>'. htmlspecialchars ( $descr ) .'</description>
											<pubDate>'. date ( DATE_RFC822, $p [ 'posted' ] ) .'</pubDate>
											<link>'. $link .'</link>
										</item>';
						}
						
						if ( CACHE_RSS )
						{
							$cache -> save ( $output );
						}
					break;	
					
					
				# Blog comments
				case 'blog_comments.xml':
						$comments = $comments -> get ( null, null, $void, 'blog_comments' );
						
						foreach ( $comments as $p )
						{
							if ( !isset ( $cm [ $p [ 'bpid' ] ] ) )
							{
								$cm [ $p [ 'bpid' ] ] = $p [ 'comments' ];
							}
							else 
							{
								$cm [ $p [ 'bpid' ] ]--;
							}
							$cno = $cm [ $p [ 'bpid' ] ];
							
							$link = $url -> make ( 'read', $p [ 'lid' ], $p [ 'plid' ], 'c'. $cno );
							$descr = str_replace ( "\r\n", ' ', htmlspecialchars ( $text -> parse_post ( $p [ 'content' ] ) ) );
							$user_url = $url -> make ( 'user', 'v', $p [ 'author' ] );
							$author = ( $p [ 'anonymous' ] != 1 ? '&lt;a href="'. $user_url .'"&gt;'. $p [ 'author' ] .'&lt;/a&gt;' : $p [ 'author' ] );
							$output .= '<item>
											<title>'. htmlspecialchars ( $p [ 'header' ] ) .'</title>
											<link>'. $link .'</link>
											<dc:creator>'. $p [ 'author' ] .'</dc:creator>
											<description>'. $author .':&lt;br/&gt;'. $descr .'</description>
											<pubDate>'. date ( DATE_RFC822, $p [ 'posted' ] ) .'</pubDate>
										</item>';
						}
						
						if ( CACHE_RSS )
						{
							$cache -> save ( $output );
						}
					break;	
					
					
				# Download comments
				case 'download_comments.xml':
						$comments = $comments -> get ( null, null, $void, 'dl_comments' );
						
						foreach ( $comments as $p )
						{
							if ( !isset ( $cm [ $p [ 'bpid' ] ] ) )
							{
								$cm [ $p [ 'bpid' ] ] = $p [ 'comments' ];
							}
							else 
							{
								$cm [ $p [ 'bpid' ] ]--;
							}
							$cno = $cm [ $p [ 'bpid' ] ];
							
							$link = $url -> make ( 'file', $p [ 'lid' ], $p [ 'sublid' ],  $p [ 'plid' ], 'c'. $cno );
							$descr = str_replace ( "\r\n", ' ', htmlspecialchars ( $text -> parse_post ( $p [ 'content' ] ) ) );
							$user_url = $url -> make ( 'user', 'v', $p [ 'author' ] );
							$author = ( $p [ 'anonymous' ] != 1 ? '&lt;a href="'. $user_url .'"&gt;'. $p [ 'author' ] .'&lt;/a&gt;' : $p [ 'author' ] );
							$output .= '<item>
											<title>'. htmlspecialchars ( $p [ 'header' ] ) .'</title>
											<link>'. $link .'</link>
											<dc:creator>'. $p [ 'author' ] .'</dc:creator>
											<description>'. $author .':&lt;br/&gt;'. $descr .'</description>
											<pubDate>'. date ( DATE_RFC822, $p [ 'posted' ] ) .'</pubDate>
										</item>';
						}
						
						if ( CACHE_RSS )
						{
							$cache -> save ( $output );
						}
					break;	
					
					
				# Pending downloads
				case 'pending.xml':
						$downloads = $downloads -> get_pending_downloads ( 20, ', dl.content, dl.user' );
						
						foreach ( $downloads as $p )
						{
							$link = $url -> make ( 'upload', 'edit', $p [ 'fid' ] );
							$shorten = ( stripos ( $p [ 'content' ], '[break]' ) !== false );
							$descr = $text -> parse_post ( $p [ 'content' ], $p [ 'lid' ], $p [ 'plid' ], false, false, $shorten, $p [ 'fid' ], false, null, $link );
							$output .= '<item>
											<category>'. htmlspecialchars ( $p [ 'name' ] ) .' &#187; '. htmlspecialchars ( $p [ 'subname' ] ) .'</category>
											<title>'. $text -> replace_quotes ( htmlspecialchars ( $p [ 'header' ] ) ) .'</title>
											<dc:creator>'. $p [ 'user' ] .'</dc:creator>
											<description>'. htmlspecialchars ( $descr ) .'</description>
											<pubDate>'. date ( DATE_RFC822, $p [ 'posted' ] ) .'</pubDate>
											<link>'. $link .'</link>
										</item>';
						}
						
						if ( CACHE_RSS )
						{
							$cache -> save ( $output );
						}
					break;	
					
					
				# Cheaters
				case 'cheaters.xml':
						$posts = $downloads -> get_cheater_list ( 20 );
						
						foreach ( $posts as $p )
						{
							$link = $url -> make ( 'upload', 'cheaters', '#ch'. $p [ 'id' ] );
							$descr = 'IP: '. long2ip ( $p [ 'ipa' ] ) .'<br/>Uploaded: '. $template -> format_size ( $p [ 'uploaded' ] ) .' ('. $template -> format_size ( $p [ 'upspeed' ] ) .'/s)';
							$output .= '<item>
											<title>'. htmlspecialchars ( $p [ 'name' ] ) .'</title>
											<description>'. $descr .'</description>
											<pubDate>'. date ( DATE_RFC822, $p [ 'tstamp' ] ) .'</pubDate>
											<link>'. $link .'</link>
										</item>';
						}
						
						if ( CACHE_RSS )
						{
							$cache -> save ( $output );
						}
					break;					
			}
				
			echo $output;
		}
		
		die ( '</channel></rss>' );
	break;		
}
	
?>