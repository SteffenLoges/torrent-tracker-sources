<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_FORUMS ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	$S [ 'stylesheets' ] [] = 'forum.css';
	
	$S [ 'op' ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
	
	switch ( $S [ 'op' ] )
	{

		default:
				$S [ 'header' ] = $l -> t ( 'forum_index' );
			
				$S [ 'op' ] = null;
				
				$S [ 'boards' ] = $forum -> get_boards ();
			break;
			
			
		case 'board':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				
				$S [ 'res' ] = $forum -> get_forum_id ( $args [ 2 ], $args [ 3 ], ', forum_categories.title AS cat, forum_boards.title, forum_boards.threads' );
				
				$S [ 'err' ] = false;
								
				if ( $S [ 'res' ] == false )
				{
					$S [ 'err' ] = true;	
				}
				else
				{		
					if ( isset ( $args [ 4 ] ) )
					{
						if ( preg_match ( "#^page([0-9]+)\$#", $args [ 4 ], $m ) )
						{
							$S [ 'page' ] = $m [ 1 ];
						}
						else 
						{
							$S [ 'page' ] = 1;	
						}
					}
					else 
					{
						$S [ 'page' ] = 1;	
					}
					
					$S [ 'threads' ] = $forum -> get_threads ( $S [ 'res' ] [ 'id' ], $S [ 'page' ], $S [ 'page_count' ] );
					$S [ 'post_count' ] = & $S [ 'res' ] [ 'threads' ];
					
					$S [ 'header' ] = $S [ 'res' ] [ 'cat' ] .' &#187; '. $S [ 'res' ] [ 'title' ];
					
					setcookie ( 'forum_'. $S [ 'res' ] [ 'id' ], time (), time () + 172800, '/', SESS_COOKIE_DOMAIN );
				}
			break;
			
			
		case 'thread':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				$args [ 4 ] = ( isset ( $args [ 4 ] ) ? $args [ 4 ] : null );
				
				$S [ 'res' ] = $forum -> get_thread_id ( $args [ 2 ], $args [ 3 ], $args [ 4 ], ', forum_categories.title AS cat, forum_boards.title AS forum, forum_boards.id AS fid, forum_threads.title, forum_threads.posts, forum_threads.closed, forum_threads.pinned' );
				
				$S [ 'err' ] = false;
								
				if ( $S [ 'res' ] == false )
				{
					$S [ 'err' ] = true;	
				}
				else
				{		
					if ( isset ( $args [ 5 ] ) )
					{
						if ( preg_match ( "#^page([0-9]+)\$#", $args [ 5 ], $m ) )
						{
							$S [ 'page' ] = $m [ 1 ];
						}
						elseif ( preg_match ( "#^p([0-9]+)\$#", $args [ 5 ], $m ) )
						{
							$post_no = $m [ 1 ];	
						}
						else 
						{
							$S [ 'page' ] = 1;	
						}
					}
					else 
					{
						$S [ 'page' ] = 1;	
					}
					
					# Get posts
					if ( isset ( $post_no ) )
					{
						if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'forum_posts_no' ] == 0 )
						{
							$page_count = FORUM_POSTS_PAGE;	
						}
						else 
						{
							$page_count = $_SESSION [ 'preferences' ] [ 'forum_posts_no' ];
						}
						
						$S [ 'page' ] = ceil ( $post_no / $page_count );
						$S [ 'pages' ] = ceil ( $S [ 'res' ] [ 'posts' ] / $page_count );
						
						if ( isset ( $post_no ) && isset ( $_SESSION [ 'preferences' ] ) && $_SESSION [ 'preferences' ] [ 'forum_posts_dir' ] != 0 )
						{
							$S [ 'page' ] = ceil ( ($S [ 'res' ] [ 'posts' ] - $post_no +1) / $page_count );
						}
					}
					
					$S [ 'posts' ] = $forum -> get_posts ( $S [ 'res' ] [ 'id' ], $S [ 'page' ], $S [ 'page_count' ] );
					$S [ 'post_count' ] = & $S [ 'res' ] [ 'posts' ];
					if ( !isset ( $S [ 'pages' ] ) )
					{
						$S [ 'pages' ] = ceil ( $S [ 'res' ] [ 'posts' ] / $S [ 'page_count' ] );	
					}
					
					$S [ 'header' ] = htmlspecialchars ( $S [ 'res' ] [ 'title' ] );
					
					# Get smilie list
					$S [ 'smilies' ] = $text -> get_smilies ( true );
					
					setcookie ( 'forum_'. $S [ 'res' ] [ 'fid' ], time (), time () + THREAD_TIMEOUT, '/', SESS_COOKIE_DOMAIN );
					setcookie ( 'thread_'. $S [ 'res' ] [ 'id' ], time (), time () + THREAD_TIMEOUT, '/', SESS_COOKIE_DOMAIN );
				}
			break;			
			
			
		case 'newthread':
				$S [ 'header' ] = $l -> t ( 'forum_new_thread' );
			
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				
				$S [ 'err' ] = false;
				
				if ( !isset ( $_SESSION [ 'logged' ] ) || !$_SESSION [ 'logged' ] )
				{
					$S [ 'err' ] = $l -> t ( 'err_not_logged' );
					$args [ 3 ] = null;
				}
				else 
				{
					if ( $args [ 3 ] != 2 )
					{
						# Get smilie list
						$S [ 'smilies' ] = $text -> get_smilies ( true );
					}
					else 
					{
						# Create thread
						$S [ 'name_p' ] = ( isset ( $_POST [ 'name' ] ) ? $_POST [ 'name' ] : null );
						$S [ 'description_p' ] = ( isset ( $_POST [ 'description' ] ) ? $_POST [ 'description' ] : null );
						$S [ 'message_p' ] = ( isset ( $_POST [ 'message' ] ) ? $_POST [ 'message' ] : null );
						
						# Antiflood
						$S [ 'aflood' ] = $_SESSION [ 'userinfo' ] [ 'last_thread' ] + FORUM_THREAD_ANTIFLOOD - time ();
						if ( $S [ 'aflood' ] <= 0 )
						{
							if ( trim ( $S [ 'name_p' ] ) == null || trim ( $S [ 'message_p' ] ) == null )
							{
								$S [ 'err' ] = $l ->t ( 'forum_err_thread_name_message_empty' );	
							}
							else 
							{
								$res = $forum -> new_thread ( $args [ 2 ], $S [ 'name_p' ], $S [ 'description_p' ], $S [ 'message_p' ] );
								if ( $res !== false )
								{
									header ( 'Location: '. $url -> make ( 'forum', 'thread', $res [ 'clid' ], $res [ 'flid' ], $res [ 'tlid' ] ) );
									die ();
								}
							}
						}
						
					}
				}
			break;
			
			
		case 'reply':
				$S [ 'header' ] = $l -> t ( 'forum_reply' );
			
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				$args [ 4 ] = ( isset ( $args [ 4 ] ) ? $args [ 4 ] : '__' );
				
				$S [ 'err' ] = false;
				
				if ( !isset ( $_SESSION [ 'logged' ] ) || !$_SESSION [ 'logged' ] )
				{
					$S [ 'err' ] = $l -> t ( 'err_not_logged' );
					$args [ 3 ] = null;
				}
				else 
				{
					if ( $args [ 3 ] != 2 )
					{
						# Get smilie list
						$S [ 'smilies' ] = $text -> get_smilies ( true );
						
						# Quote
						if ( preg_match ( "#^q([0-9]+)\$#", $args [ 3 ], $m ) )
						{
							$S [ 'quote_post' ] = $forum -> get_post ( $m [ 1 ] );
							$S [ 'quote_post' ] [ 'content' ] = "[quote]\n". $S [ 'quote_post' ] [ 'content' ] ."\n[/quote]\n";
						}
						# Edit
						elseif ( preg_match ( "#^e([0-9]+)\$#", $args [ 3 ], $m ) )
						{
							$S [ 'edit_post' ] = $forum -> get_post ( $m [ 1 ] );
							$S [ 'quote_post' ] = & $S [ 'edit_post' ];
							if ( strtolower ( $S [ 'edit_post' ] [ 'author' ] ) != strtolower ( $_SESSION [ 'user' ] ) && $_SESSION [ 'permissions' ] [ 'forum_moderator' ] != 1 )
							{
								$S [ 'err' ] = $l -> t ( 'forum_err_edit_permission' );	
							}
							else 
							{
								$S [ 'header' ] = $l -> t ( 'forum_edit' );	
								$args [ 3 ] = $m [ 1 ];
							}
						}
					}
					else 
					{
						# Post reply
						$S [ 'message_p' ] = ( isset ( $_POST [ 'message' ] ) ? $_POST [ 'message' ] : null );
						
						# Antiflood
						$S [ 'aflood' ] = $_SESSION [ 'userinfo' ] [ 'last_post' ] + FORUM_POSTS_ANTIFLOOD - time ();
						if ( $S [ 'aflood' ] <= 0 )
						{
							if ( trim ( $S [ 'message_p' ] ) == null )
							{
								$S [ 'err' ] = $l -> t ( 'forum_err_message_empty' );	
							}
							else 
							{
								$res = $forum -> post_reply ( $args [ 2 ], $S [ 'message_p' ], $S [ 'closed' ] );
								if ( $res !== false )
								{
									header ( 'Location: '. $url -> make ( 'forum', 'thread', $res [ 'clid' ], $res [ 'flid' ], $res [ 'tlid' ], 'p'. $res [ 'tposts' ] ) );
									die ();
								}
							}
						}
						
					}
				}
			break;		
			
			
		case 'edit':
				$S [ 'header' ] = $l -> t ( 'forum_edit' );
			
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : '__' );
				
				$S [ 'err' ] = true;
				
				if ( !isset ( $_SESSION [ 'logged' ] ) || !$_SESSION [ 'logged' ] )
				{
					$args [ 3 ] = null;
				}
				else 
				{
					if ( $args [ 3 ] != 2 )
					{
						# Edit
						if ( is_numeric ( $args [ 3 ] ) )
						{
							$S [ 'edit_post' ] = $forum -> get_post ( $args [ 3 ] );
							if ( strtolower ( $S [ 'edit_post' ] [ 'author' ] ) == strtolower ( $_SESSION [ 'user' ] ) || $_SESSION [ 'permissions' ] [ 'forum_moderator' ] == 1 )
							{
								# Update post body
								$res = $forum -> edit_post ( $args [ 3 ], $_POST [ 'message' ] );
								if ( $res )
								{
									# Everything seems to be fine, redirect user back to the forum thread
									header ( 'location: '. $url -> make ( 'forum', 'thread', $S [ 'edit_post' ] [ 'clid' ], $S [ 'edit_post' ] [ 'flid' ], $S [ 'edit_post' ] [ 'tlid' ], 'p'. $args [ 4 ] ) );
									die ();
								}
							}
						}
					}
				}
			break;		
			
			
		case 'moderate':
				$S [ 'header' ] = $l -> t ( 'forum_moderation' );
			
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				$args [ 4 ] = ( isset ( $args [ 4 ] ) ? $args [ 4 ] : null );

				$S [ 'err' ] = false;
				
				if ( !isset ( $_SESSION [ 'permissions' ] ) || $_SESSION [ 'permissions' ] [ 'forum_moderator' ] != 1 )
				{
					$S [ 'err' ] = $l -> t ( 'forum_err_permissions' );
					$args [ 4 ] = null;
				}
				else 
				{
					switch ( $args [ 3 ] )
					{
						default:
								$S [ 'err' ] = $l -> t ( 'forum_err_moderation_action' );
								$args [ 4 ] = null;
							break;	
							
						case 'delete_replies':
								$S [ 'mod_action' ] = $l -> t ( 'forum_moderation_message_deletion' );
								if ( $args [ 4 ] == 2 )
								{
									if ( isset ( $_POST [ 'delcomm' ] ) )
									{
										$S [ 'res' ] = $forum -> delete_replies ( $_POST [ 'delcomm' ], $args [ 2 ] );
									}
									else 
									{	
										$S [ 'res' ] = 0;	
									}
								}
							break;	
							
						case 'open':
								$S [ 'mod_action' ] = $l -> t ( 'forum_moderation_thread_unlock' );
								if ( $args [ 4 ] == 2 )
								{
									$S [ 'res' ] = $forum -> lock_thread ( $args [ 2 ], 0 );
								}
							break;	
							
						case 'close':
								$S [ 'mod_action' ] = $l -> t ( 'forum_moderation_thread_lock' );
								if ( $args [ 4 ] == 2 )
								{
									$S [ 'res' ] = $forum -> lock_thread ( $args [ 2 ], 1 );
								}
							break;	
							
						case 'unpin':
								$S [ 'mod_action' ] = $l -> t ( 'forum_moderation_thread_unpin' );
								if ( $args [ 4 ] == 2 )
								{
									$S [ 'res' ] = $forum -> pin_thread ( $args [ 2 ], 0 );
								}
							break;	
							
						case 'pin':
								$S [ 'mod_action' ] = $l -> t ( 'forum_moderation_thread_pin' );
								if ( $args [ 4 ] == 2 )
								{
									$S [ 'res' ] = $forum -> pin_thread ( $args [ 2 ], 1 );
								}
							break;	
							
						case 'delete':
								$S [ 'mod_action' ] = $l -> t ( 'forum_moderation_thread_deletion' );
								if ( $args [ 4 ] == 2 )
								{
									$S [ 'res' ] = $forum -> delete_thread ( $args [ 2 ] );
								}
							break;	
					}
				}
				
				$S [ 'subheader' ] = $S [ 'mod_action' ];
			break;
		
	}

?>
