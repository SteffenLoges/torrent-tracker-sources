<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );

	
	switch ( $args [ 0 ] )
	{

		# Homepage / title / main page / index / etc
		default:
		case 'main':
		case 'default':
		case 'index':
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'start_page' ] == null
				     || !preg_match ( "#^(b|d)_([a-zA-Z0-9\-_/]+)\$#", $_SESSION [ 'preferences' ] [ 'start_page' ], $m ) )
				{
					# Default
					if ( !isset ( $_SESSION [ 'web' ] ) || $_SESSION [ 'web' ] == true )
					{
						$start_page = true;
					}
					$S [ 'tplfile' ] = 'blog';
					require_once ( DIR_VIEWS .'/blog.php' );
				}
				else 
				{
					switch ( $m [ 1 ] )
					{
						case 'b':	$args [ 0 ] = 'blog';  		break;
						case 'd':	$args [ 0 ] = 'downloads'; 	break;	
					}
					
					$tmp = explode ( '/', $m [ 2 ] );
					
					$args [ 1 ] = $tmp [ 0 ];
					if ( isset ( $tmp [ 1 ] ) ) $args [ 2 ] = $tmp [ 1 ];

					$view = $args [ 0 ];
					require_once ( DIR_VIEWS .'/'. $args [ 0 ] .'.php' );
					$S [ 'tplfile' ] = $args [ 0 ];
				}
				
				$args [ 0 ] = 'default';
				$S [ 'header' ] = $l -> t ( 'default_welcome_header' );
				$S [ 'subheader' ] = $l -> t ( 'default_welcome_subheader', PAGE_NAME );
			break;
			
			
		# Backwards compatibility
		case 'cat':
				$view = 'blog';
				$args [ 0 ] = 'blog';
				require_once ( DIR_VIEWS .'/blog.php' );
			break;	
			
			
		# Text pages (Todo: make a system for maintaining those via web interface)
		case 'tos': 
		case 'copyright':
		case 'privacy':
		case 'disclaimer':
		case 'howto_torrents':
		case 'ratio_warning':
		case 'creating_torrent':
		case 'upload_rules':
		case 'bitlet':
				$S [ 'text' ] = $args [ 0 ];
				$args [ 0 ] = 'text';
				$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
			break;
			
			
		# Force web output instead of wap
		case 'force':
				unset ( $_SESSION [ 'template' ] );
				header ( 'location: '. $url -> make ( '_' ) );
				die ();
			break;	
		
	}

?>