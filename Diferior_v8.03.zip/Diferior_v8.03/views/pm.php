<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	# Function disabled
	if ( !FUNC_PM ) throw new error ( $l -> t ( 'err_func_disabled' ) );
	
	
	$S [ 'stylesheets' ] [] = 'forum.css';

	if ( !isset ( $_SESSION [ 'logged' ] ) || !$_SESSION [ 'logged' ] )
	{
		header ( 'location: '. $url -> make ( 'user', 'login' ) );
		die ();	
	}

	$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );

	switch ( $args [ 1 ] )
	{
		default:
		case 'list':
				$args [ 1 ] = null;
				
				$S [ 'header' ] = $l -> t ( 'pm_index' );
				
				if ( isset ( $args [ 2 ] ) )
				{
					if ( preg_match ( "#^page([0-9]+)\$#", $args [ 2 ], $m ) )
					{
						$S [ 'page' ] = $m [ 1 ];
					}
					else 
					{
						$S [ 'page' ] = 1;	
					}
				}
				else 
				{
					$S [ 'page' ] = 1;	
				}
					
				$S [ 'pm' ] = $pm -> get_list ( $S [ 'page' ], $S [ 'page_count' ] );
			break;
			
			
		case 'read':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				
				$S [ 'msg' ] = $pm -> get ( $args [ 2 ] );
				$S [ 'poster' ] = $user -> get_info ( $S [ 'msg' ] [ 'from' ] );
				
				$S [ 'header' ] = htmlspecialchars ( $S [ 'msg' ] [ 'title' ] );
			break;
			
			
		case 'send':
		case 'reply':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				
				if ( $args [ 3 ] != 2 )
				{
					if ( $args [ 1 ] == 'reply' )
					{
						$args [ 1 ] = 'send';
						$S [ 'reply' ] = $pm -> get ( $args [ 2 ], false );
						if ( $S [ 'reply' ] )
						{
							$S [ 'sendto' ] = $S [ 'reply' ] [ 'from' ];
						}
						else 
						{
							$S [ 'sendto' ] = null;	
						}
					}
					else 
					{
						$S [ 'sendto' ] = $args [ 2 ];
						if ( $S [ 'sendto' ] != null && !$user -> user_exists ( $db -> escape ( $S [ 'sendto' ] ) ) )
						{
							$S [ 'sendto' ] = null;
						}
						if ( $args [ 2 ] == null )
						{
							$args [ 2 ] = $_SESSION [ 'user' ];	
						}
					}
					
					# Get smilie list
					$S [ 'smilies' ] = $text -> get_smilies ( true );
				}
				else 
				{
					# Antiflood
					$S [ 'aflood' ] = $_SESSION [ 'userinfo' ] [ 'last_pm' ] + PM_ANTIFLOOD - time ();
					if ( $S [ 'aflood' ] <= 0 )
					{
						$S [ 'succ' ] = $pm -> send ( $_POST [ 'to' ], $_POST [ 'title' ], $_POST [ 'message' ] );	
					}
				}
			break;
			
			
		case 'delete':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				
				if ( $args [ 3 ] == 2 )
				{
					$S [ 'succ' ] = $pm -> delete ( $args [ 2 ] );	
				}
			break;
			
			
		case 'delete_all':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				
				if ( $args [ 2 ] == 2 )
				{
					$S [ 'succ' ] = $pm -> delete_all ();	
				}
			break;
	}
	
?>