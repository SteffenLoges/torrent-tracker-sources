<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_DOWNLOADS || !FUNC_DOWNLOADS_TORRENT ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	if ( !isset ( $_SESSION [ 'logged' ] ) || !$_SESSION [ 'logged' ] )
	{
		$info [ 'logged' ] = false;
	}
	else 
	{
		if ( !isset ( $_SESSION [ 'userinfo' ] [ 'torrent_pass' ] ) || $_SESSION [ 'userinfo' ] [ 'torrent_pass' ] == null )
		{
			$torrent_pass = md5 ( uniqid ( null, true ) );
			$user -> update ( array ( 'torrent_pass' => $torrent_pass ) );
		}
		
		$info = array (
			'logged' => true,
			'can_leech' => $_SESSION [ 'userinfo' ] [ 'can_leech' ],
			'torrent_pass' => $_SESSION [ 'userinfo' ] [ 'torrent_pass' ],
		);	
	}

	# Jei neprisijunges, metam lauk
	if ( !$info [ 'logged' ] && !TRACKER_ANONYMOUS )
	{
		throw new error ( $l -> t ( 'err_not_logged' ) );
	}
	
	$S [ 'error' ] = false;
	
	if ( !isset ( $args [ 1 ] ) || !isset ( $args [ 2 ] ) || !isset ( $args [ 3 ] ) )
	{
		$S [ 'error' ] = true;
	}
	else 
	{
		# Remove .torrent extension from URL
		$torrent = preg_replace ( "#\.torrent\$#", null, $args [ 3 ] );
		$cat = $args [ 1 ];
		$subcat = $args [ 2 ];
		
		$path = $downloads -> get_torrent_path ( $cat, $subcat, $torrent );
		
		if ( $path === false )
		{
			$S [ 'error' ] = true;	
		}
		else 
		{
			
			$bitlet = preg_match ( "#^BitLet.*#", ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ) );
			$ret = $downloads -> output_torrent ( $path, ( TRACKER_ANONYMOUS ? null : $info [ 'torrent_pass' ] ), $bitlet, $cat, $subcat, $torrent );
			if ( $ret === false )
			{
				$S [ 'error' ] = true;	
			}
		}
	}

?>