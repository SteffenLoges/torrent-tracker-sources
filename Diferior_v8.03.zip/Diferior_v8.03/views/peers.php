<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	# Generate seeder or leecher list
	
	$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
	$fid = ( isset ( $_POST [ 'fid' ] ) ? $_POST [ 'fid' ] : null );
	
	# Get download info
	if ( preg_match ( "#^([0-9]+)\$#", $fid, $m ) )
	{
		# Get plid, lid and sublid
		$res = $downloads -> get_plid_lid_sublid ( $m [ 1 ] );
								
		# Download exists?
		if ( !empty ( $res ) )
		{
			# Get download info
			$S [ 'file' ] = $downloads -> get_dl ( $res [ 'plid' ], $res [ 'lid' ], $res [ 'sublid' ] );
									
			# Download does not exist
			if ( $S [ 'file' ] === false )
			{
				die ( $l -> t ( 'error' ) );
			}
		}
		else 
		{
			die ( $l -> t ( 'error' ) );	
		}
	}
	else 
	{
		die ( $l -> t ( 'error' ) );	
	}
	
	
	if ( $args [ 1 ] != 'seeders' && $args [ 1 ] != 'leechers' )
	{
		die ( $l -> t ( 'error' ) );
	}
	else 
	{
		$S [ 'peers' ] = $downloads -> get_peers ( $S [ 'file' ] [ 'fid' ], $args [ 1 ] );
	}
	
	# Output
	ob_start ();
	$template -> assign_all ( $S );
	$template -> display ( SMARTY_TEMPLATES_DIR .'/'. $tpl .'/peers.tpl.php' );
	die ();

?>