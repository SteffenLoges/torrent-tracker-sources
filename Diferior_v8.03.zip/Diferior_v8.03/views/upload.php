<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_DOWNLOADS ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	# Load class for logging moderation actions
	$log = & core::load_file ( 'log' );

	# User can add downloads?
	if ( !isset ( $_SESSION [ 'logged' ] ) || $_SESSION [ 'logged' ] !== true )
	{
		$S [ 'err' ] = true;	
	}
	else 
	{
		$S [ 'err' ] = false;	
	}

	if ( !$S [ 'err' ] )
	{
		$S [ 'stylesheets' ] [] = 'post.css';
		$S [ 'stylesheets' ] [] = 'upload.css';
		$S [ 'javascripts' ] [] = 'post.js';
		$S [ 'javascripts' ] [] = 'upload.js';
	
		$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
		$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
	
		switch ( $args [ 1 ] )
		{
			default:
					$args [ 1 ] = null;
				break;
				
			case 'new':
			case 'edit':
					if ( ( $args [ 2 ] != 2 || ( !isset ( $args [ 3 ] ) && $args [ 1 ] == 'edit' ) ) && $args [ 2 ] != 'preview' )
					{
						# Get subcategories
						$S [ 'dl_cats' ] = $downloads -> get_cats ( true );
						
						$args [ 3 ] = null;
						
						# Prepare dummy post (for preview template initialization)
						$S [ 'dummy_post' ] = array ( 0 => array (
							'b' => 'd', 'name' => null, 'lid' => null, 'sub_name' => null, 'sub_lid' => null, 'plid' => null, 
							'posted' => time(), 'updated' => 0,
							'header' => null, 'subheader' => null, 'author' => $_SESSION [ 'user' ], 'content' => null, 'comments' => 0, 
							'parse_html' => 0, 'id' => 0, 'info_hash' => null, 'anonymous' => 0
						) );
						
						if ( $args [ 1 ] == 'edit' )
						{
							if ( preg_match ( "#^([0-9]+)\$#", $args [ 2 ], $m ) )
							{
								# Get download id
								$S [ 'dl_id' ] = $m [ 1 ];
								
								# Get plid, lid and sublid
								$res = $downloads -> get_plid_lid_sublid ( $m [ 1 ] );
								
								# Download exists?
								if ( !empty ( $res ) )
								{
									# Get download info
									$S [ 'dl' ] = $downloads -> get_dl ( $res [ 'plid' ], $res [ 'lid' ], $res [ 'sublid' ] );
									
									# Download does not exist
									if ( $S [ 'dl' ] === false )
									{
										$S [ 'err' ] = true;
									}
									# Unconfirmed
									elseif ( $S [ 'dl' ] [ 'confirmed' ] != 1 && $_SESSION [ 'permissions' ] [ 'approve_downloads' ] != 1 && $S [ 'dl' ] [ 'user' ] != $_SESSION [ 'user' ] )
									{
										$S [ 'err' ] = true;
									}
									# Wrong user or insufficient permissions
									elseif ( $S [ 'dl' ] [ 'user' ] != $_SESSION [ 'user' ] && $_SESSION [ 'permissions' ] [ 'edit_downloads' ] != 1 && $S [ 'dl' ] [ 'confirmed' ] == 1 )
									{
										$S [ 'err' ] = true;
									}
									
									if ( $S [ 'err' ] !== true )
									{
										# Parse tags
										if ( FUNC_TAGS )
										{
											$blog -> split_tags ( $S [ 'dl' ], true );
											$S [ 'dl' ] [ 'tags' ] = implode ( ',', $S [ 'dl' ] [ 'tags' ] );
										}
										
										# Update preview post info
										$S [ 'dummy_post' ] [ 0 ] = $S [ 'dl' ];
										$S [ 'dummy_post' ] [ 0 ] [ 'b' ] = 'd';
										$S [ 'dummy_post' ] [ 0 ] [ 'author' ] = $S [ 'dl' ] [ 'user' ];
										$S [ 'dummy_post' ] [ 0 ] [ 'id' ] = $S [ 'dl' ] [ 'fid' ];
										$S [ 'dummy_post' ] [ 0 ] [ 'updated' ] = time ();
										$S [ 'dummy_post' ] [ 0 ] [ 'parse_html' ] = 0;
									}
								}
								else 
								{
									$S [ 'err' ] = true;	
								}
							}
							else 
							{
								$S [ 'err' ] = true;
							}
						}
					}
					elseif ( $args [ 2 ] == 'preview' )
					{
						$content = ( isset ( $_POST [ 'content' ] ) ? $_POST [ 'content' ] : null );
						$cat = ( isset ( $_POST [ 'cat' ] ) ? $_POST [ 'cat' ] : null );
						$post = ( isset ( $_POST [ 'post' ] ) ? $_POST [ 'post' ] : null );
						
						if ( $post == null )
						{
							$post = 'test';
						}
						else
						{
							$post = $text -> make_lid ( $text -> decode_unicode_url ( $post ) );
						}
						
						$content = $text -> convert ( $text -> decode_unicode_url ( $content ) );
						
						//if ( get_magic_quotes_gpc() )
						//{
						//	$content = stripslashes ( $content );
						//	$post = stripslashes ( $post );	
						//}
						
						$content = str_replace ( "\n", "\r\n", $content );
						$content = str_replace ( "\r\r", "\r", $content );
						
						echo $text -> do_parse_post ( $content, $cat, $post, false, true );
						die ();
					}
					else 
					{
						$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
						
						if ( $args [ 1 ] == 'edit' )
						{
							# Editing
							if ( preg_match ( "#^([0-9]+)\$#", $args [ 3 ], $m ) )
							{
								# Get download submitter's username
								$res = $downloads -> get_plid_lid_sublid ( $m [ 1 ], ',dl_downloads.user, dl_categories.id, dl_subcategories.id as subid, dl_downloads.confirmed' );
								$author = & $res [ 'user' ];
								$plid = & $res [ 'plid' ];
								$lid = & $res [ 'lid' ];
								$lid_id = & $res [ 'id' ];
								$sublid = & $res [ 'sublid' ];
								$sublid_id = & $res [ 'subid' ];
								
								# Download does not exist
								if ( $res === false )
								{
									$S [ 'err' ] = true;
								}
								# Unconfirmed
								elseif ( $res [ 'confirmed' ] != 1 && $_SESSION [ 'permissions' ] [ 'approve_downloads' ] != 1 && $author != $_SESSION [ 'user' ] )
								{
									$S [ 'err' ] = true;
								}
								# Wrong user or insufficient permissions
								elseif ( $author != $_SESSION [ 'user' ] && $_SESSION [ 'permissions' ] [ 'edit_downloads' ] != 1 && $res [ 'confirmed' ] == 1 )
								{
									$S [ 'err' ] = true;
								}
								
								if ( !$S [ 'err' ] )
								{
									$S [ 'res' ] = $downloads -> edit_download ( $m [ 1 ], $_POST [ 'category' ], $_POST [ 'header' ], $_POST [ 'subheader' ], 
										$_POST [ 'post_content' ], ( isset ( $_POST [ 'links' ] ) ? $_POST [ 'links' ] : null ), $plid, $lid, $lid_id, $sublid, $sublid_id, ( isset ( $_POST [ 'anonymous' ] ) ? true : false ),
										( FUNC_TAGS ? $_POST [ 'tags' ] : null ), $returninfo );
										
									if ( $S [ 'res' ] == true ) 
									{
										$log -> write ( null, ( $returninfo [ 'confirm' ] ? 'approve' : 'edit' ), implode ( '/', array ( 'file', $returninfo [ 'lid' ], $returninfo [ 'sublid' ], $returninfo [ 'plid' ] ) ), $returninfo [ 'header' ] );
									}
								}
								else 
								{
									$S [ 'res' ] = false;	
								}
							}
							else 
							{
								$S [ 'res' ] = false;	
							}
						}
						else 
						{	
							# New download
							$S [ 'res' ] = $downloads -> new_download ( $_POST [ 'category' ], $_POST [ 'header' ], $_POST [ 'subheader' ], 
																		$_POST [ 'post_content' ], ( isset ( $_POST [ 'links' ] ) ? $_POST [ 'links' ] : null ), ( isset ( $_POST [ 'anonymous' ] ) ? true : false ),
																		( $_SESSION [ 'permissions' ] [ 'add_downloads' ] == 1 ? true : false ), ( FUNC_TAGS ? $_POST [ 'tags' ] : null ) );
						}
					}
				break;
				
				
			case 'list':
					$S [ 'downloads' ] = $downloads -> get_user_downloads ();
				break;
				
				
			case 'delete':
					$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
					
					if ( $args [ 3 ] == 2 )
					{
						$S [ 'res' ] = $downloads -> delete_download ( $args [ 2 ], $returninfo );
						if ( $S [ 'res' ] == true ) 
						{
							$log -> write ( null, 'delete', implode ( '/', array ( 'file', $returninfo [ 'lid' ], $returninfo [ 'sublid' ], $returninfo [ 'plid' ] ) ), $returninfo [ 'header' ] );
						}
					}
				break;
				
				
			case 'pending':
					if ( $_SESSION [ 'permissions' ] [ 'approve_downloads' ] == 1 )
					{
						$S [ 'downloads' ] = $downloads -> get_pending_downloads ( 0, ', dl.user' );
					}
					else 
					{
						$S [ 'err' ] = true;	
					}
				break;
				
				
			case 'cheaters':
					if ( $_SESSION [ 'permissions' ] [ 'cheater_list' ] == 1 )
					{
						$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
						
						if ( $args [ 2 ] != 'del' )
						{
							$S [ 'downloads' ] = $downloads -> get_cheater_list ();
						}
						else 
						{
							$S [ 'res' ] = $downloads -> delete_cheater_entries ();
						}
					}
					else 
					{
						$S [ 'err' ] = true;	
					}
				break;	
				
				
			case 'log':
					if ( $_SESSION [ 'permissions' ] [ 'view_log' ] == 1 )
					{
						# Paging
						$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
						if ( preg_match ( "#^page([0-9]+)\$#", $args [ 2 ], $m ) )
						{
							$S [ 'page' ] = $m [ 1 ];
						}
						else 
						{
							$S [ 'page' ] = 1;	
						}
	
						$S [ 'log' ] = $log -> get ( $S [ 'page' ] );
					}
					else 
					{
						$S [ 'err' ] = true;	
					}
				break;	
		}
	}

?>