<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_DOWNLOADS ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	$S [ 'stylesheets' ] [] = 'downloads.css';
	$S [ 'javascripts' ] [] = 'downloads.js';
	$S [ 'error' ] = false;
	
	if ( $S [ 'error' ] !== false || !isset ( $args [ 1 ] ) || !isset ( $args [ 2 ] ) || !isset ( $args [ 3 ] ) )
	{
		if ( $S [ 'error' ] === false )
		{
			$S [ 'error' ] = true;
		}
	}
	else 
	{
		# Remove .html extension from URL
		//$dl = preg_replace ( "#\.html\$#", null, $args [ 3 ] );
		$cat = $args [ 1 ];
		$subcat = $args [ 2 ];
		$dl = $args [ 3 ];
		
		# Get download info, perform scrape if needed
		$S [ 'file' ] = $downloads -> get_dl ( $dl, $cat, $subcat, true );
		
		if ( $S [ 'file' ] === false )
		{
			$S [ 'error' ] = true;	
		}
		else 
		{
			$S [ 'header' ] = $text -> replace_quotes ( htmlspecialchars ( $S [ 'file' ] [ 'header' ] ) );
			$S [ 'subheader' ] = $text -> replace_quotes ( htmlspecialchars ( $S [ 'file' ] [ 'subheader' ] ) );
			if ( FUNC_TAGS )
			{
				$blog -> split_tags ( $S [ 'file' ], true );
			}
			
			# Check user torrent_pass and update it if needed
			if ( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] && 
				( !isset ( $_SESSION [ 'userinfo' ] [ 'torrent_pass' ] ) || $_SESSION [ 'userinfo' ] [ 'torrent_pass' ] == null ) )
			{
				$torrent_pass = md5 ( uniqid ( null, true ) );
				$user -> update ( array ( 'torrent_pass' => $torrent_pass ) );
			}
			
			# Number of file views
			$S [ 'filecounter' ] = $counters -> simple ( 'download_'. $S [ 'file' ] [ 'fid' ] );
			
			# Get peer list
			$S [ 'peers_no' ] = $S [ 'file' ] [ 'seeders' ] + $S [ 'file' ] [ 'leechers' ];
			if ( $S [ 'file' ] [ 'info_hash' ] != null && !TRACKER_ANONYMOUS && $S [ 'peers_no' ] <= TRACKER_PEER_PRE )
			{
				$S [ 'peers' ] = $downloads -> get_peers ( $S [ 'file' ] [ 'fid' ] );
			}
			
			# Prepare HTTP links
			$S [ 'dl_links_count' ] = 0;
			if ( $S [ 'file' ] [ 'dl_links' ] != null )
			{
				$links = explode ( "\n", $S [ 'file' ] [ 'dl_links' ] );
				$S [ 'file' ] [ 'dl_links' ] = array ();	
				foreach ( $links as $k => $v )
				{
					if ( preg_match ( "#^(.*)\|([0-9]+)\s*\$#", $links [ $k ], $m ) )
					{
						$S [ 'file' ] [ 'dl_links' ] [ $k ] = array ( $m [ 1 ], $m [ 2 ] );	
					}
					else 
					{
						$S [ 'file' ] [ 'dl_links' ] [ $k ] = array ( trim ( $links [ $k ] ), 0 );
					}
					
					# Link
					if ( !preg_match ( "#^\-\-+\$#", $S [ 'file' ] [ 'dl_links' ] [ $k ] [ 0 ] ) ) 
					{
						$S [ 'dl_links_count' ] += 1;
					}
				}
			}
			
			# Prepare filelist
			if ( $S [ 'file' ] [ 'files' ] != null )
			{
				$files = explode ( "\n", $S [ 'file' ] [ 'files' ] );
				$S [ 'file' ] [ 'files' ] = array ();	
				foreach ( $files as $k => $v )
				{
					if ( preg_match ( "#^(.*)\|([0-9]+)\s*\$#", $files [ $k ], $m ) )
					{
						$S [ 'file' ] [ 'files' ] [ $k ] = array ( $m [ 1 ], $m [ 2 ] );	
					}
				}
			}

			
			# Comments page
			if ( isset ( $args [ 4 ] ) )
			{
				if ( preg_match ( "#^page([0-9]+)\$#", $args [ 4 ], $m ) )
				{
					$S [ 'page' ] = $m [ 1 ];
				}
				elseif ( preg_match ( "#^c([0-9]+)\$#", $args [ 4 ], $m ) )
				{
					$comment_no = $m [ 1 ];	
				}
				else 
				{
					$S [ 'page' ] = 1;	
				}
			}
			else 
			{
				$S [ 'page' ] = 1;	
			}
			
			# Get comments
			if ( isset ( $comment_no ) )
			{
				if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'comments_no' ] == 0 )
				{
					$page_count = COMMENTS_PAGE;	
				}
				else 
				{
					$page_count = $_SESSION [ 'preferences' ] [ 'comments_no' ];
				}
				
				$S [ 'page' ] = ceil ( $comment_no / $page_count );
				$S [ 'pages' ] = ceil ( $S [ 'file' ] [ 'comments' ] / $page_count );
				
				if ( isset ( $comment_no ) && isset ( $_SESSION [ 'preferences' ] ) && $_SESSION [ 'preferences' ] [ 'comments_dir' ] != 0 )
				{
					$S [ 'page' ] = ceil ( ($S [ 'file' ] [ 'comments' ] - $comment_no +1) / $page_count );
				}
			}
			$S [ 'comments' ] = $comments -> get ( $S [ 'file' ] [ 'fid' ], $S [ 'page' ], $S [ 'page_count' ], 'dl_comments' );
			if ( !isset ( $S [ 'pages' ] ) )
			{
				$S [ 'pages' ] = ceil ( $S [ 'file' ] [ 'comments' ] / $S [ 'page_count' ] );	
			}
				
			# Get smilie list
			$S [ 'smilies' ] = $text -> get_smilies ( true );
			
			# Generate captcha (for anonymous commenting)
			$_SESSION [ 'captcha' ] = $text -> pronounceable ();
		}
		
	}

?>