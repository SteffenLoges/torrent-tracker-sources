<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_BLOG ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	$S [ 'error' ] = false;
	
	if ( !isset ( $args [ 1 ] ) || !isset ( $args [ 2 ] ) )
	{
		$S [ 'error' ] = true;
	}
	else 
	{
		$post = & $args [ 2 ];
		$cat = $args [ 1 ];
		
		# Get post
		$S [ 'post' ] = $blog -> get_post ( $post, $cat );
		
		if ( $S [ 'post' ] === false )
		{
			$S [ 'error' ] = true;	
		}
		else 
		{
			$S [ 'header' ] = $text -> replace_quotes ( htmlspecialchars ( $S [ 'post' ] [ 'header' ] ) );
			$S [ 'subheader' ] = $text -> replace_quotes ( htmlspecialchars ( $S [ 'post' ] [ 'subheader' ] ) );
			if ( FUNC_TAGS )
			{
				$blog -> split_tags ( $S [ 'post' ], true );
			}
		}
		
		
		# Comments page
		if ( isset ( $args [ 3 ] ) )
		{
			if ( preg_match ( "#^page([0-9]+)\$#", $args [ 3 ], $m ) )
			{
				$S [ 'page' ] = $m [ 1 ];
			}
			elseif ( preg_match ( "#^c([0-9]+)\$#", $args [ 3 ], $m ) )
			{
				$comment_no = $m [ 1 ];	
			}
			else 
			{
				$S [ 'page' ] = 1;	
			}
		}
		else 
		{
			$S [ 'page' ] = 1;	
		}
		
		# Get comments
		if ( isset ( $comment_no ) )
		{
			if ( !isset ( $_SESSION [ 'preferences' ] ) || $_SESSION [ 'preferences' ] [ 'comments_no' ] == 0 )
			{
				$page_count = COMMENTS_PAGE;	
			}
			else 
			{
				$page_count = $_SESSION [ 'preferences' ] [ 'comments_no' ];
			}
			
			$S [ 'page' ] = ceil ( $comment_no / $page_count );
			$S [ 'pages' ] = ceil ( $S [ 'post' ] [ 'comments' ] / $page_count );
			
			if ( isset ( $comment_no ) && isset ( $_SESSION [ 'preferences' ] ) && $_SESSION [ 'preferences' ] [ 'comments_dir' ] != 0 )
			{
				$S [ 'page' ] = ceil ( ($S [ 'post' ] [ 'comments' ] - $comment_no +1) / $page_count );
			}
		}
		$S [ 'comments' ] = $comments -> get ( $S [ 'post' ] [ 'id' ], $S [ 'page' ], $S [ 'page_count' ] );
		if ( !isset ( $S [ 'pages' ] ) )
		{
			$S [ 'pages' ] = ceil ( $S [ 'post' ] [ 'comments' ] / $S [ 'page_count' ] );	
		}
		
		
		# Get smilie list
		$S [ 'smilies' ] = $text -> get_smilies ( true );
	}

?>