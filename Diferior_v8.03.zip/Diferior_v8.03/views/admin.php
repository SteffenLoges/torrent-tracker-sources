<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	$config = & core::load_file ( 'config' );
	
	$S [ 'stylesheets' ] [] = 'admin.css';
	$S [ 'javascripts' ] [] = 'admin.js';
	$S [ 'header' ] = $l -> t ( 'admin_header' );
	
	$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
	$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
	$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
	
	# User is admin?
	if ( !isset ( $_SESSION [ 'logged' ] ) || $_SESSION [ 'logged' ] !== true || $_SESSION [ 'permissions' ] [ 'admin' ] != 1 )
	{
		$S [ 'err' ] = true;	
	}
	else 
	{
		$S [ 'err' ] = false;	
	}

	if ( $S [ 'err' ] == false )
	{
		switch ( $args [ 1 ] )
		{
			
			default:
					$args [ 1 ] = null;
				break;
				
				
			case 'site':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_site' );
					
					# Get PHP supported timezones
					$S [ 'timezones' ] = timezone_identifiers_list ();
					
					if ( $args [ 2 ] == 2 )
					{
						if ( $_POST [ 'title' ] != null && in_array ( $_POST [ 'timezone' ], $S [ 'timezones' ] ) &&
							 ( $_POST [ 'cron' ] == 'php' || $_POST [ 'cron' ] == 'system' ) )
						{
							$config -> load_file ();
		
							$options = array (
								'PAGE_NAME'	=>	$_POST [ 'title' ],
								'PAGE_SLOGAN'	=>	$_POST [ 'slogan' ],
								'DEFAULT_TIMEZONE'	=>	$_POST [ 'timezone' ],
								'SIMULATE_CRON'	=>	( $_POST [ 'cron' ] == 'php' ? true : false ),
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}
					}
				break;
				
				
			case 'blog':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_blog' );
					
					switch ( $args [ 2 ] )
					{
						default:
								# Retrieve blog categories
								if ( !isset ( $S [ 'cats' ] ) )
								{
									$S [ 'cats' ] = $blog -> get_cats ();
								}
								$args [ 2 ] = null;
							break;
							
							
						case '2':
								if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 )
									&& is_numeric ( $_POST [ 'blog_no' ] ) 
									&& ( $_POST [ 'watermark' ] == 0 || $_POST [ 'watermark' ] == 1 )
									&& is_numeric ( $_POST [ 'watermark_width' ] ) && is_numeric ( $_POST [ 'watermark_height' ] ) )
								{
									$config -> load_file ();
				
									$options = array (
										'FUNC_BLOG'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
										'BLOG_POSTS'	=>	$_POST [ 'blog_no' ],
										'BLOG_WATERMARK'	=>	( $_POST [ 'watermark' ] == 1 ? true : false ),
										'WATERMARK_MINWIDTH'	=>	$_POST [ 'watermark_width' ],
										'WATERMARK_MINHEIGHT'	=>	$_POST [ 'watermark_height' ],
									);
				
									$S [ 'succ' ] = $config -> update_array ( $options );
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;	
							
							
						case 'edit':
								$cats = array ();
								$del = array ();
								
								foreach ( $_POST as $k => $v )
								{
									if ( preg_match ( "#^(catname|position|del)_([0-9]+)\$#", $k, $m ) )
									{
										switch ( $m [ 1 ] )
										{
											case 'catname':
													$cats [ $m [ 2 ] ] [ 'name' ] = $v;
												break;
												
											case 'position':
													if ( preg_match ( "#^position_([0-9]+)\$#", $v, $pos ) )
													{
														$cats [ $m [ 2 ] ] [ 'pos' ] = $pos [ 1 ]; 
													}
												break;
												
											case 'del':
													$del [] = $m [ 2 ];
												break;	
										}
									}
								}
								
								if ( !empty ( $del ) && $args [ 3 ] != '2' )
								{
									# Ask user for confirmation	
									$S [ 'confirmed' ] = false;
								}
								else 
								{
									# Proceed
									$S [ 'confirmed' ] = true;
								
									foreach ( $del as $v )
									{
										unset ( $cats [ $v ] );
									}
									
									if ( !empty ( $del ) )
									{
										$blog -> del_cats ( $del );
									}
									
									$blog -> update_cats ( $cats );
									
									$S [ 'succ' ] = true;
								}
							break;
							
							
						case 'create':
								if ( trim ( $_POST [ 'catname' ] ) != null )
								{
									$blog -> create_cat ( $_POST [ 'catname' ] );
									$S [ 'succ' ] = true;
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
					}
				break;	
				
				
			case 'downloads':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_downloads' );
					
					switch ( $args [ 2 ] )
					{
						default:
								# Retrieve downloads categories
								$S [ 'dl_cats' ] = $downloads -> get_cats ( true );
								$args [ 2 ] = null;
							break;
							
							
						case '2':
								$_POST [ 'ratio' ] = str_replace ( ',', '.', $_POST [ 'ratio' ] );
								
								$_POST [ 'enable_anonymous' ] = ( isset ( $_POST [ 'enable_anonymous' ] ) ? $_POST [ 'enable_anonymous' ] : 1 );
								$_POST [ 'announce' ] = ( isset ( $_POST [ 'announce' ] ) ? $_POST [ 'announce' ] : null );
								$_POST [ 'scrape' ] = ( isset ( $_POST [ 'scrape' ] ) ? $_POST [ 'scrape' ] : null );
								
								if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 )
								     && ( $_POST [ 'enable_http' ] == 0 || $_POST [ 'enable_http' ] == 1 )
								     && ( $_POST [ 'enable_torrent' ] == 0 || $_POST [ 'enable_torrent' ] == 1  || $_POST [ 'enable_torrent' ] == 2  || $_POST [ 'enable_torrent' ] == 3 )
								     && ( $_POST [ 'enable_anonymous' ] == 0 || $_POST [ 'enable_anonymous' ] == 1 )
								     && ( $_POST [ 'enable_title' ] == 0 || $_POST [ 'enable_title' ] == 1 )
								     && ( $_POST [ 'enable_nfo' ] == 0 || $_POST [ 'enable_nfo' ] == 1 )
								     && is_numeric ( $_POST [ 'downloads_no' ] )
								     && is_numeric ( $_POST [ 'ratio' ] )
								     && is_numeric ( $_POST [ 'immune' ] )
								     && is_numeric ( $_POST [ 'bitlet' ] ) )
								{
									$config -> load_file ();
				
									$options = array (
										'FUNC_DOWNLOADS'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
										'FUNC_DOWNLOADS_HTTP'	=>	( $_POST [ 'enable_http' ] == 1 ? true : false ),
										'FUNC_DOWNLOADS_TORRENT'	=>	( $_POST [ 'enable_torrent' ] != 0 ? true : false ),
										'TRACKER_URL'	=>	( $_POST [ 'announce' ] != null ? $_POST [ 'announce' ] : TRACKER_URL ),
										'SCRAPE_URL'	=>	( $_POST [ 'scrape' ] != null ? $_POST [ 'scrape' ] : SCRAPE_URL ),
										'TRACKER_ANONYMOUS'	=>	( $_POST [ 'enable_anonymous' ] == 1 ? true : false ),
										'TITLE_DOWNLOADS'	=>	( $_POST [ 'enable_title' ] == 1 ? true : false ),
										'PERFORM_SCRAPE'	=>	( trim ( $_POST [ 'scrape' ] ) != null && $_POST [ 'enable_torrent' ] == 3 ? true : false ),
										'VIEW_NFO'	=>	( $_POST [ 'enable_nfo' ] == 1 ? true : false ),
										'DL_POSTS'	=>	$_POST [ 'downloads_no' ],
										'RATIO_WARNING'	=>	$_POST [ 'ratio' ],
										'AUTOWARN_IMMUNE_TIME'	=>	$_POST [ 'immune' ] * 3600,
										'BITLET_FSIZE'	=>	ceil ( $_POST [ 'bitlet' ] * 1048576 ),
										'TRACKER_TYPE'	=>	( $_POST [ 'enable_torrent' ] == 1 ? 'PHP' : ( $_POST [ 'enable_torrent' ] == 2 ? 'XBTT' : 'Other' ) ),
									);
									
									
									$S [ 'succ' ] = $config -> update_array ( $options );
									
									$anon = ( $_POST [ 'enable_anonymous' ] == 1 ? 1 : 0 );
									$db -> update ( 'UPDATE xbt_config SET value='. $anon ." WHERE name='anonymous_scrape' OR name='anonymous_announce' OR name='anonymous_connect'" );
									$db -> update ( 'UPDATE xbt_config SET value='. ( $anon ? 0 : 1 ) ." WHERE name='cheater'" );
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
							
							
						case 'edit':
								$cats = array ();
								$subcats = array ();
								$del = array ();
								$subdel = array ();
								
								foreach ( $_POST as $k => $v )
								{
									if ( preg_match ( "#^(catname|position|del|subcatname|subposition|subdel)_([0-9]+)\$#", $k, $m ) )
									{
										switch ( $m [ 1 ] )
										{
											case 'catname':
													$cats [ $m [ 2 ] ] [ 'name' ] = $v;
												break;
											case 'subcatname':
													$subcats [ $m [ 2 ] ] [ 'name' ] = $v;
												break;
												
											case 'position':
													if ( preg_match ( "#^position_([0-9]+)\$#", $v, $pos ) )
													{
														$cats [ $m [ 2 ] ] [ 'pos' ] = $pos [ 1 ]; 
													}
												break;
											case 'subposition':
													if ( preg_match ( "#^subposition_([0-9]+)\$#", $v, $pos ) )
													{
														$subcats [ $m [ 2 ] ] [ 'pos' ] = $pos [ 1 ]; 
													}
												break;
												
											case 'del':
													$del [] = $m [ 2 ];
												break;	
											case 'subdel':
													$subdel [] = $m [ 2 ];
												break;	
										}
									}
								}
								
								if ( ( !empty ( $del ) || !empty ( $subdel ) ) && $args [ 3 ] != '2' )
								{
									# Ask user for confirmation	
									$S [ 'confirmed' ] = false;
								}
								else 
								{
									# Proceed
									$S [ 'confirmed' ] = true;
								
									foreach ( $del as $v )
									{
										unset ( $cats [ $v ] );
									}
									foreach ( $subdel as $v )
									{
										unset ( $subcats [ $v ] );
									}
									
									
									if ( !empty ( $del ) )
									{
										$downloads -> del_cats ( $del );
									}
									if ( !empty ( $subdel ) )
									{
										$downloads -> del_subcats ( $subdel );	
									}
									
									
									$downloads -> update_cats ( $cats );
									$downloads -> update_subcats ( $subcats );
									
									$S [ 'succ' ] = true;
								}
							break;
							
							
						case 'create':
								if ( trim ( $_POST [ 'catname' ] ) != null )
								{
									$downloads -> create_cat ( $_POST [ 'catname' ] );
									$S [ 'succ' ] = true;
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
							
							
						case 'create_sub':
								if ( is_numeric ( $_POST [ 'cat' ] ) && trim ( $_POST [ 'subcatname' ] ) != null )
								{
									$downloads -> create_subcat ( $_POST [ 'cat' ], $_POST [ 'subcatname' ] );
									$S [ 'succ' ] = true;
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
					}
				break;	
				
				
			case 'forum':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_forum' );
					
					switch ( $args [ 2 ] )
					{
						default:
								# Get forum categories and boards
								$S [ 'boards' ] = $forum -> get_boards ( true, false );
								$args [ 2 ] = null;
							break;
							
							
						case '2':
								if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 )
									&& is_numeric ( $_POST [ 'threads_no' ] )
									&& is_numeric ( $_POST [ 'posts_no' ] )
									&& is_numeric ( $_POST [ 'thread_af' ] )
									&& is_numeric ( $_POST [ 'post_af' ] ) )
								{
									$config -> load_file ();
				
									$options = array (
										'FUNC_FORUMS'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
										'FORUM_THREADS_PAGE'	=>	$_POST [ 'threads_no' ],
										'FORUM_POSTS_PAGE'	=>	$_POST [ 'posts_no' ],
										'FORUM_THREAD_ANTIFLOOD'	=>	$_POST [ 'thread_af' ],
										'FORUM_POSTS_ANTIFLOOD'	=>	$_POST [ 'post_af' ],
									);
				
									$S [ 'succ' ] = $config -> update_array ( $options );
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;	
							
							
						case 'edit':
								$cats = array ();
								$subcats = array ();
								$del = array ();
								$subdel = array ();
								
								foreach ( $_POST as $k => $v )
								{
									if ( preg_match ( "#^(catname|position|del|subcatname|subcatdescr|subposition|subdel)_([0-9]+)\$#", $k, $m ) )
									{
										switch ( $m [ 1 ] )
										{
											case 'catname':
													$cats [ $m [ 2 ] ] [ 'name' ] = $v;
												break;
											case 'subcatname':
													$subcats [ $m [ 2 ] ] [ 'name' ] = $v;
												break;
											case 'subcatdescr':
													$subcats [ $m [ 2 ] ] [ 'descr' ] = $v;
												break;
												
											case 'position':
													if ( preg_match ( "#^position_([0-9]+)\$#", $v, $pos ) )
													{
														$cats [ $m [ 2 ] ] [ 'pos' ] = $pos [ 1 ]; 
													}
												break;
											case 'subposition':
													if ( preg_match ( "#^subposition_([0-9]+)\$#", $v, $pos ) )
													{
														$subcats [ $m [ 2 ] ] [ 'pos' ] = $pos [ 1 ]; 
													}
												break;
												
											case 'del':
													$del [] = $m [ 2 ];
												break;	
											case 'subdel':
													$subdel [] = $m [ 2 ];
												break;	
										}
									}
								}
								
								if ( ( !empty ( $del ) || !empty ( $subdel ) ) && $args [ 3 ] != '2' )
								{
									# Ask user for confirmation	
									$S [ 'confirmed' ] = false;
								}
								else 
								{
									# Proceed
									$S [ 'confirmed' ] = true;
								
									foreach ( $del as $v )
									{
										unset ( $cats [ $v ] );
									}
									foreach ( $subdel as $v )
									{
										unset ( $subcats [ $v ] );
									}
									
									
									if ( !empty ( $del ) )
									{
										$forum -> del_cats ( $del );
									}
									if ( !empty ( $subdel ) )
									{
										$forum -> del_boards ( $subdel );	
									}
									
									
									$forum -> update_cats ( $cats );
									$forum -> update_boards ( $subcats );
									
									$S [ 'succ' ] = true;
								}
							break;
							
							
						case 'create':
								if ( trim ( $_POST [ 'catname' ] ) != null )
								{
									$forum -> create_cat ( $_POST [ 'catname' ] );
									$S [ 'succ' ] = true;
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
							
							
						case 'create_sub':
								if ( is_numeric ( $_POST [ 'cat' ] ) && trim ( $_POST [ 'subcatname' ] ) != null )
								{
									$forum -> create_board ( $_POST [ 'cat' ], $_POST [ 'subcatname' ], $_POST [ 'description' ] );
									$S [ 'succ' ] = true;
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
					}
				break;	
				
				
			case 'pm':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_pm' );
					
					if ( $args [ 2 ] == 2 )
					{
						if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 )
								&& is_numeric ( $_POST [ 'no' ] )
								&& is_numeric ( $_POST [ 'aflood' ] )
								&& is_numeric ( $_POST [ 'limit' ] ) && $_POST [ 'limit' ] > 0 )
						{
							$config -> load_file ();

							$options = array (
								'FUNC_PM'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
								'PM_PAGE'	=>	$_POST [ 'no' ],
								'PM_ANTIFLOOD'	=>	$_POST [ 'aflood' ],
								'PM_LIMIT'	=>	$_POST [ 'limit' ],
							);

							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}
					}
				break;	
				
				
			case 'contact':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_contact' );
					
					if ( $args [ 2 ] == 2 )
					{
						if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 )
						&& $text -> validate ( $_POST [ 'email' ], 'email' ) )
						{
							$config -> load_file ();
		
							$options = array (
								'FUNC_CONTACT'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
								'MAIL_FROM'	=>	$_POST [ 'email' ],
								'ADMIN_EMAIL'	=>	$_POST [ 'email' ],
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}
					}
				break;		
				
				
			case 'rss':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_rss' );
					
					if ( $args [ 2 ] == 2 )
					{
						if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 ) )
						{
							$config -> load_file ();
		
							$options = array (
								'FUNC_RSS'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}
					}
				break;	
				
				
			case 'counters':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_counters' );
					
					if ( $args [ 2 ] == 2 )
					{
						if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 ) )
						{
							$config -> load_file ();
		
							$options = array (
								'FUNC_COUNTERS'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}
					}
				break;	
				
				
			case 'users':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_users' );

					# Get user permissions
					$S [ 'permissions' ] = $user -> get_permissions ();
											
					switch ( $args [ 2 ] )
					{
						default:
								$args [ 2 ] = null;
							break;
							
							
						case '2':
								$_POST [ 'avatar_fsize' ] = str_replace ( ',', '.', $_POST [ 'avatar_fsize' ] );
								
								if ( ( $_POST [ 'enable' ] == 0 || $_POST [ 'enable' ] == 1 )
									 && is_numeric ( $_POST [ 'avatar_width' ] )
									 && is_numeric ( $_POST [ 'avatar_height' ] )
									 && is_numeric ( $_POST [ 'avatar_fsize' ] ) )
								{
									$config -> load_file ();
				
									$options = array (
										'FUNC_USER_VALIDATION'	=>	( $_POST [ 'enable' ] == 1 ? true : false ),
										'AVATAR_MAXWIDTH'	=>	$_POST [ 'avatar_width' ],
										'AVATAR_MAXHEIGHT'	=>	$_POST [ 'avatar_height' ],
										'AVATAR_MAXSIZE'	=>	floor ( $_POST [ 'avatar_fsize' ] * 1024 ),
									);
		
									$S [ 'succ' ] = $config -> update_array ( $options );
								}
								else 
								{
									$S [ 'succ' ] = false;	
								}
							break;
							
							
						case 'edit':
						case 'add':
								$username = ( isset ( $_POST [ 'user' ] ) ? $_POST [ 'user' ] : $args [ 3 ] );
								if ( trim ( $username ) != null )
								{
									$username = $db -> escape ( $username );
									
									# Check if user exists
									if ( $user -> get_info ( $username ) != false )
									{
										$val_arr = array ();
										$pass = false;
										foreach ( $S [ 'permissions' ] [ 0 ] as $k => $v )
										{
											if ( $k != 'user' )
											{
												# Do not allow to remove admincp access for current user
												if ( $k == 'admin' && strtolower ( $username ) == strtolower ( $_SESSION [ 'user' ] ) )
												{
													$_POST [ 'admin' ] = 1;
												}
												
												$val_arr [] = $k. "='". ( $_POST [ $k ] == 1 ? 1 : 0 ) ."'";
												if ( !$pass && $_POST [ $k ] == 1 )
												{
													# At least one positive value, insert/update
													$pass = true;
												}
											}
										}
										
										if ( !$pass )
										{
											# No positive values, do not insert, remove existing entry
											$db -> delete ( "DELETE FROM users_permissions WHERE user='". $username ."'" );
										}
										else 
										{
											# Insert or update
											$values = implode ( ', ', $val_arr );
											$db -> query ( "INSERT INTO users_permissions SET user='". $username ."', ". $values ."
															ON DUPLICATE KEY UPDATE ". $values );
										}
										
										$S [ 'succ' ] = true;
									}
									else 
									{
										$S [ 'succ' ] = false;	
									}
								}
								else 
								{
									$S [ 'succ' ] = false;
								}
							break;
					}
				break;	
				
				
			case 'caching':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_caching' );
					
					if ( $args [ 2 ] == 2 )
					{
						if ( ( $_POST [ 'title' ] == 0 || $_POST [ 'title' ] == 1 )
							 && ( $_POST [ 'rss' ] == 0 || $_POST [ 'rss' ] == 1 )
							 && ( $_POST [ 'search' ] == 0 || $_POST [ 'search' ] == 1 )
							 && ( $_POST [ 'tags' ] == 0 || $_POST [ 'tags' ] == 1 )
							 && ( $_POST [ 'posts' ] == 0 || $_POST [ 'posts' ] == 1 )
							 && ( $_POST [ 'other' ] == 0 || $_POST [ 'other' ] == 1 )
							 && is_numeric ( $_POST [ 'userinfo' ] ) )
						{
							$config -> load_file ();
							
							$options = array (
								'CACHE_TITLE'	=>	( $_POST [ 'title' ] == 1 ? true : false ),
								'CACHE_RSS'	=>	( $_POST [ 'rss' ] == 1 ? true : false ),
								'CACHE_SEARCH'	=>	( $_POST [ 'search' ] == 1 ? true : false ),
								'CACHE_TAGS'	=>	( $_POST [ 'tags' ] == 1 ? true : false ),
								'CACHE_POSTS'	=>	( $_POST [ 'posts' ] == 1 ? true : false ),
								'CACHE'	=>	( $_POST [ 'other' ] == 1 ? true : false ),
								'USERINFO_REFRESH'	=>	$_POST [ 'userinfo' ],
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}	
					}
				break;	
				
				
			case 'template':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_template' );
					
					# Get templates
					//require_once ( SMARTY_TEMPLATES_DIR .'/template_list.php' );
					//$S [ 'template_list' ] = & $template_list;
						
					if ( $args [ 2 ] == 2 )
					{
						$S [ 'succ' ] = false;
						
						$template_list_ids = array ();
						
						foreach ( $S [ 'template_list' ] as $v )
						{
							$template_list_ids [] = $v [ 'id' ];
						}

						if ( in_array ( $_POST [ 'template' ], $template_list_ids ) )
						{
							$config -> load_file ();
							
							$options = array (
								'DEFAULT_TEMPLATE'	=>	$_POST [ 'template' ],
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
							
							if ( $S [ 'succ' ] )
							{
								$_SESSION [ 'preferences' ] [ 'template' ] = $db -> escape ( $_POST [ 'template' ] );
								$user -> update_prefs ( $_SESSION [ 'preferences' ] );	
							}
						}
					}
				break;	
				
				
			case 'language':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_language' );

					# Get languages
					require_once ( DIR_LANGUAGES .'/language_list.php' );
					$S [ 'language_list' ] = & $language_list;
					
					if ( $args [ 2 ] == 2 )
					{
						$S [ 'succ' ] = false;
						
						$language_list_ids = array ();	
						
						foreach ( $language_list as $v )
						{
							$language_list_ids [] = $v [ 'file' ];
						}
							 
						if ( in_array ( $_POST [ 'language' ], $language_list_ids ) )
						{
							$config -> load_file ();
							
							$options = array (
								'LANG_DEFAULT'	=>	$_POST [ 'language' ],
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
							
							if ( $S [ 'succ' ] )
							{
								$_SESSION [ 'preferences' ] [ 'language' ] = $db -> escape ( $_POST [ 'language' ] );
								$user -> update_prefs ( $_SESSION [ 'preferences' ] );	
							}
						}
					}
				break;	
				
				
			case 'other':
					$S [ 'header' ] = $l -> t ( 'tpl_admin_menu_other' );
					
					if ( $args [ 2 ] == 2 )
					{
						if ( ( $_POST [ 'tags' ] == 0 || $_POST [ 'tags' ] == 1 )
							&& is_numeric ( $_POST [ 'search_perpage' ] ) 
							&& is_numeric ( $_POST [ 'search_limit' ] )
							&& ( $_POST [ 'anonymous_comments' ] == 0 || $_POST [ 'anonymous_comments' ] == 1 )
							&& is_numeric ( $_POST [ 'comments_no' ] )
							&& ( $_POST [ 'generation' ] == 0 || $_POST [ 'generation' ] == 1 )
							&& ( $_POST [ 'log' ] == 0 || $_POST [ 'log' ] == 1 )
							&& is_numeric ( $_POST [ 'log_no' ] )
							&& ( $_POST [ 'hash_ip' ] == 0 || $_POST [ 'hash_ip' ] == 1 ) )
						{
							$config -> load_file ();
							
							$options = array (
								'FUNC_TAGS'	=>	( $_POST [ 'tags' ] == 1 ? true : false ),
								'SEARCH_RESULTS'	=>	$_POST [ 'search_perpage' ],
								'SEARCH_RESULTS_LIMIT'	=>	$_POST [ 'search_limit' ],
								'FUNC_ANONYMOUS_COMMENTS'	=>	( $_POST [ 'anonymous_comments' ] == 1 ? true : false ),
								'COMMENTS_PAGE'	=>	$_POST [ 'comments_no' ],
								'GENERATION_TIME'	=>	( $_POST [ 'generation' ] == 1 ? true : false ),
								'LOG'	=>	( $_POST [ 'log' ] == 1 ? true : false ),
								'LOG_PAGE'	=>	$_POST [ 'log_no' ],
								'STORE_USER_IP'	=>	( $_POST [ 'hash_ip' ] == 0 ? true : false ),
							);
		
							$S [ 'succ' ] = $config -> update_array ( $options );
						}
						else 
						{
							$S [ 'succ' ] = false;	
						}	
					}
				break;	
		}
	}

?>