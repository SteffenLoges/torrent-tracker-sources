<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );
	

	# Function disabled
	if ( !FUNC_DOWNLOADS ) throw new error ( $l -> t ( 'err_func_disabled' ) );


	$S [ 'stylesheets' ] [] = 'downloads.css';

	# Category
	if ( isset ( $args [ 1 ] ) && $args [ 1 ] != null )
	{
		$cat = $args [ 1 ];
	}
	else 
	{
		$cat = 'all';
	}
	
	# Subcategory
	if ( isset ( $args [ 2 ] ) && $args [ 2 ] != null )
	{
		$subcat = $args [ 2 ];
	}
	else 
	{
		$subcat = 'all';
	}
	
	# Page
	if ( isset ( $args [ 3 ] ) )
	{
		$pgstr = $args [ 3 ];
	}
	else 
	{
		if ( isset ( $args [ 2 ] ) )
		{
			$pgstr = $args [ 2 ];	
		}
		else 
		{
			$page = 1;	
		}
	}
	
	if ( !isset ( $page ) )
	{
		if ( preg_match ( "#^page([0-9]+)\$#", $pgstr, $m ) )
		{
			$page = $m [ 1 ];
		}
		else 
		{
			$page = 1;	
		}
	}

	# Sorting
	$sort = ( isset ( $args [ 4 ] ) ? $args [ 4 ] : null );
	$desc = ( isset ( $args [ 5 ] ) ? ( $args [ 5 ] == 'desc' ? true : false ) : true );
	if ( $sort != 'id' && $sort != 'type' && $sort != 'header' && $sort != 'seeders' && $sort != 'leechers'
	  && $sort != 'fsize' && $sort != 'comments' && $sort != 'user' )
	{
		$sort = null;
	}
	if ( $sort != null )
	{
		$S [ 'sort_str' ] = '/'. $sort .'/'. ( $desc ? 'desc' : 'asc' );
	}
	else 
	{
		$S [ 'sort_str' ] = null;	
	}
	$S [ 'sort_desc' ] = $desc;
	$S [ 'sort_type' ] = $sort;
	
	# Paging and download list
	$S [ 'downloads' ] = $downloads -> get ( $cat, $subcat, $page, $sort, $desc, $cat_subcat, $S [ 'page_count' ] );
	$S [ 'download_count' ] = $downloads -> get_count ( $cat_subcat [ 0 ], $cat_subcat [ 1 ] );
	$S [ 'page' ] = & $page;
	$S [ 'cat' ] = & $cat;
	$S [ 'subcat' ] = & $subcat;
	
	# Get cat name
	$S [ 'header' ] = $downloads -> get_cat_info ( $cat, 'name' );
	$subheader = $downloads -> get_subcat_info ( $subcat, $cat_subcat [ 0 ], 'name' );
	
	if ( $subheader != null )
	{
		$S [ 'header' ] .= ' &#187; '. $subheader;	
	}
	
	# Parse subcats
	/*$subcats_tmp = $downloads -> get_subcats ();
	$S [ 'subcats' ] = array ();
	foreach ( $subcats_tmp as $v )
	{
		$S [ 'subcats' ] [ $v [ 'cat' ] ] [] = $v;
	}*/
	
	$S [ 'dl_cats' ] = $downloads -> get_cats ( true );
	unset ( $_SESSION [ 'subcats' ] );
	
	if ( $S [ 'header' ] == null )
	{
		$S [ 'header' ] = $l -> t ( 'downloads_newest_downloads' );	
	}
	else 
	{
		# Get subcats for opened cat
		foreach ( $S [ 'dl_cats' ] as $v )
		{
			if ( $v [ 'id' ] == $cat_subcat [ 0 ] && isset ( $v [ 'subcats' ] ) )
			{
				$_SESSION [ 'subcats' ] = array ( $cat_subcat [ 0 ], $v [ 'subcats' ] );	
			}
		}
		
		if ( !isset ( $_SESSION [ 'subcats' ] ) ) 
		{
			$_SESSION [ 'subcats' ] = array ( $cat_subcat [ 0 ], null );
		}
		
		$S [ 'subcategory' ] = & $cat_subcat [ 1 ];
		//$_SESSION [ 'subcats' ] = array ( $cat_subcat [ 0 ], $downloads -> get_subcats ( $cat_subcat [ 0 ] ) );
	}
?>