<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	switch ( $_POST [ 'type' ] )
	{
		default:
				die ( $l -> t ( 'error' ) );
			break;
			
		case 'blog':
				$posts = $blog -> get_last_posts ( 5 );
				foreach ( $posts as $v )
				{
					$title = $v [ 'header' ];
					if ( strlen ( $title ) > 33 )
					{
						$title = substr ( $title, 0, 30 ) .'...';	
					}
					$title = $text -> replace_quotes ( htmlspecialchars ( $title ) );
					echo '<a href="'. $url -> make ( 'read', $v [ 'lid' ], $v [ 'plid' ] ) .'">'. $title .'</a>';	
				}
			break;
			
		case 'comments':
				$posts = $comments -> get_last ( 5 );
				foreach ( $posts as $v )
				{
					$title = $v [ 'header' ];
					if ( strlen ( $title ) > 33 )
					{
						$title = substr ( $title, 0, 30 ) .'...';	
					}
					$title = $text -> replace_quotes ( htmlspecialchars ( $title ) );
					if ( $v [ 'sublid' ] == null )
					{
						$link = $url -> make ( 'read', $v [ 'lid' ], $v [ 'plid' ], '#comments' );
					}
					else 
					{
						$link = $url -> make ( 'file', $v [ 'lid' ], $v [ 'sublid' ], $v [ 'plid' ], '#comments' );
					}
					echo '<a href="'. $link .'">'. $title .'</a>';	
				}
			break;
			
		case 'downloads':
				$posts = $downloads -> get_top ( 5 );
				foreach ( $posts as $v )
				{
					$title = $v [ 'header' ];
					if ( strlen ( $title ) > 33 )
					{
						$title = substr ( $title, 0, 30 ) .'...';	
					}
					$title = $text -> replace_quotes ( htmlspecialchars ( $title ) );
					$link = $url -> make ( 'file', $v [ 'lid' ], $v [ 'sublid' ], $v [ 'plid' ] );
					echo '<a href="'. $link .'">'. $title .'</a>';	
				}
			break;
	}

	
	die ();
	
?>