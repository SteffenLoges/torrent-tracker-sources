<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	$S [ 'err' ] = false;
	
	if ( isset ( $args [ 1 ] ) )
	{
		if ( isset ( $_POST [ 'comment' ] ) && trim ( $_POST [ 'comment' ] ) != null && preg_match ( "#^(p|d)([0-9]+)\$#", $args [ 1 ], $m ) )
		{
			# Comment posting
			$iid = $comments -> post ( $m [ 2 ], $_POST [ 'comment' ], ( $m [ 1 ] == 'p' ? 'blog_comments' : 'dl_comments' ) );
			if ( $iid === false || is_array ( $iid ) )
			{
				if ( is_array ( $iid ) )
				{
					$S [ 'err' ] = $iid;
				}
				else 
				{
					$S [ 'err' ] = true;
				}	
			}
			else 
			{
				# OK, redirect
				if ( $m [ 1 ] == 'p' )
				{
					$info = $blog -> get_plid_lid ( $m [ 2 ], false, ', b.comments' );
					$redir_url = $url -> make ( 'read', $info [ 'lid' ], $info [ 'plid' ], 'c'. $info [ 'comments' ] );
				}
				else 
				{
					$info = $downloads -> get_plid_lid_sublid ( $m [ 2 ], ', dl_downloads.comments' );
					$redir_url = $url -> make ( 'file', $info [ 'lid' ], $info [ 'sublid' ], $info [ 'plid' ], 'c'. $info [ 'comments' ] );
				}
				
				header ( 'location: '. $redir_url );
				die ();	
			}
		}
		else 
		{
			# Comment deletion
			if ( isset ( $_SESSION [ 'permissions' ] ) && $_SESSION [ 'permissions' ] [ 'delete_comments' ]
				 && $args [ 1 ] == 'delete' && isset ( $args [ 2 ] ) && preg_match ( "#^(p|d)([0-9]+)\$#", $args [ 2 ], $m )
				 && isset ( $_POST [ 'delcomm' ] ) )
			{
				$affected = $comments -> delete ( $_POST [ 'delcomm' ], $m [ 2 ], ( $m [ 1 ] == 'p' ? 'blog_comments' : 'dl_comments' ) );
				if ( $affected == 0 )
				{
					error::line(__LINE__);
					$S [ 'err' ] = true;	
				}
				else 
				{
					# OK, redirect	
					if ( $m [ 1 ] == 'p' )
					{
						$info = $blog -> get_plid_lid ( $m [ 2 ] );
						$redir_url = $url -> make ( 'read', $info [ 'lid' ], $info [ 'plid' ] );
					}
					else 
					{
						$info = $downloads -> get_plid_lid_sublid ( $m [ 2 ] );
						$redir_url = $url -> make ( 'file', $info [ 'lid' ], $info [ 'sublid' ], $info [ 'plid' ] );
					}
					
					header ( 'location: '. $redir_url );
					die ();	
				}
			}
			else 
			{
				error::line(__LINE__);
				$S [ 'err' ] = true;	
			}
		}
	}
	else 
	{
		error::line(__LINE__);
		$S [ 'err' ] = true;
	}

?>