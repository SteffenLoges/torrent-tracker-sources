<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	$args [ 1 ] = ( isset ( $args [ 1 ] ) ? $args [ 1 ] : null );
	$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );

	switch ( $args [ 1 ] )
	{
		
		default:
				$args [ 1 ] = null;
			break;
			
		case 'register':
				if ( $args [ 2 ] != 2 )
				{
					# Draw registration form
					$_SESSION [ 'captcha' ] = $text -> pronounceable ();
				}
				else 
				{
					# Perform registration
					$username = trim ( ( isset ( $_POST [ 'user' ] ) ? $_POST [ 'user' ] : null ) );
					$pass1 = trim ( ( isset ( $_POST [ 'pass1' ] ) ? $_POST [ 'pass1' ] : null ) );
					$pass2 = trim ( ( isset ( $_POST [ 'pass2' ] ) ? $_POST [ 'pass2' ] : null ) );
					$email1 = trim ( ( isset ( $_POST [ 'email1' ] ) ? $_POST [ 'email1' ] : null ) );
					$email2 = trim ( ( isset ( $_POST [ 'email2' ] ) ? $_POST [ 'email2' ] : null ) );
					$captcha = trim ( ( isset ( $_POST [ 'captcha' ] ) ? $_POST [ 'captcha' ] : null ) );
					
					# Validate user data
					$err = $user -> validate_data ( $username, $pass1, $pass2, $email1, $email2 );
					
					# Captcha
					$err2 = $user -> validate_captcha ( $captcha );
					$err = array_merge ( $err, $err2 );
					
					# TOS
					if ( !isset ( $_POST [ 'tos' ] ) )  
					{
						$err [] = $l -> t ( 'user_err_agree_tos' );	
					}
					
					$S [ 'err' ] = & $err;
					
					if ( empty ( $err ) )
					{
						# All is well, perform registration
						$ok = $user -> register ();
						if ( $ok === false )
						{
							$err [] = $l -> t ( 'error_unknown' );	
						}
					}
					
				}
			break;
			
			
		case 'activate':
				$S [ 'validate' ] = $user -> validate_email ( $args [ 2 ] );
			break;
			
			
		case 'login':
				$username = ( isset ( $_POST [ 'user' ] ) ? $_POST [ 'user' ] : null );
				$password = ( isset ( $_POST [ 'pass' ] ) ? $_POST [ 'pass' ] : null );
			
				$S [ 'validated' ] = true;
				
				if ( $username != null && $password != null )
				{
					# Validate username
					$err = false;
					
					$strl_user = strlen ( $username );
					
					if ( $strl_user < 3 || $strl_user > 20 )
						$err = true;
				
					if ( !$text -> validate ( $username, 'username' ) )
						$err = true;

					# Error
					if ( !$err )
					{
						$log = $user -> login ( $username, $password, $S [ 'validated' ] );
					}
					else 
					{
						$log = false;	
					}
					
					# Logged in
					if ( $log == true )
					{
						if ( isset ( $_SESSION [ 'prev_args' ] ) && ( !preg_match ( "#^(?:user|captcha|rss|out|online|torrents|nfo|admin)\b#", implode ( '/', $_SESSION [ 'prev_args' ] ) ) ) )
						{
							$redir_url = $url -> make ( $_SESSION [ 'prev_args' ] );
						}
						else 
						{
							$redir_url = $url -> make ( '_' );
						}
						
						header ( 'location: '. $redir_url );
						die ();	
					}
					
					# Validate email
					if ( $S [ 'validated' ] === false )
					{
						$_SESSION [ 'captcha' ] = $text -> pronounceable ();	
						$_SESSION [ 'validate_user' ] = $username;
						$_SESSION [ 'validate_pass' ] = $password;
					}
				}
				
				$S [ 'username' ] = & $username;		
			break;
			
			
		case 'changemail':
				$email1 = trim ( ( isset ( $_POST [ 'email1' ] ) ? $_POST [ 'email1' ] : null ) );
				$email2 = trim ( ( isset ( $_POST [ 'email2' ] ) ? $_POST [ 'email2' ] : null ) );
				$captcha = trim ( ( isset ( $_POST [ 'captcha' ] ) ? $_POST [ 'captcha' ] : null ) );
				
				$err = $user -> validate_captcha ( $captcha );
				
				# Validate e-mail addresses
				$err2 = $user -> validate_data ( null, null, null, $email1, $email2, true );
				$err = array_merge ( $err, $err2 );
					
				if ( !isset ( $_SESSION [ 'validate_user' ] ) || !isset ( $_SESSION [ 'validate_pass' ] ) )
					$err [] = $l -> t ( 'error_unknown' );	
					
				$S [ 'err' ] = & $err;
					
				if ( empty ( $err ) )
				{
					# All is well, send validation (activation) e-mail
					$hash = md5 ( $email1 . uniqid () );
					$user -> update ( array ( 'email' => $email1, 'email_validate' => $hash ), $_SESSION [ 'validate_user' ] );
					$user -> send_validate_email ( $_SESSION [ 'validate_user' ], $email1, $hash );
				}
			break;
			
			
		case 'reminder':
				if ( $args [ 2 ] != 2 )
				{
					# Draw form
					$_SESSION [ 'captcha' ] = $text -> pronounceable ();
				}
				else 
				{
					$email = trim ( ( isset ( $_POST [ 'email' ] ) ? $_POST [ 'email' ] : null ) );
					$captcha = trim ( ( isset ( $_POST [ 'captcha' ] ) ? $_POST [ 'captcha' ] : null ) );
					
					# Captcha
					$err = $user -> validate_captcha ( $captcha );
					
					if ( !$text -> validate ( $email, 'email' ) || strlen ( $email ) > 32 )
						$err [] = $l -> t ( 'user_email_invalid' );	
					
					if ( empty ( $err ) )
					{
						$user -> pass_reminder ( $email );
					}
					
					$S [ 'err' ] = & $err;
				}
			break;
			
			
		case 'logoff':
				$session -> destroy ();
			
				if ( isset ( $_SESSION [ 'prev_args' ] ) && ( !preg_match ( "#^(?:user|captcha|rss|out|online|torrents|nfo|admin)\b#", implode ( '/', $_SESSION [ 'prev_args' ] ) ) ) )
				{
					$redir_url = $url -> make ( $_SESSION [ 'prev_args' ] );
				}
				else 
				{
					$redir_url = $url -> make ( '_' );
				}
				
				header ( 'location: '. $redir_url );
				die ();	
			break;
			
			
		case 'v':
				$S [ 'info' ] = $user -> get_info ( $args [ 2 ] );
				if ( $S [ 'info' ] !== false )
				{
					$S [ 'header' ] = $S [ 'info' ] [ 'name' ];	
					
					# Fix user status
					$S [ 'info' ] [ 'status' ] = $user -> get_status ( $S [ 'info' ] );
				}
			break;
			
			
		case 'preferences':
				if ( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] )
				{
					# Get downloads categories
					if ( FUNC_DOWNLOADS )
					{
						$S [ 'dl_cats' ] = $downloads -> get_cats ( true );	
					}
					
					# Get templates and languages
					//require_once ( SMARTY_TEMPLATES_DIR .'/template_list.php' );
					//$S [ 'template_list' ] = & $template_list;
					require_once ( DIR_LANGUAGES .'/language_list.php' );
					$S [ 'language_list' ] = & $language_list;
					
					if ( $args [ 2 ] == 2 )
					{
						$start_page = 		( isset ( $_POST [ 'start_page' ] ) 		? $_POST [ 'start_page' ] 		: $_SESSION [ 'preferences' ] [ 'start_page' ] );
						$blog_no = 			( isset ( $_POST [ 'blog_no' ] ) 			? $_POST [ 'blog_no' ] 			: $_SESSION [ 'preferences' ] [ 'blog_no' ] );
						$downloads_no = 	( isset ( $_POST [ 'downloads_no' ] ) 		? $_POST [ 'downloads_no' ] 	: $_SESSION [ 'preferences' ] [ 'downloads_no' ] );
						$downloads_type = 	( isset ( $_POST [ 'downloads_type' ] ) 	? $_POST [ 'downloads_type' ] 	: $_SESSION [ 'preferences' ] [ 'downloads_type' ] );
						$comments_no = 		( isset ( $_POST [ 'comments_no' ] ) 		? $_POST [ 'comments_no' ] 		: $_SESSION [ 'preferences' ] [ 'comments_no' ] );
						$comments_dir = 	( isset ( $_POST [ 'comments_dir' ] ) 		? $_POST [ 'comments_dir' ] 	: $_SESSION [ 'preferences' ] [ 'comments_dir' ] );
						$forum_threads_no = ( isset ( $_POST [ 'forum_threads_no' ] ) 	? $_POST [ 'forum_threads_no' ]	: $_SESSION [ 'preferences' ] [ 'forum_threads_no' ] );
						$forum_posts_no = 	( isset ( $_POST [ 'forum_posts_no' ] ) 	? $_POST [ 'forum_posts_no' ] 	: $_SESSION [ 'preferences' ] [ 'forum_posts_no' ] );
						$forum_posts_dir = 	( isset ( $_POST [ 'forum_posts_dir' ] ) 	? $_POST [ 'forum_posts_dir' ] 	: $_SESSION [ 'preferences' ] [ 'forum_posts_dir' ] );
						$private_no = 		( isset ( $_POST [ 'private_no' ] ) 		? $_POST [ 'private_no' ] 		: $_SESSION [ 'preferences' ] [ 'private_no' ] );
						$language_p = 		( isset ( $_POST [ 'language' ] ) 			? $_POST [ 'language' ] 		: $_SESSION [ 'preferences' ] [ 'language' ] );
						$template_p = 		( isset ( $_POST [ 'template' ] ) 			? $_POST [ 'template' ] 		: $_SESSION [ 'preferences' ] [ 'template' ] );
						
						$language_list_ids = array ();
						$template_list_ids = array ();
						
						foreach ( $S [ 'language_list' ] as $v )
						{
							$language_list_ids [] = $v [ 'file' ];
						}
						foreach ( $S [ 'template_list' ] as $v )
						{
							$template_list_ids [] = $v [ 'id' ];
						}
						
						if ( 
							$blog_no != null && is_numeric ( $blog_no ) && 
							$downloads_no != null && is_numeric ( $downloads_no ) &&
							is_numeric ( $downloads_type ) &&
							$comments_no != null && is_numeric ( $comments_no ) &&
							is_numeric ( $comments_dir ) &&
							$forum_threads_no != null && is_numeric ( $forum_threads_no ) &&
							$forum_posts_no != null && is_numeric ( $forum_posts_no ) &&
							is_numeric ( $forum_posts_dir ) 
							&& $blog_no >= 5 && $blog_no <= 15 && $blog_no % 5 == 0
							&& $downloads_no >= 10 && $downloads_no <= 50 && $downloads_no % 5 == 0
							&& $downloads_type >= 0 && $downloads_type <= 2
							&& $comments_no >= 5 && $comments_no <= 20 && $comments_no % 5 == 0
							&& $comments_dir >= 0 && $comments_dir <= 1
							&& $forum_threads_no >= 10 && $forum_threads_no <= 30 && $forum_threads_no % 5 == 0
							&& $forum_posts_no >= 5 && $forum_posts_no <= 20 && $forum_posts_no % 5 == 0
							&& $forum_posts_dir >= 0 && $forum_posts_dir <= 1
							&& $private_no >= 10 && $private_no <= 40 && $private_no % 10 == 0
							&& in_array ( $language_p, $language_list_ids )
							&& in_array ( $template_p, $template_list_ids ) )
						{
							$start_page = $db -> escape ( $start_page );
							$language_p = $db -> escape ( $language_p );
							$template_p = $db -> escape ( $template_p );
							$user -> update_prefs ( array ( 'start_page' => $start_page, 
															'blog_no' => $blog_no, 
															'downloads_no' => $downloads_no, 
															'downloads_type' => $downloads_type,
															'comments_no' => $comments_no, 
															'comments_dir' => $comments_dir,
															'forum_threads_no' => $forum_threads_no,
															'forum_posts_no' => $forum_posts_no,
															'forum_posts_dir' => $forum_posts_dir,
															'private_no' => $private_no,
															'language'	=>	$language_p,
															'template'	=>	$template_p ) );
							$S [ 'updated' ] = true;
						}
						else 
						{
							$S [ 'updated' ] = false;	
						}
					}
				}
			break;
			
			
		case 'profile':
				if ( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] )
				{
					if ( ( ( $args [ 2 ] == 'c' && isset ( $args [ 3 ] ) ) || isset ( $_POST [ 'cust_user' ] ) ) && $_SESSION [ 'permissions' ] [ 'edit_users' ] == 1 )
					{
						if ( $args [ 2 ] == 'c' ) 
						{
							$args [ 2 ] = null;
						}
						$tmp_cust = ( isset ( $_POST [ 'cust_user' ] ) ? $_POST [ 'cust_user' ] : $args [ 3 ] );
						$tmp_cust = $db -> escape ( $tmp_cust );
						if ( $user -> user_exists ( $tmp_cust ) )
						{
							$S [ 'cust_user' ] = $tmp_cust;
							$S [ 'userinfo' ] = $user -> get_info ( $tmp_cust );
						}
					}
					else 
					{
						$S [ 'userinfo' ] = & $_SESSION [ 'userinfo' ];	
					}
					
					if ( $args [ 2 ] != null )
					{
						$S [ 'err' ] = array ();
						
						$_POST [ 'cust_user' ] = ( isset ( $_POST [ 'cust_user' ] ) ? $db -> escape ( $_POST [ 'cust_user' ] ) : null );
						
						if ( $_POST [ 'cust_user' ] != null && $_SESSION [ 'permissions' ] [ 'edit_users' ] == 1 && $user -> user_exists ( $_POST [ 'cust_user' ] ) )
						{
							$update_user = $_POST [ 'cust_user' ];
							$cust_user = true;
						}
						else 
						{
							$update_user = $_SESSION [ 'user' ];
						}
						
						switch ( $args [ 2 ] )
						{
						
							case 'userinfo':
									$name_p = 		( isset ( $_POST [ 'name' ] ) 		? $_POST [ 'name' ] 	: null );
									$gender_p = 	( isset ( $_POST [ 'gender' ] ) 	? $_POST [ 'gender' ] 	: null );
									$year_p = 		( isset ( $_POST [ 'Date_Year' ] ) 	? $_POST [ 'Date_Year' ]: null );
									$month_p = 		( isset ( $_POST [ 'Date_Month' ] ) ? $_POST [ 'Date_Month' ]: null );
									$day_p = 		( isset ( $_POST [ 'Date_Day' ] ) 	? $_POST [ 'Date_Day' ] : null );
									$location_p = 	( isset ( $_POST [ 'location' ] )	? $_POST [ 'location' ]	: null );
									$avatar_p = 	( isset ( $_POST [ 'avatar' ] )		? $_POST [ 'avatar' ]	: null );
									$page_p = 		( isset ( $_POST [ 'page' ] ) 		? $_POST [ 'page' ] 	: null );
									$skype_p = 		( isset ( $_POST [ 'skype' ] ) 		? $_POST [ 'skype' ] 	: null );
									$msn_p = 		( isset ( $_POST [ 'msn' ] ) 		? $_POST [ 'msn' ] 		: null );
									$icq_p = 		( isset ( $_POST [ 'icq' ] ) 		? $_POST [ 'icq' ] 		: null );
									$yahoo_p = 		( isset ( $_POST [ 'yahoo' ] ) 		? $_POST [ 'yahoo' ] 	: null );
									$gtalk_p = 		( isset ( $_POST [ 'gtalk' ] )		? $_POST [ 'gtalk' ] 	: null );
									
									$S [ 'err' ] = $user -> validate_userinfo ( $name_p, $gender_p, $year_p, $month_p, $day_p, $location_p, $avatar_p, 
																				$page_p, $skype_p, $msn_p, $icq_p, $yahoo_p, $gtalk_p );
																				
									if ( empty ( $S [ 'err' ] ) )
									{
										error::toggle_silent ( true );
										$avatar_size = getimagesize ( $avatar_p );
										error::toggle_silent ( false );
										
										if ( $avatar_size !== false )
										{
											$headers = get_headers ( $avatar_p, 1 );
            								if ( array_key_exists ( 'Content-Length', $headers ) )
            								{
            									$avatar_fsize = $headers [ 'Content-Length' ];
            								}
            								else 
            								{
            									$avatar_fsize = 0;
            								}
										}
										
										if ( $avatar_p != null && ( $avatar_size === false || !preg_match ( "#^image/#i", $avatar_size [ 'mime' ] )
											|| $avatar_size [ 0 ] > AVATAR_MAXWIDTH || $avatar_size [ 1 ] > AVATAR_MAXHEIGHT
											|| $avatar_fsize > AVATAR_MAXSIZE ) )
										{
											$S [ 'err' ] = array ( $l -> t ( 'user_err_avatar', AVATAR_MAXWIDTH, AVATAR_MAXHEIGHT, $template -> format_size ( AVATAR_MAXSIZE ) ) );
										}
										else 
										{
											$update_array = array 
																	(
																		'pr_name' 		=> $name_p,
																		'pr_gender' 	=> $gender_p,
																		'pr_birth'		=> ( $year_p != null && $month_p != null && $day_p != null ? $year_p .'-'. $month_p .'-'. $day_p : '0000-00-00' ),
																		'pr_location' 	=> $location_p,
																		'pr_avatar' 	=> $avatar_p,
																		'pr_page' 		=> $page_p,
																		'pr_skype'	 	=> $skype_p,
																		'pr_msn' 		=> $msn_p,
																		'pr_icq' 		=> $icq_p,
																		'pr_yahoo' 		=> $yahoo_p,
																		'pr_gtalk' 		=> $gtalk_p,
																	);
											
											$user -> update ( 
															  $update_array,
															  $update_user 
															);	
										}
									}
								break;
								
							case 'email':
									// 'user', 'profile', 'email', 'validate', $hash
									$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
									$args [ 4 ] = ( isset ( $args [ 4 ] ) ? $args [ 4 ] : null );
									
									if ( $args [ 3 ] == 'validate' && $args [ 4 ] != null )
									{
										# Validatinam
										$valid = $user -> change_email ( $args [ 4 ] );
										if ( $valid )
										{
											$S [ 'okmsg' ] = $l -> t ( 'user_email_changed' );
										}
										else 
										{
											$S [ 'err' ] = array ( $l -> t ( 'user_err_email_code' ) );	
										}
									}
									else 
									{
										# Siunciam maila
										$email1_p = 		( isset ( $_POST [ 'email1' ] ) 		? $_POST [ 'email1' ] 	: null );
										$email2_p = 		( isset ( $_POST [ 'email2' ] ) 		? $_POST [ 'email2' ] 	: null );
										$pass_p = 			( isset ( $_POST [ 'pass' ] )			? $_POST [ 'pass' ] 	: null );
										
										if ( md5 ( md5 ( $pass_p ) ) == $_SESSION [ 'pass' ] || isset ( $cust_user ) )
										{
											# Validatina emailus
											$S [ 'err' ] = $user -> validate_data ( null, null, null, $email1_p, $email2_p, true, true, true );
							
											if ( empty ( $S [ 'err' ] ) )
											{
												# Viskas OK, siunciam laiska
												if ( FUNC_USER_VALIDATION && !isset ( $cust_user ) )
												{
													$hash = md5 ( $email1_p . uniqid () );
													$user -> update ( array ( 'email_change' => $email1_p, 'email_validate_change' => $hash ), $_SESSION [ 'user' ] );
													$user -> send_validate_email ( $_SESSION [ 'user' ], $email1_p, $hash, true );
													$S [ 'okmsg' ] = $l -> t ( 'user_email_change_code_sent' );
												}
												else 
												{
													$user -> update ( array ( 'email' => $email1_p, 'email_change' => '', 'email_validate_change' => '' ), $update_user );
													$user -> refresh_info ();
													$S [ 'okmsg' ] = $l -> t ( 'user_email_changed' );
												}
											}
										}
										else 
										{
											$S [ 'err' ] = array ( $l -> t ( 'user_err_email_validation_password' ) );
										}
									}
								break;
								
							case 'pass':
									$pass1_p = 		( isset ( $_POST [ 'pass1' ] ) 		? trim ( $_POST [ 'pass1' ] ) 	: null );
									$pass2_p = 		( isset ( $_POST [ 'pass2' ] ) 		? trim ( $_POST [ 'pass2' ] ) 	: null );
									$pass_p = 		( isset ( $_POST [ 'pass' ] )		? trim ( $_POST [ 'pass' ]  ) 	: null );
									
									if ( md5 ( md5 ( $pass_p ) ) == $_SESSION [ 'pass' ] || isset ( $cust_user ) )
									{
										# Keiciam pass
										$strl_pass = strlen ( $pass1_p );
										
										if ( $pass1_p != $pass2_p )
											$S [ 'err' ] [] = $l -> t ( 'user_pass_match' );
				
										if ( $strl_pass < 6 || $strl_pass > 20 )
											$S [ 'err' ] [] = $l -> t ( 'user_pass_len' );
					
										if ( $_SESSION [ 'user' ] == $pass1_p )
											$S [ 'err' ] [] = $l -> t ( 'user_name_pass_match' );
											
										if ( empty ( $S [ 'err' ] ) )
										{
											$hashed = md5 ( md5 ( $pass1_p ) );
											$user -> update ( array ( 'pass' => $hashed ), $update_user );
											$_SESSION [ 'pass' ] = $hashed;	
											$S [ 'okmsg' ] = $l -> t ( 'user_pass_changed' );
										}	
									}
									else 
									{
										$S [ 'err' ] = array ( $l -> t ( 'user_err_old_pass' ) );
									}
								break;
								
							case 'torrentpass':
									if ( !FUNC_DOWNLOADS || !FUNC_DOWNLOADS_TORRENT || TRACKER_ANONYMOUS )
									{
										throw new error ( $l -> t ( 'err_func_disabled' ) );	
									}
								
									if ( isset ( $_POST [ 'torrent_pass' ] ) )
									{
										$user -> update ( array ( 'torrent_pass' => null ), $update_user );
										$S [ 'okmsg' ] = $l -> t ( 'user_torrentpass_changed' );	
									}
									else 
									{
										$S [ 'err' ] [] = $l -> t ( 'user_err_torrentpass_check' );
									}
								break;
								
							case 'admin':
									$status_p = 		( isset ( $_POST [ 'status' ] )			? $_POST [ 'status' ] 			: null );
									$blogposts_p = 		( isset ( $_POST [ 'blogposts' ] )		? $_POST [ 'blogposts' ] 		: null );
									$downloadposts_p = 	( isset ( $_POST [ 'downloadposts' ] )	? $_POST [ 'downloadposts' ]	: null );
									$comments_p = 		( isset ( $_POST [ 'comments' ] )		? $_POST [ 'comments' ] 		: null );
									$forumposts_p = 	( isset ( $_POST [ 'forumposts' ] )		? $_POST [ 'forumposts' ] 		: null );
									$wait_time_p = 		( isset ( $_POST [ 'wait_time' ] )		? $_POST [ 'wait_time' ] 		: null );
									$peers_limit_p = 	( isset ( $_POST [ 'peers_limit' ] )	? $_POST [ 'peers_limit' ] 		: null );
									$torrents_limit_p =	( isset ( $_POST [ 'torrents_limit' ] )	? $_POST [ 'torrents_limit' ] 	: null );
									$downloaded_p = 	( isset ( $_POST [ 'downloaded' ] )		? $_POST [ 'downloaded' ] 		: null );
									$uploaded_p = 		( isset ( $_POST [ 'uploaded' ] )		? $_POST [ 'uploaded' ] 		: null );
									
									$S [ 'err' ] = array ();
									if ( !is_numeric ( $blogposts_p ) || !is_numeric ( $downloadposts_p ) || !is_numeric ( $comments_p ) || !is_numeric ( $forumposts_p ) )
									{
										$S [ 'err' ] [] = $l -> t ( 'user_err_admin_numeric' );	
									}
									
									if ( empty ( $S [ 'err' ] ) && FUNC_DOWNLOADS && FUNC_DOWNLOADS_TORRENT && TRACKER_ANONYMOUS == false &&
											( !is_numeric ( $wait_time_p ) || !is_numeric ( $peers_limit_p ) || !is_numeric ( $torrents_limit_p ) || !is_numeric ( $downloaded_p )
											  || !is_numeric ( $uploaded_p )
											) )
									{
										$S [ 'err' ] [] = $l -> t ( 'user_err_admin_numeric' );	
									}
												
									if ( isset ( $cust_user ) && empty ( $S [ 'err' ] ) )											
									{
										$update_array = array 
																(
																	'status'		=>	$db -> escape ( substr ( $status_p, 0, 255 ) ),
																	'blogposts'		=>	$blogposts_p,
																	'downloadposts'	=>	$downloadposts_p,
																	'comments'		=>	$comments_p,
																	'forumposts'	=>	$forumposts_p,
																	'wait_time'		=>	$wait_time_p,
																	'peers_limit'	=>	$peers_limit_p,
																	'torrents_limit'=>	$torrents_limit_p,
																	'downloaded'	=>	$downloaded_p,
																	'uploaded'		=>	$uploaded_p,
																);
												
										$user -> update ( 
														  $update_array,
														  $update_user 
														);	
									}
								break;	
								
						}
					}
				}
			break;
			
			
		case 'ban':
				$args [ 2 ] = ( isset ( $args [ 2 ] ) ? $args [ 2 ] : null );
				$args [ 3 ] = ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				
				if ( $_SESSION [ 'permissions' ] [ 'ban_users' ] != 1 )
				{
					$S [ 'err' ] = true;	
				}
				else 
				{
					$S [ 'user' ] = $user -> get_info ( $args [ 2 ] );
					if ( $S [ 'user' ] !== false )
					{
						$S [ 'err' ] = false;
						
						if ( $args [ 3 ] == 2 )
						{
							# Update
							$can_leech = ( isset ( $_POST [ 'noleech' ] ) ? 0 : 1 );
							$banned = ( isset ( $_POST [ 'banned' ] ) ? 1 : 0 );
							$warned = ( isset ( $_POST [ 'warned' ] ) ? 1 : 0 );
							# If something was changed
							if ( $S [ 'user' ] [ 'can_leech' ] != $can_leech || $S [ 'user' ] [ 'banned' ] != $banned || $S [ 'user' ] [ 'warned' ] != $warned )
							{
								$S [ 'res' ] = $user -> update ( array ( 'can_leech' => $can_leech, 'can_leech_manual' => $can_leech, 'banned' => $banned, 'warned' => $warned, 'warned_manual' => $warned ), $args [ 2 ] );
								$S [ 'user' ] [ 'can_leech' ] = $can_leech;
								$S [ 'user' ] [ 'banned' ] = $banned;
								$S [ 'user' ] [ 'warned' ] = $warned;
							}
							else 
							{
								$S [ 'res' ] = true;	
							}
						}
					}
					else 
					{
						$S [ 'err' ] = true;	
					}
				}
			break;
	}

?>