<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	$S [ 'stylesheets' ] [] = 'downloads.css';
	$S [ 'stylesheets' ] [] = 'search.css';

	$S [ 'err' ] = false;
	
	$S [ 'header' ] = $l -> t ( 'search_header' );
	$S [ 'subheader' ] = null;

	$str = ( isset ( $_POST [ 'search' ] ) ? $_POST [ 'search' ] : null );
	$type = ( isset ( $_POST [ 'type' ] ) ? $_POST [ 'type' ] : null );
	
	if ( $str != null && $type != null )
	{
		# Redirect
		if ( $type == 'downloads' )
		{
			$dlcats = null;
			foreach ( $_POST as $k => $v )
			{
				if ( substr ( $k, 0, 6 ) == 'dlsub_' )
				{
					$dlcats .= substr ( $k, 6 ) .',';	
				}	
			}
			$dlcats = rtrim ( $dlcats, ',' );
			if ( $dlcats == null ) $dlcats = '__';
		}
		else 
		{
			$dlcats = '__';	
		}
		header ( 'location: '. $url -> make ( 'search', $type, urlencode ( $str ), $dlcats ) );
		die ();
	}
	else 
	{
		# Search
		if ( isset ( $args [ 1 ] ) && isset ( $args [ 2 ] ) && 
				( $args [ 1 ] == 'blog' || $args [ 1 ] == 'blog_tag' || $args [ 1 ] == 'downloads' || $args [ 1 ] == 'downloads_tag' || $args [ 1 ] == 'forums' || $args [ 1 ] == 'users' ) )
		{
			$keywords = $search -> check_keywords ( urldecode ( $args [ 2 ] ), ( $args [ 1 ] == 'blog_tag' || $args [ 1 ] == 'downloads_tag' ? false : true ) );
			if ( empty ( $keywords ) )
			{
				$S [ 'err' ] = $l -> t ( 'search_err_keyword_length' );	
			}
			else 
			{
				# Sorting
				if ( $args [ 1 ] == 'downloads' || $args [ 1 ] == 'downloads_tag' )
				{
					if ( !isset ( $args [ 6 ] ) )
					{
						$sort = ( isset ( $args [ 4 ] ) ? $args [ 4 ] : null );
						$desc = ( isset ( $args [ 5 ] ) ? ( $args [ 5 ] == 'desc' ? true : false ) : true );
					}
					else 
					{
						$sort = ( isset ( $args [ 5 ] ) ? $args [ 5 ] : null );
						$desc = ( isset ( $args [ 6 ] ) ? ( $args [ 6 ] == 'desc' ? true : false ) : true );
					}
					if ( $sort != 'id' && $sort != 'type' && $sort != 'header' && $sort != 'seeders' && $sort != 'leechers'
					  && $sort != 'fsize' && $sort != 'comments' && $sort != 'user' )
					{
						$sort = null;
					}
					if ( $sort != null )
					{
						$S [ 'sort_str' ] = '/'. $sort .'/'. ( $desc ? 'desc' : 'asc' );
					}
					else 
					{
						$S [ 'sort_str' ] = null;	
					}
					$S [ 'sort_desc' ] = $desc;
					$S [ 'sort_type' ] = $sort;
				}
				else 
				{
					$sort = null;
					$desc = true;
					$S [ 'sort_str' ] = '_';
					$S [ 'sort_desc' ] = $desc;
					$S [ 'sort_type' ] = $sort;	
				}
				
				# Search in specific download (sub)categories?
				$args [ 3 ] =  ( isset ( $args [ 3 ] ) ? $args [ 3 ] : null );
				$args [ 4 ] =  ( isset ( $args [ 4 ] ) ? $args [ 4 ] : null );
				if ( is_numeric ( $args [ 3 ] ) || preg_match ( '#\d+,\d#', $args [ 3 ] ) )
				{
					$S [ 'dl_search_cats' ] = $args [ 3 ];
					$S [ 'dl_cats_arr' ] = explode ( ',', $args [ 3 ] );
				}
				else 
				{
					$S [ 'dl_search_cats' ] = '__';
					$S [ 'dl_cats_arr' ] = array ();	
				}
				
				# Check cache
				$S [ 'search' ] = $search -> check_cache ( $keywords, $args [ 1 ], $sort, $desc, $S [ 'dl_cats_arr' ] );
				
				# Perform search
				if ( $S [ 'search' ] === false )
				{
					$S [ 'search' ] = $search -> fulltext ( $keywords, $args [ 1 ], $sort, $desc, $S [ 'dl_cats_arr' ] );
				}
				
				# Paging
				if ( $args [ 3 ] != null )
				{
					if ( preg_match ( "#^page([0-9]+)\$#", ( $S [ 'dl_search_cats' ] == '__' ? $args [ 3 ] : $args [ 4 ] ), $m ) )
					{
						$S [ 'page' ] = $m [ 1 ];
					}
					else 
					{
						$S [ 'page' ] = 1;	
					}
				}
				else 
				{
					$S [ 'page' ] = 1;	
				}
				
				# Get download categories and subcategories
				$S [ 'dl_cats' ] = $downloads -> get_cats ( true );
			}
		}
		else 
		{
			$S [ 'err' ] = true;	
		}	
	}

?>