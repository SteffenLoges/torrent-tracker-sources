<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/

	/*
		Add URLs you want static-cached to this array. Be wary though, some URLs may not work or produce broken results. Better stick with caching blog posts and downloads. 
		Only HTML files may be cached. Do not attempt to cache images or, say, torrent files.
		Also, this cache never expires. To force cache reload, delete files from your CACHE_STATIC_DIR (usually named 'static').
		Tip: use 'main' to cache site title page.
		
		Example:
		$static_array = array ( 'read/sample-category-1/post-title.html', 'search/blog_tag/test+tag.html' );
	*/
	$static_array = array ();
	
	
	
	preg_match ( "#". preg_quote ( URL ) ."/(.*)\$#", $_SERVER [ 'HTTP_HOST' ] . $_SERVER [ 'REQUEST_URI' ], $m );
	$url = $m [ 1 ];
	if ( preg_match ( "#^\?(.*)\$#", $url, $m ) ) $url = $m [ 1 ];
	if ( preg_match ( "#^(.*)\?sessid=.*\$#", $url, $m ) ) $url = $m [ 1 ];
	
	if ( $url == null ) $url = 'main';
	
	if ( in_array ( $url, $static_array ) )
	{
		# Check whether static copy exists
		$static_fname = str_replace ( '/', '.', $url );
		if ( substr ( $static_fname, -5 ) != '.html' ) $static_fname .= '.html';
		if ( file_exists ( CACHE_STATIC_DIR .'/'. $static_fname ) )
		{
			header ( 'location: http://'. CACHE_STATIC_URL .'/'. $static_fname );
			die ();
		}
		else 
		{
			define ( 'CACHE_STATIC', CACHE_STATIC_DIR .'/'. $static_fname );	
		}
	}
	else 
	{
		define ( 'CACHE_STATIC', null );	
	}

	
	unset ( $url );
	unset ( $m );
	unset ( $static_array );
	unset ( $static_fname );
?>