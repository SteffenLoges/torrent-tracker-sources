{* Smarty *}
{*<?php die(); ?>*}
<p>
	{t k="tpl_rss_choose"}:<br/><br/>
	{if $smarty.const.FUNC_BLOG}<a href="{link url="rss/blog.xml"}">{t k="tpl_rss_blog"}</a> ({t k="tpl_rss_readers" a=$readers.blog})<br/>{/if}
	{if $smarty.const.FUNC_DOWNLOADS}<a href="{link url="rss/downloads.xml"}">{t k="tpl_rss_downloads"}</a> ({t k="tpl_rss_readers" a=$readers.downloads})<br/>{/if}
	{if $smarty.const.FUNC_BLOG}<a href="{link url="rss/blog_comments.xml"}">{t k="tpl_rss_blog_comments"}</a> ({t k="tpl_rss_readers" a=$readers.blog_comments})<br/>{/if}
	{if $smarty.const.FUNC_DOWNLOADS}<a href="{link url="rss/download_comments.xml"}">{t k="tpl_rss_downloads_comments"}</a> ({t k="tpl_rss_readers" a=$readers.download_comments})<br/>{/if}
</p>