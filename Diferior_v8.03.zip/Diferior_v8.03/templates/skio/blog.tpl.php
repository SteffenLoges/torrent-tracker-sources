{* Smarty *}
{*<?php die(); ?>*}

{section name="p" loop=$posts}
	{if !isset($start_page) || $posts[p].b=='b'}
		{assign var="readall" value="read/`$posts[p].lid`/`$posts[p].plid`.html"|link}
		{assign var="readall_comments" value="read/`$posts[p].lid`/`$posts[p].plid`.html/#comments"|link}
	{else}
		{assign var="readall" value="file/`$posts[p].lid`/`$posts[p].sub_lid`/`$posts[p].plid`.html"|link}
		{assign var="readall_comments" value="file/`$posts[p].lid`/`$posts[p].sub_lid`/`$posts[p].plid`.html/#comments"|link}
	{/if}
	
	{if $posts[p].comments>0}
		{if $posts[p].comments%10==1}
			{assign var="comments_str" value="tpl_comments_s"|translate:$posts[p].comments}
		{elseif $posts[p].comments%10==0 || ( $posts[p].comments > 10 && $posts[p].comments < 20 )}
			{assign var="comments_str" value="tpl_comments_p1"|translate:$posts[p].comments}
		{else}
			{assign var="comments_str" value="tpl_comments_p2"|translate:$posts[p].comments}
		{/if}
	{else}
		{assign var="comments_str" value="tpl_comments_no"|translate}
	{/if}
	
	<div class="post_holder{if isset ( $start_page ) && $posts[p].b=='d'} post_holder_dl{/if}" id="post_container">
		<div class="pholder">
		<div class="post_header{if isset ( $start_page ) && $posts[p].b=='d'} post_header_dl{/if}">
			{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $posts[p].b=='d' && $posts[p].info_hash!=null}{img src="`$imurl`dl_torrent_small.gif" alt="BT" onmouseover="javascript:window.status='Torrent'" onmouseout="javascript:window.status=''"}{/if} 
			<a href="{$readall}">{$posts[p].header|escape:"html"|quotes}</a>
		</div>
		<div class="post_subheader">{$posts[p].subheader|escape:"html"|quotes}</div>
		<div class="post_info">
			{assign var="cat_escaped" value=$posts[p].name|escape:"html"}
			{if !isset($start_page) || $posts[p].b=='b'}
				{img src="`$imurl`cat.gif" alt=""} {t k="tpl_blog_category"}: <a href="{link url="cat/`$posts[p].lid`"}">{$cat_escaped}</a>
				{img src="`$imurl`poster.gif" alt="tpl_blog_author"|translate} <a href="{link url="user/v/`$posts[p].author`"}">{$posts[p].author}</a>
			{else}
				{assign var="subcat_escaped" value=$posts[p].sub_name|escape:"html"}
				{img src="`$imurl`cat.gif" alt=""} {t k="tpl_blog_category"}: <a href="{link url="downloads/`$posts[p].lid`"}">{$cat_escaped}</a> &#187; <a href="{link url="downloads/`$posts[p].lid`/`$posts[p].sub_lid`"}">{$subcat_escaped}</a>
				{img src="`$imurl`poster.gif" alt="tpl_blog_dlauthor"|translate}
				{if $posts[p].anonymous==1}
					<i>{t k="tpl_blog_anonymous"}</i>
				{else}
					<a href="{link url="user/v/`$posts[p].author`"}">{$posts[p].author}</a>
				{/if}
				{* 
					This can be uncommented to enable real quick downloads editing
					{if isset($smarty.session.logged) && $smarty.session.logged===true && ( $smarty.session.user==$posts[p].author || $smarty.session.permissions.edit_downloads==1 )}
						<span style="font-size: 75%">( <a href="{link url="upload/edit/`$posts[p].id`"}">{t k="tpl_blog_edit_download"}</a> )</span>
					{/if}
				*}
			{/if}
			{img src="`$imurl`date.gif" alt="@"} <i>{$posts[p].posted|date_format:"%y %m %d - %H:%M:%S"}</i>
			{if $posts[p].updated!=0}, <span>{t k="tpl_blog_updated"} <i>{$posts[p].updated|date_format:"%y %m %d - %H:%M:%S"}</i></span>{/if}
		</div>
		<div class="post_content{if isset ( $start_page ) && $posts[p].b=='d'} post_content_dl{/if}" id="preview_box">
		{if !isset($start_page) || $posts[p].b=='b'}
			{assign var="search_type" value="blog_tag"}
			<p>
				{$posts[p].content|parse_post:$posts[p].lid:$posts[p].plid:$posts[p].parse_html:false:true:$posts[p].id:false:'p':$readall}
			</p>
		{else}
			{assign var="search_type" value="downloads_tag"}
			{if stripos ( $posts[p].content, '[break]' ) !== false }
				{assign var="shorten" value=true}
			{else}
				{assign var="shorten" value=false}
			{/if}
			{$posts[p].content|parse_post:$posts[p].lid:$posts[p].plid:$posts[p].parse_html:false:$shorten:$posts[p].id:false:null:$readall}
		{/if}
		</div>
		<div class="post_foot">
			{if !isset($start_page) || $posts[p].b=='b'}{img src="`$imurl`read_small.gif" alt="-"}<a href="{$readall}">{t k="tpl_blog_read_all"}{else}{img src="`$imurl`download_small.gif" alt="-"}<a href="{$readall}">{t k="tpl_blog_download"}{/if}</a>
			{img src="`$imurl`comment_small.gif" alt="-"}<a href="{$readall_comments}">{$comments_str}</a>
		</div>
		{if $smarty.const.FUNC_TAGS && !empty($posts[p].tags)}
			<div class="post_tags">
				{section name="tags" loop=$posts[p].tags}
					<a href="{link url="search/`$search_type`/`$posts[p].tags[tags]`"}">{$posts[p].tags[tags]}</a>{if !$smarty.section.tags.last}, {/if}
				{/section}
			</div>
		{/if}
		</div>
		<div class="post_foot_rounded"></div>
	</div>
{sectionelse}
	<p>{t k="tpl_blog_no_messages"}</p><br/>
{/section}

{if $page_count>0}
	{assign var="pages" value=$post_count/$page_count|ceil}
	{if $pages > 1 }
	{if !isset ( $start_page )}
		{assign var="pfx" value="cat/`$cat`"}
	{else}
		{assign var="pfx" value="main/all"}
	{/if}
		<div class="paging">
		{if $page > 1}<a href="{link url="$pfx/page`$page-1`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
		{assign var="paging" value=$page|paging:$pages:3:10}
		{foreach from=$paging item=curr_page}
			{if $curr_page != 'sep'}
				{if $curr_page != $page}
					<a href="{link url="$pfx/page`$curr_page`"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
				{else}
					<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
				{/if}
			{else}...{/if} 
		{/foreach}
		{if $page < $pages}<a href="{link url="$pfx/page`$page+1`"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
		</div>
	{/if}	
{/if}