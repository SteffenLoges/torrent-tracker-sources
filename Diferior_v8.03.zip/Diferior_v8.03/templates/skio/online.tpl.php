{* Smarty *}
{*<?php die(); ?>*}
{assign var="template_name" value="skio"}
{php}
	header ( 'Content-Type: text/html; charset=utf-8' );
	header ( 'Cache-Control: no-store, no-cache, must-revalidate' );
{/php}
{assign var="smurl" value="http://`$smarty.const.URL`/"}
{assign var="rsurl" value="`$smurl`tpl_resources/`$template_name`/"}

<html>
	<head>
		<style type="text/css" media="all">@import "{$rsurl}style/online.css";</style>
		<script src="{$rsurl}scripts/javascript.js" type="text/javascript"></script>
		<title>Online</title>
		<script language="JavaScript">
			{literal}
			function open(url)
			{
				opener.location.href=url;
				window.close();
			}
			{/literal}
		</script>
	</head>
	<body onBlur="window.close()">
		
		<div class="top_rounded">
			<span class="fl_left">{t k="tpl_online_user"}</span>
			<span class="fl_right">{t k="tpl_online_last_action"}</span>
		</div>
		
		<div class="middle">
			{section name="onl" loop=$users}
				{if $users[onl].logged}
					<div class="entry">
						<span class="fl_left"><a href="{link url="user/v/`$users[onl].user`"}" rel="external">{$users[onl].user}</a></span>
						<span class="fl_right">{$users[onl].lastaction}</span>
					</div>
				{else}
					<div class="entry">
						<span class="fl_left"><span style="font-style: italic; color: #bbd">{t k="tpl_online_anonymous"}</span></span>
						<span class="fl_right"><span style="font-style: italic; color: #bbd">{$users[onl].lastaction}</span></span>
					</div>
				{/if}
			{/section}
		</div>
		
		<div class="bot_rounded"></div>
		
	</body>
</html>