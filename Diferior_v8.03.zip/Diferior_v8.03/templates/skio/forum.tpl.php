{* Smarty *}
{*<?php die(); ?>*}

{if $op == null}
	<div class="forum_holder">
		{assign var="clid" value=null}
		{section name="f" loop=$boards}
			{if $boards[f].clid != $clid}
				<div class="forum_category">{$boards[f].cat}</div>
				{assign var="clid" value=$boards[f].clid}
				<div class="forum_board forum_board_first">
			{else}
				<div class="forum_board">
			{/if}
				<span class="new_icon">
					<a href="{link url="forum/board/`$boards[f].clid`/`$boards[f].flid`"}">
					{if $boards[f].newposts}
						{img src="`$imurl`forum/newposts.png" alt="+"}
					{else}
						{img src="`$imurl`forum/oldposts.png" alt="-"}
					{/if}
					</a>
				</span>
				<span class="title">
					<a href="{link url="forum/board/`$boards[f].clid`/`$boards[f].flid`"}">{$boards[f].title}</a>
					<span>{$boards[f].description}</span>
				</span>
				<span class="stats">
					<span class="float">{t k="tpl_forum_threads"}: {$boards[f].threads}<br/>{t k="tpl_forum_posts"}: {$boards[f].posts}</span>
				</span>
				<span class="lastpost">
					{if $boards[f].last_thread!=null}
						<a href="{link url="forum/thread/`$boards[f].clid`/`$boards[f].flid`/`$boards[f].last_tlid`"}">{$boards[f].last_thread|truncate:'40':'...':true:true|escape:"html"}</a><br/>
						{$boards[f].last_tstamp|date_format:"%y %m %d - %H:%M:%S"}<br/>
						<a href="{link url="user/v/`$boards[f].last_user`"}">{$boards[f].last_user}</a>
					{else}
						{t k="tpl_forum_last_message"}:<br/> &#8212;
					{/if}
				</span>
			</div>
		{sectionelse}
			<p>{t k="tpl_forum_no_boards"}</p>
		{/section}
	</div>

	
{elseif $op == 'board'}
	{if $err}
		<p>{t k="error_unknown"}</p>
	{else}
		<div class="forum_holder">
			<div class="forum_nav">
				<a href="{link url="forum"}">{$res.cat}</a> &#187; <a href="{link url="forum/board/`$args[2]`/`$args[3]`"}">{$res.title}</a>
			</div>
		
			{section name="t" loop=$threads}
				<div class="forum_board{if $smarty.section.t.first} forum_board_first{/if}">
					<span class="new_icon">
						{if $threads[t].newposts}{assign var="newposts" value="/p`$threads[t].posts`"}{else}{assign var="newposts" value=null}{/if}
						{if $threads[t].pinned==1}{assign var="pinned" value="_pinned"}{else}{assign var="pinned" value=null}{/if}
						{if $threads[t].closed==1}{assign var="locked" value="_locked"}{else}{assign var="locked" value=null}{/if}
						<a href="{link url="forum/thread/`$args[2]`/`$args[3]`/`$threads[t].tlid``$newposts`"}">
						{if $threads[t].newposts}
							{img src="`$imurl`forum/newposts`$pinned``$locked`.png" alt="+"}
						{else}
							{img src="`$imurl`forum/oldposts`$pinned``$locked`.png" alt="-"}
						{/if}
						</a>
					</span>
					<span class="title">
						<a href="{link url="forum/thread/`$args[2]`/`$args[3]`/`$threads[t].tlid``$newposts`"}">{$threads[t].title|escape:"html"}</a>
						<span>{$threads[t].description|escape:"html"}</span>
					</span>
					<span class="stats">
						<span class="float">{t k="tpl_forum_replies"}:<br/><b>{$threads[t].posts}</b></span>
					</span>
					<span class="lastpost">
						{t k="tpl_forum_last_message"}:<br/>
						{$threads[t].last_tstamp|date_format:"%y %m %d - %H:%M:%S"}<br/>
						<a href="{link url="user/v/`$threads[t].last_user`"}">{$threads[t].last_user}</a>
					</span>
				</div>
			{sectionelse}
				<p>{t k="tpl_forum_board_empty"}</p>
			{/section}
			
			<div class="forum_nav forum_nav_bottom">
				<a href="{link url="forum/newthread/`$res.id`"}">{t k="tpl_forum_newthread"}</a>
			</div>
		</div>
		
		{assign var="pages" value=$post_count/$page_count|ceil}
		{if $pages > 1 }
			{assign var="pfx" value="forum/board/`$args[2]`/`$args[3]`"}
			<div class="paging">
			{if $page > 1}<a href="{link url="$pfx/page`$page-1`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
			{assign var="paging" value=$page|paging:$pages:3:10}
			{foreach from=$paging item=curr_page}
				{if $curr_page != 'sep'}
					{if $curr_page != $page}
						<a href="{link url="$pfx/page`$curr_page`"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
					{else}
						<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
					{/if}
				{else}...{/if} 
			{/foreach}
			{if $page < $pages}<a href="{link url="$pfx/page`$page+1`"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
			</div>
		{/if}	
	{/if}

	
{elseif $op == 'thread'}
	{if $err}
		<p>{t k="error_unknown"}</p>
	{else}
		{if isset($args[5]) && preg_match("#^p([0-9]+)\$#",$args[5])}
			<script type="text/javascript">if (location.href.search(/#p[0-9]+$/)==-1) location.href='#{$args[5]}'</script>
		{/if}
	
		{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.forum_moderator}
			<form id="del_comment_form" action="{link url="forum/moderate/`$res.id`/delete_replies"}" method="post">
		{/if}
		
		<div class="comments_holder fl_left">
		
		<div class="forum_nav forum_comments_nav">
			<a href="{link url="forum"}">{$res.cat}</a> &#187; <a href="{link url="forum/board/`$args[2]`/`$args[3]`"}">{$res.forum}</a> &#187; <a href="{link url="forum/thread/`$args[2]`/`$args[3]`/$args[4]"}">{$res.title|truncate:'40':'...':true:true|escape:"html"}</a>
		</div>
		
		{section name="p" loop=$posts}
			{if !isset($smarty.session.preferences) || $smarty.session.preferences.forum_posts_dir==0}
				{math equation="iteration+(page_count*(page-1))" iteration=$smarty.section.p.iteration page_count=$page_count page=$page assign="p_no"}
			{else}
				{math equation="tot-(iteration+(page_count*(page-1)))" tot=`$post_count+1` iteration=$smarty.section.p.iteration page_count=$page_count page=$page assign="p_no"}
			{/if}
			<div class="comment_start">
				<div class="comment_inner">
					<a name="p{$p_no}"></a>
					<div class="comment_left">
						<div class="comment_avatar">
							{if $posts[p].pr_avatar!=null}
								{img src="`$posts[p].pr_avatar`" alt="tpl_comments_avatar"|translate}<br/>
							{/if}
						</div>
						<div class="comment_info">
							{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false && ( $posts[p].downloaded!=0 || $posts[p].uploaded!=0 ) }
								{img src="`$imurl`userinfo/downloaded.gif" alt="Dl"} {$posts[p].downloaded|format_size}<br/>
								{img src="`$imurl`userinfo/uploaded.gif" alt="Ul"} {$posts[p].uploaded|format_size}<br/>
								{img src="`$imurl`userinfo/ratio.gif" alt="R"} 
								{if $posts[p].downloaded==0}&#8734;{else}{$posts[p].uploaded/$posts[p].downloaded|string_format:"%.2f"|colorize:1}{/if}<br/><br/>
							{/if}
							
							{if $smarty.const.FUNC_BLOG && $posts[p].blogposts!=0}{t k="tpl_comments_blogposts"}: {$posts[p].blogposts}<br/>{/if}							
							{if $smarty.const.FUNC_DOWNLOADS && $posts[p].downloadposts!=0}{t k="tpl_comments_downloadposts"}: {$posts[p].downloadposts}<br/>{/if}
							{if $posts[p].comments!=0}{t k="tpl_comments_comments"}: {$posts[p].comments}<br/>{/if}
							{if $posts[p].forumposts!=0}{t k="tpl_comments_forumposts"}: {$posts[p].forumposts}<br/>{/if}
							{if $posts[p].banned==1}{img src="`$imurl`userinfo/banned.gif" alt="!"}<br/>{elseif $posts[p].warned==1}{img src="`$imurl`userinfo/warning.gif" alt="!"}<br/>{/if}
							
							{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.forum_moderator}
								<br/><br/><input type="checkbox" name="delcomm[]" value="{$posts[p].id}" style="width: auto; height: auto" /> <span style="font-size: 12px;">{t k="tpl_comments_delmark"}</span>
							{/if}
						</div>
					</div>
					<div class="comment_right">
						<div class="comment_author">
							<a href="{link url="user/v/`$posts[p].author`"}">{$posts[p].author}</a> ({get_user_status info=$posts[p]}) <span>@ {$posts[p].tstamp|date_format:"%y %m %d - %H:%M:%S"}
							{if $posts[p].edit_tstamp!=0}({t k="tpl_forum_thread_edited" a=$posts[p].edit_tstamp|date_format:"%y %m %d - %H:%M:%S"}){/if}
							</span>
						</div>
						{$posts[p].content|parse_post:'forum':'forum'}
					</div>
					<div class="comment_bottom">
						{if isset($smarty.session.logged) && $smarty.session.logged && isset($smarty.session.permissions)}
							{if strtolower($posts[p].author)==strtolower($smarty.session.user) || $smarty.session.permissions.forum_moderator==1 }
								<a href="{link url="forum/reply/`$res.id`/e`$posts[p].id`/`$p_no`"}">{t k="tpl_forum_thread_edit"}</a>
							{/if}
							<a href="{link url="forum/reply/`$res.id`/q`$posts[p].id`"}">{t k="tpl_forum_thread_quote"}</a>
						{/if}
					</div>
				</div>
			</div>
		{sectionelse}
			<p>{t k="tpl_forum_thread_empty"}</p>
		{/section}
		
			<div class="forum_nav forum_comments_nav_bottom">
				{if $res.closed==1 && (!isset($smarty.session.permissions) || $smarty.session.permissions.forum_moderator!=1)}
					<a href="#" onclick="return false;">{t k="tpl_forum_thread_locked"}</a>
				{else}
					<a href="{link url="forum/reply/`$res.id`"}">{t k="tpl_forum_write_reply"}</a>
				{/if}
			</div>
		</div>
		
		{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.forum_moderator}
			</form>
		{/if}	
		
		{if $pages > 1 }
			{assign var="pfx" value="forum/thread/`$args[2]`/`$args[3]`/`$args[4]`"}
			<div class="paging">
			{if $page > 1}<a href="{link url="$pfx/page`$page-1`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
			{assign var="paging" value=$page|paging:$pages:3:10}
			{foreach from=$paging item=curr_page}
				{if $curr_page != 'sep'}
					{if $curr_page != $page}
						<a href="{link url="$pfx/page`$curr_page`"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
					{else}
						<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
					{/if}
				{else}...{/if} 
			{/foreach}
			{if $page < $pages}<a href="{link url="$pfx/page`$page+1`"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
			</div>
		{/if}	
		
		{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.forum_moderator && $res.posts > 0}
			<br/><br/>
			<div class="forum_nav forum_comments_nav forum_nav_mod">
				<script language="JavaScript">
				{literal}
					function show_mod_banner ( obj )
					{
						document.getElementById('mod_banner').style.display='block';
						document.getElementById('mod_banner_link').style.display='none';
					}
				{/literal}
				</script>
				<a href="javascript:show_mod_banner();" id="mod_banner_link">{t k="tpl_forum_mod_link"}</a>
				<div id="mod_banner">
					<a href="#" onclick="document.getElementById('del_comment_form').submit();return false;">{t k="tpl_forum_mod_delmsg"}</a>
					{if $res.closed==1}
						<a href="{link url="forum/moderate/`$res.id`/open"}">{t k="tpl_forum_mod_open"}</a>
					{else}
						<a href="{link url="forum/moderate/`$res.id`/close"}">{t k="tpl_forum_mod_close"}</a>
					{/if}
					{if $res.pinned==1}
						<a href="{link url="forum/moderate/`$res.id`/unpin"}">{t k="tpl_forum_mod_unpin"}</a>
					{else}
						<a href="{link url="forum/moderate/`$res.id`/pin"}">{t k="tpl_forum_mod_pin"}</a>
					{/if}
					<a href="{link url="forum/moderate/`$res.id`/delete"}">{t k="tpl_forum_mod_delete"}</a>
				</div>
			</div>
		{/if}
	{/if}
	

{elseif $op == 'newthread'}
	{if $args[3] != 2}
		{if $err!=false}
			<div class="big_message big_message_err">{$err}</div>
		{else}
			<form action="{link url="forum/newthread/$args[2]/2"}" method="post" class="reg_form">
				<div class="box">
					<span>{t k="tpl_forum_thread_name"}:</span> <input type="text" name="name" maxlength="70" value="" /><br/>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_forum_thread_description"}:</span> <input type="text" name="description" maxlength="150" value="" /><br/>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_forum_thread_message"}:</span><br/>
					<textarea name="message" id="msg" class="forum_textarea" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);"></textarea>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<div class="smilies">
						{foreach name="smilies" key=k item=v from=$smilies}
							<a href="javascript:add_bbcode(' {$k|escape:'javascript'} ','msg')">{img src="`$imurl`smilies/`$v`.gif" alt="`$k`"}</a>
						{/foreach}
					</div>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<input type="submit" value="{t k="tpl_forum_thread_submit"}" class="submit" />
				</div>
				<div class="form_foot_rounded"></div>
			</form>
		{/if}
	{else}
		{if $aflood<=0}
			{if $err!=false}
				<p>{$err}</p>
			{else}
				<p>{t k="error_unknown"} {errno}</p>
			{/if}
		{else}
			<p>{t k="tpl_forum_thread_aflood" a=$aflood}<br/>
			<form action="{link url="forum/newthread/$args[2]/2"}" method="post">
				<input type="hidden" name="name" value="{$name_p|escape:"html"}" />
				<input type="hidden" name="description" value="{$description_p|escape:"html"}" />
				<input type="hidden" name="message" value="{$message_p|escape:"html"}" />
				<input type="submit" value="{t k="tpl_forum_thread_aflood_refresh"}" class="fcontrol_submit" />
			</form>
			</p>
		{/if}
	{/if}
	
	
{elseif $op == 'reply'}
	{if $args[3] != 2}
		{if $err!=false}
			<div class="big_message big_message_err">{$err}</div>
		{else}
			{if !isset($edit_post)}
				{assign var="action_url" value="forum/reply/$args[2]/2"|link}
			{else}
				{assign var="action_url" value="forum/edit/`$args[2]`/`$args[3]`/`$args[4]`"|link}
			{/if}
			<form action="{$action_url}" method="post" class="reg_form">
				<div class="box">
					<span>{t k="tpl_forum_reply_message"}:</span><br/>
					<textarea name="message" id="msg" class="forum_textarea" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);">{if isset($quote_post)}{$quote_post.content}{/if}</textarea>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<div class="smilies">
						{foreach name="smilies" key=k item=v from=$smilies}
							<a href="javascript:add_bbcode(' {$k|escape:'javascript'} ','msg')">{img src="`$imurl`smilies/`$v`.gif" alt="`$k`"}</a>
						{/foreach}
					</div>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<input type="submit" value="{t k="tpl_forum_reply_submit"}" class="submit" />
				</div>
				<div class="form_foot_rounded"></div>
			</form>
		{/if}
	{else}
		{if $aflood<=0}
			{if $err!=false}
				<p>{$err}</p>
			{else}
				{if $closed}
					<p>{t k="tpl_forum_reply_closed"}</p>
				{else}
					<p>{t k="error_unknown"} {errno}</p>
				{/if}
			{/if}
		{else}
			<p>{t k="tpl_forum_reply_aflood" a=$aflood}<br/>
			<form action="{link url="forum/reply/$args[2]/2"}" method="post">
				<input type="hidden" name="message" value="{$message_p|escape:"html"}" />
				<input type="submit" value="{t k="tpl_forum_reply_aflood_refresh"}" class="fcontrol_submit" />
			</form>
			</p>
		{/if}
	{/if}	
	
	
{elseif $op == 'edit'}
	{if $err}
		<p>{t k="tpl_forum_edit_err"}</p>
	{else}
		<p>{t k="tpl_forum_edit_succ"}</p>
	{/if}
	
	
{elseif $op == 'moderate'}
	{if $args[4] != 2}
		{if $err!=false}
			<div class="big_message big_message_err">{$err}</div>
		{else}
			<form action="{link url="forum/moderate/`$args[2]`/`$args[3]`/2"}" method="post" class="reg_form">
				<div class="box">
					<span>{t k="tpl_forum_moderate_action"}:</span> <i class="fl_right">{$mod_action}</i><br/>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<input type="submit" value="{t k="tpl_forum_moderate_submit"}" class="submit" />
				</div>
				<div class="form_foot_rounded"></div>
				{if $args[3]=='delete_replies' && isset($smarty.post.delcomm)}
					{foreach name="delcomm" key=k item=v from=$smarty.post.delcomm}
						<input type="hidden" name="delcomm[]" value="{$v}"/>
					{/foreach}
				{/if}
			</form>
		{/if}
	{else}
		{if $args[3]=='delete_replies'}
			{if $res>0}
				<p>{t k="tpl_forum_mod_delmsg_succ"}</p>
			{else}
				<p>{t k="tpl_forum_mod_delmsg_err"} {errno}</p>
			{/if}
		{elseif $args[3]=='open'}
			{if $res>0}
				<p>{t k="tpl_forum_mod_open_succ"}</p>
			{else}
				<p>{t k="tpl_forum_mod_open_err"} {errno}</p>
			{/if}
		{elseif $args[3]=='close'}
			{if $res>0}
				<p>{t k="tpl_forum_mod_close_succ"}</p>
			{else}
				<p>{t k="tpl_forum_mod_close_err"} {errno}</p>
			{/if}
		{elseif $args[3]=='unpin'}
			{if $res>0}
				<p>{t k="tpl_forum_mod_unpin_succ"}</p>
			{else}
				<p>{t k="tpl_forum_mod_unpin_err"} {errno}</p>
			{/if}
		{elseif $args[3]=='pin'}
			{if $res>0}
				<p>{t k="tpl_forum_mod_pin_succ"}</p>
			{else}
				<p>{t k="tpl_forum_mod_pin_err"} {errno}</p>
			{/if}
		{elseif $args[3]=='delete'}
			{if $res>0}
				<p>{t k="tpl_forum_mod_delete_succ"}</p>
			{else}
				<p>{t k="tpl_forum_mod_delete_err"} {errno}</p>
			{/if}
		{/if}
	{/if}	

	
{/if}