{* Smarty *}
{*<?php die(); ?>*}
{if $err!==false}
	{if $err===true}
		<p>{t k="error_unknown"}</p>
	{else}
		<p>{$err}</p>
	{/if}
{else}

	{if isset($args[1]) && $args[1]!='downloads' && $args[1]!='downloads_tag'}
		<div class="search_results_holder">
	{/if}
	
		{assign var="start" value=$page*$smarty.const.SEARCH_RESULTS-$smarty.const.SEARCH_RESULTS}
		{section name="res" loop=$search start=$start max=$smarty.const.SEARCH_RESULTS}
				{if $args[1]=='blog' || $args[1]=='blog_tag'}
					<div class="item">
						<div class="header"><a href="{link url="read/`$search[res].lid`/`$search[res].plid`"}">{$search[res].header|escape:"html"|quotes}</a></div>
						{if $search[res].subheader!=null}
							<div class="subheader">{$search[res].subheader|escape:"html"|quotes}</div>
						{/if}
						<div class="category"><a href="{link url="cat/`$search[res].lid`"}">{$search[res].name}</a></div>
						<div class="author">
							{t k="tpl_search_blog_author"} <a href="{link url="user/v/`$search[res].author`"}">{$search[res].author}</a> @
							<i>{$search[res].posted|date_format:"%Y %m %d - %H:%M:%S"}</i>{if $search[res].updated!=0}, <span>{t k="tpl_search_blog_updated"} <i>{$search[res].updated|date_format:"%y %m %d - %H:%M:%S"}</i></span>{/if}
						</div>
					</div>
					
				{elseif $args[1]=='downloads' || $args[1]=='downloads_tag'}
					{if $smarty.section.res.first}
					
						<div class="dl_search search_dl_search">
							<form action="{link url="search"}" method="post" name="search">
							{section name="search" loop=$dl_cats}
								<div class="cat">
									{if isset($dl_cats[search].subcats)}
										{foreach from=$dl_cats[search].subcats key=k item=sub}
											<div class="item"><input type="checkbox" name="dlsub_{$sub.id}" {if in_array($sub.id,$dl_cats_arr)}checked="checked"{/if}/> <a href="{link url="downloads/`$dl_cats[search].lid`/`$sub.lid`"}">{$dl_cats[search].name} &#187; {$sub.name}</a></div>
										{/foreach}
									{/if}
								</div>
							{/section}
							<div class="inputs">
								<input type="text" value="{if $args[1]!='downloads_tag'}{$args[2]|urldecode|escape:"html"}{/if}" name="search" class="search_input" onfocus="javascript:emptydef(this,'{t k="tpl_index_search_phrase"}')" /><input type="submit" value="{t k="tpl_downloads_search_input"}" class="search_submit" />
							</div>
							<input type="hidden" name="type" value="downloads" />
							</form>
						</div>
						
						<div class="download_holder download_holder_small">
							<div class="dl_cat dl_top"><span class="left_glow"></span></div>
							<div class="dl_cat dl_top"><span class="right_glow" style="left: 1px"></span></div>
							{if $sort_desc}{assign var="diff_sort" value="asc"}{else}{assign var="diff_sort" value="desc"}{/if}
							{if $sort_type=='header'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="asc"}{/if}
							<div class="dl_header dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/header/`$sort_dir`"}" class="float">{t k="tpl_downloads_title"}</a></span></div>
							{if $sort_type=='type'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
							<div class="dl_type dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/type/`$sort_dir`"}" class="float">{t k="tpl_downloads_type"}</a></span></div>
							{if $sort_type=='seeders'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
							<div class="dl_seeders dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/seeders/`$sort_dir`"}" class="float">{t k="tpl_downloads_seeders"}</a></span></div>
							{if $sort_type=='leechers'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
							<div class="dl_leechers dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/leechers/`$sort_dir`"}" class="float">{t k="tpl_downloads_leechers"}</a></span></div>
							{if $sort_type=='fsize'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
							<div class="dl_size dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/fsize/`$sort_dir`"}" class="float">{t k="tpl_downloads_size"}</a></span></div>
							{if $sort_type=='comments'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
							<div class="dl_comments dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/comments/`$sort_dir`"}" class="float">{t k="tpl_downloads_comments"}</a></span></div>
							{if $sort_type=='user'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="asc"}{/if}
							<div class="dl_user dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page1/user/`$sort_dir`"}" class="float">{t k="tpl_downloads_author"}</a></span></div>
						</div>
					{/if}
					
					<div class="download_holder">
						<div class="dl_cat"><a href="{link url="downloads/`$search[res].lid`"}">{img src="`$imurl`dl_cat/`$search[res].lid`.gif" alt=""}</a>{*`$search[res].name`*}</div>
						<div class="dl_cat"><a href="{link url="downloads/`$search[res].lid`/`$search[res].sublid`"}">{img src="`$imurl`dl_cat/`$search[res].lid`_`$search[res].sublid`.gif" alt=""}</a>{*`$search[res].sub_name`*}</div>
						<div class="dl_header">
							<span class="fl_header">
								<div class="link">
									<a href="{link url="file/`$search[res].lid`/`$search[res].sublid`/`$search[res].plid`"}">{$search[res].header|escape:"html"|wordwrap:39:"\n":true|quotes}</a>
								</div>
								<span class="dl_descr">{$search[res].subheader|escape:"html"|quotes}</span>
							</span>
						</div>
						<div class="dl_type"><span class="float">
							{if $search[res].info_hash!=null}{img src="`$imurl`dl_torrent_small.gif" alt="BT" onmouseover="javascript:window.status='Torrent'" onmouseout="javascript:window.status=''"}{/if} 
							{if $search[res].dl_links!=null}{img src="`$imurl`dl_http_small.gif" alt="HTTP" onmouseover="javascript:window.status='HTTP'" onmouseout="javascript:window.status=''"}{/if}
						</span></div>
						{if $search[res].info_hash!=null}
							<div class="dl_seeders"><span class="float">{$search[res].seeders|colorize:$search[res].leechers}
						{else}
							<div class="dl_size"><span class="float">&#8212;
						{/if}</span></div>
						{if $search[res].info_hash!=null}
							<div class="dl_leechers"><span class="float">{$search[res].leechers}
						{else}
							<div class="dl_size"><span class="float">&#8212;
						{/if}</span></div>
						<div class="dl_size"><span class="float">{if $search[res].fsize!=0}{$search[res].fsize|format_size}{else}&#8212;{/if}</span></div>
						<div class="dl_comments">
							<span class="float">
								<a href="{link url="file/`$search[res].lid`/`$search[res].sublid`/`$search[res].plid`/#comments"}">{$search[res].comments}</a>
							</span>
						</div>
						<div class="dl_user"><span class="float">
							{if $search[res].anonymous==1}
								<i>{t k="tpl_downloads_anonymous"}</i>
							{else}
								<a href="{link url="user/v/`$search[res].user`"}">{$search[res].user}</a>
							{/if}
						</span></div>
					</div>
					
				
				{elseif $args[1]=='forums'}
					<div class="item">
						{if $search[res].post_no!=0}
							{assign var="post_no" value="p`$search[res].post_no`"}
						{else}
							{assign var="post_no" value="__"}
						{/if}
						<div class="header"><a href="{link url="forum/thread/`$search[res].clid`/`$search[res].flid`/`$search[res].tlid`/`$post_no`"}">{$search[res].title|escape:"html"}</a></div>
						{if $search[res].description!=null}
							<div class="subheader">{$search[res].description|escape:"html"}</div>
						{/if}
						<div class="category"><a href="{link url="forum"}">{$search[res].cat}</a> &#187; <a href="{link url="forum/board/`$search[res].clid`/`$search[res].flid`"}">{$search[res].board}</a></div>
						<div class="author">
							{t k="tpl_search_blog_author"} <a href="{link url="user/v/`$search[res].author`"}">{$search[res].author}</a> @
							<i>{$search[res].tstamp|date_format:"%Y %m %d - %H:%M:%S"}</i>{if $search[res].edit_tstamp!=0}, <span>{t k="tpl_search_blog_updated"} <i>{$search[res].edit_tstamp|date_format:"%y %m %d - %H:%M:%S"}</i></span>{/if}
						</div>
					</div>
					
					
				{else}
					<div class="item">
						<div class="header"><a href="{link url="user/v/`$search[res].name`"}">{$search[res].name}</a></div>
					</div>
					
				{/if}
				
		{sectionelse}
			<p>{t k="tpl_search_noresults"}</p>
		{/section}
		
		
	{if isset($args[1]) && $args[1]!='downloads' && $args[1]!='downloads_tag'}
		</div>
	{/if}
	
	
	{assign var="page_count" value=$smarty.const.SEARCH_RESULTS}
	{assign var="search_count" value=$search|@count}
	{assign var="pages" value=$search_count/$page_count|ceil}
	{if $pages > 1 }
		<div class="paging">
		{if $page > 1}<a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page`$page-1``$sort_str`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
		{assign var="paging" value=$page|paging:$pages:5:20}
		{foreach from=$paging item=curr_page}
			{if $curr_page != 'sep'}
				{if $curr_page != $page}
					<a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page`$curr_page``$sort_str`"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
				{else}
					<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
				{/if}
			{else}...{/if} 
		{/foreach}
		{if $page < $pages}<a href="{link url="search/`$args[1]`/`$args[2]`/`$dl_search_cats`/page`$page+1``$sort_str`"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
		</div>
	{/if}	
	
{/if}