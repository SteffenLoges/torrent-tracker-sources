{* Smarty *}
{*<?php die(); ?>*}
{if $err===false}
	<p>{t k="tpl_comment_succ"}</p>
	
{elseif is_array ( $err )}
	<p>{t k="tpl_errors"}:</p><br/>
	{section name="e" loop=$err}
		<p>&#186; {$err[e]}</p>
	{/section}
	
{else}
	<p>
		{if !$smarty.session.logged && !$smarty.const.FUNC_ANONYMOUS_COMMENTS}
			{t k="err_not_logged"}
		{else}
			{t k="tpl_comment_err"} {errno}
		{/if}
	</p>
{/if}