{* Smarty *}
{*<?php die(); ?>*}

{if $args[1] == null}
		<div class="forum_holder">
			<div class="forum_nav">
				<span class="bar_big">
					{math equation="total*100/limit*2" total=$smarty.session.userinfo.private_total limit=$smarty.const.PM_LIMIT assign=barwidth}
					{if $barwidth>200}{assign var="barwidth" value=200}{/if}
					<span class="bar_small" style="width: {$barwidth}px"></span>
				</span>
				<span class="bar_text" style="color: {$smarty.session.userinfo.private_total|colorize:$smarty.const.PM_LIMIT:true:true}">{t k="tpl_pm_list_usage" a="`$smarty.session.userinfo.private_total`|`$smarty.const.PM_LIMIT`"}</span>
			</div>
			
			{section name="p" loop=$pm}
				<div class="forum_board{if $smarty.section.p.first} forum_board_first{/if}">
					<span class="new_icon">
						<a href="{link url="pm/read/`$pm[p].id`}">
						{if $pm[p].unread}
							{img src="`$imurl`forum/newposts.png" alt="+"}
						{else}
							{img src="`$imurl`forum/oldposts.png" alt="-"}
						{/if}
						</a>
					</span>
					<span class="title">
						<a href="{link url="pm/read/`$pm[p].id`"}">{$pm[p].title|escape:"html"}</a>
					</span>
					<span class="stats">
						<span class="float"></span>
					</span>
					<span class="lastpost">
						{t k="tpl_pm_list_from"}:<br/>
						{$pm[p].tstamp|date_format:"%y %m %d - %H:%M:%S"}<br/>
						<a href="{link url="user/v/`$pm[p].from`"}">{$pm[p].from}</a>
					</span>
				</div>
			{sectionelse}
				<p>{t k="tpl_pm_list_empty"}</p>
			{/section}
			
			<div class="forum_nav forum_nav_bottom">
				<a href="{link url="pm/send"}">{t k="tpl_pm_list_newpm"}</a> <a href="{link url="pm/delete_all"}">{t k="tpl_pm_list_delete_all"}</a> 
			</div>
		</div>
		
		{assign var="pages" value=$smarty.session.userinfo.private_total/$page_count|ceil}
		{if $pages > 1 }
			{assign var="pfx" value="pm/list"}
			<div class="paging">
			{if $page > 1}<a href="{link url="$pfx/page`$page-1`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
			{assign var="paging" value=$page|paging:$pages:3:10}
			{foreach from=$paging item=curr_page}
				{if $curr_page != 'sep'}
					{if $curr_page != $page}
						<a href="{link url="$pfx/page`$curr_page`"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
					{else}
						<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
					{/if}
				{else}...{/if} 
			{/foreach}
			{if $page < $pages}<a href="{link url="$pfx/page`$page+1`"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
			</div>
		{/if}	
		

{elseif $args[1] == 'read'}
	{if $msg==false}
		<p>{t k="tpl_pm_read_err"} {errno}</p>
	{else}
		<div class="comments_holder fl_left">
			<div class="comment_start">
				<div class="comment_inner">
					<div class="comment_left">
						<div class="comment_avatar">
							{if $poster.pr_avatar!=null}
								{img src="`$poster.pr_avatar`" alt="tpl_comments_avatar"|translate}<br/>
							{/if}
						</div>
						<div class="comment_info">
							{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false && ( $poster.downloaded!=0 || $poster.uploaded!=0 ) }
								{img src="`$imurl`userinfo/downloaded.gif" alt="Dl"} {$poster.downloaded|format_size}<br/>
								{img src="`$imurl`userinfo/uploaded.gif" alt="Ul"} {$poster.uploaded|format_size}<br/>
								{img src="`$imurl`userinfo/ratio.gif" alt="R"} 
								{if $poster.downloaded==0}&#8734;{else}{$poster.uploaded/$poster.downloaded|string_format:"%.2f"|colorize:1}{/if}<br/><br/>
							{/if}
							
							{if $smarty.const.FUNC_BLOG && $poster.blogposts!=0}{t k="tpl_comments_blogposts"}: {$poster.blogposts}<br/>{/if}							
							{if $smarty.const.FUNC_DOWNLOADS && $poster.downloadposts!=0}{t k="tpl_comments_downloadposts"}: {$poster.downloadposts}<br/>{/if}
							{if $poster.comments!=0}{t k="tpl_comments_comments"}: {$poster.comments}<br/>{/if}
							{if $poster.forumposts!=0}{t k="tpl_comments_forumposts"}: {$poster.forumposts}<br/>{/if}
							{if $poster.banned==1}{img src="`$imurl`userinfo/banned.gif" alt="!"}<br/>{elseif $poster.warned==1}{img src="`$imurl`userinfo/warning.gif" alt="!"}<br/>{/if}
						</div>
					</div>
					<div class="comment_right">
						<div class="comment_author">
							<a href="{link url="user/v/`$poster.name`"}">{$poster.name}</a> ({get_user_status info=$poster}) <span>@ {$msg.tstamp|date_format:"%y %m %d - %H:%M:%S"}</span>
						</div>
						{$msg.content|parse_post:'forum':'forum'}
					</div>
					<div class="comment_bottom">
						<a href="{link url="pm/reply/`$args[2]`"}">{t k="tpl_pm_read_reply"}</a>
					</div>
				</div>
			</div>
		
			<div class="forum_nav forum_comments_nav_bottom">
				<a href="{link url="pm/reply/`$args[2]`"}">{t k="tpl_pm_read_reply"}</a> <a href="{link url="pm/delete/`$args[2]`"}">{t k="tpl_pm_read_delete"}</a>
			</div>
		</div>
	{/if}


{elseif $args[1] == 'send'}
	{if $args[3] != 2}
		<form action="{link url="pm/send/`$args[2]`/2"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_pm_send_recipient"}:</span> <input type="text" name="to" maxlength="32" value="{$sendto}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_pm_send_title"}:</span> <input type="text" name="title" maxlength="70" value="{if isset($reply)}{if substr($reply.title,0,4)!='RE: '}RE: {/if}{$reply.title}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_pm_send_message"}:</span><br/>
				<textarea name="message" id="msg" class="forum_textarea" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);"></textarea>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<div class="smilies">
					{foreach name="smilies" key=k item=v from=$smilies}
						<a href="javascript:add_bbcode(' {$k|escape:'javascript'} ','msg')">{img src="`$imurl`smilies/`$v`.gif" alt="`$k`"}</a>
					{/foreach}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_pm_send_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{else}
		{if $aflood<=0}
			{if $succ}
				<p>{t k="tpl_pm_send_succ"}</p>
			{else}
				<p>{t k="tpl_pm_send_err"} {errno}</p>
			{/if}
		{else}
			<p>{t k="tpl_pm_send_aflood" a=$aflood}<br/>
			<form action="{link url="pm/send/`$args[2]`/2"}" method="post">
				<input type="hidden" name="to" value="{$smarty.post.to|escape:"html"}" />
				<input type="hidden" name="title" value="{$smarty.post.title|escape:"html"}" />
				<input type="hidden" name="message" value="{$smarty.post.message|escape:"html"}" />
				<input type="submit" value="{t k="tpl_pm_send_aflood_refresh"}" class="fcontrol_submit" />
			</form>
			</p>
		{/if}
	{/if}

	
{elseif $args[1] == 'delete'}
	{if $args[3] != 2}
		<p>{t k="tpl_pm_delete_confirm" a="pm/delete/`$args[2]`/2"|link}</p>
	{else}
		{if $succ}
			<p>{t k="tpl_pm_delete_succ"}</p>
		{else}
			<p>{t k="tpl_pm_delete_err"} {errno}</p>
		{/if}
	{/if}

	
{elseif $args[1] == 'delete_all'}
	{if $args[2] != 2}
		<p>{t k="tpl_pm_delete_all_confirm" a="pm/delete_all/2"|link}</p>
	{else}
		{if $succ}
			<p>{t k="tpl_pm_delete_all_succ"}</p>
		{else}
			<p>{t k="tpl_pm_delete_all_err"} {errno}</p>
		{/if}
	{/if}


{/if}