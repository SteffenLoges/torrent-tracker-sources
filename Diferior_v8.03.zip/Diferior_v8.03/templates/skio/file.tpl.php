{* Smarty *}
{*<?php die(); ?>*}

{if $error!==false}
	{if $error===true}
		<p>{t k="error_unknown"}</p>
	{else}
		<p>{$error}</p>
	{/if}
{else}
	{if isset($args[4]) && preg_match("#^c([0-9]+)\$#",$args[4])}
		<script type="text/javascript">if (location.href.search(/#c[0-9]+$/)==-1) location.href='#{$args[4]}'</script>
	{/if}
	<script language="JavaScript">var banner_txt_expand='{t k="tpl_file_banner_expand"}'; var banner_txt_collapse='{t k="tpl_file_banner_collapse"}';</script>
	
	<div class="dl_holder">
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_title"}</div>
			<div class="dl_right">
				<b>{$file.header|escape:"html"|quotes}</b>
				{if $file.subheader!=null}
					<br/><span class="descr">{$file.subheader|escape:"html"|quotes}</span>
				{/if}
			</div>
		</div>
	
		{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $file.info_hash!=null}
			<div class="dl_box">
				<div class="dl_left">{t k="tpl_file_torrent"}</div>
				<div class="dl_right">
					<span class="fl_left">
						{img src="`$imurl`dl_torrent_small.gif" alt="BT"}
						<a href="{link url="torrents/`$file.lid`/`$file.sub_lid`/`$file.plid`.torrent"}">{"`$file.plid`.torrent"|truncate:70:'...':true:true}</a>
					</span>
					<span class="fl_right">( <a href="{link url="howto_torrents"}" rel="external">{t k="tpl_file_howto_torrents"}</a> )</span>
					{if isset($smarty.session.logged) && $smarty.session.logged && $file.fsize<=$smarty.const.BITLET_FSIZE}
						<span class="fl_right clear">
							{assign var="torrent_link" value="torrents/`$file.lid`/`$file.sub_lid`/`$file.plid`.torrent"|link}
							<script src="http://www.bitlet.org/javascripts/BitLet.js" type="text/javascript"></script>
							<a href="http://www.bitlet.org?torrent={$torrent_link|escape:"url"}" onclick="return BitLet.openDownloadFromAnchor(this);">{t k="tpl_file_bitlet"}</a> ( <a href="{link url="bitlet"}">?</a> )
						</span>
					{/if}
				</div>
			</div>
		{/if}
		 
		{if $smarty.const.FUNC_DOWNLOADS_HTTP && $file.dl_links!=null}
			<div class="dl_box">
				<div class="dl_left">{t k="tpl_file_http"}</div>
				<div class="dl_right">
					{if $dl_links_count>5}
						<div class="exp" style="font-size: 16px; height: 18px">{t k="tpl_file_http_links" a=$dl_links_count} ( <a href="javascript:exp_flist('http_list','http_link')" id="http_link">{t k="tpl_file_banner_expand"}</a> )</div>
						{math equation="(files)*line" files=$file.dl_links|@count line=19 assign="height"}
						<div id="http_list" style="{if $height>500}overflow: auto; height: 500px{else}height: {$height}px{/if}">
					{/if}
					{section name="links" loop=$file.dl_links}
						{assign var="url" value=$file.dl_links[links].0}
						{assign var="size" value=$file.dl_links[links].1}
						<div class="flist_file clear">
							{if !preg_match("#^\-\-+\$#", $url)}
								<span class="fl_left">{img src="`$imurl`dl_http_small.gif" alt="HTTP"} <a href="{$url}" rel="download">{$url|truncate:70:'...':true:true}</a></span>
								<span class="fl_right">{if $size!=0}{$size|format_size}{/if}</span>
								{*{if $smarty.section.links.last!=true}<br/>{/if}*}
							{else}
								{img src="`$imurl`mirror.gif" alt="--------------"}
							{/if}
						</div>
					{/section}
					{if $dl_links_count>5}
						</div>
					{/if}
				</div>
			</div>
		{/if}
		
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_timestamp"}{if $file.updated!=0}<br/>{t k="tpl_file_updated"}{/if}</div>
			<div class="dl_right">
				{$file.posted|date_format:"%Y %m %d - %H:%M:%S"}{if $file.updated!=0}<br/>{$file.updated|date_format:"%Y %m %d - %H:%M:%S"}{/if}
			</div>
		</div>
		
		{if $file.content != null}
			<div class="dl_box">
				<div class="dl_left">{t k="tpl_file_description"}</div>
				<div class="post_content dl_right">
					{$file.content|parse_post:$file.lid:$file.plid:false:false:false:null:false:null}
				</div>
			</div>
		{/if}
		
		{if $file.nfo != null && isset($smarty.session.permissions) && $smarty.session.permissions.view_nfo}
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_nfo"}</div>
			<div class="dl_right">
				<a href="{link url="nfo/`$file.nfo`.txt"}" rel="external">.txt</a> | <a href="{link url="nfo/`$file.nfo`.png"}" rel="external">.png</a> | <a href="{link url="nfo/`$file.nfo`.nfo"}" rel="external">.nfo</a>
			</div>
		</div>
		{/if}
		
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_category"}</div>
			<div class="dl_right">
				<a href="{link url="downloads/`$file.lid`"}">{$file.name}</a> &#187; <a href="{link url="downloads/`$file.lid`/`$file.sub_lid`"}">{$file.sub_name}</a>
			</div>
		</div>
		
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_author"}</div>
			<div class="dl_right">
				{if $file.anonymous==1}
					<i>{t k="tpl_file_anonymous"}</i>
					{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.see_anonymous==1}
						[<a href="{link url="user/v/`$file.user`"}">{$file.user}</a>]
					{/if}
				{else}
					<a href="{link url="user/v/`$file.user`"}">{$file.user}</a>
				{/if}
				{if isset($smarty.session.logged) && $smarty.session.logged===true && ( ( $smarty.session.user==$file.user || $smarty.session.permissions.edit_downloads==1 ) || ( $file.confirmed!=1 && $smarty.session.permissions.approve_downloads==1 ) )}
					( <a href="{link url="upload/edit/`$file.fid`"}">{t k="tpl_file_edit"}</a> )
				{/if}
			</div>
		</div>
		
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_comments"}</div>
			<div class="dl_right">
				<a href="#comments">{$file.comments}</a>
			</div>
		</div>
		
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_views"}</div>
			<div class="dl_right">
				+{$filecounter.today} / {$filecounter.total}
			</div>
		</div>
		
		{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $file.info_hash!=null}
			<div class="dl_box">
				<div class="dl_left">{t k="tpl_file_peers"}</div>
				<div class="dl_right">
					{assign var="leechers" value=$file.leechers}
					{assign var="seeders" value=$file.seeders}
					<div class="peer_exp">{t k="tpl_file_seeders"}: {$seeders|colorize:$leechers}
					{if $seeders>0 && $smarty.const.TRACKER_ANONYMOUS==false && $peers_no <= $smarty.const.TRACKER_PEER_MAX}
						{if $peers_no <= $smarty.const.TRACKER_PEER_PRE}
							( <a href="javascript:exp_flist('seed_list','seed_link')" id="seed_link">{t k="tpl_file_banner_expand"}</a> )</div>
							{math equation="files*line" files=$peers.seeders|@count line=19 assign="height"}
							<div id="seed_list" style="{if $height>500}overflow: auto; height: 500px{else}height: {$height}px{/if}">
								{section name="s" loop=$peers.seeders}
									<div class="flist_file">
										{if $file.anonymous==1 && $peers.seeders[s].name==$file.user}<i>{t k="tpl_file_anonymous"}</i>{else}<a href="{link url="user/v/`$peers.seeders[s].name`"}">{$peers.seeders[s].name}</a>{/if}
										( 
											{img src="`$imurl`userinfo/ratio_small.gif" alt="R"}
												{if $peers.seeders[s].downloaded==0}&#8734;{else}{$peers.seeders[s].uploaded/$peers.seeders[s].downloaded|string_format:"%.2f"|colorize:1}{/if} 
											{img src="`$imurl`userinfo/uploaded_small.gif" alt="Up"}
												{$peers.seeders[s].uploaded|format_size}		
											{img src="`$imurl`userinfo/downloaded_small.gif" alt="Dl"}
												{$peers.seeders[s].downloaded|format_size}		
										)
									</div>
								{/section}
						{else}
							( <a href="javascript:fetch_peers('seed',{$file.fid})" id="seed_link">{t k="tpl_file_banner_expand"}</a> )</div>
							<div id="seed_list" style="height: 18px; overflow: auto;">
								{img src="`$imurl`/wait.gif" alt="..."}
						{/if}
					{/if}
					</div>
					
					<div class="peer_exp">{t k="tpl_file_leechers"}: {$leechers} 
					{if $leechers>0 && $smarty.const.TRACKER_ANONYMOUS==false && $peers_no <= $smarty.const.TRACKER_PEER_MAX}
						{if $peers_no <= $smarty.const.TRACKER_PEER_PRE}
							( <a href="javascript:exp_flist('leech_list','leech_link')" id="leech_link">{t k="tpl_file_banner_expand"}</a> )</div>
							{math equation="files*line" files=$peers.leechers|@count line=19 assign="height"}
							<div id="leech_list" style="{if $height>500}overflow: auto; height: 500px{else}height: {$height}px{/if}">
								{section name="l" loop=$peers.leechers}
									<div class="flist_file">
										<a href="{link url="user/v/`$peers.leechers[l].name`"}">{$peers.leechers[l].name}</a>
										( 
											{img src="`$imurl`userinfo/ratio_small.gif" alt="R"}
												{if $peers.leechers[l].downloaded==0}&#8734;{else}{$peers.leechers[l].uploaded/$peers.leechers[l].downloaded|string_format:"%.2f"|colorize:1}{/if} 
											{img src="`$imurl`userinfo/uploaded_small.gif" alt="Up"}
												{$peers.leechers[l].uploaded|format_size}		
											{img src="`$imurl`userinfo/downloaded_small.gif" alt="Dl"}
												{$peers.leechers[l].downloaded|format_size}		
										)
									</div>
								{/section}
						{else}
							( <a href="javascript:fetch_peers('leech',{$file.fid})" id="leech_link">{t k="tpl_file_banner_expand"}</a> )</div>
							<div id="leech_list" style="height: 18px; overflow: auto;">
								{img src="`$imurl`/wait.gif" alt="..."}
						{/if}
					{/if}
					</div>
					
					
				</div>
			</div>
			
			<div class="dl_box">
				<div class="dl_left">{t k="tpl_file_completed"}</div>
				<div class="dl_right">
					{$file.completed}
				</div>
			</div>
		
			<div class="dl_box">
				{assign var="files_count" value=$file.files|@count}
				<div class="exp">{t k="tpl_file_flist" a=$files_count} ( <a href="javascript:exp_flist('flist','flist_link')" id="flist_link">{t k="tpl_file_banner_expand"}</a> )</div>
				{math equation="files*line" files=$files_count line=17 assign="height"}
				<div id="flist" style="{if $height>500}overflow: auto; height: 500px{else}height: {$height}px{/if}">
					{section name="flist" loop=$file.files}
						<div class="flist_file"><span class="fl_left">{$file.files[flist].0|truncate:70:'...':true:true}</span><span class="fl_right">{$file.files[flist].1|format_size}</span></div>
					{/section}
				</div>
			</div>
		{/if}
		
		<div class="dl_box">
			<div class="dl_left">{t k="tpl_file_size"}</div>
			<div class="dl_right">
				{if $file.fsize!=0}{$file.fsize|format_size}{else}&#8212;{/if}
			</div>
		</div>
		
		{if $smarty.const.FUNC_TAGS && !empty($file.tags)}
			<div class="dl_box dl_box_bot">
				<div class="dl_left">{t k="tpl_file_tags"}</div>
				<div class="dl_right">
					{section name="tags" loop=$file.tags}
						<a href="{link url="search/downloads_tag/`$file.tags[tags]`"}">{$file.tags[tags]}</a>{if !$smarty.section.tags.last}, {/if}
					{/section}
				</div>
			</div>
		{/if}
	</div>
	
	{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments}
		<form id="del_comment_form" action="{link url="comment/delete/d`$file.fid`"}" method="post">
	{/if}
	
	<div class="comments_holder fl_left">
		{include file="`$template_name`/output_comments.tpl.php" tot_comments=$file.comments}
	
		{if $pages > 1 }
			{assign var="pfx" value="file/`$file.lid`/`$file.sub_lid`/`$file.plid`"}
			<br/><div class="paging">
			{if $page > 1}<a href="{link url="$pfx/page`$page-1`/#comments"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
			{assign var="paging" value=$page|paging:$pages:3:10}
			{foreach from=$paging item=curr_page}
				{if $curr_page != 'sep'}
					{if $curr_page != $page}
						<a href="{link url="$pfx/page`$curr_page`/#comments"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
					{else}
						<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
					{/if}
				{else}...{/if} 
			{/foreach}
			{if $page < $pages}<a href="{link url="$pfx/page`$page+1`/#comments"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
			</div>
		{/if}
	</div>
	
	{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments}
		</form>
	{/if}	
	
	<div class="post_comment clear">
	<a name="post-comment"></a>
		<form id="comment_form" action="{link url="comment/d`$file.fid`"}" method="post">
			{t k="tpl_comments_write"}:<br/>
			{if $smarty.const.FUNC_ANONYMOUS_COMMENTS && (!isset($smarty.session.logged) || $smarty.session.logged===false)}
				<div class="anonymous">
					<div>
						<span class="fl_left">{t k="tpl_comments_username"}:</span>
							<input type="text" name="c_user" value="{if isset($smarty.cookies.comments_user) && $smarty.const.CACHE_STATIC==null}{$smarty.cookies.comments_user}{/if}" maxlength="20" />
					</div>
					<div>
						<span class="fl_left">{t k="tpl_comments_email"}:</span>
							<input type="text" name="c_email" value="{if isset($smarty.cookies.comments_email) && $smarty.const.CACHE_STATIC==null}{$smarty.cookies.comments_email}{/if}" maxlength="32" />
					</div>
					<div>
						{img src="captcha/s/`$smarty.now`.jpg"|link alt="tpl_user_register_captcha"|translate onclick="javascript:reload_image(this)"}
							<input type="text" name="captcha" value="" />
					</div>
				</div>
			{/if}
			<div class="post_comment_holder">
				<span class="holder">
					<textarea name="comment" id="comment" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);"></textarea>
				</span>
				<span class="smilies">
				{foreach name="smilies" key=k item=v from=$smilies}
					<a href="javascript:add_bbcode(' {$k|escape:'javascript'} ','comment')">{img src="`$imurl`smilies/`$v`.gif" alt="`$k`"}</a>
				{/foreach}
				</span>
				<input type="button" id="comment_button" value="{t k="tpl_comments_send"}" onclick="javascript:comment_submit({if $smarty.const.FUNC_ANONYMOUS_COMMENTS}true{else}false{/if})">
				<div id="comment_login" onclick="javascript:comment_warning()">
					{assign var="link_register" value="user/register"|link}
					{assign var="link_login" value="user/login"|link}
					{t k="tpl_comments_err_login" a="`$link_register`|`$link_login`"}
				</div>
			</div>
		</form>
	</div>	
	
	{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments && $file.comments > 0}
		<input type="button" value="{t k="tpl_comments_delete"}" style="width: auto; padding: 0 4px; margin-left: 80px" onclick="javascript:document.getElementById('del_comment_form').submit()" />
	{/if}
	
{/if}