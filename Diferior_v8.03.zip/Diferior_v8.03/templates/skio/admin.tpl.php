{* Smarty *}
{*<?php die(); ?>*}

{if $err}
	<p>{t k="error_unknown"}</p>
{else}

	{* Top admin menu *}
	<div class="admin_top{if $args[1]!=null} admin_top_small{/if}">
		<div><a href="{link url="admin/site"}"{if $args[1]=='site'} class="selected"{/if}>{img src="`$imurl`admincp/site.gif" alt=""}<b>{t k="tpl_admin_menu_site"}</b><span>{t k="tpl_admin_menu_site_desc"}</span></a></div>
		<div><a href="{link url="admin/blog"}"{if $args[1]=='blog'} class="selected"{/if}>{img src="`$imurl`admincp/blog.gif" alt=""}<b>{t k="tpl_admin_menu_blog"}</b><span>{t k="tpl_admin_menu_blog_desc"}</span></a></div>
		<div><a href="{link url="admin/downloads"}"{if $args[1]=='downloads'} class="selected"{/if}>{img src="`$imurl`admincp/downloads.gif" alt=""}<b>{t k="tpl_admin_menu_downloads"}</b><span>{t k="tpl_admin_menu_downloads_desc"}</span></a></div>
		<div><a href="{link url="admin/forum"}"{if $args[1]=='forum'} class="selected"{/if}>{img src="`$imurl`admincp/forum.gif" alt=""}<b>{t k="tpl_admin_menu_forum"}</b><span>{t k="tpl_admin_menu_forum_desc"}</span></a></div>
		<div><a href="{link url="admin/pm"}"{if $args[1]=='pm'} class="selected"{/if}>{img src="`$imurl`admincp/pm.gif" alt=""}<b>{t k="tpl_admin_menu_pm"}</b><span>{t k="tpl_admin_menu_pm_desc"}</span></a></div>
		<div><a href="{link url="admin/contact"}"{if $args[1]=='contact'} class="selected"{/if}>{img src="`$imurl`admincp/contact.gif" alt=""}<b>{t k="tpl_admin_menu_contact"}</b><span>{t k="tpl_admin_menu_contact_desc"}</span></a></div>
		<div><a href="{link url="admin/rss"}"{if $args[1]=='rss'} class="selected"{/if}>{img src="`$imurl`admincp/rss.gif" alt=""}<b>{t k="tpl_admin_menu_rss"}</b><span>{t k="tpl_admin_menu_rss_desc"}</span></a></div>
		<div><a href="{link url="admin/counters"}"{if $args[1]=='counters'} class="selected"{/if}>{img src="`$imurl`admincp/counters.gif" alt=""}<b>{t k="tpl_admin_menu_counters"}</b><span>{t k="tpl_admin_menu_counters_desc"}</span></a></div>
		<div><a href="{link url="admin/users"}"{if $args[1]=='users'} class="selected"{/if}>{img src="`$imurl`admincp/users.gif" alt=""}<b>{t k="tpl_admin_menu_users"}</b><span>{t k="tpl_admin_menu_users_desc"}</span></a></div>
		<div><a href="{link url="admin/caching"}"{if $args[1]=='caching'} class="selected"{/if}>{img src="`$imurl`admincp/caching.gif" alt=""}<b>{t k="tpl_admin_menu_caching"}</b><span>{t k="tpl_admin_menu_caching_desc"}</span></a></div>
		<div><a href="{link url="admin/template"}"{if $args[1]=='template'} class="selected"{/if}>{img src="`$imurl`admincp/template.gif" alt=""}<b>{t k="tpl_admin_menu_template"}</b><span>{t k="tpl_admin_menu_template_desc"}</span></a></div>
		<div><a href="{link url="admin/language"}"{if $args[1]=='language'} class="selected"{/if}>{img src="`$imurl`admincp/language.gif" alt=""}<b>{t k="tpl_admin_menu_language"}</b><span>{t k="tpl_admin_menu_language_desc"}</span></a></div>
		<div><a href="{link url="admin/other"}"{if $args[1]=='other'} class="selected"{/if}>{img src="`$imurl`admincp/other.gif" alt=""}<b>{t k="tpl_admin_menu_other"}</b><span>{t k="tpl_admin_menu_other_desc"}</span></a></div>
	</div>
	
	
		{if $args[1] == null}
		{elseif $args[1] == 'site'}
			{if $args[2]!=2}
				<form action="{link url="admin/site/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_site_title"}:</span> 
								<input type="text" name="title" maxlength="50" value="{$smarty.const.PAGE_NAME}" /><br/>
						<span>{t k="tpl_admin_site_slogan"}:</span> 
								<input type="text" name="slogan" maxlength="200" value="{$smarty.const.PAGE_SLOGAN}" /><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_site_timezone"}:</span> 
								<select name="timezone">
									{section name="tz" loop=$timezones}
										<option value="{$timezones[tz]}"{if $timezones[tz]==$smarty.const.DEFAULT_TIMEZONE} selected="selected"{/if}>{$timezones[tz]}</option>
									{/section}
								</select><br/>
						<div class="tip">{t k="tpl_admin_site_timezone_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_site_cron"}:</span> 
								<select name="cron">
									<option value="php"{if $smarty.const.SIMULATE_CRON} selected="selected"{/if}>{t k="tpl_admin_site_cron_php"}</option>
									<option value="system"{if !$smarty.const.SIMULATE_CRON} selected="selected"{/if}>{t k="tpl_admin_site_cron_system"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_site_cron_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
		{elseif $args[1] == 'blog'}
			{if $args[2]==null}
				<form action="{link url="admin/blog/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_blog_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_BLOG} selected="selected"{/if}>{t k="tpl_admin_blog_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_BLOG} selected="selected"{/if}>{t k="tpl_admin_blog_on_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_blog_on_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_blog_posts_perpage"}:</span> 
								<select name="blog_no">
									<option value="5"{if $smarty.const.BLOG_POSTS==5} selected="selected"{/if}>5</option>
									<option value="10"{if $smarty.const.BLOG_POSTS==10} selected="selected"{/if}>10</option>
									<option value="15"{if $smarty.const.BLOG_POSTS==15} selected="selected"{/if}>15</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_blog_posts_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_blog_watermark"}:</span> 
								<select name="watermark">
									<option value="1"{if $smarty.const.BLOG_WATERMARK} selected="selected"{/if}>{t k="tpl_admin_blog_watermark_enable"}</option>
									<option value="0"{if !$smarty.const.BLOG_WATERMARK} selected="selected"{/if}>{t k="tpl_admin_blog_watermark_disable"}</option>
								</select><br/>
						<span>{t k="tpl_admin_blog_watermark_width"}:</span> 
							<input type="text" name="watermark_width" maxlength="3" value="{$smarty.const.WATERMARK_MINWIDTH}" /><br/>
						<span>{t k="tpl_admin_blog_watermark_height"}:</span> 
							<input type="text" name="watermark_height" maxlength="3" value="{$smarty.const.WATERMARK_MINHEIGHT}" /><br/>
						<div class="tip">{t k="tpl_admin_blog_watermark_tip" a=$smarty.const.WATERMARK_PATH}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
				{if count($cats)>0}
					<br/><br/>
				
					<form action="{link url="admin/blog/edit"}" method="post" class="reg_form">
						<div class="box">
							{section name="c" loop=$cats}
								<div class="cat_item" id="ch_{$smarty.section.c.iteration}">
									<span>
										<input type="text" name="catname_{$cats[c].id}" maxlength="32" value="{$cats[c].name}" />
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<input type="button" value="{t k="tpl_admin_blog_up"}" onclick="javascript:cat_mvup({$smarty.section.c.iteration})" />
										<input type="button" value="{t k="tpl_admin_blog_down"}" onclick="javascript:cat_mvdn({$smarty.section.c.iteration})" />
									</span>
									<span class="right">
										<input type="checkbox" name="del_{$cats[c].id}" /> {t k="tpl_admin_blog_delcat"}
									</span>
									<input type="hidden" name="position_{$cats[c].id}" value="position_{$smarty.section.c.iteration}" />
									<br/>
								</div>
							{/section}
							<script language="JavaScript">var admin_cat_count={$smarty.section.c.iteration-1};</script>
						</div>
						<div class="spacer"></div>
						<div class="box">
							<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
						</div>
						<div class="form_foot_rounded"></div>
					</form>
				{/if}
				
				<br/><br/>
				
				<form action="{link url="admin/blog/create"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_blog_newcat"}:</span> 
								<input type="text" name="catname" maxlength="32" value="" /><br/>
						<div class="tip">{t k="tpl_admin_blog_newcat_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_blog_newcat_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
			{elseif $args[2]=='2' || $args[2]=='create'}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
				
			{elseif $args[2]=='edit'}
				{if $confirmed}
					<p>
						{if $succ}
							{t k="tpl_admin_succ"}
						{else}
							{t k="tpl_admin_err"}
						{/if}
					</p>
				{else}
					<form action="{link url="admin/blog/edit/2"}" method="post" name="hidden">
						{foreach key=k item=v from=$smarty.post}
						<input type="hidden" name="{$k}" value="{$v}" />
						{/foreach}
					</form>
					<p>{t k="tpl_admin_blog_edit_confirm" a="javascript:document.forms.hidden.submit()"}</p>
				{/if}
			{/if}		
			
			
		{elseif $args[1] == 'downloads'}
			{if $args[2]==null}
				<form action="{link url="admin/downloads/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_downloads_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_DOWNLOADS} selected="selected"{/if}>{t k="tpl_admin_downloads_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_DOWNLOADS} selected="selected"{/if}>{t k="tpl_admin_downloads_on_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_downloads_on_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_http"}:</span> 
								<select name="enable_http">
									<option value="1"{if $smarty.const.FUNC_DOWNLOADS_HTTP} selected="selected"{/if}>{t k="tpl_admin_downloads_http_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_DOWNLOADS_HTTP} selected="selected"{/if}>{t k="tpl_admin_downloads_http_disable"}</option>
								</select><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent"}:</span> 
								<select name="enable_torrent" onchange="tracker_choose(this.value,true)">
									<option value="1"{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_TYPE=='PHP'} selected="selected"{/if}>{t k="tpl_admin_downloads_torrent_integrated"}</option>
									<option value="2"{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_TYPE=='XBTT'} selected="selected"{/if}>{t k="tpl_admin_downloads_torrent_xbtt"}</option>
									<option value="3"{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_TYPE!='PHP' && $smarty.const.TRACKER_TYPE!='XBTT'} selected="selected"{/if}>{t k="tpl_admin_downloads_torrent_other"}</option>
									<option value="0"{if !$smarty.const.FUNC_DOWNLOADS_TORRENT} selected="selected"{/if}>{t k="tpl_admin_downloads_torrent_disable"}</option>
								</select><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_anonymous"}:</span> 
								<select name="enable_anonymous" id="anonymous">
									<option value="1"{if $smarty.const.TRACKER_ANONYMOUS} selected="selected"{/if}>{t k="tpl_admin_downloads_anonymous_enable"}</option>
									<option value="0"{if !$smarty.const.TRACKER_ANONYMOUS} selected="selected"{/if}>{t k="tpl_admin_downloads_anonymous_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_downloads_anonymous_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent_announce"}:</span> 
								<input type="text" name="announce" maxlength="255" value="{$smarty.const.TRACKER_URL}" id="announce" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_torrent_announce_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent_scrape"}:</span> 
								<input type="text" name="scrape" maxlength="255" value="{$smarty.const.SCRAPE_URL}" id="scrape" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_torrent_scrape_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_title"}:</span> 
								<select name="enable_title">
									<option value="1"{if $smarty.const.TITLE_DOWNLOADS} selected="selected"{/if}>{t k="tpl_admin_downloads_title_enable"}</option>
									<option value="0"{if !$smarty.const.TITLE_DOWNLOADS} selected="selected"{/if}>{t k="tpl_admin_downloads_title_disable"}</option>
								</select><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_nfo"}:</span> 
								<select name="enable_nfo">
									<option value="1"{if $smarty.const.VIEW_NFO} selected="selected"{/if}>{t k="tpl_admin_downloads_nfo_enable"}</option>
									<option value="0"{if !$smarty.const.VIEW_NFO} selected="selected"{/if}>{t k="tpl_admin_downloads_nfo_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_downloads_nfo_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_posts_perpage"}:</span> 
								<select name="downloads_no">
									<option value="10"{if $smarty.const.DL_POSTS==10} selected="selected"{/if}>10</option>
									<option value="15"{if $smarty.const.DL_POSTS==15} selected="selected"{/if}>15</option>
									<option value="20"{if $smarty.const.DL_POSTS==20} selected="selected"{/if}>20</option>
									<option value="25"{if $smarty.const.DL_POSTS==25} selected="selected"{/if}>25</option>
									<option value="30"{if $smarty.const.DL_POSTS==30} selected="selected"{/if}>30</option>
									<option value="35"{if $smarty.const.DL_POSTS==35} selected="selected"{/if}>35</option>
									<option value="40"{if $smarty.const.DL_POSTS==40} selected="selected"{/if}>40</option>
									<option value="45"{if $smarty.const.DL_POSTS==45} selected="selected"{/if}>45</option>
									<option value="50"{if $smarty.const.DL_POSTS==50} selected="selected"{/if}>50</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_downloads_posts_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent_comment"}:</span> 
								<input type="text" name="comment" maxlength="255" value="{$smarty.const.TORRENT_COMMENT}" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_torrent_comment_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent_ratio"}:</span> 
								<input type="text" name="ratio" maxlength="7" value="{$smarty.const.RATIO_WARNING}" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_torrent_ratio_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent_immune"}:</span> 
								<input type="text" name="immune" maxlength="7" value="{$smarty.const.AUTOWARN_IMMUNE_TIME/3600}" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_torrent_immune_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_downloads_torrent_bitlet"}:</span> 
								<input type="text" name="bitlet" maxlength="20" value="{$smarty.const.BITLET_FSIZE/1048576}" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_torrent_bitlet_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
				<script language="JavaScript">
					var announce_url_php = 'http://{$smarty.const.URL}/tracker/announce.php?torrent_pass={literal}{torrent_pass}{/literal}';
					var scrape_url_php = 'http://{$smarty.const.URL}/tracker/scrape.php?torrent_pass={literal}{torrent_pass}{/literal}';
					var announce_url_xbtt = 'http://{$smarty.server.HTTP_HOST}:2710/{literal}{torrent_pass}{/literal}/announce';
					var scrape_url_xbtt = 'http://{$smarty.server.HTTP_HOST}:2710/{literal}{torrent_pass}{/literal}/scrape';
					{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_TYPE=='PHP'}tracker_choose(1,false);{/if}
					{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_TYPE=='XBTT'}tracker_choose(2,false);{/if}
					{if $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_TYPE!='PHP' && $smarty.const.TRACKER_TYPE!='XBTT'}tracker_choose(3,false);{/if}
					{if !$smarty.const.FUNC_DOWNLOADS_TORRENT}tracker_choose(0,false);{/if}
				</script>
				
				{if count($dl_cats)>0}
					<br/><br/>
				
					<form action="{link url="admin/downloads/edit"}" method="post" class="reg_form">
						<div class="box">
							{section name="c" loop=$dl_cats}
								<div class="cat_item" id="ch_{$smarty.section.c.iteration}">
									<div class="cat_item dl_cat">
										<span>
											<input type="text" name="catname_{$dl_cats[c].id}" maxlength="32" value="{$dl_cats[c].name}" />
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<input type="button" value="{t k="tpl_admin_downloads_up"}" onclick="javascript:cat_mvup({$smarty.section.c.iteration})" />
											<input type="button" value="{t k="tpl_admin_downloads_down"}" onclick="javascript:cat_mvdn({$smarty.section.c.iteration})" />
										</span>
										<span class="right">
											<input type="checkbox" name="del_{$dl_cats[c].id}" /> {t k="tpl_admin_downloads_delcat"}
										</span>
										<input type="hidden" name="position_{$dl_cats[c].id}" value="position_{$smarty.section.c.iteration}" />
										<br/>
									</div>
									{if isset($dl_cats[c].subcats)}
									{section name="s" loop=$dl_cats[c].subcats}
										<div class="cat_item cat_item_sub" id="subch_{$smarty.section.c.iteration}_{$smarty.section.s.iteration}">
											<span>
												<input type="text" name="subcatname_{$dl_cats[c].subcats[s].id}" maxlength="32" value="{$dl_cats[c].subcats[s].name}" />
												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												<input type="button" value="{t k="tpl_admin_downloads_up"}" onclick="javascript:cat_sub_mvup({$smarty.section.c.iteration},{$smarty.section.s.iteration})" />
												<input type="button" value="{t k="tpl_admin_downloads_down"}" onclick="javascript:cat_sub_mvdn({$smarty.section.c.iteration},{$smarty.section.s.iteration})" />
											</span>
											<span class="right">
												<input type="checkbox" name="subdel_{$dl_cats[c].subcats[s].id}" /> {t k="tpl_admin_downloads_delcat"}
											</span>
											<input type="hidden" name="subposition_{$dl_cats[c].subcats[s].id}" value="subposition_{$smarty.section.s.iteration}" />
											<br/>
										</div>
									{/section}
									<script language="JavaScript">var admin_subcat_count_{$smarty.section.c.iteration}={$smarty.section.s.iteration-1};</script>
									{/if}
								</div>
							{/section}
							<script language="JavaScript">var admin_cat_count={$smarty.section.c.iteration-1};</script>
						</div>
						<div class="spacer"></div>
						<div class="box">
							<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
						</div>
						<div class="form_foot_rounded"></div>
					</form>
				{/if}
				
				<br/><br/>
				
				<form action="{link url="admin/downloads/create"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_downloads_newcat"}:</span> 
								<input type="text" name="catname" maxlength="32" value="" /><br/>
						<div class="tip">{t k="tpl_admin_downloads_newcat_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_downloads_newcat_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
				{if count($dl_cats)>0}
					<br/><br/>
					
					<form action="{link url="admin/downloads/create_sub"}" method="post" class="reg_form">
						<div class="box">
							<span>{t k="tpl_admin_downloads_newsubcat_cat"}:</span> 
									<select name="cat">
									{section name="dl_cat" loop=$dl_cats}
										<option value="{$dl_cats[dl_cat].id}">{$dl_cats[dl_cat].name}</option>
									{/section}
									</select><br/>
							<span>{t k="tpl_admin_downloads_newsubcat_name"}:</span> 
									<input type="text" name="subcatname" maxlength="32" value="" /><br/>
							<div class="tip">{t k="tpl_admin_downloads_newsubcat_tip"}</div>
						</div>
						<div class="spacer"></div>
						<div class="box">
							<input type="submit" value="{t k="tpl_admin_downloads_newsubcat_submit"}" class="submit" />
						</div>
						<div class="form_foot_rounded"></div>
					</form>
				{/if}
				
			{elseif $args[2]=='2' || $args[2]=='create' || $args[2]=='create_sub'}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
				
			{elseif $args[2]=='edit'}
				{if $confirmed}
					<p>
						{if $succ}
							{t k="tpl_admin_succ"}
						{else}
							{t k="tpl_admin_err"}
						{/if}
					</p>
				{else}
					<form action="{link url="admin/downloads/edit/2"}" method="post" name="hidden">
						{foreach key=k item=v from=$smarty.post}
						<input type="hidden" name="{$k}" value="{$v}" />
						{/foreach}
					</form>
					<p>{t k="tpl_admin_downloads_edit_confirm" a="javascript:document.forms.hidden.submit()"}</p>
				{/if}
			{/if}		

					
			
		{elseif $args[1] == 'forum'}
			{if $args[2]==null}
				<form action="{link url="admin/forum/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_forum_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_FORUMS} selected="selected"{/if}>{t k="tpl_admin_forum_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_FORUMS} selected="selected"{/if}>{t k="tpl_admin_forum_on_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_forum_on_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_forum_threads_perpage"}:</span> 
								<select name="threads_no">
									<option value="10"{if $smarty.const.FORUM_THREADS_PAGE==10} selected="selected"{/if}>10</option>
									<option value="15"{if $smarty.const.FORUM_THREADS_PAGE==15} selected="selected"{/if}>15</option>
									<option value="20"{if $smarty.const.FORUM_THREADS_PAGE==20} selected="selected"{/if}>20</option>
									<option value="25"{if $smarty.const.FORUM_THREADS_PAGE==25} selected="selected"{/if}>25</option>
									<option value="30"{if $smarty.const.FORUM_THREADS_PAGE==30} selected="selected"{/if}>30</option>
								</select><br/>
						<span>{t k="tpl_admin_forum_posts_perpage"}:</span> 
								<select name="posts_no">
									<option value="5"{if $smarty.const.FORUM_POSTS_PAGE==5} selected="selected"{/if}>5</option>
									<option value="10"{if $smarty.const.FORUM_POSTS_PAGE==10} selected="selected"{/if}>10</option>
									<option value="15"{if $smarty.const.FORUM_POSTS_PAGE==15} selected="selected"{/if}>15</option>
									<option value="20"{if $smarty.const.FORUM_POSTS_PAGE==20} selected="selected"{/if}>20</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_forum_perpage_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_forum_thread_aflood"}:</span>
								<input type="text" name="thread_af" maxlength="10" value="{$smarty.const.FORUM_THREAD_ANTIFLOOD}" /><br/>
						<span>{t k="tpl_admin_forum_posts_aflood"}:</span>
								<input type="text" name="post_af" maxlength="10" value="{$smarty.const.FORUM_POSTS_ANTIFLOOD}" /><br/>
						<div class="tip">{t k="tpl_admin_forum_aflood_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
				{if count($boards)>0}
					<br/><br/>			
					
					<form action="{link url="admin/forum/edit"}" method="post" class="reg_form">
						<div class="box">
							{assign var="clid" value=null}
							{assign var="cat_no" value=1}
							{section name="f" loop=$boards}
								{if $boards[f].clid != $clid}
									{if !$smarty.section.f.first}
										</div> {* ch_* div closing *}
									{/if}
									<div class="cat_item" id="ch_{$cat_no}">
										<div class="cat_item dl_cat">
											<span>
												<input type="text" name="catname_{$boards[f].cid}" maxlength="32" value="{$boards[f].cat}" />
												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												<input type="button" value="{t k="tpl_admin_forum_up"}" onclick="javascript:cat_mvup({$cat_no})" />
												<input type="button" value="{t k="tpl_admin_forum_down"}" onclick="javascript:cat_mvdn({$cat_no})" />
											</span>
											<span class="right">
												<input type="checkbox" name="del_{$boards[f].cid}" /> {t k="tpl_admin_forum_delcat"}
											</span>
											<input type="hidden" name="position_{$boards[f].cid}" value="position_{$cat_no}" />
											<br/>
										</div>
										{if !$smarty.section.f.first}
											<script language="JavaScript">var admin_subcat_count_{$cat_no-1}={$subcat_no-1};</script>
										{/if}
										{assign var="clid" value=$boards[f].clid}
										{assign var="cat_no" value=`$cat_no+1`}
										{assign var="subcat_no" value=1}
									{/if}
									
									{if isset($boards[f].id)}
									<div class="cat_item cat_item_sub" id="subch_{$cat_no-1}_{$subcat_no}">
										<span>
											<input type="text" name="subcatname_{$boards[f].id}" maxlength="70" value="{$boards[f].title}" />
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<input type="text" name="subcatdescr_{$boards[f].id}" maxlength="255" value="{$boards[f].description}" />
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<input type="button" value="{t k="tpl_admin_forum_up"}" onclick="javascript:cat_sub_mvup({$cat_no-1},{$subcat_no})" />
											<input type="button" value="{t k="tpl_admin_forum_down"}" onclick="javascript:cat_sub_mvdn({$cat_no-1},{$subcat_no})" />
										</span>
										<span class="right">
											<input type="checkbox" name="subdel_{$boards[f].id}" /> {t k="tpl_admin_forum_delcat"}
										</span>
										<input type="hidden" name="subposition_{$boards[f].id}" value="subposition_{$subcat_no}" />
										<br/>
									</div>
									{assign var="subcat_no" value=`$subcat_no+1`}
									{/if}
							{/section}
								</div> {* ch_* div closing *}
							<script language="JavaScript">var admin_subcat_count_{$cat_no-1}={$subcat_no-1};</script>
							<script language="JavaScript">var admin_cat_count={$cat_no-1};</script>
						</div>
						<div class="spacer"></div>
						<div class="box">
							<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
						</div>
						<div class="form_foot_rounded"></div>
					</form>
				{/if}		
				
				<br/><br/>
				
				<form action="{link url="admin/forum/create"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_forum_newcat"}:</span> 
								<input type="text" name="catname" maxlength="32" value="" /><br/>
						<div class="tip">{t k="tpl_admin_forum_newcat_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_forum_newcat_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>
				
				{if isset($cat_no) && $cat_no>0}
					<br/><br/>
					
					<form action="{link url="admin/forum/create_sub"}" method="post" class="reg_form">
						<div class="box">
							{assign var="clid" value=null}
							<span>{t k="tpl_admin_forum_newsubcat_cat"}:</span> 
									<select name="cat">
									{section name="f" loop=$boards}
										{if $boards[f].clid != $clid}
											<option value="{$boards[f].cid}">{$boards[f].cat}</option>
											{assign var="clid" value=$boards[f].clid}
										{/if}
									{/section}
									</select><br/>
							<span>{t k="tpl_admin_forum_newsubcat_name"}:</span> 
									<input type="text" name="subcatname" maxlength="70" value="" /><br/>
							<span>{t k="tpl_admin_forum_newsubcat_descr"}:</span> 
									<input type="text" name="description" maxlength="255" value="" /><br/>
							<div class="tip">{t k="tpl_admin_forum_newsubcat_tip"}</div>
						</div>
						<div class="spacer"></div>
						<div class="box">
							<input type="submit" value="{t k="tpl_admin_forum_newsubcat_submit"}" class="submit" />
						</div>
						<div class="form_foot_rounded"></div>
					</form>
				{/if}	
				
			{elseif $args[2]=='2' || $args[2]=='create' || $args[2]=='create_sub'}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
				
			{elseif $args[2]=='edit'}
				{if $confirmed}
					<p>
						{if $succ}
							{t k="tpl_admin_succ"}
						{else}
							{t k="tpl_admin_err"}
						{/if}
					</p>
				{else}
					<form action="{link url="admin/forum/edit/2"}" method="post" name="hidden">
						{foreach key=k item=v from=$smarty.post}
						<input type="hidden" name="{$k}" value="{$v}" />
						{/foreach}
					</form>
					<p>{t k="tpl_admin_forum_edit_confirm" a="javascript:document.forms.hidden.submit()"}</p>
				{/if}
			{/if}
			
			
			
		{elseif $args[1] == 'pm'}
			{if $args[2]!=2}
				<form action="{link url="admin/pm/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_pm_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_PM} selected="selected"{/if}>{t k="tpl_admin_pm_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_PM} selected="selected"{/if}>{t k="tpl_admin_pm_on_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_pm_on_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_pm_perpage"}:</span> 
								<select name="no">					
									<option value="10"{if $smarty.const.PM_PAGE==10} selected="selected"{/if}>10</option>
									<option value="20"{if $smarty.const.PM_PAGE==20} selected="selected"{/if}>20</option>
									<option value="30"{if $smarty.const.PM_PAGE==30} selected="selected"{/if}>30</option>
									<option value="40"{if $smarty.const.PM_PAGE==40} selected="selected"{/if}>40</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_pm_perpage_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_pm_aflood"}:</span>
								<input type="text" name="aflood" maxlength="10" value="{$smarty.const.PM_ANTIFLOOD}" /><br/>
						<div class="tip">{t k="tpl_admin_pm_aflood_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_pm_limit"}:</span>
								<input type="text" name="limit" maxlength="5" value="{$smarty.const.PM_LIMIT}" /><br/>
						<div class="tip">{t k="tpl_admin_pm_limit_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'contact'}
			{if $args[2]!=2}
				<form action="{link url="admin/contact/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_contact_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_CONTACT} selected="selected"{/if}>{t k="tpl_admin_contact_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_CONTACT} selected="selected"{/if}>{t k="tpl_admin_contact_on_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_contact_on_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_contact_email"}:</span> 
								<input type="text" name="email" maxlength="100" value="{$smarty.const.ADMIN_EMAIL}" /><br/>
						<div class="tip">{t k="tpl_admin_contact_email_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>	
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'rss'}
			{if $args[2]!=2}
				<form action="{link url="admin/rss/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_rss_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_RSS} selected="selected"{/if}>{t k="tpl_admin_rss_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_RSS} selected="selected"{/if}>{t k="tpl_admin_rss_on_disable"}</option>
								</select><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'counters'}
			{if $args[2]!=2}
				<form action="{link url="admin/counters/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_counters_on"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_COUNTERS} selected="selected"{/if}>{t k="tpl_admin_counters_on_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_COUNTERS} selected="selected"{/if}>{t k="tpl_admin_counters_on_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_counters_on_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'users'}
			{if $args[2]==null}
				<form action="{link url="admin/users/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_users_validation"}:</span> 
								<select name="enable">
									<option value="1"{if $smarty.const.FUNC_USER_VALIDATION} selected="selected"{/if}>{t k="tpl_admin_users_validation_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_USER_VALIDATION} selected="selected"{/if}>{t k="tpl_admin_users_validation_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_users_validation_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_users_avatar_width"}:</span> 
							<input type="text" name="avatar_width" maxlength="3" value="{$smarty.const.AVATAR_MAXWIDTH}" /><br/>
						<span>{t k="tpl_admin_users_avatar_height"}:</span> 
							<input type="text" name="avatar_height" maxlength="3" value="{$smarty.const.AVATAR_MAXHEIGHT}" /><br/>
						<span>{t k="tpl_admin_users_avatar_fsize"}:</span> 
							<input type="text" name="avatar_fsize" maxlength="10" value="{$smarty.const.AVATAR_MAXSIZE/1024}" /><br/>
						<div class="tip">{t k="tpl_admin_users_avatar_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
				{* Following needs to be converted into a neat table *}
				{section name="p" loop=$permissions}
					<br/><br/>
					
					<form action="{link url="admin/users/edit/`$permissions[p].user`"}" method="post" class="reg_form">
						<div class="box">
							<span>{t k="tpl_admin_users_name"}:</span> 
									<i class="fl_right"><a href="{link url="user/v/`$permissions[p].user`"}" rel="external">{$permissions[p].user}</a></i><br/>
						</div>
						<div class="spacer"></div>
						<div class="box">
							{foreach key=k item=v from=$permissions[p]}
								{if $k!='user'}
									<span>{t k="tpl_admin_users_`$k`"}:</span>
											<select name="{$k}">
												<option value="1"{if $v==1} selected="selected"{/if}>{t k="tpl_admin_users_permissions_enable"}</option>
												<option value="0"{if $v!=1} selected="selected"{/if}>{t k="tpl_admin_users_permissions_disable"}</option>
											</select><br/><br/>
								{/if}
							{/foreach}
							<div class="tip">{t k="tpl_admin_users_permissions_tip"}</div>
						</div>
						<div class="spacer"></div>
						<div class="box">
							<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
						</div>
						<div class="form_foot_rounded"></div>
					</form>	
				{/section}	
				
				<br/><br/>
					
				<form action="{link url="admin/users/add"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_users_permissions_addname"}:</span> 
								<input type="text" name="user" maxlength="32" value="" /><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						{foreach key=k item=v from=$permissions.0}
							{if $k!='user'}
								<span>{t k="tpl_admin_users_`$k`"}:</span>
										<select name="{$k}">
											<option value="1">{t k="tpl_admin_users_permissions_enable"}</option>
											<option value="0" selected="selected">{t k="tpl_admin_users_permissions_disable"}</option>
										</select><br/><br/>
							{/if}
						{/foreach}
						<div class="tip">{t k="tpl_admin_users_permissions_add_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_users_permissions_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>	
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'caching'}
			{if $args[2]!=2}
				<form action="{link url="admin/caching/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_caching_title"}:</span> 
								<select name="title">
									<option value="1"{if $smarty.const.CACHE_TITLE} selected="selected"{/if}>{t k="tpl_admin_caching_enable"}</option>
									<option value="0"{if !$smarty.const.CACHE_TITLE} selected="selected"{/if}>{t k="tpl_admin_caching_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_caching_title_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_caching_rss"}:</span> 
								<select name="rss">
									<option value="1"{if $smarty.const.CACHE_RSS} selected="selected"{/if}>{t k="tpl_admin_caching_enable"}</option>
									<option value="0"{if !$smarty.const.CACHE_RSS} selected="selected"{/if}>{t k="tpl_admin_caching_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_caching_rss_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_caching_search"}:</span> 
								<select name="search">
									<option value="1"{if $smarty.const.CACHE_SEARCH} selected="selected"{/if}>{t k="tpl_admin_caching_enable"}</option>
									<option value="0"{if !$smarty.const.CACHE_SEARCH} selected="selected"{/if}>{t k="tpl_admin_caching_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_caching_search_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_caching_tags"}:</span> 
								<select name="tags">
									<option value="1"{if $smarty.const.CACHE_TAGS} selected="selected"{/if}>{t k="tpl_admin_caching_enable"}</option>
									<option value="0"{if !$smarty.const.CACHE_TAGS} selected="selected"{/if}>{t k="tpl_admin_caching_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_caching_tags_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_caching_posts"}:</span> 
								<select name="posts">
									<option value="1"{if $smarty.const.CACHE_POSTS} selected="selected"{/if}>{t k="tpl_admin_caching_enable"}</option>
									<option value="0"{if !$smarty.const.CACHE_POSTS} selected="selected"{/if}>{t k="tpl_admin_caching_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_caching_posts_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_caching_other"}:</span> 
								<select name="other">
									<option value="1"{if $smarty.const.CACHE} selected="selected"{/if}>{t k="tpl_admin_caching_enable"}</option>
									<option value="0"{if !$smarty.const.CACHE} selected="selected"{/if}>{t k="tpl_admin_caching_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_caching_other_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_caching_userinfo"}:</span> 
								<input type="text" name="userinfo" maxlength="100" value="{$smarty.const.USERINFO_REFRESH}" /><br/>
						<div class="tip">{t k="tpl_admin_caching_userinfo_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'template'}
			{if $args[2]!=2}
				<form action="{link url="admin/template/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_template"}:</span> 
								<select name="template">
									{section name="tpl" loop=$template_list}
										<option value="{$template_list[tpl].id}"{if $smarty.const.DEFAULT_TEMPLATE==$template_list[tpl].id} selected="selected"{/if}>{t k="tpl_user_preferences_template_option" a="`$template_list[tpl].title`|`$template_list[tpl].author`"}</option>
									{/section}
								</select><br/>
						<div class="tip">{t k="tpl_admin_template_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'language'}
			{if $args[2]!=2}
				<form action="{link url="admin/language/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_language"}:</span> 
								<select name="language">
									{section name="lang" loop=$language_list}
										<option value="{$language_list[lang].file}"{if $smarty.const.LANG_DEFAULT==$language_list[lang].file} selected="selected"{/if}>{t k="tpl_user_preferences_language_option" a="`$language_list[lang].own_title`|`$language_list[lang].author`"}</option>
									{/section}
								</select><br/>
						<div class="tip">{t k="tpl_admin_language_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
			
		{elseif $args[1] == 'other'}
			{if $args[2]!=2}
				<form action="{link url="admin/other/2"}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_admin_other_tags"}:</span> 
								<select name="tags">
									<option value="1"{if $smarty.const.FUNC_TAGS} selected="selected"{/if}>{t k="tpl_admin_other_tags_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_TAGS} selected="selected"{/if}>{t k="tpl_admin_other_tags_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_tags_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_other_search_perpage"}:</span> <select name="search_perpage">
									<option value="5"{if $smarty.const.SEARCH_RESULTS==5} selected="selected"{/if}>5</option>
									<option value="10"{if $smarty.const.SEARCH_RESULTS==10} selected="selected"{/if}>10</option>
									<option value="15"{if $smarty.const.SEARCH_RESULTS==15} selected="selected"{/if}>15</option>
									<option value="20"{if $smarty.const.SEARCH_RESULTS==20} selected="selected"{/if}>20</option>
									<option value="25"{if $smarty.const.SEARCH_RESULTS==25} selected="selected"{/if}>25</option>
									<option value="30"{if $smarty.const.SEARCH_RESULTS==30} selected="selected"{/if}>30</option>
									<option value="50"{if $smarty.const.SEARCH_RESULTS==50} selected="selected"{/if}>50</option>
									<option value="100"{if $smarty.const.SEARCH_RESULTS==100} selected="selected"{/if}>100</option>
								</select><br/>
						<span>{t k="tpl_admin_other_search_limit"}:</span> <select name="search_limit">
									<option value="50"{if $smarty.const.SEARCH_RESULTS_LIMIT==50} selected="selected"{/if}>50</option>
									<option value="100"{if $smarty.const.SEARCH_RESULTS_LIMIT==100} selected="selected"{/if}>100</option>
									<option value="150"{if $smarty.const.SEARCH_RESULTS_LIMIT==150} selected="selected"{/if}>150</option>
									<option value="200"{if $smarty.const.SEARCH_RESULTS_LIMIT==200} selected="selected"{/if}>200</option>
									<option value="250"{if $smarty.const.SEARCH_RESULTS_LIMIT==250} selected="selected"{/if}>250</option>
									<option value="300"{if $smarty.const.SEARCH_RESULTS_LIMIT==300} selected="selected"{/if}>300</option>
									<option value="500"{if $smarty.const.SEARCH_RESULTS_LIMIT==500} selected="selected"{/if}>500</option>
									<option value="1000"{if $smarty.const.SEARCH_RESULTS_LIMIT==1000} selected="selected"{/if}>1000</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_search_tip"}</div>
					</div>
					
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_other_anonymous_comments"}:</span> 
								<select name="anonymous_comments">
									<option value="1"{if $smarty.const.FUNC_ANONYMOUS_COMMENTS} selected="selected"{/if}>{t k="tpl_admin_other_anonymous_comments_enable"}</option>
									<option value="0"{if !$smarty.const.FUNC_ANONYMOUS_COMMENTS} selected="selected"{/if}>{t k="tpl_admin_other_anonymous_comments_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_anonymous_comments_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_other_comments_perpage"}:</span> 
								<select name="comments_no">
									<option value="5"{if $smarty.const.COMMENTS_PAGE==5} selected="selected"{/if}>5</option>
									<option value="10"{if $smarty.const.COMMENTS_PAGE==10} selected="selected"{/if}>10</option>
									<option value="15"{if $smarty.const.COMMENTS_PAGE==15} selected="selected"{/if}>15</option>
									<option value="20"{if $smarty.const.COMMENTS_PAGE==20} selected="selected"{/if}>20</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_comments_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_other_generation"}:</span> 
								<select name="generation">
									<option value="1"{if $smarty.const.GENERATION_TIME} selected="selected"{/if}>{t k="tpl_admin_other_generation_enable"}</option>
									<option value="0"{if !$smarty.const.GENERATION_TIME} selected="selected"{/if}>{t k="tpl_admin_other_generation_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_generation_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_other_log"}:</span> 
								<select name="log">
									<option value="1"{if $smarty.const.LOG} selected="selected"{/if}>{t k="tpl_admin_other_log_enable"}</option>
									<option value="0"{if !$smarty.const.LOG} selected="selected"{/if}>{t k="tpl_admin_other_log_disable"}</option>
								</select><br/>
						<span>{t k="tpl_admin_other_log_perpage"}:</span> 
								<select name="log_no">
									<option value="20"{if $smarty.const.LOG_PAGE==20} selected="selected"{/if}>20</option>
									<option value="50"{if $smarty.const.LOG_PAGE==50} selected="selected"{/if}>50</option>
									<option value="100"{if $smarty.const.LOG_PAGE==100} selected="selected"{/if}>100</option>
									<option value="150"{if $smarty.const.LOG_PAGE==150} selected="selected"{/if}>150</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_log_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_admin_other_hash_ip"}:</span> 
								<select name="hash_ip">
									<option value="1"{if !$smarty.const.STORE_USER_IP} selected="selected"{/if}>{t k="tpl_admin_other_hash_ip_enable"}</option>
									<option value="0"{if $smarty.const.STORE_USER_IP} selected="selected"{/if}>{t k="tpl_admin_other_hash_ip_disable"}</option>
								</select><br/>
						<div class="tip">{t k="tpl_admin_other_hash_ip_tip"}</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<input type="submit" value="{t k="tpl_admin_submit"}" class="submit" />
					</div>
					<div class="form_foot_rounded"></div>
				</form>		
				
			{else}
				<p>
					{if $succ}
						{t k="tpl_admin_succ"}
					{else}
						{t k="tpl_admin_err"}
					{/if}
				</p>
			{/if}
			
			
		{/if}
		
{/if}