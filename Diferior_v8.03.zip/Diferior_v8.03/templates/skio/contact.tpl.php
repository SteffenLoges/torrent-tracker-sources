{* Smarty *}
{*<?php die(); ?>*}
{if $args[1]!=2}
	<form action="{link url="contact/2"}" method="post" class="reg_form">
		<div class="box">
			{if $smarty.session.logged && $smarty.session.userinfo.email_validate==null}
				<span>{t k="tpl_contact_email"}:</span> <i class="fl_right">{$smarty.session.userinfo.email}</i><br/>
			{else}
				<span>{t k="tpl_contact_email"}:</span> <input type="text" name="email" maxlength="32" value="" /><br/>
				<div class="tip">{t k="tpl_contact_email_tip"}</div>
			{/if}
		</div>
		<div class="spacer"></div>
		<div class="box">
			<span>{t k="tpl_contact_subject"}:</span> <select name="topic">
																<option value="1">{t k="tpl_contact_subject_1"}</option>
																<option value="2">{t k="tpl_contact_subject_2"}</option>
																<option value="3">{t k="tpl_contact_subject_3"}</option>
																<option value="4">{t k="tpl_contact_subject_4"}</option>
													  </select><br/>
		</div>
		<div class="spacer"></div>
		<div class="box">
			<span>{t k="tpl_contact_message"}:</span><br/>
			<textarea name="message"></textarea>
		</div>
		<div class="spacer"></div>
		<div class="box">
				{img src="captcha/`$smarty.now`.jpg"|link alt="tpl_contact_captcha_alt"|translate onclick="javascript:reload_image(this)"}
				<input type="text" name="captcha" value="" class="submit" />
			<div class="tip">
				{t k="tpl_contact_captcha_tip"}
			</div>
		</div>
		<div class="spacer"></div>
		<div class="box">
			<input type="submit" value="{t k="tpl_contact_submit"}" class="submit" />
		</div>
		<div class="form_foot_rounded"></div>
	</form>
	
{else}
	{if !empty($err)}
		<p>{t k="tpl_errors"}:</p><br/>
		{section name="e" loop=$err}
			<p>&#186; {$err[e]}</p>
		{/section}
	{else}
		<p>{t k="tpl_contact_succ"}</p>
	{/if}
	
{/if}