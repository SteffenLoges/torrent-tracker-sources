{* Smarty *}
{*<?php die(); ?>*}
{if $err === true}
	<p>{t k="error_unknown"}</p>
{else}
	{if $args[1] == null}
	
	
	{elseif $args[1] == 'new' || $args[1] == 'edit'}
		{if $args[2]!=2 || ($args[1]=='edit' && $args[3]==null) }
			<p><a href="{link url="upload_rules"}">{t k="tpl_upload_upload_rules"}</a> |
			<a href="{link url="upload_rules/#guidelines"}">{t k="tpl_upload_guidelines"}</a> |
			<a href="{link url="upload_rules/#description"}">{t k="tpl_upload_description"}</a></p><br/>
			{if $smarty.session.permissions.add_downloads!=1}<div class="big_message">{t k="tpl_upload_unconfirmed_message"}</div><br/>{/if}
			{if isset($dl) && $dl.confirmed!=1 && $smarty.session.permissions.approve_downloads==1}
				<div class="big_message">
					{t k="tpl_upload_author"}:
					{if $dl.anonymous==1}
					<i>{t k="tpl_upload_anonymous"}</i>
					{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.see_anonymous==1}
						[<a href="{link url="user/v/`$dl.user`"}">{$dl.user}</a>]
					{/if}
				{else}
					<a href="{link url="user/v/`$dl.user`"}">{$dl.user}</a>
				{/if}
				</div>
			{/if}
			<a name="preview"></a>
				{*<div class="post_content" id="preview_box"></div>*}
				{include file="`$template_name`/blog.tpl.php" posts=$dummy_post page_count=0 cat="all" start_page=1}
				
				<form enctype="multipart/form-data" action="{if !isset($dl)}{link url="upload/new/2"}{else}{link url="upload/edit/2/`$dl_id`"}{/if}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_upload_category"}:</span> 
						<select name="category">
						{section name="dl_cat" loop=$dl_cats}
							{if isset($dl_cats[dl_cat].subcats)}
							<optgroup label="{$dl_cats[dl_cat].name}">
								{section name="dl_subcat" loop=$dl_cats[dl_cat].subcats}
									<option value="{$dl_cats[dl_cat].subcats[dl_subcat].id}"{if isset($dl) && $dl.subcat==$dl_cats[dl_cat].subcats[dl_subcat].id} selected="selected"
									{elseif !isset($dl) && $smarty.section.dl_cat.last && $smarty.section.dl_subcat.last} selected="selected"{/if}>{$dl_cats[dl_cat].name} &#187; {$dl_cats[dl_cat].subcats[dl_subcat].name}</option>
								{/section}
							</optgroup>
							{/if}
						{sectionelse}
							{t k="tpl_upload_no_categories"}
						{/section}
						</select><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_upload_header"}:</span> <input type="text" name="header" maxlength="78" value="{if isset($dl)}{$dl.header|escape:"html"}{/if}" /><br/>
						<span>{t k="tpl_upload_subheader"}:</span> <input type="text" name="subheader" maxlength="39" value="{if isset($dl)}{$dl.subheader|escape:"html"}{/if}" /><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<div class="bbcode">
							<input type="button" value="{t k="tpl_post_bbcode_b"}" onclick="javascript:simple_bbcode(this,'B')" style="font-weight: 700" />
							<input type="button" value="{t k="tpl_post_bbcode_i"}" onclick="javascript:simple_bbcode(this,'I')" style="font-style: italic" />
							<input type="button" value="{t k="tpl_post_bbcode_u"}" onclick="javascript:simple_bbcode(this,'U')" style="text-decoration: underline" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="button" value="{t k="tpl_post_bbcode_quote"}" onclick="javascript:simple_bbcode(this,'QUOTE')" />
							<input type="button" value="{t k="tpl_post_bbcode_code"}" onclick="javascript:simple_bbcode(this,'CODE')" />
							<input type="button" value="{t k="tpl_post_bbcode_url"}" onclick="javascript:simple_bbcode(this,'URL')" />
							<input type="button" value="{t k="tpl_post_bbcode_email"}" onclick="javascript:simple_bbcode(this,'EMAIL')" />
							<input type="button" value="{t k="tpl_upload_bbcode_img"}" onclick="javascript:simple_bbcode(this,'IMG')" />
							<br/>
							<input type="button" value="{t k="tpl_post_bbcode_big"}" onclick="javascript:add_bbcode('[size=20][/size]')" />
							<input type="button" value="{t k="tpl_post_bbcode_small"}" onclick="javascript:add_bbcode('[size=12][/size]')" />
							<input type="button" value="{t k="tpl_post_bbcode_color"}" onclick="javascript:add_bbcode('[color=000000][/color]')" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="button" value="{t k="tpl_post_bbcode_break"}" onclick="javascript:add_bbcode('[break]');this.disabled=true" />
							<span id="popup_container"></span>
						</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<textarea name="post_content" id="txt" class="newpost_textarea" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);">{if isset($dl)}{$dl.content|escape:"html"}{/if}</textarea>
					</div>
					<div class="spacer"></div>
					<div class="box upload">
						<div class="nofloat">
							{t k="tpl_upload_nfo" a="<b class=\"emph\">|</b>|<b>|</b>"}:
							<input type="file" name="nfo" />
						</div>
					</div>
					<div class="spacer"></div>
					
					{if $smarty.const.FUNC_DOWNLOADS_TORRENT}
						<div class="box upload">
							<div class="nofloat">
								{t k="tpl_upload_torrent" a="<b class=\"emph\">|</b>"}{if $smarty.const.FUNC_DOWNLOADS_HTTP} ({t k="tpl_upload_torrent_optional" a="<b>|</b>"}){/if}:
								{if isset($dl) && $dl.info_hash!=null}
									{t k="tpl_upload_torrent_noedit"}
								{else}
									<span class="fl_right"><a href="{link url="creating_torrent"}">{t k="tpl_upload_torrent_howto"}</a></span>
									<input type="file" name="torrent" />
								{/if}
							</div>
						</div>
						<div class="spacer"></div>
					{/if}
					
					{if $smarty.const.FUNC_DOWNLOADS_HTTP}
						<div class="box upload">
							<div class="nofloat">
								{t k="tpl_upload_http" a="<b class=\"emph\">|</b>"}{if $smarty.const.FUNC_DOWNLOADS_TORRENT}  {t k="tpl_upload_http_optional" a="<b>|</b>"}{/if}):
								<textarea name="links">{if isset($dl)}{$dl.dl_links|escape:"html"}{/if}</textarea>
							</div>
						</div>
						<div class="spacer"></div>
					{/if}
					
					<div class="box">
						<div class="nofloat">
							<input type="checkbox" name="anonymous"{if isset($dl) && $dl.anonymous==1}  checked="checked"{/if} /> {t k="tpl_upload_as_anonymous"}
						</div>
					</div>
					<div class="spacer"></div>
					{if $smarty.const.FUNC_TAGS}
						<div class="box">
							<div class="nofloat">
								{t k="tpl_post_tags"}:<br/>
								<input type="text" name="tags" class="tags" maxlength="398" value="{if isset($dl)}{$dl.tags}{/if}" />
							</div>
						</div>
						<div class="spacer"></div>
					{/if}
					<div class="box">
						<div class="nofloat">
							{if isset($dl) && $dl.confirmed!=1 && $smarty.session.permissions.approve_downloads==1}<input type="hidden" name="confirm" value="1" />{/if}
							<input type="button" value="{t k="tpl_upload_preview"}" class="submit" onclick="javascript:preview_upload()" /> <input type="submit" value="{if isset($dl) && $dl.confirmed!=1 && $smarty.session.permissions.approve_downloads==1}{t k="tpl_upload_confirm"}{else}{t k="tpl_upload_submit"}{/if}" class="submit" />
						</div>
					</div>
					<!-- For compatibility. Means nothing, so don't even try :) -->
					<input type="hidden" name="usehtml" value="false"/>
				</form>
				{if isset($dl)}
					<br/>
					<a href="{link url="upload/delete/$dl_id"}">{t k="tpl_upload_delete"}</a>
				{/if}
		{else}
			<p>
			{if $args[1]=='edit'}
				{if $res==true}
					{t k="tpl_upload_edit_succ"}
				{else}
					{t k="tpl_upload_edit_err"} {errno}
				{/if}
			{else}
				{if $res===true}
					{if $smarty.session.permissions.add_downloads!=1}
						{t k="tpl_upload_send_unconfirmed_succ"}
					{else}
						{t k="tpl_upload_send_succ"}
					{/if}
				{elseif $res===false}
					{t k="tpl_upload_send_err"} {errno}
				{else}
					{if $smarty.session.permissions.add_downloads!=1}
						{t k="tpl_upload_send_torrent_unconfirmed_succ"}
					{else}
						{t k="tpl_upload_send_torrent_succ"}
					{/if}
					<br/>
					<a href="{link url="_"}">{t k="tpl_upload_send_torrent_back"}</a>
					<script language="JavaScript">location.href='{$res}'</script>
				{/if}
			{/if}
			</p>
		{/if}
	
		
		
	{elseif $args[1] == 'list'}	
		<div class="list_holder">
			{section name="dl" loop=$downloads}
				<div class="line list_{cycle values="1,2"}">
					<span class="fl_left">
						{if $downloads[dl].confirmed==1}{img src="`$imurl`posted.gif" alt="P"}{else}{img src="`$imurl`pending.gif" alt="Q"}{/if}
						<span class="date">{$downloads[dl].posted|date_format:"%y %m %d - %H:%M:%S"}</span>
						<a href="{link url="file/`$downloads[dl].lid`/`$downloads[dl].sublid`/`$downloads[dl].plid`.html"}">{$downloads[dl].header|truncate:'45':'...':true:true|escape:html}</a>
						(<a href="{link url="downloads/`$downloads[dl].lid`"}">{$downloads[dl].name}</a> 
						 &#187
						 <a href="{link url="downloads/`$downloads[dl].lid`/`$downloads[dl].sublid`"}">{$downloads[dl].subname}</a>)
					 </span>
					 <a href="{link url="upload/edit/`$downloads[dl].fid`"}" class="edit">{t k="tpl_upload_list_edit"}</a>
				</div>
			{sectionelse}
				<p>{t k="tpl_upload_list_none"}</p>
			{/section}
		</div>
		
		
	{elseif $args[1] == 'delete'}	
		{if $args[3]!=2}
			<p>{t k="tpl_upload_delete_ask" a="upload/delete/`$args[2]`/2"|link}</p>
		{else}
			<p>
			{if $res}
				{t k="tpl_upload_delete_succ"}
			{else}
				{t k="error"} {errno}.
			{/if}
			</p>
		{/if}
	
		
	{elseif $args[1] == 'pending'}	
		<p><a href="{link url="rss/pending-`$smarty.session.user`-`$smarty.session.userinfo.pass`.xml"}">{img src="`$imurl`rss.gif" alt=""} RSS</a></p><br/>
		<div class="list_holder">
			{section name="dl" loop=$downloads}
				<div class="line list_{cycle values="1,2"}">
					<span class="fl_left">
						{img src="`$imurl`pending.gif" alt="Q"}
						<span class="date">{$downloads[dl].posted|date_format:"%y %m %d - %H:%M:%S"}</span>
						<a href="{link url="file/`$downloads[dl].lid`/`$downloads[dl].sublid`/`$downloads[dl].plid`.html"}">{$downloads[dl].header|truncate:'40':'...':true:true|escape:html}</a>
						(<a href="{link url="user/v/`$downloads[dl].user`"}">{$downloads[dl].user}</a>, 
						 <a href="{link url="downloads/`$downloads[dl].lid`"}">{$downloads[dl].name}</a> 
						 &#187
						 <a href="{link url="downloads/`$downloads[dl].lid`/`$downloads[dl].sublid`"}">{$downloads[dl].subname}</a>)
					 </span>
					 <a href="{link url="upload/edit/`$downloads[dl].fid`"}" class="edit">{t k="tpl_upload_list_edit"}</a>
				</div>
			{sectionelse}
				<p>{t k="tpl_upload_pending_none"}</p>
			{/section}
		</div>		
		
		
	{elseif $args[1] == 'cheaters'}	
		{if $args[2]!='del'}
			<p><a href="{link url="rss/cheaters-`$smarty.session.user`-`$smarty.session.userinfo.pass`.xml"}">{img src="`$imurl`rss.gif" alt=""} RSS</a></p><br/>
			<div class="list_holder">
				<form action="{link url="upload/cheaters/del"}" method="post">
				{section name="dl" loop=$downloads}
					<a name="ch{$downloads[dl].id}"></a>
					<div class="line list_{cycle values="1,2"}">
					<span class="fl_left">
							{if $downloads[dl].banned==1}{img src="`$imurl`userinfo/banned.gif" alt="ban"}{/if}
							{if $downloads[dl].can_leech==0}{img src="`$imurl`userinfo/no_leech.gif" alt="noleech"}{/if}
							<input type="checkbox" name="ch{$downloads[dl].id}" style="width: auto; border: 0;"/>
							<span class="date">{$downloads[dl].tstamp|date_format:"%y %m %d - %H:%M:%S"}</span>
							<a href="{link url="user/v/`$downloads[dl].name`"}">{$downloads[dl].name}</a> 
							({$downloads[dl].ipa|long2ip})
							{img src="`$imurl`userinfo/uploaded.gif" alt="Up"} {$downloads[dl].uploaded|format_size} 
							({$downloads[dl].upspeed|format_size}/s)
						 </span>
						 <a href="{link url="user/ban/`$downloads[dl].name`"}" class="edit">{t k="tpl_upload_cheaters_punish"}</a>
					</div>
				{sectionelse}
					<p>{t k="tpl_upload_cheaters_none"}</p>
				{/section}
				<br/><br/>
				<input type="submit" value="{t k="tpl_upload_cheaters_del"}" style="width: auto" />
				</form>
			</div>		
		{else}
			<p>
				{if $res===true}
					{t k="tpl_upload_cheaters_del_succ"}
				{else}
					{t k="error"} {errno}
				{/if}	
			</p>
		{/if}	
		
		
	{elseif $args[1] == 'log'}	
		<div class="list_holder">
			{section name="l" loop=$log}
				<div class="line list_{cycle values="1,2"}">
					<span class="fl_left">
						<span class="date">{$log[l].tstamp|date_format:"%y %m %d - %H:%M:%S"}</span>
						<a href="{link url="user/v/`$log[l].user`"}">{$log[l].user}</a>
						
						{if $log[l].action==1}<span style="color: #a00">{t k="tpl_upload_log_confirm"}</span>
						{elseif $log[l].action==2}<span style="color: #0a0">{t k="tpl_upload_log_edit"}</span>
						{elseif $log[l].action==3}<span style="color: #05f">{t k="tpl_upload_log_del"}</span>
						{else}<span style="color: #999">{t k="tpl_upload_log_unknown"}</span>
						{/if}
						
						<a href="{link url="`$log[l].url`"}">{$log[l].title|escape:"html"}</a>
						{if $log[l].comments!=null}{$log[l].comments|escape:"html"}{/if}
					</span>
				</div>
			{sectionelse}
				<p>{t k="tpl_upload_log_none"}</p>
			{/section}
			
			<br/><div class="paging">
			{if $page > 1}<a href="{link url="upload/log/page`$page-1`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{/if}
			<b>{$page}</b>
			<a href="{link url="upload/log/page`$page+1`"}" class="pg_next">{t k="tpl_next"} &#187;</a>
			</div>
		</div>			
		
		
	{/if}
	
{/if}