{* Smarty *}
{*<?php die(); ?>*}
{assign var="template_name" value="skio"}
{php}
	header ( 'Content-Type: text/html; charset=utf-8' );
	header ( 'Cache-Control: no-store, no-cache, must-revalidate' );
{/php}
{assign var="smurl" value="http://`$smarty.const.URL`/"}
{assign var="rsurl" value="`$smurl`tpl_resources/`$template_name`/"}
{assign var="imurl" value="`$rsurl`images/"}

{section name="u" loop=$peers}
{if $file.anonymous==1 && $peers[u].name==$file.user}
	<i>{t k="tpl_file_anonymous"}</i>
{else}
	<a href="{link url="user/v/`$peers[u].name`"}">{$peers[u].name}</a>
{/if}
( 
	{img src="`$imurl`userinfo/ratio_small.gif" alt="R"}
		{if $peers[u].downloaded==0}&#8734;{else}{$peers[u].uploaded/$peers[u].downloaded|string_format:"%.2f"|colorize:1}{/if} 
	{img src="`$imurl`userinfo/uploaded_small.gif" alt="Up"}
		{$peers[u].uploaded|format_size}		
	{img src="`$imurl`userinfo/downloaded_small.gif" alt="Dl"}
		{$peers[u].downloaded|format_size}		
)
{/section}