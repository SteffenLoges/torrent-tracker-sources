{* Smarty *}
{*<?php die(); ?>*}
{*

<p class="clear">
	Welcome to {$smarty.const.PAGE_NAME}! This is a short paragraph of text giving a quick overview of site. 
	You can uncomment this block of text and edit it. Also, title page can be customized using this template file.
	By default newest blog posts and downloads will be displayed.
</p>
<br/><br/>

*}
{include file="`$template_name`/`$tplfile`.tpl.php"}