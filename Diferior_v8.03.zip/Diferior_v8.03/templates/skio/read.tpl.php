{* Smarty *}
{*<?php die(); ?>*}
{if $error}
	<p>{t k="error_unknown"}</p>
{else}
	{if isset($args[3]) && preg_match("#^c([0-9]+)\$#",$args[3])}
		<script type="text/javascript">if (location.href.search(/#c[0-9]+$/)==-1) location.href='#{$args[3]}'</script>
	{/if}
	
	{if $post.comments>0}
		{if $post.comments%10==1}
			{assign var="comments_str" value="tpl_comments_s"|translate:$post.comments}
		{elseif $post.comments%10==0 || ( $post.comments > 10 && $post.comments < 20 )}
			{assign var="comments_str" value="tpl_comments_p1"|translate:$post.comments}
		{else}
			{assign var="comments_str" value="tpl_comments_p2"|translate:$post.comments}
		{/if}
	{else}
		{assign var="comments_str" value="tpl_comments_no"|translate}
	{/if}
	
	<div class="post_holder">
		<div class="pholder">
		<div class="post_info">
			{img src="`$imurl`cat.gif" alt=""} {t k="tpl_blog_category"}: <a href="{link url="cat/`$post.lid`"}">{$post.name|escape:"html"}</a>
			{img src="`$imurl`poster.gif" alt="tpl_blog_author"|translate} <a href="{link url="user/v/`$post.author`"}">{$post.author}</a>
			{img src="`$imurl`date.gif" alt="@"} <i>{$post.posted|date_format:"%y %m %d - %H:%M:%S"}</i>
			{if $post.updated!=0}, <span>{t k="tpl_blog_updated"} <i>{$post.updated|date_format:"%y %m %d - %H:%M:%S"}</i></span>{/if}
		</div>
		<div class="post_content">
		<p>
			{$post.content|parse_post:$post.lid:$post.plid:$post.parse_html:false:false:$post.id}
		</p>
		</div>
		{if $post.copyright==1}<div class="post_copyright">{assign var="post_year" value=$post.posted|date_format:"%Y"}{t k="tpl_read_copyright" a="`$post_year`|`$post.author`"}</div>{/if}
		<div class="post_foot">
			{img src="`$imurl`comment_small.gif" alt="-"}<a href="#comments">{$comments_str}</a>
			{img src="`$imurl`write_comment_small.gif"}<a href="#post-comment">{t k="tpl_read_post_comment"}</a>
			{img src="`$imurl`print_small.gif"}<a href="{link url="read/`$post.lid`/`$post.plid`/print"}">{t k="tpl_read_print"}</a>
			{if isset($smarty.session.logged) && $smarty.session.logged===true && ( $smarty.session.user==$post.author || $smarty.session.permissions.edit_posts==1 )}{img src="`$imurl`edit_post_small.gif"}<a href="{link url="post/edit/p`$post.id`"}">{t k="tpl_read_edit"}</a>{/if}
		</div>
		{if $smarty.const.FUNC_TAGS && !empty($post.tags)}
			<div class="post_tags">
				{section name="tags" loop=$post.tags}
					<a href="{link url="search/blog_tag/`$post.tags[tags]`"}">{$post.tags[tags]}</a>{if !$smarty.section.tags.last}, {/if}
				{/section}
			</div>
		{/if}
		</div>
		<div class="post_foot_rounded"></div>
	</div>
	
	{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments}
		<form id="del_comment_form" action="{link url="comment/delete/p`$post.id`"}" method="post">
	{/if}
	
	<div class="comments_holder fl_left">
		{include file="`$template_name`/output_comments.tpl.php" tot_comments=$post.comments}
	
		{if $pages > 1 }
			{assign var="pfx" value="read/`$post.lid`/`$post.plid`"}
			<br/><div class="paging">
			{if $page > 1}<a href="{link url="$pfx/page`$page-1`/#comments"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
			{assign var="paging" value=$page|paging:$pages:3:10}
			{foreach from=$paging item=curr_page}
				{if $curr_page != 'sep'}
					{if $curr_page != $page}
						<a href="{link url="$pfx/page`$curr_page`/#comments"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
					{else}
						<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
					{/if}					
				{else}...{/if} 
			{/foreach}
			{if $page < $pages}<a href="{link url="$pfx/page`$page+1`/#comments"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
			</div>
		{/if}
	</div>
	
	{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments}
		</form>
	{/if}	
	
	<div class="post_comment clear">
	<a name="post-comment"></a>
		<form id="comment_form" action="{link url="comment/p`$post.id`"}" method="post">
			{t k="tpl_comments_write"}:<br/>
			{if $smarty.const.FUNC_ANONYMOUS_COMMENTS && (!isset($smarty.session.logged) || $smarty.session.logged===false)}
				<div class="anonymous">
					<div>
						<span class="fl_left">{t k="tpl_comments_username"}:</span>
							<input type="text" name="c_user" value="{if isset($smarty.cookies.comments_user) && $smarty.const.CACHE_STATIC==null}{$smarty.cookies.comments_user}{/if}" maxlength="20" />
					</div>
					<div>
						<span class="fl_left">{t k="tpl_comments_email"}:</span>
							<input type="text" name="c_email" value="{if isset($smarty.cookies.comments_email) && $smarty.const.CACHE_STATIC==null}{$smarty.cookies.comments_email}{/if}" maxlength="32" />
					</div>
					<div>
						{img src="captcha/s/`$smarty.now`.jpg"|link alt="tpl_user_register_captcha"|translate onclick="javascript:reload_image(this)"}
							<input type="text" name="captcha" value="" />
					</div>
				</div>
			{/if}
			<div class="post_comment_holder">
				<span class="holder">
					<textarea name="comment" id="comment" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);"></textarea>
				</span>
				<span class="smilies">
				{foreach name="smilies" key=k item=v from=$smilies}
					<a href="javascript:add_bbcode(' {$k|escape:'javascript'} ','comment')">{img src="`$imurl`smilies/`$v`.gif" alt="`$k`"}</a>
				{/foreach}
				</span>
				<input type="button" id="comment_button" value="{t k="tpl_comments_send"}" onclick="javascript:comment_submit({if $smarty.const.FUNC_ANONYMOUS_COMMENTS}true{else}false{/if})">
				<div id="comment_login" onclick="javascript:comment_warning()">
					{assign var="link_register" value="user/register"|link}
					{assign var="link_login" value="user/login"|link}
					{t k="tpl_comments_err_login" a="`$link_register`|`$link_login`"}
				</div>
			</div>
		</form>
	</div>	

	{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments && $post.comments > 0}
		<input type="button" id="del_comms" value="{t k="tpl_comments_delete"}" style="width: auto; padding: 0 4px; margin-left: 80px" onclick="javascript:document.getElementById('del_comment_form').submit()" />
	{/if}
	
{/if}