{* Smarty *}
{*<?php die(); ?>*}
{if $args[1] == null}


{elseif $args[1] == 'register'}
	{if $args[2]!=2}
		{* Form *}
		<form action="{link url="user/register/2"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_register_username"}:</span> <input type="text" name="user" maxlength="20" value="" /><br/>
				<div class="tip">{t k="tpl_user_register_username_tip"}</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_register_password"}:</span> <input type="password" name="pass1" maxlength="20" value="" /><br/>
				<span>{t k="tpl_user_register_repeat_password"}:</span> <input type="password" name="pass2" maxlength="20" value="" /><br/>
				<div class="tip">{t k="tpl_user_register_password_tip"}</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_register_email"}:</span> <input type="text" name="email1" maxlength="32" value="" /><br/>
				<span>{t k="tpl_user_register_email_repeat"}:</span> <input type="text" name="email2" maxlength="32" value="" /><br/>
				{if $smarty.const.FUNC_USER_VALIDATION}
					<div class="tip">{t k="tpl_user_register_email_tip"}</div>
				{/if}
			</div>
			<div class="spacer"></div>
			<div class="box">
					{img src="captcha/`$smarty.now`.jpg"|link alt="tpl_user_register_captcha"|translate onclick="javascript:reload_image(this)"}
					<input type="text" name="captcha" value="" class="submit" />
				<div class="tip">
					{t k="tpl_user_register_captcha_tip"}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<div class="nofloat">
					<input type="checkbox" name="tos" /> {t k="tpl_user_register_tos" a="tos"|link}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_register_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{else}
		{if !empty($err)}
			<p>{t k="tpl_errors"}:</p><br/>
			{section name="e" loop=$err}
				<p>&#186; {$err[e]}</p>
			{/section}
		{else}
			<p>
				{if $smarty.const.FUNC_USER_VALIDATION}
					{t k="tpl_user_register_succ"}
				{else}
					{t k="tpl_user_activate_succ"}
				{/if}
			</p>
		{/if}
	{/if}
	
	
{elseif $args[1] == 'activate'}
	<p>	
	{if $validate}
		{t k="tpl_user_activate_succ"}
	{else}
		{t k="tpl_user_activate_err"}
	{/if}	
	</p>

	
{elseif $args[1] == 'login'}
	{if $validated}
		{if $username!=null && $username!='Vartotojas'}
			<p>{t k="tpl_user_login_invalid_1"}</p>
			<p>{t k="tpl_user_login_invalid_2" a="user/reminder"|link}</p><br/><br/>
		{/if}
		{* Login *}
		<form action="{link url="user/login"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_login_username"}:</span> <input type="text" name="user" maxlength="20" value="{$username}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_login_password"}:</span> <input type="password" name="pass" maxlength="20" value="" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<div class="nofloat">
					{t k="tpl_user_login_forgot" a="user/reminder"|link}<br/>
					{t k="tpl_user_login_register" a="user/register"|link}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_login_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{else}
		{* Email change (inactive user account) *}
		<form action="{link url="user/changemail"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_login_email_address"}:</span> <input type="text" name="email1" maxlength="32" value="" /><br/>
				<span>{t k="tpl_user_login_email_address_repeat"}:</span> <input type="text" name="email2" maxlength="32" value="" /><br/>
				<div class="tip">{t k="tpl_user_login_email_tip"}</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
					{img src="captcha/`$smarty.now`.jpg"|link alt="tpl_user_register_captcha"|translate onclick="javascript:reload_image(this)"}
					<input type="text" name="captcha" value="" class="submit" />
				<div class="tip">
					{t k="tpl_user_register_captcha_tip"}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_login_email_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{/if}


{elseif $args[1]=='changemail'}
		{if !empty($err)}
			<p>{t k="tpl_errors"}:</p><br/>
			{section name="e" loop=$err}
				<p>&#186; {$err[e]}</p>
			{/section}
		{else}
			<p>
				{t k="tpl_user_changemail_succ"}
			</p>
		{/if}

		
{elseif $args[1]=='reminder'}
	{if $args[2]!=2}
		{* Form *}
		<form action="{link url="user/reminder/2"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_reminder_email"}:</span> <input type="text" name="email" maxlength="32" value="" /><br/>
				<div class="tip">{t k="tpl_user_reminder_tip"}</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
					{img src="captcha/`$smarty.now`.jpg"|link alt="tpl_user_register_captcha"|translate onclick="javascript:reload_image(this)"}
					<input type="text" name="captcha" value="" class="submit" />
				<div class="tip">
					{t k="tpl_user_register_captcha_tip"}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_reminder_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{else}
		{* Registration *}
		{if !empty($err)}
			<p>{t k="tpl_errors"}:</p><br/>
			{section name="e" loop=$err}
				<p>&#186; {$err[e]}</p>
			{/section}
		{else}
			<p>
				{t k="tpl_user_reminder_succ"}
			</p>
		{/if}
	{/if}
	
	
{elseif $args[1]=='v'}
	{if $info===false}
		<p>{t k="tpl_user_v_noexist"}</p>
	{else}
		<div class="userinfo">
			<div>
				{if $info.pr_avatar!=null}
					{img src="`$info.pr_avatar`" alt="tpl_comments_avatar"|translate}
				{else}
					{img src="`$imurl`avatar.gif" alt="tpl_comments_avatar"|translate}
				{/if}<br/>
				{$info.name} ({$info.status})		
				{if $info.banned==1}
					<br/>{img src="`$imurl`userinfo/banned.gif" alt="!"}<br/>
				{elseif $info.warned==1}
					<br/>{img src="`$imurl`userinfo/warning.gif" alt="!"}<br/>
				{/if}
			</div><br/>
			
			<span class="fl_left">{t k="tpl_user_v_lastlogin"}:</span> 
				<span class="fl_right">{if $info.lastlogin!=0}{$info.lastlogin|date_format:"%Y %m %d - %H:%M:%S"}{else}{t k="tpl_user_v_lastlogin_inactive"}{/if}</span><br/>
			<span class="fl_left">{t k="tpl_user_v_registration"}:</span> 
				<span class="fl_right">{$info.registered|date_format:"%Y %m %d - %H:%M:%S"}</span><br/>
			<br/>
			
			{if $smarty.const.FUNC_BLOG && $info.blogposts!=0}
				<span class="fl_left">{t k="tpl_user_v_blogposts"}:</span> 
					<span class="fl_right">{$info.blogposts}</span><br/>
				<span class="fl_left">{t k="tpl_user_v_blogposts_perday"}:</span> 
					<span class="fl_right">{math equation="comm/ceil((now-reg)/86400)" reg=$info.registered now=$smarty.now comm=$info.blogposts assign="perday"}~{$perday|string_format:"%.2f"}</span><br/>
				<br/>
			{/if}
			
			{if $smarty.const.FUNC_DOWNLOADS && $info.downloadposts!=0}
				<span class="fl_left">{t k="tpl_user_v_downloadposts"}:</span> 
					<span class="fl_right">{$info.downloadposts}</span><br/>
				<span class="fl_left">{t k="tpl_user_v_downloadposts_perday"}:</span> 
					<span class="fl_right">{math equation="comm/ceil((now-reg)/86400)" reg=$info.registered now=$smarty.now comm=$info.downloadposts assign="perday"}~{$perday|string_format:"%.2f"}</span><br/>
				<br/>
			{/if}
			
			<span class="fl_left">{t k="tpl_user_v_comments"}:</span> 
				<span class="fl_right">{if $info.comments!=0}{$info.comments}{else}{t k="tpl_user_v_comments_none"}{/if}</span><br/>
			<span class="fl_left">{t k="tpl_user_v_comments_perday"}:</span> 
				<span class="fl_right">{math equation="comm/ceil((now-reg)/86400)" reg=$info.registered now=$smarty.now comm=$info.comments assign="perday"}{if $perday!=0}~{$perday|string_format:"%.2f"}{else}--{/if}</span><br/>
			<br/>
			
			{if $smarty.const.FUNC_FORUMS}
				<span class="fl_left">{t k="tpl_user_v_forumposts"}:</span> 
					<span class="fl_right">{if $info.forumposts!=0}{$info.forumposts}{else}{t k="tpl_user_v_forumposts_none"}{/if}</span><br/>
				<span class="fl_left">{t k="tpl_user_v_forumposts_perday"}:</span> 
					<span class="fl_right">{math equation="comm/ceil((now-reg)/86400)" reg=$info.registered now=$smarty.now comm=$info.forumposts assign="perday"}{if $perday!=0}~{$perday|string_format:"%.2f"}{else}--{/if}</span><br/>
				<br/>
			{/if}
			
			{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false}
				<span class="fl_left">{t k="tpl_user_v_uploaded"}:</span> 
					<span class="fl_right">{$info.uploaded|format_size}</span><br/>
				<span class="fl_left">{t k="tpl_user_v_downloaded"}:</span> 
					<span class="fl_right">{$info.downloaded|format_size}</span><br/>
				<span class="fl_left">{t k="tpl_user_v_ratio"}:</span> 
					<span class="fl_right">{if $info.downloaded==0}&#8734;{else}{$info.uploaded/$info.downloaded|string_format:"%.2f"|colorize:1}{/if}</span><br/>
				<br/>
			{/if}
			
			{if isset($smarty.session.permissions) && $smarty.session.permissions.view_ip}
				<span class="fl_left">{t k="tpl_user_v_ip"}{if strlen($info.ip)==32} ({t k="tpl_user_v_ip_hashed"}){/if}:</span> 
					<span class="fl_right">{$info.ip}</span><br/>
				<br/>
			{/if}
			
			{if $info.pr_name!=null}
				<span class="fl_left">{t k="tpl_user_v_name"}:</span> 
					<span class="fl_right">{$info.pr_name}</span><br/>
			{/if}
			{if $info.pr_gender!=0 && $info.pr_gender!=3}
				<span class="fl_left">{t k="tpl_user_v_gender"}:</span> 
					<span class="fl_right">{if $info.pr_gender==1}{t k="tpl_user_v_gender_male"}{elseif $info.pr_gender==2}{t k="tpl_user_v_gender_female"}{/if}</span><br/>
			{/if}
			{if $info.pr_birth!='0000-00-00'}
				{assign var="age" value=$info.pr_birth|get_age}
				<span class="fl_left">{t k="tpl_user_v_age"}:</span> 
					<span class="fl_right">{$age} {if $age==1}{t k="tpl_user_v_age_1"}{elseif ($age>=10 && $age<=20) || ($age mod 10 == 0)}{t k="tpl_user_v_age_2"}{else}{t k="tpl_user_v_age_3"}{/if}</span><br/>
				<span class="fl_left">{t k="tpl_user_v_birthday"}:</span> 
					<span class="fl_right">{$info.pr_birth|nice_date}</span><br/>
			{/if}
			{if $info.pr_location!=null}
				<span class="fl_left">{t k="tpl_user_v_location"}:</span> 
					<span class="fl_right">{$info.pr_location}</span><br/>
			{/if}
			{if $info.pr_page!=null}
				<span class="fl_left">{t k="tpl_user_v_page"}:</span> 
					<span class="fl_right"><a href="{$info.pr_page}" rel="external">{$info.pr_page}</a></span><br/>
			{/if}
			{if $info.pr_skype!=null}
				<span class="fl_left">{t k="tpl_user_v_skype"}:</span> 
					<span class="fl_right">{$info.pr_skype}</span><br/>
			{/if}
			{if $info.pr_msn!=null}
				<span class="fl_left">{t k="tpl_user_v_msn"}:</span> 
					<span class="fl_right">{$info.pr_msn|replace:'@':' (at) '|escape:'hexentity'}</span><br/>
			{/if}
			{if $info.pr_icq!=0}
				<span class="fl_left">{t k="tpl_user_v_icq"}:</span> 
					<span class="fl_right">{$info.pr_icq}</span><br/>
			{/if}
			{if $info.pr_yahoo!=null}
				<span class="fl_left">{t k="tpl_user_v_yahoo"}:</span> 
					<span class="fl_right">{$info.pr_yahoo|replace:'@':' (at) '|escape:'hexentity'}</span><br/>
			{/if}
			{if $info.pr_gtalk!=null}
				<span class="fl_left">{t k="tpl_user_v_gtalk"}:</span> 
					<span class="fl_right">{$info.pr_gtalk|replace:'@':' (at) '|escape:'hexentity'}</span><br/>
			{/if}
			
			{if isset($smarty.session.logged) && $smarty.session.logged}
				{if $smarty.const.FUNC_PM && $smarty.session.user != $info.name}
					<br/><br/><a href="{link url="pm/send/`$info.name`"}">{t k="tpl_user_v_send_pm"}</a>
				{/if}	
				
				{if $smarty.session.permissions.ban_users==1}
					<br/><br/><a href="{link url="user/ban/`$info.name`"}">{t k="tpl_user_v_ban"}</a>
				{/if}
				
				{if $smarty.session.permissions.edit_users==1}
					<br/><br/><a href="{link url="user/profile/c/`$info.name`"}">{t k="tpl_user_v_edit"}</a>
				{/if}
			{/if}
		</div>
	{/if}

	
{elseif $args[1]=='preferences'}
	{if !isset($smarty.session.logged) || !$smarty.session.logged}
		<p>{t k="err_not_logged"}</p>
	{else}
		{if $args[2]==2}
			<div class="big_message">{if $updated}{t k="tpl_user_preferences_succ"}{else}{t k="tpl_user_preferences_err"}{/if}</div>
		{/if}
		{* Form *}
		<form action="{link url="user/preferences/2"}" method="post" class="reg_form">
			{if $smarty.const.FUNC_BLOG || $smarty.const.FUNC_DOWNLOADS}
			<div class="box">
				<span>{t k="tpl_user_preferences_homepage"}:</span> 
						<select name="start_page">
							<optgroup label="{t k="tpl_user_preferences_homepage_title"}">
								<option value="m">{t k="tpl_user_preferences_homepage_title"}</option>
							</optgroup>
													
						{if $smarty.const.FUNC_BLOG}
							<optgroup label="{t k="tpl_index_menu_blog"}">
								<option value="b_all"{if $smarty.session.preferences.start_page!=null && $smarty.session.preferences.start_page=="b_all"} selected="selected"{/if}>{t k="tpl_index_menu_new_posts"}</option>
								{section name="blog_cat" loop=$cats}
									<option value="b_{$cats[blog_cat].lid}"{if $smarty.session.preferences.start_page!=null && $smarty.session.preferences.start_page=="b_`$cats[blog_cat].lid`"} selected="selected"{/if}>{$cats[blog_cat].name}</option>
								{sectionelse}
									{t k="tpl_index_menu_err_nocats"}
								{/section}
							</optgroup>
						{/if}
													
						{if $smarty.const.FUNC_DOWNLOADS}
							<optgroup label="{t k="tpl_index_menu_downloads"}">
								<option value="d_all"{if $smarty.session.preferences.start_page!=null && $smarty.session.preferences.start_page=="d_all"} selected="selected"{/if}>{t k="tpl_index_menu_new_downloads"}</option>
									{section name="dl_cat" loop=$dl_cats}
										{if isset($dl_cats[dl_cat].subcats)}
										<option value="d_{$dl_cats[dl_cat].lid}"{if $smarty.session.preferences.start_page!=null && $smarty.session.preferences.start_page=="d_`$dl_cats[dl_cat].lid`"} selected="selected"{/if}>{$dl_cats[dl_cat].name}</option>
										{section name="dl_subcat" loop=$dl_cats[dl_cat].subcats}
											<option value="d_{$dl_cats[dl_cat].lid}/{$dl_cats[dl_cat].subcats[dl_subcat].lid}"{if $smarty.session.preferences.start_page!=null && $smarty.session.preferences.start_page=="d_`$dl_cats[dl_cat].lid`/`$dl_cats[dl_cat].subcats[dl_subcat].lid`"} selected="selected"{/if}>{$dl_cats[dl_cat].name} &#187; {$dl_cats[dl_cat].subcats[dl_subcat].name}</option>
										{/section}
										{/if}
									{sectionelse}
										{t k="tpl_index_menu_err_nocats"}
									{/section}
							</optgroup>
						{/if}
						</select><br/>
			</div>
			<div class="spacer"></div>
			{/if}
			
			{if $smarty.const.FUNC_BLOG}
				<div class="box">
					<span>{t k="tpl_user_preferences_blogposts_perpage"}:</span> <select name="blog_no">
															<option value="5"{if $smarty.session.preferences.blog_no==5} selected="selected"{/if}>5</option>
															<option value="10"{if $smarty.session.preferences.blog_no==10} selected="selected"{/if}>10</option>
															<option value="15"{if $smarty.session.preferences.blog_no==15} selected="selected"{/if}>15</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
			{/if}
			
			{if $smarty.const.FUNC_DOWNLOADS}
				<div class="box">
					<span>{t k="tpl_user_preferences_downloadposts_perpage"}:</span> <select name="downloads_no">
															<option value="10"{if $smarty.session.preferences.downloads_no==10} selected="selected"{/if}>10</option>
															<option value="15"{if $smarty.session.preferences.downloads_no==15} selected="selected"{/if}>15</option>
															<option value="20"{if $smarty.session.preferences.downloads_no==20} selected="selected"{/if}>20</option>
															<option value="25"{if $smarty.session.preferences.downloads_no==25} selected="selected"{/if}>25</option>
															<option value="30"{if $smarty.session.preferences.downloads_no==30} selected="selected"{/if}>30</option>
															<option value="35"{if $smarty.session.preferences.downloads_no==35} selected="selected"{/if}>35</option>
															<option value="40"{if $smarty.session.preferences.downloads_no==40} selected="selected"{/if}>40</option>
															<option value="45"{if $smarty.session.preferences.downloads_no==45} selected="selected"{/if}>45</option>
															<option value="50"{if $smarty.session.preferences.downloads_no==50} selected="selected"{/if}>50</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
			{/if}
			
			{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_HTTP && $smarty.const.FUNC_DOWNLOADS_TORRENT}
				<div class="box">
					<span>{t k="tpl_user_preferences_dltype"}:</span> <select name="downloads_type">
															<option value="0"{if $smarty.session.preferences.downloads_type==0} selected="selected"{/if}>{t k="tpl_user_preferences_dltype_all"}</option>
															<option value="1"{if $smarty.session.preferences.downloads_type==1} selected="selected"{/if}>{t k="tpl_user_preferences_dltype_torrents"}</option>
															<option value="2"{if $smarty.session.preferences.downloads_type==2} selected="selected"{/if}>{t k="tpl_user_preferences_dltype_http"}</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
			{/if}
			
			{if $smarty.const.FUNC_BLOG || $smarty.const.FUNC_DOWNLOADS}
				<div class="box">
					<span>{t k="tpl_user_preferences_comments_perpage"}:</span> <select name="comments_no">
															<option value="5"{if $smarty.session.preferences.comments_no==5} selected="selected"{/if}>5</option>
															<option value="10"{if $smarty.session.preferences.comments_no==10} selected="selected"{/if}>10</option>
															<option value="15"{if $smarty.session.preferences.comments_no==15} selected="selected"{/if}>15</option>
															<option value="20"{if $smarty.session.preferences.comments_no==20} selected="selected"{/if}>20</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_preferences_comments_sorting"}:</span> <select name="comments_dir">
															<option value="0"{if $smarty.session.preferences.comments_dir==0} selected="selected"{/if}>{t k="tpl_user_preferences_comments_sorting_old"}</option>
															<option value="1"{if $smarty.session.preferences.comments_dir==1} selected="selected"{/if}>{t k="tpl_user_preferences_comments_sorting_new"}</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
			{/if}
			
			{if $smarty.const.FUNC_FORUMS}
				<div class="box">
					<span>{t k="tpl_user_preferences_forumthreads_perpage"}:</span> <select name="forum_threads_no">
															<option value="10"{if $smarty.session.preferences.forum_threads_no==10} selected="selected"{/if}>10</option>
															<option value="15"{if $smarty.session.preferences.forum_threads_no==15} selected="selected"{/if}>15</option>
															<option value="20"{if $smarty.session.preferences.forum_threads_no==20} selected="selected"{/if}>20</option>
															<option value="25"{if $smarty.session.preferences.forum_threads_no==25} selected="selected"{/if}>25</option>
															<option value="30"{if $smarty.session.preferences.forum_threads_no==30} selected="selected"{/if}>30</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_preferences_forumposts_perpage"}:</span> <select name="forum_posts_no">
															<option value="5"{if $smarty.session.preferences.forum_posts_no==5} selected="selected"{/if}>5</option>
															<option value="10"{if $smarty.session.preferences.forum_posts_no==10} selected="selected"{/if}>10</option>
															<option value="15"{if $smarty.session.preferences.forum_posts_no==15} selected="selected"{/if}>15</option>
															<option value="20"{if $smarty.session.preferences.forum_posts_no==20} selected="selected"{/if}>20</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_preferences_forumposts_sorting"}:</span> <select name="forum_posts_dir">
															<option value="0"{if $smarty.session.preferences.forum_posts_dir==0} selected="selected"{/if}>{t k="tpl_user_preferences_forumposts_sorting_old"}</option>
															<option value="1"{if $smarty.session.preferences.forum_posts_dir==1} selected="selected"{/if}>{t k="tpl_user_preferences_forumposts_sorting_new"}</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
			{/if}	
				
			{if $smarty.const.FUNC_PM}
				<div class="box">
					<span>{t k="tpl_user_preferences_pm_perpage"}:</span> <select name="private_no">
															<option value="10"{if $smarty.session.preferences.private_no==10} selected="selected"{/if}>10</option>
															<option value="20"{if $smarty.session.preferences.private_no==20} selected="selected"{/if}>20</option>
															<option value="30"{if $smarty.session.preferences.private_no==30} selected="selected"{/if}>30</option>
															<option value="40"{if $smarty.session.preferences.private_no==40} selected="selected"{/if}>40</option>
														</select><br/>
				</div>
				<div class="spacer"></div>
			{/if}
			
			<div class="box">
				<span>{t k="tpl_user_preferences_language"}:</span> <select name="language">
														{section name="lang" loop=$language_list}
															<option value="{$language_list[lang].file}"{if $smarty.session.preferences.language==$language_list[lang].file} selected="selected"{/if}>{t k="tpl_user_preferences_language_option" a="`$language_list[lang].own_title`|`$language_list[lang].author`"}</option>
														{/section}
													</select><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_preferences_template"}:</span> <select name="template">
														{section name="tpl" loop=$template_list}
															<option value="{$template_list[tpl].id}"{if $smarty.session.preferences.template==$template_list[tpl].id} selected="selected"{/if}>{t k="tpl_user_preferences_template_option" a="`$template_list[tpl].title`|`$template_list[tpl].author`"}</option>
														{/section}
													</select><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_preferences_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{/if}
	
{elseif $args[1]=='profile'}
	{if !isset($smarty.session.logged) || !$smarty.session.logged}
		<p>{t k="err_not_logged"}</p>
	{else}
		{if $args[2]!=null}
			{section name="err" loop=$err}
				<div class="big_message big_message_err">{$err[err]}</div>
			{sectionelse}
				<div class="big_message">{if isset($okmsg)}{$okmsg}{else}{t k="tpl_user_profile_succ"}{/if}</div>
			{/section}
		{/if}
		{* Form *}
		<form action="{link url="user/profile/userinfo"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_profile_name"}:</span> <input type="text" name="name" value="{if isset($smarty.post.name)}{$smarty.post.name|escape:"html"}{else}{$userinfo.pr_name}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_gender"}:</span> 
					<div class="fl_right">
						<input type="radio" name="gender" value="1" style="float: none; width: auto; border: 0"{if $userinfo.pr_gender==1} checked="checked"{/if} />{t k="tpl_user_profile_gender_male"}
						<input type="radio" name="gender" value="2" style="float: none; width: auto; border: 0"{if $userinfo.pr_gender==2} checked="checked"{/if} />{t k="tpl_user_profile_gender_female"}
						<input type="radio" name="gender" value="3" style="float: none; width: auto; border: 0"{if $userinfo.pr_gender==3} checked="checked"{/if} />{t k="tpl_user_profile_gender_unknown"}
					</div> <br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_birthdate"}:</span> <div class="tdate">{html_select_date time=$userinfo.pr_birth start_year="-100" end_year="-10" month_format="%m" field_order="YMD" field_separator=" /\n" reverse_years=true year_empty="--" month_empty="--" day_empty="--"}</div><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_location"}:</span> <input type="text" name="location" value="{if isset($smarty.post.location)}{$smarty.post.location|escape:"html"}{else}{$userinfo.pr_location}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_avatar"}:</span> <input type="text" name="avatar" value="{if isset($smarty.post.avatar)}{$smarty.post.avatar|escape:"html"}{else}{$userinfo.pr_avatar}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_page"}:</span> <input type="text" name="page" value="{if isset($smarty.post.page)}{$smarty.post.page|escape:"html"}{else}{$userinfo.pr_page}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_skype"}:</span> <input type="text" name="skype" value="{if isset($smarty.post.skype)}{$smarty.post.skype|escape:"html"}{else}{$userinfo.pr_skype}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_msn"}:</span> <input type="text" name="msn" value="{if isset($smarty.post.msn)}{$smarty.post.msn|escape:"html"}{else}{$userinfo.pr_msn}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_icq"}:</span> <input type="text" name="icq" value="{if isset($smarty.post.icq)}{$smarty.post.icq|escape:"html"}{else}{if $userinfo.pr_icq!=0}{$userinfo.pr_icq}{/if}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_yahoo"}:</span> <input type="text" name="yahoo" value="{if isset($smarty.post.yahoo)}{$smarty.post.yahoo|escape:"html"}{else}{$userinfo.pr_yahoo}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_gtalk"}:</span> <input type="text" name="gtalk" value="{if isset($smarty.post.gtalk)}{$smarty.post.gtalk|escape:"html"}{else}{$userinfo.pr_gtalk}{/if}" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_profile_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
			{if isset($cust_user)}<input type="hidden" name="cust_user" value="{$cust_user|escape:"html"}" />{/if}
		</form>
		<br/><br/>
		
		{* Form *}
		<form action="{link url="user/profile/email"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_profile_changemail"}:</span> <input type="text" name="email1" value="{if isset($cust_user)}{$userinfo.email}{/if}" /><br/>
				{if $smarty.const.FUNC_USER_VALIDATION && !isset($cust_user)}
					<div class="tip">{t k="tpl_user_profile_changemail_tip"}</div>
				{/if}
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_changemail_repeat"}:</span> <input type="text" name="email2" maxlength="32" value="" /><br/>
			</div>
			<div class="spacer"></div>
			{if !isset($cust_user)}
				<div class="box">
					<span>{t k="tpl_user_profile_changemail_password"}:</span> <input type="password" name="pass" value="" /><br/>
					<div class="tip">
						{t k="tpl_user_profile_changemail_password_tip"}
					</div>
				</div>
				<div class="spacer"></div>
			{/if}
			<div class="box">
				<input type="submit" value="{t k="tpl_user_profile_changemail_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
			{if isset($cust_user)}<input type="hidden" name="cust_user" value="{$cust_user|escape:"html"}" />{/if}
		</form>
		<br/><br/>
		
		{* Form *}
		<form action="{link url="user/profile/pass"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_profile_changepass"}:</span> <input type="password" name="pass1" value="" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_changepass_repeat"}:</span> <input type="password" name="pass2" value="" /><br/>
			</div>
			<div class="spacer"></div>
			{if !isset($cust_user)}
				<div class="box">
					<span>{t k="tpl_user_profile_changepass_old"}:</span> <input type="password" name="pass" value="" /><br/>
				</div>
				<div class="spacer"></div>
			{/if}
			<div class="box">
				<input type="submit" value="{t k="tpl_user_profile_changepass_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
			{if isset($cust_user)}<input type="hidden" name="cust_user" value="{$cust_user|escape:"html"}" />{/if}
		</form>
		<br/><br/>
		
		{* Form *}
		{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false}
		<form action="{link url="user/profile/torrentpass"}" method="post" class="reg_form">
			<div class="box">
				<div class="nofloat">
					<input type="checkbox" name="torrent_pass" /> {t k="tpl_user_profile_torrentpass"}<br/>
				</div>
				<div class="tip">
					{t k="tpl_user_profile_torrentpass_tip"}
				</div>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_profile_torrentpass_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
			{if isset($cust_user)}<input type="hidden" name="cust_user" value="{$cust_user|escape:"html"}" />{/if}
		</form>
		{/if}
		
		{if isset($cust_user)}
		<br/><br/>
		{* Form *}
		<form action="{link url="user/profile/admin"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_profile_admin_status"}:</span> <input type="text" name="status" value="{if isset($smarty.post.status)}{$smarty.post.status|escape:"html"}{else}{$userinfo.status|escape:"html"}{/if}" maxlength="40" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_admin_blogposts"}:</span> <input type="text" name="blogposts" value="{if isset($smarty.post.blogposts)}{$smarty.post.blogposts|escape:"html"}{else}{$userinfo.blogposts}{/if}" maxlength="5" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_admin_downloadposts"}:</span> <input type="text" name="downloadposts" value="{if isset($smarty.post.downloadposts)}{$smarty.post.downloadposts|escape:"html"}{else}{$userinfo.downloadposts}{/if}" maxlength="5" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_admin_comments"}:</span> <input type="text" name="comments" value="{if isset($smarty.post.comments)}{$smarty.post.comments|escape:"html"}{else}{$userinfo.comments}{/if}" maxlength="5" /><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_profile_admin_forumposts"}:</span> <input type="text" name="forumposts" value="{if isset($smarty.post.forumposts)}{$smarty.post.forumposts|escape:"html"}{else}{$userinfo.forumposts}{/if}" maxlength="5" /><br/>
			</div>
			<div class="spacer"></div>
			{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false}
				<div class="box">
					<span>{t k="tpl_user_profile_admin_wait_time"}:</span> <input type="text" name="wait_time" value="{if isset($smarty.post.wait_time)}{$smarty.post.wait_time|escape:"html"}{else}{$userinfo.wait_time}{/if}" maxlength="11" /><br/>
					<div class="tip">
						{t k="tpl_user_profile_admin_wait_time_tip"}
					</div>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_profile_admin_peers_limit"}:</span> <input type="text" name="peers_limit" value="{if isset($smarty.post.peers_limit)}{$smarty.post.peers_limit|escape:"html"}{else}{$userinfo.peers_limit}{/if}" maxlength="11" /><br/>
					<div class="tip">
						{t k="tpl_user_profile_admin_peers_limit_tip"}
					</div>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_profile_admin_torrents_limit"}:</span> <input type="text" name="torrents_limit" value="{if isset($smarty.post.torrents_limit)}{$smarty.post.torrents_limit|escape:"html"}{else}{$userinfo.torrents_limit}{/if}" maxlength="11" /><br/>
					<div class="tip">
						{t k="tpl_user_profile_admin_torrents_limit_tip"}
					</div>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_profile_admin_downloaded"}:</span> <input type="text" name="downloaded" value="{if isset($smarty.post.downloaded)}{$smarty.post.downloaded|escape:"html"}{else}{$userinfo.downloaded}{/if}" maxlength="20" /><br/>
					<div class="tip">
						{t k="tpl_user_profile_admin_downloaded_tip"}
					</div>
				</div>
				<div class="spacer"></div>
				<div class="box">
					<span>{t k="tpl_user_profile_admin_uploaded"}:</span> <input type="text" name="uploaded" value="{if isset($smarty.post.uploaded)}{$smarty.post.uploaded|escape:"html"}{else}{$userinfo.uploaded}{/if}" maxlength="20" /><br/>
					<div class="tip">
						{t k="tpl_user_profile_admin_downloaded_tip"}
					</div>
				</div>
				<div class="spacer"></div>
			{/if}
			<div class="box">
				<input type="submit" value="{t k="tpl_user_profile_admin_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
			{if isset($cust_user)}<input type="hidden" name="cust_user" value="{$cust_user|escape:"html"}" />{/if}
		</form>
		{/if}
	{/if}
	
	
{elseif $args[1]=='ban'}
	{if $err==true}
		<p>{t k="error"}</p>
	{else}	
		{* Form *}
		{if $args[3]==2}
			{if $err}
				<div class="big_message big_message_err">{t k="error"}</div>
			{else}
				<div class="big_message">{t k="tpl_user_ban_succ"}</div>
			{/if}
		{/if}
		<form action="{link url="user/ban/$args[2]/2"}" method="post" class="reg_form">
			<div class="box">
				<span>{t k="tpl_user_ban_username"}: </span>
				<div class="fl_right">
					{$user.name}
				</div><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<span>{t k="tpl_user_ban_type"}:</span> 
				<div class="fl_right">
					<input type="checkbox" name="warned" style="float: none; width: auto; border: 0"{if $user.warned==1} checked="checked"{/if} /> {t k="tpl_user_ban_warn"}
					<input type="checkbox" name="noleech" style="float: none; width: auto; border: 0"{if $user.can_leech==0} checked="checked"{/if} /> {t k="tpl_user_ban_noleech"}
					<input type="checkbox" name="banned" style="float: none; width: auto; border: 0"{if $user.banned==1} checked="checked"{/if} /> {t k="tpl_user_ban_banned"}
				</div><br/>
			</div>
			<div class="spacer"></div>
			<div class="box">
				<input type="submit" value="{t k="tpl_user_ban_submit"}" class="submit" />
			</div>
			<div class="form_foot_rounded"></div>
		</form>
	{/if}
	
{/if}