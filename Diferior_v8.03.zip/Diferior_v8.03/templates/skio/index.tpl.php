{* Smarty *}
{*<?php die(); ?>*}
{assign var="template_name" value="skio"}
{php}
	header ( 'Content-Type: text/html; charset=utf-8' );
	header ( 'Cache-Control: no-store, no-cache, must-revalidate' );
{/php}
{assign var="smurl" value="http://`$smarty.const.URL`/"}
{assign var="rsurl" value="`$smurl`tpl_resources/`$template_name`/"}
{assign var="imurl" value="`$rsurl`images/"}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	
	<head>
		<title>{$title}</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta http-equiv="Cache-Control" content="no-cache"/>
 		<style type="text/css" media="all">
			@import "{$rsurl}style/style.css";
			
			
			{* Uncomment this to move menu to the right side of content *}
			{*
				@import "{$rsurl}style/menu_right.css";
			*}
						
			{section name="style" loop=$stylesheets}
				@import "{$rsurl}style/{$stylesheets[style]}";
			{/section}
			{section name="style_tpl" loop=$stylesheets_template}
				@import "{$rsurl}style/{$stylesheets_template[style_tpl]}";
			{/section}
			{if isset($args[3]) && $args[3]=='print'}
				@import "{$rsurl}style/print.css";
			{/if}
		</style>
 		{if $smarty.const.FUNC_RSS}
 			{if $smarty.const.FUNC_BLOG}<link rel="alternate" type="application/rss+xml" title="{t k="tpl_rss_blog"}" href="{link url="rss/blog.xml"}"/>{/if}
			{if $smarty.const.FUNC_DOWNLOADS}<link rel="alternate" type="application/rss+xml" title="{t k="tpl_rss_downloads"}" href="{link url="rss/downloads.xml"}"/>{/if}
		{/if}
		<link rel="icon" href="{$imurl}favicon.ico" type="image/x-icon" />
		{*<link rel="shortcut icon" href="{$imurl}favicon.ico" />*}
 		<script type="text/javascript">
 			var logged={if isset($smarty.session.logged) && $smarty.session.logged===true}true{else}false{/if};
 			var main_url='{$smarty.const.URL}';
 			var external_pfx='{link url="out/_" addsid=false}';
 			var infobanner_url='{link url="infobanner"}';
 			{if isset($smarty.session.logged) && $smarty.session.logged===true}
 				{if $smarty.session.permissions.make_posts==1}
 					var post_preview_url = '{link url="post/new/preview"}';
 				{/if}
 				{if $view == 'upload'}
 					var upload_preview_url = '{link url="upload/new/preview"}';
 				{/if}
 			{/if}
 			{if $view == 'file' && $error == false}
 				var file_req_seed_url = '{link url="peers/seeders"}';
 				var file_req_leech_url = '{link url="peers/leechers"}';
 			{/if}
 		</script>
 		
 		<script src="{$rsurl}scripts/javascript.js" type="text/javascript"></script>
 		{section name="js" loop=$javascripts}
				<script src="{$rsurl}scripts/{$javascripts[js]}" type="text/javascript"></script>
		{/section}
	</head>
	
	<body>
	
		<div class="global_holder">
			
			<div class="top">
				<div class="header">
					<a href="{link url="_"}">{$smarty.const.PAGE_NAME}</a>
					{$smarty.const.PAGE_SLOGAN}
				</div>
				<div class="right_menu">
					<div class="user_menu">
						{if isset($smarty.session.logged) && $smarty.session.logged===true}
							<b><a href="{link url="user/v/`$smarty.session.user`"}">{$smarty.session.user}</a></b> | {if $smarty.const.FUNC_PM}<a href="{link url="pm"}">{t k="tpl_index_pm"}</a> | {/if}<a href="{link url="user/profile"}">{t k="tpl_index_profile"}</a> | <a href="{link url="user/preferences"}">{t k="tpl_index_preferences"}</a>
							{if $smarty.session.permissions.admin==1}
								| <a href="{link url="admin"}">{t k="tpl_index_admin"}</a>
							{/if}
							| <a href="{link url="user/logoff"}">{t k="tpl_index_logoff"}</a>
						{else}
							<a href="{link url="user/register"}">{t k="tpl_index_register"}</a> | <b><a href="{link url="user/login"}">{t k="tpl_index_login"}</a></b>
						{/if}
					</div>
					<form action="{link url="search"}" method="post" name="search">
						<input type="text" name="search" class="search_input" value="{if $view=='search' && isset ($args[2]) && $args[1]!='blog_tag' && $args[1]!='downloads_tag'}{$args[2]|urldecode|escape:"html"}{else}{t k="tpl_index_search_phrase"}{/if}" onfocus="javascript:emptydef(this,'{t k="tpl_index_search_phrase"}')" />
						<select name="type" class="search_select">
							{if $smarty.const.FUNC_BLOG}<option value="blog"{if $view=='cat' || $view=='read' || ( $view=='search' && isset ($args[1]) && $args[1]=='blog')} selected="selected"{/if}>{t k="tpl_index_search_blog"}</option>{/if}
							{if $smarty.const.FUNC_DOWNLOADS}<option value="downloads"{if $view=='downloads' || $view=='file' || ( $view=='search' && isset ($args[1]) && $args[1]=='downloads' )} selected="selected"{/if}>{t k="tpl_index_search_downloads"}</option>{/if}
							{if $smarty.const.FUNC_FORUMS}<option value="forums"{if $view=='forum' || ( $view=='search' && isset ($args[1]) && $args[1]=='forums' )} selected="selected"{/if}>{t k="tpl_index_search_forums"}</option>{/if}
							<option value="users"{if $view=='search' && isset ($args[1]) && $args[1]=='users'} selected="selected"{/if}>{t k="tpl_index_search_users"}</option>
						</select>
						<input type="submit" class="search_submit" value="{t k="tpl_index_search_button"}" />
					</form>
				</div>
				<div class="info_box">
					{if isset($smarty.session.logged) && $smarty.session.logged===true}
						{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false }
							<span>
								{img src="`$imurl`userinfo/downloaded.gif" alt="Dl"} {$smarty.session.userinfo.downloaded|format_size}
							</span>
							<span>
								{img src="`$imurl`userinfo/uploaded.gif" alt="Ul"} {$smarty.session.userinfo.uploaded|format_size}
							</span>
							<span>
								{img src="`$imurl`userinfo/ratio.gif" alt="R"} 
							{if $smarty.session.userinfo.downloaded==0}&#8734;{else}{$smarty.session.userinfo.uploaded/$smarty.session.userinfo.downloaded|string_format:"%.2f"|colorize:1}{/if}
							</span>
						{/if}
							
						{if $smarty.session.userinfo.warned==1}
							<span>
								{if $smarty.session.userinfo.warned_manual==1}
									{img src="`$imurl`userinfo/warning.gif" alt="!"}
								{elseif !$smarty.const.TRACKER_ANONYMOUS}
									<a href="{link url="ratio_warning"}">{img src="`$imurl`userinfo/warning.gif" alt="!"}</a>
								{/if}
							</span>
						{/if}
					{/if}
				</div>
				<div class="statistics">
					{if $smarty.const.FUNC_COUNTERS && $smarty.const.CACHE_STATIC==null}
						<b>+{$counter.today} / {$counter.total}</b> ( <a href="javascript:popup('{link url="online"}');" class="online">{t k="tpl_index_online" a=$online}</a> )
					{/if}
				</div>
			</div> {* top *}
		
			<div class="middle_holder">
			
				<div class="content_holder">
						{if $smarty.const.FUNC_PM && isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.userinfo.private_new>0 && $view != 'pm'}
							<div class="big_message">
								<a href="{link url="pm"}">
									{img src="`$imurl`pm_icon.gif" alt="!"}<br/>
									{t k="tpl_index_newpm"}
								</a>
							</div>
						{/if}
					
						<h1>{$header|truncate:43:'...':true}</h1>
						{if $subheader != null}<h2>{$subheader}</h2>{/if}
						<br/>
						{include file="`$template_name`/`$view`.tpl.php"}
						
				</div>	{* content_holder *}
				
				
				<div class="menu">
					<h3><span class="fl_left">{img src="`$imurl`menu_images/main.gif" alt=""} {t k="tpl_index_menu_main"}</span></h3>
					<div class="rounded_holder">
						<ul>
							<li><a href="{link url="_"}" class="first {cycle values="c1, c2"}">{t k="tpl_index_menu_title"}</a></li>
							{if $smarty.const.FUNC_FORUMS}<li><a href="{link url="forum"}" class="{cycle values="c1, c2"}">{t k="tpl_index_menu_forum"}</a></li>{/if}
							{if $smarty.const.FUNC_CONTACT}<li><a href="{link url="contact"}" class="{cycle values="c1, c2"}">{t k="tpl_index_menu_contact"}</a></li>{/if}
							{if $smarty.const.FUNC_RSS}<li><a href="{link url="rss"}" class="last {cycle values="c1, c2"}">{t k="tpl_index_menu_rss"} {img src="`$imurl`rss.gif" alt=""}</a></li>{/if}
						</ul>
					</div>
								
					
					
					
					{* Blog menu. This code can be moved around to rearrange menu. *}
					{if $smarty.const.FUNC_BLOG}
					<h3><span class="fl_left">{img src="`$imurl`menu_images/blog.gif" alt=""} {t k="tpl_index_menu_blog"}</span></h3>
					<div class="rounded_holder">
						<ul>
							<li><a href="{link url="blog"}" class="first {cycle values="c1, c2"}">{t k="tpl_index_menu_new_posts"}</a></li>
							{section name="cat" loop=$cats}
								<li>
									<a href="{link url="blog/`$cats[cat].lid`"}" class="{cycle values="c1, c2"}{if $smarty.section.cat.last} last{/if}" {if $cats[cat].color!=null} style="color: #{$cats[cat].color}"{/if} >{$cats[cat].name}</a>
								</li>
							{sectionelse}
								<li><a href="#" class="{cycle values="c1, c2"}"><span>{t k="tpl_index_menu_err_nocats"}</span></a></li>
							{/section}
						</ul>
						{if $blog_tags_max>0}
							{math equation="10/tags" tags=$blog_tags_max assign="step"}
							<div class="tags_holder">
								{foreach from=$blog_tags key=tag item=size}
									{assign var="tag" value=$tag|escape:"html"}
									<a href="{link url="search/blog_tag/`$tag`"}"{if $size>1}{math equation="(size*step)+10" size=$size step=$step assign="size"} style="font-size: {$size|ceil}px" class="hl"{/if}>{$tag}</a>
								{/foreach}
							</div>
						{/if}
					</div>
					{/if}
					{* End of blog menu *}
							
						
						
						
					{* Downloads menu. This code can be moved around to rearrange menu. *}
					{if $smarty.const.FUNC_DOWNLOADS}
					<h3><span class="fl_left">{img src="`$imurl`menu_images/downloads.gif" alt=""} {t k="tpl_index_menu_downloads"}</span></h3>
					<div class="rounded_holder">
						<ul>
							<li><a href="{link url="downloads"}" class="first {cycle values="c1, c2"}">{t k="tpl_index_menu_new_downloads"}</a></li>
							{section name="dl_cat" loop=$dl_cats}
								<li>
									{if isset($smarty.session.subcats) && $dl_cats[dl_cat].id==$smarty.session.subcats.0}{assign var="has_subcats" value=true}{else}{assign var="has_subcats" value=false}{/if}
									<a href="{link url="downloads/`$dl_cats[dl_cat].lid`"}" class="{cycle values="c1, c2"}{if $has_subcats==false && $smarty.section.dl_cat.last} last{/if}" {if $dl_cats[dl_cat].color!=null} style="color: #{$dl_cats[dl_cat].color}"{/if} >{$dl_cats[dl_cat].name}</a>
									{if $has_subcats}	
										<span>
											{section name="dl_subcat" loop=$smarty.session.subcats.1}
												<a href="{link url="downloads/`$dl_cats[dl_cat].lid`/`$smarty.session.subcats.1[dl_subcat].lid`"}" class="{cycle values="c1, c2"}{if $smarty.section.dl_cat.last && $smarty.section.dl_subcat.last} last{/if}">{$smarty.session.subcats.1[dl_subcat].name}</a>
											{/section}
										</span>
									{/if}
								</li>
							{sectionelse}
								<li><a href="#" class="{cycle values="c1, c2"}"><span>{t k="tpl_index_menu_err_nocats"}</span></a></li>
							{/section}
						</ul>
						{if $dl_tags_max>0}
							{math equation="10/tags" tags=$dl_tags_max assign="step"}
							<div class="tags_holder">
								{foreach from=$dl_tags key=tag item=size}
									{assign var="tag" value=$tag|escape:"html"}
									<a href="{link url="search/downloads_tag/`$tag`"}"{if $size>1}{math equation="(size*step)+10" size=$size step=$step assign="size"} style="font-size: {$size|ceil}px" class="hl"{/if}>{$tag}</a>
								{/foreach}
							</div>
						{/if}
					</div>
					{/if}
					{* End of downloads menu. *}
					
					
					
						
					{if isset($smarty.session.logged) && $smarty.session.logged===true }
						{if $smarty.const.FUNC_BLOG && $smarty.session.permissions.make_posts==1}
							<h3><span class="fl_left">{img src="`$imurl`menu_images/posting.gif" alt=""} {t k="tpl_index_menu_posting"}</span></h3>
							<div class="rounded_holder">
								<ul>
									<li><a href="{link url="post/new"}" class="first {cycle values="c1, c2"}">{t k="tpl_index_menu_post"}</a></li>
									<li><a href="{link url="post/list"}" class="last {cycle values="c1, c2"}">{t k="tpl_index_menu_my_posts"}</a></li>
								</ul>
							</div>
						{/if}
						
						{if $smarty.const.FUNC_DOWNLOADS}
							<h3><span class="fl_left">{img src="`$imurl`menu_images/downloads2.gif" alt=""} {t k="tpl_index_menu_downloads"}</span></h3>
							<div class="rounded_holder">
								<ul>
									<li><a href="{link url="upload/new"}" class="first {cycle values="c1, c2"}">{t k="tpl_index_menu_add_download"}</a></li>
									{if $smarty.session.permissions.approve_downloads==1}<li><a href="{link url="upload/pending"}" class="{cycle values="c1, c2"}">{t k="tpl_index_menu_pending"}</a></li>{/if}
									{if $smarty.const.LOG && $smarty.session.permissions.view_log==1}<li><a href="{link url="upload/log"}" class="{cycle values="c1, c2"}">{t k="tpl_index_menu_log"}</a></li>{/if}
									{if $smarty.session.permissions.cheater_list==1 && $smarty.const.FUNC_DOWNLOADS_TORRENT && !$smarty.const.TRACKER_ANONYMOUS}<li><a href="{link url="upload/cheaters"}" class="{cycle values="c1, c2"}">{t k="tpl_index_menu_cheaters"}</a></li>{/if}
									<li><a href="{link url="upload/list"}" class="last {cycle values="c1, c2"}">{t k="tpl_index_menu_my_downloads"}</a></li>
								</ul>
							</div>
						{/if}	
					{/if}
				</div> {* menu *}
						
			</div> {* middle_holder *}
				
			<div class="footer_push"></div>
			
		</div>	{* global_holder *}
		
		<div class="copyright">
			{* 
				VERY IMPORTANT
				
				Removal of the following 'Powered by'/'Copyright' message(s) without an exclusive permission from the author(s) is a direct breach
				of script's distribution and usage LICENSE.
				
				Please respect our hard work and leave credit where it's due.
			*}
			<a href="{link url="tos"}">{t k="tpl_index_tos"}</a> | <a href="{link url="copyright"}">{t k="tpl_index_copyright"}</a> | 
			<a href="{link url="privacy"}">{t k="tpl_index_privacy"}</a> | <a href="{link url="disclaimer"}">{t k="tpl_index_disclaimer"}</a>
			{if $smarty.const.GENERATION_TIME && $smarty.const.CACHE_STATIC==null}
				<span class="debug">
				{assign var='dbg_end_tpl' value=0|microtime}
				{assign var='dbg_end_tpl' value=' '|explode:$dbg_end_tpl}
				{assign var='dbg_end_tpl' value=$dbg_end_tpl|@array_sum}
				{assign var='dbg_tpl_diff' value=$dbg_end_tpl-$dbg_end}
				<br/><br/>{t k="tpl_index_generated"}: {$dbg_diff+$dbg_tpl_diff|string_format:"%.5f"} sec
				(PHP: {$dbg_diff|string_format:"%.3f"} sec, DB: {$dbg_query_time|string_format:"%.3f"} sec ({$dbg_query_count}), TPL: {$dbg_tpl_diff|string_format:"%.3f"} sec)
				</span>
			{/if}
			<div class="bot">
				<a href="http://diferior.com" rel="external_dif">Powered by Diferior, Copyright &copy; 2007, 2008 Povilas Musteikis</a><br/>
				<a href="http://witkuz.com" class="small" rel="external">Design is copyright &copy; 2007, 2008 witkuz</a>
			</div>
		</div>
		
	</body>
</html>