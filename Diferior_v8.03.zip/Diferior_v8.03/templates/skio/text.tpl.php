{* Smarty *}
{*<?php die(); ?>*}

{if $text == 'tos'}
 	<p>
 		{assign var="tos_link"	value="tos"|link}
 		{assign var="copyright_link"	value="copyright"|link}
 		{assign var="privacy_link"	value="privacy"|link}
 		{assign var="disclaimer_link"	value="disclaimer"|link}
 		{t k="tpl_text_tos" a="$tos_link|$copyright_link|$privacy_link|$disclaimer_link"}
 	</p>
 		                  
{elseif $text == 'copyright'}
	<p>
		{t k="tpl_text_copyright"}
	</p>

{elseif $text == 'privacy'}
	<p>
		{t k="tpl_text_privacy"}
	</p>
	
{elseif $text == 'disclaimer'}
	<p>
		{t k="tpl_text_disclaimer_1"}
 	</p><br/>
 	<p>
		{t k="tpl_text_disclaimer_2"}
 	</p><br/>
 	<p>
		{t k="tpl_text_disclaimer_3"}
 	</p><br/>
 	<p>
		{t k="tpl_text_disclaimer_4"}
 	</p><br/>
 	<p>
		{t k="tpl_text_disclaimer_5"}
 	</p>
 	
{elseif $text == 'howto_torrents'}
	<p>
		{t k="tpl_text_howto_torrents_about"}
	</p><br/>
	<p>
		{t k="tpl_text_howto_torrents_clients"}:<br/>
		<a href="http://www.utorrent.com" rel="external">µTorrent</a><br/>
		<a href="http://azureus.sourceforge.net/" rel="external">Azureus</a><br/>
		<a href="http://www.bittorrent.com/" rel="external">BitTorrent</a><br/>
		<a href="http://transmission.m0k.org/" rel="external">Transmission</a><br/>
	</p><br/><br/>
	<p>
		{t k="tpl_text_howto_torrents_buzzwords"}:<br/>
		<b>Leecher</b> – {t k="tpl_text_howto_torrents_leecher"}<br/>
		<b>Peer</b> – {t k="tpl_text_howto_torrents_peer"}<br/>
		<b>Seeder</b> – {t k="tpl_text_howto_torrents_seeder"}<br/>
		<b>Swarm</b> - {t k="tpl_text_howto_torrents_swarm"}<br/>
		<b>Torrent</b> – {t k="tpl_text_howto_torrents_torrent"}<br/>
		<b>Tracker</b> – {t k="tpl_text_howto_torrents_tracker"}<br/>
	</p>
	
{elseif $text == 'ratio_warning'}	
	<p>
		{t k="tpl_text_ratio_warning"}
	</p>
	
{elseif $text == 'creating_torrent'}	
	<p>
		{t k="tpl_text_creating_torrent_1"}<br/>
	</p><br/>
	<p>
		<a href="http://azureus.sourceforge.net/" rel="external">Azureus</a>:<br/>
		{t k="tpl_text_creating_torrent_azureus"}
	</p><br/>
	<p>{t k="tpl_text_creating_torrent_after_1"}:<br/>
		{t k="tpl_text_creating_torrent_after_2"}
	</p>

{elseif $text == 'upload_rules'}
	<p>
		{t k="tpl_text_upload_rules_rules"}
	</p><br/><br/><br/>
	<a name="guidelines"></a>
	<p>
		{t k="tpl_text_upload_rules_guidelines"}
	</p><br/>
	<p>
		{t k="tpl_text_upload_rules_guidelines_torrent"}
	</p><br/>
	<p>
		{t k="tpl_text_upload_rules_guidelines_http"}
	</p><br/><br/><br/>
	<a name="description"></a>
	<p>
		{t k="tpl_text_upload_rules_description" a=$smarty.const.WATERMARK_URL}
	</p>
	
{elseif $text == 'bitlet'}
	<p>
		{t k="tpl_text_bitlet_1"}
	</p><br/>
	<p>
		{t k="tpl_text_bitlet_2"}
	</p><br/>
	<p>
		{assign var="fsize" value=$smarty.const.BITLET_FSIZE|format_size}
		{t k="tpl_text_bitlet_3" a=$fsize}
	</p><br/>
	<p>
		{t k="tpl_text_bitlet_4"}
	</p><br/>
	<p>
		{t k="tpl_text_bitlet_5"}
	</p>
	
{/if}