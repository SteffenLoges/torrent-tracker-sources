{* Smarty *}
{*<?php die(); ?>*}
{if $err === true}
	<p>{t k="error_unknown"}</p>
{else}

	{if $args[1] == null}
	
	
	{elseif $args[1] == 'new' || $args[1] == 'edit'}
		{if $args[2]!=2}
			<a name="preview"></a>
				{*<div class="post_content" id="preview_box"></div>*}
				{include file="`$template_name`/blog.tpl.php" posts=$dummy_post page_count=0 cat="all" start_page=1}
				
				<form id="post_form" enctype="multipart/form-data" action="{if !isset($post)}{link url="post/new/2"}{else}{link url="post/edit/2/`$post_table``$post_id`"}{/if}" method="post" class="reg_form">
					<div class="box">
						<span>{t k="tpl_post_category"}:</span> 
						<select name="category">
						{section name="cat" loop=$cats}
							<option value="{$cats[cat].lid}"{if isset($post) && $post.cid==$cats[cat].id} selected="selected"{/if}>{$cats[cat].name}</option>
						{sectionelse}
							{t k="tpl_post_no_categories"}
						{/section}
						</select><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<span>{t k="tpl_post_header"}:</span> <input type="text" name="header" maxlength="255" value="{if isset($post)}{$post.header|escape:"html"}{/if}" /><br/>
						<span>{t k="tpl_post_subheader"}:</span> <input type="text" name="subheader" maxlength="255" value="{if isset($post)}{$post.subheader|escape:"html"}{/if}" /><br/>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<div class="bbcode">
							<input type="button" value="{t k="tpl_post_bbcode_b"}" onclick="javascript:simple_bbcode(this,'B')" style="font-weight: 700" />
							<input type="button" value="{t k="tpl_post_bbcode_i"}" onclick="javascript:simple_bbcode(this,'I')" style="font-style: italic" />
							<input type="button" value="{t k="tpl_post_bbcode_u"}" onclick="javascript:simple_bbcode(this,'U')" style="text-decoration: underline" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="button" value="{t k="tpl_post_bbcode_quote"}" onclick="javascript:simple_bbcode(this,'QUOTE')" />
							<input type="button" value="{t k="tpl_post_bbcode_code"}" onclick="javascript:simple_bbcode(this,'CODE')" />
							<input type="button" value="{t k="tpl_post_bbcode_url"}" onclick="javascript:simple_bbcode(this,'URL')" />
							<input type="button" value="{t k="tpl_post_bbcode_email"}" onclick="javascript:simple_bbcode(this,'EMAIL')" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="button" value="{t k="tpl_post_bbcode_big"}" onclick="javascript:add_bbcode('[size=20][/size]')" />
							<input type="button" value="{t k="tpl_post_bbcode_small"}" onclick="javascript:add_bbcode('[size=12][/size]')" />
							<input type="button" value="{t k="tpl_post_bbcode_color"}" onclick="javascript:add_bbcode('[color=000000][/color]')" />
							<br/>
							<input type="button" value="{t k="tpl_post_bbcode_img"}" onclick="javascript:show_bbcode(this,'img')" />
							<input type="button" value="{t k="tpl_post_bbcode_file"}" onclick="javascript:show_bbcode(this,'file')" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							{*Content ads can be implemented by making adjustments in functions/text.php<input type="button" value="Advertisement" onclick="javascript:add_bbcode('[_AD]');this.disabled=true" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*}
							<input type="button" value="{t k="tpl_post_bbcode_break"}" onclick="javascript:add_bbcode('[break]');this.disabled=true" />
							<span id="popup_container"></span>
						</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<textarea name="post_content" id="txt" class="newpost_textarea" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" ondblclick="storeCaret(this);">{if isset($post)}{$post.content|escape:"html"}{/if}</textarea>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<div class="nofloat">
							{if $smarty.const.BLOG_WATERMARK}
								{t k="tpl_post_watermarking" a="`$smarty.const.WATERMARK_MINWIDTH`|`$smarty.const.WATERMARK_MINHEIGHT`"}
							{/if}
							<div id="upload_container">
							</div>
							<a href="javascript:add_file_input()" id="add_input_link">{t k="tpl_post_add_file"}</a><br/>
						</div>
					</div>
					<div class="spacer"></div>
					{if isset($post)}
						<div class="box">
							<div class="nofloat">
								<b>{t k="tpl_post_del_files"}:</b><br/>
								{section name="fls" loop=$files}
									<input type="checkbox" name="filedel[]" value="{$files[fls]}" /> {$files[fls]}<br/>
								{/section}
							</div>
						</div>
						<div class="spacer"></div>
					{/if}
					<div class="box">
						<div class="nofloat">
							<input type="radio" name="schedule" value="now" checked="checked" /> {if isset($post)}{t k="tpl_post_date_nochange"}{else}{t k="tpl_post_scheduler_now"}{/if}<br/>
							<input type="radio" name="schedule" value="schedule_quick" /> <select name="scheduler">
																						{section name="sch" loop=$sch_dates}
																							<option value="{$sch_dates[sch].date}">{$sch_dates[sch].date}{if $sch_dates[sch].no!=0} (+{$sch_dates[sch].no}){/if}</option>
																						{/section}
																					</select><br/>
							<input type="radio" name="schedule" value="schedule" /> 
											{html_select_date end_year="+1" month_format="%m" field_order="YMD" field_separator=" /\n"} --
											{html_select_time}
						</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<div class="nofloat">
							<input type="radio" name="usehtml" value="bbcode" {if (isset($post) && $post.parse_html==0) || !isset($post)}checked="checked"{/if} /> {t k="tpl_post_bbcode_only"}<br/>
							<input type="radio" name="usehtml" value="html" {if isset($post) && $post.parse_html==1}checked="checked"{/if}/> {t k="tpl_post_bbcode_html"}
						</div>
					</div>
					<div class="spacer"></div>
					<div class="box">
						<div class="nofloat">
							<input type="checkbox" name="copyright" {if isset($post) && $post.copyright==1}checked="checked"{/if}/> {t k="tpl_post_add_copyright"}
						</div>
					</div>
					<div class="spacer"></div>
					{if $smarty.const.FUNC_TAGS}
						<div class="box">
							<div class="nofloat">
								{t k="tpl_post_tags"}:<br/>
								<input type="text" name="tags" class="tags" maxlength="398" value="{if isset($post)}{$post.tags}{/if}" />
							</div>
						</div>
						<div class="spacer"></div>
					{/if}
					<div class="box">
						<div class="nofloat">
							<input type="button" value="{t k="tpl_post_preview"}" class="submit" onclick="javascript:preview_post()" /> <input type="submit" value="{t k="tpl_post_submit"}" class="submit" />
						</div>
					</div>
				</form>
				{if isset($post)}
					<br/>
					<a href="{link url="post/delete/`$post_table``$post_id`"}">{t k="tpl_post_delete"}</a>
				{/if}
		{else}
			<p>
			{if $args[1]=='edit'}
				{if $res==true}
					{t k="tpl_post_edit_succ"}
				{else}
					{t k="tpl_post_edit_err"}
				{/if}
			{else}
				{if $res==true}
					{t k="tpl_post_send_succ"}
				{else}
					{t k="tpl_post_send_err"}
				{/if}
			{/if}
			</p>
		{/if}
	
		
		
	{elseif $args[1] == 'list'}	
		<div class="list_holder">
			{section name="p" loop=$posts}
				<div class="line list_{cycle values="1,2"}">
					<span class="fl_left">
						{if $posts[p].type=='q'}
							{img src="`$imurl`queue.gif" alt="Q"}
						{else}
							{img src="`$imurl`posted.gif" alt="P"}
						{/if}
						
						<span class="date">{$posts[p].posted|date_format:"%y %m %d - %H:%M:%S"}</span>
						
						{if $posts[p].type=='q'}
							{$posts[p].header|escape:html}
						{else}
							<a href="{link url="read/`$posts[p].lid`/`$posts[p].plid`.html"}">{$posts[p].header|escape:html}</a>
						{/if}
					 	(<a href="{link url="cat/`$posts[p].lid`"}">{$posts[p].name}</a>)
					 </span>
					 <a href="{link url="post/edit/`$posts[p].type``$posts[p].id`"}" class="edit">{t k="tpl_post_list_edit"}</a>
				</div>
			{sectionelse}
				<p>{t k="tpl_post_list_none"}</p>
			{/section}
		</div>
		
	{elseif $args[1] == 'delete'}	
		{if $args[3]!=2}
			<p>{t k="tpl_post_delete_ask" a="post/delete/`$args[2]`/2"|link}</p>
		{else}
			<p>
			{if $res}
				{t k="tpl_post_delete_succ"}
			{else}
				{t k="error"} {errno}.
			{/if}
			</p>
		{/if}
	
	{/if}
	
{/if}