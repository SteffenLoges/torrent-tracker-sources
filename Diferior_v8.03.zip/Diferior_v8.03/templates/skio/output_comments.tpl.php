{* Smarty *}
{*<?php die(); ?>*}

<a name="comments"></a>
{section name="c" loop=$comments}
	{if !isset($smarty.session.preferences) || $smarty.session.preferences.comments_dir==0}
		{math equation="iteration+(page_count*(page-1))" iteration=$smarty.section.c.iteration page_count=$page_count page=$page assign="c_no"}
	{else}
		{math equation="tot-(iteration+(page_count*(page-1)))" tot=`$tot_comments+1` iteration=$smarty.section.c.iteration page_count=$page_count page=$page assign="c_no"}
	{/if}
	<div class="comment_start">
		<div class="comment_inner">
		<a name="c{$c_no}"></a>
			<div class="comment_left">
				<div class="comment_avatar">
					{if $comments[c].anonymous!=1 && $comments[c].pr_avatar!=null}
						{img src="`$comments[c].pr_avatar`" alt="tpl_comments_avatar"|translate}<br/>
					{/if}
				</div>
				<div class="comment_info">
					{if $comments[c].anonymous!=1}
						{if $smarty.const.FUNC_DOWNLOADS && $smarty.const.FUNC_DOWNLOADS_TORRENT && $smarty.const.TRACKER_ANONYMOUS==false && ( $comments[c].downloaded!=0 || $comments[c].uploaded!=0 )}
							{img src="`$imurl`userinfo/downloaded.gif" alt="Dl"} {$comments[c].downloaded|format_size}<br/>
							{img src="`$imurl`userinfo/uploaded.gif" alt="Ul"} {$comments[c].uploaded|format_size}<br/>
							{img src="`$imurl`userinfo/ratio.gif" alt="R"} 
							{if $comments[c].downloaded==0}&#8734;{else}{$comments[c].uploaded/$comments[c].downloaded|string_format:"%.2f"|colorize:1}{/if}<br/><br/>
						{/if}
						
						{if $smarty.const.FUNC_BLOG && $comments[c].blogposts!=0}{t k="tpl_comments_blogposts"}: {$comments[c].blogposts}<br/>{/if}
						{if $smarty.const.FUNC_DOWNLOADS && $comments[c].downloadposts!=0}{t k="tpl_comments_downloadposts"}: {$comments[c].downloadposts}<br/>{/if}
						{if $comments[c].comments!=0}{t k="tpl_comments_comments"}: {$comments[c].comments}<br/>{/if}
						{if $smarty.const.FUNC_FORUMS && $comments[c].forumposts!=0}{t k="tpl_comments_forumposts"}: {$comments[c].forumposts}<br/>{/if}
						{if $comments[c].banned==1}{img src="`$imurl`userinfo/banned.gif" alt="!"}<br/>{elseif $comments[c].warned==1}{img src="`$imurl`userinfo/warning.gif" alt="!"}<br/>{/if}
					{/if}
					
					{if isset($smarty.session.logged) && $smarty.session.logged && $smarty.session.permissions.delete_comments}
						<br/><br/><input type="checkbox" name="delcomm[]" value="{$comments[c].id}" style="width: auto; height: auto" /> <span style="font-size: 12px;">{t k="tpl_comments_delmark"}</span>
					{/if}
				</div>
			</div>
			<div class="comment_right">
				<div class="comment_author">
					{if $comments[c].anonymous!=1}
						<a href="{link url="user/v/`$comments[c].author`"}">{$comments[c].author}</a> ({get_user_status info=$comments[c]}) <span>@ {$comments[c].posted|date_format:"%y %m %d - %H:%M:%S"}</span>
					{else}
						<b>{$comments[c].author}</b> ({t k="tpl_comments_anonymous"}) @ {$comments[c].posted|date_format:"%y %m %d - %H:%M:%S"}
					{/if}
				</div>
				
				{$comments[c].content|parse_post}
			</div>
		</div>
	</div>
{sectionelse}
	<p>{t k="tpl_comments_no_long"}</p>
{/section}