{* Smarty *}
{*<?php die(); ?>*}
<p>
	{t k="tpl_torrents_err"}
</p>