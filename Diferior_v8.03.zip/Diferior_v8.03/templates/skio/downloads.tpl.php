{* Smarty *}
{*<?php die(); ?>*}

{if isset ($smarty.session.userinfo) && $smarty.session.userinfo.warned==1 && $smarty.session.userinfo.warned_manual==0 && !$smarty.const.TRACKER_ANONYMOUS}
	<div class="big_message big_message_err">
		<a href="{link url="ratio_warning"}">
			{img src="`$imurl`userinfo/warning.gif" alt="!"}<br/>
			{t k="tpl_downloads_ratio_warning"}
		</a>
	</div>
{/if}
					
<div class="dl_search_hide"><a href="javascript:exp_flist('dl_search_holder','dl_search_link')" id="dl_search_link">{if !isset($smarty.cookies.dl_search_collapsed)}{t k="tpl_downloads_search_collapse"}{else}{t k="tpl_downloads_search_expand"}{/if}</a></div>
<div id="dl_search_holder" style="overflow: hidden;">
	<div class="dl_search">
		<form action="{link url="search"}" method="post" name="search">
		{section name="search" loop=$dl_cats}
			<div class="cat">
				{if isset($dl_cats[search].subcats)}
					{foreach from=$dl_cats[search].subcats key=k item=sub}
						<div class="item"><input type="checkbox" name="dlsub_{$sub.id}" {if isset($smarty.session.subcats) && ( ( !isset ( $subcategory ) && $dl_cats[search].id==$smarty.session.subcats.0 ) || ( isset ( $subcategory ) && $subcategory == $sub.id ) )}checked="checked"{/if} /> <a href="{link url="downloads/`$dl_cats[search].lid`/`$sub.lid`"}">{$dl_cats[search].name} &#187; {$sub.name}</a></div>
					{/foreach}
				{/if}
			</div>
		{/section}
		<div class="inputs">
			<input type="text" value="{t k="tpl_index_search_phrase"}" name="search" class="search_input" onfocus="javascript:emptydef(this,'{t k="tpl_index_search_phrase"}')" /><input type="submit" value="{t k="tpl_downloads_search_input"}" class="search_submit" />
		</div>
		<input type="hidden" name="type" value="downloads" />
		</form>
	</div>
</div>

<script language="JavaScript">
	var banner_txt_expand='{t k="tpl_downloads_search_expand"}'; 
	var banner_txt_collapse='{t k="tpl_downloads_search_collapse"}';

	var dl_search_box = true;
	
	{literal}
	if ( read_cookie ( 'dl_search_collapsed' ) == null )
	{
		flist_size_dl_search_holder = document.getElementById('dl_search_holder').offsetHeight+3;
		target_height_dl_search_holder = flist_size_dl_search_holder;
		expanded_flist_dl_search_holder = true;
	}
	else
	{
		flist_size_dl_search_holder = 0;
		target_height_dl_search_holder = document.getElementById('dl_search_holder').offsetHeight+3;
		expanded_flist_dl_search_holder = false;
	}
	
	fsize_first_dl_search_holder = false;
	tmr_dl_search_holder = null;
	document.getElementById('dl_search_holder').style.height = flist_size_dl_search_holder+'px';
	{/literal}
</script>

				
<div class="download_holder download_holder_small">
	<div class="dl_cat dl_top"><span class="left_glow"></span></div>
	<div class="dl_cat dl_top"><span class="right_glow" style="left: 1px"></span></div>
	{if $sort_desc}{assign var="diff_sort" value="asc"}{else}{assign var="diff_sort" value="desc"}{/if}
	{if $sort_type=='header'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="asc"}{/if}
	<div class="dl_header dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/header/`$sort_dir`"}" class="float">{t k="tpl_downloads_title"}</a></span></div>
	{if $sort_type=='type'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
	<div class="dl_type dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/type/`$sort_dir`"}" class="float">{t k="tpl_downloads_type"}</a></span></div>
	{if $sort_type=='seeders'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
	<div class="dl_seeders dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/seeders/`$sort_dir`"}" class="float">{t k="tpl_downloads_seeders"}</a></span></div>
	{if $sort_type=='leechers'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
	<div class="dl_leechers dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/leechers/`$sort_dir`"}" class="float">{t k="tpl_downloads_leechers"}</a></span></div>
	{if $sort_type=='fsize'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
	<div class="dl_size dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/fsize/`$sort_dir`"}" class="float">{t k="tpl_downloads_size"}</a></span></div>
	{if $sort_type=='comments'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="desc"}{/if}
	<div class="dl_comments dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/comments/`$sort_dir`"}" class="float">{t k="tpl_downloads_comments"}</a></span></div>
	{if $sort_type=='user'}{assign var="sort_dir" value=$diff_sort}{else}{assign var="sort_dir" value="asc"}{/if}
	<div class="dl_user dl_top"><span class="left_glow"><span class="right_glow"></span><a href="{link url="downloads/`$cat`/`$subcat`/page1/user/`$sort_dir`"}" class="float">{t k="tpl_downloads_author"}</a></span></div>
</div>

{section name="d" loop=$downloads}
	<div class="download_holder">
		<div class="dl_cat"><a href="{link url="downloads/`$downloads[d].lid`"}">{img src="`$imurl`dl_cat/`$downloads[d].lid`.gif" alt=""}</a></div>
		<div class="dl_cat"><a href="{link url="downloads/`$downloads[d].lid`/`$downloads[d].sub_lid`"}">{img src="`$imurl`dl_cat/`$downloads[d].lid`_`$downloads[d].sub_lid`.gif" alt=""}</a></div>
		<div class="dl_header">
			<span class="fl_header">
				<div class="link">
					<a href="{link url="file/`$downloads[d].lid`/`$downloads[d].sub_lid`/`$downloads[d].plid`.html"}">{$downloads[d].header|escape:"html"|wordwrap:39:"\n":true|quotes}</a>
				</div>
				<span class="dl_descr">{$downloads[d].subheader|escape:"html"|quotes}</span>
			</span>
		</div>
		<div class="dl_type"><span class="float">
			{if $downloads[d].info_hash!=null}{img src="`$imurl`dl_torrent_small.gif" alt="BT" onmouseover="javascript:window.status='Torrent'" onmouseout="javascript:window.status=''"}{/if} 
			{if $downloads[d].dl_links!=null}{img src="`$imurl`dl_http_small.gif" alt="HTTP" onmouseover="javascript:window.status='HTTP'" onmouseout="javascript:window.status=''"}{/if}
		</span></div>
		{if $downloads[d].info_hash!=null}
			<div class="dl_seeders"><span class="float">{$downloads[d].seeders|colorize:$downloads[d].leechers}
			{else}
			<div class="dl_size"><span class="float">&#8212;
		{/if}</span></div>
		{if $downloads[d].info_hash!=null}
			<div class="dl_leechers"><span class="float">{$downloads[d].leechers}
			{else}
			<div class="dl_size"><span class="float">&#8212;
		{/if}</span></div>
		<div class="dl_size"><span class="float">{if $downloads[d].fsize!=0}{$downloads[d].fsize|format_size}{else}&#8212;{/if}</span></div>
		<div class="dl_comments">
			<span class="float">
			<a href="{link url="file/`$downloads[d].lid`/`$downloads[d].sub_lid`/`$downloads[d].plid`.html/#comments"}">{$downloads[d].comments}</a>
			</span>
		</div>
		<div class="dl_user"><span class="float">
			{if $downloads[d].anonymous==1}
				<i>{t k="tpl_downloads_anonymous"}</i>
			{else}
				<a href="{link url="user/v/`$downloads[d].user`"}">{$downloads[d].user}</a>
			{/if}
		</span></div>
	</div>
{sectionelse}
	<br/><p class="clear">{t k="tpl_downloads_err_empty"}</p><br/>
{/section}

{assign var="pages" value=$download_count/$page_count|ceil}
{if $pages > 1 }
	<div class="paging">
	{if $page > 1}<a href="{link url="downloads/`$cat`/`$subcat`/page`$page-1``$sort_str`"}" class="pg_previous">&#171; {t k="tpl_previous"}</a>{else}<b class="pg_previous">&#171; {t k="tpl_previous"}</b>{/if}
	{assign var="paging" value=$page|paging:$pages:3:10}
	{foreach from=$paging item=curr_page}
		{if $curr_page != 'sep'}
			{if $curr_page != $page}
				<a href="{link url="downloads/`$cat`/`$subcat`/page`$curr_page``$sort_str`"}">{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</a>
			{else}
				<b>{$curr_page*$page_count-$page_count+1}-{$curr_page*$page_count}</b>
			{/if}			
		{else}...{/if} 
	{/foreach}
	{if $page < $pages}<a href="{link url="downloads/`$cat`/`$subcat`/page`$page+1``$sort_str`"}" class="pg_next">{t k="tpl_next"} &#187;</a>{else}<b class="pg_next">{t k="tpl_next"} &#187;</b>{/if}
	</div>
{/if}	