<?php

	$template_list = array ( 
		array ( 'title' => 'Skio Four', 'author' => 'witkuz', 'id' => 'skio', 'dir' => 'skio', 'style_load' => '' ),
		array ( 'title' => 'Skio Four (green)', 'author' => 'UnrealX', 'id' => 'skio_green', 'dir' => 'skio', 'style_load' => 'green/style.css' ),
		array ( 'title' => 'Skio Four (red)', 'author' => 'UnrealX', 'id' => 'skio_red', 'dir' => 'skio', 'style_load' => 'red/style.css' ),
		array ( 'title' => 'Skio Four (black)', 'author' => 'UnrealX', 'id' => 'skio_black', 'dir' => 'skio', 'style_load' => 'black/style.css' ),
	);

?>