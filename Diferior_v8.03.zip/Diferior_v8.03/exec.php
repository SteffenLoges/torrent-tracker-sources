<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


	# Check if included via index.php
	if ( !defined ( 'VIA_INDEX' ) ) die ( 'This file can\'t be run directly.' );


	##################################################
	
	$url 		= & core::load_file ( 'url' );
	$session 	= & core::load_file ( 'session' );
	$db 		= & core::load_file ( 'db' );
	# 'db' class must be loaded after 'session' class, so that 'session' class is destroyed first. However session functionality must be initialized AFTER 'db' class is ready.
	$session -> init ();
	$cron	 	= & core::load_file ( 'cron' );
	$cache 		= & core::load_file ( 'cache' );
	$l 			= & core::load_file ( 'language' );
	$text 		= & core::load_file ( 'text' );
	$user 		= & core::load_file ( 'user' );
	$template 	= & core::load_file ( 'template' );
	$counters 	= & core::load_file ( 'counters' );
	$blog 		= & core::load_file ( 'blog' );
	$downloads 	= & core::load_file ( 'downloads' );
	$comments 	= & core::load_file ( 'comments' );
	$contact 	= & core::load_file ( 'contact' );
	$wap 		= & core::load_file ( 'wap' );
	$search 	= & core::load_file ( 'search' );
	$nfo 		= & core::load_file ( 'nfo' );
	$forum 		= & core::load_file ( 'forum' );
	$pm 		= & core::load_file ( 'pm' );
	//$sms 		= & core::load_file ( 'sms' );
	
	##################################################
	
	
	# Deal with cron
	$cron -> check ();
	
	# Copy URL arguments into a local variable for easy use
	$args = $url -> get_args ();
	$S [ 'args' ] = & $args;
	
	# CSS Stylesheets / JavaScript files to include
	$S [ 'stylesheets' ] = array ();
	$S [ 'javascripts' ] = array ();
	
	# If requested view does not exist, fallback to 'default'
	if ( $args [ 0 ] == null || !preg_match ( "#^[a-zA-Z0-9_]+\$#", $args [ 0 ] ) || !file_exists ( './views/'. $args [ 0 ] .'.php' ) )
	{
		$view = 'default';
	}
	else 
	{
		$view = $args [ 0 ];	
	}
	
	# Default values
	$S [ 'title' ] = PAGE_NAME . ( PAGE_SLOGAN != null ? ' &#8212; '. PAGE_SLOGAN : null );
	$S [ 'header' ] = null;
	$S [ 'subheader' ] = null;
	
	# Check blogs posts queue
	$blog -> check_queue ();
	
	# Refresh userinfo if needed
	$user -> refresh_info ();
	
	# User banned?
	if ( isset ( $_SESSION [ 'logged' ] ) && $_SESSION [ 'logged' ] && $_SESSION [ 'userinfo' ] [ 'banned' ] == 1 )
	{
		ob_start ();
		$template -> display ( SMARTY_TEMPLATES_DIR .'/banned.tpl.php' );
		die ();
	}
	
	# Set appropriate template (web/wap)
	/*if ( $wap -> is_wap () )
	{
		$tpl = 'mobile';
	}
	else */
	{
		if ( isset ( $_SESSION [ 'preferences' ] [ 'template' ] ) )
		{
			$tpl = $_SESSION [ 'preferences' ] [ 'template' ];
		}
		else 
		{
			$tpl = DEFAULT_TEMPLATE;	
		}
	}
	$_SESSION [ 'template' ] = $tpl;
	
	# Get template directory and stylesheet options
	require_once ( SMARTY_TEMPLATES_DIR .'/template_list.php' );
	$S [ 'template_list' ] = & $template_list;
	foreach ( $S [ 'template_list' ] as $v )
	{
		if ( $v [ 'id' ] == $tpl )
		{
			$tpl_dir = $v [ 'dir' ];	
			if ( $v [ 'style_load' ] != null )
			{
				$S [ 'stylesheets_template' ] = explode ( ';', $v [ 'style_load' ] );
			}
			else 
			{
				$S [ 'stylesheets_template' ] = array ();	
			}
			break;
		}
	}
	if ( !isset ( $tpl_dir ) )
	{
		# Default
		$tpl_dir = 'skio';
	}
	$_SESSION [ 'template_dir' ] = $tpl_dir;
	
	# Unset downloads subcategories
	if ( $view != 'downloads' && $view != 'file' ) 
	{
		unset ( $_SESSION [ 'subcats' ] );
	}
	
	# Load and execute view
	require_once ( DIR_VIEWS .'/'. $view .'.php' );
	
	# Adjust page title if needed
	if ( $S [ 'header' ] != null && $view != 'main' && $view != 'default' && $view != 'index' )
	{
		$S [ 'title' ] = $S [ 'header' ] .' &#8212; '. PAGE_NAME;
	}
	
	# Parse 'view' variable for usage in templates
	$view = & $args [ 0 ];
	$S [ 'view' ] = & $view;
	
	# Retrieve blog and downloads categories
	if ( !isset ( $S [ 'cats' ] ) && FUNC_BLOG )
	{
		$S [ 'cats' ] = $blog -> get_cats ();
	}
	if ( !isset ( $S [ 'dl_cats' ] ) && FUNC_DOWNLOADS )
	{
		$S [ 'dl_cats' ] = $downloads -> get_cats ( false );
	}
	
	$blog -> get_tags ( $S [ 'blog_tags' ], $S [ 'blog_tags_max' ], $S [ 'dl_tags' ], $S [ 'dl_tags_max' ] );
	
	# Counters
	if ( FUNC_COUNTERS )
	{
		$S [ 'counter' ] = $counters -> simple ();
		$S [ 'online' ] = $counters -> online ();
	}
	
	# Last 5 blog posts for infobanner
	//$S [ 'infobanner_lastposts' ] = $blog -> get_last_posts ( 5 );
	
	# SMS advertisement (infobanner)
	//$S [ 'sms' ] = $sms -> get ( 5 );
	
	# Calculate script execution time
	if ( GENERATION_TIME )
	{
		$dbg_start = array_sum ( explode ( ' ', $dbg_start ) );
		$S [ 'dbg_end' ] = array_sum ( explode ( ' ', microtime () ) );
		$S [ 'dbg_diff' ] = $S [ 'dbg_end' ] - $dbg_start;
		
		list ( $S [ 'dbg_query_count' ], $S [ 'dbg_query_time' ] ) = $db -> get_debug_info ();
	}
	
	# Check if template exists
	if ( !file_exists ( SMARTY_TEMPLATES_DIR .'/'. $tpl_dir .'/'. $view .'.tpl.php' ) )
	{
		if ( $tpl == 'skio' )
		{
			# Game over man
			throw new error ( $l -> t ( 'err_template' ) );
		}
		else 
		{
			# Hopefully default diferior template exists
			$_SESSION [ 'preferences' ] [ 'template' ] = 'skio';
			$tpl = 'skio';	
		}
	}
	
	# Output
	ob_start ();
	$template -> assign_all ( $S );
	$template -> display ( SMARTY_TEMPLATES_DIR .'/'. $tpl_dir .'/index.tpl.php' );
	
	# If needed, save output into static file
	if ( CACHE_STATIC != null )
	{
		file_put_contents ( CACHE_STATIC, ob_get_contents() );	
	}
	
?>