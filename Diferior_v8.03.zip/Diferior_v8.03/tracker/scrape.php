<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


/*
	Some code based off tbsource. Hats off.
*/

define ( 'VIA_INDEX', true );

require_once ( dirname(__FILE__).'/../conf.php' );
require_once ( dirname(__FILE__).'/../error.php' );

# Stop execution if PHP tracker is disabled
if ( TRACKER_TYPE != 'PHP' )
{
	die ( 'PHP tracker disabled. Please re-download .torrent file from '. URL );	
}

# Set error and exception handlers
set_error_handler ( array ( 'error', 'php_error_handler' ) );
set_exception_handler ( array ( 'error', 'php_exception_handler' ) );
	
# Get rid of magic_quotes
ini_set ( 'magic_quotes_runtime', 0 );
if ( get_magic_quotes_gpc() )
{
	function array_map_r ( $cback, $arr )
	{
	    $res = array();
	    
	    foreach( $arr as $k => $v )
	    {
	        $res [ $k ] = ( is_array ( $v ) ? array_map_r ( $cback, $v ) : $cback ( $v ) );
	    }
	        
	    return $res;
	}
	//$_GET = array_map_r ( 'stripslashes', $_GET );
	$_POST = array_map_r ( 'stripslashes', $_POST );
	$_COOKIE = array_map_r ( 'stripslashes', $_COOKIE );
}

try 
{
	
	# Restrict HTTP browser access
	$agent_substr = substr ( ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ), 0, 4 );
	if ( $agent_substr == 'Mozi' || $agent_substr == 'Oper' || $agent_substr == 'Link' || $agent_substr == 'Lynx' )
	{
		die ( 'Browser access denied' );
	}
	
	
	# Load core
	require_once ( dirname(__FILE__).'/../core.php' );

	$db = & core::load_file ( 'db' );
	$bittorrent = & core::load_file ( 'bittorrent' );
	
	
	# Determine whether server supports gzip compression and if so, use it when sending output
	if ( extension_loaded ( 'zlib' ) && ini_get ( 'zlib.output_compression' ) == 0 )
	{
		ob_start ( 'ob_gzhandler' );	
	}
	
	
	# Parse URL
	$request = $_SERVER [ 'QUERY_STRING' ];
	if ( get_magic_quotes_gpc() )
	{
		$request = stripslashes ( $request );	
	}
	$vars = explode ( '&', $request );
	$info_hash = array ();
	foreach ( $vars as $v )
	{
		if ( preg_match ( "#^info_hash=(.+)\$#", $v, $m ) )
		{
			$temp_hash = urldecode ( $m [ 1 ] );	
			if ( strlen ( $temp_hash ) == 20 )
			{
				$info_hash [] = $db -> escape ( $temp_hash );	
			}
		}	
	}
	
	
	# Check if torrent exists and retrieve peer count
	$torrents = $db -> get_all ( "SELECT info_hash, seeders, leechers, completed FROM dl_downloads ". ( count ( $info_hash ) > 0 ? "WHERE info_hash='". implode ( "' OR info_hash='", $info_hash ) ."'" : 'WHERE info_hash!=\'\' LIMIT 100' ) );
	if ( !$torrents )
	{
		$bittorrent -> error ( 'Unregistered torrent' );	
	}
	else 
	{
		$files = array ();
		
		foreach ( $torrents as $v )
		{
			$files [ $v [ 'info_hash' ] ] = array (
													'complete'	=>	$v [ 'seeders' ],
													'downloaded'	=>	$v [ 'completed' ],
													'incomplete'	=>	$v [ 'leechers' ],
												);
		}

		$response = array ( 'files' => $files );
		
		# Output right away
		header ( 'Content-Type: text/plain' );
		header ( 'Pragma: no-cache' );
		echo $bittorrent -> encode ( $response );
	}
	
}
catch ( error $e )
{

	$bittorrent -> error ( $e -> getMessage () );
	
}

?>