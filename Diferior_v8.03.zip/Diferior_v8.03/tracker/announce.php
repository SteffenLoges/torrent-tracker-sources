<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


/*
	Some code based off tbsource. Hats off.
*/

define ( 'VIA_INDEX', true );

require_once ( dirname(__FILE__).'/../conf.php' );
require_once ( dirname(__FILE__).'/../error.php' );

# Stop execution if PHP tracker is disabled
if ( TRACKER_TYPE != 'PHP' )
{
	die ( 'PHP tracker disabled. Please re-download .torrent file from '. URL );	
}

# Set error and exception handlers
set_error_handler ( array ( 'error', 'php_error_handler' ) );
set_exception_handler ( array ( 'error', 'php_exception_handler' ) );
	
# Get rid of magic_quotes
ini_set ( 'magic_quotes_runtime', 0 );
if ( get_magic_quotes_gpc() )
{
	function array_map_r ( $cback, $arr )
	{
	    $res = array();
	    
	    foreach( $arr as $k => $v )
	    {
	        $res [ $k ] = ( is_array ( $v ) ? array_map_r ( $cback, $v ) : $cback ( $v ) );
	    }
	        
	    return $res;
	}
	//$_GET = array_map_r ( 'stripslashes', $_GET );
	$_POST = array_map_r ( 'stripslashes', $_POST );
	$_COOKIE = array_map_r ( 'stripslashes', $_COOKIE );
}

try 
{
	
	# Restrict HTTP browser access
	$agent_substr = substr ( ( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ), 0, 4 );
	if ( $agent_substr == 'Mozi' || $agent_substr == 'Oper' || $agent_substr == 'Link' || $agent_substr == 'Lynx' )
	{
		die ( 'Browser access denied' );
	}
	
	
	# Load core
	require_once ( dirname(__FILE__).'/../core.php' );

	$db = & core::load_file ( 'db' );
	$bittorrent = & core::load_file ( 'bittorrent' );
	
	
	# Parse URL
	$request = $_SERVER [ 'QUERY_STRING' ];
	$request = preg_replace ( "#^(torrent_pass=[^\?]*)\?#", '\1&', $request );
	parse_str ( $request, $var );
	if ( get_magic_quotes_gpc() )
	{
		$var = array_map_r ( 'stripslashes', $var );
	}
	
	$compact = ( isset ( $var [ 'compact' ] ) && $var [ 'compact' ] == 1 ? true : false );
	$no_peer_id = ( isset ( $var [ 'no_peer_id' ] ) && $var [ 'no_peer_id' ] == 1 ? true : false );
	
	# Determine whether server supports gzip compression and if so, use it when sending output
	if ( extension_loaded ( 'zlib' ) && ini_get ( 'zlib.output_compression' ) == 0 && !$compact )
	{
		ob_start ( 'ob_gzhandler' );	
	}
	
	
	# Get IP (more sophisticated IP detection can (should?) be added)
	$ip = $_SERVER [ 'REMOTE_ADDR' ];
	$ip_long = ip2long ( $ip );
	
	
	# Validate variables
	if ( !isset ( $var [ 'info_hash' ] ) || !isset ( $var [ 'peer_id' ] ) || !isset ( $var [ 'port' ] ) || !is_numeric ( $var [ 'port' ] ) 
		|| !isset ( $var [ 'uploaded' ] ) || !is_numeric ( $var [ 'uploaded' ] ) || !isset ( $var [ 'downloaded' ] ) || !is_numeric ( $var [ 'downloaded' ] )
		|| !isset ( $var [ 'left' ] ) || !is_numeric ( $var [ 'left' ] ) )
	{
		$bittorrent -> error ( 'Invalid tracker request (#1)' );
	}

	$var [ 'torrent_pass' ] = $db -> escape ( $var [ 'torrent_pass' ] );
	$var [ 'info_hash' ] = urldecode ( $var [ 'info_hash' ] );
	//$var [ 'peer_id' ] = urldecode ( $var [ 'peer_id' ] );
	
	if ( strlen ( $var [ 'info_hash' ] ) != 20 || strlen ( $var [ 'peer_id' ] ) != 20 )
	{
		$bittorrent -> error ( 'Invalid tracker request (#2)' );	
	}
	
	$var [ 'info_hash' ] = $db -> escape ( $var [ 'info_hash' ] );
	$var [ 'peer_id' ] = $db -> escape ( urlencode ( $var [ 'peer_id' ] ) );
	
	if ( !isset ( $var [ 'event' ] ) )
	{
		$var [ 'event' ] = null;
	}
	
	if ( $var [ 'port' ] == 0 || $var [ 'port' ] > 65535 )
	{
		$bittorrent -> error ( 'Invalid port' );	
	}
	
	
	# Max number of peers to retrieve
	if ( isset ( $var [ 'num want' ] ) ) $peer_limit = $var [ 'num want' ];
	if ( isset ( $var [ 'numwant' ] ) ) $peer_limit = $var [ 'numwant' ];
	if ( isset ( $var [ 'num_want' ] ) ) $peer_limit = $var [ 'num_want' ];
	if ( !isset ( $peer_limit ) || !is_numeric ( $peer_limit ) ) $peer_limit = 50;
	/*
		Even 30 peers is plenty, the official client version 3 in fact only actively forms new connections if it has less than 30 peers and will refuse connections if it has 55. 
		This value is important to performance. Above 25, new peers are highly unlikely to increase download speed.
		(from http://wiki.theory.org/BitTorrentSpecification)
	*/
	if ( $peer_limit > 55 ) $peer_limit = 55;
	
	
	# Check if user exists and can leech
	if ( !TRACKER_ANONYMOUS )
	{
		if ( trim ( $var [ 'torrent_pass' ] ) ==  null )
		{
			$bittorrent -> error ( 'Invalid user' );
		}
		
		$user = $db -> get_row ( "SELECT uid, can_leech, wait_time, peers_limit, torrents_limit, downloaded, uploaded FROM users WHERE torrent_pass='". $var [ 'torrent_pass' ] ."'" );
		if ( !$user )
		{
			$bittorrent -> error ( 'Invalid user' );	
		}
		if ( $user [ 'can_leech' ] == 0 && $var [ 'left' ] > 0 )
		{
			$bittorrent -> error ( 'User can\'t leech' );
		}
		if ( $user [ 'peers_limit' ] != 0 )
		{
			$peer_limit = $user [ 'peers_limit' ];	
		}
	}
	
	# Check if torrent exists and retrieve some information about it
	$torrent = $db -> get_row ( "SELECT fid, seeders, leechers, posted FROM dl_downloads WHERE info_hash='". $var [ 'info_hash' ] ."'" );
	if ( !$torrent )
	{
		$bittorrent -> error ( 'Unregistered torrent' );	
	}
	else 
	{
		$torrent [ 'numpeers' ] = $torrent [ 'seeders' ] + $torrent [ 'leechers' ];
	}
	
	
	if ( !TRACKER_ANONYMOUS )
	{
		# Check wait_time
		$elapsed = time () - $torrent [ 'posted' ];
		if ( $elapsed <= $user [ 'wait_time' ] )
		{
			$wait = $user [ 'wait_time' ] - $elapsed;
			$wait = $wait / 60 / 60;
			$wait = round ( $wait, 1 );
			$bittorrent -> error ( 'Please wait another '. $wait .' hour(s) before downloading this torrent' );	
		}
		
		# Check torrents_limit
		$downloading = $db -> get_all ( "SELECT DISTINCT fid FROM xbt_files_users WHERE uid='". $user [ 'uid' ] ."' AND active=1 AND `left`>0" );
		$leeching_curr = 0;
		foreach ( $downloading as $v )
		{
			if ( $v [ 'fid' ] != $torrent [ 'fid' ] )
			{
				$leeching_curr++;	
			}
		}
		if ( $var [ 'left' ] > 0 ) $leeching_curr++;
		if ( $user [ 'torrents_limit' ] > 0 && $leeching_curr > $user [ 'torrents_limit' ] )
		{
			$bittorrent -> error ( 'Torrent leech limit reached. You can download '. $user [ 'torrents_limit' ] .' concurrent torrents at once.' );	
		}
	}
	
	
	# Show peers
	if ( $peer_limit > 0 )
	{
		$qr = "SELECT `left`, peer_id, ipa, port, uploaded, downloaded, uid FROM xbt_files_users WHERE fid='". $torrent [ 'fid' ] ."' ORDER BY connectable DESC". ( $torrent [ 'numpeers' ] > $peer_limit ? ', RAND() LIMIT '. $peer_limit : null );
		$peers = $db -> get_all ( $qr );

		$response = array (
			'interval'	=>	1800, // 30 min
			'complete'	=>	(int) $torrent [ 'seeders' ],
			'incomplete'	=>	(int) $torrent [ 'leechers' ],
		);
		
		if ( !$compact )
		{
			$peers_value = array ();
		}
		else 
		{
			$peers_value = null;
		}
		
		foreach ( $peers as $v )
		{
			if ( !$compact )
			{
				# Non-compact peer list
				if ( !$no_peer_id )
				{
					$p [ 'peer id' ] = urldecode ( $v [ 'peer_id' ] );
				}
				$p [ 'ip' ] = long2ip ( $v [ 'ipa' ] );
				$p [ 'port' ] = (int) $v [ 'port' ];
				$peers_value [] = $p;
			}
			else 
			{
				# Compact output
            	$peers_value .= str_pad ( pack ( 'Nn', $v [ 'ipa' ], $v [ 'port' ] ) , 6 );
			}
			
			if ( $v [ 'peer_id' ] == $var [ 'peer_id' ] && long2ip ( $v [ 'ipa' ] ) == $ip )
			{
				$left = $v [ 'left' ];	
				$res [ 'downloaded' ] = $v [ 'downloaded' ];
				$res [ 'uploaded' ] = $v [ 'uploaded' ];
			}
		}
		
		$response [ 'peers' ] = $peers_value;
	}
	
	
	$where_peer = 'fid='. $torrent [ 'fid' ] ." AND peer_id='". $var [ 'peer_id' ] ."' AND ipa='". $ip_long ."'";
	
	if ( !isset ( $left ) )
	{
		$res = $db -> get_row ( 'SELECT `left`, downloaded, uploaded FROM xbt_files_users WHERE '. $where_peer );
		if ( $res !== false ) 
		{
			$left = $res [ 'left' ];
		}
	}
	
	if ( $peer_limit > 0 )
	{
		# Update seed/leech numbers
		if ( !isset ( $left ) )
		{
			if ( $var [ 'left' ] == 0 )
			{
				$response [ 'complete' ]++;	
			}	
			else 
			{
				$response [ 'incomplete' ]++;	
			}
		}
			
		# Output peer list
		header ( 'Content-Type: text/plain' );
		header ( 'Pragma: no-cache' );
		echo $bittorrent -> encode ( $response );
	}
	
	
	if ( !TRACKER_ANONYMOUS && isset ( $left ) )
	{
		# Update user upload / download stats
		$uploaded = max ( 0, $var [ 'uploaded' ] - $res [ 'uploaded' ] );	
		$downloaded = max ( 0, $var [ 'downloaded' ] - $res [ 'downloaded' ] );	
		if ( $uploaded > 0 || $downloaded > 0 )
		{
			$db -> update ( 'UPDATE users SET uploaded=uploaded+'. $uploaded .', downloaded=downloaded+'. $downloaded .' WHERE uid='. $user [ 'uid' ] );
		}
	}
				
	$updates = array ();
	
	switch ( $var [ 'event' ] )
	{
		case 'stopped':
				if ( !isset ( $left ) )
				{
					$bittorrent -> error ( 'Tracker error #1' );	
				}
				else 
				{
					$updates [] = ( $left == 0 ? 'seeders=seeders-1' : 'leechers=leechers-1' );	
				}
				$db -> delete ( 'DELETE FROM xbt_files_users WHERE '. $where_peer );
				//$db -> update ( 'UPDATE xbt_files_users SET active=0 WHERE '. $where_peer );
			break;
			
			
		case 'completed':
				$updates [] = 'completed=completed+1';
		default:
				if ( isset ( $left ) )
				{
					# Update peer
					$res = $db -> update ( 'UPDATE xbt_files_users SET active=1, announced='. time () .', uploaded='. $var [ 'uploaded' ] .', downloaded='. $var [ 'downloaded' ] .', `left`='. $var [ 'left' ] 
						. ( $var [ 'event' ] == 'completed' && $var [ 'left' ] == 0 && $left > 0 ? ', completed='. time () : null )
						. ' WHERE '. $where_peer );
						
					if ( $res && ( ( $var [ 'left' ] == 0 && $left > 0 ) || ( $var [ 'left' ] > 0 && $left == 0 ) ) )
					{
						if ( $var [ 'left' ] == 0 )
						{
							$updates [] = 'seeders=seeders+1';
							$updates [] = 'leechers=leechers-1';
						}
						else 
						{
							$updates [] = 'seeders=seeders-1';
							$updates [] = 'leechers=leechers+1';
						}
					}
				}
				else 
				{
					# Check if connectable
					error::toggle_silent ( true );
					$sock = @fsockopen ( $ip, $var [ 'port' ], $errno, $errstr, 5 );
					if ( !$sock )
					{
						$connectable = 0;
					}
					else
					{
						$connectable = 1;
						@fclose ( $sock );
					}
					error::toggle_silent ( false );
					
					# Insert peer
					$data = array (
						'fid'	=>	$torrent [ 'fid' ],
						'uid'	=>	( !TRACKER_ANONYMOUS ? $user [ 'uid' ] : null ),
						'active'	=>	1,
						'announced'	=>	time (),
						'completed'	=>	( $var [ 'left' ] == 0 ? 1 : 0 ),
						'downloaded'	=>	$var [ 'downloaded' ],
						'left'	=>	$var [ 'left' ],
						'uploaded'	=>	$var [ 'uploaded' ],
						'useragent'	=>	( isset ( $_SERVER [ 'HTTP_USER_AGENT' ] ) ? $_SERVER [ 'HTTP_USER_AGENT' ] : null ),
						'connectable'	=>	$connectable,
						'peer_id'	=>	$var [ 'peer_id' ],
						'ipa'	=>	$ip_long,
						'port'	=>	$var [ 'port' ],
					);
					$res = $db -> insert_array ( 'xbt_files_users', $data );
					
					if ( $res !== false )
					{
						if ( $var [ 'left' ] == 0 )
						{
							$updates [] = 'seeders=seeders+1';
						}
						else
						{
							$updates [] = 'leechers=leechers+1';
						}	
					}
				}
			break;
		
			
		/*
		case 'started':
			break;
		*/
	}
	
	
	# Update downloads table
	if ( count ( $updates ) > 0 )
	{
		$db -> update ( 'UPDATE dl_downloads SET '. implode ( ', ', $updates ) .' WHERE fid='. $torrent [ 'fid' ] );	
	}
	
}
catch ( error $e )
{
			
	$bittorrent -> error ( $e -> getMessage () );
	
}

?>