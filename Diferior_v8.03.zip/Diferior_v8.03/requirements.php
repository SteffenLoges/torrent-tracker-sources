<?php
/*
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
  '    DIFERIOR (http://diferior.com)
  '  ---------------------------------------
  '
  '	This file is part of Diferior (http://diferior.com).
  '
  ' Diferior is free software: you can redistribute it and/or modify
  ' it under the terms of the GNU General Public License as published by
  ' the Free Software Foundation, either version 3 of the License, or
  ' (at your option) any later version.
  '
  ' Diferior is distributed in the hope that it will be useful,
  ' but WITHOUT ANY WARRANTY; without even the implied warranty of
  ' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ' GNU General Public License for more details.
  '
  ' You should have received a copy of the GNU General Public License
  ' along with Diferior.  If not, see <http://www.gnu.org/licenses/>.
  '  
  '  ---------------------------------------
  '    Diferior is copyright 2007, 2008 Povilas Musteikis
   . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
*/


/*
	Diferior requires PHP 5.2.x, MySQL 4.x, mod_rewrite, cache_lite 1.7.2 and Smarty 2.6.x to run.
	Some additional requirements might be needed for additional functionality.
*/


# PHP
if ( !function_exists ( 'version_compare' ) || version_compare ( phpversion (), '5.2', '<' ) ) 
	die ( 'Diferior cannot be run in this environment. Please update your PHP installation to version 5.2.x or higher (or contact your hosting support if you are on a shared server).' );
	
# Got to implement more checks...	
	
?>