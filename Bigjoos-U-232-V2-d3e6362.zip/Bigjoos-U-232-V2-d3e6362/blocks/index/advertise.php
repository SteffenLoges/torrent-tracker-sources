<?php
/**
 *   https://09source.kicks-ass.net:8443/svn/installer09/
 *   Licence Info: GPL
 *   Copyright (C) 2010 Installer09 v.1
 *   A bittorrent tracker source based on TBDev.net/tbsource/bytemonsoon.
 *   Project Leaders: Mindless,putyn,kidvision.
 **/
//==Installer.me
   $HTMLOUT .= "
    <div class='headline'>
     Advertisement :: {$lang['index_installerme']}
     </div>
    <div class='headbody'>";
   $HTMLOUT .= "
   <div align='center'>
    <a href='http://installer09.me'>
    <img border='0' src='pic/4_logo.png' alt='Installer.me' title='Installer.me' width='401' height='67' /></a>
   </div>";
   $HTMLOUT .= "
    </div><br />";
    
//==SVN
   $HTMLOUT .= "
    <div class='headline'>
     Advertisement :: {$lang['index_installer09']}
     </div>
    <div class='headbody'>";
   $HTMLOUT .= "
    <div align='center'>
     <a href='https://09source.kicks-ass.net:8443/svn/installer09/'>
      <img border='0' src='pic/logo.png' alt='Installer09' title='Installer09 SVN Username : 09members - Password : 09source' width='730' height='68' />
     </a></div>";
   $HTMLOUT .= "
    </div><br />";
?>