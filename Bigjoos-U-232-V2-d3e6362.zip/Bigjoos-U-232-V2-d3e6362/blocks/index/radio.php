<?php
require_once ROOT_DIR.'radio.php';
$HTMLOUT .= "<div class='headline'>{$INSTALLER09['site_name']} Radio</div><div class='headbody'>";
$HTMLOUT .= radioinfo($radio);
$HTMLOUT .="</div>";
?>