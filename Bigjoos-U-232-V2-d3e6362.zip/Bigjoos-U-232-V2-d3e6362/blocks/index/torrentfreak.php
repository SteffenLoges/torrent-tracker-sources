<?php
require_once ROOT_DIR.'tfreak.php';
$HTMLOUT .= "<div class='headline'>{$INSTALLER09['site_name']} Torrent Freak News</div><div class='headbody2'>";
$HTMLOUT .= rsstfreakinfo();
$HTMLOUT .="</div>";
?>