<?php
//==Disclaimer
    $HTMLOUT .= "<div class='headline'>{$lang['index_disclaimer']}</div><div class='headbody'>";
    $HTMLOUT .= sprintf("<p><font class='small'>{$lang['foot_disclaimer']}</font></p>", $INSTALLER09['site_name']);
    $HTMLOUT .= "</div>";
?>