<?php
// Announcement Code...
   $ann_subject = trim($CURUSER['curr_ann_subject']);
   $ann_body = trim($CURUSER['curr_ann_body']);
   if ((!empty($ann_subject)) AND (!empty($ann_body)))
   {
   $HTMLOUT .= "<div class='headline'>{$lang['index_announce']}</div>
   <div class='headbody'>
   <table width='100%' border='1' cellspacing='0' cellpadding='5'>
   <tr><td bgcolor='transparent'><b><font color='red'>Announcement&nbsp;: 
   ".htmlspecialchars($ann_subject)."</font></b></td></tr>
   <tr><td style='padding: 10px; background:lightgrey'>
   ".format_comment($ann_body)."
   <br /><hr /><br />
   Click <a href='{$INSTALLER09['baseurl']}/clear_announcement.php'>
   <i><b>here</b></i></a> to clear this announcement.</td></tr></table></div><br />\n";
   }
?>