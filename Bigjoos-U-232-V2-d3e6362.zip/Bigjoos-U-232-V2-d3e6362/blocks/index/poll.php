<?php
//==Poll
   //$HTMLOUT .= "<a href=\"javascript: klappe_news('a3')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pica3\" alt=\"[Hide/Show]\"></a><div id=\"ka3\" style=\"display: none;\">";
   $HTMLOUT .= parse_poll();
   //$HTMLOUT .="</div>";
?>