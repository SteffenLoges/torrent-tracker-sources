<?php
if ($CURUSER) {
$htmlout .= "
<div style='width: 100%; text-align: center; padding: 10px;'>
 <a href='http://installer09.me' target='_blank'><img src='./pic/supportme.png' alt=''/></a>
</div>";
}
?>