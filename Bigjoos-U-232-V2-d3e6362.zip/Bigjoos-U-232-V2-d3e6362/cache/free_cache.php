<?php

/**
This file created on Feb 24 2011 20:24:53.
freeleech mod by pdq for TBDev.net 2009.
**/

$free = array(
array('modifier'=> 0, 'expires'=> 'Inf.', 'setby'=> 'No One', 'title'=> 'Add title', 'message'=> 'Add Message')
);

?>