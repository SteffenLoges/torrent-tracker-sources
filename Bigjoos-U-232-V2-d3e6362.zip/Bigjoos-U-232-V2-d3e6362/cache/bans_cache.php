<?php

$bans = array(

);

?>