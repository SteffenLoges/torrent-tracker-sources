<?php

/////////////////////////////////////////////////////////////
/////////////////////// DO NOT EDIT! ///////////////////////
////////////// File Automatically Generated //////////////
/////////////////////////////////////////////////////////

$countries	=	array (
					array (
							'id'			=>	'1',
							'name'			=>	'Sweden',
							'flagpic'			=>	'sweden.gif'
					),
					array (
							'id'			=>	'2',
							'name'			=>	'United States of America',
							'flagpic'			=>	'usa.gif'
					),
					array (
							'id'			=>	'3',
							'name'			=>	'Russia',
							'flagpic'			=>	'russia.gif'
					),
					array (
							'id'			=>	'4',
							'name'			=>	'Finland',
							'flagpic'			=>	'finland.gif'
					),
					array (
							'id'			=>	'5',
							'name'			=>	'Canada',
							'flagpic'			=>	'canada.gif'
					),
					array (
							'id'			=>	'6',
							'name'			=>	'France',
							'flagpic'			=>	'france.gif'
					),
					array (
							'id'			=>	'7',
							'name'			=>	'Germany',
							'flagpic'			=>	'germany.gif'
					),
					array (
							'id'			=>	'8',
							'name'			=>	'China',
							'flagpic'			=>	'china.gif'
					),
					array (
							'id'			=>	'9',
							'name'			=>	'Italy',
							'flagpic'			=>	'italy.gif'
					),
					array (
							'id'			=>	'10',
							'name'			=>	'Denmark',
							'flagpic'			=>	'denmark.gif'
					),
					array (
							'id'			=>	'11',
							'name'			=>	'Norway',
							'flagpic'			=>	'norway.gif'
					),
					array (
							'id'			=>	'12',
							'name'			=>	'United Kingdom',
							'flagpic'			=>	'uk.gif'
					),
					array (
							'id'			=>	'13',
							'name'			=>	'Ireland',
							'flagpic'			=>	'ireland.gif'
					),
					array (
							'id'			=>	'14',
							'name'			=>	'Poland',
							'flagpic'			=>	'poland.gif'
					),
					array (
							'id'			=>	'15',
							'name'			=>	'Netherlands',
							'flagpic'			=>	'netherlands.gif'
					),
					array (
							'id'			=>	'16',
							'name'			=>	'Belgium',
							'flagpic'			=>	'belgium.gif'
					),
					array (
							'id'			=>	'17',
							'name'			=>	'Japan',
							'flagpic'			=>	'japan.gif'
					),
					array (
							'id'			=>	'18',
							'name'			=>	'Brazil',
							'flagpic'			=>	'brazil.gif'
					),
					array (
							'id'			=>	'19',
							'name'			=>	'Argentina',
							'flagpic'			=>	'argentina.gif'
					),
					array (
							'id'			=>	'20',
							'name'			=>	'Australia',
							'flagpic'			=>	'australia.gif'
					),
					array (
							'id'			=>	'21',
							'name'			=>	'New Zealand',
							'flagpic'			=>	'newzealand.gif'
					),
					array (
							'id'			=>	'23',
							'name'			=>	'Spain',
							'flagpic'			=>	'spain.gif'
					),
					array (
							'id'			=>	'24',
							'name'			=>	'Portugal',
							'flagpic'			=>	'portugal.gif'
					),
					array (
							'id'			=>	'25',
							'name'			=>	'Mexico',
							'flagpic'			=>	'mexico.gif'
					),
					array (
							'id'			=>	'26',
							'name'			=>	'Singapore',
							'flagpic'			=>	'singapore.gif'
					),
					array (
							'id'			=>	'27',
							'name'			=>	'India',
							'flagpic'			=>	'india.gif'
					),
					array (
							'id'			=>	'28',
							'name'			=>	'Albania',
							'flagpic'			=>	'albania.gif'
					),
					array (
							'id'			=>	'29',
							'name'			=>	'South Africa',
							'flagpic'			=>	'southafrica.gif'
					),
					array (
							'id'			=>	'30',
							'name'			=>	'South Korea',
							'flagpic'			=>	'southkorea.gif'
					),
					array (
							'id'			=>	'31',
							'name'			=>	'Jamaica',
							'flagpic'			=>	'jamaica.gif'
					),
					array (
							'id'			=>	'32',
							'name'			=>	'Luxembourg',
							'flagpic'			=>	'luxembourg.gif'
					),
					array (
							'id'			=>	'33',
							'name'			=>	'Hong Kong',
							'flagpic'			=>	'hongkong.gif'
					),
					array (
							'id'			=>	'34',
							'name'			=>	'Belize',
							'flagpic'			=>	'belize.gif'
					),
					array (
							'id'			=>	'35',
							'name'			=>	'Algeria',
							'flagpic'			=>	'algeria.gif'
					),
					array (
							'id'			=>	'36',
							'name'			=>	'Angola',
							'flagpic'			=>	'angola.gif'
					),
					array (
							'id'			=>	'37',
							'name'			=>	'Austria',
							'flagpic'			=>	'austria.gif'
					),
					array (
							'id'			=>	'38',
							'name'			=>	'Yugoslavia',
							'flagpic'			=>	'yugoslavia.gif'
					),
					array (
							'id'			=>	'39',
							'name'			=>	'Western Samoa',
							'flagpic'			=>	'westernsamoa.gif'
					),
					array (
							'id'			=>	'40',
							'name'			=>	'Malaysia',
							'flagpic'			=>	'malaysia.gif'
					),
					array (
							'id'			=>	'41',
							'name'			=>	'Dominican Republic',
							'flagpic'			=>	'dominicanrep.gif'
					),
					array (
							'id'			=>	'42',
							'name'			=>	'Greece',
							'flagpic'			=>	'greece.gif'
					),
					array (
							'id'			=>	'43',
							'name'			=>	'Guatemala',
							'flagpic'			=>	'guatemala.gif'
					),
					array (
							'id'			=>	'44',
							'name'			=>	'Israel',
							'flagpic'			=>	'israel.gif'
					),
					array (
							'id'			=>	'45',
							'name'			=>	'Pakistan',
							'flagpic'			=>	'pakistan.gif'
					),
					array (
							'id'			=>	'46',
							'name'			=>	'Czech Republic',
							'flagpic'			=>	'czechrep.gif'
					),
					array (
							'id'			=>	'47',
							'name'			=>	'Serbia',
							'flagpic'			=>	'serbia.gif'
					),
					array (
							'id'			=>	'48',
							'name'			=>	'Seychelles',
							'flagpic'			=>	'seychelles.gif'
					),
					array (
							'id'			=>	'49',
							'name'			=>	'Taiwan',
							'flagpic'			=>	'taiwan.gif'
					),
					array (
							'id'			=>	'50',
							'name'			=>	'Puerto Rico',
							'flagpic'			=>	'puertorico.gif'
					),
					array (
							'id'			=>	'51',
							'name'			=>	'Chile',
							'flagpic'			=>	'chile.gif'
					),
					array (
							'id'			=>	'52',
							'name'			=>	'Cuba',
							'flagpic'			=>	'cuba.gif'
					),
					array (
							'id'			=>	'53',
							'name'			=>	'Congo',
							'flagpic'			=>	'congo.gif'
					),
					array (
							'id'			=>	'54',
							'name'			=>	'Afghanistan',
							'flagpic'			=>	'afghanistan.gif'
					),
					array (
							'id'			=>	'55',
							'name'			=>	'Turkey',
							'flagpic'			=>	'turkey.gif'
					),
					array (
							'id'			=>	'56',
							'name'			=>	'Uzbekistan',
							'flagpic'			=>	'uzbekistan.gif'
					),
					array (
							'id'			=>	'57',
							'name'			=>	'Switzerland',
							'flagpic'			=>	'switzerland.gif'
					),
					array (
							'id'			=>	'58',
							'name'			=>	'Kiribati',
							'flagpic'			=>	'kiribati.gif'
					),
					array (
							'id'			=>	'59',
							'name'			=>	'Philippines',
							'flagpic'			=>	'philippines.gif'
					),
					array (
							'id'			=>	'60',
							'name'			=>	'Burkina Faso',
							'flagpic'			=>	'burkinafaso.gif'
					),
					array (
							'id'			=>	'61',
							'name'			=>	'Nigeria',
							'flagpic'			=>	'nigeria.gif'
					),
					array (
							'id'			=>	'62',
							'name'			=>	'Iceland',
							'flagpic'			=>	'iceland.gif'
					),
					array (
							'id'			=>	'63',
							'name'			=>	'Nauru',
							'flagpic'			=>	'nauru.gif'
					),
					array (
							'id'			=>	'64',
							'name'			=>	'Slovenia',
							'flagpic'			=>	'slovenia.gif'
					),
					array (
							'id'			=>	'66',
							'name'			=>	'Turkmenistan',
							'flagpic'			=>	'turkmenistan.gif'
					),
					array (
							'id'			=>	'67',
							'name'			=>	'Bosnia Herzegovina',
							'flagpic'			=>	'bosniaherzegovina.gif'
					),
					array (
							'id'			=>	'68',
							'name'			=>	'Andorra',
							'flagpic'			=>	'andorra.gif'
					),
					array (
							'id'			=>	'69',
							'name'			=>	'Lithuania',
							'flagpic'			=>	'lithuania.gif'
					),
					array (
							'id'			=>	'70',
							'name'			=>	'Macedonia',
							'flagpic'			=>	'macedonia.gif'
					),
					array (
							'id'			=>	'71',
							'name'			=>	'Netherlands Antilles',
							'flagpic'			=>	'nethantilles.gif'
					),
					array (
							'id'			=>	'72',
							'name'			=>	'Ukraine',
							'flagpic'			=>	'ukraine.gif'
					),
					array (
							'id'			=>	'73',
							'name'			=>	'Venezuela',
							'flagpic'			=>	'venezuela.gif'
					),
					array (
							'id'			=>	'74',
							'name'			=>	'Hungary',
							'flagpic'			=>	'hungary.gif'
					),
					array (
							'id'			=>	'75',
							'name'			=>	'Romania',
							'flagpic'			=>	'romania.gif'
					),
					array (
							'id'			=>	'76',
							'name'			=>	'Vanuatu',
							'flagpic'			=>	'vanuatu.gif'
					),
					array (
							'id'			=>	'77',
							'name'			=>	'Vietnam',
							'flagpic'			=>	'vietnam.gif'
					),
					array (
							'id'			=>	'78',
							'name'			=>	'Trinidad & Tobago',
							'flagpic'			=>	'trinidadandtobago.gif'
					),
					array (
							'id'			=>	'79',
							'name'			=>	'Honduras',
							'flagpic'			=>	'honduras.gif'
					),
					array (
							'id'			=>	'80',
							'name'			=>	'Kyrgyzstan',
							'flagpic'			=>	'kyrgyzstan.gif'
					),
					array (
							'id'			=>	'81',
							'name'			=>	'Ecuador',
							'flagpic'			=>	'ecuador.gif'
					),
					array (
							'id'			=>	'82',
							'name'			=>	'Bahamas',
							'flagpic'			=>	'bahamas.gif'
					),
					array (
							'id'			=>	'83',
							'name'			=>	'Peru',
							'flagpic'			=>	'peru.gif'
					),
					array (
							'id'			=>	'84',
							'name'			=>	'Cambodia',
							'flagpic'			=>	'cambodia.gif'
					),
					array (
							'id'			=>	'85',
							'name'			=>	'Barbados',
							'flagpic'			=>	'barbados.gif'
					),
					array (
							'id'			=>	'86',
							'name'			=>	'Bangladesh',
							'flagpic'			=>	'bangladesh.gif'
					),
					array (
							'id'			=>	'87',
							'name'			=>	'Laos',
							'flagpic'			=>	'laos.gif'
					),
					array (
							'id'			=>	'88',
							'name'			=>	'Uruguay',
							'flagpic'			=>	'uruguay.gif'
					),
					array (
							'id'			=>	'89',
							'name'			=>	'Antigua Barbuda',
							'flagpic'			=>	'antiguabarbuda.gif'
					),
					array (
							'id'			=>	'90',
							'name'			=>	'Paraguay',
							'flagpic'			=>	'paraguay.gif'
					),
					array (
							'id'			=>	'93',
							'name'			=>	'Thailand',
							'flagpic'			=>	'thailand.gif'
					),
					array (
							'id'			=>	'92',
							'name'			=>	'Union of Soviet Socialist Republics',
							'flagpic'			=>	'ussr.gif'
					),
					array (
							'id'			=>	'94',
							'name'			=>	'Senegal',
							'flagpic'			=>	'senegal.gif'
					),
					array (
							'id'			=>	'95',
							'name'			=>	'Togo',
							'flagpic'			=>	'togo.gif'
					),
					array (
							'id'			=>	'96',
							'name'			=>	'North Korea',
							'flagpic'			=>	'northkorea.gif'
					),
					array (
							'id'			=>	'97',
							'name'			=>	'Croatia',
							'flagpic'			=>	'croatia.gif'
					),
					array (
							'id'			=>	'98',
							'name'			=>	'Estonia',
							'flagpic'			=>	'estonia.gif'
					),
					array (
							'id'			=>	'99',
							'name'			=>	'Colombia',
							'flagpic'			=>	'colombia.gif'
					),
					array (
							'id'			=>	'100',
							'name'			=>	'Lebanon',
							'flagpic'			=>	'lebanon.gif'
					),
					array (
							'id'			=>	'101',
							'name'			=>	'Latvia',
							'flagpic'			=>	'latvia.gif'
					),
					array (
							'id'			=>	'102',
							'name'			=>	'Costa Rica',
							'flagpic'			=>	'costarica.gif'
					),
					array (
							'id'			=>	'103',
							'name'			=>	'Egypt',
							'flagpic'			=>	'egypt.gif'
					),
					array (
							'id'			=>	'104',
							'name'			=>	'Bulgaria',
							'flagpic'			=>	'bulgaria.gif'
					),
					array (
							'id'			=>	'105',
							'name'			=>	'Isla de Muerte',
							'flagpic'			=>	'jollyroger.gif'
					),
					array (
							'id'			=>	'106',
							'name'			=>	'Scotland',
							'flagpic'			=>	'scotland.gif'
					)
			);
?>