<?php

$BLOCKS = array(
	'ie_user_alert' => 1,
	'news_on' => 1,
	'shoutbox_on' => 1,
	'active_users_on' => 1,
	'active_24h_users_on' => 1,
	'active_irc_users_on' => 1,
	'active_birthday_users_on' => 1,
	'stats_on' => 1,
	'disclaimer_on' => 1,
	'latest_user_on' => 1,
	'forum_posts_on' => 1,
	'latest_torrents_on' => 1,
	'latest_torrents_scroll_on' => 0,
	'announcement_on' => 1,
	'donation_progress_on' => 1,
	'ads_on' => 1,
	'radio_on' => 0,
	'torrentfreak_on' => 0,
	'xmas_gift_on' => 0,
	'active_poll_on' => 1,
	'global_freeleech_on' => 1,
	'global_demotion_on' => 1,
	'global_message_on' => 1,
	'global_staff_warn_on' => 1,
	'global_staff_report_on' => 1,
	'global_staff_uploadapp_on' => 1,
	'global_happyhour_on' => 1,
	'global_crazyhour_on' => 1,

);

?>