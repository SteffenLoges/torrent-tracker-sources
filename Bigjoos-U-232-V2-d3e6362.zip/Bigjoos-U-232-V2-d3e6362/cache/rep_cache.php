<?php

$reputations = array(
	-999999 => 'is infamous around these parts',
	-50 => 'can only hope to improve',
	-10 => 'has a little shameless behaviour in the past',
	0 => 'is an unknown quantity at this point',
	15 => 'is on a distinguished road',
	50 => 'will become famous soon enough',
	150 => 'has a spectacular aura about',
	250 => 'is a jewel in the rough',
	350 => 'is just really nice',
	450 => 'is a glorious beacon of light',
	550 => 'is a name known to all',
	650 => 'is a splendid one to behold',
	1000 => 'has much to be proud of',
	1500 => 'has a brilliant future',
	2000 => 'has a reputation beyond repute',

);

?>