<?php
$subs = array(
array('id'=> '1', 'name'=> 'Romania', 'pic'=> 'pic/flag/romania.gif'),
array('id'=> '2', 'name'=> 'English',  'pic'=> 'pic/flag/uk.gif'),
array('id'=> '3', 'name'=> 'Bulgarian', 'pic'=> 'pic/flag/bulgaria.gif'),
array('id'=> '4', 'name'=> 'Deutsch',  'pic'=> 'pic/flag/germany.gif')
);
?>