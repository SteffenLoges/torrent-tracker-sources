tinyMCE.addI18n('ru.stamps',{
stamps_desc: "Печати и штампы"
});