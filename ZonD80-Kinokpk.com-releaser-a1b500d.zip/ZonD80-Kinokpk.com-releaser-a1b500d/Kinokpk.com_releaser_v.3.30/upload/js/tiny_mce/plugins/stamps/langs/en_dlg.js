tinyMCE.addI18n('en.stamps_dlg',{
title:"Insert stamp"
});