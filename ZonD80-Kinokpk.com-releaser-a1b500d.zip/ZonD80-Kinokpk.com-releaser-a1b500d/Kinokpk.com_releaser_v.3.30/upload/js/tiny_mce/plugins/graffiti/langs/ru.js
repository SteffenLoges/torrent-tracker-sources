tinyMCE.addI18n('ru.graffiti',{
graffiti_desc: "Нарисовать граффити"
});