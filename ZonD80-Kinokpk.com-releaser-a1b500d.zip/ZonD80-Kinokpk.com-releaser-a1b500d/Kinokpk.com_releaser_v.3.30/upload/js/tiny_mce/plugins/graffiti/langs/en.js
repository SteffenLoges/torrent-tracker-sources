tinyMCE.addI18n('en.graffiti',{
graffiti_desc:"Graffiti",
title:"Draw a graffiti",
send:"Send",
clear:"Clear",
cancel:"Cancel",
size:"Size",
opacity:"Opacity",
image_cleared:"Image was successfully cleared",
action_undone:"Undone succeeded",
saving:"Saving",
loading:"Loading",
loading_error:"Error while processing image",
source:"Source",
confirm_delete:"Are you sure to delete image",
yes:"Yes",
no:"No"
});