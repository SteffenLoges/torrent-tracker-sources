tinyMCE.addI18n('ru.spoiler',{
spoiler_desc:"Спойлер",
spoiler_question:"Введите название спойлера или оставьте поле пустым"
});