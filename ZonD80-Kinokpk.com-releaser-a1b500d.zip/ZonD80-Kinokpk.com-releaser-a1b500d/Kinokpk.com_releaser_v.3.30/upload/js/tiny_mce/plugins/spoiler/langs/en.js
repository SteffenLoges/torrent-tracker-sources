tinyMCE.addI18n('en.spoiler',{
spoiler_desc:"Spoiler",
spoiler_question:"Enter the name of spoiler or leave field blank for default"
});