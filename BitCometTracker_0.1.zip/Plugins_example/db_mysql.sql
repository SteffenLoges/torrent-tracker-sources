CREATE TABLE trackerstatus (
  InfoHash char(20) binary NOT NULL default '0',
  CompletedNum int(10) unsigned NOT NULL default '0',
  PeerNum int(10) unsigned NOT NULL default '0',
  SeederNum int(10) unsigned NOT NULL default '0',
  UpdateTime timestamp(14) NOT NULL,
  PRIMARY KEY  (InfoHash),
  UNIQUE KEY InfoHash (InfoHash),
)

