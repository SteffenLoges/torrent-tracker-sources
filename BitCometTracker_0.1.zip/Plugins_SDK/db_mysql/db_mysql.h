#define DLL_EXPORT_API __declspec(dllexport)
#define CALL_TYPE __fastcall

extern "C" 
{

DLL_EXPORT_API BOOL CALL_TYPE db_connect(LPSTR);
DLL_EXPORT_API BOOL CALL_TYPE db_update(const unsigned char* , int, int, int);
DLL_EXPORT_API BOOL CALL_TYPE db_disconnect();

}
