// db_mssql.cpp : Defines the entry point for the DLL application.
//

//#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <stdio.h>
#include <string.h>

#include <mysql.h>
#include "db_mysql.h"

MYSQL *conn, mysql;
BOOL	bInited;

BOOL Init()
{
	conn = mysql_init(&mysql);
    if (conn) return TRUE;
    return FALSE;
}

BOOL ParseConnStr(char* conn_str, char* host, char* user, char* passwd, char* db)
{
	// in this example, i use the format as "host:user:passwd:db", and you can define yours as you like
	char* p;
	char* q;
	
	if (!conn_str || !host || !user || !passwd || !db) return FALSE;
	
	q = p = conn_str;
	while (*p && *p != ':') p++;
	if (!*p) return FALSE;
	strncpy(host, q, p - q);
	host[p-q] = '\0';
	
	q = ++p;
	while (*p && *p != ':') p++;
	if (!*p) return FALSE;
	strncpy(user, q, p - q);
	user[p-q] = '\0';

	q = ++p;
	while (*p && *p != ':') p++;
	if (!*p) return FALSE;
	strncpy(passwd, q, p - q);
	passwd[p-q] = '\0';

	q = ++p;
	while (*p && *p != ':') p++;
	strncpy(db, q, p - q);
	db[p-q] = '\0';
	
	return TRUE;
}

/* get the hex string presentation of a binary
    dst     :   hex string
    data    :   binary data
    size    :   size of data
    !!make sure dst's size >= size*2+1
*/
char* ToHexString(char* dst, const unsigned char* data, size_t size)
{
	char pBuf[4];
    size_t i;

    if (!dst) return NULL;

	memset( dst, 0, sizeof( char ) * (size * 2 + 1) );
	for(i=0; i<size; i++ )
	{
		memset( pBuf, 0, sizeof( char ) * 4 );
		sprintf( pBuf, "%02x", (unsigned char)data[i] );
		strcat(dst, pBuf);
	}
	return dst;
}



BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		bInited = Init();
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}

DLL_EXPORT_API BOOL CALL_TYPE db_connect(LPSTR conn_str)
{
	char host[32];
	char user[32];
	char passwd[32];
	char db[32];
	ParseConnStr(conn_str, host, user, passwd, db);
	conn = mysql_real_connect(&(mysql), host, user, passwd, db, 0, NULL, 0);
    if (conn) return TRUE;
    return FALSE;
}

DLL_EXPORT_API BOOL CALL_TYPE db_update(const unsigned char* info_hash, int completed_num, int peer_num, int seeder_num)
{
    MYSQL_RES	* res ;
	char hash_string[64];
	char sql[512];
	char sqlf_select[] = "SELECT InfoHash FROM TrackerStatus WHERE InfoHash='%s'";
	char sqlf_insert[] = "INSERT INTO TrackerStatus (InfoHash, CompletedNum, PeerNum, SeederNum) VALUES ('%s', %d, %d, %d)";
	char sqlf_update[] = "UPDATE TrackerStatus SET CompletedNum=CompletedNum+%d, PeerNum=%d, SeederNum=%d WHERE InfoHash='%s'";

	if ((info_hash == NULL) || (completed_num < 0) || (peer_num < 0) || (seeder_num < 0) )
	{
		return FALSE;
	}

    if (!bInited) return FALSE;	
    
    ToHexString(hash_string, info_hash, 20);

 	sprintf(sql, sqlf_select, hash_string);
    if (mysql_real_query(&mysql, sql, strlen(sql)) != 0) {
    	return FALSE;
    }
        
    res = mysql_store_result( &mysql );
    if (mysql_num_rows( res ) > 0) {
    	sprintf(sql, sqlf_update, completed_num, peer_num, seeder_num, hash_string);
    }else {
    	sprintf(sql, sqlf_insert, hash_string, completed_num, peer_num, seeder_num);
    }
    
    if (mysql_real_query(&mysql, sql, strlen(sql)) != 0) {
		return FALSE;
    }
    
    return TRUE;
}

DLL_EXPORT_API BOOL CALL_TYPE db_disconnect()
{
	if (conn) {
        mysql_close(conn);
        conn = NULL;
	}
    return TRUE;
}
