function enabledel(){
document.deluser.submit.disabled=document.deluser.submit.checked;
alert ("You can now delete this users account, be VERY VERY sure.  Have a nice day todgerme :)");
}
function disabledel(){
document.deluser.submit.disabled=!document.deluser.submit.checked;
}
