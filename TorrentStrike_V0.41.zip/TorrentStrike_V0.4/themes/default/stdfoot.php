<?
  print("</td></tr></table>\n");
  print("<table class=\"bottom\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr valign=\"top\">\n");
  print("<td class=\"bottom\" align=\"left\" width=\"49%\"><img src=\"./pic/bottom_left.gif\" alt=\"\" /></td><td width=\"49%\" align=\"right\" class=\"bottom\"><img src=\"./pic/bottom_right.gif\" alt=\"\" /></td>\n");
  print("</tr></table>\n");
  print("</body></html>\n");
?>