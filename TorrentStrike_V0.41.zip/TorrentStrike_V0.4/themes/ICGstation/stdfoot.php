							<br/>
<? end_frame(); ?>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<br/>
		
		<table class="theme_table" width="100%" cellpadding="0" cellspacing="0" border="0">
		  <tr> 
			<td align="left"><a href="http://validator.w3.org/check/referer"><img src="./themes/ICGstation/images/w3c.gif" border="0" alt="" /></a></td>
			<td align="right"><a href="#top"><img src="./themes/ICGstation/images/top.gif" border="0" alt="" /></a></td>
		  </tr>
		</table>
		<table class="theme_table" width="100%" cellpadding="0" cellspacing="0" border="0">
		  <tr> 
				<td><img src="./themes/ICGstation/images/bt_left.gif" border="0" alt="" /></td>
				<td width="100%" class="indexbom" align="center">
					<center><font class="small"><a href="http://www.torrentstrike.com">TorrentStrike</a> is Powered by <a href="http://www.tbdev.net">TBDev</a> - iCGstation v1.0 Template by <a href="http://www.ioptional.com/">Ray</a> � 2003, 2004 <a href="http://www.ioptional.com/">iOptional</a></font></center>
				</td>
				<td><img src="./themes/ICGstation/images/bt_right.gif" border="0" alt="" /></td>
		  </tr>
		</table>
	</td>
</tr>
</table>
</body>
</html>
