-- MySQL dump 9.10
--
-- Host: localhost    Database: bittorrent
-- ------------------------------------------------------
-- Server version	4.0.18-log

--
-- Dumping data for table `categories`
--

INSERT INTO categories VALUES (1,'Appz/PC ISO','cat_apps.gif');
INSERT INTO categories VALUES (4,'Games/PC ISO','cat_games.gif');
INSERT INTO categories VALUES (5,'Movies/SVCD','cat_movies.gif');
INSERT INTO categories VALUES (6,'Music','cat_music.gif');
INSERT INTO categories VALUES (7,'Episodes','cat_episodes.gif');
INSERT INTO categories VALUES (9,'XXX','cat_xxx.gif');
INSERT INTO categories VALUES (12,'Games/GBA','cat_games.gif');
INSERT INTO categories VALUES (17,'Games/PS2','cat_games.gif');
INSERT INTO categories VALUES (23,'Anime','cat_anime.gif');
INSERT INTO categories VALUES (19,'Movies/XviD','cat_movies.gif');
INSERT INTO categories VALUES (20,'Movies/DVD-R','cat_movies.gif');
INSERT INTO categories VALUES (21,'Games/PC Rips','cat_games.gif');
INSERT INTO categories VALUES (22,'Appz/misc','cat_apps.gif');

