-- MySQL dump 9.10
--
-- Host: localhost    Database: bittorrent
-- ------------------------------------------------------
-- Server version	4.0.18-log

--
-- Dumping data for table `stylesheets`
--

INSERT INTO stylesheets VALUES (1,'ICGstation','ICGstation theme');
INSERT INTO stylesheets VALUES (2,'default','(default)');
INSERT INTO stylesheets VALUES (3,'large','Large text');

