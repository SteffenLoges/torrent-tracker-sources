This package contains FTS 2.0 - The next generation of FTS - BETA.
To install, simply go to install folder throught an browser :D .
You have to make include,include/secrets.php,include/annconf.php, install writable for installer to work.
For best results, make all files writable(0777).