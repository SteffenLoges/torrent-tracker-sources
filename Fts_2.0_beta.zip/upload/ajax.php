<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: ajax.php - Ajax Backend.                                         |
// | Version: 1.0                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
//error_reporting( E_ALL );
require "include/bittorrent.php";
dbconn();
$a = $_GET['action'];
function id_to_name($id){
$result = mysql_query( "SELECT `username` FROM `users` WHERE `id` = '".$id."' LIMIT 1" );
if( mysql_num_rows( $result ) < 1 ){
return( "Unknown[".$id.']' );
} else{
return mysql_result( $result, 0, 0 );
}
}
function update_topic_last_post($topicid){
$res = mysql_query("SELECT id FROM posts WHERE topicid=$topicid ORDER BY id DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res) or die(ajaxno);
$postid = $arr[0];
mysql_query("UPDATE topics SET lastpost=$postid WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);
}
if( $a == 'edit_forum_post' ){
if( !isset( $_GET['postid'] ) || empty( $_GET['postid'] ) || !is_numeric( $_GET['postid'] ) ){
print( ajaxi );
}
$postid = $_GET['postid'];
$get_info_sql = "SELECT `body` FROM `posts` WHERE `id` = '".$postid."' LIMIT 1";
$info_result = mysql_query( $get_info_sql );
$body = mysql_result( $info_result, 0, 0 );
// print out the <textarea> with the post in it
print( "<textarea onblur=\"if(confirm('".ajaxsa."')==true){sndReq('action=save_forum_post&postid=".$postid."&body='+this.value, 'fpost_".$postid."')}\">".$body."</textarea>" );
} elseif( $a == 'save_forum_post' ){
if( !isset( $_GET['postid'] ) || empty( $_GET['postid'] ) || !is_numeric( $_GET['postid'] ) ){
print( ajaxinvalid );
}
$postid = $_GET["postid"];
if (!is_valid_id($postid)){
die();
}
$res = mysql_query("SELECT * FROM posts WHERE id=$postid") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) != 1){
stderr(ajaxerror, ajaxnopost.$postid);
}
$arr = mysql_fetch_assoc($res);
$res2 = mysql_query("SELECT locked FROM topics WHERE id = " . $arr["topicid"]) or sqlerr(__FILE__, __LINE__);
$arr2 = mysql_fetch_assoc($res2);
if (mysql_num_rows($res) != 1){
stderr(ajaxerror, ajaxnotopic.$postid);
}
$locked = ($arr2["locked"] == 'yes');
if (($CURUSER["id"] != $arr["userid"] || $locked) && get_user_class() < UC_MODERATOR){
stderr(ajaxerror, ajaxde);
}
$body = $_GET['body'];
if ($body == ""){
stderr(ajaxerror, ajaxbody);
}
$username =
//$body_esc = sqlesc($body);
$editedat = get_date_time();
$upd_sql = "UPDATE `posts` SET `body` = '".$body."', `editedat` = '".$editedat."', `editedby` = '".$CURUSER['id']."' WHERE `id` = '".$postid."'";
mysql_query($upd_sql) or sqlerr(__FILE__, __LINE__);
// print out the updated body
print( $body );
// don't forget the edited msg!
print( "<p>".ajaxla." <a href=userdetails.php?id=".$arr['editedby']."><b>".id_to_name( $CURUSER['id'] )."</b></a> at ".$editedat." GMT</font></p>\n" );
} elseif( $a == 'delete_forum_post' ){
$postid = $_GET["postid"];
if (get_user_class() < UC_MODERATOR || !is_valid_id($postid)){
print( ajaxinvalidop );
die;
}
//------- Get topic id
$res = mysql_query("SELECT `topicid` FROM `posts` WHERE `id` = '".$postid."'") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res) or stderr(ajaxerror, ajaxpostf);
$topicid = $arr[0];
//------- We can not delete the post if it is the only one of the topic
$res = mysql_query("SELECT COUNT(*) FROM posts WHERE topicid=$topicid") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if( $arr[0] <= 1 ){
print( ajaxop );
}
//------- Delete post
mysql_query("DELETE FROM posts WHERE id=$postid") or sqlerr(__FILE__, __LINE__);
//------- Update topic
update_topic_last_post($topicid);
} elseif( $a == 'validate_email' ){
function valid_email( $email ){
/* validates an email based on the domain
I recommend you copy this to global.php
but it is up to you. */
$regexp = "^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$";
$valid = false;
if( eregi( $regexp, $email ) ){
list( $username, $domaintld) = split("@",$email);
if( function_exists( 'getmxrr' ) ){
if( getmxrr( $domaintld, $mxrecords ) ){
$valid = true;
}
} else{
// we have to assume they are telling the truth sad.gif
$valid = true;
}
} else{
$valid = false;
}
return $valid;
}
if( isset( $_GET['email'] ) && !empty( $_GET['email'] ) ){
if( !valid_email( $_GET['email'] ) ){
print("<strong>&lt;-- ".ajaxine."</strong>");
}
} else{
print( ajaxinvalidr );
die();
}
} elseif( $a == 'check_username' ){
if( !isset( $_GET['username'] ) || empty( $_GET['username'] ) ){
print(ajaxnouname);
die();
}
// check for that username
$check_res = mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `username` = '".$_GET['username']."'");
$num = mysql_result( $check_res, 0, 0 );
if( $num != 0 ){
print(ajaxuta);
}
} elseif( $a == 'edit_torrent_descr' ){
// check for valid ID
if( !isset( $_GET['torrent'] ) || !is_numeric( $_GET['torrent'] ) ){
print( ajaxinto );
die();
}
// get the torrent description
$descr_req = mysql_query("SELECT `descr`, `owner` FROM `torrents` WHERE `id` = '".$_GET['torrent']."'") or sqlerr(__FILE__,__LINE__);
$descr = mysql_fetch_assoc( $descr_req );
// make sure user is owner of torrent
if( $CURUSER['id'] != $descr['owner'] ){
print( ajaxinpe );
die();
}
print( "<textarea rows=\"10\" cols=\"35\" style=\"border:0px\" onblur=\"if(confirm('Save changes to torrent description?')==true){sndReq('action=save_torrent_descr&torrent=".$_GET['torrent']."&descr='+escape(this.value), 'descrTD')}\">".$descr['descr']."</textarea>" );
} elseif( $a == 'save_torrent_descr' ){
// check for valid ID
if( !isset( $_GET['torrent'] ) || !is_numeric( $_GET['torrent'] ) ){
print( ajaxinto );
die();
}
// get the torrent description
$descr_req = mysql_query("SELECT `owner` FROM `torrents` WHERE `id` = '".$_GET['torrent']."'") or sqlerr(__FILE__,__LINE__);
$descr = mysql_fetch_assoc( $descr_req );
// make sure user is owner of torrent
if( $CURUSER['id'] != $descr['owner'] ){
print( ajaxinpe );
die();
}
$upd_sql = "UPDATE `torrents` SET `descr` = '".$_GET['descr']."' WHERE `id` = '".$_GET['torrent']."'";
mysql_query($upd_sql) or sqlerr(__FILE__,__LINE__);
print( nl2br( stripslashes( $_GET['descr'] ) ) );
} elseif( $a == 'change_banned_torrent' ){
//check valid torrent
if( !isset( $_GET['torrent'] ) || !is_numeric( $_GET['torrent'] ) ){
print( ajaxinto );
die();
}
// check is mod or higher
if( get_user_class() < UC_MODERATOR ){
print( ajaxinpe );
die();
}
// create the select
print( "<select onchange=\"if(confirm('Save banned state?')==true){sndReq('action=save_banned_torrent&torrent=".$_GET['torrent']."&banned='+this.selectedIndex, 'bannedChange')}\">
<option value=\"\" selected=\"selected\">Banned?</option>
<option value=\"1\">Yes</option>
<option value=\"0\">No</option>
</select>
");
} elseif( $a == 'save_banned_torrent' ){
//check valid torrent
if( !isset( $_GET['torrent'] ) || !is_numeric( $_GET['torrent'] ) ){
print( ajaxinto );
die();
}
// check is mod or higher
if( get_user_class() < UC_MODERATOR ){
print( ajaxinpe );
die();
}
// convert $_GET['banned'] to 'yes' or 'no'
switch( $_GET['banned'] ){
case 1 : $state = 'yes'; break;
case 2 : $state = 'no'; break;
default : $state = 'no'; break;
}
// do the SQL
mysql_query("UPDATE `torrents` SET `banned` = '".$state."' WHERE `id` = '".$_GET['id']."' LIMIT 1") or sqlerr(__FILE__,__LINE__);
// print the outcome
print( $state );
} elseif( $a == 'change_type_torrent' ){
//check valid torrent
if( !isset( $_GET['torrent'] ) || !is_numeric( $_GET['torrent'] ) ){
print( ajaxinto );
die();
}
// check is mod or higher
if( get_user_class() < UC_MODERATOR ){
print( ajaxinpe );
die();
}
// create the select
print("<select onchange=\"if(confirm('Save type change?')==true){sndReq('action=save_type_torrent&torrent=".$_GET['torrent']."&type='+this.options[this.selectedIndex].value, 'typeChange')}\">");
$cats = genrelist();
print("<option value=\"\">(choose one)</option>\n");
foreach ($cats as $row){
print("<option value=\"".$row["id"]."\">".htmlspecialchars($row["name"])."</option>\n");
}
print("</select>\n");
} elseif( $a == 'save_type_torrent' ){
//check valid torrent
if( !isset( $_GET['torrent'] ) || !is_numeric( $_GET['torrent'] ) ){
print( ajaxinto );
die();
}
// check is mod or higher
if( get_user_class() < UC_MODERATOR ){
print( ajaxinpe );
die();
}
// do the SQL
mysql_query("UPDATE `torrents` SET `category` = '".$_GET['type']."' WHERE `id` = '".$_GET['torrent']."' LIMIT 1") or sqlerr(__FILE__,__LINE__);
// get the category in text form
$cats_res = mysql_query("SELECT `name` FROM `categories` WHERE `id` = '".$_GET['type']."'");
$cat = mysql_result( $cats_res, 0, 0 );
// print the outcome
print( $cat );
} elseif( $a == 'edit_torrent_comment' ){
//check valid comment
if( !isset( $_GET['comment'] ) || !is_numeric( $_GET['comment'] ) || !is_valid_id($_GET['comment']) ){
print( ajaxinco );
die();
}
// get comment details
$details_res = mysql_query("SELECT `user`, `text` FROM `comments` WHERE `id` = '".$_GET['comment']."' LIMIT 1") or sqlerr(__FILE__,__LINE__);
$details = mysql_fetch_assoc( $details_res );
// check owner
if( get_user_class() < UC_MODERATOR || $CURUSER['id'] != $details['user'] ){
print(ajaxinpe);
die();
}
print("<textarea rows=\"8\" cols=\"25\" onblur=\"if(confirm('Save changes?')==true){sndReq('action=save_torrent_comment&comment=".$_GET['comment']."&text='+escape(this.value), 'comment_".$_GET['comment']."')}\">".$details['text']."</textarea>");
} elseif( $a == 'save_torrent_comment' ){
//check valid comment
if( !isset( $_GET['comment'] ) || !is_numeric( $_GET['comment'] ) || !is_valid_id($_GET['comment']) ){
print( ajaxinco );
die();
}
// get comment details
$details_res = mysql_query("SELECT `user` FROM `comments` WHERE `id` = '".$_GET['comment']."' LIMIT 1") or sqlerr(__FILE__,__LINE__);
$details = mysql_fetch_assoc( $details_res );
// check owner
if( get_user_class() < UC_MODERATOR || $CURUSER['id'] != $details['user'] ){
print(ajaxinpe);
die();
}
// make sure not blank
if( !isset( $_GET['text'] ) || empty( $_GET['text'] ) ){
print(ajaxbody);
die();
}
// save changes
$editedat = get_date_time();
$save_res = mysql_query("UPDATE `comments` SET `text` = '".$_GET['text']."', `editedby` = '".$CURUSER['id']."', `editedat` = '".$editedat."' WHERE `id` = '".$_GET['comment']."' LIMIT 1");
// print out the comment
print( nl2br( stripslashes( $_GET['text'] ) ) );
// don't forget the edited msg!
print( "<p><font size=1 class=small>Last edited by <a href=userdetails.php?id=".$arr['editedby']."><b>".id_to_name( $CURUSER['id'] )."</b></a> at ".$editedat." GMT</font></p>\n" );
} elseif( $a == 'delete_torrent_comment' ){
$postid = $_GET["postid"];
if (get_user_class() < UC_MODERATOR || !is_valid_id($postid)){
print( ajaxinop );
die;
}
//------- Delete comment
mysql_query("DELETE FROM `comments` WHERE id=$postid") or sqlerr(__FILE__, __LINE__);
} elseif( $a == 'member_search' ){
if( !isset( $_GET['search'] ) || empty( $_GET['search'] ) ){
print(ajaxemp);
die();
}
$search = trim($_GET['search']);
$class = $_GET['class'];
if ($class == '-' || !is_valid_id($class)){
$class = '';
}
if ( isset( $_GET['search'] ) && !empty( $_GET['search'] ) ){
$query = "username LIKE " . sqlesc("%$search%") . " AND status='confirmed'";
if ($search){
$q = "search=" . htmlspecialchars($search);
}
} else{
$letter = trim($_GET["letter"]);
if (strlen($letter) > 1){
die;
}
if ($letter == "" || strpos("abcdefghijklmnopqrstuvwxyz", $letter) === false){
$letter = "a";
}
$query = "username LIKE '$letter%' AND status='confirmed'";
$q = "letter=$letter";
}
if ($class){
$query .= " AND class=$class";
$q .= ($q ? "&amp;" : "") . "class=$class";
}
print("<p>\n");
for ($i = 97; $i < 123; ++$i){
$l = chr($i);
$L = chr($i - 32);
if ($l == $letter){
print("<b>$L</b>\n");
} else{
print("<a href=?letter=$l><b>$L</b></a>\n");
}
}
print("</p>\n");
$page = $_GET['page'];
$perpage = 100;
$res = mysql_query("SELECT COUNT(*) FROM users WHERE $query") or sqlerr();
$arr = mysql_fetch_row($res);
$pages = floor($arr[0] / $perpage);
if ($pages * $perpage < $arr[0]){
++$pages;
}
if ($page < 1){
$page = 1;
} else{
if ($page > $pages){
$page = $pages;
}
}
for ($i = 1; $i <= $pages; ++$i){
if ($i == $page){
$pagemenu .= "<b>$i</b>\n";
} else{
$pagemenu .= "<a href=?$q&page=$i><b>$i</b></a>\n";
}
}
if ($page == 1){
$browsemenu .= "<b>&lt;&lt; Prev</b>";
} else{
$browsemenu .= "<a href=?$q&page=" . ($page - 1) . "><b>&lt;&lt; Prev</b></a>";
}
$browsemenu .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
if ($page == $pages){
$browsemenu .= "<b>Next &gt;&gt;</b>";
} else{
$browsemenu .= "<a href=?$q&page=" . ($page + 1) . "><b>Next &gt;&gt;</b></a>";
}
print("<p>$browsemenu<br>$pagemenu</p>");
$offset = ($page * $perpage) - $perpage;
$res = mysql_query("SELECT * FROM users WHERE $query ORDER BY username LIMIT $offset,$perpage") or sqlerr();
$num = mysql_num_rows($res);
print("<table border=1 cellspacing=0 cellpadding=5>\n");
print("<tr><td class=colhead align=left>".ajaxuname."</td><td class=colhead>".ajaxreg."</td><td class=colhead>".ajaxlast."</td><td class=colhead align=left>".ajaxclass."</td><td class=colhead>".ajaxco."</td></tr>\n");
for ($i = 0; $i < $num; ++$i){
$arr = mysql_fetch_assoc($res);
if ($arr['country'] > 0){
$cres = mysql_query("SELECT name,flagpic FROM countries WHERE id=$arr[country]");
if (mysql_num_rows($cres) == 1){
$carr = mysql_fetch_assoc($cres);
$country = "<td style='padding: 0px' align=center><img src=/pic/flag/$carr[flagpic] alt=\"$carr[name]\"></td>";
}
} else{
$country = "<td align=center>---</td>";
}
if ($arr['added'] == '0000-00-00 00:00:00'){
$arr['added'] = '-';
}
if ($arr['last_access'] == '0000-00-00 00:00:00'){
$arr['last_access'] = '-';
}
print("<tr><td align=left><a href=userdetails.php?id=$arr[id]><b>$arr[username]</b></a>" .($arr["donated"] > 0 ? "<img src=/pic/star.gif border=0 alt='Donor'>" : "")."</td>" .
"<td>$arr[added]</td><td>$arr[last_access]</td>".
"<td align=left>" . get_user_class_name($arr["class"]) . "</td>$country</tr>\n");
}
print("</table>\n");
} else{
print( ajaxinr );
}
?>