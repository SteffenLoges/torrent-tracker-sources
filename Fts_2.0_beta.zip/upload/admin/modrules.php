<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
loggedinorreturn();
if ($CURUSER["class"] < 5) // only for admin and higher
die;

if ($_GET["action"] == "newsect")
{
stdhead("Add section");
//print("<td valign=top style=\"padding: 10px;\" colspan=2 align=center>");
begin_main_frame();

print("<form method=\"post\" action=\"admin.php?act=modrules&action=addsect\">");
print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\" align=\"center\">\n");
print("<tr><td>Title:</td><td><input style=\"width: 400px;\" type=\"text\" name=\"title\"/></td></tr>\n");
print("<tr><td style=\"vertical-align: top;\">Rules:</td><td><textarea cols=90 rows=20 name=\"text\"></textarea></td></tr>\n");

print("<tr><td colspan=\"2\" align=\"center\"><input type=\"radio\" name='public' value=\"yes\" checked>For everybody<input type=\"radio\" name='public' value=\"no\">Registered only (Class: <input type=\"text\" name='class' value=\"0\" size=1>)</td></tr>\n");
print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"Add\" style=\"width: 60px;\"></td></tr>\n");
print("</table></form>");
stdfoot();
}
elseif ($_GET["action"]=="addsect"){
$title = sqlesc($_POST["title"]);
$text = sqlesc($_POST["text"]);
$public = sqlesc($_POST["public"]);
$class = sqlesc($_POST["class"]);
mysql_query("insert into rules (title, text, public, class) values($title, $text, $public, $class)") or sqlerr(__FILE__,__LINE__);
header("Refresh: 0; url=admin.php?act=modrules");
}
elseif ($_GET["action"] == "edit"){
$id = $_POST["id"];
$res = @mysql_fetch_array(@mysql_query("select * from rules where id='$id'"));
stdhead("Edit rules");
//print("<td valign=top style=\"padding: 10px;\" colspan=2 align=center>");
begin_main_frame();

print("<form method=\"post\" action=\"admin.php?act=modrules&action=edited\">");
print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\" align=\"center\">\n");
print("<tr><td>Title:</td><td><input style=\"width: 400px;\" type=\"text\" name=\"title\" value=\"$res[title]\" /></td></tr>\n");
print("<tr><td style=\"vertical-align: top;\">Rules:</td><td><textarea cols=90 rows=20 name=\"text\">$res[text]</textarea></td></tr>\n");

print("<tr><td colspan=\"2\" align=\"center\"><input type=\"radio\" name='public' value=\"yes\" ".($res["public"]=="yes"?"checked":"").">For everybody<input type=\"radio\" name='public' value=\"no\" ".($res["public"]=="no"?"checked":"").">Registered only (Class: <input type=\"text\" name='class' value=\"$res[class]\" size=1>)</td></tr>\n");
print("<tr><td colspan=\"2\" align=\"center\"><input type=hidden value=$res[id] name=id><input type=\"submit\" value=\"Save\" style=\"width: 60px;\"></td></tr>\n");
print("</table>");
stdfoot();
}
elseif ($_GET["action"]=="edited"){
$id = $_POST["id"];
$title = sqlesc($_POST["title"]);
$text = sqlesc($_POST["text"]);
$public = sqlesc($_POST["public"]);
$class = sqlesc($_POST["class"]);
mysql_query("update rules set title=$title, text=$text, public=$public, class=$class where id=$id") or sqlerr(__FILE__,__LINE__);
header("Refresh: 0; url=admin.php?act=modrules");
}
else{
$res = mysql_query("select * from rules order by id");
stdhead();
//print("<td valign=top style=\"padding: 10px;\" colspan=2 align=center>");
print("<br><table width=100% border=1 cellspacing=0 cellpadding=10>");
print("<tr><td align=center><a href=admin.php?act=modrules&action=newsect>Add Section</a></td></tr></table>\n");
while ($arr=mysql_fetch_assoc($res)){
print("<br><table width=100% border=1 cellspacing=0 cellpadding=10>");
print("<form method=post action=admin.php?act=modrules&action=edit&id=><tr><td class=colhead>:: $arr[title]</td></tr><tr><td><ul>\n");
print(format_comment($arr["text"]));
print("</td></tr><tr><td><input type=hidden value=$arr[id] name=id><input type=submit value='Edit'></td></tr></form>");
end_frame();
}
//print("");
stdfoot();
}
?>