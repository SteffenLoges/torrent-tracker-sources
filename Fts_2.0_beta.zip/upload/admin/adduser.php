<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
loggedinorreturn();
if (get_user_class() < UC_ADMINISTRATOR)
        stderr("Error", "Access denied.");


if ($_SERVER["REQUEST_METHOD"] == "POST")
{
        if ($_POST["username"] == "" || $_POST["password"] == "" || $_POST["email"] == "")
                stderr("Error", "Missing form data.");
        if ($_POST["password"] != $_POST["password2"])
                stderr("Error", "Passwords mismatch.");
        if (!validemail($_POST['email']))
                stderr("Error", "Not valid email");

        $username = sqlesc($_POST["username"]);
        $password = $_POST["password"];
        $email = sqlesc($_POST["email"]);
        $secret = mksecret();
        $passhash = sqlesc(md5($secret . $password . $secret));
        $secret = sqlesc($secret);

        mysql_query("INSERT INTO users (added, last_access, secret, username, passhash, status, email) VALUES(NOW(), NOW(), $secret, $username, $passhash, 'confirmed', $email)") or sqlerr(__FILE__, __LINE__);
        $res = mysql_query("SELECT id FROM users WHERE username=$username");
        $arr = mysql_fetch_row($res);
        if (!$arr)
                stderr("Error", "Unable to create the account. The user name is possibly already taken.");
        header("Location: $BASEURL/userdetails.php?id=$arr[0]");
        die;
}
stdhead("Add user");
?>
<h1>Add user</h1>
<br />
<form method=post action=admin.php?act=adduser>
<table id="torrenttable" border=1 cellspacing=0 cellpadding=5>
<tr><td>User name</td><td><input type=text name=username size=40></td></tr>
<tr><td>Password</td><td><input type=password name=password size=40></td></tr>
<tr><td>Re-type password</td><td><input type=password name=password2 size=40></td></tr>
<tr><td>E-mail</td><td><input type=text name=email size=40></td></tr>
<tr><td colspan=2 align=center><input type=submit value="Okay"></td></tr>
</table>
</form>
<? stdfoot(); ?>