<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
  loggedinorreturn();

if (get_user_class() < UC_MODERATOR)
stderr("Unauthorized", "Only staff can view the leechers list....");

  function usertable($res, $frame_caption)
  {
      global $CURUSER;
    begin_frame($frame_caption, true);
    begin_table();
?>

<p>A list of users with a ratio under 0.40 that have downloaded over 1GB.<br>
Sorted by join date (oldest first).</p>
<tr>
<td class=colhead align=left>User</td>
<td class=colhead>Uploaded</td>
<td class=colhead>Downloaded</td>
<td class=colhead align=right>Ratio</td>
<td class=colhead align=left>Joined</td>
</tr>
<?
    $num = 0;
    while ($a = mysql_fetch_assoc($res))
    {
      ++$num;
      $highlight = $CURUSER["id"] == $a["userid"] ? " bgcolor=#BBAF9B" : "";
      if ($a["downloaded"])
      {
        $ratio = $a["uploaded"] / $a["downloaded"];
        $color = get_ratio_color($ratio);
        $ratio = number_format($ratio, 2);
        if ($color)
          $ratio = "<font color=$color>$ratio</font>";
      }
      else
        $ratio = "Inf.";
      print("<tr$highlight><td align=left$highlight><a href=userdetails.php?id=" .
              $a["userid"] . "><b>" . $a["username"] . "</b>" .
              "</td><td align=right$highlight>" . mksize($a["uploaded"]) .
            "</td><td align=right$highlight>" . mksize($a["downloaded"]) .
              "</td><td align=right$highlight>" . $ratio .
              "</td><td align=left>" . gmdate("Y-m-d",strtotime($a["added"])) . " (" .
              get_elapsed_time(sql_timestamp_to_unix_timestamp($a["added"])) . " ago)</td></tr>");
    }
    end_table();
    end_frame();
  }

  stdhead("Ratio Under 0.40/1GB+ Downloaded");

    $mainquery = "SELECT id as userid, username, added, uploaded, downloaded, uploaded / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS upspeed, downloaded / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS downspeed FROM users WHERE enabled = 'yes'";

          $limit = 250;
        $order = "added ASC";
        //$order = "uploaded / downloaded ASC, downloaded DESC";
          $extrawhere = " AND uploaded / downloaded < 0.40 AND downloaded > 1073741824";
          $r = mysql_query($mainquery . $extrawhere . " ORDER BY $order " . " LIMIT $limit") or sqlerr();
          usertable($r, "Ratio Under 0.40/1GB+ Downloaded");

stdfoot();

?>