<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
loggedinorreturn();
stdhead("Unconfirmed Users");
begin_main_frame();
begin_frame("");
?>
<?
if (get_user_class() < UC_ADMINISTRATOR)
 die;
$a = $_GET['a'];
if($a == 'del') {
$uid = $_GET['userid'];
$mr = mysql_query("UPDATE users SET status='$confirm' WHERE id='$uid'");
print("User(s) confirmed");
}
$res = mysql_query("SELECT * FROM users WHERE status='pending' ORDER BY username" ) or sqlerr();
if( mysql_num_rows($res) != 0 )
{
print'<br><table width=100% border=1 cellspacing=0 cellpadding=5>';
print'<tr>';
print'<td class=rowhead>Name</td>';
print'<td class=rowhead>Email</td>';
print'<td class=rowhead>Aangemaakt Op</td>';
print'<td class=rowhead>Activeren</td>';
print'<td class=rowhead>OK</td>';
print'</tr>';
while( $row = mysql_fetch_assoc($res) )
{
$id = $row['id'];
print'<tr><form method=get action='.$_SERVER["php_self"].'>';
print("<input type=hidden name='act' value='uncon'>");
print("<input type=hidden name='a' value='del'>");
print'<input type=hidden name=\'action\' value=\'confirmuser\'>';
print("<input type=hidden name='userid' value='$id'>");
 print'<a href="userdetails.php?id=' . $row['id'] . '"><td>' . $row['username'] . '</td></a>';
 print'<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;' . $row['email'] . '</td>';
 print'<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;' . $row['added'] . '</td>';
 print'<td align=left><select name=confirm><option value=pending>pending</option><option value=confirmed>confirmed</option></select></td>';
 print'<td align=left><input type=submit value="OK" style=\'height: 20px; width: 40px\'>';
 print'</form></tr>';
}
print '</table>';
}

?>
<? end_frame();?>
<? end_frame();
end_main_frame();
stdfoot();
?>