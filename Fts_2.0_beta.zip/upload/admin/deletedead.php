<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
dbconn(false);
loggedinorreturn();

stdhead("Delete all Dead Torrents");

if (get_user_class() < UC_ADMINISTRATOR){
        print("Access Denied!");
        exit;
}

if($_GET['ja'] == 1){
mysql_query("DELETE FROM torrents WHERE visible='no'") or sqlerr(__FILE__, __LINE__);
echo "All Dead Torrents have been deleted!";
}
else{
echo "Are you sure to delete all dead torrents? <br><br><a href= 'admin.php?act=deletedead&ja=1'>Yes</a>";
}

stdfoot();

?>