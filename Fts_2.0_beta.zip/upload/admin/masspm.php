<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
loggedinorreturn();
if (get_user_class() < UC_MODERATOR)
stderr("Error", "Access denied.");
stdhead("Mass PM");
if ($_POST['message'] != "")
{
$num=0;
foreach( array_keys($_POST) as $x)
{
 if (substr($x,0,3) == "UC_"){
  $querystring .= " OR class = ".constant($x);
  $classnames .= substr($x,3).", ";
  $num++;
 }
}

if ($num == $_POST["numclasses"]){
 $res = mysql_query("SELECT id FROM users");
 $msg = $_POST['message']  . "\n\nNOTICE: This is a mass pm, it has been sent to everyone";
}else{
 $res = mysql_query("SELECT id FROM users where id = 1".$querystring) or sqlerr(__FILE__, __LINE__);
 $msg = $_POST['message']  . "\n\nNOTICE: This is a mass pm, it has been sent to the following classes: " . substr($classnames,0,(strlen($classnames)-2));
}

if ($_POST["fromsystem"] == "yes"){ $sender_id="0";}else{$sender_id = $CURUSER["id"];}

while($arr = mysql_fetch_row($res))
{
 mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES ($sender_id, $arr[0], '" . get_date_time() . "', " . sqlesc($msg) . ", $sender_id)") or sqlerr(__FILE__, __LINE__);
}

print("<b>Mass Private Message Dispatched.</b><br>");
}


?>
<h1>Mass PM</h1>
<form method=post action="admin.php?act=masspm">
<table border=1 cellspacing=0 cellpadding=5 class="main" >
<tr><td colspan=2 class="rowhead"><div align=left>Send To (check all that apply):</div></td></tr>
<tr><td colspan=2>
<?
$numclasses=0;
$constants = get_defined_constants ();
foreach( array_keys($constants) as $x)
{
if (substr($x,0,3) == "UC_"){
 echo "<input name=\"".$x."\" type=\"checkbox\" value=1 checked>".substr($x,3)."<br>";
 $numclasses++;
}
}
?>
<input type="hidden" name="numclasses" value="<? echo $numclasses; ?>" />
</td></tr>
<tr><td class="rowhead">Message</td><td><textarea cols=60 rows=6 name="message"></textarea></td></tr>
<tr><td class="rowhead">System</td><td><input type="checkbox" name="fromsystem" value="yes" />Say the message was sent by 'system'</td>
<tr><td align="center" colspan=2><input type="submit" value="Okay" class="btn" /></td></tr>
</table>
</form>
<? stdfoot(); ?>