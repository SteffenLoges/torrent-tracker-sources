<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
if (get_user_class() < UC_SYSOP)
stderr("Error", "Permission denied.");

if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
 $username = trim($_POST["username"]);

if (!$username)
   stderr("Error", "Please fill out the form correctly.");

 $res = mysql_query(

 "SELECT * FROM users WHERE username=" . sqlesc($username)   ) or sqlerr();
 if (mysql_num_rows($res) != 1)
   stderr("Error", "Bad user name or password. Please verify that all entered information is correct.");
 $arr = mysql_fetch_assoc($res);

 $id = $arr['id'];
 $res = mysql_query("DELETE FROM users WHERE id=$id") or sqlerr();
 if (mysql_affected_rows() != 1)
   stderr("Error", "Unable to delete the account.");
 stderr("Success", "The account <b>$username</b> was deleted.");
}
stdhead("Delete account");
?>
<h1>Delete account</h1>
<table border=1 cellspacing=0 cellpadding=5>
<form method=post action=admin.php?act=delacctadmin>
<tr><td class=rowhead>User name</td><td><input size=40 name=username></td></tr>

<tr><td colspan=2><input type=submit class=btn value='Delete'></td></tr>
</form>
</table>
<?
stdfoot();
?>
