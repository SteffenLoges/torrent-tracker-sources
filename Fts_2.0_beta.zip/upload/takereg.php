<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: takereg.php - Invite System.                                     |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

hit_start();

dbconn();

$inviter = 0 + $_GET["inviter"];
$code = unesc($_POST["hash"]);
$ip = getip();


$res = mysql_query("SELECT username FROM users WHERE id = $inviter") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_assoc($res);
$invusername = $arr[username];

if (!mkglobal("wantusername:wantpassword:passagain:email"))
	die();

function bark($msg) {
  stdhead();
	stdmsg("Signup failed!", $msg);
  stdfoot();
  exit;
}

function validusername($username)
{
	if ($username == "")
	  return false;

	// The following characters are allowed in user names
	$allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	for ($i = 0; $i < strlen($username); ++$i)
	  if (strpos($allowedchars, $username[$i]) === false)
	    return false;

	return true;
}

function isportopen($port)
{
	global $HTTP_SERVER_VARS;
	$sd = @fsockopen($HTTP_SERVER_VARS["REMOTE_ADDR"], $port, $errno, $errstr, 1);
	if ($sd)
	{
		fclose($sd);
		return true;
	}
	else
		return false;
}
/*
function isproxy()
{
	$ports = array(80, 88, 1075, 1080, 1180, 1182, 2282, 3128, 3332, 5490, 6588, 7033, 7441, 8000, 8080, 8085, 8090, 8095, 8100, 8105, 8110, 8888, 22788);
	for ($i = 0; $i < count($ports); ++$i)
		if (isportopen($ports[$i])) return true;
	return false;
}
*/
$country = $_POST["country"]; 

if (empty($wantusername) || empty($wantpassword) || empty($email) || empty($country))
    bark("You Forgot To Enter A Required Field.");

if (strlen($wantusername) > 12)
	bark("Sorry, username is too long (max is 12 chars)");

if ($wantpassword != $passagain)
	bark("The passwords didn't match! Try again.");

if (strlen($wantpassword) < 6)
	bark("Sorry, password is too short (min is 6 chars)");

if (strlen($wantpassword) > 40)
	bark("Sorry, password is too long (max is 40 chars)");

if ($wantpassword == $wantusername)
	bark("Sorry, password cannot be same as user name.");

if (!validemail($email))
	bark("That doesn't look like a valid email address.");

if (!validusername($wantusername))
	bark("Invalid username.");

// make sure user agrees to everything...
if ($HTTP_POST_VARS["rulesverify"] != "yes" || $HTTP_POST_VARS["faqverify"] != "yes" || $HTTP_POST_VARS["ageverify"] != "yes")
	stderr("Signup failed", "Sorry, you're not qualified to become a member of this site.");

// check if email addy is already in use
$a = (@mysql_fetch_row(@mysql_query("select count(*) from users where email='$email'"))) or die(mysql_error());
if ($a[0] != 0)
  bark("The e-mail address $email is already in use.");

/*
// do simple proxy check
if (isproxy())
	bark("You appear to be connecting through a proxy server. Your organization or ISP may use a transparent caching HTTP proxy. Please try and access the site on <a href=http://torrentbits.org:81/signup.php>port 81</a> (this should bypass the proxy server). <p><b>Note:</b> if you run an Internet-accessible web server on the local machine you need to shut it down until the sign-up is complete.");
*/
hit_count();

$secret = mksecret();
$wantpasshash = md5($secret . $wantpassword . $secret);
$editsecret = mksecret();

$ret = mysql_query("INSERT INTO users (username, passhash, secret, editsecret, email, country, status, added, invites, invited_by) VALUES (" .
		implode(",", array_map("sqlesc", array($wantusername, $wantpasshash, $secret, $editsecret, $email, $country, 'pending'))) .
		",'" . get_date_time() . "', '0', $inviter)");

if (!$ret) {
	if (mysql_errno() == 1062)
		bark("Username already exists!");
	bark("Database In Distress");
}

$id = mysql_insert_id();

write_log("User account $id ($wantusername) was created. Invited by $invusername");

$msg = sqlesc("Welcome To YOUR_SITE_HERE, $wantusername.\nBefore you start downloading, please take a moment to read this:\n\n- <a href=faq.php TARGET=_blank>FAQ's</a>\n- <a href=rules.php TARGET=_blank>Rules</a>\n\n" .
              "This site works with share ratio's. This is your uploaded/downloaded amount. Every user starts with a 1.00 ratio and we expect from you\n" .
			  "that you try to keep it like that. If you violate this too much, you'll recieve a warning. After 3 warnings it's set, and you'll get banned from\n" .
			  "the server. So please try to keep a 0.50-1.00 ratio or higher. Also try to seed your torrent as long as possible, so our great community can enjoy\n" .
			  "the same vid's you enjoy.You can also upload and seed your own torrents.\n" .
			  "For requests we have our own request section. You can request anything you want, but check if noone has requested it before you by using\n" .
			  "the search function. Our forum needs seperate registration, so if you want to be part of our forum community, you have to register for that seperatly.\n\n" .
			  "If you have questions after this short intro, PM one of the staff members or post in the forum.\n\nI wish you a good time on YOUR_SITE_HERE and keep sharing!\n\nThe YOUR_SITE_HERE Staff.");
@mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $id, '" . get_date_time() . "', $msg, 0)") or sqlerr(__FILE__, __LINE__);

$psecret = md5($editsecret);

$body = <<<EOD
You have requested a new user account on YOUR_SITE_HERE and you have
specified this address ($email) as user contact.

Your account is awaiting confirmation from your inviter.
As long as your account isn't confirmed, you can't login to the site.

Account info:
Username: $wantusername
Password: $wantpassword

If your account isn't being confirmed within 24 hrs, your account will be deleted.
Please read the RULES and FAQ before you start using $SITENAME.
----------------
If you did not register for F1 Racing World, please forward this email to admin@YOUR_SITE_HERE
EOD;
mail($email, "$SITENAME Registration Confirmation", $body, "From: $SITEEMAIL");

mysql_query("DELETE FROM invites WHERE hash = '$code'");

header("Refresh: 0; url=ok.php?type=signup&email=" . urlencode($email));

hit_end();
  
?>
