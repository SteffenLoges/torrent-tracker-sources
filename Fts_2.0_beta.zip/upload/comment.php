<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: comment.php - Comment Processer                                  |
// | Version: 1.2                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");


$action = $_GET["action"];

dbconn(false);


loggedinorreturn();
parked();

if ($action == "add")
{
  if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
    $torrentid = 0 + $_POST["tid"];
          if (!is_valid_id($torrentid))
                        stderr(comerr, com1);

                $res = mysql_query("SELECT name, owner FROM torrents WHERE id = $torrentid") or sqlerr(__FILE__,__LINE__);
                $arr = mysql_fetch_array($res);
                if (!$arr)
                  stderr(comerr, com2);

          $text = trim($_POST["text"]);
          if (!$text)
                        stderr(comerr, com3);

          mysql_query("INSERT INTO comments (user, torrent, added, text, ori_text) VALUES (" .
              $CURUSER["id"] . ",$torrentid, '" . get_date_time() . "', " . sqlesc($text) .
               "," . sqlesc($text) . ")");

          $newid = mysql_insert_id();

          mysql_query("UPDATE torrents SET comments = comments + 1 WHERE id = $torrentid");
//===add karma
mysql_query("UPDATE users SET seedbonus = seedbonus+3.0 WHERE id = $CURUSER[id]") or sqlerr(__FILE__, __LINE__);
//===end
$ras = mysql_query("SELECT commentpm FROM users WHERE id = $arr[owner]") or sqlerr(__FILE__,__LINE__);
                 $arg = mysql_fetch_array($ras);

                 if($arg['commentpm'] == 'yes')
                    {
$added = sqlesc(get_date_time());
$subby = sqlesc(com4);
$notifs = sqlesc(com5."[url=details.php?id=$torrentid] " . $arr['name'] . "[/url].");
mysql_query("INSERT INTO messages (sender, receiver, msg, added) VALUES(0, " . $arr['owner'] . ", $notifs, $added)") or sqlerr(__FILE__, __LINE__);
                     }  

          header("Refresh: 0; url=details.php?id=$torrentid&viewcomm=$newid#comm$newid");
          die;
        }

  $torrentid = 0 + $_GET["tid"];
  if (!is_valid_id($torrentid))
                stderr(comerr, com6);

        $res = mysql_query("SELECT name FROM torrents WHERE id = $torrentid") or sqlerr(__FILE__,__LINE__);
        $arr = mysql_fetch_array($res);
        if (!$arr)
          stderr(comerr, com7);

        stdhead(com8." \"" . $arr["name"] . "\"");
?>
<!-- tinyMCE -->
<!-- TinyMCE -->
<script language="javascript" type="text/javascript" src="../jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		theme : "advanced",
		mode : "exact",
		elements : "text",
		plugins : "devkit,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,|,code",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom",
		content_css : "example_full.css",
	    plugin_insertdate_dateFormat : "%Y-%m-%d",
	    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "example_link_list.js",
		external_image_list_url : "example_image_list.js",
		flash_external_list_url : "example_flash_list.js",
		media_external_list_url : "example_media_list.js",
		template_external_list_url : "example_template_list.js",
		file_browser_callback : "fileBrowserCallBack",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true,
		nonbreaking_force_tab : true,
		apply_source_formatting : true,
		template_replace_values : {
			username : "Jack Black",
			staffid : "991234"
		}
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert("Example of filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = "someurl.htm";
	}
</script>
<!-- /TinyMCE -->

<?
        print("<h1>".com9."\"" . htmlspecialchars($arr["name"]) . "\"</h1>\n");
        print("<p><form method=\"post\" action=\"comment.php?action=add\">\n");
        print("<input type=\"hidden\" name=\"tid\" value=\"$torrentid\"/>\n");
        print("<textarea name=\"text\" rows=\"30\" cols=\"160\"></textarea></p>\n");
        print("<p><input type=\"submit\" class=btn value=\"".com10."\" /></p></form>\n");

        $res = mysql_query("SELECT comments.id, text, comments.added, username, users.id as user, users.avatar FROM comments LEFT JOIN users ON comments.user = users.id WHERE torrent = $torrentid ORDER BY comments.id DESC LIMIT 5");

        $allrows = array();
        while ($row = mysql_fetch_array($res))
          $allrows[] = $row;

        if (count($allrows)) {
          print("<h2>".com11."</h2>\n");
          commenttable($allrows);
        }

  stdfoot();
        die;
}
elseif ($action == "edit")
{
  $commentid = 0 + $_GET["cid"];
  if (!is_valid_id($commentid))
                stderr(comerr, com1);

  $res = mysql_query("SELECT c.*, t.name FROM comments AS c LEFT JOIN torrents AS t ON c.torrent = t.id WHERE c.id=$commentid") or sqlerr(__FILE__,__LINE__);
  $arr = mysql_fetch_array($res);
  if (!$arr)
          stderr(comerr, com1);

        if ($arr["user"] != $CURUSER["id"] && get_user_class() < UC_MODERATOR)
                stderr(comerr, com12);

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
          $text = $_POST["text"];
    $returnto = $_POST["returnto"];

          if ($text == "")
                  stderr(comerr,com13);

          $text = sqlesc($text);

          $editedat = sqlesc(get_date_time());

          mysql_query("UPDATE comments SET text=$text, editedat=$editedat, editedby=$CURUSER[id] WHERE id=$commentid") or sqlerr(__FILE__, __LINE__);

                if ($returnto)
                  header("Location: $returnto");
                else
                  header("Location: $BASEURL/");      // change later ----------------------
                die;
        }

         stdhead(com14." \"" . $arr["name"] . "\"");

        print("<h1>".com14." \"" . htmlspecialchars($arr["name"]) . "\"</h1><p>\n");
        print("<form method=\"post\" action=\"comment.php?action=edit&amp;cid=$commentid\">\n");
        print("<input type=\"hidden\" name=\"returnto\" value=\"" . $_SERVER["HTTP_REFERER"] . "\" />\n");
        print("<input type=\"hidden\" name=\"cid\" value=\"$commentid\" />\n");
        print("<textarea name=\"text\" rows=\"10\" cols=\"60\">" . htmlspecialchars($arr["text"]) . "</textarea></p>\n");
        print("<p><input type=\"submit\" class=btn value=\"Do it!\" /></p></form>\n");

        stdfoot();
        die;
}
elseif ($action == "delete")
{
        if (get_user_class() < UC_MODERATOR)
                stderr(comerr, com12);

  $commentid = 0 + $_GET["cid"];

  if (!is_valid_id($commentid))
                stderr(comerr, com6);

  $sure = $_GET["sure"];

  if (!$sure)
  {
                 $referer = $_SERVER["HTTP_REFERER"];
                stderr(com15, com16 .
                        "<a href=?action=delete&cid=$commentid&sure=1" .
                        ($referer ? "&returnto=" . urlencode($referer) : "") .
                        ">".com17);
  }


        $res = mysql_query("SELECT torrent FROM comments WHERE id=$commentid")  or sqlerr(__FILE__,__LINE__);
        $arr = mysql_fetch_array($res);
        if ($arr)
                $torrentid = $arr["torrent"];

        mysql_query("DELETE FROM comments WHERE id=$commentid") or sqlerr(__FILE__,__LINE__);
        if ($torrentid && mysql_affected_rows() > 0)
                mysql_query("UPDATE torrents SET comments = comments - 1 WHERE id = $torrentid");


        $returnto = $_GET["returnto"];

        if ($returnto)
          header("Location: $returnto");
        else
          header("Location: $BASEURL/");      // change later ----------------------
        die;
}
elseif ($action == "vieworiginal")
{
        if (get_user_class() < UC_MODERATOR)
                stderr(comerr, com12);

  $commentid = 0 + $_GET["cid"];

  if (!is_valid_id($commentid))
                stderr(comerr, com6);

  $res = mysql_query("SELECT c.*, t.name FROM comments AS c LEFT JOIN torrents AS t ON c.torrent = t.id WHERE c.id=$commentid") or sqlerr(__FILE__,__LINE__);
  $arr = mysql_fetch_array($res);
  if (!$arr)
          stderr(comerr, com6 . " $commentid.");

  stdhead(com18);
  print("<h1>".com19."$commentid</h1><p>\n");
        print("<table width=500 border=1 cellspacing=0 cellpadding=5>");
  print("<tr><td class=comment>\n");
        echo htmlspecialchars($arr["ori_text"]);
  print("</td></tr></table>\n");

  $returnto = $_SERVER["HTTP_REFERER"];

//        $returnto = "details.php?id=$torrentid&amp;viewcomm=$commentid#$commentid";

        if ($returnto)
                 print("<p><font size=small>(<a href=$returnto>".com20."</a>)</font></p>\n");

        stdfoot();
        die;
}
else
        stderr(comerr, com21."$action");

die;
?>