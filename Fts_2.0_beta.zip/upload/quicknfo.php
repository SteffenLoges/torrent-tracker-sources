<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: quicknfo.php - View NFO in a hurry.                              |
// | Version: 1.0                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();
$id = 0 + $_GET["id"];
if (get_user_class() < UC_POWER_USER || !is_valid_id($id))
  die;
?>
<style>.success {
	color: #000000;
	background: #F5FBE1;
	padding: 7px;
	margin-top: 5px;
	margin-bottom: 5px;
	border: 1px dashed #7BA813; }
	.error {
	color: #990000;
	background-color: #FFF0F0;
	padding: 7px;
	margin-top: 5px;
	margin-bottom: 10px;
	border: 1px dashed #990000;
}</style>
<body class="error">
<?
$r = mysql_query("SELECT name,nfo FROM torrents WHERE id=$id") or sqlerr();
$a = mysql_fetch_assoc($r) or die("Puke");
$nfo = htmlspecialchars($a["nfo"]);

print("<b><p class=success>NFO for <a href=details.php?id=$id>$a[name]</a></p></b>\n");
print("\n");
print("<pre><p class=success><font face='MS Linedraw' size=2 style='font-size: 10pt; line-height: 10pt'>" . format_urls($nfo) . "</font></p></pre>\n");print("\n");
print("<p align=center class=success>For best visual result, install the " .
  "<a href=http://$_SERVER[HTTP_HOST]/misc/linedraw.ttf>MS Linedraw</a> font!</p>\n");

?></body>