<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: rules.php - View all tracker's rules.                            |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
ob_start("ob_gzhandler");
require "include/bittorrent.php";
dbconn();
stdhead("Rules");
//print("<td valign=top style=\"padding: 10px;\" colspan=2 align=center>");
begin_main_frame();
?>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>
<b>Welcome to <?=$SITENAME?>!</b><br><br>
Read this rules carefully, and you wont get banned/disabled.<br>
</td></tr></table>
<? $res = mysql_query("select * from rules order by id");
while ($arr=mysql_fetch_assoc($res)){
if ($arr["public"]=="yes"){
print("<br><table width=100% border=1 cellspacing=0 cellpadding=10>");
print("<tr><td class=colhead>:: $arr[title]</td></tr><tr><td><ul>\n");
print(format_comment($arr["text"]));
print("</td></tr>");
end_frame(); }
elseif($arr["public"]=="no" && $arr["class"]<=$CURUSER["class"]){
print("<br><table width=100% border=1 cellspacing=0 cellpadding=10>");
print("<tr><td class=colhead>:: $arr[title]</td></tr><tr><td><ul>\n");
print(format_comment($arr["text"]));
print("</td></tr>");
end_frame();
}
}
end_main_frame();
stdfoot(); ?>