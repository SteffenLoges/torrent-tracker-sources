<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: searchlog.php - View site's log.                                 |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";

dbconn();

loggedinorreturn();

stdhead("Search Log Page");


$res = mysql_query("SELECT * FROM sitelog WHERE txt LIKE '%$query%' ORDER BY txt DESC") or sqlerr();
$num = mysql_num_rows($res);

  print("<table border=1 cellspacing=0 cellpadding=5>\n");
  print("<tr><td class=tabletitle align=left>Date</td><td class=tabletitle align=left>Time</td><td class=tabletitle align=left>Event</td></tr>\n");
  while ($arr = mysql_fetch_assoc($res))
  {
$color = 'black';
if (strpos($arr['txt'],'was uploaded by')) $color = "green";
if (strpos($arr['txt'],'was deleted by')) $color = "red";
if (strpos($arr['txt'],'was added to the Request section')) $color = "purple";
if (strpos($arr['txt'],'was edited by')) $color = "blue";
      $date = substr($arr['added'], 0, strpos($arr['added'], " "));
      $time = substr($arr['added'], strpos($arr['added'], " ") + 1);
//   print("<tr><td>$date</td><td>$time</td><td align=left></td></tr>\n");

  print("<tr class=tableb><td>$date</td><td>$time</td><td align=left><font color='".$color."'>".$arr['txt']."</font></td></tr>\n");
  }
  print("</table>");

stdfoot();

die;

?>