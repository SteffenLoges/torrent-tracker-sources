<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: subscribe.php - Subscribe to a forum.                            |
// | Version: 1.0                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();

function bark($msg) {
stdhead();
stdmsg("Badda-Boom!", $msg);
stdfoot();
exit;
}

if (!isset($_GET[topicid]))
bark ("Failed ... No forum selected");


if ((get_row_count("subscriptions", "WHERE userid=$CURUSER[id] AND topicid = $_GET[topicid]")) > 0)
bark("Already subscribed to $_GET[topicid]");

mysql_query("INSERT INTO subscriptions (userid, topicid) VALUES ($CURUSER[id], $_GET[topicid])") or sqlerr(__FILE__,__LINE__);

$res = mysql_query("SELECT subject FROM `topics` WHERE id=$_GET[topicid]") or sqlerr(__FILE__, __LINE__);

$arr = mysql_fetch_assoc($res) or die("Bad forum id");

$forumname = $arr["subject"];

bark ("Successfully subscribed to thread <b>$forumname</b><br><br>Click <a href=\"java script:history.back(1)\"><b>HERE</b></a> to go back to thread. Or click <a href=subscriptions.php><b>HERE</b></a> to view your subscriptions");

hit_end();

?>