<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: upload.php - Upload torrent                                      |
// | Version: 3.3                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();
parked();
if ($usergroups['canup'] == 'no')
{
  print_ug();
}
stdhead("Upload");


if (strlen($CURUSER['passkey']) != 32) {

$CURUSER['passkey'] = md5($CURUSER['username'].get_date_time().$CURUSER['passhash']);

mysql_query("UPDATE users SET passkey='$CURUSER[passkey]' WHERE id=$CURUSER[id]");

}

?><head>
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <script type="text/javascript" src="scripts/code.js"></script>
    <script type="text/javascript" src="scripts/preloader.js"></script></head>
     <div style="display:none;background:#FFF;text-align:center;border:1px solid #000" id="loading">
Uploading Your Torrent - Please Wait
<BR>        <img alt="prealoder" title="Se incarca" src='pic/8-1.gif'/>       
     </div> 
<script language="javascript" type="text/javascript" src="../jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
tinyMCE.init({
	  theme : "advanced",
    mode: "exact",
elements: "descr",
		plugins : "devkit,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,|,code",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom",
		content_css : "example_full.css",
	    plugin_insertdate_dateFormat : "%Y-%m-%d",
	    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "example_link_list.js",
		external_image_list_url : "example_image_list.js",
		flash_external_list_url : "example_flash_list.js",
		media_external_list_url : "example_media_list.js",
		template_external_list_url : "example_template_list.js",
		file_browser_callback : "fileBrowserCallBack",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true,
		nonbreaking_force_tab : true,
		apply_source_formatting : true,

});
</script>
<div align=Center>

<form name=upload enctype="multipart/form-data" action="takeupload.php" method="post" onsubmit="document.upload.submit.value=' Te rugam asteapta ...';document.upload.submit.disabled=true">
<input type="hidden" name="MAX_FILE_SIZE" value="<?=$max_torrent_size?>" />
<p>If torrent is Multi-tracker/DHT torrent and/or includes other crap, tracker will <b>remove</b> that</p>
<p>Your announce url is <b><?= $announce_urls[0] ?></b></p>
<table border="1" cellspacing="0" cellpadding="5">
<?

tr("Torrent file", "<input type=file name=file size=80>\n", 1);
tr("Torrent name", "<input type=\"text\" name=\"name\" size=\"80\" /><br />(Taken from filename if not specified. <b>Please use descriptive names.</b>)\n", 1);
tr("Torrent Image", "<input type=\"text\" name=\"t_image\" size=\"80\" /><br />(The image of the torrent shown on browse and other pages.)\n", 1);
tr("Small Description", "<input type=\"text\" name=\"description\" size=\"80\" /><b></b><br>Small Description for the uploaded file (Example: A good movie!!!)<br>This Description is shown in Browse under the Torrentname.", 1);
tr("NFO file", "<input type=file name=nfo size=80><br>(<b>Required.</b> Can only be viewed by power users.)\n", 1);
print("</td></tr>\n");
/*
print("<tr><td class=rowhead style='padding: 3px'>Description</td><td>");
textbbcode("upload","descr",($quote?(("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars(unesc($arr["body"]))."[/quote]")):""));
print("</td></tr>\n");
*/
tr("Description","<textarea name=descr id=descr rows=15 cols=90></textarea>",1);

$s = "<select name=\"type\">\n<option value=\"0\">(choose one)</option>\n";

$cats = genrelist();
foreach ($cats as $row)
        $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";

$s .= "</select>\n";
tr("Type", $s, 1);

tr("Show uploader", "<input type=checkbox name=uplver value=yes>Don't show my username in 'Uploaded By' field in browse.", 1);

?>
<tr><td align="center" colspan="2"><input type="submit" class=btn value="Upload" onClick="javascipt:showPreloader();"/></td></tr>
</table>
</form>
<?

stdfoot();

?>