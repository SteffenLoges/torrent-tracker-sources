<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: index.php - Main Script File.                                    |
// | Version: 9.3                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
ob_start("ob_gzhandler");

require "include/bittorrent.php";

dbconn(true);
loggedinorreturn();
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  $choice = $_POST["choice"];
  if ($CURUSER && $choice != "" && $choice < 256 && $choice == floor($choice))
  {
    $res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
    $arr = mysql_fetch_assoc($res) or die("No poll");
    $pollid = $arr["id"];
    $userid = $CURUSER["id"];
    $res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid && userid=$userid") or sqlerr();
    $arr = mysql_fetch_assoc($res);
    if ($arr) die("Dupe vote");
    mysql_query("INSERT INTO pollanswers VALUES(0, $pollid, $userid, $choice)") or sqlerr();
    if (mysql_affected_rows() != 1)
      stderr("Error", "An error occured. Your vote has not been counted.");
    header("Location: $BASEURL/");
    die;
  }
  else
    stderr("Error", "Please select an option.");
}

/*
$a = @mysql_fetch_assoc(@mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1")) or die(mysql_error());
if ($CURUSER)
  $latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
else
  $latestuser = $a['username'];
*/
$registered = number_format(get_row_count("users"));
//$unverified = number_format(get_row_count("users", "WHERE status='pending'"));
$torrents = number_format(get_row_count("torrents"));
//$dead = number_format(get_row_count("torrents", "WHERE visible='no'"));

$r = mysql_query("SELECT value_u FROM avps WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$seeders = 0 + $a[0];
$r = mysql_query("SELECT value_u FROM avps WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_row($r);
$leechers = 0 + $a[0];
$seeders = number_format(get_row_count("peers", "WHERE seeder='yes'"));
$leechers = number_format(get_row_count("peers", "WHERE seeder='no'"));
$peers = number_format($seeders + $leechers);
$uniqpeer = number_format(get_row_count("peers", "WHERE connectable='yes'"));
if ($leechers == 0)
$ratio = 0;
else
$ratio = round($seeders / $leechers * 100);
    $exs = mysql_query("SELECT seeders FROM torrents WHERE external != ''") or die("OopppsY!");
    $totalseedex = 0;
while($arrs = mysql_fetch_array($exs)) {
$totalseedex += $arrs['seeders'];
}
    $exs = mysql_query("SELECT leechers FROM torrents WHERE external != ''") or die("OopppsY!");
    $totalleechex = 0;
while($arrs = mysql_fetch_array($exs)) {
$totalleechex += $arrs['leechers'];
}
$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$result = mysql_query("SELECT SUM(last_access >= $dt) AS totalol FROM users") or sqlerr(__FILE__, __LINE__);

while ($row = mysql_fetch_array ($result))
{
$totalonline          = $row["totalol"];
}

$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$res = mysql_query("SELECT id, username, class, donor, warned FROM users WHERE last_access >= $dt ORDER BY username") or print(mysql_error());
while ($arr = mysql_fetch_assoc($res))

{
if ($activeusers) $activeusers .= ",\n";
switch ($arr["class"])
{
 case UC_SYSOP:
   $arr["username"] = "<font color=#FF0000>" . $arr["username"] . "</font>";
   break;
case UC_ADMINISTRATOR:
   $arr["username"] = "<font color=#FF0000>" . $arr["username"] . "</font>";
   break;
case UC_MODERATOR:
   $arr["username"] = "<font color=#0000FF>" . $arr["username"] . "</font>";
   break;
case UC_UPLOADER:
   $arr["username"] = "<font color=#9900CC>" . $arr["username"] . "</font>";
   break;
case UC_VIP:
   $arr["username"] = "<font color=#FF6600>" . $arr["username"] . "</font>";
   break;
case UC_POWER_USER:
   $arr["username"] = "<font color=#009900>" . $arr["username"] . "</font>";
   break;

}
$donator = $arr["donor"] === "yes";
if ($donator)
 $activeusers .= "<nobr>";
$warned = $arr["warned"] === "yes";
if ($warned)
 $activeusers .= "<nobr>";
if ($CURUSER)
$activeusers .= "<a href=userdetails.php?id={$arr["id"]}><b>{$arr["username"]}</b></a>";
else
$activeusers .= "<b>{$arr["username"]}</b>";
if ($donator)
$activeusers .= "<img src={$pic_base_url}star.gif alt='" .DONOR. " {$$arr["donor"]}'></nobr>";
if ($warned)
$activeusers .= "<img src={$pic_base_url}warned.gif alt='" .WARNED. " {$$arr["warned"]}'></nobr>";
}
if (!$activeusers)
$activeusers = "There have been no active users in the last 15 minutes.";

stdhead("Home");
//echo "<font class=small>Welcome to our newest member, <b>$latestuser</b>!</font>\n";
$getucn = get_user_class() >= UC_ADMINISTRATOR ? ' - <font class=small>[<a class=altlink href=news.php><b>' .NEWS_PAGE. '</b></a>]</font>' : '';
fts_start_collapse('faqtable998','<h2>'.RECENT_NEWS.$getucn.'</h2>');
print("<table width=100% class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>");
$res = mysql_query("SELECT * FROM news WHERE ADDDATE(added, INTERVAL 45 DAY) > NOW() ORDER BY added DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0)
{
        print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n<ul>");
        while($array = mysql_fetch_array($res))
        {
          print("<li>" . gmdate("Y-m-d",strtotime($array['added'])) . " - " . $array['body']);
    if (get_user_class() >= UC_ADMINISTRATOR)
    {
            print(" <font size=\"-2\">[<a class=altlink href=news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>" .EDIT. "</b></a>]</font>");
            print(" <font size=\"-2\">[<a class=altlink href=news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>" .DELETE_. "</b></a>]</font>");
    }
    print("</li>");
  }
  print("</ul></td></tr></table>\n");
}?>
				</div>
			</td></tr>	


</table>
<?
fts_end_collapse();
fts_start_collapse('faqtable997','<h2>ShoutBox</h2>')
?>
<center><a href='#' onclick="myRef = window.open('sbox.php','mywin',
'left=20,top=20,width=700,height=600,toolbar=0,resizable=0,scrollbars=1');"> Click here to open shoutbox </a>
<?
fts_end_collapse();
 if ($CURUSER)
{
  // Get current poll
  $res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
  if($pollok=(mysql_num_rows($res)))
  {
          $arr = mysql_fetch_assoc($res);
          $pollid = $arr["id"];
          $userid = $CURUSER["id"];
          $question = format_comment($arr["question"]);
          $o = array($arr["option0"], $arr["option1"], $arr["option2"], $arr["option3"], $arr["option4"],
            $arr["option5"], $arr["option6"], $arr["option7"], $arr["option8"], $arr["option9"],
            $arr["option10"], $arr["option11"], $arr["option12"], $arr["option13"], $arr["option14"],
            $arr["option15"], $arr["option16"], $arr["option17"], $arr["option18"], $arr["option19"]);

  // Check if user has already voted
          $res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid AND userid=$userid") or sqlerr();
          $arr2 = mysql_fetch_assoc($res);
  }
  $cq = get_user_class() >= UC_MODERATOR ? " - [<a class=altlink href=admin.php?act=makepoll&returnto=main><b>" .P_NEW. "</b></a>]\n" : '';
fts_start_collapse('faqtable996',"<h2>" .POLL.$cq. "");

        print("</h2>\n");
        if($pollok) {
                print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>\n");
          print("<table class=main border=1 cellspacing=0 cellpadding=0><tr><td class=text>");
          print("<p align=center><b>$question</b>\n");
          if (get_user_class() >= UC_MODERATOR)
  {
          print("");
                 print(" - [<a class=altlink href=admin.php?act=makepoll&returnto=main><b>" .P_NEW. "</b></a>]\n");
                if($pollok) {
                  print(" - [<a class=altlink href=admin.php?act=makepoll&action=edit&pollid=$arr[id]&returnto=main><b>" .EDIT. "</b></a>]\n");
                        print(" - [<a class=altlink href=admin.php?act=polls&action=delete&pollid=$arr[id]&returnto=main><b>" .DELETE_. "</b></a>]");
                }
                print("");
        }
        print('</p>');
if($usergroups['canvo'] == 'no')
$voted = true;
else
$voted = $arr2;

          if ($voted)
          {
            // display results
            if ($arr["selection"])
              $uservote = $arr["selection"];
            else
              $uservote = -1;
                        // we reserve 255 for blank vote.
            $res = mysql_query("SELECT selection FROM pollanswers WHERE pollid=$pollid AND selection < 20") or sqlerr();

            $tvotes = mysql_num_rows($res);

            $vs = array(); // array of
            $os = array();

            // Count votes
            while ($arr2 = mysql_fetch_row($res))
              $vs[$arr2[0]] += 1;

            reset($o);
            for ($i = 0; $i < count($o); ++$i)
              if ($o[$i])
                $os[$i] = array($vs[$i], $o[$i]);

            function srt($a,$b)
            {
              if ($a[0] > $b[0]) return -1;
              if ($a[0] < $b[0]) return 1;
              return 0;
            }

            // now os is an array like this: array(array(123, "Option 1"), array(45, "Option 2"))
            if ($arr["sort"] == "yes")
                    usort($os, srt);

            print("<table class=main width=100% border=0 cellspacing=0 cellpadding=0>\n");
            $i = 0;
            while ($a = $os[$i])
            {
              if ($i == $uservote)
                $a[1] .= "&nbsp;*";
              if ($tvotes == 0)
                      $p = 0;
              else
                      $p = round($a[0] / $tvotes * 100);
              if ($i % 2)
                $c = "";
              else
                $c = " bgcolor=#ECE9D8";
              print("<tr><td width=1% class=embedded$c><nobr>" . $a[1] . "&nbsp;&nbsp;</nobr></td><td width=99% class=embedded$c>" .
                "<img src=/pic/bar_left.gif><img src=/pic/bar.gif height=9 width=" . ($p * 3) .
                "><img src=/pic/bar_right.gif> $p%</td></tr>\n");
              ++$i;
            }
            print("</table>\n");
                        $tvotes = number_format($tvotes);
            print("<p align=center>" .VOTES. ": $tvotes</p>\n");
          }
          else
          {
//aici
            print("<form method=post action=index.php>\n");
            $i = 0;
            while ($a = $o[$i])
            {
              print("<input type=radio name=choice value=$i>$a<br>\n");
              ++$i;
            }
            print("<br>");
            print("<input type=radio name=choice value=255>" .BLANK_VOTE. "<br>\n");
            print("<p align=center><input type=submit value='" .VOTE. "!' class=btn></p>");
          }
?>
</td></tr></table>

</td></tr></table>

<?
        } else {
                echo "<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>\n";
          echo "<table class=main border=1 cellspacing=0 cellpadding=0><tr><td class=text>";
          echo"<p align=center><H3>" .NO_ACTIVE_POOLS. "</h3></p>\n";
          echo "</td></tr></table></td></tr></table>";
        }
} fts_end_collapse();
fts_start_collapse('faqtable995',"<h2>" .ACTIVE_USERS. " ".$totalonline.'</h2>')?>
       <table width="641" border="1" align="center">
</tr>
</table>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr>
  <td class=text>
<?=$activeusers?></td>
</tr></table>
<?fts_end_collapse();?>
<?if($last5torrents == 'yes') { ?>
<?//fts_cache_start('1199','last5torrentuploads');?>
<?fts_start_collapse('faqtable994','<h2>Last 5 Torrent Uploads(cached every 20 minutes)</h2>');?>
<?
$sql = "SELECT * FROM torrents where visible='yes' ORDER BY added DESC LIMIT 5";
$result = mysql_query($sql) or die('No torrents found');
if( mysql_num_rows($result) != 0 )
{

print'<table width=98% border=1 cellspacing=0 cellpadding=5>';
print'<tr>';
print'<td class=rowhead>Name</td>';
print'<td class=rowhead>Leechers</td>';
print'<td class=rowhead>Seeders</td>';
print'</tr>';

while( $row = mysql_fetch_assoc($result) )
{
print'<tr>';
print'<a href="details.php?id=' . $row['id'] . '&hit=1"><td>' . $row['name'] . '</td></a>';
print'<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;' . $row['leechers'] . '</td>';
print'<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;' . $row['seeders'] . '</td>';
print'</tr>';
}
print '</table>';
}
else
{
print 'No torrents found';
}
?>
<?fts_end_collapse();?>
<?}?>
<?fts_start_collapse('faqtable993',"<h2>" .STATS. "</h2>");?>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>
<table class=main border=1 cellspacing=0 cellpadding=5>
<tr><td class=rowhead><? print("" .REGISTERED_USERS. "")?></td><td align=right><?=$registered?></td></tr>
<!-- <tr><td class=rowhead>Unconfirmed users</td><td align=right><?=$unverified?></td></tr> -->
<tr><td class=rowhead><? print("" .TORRENTS. "")?></td><td align=right><?=$torrents?></td></tr>
<? if (isset($peers)) { ?>
<tr><td class=rowhead><? print("" .PEERS. "")?></td><td align=right><?=$peers?></td></tr>
<tr><td class=rowhead><? print("" .SEEDERS. "")?></td><td align=right><?=$seeders?></td></tr>
<tr><td class=rowhead><? print("" .LEECHERS. "")?></td><td align=right><?=$leechers?></td></tr>
<tr><td class=rowhead>External Torrents Seeders</td><td align=right><?=$totalseedex?></td></tr>
<tr><td class=rowhead>External Torrents Leechers</td><td align=right><?=$totalleechex?></td></tr>
<tr><td class=rowhead><? print("" .SEEDER_LEECHER_RATIO. "")?></td><td align=right><?=$ratio?></td></tr>
<? } ?>
</table>
</td></tr></table>
<?fts_end_collapse();?>



<?
		$mods = getmodules('admin/modules');
foreach($mods as $m) {
if(file_exists('admin/modules/'.$m.'/page.index.php'))	include('admin/modules/'.$m.'/page.index.php');
}
?>
<?=fts_cache_start('180','disclaimer');?>
<?$browser = $_SERVER['HTTP_USER_AGENT'];
if(!preg_match("/MSIE/i",$browser)) { ?>
<h2><center><font size=\"-1\">Disklaimer</font></center></h2>
<table width=100% border=0 cellspacing=0 cellpadding=10 class=index><tr><td align=center>


<?
echo "<marquee onmouseover=this.stop() onmouseout=this.start() scrollAmount=1.8 direction=up width='100%' height='100'>";
?>


<? print("" .DISCLAIMER. "")?>


</marquee>



</td></tr></table>

<?}else{?>
<h2><center><font size=\"-1\">Disklaimer</font></center></h2><table width=100% border=0 cellspacing=0 cellpadding=10 class=index><tr><td align=center>
<? print("" .DISCLAIMER. "")?>
</td></tr></table>
Hey, i had to modify this content for you cuz you are using IE. Please upgrade to firefox for more features on this site.
<?}?>
<?fts_cache_end();?>
<p align=center>
<a href="http://getfirefox.com"><img border="0" alt="Get firefox!" title="Get firefox!" src="pic/firefox_80x15.png"/></a><a href="http://utorrent.com"><img border="0" alt="Get utorrent!" title="Get utorrent!" src="pic/utorrent.png"/></a><a href="http://azureus.sourceforge.net"><img border="0" alt="Get Azureus!" title="Get Azureus!" src="pic/azureus.png"/></a>
</p>
</td></tr></table>
<?

stdfoot();

?>