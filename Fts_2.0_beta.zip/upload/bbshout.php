<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: bbshout.php - Bulletin Board tags.                               |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
?>
<script type="text/javascript">
<!--
function bbshout(repdeb, repfin) {
  var input = document.forms['ttshoutform'].elements['message'];
  input.focus();

  if(typeof document.selection != 'undefined') {

    var range = document.selection.createRange();
    var insText = range.text;
    range.text = repdeb + insText + repfin;

    range = document.selection.createRange();
    if (insText.length == 0) {
      range.move('character', -repfin.length);
    } else {
      range.moveStart('character', repdeb.length + insText.length + repfin.length);
    }
    range.select();
  }

  else if(typeof input.selectionStart != 'undefined')
  {

    var start = input.selectionStart;
    var end = input.selectionEnd;
    var insText = input.value.substring(start, end);
    input.value = input.value.substr(0, start) + repdeb + insText + repfin + input.value.substr(end);

    var pos;
    if (insText.length == 0) {
      pos = start + repdeb.length;
    } else {
      pos = start + repdeb.length + insText.length + repfin.length;
    }
    input.selectionStart = pos;
    input.selectionEnd = pos;
  }

  else
  {

    var pos;
    var re = new RegExp('^[0-9]{0,3}$');
    while(!re.test(pos)) {
      pos = prompt("Insertion � la position (0.." + input.value.length + "):", "0");
    }
    if(pos > input.value.length) {
      pos = input.value.length;
    }

    var insText = prompt("Veuillez entrer le texte � formater:");
    input.value = input.value.substr(0, pos) + repdeb + insText + repfin + input.value.substr(pos);
  }
}

function bbcolor() {
	var colorvalue = document.forms['ttshoutform'].elements['color'].value;
	bbshout("[color="+colorvalue+"]", "[/color]");
}

function bbfont() {
	var fontvalue = document.forms['ttshoutform'].elements['font'].value;
	bbshout("[font="+fontvalue+"]", "[/font]");
}
//-->
</script>

<?
function quickbbshout(){
echo "<center><table border=0 cellpadding=0 cellspacing=2><tr>";
echo "<tr>";
echo "<td width=22><a href=\"javascript:bbshout('[b]', '[/b]')\"><img src=/images/bbcode/bbcode_bold.gif border=0 alt='Bold'></a></td>";
echo "<td width=22><a href=\"javascript:bbshout('[i]', '[/i]')\"><img src=/images/bbcode/bbcode_italic.gif border=0 alt='Italic'></a></td>";
echo "<td width=22><a href=\"javascript:bbshout('[u]', '[/u]')\"><img src=/images/bbcode/bbcode_underline.gif border=0 alt='Underline'></a></td>";
echo "<td width=22><a href=\"javascript:bbshout('[url]', '[/url]')\"><img src=/images/bbcode/bbcode_url.gif border=0 alt='Url'></a></td>";
echo "<td>
<select name='color' size='0.5' onChange=\"javascript:bbcolor()\">
<option selected='selected'>COLOR</option>
<option value=skyblue style=color:skyblue>sky blue</option>
<option value=royalblue style=color:royalblue>royal blue</option>
<option value=blue style=color:blue>blue</option>
<option value=darkblue style=color:darkblue>dark-blue</option>
<option value=orange style=color:orange>orange</option>
<option value=orangered style=color:orangered>orange-red</option>
<option value=crimson style=color:crimson>crimson</option>
<option value=red style=color:red>red</option>
<option value=firebrick style=color:firebrick>firebrick</option>
<option value=darkred style=color:darkred>dark red</option>
<option value=green style=color:green>green</option>
<option value=limegreen style=color:limegreen>limegreen</option>
<option value=seagreen style=color:seagreen>sea-green</option>
<option value=deeppink style=color:deeppink>deeppink</option>
<option value=tomato style=color:tomato>tomato</option>
<option value=coral style=color:coral>coral</option>
<option value=purple style=color:purple>purple</option>
<option value=indigo style=color:indigo>indigo</option>
<option value=burlywood style=color:burlywood>burlywood</option>
<option value=sandybrown style=color:sandybrown>sandy brown</option>
<option value=sienna style=color:sienna>sienna</option>
<option value=chocolate style=color:chocolate>chocolate</option>
<option value=teal style=color:teal>teal</option>
<option value=silver style=color:silver>silver</option>
</select></td>";
echo "<td>
<select name='font' size='0.5' onChange=\"javascript:bbfont()\">
<option selected='selected'>FONT</option>
<option value=arial>Arial</option>
<option value=comic sans ms>Comic</option>
<option value=courier new>Courier New</option>
<option value=tahoma>Tahoma</option>
<option value=times new roman>Times New Roman</option>
<option value=verdana>Verdana</option>
</select></td>";
echo "</tr></table></center>";
}
quickbbshout();
?>
