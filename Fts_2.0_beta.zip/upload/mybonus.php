<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: mybonus.php - Exchange points with upload.                       |
// | Version: 1.0                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/

require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
parked(); //=== uncomment if you use this mod

$bonus = htmlspecialchars($CURUSER['seedbonus'], 1);
if($usergroups['canka'] == 'no')
print_ug();
if ($_GET["up_success"]){
$up_success = 0 + $_GET["up_success"];
if($up_success != '1')
stderr("Error", "I smell a rat!");

stdhead($CURUSER['username'] . "'s Karma Bonus Page");
print("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Success!</h1></td></tr><tr>".
"<td class=clearalt6 align=left><img src=$imgdir/smilies/karma.gif alt=good_karma></td>".
"<td class=clearalt6 align=left><b>Congratulations ! </b>$CURUSER[username] you have just increased your upload".
" amount! <img src=$imgdir/w00t.gif alt=\"w00t\"><br><br><br><br> click to go back to your ".
"<a class=altlink href=mybonus.php>Karma Bonus Point</a> page.<br><br></td></tr></table>");
die;
}

if ($_GET["class_success"]){
$class_success = 0 + $_GET["class_success"];
if($class_success != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Success!</h1></td></tr>".
"<tr><td align=left class=clearalt6><img src=pic/smilies/karma.gif alt=good_karma></td><td align=left class=clearalt6><b>Congratulations! </b>".
"$CURUSER[username] you have got yourself VIP Status for one month! <img src=pic/smilies/w00t.gif alt=w00t><br>".
"<br> Click to go back to your <a class=altlink href=mybonus.php>Karma Points</a> page.<br><br></td></tr></table>");
die;
}

if ($_GET["invite_success"]){
$invite_success = 0 + $_GET["invite_success"];
if($invite_success != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Success!</h1></td></tr><tr><td align=left class=clearalt6>".
"<img src=pic/smilies/karma.gif alt=good_karma></td><td align=left class=clearalt6><b>Congradulations! </b>".
"$CURUSER[username] you have got your self 3 new invites! <img src=pic/w00t.gif alt=w00t><br><br>".
" click to go back to your <a class=altlink href=mybonus.php>Karma Bonus Point</a> page.<br><br></td></tr></table>");
die;
}

if ($_GET["title_success"]){
$title_success = 0 + $_GET["title_success"];
if($title_success != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Success!</h1></td></tr><tr>".
"<td align=left class=clearalt6><img src=pic/smilies/karma.gif alt=good_karma></td><td align=left class=clearalt6><b>Congradulations! </b>".
"$CURUSER[username] you are now known as $CURUSER[title]! <img src=pic/w00t.gif alt=w00t><br>".
"<br> click to go back to your <a class=altlink href=mybonus.php>Karma Bonus Point</a> page.<br><br>".
"</td></tr></table>");
die;
}

if ($_GET["gift_fail"]){
$gift_fail = 0 + $_GET["gift_fail"];
if($gift_fail != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Huh?</h1></td></tr><tr><td align=left class=clearalt6>".
"<img src=pic/smilies/dwarf.gif alt=good_karma></td><td align=left class=clearalt6><b>Not so fast there Mr. fancy pants!</b><br>".
"$CURUSER[username]... you can not spread the karma to yourself...<br>If you want to spread the love, pick another user! <br>".
"<br> click to go back to your <a class=altlink href=mybonus.php>Karma Bonus Point</a> page.<br><br></td></tr></table>");
die;
}

if ($_GET["gift_fail_user"]){
$gift_fail_user = 0 + $_GET["gift_fail_user"];
if($gift_fail_user != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Error</h1></td></tr><tr><td align=left class=clearalt6>".
"<img src=pic/smilies/dwarf.gif alt=good_karma></td><td align=left class=clearalt6><b>Sorry $CURUSER[username]...</b>".
"<br> No User with that username <br><br> click to go back to your <a class=altlink href=mybonus.php>Karma Bonus Point</a> page.".
"<br><br></td></tr></table>");
die;
}

if ($_GET["gift_fail_points"]){
$gift_fail_points = 0 + $_GET["gift_fail_points"];
if($gift_fail_points != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>OUPS!</h1></td></tr><tr><td align=left class=clearalt6>".
"<img src=pic/smilies/cry.gif alt=oups></td><td align=left class=clearalt6><b>Sorry </b>$CURUSER[username] you don't have enough Karma points!".
"<br> go back to your <a class=altlink href=mybonus.php>Karma Bonus Point</a> page.<br><br></td></tr></table>");
die;
}

if ($_GET["gift_success"]){
$gift_success = 0 + $_GET["gift_success"];
if($gift_success != '1')
stderr("Error", "I smell a rat!");
stdhead($CURUSER['username'] . "'s Karma Bonus Page");
echo("<table width=80%><tr><td class=colhead align=left colspan=2><h1>Success!</h1></td></tr><tr><td align=left>".
"<img src=pic/smilies/karma.gif alt=good_karma></td><td align=left class=clearalt6><b>Congradulations! $CURUSER[username] </b>".
"you have spread the Karma well.<br><br>They will be pleased with your kindness!<br><br>This is the message that was sent:<br>".
"<b>Subject:</b> Someone Loves you!<br> <p>You have been given a gift of _______ Karma points by $CURUSER[username]</p><br>".
"You may also send them a message as well, or go back to your <a class=altlink href=mybonus.php>".
"Karma Bonus Point</a> page.<br><br></td></tr></table>");
die;
}

//=== exchange
if ($_GET["exchange"]){

$exchange = 0 + $_GET["exchange"];
if($exchange != '1')
stderr("Error", "I smell a rat!");

$userid = 0 + $CURUSER['id'];
if (!is_valid_id($userid))
stderr("Error", "That is not your user ID!");

$option = $_POST["option"];
$points = $_POST["points"];
if ($points == 0)
stderr("Error", "I smell a rat!");

$art = $_POST["art"];
//===custom title
$title = htmlentities($_POST["title"]);
$title = sqlesc($title);
$usernamegift = $_POST["username"];
$res = mysql_query("SELECT id,seedbonus FROM users WHERE username=" . sqlesc($usernamegift));
$arr = mysql_fetch_assoc($res);
$useridgift = $arr['id'];
$userseedbonus = $arr['seedbonus'];
$usernamegift = sqlesc($usernamegift);
$seedbonus=htmlspecialchars($bonus-$points,1);
$bonuscomment = $CURUSER['bonuscomment'];
$upload = $CURUSER['uploaded'];
$bpoints = $CURUSER['seedbonus'];
$res = mysql_query("SELECT * FROM bonus WHERE id='$option'");
$bytes = mysql_fetch_assoc($res);
$invites = $CURUSER['invites'];
$inv = $invites+$bytes['menge'];

if($bonus < $points)
stderr("Sorry", "you do not have enough Karma points!");
else{
//=== trade for upload
if($art == "traffic") {
$up = $upload + $bytes['menge'];
$bonuscomment = gmdate("Y-m-d") . " - " .$points. " Points for upload bonus.\n " .$bonuscomment;
mysql_query("UPDATE users SET uploaded = $upload + $bytes[menge], seedbonus = '$seedbonus', bonuscomment = '$bonuscomment' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
header("Refresh: 0; url=$BASEURL/mybonus.php?up_success=1");
die;
}

//=== trade for one month VIP status ***note "SET class = '3'" change "3" to whatever your VIP class number is
elseif($art == "class") {
$vip_until = get_date_time(gmtime() + 28*86400);
$bonuscomment = gmdate("Y-m-d") . " - " .$points. " Points for 1 month VIP Status.\n " .$bonuscomment;
mysql_query("UPDATE users SET class = '3', vip_added = 'yes', vip_until = '$vip_until', seedbonus = '$seedbonus' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
header("Refresh: 0; url=$BASEURL/mybonus.php?class_success=1");
die;
}

//=== trade for invites
elseif($art == "invite") {
$bonuscomment = gmdate("Y-m-d") . " - " .$points. " Points for invites.\n " .$bonuscomment;
mysql_query("UPDATE users SET invites = '$inv', seedbonus = '$seedbonus' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
header("Refresh: 0; url=$BASEURL/mybonus.php?invite_success=1");
die;
}
//=== trade for special title
/**** the $words array are words that you DO NOT want the user to have... use to filter "bad words" & user class...
the user class is just for show, but what the hell tongue.gif Add more or edit to your liking.
*note if they try to use a restricted word, they will recieve the special title "I just wasted my karma" *****/
elseif($art == "title") {
$words = array("fuck", "shit", "Moderator", "Administrator", "Admin", "pussy", "Sysop", "cunt", "nigger", "VIP", "Super User", "Power User");
$title = str_replace($words, "I just wasted my karma", $title);
$bonuscomment = gmdate("Y-m-d") . " - " .$points. " Points for custom title. old title was $CURUSER[title] new title is $title\n " .$bonuscomment;
mysql_query("UPDATE users SET title = $title, seedbonus = '$seedbonus' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
header("Refresh: 0; url=$BASEURL/mybonus.php?title_success=1");
die;
}
elseif($art == "gift_1") {
//=== trade for giving the gift of karma
$points = $_POST["bonusgift"];
$bonus= $CURUSER['seedbonus'];
if($bonus >= $points){
$points= htmlspecialchars($points,1);
$bonuscomment = gmdate("Y-m-d") . " - " .$points. " Points as gift to $_POST[username] .\n " .$bonuscomment;
$seedbonus=$bonus-$points;
$giftbonus1=$userseedbonus+$points;
if ($userid==$useridgift){
header("Refresh: 0; url=$BASEURL/mybonus.php?gift_fail=1");
die;
}
if (!$useridgift){
header("Refresh: 0; url=$BASEURL/mybonus.php?gift_fail_user=1");
die;
}
mysql_query("UPDATE users SET seedbonus = '$seedbonus', bonuscomment = '$bonuscomment' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
mysql_query("UPDATE users SET seedbonus = '$giftbonus1' WHERE id = '$useridgift'");
//===send message
$subject = sqlesc("Someone Loves you"); //=== comment out this line if you do not have subject in your PM system
$added = sqlesc(get_date_time());
$msg = sqlesc("You have been given a gift of $points Karma points by ".$CURUSER['username']);
mysql_query("INSERT INTO messages (sender, subject, receiver, msg, added) VALUES(0, $subject, $useridgift, $msg, $added)") or sqlerr(__FILE__, __LINE__);
//mysql_query("INSERT INTO messages (sender, receiver, msg, added) VALUES(0, $useridgift, $msg, $added)") or sqlerr(__FILE__, __LINE__); //=== use this line if you do not have subject in your PM system and comment out the above query.
$usernamegift = unesc($_POST["username"]);
header("Refresh: 0; url=$BASEURL/mybonus.php?gift_success=1");
die;
}
else{
header("Refresh: 0; url=$BASEURL/mybonus.php?gift_fail_points=1");
die;
}
}
}
}


//==== this is the default page
stdhead($CURUSER['username'] . "'s Karma Bonus Page");

echo("<table align=center width=80% border=1 cellspacing=0 cellpadding=5><tr><td class=colhead colspan=4>".
"<h1>$SITENAME Karma Bonus Point system:</h1></td></tr><tr><td align=center colspan=4 class=clearalt6>".
"Exchange your <a class=altlink href=mybonus.php>Karma Bonus Points</a> [ current $bonus ] for goodies!".
"<br><br>[ If no buttons appear, you have not earned enough bonus points to trade. ]<br><br><tr>".
"<td class=colhead align=left>Option</td><td class=colhead align=left>Description</td>".
"<td class=colhead align=center>Points</td><td class=colhead align=center>Trade</td></tr>");

$res = mysql_query("SELECT * FROM bonus ORDER BY id ASC");

while ($gets = mysql_fetch_assoc($res)){
//=======change colors
if($count == 0){
$count = $count+1;
$class = "clearalt7";
}
else{
$count = 0;
$class = "clearalt6";
}

$otheroption = "<table width=100%><tr><td class=$class><b>Username:</b><input type=text name=username size=20 maxlength=24></td><td class=$class> <b>to be given: </b><select name=bonusgift> <option value=100.0> 100.0</option> <option value=200.0> 200.0</option> <option value=300.0> 300.0</option> <option value=400.0> 400.0</option><option value=500.0> 500.0</option><option value=666.0> 666.0</option></select> Karma points!</td></tr></table>";
$otheroption_title = "<input type=text name=title size=30 maxlength=30>";

echo("<form action=mybonus.php?exchange=1 method=post>\n");
if ($gets["id"]==5)
echo("<tr><td class=$class align=center><b>".$gets["id"]."</b></td><td align='left' class=$class><h1><font color=\"#CECFF3\">".$gets["bonusname"]."</font></h1>".$gets["description"]."<br><br>Enter the <b>Special Title</b> you would like to have $otheroption_title click Exchange! </td><td align='center' class=$class>".$gets["points"]."</td>");
else
if ($gets["id"]==7)
echo("<tr><td class=$class align=center><b>".$gets["id"]."</b></td><td align='left' class=$class><h1><font color=\"#CECFF3\">".$gets["bonusname"]."</font></h1>".$gets["description"]."<br><br>Enter the <b>username</b> of the person you would like to send karma to, and select how many points you want to send and click Exchange!<br>$otheroption</td><td align='center' class=$class>min.<br>".$gets["points"]."<br>max.<br>666</td>");
else
echo("<tr><td class=$class align=center><b>".$gets["id"]."</b></td><td align='left' class=$class><h1><font color=\"#CECFF3\">".$gets["bonusname"]."</font></h1>".$gets["description"]."</td><td align='center' class=$class>".$gets["points"]."</td>");

echo("<input type=hidden name=points value=\"".$gets["points"]."\"><input type=hidden name=option value=\"".$gets["id"]."\">".
"<input type=hidden name=art value=\"".$gets["art"]."\">\n");
if($bonus >= $gets["points"]) {
if ($gets["id"]==7)
echo("<td class=$class><input class=button type=submit name=submit value=\"Karma Gift!\"></form></td>");
else
echo("<td class=$class><input class=button type=submit name=submit value=\"Exchange!\"></form></td>");
} else {
echo("<td class=$class align=center><b>more points needed</b></form></td>");
}
}

echo("</table><br><br><br><table width=80%><tr><td class=colhead><h1>What the hell are these Karma Bonus points,".
" and how do I get them?</h1></td></tr><tr><td class=clearalt6>- For every hour that you seed a torrent, you are awarded with 1".
" Karma Bonus Point... <br>If you save up enough of them, you can trade them in for goodies like bonus GB(s) to ".
"your upload<br> stats,getting more invites, or doing the real Karma booster... give them to another user!<br>".
"and yes! this is awarded on a per torrent basis (max of 5) even if there are no leechers on the Torrent you are seeding! <br>".
"<h1>Other things that will get you karma points:</h1><ul><li>uploading a new torrent = 15 points</li><li>".
"putting up an offer = 10 points</li><li>filling a request = 10 points</li><li>comment on torrent = 3 points</li>".
"<li>saying thanks = 2 points</li><li>rating a torrent = 5 points</li><li>making a post = 1 point</li>".
"<li>starting a topic = 2 points</li><li>voting on poll = 1 point</li><li>filling a re-seed request = 5 points</li>".
"</ul><h1>Some things that will cost you karma points:</h1><ul><li>trading for invites</li>".
"<li>trading for upload credit</li><li>trading for a custom title</li>".
"<li>giving a gift of karma points to another user</li>".
"<li>asking for a re-seed</li><li>making a request</li></ul><p>But keep in mind that everything that can get".
" you karma can also be lost, <br>ie:if you up a torrent then delete it, you will gain and then lose 10 points, <br>".
"making a post and having it deleted will do the same<br><br>... and there are other hidden bonus karma points all ".
"over the site.<br><br>Yet another way to help out your ratio! </p><p>*please note, staff can give or take away ".
"points for breaking the rules, or doing good for the community.</p></td></tr></table><p align=center>".
"<a class=altlink href=usercp.php>back to your profile</a></p></td></tr></table>");

stdfoot();
?>