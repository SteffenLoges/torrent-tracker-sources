<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
# IMPORTANT: Do not edit below unless you know what you are doing!
if(!defined('IN_INSTALL'))
  die('Hacking attempt!');
  
  function validusername($username)
{
	if ($username == "")
	  return false;

	// The following characters are allowed in user names
	$allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	for ($i = 0; $i < strlen($username); ++$i)
	  if (strpos($allowedchars, $username[$i]) === false)
	    return false;

	return true;
}

function validemail($email) {
    return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
}

function mksecret($length = 20) {
$set = array("a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","u","U","v","V","w","W","x","X","y","Y","z","Z","1","2","3","4","5","6","7","8","9");
        $str;
        for($i = 1; $i <= $length; $i++)
        {
            $ch = rand(0, count($set)-1);
            $str .= $set[$ch];
        }
        return $str;
}

function get_date_time ()
{
	return date("Y-m-d H:i:s");
}

function sqlerr($file = '', $line = '')
{
  print("<table border=0 bgcolor=blue align=left cellspacing=0 cellpadding=10 style='background: blue'>" .
    "<tr><td class=embedded><font color=white><h1>SQL Error</h1>\n" .
  "<b>" . mysql_error() . ($file != '' && $line != '' ? "<p>in $file, line $line</p>" : "") . "</b></font></td></tr></table>");
  die;
}

function sqlesc($value) {
    // Stripslashes
   if (get_magic_quotes_gpc()) {
       $value = stripslashes($value);
   }
   // Quote if not a number or a numeric string
   if (!is_numeric($value)) {
       $value = "'" . mysql_real_escape_string($value) . "'";
   }
   return $value;
}

function mkglobal($vars) {
    if (!is_array($vars))
        $vars = explode(":", $vars);
    foreach ($vars as $v) {
        if (isset($_GET[$v]))
            $GLOBALS[$v] = unesc($_GET[$v]);
        elseif (isset($_POST[$v]))
            $GLOBALS[$v] = unesc($_POST[$v]);
        else
            return 0;
    }
    return 1;
}

function unesc($x) {
    if (get_magic_quotes_gpc())
        return stripslashes($x);
    return $x;
}

function safe_email($email) { 	
	$email = str_replace("<","",$email); 
	$email = str_replace(">","",$email); 
	$email = str_replace("\'","",$email); 
	$email = str_replace('\"',"",$email); 
	$email = str_replace("\\\\","",$email); 
	return $email; 
}

function check_email ($email) {
	# Check EMail Function v.02 by xam!
	if(ereg("^([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", $email)) 
		return true;
	else
		return false;
}

function bark($msg) {
	stdmsg("Signup Failed! (See Below)", $msg,false);
	exit;
}

function stdmsg($heading, $text, $htmlstrip = TRUE)
{
    if ($htmlstrip) {
        $heading = htmlspecialchars(trim($heading));
        $text = htmlspecialchars(trim($text));
    }
    print("<table class=main width=100% border=0 cellpadding=0 cellspacing=0><tr><td class=embedded>\n");
        if ($heading)
            print("<h2>$heading</h2>\n");
    print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n");
    print($text . "</td></tr></table></td></tr></table>\n");
}
function int_check($value) {
	if ( is_array($value) ) {
        foreach ($value as $val) int_check ($val);
    } else {
	    if (!is_valid_id($value)) {
			bark("Invalid ID! For security reason, we have been logged this action.");	    }	    	
	    else
	    	return true;
    }
}

function is_valid_id($id)
{
  return is_numeric($id) && ($id > 0) && (floor($id) == $id);
}

 
  function step ($text = '', $stepname = '', $stepnumber = '', $upgrade=false) {
	  ?>
	  <p><table border=1 cellspacing=0 cellpadding=10 bgcolor=black width=900 align=center><tr><td style='padding: 10px; background: black' class=text>
<font color=white><center><b><?=$text?></b> <div align=right>STEP: <?=$stepname?> (<?=$stepnumber?>/<?=($upgrade ? '5' : '4');?>)</div>
</font></center></td></tr></table></p>
<table border=1 cellspacing=0 cellpadding=10 width=900 align=center><tr><td style='padding: 10px;' class=text><div align=justify>
	  <?
  }
  function ReadConfig ($configname) {
    if (strstr($configname, ',')) {
        $configlist = explode(',', $configname);
        foreach ($configlist as $key=>$configname) {
            ReadConfig(trim($configname));
        }
    } else {
        $configname = basename($configname);
        $path = ROOT_PATH.'config/'.$configname;
        if (!file_exists($path)) {
            die("<font color=red>File [<b>".htmlspecialchars($configname)."</b>] doesn't exist!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).");
        }
        $fp = fopen($path, 'r');
        $content = '';
        while (!feof($fp)) {
            $content .= fread($fp, 102400);
        }
        fclose($fp);
        if (empty($content)) {
            if ($configname == 'XAM') {
                Header("Location: index.php");  				
                die; 
            }
            return array();
        }
        $tmp        = @unserialize(base64_decode($content));
        if (empty($tmp)) {
            if ($configname == 'XAM') {
                Header("Location: index.php");  				
                die;                
            }
            die("<font color=red>Cannot read file [<b>".htmlspecialchars($configname)."</b>]!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).");
        }
        $GLOBALS[$configname] = $tmp;
        return true;
    }
}

function WriteConfig ($configname, $config) {
    $configname = basename($configname);
    $path = ROOT_PATH.'config/'.$configname;
    if (!file_exists($path) || !is_writable ($path)) {
        die("<font color=red>Cannot read file [<b>".htmlspecialchars($configname)."</b>]!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).");
    }
    $data = base64_encode(@serialize($config));
    if (empty($data)) {
        die("<font color=red>Cannot serialize file [<b>".htmlspecialchars($configname)."</b>]</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).");
    }
    $fp = @fopen ($path, 'w');
    if (!$fp) {
        die("<font color=red>Cannot open file [<b>".htmlspecialchars($configname)."</b>] to save info!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).");
    }
    $Res = @fwrite($fp, $data);
    if (empty($Res)) {
        die("<font color=red>Cannot save info in file (error in serialisation) [<b>".htmlspecialchars($configname)."</b>] to save info!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).");
    }
    fclose($fp);
    return true;
}

function GetVar ($name) {
    if ( is_array($name) ) {
        foreach ($name as $var) GetVar ($var);
    } else {
        if ( !isset($_REQUEST[$name]) )
            return false;
        if ( get_magic_quotes_gpc() ) {
            $_REQUEST[$name] = ssr($_REQUEST[$name]);
        }
        $GLOBALS[$name] = $_REQUEST[$name];
        return $GLOBALS[$name];
    }
}

function ssr ($arg) {
    if (is_array($arg)) {
        foreach ($arg as $key=>$arg_bit) {
            $arg[$key] = ssr($arg_bit);
        }
    } else {
        $arg = stripslashes($arg);
    }
    return $arg;
}

function tr($x,$y,$noesc=0,$relation='') {
    if ($noesc)
        $a = $y;
    else {
        $a = htmlspecialchars($y);
        $a = str_replace("\n", "<br />\n", $a);
    }
    print("<tr".( $relation ? " relation = \"$relation\"" : "")."><td class=\"heading\" valign=\"top\" align=\"right\">$x</td><td valign=\"top\" align=left>$a</td></tr>\n");
}

function random_str_c($length="8")
	{
		$set = array("a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","u","U","v","V","w","W","x","X","y","Y","z","Z","1","2","3","4","5","6","7","8","9");
		$str;
		for($i = 1; $i <= $length; $i++)
		{
			$ch = rand(0, count($set)-1);
			$str .= $set[$ch];
		}
		return $str;
	}

function generate_loginkey()
	{
		return random_str_c(50);
	}

function getip()
{
	if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
	{
		if(preg_match_all('#[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $addresses))
		{
			foreach($addresses[0] as $key => $val)
			{
				if(!preg_match('#^(10|172\.16|192\.168)\.#', $val))
				{
					$ip = $val;
					break;
				}
			}
		}
	}
	if(!isset($ip))
	{
		if(isset($_SERVER['HTTP_CLIENT_IP']))
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		else
			$ip = $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

function write_settings()
{
	$query = mysql_query('SELECT * FROM '.TABLE_PREFIX.'settings ORDER BY title ASC') or sqlerr(__FILE__, __LINE__);
	while($setting = mysql_fetch_array($query))
	{
		$setting['value'] = str_replace("\"", "\\\"", $setting['value']);
		$settings .= "\$settings['{$setting['name']}'] = \"{$setting['value']}\";\n";
	}
	if(!empty($settings))
	{
		$settings = "<?php\n/*********************************\ \n  DO NOT EDIT THIS FILE, PLEASE USE\n  THE SETTINGS EDITOR\n\*********************************/\n\n{$settings}\n?>";
		$file = fopen(ROOT_PATH."community/inc/settings.php", "w");
		fwrite($file, $settings);
		fclose($file);
	}
}
function get_extension($file)
{
	return strtolower(substr(strrchr($file, "."), 1));
}

function dir_list($dir)
{
	$dl = array();  
	$ext = '';
	if (!file_exists($dir))
		error();
	if ($hd = opendir($dir))
	{
		while ($sz = readdir($hd)) { 
		$ext = get_extension($sz);
		if (preg_match("/^\./",$sz) == 0 && $ext != 'php' && $sz != 'administrator-templates' && $sz != 'index.html' && $sz != 'default.css' && $sz != 'large.css')
			$dl[] = $sz;
		}
		closedir($hd);
		asort($dl);
		return $dl;
	}else
		error('','Couldn\'t open storage folder! Please check the path.');
}
function error($e = 'eror') {
print($e);
}
function rebuild_announce_settings()
{
include ROOT_PATH.'include/secrets.php';
ReadConfig('MAIN');
global $MAIN;
	$settings = '';
	if(!file_exists(ROOT_PATH . 'include/annconf.php'))
		$mode = 'x';
	else
		$mode = 'w';	
	$settings .= "\$mysql_host = '".$mysql_host."';\n";
	$settings .= "\$mysql_user = '".$mysql_user."';\n";
	$settings .= "\$mysql_pass = '".$mysql_pass."';\n";
	$settings .= "\$mysql_db = '".$mysql_db."';\n";
	$settings .= "\$DEFAULTBASEURL = '".$MAIN['baseurl']."';\n";
	$settings .= "\$announce_urls = array();\n";
	$settings .= "\$announce_urls = '".$MAIN['announce_url']."';\n";
	$settings .= "\$announce_interval = ".$MAIN['annint'].";\n";
	$settings .= "\$SITE_ONLINE = true;\n";
	$settings .= "\$MEMBERSONLY = true;\n";
	$settings .= "\$waitsystem = false;\n";
	$settings = "<"."?php\n/*********************************\ \n DO NOT EDIT THIS FILE, PLEASE USE\n THE SETTINGS PANEL!!\n\*********************************/\n\n\n$settings\n?".">";	
	$file = @fopen(ROOT_PATH . 'include/annconf.php', $mode);
	@fwrite($file, $settings);
	@fclose($file);
}

function lock ($baseurl = '') {	
	if ($FH = @fopen(THIS_ROOT_PATH.'install.lock', 'w'))
	{		
		@fwrite($FH, 'done', 4);
		@fclose($FH);
		
		@chmod(THIS_ROOT_PATH.'install.lock', 0666);
		$msg="<center>Although the installer is now locked (to re-install, remove the file 'install.lock'), for added security, please remove the index.php program before continuing.
			 <br><br>
			 <b><a href='".$baseurl."/admin/settings.php'>CLICK HERE TO LOGIN AND SETUP YOUR TRACKER!</a></center>";
	}
	else
	{
		$msg = "<center>PLEASE REMOVE THE INSTALLER ('index.php') BEFORE CONTINUING!<br>Failure to do so will enable ANYONE to delete/change your tracker at any time!
				<br><br>
				<b><a href='".$baseurl."/admin/settings.php'>CLICK HERE TO LOGIN AND SETUP YOUR TRACKER!</a></center>";
	}
	print ($msg."<br><b><font color=red><div align=center class=error>Please use settings panel and setup your tracker first.</div></b></font>");
}

function version_check() {
	global $rootpath;

	$error = '<center><font color=red>Please upload new files first.<br><br> REQUIRED TS VERSION: 3.1</font><br><br>Need Support? Contact us at: <a href=http://templateshares.net>http://templateshares.net</a></center>';
	
	if (!file_exists($rootpath.'/include/init.php') || !file_exists($rootpath.'/config/THEME')) {
		step("Installation ERROR!","ERROR!","0",true);
		die($error);
	}

	define('IN_TRACKER', true);
	
	
}
?>