<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
define ('IN_INSTALL', true);
define ('THIS_ROOT_PATH', './');
define ('ROOT_PATH', './../');
define('TRACKER_VERSION','FTS 1.5 FINAL');
define('INSTALL_VERSION','0.7 FINAL by fr33bh');
define ('TIMENOW', time());
define ('BIGDUMP_VERSION','0.24b');
define ('DATA_CHUNK_LENGTH',16384);
define ('MAX_QUERY_LINES',30000);

@set_magic_quotes_runtime(0);
@ignore_user_abort(1);
if (function_exists('set_time_limit') AND get_cfg_var('safe_mode') == 0)
{
	@set_time_limit(0);
}
@ini_set('auto_detect_line_endings', true);
define('INSTALL_URL', 'http://'.$_SERVER['HTTP_HOST']);
$rootpath = ROOT_PATH;
$shorthost =  $_SERVER["HTTP_HOST"];
$sh = preg_replace('/www./', '', $shorthost);

require_once(THIS_ROOT_PATH.'functions.php');
$action = isset($_POST['action']) ? htmlspecialchars($_POST['action']) : (isset($_GET['action']) ? htmlspecialchars($_GET['action']) : 'step0');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title><?=TRACKER_VERSION ?> INSTALLATION <?=INSTALL_VERSION ?></title>
<link rel="stylesheet" href="default.css" type="text/css">
</head>
<body>

<?
if ($action == 'step0') {
	step("Welcome to the installation wizard for ".TRACKER_VERSION.".","Welcome Screen","0");
?>

			<div class=alert2><p>Welcome to the installation wizard for <?=TRACKER_VERSION?>. This wizard will install and configure a copy of <?=TRACKER_VERSION?> on your server.</p>
<p>This guide will make all of your work. Will write the database config, will insert the mysql files in the db,etc.</p>			
</div>		

<div class=alert>
<form method='get' action='install.php'>
<div align=center>Please select installation type: 
<select name='action'>
<option value='step1'>Fresh Install</option>
</select>
<input type=submit value='START'></form>
</div>
</tr></td></div></table>
<?
}elseif ($action == 'step1') {
		step("Databse","Db","1");
	?>
<form action="insertdb.php" method="post"> 

Mysql Host: <input name="host" type="text" /> <BR>
Mysql User: <input name="user" type="text" /> <BR>
Mysql Password: <input name="pass" type="password" /> <BR>
Mysql Database: <input name="db" type="text" /> <BR>
<input type="submit" />
</form>
</body></html><?
}elseif ($action == 'step2') {
step("Inserting main database","2",true);
$installtype = 'install';
	include_once ('bigdump.php'); }elseif ($action == 'step3') {
step("Inserting countries and mods in database","3",true);
$installtype = 'install2';
	include_once ('bigdump.php'); }
elseif ($action == 'step4') {
step("Inserting stylesheets in database","4",true);
$installtype = 'install3';
	include_once ('bigdump.php'); }
elseif ($action == 'step5') {
Readconfig('MAIN');	
	step("Basic Tracker Setup","Tracker Setup","3");	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='save_main'>");
	
	echo '<tr><td colspan="2" class="subheader" align="center">TRACKER/BOARD Online/Offline</td></tr>';
	tr("Tracker Online? ", "yes <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "no" ? " checked" : "") . " value='no'> <br />Want to turn off your Tracker while performing updates or other types of maintenance?<br />\n", 1);
tr("Disable Right Click ", "yes <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "no" ? " checked" : "") . " value='no'> <br /> Do not allow users to right click<br />\n", 1);
tr("Boycott Internet Explorer ", "yes <INPUT type='radio' name='boie'" . ($MAIN["boie"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='boie'" . ($MAIN["boie"] == "no" ? " checked" : "") . " value='no'> <br /> Do not allow users to navigate with MSIE<br />\n", 1);
tr("Enable Last 5 torrents on index ", "yes <INPUT type='radio' name='last5torrents'" . ($MAIN["last5torrents"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='last5torrents'" . ($MAIN["last5torrents"] == "no" ? " checked" : "") . " value='no'> <br /> Show last 5 torrents block on mainpage<br />\n", 1);
tr("Invite system enabled ", "yes <INPUT type='radio' name='invitesys'" . ($MAIN["invitesys"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='invitesys'" . ($MAIN["invitesys"] == "no" ? " checked" : "") . " value='no'> <br /> Disable basic registration and enable invite!<br />\n", 1);
tr("Enable update torrents on cleanup ", "yes <INPUT type='radio' name='ucleanup'" . ($MAIN["ucleanup"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='ucleanup'" . ($MAIN["ucleanup"] == "no" ? " checked" : "") . " value='no'> <br /> Recomended: yes<br />\n", 1);
tr("Enable external torrents upload ", "yes <INPUT type='radio' name='extorr'" . ($MAIN["extorr"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='extorr'" . ($MAIN["extorr"] == "no" ? " checked" : "") . " value='no'> <br /> Recomended: yes<br />\n", 1);	
tr("Verification type ", "Email <INPUT type='radio' name='vtype'" . ($MAIN["vtype"] == "email" ? " checked" : " checked") . " value='email'> Automaticly <INPUT type='radio' name='vtype'" . ($MAIN["vtype"] == "auto" ? " checked" : "") . " value='auto'> Staff <INPUT type='radio' name='vtype'" . ($MAIN["vtype"] == "staff" ? " checked" : "") . " value='staff'> <br /> Recomended: email.<BR>Email - send verification link via email<BR>Automaticly - no verification<BR>Staff - manual verification,by staff<br />\n", 1);

	tr("Site Base Url ","<input type='text' id='specialboxes' name=baseurl value='".($MAIN["baseurl"] ? $MAIN["baseurl"] : "??" )."'> This url is verry important.\n", 1);

tr("Max Torrent Size ","<input type='text' id='specialboxes' name=maxtorentsize value='".($MAIN["maxtorentsize"] ? $MAIN["maxtorentsize"] : "" )."'> Recomended: 1000000.\n", 1);

tr("Announcee Interval ","<input type='text' id='specialboxes' name=annint value='".($MAIN["annint"] ? $MAIN["annint"] : "" )."'> Recomended: 60 * 60.\n", 1);

tr("Signup Timeout ","<input type='text' id='specialboxes' name=signt value='".($MAIN["signt"] ? $MAIN["signt"] : "" )."'> Recomended: 86400 * 3.\n", 1);

tr("Max torrent dead time ","<input type='text' id='specialboxes' name=max_dead_torrent_time value='".($MAIN["max_dead_torrent_time"] ? $MAIN["max_dead_torrent_time"] : "" )."'> Recomended: 6 * 3600.\n", 1);

tr("Max users ","<input type='text' id='specialboxes' name=max_users value='".($MAIN["max_users"] ? $MAIN["max_users"] : "" )."'> Recomended: 3000 or 5000.\n", 1);

tr("Torrent Dir ","<input type='text' id='specialboxes' name=torrent_dir value='".($MAIN["torrent_dir"] ? $MAIN["torrent_dir"] : "" )."'> Recomended: torrents.\n", 1);

tr("Announce url ","<input type='text' id='specialboxes' name=announce_url value='".($MAIN["announce_url"] ? $MAIN["announce_url"] : "" )."'> Recomended: http://".$_SERVER['HTTP_HOST']."/announce.php .\n", 1);

tr("Peer limit ","<input type='text' id='specialboxes' name=peerlimit value='".($MAIN["peerlimit"] ? $MAIN["peerlimit"] : "" )."'> Recomended: 5000 .\n", 1);

tr("Site email ","<input type='text' id='specialboxes' name=mail value='".($MAIN["mail"] ? $MAIN["mail"] : "" )."'> Recomended: noreply@".$_SERVER['HTTP_HOST']." .\n", 1);

tr("Site name ","<input type='text' id='specialboxes' name=name value='".($MAIN["name"] ? $MAIN["name"] : "" )."'> Nothing recomended .\n", 1);

tr("Autoclean interval ","<input type='text' id='specialboxes' name=acv value='".($MAIN["acv"] ? $MAIN["acv"] : "" )."'> Recomended: 900 .\n", 1);

tr("Pic base url ","<input type='text' id='specialboxes' name=picbu value='".($MAIN["picbu"] ? $MAIN["picbu"] : "" )."'> Recomended: pic/ .\n", 1);

tr("IMG Dir ","<input type='text' id='specialboxes' name=imgdir value='".($MAIN["imgdir"] ? $MAIN["imgdir"] : "" )."'> Recomended: pic/ .\n", 1);

	tr("Save settings","<input type='submit' name='save_main' value='SAVE MAIN SETTINGS AND GO NEXT STEP [PRESS ONLY ONCE]'>\n", 1);
	print ("</form>");

}elseif ($action == 'save_main') {
	step("Basic Tracker Setup (DONE!)","Tracker Setup","3");
	GetVar(array('site_online','rcl','baseurl','maxtorentsize','annint','signt','max_dead_torrent_time','max_users','torrent_dir','announce_url','peerlimit','mail','name','acv','picbu','imgdir','boie','last5torrents','ucleanup','waitsystem','vtype','extorr','invitesys'));
	$MAIN['site_online'] = $site_online;
$MAIN['rcl'] = $rcl;
$MAIN['baseurl'] = $baseurl;
$MAIN['maxtorentsize'] = $maxtorentsize;
$MAIN['annint'] = $annint;
$MAIN['signt'] = $signt;
$MAIN['max_dead_torrent_time'] = $max_dead_torrent_time;
$MAIN['max_users'] = $max_users;
$MAIN['torrent_dir'] = $torrent_dir;
$MAIN['announce_url'] = $announce_url;
$MAIN['peerlimit'] = $peerlimit;
$MAIN['mail'] = $mail;
$MAIN['name'] = $name;
$MAIN['acv'] = $acv;
$MAIN['picbu'] = $picbu;
$MAIN['imgdir'] = $imgdir;
$MAIN['boie'] = $boie;
$MAIN['last5torrents'] = $last5torrents;
$MAIN['ucleanup'] = $ucleanup;
$MAIN['waitsystem'] = $waitsystem;
$MAIN['vtype'] = $vtype;
$MAIN['extorr'] = $extorr;
$MAIN['invitesys'] = $invitesys;

	WriteConfig('MAIN', $MAIN);
	Print("MAIN Settings has been saved, please click <a href=install.php?action=step6>here</a> to go next step!"); }
	elseif($action == 'step6') {
require_once(ROOT_PATH.'include/secrets.php');
global $mysql_db,$mysql_host,$mysql_pass,$mysql_user;
mysql_connect($mysql_host,$mysql_user,$mysql_pass);
mysql_select_db($mysql_db);
step('Change table charset','6');
$result = mysql_query("SHOW TABLES FROM $mysql_db"); // Get table names from database - DO NOT EDIT!

while ($row = mysql_fetch_row($result)) {

mysql_query(" ALTER TABLE {$row[0]} CHARACTER SET utf8 COLLATE utf8_general_ci;"); // Change all table names to 'utf8_general_ci'
mysql_query(" ALTER DATABASE $mysql_db CHARACTER SET utf8 COLLATE utf8_general_ci;"); // Change database to 'utf8_general_ci'
print"Changing the table <strong>&quot;{$row[0]}&quot;</strong> to the '<strong><em>utf8_general_ci</em></strong>' collation - Done!<br>"; // This code will begin a new line for each table it changes!
}

print"<h1>DONE!</h1>"; 
Print("Database's tables changed, please click <a href=install.php?action=step7>here</a> to go next step!");
	}
	elseif ($action == 'step7') {
Readconfig('THEME');	
	step("Tracker Theme Setup","Theme Setup","7");	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='save_theme'>");
	$template_dirs =  dir_list('../templates');
echo '<tr><td class="heading" valign="top" align="right">Please select default template of your tracker:</td>';
echo '<td valign="top" align="left"><select name="defaulttemplate">';
if (empty($template_dirs))
		$dirlist .= '<option value="">There is no template</option>';
	else {
		foreach ($template_dirs as $dir)
			$dirlist .= '<option value="'.$dir.'" '.($defaulttemplate == $dir ? 'selected' : '').'>'.$dir.'</option>';
	}
	echo $dirlist.'</select></td></tr>';
	tr("Save settings","<input type='submit' name='save_main' value='SAVE MAIN SETTINGS AND GO NEXT STEP [PRESS ONLY ONCE]'>\n", 1);
	print ("</form>");

}
elseif($action == 'save_theme') {
		GetVar(array('defaulttemplate'));
	$THEME['default'] = $defaulttemplate;
print("Theme settings saved, please click <a href=install.php?action=step8>here</a> to go next step!");

	WriteConfig('THEME', $THEME);
	
}
	elseif($action == 'step8') {
		step('Write announce config','8');
		rebuild_announce_settings();
		print("Announce settings saved, please click <a href=install.php?action=step9>here</a> to go next step!");
	}
elseif ($action == 'step9') {
step("Finishing the install","9");
?>
<div class=alert2><p>Congrats! You have succesfully installed a new version of FTS.<BR> Now, you must register as a user(and you will be made SysOp) and setup your source of FTS using the settings panel. Don't forget to remove the install directory nor your site won't work. <BR> Thanks for spending time with FTS and thanks for choosing us.</p>			
</div>	
<div class=alert><p>IMPORTANT!!!<BR> Delete the install directory. This is an security measure.<BR> Now register on tracker and your account will be SysOP. Don't forget to edit the settings to fit your needs.</p></div>
<div class=alert><p>Verry IMPORTANT!!!<BR>You have to put your mysql details in announce.php because the file is now modded and does not have connection with any config files. So modify your announce.php please. Thanks!</p></div>
<?
$serverinfo = @file_get_contents('http://lic.fr33bh.evolink.ro/urgent.txt');
if(!empty($serverinfo)) {
?>
<div class=alert>
<?echo $serverinfo;?>
</div>
<?
}
	$file = @fopen(ROOT_PATH . 'install/install.done','x');
	@fwrite($file, 'done');
	@fclose($file);
 }
?>