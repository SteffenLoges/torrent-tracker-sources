CREATE TABLE `thanks` (
`torrentid` int(11) NOT NULL default '0',
`userid` int(11) NOT NULL default '0',
`id` int(11) NOT NULL auto_increment,
PRIMARY KEY  (`id`)
) TYPE=MyISAM;




CREATE TABLE `bonus` (
  `id` int(5) NOT NULL auto_increment,
  `bonusname` varchar(50) NOT NULL default '',
  `points` decimal(10,1) NOT NULL default '0.0',
  `description` text NOT NULL,
  `art` varchar(10) NOT NULL default 'traffic',
  `menge` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
);



INSERT INTO `bonus` VALUES (1, '1.0GB Uploaded', '75.0', 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 1073741824);
INSERT INTO `bonus` VALUES (2, '2.5GB Uploaded', '150.0', 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 2684354560);
INSERT INTO `bonus` VALUES (3, '5GB Uploaded', '250.0', 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 5368709120);
INSERT INTO `bonus` VALUES (5, 'Custom Title!', '50.0', 'For only 50.0 Karma Bonus Points you can buy yourself a custom title. the only restrictions are no foul or offensive language or userclass can be entered. The points are then removed from your Bonus Bank and your special title is changed to the title of your choice', 'title', 1);
INSERT INTO `bonus` VALUES (6, 'VIP Status', '500.0', 'With enough bonus points acquired, you can buy yourself VIP status for one month. The points are then removed from your Bonus Bank and your status is changed.', 'class', 1);
INSERT INTO `bonus` VALUES (7, 'Give A Karma Gift', '100.0', 'Well perhaps you don\'t need the upload credit, but you know somebody that could use the Karma boost! You are now able to give your Karma credits as  a gift! The points are then removed from your Bonus Bank and  added to the account of a user of your choice!\r\n\r\nAnd they recieve a PM with all the info as well as who it came from...', 'gift_1', 1073741824);

ALTER TABLE `users` ADD `vip_added` enum('yes','no') NOT NULL default 'no';
ALTER TABLE `users` ADD `vip_until` datetime NOT NULL default '0000-00-00 00:00:00';
ALTER TABLE `users` ADD `seedbonus` decimal(10,1) NOT NULL default '0.0';
ALTER TABLE `users` ADD `bonuscomment` text NOT NULL;
ALTER TABLE `users` ADD `passhint` TEXT NULL ,
ADD `hintanswer` TEXT NULL;
ALTER TABLE `torrents` ADD `external` BLOB;
ALTER TABLE torrents ADD free ENUM ('yes','no') DEFAULT 'no';
ALTER TABLE torrents ADD silver ENUM('yes','no') DEFAULT  'no';
ALTER TABLE torrents ADD t_image TEXT;
ALTER TABLE users ADD external ENUM ('yes','no') DEFAULT 'yes';
ALTER TABLE users ADD altrm ENUM ('yes','no') DEFAULT 'yes';
ALTER TABLE `users` ADD `invites` INT( 10 ) NOT NULL DEFAULT '4',
ADD `invited_by` INT( 10 ) NOT NULL DEFAULT '0';
DROP TABLE IF EXISTS `usergroups`;
CREATE TABLE IF NOT EXISTS `usergroups` (
  `id` int(10) NOT NULL auto_increment,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `isbanned` enum('yes','no') NOT NULL default 'no',
  `canpm` enum('yes','no') NOT NULL default 'yes',
  `candwd` enum('yes','no') NOT NULL default 'yes',
  `canup` enum('yes','no') NOT NULL default 'no',
  `canreq` enum('yes','no') NOT NULL default 'yes',
  `canof` enum('yes','no') NOT NULL default 'yes',
  `canpc` enum('yes','no') NOT NULL default 'yes',
  `canvo` enum('yes','no') NOT NULL default 'yes',
  `canth` enum('yes','no') NOT NULL default 'yes',
  `canka` enum('yes','no') NOT NULL default 'yes',
  `canrp` enum('yes','no') NOT NULL default 'no',
  `canusercp` enum('yes','no') NOT NULL default 'yes',
  `canviewotherprofile` enum('yes','no') NOT NULL default 'yes',
  `canchat` enum('yes','no') NOT NULL default 'yes',
  `canmemberlist` enum('yes','no') NOT NULL default 'yes',
  `canfriendslist` enum('yes','no') NOT NULL default 'yes',
  `cantopten` enum('yes','no') NOT NULL default 'yes',
  `cansettingspanel` enum('yes','no') NOT NULL default 'no',
  `canstaffpanel` enum('yes','no') NOT NULL default 'no',
  `showonstaff` enum('yes','no') NOT NULL default 'no',
  `usernamestyle` varchar(10000) NOT NULL default '{u}',
  `pmquote` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `usergroups`
-- 

INSERT INTO `usergroups` (`id`, `title`, `description`, `isbanned`, `canpm`, `candwd`, `canup`, `canreq`, `canof`, `canpc`, `canvo`, `canth`, `canka`, `canrp`, `canusercp`, `canviewotherprofile`, `canchat`, `canmemberlist`, `canfriendslist`, `cantopten`, `cansettingspanel`, `canstaffpanel`, `showonstaff`, `usernamestyle`, `pmquote`) VALUES 
(6, 'SysOp', 'Has the full power.', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '<span style="color: #2587A7;"><strong>{u} </strong></span>', 1000),
(0, 'User', 'Simple User', 'no', 'yes', 'yes', 'no', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '{u}', 23),
(1, 'Power User', 'The Class above user', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '<span style="color: #f9a200;"><strong>{u}</strong></span>', 50),
(2, 'Vip', 'If a user donated to the tracker, he is vip', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '<span style="color: #009F00;"><strong>{u} </strong></span>', 900),
(3, 'Uploader', 'User with upload privileges.', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', '<span style="color:#6464FF;"><strong>{u} </strong></span>', 200),
(4, 'Moderator', 'Can delete torrents,forum posts, etc...', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '<span style="color: #ff5151;"><strong>{u}</strong></span>', 250),
(5, 'Administrator', 'Almost full power :)', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '<span style="color: #CC00FF;"><strong><em>{u} </em></strong></span>', 500),
(7, 'Staff Leader', 'The user with the supreme power :D :P', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '<span style="color: darkred;"><strong><em>{u} </em></strong></span>', 1000000000);
UPDATE usergroups SET id=0 WHERE title='User' LIMIT 1;






