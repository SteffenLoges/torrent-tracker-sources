<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: staff.php - View Staff members.                              |
// | Version: 0.8                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";
dbconn();
stdhead("Staff");
begin_main_frame();
$ret = mysql_query("SELECT * FROM usergroups WHERE showonstaff = 'yes'ORDER BY id DESC");
while($varet = mysql_fetch_assoc($ret)) {
	$a = $varet['title'];
	$uid = $varet['id'];
?>
                <?
                // Get current datetime
                $dt = gmtime() - 180;
                $dt = sqlesc(get_date_time($dt));
                // Search User Database for Moderators and above and display in alphabetical order
                $res = mysql_query("SELECT * FROM users WHERE class = $uid AND status='confirmed' ORDER BY username" ) or sqlerr();
                while ($arr = mysql_fetch_assoc($res))
                {
                $staff_table[$arr['class']]=$staff_table[$arr['class']].
                "<td class=embedded><a class=altlink href=userdetails.php?id=".$arr['id'].">".
                $arr['username']."</a><sup><font color=#".
                ("'".$arr['last_access']."'">$dt?"000066>On":"999999>Off" )."line</font></sup></td>".
                "<td class=embedded><a href=sendmessage.php?receiver=".$arr['id'].">".
                "<img src=".$pic_base_url."button_pm.gif border=0></a></td>".
                "<td class=embedded><a href=email-gateway.php?id=".$arr['id'].">".
                "<img src=".$pic_base_url."button_mail.gif border=0 alt=".$arr['email']."></a></td>";
                // Show 3 staff per row, separated by an empty column
                ++ $col[$arr['class']];
                if ($col[$arr['class']]<=0)
                $staff_table[$arr['class']]=$staff_table[$arr['class']]."<td class=embedded>&nbsp;</td>";
                else
                {
                $staff_table[$arr['class']]=$staff_table[$arr['class']]."</tr><tr height=15>";
                $col[$arr['class']]=1;
                }
                }
                ?>

                <table width=725 cellspacing=0>
                <tr>
                <!-- Define table column widths -->
                <td class=embedded width="125"><b><?=$a;?></b></td>
                <td class=embedded width="25">&nbsp;</td>
                <td class=embedded width="35">&nbsp;</td>
                <td class=embedded width="85">&nbsp;</td>
                <td class=embedded width="125">&nbsp;</td>
                <td class=embedded width="25">&nbsp;</td>
                <td class=embedded width="35">&nbsp;</td>
                <td class=embedded width="85">&nbsp;</td>
                <td class=embedded width="125">&nbsp;</td>
                <td class=embedded width="25">&nbsp;</td>
                <td class=embedded width="35">&nbsp;</td>
                </tr>
                <tr>
                <td class=embedded colspan=11><hr color="#4040c0" size=1></td>
                </tr>
                <tr height=15>
                <?=$staff_table[$uid];?>
                </tr>
                </table>

<?
}
end_main_frame();
stdfoot();
?>