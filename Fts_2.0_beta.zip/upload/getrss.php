<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: getrss.php - Get rss feed link.                                  |
// | Version: 0.6                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";
dbconn();
loggedinorreturn();

$res = mysql_query("SELECT id, name FROM categories ORDER BY name");
while($cat = mysql_fetch_assoc($res))
$catoptions .= "<input type=\"checkbox\" name=\"cat[]\" value=\"$cat[id]\" ".(strpos($CURUSER['notifs'], "[cat$cat[id]]") !== false ? " checked" : "") . "/>$cat[name]<br>";
$category[$cat['id']] = $cat['name'];

stdhead(rss1);

if ($_SERVER['REQUEST_METHOD'] == "POST") {
$link = "$BASEURL/rss.php";
if ($_POST['feed'] == "dl")
$query[] = "feed=dl";
if (isset($_POST['cat']))
$query[] = "cat=".implode(',', $_POST['cat']);
else {
print("<br>".rss2."<br>");
die();
}
if ($_POST['login'] == "passkey")
$query[] = "passkey=$CURUSER[passkey]";
$queries = implode("&", $query);
if ($queries)
$link .= "?$queries";

print("<br> ".rss3."<br><br><b>$link</b><br>");
die();
}
?>
<FORM method="POST" action="getrss.php">
<table border="1" cellspacing="1" cellpadding="5">
<TR>
<TD class="rowhead"><?=rss4;?>
</TD>
<TD><?=$catoptions?>
</TD>
</TR>
<TR>
<TD class="rowhead"><?=rss5;?>
</TD>
<TD>
<INPUT type="radio" name="feed" value="web" /><?=rss6;?><BR>
<INPUT type="radio" name="feed" value="dl" checked /><?=rss7;?>
</TD>
</TR>
<TR>
<TD class="rowhead"><?=rss8;?>:
</TD>
<TD>
<INPUT type="radio" name="login" value="cookie" /><?=rss9;?><BR>
<INPUT type="radio" name="login" value="passkey" checked /><?=rss10;?>
</TD>
</TR>
<TR>
<TD colspan="2" align="center">
<BUTTON type="submit"><?=rss11;?></BUTTON>
</TD>
</TR>
</TABLE>
</FORM>

<?
stdfoot();
?>