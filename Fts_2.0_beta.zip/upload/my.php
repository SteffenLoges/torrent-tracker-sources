<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: my.php - Profile Page.                                           |
// | Version: 2.5                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();
  $action = $_GET['action'];
$res = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location IN ('in', 'both')") or print(mysql_error());
$arr = mysql_fetch_row($res);
$messages = $arr[0];
$res = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location IN ('in', 'both') AND unread='yes'") or print(mysql_error());
$arr = mysql_fetch_row($res);
$unread = $arr[0];
$res = mysql_query("SELECT COUNT(*) FROM messages WHERE sender=" . $CURUSER["id"] . " AND location IN ('out', 'both')") or print(mysql_error());
$arr = mysql_fetch_row($res);
$outmessages = $arr[0];
if ($CURUSER['added'] == "0000-00-00 00:00:00")
  $joindate = 'N/A';
else
  $joindate = "$CURUSER[added] (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($CURUSER["added"])) . ")";
  //Comment Results
$res = sql_query("SELECT COUNT(*) FROM comments WHERE user=" . $CURUSER["id"]) or sqlerr(__FILE__, __LINE__);
$row_c = mysql_fetch_array($res);
//Comment Results
  //Comment Results
$resc = sql_query("SELECT COUNT(*) FROM thanks WHERE userid=" . $CURUSER["id"]) or sqlerr(__FILE__, __LINE__);
$row_t = mysql_fetch_array($resc);
//Comment Results

if($usergroups['canusercp'] == 'no')
print_ug();
function mymenu ($selected = "home") {
	global $BASEURL,$lang,$usergroups,$CURUSER;
	print ("<div class=\"shadetabs\"><ul>");
	print ("<li" . ($selected == "home" ? " class=selected" : "") . "><a href=\"$BASEURL/my.php\">User Cp</a></li>");
	print ("<li" . ($selected == "personal" ? " class=selected" : "") . "><a href=\"$BASEURL/my.php?action=personal\">Edit Settings</a></li>");
	print ("</ul></div>");
}
stdhead($CURUSER["username"] . "'s private page", false);

if ($_GET["edited"]) {
        print("<h1>Profile updated!</h1>\n");
        if ($_GET["mailsent"])
                print("<h2>Confirmation email has been sent!</h2>\n");
}
elseif ($_GET["emailch"])
        print("<h1>Email address changed!</h1>\n");
else
        print("<h1>Welcome, <a href=userdetails.php?id=$CURUSER[id]>$CURUSER[username]</a>!</h1>\n");
if(empty($action)) {
	mymenu();
echo '<table border="0" cellspacing="0" cellpadding="5" width=100%>';
	tr('Join Date', $joindate, 1);
	tr('Email Address', $CURUSER["email"], 1);
	tr('Passkey', (get_user_class() >= UC_MODERATOR ? $CURUSER["passkey"] : "<font color=red><i><b>hidden</font></i></b>"), 1);
	tr('Avatar',get_user_avatar(),1);
	tr('Karma points', "<a href=mybonus.php>$CURUSER[seedbonus]</a>", 1);
	tr('Comments Written', $row_c[0], 1);
	tr('Thanks Given', $row_t[0], 1);
	exit;
}
elseif($action == 'personal') {
mymenu(personal);
	print ("<form method='post' action='takeprofedit.php'><table border=0 cellspacing=0 cellpadding=5 width=100%><input type=hidden name=action value=personal");
if(!empty($CURUSER['yob']) || !empty($CURUSER['mob']) || !empty($CURUSER['dob'])) {
$year_diff = date("Y") - ($CURUSER['yob']);
    $month_diff = date("m") - ($CURUSER['mob']);
    $day_diff = date("d") - ($CURUSER['dob']);
    if ($month_diff < 0)
      $year_diff--;
    elseif ($month_diff == 0 && $day_diff < 0)
      $year_diff--;
tr("Your age",$year_diff);
}
if(!empty($CURUSER['yob']) || !empty($CURUSER['mob']) || !empty($CURUSER['dob'])) {

tr("Your birthday",$CURUSER['dob'].' '.mctom($CURUSER['mob']).' '.$CURUSER['yob']);
}
tr("Accept PMs",
"<input type=radio name=acceptpms" . ($CURUSER["acceptpms"] == "yes" ? " checked" : "") . " value=yes>All (except blocks)
<input type=radio name=acceptpms" .  ($CURUSER["acceptpms"] == "friends" ? " checked" : "") . " value=friends>Friends only
<input type=radio name=acceptpms" .  ($CURUSER["acceptpms"] == "no" ? " checked" : "") . " value=no>Staff only"
,1);
tr("Account parked",
"<input type=radio name=parked" . ($CURUSER["parked"] == "yes" ? " checked" : "") . " value=yes>yes
<input type=radio name=parked" .  ($CURUSER["parked"] == "no" ? " checked" : "") . " value=no>no"
,1);
tr("Delete PMs", "<input type=checkbox name=deletepms" . ($CURUSER["deletepms"] == "yes" ? " checked" : "") . "> (Default value for \"Delete PM on reply\")",1);
tr("Save PMs", "<input type=checkbox name=savepms" . ($CURUSER["savepms"] == "yes" ? " checked" : "") . "> (Default value for \"Save PM to Sentbox\")",1);
tr("PM on Subscriptions ", "<input type=radio name=subscription_pm" . ($CURUSER["subscription_pm"] == "yes" ? " checked" : "") . " value=yes>yes" .
"<input type=radio name=subscription_pm" . ($CURUSER["subscription_pm"] == "no" ? " checked" : "") . " value=no>no<br> When someone posts in a subscribed thread, you will be PMed.",1);
print("<tr class=tableb><td><b>PM on Comments</b></td>" .
"<td align=left><input type=radio name=commentpm" . ($CURUSER["commentpm"] == "yes" ? " checked" : "") . " value=yes>yes" .
"<input type=radio name=commentpm" .  ($CURUSER["commentpm"] == "no" ? " checked" : "") . " value=no>no" .
"<br><i><font class=small size=1><b>Note:</b>When somone comments you on a torrent you uploaded you will be notified.</i>" .
" <i>This default is yes.</i></font>");
/* not ready yet
tr("Show External Torrents ", "<input type=radio name=extt" . ($CURUSER["external"] == "yes" ? " checked" : "") . " value=yes>yes" .
"<input type=radio name=extt" . ($CURUSER["external"] == "no" ? " checked" : "") . " value=no>no<br> Show external torrents in browse.php",1);
*/
tr("Email notification", "<input type=checkbox name=pmnotif" . (strpos($CURUSER['notifs'], "[pm]") !== false ? " checked" : "") . " value=yes> Notify me when I have received a PM<br>\n" .
         "<input type=checkbox name=emailnotif" . (strpos($CURUSER['notifs'], "[email]") !== false ? " checked" : "") . " value=yes> Notify me when a torrent is uploaded in one of <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; my default browsing categories.\n"
   , 1);
   $countries = "<option value=0>---- None selected ----</option>\n";
$ct_r = mysql_query("SELECT id,name FROM countries ORDER BY name") or die;
while ($ct_a = mysql_fetch_array($ct_r))
  $countries .= "<option value=$ct_a[id]" . ($CURUSER["country"] == $ct_a['id'] ? " selected" : "") . ">$ct_a[name]</option>\n";
   tr("Country", "<select name=country>\n$countries\n</select>",1);
   tr("Avatar URL", "<input name=avatar size=50 value=\"" . htmlspecialchars($CURUSER["avatar"]) .
  "\">\n<br>If you need a host for the picture, try <a href=http://imageshack.us>http://imageshack.us</a>.",1);
  	print ("<form method='post' action='takeprofedit.php'><table border=0 cellspacing=0 cellpadding=5 width=100%><input type=hidden name=action value='tracker'");
	   $lg_r = mysql_query("SELECT id,name FROM languages ORDER BY name") or die;
while ($lg_a = mysql_fetch_array($lg_r))
 $languages .= "<option value=$lg_a[id]" . ($CURUSER["language"] == $lg_a['id'] ? " selected" : "") . ">$lg_a[name]</option>\n";
   tr("Language", "<select name=language>\n$languages\n</select>",1);
   tr("Torrents per page", "<input type=text size=10 name=torrentsperpage value=$CURUSER[torrentsperpage]> (0=use default setting)",1);
tr("Topics per page", "<input type=text size=10 name=topicsperpage value=$CURUSER[topicsperpage]> (0=use default setting)",1);
tr("Posts per page", "<input type=text size=10 name=postsperpage value=$CURUSER[postsperpage]> (0=use default setting)",1);
/*People can't change this because they will have some privileges and some of them may change this to have the privileges.
tr("DATE of birth", "Year <input type=text size=10 name=yearofbirth value=$CURUSER[yob]>(2007,1970) Month <input type=text size=10 name=monthofbirth value=$CURUSER[mob]>(07,10) Day <input type=text size=10 name=dayofbirth value=$CURUSER[dob]> (31,20) ",1);
*/


tr("View avatars", "<input type=checkbox name=avatars" . ($CURUSER["avatars"] == "yes" ? " checked" : "") . "> (Low bandwidth users might want to turn this off)",1);
tr("Info", "<textarea name=info cols=50 rows=4>" . $CURUSER["info"] . "</textarea><br>Displayed on your public page. May contain <a href=tags.php target=_new>BB codes</a>.", 1);
$r = sql_query("SELECT id,name FROM categories ORDER BY name") or sqlerr(__FILE__,__LINE__);
//$categories = "Default browsing categories:<br>\n";
if (mysql_num_rows($r) > 0)
{
	if (!isset($categories))
		$categories = "<table><tr>\n";
	else
		$categories .= "<table><tr>\n";
	$i = 0;
	while ($a = mysql_fetch_array($r))
	{
	  $categories .=  ($i && $i % 2 == 0) ? "</tr><tr>" : "";
	  $categories .= "<td class=bottom style='padding-right: 5px'><input name=cat$a[id] type=\"checkbox\" " . (strpos($CURUSER['notifs'], "[cat$a[id]]") !== false ? " checked" : "") . " value='yes'>&nbsp;" . htmlspecialchars($a["name"]) . "</td>\n";
	  ++$i;
	}
	$categories .= "</tr></table>\n";
}
tr('Default categories',$categories,1);
tr("Your userbar","<img src=\"torrentbar/bar.php/".$CURUSER["id"].".png\" border=\"0\"></img><br /><input type=\"text\" size=65 value=\"$DEFAULTBASEURL/torrentbar/bar.php/".$CURUSER["id"].".png\" readonly />",1);
tr("Email address", "<input type=\"text\" name=\"email\" size=50 value=\"" . htmlspecialchars($CURUSER["email"]) . "\" />", 1);
print("<tr><td colspan=\"2\" align=left><b>Note:</b> In order to change your email address, you will receive another<br>confirmation email to your new address.</td></tr>\n");
$disabledb = $usergroups['canrp'] == 'no' ? ' disabled' : '';
$mesage = $usergroups['canrp'] == 'no' ? 'Curently you can\'t reset your passkey. Contact an admin for help' : 'Any active torrents must be downloaded again to continue leeching/seeding.';
tr("Reset passkey","<input type=checkbox name=resetpasskey value=1 $disabledb/>$CURUSER[passkey]<br><font class=small>$mesage</font>", 1);
tr("Old Password", "<input type=\"password\" name=\"oldpassword\" size=\"50\" />", 1);
tr("Change password", "<input type=\"password\" name=\"chpassword\" size=\"50\" />", 1);
tr("Type password again", "<input type=\"password\" name=\"passagain\" size=\"50\" />", 1);

function priv($name, $descr) {
        global $CURUSER;
        if ($CURUSER["privacy"] == $name)
                return "<input type=\"radio\" name=\"privacy\" value=\"$name\" checked=\"checked\" /> $descr";
        return "<input type=\"radio\" name=\"privacy\" value=\"$name\" /> $descr";
}

/* tr("Privacy level",  priv("normal", "Normal") . " " . priv("low", "Low (email address will be shown)") . " " . priv("strong", "Strong (no info will be made available)"), 1); */
   
  ?>
  <tr><td colspan="2" align="center"><input type="submit" value="Submit changes!" style='height: 25px'></td></tr>
  <?
 exit;
}
?>
<?
function format_tz($a)
{
        $h = floor($a);
        $m = ($a - floor($a)) * 60;
        return ($a >= 0?"+":"-") . (strlen(abs($h)) > 1?"":"0") . abs($h) .
                ":" . ($m==0?"00":$m);
}

?>
<?
if ($messages){
  print("<p>You have $messages message" . ($messages != 1 ? "s" : "") . " ($unread new) in your <a href=inbox.php><b>inbox</b></a>,<br>\n");
        if ($outmessages)
                print("and $outmessages message" . ($outmessages != 1 ? "s" : "") . " in your <a href=inbox.php?out=1><b>sentbox</b></a>.\n</p>");
        else
                print("and your <a href=inbox.php?out=1>sentbox</a> is empty.</p>");
}
else
{
  print("<p>Your <a href=inbox.php>inbox</a> is empty, <br>\n");
        if ($outmessages)
                print("and you have $outmessages message" . ($outmessages != 1 ? "s" : "") . " in your <a href=inbox.php?out=1><b>sentbox</b></a>.\n</p>");
        else
                print("and so is your <a href=inbox.php?out=1>sentbox</a>.</p>");
}

print("<p><a href=users.php><b>Find User/Browse User List</b></a></p>");

stdfoot();

?>