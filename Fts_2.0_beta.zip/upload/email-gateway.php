<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: email-gateway.php - Send message to an user.                     |
// | Version: 0.2                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";
dbconn();

$id = 0 + $_GET["id"];
if (!$id)
        stderr(emaerr, ema1);

$res = mysql_query("SELECT username, class, email FROM users WHERE id=$id");
$arr = mysql_fetch_assoc($res) or stderr(emaerr, ema2);
$username = $arr["username"];
if ($arr["class"] < UC_MODERATOR)
        stderr(emaerr, ema3);

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
        $to = $arr["email"];

        $from = substr(trim($_POST["from"]), 0, 80);
        if ($from == "") $from = "Anonymous";

        $from_email = substr(trim($_POST["from_email"]), 0, 80);
        if ($from_email == "") $from_email = "$SITEEMAIL";
        if (!strpos($from_email, "@")) stderr(emaerr, ema4);

        $from = "$from <$from_email>";

        $subject = substr(trim($_POST["subject"]), 0, 80);
        if ($subject == "") $subject = "(No subject)";
        $subject = "Fw: $subject";

        $message = trim($_POST["message"]);
        if ($message == "") stderr(emaerr, ema5);

        $message = "Message submitted from $_SERVER[REMOTE_ADDR] at " . gmdate("Y-m-d H:i:s") . " GMT.\n" .
                "Note: By replying to this e-mail you will reveal your e-mail address.\n" .
                "---------------------------------------------------------------------\n\n" .
                $message . "\n\n" .
                "---------------------------------------------------------------------\n$SITENAME E-Mail Gateway\n";

        $success = mail($to, $subject, $message, "From: $from", "-f$SITEEMAIL");

        if ($success)
                stderr(ema6, ema7);
        else
                stderr(emaerr, ema8);
}

stdhead(ema9);
?>
<p><table border=0 class=main cellspacing=0 cellpadding=0><tr>
<td class=embedded><img src=/pic/email.gif></td>
<td class=embedded style='padding-left: 10px'><font size=3><b>Send e-mail to <?=$username;?></b></font></td>
</tr></table></p>
<table border=1 cellspacing=0 cellpadding=5>
<form method=post action=email-gateway.php?id=<?=$id?>>
<tr><td class=rowhead><?=ema10;?></td><td><input type=text name=from size=80></td></tr>
<tr><td class=rowhead><?=ema11;?></td><td><input type=text name=from_email size=80></td></tr>
<tr><td class=rowhead><?=ema12;?></td><td><input type=text name=subject size=80></td></tr>
<tr><td class=rowhead><?=ema13;?></td><td><textarea name=message cols=80 rows=20></textarea></td></tr>
<tr><td colspan=2 align=center><input type=submit value="Send" class=btn></td></tr>
</form>
</table>
<p>
<font class=small><?=ema14;?></font>
</p>
<? stdfoot(); ?>