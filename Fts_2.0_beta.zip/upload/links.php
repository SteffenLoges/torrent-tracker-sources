<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: links.php - Tracker's links.                                     |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

dbconn(false);
stdhead("Links");


function add_link($url, $title, $description = "")
{
  $text = "<a class=altlink href=$url>$title</a>";
  if ($description)
    $text = "$text - $description";
  print("<li>$text</li>\n");
}

?>
<? if ($CURUSER) { ?>
<p><a href=sendmessage.php?receiver=1>Please report dead links!</a></p>
<? } ?>
<table width=750 class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>

<h2>BitTorrent Information</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text><ul>
<li><a class=altlink href=http://dessent.net/btfaq/>Brian's BitTorrent FAQ and Guide</a> -
  Everything you need to know about BitTorrent. Required reading for all n00bs.</font>
</ul></td></tr></table>

<h2>BitTorrent Software</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text><ul>
<li><a class=altlink href=http://azureus.sourceforge.net/>Azureus</a> -
  "Azureus is a java bittorrent client. It provides a quite full bittorrent protocol implementation using java language."</li>
<li><a class=altlink href=http://utorrent.com/>utorrent</a> -
  "uTorrent is an efficient and feature rich BitTorrent client for Windows sporting a very small footprint."</li>
<li><a class=altlink href=http://krypt.dyndns.org:81/torrent/maketorrent/>MakeTorrent</a> -
  A tool for creating torrents.</li>
</ul></td></tr></table>

<h2>Forum communities</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text><ul>
<li><a class=altlink href=http://www.filesoup.com/>Filesoup</a> -
  BitTorrent community.</li>
</ul></td></tr></table>

<h2>Other sites</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text><ul>
<li><a class=altlink href=http://www.nforce.nl/>NFOrce</a> -
  Game and movie release tracker / forums.</li>
<li><a class=altlink href=http://www.izonews.com/>iSONEWS</a> -
  Release tracker and forums.</li>
</ul></td></tr></table>

<h2>Link to <?= $SITENAME?></h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>
Do you want a link to <?= $SITENAME?> on your homepage?<br>
Copy the following and paste it into your homepage code.<br>
<br>
<font color=#004E98>
&lt;!-- <?= $SITENAME?> Link --&gt;<br>
<br>
&lt;a href="<?= $DEFAULTBASEURL?>"&gt;<br>
&lt;img src="<?= $DEFAULTBASEURL?>/pic/tbani22.gif" border="0" alt="<?= $SITENAME?> - We supply the latest stuff!"&gt;&lt;/a&gt;<br>
<br>
&lt;!-- End of <?= $SITENAME?> Link --&gt;</font><br>
<br>
<br>
It will look like this:<br>
<br>
<a href="<?= $DEFAULTBASEURL?>">
<img src="<?= $DEFAULTBASEURL?>/pic/tbani22.gif" border="0" alt="<?= $DEFAULTBASEURL?> - We supply the latest stuff!"></a>
<br>
</td></tr></table>
<p align=right><font size=1 color=#004E98><b>Links edited 2006-12-22</b></font></p>
</td></tr></table>
<? if ($CURUSER) { ?>
<? } ?>

<?php

stdfoot();

?>