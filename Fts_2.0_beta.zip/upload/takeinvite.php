<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: takrinvite.php - Invite System.                                  |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

hit_start();

dbconn();

function bark($msg) {
  stdhead();
	stdmsg("Invitation failed!", $msg);
  stdfoot();
  exit;
}

$id = 0 + $_GET["id"];

$email = unesc($_POST["email"]);
if(!$email)
bark("You need to submit an email address!");

$body = unesc($_POST["body"]);
if(!$body)
bark("Please add a personal message.");


// check if email addy is already in use
$a = (@mysql_fetch_row(@mysql_query("select count(*) from users where email='$email'"))) or die(mysql_error());
if ($a[0] != 0)
  bark("The e-mail address $email is already in use.");
  

  
  
  
  

$ret = mysql_query("SELECT username FROM users WHERE id = $id") or sqlerr();
$arr = mysql_fetch_assoc($ret); 
  
  
$hash  = md5(mt_rand(1,10000));


$message = <<<EOD
Hello,

You have been invited to join the YOUR_SITE_HERE community by {$arr[username]}.
If you want to accept this invitation, you'll need to click this link:


$BASEURL/register.php?invitenumber=$hash


You'll need to accept the invitation within 24 hours, or else the link will become inactive.
We on YOUR_SITE_HERE hope that you'll accept the invitation and join our great community!

Personal message from {$arr[username]}:
$body


----------------
If you do not know the person who has invited you, please forward this email to admin@YOUR_SITE_HERE
EOD;
mail($email, "$SITENAME Invitation Confirmation", $message, "From: $SITEEMAIL");

mysql_query("INSERT INTO invites (inviter, invitee, hash, time_invited) VALUES ('$id', '$email', '$hash', '" . get_date_time() . "')");
mysql_query("UPDATE users SET invites = invites - 1 WHERE id = $id") or sqlerr(__FILE__, __LINE__);

header("Refresh: 0; url=invite.php?id=$id&type=new");

hit_end();

?>  
  
  
    

