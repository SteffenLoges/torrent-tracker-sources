<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: edit.php - Edit an torrent.                                      |
// | Version: 2.3                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");
?>
<script language="javascript" type="text/javascript" src="../jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
tinyMCE.init({
	  theme : "advanced",
    mode: "exact",
elements: "descr",
		plugins : "devkit,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,|,code",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom",
		content_css : "example_full.css",
	    plugin_insertdate_dateFormat : "%Y-%m-%d",
	    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "example_link_list.js",
		external_image_list_url : "example_image_list.js",
		flash_external_list_url : "example_flash_list.js",
		media_external_list_url : "example_media_list.js",
		template_external_list_url : "example_template_list.js",
		file_browser_callback : "fileBrowserCallBack",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true,
		nonbreaking_force_tab : true,
		apply_source_formatting : true,

});
</script>
<?
if (!mkglobal("id"))
        die();

$id = 0 + $id;
if (!$id)
        die();

dbconn();

loggedinorreturn();

$res = mysql_query("SELECT * FROM torrents WHERE id = $id");
$row = mysql_fetch_array($res);
if (!$row)
        die();

stdhead(edt1."\"" . $row["name"] . "\"");

if (!isset($CURUSER) || ($CURUSER["id"] != $row["owner"] && get_user_class() < UC_MODERATOR)) {
        print("<h1>".edt2."</h1>\n");
        print("<p>".edt3."</p>\n");
}
else {
        print("<form name=editupload method=post action=takeedit.php enctype=multipart/form-data>\n");
        print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
        if (isset($_GET["returnto"]))
                print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" />\n");
        print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\">\n");
        tr(edt4, "<input type=\"text\" name=\"name\" value=\"" . htmlspecialchars($row["name"]) . "\" size=\"80\" />", 1);

        tr(edt5, "<input type =\"text\" name=\"description\" size=\"80\" value=\"" .htmlspecialchars($row["description"]). "\"><br>".edt6, 1);
        tr('Torrent Image', "<input type =\"text\" name=\"t_image\" size=\"80\" value=\"" .htmlspecialchars($row["t_image"]). "\"><br> The image of the torrent", 1);
        tr(edt7, "<input type=radio name=nfoaction value='keep' checked>".edt8."<br>".
        "<input type=radio name=nfoaction value='update'>".edt9.":<br><input type=file name=nfo size=80>", 1);
if ((strpos($row["ori_descr"], "<") === false) || (strpos($row["ori_descr"], "&lt;") !== false))
  $c = "";
else
  $c = " checked";
tr("Description","<textarea name=descr id=descr rows=15 cols=90>".$row[ori_descr]."</textarea>",1);
       /* print("<tr><td class=rowhead style='padding: 10px'>".edt10."</td><td align=center style='padding: 3px'>");
 textbbcode("editupload","descr","$row[ori_descr]");
        print("</td>\n");
*/
        $s = "<select name=\"type\">\n";

        $cats = genrelist();
        foreach ($cats as $subrow) {
                $s .= "<option value=\"" . $subrow["id"] . "\"";
                if ($subrow["id"] == $row["category"])
                        $s .= " selected=\"selected\"";
                $s .= ">" . htmlspecialchars($subrow["name"]) . "</option>\n";
        }

        $s .= "</select>\n";
        tr(edt11, $s, 1);
        tr(edt12, "<input type=\"checkbox\" name=\"visible\"" . (($row["visible"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" /> ".edt13, 1);
        if(get_user_class()>=UC_SYSOP)
        tr("Free download", "<input type='checkbox' name='free'" . (($row["free"] == "yes") ? " checked='checked'" : "" ) . " value='1' /> Free download (only upload stats are recorded)", 1);
        if(get_user_class()>=UC_SYSOP)
               tr("Silver download", "<input type='checkbox' name='silver'" . (($row["silver"] == "yes") ? " checked='checked'" : "" ) . " value='1' /> Silver download (only a half of download stats are recorded)", 1);
        tr(edt14, "<input type=\"checkbox\" name=\"anonymous\"" . (($row["anonymous"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" />  ".edt15, 1);

        if ($CURUSER["admin"] == "yes")
                tr(edt16, "<input type=\"checkbox\" name=\"banned\"" . (($row["banned"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" /> Banned", 1);

        print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value='".edt17."' style='height: 25px; width: 100px'> <input type=reset value='Revert changes' style='height: 25px; width: 100px'></td></tr>\n");
        print("</table>\n");
        print("</form>\n");
        print("<p>\n");
        print("<form method=\"post\" action=\"delete.php\">\n");
  print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");
  print("<tr><td class=embedded style='background-color: #F5F4EA;padding-bottom: 5px' colspan=\"2\">".edt18);
  print("<td><input name=\"reasontype\" type=\"radio\" value=\"1\">\n".edt19);
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"2\">&nbsp;".edt20."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\"></td></tr>\n");
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"3\">&nbsp;".edt21."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\"></td></tr>\n");
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"4\">&nbsp;".edt22."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\">(req)</td></tr>");
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"5\" checked>&nbsp;".edt23."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\">(req)</td></tr>\n");
        print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
        if (isset($_GET["returnto"]))
                print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" />\n");
  print("<td colspan=\"2\" align=\"center\"><input type=submit value='".edt24."' style='height: 25px'></td></tr>\n");
  print("</table>");
        print("</form>\n");
        print("</p>\n");
}

stdfoot();

?>