<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: register.php - Invite System.                                    |
// | Version: 0.1                                                            |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

dbconn();
if($invitesys == 'no') stderr('Error!','Invite system is off');
$code = $HTTP_GET_VARS["invitenumber"];

$nuIP = getip(); 
  $dom = @gethostbyaddr($nuIP); 
  if ($dom == $nuIP || @gethostbyname($dom) != $nuIP) 
    $dom = ""; 
  else 
  { 
    $dom = strtoupper($dom); 
    preg_match('/^(.+)\.([A-Z]{2,3})$/', $dom, $tldm); 
    $dom = $tldm[2]; 
  }

$res = mysql_query("SELECT inviter FROM invites WHERE hash = '$code'") or sqlerr();
$inv = mysql_fetch_assoc($res);  
  
stdhead("Signup");

print("<p><form method=post action=takereg.php?inviter=$inv[inviter]>".
"<table border=1 cellspacing=0 cellpadding=10 width=750>");
if (!$inv){
print("<tr class=tableb><td align=left><b>Hey! You aren't invited. Bugger off....</b></td></tr>");
} else {
print("<tr class=tabletitle><td align=center colspan=2><b>Welcome! You have accepted an invitation from one of our users. You can now register.</b></td></tr>"); ?>
<tr class=tableb><td align="left" width=20%>Desired username:</td><td align=left><input type="text" size="40" name="wantusername" /><font color=red>&nbsp;*</font><br>
Allowed Characters: (a-z), (A-Z), (0-9)</td></tr>
<tr class=tableb><td align="left">Pick a password:</td><td align=left><input type="password" size="40" name="wantpassword" /><font color=red>&nbsp;*</font></td></tr>
<tr class=tableb><td align="left">Enter password again:</td><td align=left><input type="password" size="40" name="passagain" /><font color=red>&nbsp;*</font></td></tr>
<tr valign=top class=tableb><td align="left">Email address:</td><td align=left><input type="text" size="40" name="email" /><font color=red>&nbsp;*</font>
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>The email address must be valid.</td></tr>
</font></td></tr></table>
</td></tr>
<? $ct_r = mysql_query("SELECT id,name from countries ORDER BY name") or die; 
while ($ct_a = mysql_fetch_array($ct_r)) { 
  $countries .= "\t\t\t\t\t\t<option value=\"$ct_a[id]\""; 
  if ($dom == $ct_a["domain"]){ 
      $countries .= " SELECTED"; 
  } 
    $countries .= ">$ct_a[name]</option>\n"; 
  } ?>
<tr class=tableb><td align="left">Country</td><td align=left><select name=country><?=$countries?></select><font color=red>&nbsp;*</font></td></tr>
</td></tr>
<tr class=tableb><td align="left">Gender</td><td align=left>
<input type=radio name=gender value=Male>Male <input type=radio name=gender value=Female>Female <font color=red>&nbsp;*</font></td></tr>
<tr class=tableb><td>Varification</td><td align=left><input type=checkbox name=rulesverify value=yes> I have read the site <a href=rules.php><u>rules</u></a> page. <font color=red>&nbsp;*</font><br>
<input type=checkbox name=faqverify value=yes> I agree to read the <a href=faq.php><u>FAQ</u></a> before asking questions. <font color=red>&nbsp;*</font><br>
<input type=checkbox name=ageverify value=yes> I am at least 13 years old. <font color=red>&nbsp;*</font></td></tr>
<input type=hidden name=hash value=<?=$code?>>
<tr><td colspan="2" align="center"><font color=red>*</font> Required Fields</font><br><input type=submit value="Sign up! (PRESS ONLY ONCE)" style='height: 25px'></td></tr>
<? } ?>
</table>
</form>

<?


stdfoot();

?>
