<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: browse.php - Torrents Browser.                                   |
// | Version: 3.2                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

dbconn();
loggedinorreturn();


parked();
global $BASEURL;
?>
<?
function show_image($text,$size=300)
{
$content = 'onmouseover="ddrivetip(\''.$text.'\', '.$size.')"; onmouseout="hideddrivetip()"';
return $content;
}
?>
<?

//$wherethisuser = where ($_SERVER["SCRIPT_FILENAME"],$CURUSER["id"]);
$cats = genrelist();

$searchstr = ($_GET['search'] ? unesc($_GET['search']) : '');
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
	unset($cleansearchstr);
if (isset($_GET['sort']) && isset($_GET['type'])) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
	case '1': $column = "name"; break;
	case '2': $column = "numfiles"; break;
	case '3': $column = "comments"; break;
	case '4': $column = "added"; break;
	case '5': $column = "size"; break;
	case '6': $column = "times_completed"; break;
	case '7': $column = "seeders"; break;
	case '8': $column = "leechers"; break;
	case '9': $column = "owner"; break;
	default: $column = "id"; break;
}

switch($_GET['type']) {
	case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
	case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
	default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
}

$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";

} else {
	$orderby = "ORDER BY torrents.id DESC";
	$pagerlink = "";
	}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
	$addparam .= "incldead=1&";
	if (!$CURUSER || get_user_class() < UC_ADMINISTRATOR)
		$wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
	$addparam .= "incldead=2&";
		$wherea[] = "visible = 'no'";
}
elseif ($_GET["incldead"] == 3)
{
	$addparam .= "incldead=3&";
	$wherea[] = "free = 'yes'";
	$wherea[] = "visible = 'yes'";
}
elseif ($_GET["incldead"] == 4)
{
$addparam .= "incldead=4&";
$wherea[] = "silver = 'yes'";
       $wherea[] = "visible = 'yes'";
}
elseif ($_GET['incldead'] == 5)
{
	$addparam .= "incldead=5&";
	$wherea[] = "external != ''";
	$wherea[] = "visible = 'yes'";
}
else
	$wherea[] = "visible = 'yes'";
$category = ($_GET["cat"] ? $_GET["cat"] : '');

$all = ($_GET["all"] ? $_GET["all"] : '');

if (!$all)
	if (!$_GET && $CURUSER['notifs'])
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $cat[id];
	    $mystring = $CURUSER['notifs'];
		$findme  = '[cat'.$cat['id'].']';
		$search = strpos($mystring, $findme);
		if ($search === false)
			$catcheck = false;
		else
			$catcheck = true;
			
	    if ($catcheck)
	    {
	      $wherecatina[] = $cat[id];
	      $addparam .= "c$cat[id]=1&";
	    }
	  }
	}
	elseif ($category)
	{
	  int_check($category,true,true,true);
	  $wherecatina[] = $category;
	  $addparam .= "cat=$category&";
	}
	else
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $_GET["c$cat[id]"];
	    if ($_GET["c$cat[id]"])
	    {
	      $wherecatina[] = $cat['id'];
	      $addparam .= "c$cat[id]=1&";
	    }
	  }
	}

if ($all)
{
	$wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
	$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
	$wherea[] = "category = $wherecatina[0]";

$wherebase = $wherea;

if ($cleansearchstr)
{
	$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";	
	$addparam .= "search=" . urlencode($searchstr) . "&";	
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
	$where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
	$where = "WHERE $where";

$res = sql_query("SELECT COUNT(*) FROM torrents $where") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && $cleansearchstr) {
	$wherea = $wherebase;
	$searcha = explode(" ", $cleansearchstr);
	$sc = 0;
	foreach ($searcha as $searchss) {
		if (strlen($searchss) <= 1)
			continue;
		$sc++;
		if ($sc > 5)
			break;
		$ssa = array();
		foreach (array("search_text", "ori_descr") as $sss)
			$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
		$wherea[] = "(" . implode(" OR ", $ssa) . ")";
	}
	if ($sc) {
		$where = implode(" AND ", $wherea);
		if ($where != "")
			$where = "WHERE $where";
		$res = sql_query("SELECT COUNT(*) FROM torrents $where");
		$row = mysql_fetch_array($res);
		$count = $row[0];
	}
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
	$torrentsperpage = 20;

if ($count)
{
	if ($addparam != "") {
 if ($pagerlink != "") {
  if ($addparam{strlen($addparam)-1} != ";") {
    $addparam = $addparam . "&" . $pagerlink;
  } else {
    $addparam = $addparam . $pagerlink;
  }
 }
    } else {
	$addparam = $pagerlink;
    }
	list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);

	$query = "SELECT torrents.id, torrents.category, torrents.leechers, torrents.seeders, torrents.name, torrents.times_completed, torrents.t_image, torrents.size, torrents.free, torrents.added, torrents.silver, torrents.comments,torrents.numfiles,torrents.description,torrents.filename,torrents.anonymous,torrents.owner,torrents.external,IF(torrents.nfo <> '', 1, 0) as nfoav," .
	"IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name,categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	"categories.name AS cat_name, categories.minclassread AS minclassread, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	$res = sql_query($query) or sqlerr(__FILE__, __LINE__);
}
else
	unset($res);

if ($cleansearchstr)
	stdhead('Search results for '.$searchstr);
else
	stdhead();

$catdropdown = "";
foreach ($cats as $cat) {
	if ($CURUSER['class'] < $cat['minclassread'])
			continue;
	$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
	if ($_GET['cat'])
		if ($cat['id'] == $_GET['cat'])
			$catdropdown .= " selected=\"selected\"";
	$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}
?>

<FIELDSET>
	<LEGEND><b>Search torrent</b></LEGEND>
<div align=left>
<form method="get" action="browse.php" name="search_form" id="search_form">
<?print(br1);?> <input type="text" name="search" autocomplete="off" ondblclick="suggest(event.keyCode,this.value);" onkeyup="suggest(event.keyCode,this.value);" onkeypress="return noenter(event.keyCode);" value="<?= htmlspecialchars($searchstr) ?>" id="searchinput" style="width:250px;"/>

<select name="cat" style="width: 145px;">
<option value="0" style="color: gray;"><?print(br2);?></option>
<?=$catdropdown;?>
</select>
<input type="checkbox" name="incldead" value="1" <?=($_GET['incldead'] ? ' checked' : '')?>/> <?print(br3);?> 
<input type="submit" value="<?print(br4);?>" class="btn" />

<div style="left:83px; position: relative;">

</form>
<script language="JavaScript" src="scripts/suggest.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 520px; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>
</div>
</FIELDSET>
<fieldset>
<legend><B>Categories</b></legend>

<table border="0" cellpadding="0" cellspacing="0" width="96%">

<tr><td>
<form method="get" action="browse.php" name="categorysearch">
<center>
<table class=bottom>
<tr>
<td class=bottom>
	<table class=bottom>
	<tr>

<?
$i = 0;
foreach ($cats as $cat)
{
		/*if ($CURUSER['class'] < $cat['minclassread'])
			continue;*/
        $catsperrow = 5;
        print(($i && $i % $catsperrow == 0) ? "</tr><tr>" : "");
        print("<td class=bottom style=\"padding-bottom: 2px;padding-left: 5px\"><div align=\"right\"><a class=catlink href=browse.php?cat=$cat[id]>" . htmlspecialchars($cat['name']) . "</a><input name=c$cat[id] type=\"checkbox\" " . (in_array($cat['id'], $wherecatina) ? "checked " : "") . "value=\"1\"></div></td>\n");
        $i++;
}

$alllink = "<div align=left>(<a href=browse.php?all=1>".br5."</a>)</div>";

$ncats = count($cats);
$nrows = ceil($ncats/$catsperrow);
$lastrowcols = $ncats % $catsperrow;

if ($lastrowcols != 0)
{
	if ($catsperrow - $lastrowcols != 1)
		{
			print("<td class=bottom rowspan=" . ($catsperrow  - $lastrowcols - 1) . ">&nbsp;</td>");
		}
	print("<td class=bottom style=\"padding-left: 5px\">$alllink</td>\n");
}
?>
	</tr>
	</table>
</td>

<table class=main align=center>
	<tr>	
		<td class=bottom>			<select name="incldead" style="width: 145px;">
				<option value="0" style="color: gray;"><?print(br6);?></option>
				<option value="1"<? print($_GET["incldead"] == 1 ? " selected" : ""); ?>><?print(br7);?></option>
				<option value="2"<? print($_GET["incldead"] == 2 ? " selected" : ""); ?>><?print(br8);?></option>
<? /*				<option value="3"<? print($_GET["incldead"] == 3 ? " selected" : ""); ?>>Free</option>*/?>
<option value="3"<? print($_GET["incldead"] == 3 ? " selected" : ""); ?>>FREE</option>
<option value="4"<? print($_GET["incldead"] == 4 ? " selected" : ""); ?>>SILVER</option>
<option value="5"<? print($_GET["incldead"] == 5 ? " selected" : ""); ?>>External Only</option>
			</select>
  	</td>
  	<td class=bottom>
  	<input type="submit" value="<?print(br9);?>" onlick="javascript:document.categorysearch.submit();" class=btn>
	<input type="button" value="<?print(br10);?>" onClick="this.value=check(form)" class="btn">  	
  	</td>
  </tr>
</table>
</td>
</tr>
</table>
</form>
</fieldset>
<? /*
# begin showlastXtorrents
		$extra1 = ($showimages == 'yes' ? ",torrents.t_image," : ",torrents.added,torrents.seeders,torrents.leechers,");
		$extra2 = ($showimages == 'yes' ? " AND torrents.t_image != '' " : "");		
		$colspan = ($showimages == 'yes' ? "5" : "4");
		$sql = 'SELECT id,name,t_image FROM torrents WHERE visible = \'yes\' ORDER BY added DESC LIMIT 5';
		$result = sql_query($sql);
		if( mysql_num_rows($result) != 0 )
		{
			$showlastXtorrents = '

			<!-- begin showlastXtorrents -->
			<br />
			<script type="text/javascript">
				function borderit(which,color)
				{
					if (document.all||document.getElementById)
					{
						which.style.borderColor=color
					}
				};
			</script>
			<table border="0" cellspacing="0" cellpadding="5" width="100%">
				<tr>
					<td align="center" class="thead" colspan="'.$colspan.'">
						'.ts_collapse('showlastXtorrents').'
						'.$lang->browse['recommendtorrents'].'
					</td>
				</tr>';
				if ($showimages != 'yes')
					$showlastXtorrents .= '
						<tr>
							<td class="subheader" align="left">'.$lang->index['name'].'</td>
							<td class="subheader" align="left">'.$lang->index['uploaddat'].'</td>
							<td class="subheader" align="center">'.$lang->index['seeders'].'</td>
							<td class="subheader" align="center">'.$lang->index['leechers'].'</td>
						</tr>';
				else
					$showlastXtorrents .= '												
						'.ts_collapse('showlastXtorrents', 2).'
						<tr>';
			
			$i_count = $i_done = 0;
			while( $row = mysql_fetch_assoc($result) )
			{
				if ($usergroups['canviewviptorrents'] != 'yes' && $row['vip'] == 'yes')
					continue;
				$seolink = ts_seo($row['id'], $row['name'], 's');
				$fullname = htmlspecialchars_uni($row['name']);
				if ($showimages != 'yes')
				{
					$added = my_datee($dateformat, $row['added']).' '.my_datee($timeformat, $row['added']);

					$showlastXtorrents .= '
					<tr>
						<td align="left">
							<a href="'.$seolink.'" alt="'.$fullname.'" title="'.$fullname.'"><b>' . cutename($fullname, 50) . '</b></a>
						</td>
						<td align="left">
							' . $added . '
						</td>
						<td align="center">
							' . ts_nf($row['seeders']) . '
						</td>
						<td align="center">
							' . ts_nf($row['leechers']) . '
						</td>	
					</tr>';
				}
				else
				{
					if ($i_count > 0 && $i_count % 5 == 0)
					{
						$showlastXtorrents .= '
						</tr>
						<tr>';
					}
					$showlastXtorrents .= '
						<td align="center" class="tcat">
							<a href="'.$seolink.'"><img src="'.htmlspecialchars_uni($row['t_image']).'" width="125" height="125" alt="' . $fullname . '" title="' . $fullname . '" class="borderimage" onmouseover="borderit(this,\'black\')" onmouseout="borderit(this,\'white\')" /></a>
						</td>';
					$i_count++;
				}				
			}
			$trows = $i_torrent_limit - $i_count;
			if ($trows > 0 && $i_count > 0)
			{
				for ($i = 0; $i < $trows; $i++)
				{
					$showlastXtorrents .= '<td> </td>';
				}
			}
			$showlastXtorrents .= ($showimages == 'yes' ? '</tr>' : '').'					
				</tbody>
			</table>
			<!-- end showlastXtorrents -->';
			echo $showlastXtorrents;
	}

# end showlastXtorrents 
<script type="text/javascript" src="scripts/collapse.js"></script>
<a href="#" onclick="return toggle_collapse('showlastXtorrents');"></a>
<!-- begin showlastXtorrents -->
			<br />
			<script type="text/javascript">
				function borderit(which,color)
				{
					if (document.all||document.getElementById)
					{
						which.style.borderColor=color
					}
				};
			</script>
			<div id="mydiv" style="display:none"><h3>This is a test!<br>Can you see me?</h3></div>
			<table border="0" cellspacing="0" cellpadding="5" width="100%">
				<tr>
					<td align="center" class="thead" colspan="5">

						<a href="javascript:;" onmousedown="if(document.getElementById('mytable').style.display == 'none'){ document.getElementById('mytable').style.display = ''; }else{ document.getElementById('mytable').style.display = 'none'; }" style="float:right;">Toggle Div Visibility</a>
						Recommend Torrents
					</td>
				</tr>												
						<tbody  id="mytable" style="display:none;">
						<tr>
						<td align="center" class="tcat">
							<a href="http://www.torentcrestin.net/details.php?id=5049&hit=1"><img src="http://aycu26.webshots.com/image/28705/2000086915331493471_rs.jpg" width="125" height="125" alt="Exodus (1960) [Rom.sub]" title="Exodus (1960) [Rom.sub]" class="borderimage" onmouseover="borderit(this,'black')" onmouseout="borderit(this,'white')" /></a>
						</td>
						<td align="center" class="tcat">

							<a href="http://www.torentcrestin.net/details.php?id=5010&hit=1"><img src="http://graphics.christianbook.com/g/slideshow/0/001299/main/001299_1_ftc_dp.jpg" width="125" height="125" alt="Behind the Sun" title="Behind the Sun" class="borderimage" onmouseover="borderit(this,'black')" onmouseout="borderit(this,'white')" /></a>
						</td>
						<td align="center" class="tcat">
							<a href="http://www.torentcrestin.net/details.php?id=4883&hit=1"><img src="http://www.torentcrestin.net/torrents/images/4883.jpg" width="125" height="125" alt="The Legend Of The Three Trees - DVD(ISO)" title="The Legend Of The Three Trees - DVD(ISO)" class="borderimage" onmouseover="borderit(this,'black')" onmouseout="borderit(this,'white')" /></a>
						</td>
						<td align="center" class="tcat">
							<a href="http://www.torentcrestin.net/details.php?id=4867&hit=1"><img src="http://blackehart.net/sitebuilder/images/Picture_008-539x401.jpg" width="125" height="125" alt="First Landing - Debarcarea (2007) + sub ro" title="First Landing - Debarcarea (2007) + sub ro" class="borderimage" onmouseover="borderit(this,'black')" onmouseout="borderit(this,'white')" /></a>
						</td>
						<td align="center" class="tcat">

							<a href="http://www.torentcrestin.net/details.php?id=4813&hit=1"><img src="http://www.torentcrestin.net/torrents/images/4813.jpg" width="125" height="125" alt="Tabara tineretului crestin la Cortul Intalnirii - Budureasa 2007 - ziua a 3-a" title="Tabara tineretului crestin la Cortul Intalnirii - Budureasa 2007 - ziua a 3-a" class="borderimage" onmouseover="borderit(this,'black')" onmouseout="borderit(this,'white')" /></a>
						</td></tr>					
				</tbody>
			</table>
			<!-- end showlastXtorrents -->*/ 
$a = 'test';
			fts_collapse('faqtable1','test',$a);?>
			
<?print(br11);?>
<?

if (isset($cleansearchstr))
print("<h2>".br12." \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
        print($pagertop);

        torrenttable($res);

        print($pagerbottom);
}
else {
        if (isset($cleansearchstr)) {
                print("<h2>".br13."</h2>\n");
                print("<p>".br14."</p>\n");
        }
        else {
                print("<h2>".br15."</h2>\n");
                print("<p>".br16."</p>\n");
        }
}

if ($CURUSER)
// Torrents Needing Seeds mod
$need = mysql_query("SELECT id, name, leechers FROM torrents WHERE seeders = 0 AND leechers > 0 ORDER BY leechers DESC") or sqlerr();
if(mysql_num_rows($need))
{
echo("<h2>".br17.": $num</h2><table width=100% border=1 cellspacing=0 cellpadding=10><td align=left>");
while($res = mysql_fetch_assoc($need))
{
 echo("<a href=details.php?id=$res[id]><b>$res[name]</a> -<font color=red> ($res[leechers] leecher" . ($res[leechers] > 1 ? "s" : "") . ")</font></b><br>");
}


echo("</td></table>");
}

?>
<br>
<fieldset>
<legend><B>Legend</B></legend>
<div align=left>
<img src='pic/reload.gif' /> - External Torrent. If you click this image, the torrent's stats(seeders and leechers) will be updated.<br>
<img src='pic/freedownload.gif' /> - Free Torrent (only upload stats are recorded!).
<br>
<img src='pic/silverdownload.gif' /> - Silver Torrent (only 50% download stats are recorded!).<br>
<img src="pic/viewnfo.gif" /> - View torrent's NFO (viewable only to power users).<br>
</div>
</fieldset>
</td></tr></table>
<?
sql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);
stdfoot();
?>
 