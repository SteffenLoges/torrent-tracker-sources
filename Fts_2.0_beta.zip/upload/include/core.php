<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
// The new mods starts here

//---- Website Settings v0.1
function ReadConfig ($configname) {
	global $rootpath,$BASEURL;
    if (strstr($configname, ',')) {
        $configlist = explode(',', $configname);
        foreach ($configlist as $key=>$configname) {
            ReadConfig(trim($configname));
        }
    } else {
        $configname = basename($configname);
        $path = 'config/'.$configname;
        if (!file_exists($path)) {
            stderr("ERROR", "<font color=red>File [<b>".htmlspecialchars($configname)."</b>] doesn't exist!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
        }
        $fp = fopen($path, 'r');
        $content = '';
        while (!feof($fp)) {
            $content .= fread($fp, 102400);
        }
        fclose($fp);
        if (empty($content)) {
            if ($configname == 'XAM') {
                Header("Location: $BASEURL/index.php");  				
                die; 
            }
            return array();
        }
        $tmp        = @unserialize(base64_decode($content));
        if (empty($tmp)) {
            if ($configname == 'XAM') {
                Header("Location: $BASEURL/index.php");  				
                die;                
            }
            stderr("ERROR", "<font color=red>Cannot read file [<b>".htmlspecialchars($configname)."</b>]!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
        }
        $GLOBALS[$configname] = $tmp;
        return true;
    }
}

function WriteConfig ($configname, $config) {
	global $rootpath;
    $configname = basename($configname);
    $path = 'config/'.$configname;
    if (!file_exists($path) || !is_writable ($path)) {
        stdmsg("ERROR", "<font color=red>Cannot read file [<b>".htmlspecialchars($configname)."</b>]!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    $data = base64_encode(@serialize($config));
    if (empty($data)) {
        stdmsg("ERROR", "<font color=red>Cannot serialize file [<b>".htmlspecialchars($configname)."</b>]</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    $fp = @fopen ($path, 'w');
    if (!$fp) {
        stdmsg("ERROR", "<font color=red>Cannot open file [<b>".htmlspecialchars($configname)."</b>] to save info!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    $Res = @fwrite($fp, $data);
    if (empty($Res)) {
        stdmsg("ERROR", "<font color=red>Cannot save info in file (error in serialisation) [<b>".htmlspecialchars($configname)."</b>] to save info!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    fclose($fp);
    return true;
}
//for tbdev mods
function hit_start() {}
function hit_count() {}
function hit_end() {}

function GetVar ($name) {
    if ( is_array($name) ) {
        foreach ($name as $var) GetVar ($var);
    } else {
        if ( !isset($_REQUEST[$name]) )
            return false;
        if ( get_magic_quotes_gpc() ) {
            $_REQUEST[$name] = ssr($_REQUEST[$name]);
        }
        $GLOBALS[$name] = $_REQUEST[$name];
        return $GLOBALS[$name];
    }
}
function sql_query($query)
{	
	++$_SESSION['totalqueries'];
	return mysql_query($query);
}

function redirect($url, $message='', $title='', $wait=3, $usephp=false, $withbaseurl=true)
{
	global $SITENAME,$BASEURL,$defaulttemplate,$lang;

	if (empty($message))
		$message = $lang->global['redirect'];

	if(empty($title))
		$title = $SITENAME;
		
	$url = htmlspecialchars($url);
	$url = str_replace("&amp;", "&", $url);
	$url = ($withbaseurl ? $BASEURL.'/'.$url : $url);

	if ($usephp) {		
		header ("Location: $url");
		exit;
	}
	ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<head>
<title><?=$title;?></title>
<meta http-equiv="refresh" content="<?=$wait;?>;URL=<?=$url;?>" />
<link rel="stylesheet" href="<?=$BASEURL;?>/include/templates/<?=$defaulttemplate;?>/style/style.css" type="text/css" media="screen" />
</head>
<body>
<br />
<br />
<br />
<br />
<div style="margin: auto auto; width: 50%" align="center">
<table border="0" cellspacing="1" cellpadding="4" class="tborder">
<tr>
<td class="thead"><strong><a href=<?=$BASEURL;?>><?=$title;?></a></strong></td>
</tr>
<tr>
<td class="trow1" align="center"><p><font color=red><?=$message;?></font></p></td>
</tr>
<tr>
<td class="trow2" align="right"><a href="<?=$url;?>">
<span class="smalltext"><?=$lang->global['nowaitmessage'];?></span></a></td>
</tr>
</table>
</div>
</body>
</html>
<?php
	ob_end_flush();
	exit;
}

function ssr ($arg) {
    if (is_array($arg)) {
        foreach ($arg as $key=>$arg_bit) {
            $arg[$key] = ssr($arg_bit);
        }
    } else {
        $arg = stripslashes($arg);
    }
    return $arg;
}
function error($e = 'eror') {
print($e);
}
function get_extension($file)
{
	return strtolower(substr(strrchr($file, "."), 1));
}

function dir_list($dir)
{
	$dl = array();  
	$ext = '';
	if (!file_exists($dir))
		error();
	if ($hd = opendir($dir))
	{
		while ($sz = readdir($hd)) { 
		$ext = get_extension($sz);
		if (preg_match("/^\./",$sz) == 0 && $ext != 'php' && $sz != 'administrator-templates' && $sz != 'index.html' && $sz != 'default.css' && $sz != 'large.css')
			$dl[] = $sz;
		}
		closedir($hd);
		asort($dl);
		return $dl;
	}else
		error('','Couldn\'t open storage folder! Please check the path.');
}
function getmodules($dir)
{
	$dl = array();  
	$ext = '';
	if (!file_exists($dir))
		error();
	if ($hd = opendir($dir))
	{
		while ($sz = readdir($hd)) { 
		$ext = get_extension($sz);
		if (preg_match("/^\./",$sz) == 0 && $ext != 'php' && $sz != 'administrator-templates')
			$dl[] = $sz;
		}
		closedir($hd);
		asort($dl);
		return $dl;
	}else
		error('','Couldn\'t open storage folder! Please check the path.');
}
// Month code to month name by fr33bh
function mctom($m) {
switch($m) {
case '01':
$month = 'January';
break;
case '02':
$month = 'February';
break;
case '03':
$month = 'March';
break;
case '04':
$month = 'April';
break;
case '05':
$month = 'May';
break;
case '06':
$month = 'June';
break;
case '07':
$month = 'July';
break;
case '08':
$month = 'August';
break;
case '09':
$month = 'September';
break;
case '10':
$month = 'October';
break;
case '11':
$month = 'November';
break;
case '12':
$month = 'December';
break;
}
return $month;
}
function get_user_class_color($class, $username)
{
  global $tracker_lang;
  switch ($class)
  {
    case UC_SYSOP:
      return "<span style=\"color:#0F6CEE\" title=\"".$tracker_lang['class_sysop']."\">" . $username . "</span>";
      break;
    case UC_ADMINISTRATOR:
      return "<span style=\"color:green\" title=\"".$tracker_lang['class_administrator']."\">" . $username . "</span>";
      break;
    case UC_MODERATOR:
      return "<span style=\"color:red\" title=\"".$tracker_lang['class_moderator']."\">" . $username . "</span>";
      break;
     case UC_UPLOADER:
      return "<span style=\"color:orange\" title=\"".$tracker_lang['class_uploader']."\">" . $username . "</span>";
      break;
     case UC_VIP:
      return "<span style=\"color:#9C2FE0\" title=\"".$tracker_lang['class_vip']."\">" . $username . "</span>";
      break;
     case UC_POWER_USER:
      return "<span style=\"color:#D21E36\" title=\"".$tracker_lang['class_power_user']."\">" . $username . "</span>";
      break;
     case UC_USER:
      return "<span title=\"".$tracker_lang['class_user']."\">" . $username . "</span>";
      break;
  }
  return "$username";
}
function timer() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}
function int_check($value,$stdhead = false, $stdfood = true, $die = true, $log = true) {
	global $CURUSER,$BASEURL,$lang;	

	$msg = sprintf($lang->global['invalididlogmsg'], htmlspecialchars($_SERVER['REQUEST_URI']), '<a href='.$BASEURL.'/userdetails.php?id='.$CURUSER['id'].'>'.$CURUSER['username'].'</a>', getip(), get_date_time());

	if ( is_array($value) ) {
        foreach ($value as $val)
			int_check ($val,$stdhead,$stdfood,$die,$log);
    } else {
	    if (!is_valid_id($value)) {
		    if ($stdhead) {
			    if ($log)
		    		write_log($msg);
		    	stderr($lang->global['error'], $lang->global['invalididlogged']);
	    }else {			    
				Print ($lang->global['invalididlogged2']);
				if ($log)
					write_log($msg);
	    	}	    	
			
		    if ($stdfood)
		    	stdfoot();
		    if ($die)
		    	die;
	    }	    	
	    else
	    	return true;
    }
}
function tinyadvanced() { ?>
<!-- TinyMCE -->
<script language="javascript" type="text/javascript" src="../jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "devkit,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,youtube",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,separator,forecolor,backcolor,youtube",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,media,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,|,code",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom",
		content_css : "example_full.css",
	    plugin_insertdate_dateFormat : "%Y-%m-%d",
	    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "example_link_list.js",
		external_image_list_url : "example_image_list.js",
		flash_external_list_url : "example_flash_list.js",
		media_external_list_url : "example_media_list.js",
		template_external_list_url : "example_template_list.js",
		file_browser_callback : "fileBrowserCallBack",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true,
		nonbreaking_force_tab : true,
		apply_source_formatting : true,
		template_replace_values : {
			username : "Jack Black",
			staffid : "991234"
		}
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert("Example of filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = "someurl.htm";
	}
</script>
<!-- /TinyMCE -->
<?
}
// Variables for Start Time
$tstart = timer(); // Start time
function ahead() {
include'templates/administrator-templates/default/header.php';
}
function afoot() {
include'templates/administrator-templates/default/footer.php';
}
function make_style () {
	$style = '<style type="text/css">
	.curlycontainer{
	border: 1px solid #b8b8b8;
	margin-bottom: 1em;

	}
	.curlycontainer .innerdiv{
	background: transparent url(../pic/brcorner.gif) bottom right no-repeat;
	position: relative;
	left: 2px;
	top: 2px;
	padding: 1px 4px 15px 5px;
	}
	</style>';
	return $style;
}

function make_div ($text='') {
	$div = '<div class="curlycontainer">
		<div class="innerdiv">'.$text.'</div></div>';
	return $div;
}
function get_count ($name, $where = '', $extra = '') {
	$res = sql_query('SELECT COUNT(*) as '.$name.' FROM '.$where.' '.($extra ? $extra : ''));
	list($info[$name]) = mysql_fetch_array($res);
	return $info[$name];
}

function get_server_load()
{	
	if(strtolower(substr(PHP_OS, 0, 3)) === 'win')
	{
		return '<font color=red>Only Linux</font>';
	}
	elseif(@file_exists("/proc/loadavg"))
	{
		$load = @file_get_contents("/proc/loadavg");
		$serverload = explode(" ", $load);
		$serverload[0] = round($serverload[0], 4);
		if(!$serverload)
		{
			$load = @exec("uptime");
			$load = split("load averages?: ", $load);
			$serverload = explode(",", $load[1]);
		}
	}
	else
	{
		$load = @exec("uptime");
		$load = split("load averages?: ", $load);
		$serverload = explode(",", $load[1]);
	}
	$returnload = trim($serverload[0]);
	if(!$returnload)
	{
		$returnload = '<font color=red>Unknown</font>';
	}
	return $returnload;
}

function get_mysql_version(){		
	$query = sql_query("SELECT VERSION() as version");
	$ver = mysql_fetch_array($query);
	if($ver['version'])
	{
		$version = explode(".", $ver['version'], 3);
		$version = intval($version[0]).".".intval($version[1]).".".intval($version[2]);
	}
	return $version;
}
function make_help($hname,$type = '1') {
	if($type == '1') {
	?>
	<span class="small">[<a href='#' onclick="myRef = window.open('help/<?=$hname;?>.html','mywin',
'left=20,top=20,width=700,height=600,toolbar=0,resizable=0,scrollbars=1');"> Help </a>]</span>
<?
}}
function getlave() {
	?>
	<script type="text/javascript" src="scripts/jquery.js"></script>
 <script>
  $(document).ready(function(){
    $("#lave").load("lave.php?w=1");
  });
  </script>
	<?
	 print("<div id='lave'>loading</div>");
}
function getver() {
	?>
	<script type="text/javascript" src="scripts/jquery.js"></script>
 <script>
  $(document).ready(function(){
    $("#vwar").load("lave.php");
  });
  </script>
	<?
}
function pres($div=loading,$text = 'Please Wait') {
    
$text = $text;
$a = $t;
?>
<?
 PRINT('
 
 <head>
    
    <script type="text/javascript" src="scripts/preloader.js"></script></head>
     <div style="position:absolute;display:none;background:#FFF;text-align:center;border:1px solid #000" id="loading">
'.$a.''. $text.'
<BR>        <img alt="prealoder" title="Se incarca" src="pic/8-1.gif"/>       
     </div>');
   return  'onclick="javascript:showPreloader();"';
}
class mod {
function addadminicon($action,$img,$text) {
	?>
	<div style="float:left;">
			<div class="icon">
			<?	print('<a href="cpanel.php?action='.$action.'"'.pres().'>'); ?>
					<img src="<?=$img;?>"  width=64 height=64 align="middle" border="0" /><span><?=$text;?></span>
				</a>
			</div>
		</div>
		<?
}
function addindexblock($title,$c) {
	?><h2><?=$title;?></h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>
<table class=main border=1 cellspacing=0 cellpadding=5>
<?=$c;?>
</table>
</td></tr></table>
<?
}
}
function get_user_avatar() {
	global $CURUSER;
		$a = "<img src='".$CURUSER['avatar']."' />";
		return $a;
}
function pm_limit ($showlimit = true, $disablepm = false, $userid = '', $class = '')
{
	global $lang, $CURUSER, $usergroups;

	if (!$CURUSER OR !$usergroups)
		return false;

	if (!$userid AND !$disablepm)
		$userid = (int)$CURUSER['id'];
	
	if ($disablepm){
		$gid = intval($class) + 1;
		$getamount = sql_query('SELECT pmquote FROM usergroups WHERE id = '.sqlesc($gid));
		$amount = mysql_fetch_array($getamount);
		$maxpmstorage = (int)$amount['pmquote'];
	}else
		$maxpmstorage = (int)$usergroups['pmquote'];
	
	if ($maxpmstorage == 0)
		return;
	$query = sql_query('SELECT count(*) AS total FROM messages WHERE receiver = '.sqlesc($userid).'');
	$pmscount = mysql_fetch_array($query);
	if ($pmscount['total'] >= $maxpmstorage AND $disablepm)	
		return false;
	elseif ($showlimit) {
	if ($pmscount['total'] >= $maxpmstorage AND $maxpmstorage != '0') {
		$spaceused = 100;
		$spaceused2 = 0;
		$belowhalf = '';
		$overhalf = '100%';
		$warnmsg = '<table border="0" cellspacing="0" cellpadding="0" class="tborder">
		<tr>
		<td class="trow1" align="center"><span class="smalltext"><strong><font color="red">Warning. You have reached your message limit.</font></strong><br />To be able to receive messages you will need to delete old messages.</span></td>
		</tr></table><br>';
		$bloc = mysql_query("UPDATE users SET altrm = 'no' WHERE id='$userid' LIMIT 1");
	}else{
		$debloc = mysql_query("UPDATE users SET altrm = 'yes' WHERE id='$userid' LIMIT 1");
		$spaceused = $pmscount['total'] / $maxpmstorage * 100;
		$spaceused2 = 100 - $spaceused;
		$warnmsg = '';
		if($spaceused <= "50")
		{
			$belowhalf = round($spaceused, 0)."%";
		}
		else
		{
			$overhalf = round($spaceused, 0)."%";
		}
	}
	$msg = '
	<table border="0" cellspacing="0" cellpadding="5" class="tborder" width="100%">
	<tr>
	<td class="trow1" align="center"><p>You have <strong>'.$pmscount['total'].'</strong> messages stored, of a total <strong>'.$maxpmstorage.'</strong> allowed.</p>
	<table align=center cellspacing="0" cellpadding="0" width="230" style="border: solid 1px #000000;">
		<tr>
			<td width="'.$spaceused.'" bgcolor="red" align="center">
			<font color=black size=1><strong>'.$overhalf.'</font></span></td>
			<td width="'.$spaceused2.'" bgcolor="green" align="center">
			<font color=black size=1><strong>'.$belowhalf.'</font></span></td>
			<td width="130" align="center"><font color=black size=1><strong>of PM space used.</strong></font></td>
		</tr>
	</table></tr></td></table><br>';
	$msg = ($warnmsg ? $warnmsg.$msg : $msg);
	return $msg;
	
}
	 else{
			return true; }
}
$GLOBALS['mod'] = new mod;

?>
<?
function fts_collapse($ftable,$name,$content) {
	?>

<table border="0" cellspacing="0" cellpadding="0" style="width: 98%">
	<tr>
		<td class="eg-bar">
				<span id="<?=$ftable;?>-title" class="iconspan" style="float:right;"><img src="minus.gif" /></span><center><?=$name;?></center>
		</td>
	</tr>
<tr>
<td>
			<div id="<?=$ftable;?>" class="icongroup2">
			 <?=$content;?>
			</div>
			</td></tr>	


</table>

<script type="text/javascript">

var faqtable=new switchicon("icongroup2", "div") //Limit scanning of switch contents to just "div" elements
faqtable.setHeader('<img src="pic/minus.gif" />', '<img src="pic/plus.gif" />') //Set header HTML
faqtable.collapsePrevious(false) //Allow more than 1 content to be open simultanously
faqtable.setPersist(true, 7) //Enable persistence to remember last switch content states for 7 days
faqtable.init()

</script>
	<?
}
function fts_start_collapse($ftable,$name,$w = 100) {
?>
<table border="0" cellspacing="0" cellpadding="0" style="width: <?=$w;?>%">
	<tr>
		<td class="eg-bar">
				<span id="<?=$ftable;?>-title" class="iconspan" style="float:right;"><img src="minus.gif" /></span><center><?=$name;?></center>
		</td>
	</tr>
<tr>
<td>
			<div id="<?=$ftable;?>" class="icongroup2">
			<?	
}
function fts_end_collapse() {
	?>
				</div>
			</td></tr>	


</table>

<script type="text/javascript">

var faqtable=new switchicon("icongroup2", "div") //Limit scanning of switch contents to just "div" elements
faqtable.setHeader('<img src="pic/minus.gif" />', '<img src="pic/plus.gif" />') //Set header HTML
faqtable.collapsePrevious(false) //Allow more than 1 content to be open simultanously
faqtable.setPersist(true, 7) //Enable persistence to remember last switch content states for 7 days
faqtable.init()

</script>
<?
}
?>