/// Space for AJAX mods \\\
function ajax_createRequestObject(){
var ro;
var browser = navigator.appName;
if(browser == "Microsoft Internet Explorer"){
ro = new ActiveXObject("Microsoft.XMLHTTP");
} else{
ro = new XMLHttpRequest();
}
return ro;
}
var ajax_http = ajax_createRequestObject();
var ajax_destObj;
function sndReq(argumentString, destStr){
ajax_destObj = document.getElementById(destStr);
ajax_http.open('get', '/ajax.php?'+argumentString);
ajax_http.onreadystatechange = ajax_handleResponse;
ajax_http.send(null);
}
function ajax_handleResponse(){
if(ajax_http.readyState == 4){
var response = ajax_http.responseText;
//alert( response );
ajax_destObj.innerHTML = response;
} else if( http.readyState == 1 ){
// Uncomment the next line if you want
// to display a Loading text. This will
// cause the page to blink if lots of
// data is being transferred. I vote off.
// However, if your server is slow and
// you want to tell your users something
// is being processed, turn it on.
//ajax_destObj.innerHTML = 'Loading...';
}
}
//// END AJAX MODS \\\\