<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("bittorrent.php");
require_once 'benc.php';

// [MOD] Scrape External Torrents - �2005 tbdev.net - Laffin
class tsniff {
var $version = '1.0a';
var $class_name = 'TSniff';

var $url;
var $infohash;
var $seeders;
var $leechers;
var $completed;
var $name;
var $err=0;
var $error;

function doscrape()
{
$this->err=0;
$this->error=null;
if(empty($this->url)) {
$this->err=1;
$this->error = 'Empty url';
return($this->err=1);
}
$ch = curl_init();

curl_setopt ($ch, CURLOPT_URL, $this->url);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt ($ch, CURLOPT_AUTOREFERER, 0);
curl_setopt ($ch, CURLOPT_TIMEOUT, 4);
curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt ($ch, CURLOPT_MAXREDIRS, 5);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt ($ch, CURLOPT_USERAGENT, 'BitTornado/T-0.3.14a (TSniff 1.0.0 - Torrent Stats)');

$dict=$x=curl_exec ($ch);
if (curl_errno($ch)) {
$this->error= curl_error($ch);
$this->err=2;
} else {
curl_close($ch);
$dict=bdec($dict);
if(empty($dict))
{
$this->err=3;
$this->error="Invalid scrape results. $x";
echo $x;
} elseif($dict['type']!='dictionary') {
$this->err=4;
$this->error="Not a Dictionary";
} else {
$dict=$dict['value']['files'];
if(!empty($dict))
{
$dict=$dict['value'];
$ih=array_keys($dict);
$dict=$dict[$ih[0]];
$this->infohash=bin2hex(stripslashes($ih[0]));
$dict=$dict['value'];
$this->seeders=$dict['complete']['value'];
$this->leechers=$dict['incomplete']['value'];
$this->completed=$dict['downloaded']['value'];
$this->name=$dict['name']['value'];
} else {
$this->err=5;
$this->error="Invalid scrape info .'$x'";
}
}
}
if($this->err)
$this->seeds=$this->leechers=$this->completed=$this->name=$this->infohash=null;
return($this->err);
}

function tsniff($url)
{
$this->url=$url;
return($this->doscrape());
}

}

function docleanup() {
        global $torrent_dir, $signup_timeout, $max_dead_torrent_time, $autoclean_interval, $READPOST_EXPIRY;

        set_time_limit(0);
        ignore_user_abort(1);

        do {
                $res = mysql_query("SELECT id FROM torrents");
                $ar = array();
                while ($row = mysql_fetch_array($res)) {
                        $id = $row[0];
                        $ar[$id] = 1;
                }

                if (!count($ar))
                        break;

                $dp = @opendir($torrent_dir);
                if (!$dp)
                        break;

                $ar2 = array();
                while (($file = readdir($dp)) !== false) {
                        if (!preg_match('/^(\d+)\.torrent$/', $file, $m))
                                continue;
                        $id = $m[1];
                        $ar2[$id] = 1;
                        if (isset($ar[$id]) && $ar[$id])
                                continue;
                        $ff = $torrent_dir . "/$file";
                        unlink($ff);
                }
                closedir($dp);

                if (!count($ar2))
                        break;

                $delids = array();
                foreach (array_keys($ar) as $k) {
                        if (isset($ar2[$k]) && $ar2[$k])
                                continue;
                        $delids[] = $k;
                        unset($ar[$k]);
                }
                if (count($delids))
                        mysql_query("DELETE FROM torrents WHERE id IN (" . join(",", $delids) . ")");

                $res = mysql_query("SELECT torrent FROM peers GROUP BY torrent");
                $delids = array();
                while ($row = mysql_fetch_array($res)) {
                        $id = $row[0];
                        if (isset($ar[$id]) && $ar[$id])
                                continue;
                        $delids[] = $id;
                }
                if (count($delids))
                        mysql_query("DELETE FROM peers WHERE torrent IN (" . join(",", $delids) . ")");

                $res = mysql_query("SELECT torrent FROM files GROUP BY torrent");
                $delids = array();
                while ($row = mysql_fetch_array($res)) {
                        $id = $row[0];
                        if ($ar[$id])
                                continue;
                        $delids[] = $id;
                }
                if (count($delids))
                        mysql_query("DELETE FROM files WHERE torrent IN (" . join(",", $delids) . ")");
        } while (0);

        $deadtime = deadtime();
        mysql_query("DELETE FROM peers WHERE last_action < FROM_UNIXTIME($deadtime)");

        $deadtime -= $max_dead_torrent_time;
        mysql_query("UPDATE torrents SET visible='no' WHERE visible='yes' AND last_action < FROM_UNIXTIME($deadtime)");

        $deadtime = time() - $signup_timeout;
        mysql_query("DELETE FROM users WHERE status = 'pending' AND added < FROM_UNIXTIME($deadtime) AND last_login < FROM_UNIXTIME($deadtime) AND last_access < FROM_UNIXTIME($deadtime)");

        $torrents = array();
        $res = mysql_query("SELECT torrent, seeder, COUNT(*) AS c FROM peers GROUP BY torrent, seeder");
        while ($row = mysql_fetch_assoc($res)) {
                if ($row["seeder"] == "yes")
                        $key = "seeders";
                else
                        $key = "leechers";
                $torrents[$row["torrent"]][$key] = $row["c"];
        }

        $res = mysql_query("SELECT torrent, COUNT(*) AS c FROM comments GROUP BY torrent");
        while ($row = mysql_fetch_assoc($res)) {
                $torrents[$row["torrent"]]["comments"] = $row["c"];
        }

        $fields = explode(":", "comments:leechers:seeders");
        $res = mysql_query("SELECT id, seeders, leechers, comments FROM torrents");
        while ($row = mysql_fetch_assoc($res)) {
                $id = $row["id"];
                $torr = $torrents[$id];
                foreach ($fields as $field) {
                        if (!isset($torr[$field]))
                                $torr[$field] = 0;
                }
                $update = array();
                foreach ($fields as $field) {
                        if ($torr[$field] != $row[$field])
                                $update[] = "$field = " . $torr[$field];
                }
                if (count($update))
                        mysql_query("UPDATE torrents SET " . implode(",", $update) . " WHERE id = $id");
        }

        //delete inactive user accounts
        $secs = 42*86400;
        $dt = sqlesc(get_date_time(gmtime() - $secs));
        $maxclass = UC_POWER_USER;
        mysql_query("DELETE FROM users WHERE parked='no' AND status='confirmed' AND class <= $maxclass AND last_access < $dt");

        //delete parked user accounts
       $secs = 175*86400; // change the time to fit your needs
       $dt = sqlesc(get_date_time(gmtime() - $secs));
       $maxclass = UC_POWER_USER;
       mysql_query("DELETE FROM users WHERE parked='yes' AND status='confirmed' AND class <= $maxclass AND last_access < $dt");

        // lock topics where last post was made more than x days ago
        $secs = 7*86400;
        $res = mysql_query("SELECT topics.id FROM topics LEFT JOIN posts ON topics.lastpost = posts.id AND topics.sticky = 'no' WHERE " . gmtime() . " - UNIX_TIMESTAMP(posts.added) > $secs") or sqlerr(__FILE__, __LINE__);
        while ($arr = mysql_fetch_assoc($res))
                mysql_query("UPDATE topics SET locked='yes' WHERE id=$arr[id]") or sqlerr(__FILE__, __LINE__);

  //remove expired warnings
  $res = mysql_query("SELECT id FROM users WHERE warned='yes' AND warneduntil < NOW() AND warneduntil <> '0000-00-00 00:00:00'") or sqlerr(__FILE__, __LINE__);
  if (mysql_num_rows($res) > 0)
  {
    $dt = sqlesc(get_date_time());
    $msg = sqlesc("Your warning has been removed. Please keep in your best behaviour from now on.\n");
    while ($arr = mysql_fetch_assoc($res))
    {
      mysql_query("UPDATE users SET warned = 'no', warneduntil = '0000-00-00 00:00:00' WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
      mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
    }
  }
//=== remove VIP status if time up===//
//=== change class to whatever is under your vip class number
  $res = mysql_query("SELECT id, modcomment FROM users WHERE vip_added='yes' AND vip_until < NOW()") or sqlerr(__FILE__, __LINE__);
  if (mysql_num_rows($res) > 0)
  {
    $dt = sqlesc(get_date_time());
    $subject = sqlesc("VIP status removed by system."); //=== comment out this line if you DO NOT have subject in your PM system and change SITE NAME HERE to your site name duh :P
    $msg = sqlesc("Your VIP status has timed out and has been auto-removed by the system. Become a VIP again by donating to SITE NAME HERE, or exchanging some Karma Bonus Points. Cheers!\n");
    while ($arr = mysql_fetch_assoc($res))
    {
        ///---AUTOSYSTEM MODCOMMENT---//
     $modcomment = htmlspecialchars($arr["modcomment"]);
     $modcomment =  gmdate("Y-m-d") . " - VIP status removed by -AutoSystem.\n". $modcomment;
     $modcom =  sqlesc($modcomment);
     ///---end
      mysql_query("UPDATE users SET class = '2', vip_added = 'no', vip_until = '0000-00-00 00:00:00', modcomment = $modcom WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
    //  mysql_query("INSERT INTO messages (sender, receiver, added, msg, subject, poster) VALUES(0, $arr[id], $dt, $msg, $subject, 0)") or sqlerr(__FILE__, __LINE__);
      mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__); //=== use this line (and comment out the above line) if you DO NOT have subject in your PM system

    }
  }
  //===end===//

$todayd = date('d');
$todaym = date('m');
$reward = date('dmY');
$resb = mysql_query("SELECT * FROM users WHERE dob = $todayd AND mob = $todaym AND rewarded != $reward") or sqlerr(__FILE__, __LINE__);
        if (mysql_num_rows($resb) > 0)
        {
                $dt2 = sqlesc(get_date_time());
                $msg2 = sqlesc("Congratulations on your new birthday :). As a present for your birthday we gave you 5 GB to your upload bank. Happy birthday.\n");
                while ($arr2 = mysql_fetch_assoc($resb))
                {
                        mysql_query("UPDATE users SET uploaded = uploaded+5368709120 WHERE id = $arr2[id]") or sqlerr(__FILE__, __LINE__);
mysql_query("UPDATE users SET rewarded = '$reward' WHERE id = $arr2[id]") or sqlerr(__FILE__, __LINE__);
                        mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr2[id], $dt2, $msg2, 0)") or sqlerr(__FILE__, __LINE__);
                }
        }

        // promote power users
        $limit = 25*1024*1024*1024;
        $minratio = 1.05;
        $maxdt = sqlesc(get_date_time(gmtime() - 86400*28));
        $res = mysql_query("SELECT id FROM users WHERE class = 0 AND uploaded >= $limit AND uploaded / downloaded >= $minratio AND added < $maxdt") or sqlerr(__FILE__, __LINE__);
        if (mysql_num_rows($res) > 0)
        {
                $dt = sqlesc(get_date_time());
                $msg = sqlesc("Congratulations, you have been auto-promoted to [b]Power User[/b]. :)\nYou can  view torrent NFOs now.\n");
                while ($arr = mysql_fetch_assoc($res))
                {
                        mysql_query("UPDATE users SET class = 1 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
                        mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
                }
        }

        // demote power users
        $minratio = 0.95;
        $res = mysql_query("SELECT id FROM users WHERE class = 1 AND uploaded / downloaded < $minratio") or sqlerr(__FILE__, __LINE__);
        if (mysql_num_rows($res) > 0)
        {
                $dt = sqlesc(get_date_time());
                $msg = sqlesc("You have been auto-demoted from [b]Power User[/b] to [b]User[/b] because your share ratio has dropped below $minratio.\n");
                while ($arr = mysql_fetch_assoc($res))
                {
                        mysql_query("UPDATE users SET class = 0 WHERE id = $arr[id]") or sqlerr(__FILE__, __LINE__);
                        mysql_query("INSERT INTO messages (sender, receiver, added, msg, poster) VALUES(0, $arr[id], $dt, $msg, 0)") or sqlerr(__FILE__, __LINE__);
                }
        }

//=== Update karma seeding bonus  
    /******************************************************
    Use ONLY one of the two options below...
    the first is per torrents seeded, the second will only give the bonus for ONE torrent no matter how many are seeded.
    
    also you will have to play with how much bonus you want to give...
    ie: seedbonus+0.0225 = 0.25 bonus points per hour
        seedbonus+0.125 = 0.5 bonus points per hour
        seedbonus+0.225 = 1 bonus point per hour
    *****************************************************/
        
    //======use this part to give seeding bonus per torrent    
   $res = mysql_query("SELECT DISTINCT userid FROM peers WHERE seeder = 'yes'") or sqlerr(__FILE__, __LINE__);
    
   if (mysql_num_rows($res) > 0)
   {
       while ($arr = mysql_fetch_assoc($res))
       {
       $work = mysql_query("select count(*) from peers WHERE seeder ='yes' AND userid = $arr[userid]");
       $row_count = mysql_result($work,0,"count(*)");
       mysql_query("UPDATE users SET seedbonus = seedbonus+0.250*$row_count WHERE id = $arr[userid]") or sqlerr(__FILE__, __LINE__);
       }
   }     
   /*
   //==use this part to only give seeding bonus for 1 torrent no matter how many are being seeded
   $res = mysql_query("SELECT DISTINCT userid FROM peers WHERE seeder = 'yes'") or sqlerr(__FILE__, __LINE__);
   if (mysql_num_rows($res) > 0)
   {
       while ($arr = mysql_fetch_assoc($res))
       {
       mysql_query("UPDATE users SET seedbonus = seedbonus+0.225 WHERE id = $arr[userid]") or sqlerr(__FILE__, __LINE__);
       }
   }
   //===end
   */

        // Update stats
        $seeders = get_row_count("peers", "WHERE seeder='yes'");
        $leechers = get_row_count("peers", "WHERE seeder='no'");
        mysql_query("UPDATE avps SET value_u=$seeders WHERE arg='seeders'") or sqlerr(__FILE__, __LINE__);
        mysql_query("UPDATE avps SET value_u=$leechers WHERE arg='leechers'") or sqlerr(__FILE__, __LINE__);

        // update forum post/topic count
        $forums = mysql_query("select id from forums");
        while ($forum = mysql_fetch_assoc($forums))
        {
                $postcount = 0;
                $topiccount = 0;
                $topics = mysql_query("select id from topics where forumid=$forum[id]");
                while ($topic = mysql_fetch_assoc($topics))
                {
                        $res = mysql_query("select count(*) from posts where topicid=$topic[id]");
                        $arr = mysql_fetch_row($res);
                        $postcount += $arr[0];
                        ++$topiccount;
                }
                mysql_query("update forums set postcount=$postcount, topiccount=$topiccount where id=$forum[id]");
        }

        // delete old torrents
        $days = 28;
        $dt = sqlesc(get_date_time(gmtime() - ($days * 86400)));
        $res = mysql_query("SELECT id, name FROM torrents WHERE added < $dt and  leechers = '0' and seeders = '0'");
        while ($arr = mysql_fetch_assoc($res))
        {
                @unlink("$torrent_dir/$arr[id].torrent");
                mysql_query("DELETE FROM torrents WHERE id=$arr[id]");
                mysql_query("DELETE FROM peers WHERE torrent=$arr[id]");
                mysql_query("DELETE FROM comments WHERE torrent=$arr[id]");
                mysql_query("DELETE FROM files WHERE torrent=$arr[id]");
                write_log("Torrent $arr[id] ($arr[name]) was deleted by system (older than $days days)");
        }
global $uetoc;
if($uetoc == 'yes')
include'updatext.php';

//delete 4 weeks or 28 days old messages
    $secs = 28*86400; // the 4 weeks or 28 days
    $dt = sqlesc(get_date_time(gmtime() - $secs)); // the date
    mysql_query("DELETE FROM messages WHERE added < $dt AND unread = 'no'"); // the query

//Set IP for Mods and above
   $hour= 1*3600;
   $dt = sqlesc(get_date_time(gmtime() - $hour));
   mysql_query("UPDATE users SET ip = '127.0.0.0' WHERE  class >= " .  UC_MODERATOR . " AND  last_login < $dt") or sqlerr(__FILE__, __LINE__);

// Remove expired readposts...
    $dt = sqlesc(get_date_time(gmtime() - $READPOST_EXPIRY));

    mysql_query("DELETE readposts FROM readposts ".
        "LEFT JOIN posts ON readposts.lastpostread = posts.id ".
        "WHERE posts.added < $dt");

}

?>