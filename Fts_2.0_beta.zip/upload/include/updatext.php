<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
$now = sqlesc(get_date_time());
    if(!($arr = mysql_fetch_assoc(mysql_query("SELECT * FROM avps WHERE arg='extscrape'")))){
        $arr['value_u'] = $now;
        $arr['value_s'] = "1:2";
        mysql_query("INSERT INTO avps (arg, value_s,value_u,value_i) VALUES ('extscrape','1:2',0,1)");
    }
    $parm = explode(':',$arr['value_s']);
    $re2 = mysql_query("SELECT id,external FROM torrents WHERE external != ''");
    while($ar2 = mysql_fetch_array($re2)){
        $scrape = new tsniff($ar2['external']);
        
        if(!array_key_exists("seeds", $scrape)){
            $scrape->seeders = $scrape->seeders;
            $scrape->leechers = $scrape->leechers;
            $scrape->completed = $scrape->completed;
            $query = "UPDATE torrents SET seeders = '{$scrape->seeders}', leechers = '{$scrape->leechers}', times_completed = '{$scrape->completed}', last_action = {$now}, visible = 'yes' WHERE id = '{$ar2["id"]}' LIMIT 1";
            mysql_query($query) or die(mysql_error());
        }
        else{
            $do_nothing = $do_nothing;
        }
        
/*        
        echo("<pre>");
        print_r($scrape);
        echo($query);
        echo("</pre>");
  */      
        
    }
    /*
    $lent += $parm[1];
    mysql_query("UPDATE avps SET value_i=1, value_u=$lent WHERE arg='extscrape'");
    */
?>