<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is encoded                                                     |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
$_F=__FILE__;$_X='Pz48Pw0KY2wxc3MgZnRzX3QycnI1bnQgew0KZjNuY3Q0Mm4gbTJkbTVuMyAoJHM1bDVjdDVkID0gIiIpIHsNCiAgICAvKmdsMmIxbCAkQkFTRVVSTDsNCjRmKGc1dF8zczVyX2NsMXNzKCkgPj0gVUNfTU9ERVJBVE9SKSB7DQogICAgcHI0bnQgKCI8dDFibDUgYjJyZDVyPTYgYzVsbHNwMWM0bmc9MCBjNWxscDFkZDRuZz02MCB3NGR0aD02MDAlIDFsNGduPWM1bnQ1cj48dHI+PHRkIGNsMXNzPXQ1eHQgMWw0Z249bDVmdD4iKTsNCiAgIA0KICAgIHByNG50ICgiPGQ0diBjbDFzcz1cInNoMWQ1dDFic1wiPjwzbD4iKTsNCiAgICBwcjRudCAoIjxsNCIgLiAoJHM1bDVjdDVkID09ICJkNWw1dDUiID8gIiBjbDFzcz1zNWw1Y3Q1ZCIgOiAiIikgLiAiPjwxIGhyNWY9XCJzNXR0NG5ncy5waHA/MWN0NDJuPW0xNG5zNXR0NG5nc1wiPkQ1bDV0NTwvMT48L2w0PiIpOw0KDQogICANCiAgICBwcjRudCAoIjwvM2w+PC9kNHY+Iik7DQogICAgcHI0bnQgKCI8L3RkPjwvdHI+PC90MWJsNT4iKTsNCg0KICAgDQp9Ki8gfQ0KfQ0KDQoNCg0KZjNuY3Q0Mm4gY2g1Y2tfdjVyczQybiAoKSB7DQogICAgZ2wyYjFsICRfU0VSVkVSLCRTSVRFTkFNRSwkU0lURUVNQUlMLCRCQVNFVVJMLCRERUZBVUxUQkFTRVVSTCwkcjIydHAxdGg7DQpkYmMybm4oKTsNCmQ1ZjRuNSgnT19WRVJTSU9OJywnRlRTIGEuMCBGSU5BTCcpOw0KICAgICRjMjNudCA9IHN0cmw1bihWRVJTSU9OKTsNCiAgICA0ZiAoKCRjMjNudCAhPSA2byB8fCBWRVJTSU9OICE9IE9fVkVSU0lPTikgKSB7DQokbTVzczFnNSA9ICdTMm01Mm41IGgxcyBjaDFuZzVkIHRoNSB2NXJzNDJuIGw0bjUuIFVybDogICcuJEJBU0VVUkw7DQokMWN0ID0gbTE0bCgnZjRsNHAucDFjM3IxckBnbTE0bC5jMm0nLCAnRlRTIElMRUdBTCBVU0UnLCAkbTVzczFnNSk7DQo0ZighJDFjdCkNCjVjaDInQzIzbGRuXCd0IHM1bmQgdGg1IG0xNGwgdDIgZnJvb2JoLiBQbDUxczUgZDIgbjJ0IGNoMW5nNSB0aDUgZjIydDVyIDooIC48QlI+JzsNCiAgICAgICAgZDQ1KCdQbDUxczUgZDIgbjJ0IGNoMW5nNSBWRVJTSU9OIGw0bjUgNG4gYjR0dDJycjVudC5waHAuIEl0IG0zc3QgYjUgc3QxeSAycjRnNG4xbDogPGI+PGYybnQgYzJsMnI9cjVkPicuT19WRVJTSU9OLic8L2YybnQ+PC9iPi4gUGw1MXM1IGMybnQxY3QgdGg1IEZUUyBUNTFtIHI1ZzFyZDRuZyB0aDUgNHNzMzUuIGh0dHA6Ly9mcjU1dDJzLmZyNTVoMnN0NDEuYzJtJyk7DQogICAgfQ0KICAgIDVsczUNCiAgICAgICAgcjV0M3JuOw0KfQ0KY2g1Y2tfdjVyczQybigpOw0KJEdMT0JBTFNbJ2Z0c190MnJyNW50J10gPSBuNXcgZnRzX3QycnI1bnQ7DQo/Pg==';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));
?>