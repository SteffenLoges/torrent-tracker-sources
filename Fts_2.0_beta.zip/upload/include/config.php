<?
define('PUN_ROOT', './punbb/');
require PUN_ROOT.'include/common.php';
function logout()
  {
  mysql_query('DELETE FROM '.$this->db_prefix.'online WHERE username='.$this->pun_user['username']);
  pun_setcookie(1, random_pass(8), time() + 31536000);
  }
?>