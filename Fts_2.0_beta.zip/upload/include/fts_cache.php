<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | This file is encoded                                                     |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
$_F=__FILE__;$_X='Pz48Pw0KZjNuY3Q0Mm4gZnRzX2MxY2g1X3N0MXJ0KCQxZzUsJGY0bDVfbjFtNSkNCnsNCiAgICBnbDJiMWwgJGMxY2g1X2Y0bDVfbjFtNTsNCiAgICAkYzFjaDVfZjRsNV9uMW01ID0gX19GSUxFX18gLiAnX2MxY2g1XycuICRmNGw1X24xbTU7DQogICAgNGYgKDVtcHR5KCQxZzUpKSAkMWc1ID0gZTAwOw0KICAgIDRmIChAZjRsNW10NG01KCRjMWNoNV9mNGw1X24xbTUpICsgJDFnNSA+IHQ0bTUoKSkgew0KICAgICAgICByNTFkZjRsNSgkYzFjaDVfZjRsNV9uMW01KTsNCiAgICAgICAgM25zNXQoJGMxY2g1X2Y0bDVfbjFtNSk7DQogICAgICAgIDV4NHQ7DQogICAgfQ0KICAgIDJiX3N0MXJ0KCk7DQp9DQoNCmYzbmN0NDJuIGZ0c19jMWNoNV81bmQoKQ0Kew0KICAgIGdsMmIxbCAkYzFjaDVfZjRsNV9uMW01Ow0KDQogICAgNGYgKDVtcHR5KCRjMWNoNV9mNGw1X24xbTUpKSByNXQzcm47DQogICAgJHN0ciA9IDJiX2c1dF9jbDUxbigpOw0KICAgIDVjaDIgJHN0cjsNCg0KICAgIGZ3cjR0NShmMnA1bigkYzFjaDVfZjRsNV9uMW01LidfdG1wJywgInciKSwgJHN0cik7DQogICAgcjVuMW01KCRjMWNoNV9mNGw1X24xbTUuJ190bXAnLCAkYzFjaDVfZjRsNV9uMW01KTsNCn0NCj8+';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>