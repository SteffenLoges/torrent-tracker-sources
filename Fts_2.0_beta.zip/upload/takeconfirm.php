<?

require_once("include/bittorrent.php");

hit_start();

dbconn();

$id = 0 + $_GET["id"];
$email = unesc($_POST["email"]);

mysql_query("UPDATE users SET status = 'confirmed' WHERE id IN (" . implode(", ", $_POST[conusr]) . ") AND status='pending'");



$message = <<<EOD
Hello,

Your account has been confirmed. You can now visit

$BASEURL/login.php

and use your login information to login in. We hope you'll read the FAQ's and Rules before you start sharing files.

Good luck and have fun on YOUR_SITE_HERE!


----------------
If you do not know the person who has invited you, please forward this email to admin@YOUR_SITE_HERE
EOD;
mail($email, "$SITENAME Account Confirmation", $message, "From: $SITEEMAIL");

header("Refresh: 0; url=invite.php?id=$id");

hit_end();

?>