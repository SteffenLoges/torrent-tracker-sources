<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: recoverhint.php - Recover password via hint.                     |
// | Version: 0.5                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";
dbconn();

if ($CURUSER) stderr("You are already logged in!"); //id10t error
stdhead("Recover Lost Password");
$act = $_GET["act"];
$act = 0 + $act;

if ($act == '0')
{
print("<h1>Enter your username</h1>\n");

print("<form method=post action=recoverhint.php?act=1 \n");
print("<table border=1 cellspacing=0 cellpadding=5>");
print("<tr><td class=rowhead>Username</td><td><input type=text size=30 name=username></td></tr>\n");
print("<tr><td colspan=2 align=center><input type=submit value='Search'></td></tr>\n");
print("</form></table>\n");
print("<p>\n");
print("<b>Note:</b> Only users with secret answer and question are searched in the database!");
}

if ($act == '1')
{
$username = $_POST["username"];
$res = mysql_query("SELECT id, username FROM users WHERE username='$username' AND passhint !=''") or sqlerr(__FILE__, __LINE__);
$num = mysql_num_rows($res);

for ($i = 0; $i < $num; ++$i)
{
$arr = mysql_fetch_assoc($res);
$id = $arr["id"];
stdmsg("User <b>$arr[username]</b> has been found", "Click <a href=recoverhint.php?act=3&id=$arr[id]><b>here</a></b>, if you are sure you want to recover your password.</a>");
}
if (!$id)
stdmsg("Error", "Username $username doesn't exist. <a href=recoverhint.php>Try again<a>");
stdfoot();
die;
}

if ($act =='3')
{
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$id = 0 + $_GET["id"];
$answer = $_POST["answer"]; //fetch users answer
//if (!$answer)
//stdmsg("Error", "You must enter an answer");
$res = @mysql_query("SELECT * FROM users WHERE id = $id");
$arr = mysql_fetch_array($res) or stdmsg("Error", "No user with that ID");

if ($answer != $arr["hintanswer"]) stdmsg("Error", "Invalid answer"); //BZZZ WRONG!
else {
$id = 0 + $_GET["id"]; //Fetch Id

$res = @mysql_query("SELECT * FROM users WHERE id = $id");
$arr = mysql_fetch_array($res) or stdmsg("Error", "No user with that ID"); //Fetch data into array or die to error

$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; //outline usable chars for pwd gen

$newpassword = "";
for ($i = 0; $i < 10; $i++)
$newpassword .= $chars[mt_rand(0, strlen($chars) - 1)];

//$sec = mksecret();

$newpasshash = md5($sec . $newpassword . $sec);

mysql_query("UPDATE users SET secret=" . sqlesc($sec) . ", editsecret='', passhash=" . sqlesc($newpasshash) . " WHERE id=$id AND editsecret=" . sqlesc($arr["editsecret"])); //insert new pwd to db

if (!mysql_affected_rows())
stdmsg("Error", "An error occurred while attempting to update user data. Please report this to an admin.");

?>
<p><? stdmsg("New Password Generated", "Your new password is <b>$newpassword</b> (Proceed to <a href=login.php>login</a>)");?></p>
<?


}
}
else
{

$id = 0 + $_GET["id"];
//if (!is_valid_id($id))
//stderr("Error", "Bad ID");
$res = @mysql_query("SELECT * FROM users WHERE id = $id");
$arr = mysql_fetch_array($res);// or stderr("Error", "No user with that ID");
if ($user["status"] == "pending") die;

?>

<h1>Recover lost password</h1>
<p>Please enter the correct answer to your password hint<br></p>
<form method=post action=recoverhint.php?act=3&id=<?print($id)?>>
<table border=1 cellspacing=0 cellpadding=6 wpar=nowrap>
<tr><td class=rowhead>Secret Question</td>
<td><? print($arr["passhint"]) ?></td>
<tr><td class=rowhead>Secret Answer</td>
<td><input type=text size=40 name=answer></td></tr>
<tr><td colspan=2 align=center><input type=submit value='Recover!' class=btn></td></tr>
</table>
<?
stdfoot();
}
}
?>