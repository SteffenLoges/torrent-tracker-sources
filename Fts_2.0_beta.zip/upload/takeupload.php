<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: takeupload.php                                                   |
// | Version: 2.3                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/benc.php");
require_once("include/bittorrent.php");
global $extorr;
ini_set("upload_max_filesize",$max_torrent_size);

function bark($msg) {
        genbark($msg, "Upload failed!");
}

dbconn();

loggedinorreturn();
parked();

if (get_user_class() < UC_UPLOADER)
  die;

foreach(explode(":","descr:type:name") as $v) {
        if (!isset($_POST[$v]))
                bark("missing form data");
}

if (!isset($_FILES["file"]))
        bark("missing form data");

$f = $_FILES["file"];
$fname = unesc($f["name"]);
if (empty($fname))
        bark("Empty filename!");

if ($_POST['uplver'] == 'yes') {
$anonymous = "yes";
$anon = "Anonymous";
}
else {
$anonymous = "no";
$anon = $CURUSER["username"];
}

$nfofile = $_FILES['nfo'];
if ($nfofile['name'] == '')
bark("No NFO!");

if ($nfofile['size'] == 0)
  bark("0-byte NFO");

if ($nfofile['size'] > 65535)
  bark("NFO is too big! Max 65,535 bytes.");

$nfofilename = $nfofile['tmp_name'];

if (@!is_uploaded_file($nfofilename))
  bark("NFO upload failed");

$descr = unesc($_POST["descr"]);
if (!$descr)
  bark("You must enter a description!");

$catid = (0 + $_POST["type"]);
if (!is_valid_id($catid))
        bark("You must select a category to put the torrent in!");

if (!validfilename($fname))
        bark("Invalid filename!");
if (!preg_match('/^(.+)\.torrent$/si', $fname, $matches))
        bark("Invalid filename (not a .torrent).");
$shortfname = $torrent = $matches[1];
if (!empty($_POST["name"]))
        $torrent = unesc($_POST["name"]);

$tmpname = $f["tmp_name"];
if (!is_uploaded_file($tmpname))
        bark("eek");
if (!filesize($tmpname))
        bark("Empty file!");

$dict = bdec_file($tmpname, $max_torrent_size);
if (!isset($dict))
        bark("What the hell did you upload? This is not a bencoded file!");

function dict_check($d, $s) {
        if ($d["type"] != "dictionary")
                bark("not a dictionary");
        $a = explode(":", $s);
        $dd = $d["value"];
        $ret = array();
        foreach ($a as $k) {
                unset($t);
                if (preg_match('/^(.*)\((.*)\)$/', $k, $m)) {
                        $k = $m[1];
                        $t = $m[2];
                }
                if (!isset($dd[$k]))
                        bark("dictionary is missing key(s)");
                if (isset($t)) {
                        if ($dd[$k]["type"] != $t)
                                bark("invalid entry in dictionary");
                        $ret[] = $dd[$k]["value"];
                }
                else
                        $ret[] = $dd[$k];
        }
        return $ret;
}

function dict_get($d, $k, $t) {
        if ($d["type"] != "dictionary")
                bark("not a dictionary");
        $dd = $d["value"];
        if (!isset($dd[$k]))
                return;
        $v = $dd[$k];
        if ($v["type"] != $t)
                bark("invalid dictionary entry type");
        return $v["value"];
}

list($ann, $info) = dict_check($dict, "announce(string):info");
list($dname, $plen, $pieces) = dict_check($info, "name(string):piece length(integer):pieces(string)");

//$passkey=$announce_urls[0].'?passkey='.$CURUSER['passkey'];

//if ($passkey != $ann)
//bark("invalid announce url! must be <b>" . $passkey . "</b>");
$external=!in_array($ann, $announce_urls, 1);
if (strlen($pieces) % 20 != 0)
        bark("invalid pieces");

$filelist = array();
$totallen = dict_get($info, "length", "integer");
if (isset($totallen)) {
        $filelist[] = array($dname, $totallen);
        $type = "single";
}
else {
        $flist = dict_get($info, "files", "list");
        if (!isset($flist))
                bark("missing both length and files");
        if (!count($flist))
                bark("no files");
        $totallen = 0;
        foreach ($flist as $fn) {
                list($ll, $ff) = dict_check($fn, "length(integer):path(list)");
                $totallen += $ll;
                $ffa = array();
                foreach ($ff as $ffe) {
                        if ($ffe["type"] != "string")
                                bark("filename error");
                        $ffa[] = $ffe["value"];
                }
                if (!count($ffa))
                        bark("filename error");
                $ffe = implode("/", $ffa);
                $filelist[] = array($ffe, $ll);
        if ($ffe == 'Thumbs.db')
        {
            stderr("Error","The torrent can't contain files named Thumbs.db!");
            die;
        }
        }
        $type = "multi";
}

//$dict['value']['announce']=bdec(benc_str( $announce_urls[0]));  // change announce url to local
//$dict['value']['info']['value']['private']=bdec('i1e');  // add private tracker flag
//unset($dict['value']['announce-list']); // remove multi-tracker capability
//unset($dict['value']['nodes']); // remove cached peers (Bitcomet & Azareus)
unset($dict['value']['info']['value']['crc32']); // remove crc32
unset($dict['value']['info']['value']['ed2k']); // remove ed2k
unset($dict['value']['info']['value']['md5sum']); // remove md5sum
unset($dict['value']['info']['value']['sha1']); // remove sha1
unset($dict['value']['info']['value']['tiger']); // remove tiger
unset($dict['value']['azureus_properties']); // remove azureus properties
$dict=bdec(benc($dict)); // double up on the becoding solves the occassional misgenerated infohash
$dict['value']['comment']=bdec(benc_str( "Torrent created for '$SITENAME' tracker")); // change torrent comment
$dict['value']['created by']=bdec(benc_str( "$CURUSER[username]")); // change created by
$dict['value']['publisher']=bdec(benc_str( "$CURUSER[username]")); // change publisher
$dict['value']['publisher.utf-8']=bdec(benc_str( "$CURUSER[username]")); // change publisher.utf-8
$dict['value']['publisher-url']=bdec(benc_str( "$DEFAULTBASEURL/userdetails.php?id=$CURUSER[id]")); // change publisher-url
$dict['value']['publisher-url.utf-8']=bdec(benc_str( "$DEFAULTBASEURL/userdetails.php?id=$CURUSER[id]")); // change publisher-url.utf-8
list($ann, $info) = dict_check($dict, "announce(string):info");

$infohash = pack("H*", sha1($info["string"]));
if($external && $extorr != 'yes')
bark('External Torrents upload disabled');
$external =($external!=null) ? sqlesc(substr($ann,0,strrpos($ann,'announce')). 'scrape'. substr($ann,strrpos($ann,'announce')+9) .'?info_hash=' . urlencode($infohash)):null;
if(preg_match('/passkey/',$external))
$external =($external!=null) ? sqlesc(substr($ann,0,strrpos($ann,'announce')). 'scrape.'. substr($ann,strrpos($ann,'announce')+9) .'&info_hash=' . urlencode($infohash)):'';
elseif(preg_match('/php/',$external))
$external =($external!=null) ? sqlesc(substr($ann,0,strrpos($ann,'announce')). 'scrape.'. substr($ann,strrpos($ann,'announce')+9) .'?info_hash=' . urlencode($infohash)):'';
elseif(!$external)
$external = false;
else
$external =($external!=null) ? sqlesc(substr($ann,0,strrpos($ann,'announce')). 'scrape'. substr($ann,strrpos($ann,'announce')+9) .'?info_hash=' . urlencode($infohash)):'';

// Replace punctuation characters with spaces

$torrent = str_replace("_", " ", $torrent);

// Replace .torrent .rar .avi .exe .zip ... characters with spaces

$torrent = str_replace(".torrent", " ", $torrent);
$torrent = str_replace(".rar", " ", $torrent);
$torrent = str_replace(".avi", " ", $torrent);
$torrent = str_replace(".mpeg", " ", $torrent);
$torrent = str_replace(".exe", " ", $torrent);
$torrent = str_replace(".zip", " ", $torrent);
$torrent = str_replace(".wmv", " ", $torrent);
$torrent = str_replace(".iso", " ", $torrent);
$torrent = str_replace(".bin", " ", $torrent);
$torrent = str_replace(".txt", " ", $torrent);
$torrent = str_replace(".nfo", " ", $torrent);
$torrent = str_replace(".7z", " ", $torrent);
$torrent = str_replace(".mp3", " ", $torrent);

$nfo = sqlesc(str_replace("\x0d\x0d\x0a", "\x0d\x0a", @file_get_contents($nfofilename)));
$smalldescr = $_POST["description"];
$image = $_POST['t_image'];
if($external)
$ret = mysql_query("INSERT INTO torrents (search_text, filename, owner, visible, info_hash, name, size, numfiles, type, descr, ori_descr, category, save_as, added, last_action, nfo, external, t_image) VALUES (" .
        implode(",", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $CURUSER["id"], 'yes', $infohash, $torrent, $totallen, count($filelist), $type, $descr, $descr, 0 + $_POST["type"], $dname))) .
        ", '" . get_date_time() . "', '" . get_date_time() . "', $nfo,$external,'$image')");
else
$ret = mysql_query("INSERT INTO torrents (search_text, filename, owner, visible, info_hash, name, size, numfiles, type, descr, ori_descr, category, save_as, added, last_action, nfo, t_image) VALUES (" .
        implode(",", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $CURUSER["id"], 'no', $infohash, $torrent, $totallen, count($filelist), $type, $descr, $descr, 0 + $_POST["type"], $dname))) .
        ", '" . get_date_time() . "', '" . get_date_time() . "', $nfo, '$image')");
if (!$ret) {
        if (mysql_errno() == 1062)
                bark("torrent already uploaded!");
        bark("mysql puked: ".mysql_error());
}
$id = mysql_insert_id();

@mysql_query("DELETE FROM files WHERE torrent = $id");
foreach ($filelist as $file) {
        @mysql_query("INSERT INTO files (torrent, filename, size) VALUES ($id, ".sqlesc($file[0]).",".$file[1].")");
}

$fp = fopen("$torrent_dir/$id.torrent", "w");
if ($fp)
{
        @fwrite($fp, benc($dict), strlen(benc($dict)));
    fclose($fp);
}

write_log("Torrent $id ($torrent) was uploaded by " . $CURUSER["username"]);



/* RSS feeds */
/*
if (($fd1 = @fopen("rss.xml", "w")) && ($fd2 = fopen("rssdd.xml", "w")))
{
        $cats = "";
        $res = mysql_query("SELECT id, name FROM categories");
        while ($arr = mysql_fetch_assoc($res))
                $cats[$arr["id"]] = $arr["name"];
        $s = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n<rss version=\"2.0\">\n<channel>\n" .
                "<title>$DEFAULTBASEURL</title>\n<description>Newest tracker torrents</description>\n<link>$DEFAULTBASEURL/</link>\n";
        @fwrite($fd1, $s);
        @fwrite($fd2, $s);
        $r = mysql_query("SELECT id,name,descr,filename,category FROM torrents ORDER BY added DESC LIMIT 15") or sqlerr(__FILE__, __LINE__);
        while ($a = mysql_fetch_assoc($r))
        {
                $cat = $cats[$a["category"]];
                $s = "<item>\n<title>" . htmlspecialchars($a["name"] . " ($cat)") . "</title>\n" .
                        "<description>" . htmlspecialchars($a["descr"]) . "</description>\n";
                @fwrite($fd1, $s);
                @fwrite($fd2, $s);
                @fwrite($fd1, "<link>$DEFAULTBASEURL/details.php?id=$a[id]&amp;hit=1</link>\n</item>\n");
                $filename = htmlspecialchars($a["filename"]);
                @fwrite($fd2, "<link>$DEFAULTBASEURL/download.php/$a[id]/$filename</link>\n</item>\n");
        }
        $s = "</channel>\n</rss>\n";
        @fwrite($fd1, $s);
        @fwrite($fd2, $s);
        @fclose($fd1);
        @fclose($fd2);
}
*/
/* Email notifs */
/*******************

$res = mysql_query("SELECT name FROM categories WHERE id=$catid") or sqlerr();
$arr = mysql_fetch_assoc($res);
$cat = $arr["name"];
$res = mysql_query("SELECT email FROM users WHERE enabled='yes' AND notifs LIKE '%[cat$catid]%'") or sqlerr();
$uploader = $CURUSER['username'];

$size = mksize($totallen);
$description = ($html ? strip_tags($descr) : $descr);

$body = <<<EOD
A new torrent has been uploaded.

Name: $torrent
Size: $size
Category: $cat
Uploaded by: $uploader

Description
-------------------------------------------------------------------------------
$description
-------------------------------------------------------------------------------

You can use the URL below to download the torrent (you may have to login).

$DEFAULTBASEURL/details.php?id=$id&hit=1

--
$SITENAME
EOD;
$to = "";
$nmax = 100; // Max recipients per message
$nthis = 0;
$ntotal = 0;
$total = mysql_num_rows($res);
while ($arr = mysql_fetch_row($res))
{
  if ($nthis == 0)
    $to = $arr[0];
  else
    $to .= "," . $arr[0];
  ++$nthis;
  ++$ntotal;
  if ($nthis == $nmax || $ntotal == $total)
  {
    if (!mail("Multiple recipients <$SITEEMAIL>", "New torrent - $torrent", $body,
    "From: $SITEEMAIL\r\nBcc: $to", "-f$SITEEMAIL"))
          stderr("Error", "Your torrent has been been uploaded. DO NOT RELOAD THE PAGE!\n" .
            "There was however a problem delivering the e-mail notifcations.\n" .
            "Please let an administrator know about this error!\n");
    $nthis = 0;
  }
}
*******************/
//===add karma
mysql_query("UPDATE users SET seedbonus = seedbonus+15.0 WHERE id = $CURUSER[id]") or sqlerr(__FILE__, __LINE__);
//===end
if($external) {
$now = sqlesc(get_date_time());
    if(!($arr = mysql_fetch_assoc(mysql_query("SELECT * FROM avps WHERE arg='extscrape'")))){
        $arr['value_u'] = $now;
        $arr['value_s'] = "1:2";
        mysql_query("INSERT INTO avps (arg, value_s,value_u,value_i) VALUES ('extscrape','1:2',0,1)");
    }
$gid = $_GET['id'];
    $parm = explode(':',$arr['value_s']);
    $re2 = mysql_query("SELECT id,external FROM torrents WHERE external != '' AND id = $id");
    while($ar2 = mysql_fetch_array($re2)){
        $scrape = new tsniff($ar2['external']);
        
        if(!array_key_exists("seeds", $scrape)){
            $scrape->seeders = $scrape->seeders;
            $scrape->leechers = $scrape->leechers;
            $scrape->completed = $scrape->completed;
            $query = "UPDATE torrents SET seeders = '{$scrape->seeders}', leechers = '{$scrape->leechers}', times_completed = '{$scrape->completed}', last_action = {$now}, visible = 'yes' WHERE id = '{$ar2["id"]}' LIMIT 1";
            mysql_query($query) or die(mysql_error());
        }
        else{
            $do_nothing = $do_nothing;
        }

}
}
if($external)
header("Location: $BASEURL/browse.php");
else
header("Location: $BASEURL/details.php?id=$id&uploaded=1");

?>