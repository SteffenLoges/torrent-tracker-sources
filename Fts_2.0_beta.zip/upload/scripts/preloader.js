//Pt centrarea preloader ului
var Page = new Object();
Page.width;
Page.height;
Page.top;
Page.getPageCenterX = function ()
{
        var fWidth;
        var fHeight;       
        //Pentru browsele IE mai vechi
        if(document.all)
        {
        fWidth  = document.body.clientWidth;
        fHeight = document.body.clientHeight;
        }
        //Pentru care suporta DOM
        else if(document.getElementById &&!document.all)
        {
         fWidth = innerWidth;
        fHeight = innerHeight;
        }
        else if(document.getElementById)
        {
        fWidth = innerWidth;
        fHeight = innerHeight;        
        }
        //Pentru Opera
        else if (is.op)
        {
        fWidth = innerWidth;
        fHeight = innerHeight;        
        }
        //Pentru browserele Netscape mai vechi
        else if (document.layers)
        {
        fWidth = window.innerWidth;
        fHeight = window.innerHeight;        
        }
    Page.width = fWidth;
    Page.height = fHeight;
    Page.top = window.document.body.scrollTop;
}

function showPreloader(div){   
    Page.getPageCenterX(); //determin mijlocul ferestrei browserului
    $('#loading').show();  //afisez div-ul cu id loading
    $('#loading').css('top' ,(Page.top + Page.height/3)-100); //pozitionez div-ul absolut
    $('#loading').css('left',Page.width/3);   
}
function hidePreloader(){
     $('#loading').hide(); //ascundem div-ul cu id loading
}