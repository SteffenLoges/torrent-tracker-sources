/***********************************************
* Pop-it menu- � Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var defaultMenuWidth="150px"
var linkset=new Array()

linkset[0]='<a href="' + baseurl + '/admin/staffpanel.php">' + l_staffpanel + '</a>'

linkset[1]='<a href="' + baseurl + '/admin/staffpanel.php">' + l_staffpanel + '</a>'
linkset[1]+='<a href="' + baseurl + '/admin/settings.php">' + l_trackersettings + '</a>'
linkset[1]+='<a href="' + baseurl + '/admin/statistics.php">' + l_trackerstats + '</a>'

linkset[2]='<a href="' + baseurl + '/admin/staffpanel.php">' + l_staffpanel + '</a>'
linkset[2]+='<a href="' + baseurl + '/admin/settings.php">' + l_trackersettings + '</a>'
linkset[2]+='<a href="' + baseurl + '/community/admin/">' + l_forumsettings + '</a>'
linkset[2]+='<a href="' + baseurl + '/admin/statistics.php">' + l_trackerstats + '</a>'
linkset[2]+='<a href="' + baseurl + '/admin/settings.php?action=usergroups">' + l_usergroups + '</a>'

linkset[3]='<a href="' + baseurl + '/forums.php">' + l_forums + '</a>'
linkset[3]+='<a href="' + baseurl + '/forums.php?action=getnew">' + l_newposts + '</a>'
linkset[3]+='<a href="' + baseurl + '/forums.php?action=getdaily">' + l_newdaily + '</a>'

linkset[4]='<a href="' + baseurl + '/browse.php">' + l_browse + '</a>'
linkset[4]+='<a href="' + baseurl + '/bookmarks.php">' + l_bookmarks + '</a>'
linkset[4]+='<a href="' + baseurl + '/myreseed.php">' + l_reseeds + '</a>'

linkset[5]='<a href="' + baseurl + '/viewrequests.php">' + l_viewreq + '</a>'
linkset[5]+='<a href="' + baseurl + '/viewoffers.php">' + l_viewoff + '</a>'

linkset[6]='<a href="' + baseurl + '/usercp.php">' + l_ucphome + '</a>'
linkset[6]+='<a href="' + baseurl + '/usercp.php?action=personal">' + l_ucppersonal + '</a>'
linkset[6]+='<a href="' + baseurl + '/usercp.php?action=tracker">' + l_ucptracker + '</a>'
linkset[6]+='<a href="' + baseurl + '/usercp.php?action=forum">' + l_ucpforum + '</a>'
linkset[6]+='<a href="' + baseurl + '/usercp.php?action=security">' + l_ucpsecurity + '</a>'
linkset[6]+='<a href="' + baseurl + '/messages.php">' + l_ucppm + '</a>'
linkset[6]+='<a href="' + baseurl + '/mytorrents.php">' + l_ucpyourtorrents + '</a>'

linkset[7]='<a href="' + baseurl + '/topten.php?type=1">' + l_top10users + '</a>'
linkset[7]+='<a href="' + baseurl + '/topten.php?type=2">' + l_top10torrents + '</a>'
linkset[7]+='<a href="' + baseurl + '/topten.php?type=3">' + l_top10countries + '</a>'
linkset[7]+='<a href="' + baseurl + '/topten.php?type=4">' + l_top10peers + '</a>'

linkset[8]='<a href="' + baseurl + '/rules.php">' + l_helprules + '</a>'
linkset[8]+='<a href="' + baseurl + '/faq.php">' + l_helpfaq + '</a>'
linkset[8]+='<a href="' + baseurl + '/links.php">' + l_helpusefulllinks + '</a>'

linkset[9]='<a href="' + baseurl + '/staff.php">' + l_staffpanel + '</a>'
linkset[9]+='<a href="' + baseurl + '/contactstaff.php">' + l_staffcontact + '</a>'

linkset[10]='<a href="' + baseurl + '/userdetails.php?id=' + userid + '">' + l_extraprofile + '</a>'
linkset[10]+='<a href="' + baseurl + '/users.php">' + l_extramembers + '</a>'
linkset[10]+='<a href="' + baseurl + '/friends.php">' + l_extrafriends + '</a>'
linkset[10]+='<a href="' + baseurl + '/getrss.php">' + l_extrarssfeed + '</a>'
linkset[10]+='<a href="' + baseurl + '/invite.php">' + l_extrainvite + '</a>'
linkset[10]+='<a href="' + baseurl + '/mybonus.php">' + l_extrabonus + '</a>'
linkset[10]+='<a href="' + baseurl + '/donate.php">' + l_extradonate + '</a>'
linkset[10]+='<a href="' + baseurl + '/logout.php" onclick="return log_out()">' + l_extralogout + '</a>'

linkset[11]='<a href="' + baseurl + '/upload.php">' + l_uploadtorrent + '</a>'
linkset[11]+='<a href="' + baseurl + '/faq.php#37">' + l_uploadrules + '</a>'


////No need to edit beyond here

var ie5=document.all && !window.opera
var ns6=document.getElementById

if (ie5||ns6)
document.write('<div id="popitmenu" onMouseover="clearhidemenu();" onMouseout="dynamichide(event)"></div>')

function iecompattest(){
return (document.compatMode && document.compatMode.indexOf("CSS")!=-1)? document.documentElement : document.body
}

function showmenu(e, which, optWidth){
if (!document.all&&!document.getElementById)
return
clearhidemenu()
menuobj=ie5? document.all.popitmenu : document.getElementById("popitmenu")
menuobj.innerHTML=which
menuobj.style.width=(typeof optWidth!="undefined")? optWidth : defaultMenuWidth
menuobj.contentwidth=menuobj.offsetWidth
menuobj.contentheight=menuobj.offsetHeight
eventX=ie5? event.clientX : e.clientX
eventY=ie5? event.clientY : e.clientY
//Find out how close the mouse is to the corner of the window
var rightedge=ie5? iecompattest().clientWidth-eventX : window.innerWidth-eventX
var bottomedge=ie5? iecompattest().clientHeight-eventY : window.innerHeight-eventY
//if the horizontal distance isn't enough to accomodate the width of the context menu
if (rightedge<menuobj.contentwidth)
//move the horizontal position of the menu to the left by it's width
menuobj.style.left=ie5? iecompattest().scrollLeft+eventX-menuobj.contentwidth+"px" : window.pageXOffset+eventX-menuobj.contentwidth+"px"
else
//position the horizontal position of the menu where the mouse was clicked
menuobj.style.left=ie5? iecompattest().scrollLeft+eventX+"px" : window.pageXOffset+eventX+"px"
//same concept with the vertical position
if (bottomedge<menuobj.contentheight)
menuobj.style.top=ie5? iecompattest().scrollTop+eventY-menuobj.contentheight+"px" : window.pageYOffset+eventY-menuobj.contentheight+"px"
else
menuobj.style.top=ie5? iecompattest().scrollTop+event.clientY+"px" : window.pageYOffset+eventY+"px"
menuobj.style.visibility="visible"
return false
}

function contains_ns6(a, b) {
//Determines if 1 element in contained in another- by Brainjar.com
while (b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}

function hidemenu(){
if (window.menuobj)
menuobj.style.visibility="hidden"
}

function dynamichide(e){
if (ie5&&!menuobj.contains(e.toElement))
hidemenu()
else if (ns6&&e.currentTarget!= e.relatedTarget&& !contains_ns6(e.currentTarget, e.relatedTarget))
hidemenu()
}

function delayhidemenu(){
delayhide=setTimeout("hidemenu()",500)
}

function clearhidemenu(){
if (window.delayhide)
clearTimeout(delayhide)
}

if (ie5||ns6)
document.onclick=hidemenu