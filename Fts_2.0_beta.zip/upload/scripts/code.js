function calculeaza(){      
  var parametri = $("input[@type=text]").serialize();
  /*
    serilizeaza toate input-urile de tip text
    Exemplu parametri va fi nr1=23&nr2=45
  */   
 
  $.ajax({
   type: "POST",
   url: "php/calculeaza.php", //script-ul php care va realiza calculul
   data: parametri,  
     success: function(msg){    
      $('#rezultat').attr('innerHTML','Suma este '+msg);
      //se updateaza div ul cu id rezultat
   }   
  });
}