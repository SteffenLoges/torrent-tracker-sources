<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: signup.php - Register for one account.                           |
// | Version: 3.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");
dbconn();
if($invitesys == 'yes') stderr('Error!','Invite system is on');
include "check_username.php";
foreach($_POST as $key => $value) {
$value=trim($value);
if (get_magic_quotes_gpc()) $value = stripslashes($value);
$value=htmlspecialchars($value,ENT_QUOTES);
$_POST[$key]=$value;
$value=str_replace("\r","",$value);
$value=str_replace("\n","<br>",$value);
$msg[$key]=$value;
}
sajax_init();
sajax_export("check_user_exist");
sajax_handle_client_request();
function check_user_exist($username) {
$username = mysql_escape_string($username);
$suggest = array('2005', '2006', '2007', 'best');
$sql = "SELECT `username` FROM `users` WHERE `username` = '$username'";
$result = mysql_query($sql);
if(mysql_num_rows($result) > 0) {
$avail[0] = 'no';
$i = 2;
foreach($suggest AS $postfix) {
$sql = "SELECT `username` FROM `users` WHERE `username` = '".$username.$postfix."'";
$result = mysql_query($sql);
if(mysql_num_rows($result) < 1) {
$avail[$i] = $username.$postfix;
$i ++;
}
}
$avail[1] = $i - 1;
return $avail;
}
return array('yes');
}
$max = 12; // Maximum chart
$min = 1; // Minimum chart
$siteweb = $BASEURL; // Your web site, no / at the end (you can change by $SITEURL (i think))
    global $CURUSER;
    if ($CURUSER) {
    stderr("Error", "You are already registred.");
    }
	
$a = (@mysql_fetch_row(@mysql_query("select count(*) from users where ip='" . $_SERVER['REMOTE_ADDR'] . "'"))) or die(mysql_error()); 
//if ($a[0] != ) 
//stderr("Error", "Youre IP adress " . $_SERVER['REMOTE_ADDR'] . " is already used.");

$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $maxusers)
        stderr("Sorry", "The current user account limit (" . number_format($maxusers) . ") has been reached. Inactive accounts are pruned all the time, please check back again later...");


stdhead("Signup");
$question = array(
'1' => 'What is your favorite colour?',
'2' => 'Whats your pets name?',
'3' => 'Whats your mothers maiden name?'
);
?>

<script type="text/javascript">
<?php
sajax_show_javascript();
?>
function check_handle(result) {
if(result[0] == 'yes') {
document.getElementById('not_available').style.display = 'none';
document.getElementById('available').style.display = 'block';
}
else {
document.getElementById('available').style.display = 'none';
document.getElementById('not_available').style.display = 'block';
var str = 'Username already exists! <br />';
document.getElementById('not_available').innerHTML = str;
}
}

function check_user_exist() {
var username = document.getElementById('username').value;
x_check_user_exist(username, check_handle);
}

function switch_username(username) {
document.getElementById('username').value = username;
}
</script>

<style type="text/css">
#available {
display: none;
color: green;
}
#not_available {
display: none;
color: red;
}
</style>
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <script type="text/javascript" src="scripts/code.js"></script>
    <script type="text/javascript" src="scripts/preloader.js"></script>
     <div style="display:none;" id="loading">
Creating Your Account - Please Wait
<BR>        <img alt="prealoder" title="Se incarca" src='pic/8-1.gif'/>       
     </div> 
<table width=500 border=1 cellspacing=0 cellpadding=10><tr><td align=left>
<h2 align=center>Bittorrent clients</h2>
<b><font color=red>Important:</font></b> We accept <b>only</b> <a href="http://utorrent.com"><img border="0" alt="Get utorrent!" title="Get utorrent!" src="pic/utorrent.png"/></a> and <a href="http://azureus.sourceforge.net"><img border="0" alt="Get Azureus!" title="Get Azureus!" src="pic/azureus.png"/></a>
as bittorrent clients, other clients are <span style="color:red"><b>banned</b></span>. Please download one of them and use, if you need any help contact <a href=staff.php><b>staff</b></a>.
</td></tr></table>
<p>

Note: You need cookies enabled to sign up or log in.
<p>
<form method="post" action="takesignup.php">
<table border="1" cellspacing=0 cellpadding="10">
<tr>
<td class="tablea" align="right">Username:<font color="red">&nbsp;*</font></td>
<td class="tablea" align="left">
<input type="text" name="wantusername" id="username" size="40" class='inputUsername'>
<input class="tableinborder" type="button" name="check" value="Check" onclick="check_user_exist(); return false;">
<div id="available">Username free for you!</div>
<div id="not_available">Username already exists!</div>
</td>
</tr>
<!-- Password strengh by darkness -->
<tr><td align="right" class="row2">Password strength:</td><td align="left" class="row1"><img src="../pic/tooshort.jpg" id="strength" alt="" /></td></tr>
<tr><td align="right" class="row2">Pick a password:</td><td align="left" class="row1">
<input onkeyup="updatestrength( this.value );" type="password" name="wantpassword" id="password"  size="40" class='inputPassword'/> </tr></td>
<tr><td align="right" class="heading">Enter password again:</td><td align=left><input type="password" size="40" name="passagain" class='inputPassword'/></td></tr>
<tr><td align="right" class="heading">Random pw:</td><td align=left><b><?=randompw(12)?></b>
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>Incase you dont have a password you can use this random one</td></tr>
</font></td></tr></table>
<tr><td align="right" class="heading">Secret Question:</td><td align=left><select name=wanthint>
<?
foreach ($question as $v => $q){
$val = strtoupper($q);
$fin = str_replace(' ','_',$val);
print($fin);
?>
<option value=<?=$fin?>><?=$q?></option>
<?}?>
</select></td></tr>
<tr><td align="right" class="heading">Enter hint answer:</td><td align=left><input type="text" class="inputG" size="40" name="wantanswer" />
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>This answer will be used to reset your password in case you forget it. Make sure its something you will not forget!</td></tr>
</font></td></tr></table>
</td></tr>

<!-- Birthday script -->
<tr><td align="right" class="heading">Your birthday:</td><td align=left>Year <input type=text size=10 name=yearofbirth value=''>(2007,1970) Month <input type=text size=10 name=monthofbirth value=''>(07,10) Day <input type=text size=10 name=dayofbirth value=''> (31,20) 
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>Beaware. You can't change this later only with moderator permission</td></tr>
</font></td></tr></table>

<tr valign=top><td align="right" class="heading">Email address:</td><td align=left><input type="text" size="40" class="inputG" name="email" />
<table width=250 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font class=small>The email address must be valid.
You will receive a confirmation email which you need to respond to. The email address won't be publicly shown anywhere.</td></tr>
</font></td></tr></table></td></tr>
<? $countries = "<option value=75>---- None selected ----</option>n";
$ct_r = mysql_query("SELECT id,name FROM countries ORDER BY name") or die;
while ($ct_a = mysql_fetch_array($ct_r))
$countries .= "<option value=$ct_a[id]" . ($CURUSER["country"] == $ct_a['id'] ? " selected" : "") . ">$ct_a[name]</option>n";
tr("Country", "<select name=country>n$countries</select>", 1); ?>
</td></tr>
<tr><td align="right" class="heading"></td><td align=left><input type=checkbox name=rulesverify value=yes> I have read the site <a href=rules.php><b>rules</b></a> page.<br>
<input type=checkbox name=faqverify value=yes> I agree to read the <a href=faq.php><b>FAQ</b></a> before asking questions.<br>
<input type=checkbox name=ageverify value=yes> I am at least 13 years old.</td></tr>
<tr><td colspan="2" align="center"><input type=submit value="Sign up! (PRESS ONLY ONCE)" style='height: 25px' onClick="javascipt:showPreloader();"></td></tr>
</table>
</form>
<?

stdfoot();

?>