<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<? global $SITENAME,$BASEURL;?>
<title><?=$SITENAME;?> - Administration [Fts!]</title>
<link rel="stylesheet" href="templates/administrator-templates/default/css/template_css.css" type="text/css" />
<link rel="stylesheet" href="templates/administrator-templates/default/css/theme.css" type="text/css" />
<meta http-equiv="Content-Type" content="text/html;" />
<meta name="Generator" content="Fts! Free torrent source." />
</head>
<body>
<div id="wrapper">
	<div id="header">
			<div id="joomla"><img src="templates/administrator-templates/default/images/header_text.png" alt="Joomla! Logo" /></div>
	</div>
</div>


<table width="100%" class="menubar" cellpadding="0" cellspacing="0" border="0">
<tr>
	<td class="menudottedline" width="40%">
<? print('<a href="'.$BASEURL.'"'.pres().'>Back to site</a> | <a href="cpanel.php"'.pres().'>Main Cpanel Page</a>'); ?>
	</td>
	<td class="menudottedline" align="right" style="padding-right:5px;">
	<?print('	<a href="logout.php" '.pres().' style="color: #333333; font-weight: bold">
			Logout</a>');?>
	</td>
</tr>
</table>

<br />
<!-- mosmsg --!>

<div align="center" class="centermain">
	<div class="main">

