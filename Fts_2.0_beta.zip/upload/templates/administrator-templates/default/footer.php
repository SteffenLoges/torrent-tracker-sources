	</div>
</div>

<div align="center" class="footer">
	<table width="99%" border="0">
	<tr>
		<td align="center">
			<div align="center">
		Current version: <?=VERSION?>
			</div>
			<div align="center" class="smallgrey">
				<?
global $laversion;if ($laversion == 'yes')
getlave();
?>
<div id='vwar'></div>
			</div>

		</td>
	</tr>
	</table>
</div>
</body>
</html>