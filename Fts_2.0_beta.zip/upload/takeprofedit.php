<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: takeprofedit.php                                                 |
// | Version: 0.9                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require_once("include/bittorrent.php");

function bark($msg) {
        genbark($msg, "Update failed!");
}

dbconn();

loggedinorreturn();

if (!mkglobal("email:oldpassword:chpassword:passagain"))
        bark("missing form data");

// $set = array();

$updateset = array();
$changedemail = 0;

if ($chpassword != "") {
        if (strlen($chpassword) > 40)
                bark("Sorry, password is too long (max is 40 chars)");
        if ($chpassword != $passagain)
                bark("The passwords didn't match. Try again.");
        if ($CURUSER["passhash"] != md5($CURUSER["secret"] . $oldpassword . $CURUSER["secret"]))
                bark("Old password didn't match. Try again.");

        $sec = mksecret();

  $passhash = md5($sec . $chpassword . $sec);

        $updateset[] = "secret = " . sqlesc($sec);
        $updateset[] = "passhash = " . sqlesc($passhash);
        logincookie($CURUSER["id"], $passhash);
}

if ($_POST['resetpasskey']) $updateset[] = "passkey=''";

if ($email != $CURUSER["email"]) {
        if (!validemail($email))
                bark("That doesn't look like a valid email address.");
  $r = mysql_query("SELECT id FROM users WHERE email=" . sqlesc($email)) or sqlerr();
        if (mysql_num_rows($r) > 0)
                bark("The e-mail address $email is already in use.");
        $changedemail = 1;
}
$yob = $_POST["yearofbirth"];
$mob = $_POST["monthofbirth"];
$dob = $_POST["dayofbirth"];
$acceptpms = $_POST["acceptpms"];
$subscription_pm = $_POST["subscription_pm"];
$commentpm = $_POST["commentpm"];
$parked = $_POST["parked"];
$deletepms = ($_POST["deletepms"] != "" ? "yes" : "no");
$savepms = ($_POST["savepms"] != "" ? "yes" : "no");
$pmnotif = $_POST["pmnotif"];
$emailnotif = $_POST["emailnotif"];
$notifs = ($pmnotif == 'yes' ? "[pm]" : "");
$notifs .= ($emailnotif == 'yes' ? "[email]" : "");
$r = mysql_query("SELECT id FROM categories") or sqlerr();
$rows = mysql_num_rows($r);
for ($i = 0; $i < $rows; ++$i)
{
        $a = mysql_fetch_assoc($r);
        if ($_POST["cat$a[id]"] == 'yes')
          $notifs .= "[cat$a[id]]";
}
$avatar = $_POST["avatar"];
$avatars = ($_POST["avatars"] != "" ? "yes" : "no");
// $ircnick = $_POST["ircnick"];
// $ircpass = $_POST["ircpass"];
$info = $_POST["info"];
$country = $_POST["country"];
$language = $_POST["language"];
//$timezone = 0 + $_POST["timezone"];
//$dst = ($_POST["dst"] != "" ? "yes" : "no");

/*
if ($privacy != "normal" && $privacy != "low" && $privacy != "strong")
        bark("whoops");

$updateset[] = "privacy = '$privacy'";
*/
$updateset[] = "yob = " . min(2007, 0 + $_POST["yearofbirth"]);
$updateset[] = "mob = " . min(12, 0 + $_POST["monthofbirth"]);
$updateset[] = "dob = " . min(31, 0 + $_POST["dayofbirth"]);
$updateset[] = "torrentsperpage = " . min(100, 0 + $_POST["torrentsperpage"]);
$updateset[] = "topicsperpage = " . min(100, 0 + $_POST["topicsperpage"]);
$updateset[] = "postsperpage = " . min(100, 0 + $_POST["postsperpage"]);

if (is_valid_id($country))
  $updateset[] = "country = $country";
if (is_valid_id($language))
  $updateset[] = "language = $language";

//$updateset[] = "timezone = $timezone";
//$updateset[] = "dst = '$dst'";
$updateset[] = "info = " . sqlesc($info);
$updateset[] = "subscription_pm = " . sqlesc($subscription_pm);
$updateset[] = "commentpm = " . sqlesc($commentpm);  
$updateset[] = "acceptpms = " . sqlesc($acceptpms);
$updateset[] = "parked = " . sqlesc($parked);
$updateset[] = "deletepms = '$deletepms'";
$updateset[] = "savepms = '$savepms'";
$updateset[] = "notifs = '$notifs'";
$updateset[] = "avatar = " . sqlesc($avatar);
$updateset[] = "avatars = '$avatars'";

/* ****** */

$urladd = "";

if ($changedemail) {
        $sec = mksecret();
        $hash = md5($sec . $email . $sec);
        $obemail = urlencode($email);
        $updateset[] = "editsecret = " . sqlesc($sec);
        $thishost = $_SERVER["HTTP_HOST"];
        $thisdomain = preg_replace('/^www\./is', "", $thishost);
        $body = <<<EOD
You have requested that your user profile (username {$CURUSER["username"]})
on $thisdomain should be updated with this email address ($email) as
user contact.

If you did not do this, please ignore this email. The person who entered your
email address had the IP address {$_SERVER["REMOTE_ADDR"]}. Please do not reply.

To complete the update of your user profile, please follow this link:

http://$thishost/confirmemail.php/{$CURUSER["id"]}/$hash/$obemail

Your new email address will appear in your profile after you do this. Otherwise
your profile will remain unchanged.
EOD;

        mail($email, "$thisdomain profile change confirmation", $body, "From: $SITEEMAIL", "-f$SITEEMAIL");

        $urladd .= "&mailsent=1";
}

mysql_query("UPDATE users SET " . implode(",", $updateset) . " WHERE id = " . $CURUSER["id"]) or sqlerr(__FILE__,__LINE__);

header("Location: $BASEURL/my.php?edited=1" . $urladd);

?>