<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: rss.php - Tracker's rss page.                                    |
// | Version: 0.2                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";
dbconn();

$passkey = $_GET["passkey"];
if ($passkey) {
$user = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM users WHERE passkey = '$passkey'"));
if ($user[0] != 1)
exit();
} else
loggedinorreturn();

$feed = $_GET["feed"];

// name a category
$res = mysql_query("SELECT id, name FROM categories");
while($cat = mysql_fetch_assoc($res))
$category[$cat['id']] = $cat['name'];

// RSS Feed description
$DESCR = "RSS Feeds";

// by category ?
if ($_GET['cat'])
$cats = explode(",", $_GET["cat"]);
if ($cats)
$where ="category IN (".implode(", ", $cats).") AND";

// start the RSS feed output
header("Content-Type: application/xml");
print("<?xml version=\"1.0\" encoding=\"windows-1251\" ?>\n<rss version=\"0.91\">\n<channel>\n" .
"<title>" . $SITENAME . "</title>\n<link>" . $BASEURL . "</link>\n<description>" . $DESCR . "</description>\n" .
"<language>en-usde</language>\n<copyright>Copyright � 2004 " . $SITENAME . "</copyright>\n<webMaster>" . $SITEEMAIL . "</webMaster>\n" .
"<image><title>" . $SITENAME . "</title>\n<url>" . $BASEURL . "/favicon.ico</url>\n<link>" . $BASEURL . "</link>\n" .
"<width>16</width>\n<height>16</height>\n<description>" . $DESCR . "</description>\n</image>\n");

// get all vars
$res = mysql_query("SELECT id,name,descr,filename,size,category,seeders,leechers,added FROM torrents WHERE $where visible='yes' ORDER BY added DESC LIMIT 15") or sqlerr(__FILE__, __LINE__);
while ($row = mysql_fetch_row($res)){
list($id,$name,$descr,$filename,$size,$cat,$seeders,$leechers,$added,$catname) = $row;

// ddl or detail ?
if ($feed == "dl")
$link = "$BASEURL/download.php/$id/". ($passkey ? "$passkey/" : "") ."$filename";
else
$link = "$BASEURL/details.php?id=$id&amp;hit=1";

// output of all data
echo("<item><title>" . htmlspecialchars($name) . "</title>\n<link>" . $link . "</link>\n<description>\nCategory: " . $category[$cat] . " \n Size: " . mksize($size) . "\n Added: " . $added . "\n Description:\n " . htmlspecialchars($descr) . "\n</description>\n</item>\n");
}

echo("</channel>\n</rss>\n");
?>