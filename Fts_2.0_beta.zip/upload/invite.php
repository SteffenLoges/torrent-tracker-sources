<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: invite.php - Invite System.                                      |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
require "include/bittorrent.php";

dbconn();

loggedinorreturn();
if($invitesys == 'no') stderr('Error!','Invite system is off');
$id = 0 + $_GET["id"];
$type = unesc($_GET["type"]);


stdhead("Invites");





$res = mysql_query("SELECT invites FROM users WHERE id = $id") or sqlerr();
$inv = mysql_fetch_assoc($res);


if ($inv["invites"] != 1){
$_s = "s";
} else {
$_s = "";
}

if ($type == 'new'){
print("<form method=post action=takeinvite.php?id=$id>".
"<table border=1 width=750 cellspacing=0 cellpadding=5>".
"<tr class=tabletitle><td colspan=2><b>Invite someone to join F1RW ($inv[invites] invitation$_s left)</b></td></tr>".
"<tr class=tableb><td width=15%>Email Address</td><td><input type=text size=40 name=email><br><font class=small>Email Address must be valid. The invitee will receive an email about your invite.</font></td></tr>".
"<tr class=tableb><td>Message</td><td><textarea name=body rows=6 cols=80></textarea></td></tr>".
"<tr class=tableb><td align=center colspan=2><input type=submit value=Invite style='height: 20px'></td></tr>".
"</form></table>");



} else {


$rel = mysql_query("SELECT COUNT(*) FROM users WHERE invited_by = $id") or sqlerr();
$arro = mysql_fetch_row($rel);
$number = $arro[0];


$ret = mysql_query("SELECT id, username, email, uploaded, downloaded, status, warned, enabled, donor, email FROM users WHERE invited_by = $id") or sqlerr();
$num = mysql_num_rows($ret);

print("<form method=post action=takeconfirm.php?id=$id><table border=1 width=750 cellspacing=0 cellpadding=5>".
"<tr class=tabletitle><td colspan=7><b>Current status of invitees</b> ($number)</td></tr>");

if(!$num){
print("<tr class=tableb><td colspan=7>No invitees yet.</tr>");
} else {


print("<tr class=tableb><td><b>Username</b></td><td><b>Email</b></td><td><b>Uploaded</b></td><td><b>Downloaded</b></td><td><b>Ratio</b></td><td><b>Status</b></td>");
if ($CURUSER[id] == $id || get_user_class() >= UC_SYSOP)
print("<td align=center><b>Confirm</b></td>");

print("</tr>");
for ($i = 0; $i < $num; ++$i)
{
  $arr = mysql_fetch_assoc($ret);
  if ($arr[status] == 'pending')
  $user = "<td align=left><a href=checkuser.php?id=$arr[id]>$arr[username]</a></td>";
  else
  $user = "<td align=left><a href=userdetails.php?id=$arr[id]>$arr[username]</a>" .($arr["warned"]  == "yes" ? "&nbsp;<img src=pic/warned.gif border=0 alt='Warned'>" : "")."&nbsp;" .($arr["enabled"]  == "no" ? "&nbsp;<img src=pic/disabled.gif border=0 alt='Disabled'>" : "")."&nbsp;" .($arr["donor"]  == "yes" ? "<img src=pic/star.gif border=0 alt='Donor'>" : "")."</td>";

  if ($arr["downloaded"] > 0) {
      $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 3);
      $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
      } else {
      if ($arr["uploaded"] > 0) {
      $ratio = "Inf.";
      }
      else {
      $ratio = "---";
      }
	  }
  if ($arr["status"] == 'confirmed')
      $status = "<a href=userdetails.php?id=$arr[id]><font color=#1f7309>Confirmed</font></a>";
      else
      $status = "<a href=checkuser.php?id=$arr[id]><font color=#ca0226>Pending</font></a>";	    	  
	  
print("<tr class=tableb>$user<td>$arr[email]</td><td>" . mksize($arr[uploaded]) . "</td><td>" . mksize($arr[downloaded]) . "</td><td>$ratio</td><td>$status</td>");
if ($CURUSER[id] == $id || get_user_class() >= UC_SYSOP){
print("<td align=center>");
if ($arr[status] == 'pending')
print("<input type=\"checkbox\" name=\"conusr[]\" value=\"" . $arr[id] . "\" />");
print("</td>");
}

print("</tr>");  	
} 
}
if ($CURUSER[id] == $id || get_user_class() >= UC_SYSOP){ 	
print("<input type=hidden name=email value=$arr[email]>");
print("<tr class=tableb><td colspan=7 align=right><input type=submit value='Confirm Users' style='height: 20px'></form></td></tr>");
print("<tr class=tableb><td colspan=7 align=center><form method=post action=invite.php?id=$id&type=new><input type=submit value='Invite Someone' style='height: 20px'></form></td></tr>");
}
print("</table><br>");










$rul = mysql_query("SELECT COUNT(*) FROM invites WHERE inviter = $id") or sqlerr();
$arre = mysql_fetch_row($rul);
$number1 = $arre[0];


$rer = mysql_query("SELECT invitee, hash, time_invited FROM invites WHERE inviter = $id") or sqlerr();
$num1 = mysql_num_rows($rer);


print("<table border=1 width=750 cellspacing=0 cellpadding=5>".
"<tr class=tabletitle><td colspan=6><b>Current status of sent out invites</b> ($number1)</td></tr>");

if(!$num1){
print("<tr class=tableb><td colspan=6>No invitations sent out at the moment.</tr>");
} else {

print("<tr class=tableb><td><b>Email</b></td><td><b>Hash</b></td><td><b>Send Date</b></td></tr>");
for ($i = 0; $i < $num1; ++$i)
{
  $arr1 = mysql_fetch_assoc($rer);
  print("<tr class=tableb><td>$arr1[invitee]<td>$arr1[hash]</td><td>$arr1[time_invited]</td></tr>");
}
}
print("</table>");












}

stdfoot();

die;

?>
