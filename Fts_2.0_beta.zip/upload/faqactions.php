<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: faqactions.php - Manage faq page.                                |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/

require "include/bittorrent.php";
dbconn();
loggedinorreturn();

if (get_user_class() < UC_ADMINISTRATOR) {
 stdhead(faa2);
 begin_main_frame();
 print("<h1>".faa1."</h1>");
 end_main_frame();
 stdfoot();
 die();
}

// ACTION: reorder - reorder sections and items
if ($_GET[action] == "reorder") {
 foreach($_POST[order] as $id => $position) mysql_query("UPDATE `faq` SET `order`='$position' WHERE id='$id'") or sqlerr();
 header("Refresh: 0; url=faqmanage.php"); 
}

// ACTION: edit - edit a section or item
elseif ($_GET[action] == "edit" && isset($_GET[id])) {
 stdhead(faa2);
 begin_main_frame();
 print("<h1 align=\"center\">".faa3."</h1>");

 $res = mysql_query("SELECT * FROM `faq` WHERE `id`='$_GET[id]' LIMIT 1");
 while ($arr = mysql_fetch_array($res, MYSQL_BOTH)) {
  $arr[question] = htmlspecialchars($arr[question]);
  $arr[answer] = htmlspecialchars($arr[answer]);
  if ($arr[type] == "item") {
   print("<form method=\"post\" action=\"faqactions.php?action=edititem\">");
   print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\" align=\"center\">\n");
   print("<tr><td>".faa4.":</td><td>$arr[id] <input type=\"hidden\" name=\"id\" value=\"$arr[id]\" /></td></tr>\n");
   print("<tr><td>".faa5.":</td><td><input style=\"width: 300px;\" type=\"text\" name=\"question\" value=\"$arr[question]\" /></td></tr>\n");
   print("<tr><td style=\"vertical-align: top;\">".faa6.":</td><td><textarea style=\"width: 300px; height=100px;\" name=\"answer\">$arr[answer]</textarea></td></tr>\n");
   if ($arr[flag] == "0") print("<tr><td>".faa7."</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\" selected=\"selected\">".faa8."</option><option value=\"1\" style=\"color: #000000;\">".faa9."</option><option value=\"2\" style=\"color: #0000FF;\">".faa10."</option><option value=\"3\" style=\"color: #008000;\">".faa11."</option></select></td></tr>");
   elseif ($arr[flag] == "2") print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\">".faa8."</option><option value=\"1\" style=\"color: #000000;\">".faa9."</option><option value=\"2\" style=\"color: #0000FF;\" selected=\"selected\">".faa10."</option><option value=\"3\" style=\"color: #008000;\">".faa11."</option></select></td></tr>");
   elseif ($arr[flag] == "3") print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\">".faa8."</option><option value=\"1\" style=\"color: #000000;\">".faa9."</option><option value=\"2\" style=\"color: #0000FF;\">".faa10."</option><option value=\"3\" style=\"color: #008000;\" selected=\"selected\">".faa11."</option></select></td></tr>");
   else print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\">".faa8."</option><option value=\"1\" style=\"color: #000000;\" selected=\"selected\">".faa9."</option><option value=\"2\" style=\"color: #0000FF;\">".faa10."</option><option value=\"3\" style=\"color: #008000;\">".faa11."</option></select></td></tr>");
   print("<tr><td>".faa12.":</td><td><select style=\"width: 300px;\" name=\"categ\" />");
   $res2 = mysql_query("SELECT `id`, `question` FROM `faq` WHERE `type`='categ' ORDER BY `order` ASC");
   while ($arr2 = mysql_fetch_array($res2, MYSQL_BOTH)) {
    $selected = ($arr2[id] == $arr[categ]) ? " selected=\"selected\"" : "";
    print("<option value=\"$arr2[id]\"". $selected .">$arr2[question]</option>");
   }
   print("</td></tr>\n");
   print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" name=\"edit\" value=\"".faa13."\" style=\"width: 60px;\"></td></tr>\n");
   print("</table>");
  }
  elseif ($arr[type] == "categ") {
   print("<form method=\"post\" action=\"faqactions.php?action=editsect\">");
   print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\" align=\"center\">\n");
   print("<tr><td>".faa4.":</td><td>$arr[id] <input type=\"hidden\" name=\"id\" value=\"$arr[id]\" /></td></tr>\n");
   print("<tr><td>".faa14.":</td><td><input style=\"width: 300px;\" type=\"text\" name=\"title\" value=\"$arr[question]\" /></td></tr>\n");
   if ($arr[flag] == "0") print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\" selected=\"selected\">".faa8."</option><option value=\"1\" style=\"color: #000000;\">".faa9."</option></select></td></tr>");
   else print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\">".faa8."</option><option value=\"1\" style=\"color: #000000;\" selected=\"selected\">".faa9."</option></select></td></tr>");
   print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" name=\"edit\" value=\"Edit\" style=\"width: 60px;\"></td></tr>\n");
   print("</table>");
  }
 }

 end_main_frame();
 stdfoot();
}

// subACTION: edititem - edit an item
elseif ($_GET[action] == "edititem" && $_POST[id] != NULL && $_POST[question] != NULL && $_POST[answer] != NULL && $_POST[flag] != NULL && $_POST[categ] != NULL) {
 $question = addslashes($_POST[question]);
 $answer = addslashes($_POST[answer]);
 mysql_query("UPDATE `faq` SET `question`='$question', `answer`='$answer', `flag`='$_POST[flag]', `categ`='$_POST[categ]' WHERE id='$_POST[id]'") or sqlerr();
 header("Refresh: 0; url=faqmanage.php"); 
}

// subACTION: editsect - edit a section
elseif ($_GET[action] == "editsect" && $_POST[id] != NULL && $_POST[title] != NULL && $_POST[flag] != NULL) {
 $title = addslashes($_POST[title]);
 mysql_query("UPDATE `faq` SET `question`='$title', `answer`='', `flag`='$_POST[flag]', `categ`='0' WHERE id='$_POST[id]'") or sqlerr();
 header("Refresh: 0; url=faqmanage.php"); 
}

// ACTION: delete - delete a section or item
elseif ($_GET[action] == "delete" && isset($_GET[id])) {
 if ($_GET[confirm] == "yes") {
  mysql_query("DELETE FROM `faq` WHERE `id`='$_GET[id]' LIMIT 1") or sqlerr();
  header("Refresh: 0; url=faqmanage.php"); 
 }
 else {
  stdhead(faa15);
  begin_main_frame();
  print("<h1 align=\"center\">".faa16."</h1>");
  print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" width=\"95%\">\n<tr><td align=\"center\">Please click <a href=\"faqactions.php?action=delete&id=$_GET[id]&confirm=yes\">here</a> to confirm.</td></tr>\n</table>\n");
  end_main_frame();
  stdfoot();
 }
}

// ACTION: additem - add a new item
elseif ($_GET[action] == "additem" && $_GET[inid]) {
 stdhead("faa15");
 begin_main_frame();
 print("<h1 align=\"center\">".faa17."</h1>");
 print("<form method=\"post\" action=\"faqactions.php?action=addnewitem\">");
 print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\" align=\"center\">\n");
 print("<tr><td>".faa5.":</td><td><input style=\"width: 300px;\" type=\"text\" name=\"question\" value=\"\" /></td></tr>\n");
 print("<tr><td style=\"vertical-align: top;\">".faa6.":</td><td><textarea style=\"width: 300px; height=100px;\" name=\"answer\"></textarea></td></tr>\n");
 print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\">".faa8."</option><option value=\"1\" style=\"color: #000000;\">".faa9."</option><option value=\"2\" style=\"color: #0000FF;\">".faa10."</option><option value=\"3\" style=\"color: #008000;\" selected=\"selected\">".faa11."</option></select></td></tr>");
 print("<tr><td>".faa12.":</td><td><select style=\"width: 300px;\" name=\"categ\" />");
 $res = mysql_query("SELECT `id`, `question` FROM `faq` WHERE `type`='categ' ORDER BY `order` ASC");
 while ($arr = mysql_fetch_array($res, MYSQL_BOTH)) {
  $selected = ($arr[id] == $_GET[inid]) ? " selected=\"selected\"" : "";
  print("<option value=\"$arr[id]\"". $selected .">$arr[question]</option>");
 }
 print("</td></tr>\n");
 print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" name=\"edit\" value=\"Add\" style=\"width: 60px;\"></td></tr>\n");
 print("</table>");
}

// ACTION: addsection - add a new section
elseif ($_GET[action] == "addsection") {
 stdhead(faa2);
 begin_main_frame();
 print("<h1 align=\"center\">".faa18."</h1>");
 print("<form method=\"post\" action=\"faqactions.php?action=addnewsect\">");
 print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\" align=\"center\">\n");
 print("<tr><td>".faa14.":</td><td><input style=\"width: 300px;\" type=\"text\" name=\"title\" value=\"\" /></td></tr>\n");
 print("<tr><td>".faa7.":</td><td><select name=\"flag\" style=\"width: 110px;\"><option value=\"0\" style=\"color: #FF0000;\">".faa8."</option><option value=\"1\" style=\"color: #000000;\" selected=\"selected\">".faa9."</option></select></td></tr>");
 print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" name=\"edit\" value=\"Add\" style=\"width: 60px;\"></td></tr>\n");
 print("</table>");
}

// subACTION: addnewitem - add a new item to the db
elseif ($_GET[action] == "addnewitem" && $_POST[question] != NULL && $_POST[answer] != NULL && $_POST[flag] != NULL && $_POST[categ] != NULL) {
 $question = addslashes($_POST[question]);
 $answer = addslashes($_POST[answer]);
 $res = mysql_query("SELECT MAX(`order`) FROM `faq` WHERE `type`='item' AND `categ`='$_POST[categ]'");
 while ($arr = mysql_fetch_array($res, MYSQL_BOTH)) $order = $arr[0] + 1;
 mysql_query("INSERT INTO `faq` (`type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES ('item', '$question', '$answer', '$_POST[flag]', '$_POST[categ]', '$order')") or sqlerr();
 header("Refresh: 0; url=faqmanage.php"); 
}

// subACTION: addnewsect - add a new section to the db
elseif ($_GET[action] == "addnewsect" && $_POST[title] != NULL && $_POST[flag] != NULL) {
 $title = addslashes($_POST[title]);
 $res = mysql_query("SELECT MAX(`order`) FROM `faq` WHERE `type`='categ'");
 while ($arr = mysql_fetch_array($res, MYSQL_BOTH)) $order = $arr[0] + 1;
 mysql_query("INSERT INTO `faq` (`type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES ('categ', '$title', '', '$_POST[flag]', '0', '$order')") or sqlerr();
 header("Refresh: 0; url=faqmanage.php");
}

else header("Refresh: 0; url=faqmanage.php");
?>