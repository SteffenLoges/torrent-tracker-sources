<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: clients.php - View all clients.                                  |
// | Version: 0.3                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
    require "include/bittorrent.php";
    dbconn(false);
    $res2 = mysql_query("SELECT agent,peer_id FROM peers  GROUP BY agent ") or sqlerr();
    stdhead("All Clients");
    print("<table align=center border=3 cellspacing=0 cellpadding=5 width=100%>\n");
    print("<tr><td class=colhead>".cl1."</td><td class=colhead>".cl2."</td></tr>\n");
    while($arr2 = mysql_fetch_assoc($res2))
    {
        print("</a></td><td align=left>$arr2[agent]</td><td align=left>$arr2[peer_id]</td></tr>\n");
    }
    print("</table>\n");
    stdfoot();
?>