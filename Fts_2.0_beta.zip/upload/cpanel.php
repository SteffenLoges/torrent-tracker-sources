<?
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: cpanel.php - Administration module.                              |
// | Version: 3.4                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/
include'include/bittorrent.php';
if(!$CURUSER || $usergroups['canstaffpanel'] != 'yes')
redirect('index.php','You don\'t have access here');
ahead();
$action = isset($_POST['action']) ? htmlspecialchars($_POST['action']) : (isset($_GET['action']) ? htmlspecialchars($_GET['action']) : '');
if(empty($action)) {
?>
				<table class="adminheading" border="0">
		<tr>
			<th class="cpanel">
			Control Panel<?make_help('main.administrator');?>
			</th>
		</tr>
		</table>
		<table class="adminform">
<tr>
	<td width="55%" valign="top">

	   	<div id="cpanel">
				<div style="float:left;">
			<div class="icon">
				<?print('<a href="cpanel.php?action=info" '.pres("#loading").'>'); ?>
					<img src="templates/administrator-templates/default/images/122.png"  width=64 height=64 align="middle" border="0" /><span>Site Information</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
				<?print('<a href="cpanel.php?action=settingsinfo"'.pres().'>'); ?>
					<img src="templates/administrator-templates/default/images/111.png"  width=64 height=64 align="middle" border="0" /><span>Settings Information</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
			<?	print('<a href="cpanel.php?action=avtemp"'.pres().'>'); ?>
					<img src="templates/administrator-templates/default/images/131.png"  width=64 height=64 align="middle" border="0" /><span>Avaible Templates</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
			<?	print('<a href="cpanel.php?action=mainsettings"'.pres().'>'); ?>
					<img src="templates/administrator-templates/default/images/128.png"  width=64 height=64 align="middle" border="0" /><span>Main Settings</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
		<?	print('<a href="cpanel.php?action=themesettings"'.pres().'>');?>
					<img src="templates/administrator-templates/default/images/117.png"  width=64 height=64 align="middle" border="0" /><span>Theme Settings</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
			<?	print('<a href="cpanel.php?action=modssettings"'.pres().'>');?>
					<img src="templates/administrator-templates/default/images/139.png"  width=64 height=64 align="middle" border="0" /><span>Extra-mods Settings</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
				<?	print('<a href="cpanel.php?action=adminsettings"'.pres().'>');?>
					<img src="templates/administrator-templates/default/images/1.png"  width=64 height=64 align="middle" border="0" /><span>Admin. Settings</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
				<?	print('<a href="cpanel.php?action=fmsettings"'.pres().'>'); ?>
					<img src="templates/administrator-templates/default/images/x21.png"  width=64 height=64 align="middle" border="0" /><span>File Man. Settings</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
				<?	print('<a href="cpanel.php?action=optimizedb"'.pres("a",'lol').'>');?>
				

					<img src="templates/administrator-templates/default/images/96.png"  width=64 height=64 align="middle" border="0" /><span>Optimize Db</span>
				</a>
			</div>
		</div>
<div style="float:left;">
			<div class="icon">
				<a href="ft2.php">
					<img src="templates/administrator-templates/default/images/x22.png"  width=64 height=64 align="middle" border="0" /><span>File Manager</span>
				</a>
			</div>
		</div>
		<?
		$modules = getmodules('admin/modules');
foreach($modules as $m) {
if(file_exists('admin/modules/'.$m.'/admin.php'))	include('admin/modules/'.$m.'/admin.php');
}

?>

			
			</div>

	<div style="clear:both;"> </div>
		</td>
	</table>	
<? }
elseif($action == 'info') {
$pathway = '/info';
?>
		<table class="adminform">
		<th class="cpanel">
			Site Information<?make_help('main.info.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">
				<div style="float:left;">
			


			
 <?
$phpversion = phpversion();
	$mysqlversion = get_mysql_version();
	$serverload = get_server_load();
	$totalusers = get_count('totalusers', 'users', 'WHERE status=\'confirmed\'');
	$timecut = time() - 86400;
	$newuserstoday = get_count('totalnewusers', 'users', 'WHERE UNIX_TIMESTAMP(added) > '.sqlesc($timecut));
	$pendingusers = get_count('pendingusers', 'users', 'WHERE status = \'pending\'');
	$todaycomments = get_count('todaycomments', 'comments', 'WHERE UNIX_TIMESTAMP(added) > '.sqlesc($timecut));
	$gd2support = (extension_loaded('gd') ? '<font color=green>Enabled</font>' : '<font color=red>Disabled</font>');
	$curlsupport = (extension_loaded('curl') ? '<font color=green>Enabled</font>' : '<font color=red>Disabled</font>');
	$sessionsupport = (function_exists('session_save_path') ? '<font color=green>Enabled</font>' : '<font color=red>Disabled</font>');
	$todayvisits = get_count('todayvisits', 'users', 'WHERE UNIX_TIMESTAMP(last_access) > '.sqlesc($timecut));

	echo make_style();
	$str = '
	<table width=100%>
  <tr>
    <td class="none"><div align="left"><b>PHP Version</b></div></td>
    <td class="none"><div align="left">'.$phpversion.'</div></td>
        <td class="none"><div align="left"><b>CURL Support</b></div></td>
    <td class="none"><div align="left">'.$curlsupport.'</div></td>
    <td class="none"><div align="left"><b>Total Users</b></div></td>
    <td class="none"><div align="left">'.$totalusers.'</div></td>
  </tr>
  <tr>
    <td class="none"><div align="left"><b>MYSQL Version</b></div></td>
    <td class="none"><div align="left">'.$mysqlversion.'</div></td>
    <td class="none"><div align="left"><b>New Users Today</b></div></td>
    <td class="none"><div align="left">'.$newuserstoday.'</div></td>
  </tr>
  <tr>
    <td class="none"><div align="left"><b>GD2 Support</b></div></td>
    <td class="none"><div align="left">'.$gd2support.'</div></td>
    <td class="none"><div align="left"><b>Unconfirmed Users</b></div></td>
    <td class="none"><div align="left">'.$pendingusers.'</div></td>
  </tr>
  <tr>
    <td class="none"><div align="left"><b>Server Load</b></div></td>
    <td class="none"><div align="left">'.$serverload.'</div></td>
    <td class="none"><div align="left"><b>New Comments Today</b></div></td>
    <td class="none"><div align="left">'.$todaycomments.'</div></td>
  </tr>
   <tr>
    <td class="none"><div align="left"><b>Session Support</b></div></td>
    <td class="none"><div align="left">'.$sessionsupport.'</div></td>
    <td class="none"><div align="left"><b>Active Users Today</b></div></td>
    <td class="none"><div align="left">'.$todayvisits.'</div></td>
  </tr>
</table>';
	
	echo $str;
	die;

?>
		</div>			</div>
<?
}elseif($action == 'settingsinfo') {
	?>
	<table class="adminform">
		<th class="cpanel">
			Settings Info <?make_help('main.setinfo.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">
	   	<?
$locksetinf = false;
if ($locksetinf)
{
  stdmsg("Excuse...", "Settings info is off by core");
  
  exit;
}
			
echo make_style();
$text = '<font color=green>Main Settings</font>';
ReadConfig('MAIN');
$text .= '<BR>Tracker Online: '.$MAIN['site_online'].'';
$text .= '<BR>Base Url: '.$MAIN['baseurl'].'';
function ConvertSize($fs)
{
     if ($fs >= 1073741824)
      $fs = round($fs / 1073741824 * 100) / 100 . " Gb";
     elseif ($fs >= 1048576)
      $fs = round($fs / 1048576 * 100) / 100 . " Mb";
     elseif ($fs >= 1024)
      $fs = round($fs / 1024 * 100) / 100 . " Kb";
     else
      $fs = $fs . " b";
     return $fs;
} 
$text .= '<BR>Max Torrent size: '.ConvertSize($MAIN['maxtorentsize']).'('.$MAIN['maxtorentsize'].'B)';
$text .= '<BR>Announce Interval: '.$MAIN['annint'].'';
$text .= '<BR>Signup Timeout: '.$MAIN['signt'].'';
$text .= '<BR>Max Dead Torrent Time: '.$MAIN['max_dead_torrent_time'].'';
$text .= '<BR>Max Users: '.$MAIN['max_users'].'';
$text .= '<BR>Torrent Dir: '.$MAIN['torrent_dir'].'';
$text .= '<BR>Announce url: '.$MAIN['announce_url'].'';
$text .= '<BR>Peer limit: '.$MAIN['peerlimit'].'';
$text .= '<BR>Tracker Mail: '.$MAIN['mail'].'';
$text .= '<BR>Torrent Name: '.$MAIN['name'].'';
$text .= '<BR>Autoclean Interval: '.$MAIN['acv'].'';
$text .= '<BR>Pic Base Url: '.$MAIN['picbu'].'';
$text .= '<BR>IMG DIR: '.$MAIN['imgdir'].'';
echo $text;
print('</div></td>');
}elseif($action=='avtemp') {
	?>
	<table class="adminform">
		<th class="cpanel">
			Avaible Templates <?make_help('main.avtmp.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">

	<?
$template_dirs =  dir_list('templates');
$dirlist = '';
if (empty($template_dirs))
		$dirlist .= '<option value="">There is no template</option>';
	else {
		foreach ($template_dirs as $dir)
			$dirlist .= ''.$dir.'<BR>';
	}
	echo make_style();
$div = $dirlist;
$total = count($template_dirs);
$div .= 'Total templates: '.$total;
echo $div;
print('</div></td>');


}elseif ($action == 'savesettings_m'){
	GetVar(array('site_online','rcl','baseurl','maxtorentsize','annint','signt','max_dead_torrent_time','max_users','torrent_dir','announce_url','peerlimit','mail','name','acv','picbu','imgdir','boie','last5torrents','ucleanup','waitsystem','vtype','extorr','invitesys'));
	$MAIN['site_online'] = $site_online;
$MAIN['rcl'] = $rcl;
$MAIN['baseurl'] = $baseurl;
$MAIN['maxtorentsize'] = $maxtorentsize;
$MAIN['annint'] = $annint;
$MAIN['signt'] = $signt;
$MAIN['max_dead_torrent_time'] = $max_dead_torrent_time;
$MAIN['max_users'] = $max_users;
$MAIN['torrent_dir'] = $torrent_dir;
$MAIN['announce_url'] = $announce_url;
$MAIN['peerlimit'] = $peerlimit;
$MAIN['mail'] = $mail;
$MAIN['name'] = $name;
$MAIN['acv'] = $acv;
$MAIN['picbu'] = $picbu;
$MAIN['imgdir'] = $imgdir;
$MAIN['boie'] = $boie;
$MAIN['last5torrents'] = $last5torrents;
$MAIN['ucleanup'] = $ucleanup;
$MAIN['waitsystem'] = $waitsystem;
$MAIN['vtype'] = $vtype;
$MAIN['extorr'] = $extorr;
$MAIN['invitesys'] = $invitesys;
	WriteConfig('MAIN', $MAIN);
	$actiontime = date("F j, Y, g:i a"); 
	write_log("Tracker MAIN settings updated by $CURUSER[username]. $actiontime");
	redirect("cpanel.php?action=mainsettings","Settings saved, you will now be redirected.");
}elseif ($action == 'savesettings_mds'){
	GetVar(array('iptc'));
	$MODS['iptc'] = $iptc;

	WriteConfig('MODS', $MODS);
	$actiontime = date("F j, Y, g:i a"); 
	write_log("Tracker MODS settings updated by $CURUSER[username]. $actiontime");
	redirect("cpanel.php?action=modssettings","Settings saved, you will now be redirected.");

}elseif ($action == 'mainsettings') {
?>
<table class="adminform">
		<th class="cpanel">
			Main Settings <?make_help('main.mainset.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">
	   	<?
print('<table border="0" class="adminform">');	

?>

<?	

print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_m'>");	
	tr("Tracker Online? ", "yes <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "no" ? " checked" : "") . " value='no'> <br />Want to turn off your Tracker while performing updates or other types of maintenance?<br />\n", 1);
tr("Disable Right Click ", "yes <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "no" ? " checked" : "") . " value='no'> <br /> Do not allow users to right click<br />\n", 1);
tr("Boycott Internet Explorer ", "yes <INPUT type='radio' name='boie'" . ($MAIN["boie"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='boie'" . ($MAIN["boie"] == "no" ? " checked" : "") . " value='no'> <br /> Do not allow users to navigate with MSIE<br />\n", 1);
tr("Enable Last 5 torrents on index ", "yes <INPUT type='radio' name='last5torrents'" . ($MAIN["last5torrents"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='last5torrents'" . ($MAIN["last5torrents"] == "no" ? " checked" : "") . " value='no'> <br /> Show last 5 torrents block on mainpage<br />\n", 1);
tr("Invite system enabled ", "yes <INPUT type='radio' name='invitesys'" . ($MAIN["invitesys"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='invitesys'" . ($MAIN["invitesys"] == "no" ? " checked" : "") . " value='no'> <br /> Disable basic registration and enable invite!<br />\n", 1);
tr("Enable update torrents on cleanup ", "yes <INPUT type='radio' name='ucleanup'" . ($MAIN["ucleanup"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='ucleanup'" . ($MAIN["ucleanup"] == "no" ? " checked" : "") . " value='no'> <br /> Recomended: yes<br />\n", 1);
tr("Enable external torrents upload ", "yes <INPUT type='radio' name='extorr'" . ($MAIN["extorr"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='extorr'" . ($MAIN["extorr"] == "no" ? " checked" : "") . " value='no'> <br /> Recomended: yes<br />\n", 1);	
tr("Verification type ", "Email <INPUT type='radio' name='vtype'" . ($MAIN["vtype"] == "email" ? " checked" : " checked") . " value='email'> Automaticly <INPUT type='radio' name='vtype'" . ($MAIN["vtype"] == "auto" ? " checked" : "") . " value='auto'> Staff <INPUT type='radio' name='vtype'" . ($MAIN["vtype"] == "staff" ? " checked" : "") . " value='staff'> <br /> Recomended: email.<BR>Email - send verification link via email<BR>Automaticly - no verification<BR>Staff - manual verification,by staff<br />\n", 1);

	tr("Site Base Url ","<input type='text' id='specialboxes' name=baseurl value='".($MAIN["baseurl"] ? $MAIN["baseurl"] : "??" )."'> This url is verry important.\n", 1);

tr("Max Torrent Size ","<input type='text' id='specialboxes' name=maxtorentsize value='".($MAIN["maxtorentsize"] ? $MAIN["maxtorentsize"] : "" )."'> Recomended: 1000000.\n", 1);

tr("Announcee Interval ","<input type='text' id='specialboxes' name=annint value='".($MAIN["annint"] ? $MAIN["annint"] : "" )."'> Recomended: 60 * 60.\n", 1);

tr("Signup Timeout ","<input type='text' id='specialboxes' name=signt value='".($MAIN["signt"] ? $MAIN["signt"] : "" )."'> Recomended: 86400 * 3.\n", 1);

tr("Max torrent dead time ","<input type='text' id='specialboxes' name=max_dead_torrent_time value='".($MAIN["max_dead_torrent_time"] ? $MAIN["max_dead_torrent_time"] : "" )."'> Recomended: 6 * 3600.\n", 1);

tr("Max users ","<input type='text' id='specialboxes' name=max_users value='".($MAIN["max_users"] ? $MAIN["max_users"] : "" )."'> Recomended: 3000 or 5000.\n", 1);

tr("Torrent Dir ","<input type='text' id='specialboxes' name=torrent_dir value='".($MAIN["torrent_dir"] ? $MAIN["torrent_dir"] : "" )."'> Recomended: torrents.\n", 1);

tr("Announce url ","<input type='text' id='specialboxes' name=announce_url value='".($MAIN["announce_url"] ? $MAIN["announce_url"] : "" )."'> Recomended: http://".$_SERVER['HTTP_HOST']."/announce.php .\n", 1);

tr("Peer limit ","<input type='text' id='specialboxes' name=peerlimit value='".($MAIN["peerlimit"] ? $MAIN["peerlimit"] : "" )."'> Recomended: 5000 .\n", 1);

tr("Site email ","<input type='text' id='specialboxes' name=mail value='".($MAIN["mail"] ? $MAIN["mail"] : "" )."'> Recomended: noreply@".$_SERVER['HTTP_HOST']." .\n", 1);

tr("Site name ","<input type='text' id='specialboxes' name=name value='".($MAIN["name"] ? $MAIN["name"] : "" )."'> Nothing recomended .\n", 1);

tr("Autoclean interval ","<input type='text' id='specialboxes' name=acv value='".($MAIN["acv"] ? $MAIN["acv"] : "" )."'> Recomended: 900 .\n", 1);

tr("Pic base url ","<input type='text' id='specialboxes' name=picbu value='".($MAIN["picbu"] ? $MAIN["picbu"] : "" )."'> Recomended: pic/ .\n", 1);

tr("IMG Dir ","<input type='text' id='specialboxes' name=imgdir value='".($MAIN["imgdir"] ? $MAIN["imgdir"] : "" )."'> Recomended: pic/ .\n", 1);

	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table>");
?>
</div></div>
<?
}elseif ($action == 'savesettings_admin'){
	GetVar(array('lv'));
	$ADMIN['lv'] = $lv;


	WriteConfig('ADMIN', $ADMIN);
	$actiontime = date("F j, Y, g:i a"); 
	redirect("cpanel.php?action=adminsettings","Settings saved, you will now be redirected.");

}
elseif ($action == 'savesettings_t'){
	GetVar(array('defaulttemplate'));
	$THEME['default'] = $defaulttemplate;


	WriteConfig('THEME', $THEME);
	$actiontime = date("F j, Y, g:i a"); 
	write_log("Tracker THEME settings updated by $CURUSER[username]. $actiontime");
	redirect("cpanel.php?action=themesettings","Settings saved, you will now be redirected.");
}elseif ($action == 'themesettings') {
?>
<table class="adminform">
		<th class="cpanel">
			Template Settings <?make_help('main.temset.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">
	   	<?
print('<table border="0" class="adminform">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_t'>");
	
	
$template_dirs =  dir_list('templates');
echo '<tr><td class="heading" valign="top" align="right">Please select default template of your tracker:</td>';
echo '<td valign="top" align="left"><select name="defaulttemplate">';
if (empty($template_dirs))
		$dirlist .= '<option value="">There is no template</option>';
	else {
		foreach ($template_dirs as $dir)
			$dirlist .= '<option value="'.$dir.'" '.($defaulttemplate == $dir ? 'selected' : '').'>'.$dir.'</option>';
	}
	echo $dirlist.'</select></td></tr>';
/*
tr("Tracker Online? ", "yes <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "no" ? " checked" : "") . " value='no'> <br />Want to turn off your Tracker while performing updates or other types of maintenance?<br />\n", 1);
tr("IMG Dir ","<input type='text' id='specialboxes' name=imgdir value='".($MAIN["imgdir"] ? $MAIN["imgdir"] : "" )."'> Recomended: pic/ .\n", 1);
*/
	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table>");

?>
</div></td>
<?
}elseif ($action == 'modssettings') {
?>
<table class="adminform">
		<th class="cpanel">
			Extra-mods Settings <?make_help('main.emoset.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">
	   	<?

print('<table border="0" class="adminform">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_mds'>");
tr("Enable ip-to-country mod ", "yes <INPUT type='radio' name='iptc'" . ($MODS["iptc"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='iptc'" . ($MODS["iptc"] == "no" ? " checked" : "") . " value='no'> <br /> This is now auto-included, so you don't have to download anything.<br />\n", 1);

	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table></div></td>"); }

elseif ($action == 'adminsettings') {
?>
<table class="adminform">
		<th class="cpanel">
			Administrator Settings <?make_help('main.admset.administrator');?>
			</th><tr>
		
	<td width="55%" valign="top">
	   	<div id="cpanel">
	   	<?

print('<table border="0" class="adminform">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_admin'>");
tr("Enable Latest Version is(in footer) ", "yes <INPUT type='radio' name='lv'" . ($laversion == "yes" ? " checked" : "") . " value='yes'> no <INPUT type='radio' name='lv'" . ($laversion == "no" ? " checked" : "") . " value='no'> <br /> We encourage you to have this ON.<br />\n", 1);

	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table></div></td>"); }
elseif($action == 'ftsnews') {
$nurl = @file_get_contents('http://cs.frts.info/news.txt');
echo"<div class='adminform'>";
echo $nurl;
echo"</div>";
}
elseif ($action == 'savesettings_fm'){
	GetVar(array('upls','uper','upbl','uptbl','upel'));
	$F['upls'] = $upls;
	$F['uper'] = $uper;
	$F['upbl'] = $upbl;
	$F['uptbl'] = $uptbl;
	$F['upel'] = $upel;


	WriteConfig('FILEMAN', $F);
	$actiontime = date("F j, Y, g:i a"); 
	redirect("cpanel.php?action=fmsettings","Settings saved, you will now be redirected.");
}
elseif ($action == 'fmsettings') {
print('<BR><table border="0" class="adminform">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_fm'>");
tr("Max. Upload Size ","<input type='text' id='specialboxes' name=upls value='".($FILEMAN["upls"] ? $FILEMAN["upls"] : "" )."'> Maximum file upload size - in bytes.\n", 1);
tr("Upload Permission ","<input type='text' id='specialboxes' name=uper value='".($FILEMAN["uper"] ? $FILEMAN["uper"] : "" )."'> Permission for uploaded files.\n", 1);
tr("File Blacklist ","<input type='text' id='specialboxes' size=80 name=upbl value='".($FILEMAN["upbl"] ? $FILEMAN["upbl"] : "" )."'> Specific files that will not be shown.\n", 1);
tr("File Type Blacklist ","<input type='text' id='specialboxes' size=80 name=uptbl value='".($FILEMAN["uptbl"] ? $FILEMAN["uptbl"] : "" )."'> File types that are not allowed for upload.\n", 1);
tr("Edit List ","<input type='text' id='specialboxes' size=80 name=upel value='".($FILEMAN["upel"] ? $FILEMAN["upel"] : "" )."'> List of file types that can be edited.\n", 1);

	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table>"); }
elseif($action == 'ftsnews') {
$nurl = @file_get_contents('http://cs.frts.info/news.txt');
echo"<div class='adminform'>";
echo $nurl;
echo"</div>";
}

elseif($action == 'optimizedb') {
$tables = "";
$tablesshow = mysql_query("SHOW TABLES FROM `".$mysql_db."`");
while (list($table) = mysql_fetch_row($tablesshow)){
$tables .= "`".mysql_real_escape_string($table)."`,";
}
$tables .= "...";
$tables = str_replace(",...", "", $tables);
mysql_query("OPTIMIZE TABLE ".$tables);

echo'OK!';
}
elseif($action == 'base64') {
?>
<table class="adminform">
		<th class="cpanel">
			Base64 encode/decode <?make_help('main.base64.administrator');?>
			</th><tr></table>
	   	<?
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='base64_calculate'>");
	print("Code to encode/decode<BR><textarea name='base64' cols=50 rows=30></textarea>");
tr('<BR>Encode/decode',"<select name='wtd'>
<option value='decode'>Decode</option>
<option value='encode'>Encode</option>
</select>",1);
?> 
     <?
print("<input type='submit' value='Process' ".pres('Processing base64 query - Plese wait.').">");
}
elseif($action == 'base64_calculate') {
	?>
	<table class="adminform">
		<th class="cpanel">
			Base64 encode/decode result <?make_help('main.base64-result.administrator');?>
			</th><tr></table>
			<?
	$method = $_POST['wtd'];
	$code = $_POST['base64'];
	if($method == 'decode')
	echo '<textarea cols=50 rows=30>'.base64_decode($code).'</textarea>';
	elseif($method == 'encode')
	echo '<textarea cols=50 rows=30>'.base64_encode($code).'</textarea>';
	else
	echo 'Php says: Unknown Method';
	?>

     <?
	print('<a href=cpanel.php?action=base64'.pres().'><button>Go back</button</a>');
}
elseif(isset($mod)) {
$mod = $_GET['mod'];
include('admin/modules/'.$mod.'/'.$action.'.php');
}

afoot();
?>