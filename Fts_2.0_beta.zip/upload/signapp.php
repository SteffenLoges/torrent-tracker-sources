<? 
/*
// +--------------------------------------------------------------------------+
// | Project:    FTS - Free Torrent Source                                    |
// +--------------------------------------------------------------------------+
// | Module: signapp.php - Signup Aplication.                                 |
// | Version: 0.1                                                             |
// +--------------------------------------------------------------------------+
// | This file is part of FTS. Fts is based on TBDev,                         |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | FTS is free software; you can redistribute it and/or modify              |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | FTS is distributed in the hope that it will be useful,                   |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with FTS; if not, write to the Free Software Foundation,           |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | FTS IS FREE SOFTWARE, but it still can contain some encoded files.       |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/

require_once("include/bittorrent.php"); 
dbconn(); 

stdhead("Registration"); 
begin_frame("..:: Registration ::.."); 

?> 

<p> 
<form method="post" action="takesignapp.php"> 
<center> 
<table class=tableinborder border=0 cellspacing=1 cellpadding=5> 
<? 
print("<tr class=tabletitle><td class=\"tablecat\" colspan=\"2\" align=left><center><b>Data about you</b></center></td></tr>\n"); 
?> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Username:</td> 
<td class="tablea" align=left><input type="text" size="40" name="username"/></td> 
</tr> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Password:</td><td class="tablea" align=left><input type="password" size="40" name="password"/></td> 
</tr> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Password again:</td><td class="tablea" align=left><input type="password" size="40" name="password_again"/></td> 
</tr> 
<tr class="tabletitle" valign=top> 
<td class="tablea" align="right" >Email:</td><td class="tablea" align=left><input type="text" size="40" name="email"/></td>
</tr>
<? 
$countries = "<option value=0>---- Choose ----</option>n"; 
$ct_r = mysql_query("SELECT id,name FROM countries ORDER BY name") or die; 
while ($ct_a = mysql_fetch_array($ct_r)) 
$countries .= "<option value=$ct_a[id]" . ($USER["country"] == $ct_a['id'] ? " selected" : "") . ">$ct_a[name]</option>n"; 

$downloadspeed = "<option value=0>---- Choose ----</option>\n"; 
$ds_a = mysql_query("SELECT id,name FROM downloadspeed ORDER BY id") or die; 
while ($ds_b = mysql_fetch_array($ds_a)) 
$downloadspeed .= "<option value=$ds_b[id]" . ($USER["download"] == $ds_b['id'] ? " selected" : "") . ">$ds_b[name]</option>\n"; 

$uploadspeed = "<option value=0>---- Choose ----</option>\n"; 
$us_a = mysql_query("SELECT id,name FROM uploadspeed ORDER BY id") or die; 
while ($us_b = mysql_fetch_array($us_a)) 
$uploadspeed .= "<option value=$us_b[id]" . ($USER["upload"] == $us_b['id'] ? " selected" : "") . ">$us_b[name]</option>\n"; 

$russiantrackers = "<option value=0>---- Choose ----</option>\n"; 
$ru_a = mysql_query("SELECT id,name FROM russiantrackers ORDER BY id") or die; 
while ($ru_b = mysql_fetch_array($ru_a)) 
$russiantrackers .= "<option value=$ru_b[id]" . ($USER["rustracker"] == $ru_b['id'] ? " selected" : "") . ">$ru_b[name]</option>\n"; 
?> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Country:</td><td class="tablea" align=left><select name=country><?=$countries?></select></td> 
</tr> 
<? 
print("<tr class=tabletitle><td class=\"tablecat\" colspan=\"2\" align=left><center><b>Specification of data</b></center></td></tr>\n"); 
?> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Whether you know how to use <br>Bittorrent?</td><td class="tablea" align=left><input type="radio" name="you_know" class="radio" checked="checked" value="yes">Yes <input type="radio" class="radio" name="you_know" value="no">No 
</td> 
</tr> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Whether are you <br> the participant of another <br>tracker ?</td><td class="tablea" align=left> 
<script type="text/javascript"> 
//<![CDATA[ 

function choose(objID) 
{ 
var panelIDs = [ 'no' , 'yes'], 
panel, 
i = 0, 
obj = document.getElementById(objID); 
while (panel = document.getElementById(panelIDs[i++])) 
panel.style.display = (panel != obj) ? 'none' : 'block'; 
} 

//]]> 
</script> 
</head> 
<body> 
<table border="0" cellspacing="0" cellpadding="2"> 
<tr> 
<td> 
<label><input type="radio" name="choice" class="radio" value="yes" onclick="choose(this.value)">Yes</label>�<label><input type="radio" class="radio" name="choice" value="no" checked="checked" onclick="choose(this.value)">No</label> 
</td> 
</tr> 
</table> 
<table id="no" class="panel" style="display:block;" border="0" cellspacing="0" cellpadding="2"> 
</table> 
<table id="yes" class="panel" border="0" cellspacing="0" cellpadding="2"> 
<tr class="tabletitle"> 
<td class="tablea">What tracker ? </td> 
<td class="tablea" align="left"> 
<select name="rustracker" id="id[1]"> <?=$russiantrackers?></select> 
</td> 
<tr class="tabletitle"> 
<td class="tablea">Your username on tracker:</td> 
<td class="tablea" align="left"><input size="20" name="trackerusername"></td> 
</tr> 
</tr> 
</table> 
</tr> 
<? 
print("<tr class=tabletitle><td class=\"tablecat\" colspan=\"2\" align=left><center><b>Speed of your Internet</b></center></td></tr>\n"); 
?> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Download:</td><td class="tablea" align=left><select name=download><?=$downloadspeed?></select></td> 
</tr> 
<tr class="tabletitle"> 
<td class="tablea" align="right">Upload:</td><td class="tablea" align=left><select name=upload><?=$uploadspeed?></select></td> 
</tr> 
<? 
print("<tr class=tabletitle><td class=\"tablecat\" colspan=\"2\" align=left><center><b>Little about you</b</center></td></tr>\n"); 
?> 
</td></tr> 
<tr class="tabletitle"><td class="tablea" align="right">Why we should accept <br> you on a site instead of someone another?</td><td class="tablea" align=left> 
<textarea name="why_you" rows="10" cols="51"></textarea></td></tr> 
<tr class="tabletitle"><td class="tablea" align="right">If you have something to add, <br> you can make it here.</td><td class="tablea" align=left> 
<textarea name="other_info" rows="10" cols="51"></textarea></td></tr> 
<tr class="tabletitle"><td class="tablea" colspan="2" align="center"> 
<center><input type=submit value="Make application!" style='height: 25px'></center></td></tr> 
</table> 
</form> 
<? 

/*stdfoot();*/ 

?>
