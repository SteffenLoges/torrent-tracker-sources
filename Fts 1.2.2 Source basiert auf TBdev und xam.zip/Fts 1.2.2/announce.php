<?

ob_start("ob_gzhandler");

// edit this configuration
$SITE_ONLINE = true;

$announce_interval = 60 * 60;

$MEMBERSONLY = true;

# the first one will be displayed on the pages
$announce_urls = array();
$announce_urls[] = "http://localhost/announce.php";

// Set this to your site URL... No ending slash!
$DEFAULTBASEURL = "http://localhost";

$mysql_host = "localhost"; ///edit with mysql host
$mysql_user = "root"; //edit with mysql user
$mysql_pass = ""; //edit with mysql pass
$mysql_db = "2"; //etdit with mysql db

// end of configuration

//
// Begin CrackerTracker  StandAlone
//

  $cracktrack = urldecode($_SERVER['QUERY_STRING']);
  $wormprotector = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
                                    'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
                                   'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
                                   'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
                                   'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
                                   'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
                                   'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
                                   'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
                                   'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
                                   'insert%20into', 'select%20', 'nigga(', '%20nigga', 'nigga%20', 'fopen', 'fwrite', '%20like', 'like%20',
                                   '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
                                   'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
                                   'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
                                   '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
                                   'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', '/usr/X11R6/bin/xterm', 'lsof%20',
                                   '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
                                   'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
                                   'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
                                   'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
                                   'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
                                   'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
                                   '<script', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
                                   'select from', 'drop%20', '.system', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=');

  $checkworm = str_replace($wormprotector, '*', $cracktrack);

  if ($cracktrack != $checkworm)
        {
          $cremotead = $_SERVER['REMOTE_ADDR'];
          $cuseragent = $_SERVER['HTTP_USER_AGENT'];

      $fp = fopen ('log.txt', 'a');
      fwrite ($fp, 'Blocked attack from: IP - ' . $_SERVER['REMOTE_ADDR'] . ' User Agent - ' . $_SERVER['HTTP_USER_AGENT'] . '
');
      fclose ($fp);

          die( "Attack detected! <br /><br /><b>Youre attack was blocked:</b><br />$cremotead - $cuseragent" );
        }

//
// End CrackerTracker StandAlone
//

// PHP5 with register_long_arrays off?
if (!isset($HTTP_POST_VARS) && isset($_POST))
{
$HTTP_POST_VARS = $_POST;
$HTTP_GET_VARS = $_GET;
$HTTP_SERVER_VARS = $_SERVER;
$HTTP_COOKIE_VARS = $_COOKIE;
$HTTP_ENV_VARS = $_ENV;
$HTTP_POST_FILES = $_FILES;
}

function strip_magic_quotes($arr)
{
foreach ($arr as $k => $v)
{
if (is_array($v))
{ $arr[$k] = strip_magic_quotes($v); }
else
{ $arr[$k] = stripslashes($v); }
}

return $arr;
}

if (get_magic_quotes_gpc())
{
if (!empty($_GET)) { $_GET = strip_magic_quotes($_GET); }
if (!empty($_POST)) { $_POST = strip_magic_quotes($_POST); }
if (!empty($_COOKIE)) { $_COOKIE = strip_magic_quotes($_COOKIE); }
}


// addslashes to vars if magic_quotes_gpc is off
// this is a security precaution to prevent someone
// trying to break out of a SQL statement.
//

if( !get_magic_quotes_gpc() )
{
if( is_array($HTTP_GET_VARS) )
{
while( list($k, $v) = each($HTTP_GET_VARS) )
{
if( is_array($HTTP_GET_VARS[$k]) )
{
while( list($k2, $v2) = each($HTTP_GET_VARS[$k]) )
{
$HTTP_GET_VARS[$k][$k2] = addslashes($v2);
}
@reset($HTTP_GET_VARS[$k]);
}
else
{
$HTTP_GET_VARS[$k] = addslashes($v);
}
}
@reset($HTTP_GET_VARS);
}

if( is_array($HTTP_POST_VARS) )
{
while( list($k, $v) = each($HTTP_POST_VARS) )
{
if( is_array($HTTP_POST_VARS[$k]) )
{
while( list($k2, $v2) = each($HTTP_POST_VARS[$k]) )
{
$HTTP_POST_VARS[$k][$k2] = addslashes($v2);
}
@reset($HTTP_POST_VARS[$k]);
}
else
{
$HTTP_POST_VARS[$k] = addslashes($v);
}
}
@reset($HTTP_POST_VARS);
}

if( is_array($HTTP_COOKIE_VARS) )
{
while( list($k, $v) = each($HTTP_COOKIE_VARS) )
{
if( is_array($HTTP_COOKIE_VARS[$k]) )
{
while( list($k2, $v2) = each($HTTP_COOKIE_VARS[$k]) )
{
$HTTP_COOKIE_VARS[$k][$k2] = addslashes($v2);
}
@reset($HTTP_COOKIE_VARS[$k]);
}
else
{
$HTTP_COOKIE_VARS[$k] = addslashes($v);
}
}
@reset($HTTP_COOKIE_VARS);
}
}

// benc.php integration start
function benc($obj) {
        if (!is_array($obj) || !isset($obj["type"]) || !isset($obj["value"]))
                return;
        $c = $obj["value"];
        switch ($obj["type"]) {
                case "string":
                        return benc_str($c);
                case "integer":
                        return benc_int($c);
                case "list":
                        return benc_list($c);
                case "dictionary":
                        return benc_dict($c);
                default:
                        return;
        }
}

function benc_str($s) {
        return strlen($s) . ":$s";
}

function benc_int($i) {
        return "i" . $i . "e";
}

function benc_list($a) {
        $s = "l";
        foreach ($a as $e) {
                $s .= benc($e);
        }
        $s .= "e";
        return $s;
}

function benc_dict($d) {
        $s = "d";
        $keys = array_keys($d);
        sort($keys);
        foreach ($keys as $k) {
                $v = $d[$k];
                $s .= benc_str($k);
                $s .= benc($v);
        }
        $s .= "e";
        return $s;
}

function bdec_file($f, $ms) {
        $fp = fopen($f, "rb");
        if (!$fp)
                return;
        $e = fread($fp, $ms);
        fclose($fp);
        return bdec($e);
}

function bdec($s) {
        if (preg_match('/^(\d+):/', $s, $m)) {
                $l = $m[1];
                $pl = strlen($l) + 1;
                $v = substr($s, $pl, $l);
                $ss = substr($s, 0, $pl + $l);
                if (strlen($v) != $l)
                        return;
                return array(type => "string", value => $v, strlen => strlen($ss), string => $ss);
        }
        if (preg_match('/^i(\d+)e/', $s, $m)) {
                $v = $m[1];
                $ss = "i" . $v . "e";
                if ($v === "-0")
                        return;
                if ($v[0] == "0" && strlen($v) != 1)
                        return;
                return array(type => "integer", value => $v, strlen => strlen($ss), string => $ss);
        }
        switch ($s[0]) {
                case "l":
                        return bdec_list($s);
                case "d":
                        return bdec_dict($s);
                default:
                        return;
        }
}

function bdec_list($s) {
        if ($s[0] != "l")
                return;
        $sl = strlen($s);
        $i = 1;
        $v = array();
        $ss = "l";
        for (;;) {
                if ($i >= $sl)
                        return;
                if ($s[$i] == "e")
                        break;
                $ret = bdec(substr($s, $i));
                if (!isset($ret) || !is_array($ret))
                        return;
                $v[] = $ret;
                $i += $ret["strlen"];
                $ss .= $ret["string"];
        }
        $ss .= "e";
        return array(type => "list", value => $v, strlen => strlen($ss), string => $ss);
}

function bdec_dict($s) {
        if ($s[0] != "d")
                return;
        $sl = strlen($s);
        $i = 1;
        $v = array();
        $ss = "d";
        for (;;) {
                if ($i >= $sl)
                        return;
                if ($s[$i] == "e")
                        break;
                $ret = bdec(substr($s, $i));
                if (!isset($ret) || !is_array($ret) || $ret["type"] != "string")
                        return;
                $k = $ret["value"];
                $i += $ret["strlen"];
                $ss .= $ret["string"];
                if ($i >= $sl)
                        return;
                $ret = bdec(substr($s, $i));
                if (!isset($ret) || !is_array($ret))
                        return;
                $v[$k] = $ret;
                $i += $ret["strlen"];
                $ss .= $ret["string"];
        }
        $ss .= "e";
        return array(type => "dictionary", value => $v, strlen => strlen($ss), string => $ss);
}

// benc.php integration end

// global.php integration start
function get_date_time($timestamp = 0)
{
  if ($timestamp)
    return date("Y-m-d H:i:s", $timestamp);
  else
    return gmdate("Y-m-d H:i:s");
}

function sqlerr($file = '', $line = '')
{
  print("<table border=0 bgcolor=blue align=left cellspacing=0 cellpadding=10 style='background: blue'>" .
    "<tr><td class=embedded><font color=white><h1>SQL Error</h1>\n" .
  "<b>" . htmlspecialchars(mysql_error()) . ($file != '' && $line != '' ? "<p>in $file, line $line</p>" : "") . "</b></font></td></tr></table>");
  die;
}

define ('UC_USER', 0);
define ('UC_POWER_USER', 1);
define ('UC_VIP', 2);
define ('UC_UPLOADER', 3);
define ('UC_MODERATOR', 4);
define ('UC_ADMINISTRATOR', 5);
define ('UC_SYSOP', 6);

function auto_enter_cheater($userid, $rate, $upthis, $diff, $torrentid, $client, $ip, $last_up)
{
    mysql_query("INSERT INTO cheaters (added, userid, client, rate, beforeup, upthis, timediff, userip, torrentid) VALUES('" . get_date_time() . "', $userid, '$client', '$rate', '$last_up', '$upthis', '$diff', '$ip', '$torrentid')") or sqlerr(__FILE__, __LINE__);
}

// global.php integration end

// bittorrent.php integration start
function validip($ip)
{
        if (!empty($ip) && $ip == long2ip(ip2long($ip)))
        {
                // reserved IANA IPv4 addresses
                // http://www.iana.org/assignments/ipv4-address-space
                $reserved_ips = array (
                                array('0.0.0.0','2.255.255.255'),
                                array('10.0.0.0','10.255.255.255'),
                                array('127.0.0.0','127.255.255.255'),
                                array('169.254.0.0','169.254.255.255'),
                                array('172.16.0.0','172.31.255.255'),
                                array('192.0.2.0','192.0.2.255'),
                                array('192.168.0.0','192.168.255.255'),
                                array('255.255.255.0','255.255.255.255')
                );

                foreach ($reserved_ips as $r)
                {
                                $min = ip2long($r[0]);
                                $max = ip2long($r[1]);
                                if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
                }
                return true;
        }
        else return false;
}

function getip() {
   if (isset($_SERVER)) {
     if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && validip($_SERVER['HTTP_X_FORWARDED_FOR'])) {
       $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
     } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && validip($_SERVER['HTTP_CLIENT_IP'])) {
       $ip = $_SERVER['HTTP_CLIENT_IP'];
     } else {
       $ip = $_SERVER['REMOTE_ADDR'];
     }
   } else {
     if (getenv('HTTP_X_FORWARDED_FOR') && validip(getenv('HTTP_X_FORWARDED_FOR'))) {
       $ip = getenv('HTTP_X_FORWARDED_FOR');
     } elseif (getenv('HTTP_CLIENT_IP') && validip(getenv('HTTP_CLIENT_IP'))) {
       $ip = getenv('HTTP_CLIENT_IP');
     } else {
       $ip = getenv('REMOTE_ADDR');
     }
   }

   return $ip;
 }

function dbconn($autoclean = false)
{
    global $mysql_host, $mysql_user, $mysql_pass, $mysql_db;

    if (!@mysql_connect($mysql_host, $mysql_user, $mysql_pass))
    {
          switch (mysql_errno())
          {
                case 1040:
                case 2002:
                        if ($_SERVER[REQUEST_METHOD] == "GET")
                                die("<html><head><meta http-equiv=refresh content=\"5 $_SERVER[REQUEST_URI]\"></head><body><table border=0 width=100% height=100%><tr><td><h3 align=center>The server load is very high at the moment. Retrying, please wait...</h3></td></tr></table></body></html>");
                        else
                                die("Too many users. Please press the Refresh button in your browser to retry.");
        default:
                die("[" . mysql_errno() . "] dbconn: mysql_connect: " . mysql_error());
      }
    }
    mysql_select_db($mysql_db)
        or die('dbconn: mysql_select_db: ' + mysql_error());

    userlogin();

    if ($autoclean)
        register_shutdown_function("autoclean");
}

function userlogin() {
    global $SITE_ONLINE;
    unset($GLOBALS["CURUSER"]);

    $ip = getip();
        $nip = ip2long($ip);
    $res = mysql_query("SELECT * FROM bans WHERE $nip >= first AND $nip <= last") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
      header("HTTP/1.0 403 Forbidden");
      print("<html><body><h1>403 Forbidden</h1>Unauthorized IP address.</body></html>\n");
      die;
    }

    if (!$SITE_ONLINE || empty($_COOKIE["uid"]) || empty($_COOKIE["pass"]))
        return;
    $id = 0 + $_COOKIE["uid"];
    if (!$id || strlen($_COOKIE["pass"]) != 32)
        return;
    $res = mysql_query("SELECT * FROM users WHERE id = $id AND enabled='yes' AND status = 'confirmed'");// or die(mysql_error());
    $row = mysql_fetch_array($res);
    if (!$row)
        return;
    $sec = hash_pad($row["secret"]);
    if ($_COOKIE["pass"] !== $row["passhash"])
        return;
    mysql_query("UPDATE users SET last_access='" . get_date_time() . "', ip=".sqlesc($ip)." WHERE id=" . $row["id"]);// or die(mysql_error());
    $row['ip'] = $ip;
    $GLOBALS["CURUSER"] = $row;
}

function mksize($bytes)
{
        if ($bytes < 1000 * 1024)
                return number_format($bytes / 1024, 2) . " kB";
        elseif ($bytes < 1000 * 1048576)
                return number_format($bytes / 1048576, 2) . " MB";
        elseif ($bytes < 1000 * 1073741824)
                return number_format($bytes / 1073741824, 2) . " GB";
        else
                return number_format($bytes / 1099511627776, 2) . " TB";
}

function sqlesc($x) {
    return "'".mysql_real_escape_string($x)."'";
}

function gmtime()
{
    return strtotime(get_date_time());
}

function hash_pad($hash) {
    return str_pad($hash, 20);
}

function hash_where($name, $hash) {
    $shhash = preg_replace('/ *$/s', "", $hash);
    return "($name = " . sqlesc($hash) . " OR $name = " . sqlesc($shhash) . ")";
}

function parked()
{
       global $CURUSER;
       if ($CURUSER["parked"] == "yes")
 stderr("Error", "Your account is parked.");
}

// bittorrent.php integration end


function checkconnect($ip,$port)
{
return (! (@fsockopen($ip, $port, $errno, $errstr, 5))) ? 'no':(@fclose($sockres)?'yes':'yes');
}

function err($msg)
{
        benc_resp(array("failure reason" => array(type => "string", value => $msg)));
        exit();
}

function benc_resp($d)
{
        benc_resp_raw(benc(array(type => "dictionary", value => $d)));
}

function benc_resp_raw($x)
{
        header("Content-Type: text/plain");
        header("Pragma: no-cache");
        print($x);
}

foreach (array("passkey","info_hash","peer_id","ip","event") as $x)

$GLOBALS[$x] = "" . $_GET[$x];





foreach (array("port","downloaded","uploaded","left") as $x)

$GLOBALS[$x] = 0 + $_GET[$x];



if (strpos($passkey, "?")) {

  $tmp = substr($passkey, strpos($passkey, "?"));

$passkey = substr($passkey, 0, strpos($passkey, "?"));

$tmpname = substr($tmp, 1, strpos($tmp, "=")-1);

$tmpvalue = substr($tmp, strpos($tmp, "=")+1);

$GLOBALS[$tmpname] = $tmpvalue;

}



foreach (array("passkey","info_hash","peer_id","port","downloaded","uploaded","left") as $x)

if (!isset($x)) err("Missing key: $x");



foreach (array("info_hash","peer_id") as $x)

if (strlen($GLOBALS[$x]) != 20) err("Invalid $x (" . strlen($GLOBALS[$x]) . " - " . urlencode($GLOBALS[$x]) . ")");



if (strlen($passkey) != 32) err("Invalid passkey (" . strlen($passkey) . " - $passkey)");



//if (empty($ip) || !preg_match('/^(d{1,3}.){3}d{1,3}$/s', $ip))

$ip = getip();

$rsize = 50;
foreach(array("num want", "numwant", "num_want") as $k)
{
        if (isset($_GET[$k]))
        {
                $rsize = 0 + $_GET[$k];
                break;
        }
}

$agent = $_SERVER["HTTP_USER_AGENT"];

/////////////////////Fix Increase ratio using Firefox //////////////////////
$headers = getallheaders();
if (isset($headers["Cookie"]) || isset($headers["Accept-Language"]) || isset($headers["Accept-Charset"]))
err("Anti-Cheater= You cannot use this agent");
///////////////////end of fix//////////////////////

// Deny access made with a browser...
//if (ereg("^Mozilla\\/", $agent) || ereg("^Opera\\/", $agent) || ereg("^Links ", $agent) || ereg("^Lynx\\/", $agent))
//        err("torrent not registered with this tracker");

if (!$port || $port > 0xffff)
        err("invalid port");

if (!isset($event))
        $event = "";

$seeder = ($left == 0) ? "yes" : "no";

dbconn(false);

$valid = @mysql_fetch_row(@mysql_query("SELECT COUNT(*) FROM users WHERE passkey=" . sqlesc($passkey)));

if ($valid[0] != 1) err("Invalid passkey! Re-download the .torrent from $BASEURL");

$res = mysql_query("SELECT id, banned, seeders + leechers AS numpeers, UNIX_TIMESTAMP(added) AS ts FROM torrents WHERE " . hash_where("info_hash", $info_hash));

$torrent = mysql_fetch_assoc($res);
if (!$torrent)
        err("torrent not registered with this tracker");

$torrentid = $torrent["id"];

$fields = "seeder, peer_id, ip, port, uploaded, downloaded, userid, UNIX_TIMESTAMP(last_action) AS ts";

$numpeers = $torrent["numpeers"];
$limit = "";
if ($numpeers > $rsize)
        $limit = "ORDER BY RAND() LIMIT $rsize";
$res = mysql_query("SELECT $fields FROM peers WHERE torrent = $torrentid AND connectable = 'yes' $limit");

$resp = "d" . benc_str("interval") . "i" . $announce_interval . "e" . benc_str("peers") . "l";

unset($self);
while ($row = mysql_fetch_assoc($res))
{
        $row["peer_id"] = hash_pad($row["peer_id"]);

        if ($row["peer_id"] === $peer_id)
        {
                $userid = $row["userid"];
                $self = $row;
                continue;
        }

        $resp .= "d" .
                benc_str("ip") . benc_str($row["ip"]) .
                benc_str("peer id") . benc_str($row["peer_id"]) .
                benc_str("port") . "i" . $row["port"] . "e" .
                "e";
}

$resp .= "ee";

$selfwhere = "torrent = $torrentid AND " . hash_where("peer_id", $peer_id);

if (!isset($self))
{
        $res = mysql_query("SELECT $fields FROM peers WHERE $selfwhere");
        $row = mysql_fetch_assoc($res);
        if ($row)
        {
                $userid = $row["userid"];
                $self = $row;
                 if(($connectable=checkconnect($row['ip'],$row['port']))=='yes')
                 mysql_query("UPDATE peers SET connectable='yes' $selfwhere");
        }
}

//// Up/down stats ////////////////////////////////////////////////////////////



if (!isset($self))

{

$valid = @mysql_fetch_row(@mysql_query("SELECT COUNT(*) FROM peers WHERE torrent=$torrentid AND passkey=" . sqlesc($passkey)));

if ($valid[0] >= 1 && $seeder == 'no') err("Connection limit exceeded! You may only leech from one location at a time.");

if ($valid[0] >= 3 && $seeder == 'yes') err("Connection limit exceeded!");



$rz = mysql_query("SELECT id, uploaded, downloaded, class FROM users WHERE passkey=".sqlesc($passkey)." AND enabled = 'yes' ORDER BY last_access DESC LIMIT 1") or err("Tracker error 2");

if ($MEMBERSONLY && mysql_num_rows($rz) == 0)

err("Unknown passkey. Please redownload the torrent from $BASEURL.");
        $az = mysql_fetch_assoc($rz);
        $userid = $az["id"];

//        if ($left > 0 && $az["class"] < UC_VIP)
        if ($az["class"] < UC_VIP)
        {
                $gigs = $az["uploaded"] / (1024*1024*1024);
                $elapsed = floor((gmtime() - $torrent["ts"]) / 3600);
                $ratio = (($az["downloaded"] > 0) ? ($az["uploaded"] / $az["downloaded"]) : 1);
                if ($ratio < 0.5 || $gigs < 5) $wait = 24;
                elseif ($ratio < 0.65 || $gigs < 6.5) $wait = 12;
                elseif ($ratio < 0.8 || $gigs < 8) $wait = 6;
                elseif ($ratio < 0.95 || $gigs < 9.5) $wait = 3;
                else $wait = 0;
                if ($elapsed < $wait)
                                err("Not authorized (" . ($wait - $elapsed) . "h) - READ THE FAQ!");
        }
}
else
{
            // Get the last uploaded amount from user account for reference and store it in $last_up
    $rst = mysql_query("SELECT class, uploaded FROM users WHERE id = $userid") or err("Tracker error 5");
    $art = mysql_fetch_array($rst);
    $last_up = $art["uploaded"];
    $class = $art["class"];

        $upthis = max(0, $uploaded - $self["uploaded"]);
        $downthis = max(0, $downloaded - $self["downloaded"]);

        if ($upthis > 0 || $downthis > 0)
        // Initial sanity check xMB/s for 1 second
    if($upthis > 2097152)
    {
        //Work out time difference
        $endtime = time();
        $starttime = $self['ts'];
        $diff = ($endtime - $starttime);
        //Normalise to prevent divide by zero.
        $rate = ($upthis / ($diff + 1));
        //Currently 2MB/s. Increase to 5MB/s once finished testing.
        if ($rate > 2097152)
        {
            if ($class < UC_MODERATOR)
            {
                $rate = mksize($rate);
                $client = $agent;
                $userip = getip();

                auto_enter_cheater($userid, $rate, $upthis, $diff, $torrentid, $client, $userip, $last_up);
            }
        }
    }
                mysql_query("UPDATE users SET uploaded = uploaded + $upthis, downloaded = downloaded + $downthis WHERE id=$userid") or err("Tracker error 3");
}

///////////////////////////////////////////////////////////////////////////////

function portblacklisted($port)
{
        // direct connect
        if ($port >= 411 && $port <= 413) return true;

        // bittorrent
        if ($port >= 6881 && $port <= 6889) return true;

        // kazaa
        if ($port == 1214) return true;

        // gnutella
        if ($port >= 6346 && $port <= 6347) return true;

        // emule
        if ($port == 4662) return true;

        // winmx
        if ($port == 6699) return true;

        return false;
}

$updateset = array();

if ($event == "stopped")
{
        if (isset($self))
        {
                mysql_query("DELETE FROM peers WHERE $selfwhere");
                if (mysql_affected_rows())
                {
                        if ($self["seeder"] == "yes")
                                $updateset[] = "seeders = seeders - 1";
                        else
                                $updateset[] = "leechers = leechers - 1";
                }
        }
}
else
{
        if ($event == "completed")
                $updateset[] = "times_completed = times_completed + 1";

        if (isset($self))
        {
                mysql_query("UPDATE peers SET uploaded = $uploaded, downloaded = $downloaded, to_go = $left, last_action = NOW(), seeder = '$seeder'"
                        . ($seeder == "yes" && $self["seeder"] != $seeder ? ", finishedat = " . time() : "") . " WHERE $selfwhere");
                if (mysql_affected_rows() && $self["seeder"] != $seeder)
                {
                        if ($seeder == "yes")
                        {
                                $updateset[] = "seeders = seeders + 1";
                                $updateset[] = "leechers = leechers - 1";
                        }
                        else
                        {
                                $updateset[] = "seeders = seeders - 1";
                                $updateset[] = "leechers = leechers + 1";
                        }
                }
        }
        else
        {
                if (portblacklisted($port))
                        err("Port $port is blacklisted.");
                if ($az["parked"] == "yes")
                        err("Error, your account is parked!");

                $useragent = substr($peer_id, 1, 2);
                $agentversion = substr($peer_id, 3, 4);
                if(($useragent != "AZ" && $useragent != "UT") || ($useragent == "AZ" && $agentversion < 2504) || ($useragent == "UT" && $agentversion < 1610))
                err("Client is banned. Please use uTorrent 1.6 or Azureus 2.5!");

          $connectable=checkconnect($ip,$port);

                $ret = mysql_query("INSERT INTO peers (connectable, torrent, peer_id, ip, port, uploaded, downloaded, to_go, started, last_action, seeder, userid, agent, uploadoffset, downloadoffset, passkey) VALUES ('$connectable', $torrentid, " . sqlesc($peer_id) . ", " . sqlesc($ip) . ", $port, $uploaded, $downloaded, $left, NOW(), NOW(), '$seeder', $userid, " . sqlesc($agent) . ", $uploaded, $downloaded, " . sqlesc($passkey) . ")");
                if ($ret)
                {
                        if ($seeder == "yes")
                                $updateset[] = "seeders = seeders + 1";
                        else
                                $updateset[] = "leechers = leechers + 1";
                }
        }
}

if ($seeder == "yes")
{
        if ($torrent["banned"] != "yes")
                $updateset[] = "visible = 'yes'";
        $updateset[] = "last_action = NOW()";
}

if (count($updateset))
        mysql_query("UPDATE torrents SET " . join(",", $updateset) . " WHERE id = $torrentid");

// g-zip start
if ($_SERVER["HTTP_ACCEPT_ENCODING"] == "gzip")

{

header("Content-Encoding: gzip");

echo gzencode(benc_resp_raw($resp), 9, FORCE_GZIP);

}

else  benc_resp_raw($resp);
// g-zip end


?>