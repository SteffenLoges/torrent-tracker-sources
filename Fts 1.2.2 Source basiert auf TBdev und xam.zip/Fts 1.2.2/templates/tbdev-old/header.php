<html><head>
<title><?= $title ?></title>
<link rel="stylesheet" href="/<?=$ss_uri?>" type="text/css">
<link rel="alternate" type="application/rss+xml" title="<? print("" .LATEST_TORRENTS. "")?>" href="<?=$DEFAULTBASEURL?>/rss.php">
<link rel="shortcut icon" href="<?=$DEFAULTBASEURL;?>/pic/logo.gif" type="image/x-icon" />
<meta http-equiv="Content-Type" content="noindex,nofollow,noarchive" name="robots" charset="utf-8">
<?scripts();?>
</head>
<body>

<table width=100% cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>
<td class=clear width=49%>
</td>
<td class=clear>
<div align=center>
<a href=/><img style=border:none alt=<? print("" .HOME. "")?> title=<? print("" .HOME. "")?> src=pic/logo.gif></a>
</div>
</td>
<td class=clear width=49% align=right>
<a href=donate.php><img src="pic/donate.gif" border="0" alt="<? print("" .MAKE_A_DONATION. "")?>" style='margin-top: 5px'></a>
</td>
</tr></table>
<!-- /////// some vars for the statusbar;o) //////// -->


<!-- //////// start the statusbar ///////////// -->
<? if($CURUSER) { ?>
<table align="center" cellpadding="0" cellspacing="0" border="0" style="width:100%">
<tr>
<td class="tablea"><table align="center" style="width:737" cellspacing="0" cellpadding="0" border="0">
<tr>
<td class="bottom" align="left"><span class="smallfont"><? print("" .WELCOME_BACK. "")?>, <a href="userdetails.php?id=<?=$CURUSER['id']?>"><?=$CURUSER['username']?></a><?=$medaldon?><?=$warn?>&nbsp; [<a href="logout.php"><? print("" .LOG_OUT. "")?></a>] <a href='/mybonus.php'>Your Karma points: <?=$CURUSER['seedbonus'];?></a>&nbsp;&nbsp;<br/>
<font color=1900D1><? print("" .RATIO. "")?>:</font> <?=$ratio?>&nbsp;&nbsp;<font color=green><? print("" .UPLOADED. "")?>:</font> <font color=black><?=$uped?></font>&nbsp;&nbsp;<font color=darkred><? print("" .DOWNLOADED. "")?>:</font> <font color=black><?=$downed?></font>&nbsp;&nbsp;<font color=1900D1><? print("" .ACTIVE_TORRENTS. "")?>:&nbsp;</font></span> <img alt="Torrents seeding" title="Torrents seeding" src="pic/arrowup.gif">&nbsp;<font color=black><span class="smallfont"><?=$activeseed?></span></font>&nbsp;&nbsp;<img alt="Torrents leeching" title="Torrents leeching" src="pic/arrowdown.gif">&nbsp;<font color=black><span class="smallfont"><?=$activeleech?></span></font>&nbsp;&nbsp;<font color=1900D1><? print("" .CONNECTABLE. "")?>:&nbsp;</font><?=$connectable?></td>
<td class="bottom" align="right"><span class="smallfont"><? print("" .THE_TIME_IS_NOW. "")?>: <?echo "$datum[hours]:$datum[minutes]";?><br/>
<?
if ($messages){
print("<span class=smallfont><a href=inbox.php>$inboxpic</a> $messages ($unread " .NEW_. ")</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> 0</span>");
}
else
{
print("<span class=smallfont><a href=inbox.php><img height=14px style=border:none alt=inbox title=" .INBOX. " src=pic/pn_inbox.gif></a> 0</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> 0</span>");
}
print("&nbsp;<a href=friends.php><img style=border:none alt=" .BUDDY_LIST. " title=" .BUDDY_LIST. " src=pic/buddylist.gif></a>");
print("&nbsp;<a href=getrss.php><img style=border:none alt=" .RSS. " title=" .RSS. " src=pic/rss.gif></a>");
?>
</span></td>

</tr>
</table></table>
<p>

<? } else { ?>
<table align="center" cellpadding="3" cellspacing="0" border="0" style="width:100%">
<tr>
<td>
<table align="center" style="width:737" cellspacing="0" cellpadding="0" border="0">
<form method="post" action="takelogin.php">
<center>
<? print("" .USERNAME. "")?>: <input type="text" size=40 name="username" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? print("" .PASSWORD. "")?>: <input type="password" size=40 name="password" />
<input type="submit" value="<? print("" .LOGIN. "")?>!" class=btn>
</center>
</form>
</table>
</td>
</tr>
</table>
<p>
<? }?>
<!-- /////////// here we go, with the cats //////////// -->
<?php

$w = "width=100%";
//if ($_SERVER["REMOTE_ADDR"] == $_SERVER["SERVER_ADDR"]) $w = "width=984";

?>
<table class=mainouter <?=$w; ?> border="1" cellspacing="0" cellpadding="10">

<!------------- MENU ------------------------------------------------------------------------>

<? $fn = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], "/") + 1); ?>
<tr><td class=outer align=center>
<table class=main width=700 cellspacing="0" cellpadding="5" border="0">
<tr>

<? if (!$CURUSER) { ?>
<td align="center" class="navigation">
<a href=/><? print("" .HOME. "")?></a> / <a href=/signup.php><? print("" .SIGNUP. "")?></a> / <a href=/recover.php><? print("" .RECOVER. "")?></a> / <a href=/rules.php><? print("" .RULES. "")?></a> / <a href=/faq.php><? print("" .FAQ. "")?></a>
</td>
<? } else { ?>
<td align="center" class="navigation"><a href=/><? print("" .HOME. "")?></a></td>
<td align="center" class="navigation"><a href=/browse.php><? print("" .BROWSE. "")?></a></td>
<? if (get_user_class() > UC_VIP) { ?>
<td align="center" class="navigation"><a href=/viewrequests.php><? print("" .REQUESTS. "")?></a></td>
<td align="center" class="navigation"><a href=/viewoffers.php><? print("" .OFFERS. "")?></a></td>
<td align="center" class="navigation"><a href=/upload.php><? print("" .UPLOAD. "")?></a></td>
</td>
<? } else { ?>
<? } ?>
<td align="center" class="navigation"><a href=/my.php><? print("" .PROFILE. "")?></a></td>
<td align="center" class="navigation"><a href=/forums.php><? print("" .FORUMS. "")?></a></td>
<td align="center" class="navigation"><a href=/chat.php><? print("" .CHAT. "")?></a></td>
<td align="center" class="navigation"><a href=/topten.php><? print("" .TOP_10. "")?></a></td>
<td align="center" class="navigation"><a href=/faq.php><? print("" .FAQ. "")?></a></td>
<td align="center" class="navigation"><a href=/rules.php><? print("" .RULES. "")?></a></td>
<? if (get_user_class() > UC_UPLOADER) { ?>
<td align="center" class="navigation"><a href=/log.php><? print("" .LOG. "")?></a></td>
<td align="center" class="navigation"><a href=/staffpanel.php><? print("" .C_PANEL. "")?></a>
<td align="center" class="navigation"><a href=/settings.php>Settings</a>
</td>
<? } else { ?>
<? } ?>
<td align="center" class="navigation"><a href=/staff.php><? print("" .STAFF. "")?></a></td>
<? } ?>
</tr>
</table>
</td>
</tr>
<tr><td align=center class=outer style="padding-top: 20px; padding-bottom: 20px">
<?

$announcement = $CURUSER['announce'];
if ($announcement == "yes")
  print("<a href=$BASEURL/announcement.php><img src=/pic/ann.png border=none alt=Announcement></a>");
  print("<br>");

if ($unread)
{
  print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background: red'>\n");
  print("<b><a href=$BASEURL/inbox.php><font color=white>" .YOU_HAVE. " $unread " .NEW_MESSAGE. "" . ($unread > 1 ? "" .ENDING. "" : "") . "!</font></a></b>");
  print("</td></tr></table></p>\n");
}