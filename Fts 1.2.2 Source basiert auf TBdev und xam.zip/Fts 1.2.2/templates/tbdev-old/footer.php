<?$version = $ver;?></td></tr></table></td></tr></table><center><br>
<?
printf ("" .EXECUTED_IN. " %f " .SECONDS. "", $totaltime);
?>
<br>
</br>
<span style="color:white">Powered by <?=$version;?></span>
<br>
</br>
<span style="color:white"><? print("" .AUTHOR. "")?></span>
</td></tr></table></center><br><br><br></body></head></html>
