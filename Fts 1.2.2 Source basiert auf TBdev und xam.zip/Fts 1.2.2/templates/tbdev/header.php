<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
<title><?= $title ?></title>
<link rel="stylesheet" href="templates/tbdev/TBDev.css" type="text/css">
<script language="javascript" type="text/javascript" src="js/resizer.js"></script>
<script language="javascript" type="text/javascript" src="js/tooltips.js"></script>
<link rel="alternate" type="application/rss+xml" title="RSS" href="<?=$DEFAULTBASEURL?>/rss.php">
<link rel="shortcut icon" href="<?=$DEFAULTBASEURL;?>/favicon.ico" type="image/x-icon" />
<?scripts();?>
<link rel="stylesheet" href="scripts/windowfiles/dhtmlwindow.css" type="text/css" />
<script type="text/javascript" src="scripts/windowfiles/dhtmlwindow.js">
</script>
<link rel="stylesheet" href="scripts/modalfiles/modal.css" type="text/css" />
<script type="text/javascript" src="scripts/modalfiles/modal.js"></script>
</head>
<body>

<table width="90%" class="clear" align="center" border="0" cellspacing="0" cellpadding="0" style="background: transparent;">
<tr>
<td class="embedded" width="50%" background="templates/tbdev/images/logobg.gif">
<a href="<?=$DEFAULTBASEURL?>"><img style="border: none" alt="<?=$SITENAME?>" title="<?=$SITENAME?>" src="templates/tbdev/images/logo.gif" /></a>
</td>
<td class="embedded" width="50%" align="right" background="templates/tbdev/images/logobg.gif">
	
<noindex><form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but21.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHZwYJKoZIhvcNAQcEoIIHWDCCB1QCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYAqITNuIizeHJpBZqtnKNdz51yUYAmeyFhT4d4SFipBuT993bqQlAl8c54/R7mB5W7Al/m/gmUp87AZDDeq41UgAoTYSMbHPw0+Kc5WBhhy3q5EV0k3EBKDrUUbtF639SALQaItCJ0j0UU+wnNBKTWNuQljf1iXwKBAw5Di88GV0TELMAkGBSsOAwIaBQAwgeQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIfEBDC/9Lr3SAgcC8QjnSZWUq1+ARoqf69vnArdhFwt7iXKIKp+9PUgFKubmHYs7ItA/SBeKoQ9JTYfFh2IrRn4eI4Ys5NQDfNh1KuNMBlHFr59BYNRPMO+NGLxiqWnAu6YFrao/c0+/tSlbmWKk/++CDYmRwMMIOuvd+xLMqfmkMZC/Y5vCJRhNYhcI1hR6dP/aSb9S+zQt9A6Mp4ei6i3OVd+PUMJV9qg7TkpXns+aThpOHVpssHjn9ohpQHEj9NkYgpWRdXrfcE4ugggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wNzA4MDYxNDQyMTVaMCMGCSqGSIb3DQEJBDEWBBRhlqIm2VjHRuztPnkRXWV+0DVaKzANBgkqhkiG9w0BAQEFAASBgCisHsDUhc6FMktZNDHJsHcXyNwEv3sGGNq8WacILouuxLM8zKwn1Jsh1Ly5xdFXatovd/210rBFt8qiKNHt8NZ92mPSaSAGSNuPiu0FDNAydf0Ah8cjUQCL/yqx/Iimk6PGVqEqNDRYCe1NLfGvfuzz33I0+L0NS4m2wEd40bee-----END PKCS7-----
">
</form>

</noindex>&nbsp;
</td>
</tr>
</table>

<!-- Top Navigation Menu for unregistered-->
<table width="90%" align="center" border="0" cellspacing="0" cellpadding="2"><tr>

<td align="center" class="topnav">&nbsp;<a href=/><font color="#FFFFFF"><? print("" .HOME. "")?></font></a>
&nbsp;&#8226;&nbsp;
<a href="browse.php"><font color="#FFFFFF"><? print("" .BROWSE. "")?></font></a>
<? if (get_user_class() >= UC_USER) { ?>
&nbsp;&#8226;&nbsp;
<a href=/viewrequests.php><font color="#FFFFFF"><? print("" .REQUESTS. "")?></font></a>
&nbsp;&#8226;&nbsp;
<a href=/viewoffers.php><font color="#FFFFFF"><? print("" .OFFERS. "")?></a>
&nbsp;&#8226;&nbsp;
<a href="upload.php"><font color="#FFFFFF"><? print("" .UPLOAD. "")?></font></a>
&nbsp;&#8226;&nbsp;
<a href=/my.php><font color="#FFFFFF"><? print("" .PROFILE. "")?></a>
<? } ?>
&nbsp;&#8226;&nbsp;
<a href="forums.php"><font color="#FFFFFF">Forum</font></a>
<? if ($CURUSER) { ?>
&nbsp;&#8226;&nbsp;
<a href="log.php"><font color="#FFFFFF">Log</font></a>
<? } ?>
&nbsp;&#8226;&nbsp;
<a href="rules.php"><font color="#FFFFFF">Rules</font></a>
&nbsp;&#8226;&nbsp;
<a href="faq.php"><font color="#FFFFFF">FAQ</font></a>
<? if ($CURUSER) { ?>
&nbsp;&#8226;&nbsp;
<!--<a href="helpdesk.php"><font color="#FFFFFF">���. ���������</font></a>
&nbsp;&#8226;&nbsp;-->
<a href="staff.php"><font color="#FFFFFF">Staff</font></a>
<? } ?>
<? if(get_user_class() > UC_UPLOADER) { ?>
&nbsp;&#8226;&nbsp;
<a href="staffpanel.php"><font color="#FFFFFF">Staff Panel</font></a>
<?
}if(get_user_class() >= UC_SYSOP) { 
?>
&nbsp;&#8226;&nbsp;
<a href="settings.php"><font color="#FFFFFF">Settings</font></a>
<?}?>
</td></tr>
</table>



<? if ($CURUSER) { ?>

<!-- //////// start the statusbar ///////////// -->

</table>

<p>

<table align="center" cellpadding="4" cellspacing="0" border="0" style="width:90%">
<tr>
<td class="tablea"><table align="center" style="width:100%" cellspacing="0" cellpadding="0" border="0">
<tr>

<td class="bottom" align="left"><span class="smallfont"><? print("" .WELCOME_BACK. "")?>, <a href="userdetails.php?id=<?=$CURUSER['id']?>"><?=$CURUSER['username']?></a><?=$medaldon?><?=$warn?>&nbsp; [<a href="logout.php"><? print("" .LOG_OUT. "")?></a>] <a href='/mybonus.php'>Your Karma points: <?=$CURUSER['seedbonus'];?></a>&nbsp;&nbsp;<br/>
<font color=1900D1><? print("" .RATIO. "")?>:</font> <?=$ratio?>&nbsp;&nbsp;<font color=green><? print("" .UPLOADED. "")?>:</font> <font color=black><?=$uped?></font>&nbsp;&nbsp;<font color=darkred><? print("" .DOWNLOADED. "")?>:</font> <font color=black><?=$downed?></font>&nbsp;&nbsp;<font color=1900D1><? print("" .ACTIVE_TORRENTS. "")?>:&nbsp;</font></span> <img alt="Torrents seeding" title="Torrents seeding" src="pic/arrowup.gif">&nbsp;<font color=black><span class="smallfont"><?=$activeseed?></span></font>&nbsp;&nbsp;<img alt="Torrents leeching" title="Torrents leeching" src="pic/arrowdown.gif">&nbsp;<font color=black><span class="smallfont"><?=$activeleech?></span></font>&nbsp;&nbsp;<font color=1900D1><? print("" .CONNECTABLE. "")?>:&nbsp;</font><?=$connectable?></td>
<td class="bottom" align="right"><span class="smallfont"><? print("" .THE_TIME_IS_NOW. "")?>: <?echo "$datum[hours]:$datum[minutes]";?><br/>
<?
if ($messages){
print("<span class=smallfont><a href=inbox.php>$inboxpic</a> $messages ($unread " .NEW_. ")</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> 0</span>");
}
else
{
print("<span class=smallfont><a href=inbox.php><img height=14px style=border:none alt=inbox title=" .INBOX. " src=pic/pn_inbox.gif></a> 0</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=" .SENTBOX. " title=" .SENTBOX. " src=pic/pn_sentbox.gif></a> 0</span>");
}
print("&nbsp;<a href=friends.php><img style=border:none alt=" .BUDDY_LIST. " title=" .BUDDY_LIST. " src=pic/buddylist.gif></a>");
print("&nbsp;<a href=getrss.php><img style=border:none alt=" .RSS. " title=" .RSS. " src=pic/rss.gif></a>");
?>
</span></td>

</tr>
</table></table>
<p>

<? } else { ?>
<table align="center" cellpadding="3" cellspacing="0" border="0" style="width:90%">
<tr>
<td>
<table align="center" style="width:90%" cellspacing="0" cellpadding="0" border="0">
<form method="post" action="takelogin.php">
<center>
<? print("" .USERNAME. "")?>: <input type="text" size=32 name="username" class="inputUsername" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? print("" .PASSWORD. "")?>: <input type="password" size=40 name="password" class="inputPassword"/>
<input type="submit" value="<? print("" .LOGIN. "")?>!" class=btn>
</center>
</form>
</table>
</td>
</tr>
</table>
<?}?>
<!-- /////////// here we go, with the menu //////////// -->

<?php

$w = "width=\"90%\"";
//if ($_SERVER["REMOTE_ADDR"] == $_SERVER["SERVER_ADDR"]) $w = "width=984";

?>
<table class="mainouter" align="center" <?=$w; ?> border="1" cellspacing="0" cellpadding="5">

<!------------- MENU ------------------------------------------------------------------------>

<? $fn = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], "/") + 1); ?>



<td align="center" valign="top" class="outer" style="padding-top: 5px; padding-bottom: 5px">
<?
if($unread AND $usergroups['canpm'] == 'yes') {
print("<p class=success><a href=$BASEURL/inbox.php>" .YOU_HAVE. " $unread " .NEW_MESSAGE. "" . ($unread > 1 ? "" .ENDING. "" : "") . "!</a></p>");
}
$announcement = $CURUSER['announce'];
$q = mysql_query('SELECT * FROM announcement ORDER BY id DESC LIMIT 5') or mysql_error(__FILE__,__LINE__);
?><div id="announcement" style="display:none;">
<div style="background: #F3F3F3; height: 100%; padding: 5px">
<?
while($ann = mysql_fetch_array($q)) {
echo 'Announce from: '.$ann['added'].'<BR>';
echo 'Title: '.$ann['title'].'<BR>';
echo $ann['body'].'<BR>';
echo '<HR>';
}

print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'>");
?>
I read all the announcements: <INPUT type='radio' name='readall' value='yes'> <input type='submit' name='save' class='btn' value='Ok'>
<?
print ("</form>");
if($_POST['readall'] == 'yes') {
mysql_query("UPDATE users SET announce = 'no' WHERE id=".$CURUSER['id']);
header('Location: '.$_SERVER['SCRIPT_NAME']);
}
?>
</div>
</div>

<script type="text/javascript">

function ageprompt(){
	agewindow=dhtmlmodal.open('agebox', 'div', 'announcement', 'Latest 5 announcements', 'width=750px,height=550px,left=150px,top=100px,resize=0,scrolling=0')
}

</script><?
if ($announcement == "yes")
  print("<p class=success><a href=# onclick=ageprompt()>There is one unread announcement. Click here to read it.</a></p>");
  print("<br>");
ads();
?>