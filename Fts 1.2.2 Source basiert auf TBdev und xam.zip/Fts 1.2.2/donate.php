<?
require "include/bittorrent.php";
dbconn();
stdhead();
?>
<?=dnt;?>
<?
stdfoot();
?>