<?
//-----------------------------------------------------
//-  Collation Fix for TBdev v1.1
//-    by Ashley
//-
//-  This will edit the collation of your database,
//-  to utf8_general_ci, which is what is recommended
//-  for use for TBdev.
//-
//-  You do NOT need to edit anything in this file
//-  for it to work, just upload it, and run it!
//-
//-  Hope this helps you, instead of doing it all
//-  manually! lol
//-----------------------------------------------------

require_once("include/bittorrent.php");

dbconn(true);

stdhead("TBDev Database Collation Fix");

?>

<h1>TBDev Database Collation Fix</h1><br>

<?

$result = mysql_query("SHOW TABLES FROM $mysql_db"); // Get table names from database - DO NOT EDIT!

while ($row = mysql_fetch_row($result)) {

mysql_query(" ALTER TABLE {$row[0]} CHARACTER SET utf8 COLLATE utf8_general_ci;"); // Change all table names to 'utf8_general_ci'
mysql_query(" ALTER DATABASE $mysql_db CHARACTER SET utf8 COLLATE utf8_general_ci;"); // Change database to 'utf8_general_ci'
print"Changing the table <strong>&quot;{$row[0]}&quot;</strong> to the '<strong><em>utf8_general_ci</em></strong>' collation - Done!<br>"; // This code will begin a new line for each table it changes!
}

print"<h1>DONE!</h1>"; 
unlink($delete); // Delete file
print"<p>&#3665;&#1769;&#1758;&#1769;&#3665; Mod by Ashley &#3665;&#1769;&#1758;&#1769;&#3665; </p>"; // My footer - do NOT delete!
die;

?>
