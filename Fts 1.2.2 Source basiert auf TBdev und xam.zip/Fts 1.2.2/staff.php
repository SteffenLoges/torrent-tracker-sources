<?
require "include/bittorrent.php";
dbconn();
stdhead("Staff");
begin_main_frame();
?>
                <?
                // Get current datetime
                $dt = gmtime() - 180;
                $dt = sqlesc(get_date_time($dt));
                // Search User Database for Moderators and above and display in alphabetical order
                $res = mysql_query("SELECT * FROM users WHERE class>=".UC_UPLOADER.
                " AND status='confirmed' ORDER BY username" ) or sqlerr();
                while ($arr = mysql_fetch_assoc($res))
                {
                $staff_table[$arr['class']]=$staff_table[$arr['class']].
                "<td class=embedded><a class=altlink href=userdetails.php?id=".$arr['id'].">".
                $arr['username']."</a><sup><font color=#".
                ("'".$arr['last_access']."'">$dt?"000066>On":"999999>Off" )."line</font></sup></td>".
                "<td class=embedded><a href=sendmessage.php?receiver=".$arr['id'].">".
                "<img src=".$pic_base_url."button_pm.gif border=0></a></td>".
                "<td class=embedded><a href=email-gateway.php?id=".$arr['id'].">".
                "<img src=".$pic_base_url."button_mail.gif border=0 alt=".$arr['email']."></a></td>";
                // Show 3 staff per row, separated by an empty column
                ++ $col[$arr['class']];
                if ($col[$arr['class']]<=3)
                $staff_table[$arr['class']]=$staff_table[$arr['class']]."<td class=embedded>&nbsp;</td>";
                else
                {
                $staff_table[$arr['class']]=$staff_table[$arr['class']]."</tr><tr height=15>";
                $col[$arr['class']]=1;
                }
                }
                ?>

                <table width=725 cellspacing=0>
                <tr>
                <!-- Define table column widths -->
                <td class=embedded width="125"><b>SysOp</b></td>
                <td class=embedded width="25">&nbsp;</td>
                <td class=embedded width="35">&nbsp;</td>
                <td class=embedded width="85">&nbsp;</td>
                <td class=embedded width="125">&nbsp;</td>
                <td class=embedded width="25">&nbsp;</td>
                <td class=embedded width="35">&nbsp;</td>
                <td class=embedded width="85">&nbsp;</td>
                <td class=embedded width="125">&nbsp;</td>
                <td class=embedded width="25">&nbsp;</td>
                <td class=embedded width="35">&nbsp;</td>
                </tr>
                <tr>
                <td class=embedded colspan=11><hr color="#4040c0" size=1></td>
                </tr>
                <tr height=15>
                <?=$staff_table[UC_SYSOP]?>
                </tr>
                <tr><td class=embedded colspan=11>&nbsp;</td></tr>
                <tr><td class=embedded colspan=11><b>Administrators</b></td></tr>
                <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
                <tr height=15>
                <?=$staff_table[UC_ADMINISTRATOR]?>
                </tr>
                <tr><td class=embedded colspan=11>&nbsp;</td></tr>
                <tr><td class=embedded colspan=11><b>Moderators</b></td></tr>
                <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
                <tr height=15>
                <?=$staff_table[UC_MODERATOR]?>
                </tr>
                <tr><td class=embedded colspan=11>&nbsp;</td></tr>
                <tr><td class=embedded colspan=11><b>Uploaders</b></td></tr>
                <tr><td class=embedded colspan=11><hr color="#4040c0" size=1></td></tr>
                <tr height=15>
                <?=$staff_table[UC_UPLOADER]?>
                </tr>
                </table>

<?
end_main_frame();
stdfoot();
?>