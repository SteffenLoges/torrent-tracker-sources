CREATE TABLE `modpanel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `url` varchar(20) default NULL,
  `info` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1000 ;


CREATE TABLE `adminpanel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `url` varchar(20) default NULL,
  `info` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2000 ;

CREATE TABLE `sysoppanel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `url` varchar(20) default NULL,
  `info` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=3000 ;

ALTER TABLE `categories` ADD `sort_index` int(10) unsigned NOT NULL default '0';
ALTER TABLE `categories` ADD `cat_desc` varchar(30) NOT NULL default '';

ALTER TABLE users ADD(parked enum ('yes','no') NOT NULL default 'no');

INSERT INTO `adminpanel` VALUES (2002, 'Add user', 'adduser.php', 'Add user');
INSERT INTO `adminpanel` VALUES (2003, 'Unconfirmed users', 'uncon.php', 'View unconfirmed accounts');
INSERT INTO `adminpanel` VALUES (2004, 'Announcement', 'announcement.php', 'Public important message for all tracker users');
INSERT INTO `adminpanel` VALUES (2005, 'Traceroute', 'traceroute.php', 'Trace IP');
INSERT INTO `adminpanel` VALUES (2006, 'FAQ management', 'faqmanage.php', 'Manage your FAQ page');
INSERT INTO `adminpanel` VALUES (2007, 'Rules  management', 'modrules.php', 'Manage your Rules page');

INSERT INTO `modpanel` VALUES (1001, 'Warned users', 'warned.php', 'See warned users');
INSERT INTO `modpanel` VALUES (1002, 'Poll overview', 'polls.php', 'View polls');
INSERT INTO `modpanel` VALUES (1003, 'Make poll', 'makepoll.php', 'Create new poll');
INSERT INTO `modpanel` VALUES (1004, 'User list', 'users.php', 'View users');
INSERT INTO `modpanel` VALUES (1005, 'Stats', 'stats.php', 'Tracker stats');
INSERT INTO `modpanel` VALUES (1006, 'Test IP', 'testip.php', 'Test single IP');
INSERT INTO `modpanel` VALUES (1007, 'Duplicate IP', 'ipcheck.php', 'Duplicate IP users');
INSERT INTO `modpanel` VALUES (1008, 'Leechers', 'leechers.php', 'Show users with ratio under 0.40');
INSERT INTO `modpanel` VALUES (1009, 'IP ban', 'bans.php', 'Ban single IP');
INSERT INTO `modpanel` VALUES (1011, 'Check script', 'proxy.php', 'Possable proxy server user check script');
INSERT INTO `modpanel` VALUES (1012, 'Uploaders', 'uploaders.php', 'See your uploaders info');
INSERT INTO `modpanel` VALUES (1013, 'Ratio cheaters', 'cheaters.php', 'Check if someone is cheating on tracker');

INSERT INTO `sysoppanel` VALUES (3001, 'Delete user', 'delacctadmin.php', 'Delete user without confirm');
INSERT INTO `sysoppanel` VALUES (3003, 'Mass mailer', 'massmail.php', 'Send mail to all tracker users');
INSERT INTO `sysoppanel` VALUES (3005, 'My_Sql stats', 'mysql_stats.php', 'See your MySql stats');
INSERT INTO `sysoppanel` VALUES (3006, 'Manage tracker categories', 'category.php', 'Manage your tracker torrent caregoties');
INSERT INTO `sysoppanel` VALUES (3008, 'Rest lost passwords', 'reset.php', 'Script that resets user password');
INSERT INTO `sysoppanel` VALUES (3009, 'Edit forum', 'editforums.php', 'Edit your forum');
INSERT INTO `sysoppanel` VALUES (3010, 'PHP info', 'phpnfo.php', 'Check your PHP status');
INSERT INTO `sysoppanel` VALUES (3012, 'Do Cleanup', 'docleanup.php', 'Do cleanup function');
INSERT INTO `sysoppanel` VALUES (3013, 'Optimize DB', 'optimize.php', 'This script will optimize your DB');

INSERT INTO countries VALUES (1,'Sweden','sweden.gif');
INSERT INTO countries VALUES (2,'United States of America','usa.gif');
INSERT INTO countries VALUES (3,'Russia','russia.gif');
INSERT INTO countries VALUES (4,'Finland','finland.gif');
INSERT INTO countries VALUES (5,'Canada','canada.gif');
INSERT INTO countries VALUES (6,'France','france.gif');
INSERT INTO countries VALUES (7,'Germany','germany.gif');
INSERT INTO countries VALUES (8,'China','china.gif');
INSERT INTO countries VALUES (9,'Italy','italy.gif');
INSERT INTO countries VALUES (10,'Denmark','denmark.gif');
INSERT INTO countries VALUES (11,'Norway','norway.gif');
INSERT INTO countries VALUES (12,'United Kingdom','uk.gif');
INSERT INTO countries VALUES (13,'Ireland','ireland.gif');
INSERT INTO countries VALUES (14,'Poland','poland.gif');
INSERT INTO countries VALUES (15,'Netherlands','netherlands.gif');
INSERT INTO countries VALUES (16,'Belgium','belgium.gif');
INSERT INTO countries VALUES (17,'Japan','japan.gif');
INSERT INTO countries VALUES (18,'Brazil','brazil.gif');
INSERT INTO countries VALUES (19,'Argentina','argentina.gif');
INSERT INTO countries VALUES (20,'Australia','australia.gif');
INSERT INTO countries VALUES (21,'New Zealand','newzealand.gif');
INSERT INTO countries VALUES (23,'Spain','spain.gif');
INSERT INTO countries VALUES (24,'Portugal','portugal.gif');
INSERT INTO countries VALUES (25,'Mexico','mexico.gif');
INSERT INTO countries VALUES (26,'Singapore','singapore.gif');
INSERT INTO countries VALUES (27,'India','india.gif');
INSERT INTO countries VALUES (28,'Albania','albania.gif');
INSERT INTO countries VALUES (29,'South Africa','southafrica.gif');
INSERT INTO countries VALUES (30,'South Korea','southkorea.gif');
INSERT INTO countries VALUES (31,'Jamaica','jamaica.gif');
INSERT INTO countries VALUES (32,'Luxembourg','luxembourg.gif');
INSERT INTO countries VALUES (33,'Hong Kong','hongkong.gif');
INSERT INTO countries VALUES (34,'Belize','belize.gif');
INSERT INTO countries VALUES (35,'Algeria','algeria.gif');
INSERT INTO countries VALUES (36,'Angola','angola.gif');
INSERT INTO countries VALUES (37,'Austria','austria.gif');
INSERT INTO countries VALUES (38,'Yugoslavia','yugoslavia.gif');
INSERT INTO countries VALUES (39,'Western Samoa','westernsamoa.gif');
INSERT INTO countries VALUES (40,'Malaysia','malaysia.gif');
INSERT INTO countries VALUES (41,'Dominican Republic','dominicanrep.gif');
INSERT INTO countries VALUES (42,'Greece','greece.gif');
INSERT INTO countries VALUES (43,'Guatemala','guatemala.gif');
INSERT INTO countries VALUES (44,'Israel','israel.gif');
INSERT INTO countries VALUES (45,'Pakistan','pakistan.gif');
INSERT INTO countries VALUES (46,'Czech Republic','czechrep.gif');
INSERT INTO countries VALUES (47,'Serbia','serbia.gif');
INSERT INTO countries VALUES (48,'Seychelles','seychelles.gif');
INSERT INTO countries VALUES (49,'Taiwan','taiwan.gif');
INSERT INTO countries VALUES (50,'Puerto Rico','puertorico.gif');
INSERT INTO countries VALUES (51,'Chile','chile.gif');
INSERT INTO countries VALUES (52,'Cuba','cuba.gif');
INSERT INTO countries VALUES (53,'Congo','congo.gif');
INSERT INTO countries VALUES (54,'Afghanistan','afghanistan.gif');
INSERT INTO countries VALUES (55,'Turkey','turkey.gif');
INSERT INTO countries VALUES (56,'Uzbekistan','uzbekistan.gif');
INSERT INTO countries VALUES (57,'Switzerland','switzerland.gif');
INSERT INTO countries VALUES (58,'Kiribati','kiribati.gif');
INSERT INTO countries VALUES (59,'Philippines','philippines.gif');
INSERT INTO countries VALUES (60,'Burkina Faso','burkinafaso.gif');
INSERT INTO countries VALUES (61,'Nigeria','nigeria.gif');
INSERT INTO countries VALUES (62,'Iceland','iceland.gif');
INSERT INTO countries VALUES (63,'Nauru','nauru.gif');
INSERT INTO countries VALUES (64,'Slovenia','slovenia.gif');
INSERT INTO countries VALUES (66,'Turkmenistan','turkmenistan.gif');
INSERT INTO countries VALUES (67,'Bosnia Herzegovina','bosniaherzegovina.gif');
INSERT INTO countries VALUES (68,'Andorra','andorra.gif');
INSERT INTO countries VALUES (69,'Lithuania','lithuania.gif');
INSERT INTO countries VALUES (70,'Macedonia','macadonia.gif');
INSERT INTO countries VALUES (71,'Netherlands Antilles','nethantilles.gif');
INSERT INTO countries VALUES (72,'Ukraine','ukraine.gif');
INSERT INTO countries VALUES (73,'Venezuela','venezuela.gif');
INSERT INTO countries VALUES (74,'Hungary','hungary.gif');
INSERT INTO countries VALUES (75,'Romania','romania.gif');
INSERT INTO countries VALUES (76,'Vanuatu','vanuatu.gif');
INSERT INTO countries VALUES (77,'Vietnam','vietnam.gif');
INSERT INTO countries VALUES (78,'Trinidad & Tobago','trinidadandtobago.gif');
INSERT INTO countries VALUES (79,'Honduras','honduras.gif');
INSERT INTO countries VALUES (80,'Kyrgyzstan','kyrgyzstan.gif');
INSERT INTO countries VALUES (81,'Ecuador','ecuador.gif');
INSERT INTO countries VALUES (82,'Bahamas','bahamas.gif');
INSERT INTO countries VALUES (83,'Peru','peru.gif');
INSERT INTO countries VALUES (84,'Cambodia','cambodia.gif');
INSERT INTO countries VALUES (85,'Barbados','barbados.gif');
INSERT INTO countries VALUES (86,'Bangladesh','bangladesh.gif');
INSERT INTO countries VALUES (87,'Laos','laos.gif');
INSERT INTO countries VALUES (88,'Uruguay','uruguay.gif');
INSERT INTO countries VALUES (89,'Antigua Barbuda','antiguabarbuda.gif');
INSERT INTO countries VALUES (90,'Paraguay','paraguay.gif');
INSERT INTO countries VALUES (92,'Union of Soviet Socialist Republics','ussr.gif');
INSERT INTO countries VALUES (93,'Thailand','thailand.gif');
INSERT INTO countries VALUES (94,'Senegal','senegal.gif');
INSERT INTO countries VALUES (95,'Togo','togo.gif');
INSERT INTO countries VALUES (96,'North Korea','northkorea.gif');
INSERT INTO countries VALUES (97,'Croatia','croatia.gif');
INSERT INTO countries VALUES (98,'Estonia','estonia.gif');
INSERT INTO countries VALUES (99,'Colombia','colombia.gif');
INSERT INTO countries VALUES (100,'Lebanon','lebanon.gif');
INSERT INTO countries VALUES (101,'Latvia','latvia.gif');
INSERT INTO countries VALUES (102,'Costa Rica','costarica.gif');
INSERT INTO countries VALUES (103,'Egypt','egypt.gif');
INSERT INTO countries VALUES (104,'Bulgaria','bulgaria.gif');
INSERT INTO countries VALUES (105,'Isla de Muerte','jollyroger.gif');
INSERT INTO countries VALUES (106,'Moldova','moldova.gif');
INSERT INTO countries VALUES (107,'Armenia','armenia.gif');
INSERT INTO countries VALUES (108,'Azerbaijan','azerbaijan.gif');
INSERT INTO countries VALUES (109,'Bahrain','bahrain.gif');
INSERT INTO countries VALUES (110,'Belarus','belarus.gif');
INSERT INTO countries VALUES (111,'Benin','benin.gif');
INSERT INTO countries VALUES (112,'Bhutan','bhutan.gif');
INSERT INTO countries VALUES (113,'Bolivia','bolivia.gif');
INSERT INTO countries VALUES (114,'Botswana','botswana.gif');
INSERT INTO countries VALUES (115,'Brunei','brunei.gif');
INSERT INTO countries VALUES (116,'Union of Myanmar','burma.gif');
INSERT INTO countries VALUES (117,'Burundi','burund.gif');
INSERT INTO countries VALUES (118,'Cameroon','cameroon.gif');
INSERT INTO countries VALUES (119,'Central African Republic','centralafricanrep.gif');
INSERT INTO countries VALUES (120,'Chad','chad.gif');
INSERT INTO countries VALUES (121,'Comoros','comoros.gif');
INSERT INTO countries VALUES (122,'Cyprus','cyprus.gif');
INSERT INTO countries VALUES (123,'Democratic Republic of the Congo','demrepcongo.gif');
INSERT INTO countries VALUES (124,'Djibouti','djiboutil.gif');
INSERT INTO countries VALUES (125,'Dominica','dominica.gif');
INSERT INTO countries VALUES (126,'El Salvador','elsalvado.gif');
INSERT INTO countries VALUES (127,'Equatorial Guinea','eq_guinea.gif');
INSERT INTO countries VALUES (128,'Eritrea','eritrea.gif');
INSERT INTO countries VALUES (129,'Ethiopia','ethiopia.gif');
INSERT INTO countries VALUES (130,'Fiji','fiji.gif');
INSERT INTO countries VALUES (131,'Gabon','gabon.gif');
INSERT INTO countries VALUES (132,'Gambia','gambia.gif');
INSERT INTO countries VALUES (133,'Georgia','georgia.gif');
INSERT INTO countries VALUES (134,'Ghana','ghana.gif');
INSERT INTO countries VALUES (135,'Grenada','grenada.gif');
INSERT INTO countries VALUES (136,'St. Vincent & the Grenadines','grenadines.gif');
INSERT INTO countries VALUES (137,'Guinea-Bissau','guineabissau.gif');
INSERT INTO countries VALUES (138,'Guinea','guineal.gif');
INSERT INTO countries VALUES (139,'Guyana','guyana.gif');
INSERT INTO countries VALUES (140,'Haiti','haiti.gif');
INSERT INTO countries VALUES (141,'Hong Kong','hong_kong.gif');
INSERT INTO countries VALUES (142,'Indonesia','indonesia.gif');
INSERT INTO countries VALUES (143,'Iran','iran.gif');
INSERT INTO countries VALUES (144,'Iraq','iraq.gif');
INSERT INTO countries VALUES (145,'Ivory Coast','ivorycoast.gif');
INSERT INTO countries VALUES (146,'Jordan','jordan.gif');
INSERT INTO countries VALUES (147,'Kazakhstan','kazakhstan.gif');
INSERT INTO countries VALUES (148,'Kenya','kenya.gif');
INSERT INTO countries VALUES (149,'Kuwait','kuwait.gif');
INSERT INTO countries VALUES (150,'Liberia','liberia.gif');
INSERT INTO countries VALUES (151,'Libya','libya.gif');
INSERT INTO countries VALUES (152,'Liechtenstein','liechtenstein.gif');
INSERT INTO countries VALUES (153,'Macao','macau.gif');
INSERT INTO countries VALUES (154,'Madagascar','madagascar.gif');
INSERT INTO countries VALUES (155,'Malawi','malawi.gif');
INSERT INTO countries VALUES (156,'Maldives','maldives.gif');
INSERT INTO countries VALUES (157,'Mali','mali.gif');
INSERT INTO countries VALUES (158,'Malta','malta.gif');
INSERT INTO countries VALUES (159,'Mauritania','mauritania.gif');
INSERT INTO countries VALUES (160,'Mauritius','mauritius.gif');
INSERT INTO countries VALUES (161,'Micronesia','micronesia.gif');
INSERT INTO countries VALUES (162,'Monaco','monaco.gif');
INSERT INTO countries VALUES (163,'Mongolia','mongolia.gif');
INSERT INTO countries VALUES (164,'Morocco','morocco.gif');
INSERT INTO countries VALUES (165,'Mozambique','mozambique.gif');
INSERT INTO countries VALUES (166,'Namibia','namibia.gif');
INSERT INTO countries VALUES (167,'Nepal','nepal.gif');
INSERT INTO countries VALUES (168,'Nicaragua','nicaragua.gif');
INSERT INTO countries VALUES (169,'Niger','niger.gif');
INSERT INTO countries VALUES (170,'North Korea','north_korea.gif');
INSERT INTO countries VALUES (171,'Oman','oman.gif');
INSERT INTO countries VALUES (172,'Panama','panama.gif');
INSERT INTO countries VALUES (173,'Papua New Guinea','papuanewguinea.gif');
INSERT INTO countries VALUES (174,'Qatar','qatar.gif');
INSERT INTO countries VALUES (175,'Rwanda','rawanda.gif');
INSERT INTO countries VALUES (176,'Sao Tome and Principe','sao_tome.gif');
INSERT INTO countries VALUES (177,'Saudi Arabia','saudiarabia.gif');
INSERT INTO countries VALUES (178,'Sierra Leone','sierraleone.gif');
INSERT INTO countries VALUES (179,'Slovakia','slovakia.gif');
INSERT INTO countries VALUES (180,'Solomon Islands','solomon_islands.gif');
INSERT INTO countries VALUES (181,'Somalia','somalia.gif');
INSERT INTO countries VALUES (182,'South Korea','south_korea.gif');
INSERT INTO countries VALUES (183,'Sri Lanka','srilanka.gif');
INSERT INTO countries VALUES (184,'St. Kitts & Nevis','stkitts_nevis.gif');
INSERT INTO countries VALUES (185,'Saint Lucia','stlucia.gif');
INSERT INTO countries VALUES (186,'Sudan','sudan.gif');
INSERT INTO countries VALUES (187,'Suriname','suriname.gif');
INSERT INTO countries VALUES (188,'Syria','syria.gif');
INSERT INTO countries VALUES (189,'Tajikistan','tajikistan.gif');
INSERT INTO countries VALUES (190,'Tanzania','tanzania.gif');
INSERT INTO countries VALUES (191,'Tonga','tonga.gif');
INSERT INTO countries VALUES (192,'Tunisia','tunisia.gif');
INSERT INTO countries VALUES (193,'Tuvalu','tuvala.gif');
INSERT INTO countries VALUES (194,'United Arab Emirates','uae.gif');
INSERT INTO countries VALUES (195,'Uganda','uganda.gif');
INSERT INTO countries VALUES (196,'Yemen','yemen.gif');
INSERT INTO countries VALUES (197,'Zaire','zaire.gif');
INSERT INTO countries VALUES (198,'Zambia','zambia.gif');
INSERT INTO countries VALUES (199,'Zimbabwe','zimbabwe.gif');

CREATE TABLE `announcement` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `body` text NOT NULL,
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM AUTO_INCREMENT=23;

ALTER TABLE `users` ADD `announce` ENUM( 'yes', 'no' ) NOT NULL DEFAULT 'no';

ALTER TABLE users ADD passkey VARCHAR(32) NOT NULL;
ALTER TABLE peers ADD passkey VARCHAR(32) NOT NULL;

ALTER TABLE users ADD (last_browse int(11) NOT NULL default '0');

CREATE TABLE `faq` (
  `id` int(10) NOT NULL auto_increment,
  `type` set('categ','item') NOT NULL default 'item',
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `flag` set('0','1','2','3') NOT NULL default '1',
  `categ` int(10) NOT NULL default '0',
  `order` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=66 ;

-- 
-- Dumping data for table `faq`
-- 

INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES 
(1, 'categ', 'Site information', '', '1', 0, 1),
(2, 'categ', 'User information', '', '1', 0, 2),
(3, 'categ', 'Stats', '', '1', 0, 3),
(4, 'categ', 'Uploading', '', '1', 0, 4),
(5, 'categ', 'Downloading', '', '1', 0, 5),
(6, 'categ', 'How can I improve my download speed?', '', '1', 0, 6),
(7, 'categ', 'My ISP uses a transparent proxy. What should I do?', '', '1', 0, 7),
(8, 'categ', 'Why can''t I connect? Is the site blocking me?', '', '1', 0, 8),
(9, 'categ', 'What if I can''t find the answer to my problem here?', '', '1', 0, 9),
(10, 'item', 'What is this bittorrent all about anyway? How do I get the files?', 'Check out <a class=altlink href="http://www.btfaq.com/">Brian''s BitTorrent FAQ and Guide</a>', '1', 1, 1),
(11, 'item', 'Where does the donated money go?', 'Donated money goes to server costs/upgrades.', '1', 1, 2),
(13, 'item', 'I registered an account but did not receive the confirmation e-mail!', 'You can use <a class=altlink href=delacct.php>this form</a> to delete the account so you can re-register.\r\nNote though that if you didn''t receive the email the first time it will probably not\r\nsucceed the second time either so you should really try another email address.', '1', 2, 1),
(14, 'item', 'I''ve lost my user name or password! Can you send it to me?', 'Please use <a class=altlink href=recover.php>this form</a> to have the login details mailed back to you.', '1', 2, 2),
(15, 'item', 'Can you rename my account?', 'We do not rename accounts. Please create a new one. (Use <a href=delacct.php class=altlink>this form</a> to\r\ndelete your present account.)', '1', 2, 3),
(16, 'item', 'Can you delete my (confirmed) account?', 'You can do it yourself by using <a href=delacct.php class=altlink>this form</a>.', '2', 2, 4),
(17, 'item', 'So, what''s MY ratio?', 'Click on your <a class=altlink href=my.php>profile</a>, then on your user name (at the top).<br>\r\n<br>\r\nIt''s important to distinguish between your overall ratio and the individual ratio on each torrent\r\nyou may be seeding or leeching. The overall ratio takes into account the total uploaded and downloaded\r\nfrom your account since you joined the site. The individual ratio takes into account those values for each torrent.<br>\r\n<br>\r\nYou may see two symbols instead of a number: &quot;Inf.&quot;, which is just an abbreviation for Infinity, and\r\nmeans that you have downloaded 0 bytes while uploading a non-zero amount (ul/dl becomes infinity); &quot;---&quot;,\r\nwhich should be read as &quot;non-available&quot;, and shows up when you have both downloaded and uploaded 0 bytes\r\n(ul/dl = 0/0 which is an indeterminate amount).', '1', 2, 5),
(18, 'item', 'Why is my IP displayed on my details page?', 'Only you and the site moderators can view your IP address and email. Regular users do not see that information.', '1', 2, 6),
(19, 'item', 'Help! I cannot login!? (a.k.a. Login of Death)', 'This problem sometimes occurs with MSIE. Close all Internet Explorer windows and open Internet Options in the control panel. Click the Delete Cookies button. You should now be able to login.\r\n', '1', 2, 7),
(20, 'item', 'My IP address is dynamic. How do I stay logged in?', 'You do not have to anymore. All you have to do is make sure you are logged in with your actual\r\nIP when starting a torrent session. After that, even if the IP changes mid-session,\r\nthe seeding or leeching will continue and the statistics will update without any problem.', '2', 2, 8),
(21, 'item', 'Why is my port number reported as "---"? (And why should I care?)', 'The tracker has determined that you are firewalled or NATed and cannot accept incoming connections.\r\n<br>\r\n<br>\r\nThis means that other peers in the swarm will be unable to connect to you, only you to them. Even worse,\r\nif two peers are both in this state they will not be able to connect at all. This has obviously a\r\ndetrimental effect on the overall speed.\r\n<br>\r\n<br>\r\nThe way to solve the problem involves opening the ports used for incoming connections\r\n(the same range you defined in your client) on the firewall and/or configuring your\r\nNAT server to use a basic form of NAT\r\nfor that range instead of NAPT (the actual process differs widely between different router models.\r\nCheck your router documentation and/or support forum. You will also find lots of information on the\r\nsubject at <a class=altlink href="http://portforward.com/">PortForward</a>).', '1', 2, 9),
(22, 'item', 'What are the different user classes?', '<table cellspacing=3 cellpadding=0>\r\n<tr>\r\n<td class=embedded width=100 bgcolor="#F5F4EA">&nbsp; <b>User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>The default class of new members.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b>Power User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Can download DOX over 1MB and view NFO files.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><img src="pic/star.gif" alt="Star"></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Has donated money to TorrentBits.org . </td>\r\n</tr>\r\n<tr>\r\n<td class=embedded valign=top bgcolor="#F5F4EA">&nbsp; <b>VIP</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Same privileges as Power User and is considered an Elite Member of TorrentBits. Immune to automatic demotion.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b>Other</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Customised title.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#4040c0">Uploader</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Same as PU except with upload rights and immune to automatic demotion.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded valign=top bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">Moderator</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Can edit and delete any uploaded torrents. Can also moderate usercomments and disable accounts.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">Administrator</color></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Can do just about anything.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">SysOp</color></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Site owner.</td>\r\n</tr>\r\n</table>', '1', 2, 10),
(23, 'item', 'How does this promotion thing work anyway?', '<table cellspacing=3 cellpadding=0>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA" valign=top width=100>&nbsp; <b>Power User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Must have been be a member for at least 4 weeks, have uploaded at least 25GB and\r\nhave a ratio at or above 1.05.<br>\r\nThe promotion is automatic when these conditions are met. Note that you will be automatically demoted from<br>\r\nthis status if your ratio drops below 0.95 at any time.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><img src="pic/star.gif" alt="Star"></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Just donate, and send <a class=altlink href=sendmessage.php?receiver=2>Redbeard</a> - and only\r\nRedbeard - the details.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA" valign=top>&nbsp; <b>VIP</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Assigned by mods at their discretion to users they feel contribute something special to the site.<br>\r\n(Anyone begging for VIP status will be automatically disqualified.)</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b>Other</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Conferred by mods at their discretion (not available to Users or Power Users).</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#4040c0">Uploader</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Appointed by Admins/SysOp (see the ''Uploading'' section for conditions).</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor="#F5F4EA">&nbsp; <b><font color="#A83838">Moderator</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>You don''t ask us, we''ll ask you!</td>\r\n</tr>\r\n</table>', '1', 2, 11),
(24, 'item', 'Hey! I''ve seen Power Users with less than 25GB uploaded!', 'The PU limit used to be 10GB and we didn''t demote anyone when we raised it to 25GB.', '1', 2, 12),
(25, 'item', 'Why can''t my friend become a member?', 'There is a 5000 users limit. When that number is reached we stop accepting new members. Accounts inactive for more than 42 days are automatically deleted, so keep trying. (There is no reservation or queuing system, don''t ask for that.)', '2', 2, 13),
(26, 'item', 'How do I add an avatar to my profile?', 'First, find an image that you like, and that is within the\r\n<a class=altlink href=rules.php>rules</a>. Then you will have\r\nto find a place to host it.\r\nPopular choices are <a class="altlink" href="http://photobucket.com/">Photobucket</a>,\r\n<a class="altlink" href="http://uploadit.org/">Upload-It!</a> or\r\n<a class="altlink" href="http://www.imageshack.us/">ImageShack</a>.\r\nAll that is left to do is copy the URL you were given when\r\nuploading it to the avatar field in your <a class="altlink" href="my.php">profile</a>.<br>\r\n<br>\r\nPlease do not make a post just to test your avatar.', '1', 2, 14),
(27, 'item', 'Most common reason for stats not updating', '<ul>\r\n<li>The user is cheating. (a.k.a. &quot;Summary Ban&quot;)</li>\r\n<li>The server is overloaded and unresponsive. Just try to keep the session open until the server responds again. (Flooding the server with consecutive manual updates is not recommended.)</li>\r\n<li>You are using a faulty client. If you want to use an experimental or CVS version you do it at your own risk.</li>\r\n<li>Tracker is banning old and bad bt clients, use recomended bt clients like <a class=altlink href=http://utorrent.com>utorrents</a> or <a class=altlink href=http://azureus.sf.net>Azureus</a>.</li>\r\n</ul>', '1', 3, 1),
(28, 'item', 'Best practices', '<ul>\r\n<li>If a torrent you are currently leeching/seeding is not listed on your profile, just wait or force a manual update.</li>\r\n<li>Make sure you exit your client properly, so that the tracker receives &quot;event=completed&quot;.</li>\r\n<li>If the tracker is down, do not stop seeding. As long as the tracker is back up before you exit the client the stats should update properly.</li>\r\n</ul>', '1', 3, 2),
(29, 'item', 'May I use any bittorrent client?', 'Yes. The tracker now updates the stats correctly for all bittorrent clients. However, we still recommend\r\nthat you <b>avoid</b> the following clients:<br>\r\n<br>\r\n� BitTorrent++,<br>\r\n� Nova Torrent,<br>\r\n� TorrentStorm.<br>\r\n<br>\r\nThese clients do not report correctly to the tracker when canceling/finishing a torrent session.\r\nIf you use them then a few MB may not be counted towards\r\nthe stats near the end, and torrents may still be listed in your profile for some time after you have closed the client.<br>\r\n<br>\r\nAlso, clients in alpha or beta version should be avoided.', '1', 3, 3),
(30, 'item', 'Why is a torrent I''m leeching/seeding listed several times in my profile?', 'If for some reason (e.g. pc crash, or frozen client) your client exits improperly and you restart it,\r\nit will have a new peer_id, so it will show as a new torrent. The old one will never receive a &quot;event=completed&quot;\r\nor &quot;event=stopped&quot; and will be listed until some tracker timeout. Just ignore it, it will eventually go away.', '1', 3, 4),
(31, 'item', 'I''ve finished or cancelled a torrent. Why is it still listed in my profile?', 'Some clients, notably TorrentStorm and Nova Torrent, do not report properly to the tracker when canceling or finishing a torrent.\r\nIn that case the tracker will keep waiting for some message - and thus listing the torrent as seeding or leeching - until some\r\ntimeout occurs. Just ignore it, it will eventually go away.', '1', 3, 5),
(32, 'item', 'Why do I sometimes see torrents I''m not leeching in my profile!?', 'When a torrent is first started, the tracker uses the IP to identify the user. Therefore the torrent will\r\nbecome associated with the user <i>who last accessed the site</i> from that IP. If you share your IP in some\r\nway (you are behind NAT/ICS, or using a proxy), and some of the persons you share it with are also users,\r\nyou may occasionally see their torrents listed in your profile. (If they start a torrent session from that\r\nIP and you were the last one to visit the site the torrent will be associated with you). Note that now\r\ntorrents listed in your profile will always count towards your total stats.', '2', 3, 6),
(33, 'item', 'Multiple IPs (Can I login from different computers?)', 'Yes, the tracker is now capable of following sessions from different IPs for the same user. A torrent is associated with the user when it starts, and only at that moment is the IP relevant. So if you want to seed/leech from computer A and computer B with the same account you should access the site from computer A, start the torrent there, and then repeat both steps from computer B (not limited to two computers or to a single torrent on each, this is just the simplest example). You do not need to login again when closing the torrent.\r\n', '2', 3, 7),
(34, 'item', 'How does NAT/ICS change the picture?', 'This is a very particular case in that all computers in the LAN will appear to the outside world as having the same IP. We must distinguish\r\nbetween two cases:<br>\r\n<br>\r\n<b>1.</b> <i>You are the single TorrentBits users in the LAN</i><br>\r\n<br>\r\nYou should use the same TorrentBits account in all the computers.<br>\r\n<br>\r\nNote also that in the ICS case it is preferable to run the BT client on the ICS gateway. Clients running on the other computers\r\nwill be unconnectable (their ports will be listed as &quot;---&quot;, as explained elsewhere in the FAQ) unless you specify\r\nthe appropriate services in your ICS configuration (a good explanation of how to do this for Windows XP can be found\r\n<a class=altlink href="redir.php?url=http://www.microsoft.com/downloads/details.aspx?FamilyID=1dcff3ce-f50f-4a34-ae67-cac31ccd7bc9&amp;displaylang=en">here</a>).\r\nIn the NAT case you should configure different ranges for clients on different computers and create appropriate NAT rules in the router. (Details vary widely from router to router and are outside the scope of this FAQ. Check your router documentation and/or support forum.)<br>\r\n<br>\r\n<br>\r\n<b>2.</b> <i>There are multiple TorrentBits users in the LAN</i><br>\r\n<br>\r\nAt present there is no way of making this setup always work properly with TorrentBits.\r\nEach torrent will be associated with the user who last accessed the site from within\r\nthe LAN before the torrent was started.\r\nUnless there is cooperation between the users mixing of statistics is possible.\r\n(User A accesses the site, downloads a .torrent file, but does not start the torrent immediately.\r\nMeanwhile, user B accesses the site. User A then starts the torrent. The torrent will count\r\ntowards user B''s statistics, not user A''s.)\r\n<br>\r\n<br>\r\nIt is your LAN, the responsibility is yours. Do not ask us to ban other users\r\nwith the same IP, we will not do that. (Why should we ban <i>him</i> instead of <i>you</i>?)', '1', 3, 8),
(35, 'item', 'For those of you who are interested...', 'Some <a class=altlink href="anatomy.php">info</a> about the &quot;Anatomy of a torrent session&quot;.', '1', 3, 9),
(36, 'item', 'Why can''t I upload torrents?', 'Only specially authorized users (<font color="#4040c0"><b>Uploaders</b></font>) have permission to upload torrents.', '1', 4, 1),
(66, 'item', 'How can i become uploader?', 'Contact staff members, they maybe promote you.', '3', 4, 4),
(38, 'item', 'Can I upload your torrents to other trackers?', 'No. We are a closed, limited-membership community. Only registered users can use the TB tracker.\r\nPosting our torrents on other trackers is useless, since most people who attempt to download them will\r\nbe unable to connect with us. This generates a lot of frustration and bad-will against us at TorrentBits,\r\nand will therefore not be tolerated.<br>\r\n<br>\r\nComplaints from other sites'' administrative staff about our torrents being posted on their sites will\r\nresult in the banning of the users responsible.<br>\r\n<br>\r\n(However, the files you download from us are yours to do as you please. You can always create another\r\ntorrent, pointing to some other tracker, and upload it to the site of your choice.)', '3', 4, 3),
(39, 'item', 'How do I use the files I''ve downloaded?', 'Check out <a class=altlink href=videoformats.php>this guide</a>.', '1', 5, 1),
(40, 'item', 'Downloaded a movie and don''t know what CAM/TS/TC/SCR means?', 'Check out <a class=altlink href=videoformats.php>this guide.', '1', 5, 2),
(41, 'item', 'Why did an active torrent suddenly disappear?', 'There may be three reasons for this:<br>\r\n(<b>1</b>) The torrent may have been out-of-sync with the site\r\n<a class=altlink href=rules.php>rules</a>.<br>\r\n(<b>2</b>) The uploader may have deleted it because it was a bad release.\r\nA replacement will probably be uploaded to take its place.<br>\r\n(<b>3</b>) Torrents are automatically deleted after 28 days.', '2', 5, 3),
(42, 'item', 'How do I resume a broken download or reseed something?', 'Open the .torrent file. When your client asks you for a location, choose the location of the existing file(s) and it will resume/reseed the torrent.\r\n', '1', 5, 4),
(43, 'item', 'Why do my downloads sometimes stall at 99%?', 'The more pieces you have, the harder it becomes to find peers who have pieces you are missing. That is why downloads sometimes slow down or even stall when there are just a few percent remaining. Just be patient and you will, sooner or later, get the remaining pieces.\r\n', '1', 5, 5),
(44, 'item', 'What are these "a piece has failed an hash check" messages?', 'Bittorrent clients check the data they receive for integrity. When a piece fails this check it is\r\nautomatically re-downloaded. Occasional hash fails are a common occurrence, and you shouldn''t worry.<br>\r\n<br>\r\nSome clients have an (advanced) option/preference to ''kick/ban clients that send you bad data'' or\r\nsimilar. It should be turned on, since it makes sure that if a peer repeatedly sends you pieces that\r\nfail the hash check it will be ignored in the future.', '1', 5, 6),
(45, 'item', 'The torrent is supposed to be 100MB. How come I downloaded 120MB?', 'See the hash fails topic. If your client receives bad data it will have to redownload it, therefore\r\nthe total downloaded may be larger than the torrent size. Make sure the &quot;kick/ban&quot; option is turned on\r\nto minimize the extra downloads.', '1', 5, 7),
(46, 'item', 'Why do I get a "Not authorized (xx h) - READ THE FAQ" error?', 'From the time that each <b>new</b> torrent is uploaded to the tracker, there is a period of time that\r\nsome users must wait before they can download it.<br>\r\nThis delay in downloading will only affect users with a low ratio, and users with low upload amounts.<br>\r\n<br>\r\n<table cellspacing=3 cellpadding=0>\r\n <tr>\r\n	<td class=embedded width="70">Ratio below</td>\r\n	<td class=embedded width="40" bgcolor="#F5F4EA"><font color="#BB0000"><div align="center">0.50</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded width="110">and/or upload below</td>\r\n	<td class=embedded width="40" bgcolor="#F5F4EA"><div align="center">5.0GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded width="50">delay of</td>\r\n	<td class=embedded width="40" bgcolor="#F5F4EA"><div align="center">24h</div></td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded>Ratio below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><font color="#A10000"><div align="center">0.65</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>and/or upload below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">6.5GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>delay of</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">12h</div></td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded>Ratio below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><font color="#880000"><div align="center">0.80</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>and/or upload below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">8.0GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>delay of</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">6h</div></td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded>Ratio below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><font color="#6E0000"><div align="center">0.95</div></font></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>and/or upload below</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">9.5GB</div></td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded>delay of</td>\r\n	<td class=embedded bgcolor="#F5F4EA"><div align="center">3h</div></td>\r\n </tr>\r\n</table>\r\n<br>\r\n"<b>And/or</b>" means any or both. Your delay will be the <b>largest</b> one for which you meet <b>at least</b> one condition.<br>\r\n<br>\r\nThis applies to new users as well, so opening a new account will not help. Note also that this\r\nworks at tracker level, you will be able to grab the .torrent file itself at any time.<br>\r\n<br>\r\n<!--The delay applies only to leeching, not to seeding. If you got the files from any other source and\r\nwish to seed them you may do so at any time irrespectively of your ratio or total uploaded.<br>-->\r\nN.B. Due to some users exploiting the ''no-delay-for-seeders'' policy we had to change it. The delay\r\nnow applies to both seeding and leeching. So if you are subject to a delay and get the files from\r\nsome other source you will not be able to seed them until the delay has elapsed.', '3', 5, 8),
(47, 'item', 'Why do I get a "rejected by tracker - Port xxxx is blacklisted" error?', 'Your client is reporting to the tracker that it uses one of the default bittorrent ports\r\n(6881-6889) or any other common p2p port for incoming connections.<br>\r\n<br>\r\nTorrentBits does not allow clients to use ports commonly associated with p2p protocols.\r\nThe reason for this is that it is a common practice for ISPs to throttle those ports\r\n(that is, limit the bandwidth, hence the speed). <br>\r\n<br>\r\nThe blocked ports list include, but is not neccessarily limited to, the following:<br>\r\n<br>\r\n<table cellspacing=3 cellpadding=0>\r\n  <tr>\r\n	<td class=embedded width="80">Direct Connect</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">411 - 413</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">Kazaa</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">1214</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">eDonkey</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">4662</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">Gnutella</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">6346 - 6347</div></td>\r\n  </tr>\r\n  <tr>\r\n	<td class=embedded width="80">BitTorrent</td>\r\n	<td class=embedded width="80" bgcolor="#F5F4EA"><div align="center">6881 - 6889</div></td>\r\n </tr>\r\n</table>\r\n<br>\r\nIn order to use use our tracker you must  configure your client to use\r\nany port range that does not contain those ports (a range within the region 49152 through 65535 is preferable,\r\ncf. <a class=altlink href="http://www.iana.org/assignments/port-numbers">IANA</a>). Notice that some clients,\r\nlike Azureus 2.0.7.0 or higher, use a single port for all torrents, while most others use one port per open torrent. The size\r\nof the range you choose should take this into account (typically less than 10 ports wide. There\r\nis no benefit whatsoever in choosing a wide range, and there are possible security implications). <br>\r\n<br>\r\nThese ports are used for connections between peers, not client to tracker.\r\nTherefore this change will not interfere with your ability to use other trackers (in fact it\r\nshould <i>increase</i> your speed with torrents from any tracker, not just ours). Your client\r\nwill also still be able to connect to peers that are using the standard ports.\r\nIf your client does not allow custom ports to be used, you will have to switch to one that does.<br>\r\n<br>\r\nDo not ask us, or in the forums, which ports you should choose. The more random the choice is the harder\r\nit will be for ISPs to catch on to us and start limiting speeds on the ports we use.\r\nIf we simply define another range ISPs will start throttling that range also. <br>\r\n<br>\r\nFinally, remember to forward the chosen ports in your router and/or open them in your\r\nfirewall, should you have them.', '3', 5, 9),
(48, 'item', 'What''s this "IOError - [Errno13] Permission denied" error?', 'If you just want to fix it reboot your computer, it should solve the problem.\r\nOtherwise read on.<br>\r\n<br>\r\nIOError means Input-Output Error, and that is a file system error, not a tracker one.\r\nIt shows up when your client is for some reason unable to open the partially downloaded\r\ntorrent files. The most common cause is two instances of the client to be running\r\nsimultaneously:\r\nthe last time the client was closed it somehow didn''t really close but kept running in the\r\nbackground, and is therefore still\r\nlocking the files, making it impossible for the new instance to open them.<br>\r\n<br>\r\nA more uncommon occurrence is a corrupted FAT. A crash may result in corruption\r\nthat makes the partially downloaded files unreadable, and the error ensues. Running\r\nscandisk should solve the problem. (Note that this may happen only if you''re running\r\nWindows 9x - which only support FAT - or NT/2000/XP with FAT formatted hard drives.\r\nNTFS is much more robust and should never permit this problem.)', '3', 5, 10),
(49, 'item', 'What''s this "TTL" in the browse page?', 'The torrent''s Time To Live, in hours. It means the torrent will be deleted\r\nfrom the tracker after that many hours have elapsed (yes, even if it is still active).\r\nNote that this a maximum value, the torrent may be deleted at any time if it''s inactive.', '3', 5, 11),
(50, 'item', 'Do not immediately jump on new torrents', 'The download speed mostly depends on the seeder-to-leecher ratio (SLR). Poor download speed is\r\nmainly a problem with new and very popular torrents where the SLR is low.<br>\r\n<br>\r\n(Proselytising sidenote: make sure you remember that you did not enjoy the low speed.\r\n<b>Seed</b> so that others will not endure the same.)<br>\r\n<br>\r\nThere are a couple of things that you can try on your end to improve your speed:<br>\r\n<br>In particular, do not do it if you have a slow connection. The best speeds will be found around the\r\nhalf-life of a torrent, when the SLR will be at its highest. (The downside is that you will not be able to seed\r\nso much. It''s up to you to balance the pros and cons of this.)', '1', 6, 1),
(51, 'item', 'Limit your upload speed', 'The upload speed affects the download speed in essentially two ways:<br>\r\n<ul>\r\n    <li>Bittorrent peers tend to favour those other peers that upload to them. This means that if A and B\r\n	are leeching the same torrent and A is sending data to B at high speed then B will try to reciprocate.\r\n	So due to this effect high upload speeds lead to high download speeds.</li>\r\n\r\n    <li>Due to the way TCP works, when A is downloading something from B it has to keep telling B that\r\n        it received the data sent to him. (These are called acknowledgements - ACKs -, a sort of &quot;got it!&quot; messages).\r\n        If A fails to do this then B will stop sending data and wait. If A is uploading at full speed there may be no\r\n        bandwidth left for the ACKs and they will be delayed. So due to this effect excessively high upload speeds lead\r\n        to low download speeds.</li>\r\n</ul>\r\n\r\nThe full effect is a combination of the two. The upload should be kept as high as possible while allowing the\r\nACKs to get through without delay. <b>A good thumb rule is keeping the upload at about 80% of the theoretical\r\nupload speed.</b> You will have to fine tune yours to find out what works best for you. (Remember that keeping the\r\nupload high has the additional benefit of helping with your ratio.) <br>\r\n<br>\r\nIf you are running more than one instance of a client it is the overall upload speed that you must take into account.\r\nSome clients (e.g. Azureus) limit global upload speed, others (e.g. Shad0w''s) do it on a per torrent basis.\r\nKnow your client. The same applies if you are using your connection for anything else (e.g. browsing or ftp),\r\nalways think of the overall upload speed.', '1', 6, 2),
(52, 'item', 'Limit the number of simultaneous connections', 'Some operating systems (like Windows 9x) do not deal well with a large number of connections, and may even crash.\r\nAlso some home routers (particularly when running NAT and/or firewall with stateful inspection services) tend to become\r\nslow or crash when having to deal with too many connections. There are no fixed values for this, you may try 60 or 100\r\nand experiment with the value. Note that these numbers are additive, if you have two instances of\r\na client running the numbers add up.', '1', 6, 3),
(53, 'item', 'Limit the number of simultaneous uploads', 'Isn''t this the same as above? No. Connections limit the number of peers your client is talking to and/or\r\ndownloading from. Uploads limit the number of peers your client is actually uploading to. The ideal number is\r\ntypically much lower than the number of connections, and highly dependent on your (physical) connection.', '1', 6, 4),
(54, 'item', 'Just give it some time', 'As explained above peers favour other peers that upload to them. When you start leeching a new torrent you have\r\nnothing to offer to other peers and they will tend to ignore you. This makes the starts slow, in particular if,\r\nby change, the peers you are connected to include few or no seeders. The download speed should increase as soon\r\nas you have some pieces to share.', '1', 6, 5),
(55, 'item', 'Why is my browsing so slow while leeching?', 'Your download speed is always finite. If you are a peer in a fast torrent it will almost certainly saturate your\r\ndownload bandwidth, and your browsing will suffer. At the moment there is no client that allows you to limit the\r\ndownload speed, only the upload. You will have to use a third-party solution,\r\nsuch as <a class=altlink href="redir.php?url=http://www.netlimiter.com/">NetLimiter</a>.<br>\r\n<br>\r\nBrowsing was used just as an example, the same would apply to gaming, IMing, etc...', '1', 6, 6),
(56, 'item', 'What is a proxy?', 'Basically a middleman. When you are browsing a site through a proxy your requests are sent to the proxy and the proxy\r\nforwards them to the site instead of you connecting directly to the site. There are several classifications\r\n(the terminology is far from standard):<br>\r\n<br>\r\n\r\n\r\n<table cellspacing=3 cellpadding=0>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA" width="100">&nbsp;Transparent</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">A transparent proxy is one that needs no configuration on the clients. It works by automatically redirecting all port 80 traffic to the proxy. (Sometimes used as synonymous for non-anonymous.)</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Explicit/Voluntary</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">Clients must configure their browsers to use them.</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Anonymous</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">The proxy sends no client identification to the server. (HTTP_X_FORWARDED_FOR header is not sent; the server does not see your IP.)</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Highly Anonymous</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">The proxy sends no client nor proxy identification to the server. (HTTP_X_FORWARDED_FOR, HTTP_VIA and HTTP_PROXY_CONNECTION headers are not sent; the server doesn''t see your IP and doesn''t even know you''re using a proxy.)</td>\r\n </tr>\r\n <tr>\r\n	<td class=embedded valign="top" bgcolor="#F5F4EA">&nbsp;Public</td>\r\n	<td class=embedded width="10">&nbsp;</td>\r\n	<td class=embedded valign="top">(Self explanatory)</td>\r\n </tr>\r\n</table>\r\n<br>\r\nA transparent proxy may or may not be anonymous, and there are several levels of anonymity.', '1', 7, 1),
(57, 'item', 'How do I find out if I''m behind a (transparent/anonymous) proxy?', 'Try <a href=http://proxyjudge.org class="altlink">ProxyJudge</a>. It lists the HTTP headers that the server where it is running\r\nreceived from you. The relevant ones are HTTP_CLIENT_IP, HTTP_X_FORWARDED_FOR and REMOTE_ADDR.<br>\r\n<br>\r\n<br>\r\n<b>Why is my port listed as &quot;---&quot; even though I''m not NAT/Firewalled?</b><a name="prox3"></a><br>\r\n<br>\r\nThe TorrentBits tracker is quite smart at finding your real IP, but it does need the proxy to send the HTTP header\r\nHTTP_X_FORWARDED_FOR. If your ISP''s proxy does not then what happens is that the tracker will interpret the proxy''s IP\r\naddress as the client''s IP address. So when you login and the tracker tries to connect to your client to see if you are\r\nNAT/firewalled it will actually try to connect to the proxy on the port your client reports to be using for\r\nincoming connections. Naturally the proxy will not be listening on that port, the connection will fail and the\r\ntracker will think you are NAT/firewalled.', '1', 7, 2),
(58, 'item', 'Can I bypass my ISP''s proxy?', 'If your ISP only allows HTTP traffic through port 80 or blocks the usual proxy ports then you would need to use something\r\nlike <a href=http://www.socks.permeo.com>socks</a> and that is outside the scope of this FAQ.<br>\r\n<br>\r\nThe site accepts connections on port 81 besides the usual 80, and using them may be enough to fool some proxies. So the first\r\nthing to try should be connecting to www.torrentbits.org:81. Note that even if this works your bt client will still try\r\nto connect to port 80 unless you edit the announce url in the .torrent file.<br>\r\n<br>\r\nOtherwise you may try the following:<br>\r\n<ul>\r\n    <li>Choose any public <b>non-anonymous</b> proxy that does <b>not</b> use port 80\r\n	(e.g. from <a href=http://tools.rosinstrument.com/proxy  class="altlink">this</a>,\r\n	<a href=http://www.proxy4free.com/index.html  class="altlink">this</a> or\r\n	<a href=http://www.samair.ru/proxy  class="altlink">this</a> list).</li>\r\n\r\n    <li>Configure your computer to use that proxy. For Windows XP, do <i>Start</i>, <i>Control Panel</i>, <i>Internet Options</i>,\r\n	<i>Connections</i>, <i>LAN Settings</i>, <i>Use a Proxy server</i>, <i>Advanced</i> and type in the IP and port of your chosen\r\n	proxy. Or from Internet Explorer use <i>Tools</i>, <i>Internet Options</i>, ...<br></li>\r\n\r\n    <li>(Facultative) Visit <a href=http://proxyjudge.org  class="altlink">ProxyJudge</a>. If you see an HTTP_X_FORWARDED_FOR in\r\n	the list followed by your IP then everything should be ok, otherwise choose another proxy and try again.<br></li>\r\n\r\n    <li>Visit TorrentBits. Hopefully the tracker will now pickup your real IP (check your profile to make sure).</li>\r\n</ul>\r\n<br>\r\nNotice that now you will be doing all your browsing through a public proxy, which are typically quite slow.\r\nCommunications between peers do not use port 80 so their speed will not be affected by this, and should be better than when\r\nyou were &quot;unconnectable&quot;.', '1', 7, 3),
(59, 'item', 'How do I make my bittorrent client use a proxy?', 'Just configure Windows XP as above. When you configure a proxy for Internet Explorer you''re actually configuring a proxy for\r\nall HTTP traffic (thank Microsoft and their &quot;IE as part of the OS policy&quot; ). On the other hand if you use another\r\nbrowser (Opera/Mozilla/Firefox) and configure a proxy there you''ll be configuring a proxy just for that browser. We don''t\r\nknow of any BT client that allows a proxy to be specified explicitly.', '1', 7, 4),
(60, 'item', 'Why can''t I signup from behind a proxy?', 'It is our policy not to allow new accounts to be opened from behind a proxy.', '1', 7, 5),
(61, 'item', 'Does this apply to other torrent sites?', 'This section was written for TorrentBits, a closed, port 80-81 tracker. Other trackers may be open or closed, and many listen\r\non e.g. ports 6868 or 6969. The above does <b>not</b> necessarily apply to other trackers.', '1', 7, 6),
(62, 'item', 'Maybe my address is blacklisted?', 'The site blocks addresses listed in the (former) <a class=altlink href="http://methlabs.org/">PeerGuardian</a>\r\ndatabase, as well as addresses of banned users. This works at Apache/PHP level, it''s just a script that\r\nblocks <i>logins</i> from those addresses. It should not stop you from reaching the site. In particular\r\nit does not block lower level protocols, you should be able to ping/traceroute the server even if your\r\naddress is blacklisted. If you cannot then the reason for the problem lies elsewhere.<br>\r\n<br>\r\nIf somehow your address is indeed blocked in the PG database do not contact us about it, it is not our\r\npolicy to open <i>ad hoc</i> exceptions. You should clear your IP with the database maintainers instead.', '1', 8, 1),
(63, 'item', 'Your ISP blocks the site''s address', '(In first place, it''s unlikely your ISP is doing so. DNS name resolution and/or network problems are the usual culprits.)\r\n<br>\r\nThere''s nothing we can do.\r\nYou should contact your ISP (or get a new one). Note that you can still visit the site via a proxy, follow the instructions\r\nin the relevant section. In this case it doesn''t matter if the proxy is anonymous or not, or which port it listens to.<br>\r\n<br>\r\nNotice that you will always be listed as an &quot;unconnectable&quot; client because the tracker will be unable to\r\ncheck that you''re capable of accepting incoming connections.', '1', 8, 2),
(64, 'item', 'Alternate port (81)', 'Some of our torrents use ports other than the usual HTTP port 80. This may cause problems for some users,\r\nfor instance those behind some firewall or proxy configurations.\r\n\r\nYou can easily solve this by editing the .torrent file yourself with any torrent editor, e.g.\r\n<a href="http://sourceforge.net/projects/burst/" class="altlink">MakeTorrent</a>,\r\nand replacing the announce url torrentbits.org:81 with torrentbits.org:80 or just torrentbits.org.<br>\r\n<br>\r\nEditing the .torrent with Notepad is not recommended. It may look like a text file, but it is in fact\r\na bencoded file. If for some reason you must use a plain text editor, change the announce url to\r\ntorrentbits.org:80, not torrentbits.org. (If you''re thinking about changing the number before the\r\nannounce url instead, you know too much to be reading this.)', '2', 8, 3),
(65, 'item', 'You can try these:', 'Post in the <a class="altlink" href="forums.php">Forums</a>, by all means. You''ll find they\r\nare usually a friendly and helpful place,\r\nprovided you follow a few basic guidelines:\r\n<ul>\r\n<li>Make sure your problem is not really in this FAQ. There''s no point in posting just to be sent\r\nback here.\r\n<li>Before posting read the sticky topics (the ones at the top). Many times new information that\r\nstill hasn''t been incorporated in the FAQ can be found there.</li>\r\n<li>Help us in helping you. Do not just say "it doesn''t work!". Provide details so that we don''t\r\nhave to guess or waste time asking. What client do you use? What''s your OS? What''s your network setup? What''s the exact\r\nerror message you get, if any? What are the torrents you are having problems with? The more\r\nyou tell the easiest it will be for us, and the more probable your post will get a reply.</li>\r\n<li>And needless to say: be polite. Demanding help rarely works, asking for it usually does\r\nthe trick.', '1', 9, 1),
(67, 'item', 'What does "Account parked" means?', 'You can park your account to prevent it from being deleted because of inactivity, for example if you go away on a vacation.\r\nWhen the account has been parked limits are put on the account, for example you cannot use the tracker.', '3', 2, 15);

CREATE TABLE `rules` (
 `id` int(11) NOT NULL auto_increment,
 `title` varchar(255) NOT NULL default '',
 `text` text NOT NULL,
 `public` enum('yes','no') NOT NULL default 'yes',
 `class` int(11) NOT NULL default '0',
 PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

INSERT INTO `rules` (`id`, `title`, `text`, `public`, `class`) VALUES 
(1, 'General Rules - Breaking these rules can and will get you banned!', '[*] Do not defy the moderators expressed wishes!\r\n[*] Duplicate account are not allowed unless express permission has been given by a member of staff.\r\n[*] Do not upload our torrents to other trackers!\r\n[*] Disruptive behaviour in the forums will result in a warning.\r\nYou will only get one warning! After that it''s bye bye Kansas!', 'yes', 0),
(2, 'Downloading rules - By not following these rules you will lose download privileges!', '[*] Access to the newest torrents is conditional on a good ratio!\r\n[*] Low ratios may result in severe consequences, including banning in extreme cases.\r\n[*] Two warnings and you''r out.', 'yes', 0),
(3, 'General Forum Guidelines - Please follow these guidelines or else you might end up with a warning!', '[*] No aggressive behaviour or flaming in the forums.\r\n[*] No trashing of other peoples topics (i.e. SPAM).\r\n[*] No language other than English in the forums.\r\n[*] No systematic foul language (and none at all on titles).\r\n[*] No links to warez or crack sites in the forums.\r\n[*] No requesting or posting of serials, CD keys, passwords or cracks in the forums.\r\n[*] No bumping... (All bumped threads will be deleted.)\r\n[*] No images larger than 800x600, and preferably web-optimised.\r\n[*] No double posting. If you wish to post again, and yours is the last post in the thread please use the EDIT function, instead of posting a double.\r\n[*] Please ensure all questions are posted in the correct section!  (Game questions in the Games section, Apps questions in the Apps section, etc.)\r\n[*] Last, please read the [url=faq.php]FAQ[/url] before asking any questions!', 'yes', 0),
(4, 'Avatar Guidelines - Please try to follow these guidelines', '[*] The allowed formats are .gif, .jpg and .png.\r\n[*] Be considerate. Resize your images to a width of 150 px and a size of no more than 150 KB. (Browsers will rescale them anyway: smaller images will be expanded and will not look good; larger images will just waste bandwidth and CPU cycles.) For now this is just a guideline but it will be automatically enforced in the near future.\r\n[*] Do not use potentially offensive material involving porn, religious material, animal / human cruelty or ideologically charged images. Mods have wide discretion on what is acceptable. If in doubt PM one. ', 'yes', 0),
(5, 'Uploading rules - Torrents violating these rules may be deleted without notice', '[*] All uploads must include a proper NFO.\r\n[*] All files must be in original format (usually 14.3 MB RARs).\r\n[*] Pre-release stuff should be labeled with an *ALPHA* or *BETA* tag.\r\n[*] Make sure not to include any serial numbers, CD keys or similar in the description (you do not need to edit the NFO!).\r\n[*] Make sure your torrents are well-seeded for at least 24 hours.\r\n[*] Do not include the release date in the torrent name.\r\n[*] Stay active! You risk being demoted if you have no active torrents.', 'yes', 0),
(6, 'Moderating Rules - Use your better judgement!', '[*] The most important rule: Use your better judgment!\r\n[*] Don''t be afraid to say NO! (a.k.a. "Helshad''s rule".)\r\n[*] Don''t defy another mod in public, instead send a PM or through IM.\r\n[*] Be tolerant! Give the user(s) a chance to reform.\r\n[*] Don''t act prematurely, let the users make their mistakes and THEN correct them.\r\n[*] Try correcting any "off topics" rather then closing a thread.\r\n[*] Move topics rather than locking them.\r\n[*] Be tolerant when moderating the Chit-chat section (give them some slack).\r\n[*] If you lock a topic, give a brief explanation as to why you''re locking it.\r\n[*] Before you disable a user account, send him/her a PM and if they reply, put them on a 2 week trial.\r\n[*] Don''t disable a user account until he or she has been a member for at least 4 weeks.\r\n[*] Always state a reason (in the user comment box) as to why the user is being banned / warned.', 'yes', 0),
(7, 'Moderating options - What are my privileges as a mod?', '[*] You can delete and edit forum posts.\r\n[*] You can delete and edit torrents.\r\n[*] You can delete and change users avatars.\r\n[*] You can disable user accounts.\r\n[*] You can edit the title of VIP''s.\r\n[*] You can see the complete info of all users.\r\n[*] You can add comments to users (for other mods and admins to read).\r\n[*] You can stop reading now ''cuz you already knew about these options. ;)\r\n[*] Lastly, check out the Staff page (top right corner).', 'yes', 0);

CREATE TABLE `cheaters` (
`id` int(10) unsigned NOT NULL auto_increment,
`added` datetime NOT NULL default '0000-00-00 00:00:00',
`userid` int(10) NOT NULL default '0',
`torrentid` int(10) NOT NULL default '0',
`client` varchar(255) NOT NULL default '',
`rate` varchar(255) NOT NULL default '',
`beforeup` varchar(255) NOT NULL default '',
`upthis` varchar(255) NOT NULL default '',
`timediff` varchar(255) NOT NULL default '',
`userip` varchar(15) NOT NULL default '0',
PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


INSERT INTO `categories` VALUES (1, 'Appz/PC ISO', 'cat_apps.gif', 0, '');
INSERT INTO `categories` VALUES (4, 'Games/PC ISO', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (5, 'Movies/SVCD', 'cat_movies.gif', 0, '');
INSERT INTO `categories` VALUES (6, 'Music', 'cat_music.gif', 0, '');
INSERT INTO `categories` VALUES (7, 'Episodes', 'cat_episodes.gif', 0, '');
INSERT INTO `categories` VALUES (9, 'XXX', 'cat_xxx.gif', 0, '');
INSERT INTO `categories` VALUES (12, 'Games/GBA', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (17, 'Games/PS2', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (23, 'Anime', 'cat_anime.gif', 0, '');
INSERT INTO `categories` VALUES (19, 'Movies/XviD', 'cat_movies.gif', 0, '');
INSERT INTO `categories` VALUES (20, 'Movies/DVD-R', 'cat_movies.gif', 0, '');
INSERT INTO `categories` VALUES (21, 'Games/PC Rips', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (22, 'Appz/misc', 'cat_apps.gif', 0, '');
INSERT INTO `categories` VALUES (24, 'Appz/PDA', 'cat_apps.gif', 0, '');
INSERT INTO `categories` VALUES (25, 'Games/GameCube', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (26, 'Games/PSP', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (27, 'Games/PSX', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (28, 'Games/XBOX', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (29, 'Games/XBOX360', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (30, 'Games/Misc', 'cat_games.gif', 0, '');
INSERT INTO `categories` VALUES (31, 'Movies/HDTV', 'cat_movies.gif', 0, '');
INSERT INTO `categories` VALUES (32, 'Movies/VCD', 'cat_movies.gif', 0, '');
INSERT INTO `categories` VALUES (33, 'TV/HDTV', 'cat_movies.gif', 0, '');
INSERT INTO `categories` VALUES (34, 'Music Video', 'cat_episodes.gif', 0, '');
INSERT INTO `categories` VALUES (35, 'Misc', 'cat_apps.gif', 0, '');
INSERT INTO `categories` VALUES (36, 'Movies/CAM', 'cat_movies.gif', 0, '');

CREATE TABLE `addedrequests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `requestid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`id`),
  KEY `userid` (`userid`),
  KEY `requestid_userid` (`requestid`,`userid`)
) TYPE=MyISAM;

CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `request` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL default '0',
  `cat` int(10) unsigned NOT NULL default '0',
  `filledby` int(10) unsigned NOT NULL default '0',
  `filledurl` varchar(70) default NULL,
  `filled` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`),
  KEY `id_added` (`id`,`added`)
) TYPE=MyISAM;

CREATE TABLE `offers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `name` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `yeah` int(10) unsigned NOT NULL default '0',
  `against` int(10) unsigned NOT NULL default '0',
  `category` int(11) NOT NULL default '0',
  `comments` int(11) NOT NULL default '0',
  `allowed` enum('allowed','pending','denied') NOT NULL default 'pending',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM;
    
CREATE TABLE `offervotes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `offerid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `vote` enum('yeah','against') NOT NULL default 'yeah',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM;

ALTER TABLE `comments` ADD `request` int(11) NOT NULL default '0';
ALTER TABLE `comments` ADD `offer` int(11) NOT NULL default '0';

ALTER TABLE `torrents` ADD `description` varchar(120) NOT NULL default '';

ALTER TABLE `torrents` ADD `anonymous` ENUM( 'yes', 'no' ) DEFAULT 'no' NOT NULL;

CREATE TABLE `languages` (
`id` int(10) unsigned NOT NULL auto_increment,
`uri` varchar(255) NOT NULL default '',
`name` varchar(64) NOT NULL default '',
PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

INSERT INTO `languages` VALUES (1, 'english.lang', 'English');

ALTER TABLE `users` ADD `language` int(10) NOT NULL default '1';