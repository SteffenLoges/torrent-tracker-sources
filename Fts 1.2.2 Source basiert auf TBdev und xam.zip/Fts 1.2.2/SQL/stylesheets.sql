-- MySQL dump 9.10
--
-- Host: localhost    Database: bittorrent
-- ------------------------------------------------------
-- Server version	4.0.18-log

--
-- Dumping data for table `stylesheets`
--

INSERT INTO stylesheets VALUES (1,'default.css','(default)');
INSERT INTO stylesheets VALUES (2,'large.css','Large text');

