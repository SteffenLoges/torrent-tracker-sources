<?
require "include/bittorrent.php";
dbconn();
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  $username = trim($_POST["username"]);
  $password = trim($_POST["password"]);
  if (!$username || !$password)
    stderr(dcterr, dct1);
  $res = mysql_query(

  "SELECT * FROM users WHERE username=" . sqlesc($username) .
  " && passhash=md5(concat(secret,concat(" . sqlesc($password) . ",secret)))") or sqlerr();
  if (mysql_num_rows($res) != 1)
    stderr(dcterr, dct2);
  $arr = mysql_fetch_assoc($res);

  $id = $arr['id'];

  $userwarn = $arr['warned'];
if ($userwarn == 'yes')
stderr(dcterr, dct3);

  $res = mysql_query("DELETE FROM users WHERE id=$id") or sqlerr();
  if (mysql_affected_rows() != 1)
    stderr(dcterr, dct4);
  stderr(dct5, sprintf(dct6,$username));
}
stdhead(dct7);
?>
<h1><?print(dct7);?></h1>
<table border=1 cellspacing=0 cellpadding=5>
<form method=post action=delacct.php>
<tr><td class=rowhead><?=dct8;?></td><td><input size=40 name=username></td></tr>
<tr><td class=rowhead><?=dct9;?></td><td><input type=password size=40 name=password></td></tr>
<tr><td colspan=2><input type=submit class=btn value='<?=dct10;?>'></td></tr>
</form>
</table>
<?
stdfoot();
?>