<?
$dep = true;
if($dep)
header('Location: admin.php');
ob_start();
require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
stdhead("Administration");
if (get_user_class() < UC_MODERATOR)
{
  stdmsg("Excuse...", "Access is not present!!!");
  stdfoot();
  exit;
}
print("<script type=\"text/javascript\" src=blink.js></script>");
begin_frame("..:: Administration ::..");
print("</br>");
print("<table width=100% border=0 cellspacing=0 cellpadding=2><tr><td align=center>\n");

///////////////////// Remove And Edit Options Sys.Admin \\\\\\\\\\\\\\\\\\\\\\\\\\\\

$sure = $_GET['sure'];
if($sure == "yes") {
$delsosadminid = $_GET['delsosadminid'];
$query = "DELETE FROM sysoppanel WHERE id=" .sqlesc($delsosadminid) . " LIMIT 1";
$sql = mysql_query($query);
echo("The option is successfully removed![ <a href='". $_SERVER['PHP_SELF'] . "'>Back</a> ]");
end_frame();
stdfoot();
die();
}
$delsosadminid = $_GET['delsosadminid'];
$name = $_GET['mod'];
if($delsosadminid > 0) {
echo("Only Sys.Admin is able to do it <p>");
if (get_user_class() >= UC_SYSOP) {
echo("You and in the truth wish to remove an option? ($name) ( <strong><a href='". $_SERVER['PHP_SELF'] . "?delsosadminid=$delsosadminid&mod=$name&sure=yes'>Yes!</a></strong> / <strong><a href='". $_SERVER['PHP_SELF'] . "'>No!</a></strong> )");
}
end_frame();
stdfoot();
die();
}

$editsosadmin = $_GET['editsosadmin'];
if($editsosadmin == 1) {
$id = $_GET['id'];
$mod_name = $_GET['mod_name'];
$mod_url = $_GET['mod_url'];
$mod_info = $_GET['mod_info'];
$query = "UPDATE sysoppanel SET
name = '$mod_name',
url = '$mod_url',
info = '$mod_info'
WHERE id=".sqlesc($id);
$sql = mysql_query($query);
if($sql) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td><div align='center'><strong>It is successfully </strong>changed[ <a href='". $_SERVER['PHP_SELF'] . "'>Back</a> ]</div></tr>");
echo("</table>");
}
end_frame();
stdfoot();
die();
}
}
$editsosadminid = $_GET['editsosadminid'];
$name = $_GET['name'];
$url = $_GET['url'];
$info = $_GET['info'];
if($editsosadminid > 0) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<div align='center'><input type='hidden' name='editsosadmin' value='1'>At present you change an option <strong>&quot;$name&quot;</strong></div>");
echo("<br>");
echo("<input type='hidden' name='id' value='$editsosadminid'<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td>Option: </td><td align='right'><input type='text' size=50 name='mod_name' value='$name'></td></tr>");
echo("<tr><td>URL-file: </td><td align='right'><input type='text' size=50 name='mod_url' value='$url'></td></tr>");
echo("<tr><td>Info: </td><td align='right'><input type='text' size=50 name='mod_info' value='$info'></td></tr>");
echo("<tr><td></td><td><div align='right'><input type='Submit' value='Change'></div></td></tr>");
echo("</table></form>");
}
end_frame();
stdfoot();
die();
}
///////////////////// Remove And Edit Options Admin \\\\\\\\\\\\\\\\\\\\\\\\\\\\

$suree = $_GET['suree'];
if($suree == "yes") {
$deladminid = $_GET['deladminid'];
$query = "DELETE FROM adminpanel WHERE id=" .sqlesc($deladminid) . " LIMIT 1";
$sql = mysql_query($query);
echo("The option is successfully removed![ <a href='". $_SERVER['PHP_SELF'] . "'>Back</a> ]");
end_frame();
stdfoot();
die();
}
$deladminid = $_GET['deladminid'];
$nameadmin = $_GET['admin'];
if($deladminid > 0) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("You and in the truth wish to remove an option? ($nameadmin) ( <strong><a href='". $_SERVER['PHP_SELF'] . "?deladminid=$deladminid&admin=$nameadmin&suree=yes'>Yes!</a></strong> / <strong><a href='". $_SERVER['PHP_SELF'] . "'>No!</a></strong> )");
}
end_frame();
stdfoot();
die();
}

$editadmin = $_GET['editadmin'];
if($editadmin == 1) {
$id = $_GET['id'];
$mod_name = $_GET['mod_name'];
$mod_url = $_GET['mod_url'];
$mod_info = $_GET['mod_info'];
$query = "UPDATE adminpanel SET
name = '$mod_name',
url = '$mod_url',
info = '$mod_info'
WHERE id=".sqlesc($id);
$sql = mysql_query($query);
if($sql) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td><div align='center'><strong>It is successfully </strong>changed[ <a href='". $_SERVER['PHP_SELF'] . "'>Back</a> ]</div></tr>");
echo("</table>");
}
end_frame();
stdfoot();
die();
}
}

$editadminid = $_GET['editadminid'];
$name = $_GET['name'];
$url = $_GET['url'];
$info = $_GET['info'];
if($editadminid > 0) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<div align='center'><input type='hidden' name='editadmin' value='1'>At present you change an option <strong>&quot;$name&quot;</strong></div>");
echo("<br>");
echo("<input type='hidden' name='id' value='$editadminid'<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td>Option: </td><td align='right'><input type='text' size=50 name='mod_name' value='$name'></td></tr>");
echo("<tr><td>URL-file: </td><td align='right'><input type='text' size=50 name='mod_url' value='$url'></td></tr>");
echo("<tr><td>Info: </td><td align='right'><input type='text' size=50 name='mod_info' value='$info'></td></tr>");
echo("<tr><td></td><td><div align='right'><input type='Submit' value='Change'></div></td></tr>");
echo("</table></form>");
}
end_frame();
stdfoot();
die();
}

///////////////////// Remove And Edit Options Moderator \\\\\\\\\\\\\\\\\\\\\\\\\\\\

$sureee = $_GET['sureee'];
if($sureee == "yes") {
$delmodid = $_GET['delmodid'];
$query = "DELETE FROM modpanel WHERE id=" .sqlesc($delmodid) . " LIMIT 1";
$sql = mysql_query($query);
echo("The option is successfully removed![ <a href='". $_SERVER['PHP_SELF'] . "'>Back</a> ]");
end_frame();
stdfoot();
die();
}
$delmodid = $_GET['delmodid'];
$namemod = $_GET['mod'];
if($delmodid > 0) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("You and in the truth wish to remove an option? ($namemod) ( <strong><a href='". $_SERVER['PHP_SELF'] . "?delmodid=$delmodid&mod=$namemod&sureee=yes'>Yes!</a></strong> / <strong><a href='". $_SERVER['PHP_SELF'] . "'>No!</a></strong> )");
}
end_frame();
stdfoot();
die();
}

$editmod = $_GET['editmod'];
if($editmod == 1) {
$id = $_GET['id'];
$mod_name = $_GET['mod_name'];
$mod_url = $_GET['mod_url'];
$mod_info = $_GET['mod_info'];
$query = "UPDATE modpanel SET
name = '$mod_name',
url = '$mod_url',
info = '$mod_info'
WHERE id=".sqlesc($id);
$sql = mysql_query($query);
if($sql) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td><div align='center'><strong>It is successfully </strong>changed[ <a href='". $_SERVER['PHP_SELF'] . "'>Back</a> ]</div></tr>");
echo("</table>");
}
end_frame();
stdfoot();
die();
}
}

$editmodid = $_GET['editmodid'];
$name = $_GET['name'];
$url = $_GET['url'];
$info = $_GET['info'];
if($editmodid > 0) {
echo("Only Sys.Admin is able to do it<p>");
if (get_user_class() >= UC_SYSOP) {
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<div align='center'><input type='hidden' name='editmod' value='1'>At present you change an option <strong>&quot;$name&quot;</strong></div>");
echo("<br>");
echo("<input type='hidden' name='id' value='$editmodid'<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td>Option: </td><td align='right'><input type='text' size=50 name='mod_name' value='$name'></td></tr>");
echo("<tr><td>URL-file: </td><td align='right'><input type='text' size=50 name='mod_url' value='$url'></td></tr>");
echo("<tr><td>Info: </td><td align='right'><input type='text' size=50 name='mod_info' value='$info'></td></tr>");
echo("<tr><td></td><td><div align='right'><input type='Submit' value='Change'></div></td></tr>");
echo("</table></form>");
}
end_frame();
stdfoot();
die();
}


///////////////////// Add new options \\\\\\\\\\\\\\\\\\\\\\\\\\\\
$add = $_GET['add'];
if($add == 'true') {
$mod_name = $_GET['mod_name'];
$mod_url = $_GET['mod_url'];
$mod_info = $_GET['mod_info'];
$cppanel = $_GET['cppanel'];
$query = "INSERT INTO $cppanel SET
name = '$mod_name',
url = '$mod_url',
info = '$mod_info'";
$sql = mysql_query($query);
if($sql) {
$success = TRUE;
} else {
$success = FALSE;
}
}
if (get_user_class() >= UC_SYSOP) {
print("<strong>Add new option:</strong>");
print("<br />");
print("<br />");
echo("<form name='form1' method='get' action='" . $_SERVER['PHP_SELF'] . "'>");
echo("<table class=main cellspacing=0 cellpadding=5 width=50%>");
echo("<tr><td>Name: </td><td align='left'><input type='text' size=50 name='mod_name'></td></tr>");
echo("<tr><td>URL-file: </td><td align='left'><input type='text' size=50 name='mod_url'></td></tr>");
echo("<tr><td>Info: </td><td align='left'><input type='text' size=50 name='mod_info'></td></tr>");
echo("<tr><td>Option for: </td><td align='left'><select name='cppanel'><option value='sysoppanel'>Sys.Admins</option><option value='adminpanel'>Admins</option><option value='modpanel'>Moderators</option></select><input type='hidden' name='add' value='true'></td></tr>");
echo("<tr><td></td><td><div align='left'><input value='Add' type='Submit'></div></td></tr>");
echo("</table>");
}
if($success == TRUE) {
header("Location:  " . $_SERVER['PHP_SELF'] . "");
}

echo("<br>");
echo("</form>");

///////////////////// Sys.Admin Only \\\\\\\\\\\\\\\\\\\\\\\\\\\\
if (get_user_class() >= UC_SYSOP) {
print("<center>");
echo("<strong><font color=#FF0000><blink>..:: For Sys.Admin Only  ::..</blink></strong>");
print("<br />");
print("<br />");
print("<table border=1 class=main cellspacing=0 cellpadding=5>");
echo("<td>The name an option and URL:</td><td>Info:</td><td>Change:</td><td>Remove:</td>");
$query = "SELECT * FROM sysoppanel WHERE 1=1";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id = $row['id'];
$name = $row['name'];
$url = $row['url'];
$info = $row['info'];

echo("<tr><td><strong><a href=$url>$name</a></strong></td> <td>$info</td> <td><a href='". $_SERVER['PHP_SELF'] . "?editsosadminid=$id&name=$name&url=$url&info=$info'><div align='center'><img src='$BASEURL/pic/multipage.gif' alt='Change' border='0' class=special /></a></div></td> <td><div align='center'><a href='". $_SERVER['PHP_SELF'] . "?delsosadminid=$id&mod=$name'><img src='$BASEURL/pic/warned2.gif' alt='Remove' border='0' class=special align='center' /></a></div></td></center>");
}
print("</table>");
print("<br />");
print("<br />");
}
///////////////////// Admin Only \\\\\\\\\\\\\\\\\\\\\\\\\\\\
if (get_user_class() >= UC_ADMINISTRATOR) {
print("<center>");
echo("<strong><font color=#FF0000><blink>..:: For Admin Only :..</blink></strong>");
print("<br />");
print("<br />");
print("<table border=1 class=main cellspacing=0 cellpadding=5>");
echo("<td>The name an option and URL:</td><td>Info:</td><td>Change:</td><td>Remove:</td>");
$query = "SELECT * FROM adminpanel WHERE 1=1";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id = $row['id'];
$name = $row['name'];
$url = $row['url'];
$info = $row['info'];

echo("<tr><td><strong><a href=$url>$name</a></strong></td> <td>$info</td> <td><a href='". $_SERVER['PHP_SELF'] . "?editadminid=$id&name=$name&url=$url&info=$info'><div align='center'><img src='$BASEURL/pic/multipage.gif' alt='Change' border='0' class=special /></a></div></td> <td><div align='center'><a href='". $_SERVER['PHP_SELF'] . "?deladminid=$id&admin=$name'><img src='$BASEURL/pic/warned2.gif' alt='Remove' border='0' class=special align='center' /></a></div></td></center>");
}
print("</table>");
print("<br />");
print("<br />");
}
///////////////////// Moderator Only \\\\\\\\\\\\\\\\\\\\\\\\\\\\
print("<center>");
echo("<strong><font color=#FF0000><blink>..:: For Moderator Only  ::..</blink></strong>");
print("<br />");
print("<br />");
print("<table border=1 class=main cellspacing=0 cellpadding=5>");
echo("<td>The name an option and URL:</td><td>Info:</td><td>Change:</td><td>Remove:</td>");
$query = "SELECT * FROM modpanel WHERE 1=1";
$sql = mysql_query($query);
while ($row = mysql_fetch_array($sql)) {
$id = $row['id'];
$name = $row['name'];
$url = $row['url'];
$info = $row['info'];

echo("<tr><td><strong><a href=$url>$name</a></strong></td> <td>$info</td> <td><a href='". $_SERVER['PHP_SELF'] . "?editmodid=$id&name=$name&url=$url&info=$info'><div align='center'><img src='$BASEURL/pic/multipage.gif' alt='Change' border='0' class=special /></a></div></td> <td><div align='center'><a href='". $_SERVER['PHP_SELF'] . "?delmodid=$id&mod=$name'><img src='$BASEURL/pic/warned2.gif' alt='Remove' border='0' class=special align='center' /></a></div></td></tr></center>");
}
print("</table>");

?>
<h2>Server load</h2>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>
<table class=main border=0 width=402><tr><td style='padding: 0px; background-image: url(/pic/loadbarbg.gif); background-repeat: repeat-x'>
<? $percent = min(100, round(exec('ps ax | grep -c apache') / 256 * 100));
if ($percent <= 70) $pic = "loadbargreen.gif";
elseif ($percent <= 90) $pic = "loadbaryellow.gif";
else $pic = "loadbarred.gif";
$width = $percent * 4;
print("<img height=15 width=$width src=\"/pic/$pic\" alt='$percent%'>"); ?>
</td></tr></table>
</td></tr></table>
<?
end_frame();
end_frame();
stdfoot();
?>