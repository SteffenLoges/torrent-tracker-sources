<?

require_once("include/bittorrent.php");

if (!mkglobal("id"))
        die();

$id = 0 + $id;
if (!$id)
        die();

dbconn();

loggedinorreturn();

$res = mysql_query("SELECT * FROM torrents WHERE id = $id");
$row = mysql_fetch_array($res);
if (!$row)
        die();

stdhead(edt1."\"" . $row["name"] . "\"");

if (!isset($CURUSER) || ($CURUSER["id"] != $row["owner"] && get_user_class() < UC_MODERATOR)) {
        print("<h1>".edt2."</h1>\n");
        print("<p>".edt3."</p>\n");
}
else {
        print("<form name=editupload method=post action=takeedit.php enctype=multipart/form-data>\n");
        print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
        if (isset($_GET["returnto"]))
                print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" />\n");
        print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"10\">\n");
        tr(edt4, "<input type=\"text\" name=\"name\" value=\"" . htmlspecialchars($row["name"]) . "\" size=\"80\" />", 1);
        tr(edt5, "<input type =\"text\" name=\"description\" size=\"80\" value=\"" .htmlspecialchars($row["description"]). "\"><br>".edt6, 1);
        tr(edt7, "<input type=radio name=nfoaction value='keep' checked>".edt8."<br>".
        "<input type=radio name=nfoaction value='update'>".edt9.":<br><input type=file name=nfo size=80>", 1);
if ((strpos($row["ori_descr"], "<") === false) || (strpos($row["ori_descr"], "&lt;") !== false))
  $c = "";
else
  $c = " checked";
        print("<tr><td class=rowhead style='padding: 10px'>".edt10."</td><td align=center style='padding: 3px'>");
 textbbcode("editupload","descr","$row[ori_descr]");
        print("</td>\n");

        $s = "<select name=\"type\">\n";

        $cats = genrelist();
        foreach ($cats as $subrow) {
                $s .= "<option value=\"" . $subrow["id"] . "\"";
                if ($subrow["id"] == $row["category"])
                        $s .= " selected=\"selected\"";
                $s .= ">" . htmlspecialchars($subrow["name"]) . "</option>\n";
        }

        $s .= "</select>\n";
        tr(edt11, $s, 1);
        tr(edt12, "<input type=\"checkbox\" name=\"visible\"" . (($row["visible"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" /> ".edt13, 1);
        tr(edt14, "<input type=\"checkbox\" name=\"anonymous\"" . (($row["anonymous"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" />  ".edt15, 1);

        if ($CURUSER["admin"] == "yes")
                tr(edt16, "<input type=\"checkbox\" name=\"banned\"" . (($row["banned"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" /> Banned", 1);

        print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value='".edt17."' style='height: 25px; width: 100px'> <input type=reset value='Revert changes' style='height: 25px; width: 100px'></td></tr>\n");
        print("</table>\n");
        print("</form>\n");
        print("<p>\n");
        print("<form method=\"post\" action=\"delete.php\">\n");
  print("<table border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");
  print("<tr><td class=embedded style='background-color: #F5F4EA;padding-bottom: 5px' colspan=\"2\">".edt18);
  print("<td><input name=\"reasontype\" type=\"radio\" value=\"1\">\n".edt19);
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"2\">&nbsp;".edt20."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\"></td></tr>\n");
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"3\">&nbsp;".edt21."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\"></td></tr>\n");
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"4\">&nbsp;".edt22."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\">(req)</td></tr>");
  print("<tr><td><input name=\"reasontype\" type=\"radio\" value=\"5\" checked>&nbsp;".edt23."</td><td><input type=\"text\" size=\"40\" name=\"reason[]\">(req)</td></tr>\n");
        print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
        if (isset($_GET["returnto"]))
                print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" />\n");
  print("<td colspan=\"2\" align=\"center\"><input type=submit value='".edt24."' style='height: 25px'></td></tr>\n");
  print("</table>");
        print("</form>\n");
        print("</p>\n");
}

stdfoot();

?>