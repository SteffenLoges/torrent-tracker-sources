<?

require_once("include/bittorrent.php");

dbconn(false);



loggedinorreturn();

//-------- Action: Delete subscription

if ($action == "deletesubscription")
{
$topicid = $_GET["topicid"];
if (!is_valid_id($topicid) || get_user_class() < UC_USER)
die;

$sure = $_GET["sure"];

if (!$sure)
{
stderr("Delete subscription", "Sanity check: You are about to delete your subscription to this thread. Click\n" .
"<a href=?action=deletesubscription&topicid=$topicid&sure=1>here</a> if you are sure.");
}

//mysql_query("DELETE FROM subscriptions WHERE topicid='$topicid'") or sqlerr(__FILE__, __LINE__);
mysql_query("DELETE FROM subscriptions WHERE userid=$CURUSER[id] AND topicid =$topicid") or sqlerr(__FILE__, __LINE__);
header("Location: $DEFAULTBASEURL/subscriptions.php");

die;
}

if (!$CURUSER){
print "<div align='center'><br><br><table width='500' height='200' border='0' summary=''><tr><th height='30' align='center' valign='middle'>";
print "<h2><div align='center'>Sorry, This is a members only site.</div></h2></th></tr><tr><td valign='top'><div align='center'><br><br>";
print "You are not loggen in.<br><a href='login.php'>log in</a> - <a href='signup.php'>sign up</a></div></td></tr></table><br></div>";
}

if ($CURUSER){
if (!isset($_GET[user]))
$user = $CURUSER[id];
else
$user = $_GET[user];


$res = mysql_query("SELECT username FROM users WHERE id = $user") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_array($res);

stdhead("Subscribed Forums for " . $arr[username]);
print("<br>");
echo("<h4>Subscribed Forums for $subject</h4><p align=center>to be notified via PM when there is a new post, go to your <a class=altlink href=my.php>profile</a> and set <b><i>PM on Subscriptions</i></b> to yes</p>\n");

//-------- View subscribed forums

$userid = $CURUSER['id'];
$maxresults = 200;

$res = mysql_query("SELECT topics.id, topics.userid, topics.forumid, topics.subject, topics.lastpost, subscriptions.topicid FROM topics, subscriptions WHERE topics.id = subscriptions.topicid AND subscriptions.userid=$userid ORDER BY lastpost") or sqlerr(__FILE__, __LINE__);
print ("<h1>Subscribed Forums for <a href=userdetails.php?id=$user><b>$arr[username]<b></a></h2>");
$n = 0;
$uc = get_user_class();
while ($arr = mysql_fetch_assoc($res))
{
$topicid = $arr['id'];
$forumid = $arr['forumid'];
$posternumber = $arr['userid'];
//------ Get author
$res2 = mysql_query("SELECT username FROM users WHERE id=$posternumber") or sqlerr(__FILE__, __LINE__);
$arr2 = mysql_fetch_assoc($res2);
$postername = "<a href=userdetails.php?id=$posternumber><b>$arr2[username]</b></a>";
$r = mysql_query("SELECT name, minclassread FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_assoc($r);
if ($uc < $a['minclassread'])
continue;
++$n;
if ($n > $maxresults)
break;
$forumname = $a['name'];

if ($n == 1)
{
print("<table border=1 cellspacing=0 cellpadding=5>\n");
print("<tr><td class=colhead align=left>Topic</td><td class=colhead align=left>Forum</td><td class=colhead align=left>Delete</td></tr>\n");
}
print("<tr><td class=kleer align=left><table class=clear border=0 cellspacing=3 cellpadding=3><tr><td class=kleer>" .
"<img src=pic/unlockednew.gif style='margin-right: 5px'></td><td class=kleer>" .
"<a href=forums.php?action=viewtopic&topicid=$topicid&page=last#last><b>" . htmlspecialchars($arr["subject"]) .
"</b></a><br><font style=\"color: silver; font: xx-small\">Started by - $postername </font></td></tr></table>
</td><td class=kleer align=left><a href=forums.php?action=viewforum&forumid=$forumid><b>$forumname</b></a></td>
<td class=kleer align=center><a href=?action=deletesubscription&topicid=$topicid>un-subscribe</a></td></tr>\n");
}
if ($n > 0)
{
print("</table>\n");
if ($n > $maxresults)
print("<p>More than $maxresults items found, displaying first $maxresults.</p>\n");
}
else
print("<b>Nothing found</b>");
stdfoot();
die;
}
stdfoot();
hit_end();
?> 
