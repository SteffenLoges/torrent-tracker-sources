<?

require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();
parked();
if ($usergroups['canup'] == 'no')
{
  print_ug();
}
stdhead("Upload");


if (strlen($CURUSER['passkey']) != 32) {

$CURUSER['passkey'] = md5($CURUSER['username'].get_date_time().$CURUSER['passhash']);

mysql_query("UPDATE users SET passkey='$CURUSER[passkey]' WHERE id=$CURUSER[id]");

}

?>
<div align=Center>
<form name=upload enctype="multipart/form-data" action="takeupload.php" method="post">
<input type="hidden" name="MAX_FILE_SIZE" value="<?=$max_torrent_size?>" />
<p>If torrent is Multi-tracker/DHT torrent and/or includes other crap, tracker will <b>remove</b> that</p>
<p>Your announce url is <b><?= $announce_urls[0] ?></b></p>
<table border="1" cellspacing="0" cellpadding="5">
<?

tr("Torrent file", "<input type=file name=file size=80>\n", 1);
tr("Torrent name", "<input type=\"text\" name=\"name\" size=\"80\" /><br />(Taken from filename if not specified. <b>Please use descriptive names.</b>)\n", 1);
tr("Small Description", "<input type=\"text\" name=\"description\" size=\"80\" /><b></b><br>Small Description for the uploaded file (Example: A good movie!!!)<br>This Description is shown in Browse under the Torrentname.", 1);
tr("NFO file", "<input type=file name=nfo size=80><br>(<b>Required.</b> Can only be viewed by power users.)\n", 1);
print("</td></tr>\n");

print("<tr><td class=rowhead style='padding: 3px'>Description</td><td>");
textbbcode("upload","descr",($quote?(("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars(unesc($arr["body"]))."[/quote]")):""));
print("</td></tr>\n");

$s = "<select name=\"type\">\n<option value=\"0\">(choose one)</option>\n";

$cats = genrelist();
foreach ($cats as $row)
        $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";

$s .= "</select>\n";
tr("Type", $s, 1);

tr("Show uploader", "<input type=checkbox name=uplver value=yes>Don't show my username in 'Uploaded By' field in browse.", 1);

?>
<tr><td align="center" colspan="2"><input type="submit" class=btn value="Upload" /></td></tr>
</table>
</form>
<?

stdfoot();

?>