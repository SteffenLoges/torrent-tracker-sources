ssmItems[0]=[l_sidemenu] //create header
ssmItems[1]=[l_homepage, baseurl, ""]
ssmItems[2]=[l_forums, baseurl + "/forums.php", ""]
ssmItems[3]=[l_browse, baseurl + "/browse.php",""]		
ssmItems[4]=[l_uploadtorrent, baseurl + "/upload.php", "_new"]
ssmItems[5]=[l_ucphome, baseurl + "/usercp.php", ""]		
ssmItems[6]=[l_top10, baseurl + "/topten.php", ""]
ssmItems[7]=[l_helprules, baseurl + "/rules.php", ""]
ssmItems[8]=[l_helpfaq, baseurl + "/faq.php", ""]
ssmItems[9]=[l_helpusefulllinks, baseurl + "/links.php", ""]
ssmItems[10]=[l_staffteam, baseurl + "/staff.php", ""]
ssmItems[11]=[l_staffcontact, baseurl + "/contactstaff.php", ""]
ssmItems[12]=[l_extramenu, "", ""] //create header

ssmItems[13]=[""+ l_extrainvite +" ("+ invites +")", baseurl + "/invite.php?id="+ userid, "", 2, "yes"] //create two column row
ssmItems[14]=[""+ l_extrabonus +" ("+ bonus +")", baseurl + "/mybonus.php", "",2]
ssmItems[15]=[""+ l_ucppm +"", baseurl + "/messages.php", "",2]
ssmItems[16]=[""+ l_extrafriends +"", baseurl + "/friends.php", "",2]
ssmItems[17]=[""+ l_extramembers +"", baseurl + "/users.php", "",2]
ssmItems[18]=[""+ l_bookmarks +"", baseurl + "/bookmarks.php", "",2]
ssmItems[19]=[""+ l_reseeds +"", baseurl + "/myreseed.php", "",2]
buildMenu();