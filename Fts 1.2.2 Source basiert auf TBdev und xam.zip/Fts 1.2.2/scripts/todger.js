function enabledel(){
document.deluser.submit.disabled=document.deluser.submit.checked;
alert (l_deleteusersure);
}
function disabledel(){
document.deluser.submit.disabled=!document.deluser.submit.checked;
}