var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return l_uncheckall; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return l_checkall; }
}

function SetSize(obj, x_size) {
      if (obj.offsetWidth > x_size) {
      obj.style.width = x_size;
  };
}

function SmileIT(smile,form,text){
	document.forms[form].elements[text].value = document.forms[form].elements[text].value+" "+smile+" ";
	document.forms[form].elements[text].focus();
	};
function log_out()
{
	ht = document.getElementsByTagName("html");
	ht[0].style.filter = "progid:DXImageTransform.Microsoft.BasicImage(grayscale=1)";
	if (confirm(l_logout))
	{
		return true;
	}
	else
	{
		ht[0].style.filter = "";
		return false;
	}
}
function goback(to)
{
history.back(to)
}