ssmItems[0]=[l_sidemenu] //create header
ssmItems[1]=[l_homepage, baseurl, ""]
ssmItems[2]=[l_login, baseurl + "/login.php",""]
ssmItems[3]=[l_register, baseurl + "/signup.php", ""]

ssmItems[4]=[l_recover1, "", ""] //create header
ssmItems[5]=[l_recover2, baseurl + "/recover.php", "", 1, "no"] //create two column row
ssmItems[6]=[l_recover3, baseurl + "/recoverhint.php", "",1]

ssmItems[7]=[l_needhelp, "", ""] //create header
ssmItems[8]=[l_helpfaq, baseurl + "/faq.php", "", 1, "no"] //create two column row
ssmItems[9]=[l_helprules, baseurl + "/rules.php", "",1]
buildMenu();