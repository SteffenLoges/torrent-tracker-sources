<?php

require "include/bittorrent.php";
dbconn();
if($usergroups['canchat'] == 'no')
print_ug();
stdhead("Chat");
begin_main_frame();
begin_frame("IRC");

$nick = ($CURUSER ? $CURUSER["username"] : ("Guest" . rand(1000, 9999)));
$ircNick = $CURUSER['username'] . "";


?>

<applet codebase="/chat/" code="IRCApplet.class" archive="irc.jar,pixx.jar" width=640 height=400>
<param name="CABINETS" value="irc.cab,securedirc.cab,pixx.cab">
<param name="nick" value="<? echo $ircNick; ?>"/>
<param name="name" value="<? echo $SITENAME;?> User">
<param name="host" value="server.net">
<param name="gui" value="pixx">
       <param name="command1" value="/join #mytracker">
       <param name="authorizedjoinlist" value="">
       <param name="pixx:color0" value="ECE9D8">
       <param name="pixx:color1" value="004E98">
       <param name="pixx:color2" value="F5F4EA">
       <param name="pixx:color3" value="000000">
       <param name="pixx:color4" value="000000">
       <param name="pixx:color5" value="000000">
       <param name="pixx:color6" value="000000">
       <param name="pixx:color7" value="000000">
       <param name="pixx:color8" value="000000">
       <param name="pixx:color9" value="000000">
       <param name="pixx:color10" value="000000">
       <param name="pixx:color11" value="000000">
       <param name="pixx:color12" value="000000">
       <param name="pixx:color13" value="000000">
       <param name="pixx:color14" value="000000">
       <param name="pixx:color15" value="000000">
       <param name="pixx:nickfield" value="true">
       <param name="pixx:styleselector" value="true">
       <param name="pixx:setfontonstyle" value="true">
       <param name="style:bitmapsmileys" value="true">
       <param name="style:smiley1" value=":) img/sourire.gif">
       <param name="style:smiley2" value=":-) img/sourire.gif">
       <param name="style:smiley3" value=":-D img/content.gif">
       <param name="style:smiley4" value=":d img/content.gif">
       <param name="style:smiley5" value=":-O img/OH-2.gif">
       <param name="style:smiley6" value=":o img/OH-1.gif">
       <param name="style:smiley7" value=":-P img/langue.gif">
       <param name="style:smiley8" value=":p img/langue.gif">
       <param name="style:smiley9" value=";-) img/clin-oeuil.gif">
       <param name="style:smiley10" value=";) img/clin-oeuil.gif">
       <param name="style:smiley11" value=":-( img/triste.gif">
       <param name="style:smiley12" value=":( img/triste.gif">
       <param name="style:smiley13" value=":-| img/OH-3.gif">
       <param name="style:smiley14" value=":| img/OH-3.gif">
       <param name="style:smiley15" value=":'( img/pleure.gif">
       <param name="style:smiley16" value=":$ img/rouge.gif">
       <param name="style:smiley17" value=":-$ img/rouge.gif">
       <param name="style:smiley18" value="(H) img/cool.gif">
       <param name="style:smiley19" value="(h) img/cool.gif">
       <param name="style:smiley20" value=":-@ img/enerve1.gif">
       <param name="style:smiley21" value=":@ img/enerve2.gif">
       <param name="style:smiley22" value=":-S img/roll-eyes.gif">
       <param name="style:smiley23" value=":s img/roll-eyes.gif">
</applet>
<?

end_frame();
end_main_frame();
stdfoot();

?>