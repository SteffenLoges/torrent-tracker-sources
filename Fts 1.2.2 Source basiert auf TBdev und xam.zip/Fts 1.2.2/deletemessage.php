<?
  require "include/bittorrent.php";
  $id = $_GET["id"];
  if (!is_numeric($id) || $id < 1 || floor($id) != $id)
    die;

  $type = $_GET["type"];

  dbconn(false);
  loggedinorreturn();
  if ($type == 'in')
  {
  	// make sure message is in CURUSER's Inbox
	  $res = mysql_query("SELECT receiver, location FROM messages WHERE id=" . sqlesc($id)) or die("barf");
	  $arr = mysql_fetch_array($res) or die(dms1);
	  if ($arr["receiver"] != $CURUSER["id"])
	    die(dms2);
    if ($arr["location"] == 'in')
	  	mysql_query("DELETE FROM messages WHERE id=" . sqlesc($id)) or die(dms3);
    else if ($arr["location"] == 'both')
			mysql_query("UPDATE messages SET location = 'out' WHERE id=" . sqlesc($id)) or die(dms4);
    else
    	die(dms5);
  }
	elseif ($type == 'out')
  {
   	// make sure message is in CURUSER's Sentbox
	  $res = mysql_query("SELECT sender, location FROM messages WHERE id=" . sqlesc($id)) or die("barf");
	  $arr = mysql_fetch_array($res) or die(dms1);
	  if ($arr["sender"] != $CURUSER["id"])
	    die(dms2);
    if ($arr["location"] == 'out')
	  	mysql_query("DELETE FROM messages WHERE id=" . sqlesc($id)) or die(dms3);
    else if ($arr["location"] == 'both')
			mysql_query("UPDATE messages SET location = 'in' WHERE id=" . sqlesc($id)) or die(dms4);
    else
    	die(dms6);
  }
  else
  	die(dms7);
  header("Location: $BASEURL/inbox.php".($type == 'out'?"?out=1":""));
?>