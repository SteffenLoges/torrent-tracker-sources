<?
$act = $_GET['act'];
include('include/bittorrent.php');
dbconn(false);
if($usergroups['canstaffpanel'] == 'no')
print_ug();
if(get_user_class() <= UC_UPLOADER) {
stdhead();
die(adminsmall);
stdfoot();
}
if(file_exists('admin/'.$act.'.php')) {
require_once("include/class.ip2country.php");
include("include/secrets.php");
include('admin/'.$act.'.php');
}
elseif(empty($act)) {
?>
<style>
table.stats
{text-align: center;
font-family: Verdana, Geneva, Arial, Helvetica, sans-serif ;
font-weight: normal;
font-size: 11px;
color: #fff;
width: 100%;
background-color: #666;
border: 0px;
border-collapse: collapse;
border-spacing: 0px;}

table.stats td
{background-color: #CCC;
color: #000;
text-align: left;
border: 1px #fff solid;}

table.stats td:hover {
text-transform: uppercase;
background-color: #ec1308;
color: #fff;
}
table.stats td:hover a {
text-transform: uppercase;
color: #fff;
}

table.stats td a.w {
color: #fff;
}

table.stats td.hed
{background-color: #666;
color: #fff;
padding: 4px;
text-align: left;
border-bottom: 2px #fff solid;
font-size: 12px;
font-weight: bold;}
</style>
<?
stdhead();
print("<table class=stats border=1 cellspacing=0 cellpadding=5><tr>
<td class='hed' colspan='4'>Administration panel");
if(get_user_class() >= UC_ADMINISTRATOR) {
print("{ <a href='admin.php?act=add' class=w>".adminadd."</a> }</td>
</tr>");
}else
print('</td></tr>');
print("".
"<td class=tabletitle align=left>".adminname."</td>".
"<td class=tabletitle align=left>".adminurl."</td>".
"<td class=tabletitle align=left>".admininfo."</td>".
"<td class=tabletitle align=left>".admindelete."</td>".
"</tr>");
print("");
$class = $CURUSER["class"];
$q = mysql_query("SELECT * FROM sysoppanel WHERE min_class <= '$class' ORDER BY url") or sqlerr(__FILE__,__LINE__);
$total = mysql_query("SELECT COUNT(*) FROM sysoppanel WHERE min_class <= '$class'") or sqlerr(__FILE__,__LINE__);
$total2 = mysql_query("SELECT COUNT(*) FROM sysoppanel") or
 sqlerr(__FILE__,__LINE__);
while ($sys = mysql_fetch_array($q))
{
$id = $sys['id'];
$name = $sys['name'];
$url = $sys['url'];
$info = $sys['info'];
print('<tr><td class=tabletitle align=left>'.$name.'</td><td class=tabletitle align=left><a href="'.$url.'">'.adminclh.'</a></td><td class=tabletitle align=left>'.$info.'</td><td class=tabletitle align=left><a href=admin.php?act=del&id='.$id.'>'.admindelete.'</a></td></tr>');

}
print('</table>'); ?>

<?
echo (admintotal.":" . mysql_result($total,0)."(total: ".mysql_result($total2,0).")<BR>".adminworry);
stdfoot();
die;
}elseif($act == 'add') {
stdhead();
?>
<form method=post action=admin.php?act=takeadd>
<?print(admintname);?>: <input type='text' id='specialboxes' name='name' value='' /><BR>
<?print(admindesc);?>: <input type='text' id='specialboxes' name='desc' value='' /><BR>
<?print(adminmin);?>: <input type='text' id='specialboxes' name='min' value='' /><BR>
<input type='submit' name='save' class='btn' value="<?print(adminonce);?>">
</form>
<?
stdfoot();
}elseif($act == 'takeadd') {
$name = $_POST['name'];
$url = 'admin.php?act='.$name.'';
$desc = $_POST['desc'];
$min = $_POST['min'];
//echo $name.' '.$url.' '.$desc;
$que = mysql_query("INSERT INTO sysoppanel(name,url,info,min_class) VALUES ('$name','$url','$desc','$min')");
if(!$que) sqlerr(__FILE__,__LINE__);
else header('Location: admin.php');
}


elseif($act = 'del') {
stdhead();
$id = $_GET['id'];
echo(onlysys);
if (get_user_class() >= UC_SYSOP) {
$s = $_GET['s'];

if($s == 'yes') {
$query = "DELETE FROM sysoppanel WHERE id=" .sqlesc($id) . " LIMIT 1";
$sql = mysql_query($query);
print(adminqok);
}else{
echo adminays.'<a href="admin.php?act=del&s=yes&id='.$id.'">Y</a>
';}
}

}elseif($act='a') echo 'a'; else
die(admininv);
?>