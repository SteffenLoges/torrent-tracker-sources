<?
ob_start();
require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
if($usergroups['cansettingspanel'] == 'no')
print_ug();
$action = isset($_POST['action']) ? htmlspecialchars($_POST['action']) : (isset($_GET['action']) ? htmlspecialchars($_GET['action']) : '');
if ($action == 'trackerinfo') {
stdhead();
	$phpversion = phpversion();
	$mysqlversion = get_mysql_version();
	$serverload = get_server_load();
	$totalusers = get_count('totalusers', 'users', 'WHERE status=\'confirmed\'');
	$timecut = time() - 86400;
	$newuserstoday = get_count('totalnewusers', 'users', 'WHERE UNIX_TIMESTAMP(added) > '.sqlesc($timecut));
	$pendingusers = get_count('pendingusers', 'users', 'WHERE status = \'pending\'');
	$todaycomments = get_count('todaycomments', 'comments', 'WHERE UNIX_TIMESTAMP(added) > '.sqlesc($timecut));
	$gd2support = (extension_loaded('gd') ? '<font color=green>Enabled</font>' : '<font color=red>Disabled</font>');
	$sessionsupport = (function_exists('session_save_path') ? '<font color=green>Enabled</font>' : '<font color=red>Disabled</font>');
	$todayvisits = get_count('todayvisits', 'users', 'WHERE UNIX_TIMESTAMP(last_access) > '.sqlesc($timecut));

	echo make_style();
	$str = '
	<table width=100%>
  <tr>
    <td class="none"><div align="left"><b>PHP Version</b></div></td>
    <td class="none"><div align="left">'.$phpversion.'</div></td>
    <td class="none"><div align="left"><b>Total Users</b></div></td>
    <td class="none"><div align="left">'.$totalusers.'</div></td>
  </tr>
  <tr>
    <td class="none"><div align="left"><b>MYSQL Version</b></div></td>
    <td class="none"><div align="left">'.$mysqlversion.'</div></td>
    <td class="none"><div align="left"><b>New Users Today</b></div></td>
    <td class="none"><div align="left">'.$newuserstoday.'</div></td>
  </tr>
  <tr>
    <td class="none"><div align="left"><b>GD2 Support</b></div></td>
    <td class="none"><div align="left">'.$gd2support.'</div></td>
    <td class="none"><div align="left"><b>Unconfirmed Users</b></div></td>
    <td class="none"><div align="left">'.$pendingusers.'</div></td>
  </tr>
  <tr>
    <td class="none"><div align="left"><b>Server Load</b></div></td>
    <td class="none"><div align="left">'.$serverload.'</div></td>
    <td class="none"><div align="left"><b>New Comments Today</b></div></td>
    <td class="none"><div align="left">'.$todaycomments.'</div></td>
  </tr>
   <tr>
    <td class="none"><div align="left"><b>Session Support</b></div></td>
    <td class="none"><div align="left">'.$sessionsupport.'</div></td>
    <td class="none"><div align="left"><b>Active Users Today</b></div></td>
    <td class="none"><div align="left">'.$todayvisits.'</div></td>
  </tr>
</table>';
	
	echo make_div($str);
	die;
stdfoot();
}
elseif ($action == 'settingsinfo') {
stdhead();
if (get_user_class() < UC_SYSOP)
{
  stdmsg("Excuse...", "Access is not present!!!");
  
  exit;
}
$locksetinf = false;
if ($locksetinf)
{
  stdmsg("Excuse...", "Settings info is off by core");
  
  exit;
}
echo make_style();
$text = '<font color=green>Main Settings</font>';
ReadConfig('MAIN');
$text .= '<BR>Tracker Online: '.$MAIN['site_online'].'';
$text .= '<BR>Base Url: '.$MAIN['baseurl'].'';
function ConvertSize($fs)
{
     if ($fs >= 1073741824)
      $fs = round($fs / 1073741824 * 100) / 100 . " Gb";
     elseif ($fs >= 1048576)
      $fs = round($fs / 1048576 * 100) / 100 . " Mb";
     elseif ($fs >= 1024)
      $fs = round($fs / 1024 * 100) / 100 . " Kb";
     else
      $fs = $fs . " b";
     return $fs;
} 
$text .= '<BR>Max Torrent size: '.ConvertSize($MAIN['maxtorentsize']).'('.$MAIN['maxtorentsize'].'B)';
$text .= '<BR>Announce Interval: '.$MAIN['annint'].'';
$text .= '<BR>Signup Timeout: '.$MAIN['signt'].'';
$text .= '<BR>Max Dead Torrent Time: '.$MAIN['max_dead_torrent_time'].'';
$text .= '<BR>Max Users: '.$MAIN['max_users'].'';
$text .= '<BR>Torrent Dir: '.$MAIN['torrent_dir'].'';
$text .= '<BR>Announce url: '.$MAIN['announce_url'].'';
$text .= '<BR>Peer limit: '.$MAIN['peerlimit'].'';
$text .= '<BR>Tracker Mail: '.$MAIN['mail'].'';
$text .= '<BR>Torrent Name: '.$MAIN['name'].'';
$text .= '<BR>Autoclean Interval: '.$MAIN['acv'].'';
$text .= '<BR>Pic Base Url: '.$MAIN['picbu'].'';
$text .= '<BR>IMG DIR: '.$MAIN['imgdir'].'';
echo make_div($text);
stdfoot();
die;
}
elseif($action == 'avtemp') {
stdhead();
$template_dirs =  dir_list('templates');
$dirlist = '';
if (empty($template_dirs))
		$dirlist .= '<option value="">There is no template</option>';
	else {
		foreach ($template_dirs as $dir)
			$dirlist .= ''.$dir.'<BR>';
	}
echo $dirlist;
$total = count($template_dirs);
print('Total templates: '.$total);
stdfoot();
}

if (get_user_class() < UC_SYSOP)
{
  stdmsg("Excuse...", "Access is not present!!!");
  stdfoot();
  exit;
}
function make_style () {
	$style = '<style type="text/css">
	.curlycontainer{
	border: 1px solid #b8b8b8;
	margin-bottom: 1em;

	}
	.curlycontainer .innerdiv{
	background: transparent url(../pic/brcorner.gif) bottom right no-repeat;
	position: relative;
	left: 2px;
	top: 2px;
	padding: 1px 4px 15px 5px;
	}
	</style>';
	return $style;
}

function make_div ($text='') {
	$div = '<div class="curlycontainer">
		<div class="innerdiv">'.$text.'</div></div>';
	return $div;
}
function get_count ($name, $where = '', $extra = '') {
	$res = sql_query('SELECT COUNT(*) as '.$name.' FROM '.$where.' '.($extra ? $extra : ''));
	list($info[$name]) = mysql_fetch_array($res);
	return $info[$name];
}

function get_server_load()
{	
	if(strtolower(substr(PHP_OS, 0, 3)) === 'win')
	{
		return '<font color=red>Unknown</font>';
	}
	elseif(@file_exists("/proc/loadavg"))
	{
		$load = @file_get_contents("/proc/loadavg");
		$serverload = explode(" ", $load);
		$serverload[0] = round($serverload[0], 4);
		if(!$serverload)
		{
			$load = @exec("uptime");
			$load = split("load averages?: ", $load);
			$serverload = explode(",", $load[1]);
		}
	}
	else
	{
		$load = @exec("uptime");
		$load = split("load averages?: ", $load);
		$serverload = explode(",", $load[1]);
	}
	$returnload = trim($serverload[0]);
	if(!$returnload)
	{
		$returnload = '<font color=red>Unknown</font>';
	}
	return $returnload;
}

function get_mysql_version(){		
	$query = sql_query("SELECT VERSION() as version");
	$ver = mysql_fetch_array($query);
	if($ver['version'])
	{
		$version = explode(".", $ver['version'], 3);
		$version = intval($version[0]).".".intval($version[1]).".".intval($version[2]);
	}
	return $version;
}
function settingsmenu ($selected = "") {
	global $BASEURL;
	print ("<table border=1 cellspacing=0 cellpadding=10 width=100% align=center><tr><td class=text align=left>");
	
	print ("<div class=\"shadetabs\"><ul>");
	print ("<li" . ($selected == "mainsettings" ? " class=selected" : "") . "><a href=\"settings.php?action=mainsettings\">Main Settings</a></li>");
print ("<li" . ($selected == "themesettings" ? " class=selected" : "") . "><a href=\"settings.php?action=themesettings\">Theme Settings</a></li>");
print ("<li" . ($selected == "modssettings" ? " class=selected" : "") . "><a href=\"settings.php?action=modssettings\">Extra-mods Settings</a></li>");
	
	print ("</ul></div>");
	print ("</td></tr></table>");
	
}
 if (empty($action)) {stdhead();
settingsmenu();?>
<head>
<script type="text/javascript" src="scripts/ajaxtabs.js">

/***********************************************
* Ajax Tabs Content script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>
</head>
<ul id="maintab" class="shadetabs">
<li class="selected"><a href="#default" rel="ajaxcontentarea">Home</a></li>
<li><a href="settings.php?action=trackerinfo" rel="ajaxcontentarea">Tracker Info</a></li>
<li><a href="settings.php?action=settingsinfo" rel="ajaxcontentarea">Settings Info</a></li>
<li><a href="settings.php?action=avtemp" rel="ajaxcontentarea">Av. Templates</a></li>

</ul>

<div id="ajaxcontentarea" class="contentstyle">
<p>Welcome to the Administration Pannel where you can make various settings to your copy of FTS.</p>
</div>
<script type="text/javascript">
//Start Ajax tabs script for UL with id="maintab" Separate multiple ids each with a comma.
startajaxtabs("maintab")
</script>
<?

}elseif ($action == 'savesettings_m'){
	GetVar(array('site_online','rcl','baseurl','maxtorentsize','annint','signt','max_dead_torrent_time','max_users','torrent_dir','announce_url','peerlimit','mail','name','acv','picbu','imgdir'));
	$MAIN['site_online'] = $site_online;
$MAIN['rcl'] = $rcl;
$MAIN['baseurl'] = $baseurl;
$MAIN['maxtorentsize'] = $maxtorentsize;
$MAIN['annint'] = $annint;
$MAIN['signt'] = $signt;
$MAIN['max_dead_torrent_time'] = $max_dead_torrent_time;
$MAIN['max_users'] = $max_users;
$MAIN['torrent_dir'] = $torrent_dir;
$MAIN['announce_url'] = $announce_url;
$MAIN['peerlimit'] = $peerlimit;
$MAIN['mail'] = $mail;
$MAIN['name'] = $name;
$MAIN['acv'] = $acv;
$MAIN['picbu'] = $picbu;
$MAIN['imgdir'] = $imgdir;

	WriteConfig('MAIN', $MAIN);
	$actiontime = date("F j, Y, g:i a"); 
	write_log("Tracker MAIN settings updated by $CURUSER[username]. $actiontime");
	redirect("settings.php?action=mainsettings","Settings saved, you will now be redirected.");
}elseif ($action == 'savesettings_mds'){
	GetVar(array('iptc'));
	$MODS['iptc'] = $iptc;

	WriteConfig('MODS', $MODS);
	$actiontime = date("F j, Y, g:i a"); 
	write_log("Tracker MODS settings updated by $CURUSER[username]. $actiontime");
	redirect("settings.php?action=modssettings","Settings saved, you will now be redirected.");

}elseif ($action == 'mainsettings') {

	stdhead("Website Settings".S_VERSION." - Main Settings");
	settingsmenu("mainsettings");
print('<BR><table border="1">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_m'>");
	
	tr("Tracker Online? ", "yes <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "no" ? " checked" : "") . " value='no'> <br />Want to turn off your Tracker while performing updates or other types of maintenance?<br />\n", 1);
tr("Disable Right Click ", "yes <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "no" ? " checked" : "") . " value='no'> <br /> Do not allow users to right click<br />\n", 1);

	
	tr("Site Base Url ","<input type='text' id='specialboxes' name=baseurl value='".($MAIN["baseurl"] ? $MAIN["baseurl"] : "??" )."'> This url is verry important.\n", 1);

tr("Max Torrent Size ","<input type='text' id='specialboxes' name=maxtorentsize value='".($MAIN["maxtorentsize"] ? $MAIN["maxtorentsize"] : "" )."'> Recomended: 1000000.\n", 1);

tr("Announcee Interval ","<input type='text' id='specialboxes' name=annint value='".($MAIN["annint"] ? $MAIN["annint"] : "" )."'> Recomended: 60 * 60.\n", 1);

tr("Signup Timeout ","<input type='text' id='specialboxes' name=signt value='".($MAIN["signt"] ? $MAIN["signt"] : "" )."'> Recomended: 86400 * 3.\n", 1);

tr("Max torrent dead time ","<input type='text' id='specialboxes' name=max_dead_torrent_time value='".($MAIN["max_dead_torrent_time"] ? $MAIN["max_dead_torrent_time"] : "" )."'> Recomended: 6 * 3600.\n", 1);

tr("Max users ","<input type='text' id='specialboxes' name=max_users value='".($MAIN["max_users"] ? $MAIN["max_users"] : "" )."'> Recomended: 3000 or 5000.\n", 1);

tr("Torrent Dir ","<input type='text' id='specialboxes' name=torrent_dir value='".($MAIN["torrent_dir"] ? $MAIN["torrent_dir"] : "" )."'> Recomended: torrents.\n", 1);

tr("Announce url ","<input type='text' id='specialboxes' name=announce_url value='".($MAIN["announce_url"] ? $MAIN["announce_url"] : "" )."'> Recomended: http://".$_SERVER['HTTP_HOST']."/announce.php .\n", 1);

tr("Peer limit ","<input type='text' id='specialboxes' name=peerlimit value='".($MAIN["peerlimit"] ? $MAIN["peerlimit"] : "" )."'> Recomended: 5000 .\n", 1);

tr("Site email ","<input type='text' id='specialboxes' name=mail value='".($MAIN["mail"] ? $MAIN["mail"] : "" )."'> Recomended: noreply@".$_SERVER['HTTP_HOST']." .\n", 1);

tr("Site name ","<input type='text' id='specialboxes' name=name value='".($MAIN["name"] ? $MAIN["name"] : "" )."'> Nothing recomended .\n", 1);

tr("Autoclean interval ","<input type='text' id='specialboxes' name=acv value='".($MAIN["acv"] ? $MAIN["acv"] : "" )."'> Recomended: 900 .\n", 1);

tr("Pic base url ","<input type='text' id='specialboxes' name=picbu value='".($MAIN["picbu"] ? $MAIN["picbu"] : "" )."'> Recomended: pic/ .\n", 1);

tr("IMG Dir ","<input type='text' id='specialboxes' name=imgdir value='".($MAIN["imgdir"] ? $MAIN["imgdir"] : "" )."'> Recomended: pic/ .\n", 1);

	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table>");

}elseif ($action == 'savesettings_t'){
	GetVar(array('defaulttemplate'));
	$THEME['default'] = $defaulttemplate;


	WriteConfig('THEME', $THEME);
	$actiontime = date("F j, Y, g:i a"); 
	write_log("Tracker THEME settings updated by $CURUSER[username]. $actiontime");
	redirect("settings.php?action=themesettings","Settings saved, you will now be redirected.");
}elseif ($action == 'themesettings') {

	stdhead("Website Settings".S_VERSION." - THEME Settings");
	settingsmenu("themesettings");
print('<BR><table border="1">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_t'>");
	
	
$template_dirs =  dir_list('templates');
echo '<tr><td class="heading" valign="top" align="right">Please select default template of your tracker:</td>';
echo '<td valign="top" align="left"><select name="defaulttemplate">';
if (empty($template_dirs))
		$dirlist .= '<option value="">There is no template</option>';
	else {
		foreach ($template_dirs as $dir)
			$dirlist .= '<option value="'.$dir.'" '.($defaulttemplate == $dir ? 'selected' : '').'>'.$dir.'</option>';
	}
	echo $dirlist.'</select></td></tr>';
/*
tr("Tracker Online? ", "yes <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "no" ? " checked" : "") . " value='no'> <br />Want to turn off your Tracker while performing updates or other types of maintenance?<br />\n", 1);
tr("IMG Dir ","<input type='text' id='specialboxes' name=imgdir value='".($MAIN["imgdir"] ? $MAIN["imgdir"] : "" )."'> Recomended: pic/ .\n", 1);
*/
	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table>");


}elseif ($action == 'modssettings') {

	stdhead("Website Settings".S_VERSION." - Mods Settings");
	settingsmenu("modssettings");
print('<BR><table border="1">');	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='savesettings_mds'>");
tr("Enable ip-to-country mod ", "yes <INPUT type='radio' name='iptc'" . ($MODS["iptc"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='iptc'" . ($MODS["iptc"] == "no" ? " checked" : "") . " value='no'> <br /> Enable only if you installed ip-to-country mod by fr33bh(downloaded from the forum)<br />\n", 1);

	tr("Save settings","<input type='submit' name='save' class='btn' value='SAVE[press only once]'>\n", 1);
	print ("</form></table>"); }
stdfoot();
?>