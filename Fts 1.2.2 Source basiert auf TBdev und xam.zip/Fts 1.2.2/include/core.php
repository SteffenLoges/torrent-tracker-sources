<?
// The new mods starts here

//---- Website Settings v0.1
function ReadConfig ($configname) {
	global $rootpath,$BASEURL;
    if (strstr($configname, ',')) {
        $configlist = explode(',', $configname);
        foreach ($configlist as $key=>$configname) {
            ReadConfig(trim($configname));
        }
    } else {
        $configname = basename($configname);
        $path = 'config/'.$configname;
        if (!file_exists($path)) {
            stderr("ERROR", "<font color=red>File [<b>".htmlspecialchars($configname)."</b>] doesn't exist!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
        }
        $fp = fopen($path, 'r');
        $content = '';
        while (!feof($fp)) {
            $content .= fread($fp, 102400);
        }
        fclose($fp);
        if (empty($content)) {
            if ($configname == 'XAM') {
                Header("Location: $BASEURL/index.php");  				
                die; 
            }
            return array();
        }
        $tmp        = @unserialize(base64_decode($content));
        if (empty($tmp)) {
            if ($configname == 'XAM') {
                Header("Location: $BASEURL/index.php");  				
                die;                
            }
            stderr("ERROR", "<font color=red>Cannot read file [<b>".htmlspecialchars($configname)."</b>]!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
        }
        $GLOBALS[$configname] = $tmp;
        return true;
    }
}

function WriteConfig ($configname, $config) {
	global $rootpath;
    $configname = basename($configname);
    $path = 'config/'.$configname;
    if (!file_exists($path) || !is_writable ($path)) {
        stdmsg("ERROR", "<font color=red>Cannot read file [<b>".htmlspecialchars($configname)."</b>]!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    $data = base64_encode(@serialize($config));
    if (empty($data)) {
        stdmsg("ERROR", "<font color=red>Cannot serialize file [<b>".htmlspecialchars($configname)."</b>]</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    $fp = @fopen ($path, 'w');
    if (!$fp) {
        stdmsg("ERROR", "<font color=red>Cannot open file [<b>".htmlspecialchars($configname)."</b>] to save info!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    $Res = @fwrite($fp, $data);
    if (empty($Res)) {
        stdmsg("ERROR", "<font color=red>Cannot save info in file (error in serialisation) [<b>".htmlspecialchars($configname)."</b>] to save info!.</font><br><font color=blue>Before the setup starts, please ensure that you have properly configured file and directory access permissions. Please see below.</font><br><br>chmod 777 CONFIG (config directory).<br>chmod 777 CONFIG/main (the file which save the main settings).",false);
    }
    fclose($fp);
    return true;
}

function GetVar ($name) {
    if ( is_array($name) ) {
        foreach ($name as $var) GetVar ($var);
    } else {
        if ( !isset($_REQUEST[$name]) )
            return false;
        if ( get_magic_quotes_gpc() ) {
            $_REQUEST[$name] = ssr($_REQUEST[$name]);
        }
        $GLOBALS[$name] = $_REQUEST[$name];
        return $GLOBALS[$name];
    }
}
function sql_query($query)
{	
	++$_SESSION['totalqueries'];
	return mysql_query($query);
}

function redirect($url, $message='', $title='', $wait=3, $usephp=false, $withbaseurl=true)
{
	global $SITENAME,$BASEURL,$defaulttemplate,$lang;

	if (empty($message))
		$message = $lang->global['redirect'];

	if(empty($title))
		$title = $SITENAME;
		
	$url = htmlspecialchars($url);
	$url = str_replace("&amp;", "&", $url);
	$url = ($withbaseurl ? $BASEURL.'/'.$url : $url);

	if ($usephp) {		
		header ("Location: $url");
		exit;
	}
	ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<head>
<title><?=$title;?></title>
<meta http-equiv="refresh" content="<?=$wait;?>;URL=<?=$url;?>" />
<link rel="stylesheet" href="<?=$BASEURL;?>/include/templates/<?=$defaulttemplate;?>/style/style.css" type="text/css" media="screen" />
</head>
<body>
<br />
<br />
<br />
<br />
<div style="margin: auto auto; width: 50%" align="center">
<table border="0" cellspacing="1" cellpadding="4" class="tborder">
<tr>
<td class="thead"><strong><a href=<?=$BASEURL;?>><?=$title;?></a></strong></td>
</tr>
<tr>
<td class="trow1" align="center"><p><font color=red><?=$message;?></font></p></td>
</tr>
<tr>
<td class="trow2" align="right"><a href="<?=$url;?>">
<span class="smalltext"><?=$lang->global['nowaitmessage'];?></span></a></td>
</tr>
</table>
</div>
</body>
</html>
<?php
	ob_end_flush();
	exit;
}

function ssr ($arg) {
    if (is_array($arg)) {
        foreach ($arg as $key=>$arg_bit) {
            $arg[$key] = ssr($arg_bit);
        }
    } else {
        $arg = stripslashes($arg);
    }
    return $arg;
}
function error($e = 'eror') {
print($e);
}
function get_extension($file)
{
	return strtolower(substr(strrchr($file, "."), 1));
}

function dir_list($dir)
{
	$dl = array();  
	$ext = '';
	if (!file_exists($dir))
		error();
	if ($hd = opendir($dir))
	{
		while ($sz = readdir($hd)) { 
		$ext = get_extension($sz);
		if (preg_match("/^\./",$sz) == 0 && $ext != 'php')
			$dl[] = $sz;
		}
		closedir($hd);
		asort($dl);
		return $dl;
	}else
		error('','Couldn\'t open storage folder! Please check the path.');
}
// Month code to month name by fr33bh
function mctom($m) {
switch($m) {
case '01':
$month = 'January';
break;
case '02':
$month = 'February';
break;
case '03':
$month = 'March';
break;
case '04':
$month = 'April';
break;
case '05':
$month = 'May';
break;
case '06':
$month = 'June';
break;
case '07':
$month = 'July';
break;
case '08':
$month = 'August';
break;
case '09':
$month = 'September';
break;
case '10':
$month = 'October';
break;
case '11':
$month = 'November';
break;
case '12':
$month = 'December';
break;
}
return $month;
}
function get_user_class_color($class, $username)
{
  global $tracker_lang;
  switch ($class)
  {
    case UC_SYSOP:
      return "<span style=\"color:#0F6CEE\" title=\"".$tracker_lang['class_sysop']."\">" . $username . "</span>";
      break;
    case UC_ADMINISTRATOR:
      return "<span style=\"color:green\" title=\"".$tracker_lang['class_administrator']."\">" . $username . "</span>";
      break;
    case UC_MODERATOR:
      return "<span style=\"color:red\" title=\"".$tracker_lang['class_moderator']."\">" . $username . "</span>";
      break;
     case UC_UPLOADER:
      return "<span style=\"color:orange\" title=\"".$tracker_lang['class_uploader']."\">" . $username . "</span>";
      break;
     case UC_VIP:
      return "<span style=\"color:#9C2FE0\" title=\"".$tracker_lang['class_vip']."\">" . $username . "</span>";
      break;
     case UC_POWER_USER:
      return "<span style=\"color:#D21E36\" title=\"".$tracker_lang['class_power_user']."\">" . $username . "</span>";
      break;
     case UC_USER:
      return "<span title=\"".$tracker_lang['class_user']."\">" . $username . "</span>";
      break;
  }
  return "$username";
}
function timer() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}

// Variables for Start Time
$tstart = timer(); // Start time
?>