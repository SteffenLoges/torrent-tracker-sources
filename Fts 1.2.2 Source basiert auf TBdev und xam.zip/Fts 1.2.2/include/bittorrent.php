<?
/*
Fts - Free torrent source.
Main file which includes init
*/
define('r','./../');
require_once("languages/english.lang");
define ('VERSION','FTS 1.2 FINAL'); // DO NOT CHANGE PLEASE!
include 'include/init.php';
?>