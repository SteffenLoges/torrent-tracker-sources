<?php
function unquote(&$str)
{
	$str = trim($str);
	
	if (($str[0] == '"')&& ($str[strlen($str) - 1] == '"'))
	{
		$str = substr($str,1,strlen($str) - 2);			
	}
}

// Recreate inet_aton function like in mySQL
// convert Internet dot address to network address
function inet_aton($ip)
{
	$ip_array = explode(".",$ip);
	return ($ip_array[0] * pow(256,3)) + 
		   ($ip_array[1] * pow(256,2)) + 
		   ($ip_array[2] * 256) + 
			$ip_array[3]; 
}

class ip2country
{
	var $CVSFile;				   // the ip-to-country.csv file
	var $IP;					   // IP to looking for

	var $Prefix1;				   // Country prefix (2char) ex.: US
	var $Prefix2;				   // Country prefix (3char) ex.: USA
	var $Country;				   // Country name  ex.: UNITED STATE

	var $UseDB;					   // Use database instead csv file (more fast)

	// db values
	var $db_host;				   // host information for database connection
	var $db_login;				   // login information for database connection
	var $db_password;			   // password information for database connection
	var $db_basename;			   // base information for database connection
	var $db_tablename;			   // Your own table name
	var $db_ip_from_colname;	   // Your own ip_from column name
	var $db_ip_to_colname;		   // Your own ip_to column name
	var $db_prefix1_colname;	   // Your own prefix1 column name
	var $db_prefix2_colname;	   // Your own prefix2 column name
	var $db_country_colname;	   // Your own country column name

	var $_IPn;					   // Private - network address


	// Constructor
	function ip2country($ip,$usedb = true)
	{
		// TODO: Add regex to verify ip is valid
		if ($ip) 
		{
			$this->_IPn = inet_aton($ip);
			$this->IP	= $ip;
		}

		$this->CVSFile = dirname(__FILE__)."\ip-to-country.csv";
		$this->UseDB = $usedb;
		
		// D�fault value
		$this->db_host				= "localhost";
		$this->db_tablename			= "2";
		$this->db_ip_from_colname	= "ip_from";
		$this->db_ip_to_colname		= "ip_to";
		$this->db_prefix1_colname	= "country_code2";
		$this->db_prefix2_colname	= "country_code3";
		$this->db_country_colname	= "country_name";
	}

	// Look in file or database
	function LookUp()
	{
		if (!$this->UseDB)
		{
			$fd = fopen ($this->CVSFile, "r");
			while (!feof ($fd)) 
			{
				$line = fgets($fd);
				if ($line)
				{
					list($ip_from,$ip_to,$prefix1,$prefix2,$country) = explode(",",$line);
					
					unquote($ip_from);
					unquote($ip_to);
					unquote($prefix1);
					unquote($prefix2);
					unquote($country);
					
					if (($this->_IPn >= intval($ip_from)) && ($this->_IPn <= intval($ip_to)))
					{
						$this->Prefix1 = $prefix1;
						$this->Prefix2 = $prefix2;
						$this->Country = $country;
						fclose ($fd);
						return true;
					}
				}
			}
			fclose ($fd);
			return false;
		} else {
			/*
			 * The Fastest Way is to import the CSV file in your database and to
			 * set UseDB to true !
			 * I use MySQL but feel free to use your database functions ;)
			 */
			$conn = mysql_connect($this->db_host,$this->db_login,$this->db_password);
			mysql_select_db($this->db_basename,$conn);
			$query = "SELECT ".$this->db_prefix1_colname.",".$this->db_prefix2_colname.",".$this->db_country_colname." FROM ".$this->db_tablename." WHERE ".$this->_IPn.">=".$this->db_ip_from_colname." AND ".$this->_IPn."<=".$this->db_ip_to_colname;
			
			$result = mysql_query($query) or die ("Requ&ecirc;te invalide");
			$row = mysql_fetch_row($result);
			if ($row)
			{
				$this->Prefix1 = $row[0];
				$this->Prefix2 = $row[1];
				$this->Country = $row[2];
				return true;
			} else return false;

			mysql_close($conn);

		}
	}

	// This function intend to look directly on the site but it's often down :(
	function LookRemote()
	{
		$handle = fopen("http://ip-to-country.directi.com/country/name/".$this->IP, 'r');
		$this->Country = fgets($handle, 4096);
		fclose($handle);

		if (trim($this->Country) != "This service is currently down.")
		{
			$handle = fopen("http://ip-to-country.directi.com/country/code2/".$this->IP, 'r');
			$this->Prefix1 = fgets($handle, 4096);
			fclose($handle);

			$handle = fopen("http://ip-to-country.directi.com/country/code3/".$this->IP, 'r');
			$this->Prefix2 = fgets($handle, 4096);
			fclose($handle);

			return true;
		}

		return false;
	}
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
?>