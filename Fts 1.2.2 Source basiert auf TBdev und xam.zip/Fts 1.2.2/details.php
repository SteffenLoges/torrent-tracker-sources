<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


function getagent($httpagent, $peer_id="")
{
if (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_B([0-9][0-9|*])(.+)$)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_CVS)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/^Java\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Azureus/<2.0.7.0";
elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/BitTorrent\/S-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "Shadow's/$matches[1]";
elseif (preg_match("/BitTorrent\/U-([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "UPnP/$matches[1]";
elseif (preg_match("/^BitTor(rent|nado)\\/T-(.+)$/", $httpagent, $matches))
return "BitTornado/$matches[2]";
elseif (preg_match("/^BitTornado\\/T-(.+)$/", $httpagent, $matches))
return "BitTornado/$matches[1]";
elseif (preg_match("/^BitTorrent\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC/$matches[1]";
elseif (preg_match("/^ABC ([0-9]+\.[0-9]+(\.[0-9]+)*)\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC/$matches[1]";
elseif (preg_match("/^Python-urllib\/.+?, BitTorrent\/([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "BitTorrent/$matches[1]";
elseif (preg_match("/^BitTorrent\/brst(.+)/", $httpagent, $matches))
return "Burst";
elseif (preg_match("/^RAZA (.+)$/", $httpagent, $matches))
return "Shareaza/$matches[1]";
elseif (preg_match("/Rufus\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Rufus/$matches[1]";
elseif (preg_match("/^Python-urllib\\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
return "G3 Torrent";
elseif (preg_match("/MLDonkey\/([0-9]+).([0-9]+).([0-9]+)*/", $httpagent, $matches))
return "MLDonkey/$matches[1].$matches[2].$matches[3]";
elseif (preg_match("/ed2k_plugin v([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "eDonkey/$matches[1]";
elseif (preg_match("/uTorrent\/([0-9]+)([0-9]+)([0-9]+)([0-9A-Z]+)/", $httpagent, $matches))
return "uTorrent/$matches[1].$matches[2].$matches[3].$matches[4]";
elseif (preg_match("/CT([0-9]+)([0-9]+)([0-9]+)([0-9]+)/", $peer_id, $matches))
return "cTorrent/$matches[1].$matches[2].$matches[3].$matches[4]";
elseif (preg_match("/Transmission\/([0-9]+).([0-9]+)/", $httpagent, $matches))
return "Transmission/$matches[1].$matches[2]";
elseif (preg_match("/KT([0-9]+)([0-9]+)([0-9]+)([0-9]+)/", $peer_id, $matches))
return "KTorrent/$matches[1].$matches[2].$matches[3].$matches[4]";
elseif (preg_match("/rtorrent\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
return "rTorrent/$matches[1]";
elseif (preg_match("/^ABC\/Tribler_ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "Tribler/$matches[1]";
elseif (preg_match("/^BitsOnWheels( |\/)([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "BitsOnWheels/$matches[2]";
elseif (preg_match("/BitTorrentPlus\/(.+)$/", $httpagent, $matches))
return "BitTorrent Plus!/$matches[1]";
elseif (ereg("^Deadman Walking", $httpagent))
return "Deadman Walking";
elseif (preg_match("/^eXeem( |\/)([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "eXeem$matches[1]$matches[2]";
elseif (preg_match("/^libtorrent\/(.+)$/", $httpagent, $matches))
return "libtorrent/$matches[1]";
elseif (substr($peer_id, 0, 12) == "d0c")
return "Mainline";
elseif (substr($peer_id, 0, 1) == "M")
return "Mainline/Decoded";
elseif (substr($peer_id, 0, 3) == "-BB")
return "BitBuddy";
elseif (substr($peer_id, 0, 8) == "-AR1001-")
return "Arctic Torrent/1.2.3";
elseif (substr($peer_id, 0, 6) == "exbc\08")
return "BitComet/0.56";
elseif (substr($peer_id, 0, 6) == "exbc\09")
return "BitComet/0.57";
elseif (substr($peer_id, 0, 6) == "exbc\0:")
return "BitComet/0.58";
elseif (substr($peer_id, 0,4) == "-BC0")
return "BitComet/0.".substr($peer_id,5,2);
elseif (substr($peer_id, 0, 7) == "exbc\0L")
return "BitLord/1.0";
elseif (substr($peer_id, 0, 7) == "exbcL")
return "BitLord/1.1";
elseif (substr($peer_id, 0, 3) == "346")
return "TorrenTopia";
elseif (substr($peer_id, 0, 8) == "-MP130n-")
return "MooPolice";
elseif (substr($peer_id, 0, 8) == "-SZ2210-")
return "Shareaza/2.2.1.0";
elseif (ereg("^0P3R4H", $httpagent))
return "Opera BT Client";
elseif (substr($peer_id, 0, 6) == "A310--")
return "ABC/3.1";
elseif (ereg("^XBT Client", $httpagent))
return "XBT Client";
elseif (ereg("^BitTorrent\/BitSpirit$", $httpagent))
return "BitSpirit";
elseif (ereg("^DansClient", $httpagent))
return "XanTorrent";

else
return "Unknow";
}

function dltable($name, $arr, $torrent)
{

        global $CURUSER;
        $s = "<b>" . count($arr) . " $name</b>\n";
        if (!count($arr))
                return $s;
        $s .= "\n";
        $s .= "<table width=100% class=main border=1 cellspacing=0 cellpadding=5>\n";
        $s .= "<tr><td class=colhead>".dt1."</td>" .
          "<td class=colhead align=center>".dt2."</td>".
          "<td class=colhead align=right>".dt3."</td>".
          "<td class=colhead align=right>".dt4."</td>".
          "<td class=colhead align=right>".dt5."</td>" .
          "<td class=colhead align=right>".dt6."</td>" .
          "<td class=colhead align=right>".dt7."</td>" .
          "<td class=colhead align=right>".dt8."</td>" .
          "<td class=colhead align=right>".dt9."</td>" .
          "<td class=colhead align=right>".dt10."</td>" .
          "<td class=colhead align=left>".dt11."</td></tr>\n";
        $now = time();
        $moderator = (isset($CURUSER) && get_user_class() >= UC_MODERATOR);
$mod = get_user_class() >= UC_MODERATOR;
        foreach ($arr as $e) {


                // user/ip/port
                // check if anyone has this ip
                ($unr = mysql_query("SELECT id, username, privacy, warned, donor FROM users WHERE id=$e[userid] ORDER BY last_access DESC LIMIT 1")) or die;
                $una = mysql_fetch_array($unr);
                if ($una["privacy"] == "strong") continue;
                ++$num;

                $highlight = $CURUSER["id"] == $una["id"] ? " bgcolor=#BBAF9B" : "";
                $s .= "<tr$highlight>\n";
              //$s .= "<tr>\n";
                if ($una["username"]) {

                if (get_user_class() >= UC_MODERATOR || $torrent['anonymous'] != 'yes' || $e['userid'] != $torrent['owner']) {
             // $s .= "<td><a href=userdetails.php?id=$e[userid]><b>$una[username]</b></a></td>\n";
                $s .= "<td><a href=userdetails.php?id=$e[userid]><b>$una[username]</b></a>" . ($una["donor"] == "yes" ? "<img src=".
                "/pic/star.gif alt='Donor'>" : "") . ($una["enabled"] == "no" ? "<img src=".
                "/pic/disabled.gif alt=\"This account is disabled\" style='margin-left: 2px'>" : ($una["warned"] == "yes" ? "<a href=rules.php#warning class=altlink><img src=/pic/warned.gif alt=\"Warned\" border=0></a>" : ""));
                }
                elseif (get_user_class() >= UC_MODERATOR || $torrent['anonymous'] = 'yes') {
                $s .= "<td><i>".dt12."</i></a></td>\n";
                }
                }
                else
                $s .= "<td>".dt13."</td>\n";
                $secs = max(1, ($now - $e["st"]) - ($now - $e["la"]));
                $revived = $e["revived"] == "yes";
        $s .= "<td align=center>" . ($e[connectable] == "yes" ? dt14 : "<font color=red>".dt15."</font>") . "</td>\n";
                $s .= "<td align=right>" . mksize($e["uploaded"]) . "</td>\n";
                $s .= "<td align=right><nobr>" . mksize(($e["uploaded"] - $e["uploadoffset"]) / $secs) . "/s</nobr></td>\n";
                $s .= "<td align=right>" . mksize($e["downloaded"]) . "</td>\n";
                if ($e["seeder"] == "no")
                        $s .= "<td align=right><nobr>" . mksize(($e["downloaded"] - $e["downloadoffset"]) / $secs) . "/s</nobr></td>\n";
                else
                        $s .= "<td align=right><nobr>" . mksize(($e["downloaded"] - $e["downloadoffset"]) / max(1, $e["finishedat"] - $e[st])) .        "/s</nobr></td>\n";
                if ($e["downloaded"])
                                {
                  $ratio = floor(($e["uploaded"] / $e["downloaded"]) * 1000) / 1000;
                    $s .= "<td align=\"right\"><font color=" . get_ratio_color($ratio) . ">" . number_format($ratio, 3) . "</font></td>\n";
                                }
                       else
                  if ($e["uploaded"])
                    $s .= "<td align=right>Inf.</td>\n";
                  else
                    $s .= "<td align=right>---</td>\n";
                $s .= "<td align=right>" . sprintf("%.2f%%", 100 * (1 - ($e["to_go"] / $torrent["size"]))) . "</td>\n";
                $s .= "<td align=right>" . mkprettytime($now - $e["st"]) . "</td>\n";
                $s .= "<td align=right>" . mkprettytime($now - $e["la"]) . "</td>\n";
                $s .= "<td align=left>" . htmlspecialchars(getagent($e["agent"], $e["peer_id"])) . "</td>\n";
                $s .= "</tr>\n";
        }
        $s .= "</table>\n";
        return $s;
}

dbconn(false);

loggedinorreturn();

$id = 0 + $_GET["id"];

if (!isset($id) || !$id)
        die();

$res = mysql_query("SELECT torrents.seeders, torrents.banned, torrents.leechers, torrents.info_hash, torrents.filename, LENGTH(torrents.nfo) AS nfosz, UNIX_TIMESTAMP() - UNIX_TIMESTAMP(torrents.last_action) AS lastseed, torrents.numratings, torrents.name, torrents.description, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, torrents.owner, torrents.save_as, torrents.descr, torrents.visible, torrents.size, torrents.added, torrents.views, torrents.hits, torrents.times_completed, torrents.id, torrents.type, torrents.numfiles, torrents.anonymous, categories.name AS cat_name, users.username FROM torrents LEFT JOIN categories ON torrents.category = categories.id LEFT JOIN users ON torrents.owner = users.id WHERE torrents.id = $id")
        or sqlerr();
$row = mysql_fetch_array($res);

$owned = $moderator = 0;
        if (get_user_class() >= UC_MODERATOR)
                $owned = $moderator = 1;
        elseif ($CURUSER["id"] == $row["owner"])
                $owned = 1;
//}

if (!$row || ($row["banned"] == "yes" && !$moderator))
        stderr("Error", "No torrent with ID $id.");
else {
        if ($_GET["hit"]) {
                mysql_query("UPDATE torrents SET views = views + 1 WHERE id = $id");
                if ($_GET["tocomm"])
                        header("Location: $BASEURL/details.php?id=$id&page=0#startcomments");
                elseif ($_GET["filelist"])
                        header("Location: $BASEURL/details.php?id=$id&filelist=1#filelist");
                elseif ($_GET["toseeders"])
                        header("Location: $BASEURL/details.php?id=$id&dllist=1#seeders");
                elseif ($_GET["todlers"])
                        header("Location: $BASEURL/details.php?id=$id&dllist=1#leechers");
                else
                        header("Location: $BASEURL/details.php?id=$id");
                exit();
        }

        if (!isset($_GET["page"])) {
                stdhead("Details for torrent \"" . $row["name"] . "\"");

                if ($CURUSER["id"] == $row["owner"] || get_user_class() >= UC_MODERATOR)
                        $owned = 1;
                else
                        $owned = 0;

                $spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

                if ($_GET["uploaded"]) {
                        print("<h2>".dt16."</h2>\n");
                        print("<p><b>".dt17."</b></p>\n");
                        print("<p>".dt18."</p>\n");
                }
                elseif ($_GET["edited"]) {
                        print("<h2>".dt19."</h2>\n");
                        if (isset($_GET["returnto"]))
                                print("<p><b>".dt20." <a href=\"" . htmlspecialchars($_GET["returnto"]) . "\">".dt21."</a>.</b></p>\n");
                }
                elseif (isset($_GET["searched"])) {
                        print("<h2>".dt22." \"" . htmlspecialchars($_GET["searched"]) . "\" ".dt23.":</h2>\n");
                }
                elseif ($_GET["rated"]) {
 print("<h2>".dt24."</h2>\n");
}
elseif ($_GET["thanks"])
 print("<h2>".dt25."</h2>\n");

$s=$row["name"];
$descrs = $row["description"];
$fts_torrent->modmenu();                
print("<h1>$s</h1>\n");
                print("<table width=100% border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");

                $url = "edit.php?id=" . $row["id"];
                if (isset($_GET["returnto"])) {
                        $addthis = "&amp;returnto=" . urlencode($_GET["returnto"]);
                        $url .= $addthis;
                        $keepget .= $addthis;
                }
                $editlink = "a href=\"$url\" class=\"sublink\"";

//                $s = "<b>" . htmlspecialchars($row["name"]) . "</b>";
//                if ($owned)
//                        $s .= " $spacer<$editlink>[Edit torrent]</a>";
//                tr("Name", $s, 1);
if($usergroups['candwd'] == 'yes')
                print("<tr><td class=rowhead width=1%>".dt26."</td><td width=99% align=left><a href=\"download.php/$id/" . rawurlencode($row["filename"]) . "\">" . htmlspecialchars($row["filename"]) . "</a></td></tr>");
                if (!empty($row["description"]))
                print("<tr><td class=rowhead width=1%>".dt27."</td><td width=99% align=left>$descrs</td></tr>");
                //                tr("Downloads&nbsp;as", $row["save_as"]);

                function hex_esc($matches) {
                        return sprintf("%02x", ord($matches[0]));
                }
                tr(dt28, preg_replace_callback('/./s', "hex_esc", hash_pad($row["info_hash"])));

                if (!empty($row["descr"])){
           tr(dt29, str_replace(array("\n", "  "), array("<br>\n", "&nbsp; "), format_urls(htmlspecialchars($row["descr"]))), 1, "id=\"descrTD\"".( $owned ? " ondblclick=\"sndReq('action=edit_torrent_descr&torrent=".$_GET['id']."', 'descrTD')\"" : '') );
       }

if (get_user_class() >= UC_POWER_USER && $row["nfosz"] > 0)
  print("<tr><td class=rowhead>".dt30."</td><td align=left><a href=viewnfo.php?id=$row[id]><b>".dt31."</b></a> (" .
     mksize($row["nfosz"]) . ")</td></tr>\n");
                if ($row["visible"] == "no")
                        tr("Visible", "<b>no</b> (dead)", 1);
                       if ($moderator){
           tr(dt32, $row["banned"], 0, "id=\"bannedChange\" style=\"cursor:default\" ondblclick=\"sndReq('action=change_banned_torrent&torrent=".$_GET['id']."', 'bannedChange')\"");
       }
       if (isset($row["cat_name"])){
           tr(dt33, $row["cat_name"], 0, ( $moderator ? "id=\"typeChange\" style=\"cursor:default\" ondblclick=\"sndReq('action=change_type_torrent&torrent=".$_GET['id']."', 'typeChange')\"" : "" ) );
       } else{
           tr(dt33, "(none selected)");
       }

                tr(dt34, dt35 . mkprettytime($row["lastseed"]) . " ago");
                tr(dt36,mksize($row["size"]) . " (" . number_format($row["size"]) . " bytes)");
/*
                $s = "";
                $s .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td valign=\"top\" class=embedded>";
                if (!isset($row["rating"])) {
                        if ($minvotes > 1) {
                                $s .= "none yet (needs at least $minvotes votes and has got ";
                                if ($row["numratings"])
                                        $s .= "only " . $row["numratings"];
                                else
                                        $s .= "none";
                                $s .= ")";
                        }
                        else
                                $s .= "No votes yet";
                }
                else {
                        $rpic = ratingpic($row["rating"]);
                        if (!isset($rpic))
                                $s .= "invalid?";
                        else
                                $s .= "$rpic (" . $row["rating"] . " out of 5 with " . $row["numratings"] . " vote(s) total)";
                }
                $s .= "\n";
                $s .= "</td><td class=embedded>$spacer</td><td valign=\"top\" class=embedded>";
                if (!isset($CURUSER))
                        $s .= "(<a href=\"login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;nowarn=1\">Log in</a> to rate it)";
                else {
                        $ratings = array(
                                        5 => "Kewl!",
                                        4 => "Pretty good",
                                        3 => "Decent",
                                        2 => "Pretty bad",
                                        1 => "Sucks!",
                        );
                        if (!$owned || $moderator) {
                                $xres = mysql_query("SELECT rating, added FROM ratings WHERE torrent = $id AND user = " . $CURUSER["id"]);
                                $xrow = mysql_fetch_array($xres);
                                if ($xrow)
                                        $s .= "(you rated this torrent as \"" . $xrow["rating"] . " - " . $ratings[$xrow["rating"]] . "\")";
                                else {
                                        $s .= "<form method=\"post\" action=\"takerate.php\"><input type=\"hidden\" name=\"id\" value=\"$id\" />\n";
                                        $s .= "<select name=\"rating\">\n";
                                        $s .= "<option value=\"0\">(add rating)</option>\n";
                                        foreach ($ratings as $k => $v) {
                                                $s .= "<option value=\"$k\">$k - $v</option>\n";
                                        }
                                        $s .= "</select>\n";
                                        $s .= "<input type=\"submit\" value=\"Vote!\" />";
                                        $s .= "</form>\n";
                                }
                        }
                }
                $s .= "</td></tr></table>";
                tr("Rating", $s, 1);

*/

                tr(dt37, $row["added"]);
                tr(dt38, $row["views"]);
                tr(dt39, $row["hits"]);
                tr(dt40, $row["times_completed"] . dt41);

                $keepget = "";
                if($row['anonymous'] == 'yes') {

                if (get_user_class() < UC_UPLOADER)
                $uprow = "<i>".dt42."</i>";
                else
                $uprow = "<i>".dt42."</i> (<a href=userdetails.php?id=$row[owner]><b>$row[username]</b></a>)";
                }
                else {
                $uprow = (isset($row["username"]) ? ("<a href=userdetails.php?id=" . $row["owner"] . "><b>" . htmlspecialchars($row["username"]) . "</b></a>") : "<i>".dt43."</i>");
                }
                if ($owned)
                        $uprow .= " $spacer<$editlink><b>".dt44."</b></a>";
                tr(dt45, $uprow, 1);

                if ($row["type"] == "multi") {
                        if (!$_GET["filelist"])
                                tr(dt46."<br /><a href=\"details.php?id=$id&amp;filelist=1$keepget#filelist\" class=\"sublink\">[".dt47."]</a>", $row["numfiles"] . " files", 1);
                        else {
                                tr(dt46, $row["numfiles"] . dt48, 1);

                                $s = "<table class=main border=\"1\" cellspacing=0 cellpadding=\"5\">\n";

                                $subres = mysql_query("SELECT * FROM files WHERE torrent = $id ORDER BY id");
$s.="<tr><td class=colhead>".dt49."</td><td class=colhead align=right>".dt50."</td></tr>\n";
                                while ($subrow = mysql_fetch_array($subres)) {
                                        $s .= "<tr><td>" . $subrow["filename"] .
                            "</td><td align=\"right\">" . mksize($subrow["size"]) . "</td></tr>\n";
                                }

                                $s .= "</table>\n";
                                tr("<a name=\"filelist\">".dt51."</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[".dt52."]</a>", $s, 1);
                        }
                }

                if (!$_GET["dllist"]) {
                        /*
                        $subres = mysql_query("SELECT seeder, COUNT(*) FROM peers WHERE torrent = $id GROUP BY seeder");
                        $resarr = array(yes => 0, no => 0);
                        $sum = 0;
                        while ($subrow = mysql_fetch_array($subres)) {
                                $resarr[$subrow[0]] = $subrow[1];
                                $sum += $subrow[1];
                        }
                        tr("Peers<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[See full list]</a>", $resarr["yes"] . " seeder(s), " . $resarr["no"] . " leecher(s) = $sum peer(s) total", 1);
                        */
                        tr(dt53."<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[".dt47."]</a>", $row["seeders"] . " seeder(s), " . $row["leechers"] . " leecher(s) = " . ($row["seeders"] + $row["leechers"]) . " peer(s) total", 1);
                }
                else {
                        $downloaders = array();
                        $seeders = array();
                        $subres = mysql_query("SELECT seeder, finishedat, downloadoffset, uploadoffset, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, agent, peer_id, UNIX_TIMESTAMP(last_action) AS la, userid FROM peers WHERE torrent = $id") or sqlerr();
                        while ($subrow = mysql_fetch_array($subres)) {
                                if ($subrow["seeder"] == "yes")
                                        $seeders[] = $subrow;
                                else
                                        $downloaders[] = $subrow;
                        }

                        function leech_sort($a,$b) {
                                if ( isset( $_GET["usort"] ) ) return seed_sort($a,$b);
                                $x = $a["to_go"];
                                $y = $b["to_go"];
                                if ($x == $y)
                                        return 0;
                                if ($x < $y)
                                        return -1;
                                return 1;
                        }
                        function seed_sort($a,$b) {
                                $x = $a["uploaded"];
                                $y = $b["uploaded"];
                                if ($x == $y)
                                        return 0;
                                if ($x < $y)
                                        return 1;
                                return -1;
                        }

                        usort($seeders, "seed_sort");
                        usort($downloaders, "leech_sort");

                        tr("<a name=\"seeders\">".dt54."</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[".dt52."]</a>", dltable("Seeder(s)", $seeders, $row), 1);
                        tr("<a name=\"leechers\">Leechers</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[".dt52."]</a>", dltable("Leecher(s)", $downloaders, $row), 1);
                }
                //.torrent file info link
                if (get_user_class() >= UC_MODERATOR)
                {
                tr(dt55, "<a href=\"torrent_info.php?id=$id\">".dt56."</a>", 1);
                }
$disabled = $usergroups['canth'] == 'no' ? ' disabled' : '';
$xtrainfo = $usergroups['canth'] == 'no' ? '(your usergroup doesn\'t have access to give thanks on a torrent)' : '';
$torrentid = $_GET["id"];
         $thanks_sql = mysql_query("SELECT * FROM thanks where torrentid=$torrentid");
   $thanks_all = mysql_numrows($thanks_sql);
   if ($thanks_all) {
   while($rows_t = mysql_fetch_array($thanks_sql)) {
   $thanks_userid = $rows_t["userid"];
   $user_sql = mysql_query("SELECT * FROM users where id=$thanks_userid");
   $rows_a = mysql_fetch_array($user_sql);
   $username_t = $rows_a["username"];
   $thanksby =  $thanksby."<a href='userdetails.php?id=$thanks_userid'>$username_t</a>, ";
   }
   $t_userid = $CURUSER["id"];
   $tsql = mysql_query("SELECT COUNT(*) FROM thanks where torrentid=$torrentid and userid=$t_userid");
   $trows = mysql_fetch_array($tsql);
   $t_ab = $trows[0];
   if ($t_ab == "0") {

   $thanksby = $thanksby." <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"".dt57."\" $disabled> $xtrainfo
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>";
   }
   else {
   $thanksby = $thanksby." <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"".dt57."\" disabled>
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>";
   }
   }
   else {
   $thanksby = dt58."  
   <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"".dt57."\" $disabled> $xtrainfo
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>
   ";
   }
       tr(dt59,$thanksby,1);

                print("</table></p>\n");
        }
        else {
                stdhead(dt60." \"" . $row["name"] . "\"");
                print("<h1>".dt61." <a href=details.php?id=$id>" . $row["name"] . "</a></h1>\n");
//                print("<p><a href=\"details.php?id=$id\">Back to full details</a></p>\n");
        }

        print("<p><a name=\"startcomments\"></a></p>\n");
if($usergroups['canpc'] == 'yes')
        $commentbar = "<p align=center><a href=comment.php?action=add&amp;tid=$id>".dt65."</a></p>\n";
else
$commentbar = 'Your usergroup cannot post comments.';
$quickcomment = "<table style='border:1px solid #000000;'><tr>".
  "<td style='padding:10px;text-align:center;'><p><b>".dt62."</b><br />".
  "<form name=comment method=\"post\" action=\"comment.php?action=add\">".
  "<textarea name=\"text\" rows=\"4\" cols=\"97\"></textarea>".
  "<input type=\"hidden\" name=\"tid\" value=\"$id\"/><br />".
  "<input type=\"submit\" class=btn value=\"".dt63."\" />".
  "</form></p></td></tr></table>";

        $subres = mysql_query("SELECT COUNT(*) FROM comments WHERE torrent = $id");
        $subrow = mysql_fetch_array($subres);
        $count = $subrow[0];

        if (!$count) {
if($usergroups['canpc'] == 'yes') 
print($quickcomment);
 print("<h3>".dt64."</h3>\n");
}
        else {
                list($pagertop, $pagerbottom, $limit) = pager(20, $count, "details.php?id=$id&", array(lastpagedefault => 1));

                $subres = mysql_query("SELECT comments.id, text, user, comments.added, editedby, editedat, avatar, warned, ".
                  "username, title, class, donor FROM comments LEFT JOIN users ON comments.user = users.id WHERE torrent = " .
                  "$id ORDER BY comments.id $limit") or sqlerr(__FILE__, __LINE__);
                $allrows = array();
                while ($subrow = mysql_fetch_array($subres))
                        $allrows[] = $subrow;

                print($commentbar);
if($usergroups['canpc'] == 'yes')
print($quickcomment);
                print($pagertop);

                commenttable($allrows);

                print($pagerbottom);
        }

        print($commentbar);
}

stdfoot();

?>