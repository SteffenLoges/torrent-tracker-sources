<?php

loggedinorreturn();



$action = $_GET["action"];

//   Delete Announce Item    //////////////////////////////////////////////////////

if ($action == 'delete')
{
	
		if (get_user_class() < UC_ADMINISTRATOR)
	die(Error);
	
	$ann_id = $_GET["ann_id"];
  if (!is_valid_id($ann_id))
  	stderr(annerr,annc1);

  $returnto = $_GET["returnto"];

  $sure = $_GET["sure"];
  if (!$sure)
    stderr(anndel, annrealy .
    	"<a href=admin.php?act=announcement&action=delete&ann_id=$ann_id&returnto=$returnto&sure=1>".annh."</a>".annsure);

  mysql_query("DELETE FROM announcement WHERE id=$ann_id") or sqlerr(__FILE__, __LINE__);

	if ($returnto != "")
		header("Location: $returnto");
	else
		$warning = annok;
}

//   Add Announcement Item    /////////////////////////////////////////////////////////

if ($action == 'add')
{
	if (get_user_class() < UC_SYSOP)
	die(Error);
	
	$body = $_POST["body"];
	if (!$body)
		stderr(annerr,ann2);
		
$title = $_POST["title"];
	if (!$title)
		stderr(annerr,ann3);

	$added = $_POST["added"];
	if (!$added)
		$added = sqlesc(get_date_time());

  mysql_query("INSERT INTO announcement (userid, added, body ,title) VALUES (".
  		$CURUSER['id'] . ", $added, " . sqlesc($body) . ", " . sqlesc($title) . ")") or sqlerr(__FILE__, __LINE__);
	if (mysql_affected_rows() == 1)
	{
		mysql_query("UPDATE users SET announce = 'yes' WHERE announce='no'");
			$warning = annok2;
		}
	else
		stderr(annerr,ann4);
}

//   Edit Announcement    ////////////////////////////////////////////////////////

if ($action == 'edit')
{
	if (get_user_class() < UC_ADMINISTRATOR)
	die(Error);
	
	$ann_id = $_GET["ann_id"];

  if (!is_valid_id($ann_id))
  	stderr(annerr,ann5);

  $res = mysql_query("SELECT * FROM announcement WHERE id=$ann_id") or sqlerr(__FILE__, __LINE__);

	if (mysql_num_rows($res) != 1)
	  stderr(annerr, ann6.$ann_id.".");

	$arr = mysql_fetch_array($res);

  if ($_SERVER['REQUEST_METHOD'] == 'POST')
  {
  	$body = $_POST['body'];
    if ($body == "")
    	stderr(annerr, ann7);
    $body = sqlesc($body);
    mysql_query("UPDATE announcement SET body=$body WHERE id=$ann_id") or sqlerr(__FILE__, __LINE__);

$title = $_POST['title'];
    if ($title == "")
    	stderr(annerr, ann8);
    $title = sqlesc($title);
    mysql_query("UPDATE announcement SET title=$title WHERE id=$ann_id") or sqlerr(__FILE__, __LINE__);
    
    
    $editedat = sqlesc(get_date_time());



    $returnto = $_POST['returnto'];

		if ($returnto != "")
			header("Location: $returnto");
		else
			$warning = ann9;
  }
  else
  {
 	 	$returnto = $_GET['returnto'];
	  stdhead();
	  print("<h1>".ann10."</h1>\n");
	  print("<form method=post action=admin.php?act=announcement&action=edit&ann_id=$ann_id>\n");
	  print("<table border=1 cellspacing=0 cellpadding=5>\n");
	  print("<tr><td><input type=hidden name=returnto value=$returnto></td></tr>\n");
	  print("<tr><td><b>".ann11." &nbsp </b><input type=text size=100 maxlength=80 name=title value=".htmlspecialchars($arr['title'])."></td></tr>\n");
	  print("<tr><td style='padding: 0px'><textarea name=body cols=145 rows=5 style='border: 0px'>" . htmlspecialchars($arr["body"]) . "</textarea></td></tr>\n");
	  print("<tr><td align=center><input type=submit value='Edit' class=btn></td></tr>\n");
	  print("</table>\n");
	  print("</form>\n");
	  stdfoot();
	  die;
  }
}

//   Other Actions and followup    ////////////////////////////////////////////


//   Set announce to YES for all users    //////////////////////////////////////////////////////

if ($action == 'show_all')
{
	
	if (get_user_class() < UC_ADMINISTRATOR)
	die(Error);
	
	  $sure = $_GET["sure"];
  if (!$sure)
    stderr(ann12,ann13 . "<a href=admin.php?act=announcement&action=show_all&returnto=$returnto&sure=1>".ann14);
					 mysql_query("UPDATE users SET announce = 'yes' WHERE announce='no'");

	if ($returnto != "")
		header("Location: $returnto");
	else
		$warning = ann15;
}

//   Set announce to NO for all users    //////////////////////////////////////////////////////

if ($action == 'hide_all')
{
		if (get_user_class() < UC_ADMINISTRATOR)
	die(Error);
	
	$sure = $_GET["sure"];
  if (!$sure)
    stderr(ann16,ann17 .
    	"<a href=admin.php?act=announcement&action=hide_all&returnto=$returnto&sure=1>".ann18);
					 mysql_query("UPDATE users SET announce = 'no' WHERE announce='yes'");

	if ($returnto != "")
		header("Location: $returnto");
	else
		$warning = ann19;
}
////////////////////////////////////////////////////////////////////////////////////////////////


stdhead("Announcement");
if (get_user_class() > UC_ADMINISTRATOR){
print("<h1>".ann20."</h1>\n");
if ($warning)
	print("<p><font size=-3>($warning)</font></p>");
print("<form method=post action=admin.php?act=announcement&action=add>\n");
print("<table border=1 cellspacing=0 cellpadding=5>\n");
print("<tr><td style='padding: 10px'><b>".ann21." &nbsp </b><input type=text size=140 maxlength=80 name=title " . "style='border: 0px; height: 19px'></input>\n");
print("<tr><td style='padding: 10px'><textarea name=body cols=145 rows=5 style='border: 0px'></textarea>\n");
print("<br><br><div align=center><input type=submit value='Announce' class=btn></div></td></tr>\n");
print("</table></form><br><br>\n");
}
$res = mysql_query("SELECT * FROM announcement ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);


if (get_user_class() >= UC_ADMINISTRATOR){
print("[<a href=admin.php?act=announcement&action=show_all><b>".ann22."</b></a>]");
print(" - [<a href=admin.php?act=announcement&action=hide_all><b>".ann23."</b></a>]");
}

print("<h1>.: ".ann24." :.</h1>");

if (mysql_num_rows($res) > 0)
{


 	begin_main_frame();
	begin_frame();
	
	
	
	

	while ($arr = mysql_fetch_array($res))
	{
		$ann_id = $arr["id"];
		$body = $arr["body"];
		$title = $arr["title"];
	  $userid = $arr["userid"];
	  $added = $arr["added"] . " GMT (" . (get_elapsed_time(sql_timestamp_to_unix_timestamp($arr["added"]))) . " ago)";

    $res2 = mysql_query("SELECT username, donor FROM users WHERE id = $userid") or sqlerr(__FILE__, __LINE__);
    $arr2 = mysql_fetch_array($res2);

    $postername = $arr2["username"];
 print("<p class=sub><table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>");
    print("$added&nbsp;");
if (get_user_class() >= UC_ADMINISTRATOR){
    if ($postername == "")
    	$by = "unknown[$userid]";
    else
    	$by = "<a href=userdetails.php?id=$userid><b>$postername</b></a>" .
    		($arr2["donor"] == "yes" ? "<img src=pic/star.gif alt='Donor'>" : "");
		print(" ---&nbsp;by&nbsp$by");
	  print(" - [<a href=admin.php?act=announcement&action=edit&ann_id=$ann_id><b>".ann25."</b></a>]");
    print(" - [<a href=admin.php?act=announcement&action=delete&ann_id=$ann_id><b>".ann26."</b></a>]");
   
}


 print("</td></tr></table></p>\n");
	  begin_table(true);
	  print("<td padding: 0px height=5 background=/pic/ann_bg.jpg><b><font size=1>$title</font></b></td>\n");
	  print("<tr valign=top><td class=comment>".format_comment($body)."</td></tr>\n");
	  end_table();
	}
	end_frame();
	end_main_frame();
}
else
  stdmsg(ann27, ann28);
  
  mysql_query("UPDATE users SET announce = 'no' WHERE id=".$CURUSER['id']);
stdfoot();
die;
?>