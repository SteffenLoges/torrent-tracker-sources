<?php
stdhead();
if (get_user_class() < UC_ADMINISTRATOR) {
die("Access denied.");
}
$unix = 1; //set this to 1 if you are on a *unix system
$windows = 0; //set this to 1 if you are on a windows system

$register_globals = (bool) ini_get('register_gobals');
$system = ini_get('system');
$unix = (bool) $unix;
$win = (bool) $windows;
//
If ($register_globals)
{
$ip = getenv(REMOTE_ADDR);
$self = $PHP_SELF;
}
else
{
$submit = $_GET['submit'];
$host = $_GET['host'];
$ip = $_SERVER['REMOTE_ADDR'];
$self = $_SERVER['PHP_SELF'];
};
// form submitted ?
If ($submit == "Traceroute!")
{
// replace bad chars
$host= preg_replace ("/[^A-Za-z0-9.]/","",$host);
echo '<body bgcolor="#FFFFFF" text="#000000"></body>';
echo("Trace Output:<br>");
echo '<pre>';
//check target IP or domain
if ($unix)
{
system ("traceroute $host");
system("killall -q traceroute");// kill all traceroute processes in case there are some stalled ones or use echo 'traceroute' to execute without shell
}
else
{
system("tracert $host");
}
echo '</pre>';
echo 'done ...';
}
else
{
echo '<body bgcolor="#FFFFFF" text="#000000"></body>';
echo '<p><font size="2">Your IP is: '.$ip.'</font></p>';
echo '<form methode="post" action="admin.php?act=traceroute">';
echo ' <input type="hidden" name="act" value="traceroute"></input>';
echo ' Enter IP or Host <input type="text" name="host" value="'.$ip.'"></input>';
echo ' <input type="submit" name="submit" value="Traceroute!"></input>';
echo '</form>';
echo '<br><b>'.$system.'</b>';
echo '</body></html>';
}
stdfoot();
?>