<?php
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// MODULE: ip to country by fr33bh
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
header("Pragma: no-cache"); 
header("Cache-Control: no-cache");
define ('ROOT_PATH', './../');
?>
<head><style>
p.trl
{ 
text-transform: lowercase
}
</style></head>
<?

$ip = $_GET['ip'];
$user = $_GET['user'];

$iplook = new ip2country($ip);

$iplook->UseDB			= true;
$iplook->db_login		= $mysql_user;
$iplook->db_password	= $mysql_pass;
$iplook->db_basename	= $mysql_db;
$iplook->db_host	= $mysql_host;
$iplook->db_tablename	= "iptoc";

if ($iplook->LookUp())
{
stdhead();
	echo "User  ".$user." is from ".$iplook->Country." ( ".$iplook->Prefix1." )";
$ctr = strtolower($iplook->Country);
echo '<BR>';
echo"<img src='pic/flag/".$ctr."' />";
stdfoot();
}
else echo "I don't know where you come from !";
			  
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
?>