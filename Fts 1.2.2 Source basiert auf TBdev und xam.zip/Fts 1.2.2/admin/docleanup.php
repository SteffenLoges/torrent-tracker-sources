<?
loggedinorreturn();

if (get_user_class() < UC_SYSOP)
        stderr("Error", "Access denied.");

stdhead("Do cleanup");

docleanup();

print("Done");
print("<p>Back to <a href=admin.php><b>CPanel</b></a></p>");

stdfoot();

?>