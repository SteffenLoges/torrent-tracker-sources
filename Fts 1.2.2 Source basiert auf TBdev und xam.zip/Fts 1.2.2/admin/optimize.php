<?
define('p','./../');
//---------------------------------------------------------
//---- Optimize & Repair Database from Tracker by D3SI
//---------------------------------------------------------
loggedinorreturn();
if (get_user_class() < UC_SYSOP)
stderr("Error", "Permission denied.");
$tables = "";
$tablesshow = mysql_query("SHOW TABLES FROM `".$mysql_db."`");
while (list($table) = mysql_fetch_row($tablesshow)){
$tables .= "`".mysql_real_escape_string($table)."`,";
}
$tables .= "...";
$tables = str_replace(",...", "", $tables);
mysql_query("OPTIMIZE TABLE ".$tables);
//mysql_query("REPAIR TABLE ".$tables);

stderr("Optimize & Repair Database", "Database OPTIMIZED & Repaired!");
//---------------------------------------------
//---- END
//---------------------------------------------
?>