<?php
dbconn(false);
loggedinorreturn();

stdhead("Delete all Dead Torrents");

if (get_user_class() < UC_ADMINISTRATOR){
        print("Access Denied!");
        exit;
}

if($_GET['ja'] == 1){
mysql_query("DELETE FROM torrents WHERE visible='no'") or sqlerr(__FILE__, __LINE__);
echo "All Dead Torrents have been deleted!";
}
else{
echo "Are you sure to delete all dead torrents? <br><br><a href= 'admin.php?act=deletedead&ja=1'>Yes</a>";
}

stdfoot();

?>