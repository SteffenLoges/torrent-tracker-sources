<?php
dbconn();

//loggedinorreturn();

stdhead("Delete Torrent");

begin_main_frame();

?>

<?
if($_GET[mode] == "delete"){
if (get_user_class() >= UC_MODERATOR) {
//echo"" . implode(", ", $_POST[delete]) . "";
$table = "torrents";
$table2 = "sitelog";
$res = mysql_query("SELECT id, name,owner,seeders FROM torrents WHERE id IN (" . implode(", ", $_POST[delete]) . ")");
echo"The following torrents has been deleted:<br><br>";
while($row = mysql_fetch_array($res)) {
echo"ID: $row[id] - $row[name]<br>";
$reasonstr = "Dead: 0 seeders, 0 leechers = 0 peers total";
$text = "Torrent $row[id] ($row[name]) was deleted by $CURUSER[username] ($reasonstr)\n";
$added = sqlesc(get_date_time());
write_log("Torrent $row[id] ($row[name]) was deleted by $CURUSER[username] ($reasonstr)\n");

}
mysql_query("DELETE FROM $table where id IN (" . implode(", ", $_POST[delete]) . ")") or die(mysql_error());

}else{
echo"You are not allowed to view this page";
}}
?>

<? end_frame();
end_main_frame();
stdfoot(); ?>