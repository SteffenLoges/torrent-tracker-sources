<?php
loggedinorreturn();
stdhead("Unconfirmed Users");
begin_main_frame();
begin_frame("");
?>
<?
if (get_user_class() < UC_ADMINISTRATOR)
 die;
$res = mysql_query("SELECT * FROM users WHERE status='pending' ORDER BY username" ) or sqlerr();
if( mysql_num_rows($res) != 0 )
{
print'<br><table width=100% border=1 cellspacing=0 cellpadding=5>';
print'<tr>';
print'<td class=rowhead>Name</td>';
print'<td class=rowhead>Email</td>';
print'<td class=rowhead>Aangemaakt Op</td>';
print'<td class=rowhead>Activeren</td>';
print'<td class=rowhead>OK</td>';
print'</tr>';
while( $row = mysql_fetch_assoc($res) )
{
$id = $row['id'];
print'<tr><form method=post action=modtask.php>';
print'<input type=hidden name=\'action\' value=\'confirmuser\'>';
print("<input type=hidden name='userid' value='$id'>");
 print'<a href="userdetails.php?id=' . $row['id'] . '"><td>' . $row['username'] . '</td></a>';
 print'<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;' . $row['email'] . '</td>';
 print'<td align=left>&nbsp;&nbsp;&nbsp;&nbsp;' . $row['added'] . '</td>';
 print'<td align=left><select name=confirm><option value=pending>pending</option><option value=confirmed>confirmed</option></select></td>';
 print'<td align=left><input type=submit value="OK" style=\'height: 20px; width: 40px\'>';
 print'</form></tr>';
}
print '</table>';
}

?>
<? end_frame();?>
<? end_frame();
end_main_frame();
stdfoot();
?>