<?php
stdhead('php info');
phpinfo();
stdfoot();
?>