<?
loggedinorreturn();

if (get_user_class() < UC_SYSOP)
stderr("Error", "Permission denied.");

stdhead("Spam test");

$res = mysql_query("SELECT *FROM messages ORDER BY id DESC LIMIT 50") or sqlerr(__FILE__, __LINE__);
print("<h1>Spam test</h1>\n");
  print("<table border=1 cellspacing=0 cellpadding=5>\n");
  print("<tr><td class=colhead align=left>Sender</td><td class=colhead align=left>Receiver</td><td class=colhead align=left>Text</td></tr>\n");
  while ($arr = mysql_fetch_assoc($res))
  {
    $res2 = mysql_query("SELECT username FROM users WHERE id=" . $arr["receiver"]) or sqlerr();
    $arr2 = mysql_fetch_assoc($res2);
    $receiver = "<a href=userdetails.php?id=" . $arr["receiver"] . "><b>" . $arr2["username"] . "</b></a>";
    $res3 = mysql_query("SELECT username FROM users WHERE id=" . $arr["sender"]) or sqlerr();
    $arr3 = mysql_fetch_assoc($res3);
    $sender = "<a href=userdetails.php?id=" . $arr["sender"] . "><b>" . $arr3["username"] . "</b></a>";
             if( $arr["sender"] == 0 )
             $sender = "<font color=red><b>System</b></font>";
    $msg = format_comment($arr["msg"]);
  print("<tr><td>$sender</td><td>$receiver</td><td align=left>$msg</td></tr>\n");
  }
  print("</table>");
print("<p>Times are in GMT.</p>\n");
stdfoot();
?>