-- MySQL dump 9.10
--
-- Host: localhost    Database: bittorrent
-- ------------------------------------------------------
-- Server version	4.0.18-log

--
-- Dumping data for table `stylesheets`
--

INSERT INTO stylesheets VALUES (1,'default.css','(default)');
INSERT INTO stylesheets VALUES (2,'large.css','Large text');

CREATE TABLE `thanks` (
`torrentid` int(11) NOT NULL default '0',
`userid` int(11) NOT NULL default '0',
`id` int(11) NOT NULL auto_increment,
PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `iptoc` (
`ip_from` INT( 10 ) NOT NULL ,
`ip_to` INT( 10 ) NOT NULL ,
`country_code2` CHAR( 2 ) NOT NULL ,
`country_code3` CHAR( 3 ) NOT NULL ,
`country_name` VARCHAR( 50 ) NOT NULL
);

CREATE TABLE `usergroups` (
  `id` int(10) NOT NULL auto_increment,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `isbanned` enum('yes','no') NOT NULL default 'no',
  `canpm` enum('yes','no') NOT NULL default 'yes',
  `candwd` enum('yes','no') NOT NULL default 'yes',
  `canup` enum('yes','no') NOT NULL default 'no',
  `canreq` enum('yes','no') NOT NULL default 'yes',
  `canof` enum('yes','no') NOT NULL default 'yes',
  `canpc` enum('yes','no') NOT NULL default 'yes',
  `canvo` enum('yes','no') NOT NULL default 'yes',
  `canth` enum('yes','no') NOT NULL default 'yes',
  `canka` enum('yes','no') NOT NULL default 'yes',
  `canrp` enum('yes','no') NOT NULL default 'no',
  `canusercp` enum('yes','no') NOT NULL default 'yes',
  `canviewotherprofile` enum('yes','no') NOT NULL default 'yes',
  `canchat` enum('yes','no') NOT NULL default 'yes',
  `canmemberlist` enum('yes','no') NOT NULL default 'yes',
  `canfriendslist` enum('yes','no') NOT NULL default 'yes',
  `cantopten` enum('yes','no') NOT NULL default 'yes',
  `cansettingspanel` enum('yes','no') NOT NULL default 'no',
  `canstaffpanel` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;

INSERT INTO `usergroups` (`id`, `title`, `description`, `isbanned`, `canpm`, `candwd`, `canup`, `canreq`, `canof`, `canpc`, `canvo`, `canth`, `canka`, `canrp`, `canusercp`, `canviewotherprofile`, `canchat`, `canmemberlist`, `canfriendslist`, `cantopten`, `cansettingspanel`, `canstaffpanel`) VALUES 
(6, 'SysOp', 'Has the full power.', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes'),
(0, 'User', 'Simple User', 'no', 'yes', 'yes', 'no', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no'),
(1, 'Power User', 'The Class above user', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no'),
(2, 'Vip', 'If a user donated to the tracker, he is vip', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no'),
(3, 'Uploader', 'User with upload privileges.', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no'),
(4, 'Moderator', 'Can delete torrents,forum posts, etc...', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no'),
(5, 'Administrator', 'Almost full power :)', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no');

UPDATE usergroups SET id = '0' WHERE id='7';

CREATE TABLE `bonus` (
  `id` int(5) NOT NULL auto_increment,
  `bonusname` varchar(50) NOT NULL default '',
  `points` decimal(10,1) NOT NULL default '0.0',
  `description` text NOT NULL,
  `art` varchar(10) NOT NULL default 'traffic',
  `menge` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
);



INSERT INTO `bonus` VALUES (1, '1.0GB Uploaded', '75.0', 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 1073741824);
INSERT INTO `bonus` VALUES (2, '2.5GB Uploaded', '150.0', 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 2684354560);
INSERT INTO `bonus` VALUES (3, '5GB Uploaded', '250.0', 'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.', 'traffic', 5368709120);
INSERT INTO `bonus` VALUES (5, 'Custom Title!', '50.0', 'For only 50.0 Karma Bonus Points you can buy yourself a custom title. the only restrictions are no foul or offensive language or userclass can be entered. The points are then removed from your Bonus Bank and your special title is changed to the title of your choice', 'title', 1);
INSERT INTO `bonus` VALUES (6, 'VIP Status', '500.0', 'With enough bonus points acquired, you can buy yourself VIP status for one month. The points are then removed from your Bonus Bank and your status is changed.', 'class', 1);
INSERT INTO `bonus` VALUES (7, 'Give A Karma Gift', '100.0', 'Well perhaps you don\'t need the upload credit, but you know somebody that could use the Karma boost! You are now able to give your Karma credits as  a gift! The points are then removed from your Bonus Bank and  added to the account of a user of your choice!\r\n\r\nAnd they recieve a PM with all the info as well as who it came from...', 'gift_1', 1073741824);

ALTER TABLE `users` ADD `vip_added` enum('yes','no') NOT NULL default 'no';
ALTER TABLE `users` ADD `vip_until` datetime NOT NULL default '0000-00-00 00:00:00';
ALTER TABLE `users` ADD `seedbonus` decimal(10,1) NOT NULL default '0.0';
ALTER TABLE `users` ADD `bonuscomment` text NOT NULL;





