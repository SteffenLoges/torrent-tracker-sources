<?
$mysql_host = $_POST['host'];
$mysql_user = $_POST['user'];
$mysql_pass = $_POST['pass'];
$mysql_db = $_POST['db'];
define ('ROOT_PATH', './../');
	$txt = "<?php
/**
 * Daatabase configuration - FTS 1.2 FINAL
 */

\$mysql_host = '{$mysql_host}';
\$mysql_user = '{$mysql_user}';
\$mysql_pass = '{$mysql_pass}';
\$mysql_db = '{$mysql_db}';


 
?>";
$file = fopen(ROOT_PATH.'include/secrets.php', 'w');
$test = fwrite($file, $txt);
if(!$test)
die('Error. Maybe secrets.php its not writable');
	fclose($file);
header('Location: install.php?action=step2');
?>