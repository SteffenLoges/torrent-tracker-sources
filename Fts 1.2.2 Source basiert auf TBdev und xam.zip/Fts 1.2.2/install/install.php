<?
define ('IN_INSTALL', true);
define ('THIS_ROOT_PATH', './');
define ('ROOT_PATH', './../');
define('TRACKER_VERSION','FTS 1.2 FINAL');
define('INSTALL_VERSION','0.7 FINAL by fr33bh');
define ('TIMENOW', time());
define ('BIGDUMP_VERSION','0.24b');
define ('DATA_CHUNK_LENGTH',16384);
define ('MAX_QUERY_LINES',30000);

@set_magic_quotes_runtime(0);
@ignore_user_abort(1);
if (function_exists('set_time_limit') AND get_cfg_var('safe_mode') == 0)
{
	@set_time_limit(0);
}
@ini_set('auto_detect_line_endings', true);
define('INSTALL_URL', 'http://'.$_SERVER['HTTP_HOST']);
$rootpath = ROOT_PATH;
$shorthost =  $_SERVER["HTTP_HOST"];
$sh = preg_replace('/www./', '', $shorthost);

require_once(THIS_ROOT_PATH.'functions.php');
$action = isset($_POST['action']) ? htmlspecialchars($_POST['action']) : (isset($_GET['action']) ? htmlspecialchars($_GET['action']) : 'step0');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title><?=TRACKER_VERSION ?> INSTALLATION <?=INSTALL_VERSION ?></title>
<link rel="stylesheet" href="default.css" type="text/css">
</head>
<body>

<?
if ($action == 'step0') {
	step("Welcome to the installation wizard for ".TRACKER_VERSION.".","Welcome Screen","0");
?>

			<div class=alert2><p>Welcome to the installation wizard for <?=TRACKER_VERSION?>. This wizard will install and configure a copy of <?=TRACKER_VERSION?> on your server.</p>
<p>This guide will make all of your work. Will write the database config, will insert the mysql files in the db,etc.</p>			
</div>		

<div class=alert>
<form method='get' action='install.php'>
<div align=center>Please select installation type: 
<select name='action'>
<option value='step1'>Fresh Install</option>
</select>
<input type=submit value='START'></form>
</div>
</tr></td></div></table>
<?
}elseif ($action == 'step1') {
		step("Databse","Db","1");
	?>
<form action="insertdb.php" method="post"> 

Mysql Host: <input name="host" type="text" /> <BR>
Mysql User: <input name="user" type="text" /> <BR>
Mysql Password: <input name="pass" type="password" /> <BR>
Mysql Database: <input name="db" type="text" /> <BR>
<input type="submit" />
</form>
</body></html><?
}elseif ($action == 'step2') {
step("Inserting main database","2",true);
$installtype = 'install';
	include_once ('bigdump.php'); }elseif ($action == 'step3') {
step("Inserting countries and mods in database","3",true);
$installtype = 'install2';
	include_once ('bigdump.php'); }
elseif ($action == 'step4') {
step("Inserting stylesheets in database","4",true);
$installtype = 'install3';
	include_once ('bigdump.php'); }
elseif ($action == 'step5') {
Readconfig('MAIN');	
	step("Basic Tracker Setup","Tracker Setup","3");	
	print ("<form method='post' action='".$_SERVER["SCRIPT_NAME"]."'><input type='hidden' name='action' value='save_main'>");
	
	echo '<tr><td colspan="2" class="subheader" align="center">TRACKER/BOARD Online/Offline</td></tr>';
		tr("Tracker Online? ", "yes <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='site_online'" . ($MAIN["site_online"] == "no" ? " checked" : "") . " value='no'> <br />Want to turn off your Tracker while performing updates or other types of maintenance?<br />\n", 1);
tr("Disable Right Click ", "yes <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "yes" ? " checked" : " checked") . " value='yes'> no <INPUT type='radio' name='rcl'" . ($MAIN["rcl"] == "no" ? " checked" : "") . " value='no'> <br /> Do not allow users to right click<br />\n", 1);

	
	tr("Site Base Url ","<input type='text' id='specialboxes' name=baseurl value='".($MAIN["baseurl"] ? $MAIN["baseurl"] : "??" )."'> This url is verry important.\n", 1);

tr("Max Torrent Size ","<input type='text' id='specialboxes' name=maxtorentsize value='".($MAIN["maxtorentsize"] ? $MAIN["maxtorentsize"] : "" )."'> Recomended: 1000000.\n", 1);

tr("Announcee Interval ","<input type='text' id='specialboxes' name=annint value='".($MAIN["annint"] ? $MAIN["annint"] : "" )."'> Recomended: 60 * 60.\n", 1);

tr("Signup Timeout ","<input type='text' id='specialboxes' name=signt value='".($MAIN["signt"] ? $MAIN["signt"] : "" )."'> Recomended: 86400 * 3.\n", 1);

tr("Max torrent dead time ","<input type='text' id='specialboxes' name=max_dead_torrent_time value='".($MAIN["max_dead_torrent_time"] ? $MAIN["max_dead_torrent_time"] : "" )."'> Recomended: 6 * 3600.\n", 1);

tr("Max users ","<input type='text' id='specialboxes' name=max_users value='".($MAIN["max_users"] ? $MAIN["max_users"] : "" )."'> Recomended: 3000 or 5000.\n", 1);

tr("Torrent Dir ","<input type='text' id='specialboxes' name=torrent_dir value='".($MAIN["torrent_dir"] ? $MAIN["torrent_dir"] : "" )."'> Recomended: torrents.\n", 1);

tr("Announce url ","<input type='text' id='specialboxes' name=announce_url value='".($MAIN["announce_url"] ? $MAIN["announce_url"] : "" )."'> Recomended: http://".$_SERVER['HTTP_HOST']."/announce.php .\n", 1);

tr("Peer limit ","<input type='text' id='specialboxes' name=peerlimit value='".($MAIN["peerlimit"] ? $MAIN["peerlimit"] : "" )."'> Recomended: 5000 .\n", 1);

tr("Site email ","<input type='text' id='specialboxes' name=mail value='".($MAIN["mail"] ? $MAIN["mail"] : "" )."'> Recomended: noreply@".$_SERVER['HTTP_HOST']." .\n", 1);

tr("Site name ","<input type='text' id='specialboxes' name=name value='".($MAIN["name"] ? $MAIN["name"] : "" )."'> Nothing recomended .\n", 1);

tr("Autoclean interval ","<input type='text' id='specialboxes' name=acv value='".($MAIN["acv"] ? $MAIN["acv"] : "" )."'> Recomended: 900 .\n", 1);

tr("Pic base url ","<input type='text' id='specialboxes' name=picbu value='".($MAIN["picbu"] ? $MAIN["picbu"] : "" )."'> Recomended: pic/ .\n", 1);

tr("IMG Dir ","<input type='text' id='specialboxes' name=imgdir value='".($MAIN["imgdir"] ? $MAIN["imgdir"] : "" )."'> Recomended: pic/ .\n", 1);

	tr("Save settings","<input type='submit' name='save_main' value='SAVE MAIN SETTINGS AND GO NEXT STEP [PRESS ONLY ONCE]'>\n", 1);
	print ("</form>");

}elseif ($action == 'save_main') {
	step("Basic Tracker Setup (DONE!)","Tracker Setup","3");
		GetVar(array('site_online','rcl','baseurl','maxtorentsize','annint','signt','max_dead_torrent_time','max_users','torrent_dir','announce_url','peerlimit','mail','name','acv','picbu','imgdir'));
	$MAIN['site_online'] = $site_online;
$MAIN['rcl'] = $rcl;
$MAIN['baseurl'] = $baseurl;
$MAIN['maxtorentsize'] = $maxtorentsize;
$MAIN['annint'] = $annint;
$MAIN['signt'] = $signt;
$MAIN['max_dead_torrent_time'] = $max_dead_torrent_time;
$MAIN['max_users'] = $max_users;
$MAIN['torrent_dir'] = $torrent_dir;
$MAIN['announce_url'] = $announce_url;
$MAIN['peerlimit'] = $peerlimit;
$MAIN['mail'] = $mail;
$MAIN['name'] = $name;
$MAIN['acv'] = $acv;
$MAIN['picbu'] = $picbu;
$MAIN['imgdir'] = $imgdir;

	WriteConfig('MAIN', $MAIN);
	Print("MAIN Settings has been saved, please click <a href=install.php?action=step6>here</a> to go next step!"); }
elseif ($action == 'step6') {
step("Finishing the install","6",true);
?>
<div class=alert2><p>Congrats! You have succesfully installed a new version of FTS.<BR> Now, you must register as a user(and you will be made SysOp) and setup your source of FTS using the settings panel. Don't forget to remove the install directory nor your site won't work. <BR> Thanks for spending time with FTS and thanks for choosing us.</p>			
</div>	
<div class=alert><p>IMPORTANT!!!<BR> Delete the install directory. This is an security measure.<BR> Now register on tracker and your account will be SysOP. Don't forget to edit the settings to fit your needs.</p></div>
<div class=alert><p>Verry IMPORTANT!!!<BR>You have to put your mysql details in announce.php because the file is now modded and does not have connection with any config files. So modify your announce.php please. Thanks!</p></div>
<?
$serverinfo = @file_get_contents('http://lic.fr33bh.evolink.ro/urgent.txt');
if(!empty($serverinfo)) {
?>
<div class=alert>
<?echo $serverinfo;?>
</div>
<?
} }
?>