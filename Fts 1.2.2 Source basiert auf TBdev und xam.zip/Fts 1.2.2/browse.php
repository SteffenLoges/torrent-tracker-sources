<?php
require_once("include/bittorrent.php");

dbconn();
loggedinorreturn();


parked();

//$wherethisuser = where ($_SERVER["SCRIPT_FILENAME"],$CURUSER["id"]);
$cats = genrelist();

$searchstr = ($_GET['search'] ? unesc($_GET['search']) : '');
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
	unset($cleansearchstr);
if (isset($_GET['sort']) && isset($_GET['type'])) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
	case '1': $column = "name"; break;
	case '2': $column = "numfiles"; break;
	case '3': $column = "comments"; break;
	case '4': $column = "added"; break;
	case '5': $column = "size"; break;
	case '6': $column = "times_completed"; break;
	case '7': $column = "seeders"; break;
	case '8': $column = "leechers"; break;
	case '9': $column = "owner"; break;
	default: $column = "id"; break;
}

switch($_GET['type']) {
	case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
	case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
	default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
}

$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";

} else {
	$orderby = "ORDER BY torrents.id DESC";
	$pagerlink = "";
	}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
	$addparam .= "incldead=1&";
	if (!$CURUSER || get_user_class() < UC_ADMINISTRATOR)
		$wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
	$addparam .= "incldead=2&";
		$wherea[] = "visible = 'no'";
}
elseif ($_GET["incldead"] == 3)
{
	$addparam .= "incldead=3&";
	$wherea[] = "free = 'yes'";
	$wherea[] = "visible = 'yes'";
}
else
	$wherea[] = "visible = 'yes'";

$category = ($_GET["cat"] ? $_GET["cat"] : '');

$all = ($_GET["all"] ? $_GET["all"] : '');

if (!$all)
	if (!$_GET && $CURUSER['notifs'])
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $cat[id];
	    $mystring = $CURUSER['notifs'];
		$findme  = '[cat'.$cat['id'].']';
		$search = strpos($mystring, $findme);
		if ($search === false)
			$catcheck = false;
		else
			$catcheck = true;
			
	    if ($catcheck)
	    {
	      $wherecatina[] = $cat[id];
	      $addparam .= "c$cat[id]=1&";
	    }
	  }
	}
	elseif ($category)
	{
	  int_check($category,true,true,true);
	  $wherecatina[] = $category;
	  $addparam .= "cat=$category&";
	}
	else
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $_GET["c$cat[id]"];
	    if ($_GET["c$cat[id]"])
	    {
	      $wherecatina[] = $cat['id'];
	      $addparam .= "c$cat[id]=1&";
	    }
	  }
	}

if ($all)
{
	$wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
	$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
	$wherea[] = "category = $wherecatina[0]";

$wherebase = $wherea;

if ($cleansearchstr)
{
	$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";	
	$addparam .= "search=" . urlencode($searchstr) . "&";	
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
	$where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
	$where = "WHERE $where";

$res = sql_query("SELECT COUNT(*) FROM torrents $where") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && $cleansearchstr) {
	$wherea = $wherebase;
	$searcha = explode(" ", $cleansearchstr);
	$sc = 0;
	foreach ($searcha as $searchss) {
		if (strlen($searchss) <= 1)
			continue;
		$sc++;
		if ($sc > 5)
			break;
		$ssa = array();
		foreach (array("search_text", "ori_descr") as $sss)
			$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
		$wherea[] = "(" . implode(" OR ", $ssa) . ")";
	}
	if ($sc) {
		$where = implode(" AND ", $wherea);
		if ($where != "")
			$where = "WHERE $where";
		$res = sql_query("SELECT COUNT(*) FROM torrents $where");
		$row = mysql_fetch_array($res);
		$count = $row[0];
	}
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
	$torrentsperpage = 20;

if ($count)
{
	if ($addparam != "") {
 if ($pagerlink != "") {
  if ($addparam{strlen($addparam)-1} != ";") {
    $addparam = $addparam . "&" . $pagerlink;
  } else {
    $addparam = $addparam . $pagerlink;
  }
 }
    } else {
	$addparam = $pagerlink;
    }
	list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);

	$query = "SELECT torrents.id, torrents.category, torrents.leechers, torrents.seeders, torrents.name, torrents.times_completed, torrents.size, torrents.added, torrents.comments,torrents.numfiles,torrents.description,torrents.filename,torrents.anonymous,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
	"IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name,categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	"categories.name AS cat_name, categories.minclassread AS minclassread, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	$res = sql_query($query) or sqlerr(__FILE__, __LINE__);
}
else
	unset($res);

if ($cleansearchstr)
	stdhead('Search results for '.$searchstr);
else
	stdhead();

$catdropdown = "";
foreach ($cats as $cat) {
	if ($CURUSER['class'] < $cat['minclassread'])
			continue;
	$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
	if ($_GET['cat'])
		if ($cat['id'] == $_GET['cat'])
			$catdropdown .= " selected=\"selected\"";
	$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}
?>
<table border="10" cellpadding="0" cellspacing="0" width="96%">
<tr><td>
<form method="get" action="browse.php" name="search_form" id="search_form">
<?print(br1);?> <input type="text" name="search" autocomplete="off"  id="specialboxn" ondblclick="suggest(event.keyCode,this.value);" onkeyup="suggest(event.keyCode,this.value);" onkeypress="return noenter(event.keyCode);" value="<?= htmlspecialchars($searchstr) ?>" />
<select name="cat" style="width: 145px;">
<option value="0" style="color: gray;"><?print(br2);?></option>
<?=$catdropdown;?>
</select>
<input type="checkbox" name="incldead" value="1" <?=($_GET['incldead'] ? ' checked' : '')?>/> <?print(br3);?> 
<input type="submit" value="<?print(br4);?>" class="btn" />
<div style="left:83px; position: relative;">
<script language="JavaScript" src="<?=$BASEURL;?>/scripts/suggest_torrent_search.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 100%; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>
</form>
</tr></td>
<tr><td>
<form method="get" action="browse.php" name="categorysearch">
<table class=bottom>
<tr>
<td class=bottom>
	<table class=bottom>
	<tr>

<?
$i = 0;
foreach ($cats as $cat)
{
		/*if ($CURUSER['class'] < $cat['minclassread'])
			continue;*/
        $catsperrow = 5;
        print(($i && $i % $catsperrow == 0) ? "</tr><tr>" : "");
        print("<td class=bottom style=\"padding-bottom: 2px;padding-left: 5px\"><div align=\"right\"><a class=catlink href=browse.php?cat=$cat[id]>" . htmlspecialchars($cat['name']) . "</a><input name=c$cat[id] type=\"checkbox\" " . (in_array($cat['id'], $wherecatina) ? "checked " : "") . "value=\"1\"></div></td>\n");
        $i++;
}

$alllink = "<div align=left>(<a href=browse.php?all=1>".br5."</a>)</div>";

$ncats = count($cats);
$nrows = ceil($ncats/$catsperrow);
$lastrowcols = $ncats % $catsperrow;

if ($lastrowcols != 0)
{
	if ($catsperrow - $lastrowcols != 1)
		{
			print("<td class=bottom rowspan=" . ($catsperrow  - $lastrowcols - 1) . ">&nbsp;</td>");
		}
	print("<td class=bottom style=\"padding-left: 5px\">$alllink</td>\n");
}
?>
	</tr>
	</table>
</td>

<table class=main align=center>
	<tr>	
		<td class=bottom>			<select name="incldead" style="width: 145px;">
				<option value="0" style="color: gray;"><?print(br6);?></option>
				<option value="1"<? print($_GET["incldead"] == 1 ? " selected" : ""); ?>><?print(br7);?></option>
				<option value="2"<? print($_GET["incldead"] == 2 ? " selected" : ""); ?>><?print(br8);?></option>
<? /*				<option value="3"<? print($_GET["incldead"] == 3 ? " selected" : ""); ?>>Free</option>*/?>
			</select>
  	</td>
  	<td class=bottom>
  	<input type="submit" value="<?print(br9);?>" onlick="javascript:document.categorysearch.submit();" class=btn>
	<input type="button" value="<?print(br10);?>" onClick="this.value=check(form)" class="btn">  	
  	</td>
  </tr>
</table>
</td>
</tr>
</table>
</form>
<table>
<?print(br11);?>
<?

if (isset($cleansearchstr))
print("<h2>".br12." \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
        print($pagertop);

        torrenttable($res);

        print($pagerbottom);
}
else {
        if (isset($cleansearchstr)) {
                print("<h2>".br13."</h2>\n");
                print("<p>".br14."</p>\n");
        }
        else {
                print("<h2>".br15."</h2>\n");
                print("<p>".br16."</p>\n");
        }
}

if ($CURUSER)
// Torrents Needing Seeds mod
$need = mysql_query("SELECT id, name, leechers FROM torrents WHERE seeders = 0 AND leechers > 0 ORDER BY leechers DESC") or sqlerr();
if(mysql_num_rows($need))
{
echo("<h2>".br17.": $num</h2><table width=100% border=1 cellspacing=0 cellpadding=10><td align=left>");
while($res = mysql_fetch_assoc($need))
{
 echo("<a href=details.php?id=$res[id]><b>$res[name]</a> -<font color=red> ($res[leechers] leecher" . ($res[leechers] > 1 ? "s" : "") . ")</font></b><br>");
}


echo("</td></table>");
}

?>
<br>
<span style="color:green"><?print(br18);?></span>
</td></tr></table>
<?
sql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);
stdfoot();
?>
 