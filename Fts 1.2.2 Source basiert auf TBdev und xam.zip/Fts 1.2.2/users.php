<?
error_reporting( E_NONE );
require "include/bittorrent.php";

dbconn();
loggedinorreturn();
if($usergroups['canmemberlist'] == 'no')
print_ug();
stdhead("Users");
print("<script type=\"text/javascript\">
function parseSearch(){
var usernameStr = document.getElementById('searchbox').value;
var classObj = document.getElementById('classcombo');
var classNum = classObj.options[classObj.selectedIndex].value;
var query = 'action=member_search&search='+usernameStr+'&class='+classNum;
sndReq(query, 'searchresults');
}
</script>");
print("<h1>Users</h1>\n");
print("<form method=\"get\" action=\"\" name=\"usersearch\">\n");
print("Search: <input type=\"text\" size=\"30\" name=\"search\" id=\"searchbox\" onkeyup=\"parseSearch()\">\n");
print("<select name=\"class\" onchange=\"parseSearch()\" id=\"classcombo\">\n");
print("<option value='-'>(any class)</option>\n");
for ($i = 0;;++$i){
if ($c = get_user_class_name($i)){
print("<option value=$i" . ($class && $class == $i ? " selected" : "") . ">$c</option>\n");
} else{
break;
}
}
print("</select>\n");
print("<input type=\"submit\" value=\"Okay\">\n");
print("</form>\n");
print("<div id=\"searchresults\"></div>\n");
stdfoot();
die;
?>