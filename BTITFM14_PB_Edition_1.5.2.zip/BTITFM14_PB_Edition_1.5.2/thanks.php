<?
require_once("include/functions.php");
require_once("include/config.php");
dbconn(true);
$userid = $CURUSER["uid"];
$infohash = $_POST["infohash"];
if (isset($userid) && isset($infohash))
{
mysql_query("INSERT INTO thanks VALUES ('$infohash', '$userid')");
header("Location: $BASEURL/details.php?id=$infohash&thanks=1");
}
else {
header("Location: $BASEURL/details.php?id=$infohash");
}
?>