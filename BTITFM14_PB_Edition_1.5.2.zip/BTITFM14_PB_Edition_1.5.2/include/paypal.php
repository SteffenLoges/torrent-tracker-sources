<?
/* PayPal Configuration
 */

$GLOBALS["d_needed"] = "�150";
$GLOBALS["d_received"] = "�1";

?>