<?php
block_begin("Donate");
?>
<table align="center">
<tr>
<td align="center">
<a href="donate.php"><img src="images/donate.gif" border="0"></a>
</td>
</tr>
</table>
<?php
block_end();
?>
