<?php
//for direct access checking. no out of the box surprises!
define("VAR_SHOUT","ok");
//contact block control module
include("./shoutbox/sbb_control.php");
?>