</td>
<?php
if(mysql_query("SELECT * FROM blocks WHERE position='r'"))
right_menu();
?>
</tr>
<tr>
<td height="20%" colspan="2">
<?php

   //print("<p align=right>BtitTracker (Alpha3) by Btiteam</p>"); //mysql_stat());
?>
</td></tr>
</table>
</table>

