<?
$SBX['guest_post'] = "f";
$SBX['guest_view'] = "t";
$SBX['date'] = "d/m/Y H:i:s";
$SBX['guest'] = "Guest";
$SBX['deactivated'] = "f";
$SBX['allow_img'] = "t";
$SBX['shout_limit'] = "255";
$SBX['img_ban_message'] = "(IMAGE INSERTED)";
$SBX['sbmini_url'] = "index.php";
$SBX['limit'] = "20";
$SBX['layout'] = "default";
$SBX['import'] = "f";
$SBX['upgrade'] = "f";
?>