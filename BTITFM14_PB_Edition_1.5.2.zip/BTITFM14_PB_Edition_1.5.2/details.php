<?php
/********
Copyright � 2007 BTITeam.org. All Rights Reserved. 
PB Edition 1.5 Copyright � 2007 PantheraBits.com. All Rights Reserved. 
Do not remove the Copyright in footer!
********/
require_once("include/functions.php");
require_once("include/config.php");

dbconn();

//Fix Code added 06-07-2007
global $CURUSER;
if (!$CURUSER || $CURUSER["view_torrents"]=="no")
{
standardheader("Access Denied");
block_begin("Access Denied");
err_msg(ERROR,"You do not have permission to access this page");
block_end();
stdfoot();
exit();
}
else
{

standardheader('Torrent Details',($GLOBALS["usepopup"]?false:true));
?>
<script language=javascript>
function windowunder(link)
{
  window.opener.document.location=link;
  window.close();
}
</script>
<script type="text/javascript" src="js/mootools.js"></script>
<script type="text/javascript" src="js/slimbox.js"></script>
<script type="text/javascript" src="js/mootools.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/videobox.js"></script>
<link rel="stylesheet" href="css/slimbox.css" type="text/css" media="screen" />
<?php
block_begin(TORRENT_DETAIL);

$id = AddSlashes((isset($_GET["id"])?$_GET["id"]:false));
if (!isset($id) || !$id)
    die(ERROR_ID.": $id");

if (isset($_GET["act"]))
   {
       print("<center>".TORRENT_UPDATE."</center>");
       require_once("./include/getscrape.php");
       scrape(urldecode($_GET["surl"]),$id);
       redirect("details.php?id=$id");
       exit();
   }

if (isset($_GET["vote"]) && $_GET["vote"]==VOTE)
   {
if (isset($_GET["rating"]) && $_GET["rating"]==0)
{
   err_msg(ERROR,ERR_NO_VOTE);
     block_end();
     stdfoot(($GLOBALS["usepopup"]?false:true),false);
     exit();
}
else {
   @mysql_query("INSERT INTO ratings SET infohash='$id',userid=$CURUSER[uid],rating=".intval($_GET["rating"]).",added='".time()."'");
   redirect("details.php?id=$id");
}
   exit();
}

$res = mysql_query("SELECT namemap.genre, namemap.scene, namemap.info_hash, namemap.infosite, namemap.screen, namemap.screen2, namemap.video, namemap.dd, nfo, namemap.filename, namemap.url, UNIX_TIMESTAMP(namemap.data) as data, namemap.size, namemap.comment, namemap.requested, namemap.nuked, namemap.nuke_reason, namemap.uploader, categories.name as cat_name, summary.seeds, summary.leechers, summary.finished, summary.speed, namemap.external, namemap.announce_url,UNIX_TIMESTAMP(namemap.lastupdate) as lastupdate, namemap.anonymous, users.username FROM namemap LEFT JOIN categories ON categories.id=namemap.category LEFT JOIN summary ON summary.info_hash=namemap.info_hash LEFT JOIN users ON users.id=namemap.uploader WHERE namemap.info_hash ='" . $id . "'")
    or die(mysql_error());
$row = mysql_fetch_array($res);

if (!$row)
   die("Bad ID!");

$spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

print("<div align=center><table class=\"lista\" border=\"0\" cellspacing=\"5\" cellpadding=\"5\">\n");
//print("<tr><td align=\"right\" class=\"header\"> ".FILE_NAME.":</td><td class=\"lista\" align=\"center\">" . $row["filename"]. "</td></tr>\n");
print("<tr><td align=\"right\" class=\"header\"> ".FILE_NAME);

if ($CURUSER["uid"]==$row["uploader"] || $CURUSER["edit_torrents"]=="yes" || $CURUSER["delete_torrents"]=="yes")
    print("<br />&nbsp;&nbsp;");

// edit and delete picture/link
if ($CURUSER["uid"]==$row["uploader"] || $CURUSER["edit_torrents"]=="yes") {
      if ($GLOBALS["usepopup"])
        print("<a href=\"javascript: windowunder('edit.php?info_hash=".$row["info_hash"]."&amp;returnto=".urlencode("torrents.php")."')\">".image_or_link("$STYLEPATH/edit.png","",EDIT)."</a>&nbsp;&nbsp;");
      else
        print("<a href=edit.php?info_hash=".$row["info_hash"]."&amp;returnto=".urlencode("torrents.php").">".image_or_link("$STYLEPATH/edit.gif","",EDIT)."</a>&nbsp;&nbsp;");
}

if ($CURUSER["uid"]==$row["uploader"] || $CURUSER["delete_torrents"]=="yes") {
      if ($GLOBALS["usepopup"])
        print("<a href=\"javascript: windowunder('delete.php?info_hash=".$row["info_hash"]."&amp;returnto=".urlencode("torrents.php")."')\">".image_or_link("$STYLEPATH/delete.png","",DELETE)."</a>&nbsp;&nbsp;");
      else
        print("<a href=delete.php?info_hash=".$row["info_hash"]."&amp;returnto=".urlencode("torrents.php").">".image_or_link("$STYLEPATH/delete.gif","",DELETE)."</a>");
}

print("</td><td class=\"lista\" align=\"center\">" . $row["filename"]."</td></tr>\n");
print("<tr><td align=\"right\" class=\"header\"> ".TORRENT.":</td><td class=\"lista\" align=\"center\"><a class \"index\" <a href=\"download.php?id=".$row["info_hash"]."&f=" . rawurlencode($row["filename"]) . ".torrent\">" . $row["filename"] . "</a><br><small><a href=report.php?torrent=".$row["info_hash"]."><font color=Red>Report this torrent</font></a> <a href=wishlist.php?do=add&torrent_id=".$row["info_hash"]."><font color=Green>Add to wishlist</font></a></td></tr>\n");
print("<tr><td align=\"right\" class=\"header\"> ".INFO_HASH.":</td><td class=\"lista\" align=\"center\">" . $row["info_hash"]. "</td></tr>\n");
//Extra option hack start
if (!empty($row["infosite"]))
{
print("<tr><td align=\"right\" class=\"header\"> ".INFOSITE.":</td><td class=\"lista\" align=\"center\"><a target=\"blank\" href=\"".$row["infosite"]."\">".$row["infosite"]."</a></td></tr>\n");
}
if (!empty($row["screen"]))
{
print("<tr><td align=\"right\" class=\"header\"> ".SCREEN.":</td><td class=\"lista\" align=\"center\"><a href=\"".$row["screen"]."\" rel=\"lightbox[roadtrip]\"><img width=80 border=0 src=\"".$row["screen"]."\"></img></a></td></tr>\n");
}
if (!empty($row["screen2"]))
{
print("<tr><td align=\"right\" class=\"header\"> ".SCREEN.":</td><td class=\"lista\" align=\"center\"><a href=\"".$row["screen2"]."\" rel=\"lightbox[roadtrip]\"><img width=80 border=0 src=\"".$row["screen2"]."\"></img></a></td></tr>\n");
}
if (!empty($row["video"]))
{
print("<tr><td align=\"right\" class=\"header\"> ".VIDEO.":</td><td class=\"lista\" align=\"center\"><a href=\"".$row["video"]."\" rel=\"vidbox\"><center>Click Here to View the Video</center></a></td></tr>\n");
}
if (!empty($row["dd"]))
if (($CURUSER["id_level"])>"5")
{
print("<tr><td align=\"right\" class=\"header\"> ".DD.":</td><td class=\"lista\" align=\"center\"><a href=\"".$row["dd"]."\">".DD."</a></td></tr>\n");
}
//Extra option hack ends
if (!empty($row["nfo"])){
print("<tr><td align=right class=\"header\"> NFO:</td><td align=left class=\"lista\" ><a href=viewnfo.php?info_hash=" . $row["info_hash"]. "><b>View NFO</b></a></td></tr>\n");
}
if (!empty($row["comment"]))
   print("<tr><td align=\"right\" class=\"header\"> ".DESCRIPTION.":</td><td align=\"center\" class=\"lista\">" . format_comment($row["comment"]) . "</td></tr>\n");
if (isset($row["cat_name"]))
   print("<tr><td align=\"right\" class=\"header\"> ".CATEGORY_FULL.":</td><td class=\"lista\" align=\"center\">" . unesc($row["cat_name"]). "</td></tr>\n");
else
    print("<tr><td align=\"right\" class=\"header\"> ".CATEGORY_FULL.":</td><td class=\"lista\" align=\"center\">(nessuno)</td></tr>\n");
print("<tr><td align=\"right\" class=\"header\">".SCENE_RELEASE.":</td><td class=\"lista\" >".$row["scene"]."</td></tr>\n");
if(!empty($row['genre']))
print("<tr><td align=\"right\" class=\"header\">".GENRE.":</td><td class=\"lista\" >".$row["genre"]."</td></tr>\n");
//Requested/Nuked Torrent Hack Start - 13:36 08.08.2006
if ($row["requested"] == "true")
$req="".YES."";
else
$req="".NO."";

if ($row["nuked"] == "true")
$nuke="".YES."";
else
$nuke="".NO."";

   print("<tr><td align=right class=\"header\">".TORRENT_REQUESTED.":</td><td align=left class=\"lista\" >".$req."</td></tr>\n");

   print("<tr><td align=right class=\"header\">".TORRENT_NUKED.":</td><td align=left class=\"lista\" >".$nuke."</td></tr>\n");

if ($row["nuked"] == "true")
   print("<tr><td align=right class=\"header\">".TORRENT_NUKED_REASON.":</td><td align=left class=\"lista\" >".$row["nuke_reason"]."</td></tr>\n");
//Requested/Nuked Torrent Hack Stop
// rating
print("<tr><td align=\"right\" class=\"header\"> ".RATING.":</td><td class=\"lista\" align=\"center\">\n");

$vres = mysql_query("SELECT sum(rating) as totrate, count(*) as votes FROM ratings WHERE infohash = '$id'");
$vrow = @mysql_fetch_array($vres);
if ($vrow && $vrow["votes"]>=1)
   {
   $totrate=round($vrow["totrate"]/$vrow["votes"],1);
   if ($totrate==5)
      $totrate="<img src=\"$STYLEPATH/5.gif\" title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>4.4 && $totrate<5)
      $totrate="<img src=$STYLEPATH/4.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>3.9 && $totrate<4.5)
      $totrate="<img src=$STYLEPATH/4.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>3.4 && $totrate<4)
      $totrate="<img src=$STYLEPATH/3.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>2.9 && $totrate<3.5)
      $totrate="<img src=$STYLEPATH/3.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>2.4 && $totrate<3)
      $totrate="<img src=$STYLEPATH/2.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>1.9 && $totrate<2.5)
      $totrate="<img src=$STYLEPATH/2.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   elseif ($totrate>1.4 && $totrate<2)
      $totrate="<img src=$STYLEPATH/1.5.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   else
      $totrate="<img src=$STYLEPATH/1.gif title=\"$vrow[votes] ".VOTES_RATING.": $totrate/5.0)\" />";
   }
else
    $totrate=NA;

if ($row["username"]!=$CURUSER["username"] && $CURUSER["uid"]>1)
   {
   $ratings = array(5 => FIVE_STAR,4 => FOUR_STAR,3 => THREE_STAR,2 => TWO_STAR,1 => ONE_STAR);
   $xres = mysql_query("SELECT rating, added FROM ratings WHERE infohash = '$id' AND userid = " . $CURUSER["uid"]);
   $xrow = @mysql_fetch_array($xres);
   if ($xrow)
       $s = $totrate. " (".YOU_RATE." \"" . $ratings[$xrow["rating"]] . "\")";
   else {
       $s = "<form method=\"get\" action=\"details.php\" name=\"vote\">\n";
       $s .= "<input type=\"hidden\" name=\"id\" value=\"$id\" />\n";
       $s .= "<select name=\"rating\">\n";
       $s .= "<option value=\"0\">(".ADD_RATING.")</option>\n";
       foreach ($ratings as $k => $v) {
           $s .= "<option value=\"$k\">$v</option>\n";
       }
       $s .= "</select>\n";
       $s .= "<input type=\"submit\" name=\"vote\" value=\"".VOTE."\" />";
       $s .= "</form>\n";
       }
}
else
    {
    $s = $totrate;
}
print $s;
print("</td></tr>\n");
print("<tr><td align=right class=\"header\"> ".SIZE.":</td><td class=\"lista\" align=\"center\">" . makesize($row["size"]). "</td></tr>\n");
// files in torrent - by Lupin 20/10/05

?>
<script type="text/javascript" language="JavaScript">
function ShowHide(id,id1) {
    obj = document.getElementsByTagName("div");
    if (obj[id].style.display == 'block'){
     obj[id].style.display = 'none';
     obj[id1].style.display = 'block';
    }
    else {
     obj[id].style.display = 'block';
     obj[id1].style.display = 'none';
    }
}

</script>
<?php

require_once(dirname(__FILE__)."/include/BDecode.php");
if (file_exists($row["url"]))
  {
    print("
    <tr>
    <td align=\"right\" class=\"header\" valign=\"top\">
    <a name=\"#expand\" href=\"#expand\" onclick=\"javascript:ShowHide('files','msgfile');\">Show/Hide Files: </td>
    <td align=\"left\" class=\"lista\">
    <div name=\"files\" style=\"display:none\" id=\"files\">
        <table class=\"lista\">
        <tr>
        <td align=\"center\" class=\"header\">".FILE_NAME."</td>
        <td align=\"center\" class=\"header\">".SIZE."</td>
        </tr>");
    $ffile=fopen($row["url"],"rb");
    $content=fread($ffile,filesize($row["url"]));
    fclose($ffile);
    $content=BDecode($content);
    $numfiles=0;
    if (isset($content["info"]) && $content["info"])
      {
        $thefile=$content["info"];
        if (isset($thefile["length"]))
          {
          $numfiles++;
          print("\n<tr>\n<td align=\"left\" class=\"lista\">".htmlspecialchars($thefile["name"])."</td>\n<td align=\"right\" class=\"lista\">".makesize($thefile["length"])."</td></tr>\n");
          }
        elseif (isset($thefile["files"]))
         {
           foreach($thefile["files"] as $singlefile)
             {
               print("\n<tr>\n<td align=\"left\" class=\"lista\">".htmlspecialchars(implode("/",$singlefile["path"]))."</td>\n<td align=\"right\" class=\"lista\">".makesize($singlefile["length"])."</td></tr>\n");
               $numfiles++;
             }
         }
       else
         {
           print("\n<tr>\n<td colspan=\"2\">no data...</td></tr>\n");   // can't be but...
         }
     }
    print("</table></div>
    <div name=\"msgfile\" style=\"display:block\" id=\"msgfile\" align=\"center\">$numfiles".($numfiles==1?" file":" files")."</div>
    </td></tr>\n");
  }
// end files in torrents
include("include/offset.php");
print("<tr><td align=\"right\" class=\"header\"> ".ADDED.":</td><td class=\"lista\" align=\"center\">" . date("d/m/Y",$row["data"]-$offset). "</td></tr>\n");

if ($row["anonymous"]=="true")
{
   if ($CURUSER["edit_torrents"]=="yes")
       $uploader="<a href=userdetails.php?id=".$row['uploader'].">".TORRENT_ANONYMOUS."</a>";
   else
      $uploader=TORRENT_ANONYMOUS;
   }
else
    $uploader="<a href=userdetails.php?id=".$row['uploader'].">".$row["username"]."</a>";

print("<tr><td align=\"right\" class=\"header\"> ".UPLOADER.":</td><td class=\"lista\" >$uploader" . Warn_disabled($row['uploader']) . "</td></tr>\n");

if ($row["speed"] < 0) {
  $speed = "N/D";
}
else if ($row["speed"] > 2097152) {
  $speed = round($row["speed"]/1048576,2) . " MB/sec";
}
else {
  $speed = round($row["speed"] / 1024, 2) . " KB/sec";
}

print("<tr><td align=\"right\" class=\"header\"> ".SPEED.":</td><td class=\"lista\" align=\"center\">" . $speed . "</td></tr>\n");
print("<tr><td align=\"right\" class=\"header\"> ".DOWNLOADED.":</td><td class=\"lista\" align=\"center\"><a href=torrent_history.php?id=".$row["info_hash"].">" . $row["finished"] . "</a> " . X_TIMES. "</td></tr>\n");
//Reqseed Start
if ($row["seeds"] == 0 && $row["external"]=="no")
{
	print("<tr><td align=right class=\"header\">Request Reseed:</td><td class=\"lista\"  align=\"left\" ><a href=reseed.php?id=" . $row["info_hash"]. ">".image_or_link("images/reseedbutton.png","","Req Seed")."</a></td></tr>\n");
}
//print("<tr><td align=right class=\"header\">Req Seed:</td><td class=\"lista\" ><a href=reseed.php?id=" . $row["info_hash"]. ">".image_or_link("images/seed.png","","Req Seed")."</a></td></tr>\n");
//Reqseed Ends
// snatchers
print("<tr><td align=right class=\"header\"> ".SNATCHERS.":</td><td class=\"lista\">");
  $sres = mysql_query("SELECT * FROM history WHERE infohash = '$id'");
  $line=0;
  while ($srow = mysql_fetch_array($sres)) {
$res =mysql_query("SELECT prefixcolor, suffixcolor, users.id, username,level FROM users INNER JOIN users_level ON users.id_level=users_level.id WHERE users.id='".$srow["uid"]."'") or die(mysql_error());
$result=mysql_fetch_array($res);
print("<a href=userdetails.php?id=$result[id]>".unesc($result["prefixcolor"]).unesc($result["username"]).unesc($result["suffixcolor"])."</a>, ");
$line++;
if ($line>6){
print ("<br>");
$line=0;
}
}
print("</td></tr>\n");
//end
print("<tr><td align=\"right\" class=\"header\"> ".PEERS.":</td><td class=\"lista\" align=\"center\"> ".SEEDERS.": <a href=peers.php?id=".$row["info_hash"].">" . $row["seeds"] . "</a>, ".LEECHERS.": <a href=peers.php?id=".$row["info_hash"].">" . $row["leechers"] ."</a> = <a href=peers.php?id=".$row["info_hash"].">" . ($row["leechers"]+$row["seeds"]) . "</a> ".PEERS."</td></tr>\n");
if ($row["leechers"]+$row["seeds"] == 0) {
print("<tr><td align=right class=\"header\"> Statistic: </td><td class=\"lista\" >Not available!</td></tr>");
}
else {
print("<tr><td align=right class=\"header\"> Statistic: </td><td class=\"lista\" ><img src=stat.php?id=".$row["info_hash"]."></td></tr>");
}
if ($row["external"]=="yes")
   {
       print("<tr><td valign=\"middle\" align=\"right\" class=\"header\"><a href=details.php?act=update&id=".$row["info_hash"]."&surl=".urlencode($row["announce_url"]).">".UPDATE."</a></td><td class=\"lista\" align=\"center\"><b>EXTERNAL</b><br />".$row["announce_url"]."</td></tr>\n");
       print("<tr><td valign=\"middle\" align=\"right\" class=\"header\">".LAST_UPDATE."</td><td class=\"lista\" align=\"center\">".get_date_time($row["lastupdate"])."</td></tr>\n");
   }
//Thanks Hack by Larkspeed
print("<tr><td align=right class=\"header\">Thanks:</td><td class=\"lista\" >");
$user = $CURUSER["uid"];
$uploaderres = mysql_query("SELECT uploader FROM namemap AS uploader WHERE info_hash = '$id'");
$uploaderrow = mysql_fetch_array($uploaderres);
$sres = mysql_query("SELECT * FROM thanks WHERE infohash = '$id' AND userid = '$user'");
$srow = mysql_fetch_array($sres);
if ($srow["userid"]==0 && $uploaderrow["uploader"]!=$user)
{
 print("<form action=\"thanks.php\" method=\"post\">");
 print("<input type=\"submit\" name=\"submit\" value=\"Say Thanks!\">");
 print("<input type=\"hidden\" name=\"infohash\" value=\"$id\">");
 print("</form>");
}
$sres = mysql_query("SELECT * FROM thanks WHERE infohash = '$id'");
while ($srow = mysql_fetch_array($sres))
{
$res =mysql_query("SELECT prefixcolor, suffixcolor, users.id, username,level FROM users INNER JOIN users_level ON users.id_level=users_level.id WHERE users.id='".$srow["userid"]."'") or die(mysql_error());
$result=mysql_fetch_array($res);
print("<a href=userdetails.php?id=$result[id]>".unesc($result["prefixcolor"]).unesc($result["username"]).unesc($result["suffixcolor"])."</a>, ");
}
print("</td></tr>\n");
// End
print("</table>\n");
print("<a name=\"comments\" /></a>");
// comments...
$subres = mysql_query("SELECT avatar, comments.id, text, UNIX_TIMESTAMP(added) as data, user, users.id as uid, users.custom_title, users.id_level FROM comments LEFT JOIN users ON comments.user=users.username WHERE info_hash = '" . $id . "' ORDER BY added ASC");
if (!$subres || mysql_num_rows($subres)==0) {
   if($CURUSER["uid"]>1)
       $s = "<br /><br />\n<table width=\"95%\" class=\"lista\">\n<tr>\n<td align=\"center\">\n<a href=comment.php?id=" . $id . "&usern=".urlencode($CURUSER["username"]).">".NEW_COMMENT."</a>\n</td>\n</tr>\n";
   else
       $s = "<br /><br />\n<table width=\"95%\" class=\"lista\">\n";
       $s .= "<tr>\n<td class=\"lista\" align=\"center\">".NO_COMMENTS."</td>\n</tr>\n";
       $s .= "</table>\n";
}
else {
     print("<br /><br />");
     if($CURUSER["uid"]>1)
       $s = "<br /><br />\n<table width=\"95%\" class=\"lista\"><tr><td colspan=\"3\" align=\"center\"><a href=comment.php?id=" . $id . "&usern=".urlencode($CURUSER["username"]).">".NEW_COMMENT."</a></td></tr>\n";
     else
         $s = "<br /><br />\n<table width=95% class=lista>\n";
     while ($subrow = mysql_fetch_array($subres)) {
//Custom Title System Hack Start
$level = mysql_query("SELECT level FROM users_level WHERE id_level='$subrow[id_level]'");
$lvl = mysql_fetch_assoc($level);

if (!$subrow[uid])
        $title = "orphaned";
elseif (!"$subrow[custom_title]")
        $title = "".$lvl['level']."";
else
        $title = unesc($subrow["custom_title"]);
//Custom Title System Hack Stop
       $s .= "<tr><td class=\"header\"><a href=userdetails.php?id=".$subrow["uid"].">" . $subrow["user"] . "</a>" . Warn_disabled($subrow['uid']) . " (".$title.")</td><td class=\"header\">" . date("d/m/Y H.i.s",$subrow["data"]) . "</td>\n";
       // only users able to delete torrents can delete comments...
       if ($CURUSER["delete_torrents"]=="yes")
         $s .= "<td class=\"header\" align=\"right\"><a onclick=\"return confirm('". str_replace("'","\'",DELETE_CONFIRM)."')\" href=\"comment.php?id=$id&cid=" . $subrow["id"] . "&action=delete\">".image_or_link("$STYLEPATH/delete.png","",DELETE)."</a></td>\n";
       $s .="</tr>\n";
       $s .= "<tr><td class=lista width=15% align=center><img width=150 border=0 src=".($subrow["avatar"])."></td><td valign=\"top\" colspan=\"3\" class=\"lista\">" . format_comment($subrow["text"]) . "</td></tr>\n";
        }
        $s .= "</table>\n";
}
print($s);

if ($GLOBALS["usepopup"])
    print("</div><br /><br /><center><a href=\"javascript: window.close();\">".CLOSE."</a>");
else
    print("</div><br /><br /><center><a href=\"javascript: history.go(-1);\">".BACK."</a>");
print("</center>\n");

block_end();
stdfoot(($GLOBALS["usepopup"]?false:true),false);
}
?>