<?php
//for direct access checking. no out of the box surprises!
define("VAR_SHOUT","ok");
//call main script and run it
include("shoutbox/index.php")
?>