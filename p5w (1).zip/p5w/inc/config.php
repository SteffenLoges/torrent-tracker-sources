<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
# Gzip
ob_start("ob_gzhandler");

# Database
$mysql_host = "localhost";
$mysql_user = "user";
$mysql_pass = "passwd";
$mysql_db   = "p5w";

# Charset 
ini_set('default_charset', "UTF-8");

# True Site Online, False Site Offline
$GLOBALS["SITE_ONLINE"]=True;

# Base Url
$GLOBALS["BASEURL"] = "http://192.168.1.2";

#Tracker Announce URLS
$GLOBALS["ANNOUNCE_URLS"] = array();
$GLOBALS["ANNOUNCE_URLS"][] = "http://192.168.1.2/announce.php";
$GLOBALS["ANNOUNCE_URLS"][] = "https://192.168.1.2/announce.php";

# Announce URL with UserKey placeholder
$GLOBALS["PASSKEY_ANNOUNCE_URL"] = "http://192.168.1.2/announce.php?userkey=%KEY%";





###################################ANNOUNCE PHP#####################################

# Reannounce interval suggested to clients.
# Do not set this lower than about 20 minutes (1200 sec.), since some clients
# do not honour this value, and rather do their reannounces at 30 minute (1800 sec.)
# intervals. This would result in concurrent timeouts for these peers.
$GLOBALS["ANNOUNCE_INTERVAL"] = 1800;
$GLOBALS["MIN_ANNOUNCE_INTERVAL"] = 60;


# WRITE USERS AND PEER VALUES TO DATABASE every xx sec.
$GLOBALS["USERS_DB_WRITE_INTERVAL"] = 22;

# WRITE COMPLETED TORRENTS AND TRAFFIC TO DATABASE every xx sec.
$GLOBALS["COMPLETED_DB_WRITE_INTERVAL"] = 65;

####################################################################################





# TRACKER FILES DIRECTORY (/var/www/p5w)
$GLOBALS["TRACKER_DIR"] = "/var/www/p5w";

# Site Name
$GLOBALS["SITENAME"] = "P5W Tracker-1.0.0";


# Jquery Version
$GLOBALS["JQUERY"] = "jquery-1.7.1.min.js";


# Max. Users
$GLOBALS["MAX_USERS"] = 5000;


# CLEAN TIME FOR TORRENT STATS AND OLD PEERS (32 min.)
$GLOBALS["CLEAN_TIME1"] = 32 * 60;


# CLEAN TIME FOR DISABLED OR INACTIVE USER ACCOUNTS AND OTHER MYSQL DB CLEANS. EVERY (14 hours)
$GLOBALS["CLEAN_TIME2"] = 14 * 3600;


# Signup Upload Gift (GB)
$GLOBALS["SIGNUP_UPLOAD_GIFT"] = 5 * (1024 * 1024 * 1024);


# Site Root Email Adress
$GLOBALS["SITEEMAIL"]="root@p5wtracker.com";


# Site Noreply Email Adress
$GLOBALS["NOREPLY_SITEEMAIL"]="noreply@p5wtracker.com";


# Torrents Directory
$GLOBALS["TORRENT_DIR"] = "torrents";


# Maximum size for uploaded .torrent files, default is 1 MB
$GLOBALS["MAX_TORRENT_SIZE"] = 1 * 1024 * 1024;


# Path where all XimgDepot files are stored.
$GLOBALS["XIMGDEPOT_DIR"] = "ximgdepot";


# Maximum size of files uploaded into the XimgDepot in bytes
$GLOBALS["MAX_XIMGDEPOT_UPLOAD_SIZE"] = 784 * 1024;


# Maximum size of the ImgDepot per user in bytes
$GLOBALS["MAX_XIMGDEPOT_SIZE_USER"] = 20 * 1024 * 1024;


# Maximum size of the XimgDepot for uploaders in bytes
$GLOBALS["MAX_XIMGDEPOT_SIZE_UPLOADER"] = 50 * 1024 * 1024;


# Relative or absolute URL where all images for the interface are stored.
$GLOBALS["IMAGES_DIR"] = "images/";


# Delete Messages older than 21 days
$GLOBALS["DEL_MESSAGES_DAY"] = 21;


# Delete Messages Check every x hours
$GLOBALS["DEL_MESSAGES_CHECK"] = 18;


# XIMGDEPOT PUBLIC IMAGE PERPAGE
$GLOBALS["XIMGDEPOT_PUB_PERPAGE"] = 50;


# Messages Perpage Limit
$GLOBALS["MESSAGE_PER_PAGE"]=20;


# UserHistory Perpage Limit
$GLOBALS["USERHISTORY_PER_PAGE"]=20;


# TORRENTS PERPAGE
$GLOBALS["TORRENTS_PERPAGE"] = 20;


# MAX TORRENTS PERPAGE
$GLOBALS["MAX_TORRENTS_PERPAGE"] = 32;


# COMMENTS PERPAGE in DETAILS
$GLOBALS["COMMENTS_PERPAGE"] = 10;


# MAX COMMENTS PERPAGE in DETAILS
$GLOBALS["MAX_COMMENTS_PERPAGE"] = 20;


# Max User Warnpoints for Ban [Max. 256 points]
$GLOBALS["MAX_USER_WARN_POINTS"]=11;


# BROWSE CATEGORIES IN SEARCH
$GLOBALS["BROWSE_CATS_PER_ROW"] = 6;


# DELETE INACTIVE PEERS TIME
$GLOBALS["DEL_PEERS_TIME"] = $GLOBALS["ANNOUNCE_INTERVAL"] * 1.3;


# Max signup timeout (hours). Time given to an user to activate his/her account
$GLOBALS["SIGNUP_TIMEOUT"] = 36 * 3600;


# Max inactive timeout (days) Period of inactivity/no logins after an user is deleted
$GLOBALS["INACTIVE_TIMEOUT"] = 42 * 86400;


# Max disabled timeout (days) Period of time after a disabled user is deleted
$GLOBALS["DISABLED_TIMEOUT"] = 3 * 86400;


# DELETE 1 WARNPOINT EVERY X DAYS IF WARNPOINT EXISTS
$GLOBALS["DEL_WARN_TIME"] = 21 * 86400;


# PROMOTE POWER USERS LIMIT (GB)
$GLOBALS["PRO_POWER_USERS_LIMIT"] = 25 * 1024 * 1024 * 1024;


# PROMOTE POWER USERS RATIO 
$GLOBALS["PRO_POWER_USERS_RATIO"] = 1.05;


# DEMOTE POWER USERS RATIO
$GLOBALS["DEMOTE_POWER_USERS_RATIO"] = 0.95;


# MAX DEAD TORRENT TIMEOUT (DAYS). TIME AFTE WHICH TORRENTS WITH 0 PEERS ARE MARKED AS DEAD (INVISIBLE)
$GLOBALS["MAX_DEAD_TORRENT_TIME"] = 2 * 86400;


# Max torrent TTL (days, 0 to disable)
# Time after which torrents are automatically deleted
$GLOBALS["MAX_TORRENT_TTL"] = 28 * 86400;


# DELETE NOT ACTIVATED TORRENTS AFTER X DAYS (2 DAYS)
$GLOBALS["MAX_NOTACTIVATED_TOR_TIME"] = 2 * 86400;


# USER SEEDBONUS PER HOUR
$GLOBALS["SEEDBONUS"] = 1;


# TORRENT THUMBNAIL WIDTH 150 PX
$GLOBALS["TOR_THUMB_WIDTH"] = 150;


# USER AVATAR WIDTH 110 PX
$GLOBALS["USER_AVATAR_WIDTH"] = 110;


# SHOUTBOX ENABLE=1 DISABLE=0
$GLOBALS["SHOUTBOX"] = 1;


# Seed Speed
$seederspeed=array("1024","512","450","400","300","350","300","250","200","150","125","100","90","75","60","50","20");

# Torrent Audio AND Subtitle
$torrentlang=array("de" => "Deutsch","en" => "Englisch","fr" => "Französisch","it" => "Italienisch","jp" => "Japanisch","sp" => "Spanisch");


# User levels
define ("UC_USER", 10);
define ("UC_POWER_USER", 15);
define ("UC_VIP", 20);
define ("UC_UPLOADER", 25);
define ("UC_GUTEAM", 30);
define ("UC_MODERATOR", 35);
define ("UC_ADMIN", 50);
define ("UC_ROOT", 100);

# User Class No.
function get_user_class()
{
    global $CURUSER;
    return $CURUSER["class"];
} 

# User Class Name
function get_user_class_name($class)
{
    switch ($class) {
        case UC_USER: return "User";
        case UC_POWER_USER: return "Power User";
        case UC_VIP: return "VIP";
        case UC_UPLOADER: return "Uploader";
        case UC_GUTEAM: return "GU-Betreuer";
        case UC_MODERATOR: return "Moderator";
        case UC_ADMIN: return "Admin";
        case UC_ROOT: return "RooT";
    } 
    return "";
}


//// Convert special characters ////
function htmlchar($x,$x2=1)
{
	if($x2){
	    $x = htmlspecialchars($x);
	    $x = stripslashes($x);
	    $x = strip_tags($x);
	    $banlist = array ("'", "%", "$", "--", "*", ">", "\"", "<",'"', "|", "~");
	    $replace = array("", "\\%", "" , ""  , "" , "" , ""  , "" , "", "" , "", "");
	    $x = str_ireplace($banlist, $replace, $x);
	}else{
	   $x = stripslashes($x);
        }
return $x;
}


function sqlesc($x)
{
    return "'" . mysql_real_escape_string($x) . "'";
} 

function sqlesc2($x)
{
    return mysql_real_escape_string($x);
} 


function sqlwildcardesc($x)
{
    return str_replace(array("%", "_"), array("\\%", "\\_"), mysql_real_escape_string($x));
} 

?>