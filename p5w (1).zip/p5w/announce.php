<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
ini_set('display_errors', "Off");
require("inc/benc.php");
require("inc/funcann.php");

$agent = htmlchar($_SERVER["HTTP_USER_AGENT"]);

// Deny access made with a browser...
if(preg_match('%^Mozilla/|^Opera/|^Links |^Lynx/%i', $agent) || isset($_SERVER['HTTP_COOKIE']) || isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) || isset($_SERVER['HTTP_ACCEPT_CHARSET']))
   {
      		  die("<br><div align=\"center\" style=\"margin: 0 auto;padding:16px;background:#D40000;font-size:20px;border:1px solid #A1A1A1;width:520px;	
		       -moz-border-radius:6px;-webkit-border-radius:6px;\">
		       <font color=\"#FFFFFF\"><b>...::: Access with a browser not allowed :::...</b></font>
		       </div>");
      }



 $clireq = array("info_hash","peer_id","port","uploaded","downloaded","left","event","userkey","compact");


  foreach($clireq as $x)
  {
      if(isset($_GET[$x])){
	      $GLOBALS[$x] = htmlchar($_GET[$x],0);
	    }
	      else{
		$GLOBALS[$x] = "";
	      }
  }

if(!$compact){
    err(' Fehler => Sorry, this tracker no longer supports non-compact clients!');
 }

    # CHECK INFO_HASH
      if(strlen($info_hash) != 20){
	  err("Fehler => Ungueltiger Wert fuer INFO_HASH (" . strlen($info_hash) . ")");
         }

    # CHECK PEER_ID
      if(strlen($peer_id) != 20){
 	  err("Fehler => Ungueltiger Wert fuer PEER_ID (" . strlen($peer_id) . ")");
         }

    # CHECK USERKEY
      if(strlen($userkey) != 14){
	  err("Fehler => Ungueltiger Wert fuer USERKEY (" . strlen($userkey) . ")");
         }


  $nwant = 50;

  foreach(array("num want", "numwant", "num_want") as $k)
  {
      if(isset($_GET[$k])){
	  $nwant = 0 + $_GET[$k];
	  break;
      }
  }

  if(!$port || $port > 0xffff){
      err("Fehler => Ungueltiges TCP-Port");
    }

  $ip = ipe(getip());
  $port =  0 + $port;
  $downloaded = 0 + $downloaded;
  $uploaded = 0 + $uploaded;
  $left = 0 + $left;



 $seeder = 0;

  if(!$left){
       $seeder = 1;
    }


        if(portblacklisted($port)){
            err("Fehler => Der TCP-Port $port ist nicht erlaubt.");
           }
        else
        {
            $sockres = fsockopen(getip(), $port, $errno, $errstr, 4);
            if(!$sockres){
                $connectable = 0;
	     }
	      else
	      {
		  $connectable = 1;
		  fclose($sockres);
	      }
        }

 $info_hashmd5 = md5($info_hash);

 $user = apc_fetch("us_$userkey");
 $torrent = apc_fetch("tor_$info_hashmd5");
 $client = apc_fetch("clients");

# CHECK

  if(!$connectable){
	err("Fehler => Port $port nicht erreichbar, Firewall-Einstellung überprüfen!!");
    }

  if(!$user){
	err("Fehler => Unbekannte Userkey!!");
    }

  if(!$torrent){
	err("Fehler => Torrent Existiert Nicht!! ");
    }

  if($torrent["vip"] && $user["class"] < UC_VIP){
	err("Fehler => VIP Torrent !! ");
    }      

dbconn();

  if(!isset($client[$agent])){
	  mysql_query("INSERT INTO clients (agent,addtime) VALUES (".sqlesc($agent).", $time)");
	  add_clients_to_ram();
      	err("Fehler => Sie benutzen Tracker nicht bekannte Client.Neue Clients werden Automatisch Gebannt !! Lies FAQ");
    }
      else if($client[$agent] == "1"){
	    err("Fehler => Client $agent ist Gebannt !! ");
	}


##################################################################################################################################################################

  $tot_uspeer_res=mysql_query("SELECT SUM(IF(tleft=0, 1, 0)), SUM(IF(tleft > 0, 1, 0)) FROM peers WHERE puid = ".$user["uid"]);
  $tot_uspeer_row=mysql_fetch_row($tot_uspeer_res);

    if($user["tmaxseeds"] && $tot_uspeer_row[0] >= $user["tmaxseeds"]){
	  err("Fehler => Max. Torrent Seeds Erreicht (Max. ".$user["tmaxseeds"].")!!");   
	}

    if($user["tmaxleechs"] && $tot_uspeer_row[1] >= $user["tmaxleechs"]){
	 err("Fehler => Max. Torrent Leechs Erreicht (Max ".$user["tmaxleechs"].") !!");
       }






 $upload_time = 0;
 $download_time = 0;
 $downthis = $downloaded;
 $upthis = $uploaded;
 $interval = 0;
 $downspeed = 0;
 $upspeed = 0;
 $comptime = 0;
 $seedbonus = 0;

	$pu_res = mysql_query("SELECT downloaded, uploaded, lastaction FROM peers WHERE puid = ".$user["uid"]." AND ptid = ".$torrent["tid"]);
	$pu_row = mysql_fetch_row($pu_res);

	  if($pu_row){
		$downthis = max(0, $downloaded - $pu_row[0]);
		$upthis = max(0, $uploaded - $pu_row[1]);
		$interval = $time - $pu_row[2];
		$downspeed = max(0, $downthis / $interval);
		$upspeed = max(0, $upthis / $interval);
	    }

		$user_upthis = $upthis;
		$user_downthis = $downthis;

		  # ONLYUP
		      if($torrent["onlyup"]){
			  $user_downthis = 0;
		      }

		  # DOUBLEUP
		      if($torrent["doubleup"]){
			  $user_upthis = $upthis * 2;
		      }

		  # TORRENT COMPLETE TIME
		      if($event == "completed") {
			    $comptime = $time;
			  }

		  # UPLOAD / DOWNLOAD TIME
		      if($seeder){
		      $upload_time = $interval;
		      }
		      else{
			$download_time = $interval;
		      }  


		  # SEEDBONUS
		      if($seeder && $event != "completed"){
			  $seedbonus = $GLOBALS["SEEDBONUS"] / 3600;
			  $seedbonus = round($interval * $seedbonus,2);
			}

################################################################################################


 # PEER VALUES
  $peer_values = "(".$user["uid"].",".$torrent["tid"].", '$ip', $port, ".sqlesc($agent).", $downthis, $upthis, $left, $time, $time, $connectable, $comptime, $downspeed, $upspeed),";

 # USER VALUES
  $user_values="('".$user["uid"]."', $user_upthis , $user_downthis, $seedbonus),";

 # TRAFFIC VALUES
  $traffic_values="(".$user["uid"].",".$torrent["tid"].", $user_upthis , $user_downthis, $upload_time, $download_time),";

 # TORRENT LASTACTION VALUES
  $lastaction_values="(".$torrent["tid"].", $time),";


################################################################################################


 # READ PEER VALUES FROM RAM
  $peers_buffer = apc_fetch("peers_buffer");

 # READ USER VALUES FROM RAM
  $users_buffer = apc_fetch("users_buffer");

 # READ TRAFFIC VALUES FROM RAM
  $traffic_buffer = apc_fetch("traffic_buffer");

 # READ LASTACTION VALUES FROM RAM
  $lastaction_buffer = apc_fetch("lastaction_buffer");


################################################################################################


  $peers_buffer .= $peer_values;

  $users_buffer .= $user_values;

  $traffic_buffer .= $traffic_values;

  $lastaction_buffer .= $lastaction_values;


################################################################################################


  # SAVE PEER VALUES TO RAM
  apc_store("peers_buffer",$peers_buffer);

  # SAVE USER VALUES TO RAM
  apc_store("users_buffer",$users_buffer);

  # SAVE TRAFFIC VALUES TO RAM
  apc_store("traffic_buffer",$traffic_buffer);

  # SAVE TORRENT LASTACTION VALUES TO RAM
  apc_store("lastaction_buffer",$lastaction_buffer);


################## WRITE VALUES ##################


  $write_users_time = apc_fetch("write_users_time");

  $write_completed_time = apc_fetch("write_completed_time");


  # WRITE COMPLETED TORRENTS TO DATABASE
    if($time > $write_completed_time){
	write_db_completed();	   
      }


  # WRITE USER AND TRAFFIC VALUES TO DATABASE
    if($time > $write_users_time){
	write_db_users();	   
      }


################# END WRITE VALUES ################


  $torrent_peers_buffer = apc_fetch("peers_tid_".$torrent["tid"]);

  $peeruid="puid".$user["uid"];

 # STOPPED
  if($event == "stopped"){

	    unset($torrent_peers_buffer["$peeruid"]);
	    apc_store("peers_tid_".$torrent["tid"],$torrent_peers_buffer,7200);
	    
	    if(mysql_query("DELETE FROM peers WHERE puid = ".$user["uid"]." AND ptid = ".$torrent["tid"]))
	    {
		if($seeder){
		    mysql_query("UPDATE torrents SET seeders = seeders - 1 WHERE tid = ".$torrent["tid"]);
		}
		else{
		    mysql_query("UPDATE torrents SET leechers = leechers - 1 WHERE tid = ".$torrent["tid"]);
		  }
	    }
      die();
    }   
   
      # COMPLETED
	elseif($event == "completed"){

	      $completed_buffer = apc_fetch("completed_torrents");

	      mysql_query("UPDATE torrents SET times_completed = times_completed + 1, seeders = seeders + 1, leechers = leechers - 1 WHERE tid = ".$torrent["tid"]);
	      $completed_buffer .= "(".$user["uid"].", ".$torrent["tid"].", '".$torrent["name"]."', ".$torrent["catid"].", $time),";
	      apc_store("completed_torrents",$completed_buffer);
	}

	    # STARTED
		elseif($event == "started" || !$interval){

		      if($seeder && !$interval){
			  mysql_query("UPDATE torrents SET seeders = seeders + 1 WHERE tid = ".$torrent["tid"]);
		      }

		      if(!$seeder && !$interval){
			      mysql_query("UPDATE torrents SET leechers = leechers + 1 WHERE tid = ".$torrent["tid"]);
		      }

				  if(!$seeder || ($user["uid"] == $torrent["toruid"] && $seeder)){

					  $torrent_peer_user_values = array($peeruid => pack('A*n*', $ip, (int)$port));

					  if(!isset($torrent_peers_buffer["$peeruid"]) && !$torrent_peers_buffer){
					      $torrent_peers_buffer = $torrent_peer_user_values;
					  }

					  $results = array_merge($torrent_peers_buffer,$torrent_peer_user_values);

					  apc_store("peers_tid_".$torrent["tid"],$results,7200);
			          }

		}

		    # UPDATE
		      else{
			    if(!$seeder || ($user["uid"] == $torrent["toruid"] && $seeder)){
				  $torrent_peer_user_values = array($peeruid => pack('A*n*', $ip, (int)$port));

					  if(!isset($torrent_peers_buffer["$peeruid"]) && !$torrent_peers_buffer){
					      $torrent_peers_buffer = $torrent_peer_user_values;
					  }

				  $results = array_merge($torrent_peers_buffer,$torrent_peer_user_values);
						  
				  apc_store("peers_tid_".$torrent["tid"],$results,7200);
			      }
			}



# SEND PEERS TO TORRENT CLIENT

 $anninterval = $GLOBALS["ANNOUNCE_INTERVAL"];

  if($user["uid"] == $torrent["toruid"] && !$torrent_peers_buffer){
      $anninterval = mt_rand(5, 10) * 60;
    }

 $sendpeers2cli ="d" . benc_str("interval") . "i" . $anninterval . "e" . benc_str("min interval") . "i" . $GLOBALS["MIN_ANNOUNCE_INTERVAL"] . "e"  . benc_str("peers");

  $peers="";

 if($torrent_peers_buffer){

      shuffle($torrent_peers_buffer);

      $cnt_buffer=count($torrent_peers_buffer);

	if($cnt_buffer > $nwant){
	    $nwant=$nwant;
	  }
	  else{
	      $nwant=$cnt_buffer;
	    }

	    $cnt=1;

	    foreach($torrent_peers_buffer as $torpeers){
	      $peers .= $torpeers;
	      $cnt++;
		if($cnt > $nwant){
		    break;
		    }
	    }

  }

 $sendpeers2cli .= strlen($peers) . ':' . $peers . 'ee';

 benc_resp_raw($sendpeers2cli);




# WRITE USERS VALUES TO DATABASE
  function write_db_users(){

    global $torrent,$time;

	# UPDATE WRITE TIME
	  apc_store("write_users_time",($time+$GLOBALS["USERS_DB_WRITE_INTERVAL"]));



# PEER VALUES
    $peers_bufferval = apc_fetch("peers_buffer");

	   if($peers_bufferval){

		      $peers_bufferval = trim($peers_bufferval,",");

		     mysql_query("insert into peers (puid, ptid, ip, port, agent, downloaded, uploaded, tleft, startdate, lastaction, connectable, finishedate, downspeed, upspeed) VALUES $peers_bufferval 
								 on duplicate key update 
								 downloaded = if(values(downloaded) = 0, downloaded, downloaded + values(downloaded)), 
								 uploaded = if(values(uploaded) = 0, uploaded, uploaded + values(uploaded)),
								 tleft = values(tleft),   
								 ip = if(values(ip) = ip, ip, values(ip)), 
								 port = if(values(port) = port, port, values(port)), 
								 agent = if(values(agent) = agent, agent, values(agent)), 
								 connectable = if(values(connectable) = connectable, connectable, values(connectable)),  
								 finishedate = if(values(finishedate) = 0, finishedate, values(finishedate)),
								 lastaction = values(lastaction),
								 downspeed = if(values(downspeed) = downspeed, downspeed, values(downspeed)) ,
								 upspeed = if(values(upspeed) = upspeed, upspeed, values(upspeed))");

		      apc_store("peers_buffer","");

		   }



# USER VALUES
     $users_bufferval = apc_fetch("users_buffer");

	      if($users_bufferval){

		      $users_bufferval = trim($users_bufferval,",");

			mysql_query("insert into users (uid, uploaded, downloaded, seedbonus) VALUES $users_bufferval 
								 on duplicate key update 
								 downloaded = if(values(downloaded) = 0, downloaded, downloaded + values(downloaded)), 
								 uploaded = if(values(uploaded) = 0, uploaded, uploaded + values(uploaded)),
								 seedbonus = if(values(seedbonus) = 0, seedbonus, seedbonus + values(seedbonus))
								 ");
		      apc_store("users_buffer","");
		  }



# UPDATE TORRENT LASTACTION

      # READ LASTACTION VALUES FROM RAM
      $lastaction_bufferval = apc_fetch("lastaction_buffer");

		if($lastaction_bufferval){

			  $lastaction_bufferval = trim($lastaction_bufferval,",");

			  mysql_query("insert into torrents (tid, lastaction) VALUES $lastaction_bufferval  
								  on duplicate key update 
								  visible = if(visible = 0, 1, visible),
								  lastaction = values(lastaction) ");
			  apc_store("lastaction_buffer","");
		  }

  }



# WRITE COMPLETED TORRENTS AND TRAFFIC TO DATABASE
 function write_db_completed(){

global $time;

  $completed_buffer_values = apc_fetch("completed_torrents");

	  apc_store("write_completed_time",($time+$GLOBALS["COMPLETED_DB_WRITE_INTERVAL"]));

	if($completed_buffer_values){

		      $completed_buffer_values = trim($completed_buffer_values,",");

			mysql_query("insert into completed (user_id, tor_id, tor_name, tor_cat, complete_time) VALUES $completed_buffer_values 
								 on duplicate key update 
								 complete_time = values(complete_time)");

		      apc_store("completed_torrents","");
		   }


# TRAFFIC VALUES
     $traffic_bufferval = apc_fetch("traffic_buffer");

	      if($traffic_bufferval){

		      $traffic_bufferval = trim($traffic_bufferval,",");

			mysql_query("insert into traffic (uid, tid, uploaded, downloaded, uploadtime, downloadtime) VALUES $traffic_bufferval 
								 on duplicate key update 
								 uploaded = if(values(uploaded) = 0, uploaded, uploaded + values(uploaded)), 
								 uploadtime = if(values(uploadtime) = 0, uploadtime, uploadtime + values(uploadtime)), 
								 downloaded = if(values(downloaded) = 0, downloaded, downloaded + values(downloaded)), 
								 downloadtime = if(values(downloadtime) = 0, downloadtime, downloadtime + values(downloadtime))");
		      apc_store("traffic_buffer","");
		  }


 }


# FIND BUFFER
  function find_buffer($inputStr, $delimeterLeft, $delimeterRight = "),") {

    $delimeterLeft="(".$delimeterLeft;

      $posLeft=strpos($inputStr, $delimeterLeft);

      if ( $posLeft===false ) {
	  return false;
      }

      $posLeft+=0;
      $posRight=strpos($inputStr, $delimeterRight, $posLeft);

      if ( $posRight===false ) {
	  return false;
      }

      $posRight =$posRight + 2;
      return substr($inputStr, $posLeft, $posRight-$posLeft);
  } 



/*

# FIND PEER VALUES FROM BUFFER
		  $find_peer_buffer = find_buffer($peers_buffer,$user["uid"].",".$torrent["tid"]);
		    if($find_peer_buffer){
			# IF PEER EXISTS REPLACE VALUES
			if($event == "stopped"){
			    $peer_values = "";
			  }else{
				    $peers_buffer = str_replace($find_peer_buffer,$peer_values,$peers_buffer);
				}
		      }
		      else{
			  $peers_buffer .= $peer_values;
			}


		# FIND USER VALUES FROM BUFFER
		  $find_user_buffer = find_buffer($users_buffer,"'".$user["uid"]."',");
		      if($find_user_buffer){
			  # IF USER EXISTS REPLACE VALUES
			    $users_buffer = str_replace($find_user_buffer,$user_values,$users_buffer);
			}
			else{
			    $users_buffer .= $user_values;
			  }


		# FIND TRAFFIC VALUES FROM BUFFER
		  $find_traffic_buffer = find_buffer($traffic_buffer,$user["uid"].",".$torrent["tid"]);
		      if($find_traffic_buffer){
			  # IF USER EXISTS REPLACE VALUES
			    $traffic_buffer = str_replace($find_traffic_buffer,$traffic_values,$traffic_buffer);
			}
			else{
			    $traffic_buffer .= $traffic_values;
			  }

*/


?>