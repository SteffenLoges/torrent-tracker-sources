<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["act"])){$act=$_GET["act"];}else{$act="";}
if(isset($_GET["uid"])){$uid = 0+$_GET["uid"];}else{$uid=0;}
if(isset($_GET["show"])){$show = 0+$_GET["show"];}else{$show=0;}

    function check_user($u_id){
      # Check User
	$userres = mysql_query("SELECT COUNT(*) FROM users WHERE uid=".sqlesc($u_id)) or sqlerr(__FILE__, __LINE__);
	$user = mysql_fetch_row($userres);

	  if(!$user[0]){
	      errmsg(btlng32,btlng173.$uid);
	  }
    }

?>
<script>
  $('#fbbutton1,#fbbutton2,#fbbutton3,#fbbutton4').click(function() {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/friends.php", { act: $(this).attr("act"), uid:$(this).attr("uid"), show: 1 }, function(data){
	$('#friendres').html(data);
	});
  });

</script>
<?php

    $add_user = "<div class=\"tr\">
    <div class=\"td\"><center><a id=\"fbbutton3\" href=\"javascript:;\" act=\"addfriend\" uid=\"$uid\" title=\"".btlng155_2."\"><img src=\"$stylelink/adduser.png\"><br>".btlng155_2."</a> &nbsp;&nbsp;</center></div>
    <div class=\"td\"><center><a id=\"fbbutton4\" href=\"javascript:;\" act=\"addblock\" uid=\"$uid\" title=\"".btlng155_3."\"> <img src=\"$stylelink/block_user.png\"><br>".btlng155_3."</a></center></div>
    </div>\n";

# Add Friend
  if($act=="addfriend"){

	  if($show){
	      echo  "<div class=\"tr\"><div class=\"td\"><center><a id=\"fbbutton1\" href=\"javascript:;\" act=\"delfriend\" uid=\"$uid\" title=\"".btlng155_4."\"><img src=\"$stylelink/remove_user.png\"><br>".btlng155_4."</a></center></div></div>\n";
	    }

		check_user($uid);

		      # Check Block list
			$frlist = mysql_query("SELECT buid FROM blocks WHERE buid=".$CURUSER["uid"]." AND blockid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);
			if(mysql_num_rows($frlist)){
			      infoerr(btlng176);
			    }
			     # Add Friend
			      mysql_query("INSERT INTO friends (fuid, friendid) VALUES (".$CURUSER["uid"].", ".sqlesc($uid).")");

				  if(mysql_errno() == 1062){
					infoerr(btlng174);
				      }
				      else{
					  infok(btlng175);
				      }
  }

# Add Block
  else if($act=="addblock"){
	  if($show){
	      echo  "<div class=\"tr\"><div class=\"td\"><center><a id=\"fbbutton2\" href=\"javascript:;\" act=\"delblock\" uid=\"$uid\" title=\"".btlng155_5."\"><img src=\"$stylelink/remove_user.png\"><br>".btlng155_5."</a></center></div></div>\n";
	    }

	      check_user($uid);

			# Check Friend list
			  $frlist = mysql_query("SELECT fuid FROM friends WHERE fuid=".$CURUSER["uid"]." AND friendid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);
			  if(mysql_num_rows($frlist)){
				infoerr(btlng174);
			      }
				# Add Block
				  mysql_query("INSERT INTO blocks (buid, blockid) VALUES (".$CURUSER["uid"].", ".sqlesc($uid).")") or sqlerr(__FILE__, __LINE__);

				      if(mysql_errno() == 1062){
					    infoerr(btlng176);
					  }
					  else{
					      infok(btlng177);
					  }
    }

# DEL Friend
  else if($act=="delfriend"){

	  if($show){
		echo $add_user;
		}

		  mysql_query("DELETE FROM friends WHERE fuid=".$CURUSER["uid"]." AND friendid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);

			    if(mysql_affected_rows()=="0"){
				  infoerr(btlng178);
				  }
				  else{
				      infok(btlng180);
					  }

      }

# DEL Block
  else if($act=="delblock"){

	  if($show){
		echo $add_user;
		}

		mysql_query("DELETE FROM blocks WHERE buid=".$CURUSER["uid"]." AND blockid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);

			if(!mysql_affected_rows()){
			      infoerr(btlng179);
			      }
			      else{
				    infok(btlng181);
				      }
      }

# Show Block And Friend List
  else{

?>
<script>
  $('#frbutton,#blbutton').click(function() {
     if (confirm('<?php echo btlng185;?>')) {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/friends.php", { act: $(this).attr("act"), uid:$(this).attr("uid") }, function(data){
	$('#info').html(data);
	});
    if($(this).attr("act")=="delfriend"){
      $("#fr"+$(this).attr("uid")).remove();
	}
    if($(this).attr("act")=="delblock"){
      $("#bl"+$(this).attr("uid")).remove();
	}
   }
  });

</script>
<?php
      title(btlng182,btlng182." [img=".$GLOBALS["BASEURL"]."/$stylelink/friends.png] ");

# FRIEND LIST
$resfriend = mysql_query("SELECT f.friendid as fid, u.username AS uname, u.class, u.avatar, u.title, u.donor, u.warnpoints, u.enabled, u.lastaccess, u.added FROM friends AS f JOIN users as u ON f.friendid = u.uid WHERE fuid IN(".$CURUSER["uid"].") ORDER BY uname ASC") or sqlerr(__FILE__, __LINE__);

	echo "<div class=\"shadow\" style=\"background:#fff url($stylelink/h40.png) repeat-x;\"><div align=\"center\" style=\"padding:8px;\"><font><b><i>".btlng184."</i></b></font></div></div>";
	echo "<div class=\"shadow\">";

	      if(!mysql_num_rows($resfriend)){
		  echo "<div align=\"center\" style=\"padding:8px;\"><b><em>".btlng183."</em></b></div>";
	         }
		  else{

	      $tdstyle="border-left:1px solid #ccc;padding:10px;vertical-align:top;";

		      echo "<div class=\"table\">";
			    echo "<div class=\"divbottom\"><div class=\"tr\">";
			    echo "<div class=\"td\" style=\"border-left:0px solid #ccc;padding:10px;vertical-align:top;width: 50px;\"><b>".btlng157."</b></div>";
			    echo "<div class=\"td\" style=\"$tdstyle width: 110px;\"><b>".btlng6_2."</b></div>";
 			    echo "<div class=\"td\" style=\"$tdstyle width: 125px;\"><b>".btlng156."</b></div>";
			    echo "<div class=\"td\" style=\"$tdstyle width: 70px;\"><b>".btlng155."</b></div>";
 			    echo "<div class=\"td\" style=\"$tdstyle width: 130px;\"><b>".btlng151."</b></div>";
 			    echo "<div class=\"td\" style=\"$tdstyle width: 70px;\"><center><b>".btlng128."</b></center></div>";
 			    echo "<div class=\"td\" style=\"$tdstyle width: 58px;\"><b>".btlng117."</b></div>";
			    echo "</div></div>";
		    
		    while($friend = mysql_fetch_row($resfriend)) {

			$ffid=$friend[0];
			$funame=ucfirst($friend[1]);
			$fclass=$friend[2];
			$favatar=$friend[3];
			$ftitle=$friend[4];
			$fdonor=$friend[5];
			$fwarnpoints=$friend[6];
			$fenabled=$friend[7];
			$flastaccess=$friend[8];
			$fadded=$friend[9];

			echo "<div id=\"fr$ffid\"><div class=\"divbottom\"><div class=\"tr\">";

			# Friend Avatar
			if($favatar){
				$avatarsrc=htmlchar($favatar);
				}
				else{
				      if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($ffid.$fadded).".jpg")){
					      $avatarsrc=$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($ffid.$fadded).".jpg";
						}else{
						    $avatarsrc=$GLOBALS["IMAGES_DIR"]."default_avatar.png";
						  }
				  }
			# Friend Title
			if($ftitle){
				  if(strlen($ftitle) > 20){
				      $ftitle1 = substr($ftitle, 0, 20) . "...";
				     }else{
					  $ftitle1 = $ftitle;
				         }

				$title=htmlchar($ftitle1);
				}
				else{
				    $title=" ---------- ";
				  }

			echo "<div class=\"td\" style=\"border-left:0px solid #ccc;padding:10px;vertical-align:top;width: 50px;\"><img class=\"imgborder\" style=\"width: 40px;\" src=\"$avatarsrc\"></div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 110px;\"><a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$ffid\"><font color=".get_class_color($fclass)."><b>$funame</b></font><br><br>".get_user_icons($fdonor,$fwarnpoints,$fenabled,$fadded)."</a></div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 125px;\" title=\"".htmlchar($ftitle)."\">$title</div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 70px;\"><font color=".get_class_color($fclass)."><b>".get_user_class_name($fclass)."</b></font></div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 130px;\">".gdate($flastaccess)."</div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 70px;\"><center><a href=\"".$GLOBALS["BASEURL"]."/#messages?act=sendpm&recuid=$ffid\" class=\"buttonsilver\" title=\"".btlng129_2."\">".btlng188."</a></center></div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 58px;\"><center><a id=\"frbutton\" href=\"javascript:;\" act=\"delfriend\" uid=\"$ffid\" title=\"".btlng155_4."\"><img src=\"$stylelink/remove_user.png\"></a></center></div>";
			 echo "</div></div></div>";
			}
		echo "</div><br>";
		      }

	echo "</div><br><br>";


# BLOCK LIST
$resblock = mysql_query("SELECT b.blockid as bid, u.username AS uname, u.avatar, u.donor, u.warnpoints, u.enabled, u.lastaccess, u.added, u.class FROM blocks AS b JOIN users as u ON b.blockid = u.uid WHERE buid IN(".$CURUSER["uid"].") ORDER BY uname ASC") or sqlerr(__FILE__, __LINE__);

	echo "<div class=\"shadow\" style=\"background:#fff url($stylelink/h40.png) repeat-x;\"><div align=\"center\" style=\"padding:8px;\"><font><b><i>".btlng186."</i></b></font></div></div>";
	echo "<div class=\"shadow\">";
	      if(!mysql_num_rows($resblock)){
		  echo "<div align=\"center\" style=\"padding:8px;\"><b><em>".btlng187."</em></b></div>";
	         }
		  else{

			  $tdstyle="border-left:1px solid #ccc;padding:10px;vertical-align:top;";

			    echo "<div class=\"table\">";
			    echo "<div class=\"divbottom\"><div class=\"tr\">";
			    echo "<div class=\"td\" style=\"border-left:0px solid #ccc;padding:10px;vertical-align:top;width: 50px;\"><b>".btlng157."</b></div>";
			    echo "<div class=\"td\" style=\"$tdstyle width: 300px;\"><b>".btlng6_2."</b></div>";
 			    echo "<div class=\"td\" style=\"$tdstyle width: 230px;\"><b>".btlng151."</b></div>";
 			    echo "<div class=\"td\" style=\"$tdstyle width: 85px;\"><b>".btlng117."</b></div>";
			    echo "</div></div>";

		    while($block = mysql_fetch_row($resblock)) {
			  $bid=$block[0];
			  $buname=ucfirst($block[1]);
			  $bavatar=$block[2];
			  $bdonor=$block[3];
			  $bwarnpoints=$block[4];
			  $benabled=$block[5];
			  $blastaccess=$block[6];
			  $badded=$block[7];
			  $bclass=$block[8];

			echo "<div id=\"bl$bid\"><div class=\"divbottom\"><div class=\"tr\">";

			# Friend Avatar
			if($bavatar){
				$avatarsrc=htmlchar($bavatar);
				}
				else{
				      if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($bid.$badded).".jpg")){
					      $avatarsrc=$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($bid.$badded).".jpg";
						}else{
						    $avatarsrc=$GLOBALS["IMAGES_DIR"]."default_avatar.png";
						  }
				  }

			echo "<div class=\"td\" style=\"border-left:0px solid #ccc;padding:10px;vertical-align:top;width: 50px;\"><img class=\"imgborder\" style=\"width: 40px;\" src=\"$avatarsrc\"></div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 300px;\"><a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$bid\"><font color=".get_class_color($bclass)."><b>$buname</b></font><b></b><br>".get_user_icons($bdonor,$bwarnpoints,$benabled,$badded)."</a></div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 230px;\">".gdate($blastaccess)."</div>";
			echo "<div class=\"td\" style=\"$tdstyle width: 85px;\"><center><a id=\"blbutton\" href=\"javascript:;\" act=\"delblock\" uid=\"$bid\" title=\"".btlng155_5."\"><img src=\"$stylelink/remove_user.png\"></a></center></div>";

			 echo "</div></div></div>";
		    }
		echo "</div><br>";

		  }

	echo "</div>";

  }




?>