<?php
define("btlng0","Sorry, Sie Sind Gebannt!!");
define("btlng0_0","Tracker Offline!!");
define("btlng0_1","<center><b>JAVASCRIPT DEAKTIVIERT !!</b></center> Aktivieren Sie bitte JavaScript in Ihren Browsereinstellungen.");
define("btlng0_2","Wartungsarbeiten !!");
define("btlng1","Navi");
define("btlng2","Startseite");
define("btlng3","Anmelden");
define("btlng4","Einloggen");
define("btlng4_0","Download");
define("btlng4_1","Torrents");
define("btlng4_2","Upload");
define("btlng4_3","Nachrichten");
define("btlng4_4","Logout");
define("btlng4_5","Freundesliste");
define("btlng4_6","Digitale Uhr");
define("btlng4_7","Ratio");
define("btlng4_8","IP");
define("btlng4_9","Mitglieder");
define("btlng4_10","Mein Profil");
define("btlng4_11","Trackerinfo");
define("btlng4_12","APC");
define("btlng4_13","Clients");
define("btlng4_14","Bann Liste");
define("btlng4_15","Bann Benutzer");
define("btlng4_16","Bann IP");
define("btlng4_17","Regeln");
define("btlng5","<b>Hinweis:</b> <font color=\"#ff0000\"><i>Du musst Cookies akzeptieren, um Dich Anmelden und Einloggen zu können!</i></font>");
define("btlng6","Benutzername : ");
define("btlng6_2","Benutzername");
define("btlng7","Passwort : ");
define("btlng8","Passwort Erneut : ");
define("btlng9","E-Mail Adresse : ");
define("btlng9_1","Anmeldungscode : ");
define("btlng9_2","E-Mail Senden");
define("btlng10","Ich werde die FAQ lesen, bevor ich Fragen an einen Moderator oder RooT stelle.");
define("btlng11","Ich bin mindestens 13 Jahre alt.");
define("btlng12","Anmelden");
define("btlng13","Sorry, das Benutzerlimit wurde erreicht. Bitte versuche es später erneut.");
define("btlng14","Undefined index");
define("btlng15","Du musst alle Felder ausfüllen.");
define("btlng16","Sorry, Dein Benutzername ist zu lang (Maximum sind 12 Zeichen)");
define("btlng17","Die Passwörter stimmen nicht überein! Du musst Dich vertippt haben. bitte versuche es erneut!");
define("btlng18","Sorry, Dein Passwort ist zu kurz (Mindestens 6 Zeichen)");
define("btlng19","Sorry, Dein Passwort ist zu lang (Maximal 40 Zeichen)");
define("btlng20","Sorry, Dein Passwort darf nicht mit Deinem Benutzernamen identisch sein.");
define("btlng21","Die E-Mail Adresse sieht nicht so aus, als ob sie gültig wäre.");
define("btlng22","Ungültiger Benutzername.");
define("btlng22_2","Anmeldungscode stimmt nicht überein! Du musst Dich vertippt haben. Bitte versuche es erneut!");
define("btlng23","Sorry, aber Du bist nicht dafür qualifiziert, ein Mitglied dieser Seite zu werden.");
define("btlng24","Die E-Mail Adresse %email% wird schon verwendet.");
define("btlng25","Der Benutzername existiert bereits!");
define("btlng25_2","Ip-Adresse wird bereits verwendet!");
define("btlng26","Borked");
define("btlng26_2","Zugriff verweigert");


#EMAIL TEXT
define("btlng27","Du oder jemand anderes hat auf %sitename% einen neuen Account erstellt und
diese E-Mail Adresse (%email%) dafuer verwendet.

Wenn Du den Account nicht erstellt hast, ignoriere diese Mail. In diesem
Falle wirst Du von uns keine weiteren Nachrichten mehr erhalten. Die
Person, die Deine E-Mail Adresse benutzt hat, hatte die IP-Adresse
%ip%. Bitte antworte nicht auf diese automatisch
erstellte Nachricht

Um die Anmeldung zu bestaetigen, folge bitte dem folgenden Link:

%baseurl%/#confirm?uid=%id%&secret=%secret%

Wenn du dies getan hast, wirst Du in der Lage sein, Deinen neuen Account zu
verwenden. Wenn die Aktivierung fehlschlaegt, oder Du diese nicht vornimmst,
wird Dein Account innerhalb der naechsten Tage wieder geloescht.
Wir empfehlen Dir dringlichst, die Regeln und die FAQ zu lesen, bevor Du
unseren Tracker verwendest.");

define("btlng28","Anmeldebestaetigung");
define("btlng29","From");
define("btlng30","Anmeldung erfolgreich!");
define("btlng31","Du bekommst in Kürze eine Bestätigungsmail mit dem Aktivierungslink. Folge bitte den Anweisungen in der Mail!");
define("btlng32","Fehler !!");
define("btlng32_2","Erfolg");
define("btlng33","ID wurde nicht gefunden");
define("btlng34","Dieser Account wurde bereits aktiviert. Du kannst Dich nun auf der Seite mit Deinen Benutzerdaten [url=%login%]Einloggen[/url].");
define("btlng35","Secret stimmt nicht");
define("btlng36","Account wurde nicht aktiviert.");
define("btlng37","Account erfolgreich aktiviert!");
define("btlng38","Dein Account wurde aktiviert! Du wurdest automatisch eingeloggt. Du kannst nun zur [url=/][b]Startseite[/b][/url] gehen, und Deinen Account benutzen.Bitte denke daran, Dich immer an die Regeln zu halten!");
define("btlng39","Tracker Login");
define("btlng40","<b>Hinweis</b>: <font color=\"#ff0000;\"><i>Du musst Deinen Browser so eingestellt haben, dass er Cookies akzeptiert, damit Du Dich einloggen kannst.</i></font>");
define("btlng41","Login -->");
define("btlng42","Du hast noch keinen Account? <a href=\"%signup%\"><b style=\"color:green;\">Registriere Dich</b></a> hier!");
define("btlng42_2","<a href=\"%recover%\"><b style=\"color:#ff0000;\">Passwort vergessen ?</b></a>");
define("btlng43","Hier ist was faul...");
define("btlng44","Benutzername oder Passwort ungültig");
define("btlng45","Dieser Account wurde deaktiviert.");
define("btlng45_2","Es ist Dir nicht gestattet, Torrents hochzuladen!");
define("btlng46_0","<font color=\"#539C00\"><b>Announce Url</b></font> : ");
define("btlng46","Torrent Datei :");
define("btlng47","Name :");
define("btlng48","Bild 1 :");
define("btlng49","Bild 2 :");
define("btlng50","Nfo :");
define("btlng51","Seed Geschwindigkeit :");
define("btlng52"," Bitte Auswählen ");
define("btlng53","Audio :");
define("btlng54","Untertitel :");
define("btlng55","Kategorie :");
define("btlng56","Beschreibung :");
define("btlng57","Upload");
define("btlng58","Beschreibung :");
define("btlng59","Zitat");
define("btlng60","hat geschrieben...");
define("btlng61","<font color=\"#FF0000\"><b>Beachte, dass Du nicht Deine eigene, mit Deinem UserKey versehene URL einträgst</b>.<br><br>
Der UserKey des jew. Users wird vom Download-Script automatisch eingefügt! Aus diesem Grund MUSST
Du den Torrent nach erfolgtem Upload noch einmal vom Tracker runterladen und diesen dann zum Seeden
verwenden.</font><br><br>");
define("btlng62","Keine Uploadrechte! Du hast kein Recht, auf diesem Tracker Torrents hochzuladen, da diese Funktion für Deinen Account von einem Moderator deaktiviert wurde.");
define("btlng63","Du musst eine Beschreibung eingeben!");
define("btlng64","Du musst eine Kategorie angeben, welcher der Torrent zugeordnet werden soll.");
define("btlng65","Du musst eine Seed Geschwindigkeit angeben!");
define("btlng66","Die angebene Beschreibung ist zu gross;. Maximal 20000 Zeichen sind erlaubt!");
define("btlng67","Torrent-Metadatei hat keinen Dateinamen bzw. es wurde kein Torrent hochgeladen!");
define("btlng68","Der Dateiname der Torrent-Datei enthält ungültige Zeichen!!");
define("btlng69","Der Torrent-Dateiname muss mit (.torrent) enden.");
define("btlng70","Beim Upload der Torrent-Metadatei ist etwas schiefgegangen...");
define("btlng71","Torrent-Metadatei ist zu gross (Max. ".mksize($GLOBALS["MAX_TORRENT_SIZE"],0).")!");
define("btlng72","Leere Torrent-Metadatei hochgeladen!");
define("btlng73","Die NFO hat keinen Dateinamen oder es wurde keine NFO-Datei hochgeladen!");
define("btlng74","0=>Byte NFO");
define("btlng75","NFO ist zu gross! Maximal 65535 Bytes (64 KB) sind erlaubt.");
define("btlng76","NFO-Upload fehlgeschlagen");
define("btlng77","Was zum Teufel hast du da hochgeladen? Das ist jedenfalls keine gültige Torrent-Datei!");
define("btlng78","Die Datei ist kein BEnc-Dictionary.");
define("btlng79","Es fehlt ein benötigter Schlüssel im Dictionary!");
define("btlng80","Das Dictionary enthält einen ungültigen Eintrag (Tatsächlicher Datentyp entspricht nicht dem erwarteten)!");
define("btlng81","Unerwarteter Fehler beim Dekodieren der Metadaten: Das ist kein Dictionary !");
define("btlng82","Unerwarteter Fehler beim Dekodieren der Metadaten: Der Datentyp des Eintrags enspricht nicht dem erwarteten Typ!");
define("btlng83","Ungültige Announce-URL! Muss eine der Folgenden sein : ".$GLOBALS["ANNOUNCE_URLS"][0]." oder ".$GLOBALS["ANNOUNCE_URLS"][1]);
define("btlng84","Es fehlen sowohl der length- als auch der files-Schlüssel im Info-Dictionary!");
define("btlng85","Der Torrent enthält keine Dateien");
define("btlng86","Ein Eintrag in der Dateinamen-Liste hat einen ungültigen Datentyp (%type%)");
define("btlng87","Eine Datei in der Torrent-Metadatei hat einen ungültigen Namen (%value%)");
define("btlng88","Die Länge der Piece-Hashes ist kein Vielfaches von 20!");
define("btlng89","Die Anzahl Piecehashes stimmt nicht mit der Torrentlänge überein");
define("btlng90","Dieser Torrent wurde bereits hochgeladen!");
define("btlng91","Fehler beim Öffnen der Torrent-Datei auf dem Server (Schreibzugriff verweigert) - bitte RooT benachrichtigen!");
define("btlng92","Es wurden keine Daten von (%imgname%) empfangen!");
define("btlng93","Die Bilddatei (%imgname%) ist zu groß (Max. ".mksize($GLOBALS["MAX_XIMGDEPOT_UPLOAD_SIZE"],0).")!");
define("btlng94","Sorry, die hochgeladene Datei (%imgname%) konnte nicht als gültige Bilddatei verifiziert werden.");
define("btlng95","Ungültige Dateinamenerweiterung: ( %ext% )!!");
define("btlng96","Die Datei (%imgname%) besitzt keine Dateinamenerweiterung.");
define("btlng97","Das Bild (%imgname%) konnte nicht verkleinert werden.");
define("btlng98","Die Originalversion des Bildes (%imgname%) konnte nicht auf dem Server gespeichert werden - bitte SysOp benachrichtigen!");
define("btlng99","Konnte das NFO-Font nicht laden. RooT benachrichtigen!");
define("btlng100","Torrent-Upload war erfolgreich!");
define("btlng101","Dein Torrent wurde erfolgreich hochgeladen. [b]Beachte[/b] dass Dein Torrent erst sichtbar wird, wenn der erste Seeder verfügbar ist!");
define("btlng102","\n \n [b]Da Du kein Uploader bist, wurde Dein Torrent als Gastupload gewertet, und muss zuerst von einem Gastupload-Betreuer überprüft und freigeschaltet werden. Erst dann kannst Du den Torrent zum Seeden herunterladen.[/b]\n \n Bitte sende uns keine Nachrichten mit der Bitte um Freischaltung. Das Team wurde bereits per PN über Deinen Upload benachrichtigt, und wird sich baldmöglichst darum kümmern.\n \n [b]Wichtiger Hinweis : [/b] \n Bevor Du den Torrent seeden kannst, musst Du den Torrent erneut vom Tracker herunterladen, da beim Upload einige Änderungen an der Torrent-Datei vorgenommen wurden. Dadurch hat der Torrent einen neuen Info-Hash erhalten, und beim Download wird ebenfalls Dein UserKey in die Announce-URL eingefügt.\n \n [b]Das Ändern der Announce-URL in Deiner soeben hochgeladenen Torrent-Metadatei genügt nicht![/b]\n \n [url=".$GLOBALS["BASEURL"]."/#details?tid=%tid%]>Weiter zu den Details Deines Torrents[/url]");
define("btlng103","Nachrichten - Posteingang");
define("btlng104","Nachrichten - Postausgang");
define("btlng105","Dieser Ordner enthält keine Nachrichten");
define("btlng106","Posteingang");
define("btlng107","Postausgang");
define("btlng108","Backup Ordner");
define("btlng109","System Nachrichten");
define("btlng110","Nachrichten - Backup Ordner");
define("btlng111","Nachrichten - System Nachrichten");
define("btlng112","Betreff");
define("btlng113","Absender");
define("btlng114","Empfänger");
define("btlng115","Datum");
define("btlng116","Aktion");
define("btlng117","Löschen");
define("btlng118","Backup Ordner Verschieben");
define("btlng119","Antworten");
define("btlng120","Sind Sie Sicher?");
define("btlng121","Nachricht(en) Gelöscht");
define("btlng122","Nachricht(en) in Backup Ordner Verschoben");
define("btlng123","Verschieben");
define("btlng124","Persönliche Nachricht Lesen");
define("btlng125","Die zu beantwortende Nachricht existiert nicht mehr.");
define("btlng125_1","Die Nachricht existiert nicht mehr.");
define("btlng126","Der gewünschte Empfänger existiert nicht!");
define("btlng127","Du kannst keine Nachricht an Dich selbst versenden!");
define("btlng128","Nachricht");
define("btlng129","Nachricht Versenden");
define("btlng129_2","Nachricht Senden");
define("btlng129_3","Neue Nachricht Schreiben");
define("btlng130","Du musst einen Betreff angeben!");
define("btlng131","Der Betreff ist zu lang (maximal 250 Zeichen)");
define("btlng132","Du musst einen Nachrichtentext angeben!");
define("btlng133","Der Nachrichtentext ist zu lang. Bitte kürze den Text auf unter 5.000 Zeichen!");
define("btlng134","Dieser Benutzer hat PNs von Dir blockiert");
define("btlng135","Dieser Benutzer akzeptiert nur PNs von Benutzern auf seiner Freundesliste");
define("btlng136","Dieser Benutzer akzeptiert keine PNs.");
define("btlng137","Nachricht erfolgreich versendet!");
define("btlng138","[align=center]Die Nachricht wurde erfolgreich versendet.[/align]");
define("btlng139","Nachricht löschen, auf die Du antwortest");
define("btlng140","Nachricht im Postausgang speichern");
define("btlng141","Sie Haben ( %totmsg% ) Ungelesene Nachricht(en) !");
define("btlng142","Diese Aktion ist ungültig!");
define("btlng143","[b]Der Benutzer [url=".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%]%username%[/url] hat einen Torrent hochgeladen:[/b]\n\n[url=".$GLOBALS["BASEURL"]."/#details?tid=%tid%]%torrentname%[/url]\n\nBitte überprüfen und freischalten/löschen.\n\n");
define("btlng144","Der Benutzer %username% hat einen Torrent hochgeladen.");
define("btlng145","Der Torrent <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=%tid%\"> (%torrentname%) </a> wurde von ' <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> ' hochgeladen.");
define("btlng146","Unbekannte User ID");
define("btlng147","Benutzer Existiert Nicht");
define("btlng148","Benutzer wurde noch nicht bestätigt");
define("btlng149","Benutzerprofil von ");
define("btlng150","Registriert");
define("btlng151","Zuletzt aktiv");
define("btlng152","Hochgeladen");
define("btlng153","Runtergeladen");
define("btlng154","Ratio");
define("btlng155","Rang");
define("btlng155_2","Zu Freunden hinzufügen");
define("btlng155_3","Zu Blockliste hinzufügen");
define("btlng155_4","Von Freundesliste entfernen");
define("btlng155_5","Von Blockliste entfernen");
define("btlng156","Titel");
define("btlng157","Avatar");
define("btlng158","Dieser Account wurde gesperrt");
define("btlng159","Tag");
define("btlng160","Announce Url");
define("btlng161","Kommentare");
define("btlng162","Keine Kommentare gefunden");
define("btlng163","Kommentar-History");
define("btlng164","Dieser Benutzer hat mit einer Spende zum Erhalt des Trackers beigetragen");
define("btlng165","Dieser Benutzer hat %warnpoints% Verwarnpunkte");
define("btlng166","Dieser Benutzer ist deaktiviert");
define("btlng167","Ist noch neu hier");
define("btlng168","Gelöscht");
define("btlng169","Unbekannte Aktion");
define("btlng170","Peer-Adressen");
define("btlng171","IP-Adresse");
define("btlng172","Keine gültige IP angegeben!");
define("btlng173","Es gibt keinen User mit der UID ");
define("btlng174","Benutzer bereits in Deiner Freundesliste");
define("btlng175","Benutzer zu Freundesliste Hinzugefügt");
define("btlng176","Benutzer bereits in deiner Blockliste");
define("btlng177","Benutzer zu Blockliste Hinzugefügt");
define("btlng178","Kein Freund gefunden");
define("btlng179","Blockierter Benutzer nicht gefunden");
define("btlng180","Benutzer von Freundesliste entfernt");
define("btlng181","Benutzer von Blockliste entfernt");
define("btlng182","Freunde und Blockliste");
define("btlng183","Deine Freudeliste ist leer.");
define("btlng184","Freundes Liste");
define("btlng185","Möchtest Du wirklich Benutzer aus der Liste entfernen?");
define("btlng186","Blocks Liste");
define("btlng187","Du hast keine anderen Mitglieder blockiert.");
define("btlng188","Senden");
define("btlng189","Klasse");
define("btlng190","Gespendet");
define("btlng191","Torrentbegrenzung");
define("btlng192","Seeds");
define("btlng193","Leeches");
define("btlng194","Gesamt");
define("btlng195","Ja");
define("btlng196","Nein");
define("btlng197","Tor-Upload Sperren");
define("btlng198","Aktiviert");
define("btlng198_2","Bestätigt");
define("btlng199","Verwarn Punkte");
define("btlng199_2","User Verwarnen");
define("btlng199_3","+1 verwarn punkte hinzufügen + Kommentar");
define("btlng199_4","-1 verwarn punkte entfernen + Kommentar");
define("btlng200","Letzt Verwarnt oder Verwarnung gelöscht");
define("btlng201","Muss Regeln bestätigen");
define("btlng202","Torrentbegrenzung");
define("btlng203","Torrentbegrenzung");
define("btlng204","Speichern");
define("btlng205","Falsche User ID oder Klassen ID.");
define("btlng206","Du musst einen Verwarnungsgrund angeben (z.B. [Zu niedrige Ratio] oder [Ich mag Dich einfach nicht!]).");
define("btlng207","Du musst einen Entwarnungsgrund angeben (z.B. [Ich mag Dich einfach!]).");
define("btlng208","Du musst einen Grund für die Deaktivierung angeben (z.B. Verwarnungsbedingungen nicht erfüllt oder Cheating). Der Benutzer erhält den Grund als E-Mail zugesandt.");
define("btlng209","Torrentbegrenzung geändert: %maxleeches% Leeches, %maxseeds% Seeds");
define("btlng210","Titel geändert auf [%titel%].");
define("btlng211","befördert");
define("btlng212","degradiert");
define("btlng213","promotion");
define("btlng214","demotion");
define("btlng215","[b]Herzlichen Glückwunsch![/b]");
define("btlng216","Du wurdest soeben von [url=".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%] [b]%username%[/b] [/url] zum  %classname% %what%. Wenn etwas an dieser Aktion nicht in Ordnung sein sollte, melde Dich bitte bei dem angegebenen Team mitglied!");
define("btlng217","Du wurdest zum  %classname% %what%");
define("btlng218","Der Benutzer <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% zum  %classname% %what%.");
define("btlng219","Beförderung");
define("btlng220","Degradierung");
define("btlng221","%what% zum %classname%.");
define("btlng222","Du wurdest von %curusername% [url=#rules#warning]verwarnt[/url]. Grund: %warnpm%");
define("btlng223","Verwarnung erteilt.\nGrund: %warnpm%");
define("btlng224","Du wurdest verwarnt");
define("btlng224_2","Verwarn Punkt Sowieso 0");
define("btlng224_3","Maximale Verwarn Punkte Erreicht User wird Gebannt.");
define("btlng225","Der Benutzer <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% verwarnt \n\nGrund:(%warnpm%).");
define("btlng226","Deine Verwarnung wurde von %curusername% zurückgenommen.\n\nFalls die Verwarnung nicht wegen Unrechtmässigkeit zurückgenommen wurde, achte bitte in Zukunft darauf, die Tracker-Regeln ernstzunehmen.");
define("btlng227","Die Verwarnung wurde zurückgenommen");
define("btlng228","Die Verwarnung für Benutzer <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% zurückgenommen \n\nGrund:(%warnpm%).");
define("btlng229","Torrentupload ");
define("btlng230","erlaubt");
define("btlng231","gesperrt");
define("btlng232","Account aktiviert. Grund:\n ");
define("btlng233","Benutzeraccount <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% aktiviert.");
define("btlng234","Account deaktiviert. Grund:\n ");
define("btlng235","Benutzeraccount <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% deaktiviert (Grund: %discomm%).");
define("btlng236","Dein Account auf %sitename% wurde von einem Moderator deaktiviert.
Du kannst dich ab sofort nicht mehr einloggen. Grund fuer diesen Schritt:

%discomm%

Bitte sehe in Zukunft davon ab, Dir einen neuen Account zu erstellen. Dieser
wird umgehend und ohne weitere Warnung deaktiviert werden.

Bei Fragen besuche uns im IRC.");

define("btlng237","Account %username% auf %sitename% wurde deaktiviert");
define("btlng238","Benutzeraccount <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% bestätigt.");
define("btlng239","Benutzeraccount <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde von %curusername% UNbestätigt.");
define("btlng240","Benutzeraccount wurde bestätigt");
define("btlng241","Benutzeraccount wurde UNbestätigt");
define("btlng242","Änderungen Erfolgreich Gespeichert");
define("btlng243","RooT Klasse nicht bestätigbar");
define("btlng244","Root Klasse Kann Nicht Deaktiviert werden!");
define("btlng245","Verwarnung für diese User Klasse wird Ignoriert");
define("btlng246"," Senden ");
define("btlng246_2","Eine E-Mail an (%username%) senden");
define("btlng247","Dein Name");
define("btlng248","Deine E-Mail Adresse");
define("btlng249","Betreff");
define("btlng250","Nachricht");
define("btlng251","Du kannst Dir nicht selber eine E-Mail senden.");
define("btlng252","Dieser Benutzer ist kein Team-Mitglied, und akzeptiert keine E-Mails.");
define("btlng253","Dieser Benutzer ist kein Team-Mitglied, und akzeptiert E-Mails nur von Freunden.");
define("btlng254","Dieser Benutzer ist kein Team-Mitglied, und akzeptiert von Dir keine E-Mails.");
define("btlng255","Die angegebene E-Mail-Adresse scheint ungültig zu sein.");
define("btlng256","(Kein Betreff)");
define("btlng257","Du musst eine Nachricht eingeben!");
define("btlng258","Nachricht gesendet von %ip% am %date%.\n" .
		"Hinweis: Wenn Du auf diese Nachricht antwortest, gibst Du Deine E-Mail-Adresse preis.\n
		---------------------------------------------------------------------\n\n 
		%message%  \n\n 
		---------------------------------------------------------------------\n %sitename% E-Mail Gateway\n");
define("btlng259","Die E-Mail wurde erfolgreich gesendet.");
define("btlng260","Die Mail konnte nicht versendet werden. Entweder ist das Mail-System des Servers nicht verfügbar oder nicht korrekt konfiguriert.");
define("btlng261","Suchen");
define("btlng262","(beliebige Klasse)");
define("btlng263","Zuviele Buchstabe");
define("btlng264","Benutzername");
define("btlng265","Registriert");
define("btlng266","Letzter Zugriff");
define("btlng267","Land");
define("btlng268","in");
define("btlng268_2","Torrents");
define("btlng269","aktiven");
define("btlng270","toten");
define("btlng271","allen");
define("btlng272","Sortieren nach");
define("btlng273","Alle Anzeigen");
define("btlng273_2","Meine Torrents");
define("btlng274","Torrent-Name");
define("btlng275","Kategorie");
define("btlng276","Anzahl Dateien");
define("btlng277","Anzahl Kommentare");
define("btlng278","Upload-Datum");
define("btlng279","Gesamtgrösse");
define("btlng280","Anzahl heruntergeladen");
define("btlng281","Anzahl Seeder");
define("btlng282","Anzahl Leecher");
define("btlng283","Uploader");
define("btlng284","absteigender");
define("btlng285","aufsteigender");
define("btlng286","Suchergebnisse für");
define("btlng287","Reihenfolge");
define("btlng288","Datei(en)");
define("btlng289","Seeder");
define("btlng290","Leecher");
define("btlng291","heruntergeladen");
define("btlng292","Kommentare");
define("btlng292_2","Kommentar");
define("btlng293","Von");
define("btlng294","Nicht Aktiviert");
define("btlng295","Torrent wurde nicht gefunden!");
define("btlng296","Torrent Datei Fehlerhaft!");
define("btlng297","Torrent Datei nicht lesbar!");
define("btlng298","Torrent noch nicht aktiviert!");
define("btlng299","Dateiliste von %torname%");
define("btlng300","No.");
define("btlng301","Dateiname");
define("btlng302","Datei Grösse");
define("btlng303","Details zu %tname%");
define("btlng304","Diese Torrent ist Gebannt");
define("btlng305","Diese Torrent wurde noch nict aktiviert");
define("btlng306","Beschreibung");
define("btlng307","Audio");
define("btlng308","Untertitel");
define("btlng309","Nicht Aktiviert");
define("btlng310","Letzte Aktivität");
define("btlng311","Grösse");
define("btlng312","Hinzugefügt");
define("btlng313","Fertiggestellt");
define("btlng313_2","Fertiggestellt von");
define("btlng314","mal");
define("btlng315","Hochgeladen von ");
define("btlng316","Anzahl Dateien");
define("btlng317","Seed Speed");
define("btlng318","Peers");
define("btlng319","Peer(s) gesamt");
define("btlng320","Diesen Torrent hat noch niemand fertiggestellt.");
define("btlng321","(Fettgedruckte User seeden noch)");
define("btlng322","Ab jetzt wird diese torrent von dir bearbeitet");
define("btlng323","Torrent Erfolgreich freigeschaltet und PM Gesendet");
define("btlng324","Dein Torrent wurde von einem Moderator freigeschaltet!");
define("btlng325","[br]Dein Torrent [url=%torurl%][b]%torname%[/b][/url] wurde von [url=%userlink%][b]%username%[/b][/url] freigeschaltet.[br][br] Du musst nun die Torrent-Datei erneut vom Tracker herunterladen, und kannst dann mit dem Seeden beginnen.[br]");
define("btlng326","NFO");
define("btlng327","NFO anzeigen");
define("btlng328","Ungültige NFO-ID!");
define("btlng329","NFO zu");
define("btlng330","Download NFO");
define("btlng331","Kommentare");
define("btlng332","Bisher noch keine Kommentare");
define("btlng333","Der Torrent <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=%tid%\">%torname%</a> wurde von '<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%curuid%\">%curname%</a>' freigeschaltet.");
define("btlng334","Torrent Bearbeiten");
define("btlng334_2","Torrent Löschen");
define("btlng334_3","Grund");
define("btlng335","als Mod");
define("btlng336","Torrent Aktivieren");
define("btlng337","Ungültige Torrent ID");
define("btlng338","Du musst Text eingeben!");
define("btlng339","Gelöscht");
define("btlng340","Ungültige Kommentar ID");
define("btlng341","Kommentar für %comname% bearbeiten");
define("btlng342","Der Kommentar-Text darf nicht leer sein!");
define("btlng343","Kommentar Gelöscht");
define("btlng344","Kommentar konnte nicht Gelöscht werden ");
define("btlng345","Kommentar Senden");
define("btlng345_2","Zuletzt von");
define("btlng345_3","am");
define("btlng345_4","bearbeitet");
define("btlng346","Mein Profil");
define("btlng347","PNs akzeptieren");
define("btlng348","Alle (ausser blockierte)");
define("btlng349","<b>nur</b> Freunde (Buddyliste)");
define("btlng350","<b>nur</b> Team");
define("btlng351","PNs löschen");
define("btlng352","(Bei Antwort PN l&ouml;schen)");
define("btlng353","PNs speichern");
define("btlng354","(Bei Antwort PN speichern)");
define("btlng355","E-Mails akzeptieren");
define("btlng356","Avatar URL");
define("btlng357","Wget-Kommando");
define("btlng358","Anzeigen<br><br>Dieses Kommando kann dazu benutzt werden, um den gewünschten Torrent schnell über die Kommandozeile herunterzuladen. Wird in der Torrent-Detailansicht angezeigt.");
define("btlng359","E-Mail Addresse");
define("btlng360","Passwort ändern");
define("btlng361","Passwort wiederholen");
define("btlng362","Zurücksetzen!");
define("btlng363","Hinweis : ");
define("btlng364","Du bekommst eine eMail zur Bestätigung zugeschickt!");
define("btlng365","Du hast in Auftrag gegeben, dass Dein Profil (Benutzername %username%)
auf ".$GLOBALS["BASEURL"]." mit dieser E-Mail Adresse (%email%) als Kontaktadresse aktualisiert
werden soll.

Wenn Du dies nicht beauftragt hast, ignoriere bitte diese Mail. Die Person, die
Deine E-Mail Adresse eingegeben hat, hatte die IP-Adresse ( %ip% ).
Bitte antworte nicht auf diese automatisch generierte Nachricht.

Um die Aktualisierung Deines Profils abzuschliessen, klicke auf folgenden Link:

http://".$GLOBALS["BASEURL"]."/#confirmemail?uid=%uid%&secret=%hash%&email=%email%

Die neue E-Mail Adresse wird dann in Deinem Profil erscheinen. Wenn Du
diesen Link nicht anklickst, wird Dein Profil unveraendert bleiben.");
define("btlng366","Profilaenderungsbestaetigung");
define("btlng367"," und Bestätigungsmail wurde versandt");
define("btlng368","Unbekannte Secret oder User ID");
define("btlng369","Unbekannte Secret");
define("btlng370","E-Mail Adresse konnte nicht geändert werden!");
define("btlng371","E-Mail Adresse erfolgreich geändert.");
define("btlng372","XimgDepot");
define("btlng372_2","XimgDepot Öffentlich");
define("btlng372_3","XimgDepot-Inhalt dieses Benutzers anzeigen / bearbeiten");
define("btlng373","Bild Datei");
define("btlng374","Bild Hochladen");
define("btlng375","Erlaubte Bild Datei Endungen : <b>png, jpg, jpeg, gif</b>");
define("btlng376","Es sind zurzeit keine Bild Dateien im XimgDepot vorhanden");
define("btlng376_2","!! Die Suche war Ergebnislos !!");
define("btlng377","Es wurden keine Daten empfangen!");
define("btlng378","Sorry, die hochgeladene Datei konnte nicht als gütige Bilddatei verifiziert werden.");
define("btlng379","Sorry, diese Bild Datei ist zu gross für den XimgDepot.");
define("btlng380","Sorry, Dein XimgDepot is zu voll, um diese Datei aufnehmen zu können. Bitte lösche erst eine oder mehrere Bild Dateien, bevor Du eine weitere hochlädst.");
define("btlng381","Ungültige Dateinamenerweiterung : ");
define("btlng382","Sorry, eine Bild Datei mit dem Namen %imgname% existiert bereits im Deinem XimgDepot.");
define("btlng383","Das hochgeladene Bild konnte nicht verarbeitet werden. Bitte ändere die Grösse selbständig auf Avatargrösse, und versuche den Upload ohne die Option (automatisch anpassen). Die Automatik akzeptiert nur die Formate JPEG und PNG. Animierte GIFs werden nicht unterstützt (ergeben ein statisches Bild).");
define("btlng384","Interner Fehler #2");
define("btlng385","Avatar Erfolgreich Erstellt");
define("btlng386","Dieses Bild ist ein Avatar und soll automatisch auf die richtige Größe gebracht werden.(Nur JPEG und PNG)");
define("btlng387","Öffentlich ");
define("btlng388","Bild Erfolgreich Hochgeladen");
define("btlng389","Bearbeiten");
define("btlng390","Sie können diesem bild nicht löschen");
define("btlng391","Bild datei (%imgname%) erfolgreich gelöscht.");
define("btlng392","Bild datei könnte nicht gelöscht werden!");
define("btlng393","Nein");
define("btlng394","Ja");
define("btlng395","Bild datei existiert nicht!");
define("btlng396","Sie können diesem bild nicht bearbeiten");
define("btlng397","Bild Datei (%imgname%) Bearbeiten");
define("btlng398","Bild Name");
define("btlng399","Bild Name darf nicht leer sein!");
define("btlng400","Änderung erfolgreich gespeichert.");
define("btlng401","noch frei");
define("btlng402","ist belegt");
define("btlng403","%size% von %maxsize% belegt. (Frei %perc% %)");
define("btlng404","Torrent Name");
define("btlng405","Du darfst diesen Torrent nicht bearbeiten");
define("btlng406","NFO Datei");
define("btlng406_2","Bilder");
define("btlng407","Audio");
define("btlng408","Untertitel");
define("btlng409","Beschreibung");
define("btlng410","Sichtbar");
define("btlng411","Beachten Sie, dass der torrent wird automatisch sichtbar, wenn es eine seeder, und wird automatisch unsichtbar (tot), wenn es keine seeder gibt. Verwenden Sie diesen Schalter, um den Prozess zu beschleunigen manuell. Beachten Sie auch, dass unsichtbare (tote) torrents immer noch angezeigt oder gesucht werden.");
define("btlng412","Sichtbar auf der Torrentsseite");
define("btlng413","Gebannt");
define("btlng414","Diesen Torrent bannen");
define("btlng414_2","Torrent Gebannt");
define("btlng415","VIP");
define("btlng416","VIP Torrent");
define("btlng417","Fehlende Formulardaten!");
define("btlng418","Bitte geben Sie ein Torrent Name an");
define("btlng419","Ändern (leer lassen, um Bilder zu löschen)");
define("btlng420","Der Torrent <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=%tid%\">%tid% (%name%)</a> wurde von <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%curid%\">%curname%</a> bearbeitet.");
define("btlng421","Dein Account auf %sitename% wurde gelöscht. Dies ist entweder passiert,
		      weil Du Dich längere Zeit nicht mehr eingeloggt hast, oder Dein Account von einem
		      RooT deaktiviert wurde.

		      Diese E-Mail dient dazu, Dich darüber zu informieren, dass Du diesen Account nun nicht
		      mehr nutzen kannst. Bitte antworte nicht auf diese E-Mail!");
define("btlng421_2","Account gelöscht auf");
define("btlng422","Der Benutzer '%username%' mit der ID %uid% wurde aus der Datenbank gelöscht.");
define("btlng423","Verwarnung Punkt Entfernt");
define("btlng424","1 Verwarnung Punkt wurde automatisch entfernt.");
define("btlng425","1 Verwarnung Punkte von <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde vom System entfernt.");
define("btlng426","Du wurdest zum Power User befördert");
define("btlng427","Glückwunsch, Du wurdest automatisch zum [b]Power User[/b] befördert. :)\n\n");
define("btlng428","Der Benutzer <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde automatisch zum Power User befördert.");
define("btlng429","Automatische Beförderung zum Power User.");
define("btlng430","Du wurdest zum 'User' degradiert");
define("btlng431","Du wurdest automatisch vom [b]Power User[/b] zum [b]User[/b] degradiert, da Deine Share-Ratio unter %minratio% gefallen ist.\n");
define("btlng432","Der Benutzer <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> wurde automatisch zum User degradiert.");
define("btlng433","Automatische Degradierung zum User.");
define("btlng434","Dein Torrent %torname% wurde von [url=".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%] %username% [/url] gelöscht.\n\n[b]Grund:[/b]\n %comment%");
define("btlng435","Einer Deiner Torrents wurde gelöscht");
define("btlng436","Dein Torrent %torname% wurde automatisch vom System gelöscht. (Inaktiv und älter als %days% Tage oder noch nicht aktiviert).\n");
define("btlng437","Torrent [%tid%] (%torname%) wurde vom System gelöscht (Inaktiv und älter als %days% Tage)");
define("btlng438","Offen");
define("btlng439","Geschlossen");
define("btlng440","Peerlist von ");
define("btlng441","Bitte gebe einen Grund an, warum dieser Torrent gelöscht werden soll");
define("btlng442","Dir gehört der Torrent nicht!");
define("btlng443","Der Torrent %tid% (%name%) wurde von <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=%uid%\">%username%</a> gelöscht (%reason%)\n");
define("btlng444","Torrent wurde erfolgreich gelöscht");
define("btlng445","Client Name");
define("btlng446","Banned");
define("btlng447","Client Bannen");
define("btlng448","Änderungen gespeichert");
define("btlng449","Ja");
define("btlng450","Nein");
define("btlng451","Seeders");
define("btlng452","Leechers");
define("btlng453","Downloaded");
define("btlng454","Uploaded");
define("btlng455","Registrierte Mitglieder");
define("btlng456","Unbestätigte Mitglieder");
define("btlng457","Deaktivierte Accounts");
define("btlng458","Aktive Torrents");
define("btlng459","Inaktive Torrents");
define("btlng460","Deine Nachricht ist zu Kurz");
define("btlng460_1","Textfeld Leer oder Ungültige ID");
define("btlng461","Shoutbox Eintrag Gelöscht");
define("btlng462","Shoutbox Eintrag Könnte Nicht Gelöscht Werden");
define("btlng463","Shoutbox Eintrag Geändert");
define("btlng464","Montag");
define("btlng465","Dienstag");
define("btlng466","Mittwoch");
define("btlng467","Donnerstag");
define("btlng468","Freitag");
define("btlng469","Samstag");
define("btlng470","Sonntag");
define("btlng471","Nachricht Bearbeiten");
define("btlng472","Nachricht Löschen");
define("btlng473","Neue Nachricht Schreiben");
define("btlng474","Keine Einträge vorhanden");
define("btlng475","Ungültige Nachricht ID");
define("btlng476","Nachricht Exsistiert Nicht");
define("btlng477","Nachricht Titel ist Leer!!");
define("btlng478","Nachricht Body ist Leer!!");
define("btlng479","Nachricht Gelöscht");
define("btlng480","Neue Nachticht wurde Hinzugefügt");
define("btlng481","Selektiere erst den zu formatierenden Text!");
define("btlng482","Benutzer oder IP Bannen");
define("btlng483","Bannen");
define("btlng484","Nichts Gefunden!");
define("btlng485","Ungültige ID");
define("btlng486","Bitte geben Sie einen Kommentar ein!");
define("btlng487","Benutzer Gebannt");
define("btlng488","Selbst Bannen Geht Nicht");
define("btlng489","Root, Admin und Moderator kann nicht gebannt werden");
define("btlng490","Erste IP");
define("btlng491","Letzte IP");
define("btlng492","User ID");
define("btlng493","Ip's mit dieser uid löschen");
define("btlng494","User ID IP's Gelöscht");
define("btlng495","IP Gelöscht");
define("btlng496","Benutzer ID");
define("btlng497","Ungültige Ip-Adresse");
define("btlng498","Ungültige Aktion");
define("btlng499","Ban ID(%bid%) wurde von UID(%uid%) (%username%) entfernt");
define("btlng500","IP Bereich (%fip% - %lip%) wurde von UID(%uid%) (%username%) gebannt");
define("btlng501","User ID(%buid% - %busername%) wurde von UID(%uid%) (%username%) gebannt");
define("btlng502","Aktuelle Umfrage");
define("btlng503","Es gibt keine Umfrage");
define("btlng504","Umfrage Erstellen");
define("btlng505","Frage");
define("btlng506","Option");
define("btlng507","Ungültige Umfrage ID");
define("btlng508","Keine Umfrage mit diese ID gefunden");
define("btlng509","Umfrage Erfolgreich Erstellt");
define("btlng510","Umfrage Könnte nicht Erstellt werden");
define("btlng511","Umfrage Erfolgreich Bearbeitet");
define("btlng512","Umfrage konnte nicht bearbeitet werden");
define("btlng513","Frage oder mindestens 2 optionen fehlen");
define("btlng514","Abgebene Stimmen");
define("btlng515","Ich will keine Stimme abgeben, ich möchte nur das Ergebnis sehen!");
define("btlng516","Passwort vergessen");
define("btlng517","Verlorenes Passwort und/oder Benutzernamen wiederfinden");
define("btlng518","Benutze das folgende Formular, und Deine Account-Daten werden Dir umgehend per Mail zugesandt.<br> (Du musst zuerst eine Bestätigungsmail beantworten)");
define("btlng519","Verwendete E-Mail Adresse : ");
define("btlng520","Du musst eine E-Mail Adresse eingeben");
define("btlng521","Die E-Mail Adresse (%email%) wurde nicht in der Datenbank gefunden");
define("btlng522","Datenbankfehler. Bitte informiere den RooT darüber.");
define("btlng523","Jemand, hoffentlich Du, hat ein neues Passwort fuer den Account
beantragt, mit dem diese E-Mail Adresse (%email%) verknuepft ist.
Die Anfrage wurde von der IP %ip% gestellt.

Wenn Du dies nicht getan hast, ignoriere diese Mail einfach, und
antwtorte nicht darauf.


Wenn Du die Anfrage bestaetigen moechtest, klicke auf folgenden Link:

%url%


Nachdem Du dies getan hast, wird Dein Passwort zurueckgesetzt und Dir
per Mail zugestellt.
--
".$GLOBALS["SITENAME"]);

define("btlng524","Passwort Zuruecksetzen");
define("btlng525","Die E-Mail könnte nicht gesendet werden. Bitte informiere den RooT darüber.");
define("btlng526","Eine Bestätigungsmail wurde an (%email%) versandt.Bitte habe einen Moment Geduld, bis die Mail angekommen ist.");
define("btlng527","Ungültige Wert");
define("btlng528","Passwort Erfolgreich geändert . Sie können sich jetzt einloggen.");
define("btlng529","Passwort Ändern");
define("btlng530","Stil");
define("btlng531","Sprache");
define("btlng532","Sie haben neue regeln akzeptiert.");
define("btlng533","Ich akzeptiere neue regeln");






















?>