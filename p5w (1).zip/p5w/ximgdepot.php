<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

 if(isset($_GET["act"])){$act=$_GET["act"];}else{$act="";}
 if(isset($_GET["imgid"])){$imgid=htmlchar(0+$_GET["imgid"]);}else{$imgid="";}
 if(isset($_GET["saveedit"])){$saveedit=0+$_GET["saveedit"];}else{$saveedit="";}

if(isset($_GET["uid"]) && $_GET["uid"] != $CURUSER["uid"] && get_user_class() >= UC_MODERATOR){
    $uid=htmlchar(0+$_GET["uid"]);

    $linkparam="&uid=$uid";

    $resuc = mysql_query("SELECT class FROM users WHERE uid = ".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);
    $rowuc = mysql_fetch_row($resuc);

    if($rowuc[0] == UC_ROOT && get_user_class() != UC_ROOT){
	errmsg(btlng26_2,btlng26_2);
    }

  }else{
      $uid=$CURUSER["uid"];
    $linkparam="";
    }

# DELETE IMAGE
if($act=="del" && is_valid_id($imgid)){

    $res = mysql_query("SELECT imguid, orgname, filename FROM ximgdepot WHERE imguid = ".sqlesc($uid)." AND imgid=".sqlesc($imgid)) or sqlerr(__FILE__, __LINE__);
    $row = mysql_fetch_row($res);

	if(!$row){
	     infoerr(btlng395);
	  }

  	    if($row[0] != $CURUSER["uid"] && get_user_class() < UC_MODERATOR){
		      infoerr(btlng390);
		}
      
	mysql_query("DELETE FROM ximgdepot WHERE imguid = $uid AND imgid=".sqlesc($imgid));
  
	if($imgid && mysql_affected_rows() > 0){
		      infok(str_replace("%imgname%",$row[1],btlng391));
			if(file_exists($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/".$row[2])){
			    unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/".$row[2]);
			  }
		}else{
		      infoerr(btlng392);
		      }

    go_to("ximgdepot:$time$linkparam");

  }


# EDIT IMAGE
elseif($act=="edit" && is_valid_id($imgid)){



    $res = mysql_query("SELECT imguid, orgname, filename, public FROM ximgdepot WHERE imguid = ".sqlesc($uid)." AND imgid=".sqlesc($imgid)) or sqlerr(__FILE__, __LINE__);
    $row = mysql_fetch_row($res);

	if(!$row){
	     errmsg(btlng32,btlng395);
	  }

  	    if($row[0] != $CURUSER["uid"] && get_user_class() < UC_MODERATOR){
		      errmsg(btlng32,btlng396);
		}

	    $imgext=strtolower(fext($row[1]));

     if($saveedit){
	  if(isset($_GET["public"])){$epublic=1;}else{$epublic=0;}
	  if(isset($_GET["imgname"])){$imgname=htmlchar($_GET["imgname"]);}else{$imgname="";}

		if(!$imgname){
		    infoerr(btlng399);  
		  }

		mysql_query("UPDATE ximgdepot SET orgname=".sqlesc($imgname.".$imgext").", public = $epublic WHERE imguid = ".sqlesc($uid)." AND imgid = ".sqlesc($imgid)) or sqlerr(__FILE__, __LINE__);

		infok(btlng400);

                go_to("ximgdepot:$time$linkparam");

	   }else{

		$title=str_replace("%imgname%",$row[1],btlng397);
		title($title,$title);

		?>
		<script>
			    $('#saveedit').click(function() {
					    $.get("<?php echo $GLOBALS["BASEURL"];?>/ximgdepot.php", {
						  act: "edit", saveedit: 1, imgid: '<?php echo $imgid;?>', imgname: $('#imgname').val(), public: $('#public:checked').val(), uid: '<?php echo $uid?>' }, function(data) {
					      $("#info").html(data);
					    });
			    });
		</script>
		<?php


		    if($row[3]){$pchecked=" checked=\"checked\" ";}else{$pchecked="";}

			  echo "<br><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\" id=\"ximgdepot_table\">
					<div class=\"tr\" id=\"ximgdepot_tr\">
					  <div class=\"td\" id=\"ximgdepot_td\">
					      <center><img class=\"imgborder\" width=\"100px\" src=\"".$GLOBALS["XIMGDEPOT_DIR"]."/".$row[2]."\" title=\"".$row[1]."\"></center> 
					  </div>
				      </div>  
					<div class=\"tr\" id=\"ximgdepot_tr\">
					  <div class=\"td\" id=\"ximgdepot_td\">
					      ".btlng398." : <input id=\"imgname\" value=\"".str_replace(".$imgext","",$row[1])."\" size=\"72\"> 
					  </div>
				      </div>  ";  
			    if($row[0] == $CURUSER["uid"]){
				echo "<div class=\"tr\" id=\"ximgdepot_tr\">
					  <div class=\"td\" id=\"ximgdepot_td\">
					      ".btlng387." : <input id=\"public\" type=\"checkbox\" $pchecked> 
					  </div>
				      </div>"; 
				    }
				 echo "<div class=\"tr\" id=\"ximgdepot_tr\">
					  <div class=\"td\" id=\"ximgdepot_td\">
					      <center><a href=\"javascript:;\" class=\"buttonsilver\" id=\"saveedit\">".btlng204."</a></center>
					  </div>
				      </div> 
			      ";

		echo "</div></div>";

             }

  }

else{

 if($CURUSER["class"]>=UC_UPLOADER) {
    $max_imgdepotsize = $GLOBALS["MAX_XIMGDEPOT_SIZE_UPLOADER"];
 } else {
    $max_imgdepotsize = $GLOBALS["MAX_XIMGDEPOT_SIZE_USER"];
  }

 title(btlng372,"[img=".$GLOBALS["BASEURL"]."/$stylelink/ximgdepot.png] ".btlng372);

?>

<script type="text/javascript" src="js/jquery.upload.js"></script>

<script>
    $(function() {
        $('#ximgdepotupload').click(function() {
            $('#files').upload('<?php echo $GLOBALS["BASEURL"];?>/ximgdepotupload.php', function(res) {
	    $('#info').html(res);
	      window.location.replace("<?php echo $GLOBALS["BASEURL"]."/#ximgdepot?$time";?>");
            }, 'html');
        });
    });

       // DEL IMAGE
	function delimg(imgid){
         if (confirm('<?php echo btlng120;?>')) {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/ximgdepot.php", {act: "del", imgid: imgid, uid: '<?php echo $uid?>'}, function(data) {
			      $("#info").html(data);
			    });
	   }
         }


  </script>

 
<?php

    $size = mysql_result(mysql_query("SELECT SUM(size) FROM ximgdepot WHERE imguid=".sqlesc($uid)),0);
	$percent = min(100,round($size/$max_imgdepotsize*100));
        if($percent <= 70) { 
		$pic = "loadbargreen.gif";
	    } elseif($percent <= 90){ 
			$pic = "loadbaryellow.gif";
		      } else {
			    $pic = "loadbarred.gif";
			  }
        $width = $percent * 4;
	  $percxfree=100-$percent;

 echo "<br><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\" id=\"ximgdepot_table\">
         <div class=\"tr\" >
	    <div class=\"td\" id=\"ximgdepot_td\">
	       <div id=\"files\"> 
			<p style=\"padding:1px;\">".btlng373." : <input name=\"imgfile\" type=\"file\" size=\"64\"></p>
			<p style=\"padding:1px;\"><center><font color=\"red\"><b>Max. ".mksize($GLOBALS["MAX_XIMGDEPOT_UPLOAD_SIZE"])."</b></font><br> ".btlng375."</center></p> 
			<p style=\"padding:1px;\"><input name=\"avatar\" type=\"checkbox\"> <u>".btlng386."</u></p>
			<p style=\"padding:1px;\"><input name=\"public\" type=\"checkbox\"> <u>".btlng387."</u></p>
	       </div>
	    </div>
         </div>

         <div class=\"tr\" id=\"ximgdepot_tr1\">
	    <div class=\"td\" id=\"ximgdepot_td\" style=\"text-align:left;padding:0px;width:400px;height:20px;\">
		<center><p title=\"$percxfree % ".btlng401."\" style=\"text-align:left;padding:0px;width:400px;height:20px;background-image:url('".$GLOBALS["IMAGES_DIR"]."/loadbarbg.gif'); background-repeat: repeat-x\">
		    <img src=\"".$GLOBALS["IMAGES_DIR"].$pic."\" height=\"15\" width=\"$width\" title=\"$percent % ".btlng402."\"> <b style=\"font-size:10pt;vertical-align:top;\">$percent %</b>
		     <p>".str_replace(array("%size%","%maxsize%","%perc%"),array(mksize($size),mksize($max_imgdepotsize),$percxfree),btlng403)."</p>
		</p></center>
	    </div>
         </div>

         <div class=\"tr\">
	    <div class=\"td\" id=\"ximgdepot_td\">
	      <center><a id=\"ximgdepotupload\" class=\"buttonsilver\" href=\"javascript:;\">".btlng374."</a></center>
	    </div>
         </div>

       </div></div>";


     $imgrow=mysql_query("SELECT * FROM ximgdepot WHERE imguid = ".sqlesc($uid)." ORDER BY imgid DESC") or sqlerr(__FILE__, __LINE__);
 

 echo "<br><br><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\" id=\"ximgdepot_table\">";

	  if(!mysql_num_rows($imgrow)){
	    echo "<div class=\"tr\"><div class=\"td\" id=\"ximgdepot_td\">
	              <center> ".btlng376."</center>
		  </div></div>";
	    }else{

	echo '<div class=\"tr\" id=\"ximgdepot_tr\">
		<script type="text/javascript" src="/min/?b=js&amp;f=FancyZoomHTML.js,FancyZoom.js"></script>
		<script>setupZoom();</script>';
		    $prow=0;

		    while($imgres=mysql_fetch_row($imgrow)){
			  $imgi=0;
				$imgid=$imgres[$imgi++];
				$imguid=$imgres[$imgi++];
				$imgsize=mksize($imgres[$imgi++]);
				$imgfilename=$imgres[$imgi++];
				$imgorgname=$imgres[$imgi++];
				$imgpublic=$imgres[$imgi++];



				      # IMAGE NAME LENGTH
				      if(strlen($imgorgname) > 21){
					      $imgorgname2=substr($imgorgname, 0, 21)."..";
					      }
					      else{
						  $imgorgname2=$imgorgname;
						}
					    # PUBLIC YES OR NO
					    $public="<font color=\"green\"><b>".btlng393."</b></font>";
						if($imgpublic){
							$public="<font color=\"red\"><b>".btlng394."</b></font>";
						    }

				echo " <div class=\"td\" id=\"ximgdepot_td\" style=\"width:20%;\">
					    <p><a href=\"".$GLOBALS["XIMGDEPOT_DIR"]."/$imgfilename\" title=\"$imgorgname&nbsp;&nbsp;\"><img class=\"imgborder\" src=\"".$GLOBALS["XIMGDEPOT_DIR"]."/$imgfilename\"  title=\"$imgorgname\" width=\"80px\"></a></p> \n
					    <p>&nbsp;$imgorgname2</p>\n
					    <p>&nbsp;<u>$imgsize</u></p>\n
					    <p>&nbsp;".btlng387.": $public</p>\n
					    <p>&nbsp;
					       <a href=\"".$GLOBALS["BASEURL"]."/#ximgdepot?act=edit&imgid=$imgid$linkparam\"><img src=\"$stylelink/imgedit.png\"  title=\"".btlng389."\"></a> 
					       <a href=\"javascript:;\" onclick=\"delimg('$imgid')\"><img src=\"$stylelink/imgdel.png\"  title=\"".btlng117."\"></a></p>\n
				      </div> ";
		    
			      $prow++;

				if($prow%5 == 0){
					  echo "</div><div class=\"tr\" id=\"ximgdepot_tr\">";	
				      }
				
			 }

		  }

     echo "</div>
       </div></div>";
}



?>