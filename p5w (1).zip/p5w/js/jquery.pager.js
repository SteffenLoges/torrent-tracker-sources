(function($){$.fn.pager=function(options){var opts=$.extend({},$.fn.pager.defaults,options);return this.each(function(){$(this).empty().append(renderpager(parseInt(options.pagenumber),parseInt(options.pagecount),options.buttonClickCallback));$('.pages li').mouseover(function(){document.body.style.cursor="pointer";}).mouseout(function(){document.body.style.cursor="auto";});});};function renderpager(pagenumber,pagecount,buttonClickCallback){var $pager=$('<ul class="pages"></ul>');$pager.append(renderButton('<<',pagenumber,pagecount,buttonClickCallback)).append(renderButton('<',pagenumber,pagecount,buttonClickCallback));var startPoint=1;var endPoint=9;if(pagenumber>4){startPoint=pagenumber-4;endPoint=pagenumber+4;}
if(endPoint>pagecount){startPoint=pagecount-8;endPoint=pagecount;}
if(startPoint<1){startPoint=1;}
for(var page=startPoint;page<=endPoint;page++){var currentButton=$('<li id="pno" class="page-number">'+(page)+'</li>');page==pagenumber?currentButton.addClass('pgCurrent'):currentButton.click(function(){buttonClickCallback(this.firstChild.data);});currentButton.appendTo($pager);}
$pager.append(renderButton('>',pagenumber,pagecount,buttonClickCallback)).append(renderButton('>>',pagenumber,pagecount,buttonClickCallback));return $pager;}
function renderButton(buttonLabel,pagenumber,pagecount,buttonClickCallback){var $Button=$('<li class="pgNext">'+buttonLabel+'</li>');var destPage=1;switch(buttonLabel){case"<<":destPage=1;break;case"<":destPage=pagenumber-1;break;case">":destPage=pagenumber+1;break;case">>":destPage=pagecount;break;}
if(buttonLabel=="<<"||buttonLabel=="<"){pagenumber<=1?$Button.addClass('pgEmpty'):$Button.click(function(){buttonClickCallback(destPage);});}
else{pagenumber>=pagecount?$Button.addClass('pgEmpty'):$Button.click(function(){buttonClickCallback(destPage);});}
return $Button;}
$.fn.pager.defaults={pagenumber:1,pagecount:1};})(jQuery);

/*
(function($){$.fn.pager=function(options){var opts=$.extend({},$.fn.pager.defaults,options);return this.each(function(){$(this).empty().append(renderpager(parseInt(options.pagenumber),parseInt(options.pagecount),options.buttonClickCallback));$('.pages li').mouseover(function(){document.body.style.cursor="pointer";}).mouseout(function(){document.body.style.cursor="auto";});});};function renderpager(pagenumber,pagecount,buttonClickCallback){var $pager=$('<ul class="pages"></ul>');$pager.append(renderButton('<<',pagenumber,pagecount,buttonClickCallback)).append(renderButton('<',pagenumber,pagecount,buttonClickCallback));var startPoint=1;var endPoint=9;if(pagenumber>4){startPoint=pagenumber-4;endPoint=pagenumber+4;}
if(endPoint>pagecount){startPoint=pagecount-8;endPoint=pagecount;}
if(startPoint<1){startPoint=1;}
for(var page=startPoint;page<=endPoint;page++){var currentButton=$('<li id="pno" class="page-number">'+(page)+'</li>');page==pagenumber?currentButton.addClass('pgCurrent'):currentButton.click(function(){$.history.load("myvideos?pno="+this.firstChild.data);});currentButton.appendTo($pager);}
$pager.append(renderButton('>',pagenumber,pagecount,buttonClickCallback)).append(renderButton('>>',pagenumber,pagecount,buttonClickCallback));return $pager;}
function renderButton(buttonLabel,pagenumber,pagecount,buttonClickCallback){
var $Button=$('<li class="pgNext">'+buttonLabel+'</li>');
var destPage=1;
switch(buttonLabel){
case"<<":destPage=1;break;
case"<":destPage=pagenumber-1;break;
case">":destPage=pagenumber+1;break;
case">>":destPage=pagecount;break;}
if(buttonLabel=="<<"||buttonLabel=="<"){
pagenumber<=1?$Button.addClass('pgEmpty'):$Button.click(function(){$.history.load("myvideos?pno="+destPage);});}
else{
pagenumber>=pagecount?$Button.addClass('pgEmpty'):$Button.click(function(){$.history.load("myvideos?pno="+destPage);});}
return $Button;}
$.fn.pager.defaults={pagenumber:1,pagecount:1};})(jQuery);
*/