<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(get_user_class() < UC_MODERATOR){
errmsg(btlng26_2,btlng26_2);
}

if(isset($_GET["uid"])){$uid=0+$_GET["uid"];}else{$uid="";}
if(isset($_GET["title"])){$title=htmlchar($_GET["title"]);}else{$title="";}
if(isset($_GET["avatar"])){$avatar=htmlchar($_GET["avatar"]);}else{$avatar="";}
if(isset($_GET["email"])){$email=htmlchar($_GET["email"]);}else{$email="";}
if(isset($_GET["donor"])){$donor=0+$_GET["donor"];}else{$donor="";}
if(isset($_GET["uclass"])){$uclass=0+$_GET["uclass"];}else{$uclass="";}
if(isset($_GET["userwarn"])){$userwarn=$_GET["userwarn"];}else{$userwarn="";}
if(isset($_GET["warncomm"])){$warncomm=htmlchar($_GET["warncomm"]);}else{$warncomm="";}
if(isset($_GET["maxseeds"])){$maxseeds=0+$_GET["maxseeds"];}else{$maxseeds="";}
if(isset($_GET["maxleeches"])){$maxleeches=0+$_GET["maxleeches"];}else{$maxleeches="";}
if(isset($_GET["denyupload"])){$denyupload=0+$_GET["denyupload"];}else{$denyupload="";}
if(isset($_GET["acceptrules"])){$acceptrules=0+$_GET["acceptrules"];}else{$acceptrules="";}
if(isset($_GET["enabled"])){$enabled=0+$_GET["enabled"];}else{$enabled="";}
if(isset($_GET["confirmed"])){$confirmed=0+$_GET["confirmed"];}else{$confirmed="";}
if(isset($_GET["disabledcomm"])){$disabledcomm=htmlchar($_GET["disabledcomm"]);}else{$disabledcomm="";}


    if(!is_valid_id($uid) || !is_valid_user_class($uclass))
      {
	errmsg(btlng32,btlng205);
	}

    // check target user class
    $resuser = mysql_query("SELECT email, title, enabled, username, class, tmaxseeds, tmaxleechs, allowupload, uploaded, downloaded, confirmed, donor, warnpoints, acceptrules FROM users WHERE uid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);
    $arruser = mysql_fetch_row($resuser);
    
    $us_email=$arruser[0];
    $us_title=$arruser[1];
    $us_enabled=$arruser[2];
    $us_username=$arruser[3];
    $us_class=$arruser[4];
    $us_tmaxseeds=$arruser[5];
    $us_tmaxleechs=$arruser[6];
    $us_allowupload=$arruser[7];
    $us_uploaded=$arruser[8];
    $us_downloaded=$arruser[9];
    $us_confirmed=$arruser[10];
    $us_donor=$arruser[11];
    $us_warnpoints=$arruser[12];
    $us_acceptrules=$arruser[13];

    // User may not edit someone with same or higher class than himself!
    if(get_user_class() != UC_ROOT && $us_class >= get_user_class()){
	errmsg(btlng26_2,btlng26_2);
      }


    if($userwarn=="add" && $warncomm == ""){
	infoerr(btlng206);
      }

    if($userwarn=="del" && $warncomm == ""){
	infoerr(btlng207);
      }

    if($enabled != $us_enabled && $enabled == 0 && $disabledcomm == ""){
	infoerr(btlng208);
      }

# USER SEEDS AND LEECHES LIMIT

    if ($maxseeds <> intval($us_tmaxseeds) || $maxleeches <> intval($us_tmaxleechs)) {
        $updateuser[] = "tmaxseeds = " . sqlesc($maxtotal);
        $updateuser[] = "tmaxleeches = " . sqlesc($maxseeds);
        write_modcomment($uid, $CURUSER["uid"],  str_replace(array("%maxleeches%","%maxseeds%"),array("$maxleeches","$maxseeds"),btlng209));
    } 

    if($us_title != $title &&  $title) {
        write_modcomment($uid, $CURUSER["uid"], str_replace("%titel%",$title ,btlng210));
    } 

# NOTIFY USER
    if ($us_class != $uclass) {

        $what = ($uclass > $us_class ? btlng211 : btlng212);

        $type = ($uclass > $us_class ? btlng213 : btlng214);

        $msg = sqlesc(($uclass > $us_class? btlng215." ":"") . str_replace(array("%username%","%uid%", "%classname%","%what%"),array($CURUSER["username"],$CURUSER["uid"],get_user_class_name($uclass),$what),btlng216));
    
	$msgsubject = str_replace(array("%classname%","%what%"),array(get_user_class_name($uclass),$what),btlng217);

      # SEND PM
	mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
	".implode(",", array_map("sqlesc", array(
	  0, 
	  $uid, 
	  4,  
	  $time,
	  $msgsubject,
	  $msg))).")");

        write_log($type, str_replace(array("%uid%","%username%","%curusername%","%classname%","%what%"),array($uid,$us_username,$CURUSER["username"],get_user_class_name($uclass),$what),btlng218));

        $updateuser[] = "class = ".sqlesc($uclass);

        $what = ($uclass > $us_class ? btlng219 : btlng220);

        write_modcomment($uid, $CURUSER["uid"], str_replace(array("%what%","%classname%"),array($what,get_user_class_name($uclass)),btlng221)); 
        
	// User has to re-accept rules if promoted to anything higher than UC_VIP
        if($uclass > UC_VIP && $us_class < $uclass){
            $updateuser[] = "acceptrules = '0'";
	  }
    } 

if(($userwarn=="add" || $userwarn=="del") && $us_class < UC_MODERATOR){
	# ADD USERWARNING

	    if($userwarn=="add" && $warncomm && $us_warnpoints < $GLOBALS["MAX_USER_WARN_POINTS"]){
	      $warnaddmsg=str_replace(array("%curusername%","%warnpm%"),array($CURUSER["username"],$warncomm),btlng222);

		write_modcomment($uid, $CURUSER["uid"], str_replace("%warnpm%",$warncomm ,btlng223));
		write_log("addwarn", str_replace(array("%uid%","%username%","%curusername%","%warnpm%"),array($uid,$us_username,$CURUSER["username"],$warncomm),btlng225));

	      # SEND PM
		mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
		".implode(",", array_map("sqlesc", array(
		  0, 
		  $uid, 
		  4,  
		  $time,
		  btlng224,
		  $warnaddmsg))).")");

	      if(($us_warnpoints + 1) >= $GLOBALS["MAX_USER_WARN_POINTS"]){
	    	      $updateuser[] = "enabled = 0";
		  }

	      $updateuser[] = "warnpoints = warnpoints + 1";
	      $updateuser[] = "lastwarned = ".sqlesc($time);
	      }
		elseif($userwarn=="add" && $warncomm && $us_warnpoints >= $GLOBALS["MAX_USER_WARN_POINTS"]){
		  infoerr(btlng224_3);
		  }

	# DEL USERWARNING

	    if($userwarn=="del" && $warncomm && $us_warnpoints != 0){
	      $warndelmsg=str_replace("%curusername%",$CURUSER["username"],btlng226);

		write_modcomment($uid, $CURUSER["uid"], btlng227);
		write_log("delwarn", str_replace(array("%uid%","%username%","%curusername%","%warnpm%"),array($uid,$us_username,$CURUSER["username"],$warncomm),btlng228));

	      # SEND PM
		mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
		".implode(",", array_map("sqlesc", array(
		  0, 
		  $uid, 
		  4,  
		  $time,
		  btlng227,
		  $warndelmsg))).")");

		      $updateuser[] = "warnpoints = warnpoints - 1";
		      $updateuser[] = "lastwarned = ".sqlesc($time);
	      }
		elseif($userwarn=="del" && $warncomm && $us_warnpoints == 0){
		  infoerr(btlng224_2);
		  }

  } 
    elseif(($userwarn=="add" || $userwarn=="del") && $us_class >= UC_MODERATOR){
        infoerr(btlng245);
     }



# DENY AND ALLOW UPLOAD

    if($denyupload != $us_allowupload) {
        $updateuser[] = "allowupload = ".sqlesc($denyupload);
	 if($denyupload==1){
		$allowmsg=btlng229.btlng230;
	      }else{
		  $allowmsg=btlng229.btlng231;
		}
        write_modcomment($uid, $CURUSER["uid"], $allowmsg);
    }

# ENABLE AND DISABLE USER


      if($enabled != $us_enabled && $us_class != UC_ROOT) {
        if ($enabled == 1) {
            write_modcomment($uid, $CURUSER["uid"], btlng232 .$disabledcomm);
            write_log("accenabled", str_replace(array("%uid%","%username%","%curusername%"),array($uid,$us_username,$CURUSER["username"]),btlng233));
	    } else {
		  write_modcomment($uid, $CURUSER["uid"], btlng234.$disabledcomm);
		  write_log("accdisabled", str_replace(array("%uid%","%username%","%curusername%","%discomm%"),array($uid,$us_username,$CURUSER["username"],$disabledcomm),btlng235));

		  $mailbody = str_replace(array("%sitename%","%discomm%"),array($GLOBALS["SITENAME"],$disabledcomm),btlng236);

	    # SEND DISABLE EMAIL
            mail($email, str_replace(array("%username%","%sitename%"),array($us_username,$GLOBALS["SITENAME"]),btlng237), $mailbody);
        } 
     $updateuser[] = "enabled = ".sqlesc($enabled);
    } 
      elseif($enabled != $us_enabled && $enabled == 0 && $us_class == UC_ROOT) {
  	             infoerr(btlng244);
	    }

# CONFIRM USER

	  if($confirmed != $us_confirmed  && $us_class != UC_ROOT) {
		if($confirmed == 1){
		      write_modcomment($uid, $CURUSER["uid"], btlng240);
		      write_log("userconfirmed", str_replace(array("%uid%","%username%","%curusername%"),array($uid,$us_username,$CURUSER["username"]),btlng238));
		   } else{
			write_modcomment($uid, $CURUSER["uid"], btlng241);
			write_log("userunconfirmed", str_replace(array("%uid%","%username%","%curusername%"),array($uid,$us_username,$CURUSER["username"]),btlng239));
		  }
            $updateuser[] = "confirmed = ".sqlesc($confirmed);
	    } elseif($confirmed != $us_confirmed && $confirmed == 0 && $us_class == UC_ROOT) {
  	             infoerr(btlng243);
	    }

# CHANGE USER EMAIL AND DONOR

    if($CURUSER["class"] == UC_ROOT){

# EMAIL

	if($email != $us_email){

	    // check if email addy is already in use
	      $chek_email = (mysql_fetch_row(mysql_query("SELECT COUNT(*) from users where email=".sqlesc($email))))  or sqlerr(__FILE__, __LINE__);

	      if($chek_email[0] != 0){
		     $emailerr=str_replace("%email%", $email, btlng24);
	             infoerr($emailerr);
	           } else{
			$updateuser[] = "email = ".sqlesc($email);
		     }
	   }

# DONOR

	if($donor != $us_donor){
	     $updateuser[] = "donor = ".sqlesc($donor);
	   }
      }

# TITLE

	if($us_title != $title) {
	  $updateuser[] = "title = ".sqlesc($title);
	}

# ACCEPT RULES

	if($acceptrules != $us_acceptrules) {
              $updateuser[] = "acceptrules = ".sqlesc($acceptrules);
	  }

# AVATAR

    $updateuser[] = "avatar = ".sqlesc($avatar);

    $updateuser[] = "flags = 1";

    mysql_query("UPDATE users SET  " . implode(", ", $updateuser) . " WHERE uid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);

infok(btlng242);




?>