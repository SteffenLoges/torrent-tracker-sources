<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(get_user_class() == UC_ROOT){

  title("Clients","Torrent Clients");

if(isset($_GET["orderby"])){$gorderby=htmlchar($_GET["orderby"]);}else{$gorderby="";}
if(isset($_GET["sort"])){$sort=htmlchar($_GET["sort"]);}else{$sort="";}

if(isset($_GET["act"])){$act = htmlchar($_GET["act"]);}else{$act="";}
if(isset($_GET["cliid"])){$cliid = 0 + $_GET["cliid"];}else{$cliid="";}
if(isset($_GET["banned"])){$banned = 0 + $_GET["banned"];}else{$banned="0";}


  if($act=="save" && $cliid){

      mysql_query("UPDATE clients SET banned = ".sqlesc($banned)." WHERE cliid = ".sqlesc($cliid)) or sqlerr(__FILE__, __LINE__);
      add_clients_to_ram();

      infok(btlng448);
    die();
    }


if($sort=="asc"){$param="desc";}else{$param="asc";}

# ORDER BY
$orderby = "ORDER BY ";

if($gorderby == "name"){

		    $orderby .= "agent";
	}
	else{

		    $orderby .= "addtime";
	}
	

# SORT
	if($sort == "asc"){
		      $orderby .= " ASC";
	}
	else{
		      $orderby .= " DESC";
	}


 $clires = mysql_query("SELECT * FROM clients $orderby");

  echo "<br><div class=\"shadow\" style=\"background:#fff url($stylelink/h28.png) repeat-x;width:880px;padding:1px;\">
		<div class=\"table\">
        <div class=\"tr\">
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><a href=\"".$GLOBALS["BASEURL"]."/#tclients?orderby=name&sort=$param\"><b>".btlng445."</b></a></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><a href=\"".$GLOBALS["BASEURL"]."/#tclients?orderby=added&sort=$param\"><b>".btlng115."</b></a></div>
 		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>".btlng446."</b></div>
 		<div class=\"td\" style=\"text-align:center;\"><b>".btlng447."</b></div>
	      </div>";

 $ti = 0;
$trstyle = "";

?>

<script>
                  // BANN CLIENT
		      function clibann(cliid){
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/tclients.php", {act:"save", cliid: cliid, banned: $('#banned'+cliid+':checked').val() }, function(data) {
			    $("#info").html(data);
			    });
			    window.location.replace("<?php echo $GLOBALS["BASEURL"]."/#tclients?$time";?>");
			}
</script>

<?php
  while($clirrow = mysql_fetch_row($clires)){
	$cc = -1;
	$cliid = $clirrow[++$cc];
	$cliname = $clirrow[++$cc];
	$clidate = date("d.m.Y",$clirrow[++$cc]);
	$clibanned = $clirrow[++$cc];
	if($ti){
	  $trstyle="border-top:1px solid #ABABAB;";
	}

      $nchecked = "";
      $ychecked = "";

      if($clibanned){$ychecked="checked";}else{$nchecked="checked";}

	# BACKGROUND COLOR ROW
	      if($ti % 2 ){
		  $bgcolor="#FFFFE5";
		 }else{$bgcolor="#F8F8F8";}

        echo "<div class=\"tr\" style=\"background-color:$bgcolor;$trstyle\">
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:left;\">$cliname</div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$clidate</div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">".btlng449." <input id=\"banned$cliid\" name=\"banned$cliid\" $ychecked type=\"radio\" value=\"1\">  &nbsp;&nbsp;&nbsp; ".btlng450." <input type=\"radio\" id=\"banned$cliid\" name=\"banned$cliid\" $nchecked value=\"0\"></div>
		<div class=\"td\" style=\"text-align:center;\"><a id=\"savebann\" onclick=\"clibann('$cliid')\" class=\"buttonsilver\">".btlng204."</a></div>
	      </div>";



  $ti++;
    }

echo "</div></div>";

}
  else{
    errmsg(btlng26_2,btlng26_2);
  }








?> 
