<?php
require_once('inc/func.php');
head();



footer();
?>