<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();
ini_set("upload_max_filesize", $GLOBALS["MAX_TORRENT_SIZE"] + 2 * $GLOBALS["MAX_XIMGDEPOT_UPLOAD_SIZE"]);echo "1";// Do Not Delete This ECHO 


if (get_user_class() < UC_UPLOADER){
    $activated = "0";
  }
  else{
       $activated = "1";
     }

 if(!$CURUSER["allowupload"]){
    infoerr(btlng62);
  }


mkglobal("descr:cat:name:seederspeed");

$torfile=$_FILES["torrent"];
$torfilename=htmlchar($torfile["name"]);
$torfilesize=$torfile["size"];
$tortmpname=$torfile["tmp_name"];
$nfofile = $_FILES['nfo'];


  if(!$torfilesize || !$torfilename){
  infoerr(btlng67);
  }

  if(!validfilename($torfilename)){
  infoerr(btlng68);
  }
  
  if(fileext($torfilename) != "torrent"){
  infoerr(btlng69);
  }

  if(!is_uploaded_file($tortmpname)){
  infoerr(btlng70);
  }

  if($torfilesize > $GLOBALS["MAX_TORRENT_SIZE"]) {
  infoerr(btlng71);
  }

  if(!filesize($tortmpname)) {
  infoerr(btlng72);
  }

  if(!$descr){
  infoerr(btlng63);
  }
   else if(!$cat || !is_valid_id($cat)){
	  infoerr(btlng64);
	  }
	   else if(!$seederspeed){
	          infoerr(btlng65);
		  }

  if(strlen($descr) > 20000) {
  infoerr(btlng66);
  }

  if(!$nfofile['name']) {
  infoerr(btlng73);
  }

  if(!$nfofile['size']) {
  infoerr(btlng74);
  }

  if($nfofile['size'] > 65535) {
  infoerr(btlng75);
  }

  if(!is_uploaded_file($nfofile['tmp_name'])) {
  infoerr(btlng76);
  }

 # Get Torrent Name
  if($name){
    $torfilename=str_replace(".torrent", "", htmlchar($_POST["name"]));
    }else{
    $torfilename=str_replace(".torrent", "", $torfilename);
    }

require_once("inc/benc.php");

$dict = bdec_file($tortmpname, $GLOBALS["MAX_TORRENT_SIZE"]);

  if(!isset($dict)) {
  infoerr(btlng77);
  }


function dict_check($d, $s, $type = "")
{

    if($d["type"] != "dictionary") {
	  infoerr(btlng78);
    }

    $a = explode(":", $s);
    $dd = $d["value"];
    $ret = array();
    foreach ($a as $k) {
        unset($t);
        if(preg_match('/^(.*)\((.*)\)$/', $k, $m)) {
            $k = $m[1];
            $t = $m[2];
        } 
        if(!isset($dd[$k])) {
 	   infoerr(btlng79);
        }
        if (isset($t)) {
            if ($dd[$k]["type"] != $t) {
		infoerr(btlng80);
            }
            $ret[] = $dd[$k]["value"];
        } else
            $ret[] = $dd[$k];
    }
    return $ret;
} 


function dict_get($d, $k, $t)
{
    if($d["type"] != "dictionary"){
	infoerr(btlng81);
      }
    $dd = $d["value"];
    if(!isset($dd[$k])){
        return;
      }
    $v = $dd[$k];
    if($v["type"] != $t){
	infoerr(btlng82);
      }
    return $v["value"];
} 

  list($ann, $info) = dict_check($dict, "announce(string):info", "Globales Dictionary");
  list($dname, $plen, $pieces) = dict_check($info, "name(string):piece length(integer):pieces(string)", "Info-Dictionary");

  # Check Announce Url
  if(!in_array($ann, $GLOBALS["ANNOUNCE_URLS"], 1)) {
	infoerr(btlng83);
  }

  #Torrent File list
  $totallen = dict_get($info, "length", "integer");
  $filelist = array();
  if ($totallen > 0) {
    $filelist[] = array($dname, $totallen);
    $type = "1";
  } else {
    $flist = dict_get($info, "files", "list");
    if (!isset($flist)) {
        infoerr(btlng84);
    }
    if (!count($flist)) {
        infoerr(btlng85);
    }
    $totallen = 0;
    foreach ($flist as $fn) {
        list($ll, $ff) = dict_check($fn, "length(integer):path(list)");
        $totallen += $ll;
        $ffa = array();
        foreach ($ff as $ffe) {
            if ($ffe["type"] != "string") {
		infoerr(str_replace("%type%", $ffe["type"], btlng86));
            }
            if (preg_match('/^[.\\/^~][\/\^]*/', $ffe["value"])) {
		infoerr(str_replace("%value%", $ffe["value"], btlng87));
            }
            $ffa[] = $ffe["value"];
        } 
        if (!count($ffa)){
            infoerr("filename error");
	  }
        $ffe = implode("/", $ffa);
        $filelist[] = array($ffe, $ll);
    } 
    $type = "2";
  }


  if(strlen($pieces) % 20 != 0) {
    infoerr(btlng88);
  }

  $numpieces = strlen($pieces)/20;
  if($numpieces != ceil($totallen/$plen)) {
    infoerr(btlng89);
  }


  unset($dict['value']['announce-list']); // remove multi-tracker capability
  unset($dict['value']['nodes']); // remove cached peers (Bitcomet & Azareus)
  // Add private flag to prevent Azureus 2.3.0.0+ from sharing the peers with other clients.
  // The array equals to the return value of bdec("7:privatei1e").
  $dict["value"]["info"]["value"]["private"] = array("type" => "integer", "value" => "1");

  $infohash = pack("H*", sha1(benc($dict["value"]["info"])));



  $torfilename = str_replace("_", " ", $torfilename);


  # Audio
  foreach($torrentlang as $key => $val){
      if(isset($_POST["alang_$key"])){$alang["$key"]=1;}else{$alang["$key"]=0;}
  }

  # Subtitle
  foreach($torrentlang as $key => $val){
      if(isset($_POST["slang_$key"])){$slang["$key"]=1;}else{$slang["$key"]=0;}
  }

  # Check Image uploads
  if($_FILES["pic1"]["name"]) {
    torrent_image_upload($_FILES["pic1"], "", "", 1);
	}

  if($_FILES["pic2"]["name"]) {    
    torrent_image_upload($_FILES["pic2"], "", "", 1);
  }
  
  # Dispaly Image Upload Errors
  if($imginfo){
  infoerr($imginfo);
  }


# Write Sql
$ret=mysql_query("INSERT INTO torrents (toruid, info_hash, name, search_text, descr, catid, seedspeed, size, added, type, numfiles, audlang_de, audlang_en, audlang_fr, audlang_it, audlang_jp, audlang_sp, sublang_de, sublang_en, sublang_fr, sublang_it, sublang_jp, sublang_sp, lastaction, activated) VALUES (
".implode(",", array_map("sqlesc", array(
$CURUSER["uid"], 
$infohash, 
$torfilename, 
searchfield($torfilename), 
$descr,
$cat,
$seederspeed,
$totallen,
$time,
$type,
count($filelist),
$alang["de"],
$alang["en"],
$alang["fr"],
$alang["it"],
$alang["jp"],
$alang["sp"],
$slang["de"],
$slang["en"],
$slang["fr"],
$slang["it"],
$slang["jp"],
$slang["sp"],
$time,
$activated))).")");


  if(!$ret) {
    if(mysql_errno() == 1062){
         infoerr(btlng90);
	}
    infoerr(str_replace(chr(13), "", mysql_error() . " (".mysql_errno().")"));
  } 

  $id = mysql_insert_id();

  mysql_query("DELETE FROM files WHERE filestid = $id");

  $torfiles="";
  foreach ($filelist as $file) {
      $torfiles.= htmlchar($file[0]).":".$file[1].";";
  } 

  # Write Torrent File list
  mysql_query("INSERT INTO files (filestid, filevals) VALUES ($id, ".sqlesc($torfiles).")") or sqlerr(__FILE__, __LINE__);

  $fhandle = fopen("./".$GLOBALS["TORRENT_DIR"]."/$id.torrent", "w");

  if($fhandle) {
    fwrite($fhandle, benc($dict));
    fclose($fhandle);
  } else {
         infoerr(btlng91);
  } 


unlink($tortmpname);

  # Handle picture uploads
  $picnum = 0;
  if($_FILES["pic1"]["name"]) {
    if(torrent_image_upload($_FILES["pic1"], $id, $picnum+1)){
        $picnum++;
	}
  } 

  if($_FILES["pic2"]["name"]) {    
    if(torrent_image_upload($_FILES["pic2"], $id, $picnum+1)){
        $picnum++;
      }
  }

  if($picnum){
     mysql_query("UPDATE torrents SET numpics=$picnum WHERE tid=$id");
    }

# Create NFO image
  $nfo = str_replace("\x0d\x0d\x0a", "\x0d\x0a", file_get_contents($nfofile['tmp_name']));

  gen_nfo_pic($nfo, "./".$GLOBALS["XIMGDEPOT_DIR"]."/nfo/nfo-".md5($id.$infohash).".png");
  unlink($nfofile['tmp_name']);

  $activitedmsg="";
  if(!$activated) {
    $activitedmsg=str_replace("%tid%",$id,btlng102);
  }

  if($activated) {
      add_torrent_to_ram($id);
  }

okmsg(btlng100,btlng101.$activitedmsg,1);

    # GUTEAM MESSAGE
    $modmsgsearch = array("%uid%", "%username%", "%tid%", "%torrentname%");
    $modmsgreplace = array($CURUSER["uid"], $CURUSER["username"], $id, $torfilename);
    $modmsg=str_replace($modmsgsearch, $modmsgreplace, btlng143);

	$modmsgsubject=str_replace("%username%", $CURUSER["username"], btlng144);

	    // Send a system message to each member of the guest upload team
	    $resgu = mysql_query("SELECT uid FROM users WHERE class = ".UC_GUTEAM);
	    $sqlmodmsg="";
	if(mysql_num_rows($resgu)){
	    while ($guteamid = mysql_fetch_row($resgu)){
		$sqlmodmsg .="(0, ".$guteamid[0].", 4, $time, ".sqlesc($modmsgsubject).", ".sqlesc($modmsg)."),";
	      }

	      # Write GUTEAM Message
	      mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES ".rtrim($sqlmodmsg,",")) or sqlerr(__FILE__, __LINE__);
         }
$logsearch = array("%uid%", "%username%", "%tid%", "%torrentname%");
$logreplace = array($CURUSER["uid"], $CURUSER["username"], $id, $torfilename);
$logtext=str_replace($logsearch, $logreplace, btlng145);

write_log("torrentupload", $logtext);

?>