<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}
if(isset($_GET["reason"])){$reason=htmlchar($_GET["reason"]);}else{$reason="";}

 if(!is_valid_id($tid)){
    errmsg(btlng32,btlng417);
  }

 if(!$reason){
    infoerr(btlng441);
  }

$res = mysql_query("SELECT torrents.name,torrents.toruid,torrents.activated,users.class FROM torrents LEFT JOIN users ON torrents.toruid=users.uid WHERE torrents.tid = ".sqlesc($tid));
$row = mysql_fetch_row($res);

if(!$row){
    infoerr(btlng295);
        errmsg(btlng32,btlng295);
}


if($CURUSER["uid"] != $row[1] && !(get_user_class() >= UC_MODERATOR || ($row[2] == "0" && get_user_class() == UC_GUTEAM && $row[3] < UC_UPLOADER))){

        errmsg(btlng32,btlng442);

  }


deletetorrent($tid, $row[1], $reason);



 $logmsg = str_replace(array("%tid%","%name%","%uid%","%username%","%reason%"),array($tid, $row[0], $CURUSER["uid"], $CURUSER["username"], $reason),btlng443);


write_log("torrentdelete",$logmsg);


 infok(btlng444);

 go_to("torrents?incldead=2&my=1");










?>