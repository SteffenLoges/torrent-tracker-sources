<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

 $limit="";$searchsql="";

 title(btlng372_2,"[img=".$GLOBALS["BASEURL"]."/$stylelink/publict.png] ".btlng372_2);

 if(isset($_GET["search"])){$search=htmlchar($_GET["search"]);}else{$search="";}
 if(isset($_GET["hidehead"])){$hidehead=0+$_GET["hidehead"];}else{$hidehead=0;}
 if(isset($_GET["pno"])){$page=0+$_GET["pno"];}else{$page=1;}


# SEARCH
 if($search){
	$searchsql = "orgname LIKE '%" . sqlwildcardesc($search) . "%' AND ";
 }


  $imgrresc=mysql_query("SELECT COUNT(*) FROM ximgdepot WHERE $searchsql public = 1") or sqlerr(__FILE__, __LINE__);

		    $row = mysql_fetch_row($imgrresc);
		    $count = $row[0];
                $perpage=$GLOBALS["XIMGDEPOT_PUB_PERPAGE"];
		if($count){
		  $pages = ceil($count / $perpage);
		    if($page > $pages){
			    $page=$pages;
			    }else{
				$page=$page;
				}

			    $limit = ($page - 1) * $perpage;
			    $limit = " LIMIT $limit, $perpage ";
			 }



?>

<script>

	  $("#imgsearch").click(function() {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/ximgdepotpub.php", {search: $('#valsearch').val(), hidehead: 1 }, function(data) {
			      $("#searchres").html(data);
			    });

	         });

       $('#valsearch').keypress(function(e) {
	 if(e.which == 13) {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/ximgdepotpub.php", {search: $('#valsearch').val(), hidehead: 1 }, function(data) {
			      $("#searchres").html(data);
			    });
	   }
      	});


        PageClick = function(pageclickednumber) {
            $("#pager").pager({ pagenumber: pageclickednumber, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
		$.get("<?php echo $GLOBALS["BASEURL"];?>/ximgdepotpub.php", {  search: "<?php echo $search;?>", pno: pageclickednumber, hidehead: 1},
   		function(data){
    		 $('#searchres').html(data);
   		});
        }

  $("#pager").pager({ pagenumber: <?php echo $page;?>, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });

       // DEL IMAGE
	function delimg(imgid, imguid){
         if (confirm('<?php echo btlng120;?>')) {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/ximgdepot.php", {act: "del", imgid: imgid, uid: imguid}, function(data) {
			      $("#info").html(data);
			    });
	   }
         }


  </script>

 
<?php

     $imgrow=mysql_query("SELECT * FROM ximgdepot WHERE $searchsql public = 1 ORDER BY imgid ASC $limit") or sqlerr(__FILE__, __LINE__);
 
if(!$hidehead){
 echo "<div class=\"shadow\" style=\"padding:2px;\">
	<div class=\"table\" id=\"ximgdepot_table\">
	  <div class=\"tr\">
	     <div class=\"td\">
		<center>
	          ".btlng261." : <input type=\"text\" size=\"42\" id=\"valsearch\">
		  <a class=\"buttonsilver\" id=\"imgsearch\" href=\"javascript:;\">".btlng261."</a>
	        </center>
             </div>
	  </div>
        </div>
       </div><br>";
echo "<div style=\"padding-left:12%;\" id=\"pager\"></div><br><br><br>";
}



 echo  "<div id=\"searchres\">
	 <div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\" id=\"ximgdepot_table\">
           ";

	  if(!mysql_num_rows($imgrow)){
	      if($search){
		  $distext="<font color=\"#ff0000\"><b>".btlng376_2."</b></font>";
		}else{
		  $distext=btlng376;
		  }
	    echo "<div class=\"tr\"><div class=\"td\" id=\"ximgdepot_td\">
	              <center> $distext </center>
		  </div></div>";
	    }else{

	echo '<div class=\"tr\" id=\"ximgdepot_tr\">
	      <script type="text/javascript" src="/min/?b=js&amp;f=FancyZoomHTML.js,FancyZoom.js"></script>
	      <script>setupZoom();</script>';
		    $prow=0;

		    while($imgres=mysql_fetch_row($imgrow)){
			  $imgi=0;
				$imgid=$imgres[$imgi++];
				$imguid=$imgres[$imgi++];
				$imgsize=mksize($imgres[$imgi++]);
				$imgfilename=$imgres[$imgi++];
				$imgorgname=$imgres[$imgi++];
				$imgpublic=$imgres[$imgi++];

				if($prow % 5 == 0){
					  echo "</div><div class=\"tr\" id=\"ximgdepot_tr\">";	
				      }

				      # IMAGE NAME LENGTH
				      if(strlen($imgorgname) > 21){
					      $imgorgname2=substr($imgorgname, 0, 21)."..";
					      }
					      else{
						  $imgorgname2=$imgorgname;
						}
					    # PUBLIC YES OR NO
					    $public="<font color=\"green\"><b>".btlng393."</b></font>";
						if($imgpublic){
							$public="<font color=\"red\"><b>".btlng394."</b></font>";
						    }

				echo " <div class=\"td\" id=\"ximgdepot_td\" style=\"width:20%;\">
					    <p><a href=\"".$GLOBALS["XIMGDEPOT_DIR"]."/$imgfilename\" title=\"$imgorgname&nbsp;&nbsp;\"><img class=\"imgborder\" src=\"".$GLOBALS["XIMGDEPOT_DIR"]."/$imgfilename\"  title=\"$imgorgname\" width=\"80px\"></a></p> \n
					    <p>&nbsp;$imgorgname2</p>\n
					    <p>&nbsp;<u>$imgsize</u></p>\n";
			            if(get_user_class() >= UC_MODERATOR){
					    echo "<p>&nbsp;
					       <a href=\"".$GLOBALS["BASEURL"]."/#ximgdepot?act=edit&imgid=$imgid&uid=$imguid\"><img src=\"$stylelink/imgedit.png\"  title=\"".btlng389."\"></a> 
					       <a href=\"javascript:;\" onclick=\"delimg($imgid,$imguid)\"><img src=\"$stylelink/imgdel.png\"  title=\"".btlng117."\"></a></p>\n";
					   }
				      echo "</div> ";
				$prow++;
			 }

		  }

     echo "</div>
       </div></div></div>";




?>