<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}
if(isset($_GET["showname"])){$showname=0+$_GET["showname"];}else{$showname="";}

 if(!$tid || !is_valid_id($tid)){
	  errmsg(btlng32,btlng295);
       }

 $resfiles = mysql_query("SELECT files.filevals, torrents.name FROM files LEFT JOIN torrents ON torrents.tid = ".sqlesc($tid)." WHERE filestid= ".sqlesc($tid)) or sqlerr(__FILE__, __LINE__);

  if(!mysql_num_rows($resfiles)){
	  errmsg(btlng32,btlng295);
     }

?>
<script>
	$('#filelist').click(function() {
	   $("#filelist").hide();
	});
</script>

<?php

 $rowfiles = mysql_fetch_row($resfiles);

    if($showname){
      echo "<div class=\"shadow\"><div class=\"table\" style=\"text-align:center;
	background:#fff url('$stylelink/h40.png') repeat-x scroll 0 0;
	 border-radius: 6px 6px;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;\">
	   <div class=\"tr\"><div class=\"td\"><b>".str_replace("%torname%",$rowfiles[1],btlng299)."</b></div></div></div></div>";
    }

  echo "<br><div class=\"shadow\"><div class=\"table\">";


    echo "<div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;background:#fff url('$stylelink/h40.png') repeat-x scroll 0 0;\">
            <div class=\"td\" style=\"border-right:1px solid #ABABAB;width:32px;\"><b>".btlng300."</b></div>
            <div class=\"td\" style=\"border-right:1px solid #ABABAB;\"><b>".btlng301."</b></div>
            <div class=\"td\" style=\"width:100px;\"><b>".btlng302."</b></div>
         </div>";

 $fno=1;

$rowfiles = trim($rowfiles[0],";");

$delimiters = Array(";",":");

$res = multiexplode($delimiters,$rowfiles);

foreach($res as $files){

 if($fno==1){
      $trstyle = "";
    }else{
        $trstyle = " style=\"border-top:1px solid #ABABAB;\"";
      }

    echo "<div class=\"tr\" $trstyle>
            <div class=\"td\" style=\"border-right:1px solid #ABABAB;\">$fno</div>
            <div class=\"td\" style=\"border-right:1px solid #ABABAB;\">".htmlchar($files[0])."</div>
            <div class=\"td\">".mksize($files[1])."</div>
         </div>";

  $fno++;

}



  echo "</div></div><br>";


?>