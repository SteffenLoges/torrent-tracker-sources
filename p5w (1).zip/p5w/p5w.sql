-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 21. November 2011 um 18:50
-- Server Version: 5.5.16
-- PHP-Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `p5w`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bans`
--

CREATE TABLE IF NOT EXISTS `bans` (
  `bannid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` tinyblob NOT NULL,
  `iplast` tinyblob NOT NULL,
  `comment` varchar(255) NOT NULL,
  `addedby` mediumint(8) unsigned NOT NULL,
  `banuid` mediumint(8) unsigned NOT NULL,
  `added` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bannid`),
  KEY `banuid` (`banuid`),
  KEY `ip` (`ip`(16),`iplast`(16))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `bans`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `blocks`
--

CREATE TABLE IF NOT EXISTS `blocks` (
  `buid` mediumint(8) unsigned NOT NULL,
  `blockid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid` (`buid`,`blockid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `blocks`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `image` varchar(60) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`cid`, `name`, `image`) VALUES
(1, 'Anime', 'anime.png'),
(2, 'Serien', 'episodes.png'),
(3, 'Games', 'games.png'),
(4, 'Movies', 'movies.png'),
(5, 'Software', 'software.png'),
(6, 'Musik', 'music.png'),
(7, 'Doku', 'docu.png');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `cliid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `agent` varchar(80) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `banned` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cliid`),
  UNIQUE KEY `agent` (`agent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `clients`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `comid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cuid` mediumint(8) unsigned NOT NULL,
  `tid` mediumint(8) unsigned NOT NULL,
  `added` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  `editedby` mediumint(8) unsigned NOT NULL,
  `editedat` int(10) unsigned NOT NULL,
  PRIMARY KEY (`comid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `comments`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `completed`
--

CREATE TABLE IF NOT EXISTS `completed` (
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tor_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tor_cat` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tor_name` varchar(255) NOT NULL,
  `complete_time` int(10) unsigned NOT NULL,
  UNIQUE KEY `user_id` (`user_id`,`tor_id`),
  KEY `tor_id` (`tor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `completed`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `filestid` mediumint(8) unsigned NOT NULL,
  `filevals` mediumtext NOT NULL,
  KEY `tid` (`filestid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `files`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `fuid` mediumint(8) unsigned NOT NULL,
  `friendid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid` (`fuid`,`friendid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `friends`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `log_ip`
--

CREATE TABLE IF NOT EXISTS `log_ip` (
  `uid` mediumint(8) unsigned NOT NULL,
  `ip` tinyblob NOT NULL,
  UNIQUE KEY `uid` (`uid`,`ip`(16)),
  KEY `ip` (`ip`(16))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `log_ip`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `log_site`
--

CREATE TABLE IF NOT EXISTS `log_site` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typ` enum('torrentupload','torrentedit','torrentdelete','promotion','demotion','addwarn','delwarn','accenabled','accdisabled','userconfirmed','userunconfirmed','torrentgranted','accdeleted','addbann','delbann') NOT NULL DEFAULT 'torrentupload',
  `added` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `added` (`added`),
  KEY `typ` (`typ`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `log_site`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `receiver` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `inbox` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `outbox` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `added` int(10) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `unread` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`mid`),
  KEY `receiver` (`receiver`),
  KEY `unread` (`unread`),
  KEY `inbox` (`inbox`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `messages`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `modcomments`
--

CREATE TABLE IF NOT EXISTS `modcomments` (
  `added` int(10) unsigned NOT NULL,
  `cuid` mediumint(8) unsigned NOT NULL,
  `moduid` mediumint(8) unsigned NOT NULL,
  `txt` text NOT NULL,
  KEY `cuid` (`cuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `modcomments`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `nid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `nuid` mediumint(8) unsigned NOT NULL,
  `added` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` tinytext NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `news`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `peers`
--

CREATE TABLE IF NOT EXISTS `peers` (
  `puid` mediumint(8) unsigned NOT NULL,
  `ptid` mediumint(8) unsigned NOT NULL,
  `ip` tinyblob NOT NULL,
  `port` smallint(5) unsigned NOT NULL,
  `agent` varchar(100) NOT NULL,
  `downloaded` bigint(20) unsigned NOT NULL,
  `uploaded` bigint(20) unsigned NOT NULL,
  `tleft` bigint(20) unsigned NOT NULL,
  `startdate` int(10) unsigned NOT NULL,
  `finishedate` int(10) unsigned NOT NULL,
  `lastaction` int(10) unsigned NOT NULL,
  `connectable` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `downspeed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `upspeed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `puid` (`puid`,`ptid`),
  KEY `lastaction` (`lastaction`),
  KEY `ptid` (`ptid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `peers`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `polls`
--

CREATE TABLE IF NOT EXISTS `polls` (
  `poid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `added` int(10) unsigned NOT NULL,
  `question` varchar(255) NOT NULL,
  `opt0` varchar(150) NOT NULL,
  `opt1` varchar(150) NOT NULL,
  `opt2` varchar(150) NOT NULL,
  `opt3` varchar(150) NOT NULL,
  `opt4` varchar(150) NOT NULL,
  `opt5` varchar(150) NOT NULL,
  `opt6` varchar(150) NOT NULL,
  `opt7` varchar(150) NOT NULL,
  `opt8` varchar(150) NOT NULL,
  `opt9` varchar(150) NOT NULL,
  `opt10` varchar(150) NOT NULL,
  `opt11` varchar(150) NOT NULL,
  `opt12` varchar(150) NOT NULL,
  `opt13` varchar(150) NOT NULL,
  `opt14` varchar(150) NOT NULL,
  `vote0` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote5` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote6` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote7` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote8` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote9` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote10` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote11` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote12` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote13` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote14` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`poid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `polls`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pollsansusers`
--

CREATE TABLE IF NOT EXISTS `pollsansusers` (
  `pollid` smallint(5) unsigned NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `pollid` (`pollid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `pollsansusers`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `shid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL,
  `text` tinytext NOT NULL,
  PRIMARY KEY (`shid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `shoutbox`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `site_info`
--

CREATE TABLE IF NOT EXISTS `site_info` (
  `info` tinyint(1) NOT NULL DEFAULT '0',
  `seeders` int(10) unsigned NOT NULL DEFAULT '0',
  `leechers` int(10) unsigned NOT NULL DEFAULT '0',
  `downloaded` varchar(255) NOT NULL DEFAULT '0',
  `uploaded` varchar(255) NOT NULL DEFAULT '0',
  `registered` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `unverified` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `disabled` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `torrents` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dead` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`info`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `site_info`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `torrents`
--

CREATE TABLE IF NOT EXISTS `torrents` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `toruid` mediumint(8) unsigned NOT NULL,
  `catid` smallint(5) unsigned NOT NULL,
  `info_hash` binary(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `search_text` tinytext NOT NULL,
  `descr` text NOT NULL,
  `seedspeed` smallint(5) unsigned NOT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `added` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `numfiles` smallint(5) unsigned NOT NULL,
  `numpics` tinyint(1) unsigned NOT NULL,
  `audlang_de` tinyint(1) unsigned NOT NULL,
  `audlang_en` tinyint(1) unsigned NOT NULL,
  `audlang_fr` tinyint(1) unsigned NOT NULL,
  `audlang_it` tinyint(1) unsigned NOT NULL,
  `audlang_jp` tinyint(1) unsigned NOT NULL,
  `audlang_sp` tinyint(1) unsigned NOT NULL,
  `sublang_de` tinyint(1) unsigned NOT NULL,
  `sublang_en` tinyint(1) unsigned NOT NULL,
  `sublang_fr` tinyint(1) unsigned NOT NULL,
  `sublang_it` tinyint(1) unsigned NOT NULL,
  `sublang_jp` tinyint(1) unsigned NOT NULL,
  `sublang_sp` tinyint(1) unsigned NOT NULL,
  `times_completed` smallint(5) unsigned NOT NULL,
  `leechers` smallint(5) unsigned NOT NULL,
  `seeders` smallint(5) unsigned NOT NULL,
  `lastaction` int(10) unsigned NOT NULL,
  `activated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `banned` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `onlyup` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `doubleup` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `comments` smallint(5) unsigned NOT NULL,
  `gu_agent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `info_hash` (`info_hash`),
  KEY `visible` (`visible`),
  KEY `activated` (`activated`),
  KEY `banned` (`banned`),
  KEY `lastaction` (`lastaction`),
  FULLTEXT KEY `search_text` (`search_text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `torrents`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `traffic`
--

CREATE TABLE IF NOT EXISTS `traffic` (
  `uid` mediumint(8) unsigned NOT NULL,
  `tid` mediumint(8) unsigned NOT NULL,
  `downloaded` bigint(20) unsigned NOT NULL,
  `uploaded` bigint(20) unsigned NOT NULL,
  `downloadtime` mediumint(8) unsigned NOT NULL,
  `uploadtime` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`uid`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Daten für Tabelle `traffic`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `passhash` varchar(32) NOT NULL,
  `userkey` varchar(14) NOT NULL,
  `secret` tinyblob NOT NULL,
  `editsecret` tinyblob NOT NULL,
  `editsecrettime` int(10) unsigned NOT NULL,
  `email` varchar(100) NOT NULL,
  `added` int(10) unsigned NOT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `ip` tinyblob NOT NULL,
  `lastaccess` int(10) unsigned NOT NULL,
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `allowupload` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `acceptemail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `acceptpms` tinyint(1) NOT NULL DEFAULT '1',
  `acceptrules` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `rules_accepted` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `deletepms` tinyint(1) NOT NULL DEFAULT '1',
  `savepms` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(32) NOT NULL,
  `donor` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `seedbonus` decimal(6,2) NOT NULL,
  `warnpoints` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lastwarned` int(10) unsigned NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `country` varchar(3) NOT NULL,
  `tmaxleechs` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `tmaxseeds` tinyint(3) unsigned NOT NULL DEFAULT '12',
  `flags` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `wget` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `confirmed` (`confirmed`),
  KEY `lastaccess` (`lastaccess`),
  KEY `added` (`added`),
  KEY `enabled` (`enabled`),
  KEY `warnpoints` (`warnpoints`,`lastwarned`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `users`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ximgdepot`
--

CREATE TABLE IF NOT EXISTS `ximgdepot` (
  `imgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imguid` mediumint(8) unsigned NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `filename` varchar(40) NOT NULL,
  `orgname` varchar(255) NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`imgid`),
  KEY `imguid` (`imguid`),
  KEY `public` (`public`),
  FULLTEXT KEY `orgname` (`orgname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `ximgdepot`
--

