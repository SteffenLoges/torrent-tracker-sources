<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

$sortfield="added";$sortorder="DESC";$sqlquery="";$orderby="";$count="";$limit = "";$pagelink="";$ppagelink="";

mkglobal("act:actmid:msgtext:msgsubject");
mkglobal("mid:savepm:delorgpm:hidehead","int");

  if(isset($_GET["ppage"])){$perpage=0+$_GET["ppage"];}else{$perpage=$GLOBALS["MESSAGE_PER_PAGE"];}
  if(isset($_GET["pno"])){$page=0+$_GET["pno"];}else{$page=1;}
  if(isset($_GET["recuid"])){$reciveruid=0+$_GET["recuid"];}else{$reciveruid=0;}
  if(isset($_GET["folder"])){$folder=htmlchar("?act=".$_GET["folder"]);}else{$folder="";}



if (isset($_GET["sortfield"]) && in_array($_GET["sortfield"], array('added','subject','sendername','receivername'))) {
    if (isset($_GET["sortorder"]) && in_array($_GET["sortorder"], array("ASC", "DESC"))) {
	  mkglobal("sortfield:sortorder");
    }
}

    # Delete Messages older X days
      $nextmsgcheck=apc_fetch('nextdelmsgcheck');

	if(!$nextmsgcheck || $time > $nextmsgcheck ){
	    apc_store('nextdelmsgcheck',$time+round($GLOBALS["DEL_MESSAGES_CHECK"]*3600,0));
	    mysql_query("DELETE FROM messages WHERE (inbox=0 OR inbox=1 OR inbox=3 OR inbox=4) AND (outbox=0 OR outbox=1) AND added < ".($time-round($GLOBALS["DEL_MESSAGES_DAY"]*86400,0)));
      }


  if($sortfield=="added"){$orderby=" ORDER BY added $sortorder";}
    elseif($sortfield=="subject"){$orderby=" ORDER BY subject $sortorder";}
      elseif($sortfield=="sendername"){$orderby=" ORDER BY sendername $sortorder";}
	elseif($sortfield=="receivername"){$orderby=" ORDER BY receivername $sortorder";}


	  if((!$act && !$mid) || $act=="inbox"){$sqlquery=" receiver IN (".$CURUSER["uid"].") AND inbox IN (1) ";}
	      elseif($act=="outbox"){$sqlquery=" sender IN (".$CURUSER["uid"].") AND outbox IN (1) ";}
		elseif($act=="backup"){$sqlquery=" sender IN (".$CURUSER["uid"].") AND outbox IN (2) OR receiver IN (".$CURUSER["uid"].") AND inbox IN (2) ";}
		  elseif($act=="system"){$sqlquery=" receiver IN (".$CURUSER["uid"].") AND sender=0 AND inbox IN (4) ";}

	    # PAGER
	      if($sqlquery){
		    $res = mysql_query("SELECT COUNT(*) FROM messages WHERE $sqlquery");
		    $row = mysql_fetch_row($res);
		    $count = $row[0];
		  }

		  $pages = ceil($count / $perpage);

		    if($page > $pages){
			    $page=$pages;
			    }else{
				$page=$page;
				}


		      if($page){
			    $limit = ($page - 1) * $perpage;
			    $limit = " LIMIT $limit, $perpage ";
			    $pagelink="pno=$page&amp;ppage=$perpage&amp;";

			  }

 # SQL QUERY
  $sqlquery=$sqlquery.sqlwildcardesc($orderby).$limit;


?>
<script type="text/javascript" src="/js/jquery.pager.js"></script>
<script>

        PageClick = function(pageclickednumber) {
            $("#pager").pager({ pagenumber: pageclickednumber, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
		$.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", { act: "<?php echo $act;?>", pno: pageclickednumber, ppage: "<?php echo $perpage;?>", sortfield: "<?php echo $sortfield;?>", sortorder: "<?php echo $sortorder;?>", hidehead: '1'},
   		function(data){
    		 $('#res').html(data);

   		});
        }

  $("#pager").pager({ pagenumber: <?php echo $page;?>, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });

	$("input[name='check_all']").click(function(){
	      if($(this).val()==0){
		$(this).parents("div").find("input:checkbox").attr("checked",true);
		$('#check_all').val("1");
		$('#delbutton').show();
	      }
	      else{
		$(this).parents("div").find("input:checkbox").attr("checked",false);
		$('#check_all').val("0");
		$('#delbutton').hide();
	      }
	    });


 function countChecked() {
      var n = $("input:checked").length;
      if(n){
	    $('#delbutton').show();
		}else{
			$('#delbutton').hide();

			}
    }

    countChecked();
    

    $("input[id='cmsg']").click(countChecked);

	// DELETE CHECKED MESSAGES
	$("#butdelmsg").click(function(){
	    if (confirm('<?php echo btlng120;?>')) {
	    var ctot = $("input[id='cmsg']:checked").length - 1;
	    var msgids="";

	    $("input[id='cmsg']:checked").each(function(i){
	
	    if(ctot == i){
		msgids+=$(this).val();
	      }else{
		msgids+=$(this).val() + ",";
		}
	      $("#msg"+$(this).val()).remove();
	      });
	      $.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", {act : 'del', actmid: msgids , folder: "<?php echo $act;?>" }, function(data) {
		$("#info").html(data);
	      });
	    }
      	});

		// MOVE CHECKED MESSAGES
		$("#butmovemsg").click(function(){

		    var ctot = $("input[id='cmsg']:checked").length - 1;
		    var msgids="";

		    $("input[id='cmsg']:checked").each(function(i){
		
		    if(ctot == i){
			msgids+=$(this).val();
		      }else{
			msgids+=$(this).val() + ",";
			}
		      $("#msg"+$(this).val()).remove();
		      });
		    
		      $.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", {act : 'move', actmid: msgids , folder: "<?php echo $act;?>" }, function(data) {
			$("#info").html(data);
		      });
		});

		  // DELETE CLICKED MESSAGES
		  function delete_msg(mid){
			$.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", {act : 'del', actmid: mid , folder: "<?php echo $act;?>" }, function(data) {
			  $("#info").html(data);
			});
		      $("#msg"+mid).remove();
		    }

		      // MOVE CLICKED MESSAGES
		      function move_msg(mid){
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", {act : 'move', actmid: mid , folder: "<?php echo $act;?>" }, function(data) {
			      $("#info").html(data);
			    });
			  $("#msg"+mid).remove();
			}

</script>
<?php


  # MESSAGES HEADER


	    $cntinboxres=mysql_query("SELECT COUNT(*) FROM messages WHERE unread=1 AND receiver=".$CURUSER["uid"]." AND inbox=1");
	    $cntinboxrow = mysql_fetch_row($cntinboxres);

		$cntsysres=mysql_query("SELECT COUNT(*) FROM messages WHERE unread=1 AND receiver=".$CURUSER["uid"]." AND sender=0 AND inbox=4");
		$cntsysrow = mysql_fetch_row($cntsysres);
	    

	    $unreadedmsgs=$cntinboxrow[0];
	    $unreadedsysmsgs=$cntsysrow[0];

	    $unreadedtotmsgs=$_SESSION["udata"]["unreadedtotmsgs"];

  if($unreadedmsgs){$unreadmsg=" ( <font color=\"#EA0000\"><b>".$unreadedmsgs."</b></font> )";}else{$unreadmsg="";}

      if($unreadedsysmsgs){$unreadsysmsg=" ( <font color=\"#EA0000\"><b>".$unreadedsysmsgs."</b></font> )";}else{$unreadsysmsg="";}


if($act){
$ppagelink="act=$act&amp;";}

	    if(!$hidehead){
	    echo "<div class=\"msgheader\">
	      <div class=\"table\">
	      <div class=\"tr\">
		<div class=\"td\"><a href=\"#messages\"><img src=\"$stylelink/inbox.png\" title=\"",btlng106,"\"></a><br>",btlng106,"$unreadmsg</div>
		<div class=\"td\"><a href=\"#messages?act=outbox\"><img src=\"$stylelink/outbox.png\" title=\"",btlng107,"\"></a><br>",btlng107,"</div>
		<div class=\"td\"><a href=\"#messages?act=backup\"><img src=\"$stylelink/backup.png\" title=\"",btlng108,"\"></a><br>",btlng108,"</div>
		<div class=\"td\"><a href=\"#messages?act=system\"><img src=\"$stylelink/system.png\" title=\"",btlng109,"\"></a><br>",btlng109,"$unreadsysmsg</div>
	      </div>
	      </div>
	      </div>";

	      if($pages > 1){ echo "<br><div id=\"pager\"></div><div align=\"right\" style=\"padding-right:1%;\"><a href=\"#messages?".$ppagelink."ppage=20\">20</a> | <a href=\"#messages?".$ppagelink."ppage=30\">30</a> | <a href=\"#messages?".$ppagelink."ppage=50\">50</a></div><br><br><br>";}else{ echo "<br><br>";}

	    }



  # Jquery Pager Results
  echo "<div id=\"res\">";


# INBOX
 if((!$act && !$mid) || $act=="inbox"){
      $inboxres=mysql_query("SELECT messages.mid, messages.sender, messages.added, messages.subject, messages.unread, sender.username, sender.class FROM messages 
			LEFT JOIN users AS sender ON sender.uid=messages.sender WHERE $sqlquery") or sqlerr(__FILE__, __LINE__);
	title(btlng103,btlng103);

	  echo "<div id=\"delbutton\" style=\"display:none;\"><a href=\"javascript:;\" id=\"butdelmsg\" class=\"buttonsilver\">".btlng117."</a> &nbsp; <a href=\"javascript:;\" id=\"butmovemsg\" class=\"buttonsilver\">".btlng123."</a><br><br></div>";

	    echo "<div class=\"tablemsg\">";

  if(!mysql_num_rows($inboxres)) {
    echo "<div class=\"trmsg\"><div class=\"tdmsg\"><br><center><b>",btlng105,"</b></center><br></div></div>";
    } else {
      echo "<div class=\"trmsgtit\">
	    <div class=\"tdmsg\" style=\"width:1%;\"><input type=\"checkbox\" name=\"check_all\" id=\"check_all\" value=\"0\"></div>
	    <div class=\"tdmsg\" style=\"width:73%;\"><a href=\"#messages?act=inbox&amp;",$pagelink,"sortfield=subject&amp;sortorder=";if($sortfield == "subject"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">",btlng112,"</font></a></div>
	    <div class=\"tdmsg\" style=\"width:8%;\"><a href=\"#messages?act=inbox&amp;",$pagelink,"sortfield=sendername&amp;sortorder=";if($sortfield == "sendername"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">",btlng113,"</font></a></div>
	    <div class=\"tdmsg\" style=\"width:10%;\"><a href=\"#messages?act=inbox&amp;",$pagelink,"sortfield=added&amp;sortorder=";if($sortfield == "added"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">",btlng115,"</font></a></div>
	    <div class=\"tdmsg\" style=\"width:8%;\"><font class=\"msgtitlefont\">",btlng116,"</font></div>
	    </div>";
	  while($inboxmsg = mysql_fetch_row($inboxres)) {

		      echo "<div class=\"trmsg\" id=\"msg".$inboxmsg[0]."\">
		      <div class=\"tdmsg\"><input type=\"checkbox\" id=\"cmsg\" value=\"".$inboxmsg[0]."\"></div>
		      <div class=\"tdmsg\">";

		      # Check if Message Readed
		      if($inboxmsg[4]){
			    echo "<a href=\"#messages?mid=".$inboxmsg[0]."\"><font color=\"#EA0000\"><b>".$inboxmsg[3]."</b></font></a>";
			  }else{
			    echo "<a href=\"#messages?mid=".$inboxmsg[0]."\"><font color=\"#000000\">".$inboxmsg[3]."</font></a>";
			    }

		      # USERNAME
			if($inboxmsg[5]){
			  $usname="<a href=\"#userdetails?uid=".$inboxmsg[1]."\"><font color=\"".get_class_color($inboxmsg[6])."\"><b>".ucfirst($inboxmsg[5])."</b></font></a>";	
			}else {
			      $usname="<del><i>(".btlng339.")</i></del>";
				}
			if($inboxmsg[1]==0){
			  $usname="<font color=\"#ff0000\"><b><i>System</i></b></font>";	
			}

			    echo "</div>
			      <div class=\"tdmsg\">$usname</div>
			      <div class=\"tdmsg\">".gdate($inboxmsg[2])."</div>
			      <div class=\"tdmsg\">
				<div class=\"table\" style=\"margin: 0px;\">
				  <div class=\"tr\">
				    <div class=\"td\"><a id=\"delmsg\" onclick=\"delete_msg(".$inboxmsg[0].")\" href=\"javascript:;\"><img src=\"".$stylelink."/delete.png\" title=\"".btlng117."\"></a></div>
				    <div class=\"td\"><a id=\"movemsg\" onclick=\"move_msg(".$inboxmsg[0].")\" href=\"javascript:;\" ><img src=\"".$stylelink."/backup_add.gif\" title=\"".btlng118."\"></a></div>";
				  if(!$inboxmsg[4]){
					    echo " <div class=\"td\"><a href=\"#messages?act=reply&mid=".$inboxmsg[0]."\"><img src=\"".$stylelink."/reply.png\" title=\"".btlng119."\"></a></div>";
					}
				echo "  </div>
				</div>";

			    echo "</div></div>\n";
	    }
   }

  echo "</div>";
 }




# OUTBOX
 elseif($act=="outbox"){
	$outboxres=mysql_query("SELECT messages.mid, messages.receiver, messages.added, messages.subject, receiver.username, receiver.class FROM messages 
			LEFT JOIN users AS receiver ON receiver.uid=messages.receiver WHERE $sqlquery") or sqlerr(__FILE__, __LINE__);
	title(btlng104,btlng104);

	  echo "<div id=\"delbutton\" style=\"display:none;\"><a href=\"javascript:;\" id=\"butdelmsg\" class=\"buttonsilver\">".btlng117."</a> &nbsp; <a href=\"javascript:;\" id=\"butmovemsg\" class=\"buttonsilver\">".btlng123."</a><br><br></div>";

	  echo "<div class=\"tablemsg\">";

  if(!mysql_num_rows($outboxres)) {
    echo "<div class=\"trmsg\"><div class=\"tdmsg\"><br><center><b>".btlng105."</b></center><br></div></div>";
      } else {
	    echo "
	    <div class=\"trmsgtit\">
	    <div class=\"tdmsg\" style=\"width:1%;\"><input type=\"checkbox\" name=\"check_all\" id=\"check_all\" value=\"0\"></div>
	    <div class=\"tdmsg\" style=\"width:73%;\"><a href=\"#messages?act=outbox&amp;".$pagelink."sortfield=subject&amp;sortorder=";if($sortfield == "subject"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng112."</font></a></div>
	    <div class=\"tdmsg\" style=\"width:8%;\"><a href=\"#messages?act=outbox&amp;".$pagelink."sortfield=receivername&amp;sortorder=";if($sortfield == "receivername"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng114."</font></a></div>
	    <div class=\"tdmsg\" style=\"width:10%;\"><a href=\"#messages?act=outbox&amp;".$pagelink."sortfield=added&amp;sortorder=";if($sortfield == "added"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng115."</font></a></div>
	    <div class=\"tdmsg\" style=\"width:8%;\"><font class=\"msgtitlefont\">".btlng116."</font></div>
	    </div>";
	    while($outboxmsg = mysql_fetch_row($outboxres)) {

		  # USERNAME
		      if($outboxmsg[4]){
			$usname="<a href=\"#userdetails?uid=".$outboxmsg[1]."\"><font color=\"".get_class_color($outboxmsg[5])."\"><b>".ucfirst($outboxmsg[4])."</b></font></a>";	
		      }else {
			    $usname="<del><i>(".btlng339.")</i></del>";
			      }

			  echo "<div class=\"trmsg\" id=\"msg".$outboxmsg[0]."\">
			    <div class=\"tdmsg\"><input type=\"checkbox\" id=\"cmsg\" value=\"".$outboxmsg[0]."\"></div>
			    <div class=\"tdmsg\"><a href=\"#messages?mid=".$outboxmsg[0]."\">".$outboxmsg[3]."</a></div>
			    <div class=\"tdmsg\">$usname</div>
			    <div class=\"tdmsg\">".gdate($outboxmsg[2])."</div>
			    <div class=\"tdmsg\">
			      <div class=\"table\" style=\"margin: 0px;\">
				<div class=\"tr\">
				  <div class=\"td\"><a id=\"delmsg\" onclick=\"delete_msg(".$outboxmsg[0].")\" href=\"javascript:;\"><img src=\"".$stylelink."/delete.png\" title=\"".btlng117."\"></a></div>
				  <div class=\"td\"><a id=\"movemsg\" onclick=\"move_msg(".$outboxmsg[0].")\" href=\"javascript:;\" ><img src=\"".$stylelink."/backup_add.gif\" title=\"".btlng118."\"></a></div>
				</div>
			      </div>";

			  echo "</div></div>\n";
            }
   }
  echo "</div>";

 }



# BACKUP FOLDER
      elseif($act=="backup"){
	  title(btlng110,btlng110);
	    $backupres=mysql_query("SELECT messages.mid, messages.sender, messages.added, messages.subject, sender.username, sender.class FROM messages 
			 LEFT JOIN users AS sender ON sender.uid=messages.sender WHERE $sqlquery ") or sqlerr(__FILE__, __LINE__);

    echo "<div id=\"delbutton\" style=\"display:none;\"><a href=\"javascript:;\" id=\"butdelmsg\" class=\"buttonsilver\">".btlng117."</a><br><br></div>";
    echo "<div class=\"tablemsg\">";

	    if(!mysql_num_rows($backupres)) {
	      echo "<div class=\"trmsg\"><div class=\"tdmsg\"><br><center><b>".btlng105."</b></center><br></div></div>";
	      } else {
		  echo "<div class=\"trmsgtit\">
		  <div class=\"tdmsg\" style=\"width:1%;\"><input type=\"checkbox\" name=\"check_all\" id=\"check_all\" value=\"0\"></div>
		  <div class=\"tdmsg\" style=\"width:73%;\"><a href=\"#messages?act=backup&amp;".$pagelink."sortfield=subject&amp;sortorder=";if($sortfield == "subject"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng112."</font></a></div>
		  <div class=\"tdmsg\" style=\"width:8%;\"><a href=\"#messages?act=backup&amp;".$pagelink."sortfield=sendername&amp;sortorder=";if($sortfield == "sendername"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng113."</font></a></div>
		  <div class=\"tdmsg\" style=\"width:10%;\"><a href=\"#messages?act=backup&amp;".$pagelink."sortfield=added&amp;sortorder=";if($sortfield == "added"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng115."</font></a></div>
		  <div class=\"tdmsg\" style=\"width:8%;\"><font class=\"msgtitlefont\">".btlng116."</font></div>
		  </div>";
		while($backupmsg = mysql_fetch_row($backupres)) {

# USERNAME
        if($backupmsg[4]){
	   $usname="<a href=\"#userdetails?uid=".$backupmsg[1]."\"><font color=\"".get_class_color($backupmsg[5])."\"><b>".ucfirst($backupmsg[4])."</b></font></a>";	
         }else {
		  if($backupmsg[4]==0){
		      $usname="<font color=\"#ff0000\"><b><i>System</i></b></font>";
			}else{
			      $usname="<del><i>(".btlng339.")</i></del>";
			  }
		}

		  echo "<div class=\"trmsg\" id=\"msg".$backupmsg[0]."\">
			<div class=\"tdmsg\"><input type=\"checkbox\" id=\"cmsg\" value=\"".$backupmsg[0]."\"></div>
			<div class=\"tdmsg\"><a href=\"#messages?mid=".$backupmsg[0]."\">".$backupmsg[3]."</a></div>
			<div class=\"tdmsg\">$usname</div>
			<div class=\"tdmsg\">".gdate($backupmsg[2])."</div>
			<div class=\"tdmsg\">
			  <div class=\"table\" style=\"margin: 0px;\">
			    <div class=\"tr\">
		    <div class=\"td\"><a id=\"delmsg\" onclick=\"delete_msg(".$backupmsg[0].")\" href=\"javascript:;\"><img src=\"".$stylelink."/delete.png\" title=\"".btlng117."\"></a></div>
			      <div class=\"td\"><a href=\"#messages?act=reply&mid=".$backupmsg[0]."\"><img src=\"".$stylelink."/reply.png\" title=\"".btlng119."\"></a></div>
			    </div>
			  </div>";
	    echo "</div></div>\n";
	  }
	}
	echo "</div>";
      }



# SYSTEM FOLDER
     elseif($act=="system"){

	  $systemres=mysql_query("SELECT messages.mid, messages.added, messages.subject, messages.unread FROM messages WHERE $sqlquery") or sqlerr(__FILE__, __LINE__);

	  title(btlng111,btlng111);

	    echo "<div id=\"delbutton\" style=\"display:none;\"><a href=\"javascript:;\" id=\"butdelmsg\" class=\"buttonsilver\">".btlng117."</a> &nbsp; <a href=\"javascript:;\" id=\"butmovemsg\" class=\"buttonsilver\">".btlng123."</a><br><br></div>";
	    echo "<div class=\"tablemsg\">";

	  if(!mysql_num_rows($systemres)) {
	    echo "<div class=\"trmsg\"><div class=\"tdmsg\"><br><center><b>".btlng105."</b></center><br></div></div>";
	      } else {
		echo "<div class=\"trmsgtit\">
		      <div class=\"tdmsg\" style=\"width:1%;\"><input type=\"checkbox\" name=\"check_all\" id=\"check_all\" value=\"0\"></div>
		      <div class=\"tdmsg\" style=\"width:73%;\"><a href=\"#messages?act=system&amp;".$pagelink."sortfield=subject&amp;sortorder=";if($sortfield == "subject"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng112."</font></a></div>
		      <div class=\"tdmsg\" style=\"width:8%;\"><font class=\"msgtitlefont\">".btlng113."</font></div>
		      <div class=\"tdmsg\" style=\"width:10%;\"><a href=\"#messages?act=system&amp;".$pagelink."sortfield=added&amp;sortorder=";if($sortfield == "added"){ echo ($sortorder=="ASC"?"DESC":"ASC");} else{echo $sortorder;} echo "\"><font class=\"msgtitlefont\">".btlng115."</font></a></div>
		      <div class=\"tdmsg\" style=\"width:8%;\"><font class=\"msgtitlefont\">".btlng116."</font></div>
		      </div>";
	      while($systemmsg = mysql_fetch_row($systemres)) {
		    echo "<div class=\"trmsg\" id=\"msg".$systemmsg[0]."\">
			  <div class=\"tdmsg\"><input type=\"checkbox\" id=\"cmsg\" value=\"".$systemmsg[0]."\"></div>
			  <div class=\"tdmsg\">";

	# Check if Message Readed
	      if($systemmsg[3]){
		    echo "<a href=\"#messages?mid=".$systemmsg[0]."\"><font color=\"#EA0000\"><b>".$systemmsg[2]."</b></font></a>";
		    }
		    else{
		      echo "<a href=\"#messages?mid=".$systemmsg[0]."\"><font color=\"#000000\">".$systemmsg[2]."</font></a>";
		    }
 
		    echo "</div>
		      <div class=\"tdmsg\"><font color=\"#ff0000\"><b><i>System</i></b></font></div>
		      <div class=\"tdmsg\">".gdate($systemmsg[1])."</div>
		      <div class=\"tdmsg\">
			<div class=\"table\" style=\"margin: 0px;\">
			  <div class=\"tr\">
			<div class=\"td\"><a id=\"delmsg\" onclick=\"delete_msg(".$systemmsg[0].")\" href=\"javascript:;\"><img src=\"".$stylelink."/delete.png\" title=\"".btlng117."\"></a></div>
			  </div>
			</div>";
		echo "</div></div>\n";
		}
	      }
	    echo "</div>";
	  }


# READ MESSAGE
	elseif(!$act && is_valid_id($mid)){
	  $readres=mysql_query("SELECT messages.mid, messages.sender, messages.added, messages.outbox, messages.subject, messages.msg, messages.unread, sender.username AS sendername, sender.uid AS senderid FROM messages 
			LEFT JOIN users AS sender ON sender.uid=messages.sender WHERE mid=".sqlesc($mid)." AND ((receiver=".$CURUSER["uid"]." AND (inbox=1 OR inbox=2 OR inbox=3 OR inbox=4)) OR (sender=".$CURUSER["uid"]." AND (outbox=1 OR outbox=2)))") or sqlerr(__FILE__, __LINE__);
	   $readmsg = mysql_fetch_row($readres);

   title(btlng124,btlng124);

	  echo "<div id=\"msgread\">";

	    if(!$readmsg){
		  errmsg(btlng32,btlng125_1,"","msgread");
		}
	  

		  echo "<div class=\"tablemsg\" style=\"width:720px;margin: 0px auto;\">
			<div class=\"trmsgreadtit\">
			  <div class=\"tdmsgread\">".$readmsg[4]."</div>
			</div>
			<div class=\"tr\"><div class=\"tdmsgread\"><b>".btlng113."</b> : ";
		      if(!$readmsg[1]){echo "<font color=\"#ff0000\"><b><i>System</i></b></font>";}else{echo "<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=".$readmsg[8]."\">".ucfirst($readmsg[7])."</a>";} 
		  echo "</div></div>
			<div class=\"tr\"><div class=\"tdmsgread\"><b>".btlng115."</b> : ".gdate($readmsg[2])."</div></div>";
			if($readmsg[8] != $CURUSER["uid"] && $readmsg[1]){
				    echo "<div class=\"tr\"><div class=\"tdmsgread\"><a href=\"".$GLOBALS["BASEURL"]."/#messages?act=reply&mid=".$readmsg[0]."\"><img src=\"".$stylelink."/reply.png\" title=\"".btlng119."\"></a></div></div>";
				  }
		    echo "<div class=\"tr\"><div class=\"tdmsgread\" >".format_comment($readmsg[5])."</div></div>
			</div>
		      </div>";


    
      if($readmsg[6]){
		mysql_query("UPDATE messages SET unread = 0 WHERE receiver=".$CURUSER["uid"]." AND mid=".sqlesc($mid)) or sqlerr(__FILE__, __LINE__);
			 if($_SESSION["udata"]["unreadedtotmsgs"]){$_SESSION["udata"]["unreadedtotmsgs"]=max(0,$unreadedtotmsgs - 1);}
	      }

	}




# REPLY MESSAGE
    elseif($act=="reply" && is_valid_id($mid)){
	    	  $replyres=mysql_query("SELECT messages.mid, messages.sender, messages.added, messages.subject, messages.msg, sender.username AS sendername, sender.uid AS senderid FROM messages 
			LEFT JOIN users AS sender ON sender.uid=messages.sender WHERE mid=".sqlesc($mid)) or sqlerr(__FILE__, __LINE__);
		  $replymsg = mysql_fetch_row($replyres);
	echo "<div id=\"sendres\">";
	  if(!$replymsg){
	  errmsg(btlng32,btlng125,"","sendres");
	  }
	    elseif(!$replymsg[5]){
		errmsg(btlng32,btlng126,"","sendres");
		  }
		    elseif(!$replymsg[6]){
			 errmsg(btlng32,btlng126,"","sendres");
			}
	  		   elseif($replymsg[1]==$CURUSER["uid"]){
				errmsg(btlng32,btlng127,"","sendres");
				}
            if(substr($replymsg[3], 0, 4) != "Re: "){
			      $replymsg[3] = "Re: ".$replymsg[3];
			    }
	  $body = "\n\n[quote=".ucfirst($replymsg[5])."]".htmlchar($replymsg[4])."[/quote]";

    ?>
      <script>
	$("input[name='delorgpm']").click(function(){
		 if($(this).val()==0){
		   $('#delorgpm').val("1");
		   }
		   else{
			$('#delorgpm').val("0");
		    }
	});

	      $("input[name='savepm']").click(function(){
		    if($(this).val()==0){
		      $('#savepm').val("1");
		    }
		    else{
		      $('#savepm').val("0");
		    }
		  });
	// SEND REPLY MESSAGE
	$("#sendpmreply").click(function(){
	      $.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", {act : 'send', recuid: "<?php echo $replymsg[1];?>", msgtext: $('#markItUp').val(), msgsubject: "<?php echo $replymsg[3];?>", savepm: $('#savepm').val(), delorgpm: $('#delorgpm').val(), mid: <?php echo $mid;?>}, function(data) {
		$("#info").html(data);
	      });
      	});
      </script>
      <?php

      echo "<div><div class=\"tablemsg\" style=\"width:720px;margin: 0px auto;\">
	    <div class=\"trmsgreadtit\">
	    <div class=\"tdmsgread\">".$replymsg[3]."</div>
	    </div>
    	    <div class=\"tr\"><div class=\"tdmsgread\"><b>".btlng114."</b> : <a href=\"#userdetails?uid=".$replymsg[1]."\">".ucfirst($replymsg[5])."</a></div></div>
    	    <div class=\"tr\"><div class=\"tdmsgread\"><b>".btlng115."</b> : ".gdate($replymsg[2])."</div></div>";?>
    	    <div class="tr"><div class="tdmsgread"><?php editor($body);?></div></div>
    	    <div class="tr"><div class="tdmsgread"><input type="checkbox" name="delorgpm" id="delorgpm" value="1" <?php echo $CURUSER['deletepms']?"checked":""?>> <?php echo btlng139;?><br>
						   <input type="checkbox" name="savepm" id="savepm" value="0" <?php echo $CURUSER['savepms']?"checked":""?>> <?php echo btlng140;?></div></div>
	    <div class="tr"><div class="tdmsgread"><?php echo "<center><a id=\"sendpmreply\" href=\"javascript:;\" class=\"buttonsilver\">".btlng129."</a></center>";?></div></div>
      <?php
	    echo "</div></div>";
 
      }


# SEND NEW MESSAGE
      elseif($act=="sendpm" && is_valid_id($reciveruid)){
      title(btlng129_3,btlng129_3);
	    	    	  $userres=mysql_query("SELECT username, class FROM users WHERE uid =".sqlesc($reciveruid)) or sqlerr(__FILE__, __LINE__);
			   $userrow = mysql_fetch_row($userres);
      echo "<div id=\"sendres\">";

	if($reciveruid==$CURUSER["uid"]){
		errmsg(btlng32,btlng127,"","sendres");
	  }
    ?>
      <script>
	      $("input[name='savepm']").click(function(){
		    if($(this).val()==0){
		      $('#savepm').val("1");
		    }
		    else{
		      $('#savepm').val("0");
		    }
		  });

	// SEND NEW MESSAGE
	$("#sendpm").click(function(){
	      $.get("<?php echo $GLOBALS["BASEURL"];?>/messages.php", {act : 'send', recuid: "<?php echo $reciveruid;?>", msgtext: $('#markItUp').val(), msgsubject: $('#subject').val(), savepm: $('#savepm').val()}, function(data) {
		$("#info").html(data);
	      });
      	});
      </script>
  <?php

      echo "<div class=\"tablemsg\" style=\"width:720px;margin: 0px auto;\">
	    <div class=\"trmsgreadtit\">
	    <div class=\"tdmsgread\">".btlng129."</div>
	    </div>
    	    <div class=\"tr\"><div class=\"tdmsgsenrep\"><dl><dt><b>".btlng114." : </b></dt><dd><a href=\"#userdetails?uid=$reciveruid\"><font color=\"".get_class_color($userrow[1])."\"><b>".ucfirst($userrow[0])."</b></font></a></dd></dl></div></div>
	    <div class=\"tr\"><div class=\"tdmsgsenrep\"><dl><dt><b>".btlng112." : </b></dt><dd><input type=\"text\" id=\"subject\" size=\"60\" value=\"$msgsubject\" maxlength=\"250\"></dd></dl></div></div>";
    ?>

    	    <div class="tr"><div class="tdmsgsenrep" style="padding-left:0px;"><?php echo "<br><b style=\"padding-left:8px;\">".btlng128." : </b>  "; editor();?><br></div></div>
    	    <div class="tr"><div class="tdmsgread"><input type="checkbox" name="savepm" id="savepm" value="0" <?php echo $CURUSER['savepms']?"checked":""?>> <?php echo btlng140;?></div></div>
	    <div class="tr"><div class="tdmsgread"><?php echo "<center><a id=\"sendpm\" href=\"javascript:;\" class=\"buttonsilver\">".btlng129_2."</a></center><br>";?></div></div>
      <?php
	    echo "</div></div>";

    }

# SEND REPLY MESSAGE
     elseif($act=="send" && is_valid_id($reciveruid)){

      if($reciveruid==$CURUSER["uid"]){
		infoerr(btlng127);
	}

      if(!$msgsubject){infoerr(btlng130);}
      if(!$msgtext){infoerr(btlng132);}
      if(strlen($msgsubject) > 250){infoerr(btlng131);}
      if(strlen($msgtext) > 250){infoerr(btlng133);}


    $res = mysql_query("SELECT acceptpms FROM users WHERE uid=".sqlesc($reciveruid)) or sqlerr(__FILE__, __LINE__);
    $user = mysql_fetch_row($res);

    if(!$user){infoerr(btlng126);}

        if (get_user_class() < UC_GUTEAM){

        if($user[0] == "1") {
	     $resbl = mysql_query("SELECT COUNT(*) FROM blocks WHERE buid=".sqlesc($reciveruid)." AND blockid=".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
	     $rowbl = mysql_fetch_row($resbl);
		if($rowbl[0]){
			  infoerr(btlng134.$reciveruid.$CURUSER["uid"]);
		        }
	    } 
	      elseif($user[0] == "2") {
		    $resfr = mysql_query("SELECT COUNT(*) FROM friends WHERE fuid=".sqlesc($reciveruid)." AND friendid=".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
		    $rowfr = mysql_fetch_row($resfr);
 			    if(!$rowfr[0]){
					infoerr(btlng135);
				      }
                     } 
		      elseif($user[0] == "0"){
				      infoerr(btlng136);
				      }
      }

    if(is_valid_id($mid)){
	$resmid = mysql_query("SELECT COUNT(*) FROM messages WHERE mid=".sqlesc($mid)) or sqlerr(__FILE__, __LINE__);
	  if(mysql_num_rows($resmid)){
		if($delorgpm){
		      # RECEIVER
		      mysql_query("UPDATE messages SET inbox=0 WHERE mid IN (".sqlesc($mid).") AND (inbox=1 OR inbox=2 OR inbox=3 OR inbox=4) AND receiver=".$CURUSER["uid"]);
		      mysql_query("DELETE FROM messages WHERE mid IN (".sqlesc($mid).") AND outbox=0 AND inbox=0 AND receiver=".$CURUSER["uid"]);
		      # SENDER
		      mysql_query("UPDATE messages SET outbox=0 WHERE mid IN (".sqlesc($mid).") AND (outbox=1 OR outbox=2) AND sender=".$CURUSER["uid"]);
		      mysql_query("DELETE FROM messages WHERE mid IN (".sqlesc($mid).") AND inbox=0 AND outbox=0 AND sender=".$CURUSER["uid"]);
		   }
	      }
	}
     
      
    $ret=mysql_query("INSERT INTO messages (sender, receiver, inbox, outbox, added, subject, msg) VALUES (
	".implode(",", array_map("sqlesc", array(
	  $CURUSER["uid"], 
	  $reciveruid, 
	  1, 
	  $savepm, 
	  $time,
	  $msgsubject,
	  $msgtext))).")");

      okmsg(btlng137,btlng138,1,"sendres");

  }

    # DELETE MESSAGES
      elseif($act=="del"){
	  # RECEIVER
	  mysql_query("UPDATE messages SET inbox=0 WHERE mid IN (".sqlesc2($actmid).") AND (inbox=1 OR inbox=2 OR inbox=3 OR inbox=4) AND receiver=".$CURUSER["uid"]);
	  mysql_query("DELETE FROM messages WHERE mid IN (".sqlesc2($actmid).") AND outbox=0 AND inbox=0 AND receiver=".$CURUSER["uid"]);
	  # SENDER
	  mysql_query("UPDATE messages SET outbox=0 WHERE mid IN (".sqlesc2($actmid).") AND (outbox=1 OR outbox=2) AND sender=".$CURUSER["uid"]);
	  mysql_query("DELETE FROM messages WHERE mid IN (".sqlesc2($actmid).") AND inbox=0 AND outbox=0 AND sender=".$CURUSER["uid"]);

	    infok(btlng121);
	
	      echo "<script>$(\"#content\").load(\"messages.php$folder\");</script>";
	$_SESSION["udata"]["unreadmsgchktime"]=0;
	  
	    }


	    # MOVE MESSAGES
	      elseif($act=="move"){
			mysql_query("UPDATE messages SET inbox=2 , unread=0 WHERE mid IN (".sqlesc2($actmid).") AND receiver=".$CURUSER["uid"]);
			mysql_query("UPDATE messages SET outbox=2 , unread=0 WHERE mid IN (".sqlesc2($actmid).") AND sender=".$CURUSER["uid"]);
		  infok(btlng122);

		    echo "<script>$(\"#content\").load(\"messages.php$folder\");</script>";
	      $_SESSION["udata"]["unreadmsgchktime"]=0;
		    }

	    else{
		errmsg(btlng32,btlng142,"","res");
	      }

echo "</div>";


?>