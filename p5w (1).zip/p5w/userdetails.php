<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

$down_per_day="";$upped_per_day="";$sendemail="";$showpmbutton = "";$showemailbutton = "";$pmbutton="";

      function get_domain($ip)
      {
	  $dom = gethostbyaddr($ip);
	  if ($dom == $ip || gethostbyname($dom) != $ip)
	      return "<a href=\"".$GLOBALS["BASEURL"]."/#whois?ip=$ip\" target=\"_blank\">$ip</a>";
	  else {
	      $dom = strtoupper($dom);
	      return "<a href=\"".$GLOBALS["BASEURL"]."/#whois?ip=$ip\" target=\"_blank\">$ip</a> ($dom)";
	  } 
      }

if(isset($_GET["uid"])){$uid = 0+$_GET["uid"];}else{$uid=0;}

  if(!is_valid_id($uid)){
    errmsg(btlng32,btlng146." ($uid) ");
    }

$useres = mysql_query("SELECT uid, username, userkey, email, added, confirmed, enabled, class, ip, lastaccess, downloaded, uploaded, title, avatar, donor, warnpoints, tmaxleechs, tmaxseeds, allowupload, lastwarned, acceptrules, country, acceptpms, acceptemail FROM users WHERE uid=".sqlesc($uid))  or sqlerr(__FILE__, __LINE__);
$user = mysql_fetch_row($useres);

$ui=-1;

$u_uid=$user[++$ui];
$u_username=htmlchar($user[++$ui]);
$u_userkey=$user[++$ui];
$u_email=$user[++$ui];
$u_added=$user[++$ui];
$u_confirmed=$user[++$ui];
$u_enabled=$user[++$ui];
$u_class=$user[++$ui];
$u_ip=$user[++$ui];
$u_lastaccess=$user[++$ui];
$u_downloaded=$user[++$ui];
$u_uploaded=$user[++$ui];
$u_title=$user[++$ui];
$u_avatar=$user[++$ui];
$u_donor=$user[++$ui];
$u_warnpoints=$user[++$ui];
$u_maxleechs=$user[++$ui];
$u_maxseeds=$user[++$ui];
$u_allowupload=$user[++$ui];
$u_lastwarned=$user[++$ui];
$acceptrules=$user[++$ui];
$u_country=$user[++$ui];
$u_acceptpms=$user[++$ui];
$u_acceptemail=$user[++$ui];


  if(!$user){
    errmsg(btlng32,btlng147);
    }


 if($CURUSER["class"] != UC_ROOT){

    if($u_confirmed == "0"){
	    errmsg(btlng32,btlng148);
	    }

    if($u_enabled == "0"){
	    errmsg(btlng32,btlng158);
	    }
   }

	title(btlng149.ucfirst($u_username),btlng149.ucfirst($u_username)." [img=".$GLOBALS["BASEURL"]."/$stylelink/personal.png]");

# FRIEND AND BLOCK 
    if($u_uid !=$CURUSER["uid"]){

?>
<script>
  $('#fbbutton1,#fbbutton2,#fbbutton3,#fbbutton4').click(function() {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/friends.php", { act: $(this).attr("act"), uid:$(this).attr("uid"), show: 1 }, function(data){
	$('#friendres').html(data);
	});
  });

</script>
<?php

    $friendres = mysql_query("SELECT COUNT(*) FROM friends WHERE fuid=".$CURUSER["uid"]." AND friendid=$uid") or sqlerr(__FILE__, __LINE__);
    $friend = mysql_fetch_row($friendres);
    $blockres  = mysql_query("SELECT COUNT(*) FROM blocks WHERE buid=".$CURUSER["uid"]." AND blockid=$uid") or sqlerr(__FILE__, __LINE__);
    $block  = mysql_fetch_row($blockres);

	    echo " <br><div class=\"shadow\" style=\"width: 380px;\">";
	    echo " <div id=\"friendres\" class=\"table\" style=\"margin: 0px auto;width: 360px;\">";
			if($friend[0]){
				  echo  "<div class=\"tr\"><div class=\"td\"><center><a id=\"fbbutton1\" href=\"javascript:;\" act=\"delfriend\" uid=\"$uid\" title=\"".btlng155_4."\"><img src=\"$stylelink/remove_user.png\"><br>".btlng155_4."</a></center></div></div>\n";
			}elseif($block[0]){
				  echo  "<div class=\"tr\"><div class=\"td\"><center><a id=\"fbbutton2\" href=\"javascript:;\" act=\"delblock\" uid=\"$uid\" title=\"".btlng155_5."\"><img src=\"$stylelink/remove_user.png\"><br>".btlng155_5."</a></center></div></div>\n";
			    }else{
				  echo "<div class=\"tr\">
					<div class=\"td\"><center><a id=\"fbbutton3\" href=\"javascript:;\" act=\"addfriend\" uid=\"$uid\" title=\"".btlng155_2."\"><img src=\"$stylelink/adduser.png\"><br>".btlng155_2."</a> &nbsp;&nbsp;</center></div>
					<div class=\"td\"><center><a id=\"fbbutton4\" href=\"javascript:;\" act=\"addblock\" uid=\"$uid\" title=\"".btlng155_3."\"> <img src=\"$stylelink/block_user.png\"><br>".btlng155_3."</a></center></div>
					</div>\n";
			}
	    echo "</div></div>";
    }


echo " <br><div class=\"shadow\" style=\"padding:1px;\">";
echo " <div class=\"table backg\" style=\"margin: 0px;\">";


# Avatar
      if($u_avatar){
	$avatarsrc=htmlchar($u_avatar);
	}else{
	      if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($u_uid.$u_added).".jpg")){
	              $avatarsrc=$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($u_uid.$u_added).".jpg";
			}else{
	                    $avatarsrc=$GLOBALS["IMAGES_DIR"]."default_avatar.png";
			  }
	      }

  echo "<div class=\"tr borderbottom\"> <div class=\"td userdetails1\"><b>".btlng157." : </b></div> <div class=\"td userdetails2\"><img class=\"imgborder\" style=\"width: 110px;\" src=\"$avatarsrc\"></div> </div>\n";


# COUNTRY FLAG

   if($u_country || file_exists($GLOBALS["IMAGES_DIR"]."flags/$u_country.png")){
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng267." : </b></div><div class=\"td userdetails2\"><img src=\"".$GLOBALS["IMAGES_DIR"]."flags/$u_country.png\"></div></div>\n";
    }else{
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng267." : </b></div><div class=\"td userdetails2\"><img src=\"".$GLOBALS["IMAGES_DIR"]."flags/world.png\"></div></div>\n";
      }

# Title
   if($u_title){
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng156." : </b></div><div class=\"td userdetails2\">".$u_title."</div></div>\n";
    }

# Added
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng150." : </b></div><div class=\"td userdetails2\">".gdate($u_added)."</div></div>\n";

# last Access
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng151." : </b></div><div class=\"td userdetails2\">".gdate($u_lastaccess)."</div></div>\n";

     $days_regged = round((time() - $u_added) / 86400);

      if($days_regged) {
	$down_per_day = "(" . mksize($u_downloaded / $days_regged) . " / ".btlng159.")";
	$upped_per_day = "(" . mksize($u_uploaded / $days_regged) . " / ".btlng159.")";
	} 

# Downloaded
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><font color=\"green\"><b>".btlng153." : </b></font></div><div class=\"td userdetails2\">".mksize($u_downloaded)." $down_per_day</div></div>\n";

# Uploaded
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><font color=\"red\"><b>".btlng152." : </b></font></div><div class=\"td userdetails2\">".mksize($u_uploaded)." $upped_per_day</div></div>\n";

# Ratio
      if($u_downloaded > 0){
	  $ratio = $u_uploaded / $u_downloaded;
	  if($ratio >= 10){$ratioimg = "pirate2";}
	  else if ($ratio >= 7.5){$ratioimg = "bow";}
	  else if ($ratio >= 5){$ratioimg = "yikes";}
	  else if ($ratio >= 3.5){$ratioimg = "w00t";}
	  else if ($ratio >= 2){$ratioimg = "grin";}
	  else if ($ratio >= 1){$ratioimg = "smile1";}
	  else if ($ratio >= 0.9){$ratioimg = "innocent";}
	  else if ($ratio >= 0.5){$ratioimg = "noexpression";}
	  else if ($ratio >= 0.25){$ratioimg = "sad";}
	  else if ($ratio >= 0.1){$ratioimg = "cry";}
	  else{$ratioimg = "shit";}

      echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng154." : </b></div><div class=\"td userdetails2\"><font color=".get_ratio_color($ratio).">".number_format($ratio, 2)."</font> &nbsp; <img  src=\"".$GLOBALS["IMAGES_DIR"]."smilies/$ratioimg.gif\" title=\"$ratioimg\"></div></div>\n";
       }

# Userclass Name
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng155." : </b></div><div class=\"td userdetails2\"><font color=".get_class_color($u_class)."><b>".get_user_class_name($u_class)." ".get_user_icons($u_donor,$u_warnpoints,$u_enabled,$u_added)."</b></font></div></div>\n";

# Announce Url
   if($u_uid == $CURUSER["uid"] || get_user_class() == UC_ROOT){
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng160." : </b></div><div class=\"td userdetails2\">".$GLOBALS["ANNOUNCE_URLS"][0]."?userkey=".$u_userkey."</div></div>\n";
    }

# XimgDepot
   if(get_user_class() >= UC_MODERATOR && $u_class <= UC_ADMIN){
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng372." : </b></div><div class=\"td userdetails2\"><a href=\"".$GLOBALS["BASEURL"]."/#ximgdepot?uid=$u_uid\">".btlng372_3."</a></div></div>\n";
    }

# USERWARNING
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng199." : </b></div><div class=\"td userdetails2\">$u_warnpoints &nbsp;(Max. ".$GLOBALS["MAX_USER_WARN_POINTS"].")</div></div>\n";

# User Comments
    $rescomm = mysql_query("SELECT COUNT(*) FROM comments WHERE cuid = $u_uid")  or sqlerr(__FILE__, __LINE__);
     $rowcomm = mysql_fetch_row($rescomm);
      $torrentcomments = $rowcomm[0];

      if($torrentcomments && (($u_class >= UC_POWER_USER && $u_uid == $CURUSER["uid"]) || get_user_class() >= UC_MODERATOR)){
        echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng161." : </b></div><div class=\"td userdetails2\"><a href=\"".$GLOBALS["BASEURL"]."/#userhistory?act=viewcomments&uid=".$u_uid."\">( $torrentcomments )</a></div></div>\n";
	}
	else{
          echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng161." : </b></div><div class=\"td userdetails2\">$torrentcomments</div></div>\n";
	 }

# Ip Adress
  if($u_ip && (get_user_class() >= UC_MODERATOR || $u_uid == $CURUSER["uid"]) && ($u_class < UC_MODERATOR || get_user_class() >= UC_ADMIN)) {
	$ip = ipd($u_ip);
	$ipaddr = get_domain($ip);

      echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng171." : </b></div><div class=\"td userdetails2\">$ipaddr</div></div>\n";
    

# Peer Adress
	$peer_addr="";
	  $res = mysql_query("SELECT DISTINCT(ip) AS ip FROM peers WHERE puid=$u_uid");
	  if(mysql_num_rows($res)) {
	      while($peer_ip = mysql_fetch_row($res)) {
		  if($peer_addr != ""){
			      $peer_addr .= "<br>";
			      }
		  $peer_addr .= get_domain(ipd($peer_ip[0]));
	      } 
	    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng170." : </b></div><div class=\"td userdetails2\">$peer_addr</div></div>\n";
	  } 
      }


# Send PM AND EMAIL BUTTON

if ($u_uid !=$CURUSER["uid"]){ 
    if (get_user_class() >= UC_GUTEAM) {
        $showpmbutton = true;
        $showemailbutton = true;
    } else {
        if($u_acceptpms == "1") {
            $r = mysql_query("SELECT buid FROM blocks WHERE buid=$u_uid AND blockid=".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
            $showpmbutton = (mysql_num_rows($r) == 1 ? false : true);
        } elseif($u_acceptpms == "2") {
            $r = mysql_query("SELECT fuid FROM friends WHERE fuid=$u_uid AND friendid=".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
            $showpmbutton = (mysql_num_rows($r) == 1 ? true : false);
        } 

        if($u_acceptemail == "1") {
            $r = mysql_query("SELECT buid FROM blocks WHERE buid=$u_uid AND blockid=".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
            $showemailbutton = (mysql_num_rows($r) == 1 ? false : true);
        } 
	  elseif($u_acceptemail == "2") {
              $r = mysql_query("SELECT fuid FROM friends WHERE fuid=$u_uid AND friendid=".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
              $showemailbutton = (mysql_num_rows($r) == 1 ? true : false);
          } 
    } 
} 

if($showpmbutton || $showemailbutton) {

# EMAIL BUTTON
      if ($showemailbutton){
	      $sendemail="<a href=\"".$GLOBALS["BASEURL"]."/#sendemail?recuid=$u_uid\" title=\"".btlng9_2."\" class=\"buttonsilver\">".btlng9_2."</a>";
             }

      if ($showpmbutton){
	      $pmbutton="<a href=\"".$GLOBALS["BASEURL"]."/#messages?act=sendpm&recuid=$u_uid\" title=\"".btlng129_2."\" class=\"buttonsilver\">".btlng129_2."</a>";
             }
      echo "<div class=\"tr borderbottom\" $divbackg><center><br>
	     $pmbutton &nbsp;&nbsp; $sendemail
	    <br><br></center>
	    </div>\n";
    }


echo "</div></div><br>";




# MOD AND ROOT ZONE

if ((get_user_class() >= UC_MODERATOR && $u_class < get_user_class()) || get_user_class() == UC_ROOT) {
?>

<script>
  $('#saveuedit').click(function() {
   if(confirm('<?php echo btlng120;?>')) {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/modtask.php", {  
	uid:'<?php echo $u_uid;?>', title: $('#title').val(), avatar: $('#avatar').val(), email: $('#email').val(), donor: $('#donor:checked').val(), uclass: $('#uclass option:selected').val(), userwarn: $('#userwarn:checked').val()
	, warncomm: $('#warncomm').val(), maxseeds: $('#maxseeds').val(), maxleeches: $('#maxleeches').val(), denyupload: $('#denyupload:checked').val(), acceptrules: $('#acceptrules:checked').val(), enabled: $('#enabled:checked').val()
	, confirmed: $('#confirmed:checked').val(), disabledcomm:$('#disabledcomm').val()

	}, function(data){
	$('#info').html(data);        
       	      window.location.replace("<?php echo $GLOBALS["BASEURL"]."/#userdetails?uid=$u_uid&$time";?>");
	});
     }
  });
</script>

<?php
echo " <br><div class=\"shadow\" style=\"padding:1px;\">";
echo " <div class=\"table backg\" style=\"margin: 0px;width:100%\">";

# TITLE
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng156." : </b></div><div class=\"td userdetails2\"><input type=\"text\" size=\"60\" id=\"title\" value=\"".htmlchar($u_title)."\"></div></div>\n";


# AVATAR
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng157." : </b></div><div class=\"td userdetails2\"><input type=\"text\" size=\"60\" id=\"avatar\" value=\"".htmlchar($u_avatar)."\"></div></div>\n";


# EMAIL
 if($CURUSER["class"] == UC_ROOT){
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng9." </b></div><div class=\"td userdetails2\"><input type=\"text\" size=\"60\" id=\"email\" value=\"".$u_email."\"></div></div>\n";
   }

# DONOR
    if($CURUSER["class"] == UC_ROOT){
	echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng190." : </b></div><div class=\"td userdetails2\"><input type=\"radio\" id=\"donor\" name=\"donor\" value=\"1\"" . ($u_donor ? " checked" : "") . ">".btlng195." <input type=\"radio\" id=\"donor\" name=\"donor\" value=\"0\"" . (!$u_donor ? " checked" : "") . "> ".btlng196."</div></div>\n";
      } 

# USER CLASS
    if(get_user_class() == UC_MODERATOR && $u_class > UC_VIP)
	{
      echo "<div class=\"tr borderbottom\">\n";
      echo "<div class=\"td userdetails1\"><b>".btlng189." : </b></div><div class=\"td userdetails2\"><select id=\"uclass\">\n";
      echo "<option value=\"$u_class\" selected >" . get_user_class_name($u_class)."</option>\n";
      echo "</select></div></div>\n";
      }
	else {
	    echo "<div class=\"tr borderbottom\">\n";
	    echo "<div class=\"td userdetails1\"><b>".btlng189." : </b></div><div class=\"td userdetails2\">\n<select id=\"uclass\">\n";

	    if(get_user_class() == UC_MODERATOR){
		$maxclass = UC_VIP;
	         }
	          elseif(get_user_class() == UC_ROOT){
		           $maxclass = UC_ROOT;
		          }
	                    else{
		               $maxclass = get_user_class() - 1;
	                     }

	    for($i = 0; $i <= $maxclass; ++$i){
	      if(get_user_class_name($i) != "")
		 {
		 echo "<option value=\"$i\"" . ($u_class == $i ? " selected" : "") . ">" . get_user_class_name($i)."</option>\n";
		}
	     }
	    echo "</select></div></div>\n";
	} 



# LAST USERWARNING
  if($u_lastwarned){
      $lastwarntime=gdate($u_lastwarned);
    }else{
	$lastwarntime="--------";
      }
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng200." : </b></div><div class=\"td userdetails2\">$lastwarntime</div></div>\n";


# ADD OR DELWARNING
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng199_2." : </b></div><div class=\"td userdetails2\">
	  <input id=\"userwarn\" name=\"userwarn\" value=\"add\" type=\"radio\"><label> &nbsp;".btlng199_3."</label>
	  <br>
	  <input id=\"userwarn\" name=\"userwarn\" value=\"del\" type=\"radio\"><label> &nbsp;".btlng199_4."</label>
	  <br><br>
	  <textarea id=\"warncomm\" cols=\"76\" rows=\"3\"></textarea></div></div>\n";


# COMMENTS
 $modcommentres = mysql_query("SELECT modcomments.added, modcomments.moduid, modcomments.txt, users.username, users.class FROM modcomments LEFT JOIN users ON users.uid=modcomments.moduid WHERE cuid=$u_uid ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);

    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng161." : </b></div>
	  <div class=\"td userdetails2\">
	      <div style=\"width:575px;height:220px;overflow:auto;\"><div class=\"table\">";
                       while ($commentr = mysql_fetch_row($modcommentres)) {

			      if($commentr[1] == 0){
				  $comusername="<b style=\"color:#ff0000;\">System</b>";
			        }
			      elseif($commentr[3] == ""){
				  $comusername="<i>".btlng168."</i>";
				}
			      else{
				  $comusername="<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=".$commentr[1]."\"><font color=".get_class_color($commentr[4])."><b>".$commentr[3]."</b></font></a>";
				}

			      echo "<div class=\"tr\" id=\"userdetails_com_tr\">
					<div class=\"td\" id=\"userdetails_com_td\">".date("H:i:s-d.m.Y",$commentr[0])."</div>
					<div class=\"td\" id=\"userdetails_com_td\">$comusername</div>
					<div class=\"td\" id=\"userdetails_com_td\">".format_comment($commentr[2])."</div>
				   </div>";


			  }
      echo " </div> </div>
	  </div></div>\n";



# TORRENT LIMITATION
$u_maxtotal=$u_maxseeds+$u_maxleechs;
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng191." : </b></div><div class=\"td userdetails2\">
	 ".btlng192." : <input type=\"text\" size=\"2\" maxlength=\"2\" name=\"maxseeds\" id=\"maxseeds\" value=\"$u_maxseeds\">
	 ".btlng193." : <input type=\"text\" size=\"2\" maxlength=\"2\" name=\"maxleeches\" id=\"maxleeches\" value=\"$u_maxleechs\">
	 ".btlng194." : <input type=\"text\" size=\"2\" maxlength=\"2\" disabled=\"disabled\" value=\"$u_maxtotal\">  ( 0 = Unlimited )
          </div></div>\n";


# TORRENT UPLOAD BLOCK
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng197." : </b></div><div class=\"td userdetails2\">
	  <input name=\"denyupload\" id=\"denyupload\" value=\"0\" type=\"radio\"" . (!$u_allowupload ? " checked" : "") . ">".btlng195." 
	  <input name=\"denyupload\" id=\"denyupload\" value=\"1\" type=\"radio\"" . ($u_allowupload ? " checked" : "") . ">".btlng196."
	  </div></div>\n";

# RULES MUST CONFIRMED
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng201." : </b></div><div class=\"td userdetails2\">
	  <input name=\"acceptrules\" id=\"acceptrules\" value='1' type=\"radio\"" . ($acceptrules ? " checked" : "") . ">".btlng195." 
	  <input name=\"acceptrules\" id=\"acceptrules\" value='0' type=\"radio\"" . (!$acceptrules ? " checked" : "") . ">".btlng196." 
	  </div></div>\n";

# USER ENABLED
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng198." : </b></div><div class=\"td userdetails2\">
          <input name=\"enabled\" id=\"enabled\" value='1' type=\"radio\"" . ($u_enabled ? " checked" : "") . ">".btlng195." 
	  <input name=\"enabled\" id=\"enabled\" value='0' type=\"radio\"" . (!$u_enabled ? " checked" : "") .">".btlng196."
	  <br>
	  <textarea id=\"disabledcomm\" cols=\"76\" rows=\"3\"></textarea>
	  </div></div>\n";

# USER CONFIRMED
    echo "<div class=\"tr borderbottom\"><div class=\"td userdetails1\"><b>".btlng198_2." : </b></div><div class=\"td userdetails2\">
          <input name=\"confirmed\" id=\"confirmed\" value='1' type=\"radio\"" . ($u_confirmed ? " checked" : "") . ">".btlng195." 
	  <input name=\"confirmed\" id=\"confirmed\" value='0' type=\"radio\"" . (!$u_confirmed ? " checked" : "") .">".btlng196."
	  </div></div>\n";

      echo "<div class=\"tr borderbottom\"><center><br><a href=\"javascript:;\" id=\"saveuedit\" class=\"buttonsilver\">".btlng204."</a><br><br></center></div>\n";

echo "</div></div><br>";

}

?>