<?php
require_once("inc/func.php");

$username="";$passwd="";

if(isset($_GET["returnto"])){$returnto=htmlchar($_GET["returnto"]);}else{$returnto="";}

if(!mkglobal("username:passwd")){
	infoerr(btlng43);
}

dbconn();

$res = mysql_query("SELECT * FROM users WHERE username = " . sqlesc($username) . " AND confirmed = '1'") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_assoc($res);

 if(!$row){
  infoerr(btlng44);
 }

 if($row["passhash"] != md5($row["secret"] . $passwd . $row["secret"])){
  infoerr(btlng44);
 }

 if(!$row["enabled"]){
	infoerr(btlng45);
 }

logincookie($row["uid"], $row["passhash"]);

$_SESSION["udata"] = $row;
$_SESSION["udata"]["ip"] = ipd($ipencode);
$_SESSION["udata"]["lastaccess2"]=$time;
	    $_SESSION["udata"]["unreadedmsgs"]=0;
	    $_SESSION["udata"]["unreadedsysmsgs"]=0;
	    $_SESSION["udata"]["unreadedtotmsgs"]=0;


if (!empty($returnto)){
    go_to($returnto);
    } else{
	  go_to();
	    }

?> 
