<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

mkglobal("act:question:opt0:opt1:opt2:opt3:opt4:opt5:opt6:opt7:opt8:opt9:opt10:opt11:opt12:opt13:opt14");
mkglobal("poid","int");
    if(get_user_class() < UC_MODERATOR){
	errmsg(btlng26_2,btlng26_2);
    }

  title(btlng504,btlng504);



 ?>
 <script>

    function pollsave(act){
		$.get("<?php echo $GLOBALS["BASEURL"];?>/polls.php", { 
		    act: act, poid: $('#poid').val() , question: $('#question').val(), opt0: $('#opt0').val(), opt1: $('#opt1').val(), opt2: $('#opt2').val(), opt3: $('#opt3').val(), opt4: $('#opt4').val(), opt5: $('#opt5').val(), opt6: $('#opt6').val(), 
		    opt7: $('#opt7').val(), opt8: $('#opt8').val(), opt9: $('#opt9').val(), opt10: $('#opt10').val(), opt11: $('#opt11').val(), opt12: $('#opt12').val(), opt13: $('#opt13').val(), opt14: $('#opt14').val()

		  }, function(data){
		    $('#info').html(data);
		});

      }

 </script>
  <?php
$submit="add";

  if($act=="add"){

        if(!$question || !$opt0 || !$opt1){
	    infoerr(btlng513);
	  }

    
	    mysql_query("INSERT INTO polls (added, question, opt0, opt1, opt2, opt3, opt4, opt5, opt6, opt7, opt8, opt9, opt10, opt11, opt12, opt13, opt14) VALUES ($time, ".sqlesc($question).", ".sqlesc($opt0).", ".sqlesc($opt1).",
			".sqlesc($opt2).", ".sqlesc($opt3).", ".sqlesc($opt4).", ".sqlesc($opt5).", ".sqlesc($opt6).", ".sqlesc($opt7).", ".sqlesc($opt8).", ".sqlesc($opt9).", ".sqlesc($opt10).", ".sqlesc($opt11).", 
			".sqlesc($opt12).", ".sqlesc($opt13).", ".sqlesc($opt14).")") or sqlerr(__FILE__, __LINE__);

	    if(mysql_affected_rows()){
	      okmsg(btlng504,btlng509);
	    }else{
		errmsg(btlng32,btlng510);
	      }

      die();
    }

  elseif($act=="editsave"){

    
		mysql_query("UPDATE polls SET " .
		"question = " . sqlesc($question) . ", " .
		"opt0 = " . sqlesc($opt0) . ", " .
		"opt1 = " . sqlesc($opt1) . ", " .
		"opt2 = " . sqlesc($opt2) . ", " .
		"opt3 = " . sqlesc($opt3) . ", " .
		"opt4 = " . sqlesc($opt4) . ", " .
		"opt5 = " . sqlesc($opt5) . ", " .
		"opt6 = " . sqlesc($opt6) . ", " .
		"opt7 = " . sqlesc($opt7) . ", " .
		"opt8 = " . sqlesc($opt8) . ", " .
		"opt9 = " . sqlesc($opt9) . ", " .
		"opt10 = " . sqlesc($opt10) . ", " .
		"opt11 = " . sqlesc($opt11) . ", " .
		"opt12 = " . sqlesc($opt12) . ", " .
		"opt13 = " . sqlesc($opt13) . ", " .
		"opt14 = " . sqlesc($opt14) ." WHERE poid = $poid") or sqlerr(__FILE__, __LINE__);

		if(mysql_affected_rows()){

		  okmsg(btlng511,btlng511);

		  }else{

		    errmsg(btlng32,btlng512);

		  }

      die();
    }

  else{

	if($act=="edit"){

		if(!is_valid_id($poid)){
			infoerr(btlng507);
		  }

		    $res = mysql_query("SELECT * FROM polls WHERE poid = ".sqlesc($poid)) or sqlerr(__FILE__, __LINE__);


		      if (mysql_num_rows($res) == 0){
			      infoerr(btlng508);
			}


		    $poll = mysql_fetch_assoc($res);

		    $submit="editsave";

	}

	echo "<br><div class=\"shadow\" style=\"padding:1px;width:50%;background-color:#FFFFDD;\">

		  <div class=\"table\">
		      <div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;background-color:#E9FFC4;\">
			  <div class=\"td\" style=\"border-right:1px solid #ABABAB;\"><b>".btlng505."</b> : </div><div class=\"td\"><input type=\"text\" id=\"question\" value=\"";

			  if(isset($poll["question"])){echo $poll["question"];}

		      echo "\" size=\"84\"></div>
		      </div>
		      ";

		  $i=0;
		  while($i < 15){
			  echo "<div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\">
				  <div class=\"td\" style=\"border-right:1px solid #ABABAB;\"><b>".btlng506.($i+1)." </b>: </div>
				  <div class=\"td\"><input type=\"text\" id=\"opt$i\" size=\"84\" value=\"";

				  if(isset($poll["opt$i"])){echo $poll["opt$i"];}

				  echo "\" maxlength=\"150\"></div>
				</div>";
			$i++;
			}

		      if($act=="edit"){
			      echo "<input type=\"hidden\" id=\"poid\" value=\"".$poll["poid"]."\">";
			}else{
			      echo "<input type=\"hidden\" id=\"poid\" value=\"\">";
			  }

		  echo "</div>
			    <div><center><br><a href=\"javascript:pollsave('$submit');\" class=\"buttonsilver\">".btlng204."</a><br><br></center></div>\n
			</div><br>";

}

?>