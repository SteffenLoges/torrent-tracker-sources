<?php
require_once("inc/func.php");

dbconn();
if($CURUSER){
   $langlang = btlng531;
  }else{
      $langlang =  "Language";
  }

  title($langlang,$langlang);

  mkglobal("lang");

  if($lang){
          setcookie("p5w_lang", $lang, 0x7fffffff, "/");
      go_to("language");
    }
?> 
<br>
<div class="shadow">
      <div class="table">

	  <div class="tr">
		<div class="td"><a href="<?php echo $GLOBALS["BASEURL"];?>/#language?lang=de"><img src="/images/flags/de.png" title="Deutsch"></a></div>

		<div class="td"><a href="<?php echo $GLOBALS["BASEURL"];?>/#language?lang=en"><img src="/images/flags/en.png" title="English"></a></div>
	  </div>

      </div>
</div>

