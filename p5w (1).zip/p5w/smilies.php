<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();
 if(isset($_GET["shout"])){$shout = 0+$_GET["shout"];}else{$shout=0;}

if($shout==1){
?>
    <script>
	  $('#smilieimg a').click(function() {
	    emoticon = $(this).attr("title"); 
	    $("#shtext").val($("#shtext").val() + emoticon);
	    $('#smilies').hide();
	    $("#shtext").focus();
	    });
    </script>
<?php

}
if(!$shout){
?>
    <script>
	  $('#smilieimg a').click(function() {
	    emoticon = $(this).attr("title");
	    $.markItUp( { replaceWith:emoticon } );
	    $('#smilies').hide();
	    });
    </script>
<?php
}
  echo "<div id=\"smilieimg\">";
  foreach($smilies as $key => $val){
  echo "<a href=\"javascript:;\" title=\"$key\"><img src=\"".$GLOBALS["IMAGES_DIR"]."smilies/$val\" title=\"$key\"></a>";
  }
  echo "</div>";


?>