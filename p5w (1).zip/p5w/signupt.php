<?php
require_once("inc/func.php");
dbconn();

function validusername($username)
{
	if ($username == "")
	  return false;

	// The following characters are allowed in user names
	$allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	for ($i = 0; $i < strlen($username); ++$i)
	  if (strpos($allowedchars, $username[$i]) === false)
	    return false;

	return true;
}

$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $GLOBALS["MAX_USERS"])
{
infoerr(btlng13);
}

// check if IP addy is already in use
  $chkip = mysql_fetch_row(mysql_query("select COUNT(*) from log_ip where ip='$ipencode'"))  or sqlerr(__FILE__, __LINE__);
  if ($chkip[0] != 0){
  infoerr(btlng25_2);
  }

$username="";$passwd="";$repasswd="";$email="";$scode="";

if(isset($_GET["faqverify"])){$faqverify=$_GET["faqverify"];}else{$faqverify="";}

if(isset($_GET["ageverify"])){$ageverify=$_GET["ageverify"];}else{$ageverify="";}


if (!mkglobal("username:passwd:repasswd:email:scode"))
{
infoerr(btlng14);
}

  if(!$scode || strtolower($scode) != $_SESSION["scode"]){
  infoerr(btlng22_2);
  }

  if(empty($username) || empty($passwd) || empty($email)){
  infoerr(btlng15);
  }

  if(strlen($username) > 12){
  infoerr(btlng16);
  }

  if($passwd != $repasswd){
  infoerr(btlng17);
  }

  if(strlen($passwd) < 6){
  infoerr(btlng18);
  }

  if(strlen($passwd) > 40){
  infoerr(btlng19);
  }

  if($passwd == $username){
  infoerr(btlng20); 
  }

  if(!validemail($email)){
    infoerr(btlng21);
  }

  if(!validusername($username)){
    infoerr(btlng22);
  }

  if($faqverify != "yes" || $ageverify != "yes"){
  infoerr(btlng23);
  }

// check if email addy is already in use
  $a = (mysql_fetch_row(mysql_query("select COUNT(*) from users where email=".sqlesc($email))))  or sqlerr(__FILE__, __LINE__);
  if ($a[0] != 0){
  $emailerr=str_replace("%email%", $email, btlng24);
  infoerr($emailerr);
  }

// check if username addy is already in use
  $b = (mysql_fetch_row(mysql_query("select COUNT(*) from users where username=".sqlesc($username)))) or sqlerr(__FILE__, __LINE__);
  if ($b[0] != 0){
  infoerr(btlng25);
  }

$secret = mksecret();
$passhash = md5($secret . $passwd . $secret);
$editsecret = mksecret();
$userkey = userkey();


if(!$arr[0]){
    $userclass=UC_ROOT;
    } else{
	$userclass=UC_USER;
      }

$ret=mysql_query("INSERT INTO users (username, passhash, userkey, secret, editsecret, email, class, added, uploaded) VALUES (
".implode(",", array_map("sqlesc", array(
$username, 
$passhash, 
$userkey, 
$secret, 
$editsecret, 
$email))).", 
$userclass, 
$time,
".$GLOBALS["SIGNUP_UPLOAD_GIFT"].")") or sqlerr(__FILE__, __LINE__);


  if(!$ret) {
	  infoerr(btlng26);
	}

$uid = mysql_insert_id();

$psecret = md5($editsecret);

# SIGNUP EMAIL BODY
$body=str_replace(array("%sitename%","%email%","%ip%","%baseurl%","%id%","%secret%"),array($GLOBALS["SITENAME"],$email,$ip,$GLOBALS["BASEURL"],$uid,md5($editsecret)),btlng27);

mail($email, $GLOBALS["SITENAME"]." ".btlng28, $body, btlng29.": ".$GLOBALS["SITEEMAIL"]);

if(!$arr[0]){
    add_user_to_ram($uid);
    }


okmsg(btlng30,btlng31);



dbclose();
?>
