<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["uid"])){$uid=0+$_GET["uid"];}else{$uid="";}
if(isset($_GET["secret"])){$md5=htmlchar($_GET["secret"]);}else{$md5="";}
if(isset($_GET["email"])){$email=htmlchar(urldecode($_GET["email"]));}else{$email="";}

 $res = mysql_query("SELECT editsecret FROM users WHERE uid = ".sqlesc($uid)) or sqlerr(__FILE__,__LINE__);
 $row = mysql_fetch_row($res);

 if(!$row || !$md5){
        errmsg(btlng32,btlng368);   
      }

 $sec = hash_pad($row[0],12);

 if($md5 != md5($sec . $email . $sec)){
        errmsg(btlng32,btlng369);
  }

 mysql_query("UPDATE users SET editsecret='', editsecrettime='', email=" . sqlesc($email) . " WHERE uid=".sqlesc($uid)." AND editsecret=" . sqlesc($row[0])) or sqlerr(__FILE__,__LINE__);

 if(!mysql_affected_rows()){
        errmsg(btlng32,btlng370);
     }

 infok(btlng371);

 $_SESSION["udata"]["email"]=$email;

 go_to("profile");


?> 