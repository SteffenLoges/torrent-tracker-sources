<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

mkglobal("act");
mkglobal("voteid:sort","int");

 $userid = $CURUSER["uid"];

 # ADD POOL VOTE
    if($act=="addvote"){

		# get current poll
		$pres = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

		  $parr = mysql_fetch_assoc($pres);
		    $pollid = $parr["poid"];

		    $i=0;
		    $totpollsels=0;

		    while($i < 15)
		      {
			  if($parr["opt$i"]){
				$totpollsels++;
			      }
		      $i++;
		      }

		    # SAVE USER VOTE
		    if($voteid < $totpollsels){
			  mysql_query("INSERT INTO pollsansusers (pollid, userid) VALUES ($pollid, $userid)");

			  mysql_query("UPDATE polls SET vote$voteid = vote$voteid + 1") or sqlerr(__FILE__, __LINE__);
		      }
			elseif($voteid >= $totpollsels){
			  mysql_query("INSERT INTO pollsansusers (pollid, userid) VALUES ($pollid, $userid)");
			  }
         }




  # READ POOL
		      $pres = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

		      if(mysql_num_rows($pres)){
			  $parr = mysql_fetch_assoc($pres);
			    $pollid = $parr["poid"];
			    $question = $parr["question"];

			    $pollres=array();

			    $i=0;
			    $totvotes=0;
			    $totpollsels=0;

			    while($i < 15)
			      {
				  if($parr["opt$i"]){
				      $selcs=$parr["opt$i"];
				      $selsvote=$parr["vote$i"];

				      $pollres[$selcs]=$selsvote;

				      $totvotes = $totvotes + $selsvote;
					$totpollsels++;

				      }
			      $i++;
			      }


			    # check if user has already voted
			    $usvotres = mysql_query("SELECT COUNT(*) FROM pollsansusers WHERE pollid=$pollid AND userid=$userid") or sqlerr(__FILE__, __LINE__);
			    $usvotrow = mysql_fetch_row($usvotres);
			    
			    if($usvotrow[0]){
?>
					<script>
						      $('#pollr').fadeIn(1000);
						</script>
<?php
				  arsort ($pollres);
					  echo "<div class=\"table\" style=\"text-align:center;\">
						  <div class=\"tr\" style=\"background:#fff url($stylelink/h28.png) repeat-x;\">
							<div class=\"td\"><b style=\"font-size:13px;\">$question</b></div>
						  </div>
						  </div><br>";
				echo "<div class=\"table\" style=\"width:500px;\"> ";

				 $colorArray = array(0 => "#ffcc00", "#00ff00", "#cc0000", "#0066cc", "#ff0099", "#ffcc00", "#00ff00", "#cc0000", "#0066cc", "#ff0099", "#ffcc00", "#00ff00", "#cc0000", "#0066cc", "#ff0099");
				  $perci=0;
				      foreach ($pollres as $val => $key){
					  $perc = round($key / $totvotes * 100) ;

				
					      $pcolor=$colorArray[$perci];
					      
						    $perc2=$perc * 1.5;
					      echo "<script>
						      $('#perc$perci').animate({width: \"$perc2\"}, 1000);
 

					      </script>";

						  echo "<div class=\"tr\">
								<div class=\"td\" style=\"text-align:left;font-size:11px;\">$val</div>
								<div class=\"td\" style=\"text-align:left; width: 150px;\"><div class=\"percpoll\" id=\"perc$perci\" style=\"width:0%;background-color:$pcolor;\">&nbsp;</div></div>
								<div class=\"td\" style=\"text-align:left;\">$perc % </div>
							     </div>";
					      $perci++;
					  }
			      echo "</div><br><p><center>".btlng514." : $totvotes</center></p>";
				}else{

					?>
						<script>
						      $("input[id='pollradio']").click(function() {
 
							    $.get("<?php echo $GLOBALS["BASEURL"];?>/poll.php", { act: "addvote", voteid: $("input[id='pollradio']:checked").val() }, function(data){
							      $('#pollr').css("display","none").fadeOut(300);
							      $('#pollr').fadeIn(1300).html(data);
							    });
						      });
						      $('#pollr').fadeIn(1000);
						</script>
					<?php



					  echo "<div class=\"table\" style=\"text-align:center;\">
						  <div class=\"tr\" style=\"background:#fff url($stylelink/h28.png) repeat-x;\">
							<div class=\"td\"><b style=\"font-size:13px;\">$question</b></div>
						  </div>
						  </div><br>";
					    $i=0;
					    while($i < $totpollsels)
					      {
						echo "<div style=\"padding-left:25%;\"><input type=\"radio\" id=\"pollradio\" name=\"pollradiox\" value=\"$i\"><label for=\"$i\">&nbsp;".$parr["opt$i"]."</label></div>";

					      $i++;
					      }

						echo "<p style=\"padding-left:25%;\"><input type=\"radio\" id=\"pollradio\" name=\"pollradiox\" value=\"999\"><label for=\"999\">&nbsp;".btlng515."</label></p>";

				  }

		      }

		      else{
			  echo "<center><b>".btlng503."</b><center>";
			}

?>