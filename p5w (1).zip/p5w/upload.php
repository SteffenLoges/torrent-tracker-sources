<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

  # Check User Upload
    if(!$CURUSER["allowupload"]){
	errmsg(btlng32,btlng45_2);
      }

 title(btlng4_2,btlng4_2);
?>

<script type="text/javascript" src="js/jquery.upload.js"></script>

<script>
    $(function() {
        $('#upload_button').click(function() {
            $('#fields').upload('<?php echo $GLOBALS["BASEURL"];?>/uploadt.php', function(res) {
	    $('#info').html(res);
            }, 'html');
        });
    });
  </script>

 <div class="upload">
<?php echo btlng46_0;?> <input size="45" value="<?php echo $GLOBALS["ANNOUNCE_URLS"][0];?>"> 
<br><br>
<?php echo btlng61;?>
 </div>
<br>
  <form action="#" method="post">
 <div id="fields" class="upload">

     <div class="divbottom"><dl><dt><?php echo btlng46;?></dt><dd><input type="file" name="torrent" size="44"></dd></dl></div>
     <div class="divbottom"><dl><dt><?php echo btlng47;?></dt><dd><input type="text" name="name" size="44"></dd></dl></div>
     <div class="divbottom"><dl><dt><?php echo btlng48;?></dt><dd><input type="file" name="pic1" size="44" /></dd></dl></div>
     <div class="divbottom"><dl><dt><?php echo btlng49;?></dt><dd><input type="file" name="pic2" size="44" /></dd></dl></div>
     <div class="divbottom"><dl><dt><?php echo btlng50;?></dt><dd><input type="file" name="nfo" size="44" /></dd></dl></div>



  <!-- Audio -->

  <div class="divbottom"><dl><dt><?php echo btlng53;?></dt><dd>
  <?php
  $count=1;
  foreach($torrentlang as $key => $val){
  echo "<div style=\"float:left;width:130px;\"><input name=\"alang_$key\" value=\"$key\" type=\"checkbox\"> <img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\"> $val</div>\n";
  if($count%3==0){echo "<div style=\"clear:left;\"></div>\n";}
  $count++;
  }
  ?></dd></dl></div>



  <!-- Subtitle -->

  <div class="divbottom"><dl><dt><?php echo btlng54;?></dt><dd>
  <?php
  $count=1;
  foreach($torrentlang as $key => $val){
  echo "<div style=\"float:left;width:130px;\"><input name=\"slang_$key\" value=\"$key\" type=\"checkbox\"><img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\"> $val</div>\n";
  if($count%3==0){echo "<div style=\"clear:left;\"></div>\n";}
  $count++;
  }
  ?></dd></dl></div>



  <!-- Seedspeed -->

  <div class="divbottom"><dl><dt><?php echo btlng51;?></dt><dd>
  <select name="seederspeed">
  <option value="0"><?php echo btlng52;?></option>
  <?php
  foreach($seederspeed as $speedval){
  echo "<option value=\"$speedval\">$speedval</option>";
  }
  ?></select> KB/s</dd></dl></div>



  <!-- Categories -->

  <div class="divbottom"><dl><dt><?php echo btlng55;?></dt><dd>
  <select name="cat"><option value="0"><?php echo btlng52;?></option>";
  <?php
  $rescat=mysql_query("SELECT cid,name FROM categories");
  while ($rowcat = mysql_fetch_row($rescat)) {
  echo "<option value=\"".$rowcat["0"]."\">".htmlchar($rowcat["1"])."</option>";
  }
  ?></select></dd></dl></div>



  <!-- Editor -->

  <div class="divbottom"><dl><dt><?php echo btlng56;?></dt><dd style="margin: 0 auto;padding-left:0px;"><?php editor();?></dd></dl></div>

<br>



    <!-- Submit Button -->
    <a id="upload_button" class="buttonsilver"><?php echo btlng57;?></a>

  </div>
  </form>


