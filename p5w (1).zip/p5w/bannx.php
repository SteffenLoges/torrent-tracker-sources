<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(get_user_class() < UC_MODERATOR){
      errmsg(btlng26_2,btlng26_2);
}

mkglobal("banuid","int");
mkglobal("act");

  title(btlng482,btlng482);


    if($act=="user"){

	  if($banuid){
		?>
		<script>
		  $('#addbann').click(function() {
		  if(confirm('<?php echo btlng120;?>')) {
		    $.post("<?php echo $GLOBALS["BASEURL"];?>/bans.php", {  
			act:'bannuser', banuid: '<?php echo $banuid;?>', comment: $('#banncomm').val()}, function(data){
			$('#info').html(data);        
			});
		    }
		  });
		</script>
		<?php

		$banuserres=mysql_query("SELECT ip FROM log_ip WHERE uid=".sqlesc($banuid)) or sqlerr(__FILE__, __LINE__); 

		  if(!mysql_num_rows($banuserres)){
		      errmsg(btlng485,btlng485);
		  }

		$user=mysql_fetch_row(mysql_query("SELECT username, class FROM users WHERE uid=".sqlesc($banuid))) or sqlerr(__FILE__, __LINE__); 

		    if($user[1] >= UC_MODERATOR){
			  infoerr(btlng489);
		    }

		echo "<br><div class=\"shadow\"><div class=\"table\">
			<div class=\"tr\" style=\"padding:10px;background-color:#FFFFE5;width:110px;\">
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;\">".btlng6_2." : </div>
			      <div class=\"td\">".$user[0]." (UID = $banuid)</div>
			</div>
			<div class=\"tr\" style=\"border-top:1px solid #ABABAB;padding:10px;background-color:#FFFFE5;\">
			      <div class=\"td\" style=\"width:110px;border-right:1px solid #ABABAB;\"> Log ".btlng4_8." : </div> 
			      <div class=\"td\"><div class=\"table\">";

		  while($banuserrow=mysql_fetch_row($banuserres)){

			    echo "<div class=\"tr\">
					<div class=\"td\"> ".ipd($banuserrow[0])." </div>
				  </div>";

		    }

		echo "</div>
			</div>
			</div>
			<div class=\"tr\" style=\"border-top:1px solid #ABABAB;padding:10px;background-color:#FFFFE5;\">
			      <div class=\"td\" style=\"width:110px;border-right:1px solid #ABABAB;vertical-align:top;\">".btlng292_2." : </div>
			      <div class=\"td\"><textarea id=\"banncomm\" name=\"descr\" cols=\"80\" rows=\"8\"></textarea></div>
			</div>
		</div></div>

		<br><center><a href=\"javascript:;\" id=\"addbann\" class=\"buttonsilver\">".btlng483."</a></center>";
      }
	    else{

			  ?>
			  <script>
				$('#gotousbann').click(function() {
				      window.location.replace('<?php echo $GLOBALS["BASEURL"]."/#bannx?act=user&banuid="?>'+$('#banuserid').val());               
				});
			  </script>
			  <?php

			  echo "<br><div class=\"shadow\" style=\"width:400px;\"><div class=\"table\">";
			  echo "<div class=\"tr\" style=\"padding:10px;background-color:#FFFFE5;\">
					<div class=\"td\" style=\"width:110px;border-right:1px solid #ABABAB;padding:10px;\">".btlng496." : </div>
					<div class=\"td\"><input id=\"banuserid\" type=\"text\" size=\"28\"></div>
				</div>";
			  echo "</div></div>
				  <br><center><a href=\"javascript:;\" id=\"gotousbann\" class=\"buttonsilver\">".btlng188."</a></center>";

	    }
    }

    elseif($act=="ip"){

			  ?>
			  <script>
				$('#banip').click(function() {
				if(confirm('<?php echo btlng120;?>')) {
				  $.post("<?php echo $GLOBALS["BASEURL"];?>/bans.php", {  
				      act:'bannip', fip: $('#fip').val(), lip: $('#lip').val(), comment: $('#banncomm').val()}, function(data){
				      $('#info').html(data);        
				      });
				  }
				});
			  </script>
			  <?php

			  echo "<br><div class=\"shadow\" style=\"width:500px;\"><div class=\"table\">";

			  echo "<div class=\"tr\" style=\"padding:10px;background-color:#FFFFE5;\">
					<div class=\"td\" style=\"width:110px;border-right:1px solid #ABABAB;padding:10px;\">".btlng490." : </div>
					<div class=\"td\"><input id=\"fip\" type=\"text\" size=\"28\"></div>
				</div>
				 <div class=\"tr\" style=\"border-top:1px solid #ABABAB;padding:10px;background-color:#FFFFE5;\">
					<div class=\"td\" style=\"width:110px;border-right:1px solid #ABABAB;padding:10px;\">".btlng491." : </div>
					<div class=\"td\"><input id=\"lip\" type=\"text\" size=\"28\"></div>
				</div>
				<div class=\"tr\" style=\"border-top:1px solid #ABABAB;padding:10px;background-color:#FFFFE5;\">
				      <div class=\"td\" style=\"width:110px;border-right:1px solid #ABABAB;vertical-align:top;\">".btlng292_2." : </div>
				      <div class=\"td\"><textarea id=\"banncomm\" name=\"descr\" cols=\"50\" rows=\"8\"></textarea></div>
				</div>";

			  echo "</div></div>
				  <br><center><a href=\"javascript:;\" id=\"banip\" class=\"buttonsilver\">".btlng483."</a></center>";


      }
     else{

		$res = mysql_query("SELECT * FROM bans ORDER BY added DESC") or sqlerr(__FILE__, __LINE__); 
		
		echo "<br><div class=\"shadow\" style=\"width:75%;\"><div class=\"table\">";

		      if(!mysql_num_rows($res)){
			echo "<div class=\"tr\" >
			      <div class=\"td\" style=\"padding:10px;\"><center><b>".btlng484."</b></center></div>
			</div>";
		      }
			else{

			      ?>
			      <script>
				function rembann(bid) {
				if(confirm('<?php echo btlng120;?>')) {
				  $.get("<?php echo $GLOBALS["BASEURL"];?>/bans.php", {  
				      act:'delbann', bannid: bid , wuid: $('#withuid:checked').val()}, function(data){
				      $('#info').html(data);   
				      $('#bann_'+bid).remove(); 
				      });
				  }
				}
			      </script>
			      <?php

				  echo "<div class=\"tr\" style=\"background:#fff url($stylelink/h28.png) repeat-x;padding:1px;\">
					    <div class=\"td\"><b>".btlng115."</b></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><b>".btlng490."</b></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><b>".btlng491."</b></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><b>".btlng6_2."</b></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><b>".btlng292_2."</b></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><b>".btlng492."</b></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><b>".btlng117."</b></div>
					</div>";
			  $icolor=0;
			      while ($arr = mysql_fetch_row($res))
			      {
				$uschkbox="";
				    $r2 = mysql_query("SELECT username, class FROM users WHERE uid=".$arr[4]) or sqlerr();
				    $a2 = mysql_fetch_row($r2);

				    $ipfirst = ipd($arr[1]);
				    $iplast = ipd($arr[2]);
				    $added = gdate($arr[6]);
				    if($arr[5]){
					$uschkbox="<input type=\"checkbox\" id=\"withuid\" value=\"".$arr[5]."\" title=\"".btlng493."\"> ( ".$arr[5]." )";
				      }
		      # BACKGROUND COLOR ROW
		      if($icolor % 2 ){
			  $bgcolor="#F8F8F8";
			}else{$bgcolor="#FFFFE5";}

				  echo "<div class=\"tr\" id=\"bann_".$arr[0]."\" style=\"border-top:1px solid #ABABAB;padding:10px;background-color:$bgcolor;\">
					    <div class=\"td\">$added</div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\">$ipfirst</div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\">$iplast</div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=".$arr[4]."\" ><font color=\"".get_class_color($a2[1])."\"><b>".ucfirst($a2[0])."</b></font></a></div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;\">".$arr[3]."</div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;\">$uschkbox</div>
					    <div class=\"td\" style=\"border-left:1px solid #ABABAB;text-align:center;\"><a href=\"javascript:;\" class=\"buttonsilver\" onclick=\"rembann('".$arr[0]."')\">".btlng117."</a></div>
					</div>";
			    $icolor++;
			      }

		      }

		echo "</div></div>";
    }





















?>