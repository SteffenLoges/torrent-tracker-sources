<?php
require_once("inc/func.php");

dbconn();

logoutcookie();

go_to("login");
?> 
