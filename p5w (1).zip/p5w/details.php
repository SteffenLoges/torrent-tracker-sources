<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}
if(isset($_GET["act"])){$act=$_GET["act"];}else{$act="";}
if(isset($_GET["guedit"])){$guedit=0+$_GET["guedit"];}else{$guedit="";}
if(isset($_GET["activate"])){$tactivate=0+$_GET["activate"];}else{$tactivate="";}
if(isset($_GET["ppage"])){$perpage=0+$_GET["ppage"];}else{$perpage=$GLOBALS["COMMENTS_PERPAGE"];}
if(isset($_GET["pno"])){$page=0+$_GET["pno"];}else{$page=1;}
if(isset($_GET["hidehead"])){$hidehead=0+$_GET["hidehead"];}else{$hidehead=0;}

if($perpage > $GLOBALS["MAX_COMMENTS_PERPAGE"]){$perpage = $GLOBALS["MAX_COMMENTS_PERPAGE"];}

 if(!$tid || !is_valid_id($tid)){
	  errmsg(btlng32,btlng295);
       }

 $sqlcatsaud="";
 $sqlcatssub="";
  foreach($torrentlang as $key => $val){
     $sqlcatsaud .= "audlang_$key ,";
     $sqlcatssub .= "sublang_$key ,";
  }

$torquery  = "SELECT torrents.tid, torrents.toruid, torrents.name, torrents.descr, torrents.seedspeed, torrents.size, torrents.added, torrents.numfiles, ";
$torquery .= "torrents.numpics, $sqlcatsaud $sqlcatssub torrents.times_completed, torrents.leechers, torrents.seeders, torrents.lastaction, torrents.activated, torrents.banned, ";
$torquery .= "torrents.visible, torrents.gu_agent, categories.name AS cat_name, users.username, users.class FROM torrents ";
$torquery .= "LEFT JOIN categories ON torrents.catid = categories.cid LEFT JOIN users ON torrents.toruid = users.uid WHERE torrents.tid = ".sqlesc($tid);

 $restord = mysql_query($torquery) or sqlerr(__FILE__, __LINE__); 

  if(!mysql_num_rows($restord)){
	  errmsg(btlng32,btlng295);
     }

 $rowtord = mysql_fetch_row($restord);


 $di=-1;

 $tid = $rowtord[++$di];
 $toruid = $rowtord[++$di];
 $name = $rowtord[++$di];
 $descr = $rowtord[++$di];
 $seedspeed = $rowtord[++$di];
 $size = mksize($rowtord[++$di]);
 $added = gdate($rowtord[++$di]);
 $numfiles = $rowtord[++$di];
 $numpics = $rowtord[++$di];

  foreach($torrentlang as $key => $val){
     $aud_["$key"] = $rowtord[++$di];

  }
  foreach($torrentlang as $key => $val){
     $sub_["$key"] = $rowtord[++$di];
  }

 $times_completed = $rowtord[++$di];
 $leechers = $rowtord[++$di];
 $seeders = $rowtord[++$di];
 $lastaction = gdate($rowtord[++$di]);
 $activated = $rowtord[++$di];
 $banned = $rowtord[++$di];
 $visible = $rowtord[++$di];
 $gu_agent = $rowtord[++$di];
 $cat_name = $rowtord[++$di];
 $username = $rowtord[++$di];
 $userclass = $rowtord[++$di];

  # We limit access for the GU team on torrents of users below UC_UPLOADER
  $owned = $moderator = 0;

   if ($CURUSER["uid"] == $toruid){
            $owned = 1;
	} 

        if(get_user_class() >= UC_MODERATOR || (!$activated && get_user_class() == UC_GUTEAM && $userclass < UC_UPLOADER)){
	      $moderator = 1;
	    }

  $titlename=str_replace("%tname%",$name,btlng303);

# PAGE TITLE
  title($titlename,"[img=".$GLOBALS["BASEURL"]."/$stylelink/viewmag.png] ".$titlename);

# BANNED MSG
    if($banned && !$moderator){
	  errmsg(btlng32,btlng304);
      }
# NOT ACTIVATED MSG
    if(!$owned && !$activated){
	  errmsg(btlng32,btlng305);
	}

# HIDE DETAILS FOR COMMENTS

if(!$hidehead){

# OWNER AND MODERATOR TORRENT EDIT, ACTIVATE 
	if($owned || $moderator){
?>

<script>
  $('#deltor').click(function() {
      $('#tordel').show("slow");
  });

  $('#deletetor').click(function() {
   if(confirm('<?php echo btlng120;?>')) {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/delete.php", {  tid:'<?php echo $tid;?>', reason: $('#delreason').val()}, function(data){
	$('#info').html(data);        
	});
     }
  });

</script>

<?php
	  echo "<div id=\"tordel\" style=\"display:none;\">
			  <div class=\"shadow\" style=\"background:#fff url($stylelink/h28.png) repeat-x;width:460px;padding:1px;\">
					<div class=\"table\">
					    <div class=\"tr\">
						  <div class=\"td\"><center><b>".btlng334_2."</b></center></div>
					    </div>
					</div>
			  </div>

			  <div class=\"shadow\" style=\"width:460px;\">
					  <div class=\"table\">
						<div class=\"tr\">
						  <div class=\"td\"><center>".btlng334_3. ": <input type=\"text\" id=\"delreason\" size=\"30\"></center></div>
						</div>
						<div class=\"tr\">
						  <div class=\"td\"><center><a href=\"javascript:;\" id=\"deletetor\" class=\"buttonsilver\">".btlng334_2."</a></center></div>
						</div>
					  </div>
			  </div>
		</div>


		<br><div class=\"shadow\" style=\"width:200px;\"><div class=\"table\">
		      <div class=\"tr\">
			<div class=\"td\"><center><a href=\"".$GLOBALS["BASEURL"]."/#toredit?tid=$tid\" title=\"".btlng334."\"><img src=\"$stylelink/edit.png\"></a></center></div>
			<div class=\"td\"><center><a href=\"javascript:;\" id=\"deltor\" title=\"".btlng334_2."\"><img src=\"$stylelink/deletet.png\"></a></center></div>";
	    if($moderator){

		    if(!$gu_agent && !$activated){
	               echo "<div class=\"td\"><center><a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tid&guedit=1\" title=\"".btlng334." ".btlng335."\"><img src=\"$stylelink/guedit.png\"></a></center></div>";
		      }

		    if(!$activated && ($gu_agent==$CURUSER["uid"] || get_user_class() >= UC_MODERATOR)){
	               echo "<div class=\"td\"><center><a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tid&activate=1\" title=\"".btlng336."\"><img src=\"$stylelink/activate.png\"></a></center></div>";
		      }

		if(!$gu_agent && $guedit){
                      mysql_query("UPDATE torrents SET gu_agent = ".$CURUSER["uid"]." WHERE tid=$tid");
		      infok(btlng322);
		  }

		if($tactivate && !$activated){

		      $modmsg=str_replace(array("%torurl%","%torname%","%userlink%","%username%"),array($GLOBALS["BASEURL"]."/#details?tid=$tid","$name",$GLOBALS["BASEURL"]."/#userdetails?uid=".$CURUSER["uid"],$CURUSER["username"]),btlng325);
                      $sendmsg ="(0, $toruid, 4, $time, '".btlng324."', '$modmsg')";
	              mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES ".$sendmsg) or sqlerr(__FILE__, __LINE__);

                          mysql_query("UPDATE torrents SET activated=1, gu_agent = 0, added = $time WHERE tid=$tid");
                           write_log("torrentgranted", str_replace(array("%tid%","%torname%","%curuid%","%curname%"),array($tid,$name,$CURUSER["uid"],$CURUSER["username"]),btlng333));
			   add_torrent_to_ram($tid);
		      infok(btlng323);
		  }

	      }
	  echo "</div></div></div>";
	}



  echo "<br><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\">";

# DOWNLOAD
    if($activated){
       $downloadname="<a href=\"".$GLOBALS["BASEURL"]."/download.php?tid=$tid\" style=\"background:url('$stylelink/download2.png') no-repeat;padding: 0px 20px 16px;\" title=\"Download -> $name\">$name</a>\n";
      }else{
	      $downloadname="<img src=\"$stylelink/notactived2.png\" title=\"".btlng309."\">\n";
	   }

    echo "<div class=\"tr\" id=\"details_tr\">
            <div class=\"td\" id=\"details_td1\"><b>".btlng4_0."</b></div> <div class=\"td\" id=\"details_td2\">$downloadname</div>
          </div>\n";

# WGET COMMAND
  if($CURUSER["wget"]){
            $wget_url = "wget --header='Cookie: p5w_uid=" . $CURUSER["uid"] . "; p5w_pass=" . $CURUSER["passhash"] . "' '".$GLOBALS["BASEURL"]."/download.php?tid=$tid' -O '" . str_replace(array(" "),array("_"),htmlchar($name)) . ".torrent'";
	  echo "<div class=\"tr\" id=\"details_tr\">
		  <div class=\"td\" id=\"details_td1\"><b>".btlng357."</b></div> <div class=\"td\" id=\"details_td2\"><input size=\"74\" value=\"$wget_url\"></div>
		</div>\n";
     }


# DESCR
    if (!empty($descr)) {
	echo '<script type="text/javascript" src="/min/?b=js&amp;f=FancyZoomHTML.js,FancyZoom.js"></script>
	      <script>setupZoom();</script>';

        if ($numpics > 0) {
            $img_prev = "[center]";

            for($I = 1; $I <= $numpics; $I++){
                 $img_prev .= "[url=".$GLOBALS["BASEURL"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/$tid-$I-f.jpg][imgl=".$GLOBALS["BASEURL"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/$tid-$I-t.jpg][/url] ";
	      }

            $img_prev .= "[/center]\n\n";
            $descr = $img_prev . $descr;

        } 
    }

    echo "<div class=\"tr\" id=\"details_tr\">
	   <div class=\"td\" id=\"details_td1\" style=\"vertical-align:top;\"><b>".btlng306."</b></div> <div class=\"td\" id=\"details_td2\">".format_comment($descr)."</div>\n
          </div>\n";

# CAT
    echo "<div class=\"tr\" id=\"details_tr\">
	    <div class=\"td\" id=\"details_td1\"><b>".btlng275."</b></div> <div class=\"td\" id=\"details_td2\">$cat_name</div>\n
	  </div>\n";


  $audimg="";
  $subimg="";
  foreach($torrentlang as $key => $val){
    if($aud_["$key"]){
        $audimg .="<img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\">\n";
      }

    if($sub_["$key"]){
        $subimg .="<img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\">\n";
      }

  }

# AUDIO
  if($audimg){
    echo "<div class=\"tr\" id=\"details_tr\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng307."</b></div> <div class=\"td\" id=\"details_td2\">$audimg</div>\n
         </div>\n";
  }


# SUBTITLE
  if($subimg){
    echo "<div class=\"tr\" id=\"details_tr\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng308."</b></div> <div class=\"td\" id=\"details_td2\">$subimg</div>\n
         </div>\n";
  }

# LAST ACTIVITY
    echo "<div class=\"tr\" id=\"details_tr\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng310."</b></div> <div class=\"td\" id=\"details_td2\">$lastaction</div>\n
         </div>\n";

# SIZE
    echo "<div class=\"tr\" id=\"details_tr\">
            <div class=\"td\" id=\"details_td1\"><b>".btlng311."</b></div> <div class=\"td\" id=\"details_td2\">$size</div>\n
          </div>\n";

# ADDED
    echo "<div class=\"tr\" id=\"details_tr\">
            <div class=\"td\" id=\"details_td1\"><b>".btlng312."</b></div> <div class=\"td\" id=\"details_td2\">$added</div>\n
</div>\n";


# TIMES COMPLETED

    echo "<div class=\"tr\" id=\"details_tr\">
            <div class=\"td\" id=\"details_td1\"><b>".btlng313."</b></div> <div class=\"td\" id=\"details_td2\">$times_completed ".btlng314."</div>\n
          </div>\n";


# TIMES COMPLETED2

    $res = mysql_query("SELECT DISTINCT(user_id) as id, username, class, peers.puid FROM completed,users LEFT JOIN peers ON peers.puid=users.uid AND peers.ptid=$tid AND peers.tleft='0' WHERE completed.user_id=users.uid AND completed.tor_id=$tid ORDER BY complete_time DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);

      $last10users = "";

	  while ($arr = mysql_fetch_row($res)) {
	      if($last10users){ 
		    $last10users .= ", ";
		  }

	      $arr[1] = "<font color=\"".get_class_color($arr[2])."\">".ucfirst($arr[1])."</font>";

	      if($arr[3]) {
		  $arr[1] = "<font color=\"".get_class_color($arr[2])."\"><b>".ucfirst($arr[1])."</b></font>";
	      } 

	      $last10users .= "<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=".$arr[0]."\">".$arr[1]."</a>";
	  } 


		if ($last10users == ""){
			$last10users = btlng320;
		      }else{
			$last10users .= "<br/><br/>".btlng321;
		      }

    echo "<div class=\"tr\" id=\"details_tr\">
            <div class=\"td\" id=\"details_td1\"><b>".btlng313_2."</b></div> <div class=\"td\" id=\"details_td2\">$last10users</div>\n
         </div>\n";


# NFO

    echo "<div class=\"tr\" id=\"details_tr\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng326."</b></div> <div class=\"td\" id=\"details_td2\"><a href=\"".$GLOBALS["BASEURL"]."/#viewnfo?tid=$tid\"><b>".btlng327."</b></a></div>\n
         </div>\n";

# UPLOADER NAME
   $sendpmbut="";
  if($toruid != $CURUSER["uid"]){
      $sendpmbut=" &nbsp;<a href=\"".$GLOBALS["BASEURL"]."/#messages?act=sendpm&recuid=$toruid\" class=\"buttonsilver\" title=\"".btlng129_2."\"> &nbsp; PM &nbsp;</a>\n";
    }
        if(isset($username)){
	   $usnamed="<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$toruid\" title=\"$username\"><font color=\"".get_class_color($userclass)."\"><b>".ucfirst($username)."</b></font></a> $sendpmbut ";	
         }else {
	      $usnamed=" <del><i>(".btlng339.")</i></del> ";
		}

    echo "<div class=\"tr\" id=\"details_tr\">
            <div class=\"td\" id=\"details_td1\"><b>".btlng315."</b></div> <div class=\"td\" id=\"details_td2\">$usnamed</div>\n
         </div>\n";

?>
<script>
                  // PEERLIST
		      function peerlist(tid){
			    $("#peerlist").show();
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/torleechseed.php", {tid: tid }, function(data) {
			      $("#peerlist").html(data);
			    });
			}

                  // FILELIST
		      function filelist(tid){
			    $("#filelist").show();
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/torfiles.php", {tid: tid, showname:1 }, function(data) {
			      $("#filelist").html(data);
			    });
			}
</script>

<?php
# TOTAL FILES
    echo "<div class=\"tr\" id=\"details_tr\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng316."</b></div> <div class=\"td\" id=\"details_td2\"><div id=\"filelist\" class=\"filelist\"></div><a onclick=\"filelist('$tid')\" href=\"javascript:;\">&nbsp; $numfiles &nbsp;</a></div>\n
         </div>\n";


# SEEDER SPEED
    echo "<div class=\"tr\" id=\"details_tr\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng317."</b></div> <div class=\"td\" id=\"details_td2\"><b style=\"color:#740002;\">$seedspeed</b> KB/s</div>\n
         </div>\n";


# PEERS

    if($seeders){
	$sseeders="<font color=\"".get_slr_color($seeders)."\"><b>$seeders</b></font> <a onclick=\"peerlist('$tid')\" href=\"javascript:;\">".btlng289."</a>\n";
	 }else{
	    $sseeders="<font color=\"".get_slr_color($seeders)."\"><b>$seeders</b></font> ".btlng289;
		}

    if($leechers){
	$sleechers="<font color=\"".get_slr_color($leechers)."\"><b>$leechers</b></font> <a onclick=\"peerlist('$tid')\" href=\"javascript:;\">".btlng290."</a>\n";
	 }else{
	    $sleechers="<font color=\"".get_slr_color($leechers)."\"><b>$leechers</b></font> ".btlng290;
		}
      $totalpeers= $seeders + $leechers;
    echo "<div class=\"tr\" id=\"details_tr2\">
           <div class=\"td\" id=\"details_td1\"><b>".btlng318."</b></div> <div class=\"td\" id=\"details_td2\"> $sseeders & $sleechers = 
	   <font color=\"".get_slr_color($totalpeers)."\"><b>$totalpeers</b></font> ".btlng319."
           <div id=\"peerlist\" class=\"peerlist\"></div></div>\n
         </div>\n";


  echo "</div></div><br><br>";

}


####################### COMMENTS #######################


    $commresp = mysql_query("SELECT COUNT(*) FROM comments WHERE tid = $tid");
    $commrowp = mysql_fetch_row($commresp);
$pages=0;
		    $count = $commrowp[0];
		if($count){
		  $pages = ceil($count / $perpage);
		    if($page > $pages){
			    $page=$pages;
			    }else{
				$page=$page;
				}

			    $limit = ($page - 1) * $perpage;
			    $limit = " LIMIT $limit, $perpage ";
			 }

?>
<script>
 	     $('#addcom').click(function() {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/comment.php", {act: "add",tid: '<?php echo $tid;?>', comtxt: $('#markItUp').val() }, function(data) {
			      $("#info").html(data);
			    });
             });
	
	function delcom(comid){
         if (confirm('<?php echo btlng120;?>')) {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/comment.php", {act: "del", comid: comid }, function(data) {
			      $("#info").html(data);
			    });
			  $('#com'+comid).remove();
	   }
         }

        PageClick = function(pageclickednumber) {
            $('#pager,#pager').pager({ pagenumber: pageclickednumber, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
		$.get("<?php echo $GLOBALS["BASEURL"];?>/details.php", { tid: "<?php echo $tid;?>", pno: pageclickednumber, ppage: "<?php echo $perpage;?>", hidehead: 1},
   		function(data){
    		 $('#com').html(data);
   		});
        }

      $('#pager,#pager').pager({ pagenumber: <?php echo $page;?>, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });


</script>
<?php

  $commenthead="<div id=\"com\"><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\">
	      <div class=\"tr\" id=\"details_comment_head\">
		 <div class=\"td\"><center><img src=\"$stylelink/comments.png\"><b>".btlng331."</b></center></div>\n
	      </div>\n";

  if(!$commrowp[0]){

      echo "$commenthead<div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\">
	       <div class=\"td\"><center><b>".btlng332."</b></center></div>
            </div>\n";

      echo "<div class=\"tr\">
	       <div class=\"td\">\n
	     <div style=\"margin: 0 auto;padding-left:0px;\">".editor("",150)."</div>
                 <br><center><a href=\"javascript:;\" id=\"addcom\" class=\"buttonsilver\">".btlng345."</a></center>
               </div></div>";

    } else{
    $commres = mysql_query("SELECT comments.comid, comments.text, comments.cuid, comments.added, comments.editedby, comments.editedat, users.avatar, users.warnpoints, users.username, users.title, users.class, users.donor, users.enabled, users.added FROM comments LEFT JOIN users ON comments.cuid = users.uid WHERE tid = $tid ORDER BY comments.comid $limit") or sqlerr(__FILE__, __LINE__);
    
      echo "$commenthead<div class=\"tr\">
	       <div class=\"td\"><br><div id=\"pager\"></div><br><br>
	
		  <div style=\"text-align:right;padding-right:1px;\">
		  <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tid&ppage=".$GLOBALS["COMMENTS_PERPAGE"]."#com\">".$GLOBALS["COMMENTS_PERPAGE"]."</a> |  
		  <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tid&ppage=15#com\">15</a> | 
		  <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tid&ppage=".$GLOBALS["MAX_COMMENTS_PERPAGE"]."#com\">".$GLOBALS["MAX_COMMENTS_PERPAGE"]."</a> 
		  </div>";

	while($commrow = mysql_fetch_row($commres)){
	     $coi=0;
	      $comid=$commrow[$coi++];
	      $text=$commrow[$coi++];
	      $cuid=$commrow[$coi++];
	      $cadded=gdate($commrow[$coi++]);
	      $editedby=$commrow[$coi++];
	      $editedat=$commrow[$coi++];
	      $avatar=$commrow[$coi++];
	      $warnpoints=$commrow[$coi++];
	      $username=$commrow[$coi++];
	      $title=$commrow[$coi++];
	      $class=$commrow[$coi++];
	      $donor=$commrow[$coi++];
	      $enabled=$commrow[$coi++];
	      $added=$commrow[$coi++];

# Avatar
      if($avatar){
	$avatarsrc=htmlchar($avatar);
	}else{
	      if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($cuid.$added).".jpg")){
	              $avatarsrc=$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($cuid.$added).".jpg";
			}else{
	                    $avatarsrc=$GLOBALS["IMAGES_DIR"]."default_avatar.png";
			  }
	      }
# USERNAME
        if(isset($username)){
	   $usname="<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$cuid\"><font color=\"".get_class_color($class)."\"><b>".$username."</b></font></a> &nbsp;(<b>".get_user_class_name($class)."</b>)";	
         }else {
	      $usname="<del><i>(".btlng339.")</i></del>";
		}

         echo "<br><div id=\"com$comid\">
		    <div class=\"shadow\" style=\"width:98%;padding:1px;\">
		     <div class=\"table\" id=\"details_comment_table\">
			  <div class=\"tr\">
			      <div class=\"td\" id=\"details_comment_td\">
			      <center>
			      <img class=\"imgborder\" style=\"width:110px;\" src=\"$avatarsrc\">
			      <p>$usname</p>
                              <p>".get_user_icons($donor,$warnpoints,$enabled,$added)."</p>
			      <p>$cadded</p>";

				  $mcimglinks="";

				    if($cuid == $CURUSER["uid"] || get_user_class() >= UC_MODERATOR ){
				    $mcimglinks .= "<a href=\"".$GLOBALS["BASEURL"]."/#comment?act=edit&comid=$comid\"><img src=\"$stylelink/comedit.png\"></a>";
				    }

					  if(get_user_class() >= UC_MODERATOR ){
					  $mcimglinks .=  " &nbsp;&nbsp;&nbsp;&nbsp; <a href=\"javascript:;\" onclick=\"delcom('$comid')\"><img src=\"$stylelink/comdel.png\"></a>";
					  }

				  if($mcimglinks){
				  echo "<p>$mcimglinks</p>";
				  }

			echo "</center></div>\n
			  <div class=\"td\" id=\"details_comment_td2\">".format_comment($text)."</div>\n
			  </div>\n";
			  if($editedby || $editedat){
			    echo "<div class=\"tr\">
				  <div class=\"td\" id=\"details_comment_td\"></div>
				  <div class=\"td\" id=\"details_comment_td2\"><i>".btlng345_2." $usname ".btlng345_3." ".gdate($editedat)." ".btlng345_4."</i></div>
			      </div>";
			    }
	        echo "</div>
		    </div>
		   </div>";
	    }

    echo "<br><div id=\"pager\"></div><br><br>
	    </div></div>";

      echo "<div class=\"tr\">
	       <div class=\"td\">\n
	     <div style=\"margin: 0 auto;padding-left:0px;\">".editor("",150)."</div>
                 <br><center><a href=\"javascript:;\" id=\"addcom\" class=\"buttonsilver\">".btlng345."</a></center>
               </div></div>";
	
   }



  echo "</div><br></div></div><br>";

?>