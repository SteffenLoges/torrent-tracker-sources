<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");

if($GLOBALS["SHOUTBOX"]){

      dbconn();
      loggedinorreturn();

      if(isset($_GET["act"])){$act = $_GET["act"];}else{$act="";}
      if(isset($_GET["shid"])){$shid = 0 + $_GET["shid"];}else{$shid=0;}
      if(isset($_GET["shtext"])){$shtext = htmlchar($_GET["shtext"]);}else{$shtext="";}
      if(!isset($_SESSION["shoutboxtime"])){$_SESSION["shoutboxtime"]="empty2";}


  function updateshout(){

	$shres=mysql_query("SELECT shoutbox.*, users.username, users.class FROM shoutbox LEFT JOIN users ON shoutbox.userid=users.uid ORDER BY shid DESC LIMIT 150") or sqlerr(__FILE__, __LINE__);

	$shoutvals="";

	  while($shrow=mysql_fetch_row($shres)){
	  $si=-1;
		$shid=$shrow[++$si];
		$userid=$shrow[++$si];
		$date=$shrow[++$si];
		$text=$shrow[++$si];
		$username=$shrow[++$si];
		$userclass=$shrow[++$si];
		$shoutvals .= "$shid~$userid~$date~$text~$username~$userclass|";
		}

      apc_store("shoutboxvals",$shoutvals);

  }


if($act == "show"){

      $shoutboxtime = apc_fetch("shoutboxtime");

      $shoutboxwvals = apc_fetch("shoutboxvals");



	  if(!$shoutboxwvals){
			$shres=mysql_query("SELECT shoutbox.*, users.username, users.class FROM shoutbox LEFT JOIN users ON shoutbox.userid=users.uid ORDER BY shid DESC LIMIT 150") or sqlerr(__FILE__, __LINE__);

			$shoutvals="";

			  while($shrow=mysql_fetch_row($shres)){
			  $si=-1;
				$shid=$shrow[++$si];
				$userid=$shrow[++$si];
				$date=$shrow[++$si];
				$text=$shrow[++$si];
				$username=$shrow[++$si];
				$userclass=$shrow[++$si];
				$shoutvals .= "$shid~$userid~$date~$text~$username~$userclass|";
				}

			  if($shoutvals){
			      apc_store("shoutboxvals",$shoutvals);
			    }

			$shoutboxwvals = apc_fetch("shoutboxvals");
			apc_store("shoutboxtime",$time);
	  }

      
	  if(!$shoutboxwvals){
		  echo "<center><b>".btlng474."</b></center>";
		  die();
		}else{

			    if($shoutboxtime != $_SESSION["shoutboxtime"]){

			      echo "<div class=\"table\" style=\"border-bottom:1px solid #ABABAB;\">";

				$tr = "border-top:1px solid #ABABAB;background-color:#FFFFDD;";

				$rowshouts = trim($shoutboxwvals,"|");

				$delimiters = Array("|","~");

				$ressh = multiexplode($delimiters,$rowshouts);

				foreach($ressh as $rshout){

					$si=-1;
					      $shid=$rshout[++$si];
					      $userid=$rshout[++$si];
					      $date=date("H:i:s", $rshout[++$si]);
					      $text=$rshout[++$si];
					      $username=$rshout[++$si];
					      $userclass=$rshout[++$si];

					  echo "<div class=\"tr\" id=\"shbox$shid\" style=\"$tr\">
						    <div class=\"td\" style=\"border-right:1px solid #ABABAB;width:40px;padding:9px;vertical-align:middle;\">$date</div>
						    <div class=\"td\" style=\"border-right:1px solid #ABABAB;width:70px;padding:9px;vertical-align:middle;\"><a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$userid\" title=\"".get_user_class_name($userclass)."\"><font color=\"".get_class_color($userclass)."\"><b>".$username."</b></font></a></div>
						    ";

						      if(get_user_class() >= UC_MODERATOR){
									  ?>
									  <script>
									    function delshtxt(shid){
										  if(confirm('<?php echo btlng120;?>')) {
											$.get("<?php echo $GLOBALS["BASEURL"];?>/shoutbox.php", { act: "del", shid: shid }, function(data){
											      $("#info").html(data);
											      $("#shbox"+shid).remove();
											});
										    }
									    }
									    function editshtxt(shid){
											  $('#shouttxtedit').show();
											$.get("<?php echo $GLOBALS["BASEURL"];?>/shoutbox.php", { act: "edit", shid: shid }, function(data){
											      $("#shouttxtedit").html(data);
											});
									    }
									  </script>

									  <?php
							    echo "<div class=\"td\" style=\"border-right:1px solid #ABABAB;padding:9px;vertical-align:middle;\">".format_shout($text)."</div>
								  <div class=\"td\" style=\"border-right:1px solid #ABABAB;vertical-align:middle;width:30px;\"><a href=\"javascript:;\" onclick=\"editshtxt('$shid')\"><center><img title=\"".btlng389."\" width=\"24px\" src=\"$stylelink/edit.png\"></center></a></div>
								  <div class=\"td\" style=\"vertical-align:middle;width:30px;\"><a href=\"javascript:;\" onclick=\"delshtxt('$shid')\"><center><img title=\"".btlng117."\" width=\"24px\" src=\"$stylelink/deletet.png\"></center></a></div>
								  ";
							    }
							      else{
								    echo "<div class=\"td\" style=\"padding:9px;vertical-align:middle;\">".format_shout($text)."</div>";
								  }
					      echo "</div>";
				}

				echo "</div>";

				$_SESSION["shoutboxtime"]=$shoutboxtime;

			    }else{
				echo "0";
				die();
				}
   }
}

elseif($act == "edit"){
  
		if(get_user_class() >= UC_MODERATOR){
			  $editres = mysql_query("SELECT shid, text FROM shoutbox WHERE shid = ". sqlesc($shid)) or sqlerr(__FILE__, __LINE__);
			  $editrow = mysql_fetch_row($editres);

			    ?>
			    <script>
				  $('#editedshsave').click(function() {
				      $('#shouttxtedit').hide();
					$.get("<?php echo $GLOBALS["BASEURL"];?>/shoutbox.php", { act: "editsave", shid: '<?php echo $editrow[0];?>', shtext : $('#editedshtxt').val() }, function(data){
					  $("#info").html(data);
					});
				  });
			    </script>
			<?php

			    echo "<br><div class=\"shadow\" style=\"width:460px;\">
						      <div class=\"table\" id=\"shedittable\">
							    <div class=\"tr\">
							      <div class=\"td\"><center><textarea  id=\"editedshtxt\" cols=\"60\" rows=\"3\">".$editrow[1]."</textarea></center></div>
							    </div>
							    <div class=\"tr\">
							      <div class=\"td\"><center><a href=\"javascript:;\" id=\"editedshsave\" class=\"buttonsilver\">".btlng204."</a></center></div>
							    </div>
						      </div>
				      </div><br>";
		  }

      updateshout();

}

elseif($act == "editsave"){
  
		if(get_user_class() >= UC_MODERATOR){

		  if(!$shtext || !$shid){
		  infoerr(btlng460_1);
		  }
			  mysql_query("UPDATE shoutbox SET text = ".sqlesc($shtext)." WHERE shid = ". sqlesc($shid)) or sqlerr(__FILE__, __LINE__);
		      infok(btlng463);
		      updateshout();
		    die();
		  }
}

elseif($act == "add"){

		  if(!$shtext || strlen($shtext) < 2 || $shtext == "[b][/b]" || $shtext == "[u][/u]" || $shtext == "[i][/i]" || $shtext == "[center][/center]" || $shtext == "[img][/img]" || $shtext == "[url][/url]"){
		  infoerr(btlng460);
		  }else{
		    mysql_query("INSERT INTO shoutbox (userid, date, text) VALUES (".$CURUSER["uid"].", $time, ".sqlesc($shtext).")") or sqlerr(__FILE__, __LINE__);
		      updateshout();
		    apc_store("shoutboxtime",$time);
		  }
}

elseif($act == "del"){

		if($shid && get_user_class() >= UC_MODERATOR){
		    mysql_query("DELETE FROM shoutbox WHERE shid = ". sqlesc($shid)) or sqlerr(__FILE__, __LINE__);
		    
		    if(mysql_affected_rows()){
			infok(btlng461);
			updateshout();
		      }else{
			infoerr(btlng462);
		      }
		}

}



}





?>