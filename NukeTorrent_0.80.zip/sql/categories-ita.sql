TRUNCATE TABLE torrent_categories;
INSERT INTO `torrent_categories` VALUES
(1, 'Filmati', 10, 'film.jpg'),
(2, 'Musica', 20, 'music.jpg'),
(3, 'TV', 30, 'tv3.jpg'),
(4, 'Giochi', 40, 'games.jpg'),
(5, 'Software', 50, 'apps.jpg'),
(6, 'Altro', 1000, 'misc.jpg'),
(7, 'Macintosh', 150, 'macosx.jpg'),
(8, 'Immagini', 80, 'pics.jpg'),
(9, 'Anime', 90, 'anime.jpg'),
(10, 'Ridere', 100, 'comics.jpg'),
(11, 'Libri', 110, 'books2.jpg');