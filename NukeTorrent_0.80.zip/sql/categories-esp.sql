TRUNCATE TABLE torrent_categories;
INSERT INTO `torrent_categories` VALUES
(1, 'Pel�culas', 10, 'film.jpg'),
(2, 'M�sica', 20, 'music.jpg'),
(3, 'TV', 30, 'tv3.jpg'),
(4, 'Juegos', 40, 'games.jpg'),
(5, 'Software para PC', 50, 'apps.jpg'),
(6, 'Otra', 1000, 'misc.jpg'),
(7, 'Software para Mac', 150, 'macosx.jpg'), (8, 'Im�genes', 80, 'pics.jpg'),
(9, 'Anime', 90, 'anime.jpg'),
(10, 'Diversi�n', 100, 'comics.jpg'),
(11, 'Libros', 110, 'books2.jpg');
