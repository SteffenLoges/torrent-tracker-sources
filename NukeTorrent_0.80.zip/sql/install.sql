-- Microsoft Visual Studio .NET Enterprise Architect 2005

-- 
-- Struttura della tabella `torrent_categories`
-- 

CREATE TABLE `torrent_categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `sort_index` int(10) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_check_peers`
-- 

CREATE TABLE `torrent_check_peers` (
  `connectable` char(3) NOT NULL default '',
  `true_ip` varchar(15) NOT NULL default '',
  `ip` varchar(15) NOT NULL default '',
  `port` mediumint(5) NOT NULL default '0',
  `data` datetime NOT NULL default '0000-00-00 00:00:00',
  KEY `data` (`data`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_comments`
-- 

CREATE TABLE `torrent_comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `torrent` int(10) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `ori_text` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `user` (`user`),
  KEY `torrent` (`torrent`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_comments_notify`
-- 

CREATE TABLE `torrent_comments_notify` (
  `torrent` int(11) NOT NULL default '0',
  `user` int(11) NOT NULL default '0',
  `can_send` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`torrent`,`user`),
  KEY `torrent` (`torrent`,`can_send`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_config`
-- 

CREATE TABLE `torrent_config` (
  `onlysearch` enum('true','false') NOT NULL default 'true',
  `max_torrent_size` int(11) unsigned NOT NULL default '0',
  `announce_interval` int(10) unsigned NOT NULL default '0',
  `minvotes` smallint(5) unsigned NOT NULL default '0',
  `time_tracker_update` int(10) unsigned NOT NULL default '0',
  `timeout_repeat_tu` int(10) unsigned NOT NULL default '0',
  `time_check` int(10) unsigned NOT NULL default '0',
  `best_limit` smallint(5) unsigned NOT NULL default '0',
  `down_limit` smallint(5) unsigned NOT NULL default '0',
  `default_limit` smallint(5) unsigned NOT NULL default '0',
  `torrent_global_privacy` enum('true','false') NOT NULL default 'true',
  `down_reg` enum('true','false') NOT NULL default 'true',
  `down_paid` enum('true','false') NOT NULL default 'true',
  `max_num_file` smallint(5) unsigned NOT NULL default '0',
  `max_share_size` bigint(8) unsigned NOT NULL default '0',
  `min_size_seed` mediumint(8) unsigned NOT NULL default '0',
  `min_share_seed` bigint(8) unsigned NOT NULL default '0',
  `extern_check` enum('true','false') NOT NULL default 'true',
  `max_num_file_day_e` smallint(5) unsigned NOT NULL default '0',
  `max_num_file_week_e` smallint(5) unsigned NOT NULL default '0',
  `min_num_seed_e` smallint(5) unsigned NOT NULL default '0',
  `min_size_seed_e` bigint(8) unsigned NOT NULL default '0',
  `maxupload_day_num` smallint(5) unsigned NOT NULL default '0',
  `maxupload_day_share` bigint(8) unsigned NOT NULL default '0',
  `minupload_size_file` int(10) unsigned NOT NULL default '0',
  `announce_urls` text NOT NULL,
  `stealthmode` enum('true','false') NOT NULL default 'true',
  `autoclean_interval` int(10) unsigned NOT NULL default '0',
  `maximagesize` int(10) unsigned NOT NULL default '0',
  `signup_timeout` int(10) unsigned NOT NULL default '0',
  `max_dead_torrent_time` int(10) unsigned NOT NULL default '0',
  `src_url` enum('disabled','torrent','url','force') NOT NULL default 'disabled',
  `version` varchar(5) NOT NULL default ''
) TYPE=MyISAM COMMENT='torrent_config';

-- 
-- Dump dei dati per la tabella `torrent_config`
-- 

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_download`
-- 

CREATE TABLE `torrent_download` (
  `chi` int(11) NOT NULL default '0',
  `quando` date NOT NULL default '0000-00-00',
  `cosa` int(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`chi`,`cosa`),
  KEY `chi` (`chi`),
  KEY `chi_2` (`chi`,`quando`),
  KEY `ip` (`ip`),
  KEY `ip_2` (`ip`,`quando`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_file_privacy`
-- 

CREATE TABLE `torrent_file_privacy` (
  `from` int(11) NOT NULL default '0',
  `to` int(11) NOT NULL default '0',
  `file` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`from`,`to`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_files`
-- 

CREATE TABLE `torrent_files` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `size` bigint(20) unsigned NOT NULL default '0',
  `ed2k` varchar(250) NOT NULL default '',
  `magnet` varchar(250) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `torrent` (`torrent`)
) TYPE=MyISAM AUTO_INCREMENT=63990 ;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_filter`
-- 

CREATE TABLE `torrent_filter` (
  `keyword` varchar(20) NOT NULL default '',
  `reason` varchar(250) NOT NULL default '',
  PRIMARY KEY  (`keyword`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_global_privacy`
-- 

CREATE TABLE `torrent_global_privacy` (
  `from` int(11) NOT NULL default '0',
  `to` int(11) NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`from`,`to`,`status`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_hits`
-- 

CREATE TABLE `torrent_hits` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `page` varchar(20) NOT NULL default '',
  `period` datetime NOT NULL default '0000-00-00 00:00:00',
  `count` bigint(20) unsigned NOT NULL default '0',
  `runs` bigint(20) unsigned NOT NULL default '0',
  `runtime` double NOT NULL default '0',
  `user_cpu` double NOT NULL default '0',
  `sys_cpu` double NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `hit` (`period`,`page`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_legalizeit`
-- 

CREATE TABLE `torrent_legalizeit` (
  `id_user` int(11) NOT NULL default '0',
  `data_iscrizione` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id_user`),
  KEY `data_iscrizione` (`data_iscrizione`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_peers`
-- 

CREATE TABLE `torrent_peers` (
  `torrent` int(10) unsigned NOT NULL default '0',
  `peer_id` char(20) binary NOT NULL default '',
  `ip` char(15) NOT NULL default '',
  `port` smallint(5) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `to_go` bigint(20) unsigned NOT NULL default '0',
  `seeder` enum('yes','no') NOT NULL default 'no',
  `started` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL default 'yes',
  `download_speed` int(11) NOT NULL default '0',
  `upload_speed` int(11) NOT NULL default '0',
  PRIMARY KEY  (`torrent`,`peer_id`),
  KEY `torrent` (`torrent`),
  KEY `last_action` (`last_action`),
  KEY `seeder` (`seeder`,`torrent`),
  KEY `connectable` (`torrent`,`connectable`)
) TYPE=HEAP;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_ratings`
-- 

CREATE TABLE `torrent_ratings` (
  `torrent` int(10) unsigned NOT NULL default '0',
  `user` int(10) unsigned NOT NULL default '0',
  `rating` tinyint(3) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`torrent`,`user`),
  KEY `user` (`user`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_seeder_notify`
-- 

CREATE TABLE `torrent_seeder_notify` (
  `torrent` int(11) NOT NULL default '0',
  `user` int(11) NOT NULL default '0',
  `day` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`torrent`,`user`),
  KEY `torrent` (`torrent`,`day`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_torrents`
-- 

CREATE TABLE `torrent_torrents` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `info_hash` varchar(20) binary NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `save_as` varchar(255) NOT NULL default '',
  `src_url` varchar(250) default NULL,
  `search_text` text NOT NULL,
  `descr` text NOT NULL,
  `ori_descr` text NOT NULL,
  `category` int(10) unsigned NOT NULL default '0',
  `size` bigint(20) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` enum('single','multi','link') NOT NULL default 'single',
  `numfiles` int(10) unsigned NOT NULL default '0',
  `views` int(10) unsigned NOT NULL default '0',
  `hits` int(10) unsigned NOT NULL default '0',
  `times_completed` int(10) unsigned NOT NULL default '0',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `visible` enum('yes','no') NOT NULL default 'yes',
  `owner` int(10) unsigned NOT NULL default '0',
  `numratings` int(10) unsigned NOT NULL default '0',
  `ratingsum` int(10) unsigned NOT NULL default '0',
  `seeders` int(10) unsigned NOT NULL default '0',
  `leechers` int(10) unsigned NOT NULL default '0',
  `tot_peer` int(11) NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `banned` enum('yes','no') NOT NULL default 'no',
  `evidence` tinyint(1) NOT NULL default '0',
  `ownertype` tinyint(1) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  `speed` int(10) unsigned NOT NULL default '0',
  `tracker` varchar(250) default NULL,
  `tracker_update` datetime default NULL,
  `ed2k` varchar(250) NOT NULL default '',
  `magnet` varchar(250) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `info_hash` (`info_hash`),
  KEY `owner` (`owner`),
  KEY `visible` (`visible`),
  KEY `category_visible` (`category`,`visible`),
  KEY `added` (`added`),
  KEY `seeders` (`seeders`),
  KEY `leechers` (`leechers`),
  KEY `tot_peer` (`tot_peer`,`seeders`,`leechers`),
  KEY `visible_2` (`last_action`,`tot_peer`,`visible`),
  KEY `owner_2` (`owner`,`seeders`,`size`),
  KEY `tracker_update` (`last_action`,`tracker_update`),
  KEY `visible_index` (`visible`,`ed2k`(2),`magnet`(2),`type`),
  FULLTEXT KEY `ft_search` (`search_text`,`ori_descr`),
  FULLTEXT KEY `filename` (`filename`)
) TYPE=MyISAM AUTO_INCREMENT=5151 ;

-- --------------------------------------------------------

-- 
-- Struttura della tabella `torrent_trackers`
-- 

CREATE TABLE `torrent_trackers` (
  `id` tinyint(5) unsigned NOT NULL auto_increment,
  `url` varchar(120) NOT NULL default '',
  `update` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `url` (`url`),
  KEY `update` (`update`)
) TYPE=MyISAM AUTO_INCREMENT=255 ;

INSERT INTO `torrent_config` VALUES ('false', 1000000, 1800, 1, 180, 60, 1800, 10, 10, 10, 'true', 'true', 'true', 0, 0, 0, 0, 'true', 0, 0, 0, 524268000, 100, 10737008640, 524288, '', 'true', 600, 30, 259200, 21600, 'disabled', '0.80');

        
INSERT INTO `torrent_categories` VALUES
(1, 'Movies', 10, 'film.jpg'),
(2, 'Music', 20, 'music.jpg'),
(3, 'TV', 30, 'tv3.jpg'),
(4, 'Games', 40, 'games.jpg'),
(5, 'PC Software', 50, 'apps.jpg'),
(6, 'Other', 1000, 'misc.jpg'),
(7, 'Mac Software', 150, 'macosx.jpg'),
(8, 'Pictures', 80, 'pics.jpg'),
(9, 'Anime', 90, 'anime.jpg'),
(10, 'Fun', 100, 'comics.jpg'),
(11, 'Books', 110, 'books2.jpg');