<?php



$urlin = array(

"'(?<!/)modules.php\?name=Bittorrent&amp;page=([0-9]*)'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=details&amp;id=([0-9]*)&amp;hit=1'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=details&amp;id=([0-9]*)&amp;spytorrent=1#peers'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=mytorrents'",

"'(?<!/)modules.php\?name=Bittorrent(?!&)'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=download&amp;id=([0-9]*)'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=index_help'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=rulez'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=connection_help'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=upload_help'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=tutorial'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=details_help'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=upload'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=addcomment&amp;id=([0-9]*)'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=takecomment'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=takeupload'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=takeuploadurl'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=details&amp;id=([0-9]*)&amp;viewcomm=([0-9]*)'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=index&amp;op=search'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=grab'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=edit&amp;id=([0-9]*)'",

"'(?<!/)modules.php\?name=Bittorrent&amp;file=details&amp;id=([0-9]*)&amp;uploaded=1'",

"'(?<!/)modules.php\?name=Forums'"

);



$urlout = array(

"torrentpage\\1.html",

"torrent\\1.html",

"spytorrent\\1.html#peers",

"mytorrents.html",

"Bittorrent.html",

"btdownload\\1.html",

"bthelp.html",

"btrulez.html",

"btconnhelp.html",

"btuphelp.html",

"bttutorial.html",

"btdethelp.html",

"btupload.html",

"btaddcomment\\1.html",

"bttakecomment.html",

"bttakeupload.html",

"bttakeuploadurl.html",

"btcomment\\1-\\2.html",

"btsearch.html",

"btgrab.html",

"btedit\\1.html",

"btuploaded-\\1.html",

"forums.html"

);

?>