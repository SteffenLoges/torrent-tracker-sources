<?

$index = 0;
global $module_name, $name, $dbi;

$module_name = $name;

if (!eregi("modules.php", $PHP_SELF)) {
    die ("You can't access this file directly...");
}

require_once("include/benc.php");
require_once("include/bittorrent.php");

loggedinorreturn();

ini_set("upload_max_filesize",$max_torrent_size);

include("config.php");
include("header.php");
OpenTable();

if(!is_admin($admin))die("ADMIN Only");

set_time_limit(60*5);

//Falsifica l'agente del browser :D
ini_set('user_agent','Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)');
ini_set('referer_check', $url);

function fget_proxy($urltorrent)
{
global $url;
// $PROXY_URL="proxy.yourisp.org";
// $PROXY_PORT=8080;

// putenv("http_proxy=$PROXY_URL:$PROXY_PORT");
 $result = shell_exec("wget --user-agent='Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)' --timeout=10 -q -O - '$urltorrent' --referer='$url'");

 return $result;
}


                function dict_check($d, $s){
                        if ($d["type"] != "dictionary")
                                bark("not a dictionary");
                        $a = explode(":", $s);
                        $dd = $d["value"];
                        $ret = array();
                        foreach ($a as $k) {
                                unset($t);
                                if (preg_match('/^(.*)\((.*)\)$/', $k, $m)) {
                                        $k = $m[1];
                                        $t = $m[2];
                                }
                                if (!isset($dd[$k]))
                                        bark("dictionary is missing key(s)");
                                if (isset($t)) {
                                        if ($dd[$k]["type"] != $t)
                                                bark("invalid entry in dictionary");
                                        $ret[] = $dd[$k]["value"];
                                }
                                else
                                        $ret[] = $dd[$k];
                        }
                        return $ret;
                }

                function dict_get($d, $k, $t) {
                        if ($d["type"] != "dictionary")
                                bark("not a dictionary");
                        $dd = $d["value"];
                        if (!isset($dd[$k]))
                                return;
                        $v = $dd[$k];
                        if ($v["type"] != $t)
                                bark("invalid dictionary entry type");
                        return $v["value"];
                }

                function print_parse(&$parse_array_read){
                        foreach ($parse_array_read as $key => $val){
                                echo "[$key => ";
                                if (is_array ($val)){
                                        echo "<BLOCKQUOTE dir=ltr style='MARGIN-RIGHT: 0px'><P>";
                                        print_parse($val);
                                        echo "</P></BLOCKQUOTE>";
                                }else{
                                        echo $val;
                                }
                                echo "]";
                        }
                }
                // Convert 5 Bytes to 8 Bytes Base32
                function _Sha1toBase32($in){
                        $Table = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

                        $out = substr($Table, ((ord(substr($in, 0, 1)) >> 3)               ) & 0x1F, 1);
                        $out .= substr($Table, ((ord(substr($in, 0, 1)) << 2) | (ord(substr($in, 1, 1)) >> 6)) & 0x1F, 1);
                        $out .= substr($Table, ((ord(substr($in, 1, 1)) >> 1)               ) & 0x1F, 1);

                        $a = (ord(substr($in, 1, 1)) << 4) & 0x00FF;
                        $b = ((ord(substr($in, 2, 1))) >> 4)&0x00FF;
                        $out .= substr($Table, ( $a | $b )&0x1F, 1);

                        $a = ( (ord(substr($in, 2, 1))&0x00FF) << 1) &0x00FF;
                        $b = ((ord(substr($in, 3, 1)) >> 7)) &0x00FF;


                        $out .= substr($Table, ( $a | $b )&0x1F, 1);
                        $out .= substr($Table, ((ord(substr($in, 3, 1)) >> 2)               ) & 0x1F, 1);

                        $a = (ord(substr($in, 3, 1)) << 3) & 0x00FF;
                        $b = ((ord(substr($in, 4, 1)) >> 5)) &0x00FF;
                        $out .= substr($Table, ( $a|$b ) & 0x1F, 1);

                        $out .= substr($Table, ((ord(substr($in, 4, 1))     )               ) & 0x1F, 1);
                        return $out;
                }

                // Return a base32 representation of a sha1 hash
                function Sha1toBase32($Sha1){
                        //Magnetic link
                        $ret="";

                        $Base32 = _Sha1toBase32(substr($Sha1, 0, 5));
                        $Base32 .= _Sha1toBase32(substr($Sha1, 5, 5));
                        $Base32 .= _Sha1toBase32(substr($Sha1, 10, 5));
                        $Base32 .= _Sha1toBase32(substr($Sha1, 15, 5));

                        $ret = $Base32;
                        return $ret;
                }

                function strtohex($strtmp){
                        //Emule
                        $max = strlen($strtmp);
                        $hex = "";
                        for($i=0; $i<$max;$i++){
                                $hex .= dechex(ord(substr($strtmp, $i, 1)));
                        }
                        return strtoupper($hex);
                }


function bark($msg) {
//        genbark($msg, "Upload failed!");
        echo $msg;
}

global $url;

if($url==""){
        echo "<form method=post action='modules.php?name=$name&file=grab' enctype='multipart/form-data'>
                Url = <input type=text name=url><br>
                Tipo =
        ";

        $sql = "SELECT id, name FROM `torrent_categories` ORDER BY `name` ASC";
        $res = $db->sql_query($sql);
        echo "<select name=category>";
        while($dat = $db->sql_fetchrow($res)){
                echo "<option value='".$dat[id]."'>".$dat[name]."</option>";
        }
        echo "</select>";
        echo "description <input type=text name=description>";
        echo "<input type=submit></form>";
}else{

        if(substr($url, 0, 7)!="http://") die("Url non comincia per http://");

        $fp = fopen($url, "r");
        if(!$fp)die("Connessione alla pagina non riuscita");

        $line = "";
        while(!feof($fp)) {
                $line .= fgets($fp,60000);
        }

        fclose($fp);
        //tot = strlen($line);

        $category = intval($category);

        unset($torrent_servers);
        $takefrom = "torrent_servers[";
        $takefromlen = strlen($takefrom);
        $posts = strpos($line, $takefrom, $posts);
/*
                $posendts = strpos($line, "]", $posts);
        echo "posendts*$posendts*";
                if( $posendts === false ) die("Trovato false in posapice");
                $num = substr($line, $posts+$takefromlen, $posendts-$posts-$takefromlen);

        echo "num=*".$num."*";

                $posapice = strpos($line, "'", $posendts);
                if( $posapice === false ) die("Trovato false in posapice");
        echo "posapice=*".$posapice."*";

                $posapicfine = strpos($line, "'", $posapice+1);
                if( $posapicfine === false ) die("Trovato false in posapice");
        echo "posapicfine=*".$posapicfine."*";

                $torrent_servers[$num] = substr($line, $posapice+1, $posapicfine-$posapice-1);

        echo "torrent_servers[$num]=*".$torrent_servers[$num]."*";

        die();
*/

if($passo=="")$passo=5;

        $i=0;
        while(! ($posts === false) ){
                $i++;

                $posendts = strpos($line, "]", $posts);
                if( $posendts === false ) die("Trovato false in posapice");
                $num = substr($line, $posts+$takefromlen, $posendts-$posts-$takefromlen);

                $posapice = strpos($line, "'", $posendts);
                if( $posapice === false ) die("Trovato false in posapice");

                $posapicfine = strpos($line, "'", $posapice+1);
                if( $posapicfine === false ) die("Trovato false in posapice");

                $torrent_servers[$num] = substr($line, $posapice+1, $posapicfine-$posapice-1);
                $posts = strpos($line, $takefrom, $posts+1);

                if($i==100)die("stop5");
        }


        $takefrom = "at2(";
        $takefromlen = strlen($takefrom);
        $posts = strpos($line, $takefrom, $posts);
        $i=0;
        unset($textgetparam);
        while(! ($posts === false) ){

                $posendts = strpos($line, ");", $posts);
                if( $posendts === false ) die("Trovato false in posapice");
                $textget = substr($line, $posts+$takefromlen, $posendts-$posts-$takefromlen);

                $textgetparam[] = explode(",", str_replace("'", "", $textget ) );

                $posts = strpos($line, $takefrom, $posts+1);

        echo "<p>$i";
        echo "NOME*".$textgetparam["$i"][6]."*<br>";
        echo "DESCRIZIONE*".$textgetparam[$i][5]."*<br>";

        echo "SERVER*".$textgetparam[$i][2]."*<br>";
        echo "SERVER[]*".$torrent_servers[ $textgetparam[$i][2] ]."*<br>";
        echo "PATH*".$textgetparam[$i][7]."*<br>";
        echo "URL*". $torrent_servers[ $textgetparam[$i][2] ] ."/torrents/". $textgetparam[$i][7]."*<br>";
        echo "</p>";

                $i++;

//                if($i==50) break;

        }

        $numtorrenttot = $i;

//        print_r($torrent_servers);

        $maxelem = $i;
        global $start;
        if($start=="")$start=0;
        for($numelem=$start; $numelem<$start + $passo; $numelem++){

                if($numelem>$numtorrenttot)die("Finiti tutti");


                echo "<h4>$numelem</h4><p>";
                $descr = unesc($textgetparam[$numelem][6]." ".$textgetparam[$numelem][5]." ".$description);

/*
                foreach(explode(":","descr:type:namex") as $v) {
                        if (!isset($_POST[$v]))
                                bark("missing form data");
                }

                if (!isset($_FILES["filex"]))
                        bark("missing form data");
*/
//                $f = $_FILES["filex"];
/*
                $url = $torrent_servers[ $textgetparam[$numelem][2] ] ."/torrents/". $textgetparam[$numelem][7];
                $f = fopen($url, "r");
                if(!$fp)die("Connessione alla pagina non riuscita");

                $line = "";
                while(!feof($fp)) {
                        $line .= fgets($fp,60000);
                }
*/
                echo "*".$textgetparam["$numelem"][7]."*";
                echo "*".strrpos($textgetparam["$numelem"][7], "/")."*";

                $fname = substr($textgetparam["$numelem"][7], strrpos($textgetparam["$numelem"][7], "/")+1 );

                if (empty($fname)){
                        bark("Empty filename!");
                        continue;
                }
                if (!validfilename($fname)){
                        bark("Invalid filename!");
                        continue;
                }
                if (!preg_match('/^(.+)\.torrent$/si', $fname, $matches)){
                        bark("Invalid filename (not a .torrent).");
                        continue;
                }

                $shortfname = $torrent = $matches[1];
                if (!empty($textgetparam["$numelem"][6])){
                        $torrent = $textgetparam["$numelem"][6];
                }

                $tmpname = "http://" . str_replace("//", "/", substr($torrent_servers[ $textgetparam[$numelem][2] ], 7) ."/torrents/". $textgetparam[$numelem][7] );

//                $tmpname = "http://rktest.altervista.org/pippo.php";

$pagetorrent = "";
echo "Server*".$textgetparam[$numelem][2] ."*";
$prima = time();
echo "Tempo iniziale*".$prima."*";
$pagetorrent = fget_proxy($tmpname);

echo "Tempo finale*".time()."*";
echo "Differenza*".(time()-$prima)."*";
/*
                $fp = fopen($tmpname, "r");
                $page = "";
                if ($fp){
                        socket_set_timeout($fp, 10);
                        while(!feof($fp)) {
                                $page .= fgets($fp,60000);
                        }

                        fclose($fp);
                }else{
                        echo("errore file $tmpname");
                        continue;
                }
*/
//                echo strip_tags(str_replace("%", "�/.", str_replace("\$", "S", str_replace("\"", " ", $page))) );

//                echo $page;



                if(strlen($pagetorrent)==0){
                        echo "Vuoto";
                        continue;
                }


                $parse_array_torrent = array();
                $i=0;
                $max=strlen($pagetorrent);
                $parse_array_torrent = ergo($pagetorrent, $parse_array_torrent, $i, $max);

                $magnet_link = "";
                $ed2k_link = "";
                $sql_insert_field = "";
                $sql_insert_value = "";
                if($parse_array_torrent["0"]["info"]["sha1"]){
                        $magnet_link = "magnet:?xt=urn:sha1:".addslashes(Sha1toBase32($parse_array_torrent["0"]["info"]["sha1"]))."&dn=".urlencode($parse_array_torrent["0"]["info"]["name"]);
                        $sql_insert_field .= ", magnet";
                        $sql_insert_value .= ", '$magnet_link'";
                }
                if($parse_array_torrent["0"]["info"]["ed2k"]){
                        $ed2k_link = "ed2k://|file|".urlencode($parse_array_torrent["0"]["info"]["name"])."|".urlencode($parse_array_torrent["0"]["info"]["length"])."|".strtohex($parse_array_torrent["0"]["info"]["ed2k"])."|/";
                        $sql_insert_field .= ", ed2k";
                        $sql_insert_value .= ", '$ed2k_link'";
                }

                if (strlen($pagetorrent>$max_torrent_size)){
                        bark("What the hell did you upload? This is not a bencoded file!");
                        continue;
                }
                $dict = bdec($pagetorrent);

                list($ann, $info) = dict_check($dict, "announce(string):info");
                list($dname, $plen, $pieces) = dict_check($info, "name(string):piece length(integer):pieces(string)");

                if (!in_array($ann, $announce_urls, 1))
                        if (!$stealthmode){
                                bark("invalid announce url! must be <b>" . $announce_urls[0] . "</b>. Il tracker che hai specificato � -&gt;".$ann."&lt;- verifica che non ci siano spazi tra l'indirizzo del tracker e le parentesi angolari (maggiore e minore)");
                                continue;
                        }else{
                                $tracker = $ann;
                        }

                if($ann=="http://www.raulken.it/home/modules/Bittorrent/announce.php"){
                        echo("Il nostro tracker � stato disabilitato, <a href='modules.php?name=$name&file=upload_help'>leggi la guida</a> per sapere come poter inserire torrent con tracker esterni");
                        continue;
                }

                if (strlen($pieces) % 20 != 0){
                        bark("invalid pieces");
                        continue;
                }

                $filelist = array();
                $totallen = dict_get($info, "length", "integer");
                if (isset($totallen)) {
                        $filelist[] = array($dname, $totallen);
                        $type = "single";
                }
                else {
                        $flist = dict_get($info, "files", "list");
                        if (!isset($flist)){
                                bark("missing both length and files");
                                continue;
                        }
                        if (!count($flist)){
                                bark("no files");
                                continue;
                        }
                        $totallen = 0;
                        foreach ($flist as $fn) {
                                list($ll, $ff) = dict_check($fn, "length(integer):path(list)");
                                $totallen += $ll;
                                $ffa = array();
                                foreach ($ff as $ffe) {
                                        if ($ffe["type"] != "string"){
                                                bark("filename error");
                                                continue;
                                        }
                                $ffa[] = $ffe["value"];
                                }
                                if (!count($ffa)){
                                        bark("filename error");
                                        continue;
                                }
                                $ffe = implode("/", $ffa);
                                $filelist[] = array($ffe, $ll);
                        }
                        $type = "multi";
                }

                $infohash = pack("H*", sha1($info["string"]));

                //Raulken
                //$maxupload_day_num = 2; //Number of max upload a day
                //$maxupload_day_share = 3 * 1024 *1048576; //Max share size to upload a day
                //$minupload_size_file = 100 * 1048576; //Min size of

                $sql = "SELECT  count(size) as num, sum(size) as tot_size FROM `torrent_torrents` where `added` > sysdate() - 1000000 AND owner = '".$CURUSER["id"]."'";

                $res = mysql_query($sql, $dbi);
                $row = mysql_fetch_array($res);

                if ($CURUSER["admin"] != "yes" && $minupload_size_file>=$totallen){
                        echo "<p>Non � possibile fare condividere un file pi� piccolo di <b>".mksize($minupload_size_file)."</b></p><p>Il torrent che hai inviato riguardava un file grande <b>".mksize($totallen)."</b>.";
                        continue;
                }

                //Max # num upload on 24h
                if ($CURUSER["admin"] != "yes" && $maxupload_day_num>0 && $maxupload_day_num<=$row["num"]){
                        echo "Non � possibile fare l'upload pi� di $maxupload_day_num ogni 24 ore.";
                        continue;
                }

                //Max size share upload on 24h
                if ($CURUSER["admin"] != "yes" && $maxupload_day_share>0 && $maxupload_day_share<$row["tot_size"]+$totallen){
                        echo "<p>Non � possibile fare l'upload di una quantit� di file superiore a <b>$maxupload_day_share</b> in 24 ore.</p><p>Al momento hai gi� fatto l'upload di <b>".$row["num"]."</b> file per un totale di <b>".mksize($row["tot_size"])."</b>";
                        continue;
                }

                        //Filtro costruzione dal nome file lungo almeno 4 caratteri
                        $materia=trim($fname);
                        $pos = strrpos($materia, '.');
                        if (!$pos===false)
                                $materia = substr($materia, 0, $pos);
                        $search = array (
                                                         "'[^a-zA-Z]'",                 // Remove not lecter
                                                         "'([\r\n])[\s]+'"                 // Remove Blank space
                        );
                        $replace = array (
                                                          " ",
                                                          "\\1"
                        );
                        $materia = preg_replace ($search, $replace, $materia);
                        $materia=explode(" ", $materia);

                        $sql_filter = "";
                        foreach($materia as $x){
                                $x = trim($x);
                                if(strlen($x)>=3){
                                                $sql_filter .= " OR keyword LIKE '".mysql_real_escape_string($x)."'";
                                }
                        }
                        $sql_filter = "SELECT * FROM torrent_filter WHERE 1=0 ".$sql_filter;
                        $res = mysql_query($sql_filter, $dbi);
                        if ($row = mysql_fetch_array($res)){
                                Echo "E' stata effettuata una ricerca utilizzando le parole del nome del file, il sistema considera che le seguenti parole potrebbero essere oggetto di attivit� illegali:<ol>";
                                do{
                                        echo "<li><b>".$row[keyword]."</b> ".$row[reason];
                                }while ($row = mysql_fetch_array($res));
                                echo "</ol><p>Siamo consapevoli del fatto che il file potrebbe essere del tutto legale, ci scusiamo dell'inconveniente e la invitiamo a rinominare il file utilizzando altre parole. Questo sistema � un filtro per vietare lo scambio di file ritenuto teoricamente illegale, in quanto per legge sulla provacy non possiamo verificarne il contenuto, ed � solo un'ipotesi.</p>";
                                continue;
                        }

                        //Fine filtro


                global $jump_check;
                if ($jump_check){
                        $materia=trim($fname);

                        $pos = strrpos($materia, '.');
                        if (!$pos===false)
                                $materia = substr($materia, 0, $pos);

                        $search = array (
                                                         "'[^a-zA-Z]'",                 // Remove not lecter
                                                         "'([\r\n])[\s]+'"                 // Remove Blank space
                        );

                        $replace = array (
                                                          " ",
                                                          "\\1"
                        );

                        $materia = preg_replace ($search, $replace, $materia);
                        $materia=explode(" ", $materia);

                        $sql = "";
                        $sql_filter = "";
                        foreach($materia as $x){
                                        $x = trim($x);
                                        if(strlen($x)>=5){
                                                        $sql .= " OR filename LIKE '%".mysql_real_escape_string($x)."%'";
                                        }
                        }

                        foreach ($filelist as $filet) {
                                        $sql .= " OR size=".sqlesc($filet[1]);
                        }

                        $sql = "SELECT torrent, filename, size FROM torrent_files WHERE 1=0 ".$sql;
                        $res = mysql_query($sql, $dbi);
                        if ($row = mysql_fetch_array($res)){
                                Echo "E' stata effettuata una ricerca utilizzando le parole del nome del file e la dimensione, il sistema considera che i seguenti file potrebbero essere fonti uguali gi� presenti:<ol>";
                                do{
                                        echo "<li><a href='modules.php?name=$name&file=details&id=".$row["torrent"]."&hit=1'>".$row["filename"]."</a> (".mksize($row["size"]).")";
                                }while ($row = mysql_fetch_array($res));
                                echo "<p>Se il tuo file corrisponde ad uno di questi ti preghiamo di lanciare un .torrent gi� esistente, grazie!</p>";
                                continue;
                        }
                }
                //Raulken


                $ip = substr( $torrent_servers[ $textgetparam[$numelem][2] ], 7) ;
                if (strpos($ip, "/")>0) $ip = substr( $ip, 0, strpos($ip, "/") ) ;

                if ($evidence!=1) $evidence =0;

                $owner = 0;
                $ownertype = 2;






                if ($tracker!=""){

                        $tmp_tracker=str_replace("announce", "scrape", $tracker)."?info_hash=".urlencode($infohash);

                        $use_std_tracker = false;
                        $parse_array = array();
                        $i=0;

                        $fp = @fopen($tmp_tracker, "rb");
                        if ($fp){
                                socket_set_timeout($fp, 10);
                                $page=fread($fp, 1000000);

                                $status = socket_get_status($fp);
                                if ($status['timed_out']) {
                                    die("ERRORE: Socket timed out\n");
                                }


                                fclose($fp);
                                $max=strlen($page);
                                $parse_array = ergo($page, $parse_array, $i, $max);

                                //Check data
                                if ( !is_array($parse_array["0"]["files"][ "$infohash" ])  )
                                        $use_std_tracker = true;
                                else{
                                        //check seeder
                                        if ($parse_array["0"]["files"][ "$infohash" ]["complete"]<=0){
                                                echo("Il tracker esterno ha risposto confermando la presenza del file ma con nessuna fonte completa. Ti ricordiamo che il file deve essere gi� presente sull'altro tracker con almeno un seeder per essere inserito sul nostro sito.");
                                                continue;
                                        }

                                        $sql = "INSERT INTO torrent_torrents (search_text, filename, owner, visible, info_hash, name, size, numfiles, `type`, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip, seeders, leechers, tot_peer, times_completed, tracker, tracker_update $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $owner, "yes", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, 0 + $category, $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip', ".sqlesc($parse_array["0"]["files"][ "$infohash" ]["complete"]).", ".intval($parse_array["0"]["files"][ "$infohash" ]["incomplete"]).", ".intval($parse_array["0"]["files"][ "$infohash" ]["complete"]+$parse_array["0"]["files"][ "$infohash" ]["incomplete"]).",".intval($parse_array["0"]["files"][ "$infohash" ]["downloaded"]).", '$tmp_tracker', SYSDATE() $sql_insert_value)";

                                }
                        }else{
                                $use_std_tracker = true;
                        }

                        //Strandard Tracker
                        if ($use_std_tracker){
                                $add_tracker = "&peer_id=%00%00%00%00%00Azureus9%09%40d%BE%3D%C1%8B&port=666&uploaded=0&downloaded=0&left=1&num_peers=10000";
                                $tracker.="?info_hash=".urlencode($infohash).$add_tracker;
                                $fp = @fopen($tracker, "rb");
                                if (!$fp) {
                                        echo("Il tracker esterno specificato non risponde, -&gt;".$ann."&lt;- verifica che non ci siano spazi tra l'indirizzo del tracker e le parentesi angolari (maggiore e minore). Se hai provato ad usare il nostro tracker hai sicuramente o sbagliato a scriverlo oppure hai inserito qualche spazio.");
                                        continue;
                                }
                                socket_set_timeout($fp, 10);
                                $page=fread($fp, 1000000);

                                $status = socket_get_status($fp);
                                if ($status['timed_out']) {
                                    echo("ERRORE: Socket timed out\n");
                                    continue;
                                }

                                fclose($fp);

                                $peers = substr_count($page, "peer id");

                                if ($peers<=0){
                                        $max=strlen($page);
                                        $parse_array = ergo($page, $parse_array, $i, $max);

                                        if (!is_array($parse_array["0"]["peers"])){
                                                echo("Il tracker esterno ha risposto con dei dati non corretti. Potresti aver scritto male il nome del tracker, -&gt;".$ann."&lt;- verifica che non ci siano spazi tra l'indirizzo del tracker e le parentesi angolari (maggiore e minore). Altrimenti potrebbero esserci problemi sul tracker esterno, ti invitiamo a riprovare pi� tardi.");
                                                continue;
                                        }else{
                                                echo("Il tracker esterno ha risposto indicando nessuna fonte presente, ti ricordiamo che il file deve essere gi� presente e con almeno un seeder per essere inserito sul nostro sito. Questo problema pu� anche essere dovuto ad errato nome del tracker -&gt;".$ann."&lt;- verifica che non ci siano spazi tra l'indirizzo del tracker e le parentesi angolari (maggiore e minore) oppure il file � stato rimosso dal tracker originale.");
                                                continue;
                                        }
                                }

                                $sql = "INSERT INTO torrent_torrents (search_text, filename, owner, visible, info_hash, name, size, numfiles, `type`, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip, leechers, tot_peer, tracker, tracker_update $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $owner, "yes", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, 0 + $category, $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip', '$peers', '$peers', '$tmp_tracker', SYSDATE() $sql_insert_value)";
                        }
                }else{
                        $sql = "INSERT INTO torrent_torrents (search_text, filename, owner, visible, info_hash, name, size, numfiles, `type`, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $owner, "no", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, $category, $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip' $sql_insert_value)";
                }



                echo "sql$sql";


                $ret = mysql_query($sql, $dbi);
                if (!$ret) {
                        if (mysql_errno() == 1062){
                                bark("torrent already uploaded!");
                                continue;
                        }
                        bark("mysql puked: ".mysql_error(). "SQL=$sql");
                        die();
                }
                $id = mysql_insert_id();

                mysql_query("DELETE FROM torrent_files WHERE torrent = '$id'", $dbi) or die(mysql_error());
                $i=0;
                foreach ($filelist as $filet) {
                        $ins_camp = "";
                        $ins_val = ""        ;
                        if ($sha1=$parse_array_torrent["0"]["info"]["files"]["$i"]["sha1"]){
                                $ins_camp .= ", magnet";
                                $ins_val .= ", 'magnet:?xt=urn:sha1:".addslashes(Sha1toBase32($sha1))."&dn=".urlencode($filet[0])."'";
                        }
                        if ($ed2k=$parse_array_torrent["0"]["info"]["files"]["$i"]["ed2k"]){
                                $ins_camp .= ", ed2k";
                                $ins_val .= ", 'ed2k://|file|".urlencode($filet[0])."|".urlencode($filet[1])."|".strtohex($ed2k)."|/'";
                        }

                        $sql = "INSERT INTO torrent_files (torrent, filename, size $ins_camp) VALUES ('$id', ".sqlesc($filet[0]).", '".$filet[1]."' $ins_val)";
                //        echo $sql;
                        mysql_query($sql, $dbi) or die(mysql_error()." SQL: ".$sql);
                        echo "FILE $i = *$sql*";
                        $i++;
                }

                //print_parse($parse_array_torrent);

//                copy($tmpname, "$torrent_dir/$id.torrent");

                $fp = fopen("$torrent_dir/$id.torrent", "wb");
                if ($fp){
                        fwrite($fp, $pagetorrent);
                        fclose($fp);
                        echo "torrent file *$torrent_dir/$id.torrent* creato";
                }else{
                        echo("errore creazione torrent $id");
                        continue;
                }

        }

echo "<meta http-equiv=\"refresh\" content=\"5;url=modules.php?name=$name&file=$file&start=".($start+$passo)."&category=$category&description=".urlencode($description)."&url=".urlencode($url)."\">";
echo "Upgrade effettuato correttamente, tra 5 secondi verrai ridiretto e continuer� il grabbing :D";

}



CloseTable();
include("footer.php");
?>