<?php
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
global $name;


//ERRORI SQL
define("_btsqlerror1","Error executing SQL Query ");
define("_btsqlerror2","Error ID: ");
define("_btsqlerror","Error Message: ");

//TESTI CHE COMPAIONO IN INCLUDE/BITTORRENT.PHP
define("_btindex","Home Torrent");
define("_btupload","Upload Torrent");
define("_btlogin","Login");
define("_btsignup","Register");
define("_btpersonal","Torrent by ");
define("_btrulez","Rules");
define("_btforums","Forum");
define("_bthelp","Help");
define("_btadvinst","Install Bit Torrent or Shareaza to download");
define("_btaccessden","Access Denied. Download requires <A href=\"modules.php?name=Your_Account&op=new_user\">registration</a>");
define("_btlegenda","Features Help and Legend");
define("_btyourfilext","Your file, external tracker");
define("_btexternal","External Tracker");
define("_btyourfile","Your File");
define("_btsticky","Evidence");
define("_btauthforreq","Authorization to request");
define("_btauthreq","Authorization Request");
define("_btdown","Download");
define("_btunknown","Unknonw");
define("_btrefresh","Update");
define("_btvisible","Visible");

//TESTI CHE COMPAIONO IN INDEX.PHP
define("_btstart","<h2>Welcome to BIT TORRENT</h2>
<p>Please keep your Bit Torrent window open as longest as possible after downloading! This will speed up all downloads.</p>
<p>Beginners <a href='modules.php?name=$name&file=index_help'>read this help</a></p>
<p>In order to increase your download speed, try to use <b>ACTIVE</b> mode, <a href='modules.php?name=$name&file=connection_help'>reading this help</a>. Suggested to everyone!</p>
<p>We released a <a href='modules.php?name=$name&file=tutorial'>Bit Torrent tutorial</a>, focusing on Azureus client, full of powerful features</p>");
define("_btsearch","<img src='modules/$name/pic/icon_mini_search.gif' align=midle> Search");
define("_btin","in");
define("_btalltypes","any");
define("_btactivetorrents","Active Torrents");
define("_btitm","include dead Torrents");
define("_btstm","only dead Torrents");
define("_btgo","Go!");
define("_btresfor","Results found for");
define("_btnotfound","<h2>No result!</h2>\n<p>Try checking your search keys.</p>\n");
define("_btvoidcat","<h2>Empty!</h2>\n<p>Choose another category</p>\n");
define("_btorderby","Order by");
define("_btinsdate","Insert date");
define("_btname","Name");
define("_btdim","Size");
define("_btnfile","Number of files:");
define("_btevidence","Evidence");
define("_btcomments","Comments");
define("_btvote","Rate");
define("_btdownloaded","Downloaded");
define("_btprivacy","Privacy");
define("_bttotsorc","Total peers");
define("_btdesc","descending");
define("_btord","ascending");
define("_btnosearch","<center><h2>Search the files you would like to download</h2>If you need help try asking on the Forums; if you cannot download Magnet:/eD2K: links you probabily haven't installed Shareaza.<br>We remind you that our rules state that all files are private, and it's up to who shares to allow other people to download, and it's strictly forbidden to share copyrighted, porn, child-porn, racist, offending material or anything that could anyway violate the laws (ie. bomb creation tutorials).<br>anybody can request the appliance of a free filename filter that allows to protect his/her trademarks.</center>");
define("_bthelpfind","Search Help");
define("_bttype","Categories");
define("_bttopsource","TOP download sources");
define("_btnotopsource","There are no downloading Torrents at this time");
define("_btnotseeder_noneed","There are no critical Torrents at this time");
define("_btnotseeder_desc","If you have one of these file, please seed (share) it for who's waiting for downloading. Just try to download the file again setting as target the file you own, your client will detect that and will NEVER touch it.<br>Thanks from everybody for your help. There could be people waiting since hours/days. <b>FILESHARE PHILOSOPHY INSIDE</b>");
define("_btnoseeder","NO COMPLETE upload source");
define("_bthelpindex","<p><a name=\"HELP\"></a><a href='modules.php?name=$name&file=index_help'>Install Bit Torrent or Shareaza to download</a>");
define("_btnet","Network");
define("_btsource","Sources");
define("_btvisible","Visible");
define("_bttorrent","Torrent");
define("_btview","Seen");
define("_bthits","Downloaded");
define("_btsnatch","Completed");
define("_btalternatesource","Only alternate sources available");
define("_bteasy","Fast download");
define("_btmedium","Slow download");
define("_bthard","Difficult to download");
define("_btstats","Statistics");

//TESTI CHE COMPAIONO IN DETAILS.PHP
define("_btddownloaded","Downloaded");
define("_btdcomplete","Completed");
define("_dtimeconnected","Time connected");
define("_btsourceurl","Available on");
define("_btdidle","Paused");
define("_btdsuccessfully","Torrent uploaded successfully");
define("_btdsuccessfully2","Please start seeding now. Visibility depends on the number of the sources");
define("_btdsuccessfullye","Edit successfully");
define("_btdgobackto","Back to page");
define("_btdwhenceyoucame","since you came from");
define("_btdyoursearchfor","Your search for");
define("_btnotorrent","Torrent does not exist or has been banned");
define("_btdratingadded","Rate added");
define("_btdspytorrentupdate","SpyTorrent has updated the sources");
define("_btdspytorrentupdate1","You are being redirected in 3 seconds to the page");
define("_btdspytorrentupdate2","If something goes wrong, you can reach the page from");
define("_btdspytorrentupdate3","here");
define("_btdspytorrentnoupdate","It is not necessary to run SpyTorrent on internal Torrents or before 15 minutes since the last scan.");
define("_btname","Name");
define("_btdownloadas","Download as");
define("_btnetwork","network");
define("_bthelpinfohash","Info Hash Help");
define("_btdescription","Description");
define("_btnodead","<b>no</b> (dead)");
define("_btvisible","Visible");
define("_btbanned","Banned");
define("_btothersource","Altre Fonti");
define("_btnoselected","No category selected");
define("_btago","ago");
define("_btlastseeder","Last Seeder");
define("_btlastactivity","Last Activity");
define("_bttypetorrent","Type");
define("_btsize","Size");
define("_btminvote","Not voted (required at least __minvotes__ votes");
define("_btonly","only");
define("_btnone","none");
define("_btnovotes","No rate");
define("_btoo5","of 5 with");
define("_btvotestot","vote(s) total");
define("_btlogintorate","Login</a> to vote");
define("_btvot1","Very bad");
define("_btvot2","Not good");
define("_btvot3","Not bad");
define("_btvot4","Good");
define("_btvot5","Very Good");
define("_btaddrating","vote");
define("_btvote","Vote!");
define("_btrating","Rate");
define("_bthelpstat","Statistics Help");
define("_btviews","seen");
define("_bttimes","time(s)");
define("_btleechspeed","Leech Speed");
define("_bteta","ETA");
define("_btuppedby","Upladed by");
define("_btnumfiles","Number of files");
define("_btfilelist","Files list");
define("_btlasttrackerupdate","Last tracker update");
define("_bthidelist","Hide List");
define("_btleechers","Incomplete");
define("_bthelpsource","Peer Help");
define("_btseeders","Complete");
define("_btcommentsfortorrent","Comments for Torrent");
define("_btbacktofull","Back to complete details");
define("_btnotifyemailcom","If you want to be e-mailed when comments are added");
define("_btnotnotifyemailcom","You are currently listed among comments email, if you don't want to be e-amiled any more");
define("_btclickhere","click here");
define("_btnotifyemail1s","If you want to be e-mailed when the first <b>SEEDER</b> is added");
define("_btnotnotifyemail1s","You are currently listed among seeder email, if you don't want to be e-amiled any more");
define("_btaddcomment","Add Comment");
define("_btnocommentsyet","There are no comments at this time");
define("_btnotnotifyemail1s","in order to be e-mailed when the first SEEDER is added");
define("_btdgavesresult","has returned one result");
define("_btdnotifyemaildel","You have been removed from comment notify list");
define("_btdnotifyemaildel1","You're not receiving any more e-mail when a comment is added!");
define("_btdnotifyemailadd1","You will receive an e-mail when a comment is added, and you will not receive any more before you read the comment!");
define("_btdnotifyemailadd","You have been added to the comment notify list");
define("_btdnotifyadd","You have been added to the seeder notify list");
define("_btdnotifyadd2","you'll be noticed of new seeders for maximum one email each day!");
define("_btdnotifydel","You have been removed from seeder notify list and you're not receiving any more e-mails!");
define("_btddetails","Torrent details");
define("_bteditthistorrent","Edit this Torrent");
define("_btyes","yes");
define("_btno","no");
define("_btadded","Uploaded by");
define("_bton","up");
define("_bthelpothersource","Help Alternate Sources");
define("_btfilename","Filename");
define("_btpeers","Sources");
define("_btpeerstot","Total peers");
define("_bthelppeer","Peer Help");
define("_btleechers","Leechers");
define("_btdhelpdownload","Download Help");
define("_btyourate","You have voted");
define("_btupdatesource","Update sources now!");
define("_btseeders","Seeders");

//TESTI PRESENTI IN TAKEUPLOADURL.PHP
define("_btinseriti","Inserted");
define("_btand","and");
define("_btnumerror","their number is not equal and it is not possible to proceed with binary assignment");
define("_btmaxchar","ED2K URL must be at maximum 200 characters of length");
define("_bted2kstart","URL doesn't start with <b>ed2k://</b>");
define("_bt2par","URL doesn't have the second parameter: ");
define("_bturlfile","file");
define("_bturlcontent","URL doesn't contain");
define("_btfname","filename");
define("_bturlsize","URL doesn't contain");
define("_btsz","size");
define("_btidcode","hash info");
define("_bturlparerror","URL doesn't contain the parameter:");
define("_bturlsureerror","URL contains an illegal source");
define("_bturlnotinsert","Must insert an ED2K Link");
define("_btnotip","IP not specified");
define("_btinvip","Invalid IP");
define("_btnoport","No port specified");
define("_btinvport","Invalid Port");
define("_btparmag","none");
define("_btnopresent","not present");
define("_btmagchar","MagnetURL must be at maximum 200 characters of length");
define("_bftminlimit","You cannot share files smaller than");
define("_btfmaxlimit","Your Torrent has a too big file");
define("_btillegalword","Filename keywords seem to be of illegal activities.");
define("_btillegalwordinfo","Our portal use a special keyword filter to prevent illegal activities. We know that, even if your file contains illegal words, it can still be totally legal. Please accept our apologizes and try to upload a file a little different in name.");
define("_bturlinserted1","Torrent uploaded. You are being redirected in 3 seconds.<BR>If you are not redirect, you can reach the page from");
define("_bturlinserted2","this link");
define("_btnotify","You have been added to the notify list: you'll be e-mailed of new comments.");
define("_btnolinkinsert","No link inserted");

//TESTI PRESENTI IN UPLOAD.PHP
define("_btphotoext","Image file hasn't GIF, JPG or PNG extension");
define("_btalertmsg","Form has not been submitted due to these errors:");
define("_btalertmsg2","Please fix the errors and try to upload again");
define("_btfnotselected","ERROR: file not selected");
define("_btalertdesc","Please type in a description that indicates file type and quality, in particular in case of multimedia files");
define("_btalertcat","Select a category");
define("_btconferma","Are you ready to upload? If your Torrent is made of more files, please re-create it as a multiarchive containing the entire folder. Else, it could be unusable or it could make only troubles to who will try to download it.");
define("_btalerturl","Insertt a MAGNET or ED2K link");
define("_btalerturlnum1","ED2K link number");
define("_btalerturlnum2","while MAGNET link number is");
define("_btalerturlnum3","The number of the links must be the same since Torrents are made by couples of links");
define("_btalert5char","Filename must be at least 5 characters long");
define("_btofficialurl","This site's official trackers are:");
define("_btseeded","Only upload Torrents if you are seeding them!!! A peerless Torrent is not shown on main page.");
define("_btupfile","Upload file:");
define("_bttorrentname","Torrent name");
define("_btfromtorrent","Don't worry about not filling the field: it would be automatically filled from filename.");
define("_btdescname","Try to give it a descriptive name");
define("_btsrc_url","Source URL");
define("_btcompulsory"," (Compulsory)");
define("_btdescription","Torrent description (required)");
define("_btnohtml","WITHOUT USING HTML");
define("_btchooseone","Choose");
define("_bttype","Type");
define("_btverduplicate","Check against similar Torrents");
define("_btduplicatinfo","If checked the system stops the upload if a similar Torrent is found. Uncheck only if you still want to upload your Torrent. Remember that duplicate Torrents only confuse users, so it's better to have one Torrent for each product.");
define("_btupevidence","Evidence");
define("_btupevidencinfo","Use with responsibility: use it only when the file can be considered interesting for most of the public and a stable seed is granted (maybe 24/7 if possible, for at least one week...)");
define("_btowner","Owner");
define("_btowner1","Show User");
define("_btowner2","Privacy Mode");
define("_btowner3","Stealth Mode");
define("_btownerinfo","'SHOW USER' option allows other user to display your username, 'PRIVACY MODE' hides it but keeps edit/delete functions of owned Torrents, 'STEALTH MODE' completely hides the owner to the system, and doesn't allow any edit/deletion by the user.");
define("_btupnotify","Notify");
define("_btupnotifynfo","You will be e-mail when a comment is added");
define("_btfsend","Send Torrent");
define("_btinserte2k","Insert ED2K Link");
define("_btmagnetinsert","Insert Magnet Link");
define("_btinsertlinktitle","Insert links for GNutella and eDonkey2000 Networks");
define("_btinsertlinktext","You can insert an eDonkey2000 link to your Bit Torrent files to avoid tracker failures. Your links will be active until noticed fake or peerless to our staff");
define("_btinserttext2","You can insert either only MAGNET links or only ED2K links. If both lists are filled with entries, two links will be associated to each file: in other words the firs ED2K link and the first MAGNET link will be associated to the first file, and so on... By creating long file lists there will be more files ready for download: this is a very interesting feature, useful when you divide your download in small parts and you don't use Shareaza (that recognizes both kinds of links).");
define("_bted2kurl","Insert ED2K link");
define("_btsyntax","Like");
define("_btfiletype","extension");
define("_btfilesize","size");
define("_btidcode","infohash");
define("_btipport","ip:port");
define("_btstatic","indicates only we are using eDonkey2000 protocol");
define("_btfinalname","is the name of the file to download");
define("_btfinalsize","is the byte size of the file");
define("_btfinalidcode","ia special verification code that allows to find ONE ONLY FILE, and its copies, among many similar");
define("_btfinalipport","represents the main stable source (used by releasers)");
define("_btor","or");
define("_btaddmagnet","Add MAGNET link");
//ADDED!!!!
define("_btadded2k","Add eD2K Link");
define("_bthelpupload","Need help? Take a look on our <a href='modules.php?name=$name&file=upload_help'>tutorial</a>");
define("_btphoto","Image");

//TESTI CHE COMPAIONO IN ADDCOMMENT.PHP
define("_btiderror","Invalid ID");
define("_btnotfoundid","Torrent does not exist");
define("_btaddcomment","Add comment to");
define("_btaddtime","Uploaded ");
define("_btby","by");
define("_btsend","Send");

//TESTI CHE COMPAIONO IN DELETE.PHP
define("_btcannotdel","Unable to delete!");
define("_btmissingdata","Request data missing!");
define("_btdeldenied","Only Owner or site Administrator can delete this Torrent");
define("_btnotconfirmed","You must be sure of what you are going to do");
define("_btdeleted","Torrent deleted");
define("_btgoback","Go back");


//TESTI CHE COMPAIONO IN DOWNLOAD.PHP
//LE PAROLE TRA "** **" SONO INDICATORI
define("_btantiscrocco","<p>If you want to keep downloading you can share other **min_num** Torrents containing, each one, at least **min_size** of data and keep at least a seeder. Remember to use an external tracker and upload the file here. We remind you that only LEGAL files are allowes, and you must not set STEALTH MODE as privacy, or the system will not recognize you as seeder, and you must be able to moderate file permissions. Only files uploaded by you can be counted among seeds. Redundant and grabbed Torrent will cause account termination. This server synchronizes Torrents sources each hour, so you could sometimes find troubles (try to force SpyTorrent on seeded Torrents). This will allow the growth of community forcing peope to share.</p><P>Try to seed the most Torrents you can. Do not register with a different username, since we trace IPs. People who make a donation will gain the COMPLETE unlock of download capabilities. Remember to specify your username. Remember that we are not responsible for the content of the Torrents and users privately share their Torrents: they can decide who can or not download. $nukeurl can make only statistics, and cannot keep control of each shared Torrent, but thousands of people are satisfied by using our portal.</p>");
define("_btnogratis","You cannot live always for free!");
define("_bttodayused","Today you used");
define("_bttomorrow","Torrents and it is not possible to use any more. Come back tomorrow and remember you can use at maximum **maxfile** daily Torrents.</p>");
define("_btlantoday","Today you or somebody inside your LAN with IP **ip** has already uses ");
define("_btlantomorrow"," Torrents and it is not possible to use any more. Come back tomorrow and remember you can use at maximum **max_num** daily Torrents. We know LANs are penalized, but we must prevent network abuse.</p>");
define("_btthisweek","This week you already used ");
define("_btnextweek"," Torrents and it is not possible to use any more. Come back next week and remember you can use at maximum **max_num** weekly Torrents.</p>");
define("_btthisweeklan","This week, you or somebody having your same IP **ip** has already used ");
define("_btnextweeklan"," Torrents and it is not possible to use any more. Come back next week and remember you can use at maximum **max_num** weekly Torrents.</p>");
define("_btmsgbody1","The owner has allowed you to download the files he/she is sharing on BIT TORRENT by **nukeurl** for which you asked for authorization: ");
define("_btmsgbody2","From now on you can download all the user's files. **nukeurl** protects your privacy.");
define("_btmsgsubject","Access Authorization for BIT TORRENT files by **nukeurl**");
define("_btauthreqbody","User **username** has requested you to be authorized to view the file you are sharing on BIT TORRENT by **nukeurl**: In order to authorize him/her go to:\n\n   **nukeurl**/modules.php?name=$name&file=mytorrents&privacy=**userid**\n\n\nIf you want to authorize all pending Torrent authorizations click here:\n\n$nukeurl/modules.php?name=$name&file=mytorrents&privacy=all\n\n\nYou won't receive any more e-mails before you allow or deny download to all pending files.\nTo view all users who are asking for authorization:\n\n**nukeurl**/modules.php?name=$name&file=mytorrents\n\n\n**sname** protects you privacy, your most important right after freedom!");
define("_btautherrpending","You have already asked for download authorization to this user. While he/she doesn't decide to approve or deny that you won't be able to ask more authorizations. There are **tot** pending authorizations.");
define("_bterrminseed","<li>You must seed at least <b>**min_share**</b> of data.<br>");
define("_btruleok","Rule is OK");
define("_btruleko","<b>WARNING: you don't match this rule</b>. ");
define("_bterrnoseeder","<b>You are not seeding anything!</b>");
define("_bterrnotenoughshare1","<b>You are seeding");
define("_bterrnotenoughshare2"," of data, you must seed more ");
define("_bterrtoosmall","<li>You must seed at least a file of <b>**min_share**</b> of size.<br>");
define("_bterrtoobig","<b>Your largest seeded file is ");
define("_bterrmaxnumnoseed", "<li>You can download at maximum <b>**maxfile**</b> without being seeder.<br> ");
define("_bterrmaxdownloadsize","<li>You cannot download when beyond of <b>**maxsize**</b> limit.<br>");
define("_btfinalerrmsg1","At this time you, using IP <b>**ip**</b> (you are the only reading this) or other users inside your LAN have gone beyond the <b>free</b> download limit for this site!<br>Site limits are:<ol>");
define("_btfinalerrmsg2","</ol>To keep downloading <b>without limitations</b> you must match the following rules:<ol>");
define("_btfinalerrmsg3","</ol><p>Seeding means sharing <b>a 100% complete file</b> by specifying your complete file as target file for download (it won't be touched by Bit Torrent).<br></p><p>You may also <a href='modules.php?name=**name**&file=upload'>UPLOAD</a> new torrents and run them.</p><p>Else you can wait the end of your current downloads, which automatically become seeded if you DO NOT CLOSE your download window.</p><p>When matching all the rules, you will be able to download again</p>");
define("_bterrorprivate","This is a private file: you have already asked for download authorization. While the owner has not accepted your request yet, you cannot download the file.");
define("_btrefused","The owner declined your authorization request. You cannot send any more requests to that user.");
define("_btreqsent","An e-mail has sent to the Torrent owner in order to ask for download authorization: you will be noticed by e-mail of the result.");

//TESTI CHE COMPAIONO IN EDIT.PHP
define("_btedittorrent","Edit Torrent \"");
define("_bterreditnoowner","<h1>Access Denied</h1>\n<p>Only Owner and Administrators can edit Torrents</p>\n");
define("_btbanned","Banned");
define("_btcancel","Cancel");
//define("_btdelcommand","Do not edit Torrent, but <input type=\"submit\" value=\"DELETE IT!\" />\n");
//define("_btsure","Yes: I'm sure about that!");

//TESTI CHE COMPAIONO IN MYTORRENTS.PHP
define("_btallauthorized","All users have been authorized");
define("_btauthorized","Selected user has been authorized");
define("_bthasauthorized","Owner has authorized you to download his files");
define("_btnowcandownload","You can now freely download all the user's files.\nWe protect your privacy.");
define("_btauthmailsubj","BIT TORRENT file access Authorization");
define("_btauthorizationrequested","The following users have requested download authorization:");
define("_btnotorrents","There are no Torrents");
define("_btnotorrentuploaded","You have not uploaded any Torrent yet");

//TESTI CHE COMPAIONO IN TAKECOMMENT.PHP
define("_btcommentkeyfound","The system has checked the words of your comment. The following words may be connected with illegal activities:<ol>");
define("_btcommentkeyfound2","</ol><p>We know that the comment can still be legal, we apologize for the inconvenience and ask you to use different words. This is an automatic filter, and it could be wrong sometimes.</p>");
define("_bttorrentmailbody","Hello, you are receiving this message since you explicitely requested it on BIT TORRENT service\nrabout TORRENT **nome**\n\nYou can view the comment clicking on:\n\n**url_site**/modules.php?name=**name**&file=details&id=**id**&viewcomm=**newid**&sn=u#comm**newid**\n\n\nYou must be logged into the site to view that.\n\nYou won't receive any more e-mails about this Torrent unless you read the comment.\n\n\nIn order to stop receiving notices about this Torrent's comments click here:\n**url_site**/modules.php?name=**name**&file=details&id=**id**&cn=n");
define("_btcommentinserted","Comment successfully inserted, you are being redirected in 3 seconds on the Torrent page.<br>You can reach the page from <a href=\"modules.php?name=**name**&file=details&id=**id**&viewcomm=**newid**#comm**newid**\">here</a> if you have troubles");

//TESTI CHE COMPAIONO IN TAKEEDIT.PHP
define("_btmissingformdata","Missing input data!");
define("_bteditfailed","Edit failed");
define("_bteditdenied","Unable to edit other people's Torrents");
define("_btreturl","File successfully edited, you are being redirected in 3 seconds on the Torrent page.<br>You can reach the page from <a href=\"**returl**\">here</a> if you have troubles");

//TESTI CHE COMPAIONO IN TAKERATE.PHP
define("_btratefailed","Vote failed!");
define("_btinvalidrating","Invalid vote");
define("_btidnotorrent","Invalid ID. Torrent does not exist");
define("_btnovoteowntorrent","You cannot vote your own Torrents");
define("_btalreadyrated","Torrent already rated");
define("_btvotedone","Vote successfull, you are being redirected in 3 seconds on the Torrent page.<br>You can reach the page from <a href=\"modules.php?name=**name**&details.php&id=**id**&rated=1\">here</a> if you have trubles");

//TESTI CHE COMPAIONO IN TAKEUPLOAD.PHP
define("_btuploadfailed","Upload failed!");
define("_btemptyfname","Empty filename");
define("_btinvalidfname","Invalid filename");
define("_btfnamenotorrent","This is not a Torrent file (.torrent)");
define("_btferror","File Error");
define("_bterrnofileupload","Fatal error in file.");
define("_btemptyfile","File empty");
define("_btnobenc","File damaged. Are you sure it is really a Torrent?");
define("_btnodictionary","Torrent dictionary not present");
define("_btdictionarymisskey","Missing Torrent Dictionary Keys");
define("_btdictionaryinventry","Invalid data inside Torrent Dictionary");
define("_btdictionaryinvetype","Invalid data types in Torrent Dictionary");
define("_btinvannounce","Invalid Announce URL. Must be ");
define("_btactualannounce","Specified tracker ");
define("_bttrackerdisabled","Our tracker has been disabled, <a href='modules.php?name=**name**&file=upload_help'>read tutorials</a> to learn how to use external trackers");
define("_btinvpieces","Invalid Torrent parts");
define("_btmissinglength","Missing files and size");
define("_btnofilesintorrent","Missing Torrent files");
define("_btfnamerror","Invalid filename");
define("_btfilenamerror","Error in filename");
define("_bttorrenttoosmall","<p>You cannot share a file smaller than <b>");
define("_bttorrenttoosmall2","</b></p><p>Your torrent contains a file of <b>");
define("_btmaxuploadexceeded","It is not possible to upload more than **maxupload** each 24 hours.");
define("_btnumfileexceeded","<p>It is not possible to upload more than <b>**maxupload**</b> files each 24 hours.</p><p>At this time you have already uploaded <b>**rownum**</b> files for a total of <b>**totsize**</b> of size");
define("_btsearchdupl","The search resulted that these files may correspond to the ones you are sharing:<ol>");
define("_btduplinfo","<p>If you file is in this list, please seed one of these Torrents!</p>");
define("_btsocktout","ERROR: Socket timed-out");
define("_bttrackernotresponding","Tracker not responding.\n You must check tracker spelling (NO EMPTY SPACES INSIDE URLs) and that it is running. Specified tracker:");
define("_bttrackerdata","Invalid data on external tracker. There can be server problems on the tracker. Please try again later.");
define("_btuploadcomplete","Successfully uploaded, you are being redirected in 3 seconds on the file page. Remember to seed it or the Torrent won't be visible on main page!<br>You can reach the page from <a href=\"modules.php?name=**name**&file=details&id=**id**&uploaded=1\">here</a> if you have troubles");
?>