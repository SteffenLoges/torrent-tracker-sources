<?php
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
global $name;


//ERRORI SQL
define("_btsqlerror1","Errore nella Query SQL ");
define("_btsqlerror2","ID errore: ");
define("_btsqlerror","Messaggio di errore: ");

//TESTI CHE COMPAIONO IN INCLUDE/BITTORRENT.PHP
define("_btindex","Home Torrent");
define("_btupload","Invia un Torrent");
define("_btlogin","Login");
define("_btsignup","Registrati");
define("_btpersonal","Torrent di ");
define("_btrulez","Regolamento");
define("_btforums","Forum");
define("_bthelp","Aiuto");
define("_btadvinst","Installa Bit Torrent o Shareaza per scaricare");
define("_btaccessden","Accesso Negato. Per accedere devi essere <A href=\"modules.php?name=Your_Account&op=new_user\">registrato</a>");
define("_btlegenda","Aiuto Funzioni e legenda");
define("_btyourfilext","File tuo, tracker esterno");
define("_btexternal","Tracker Esterno");
define("_btyourfile","File tuo");
define("_btsticky","In Evidenza");
define("_btauthforreq","Autorizzazione da richiedere");
define("_btauthreq","Richiesta Autorizzazione");
define("_btdown","Scarica");
define("_btunknown","Sconosciuto");
define("_btrefresh","Aggiorna");
define("_btvisible","Visibile");

//TESTI CHE COMPAIONO IN INDEX.PHP
define("_btstart","<h2>Benvenuti su BIT TORRENT</h2>
<p>Per favore mantieni la tua finestra BitTorrent aperta il pi� lungo possibile dopo aver scaricato! Questo velocizzer� tutti i download.</p>
<p>Per cominciare <a href='modules.php?name=$name&file=index_help'>leggi questa guida</a></p>
<p>Per aumentare la tua velocit� cerca di entrare in modalit� <b>ATTIVA</b>, <a href='modules.php?name=$name&file=connection_help'>leggi questa guida</a>. Consigliato a TUTTI!</p>
<p>Abbiamo pubblicato una <a href='modules.php?name=$name&file=tutorial'>guida a Bit Torrent</a>, con un occhio in particolare sul Client JAVA Azereus che � pieno di funzionalit� e per finire come configurare Azereus per scaricare anche tra client Fastweb! Si ringrazia ZackS</p>");
define("_btsearch","<img src='modules/$name/pic/icon_mini_search.gif' align=midle> Cerca");
define("_btin","in");
define("_btalltypes","qualsiasi");
define("_btactivetorrents","Torrent attivi");
define("_btitm","includi Torrent morti");
define("_btstm","solo Torrent morti");
define("_btgo","Vai!");
define("_btresfor","Risultati trovati per");
define("_btnotfound","<h2>Nessun risultato!</h2>\n<p>Prova ancora ridefinendo le parole di ricerca.</p>\n");
define("_btvoidcat","<h2>Vuota!</h2>\n<p>Seleziona un'altra categoria</p>\n");
define("_btorderby","Ordina per");
define("_btinsdate","Data Inserimento");
define("_btname","Nome");
define("_btdim","Dimensione");
define("_btnfile","Numero file:");
define("_btevidence","In Evidenza");
define("_btcomments","Commenti");
define("_btvote","Valutazione");
define("_btdownloaded","Scaricato");
define("_btprivacy","Privacy");
define("_bttotsorc","Fonti Totali");
define("_btdesc","decrescente");
define("_btord","crescente");
define("_btnosearch","<center><h2>Per visualizzare i file effettua una ricerca</h2>Se hai bisogno di aiuto entra in chat, se non riesci a scaricare dagli ed2k/magnet link dipende dal fatto che non hai installato shareaza.<br>Ricordiamo che da nostro regolamento tutti i file inseriti vengono dichiarati privati ed � compito di chi condivide limitare gli ip consentiti, inoltre � severmente vietato codividere materiale protetto da diritti d'autore, porno e pedopornografici, razzista/offensivo o che possano in qualche maniera danneggiare minorenni, come ad esempio informazioni sulla creazione di bombe, o in ogni caso ritenuti illegali nello stato italiano e nella comunit� europea.<br>Chiunque pu� richiedere gratuitamente di applicare attraverso i nostri filtri il blocco di una parola di cui risulta proprietario come ad esempio nome e cognome, marca ecc.</center>");
define("_bthelpfind","Aiuto Ricerca");
define("_bttype","Categorie");
define("_bttopsource","TOP FONTI in download");
define("_btnotopsource","Non ci sono torrent in download in questo momento");
define("_btnotseeder_noneed","Non ci sono Torrent critici in questo momento");
define("_btnotseeder_desc","Per favore se hai uno o pi� di questi file completi fai da seeder (fonte completa) per chi li vuole, devi semplicemente scaricare il TORRENT e specificare come destinazione il tuo file, in nessun caso verr� modificato.<br>Grazie da parte di tutti per il tuo aiuto, molti potrebbero stare da ore/giorni ad espettare <b>FILESHARE PHILOSOPHY INSIDE</b>");
define("_btnoseeder","NESSUNA FONTE COMPLETA in upload");
define("_bthelpindex","<p><a name=\"HELP\"></a><a href='modules.php?name=$name&file=index_help'>Installare Bit Torrent o Shareaza per scaricare</a>");
define("_btnet","Rete");
define("_btsource","Fonti");
define("_btvisible","Visibile");
define("_bttorrent","Torrent");
define("_btview","Visto");
define("_bthits","Scaricato");
define("_btsnatch","Completato");
define("_btalternatesource","Disponibili solo fonti alternative");
define("_bteasy","Veloce da scaricare");
define("_btmedium","Lento da scaricare");
define("_bthard","Difficile da scaricare");
define("_btstats","Statistiche");

//TESTI CHE COMPAIONO IN DETAILS.PHP
define("_btddownloaded","Scaricato");
define("_btdcomplete","Completato");
define("_dtimeconnected","Tempo connesso");
define("_btsourceurl","Disponibile su");
define("_btdidle","In pausa");
define("_btdsuccessfully","Torrent caricato con successo");
define("_btdsuccessfully2","Per favore inizia adesso a fare da seed. La visibilit� del Torrent dipende dal numero delle fonti");
define("_btdsuccessfullye","Modificato con successo");
define("_btdgobackto","Indietro alla pagina");
define("_btdwhenceyoucame","da cui sei venuto");
define("_btdyoursearchfor","La tua ricerca per");
define("_btnotorrent","Il Torrent non esiste o � stato bannato");
define("_btdratingadded","Votazione aggiunta");
define("_btdspytorrentupdate","SpyTorrent ha aggiornato le fonti");
define("_btdspytorrentupdate1","Tra 3 secondi sarai redirettato alla pagina del Torrent");
define("_btdspytorrentupdate2","Qualunque cosa andasse storto puoi raggiungere la pagina da");
define("_btdspytorrentupdate3","qui");
define("_btdspytorrentnoupdate","Non � necessario eseguire spytorrent su file interni o su torrent prima che siano trascorsi almeno 15 minuti.");
define("_btname","Nome");
define("_btdownloadas","Scarica come");
define("_btnetwork","network");
define("_bthelpinfohash","Aiuto Info Hash");
define("_btdescription","Descrizione");
define("_btnodead","<b>no</b> (morto)");
define("_btvisible","Visibile");
define("_btbanned","Bannato");
define("_btothersource","Altre Fonti");
define("_btnoselected","Nessuna categoria selezionata");
define("_btago","fa");
define("_btlastseeder","Ultimo Seeder");
define("_btlastactivity","Ultima Attivit�");
define("_bttypetorrent","Tipo");
define("_btsize","Dimensione");
define("_btminvote","Non votato (servono almeno __minvotes__ voti");
define("_btonly","solo");
define("_btnone","nessuno");
define("_btnovotes","Nessun voto");
define("_btoo5","di 5 con");
define("_btvotestot","voto(i) totali");
define("_btlogintorate","Autenticati</a> per dare il tuo voto");
define("_btvot1","Pessimo");
define("_btvot2","Sufficiente");
define("_btvot3","Mediocre");
define("_btvot4","Buono");
define("_btvot5","Ottimo");
define("_btaddrating","vota");
define("_btvote","Vota!");
define("_btrating","Votazione");
define("_bthelpstat","Aiuto Statistiche");
define("_btviews","visto");
define("_bttimes","volta(e)");
define("_btleechspeed","Velocit� Leech");
define("_bteta","ETA");
define("_btuppedby","Segnalato da");
define("_btnumfiles","Numero file");
define("_btfilelist","Lista file");
define("_btlasttrackerupdate","Ultimo aggiornamento tracker");
define("_bthidelist","Nascondi Lista");
define("_btleechers","Incompleti");
define("_bthelpsource","Aiuto Fonti");
define("_btseeders","Completi");
define("_btcommentsfortorrent","Commenti per il Torrent");
define("_btbacktofull","Torna ai dettagli completi");
define("_btnotifyemailcom","Se vuoi essere avvisato via email quando vengono aggiunti commenti a qusto Torrent");
define("_btnotnotifyemailcom","Attualmente stai ricevendo la notifica per email se viene aggiunto un commento a questo torrent, se desideri non riceverla pi�");
define("_btclickhere","fai click qui");
define("_btnotifyemail1s","Se vuoi ricevere una notifica per email quando viene aggiunto il primo <b>SEEDER</b> a questo torrent");
define("_btnotnotifyemail1s","Attualmente stai ricevendo la notifica per email al primo seeder che viene a questo torrent nell'arco di una giornata, se desideri non riceverla pi�");
define("_btaddcomment","Aggiungi un Commento");
define("_btnocommentsyet","Attualmente non sono presenti commenti");
define("_btnotnotifyemail1s","Per essere avvertito via email appena verr� aggiunto il primo SEEDER");
define("_btdgavesresult","ha restituito un solo risultato");
define("_btdnotifyemaildel","Sei stato rimosso dalla lista di notifica per email commento");
define("_btdnotifyemaildel1","Non riceverai ulteriori email quando verra aggiunto un commento!");
define("_btdnotifyemailadd1","Verrai informato quando commento verr� aggiunto e non riceverai ulteriori notifiche finch� non li visualizzerai!");
define("_btdnotifyemailadd","Sei stato aggiunto alla lista di notifica email per commento");
define("_btdnotifyadd","Sei stato aggiunto alla lista di notifica email per seeder");
define("_btdnotifyadd2","Verrai informato quando il primo seeder si collega e riceverai al massimo un email a giorno!");
define("_btdnotifydel","Sei stato rimosso dalla lista di notifica per email da seeder e non riceverai ulteriori email quando verra aggiunto un seeder!");
define("_btddetails","Dettagli per il Torrent");
define("_bteditthistorrent","Modifica questo Torrent");
define("_btyes","si");
define("_btno","no");
define("_btadded","Segnalato da");
define("_bton","su");
define("_bthelpothersource","Aiuto Fonti Alternative");
define("_btfilename","Nome file");
define("_btpeers","Fonti");
define("_btpeerstot","Fonti totali");
define("_bthelppeer","Aiuto Fonti");
define("_btleechers","Leecher");
define("_btdhelpdownload","Aiuto Download");
define("_btyourate","Tu hai votato");
define("_btupdatesource","Aggiorna le fonti ora!");
define("_btseeders","Seeder");

//TESTI PRESENTI IN TAKEUPLOADURL.PHP
define("_btinseriti","Inseriti");
define("_btand","e");
define("_btnumerror","il loro numero non � uguale e quindi non � possibile procedere con l'assegnazione binaria");
define("_btmaxchar","L'URL ED2K non pu� essere pi� grande di 200 caratteri");
define("_bted2kstart","L'URL non comincia per <b>ed2k://</b>");
define("_bt2par","L'URL non ha come secondo parametro");
define("_bturlfile","file");
define("_bturlcontent","L'URL non contiene il");
define("_btfname","nome file");
define("_bturlsize","L'URL non contiene la");
define("_btsz","dimensione");
define("_btidcode","codice identificativo");
define("_bturlparerror","L'URL non contiene il parametro");
define("_bturlsureerror","L'URL contiene una fonte non regolare");
define("_bturlnotinsert","Obbligatorio inserire un URL ED2K");
define("_btnotip","IP non inserito");
define("_btinvip","IP non valido");
define("_btnoport","Porta non inserita");
define("_btinvport","Porta non valida");
define("_btparmag","nessuno");
define("_btnopresent","non presente");
define("_btmagchar","L'URL Magnet non pu� essere pi� grande di 200 caratteri");
define("_bftminlimit","Non � possibile fare condividere un file pi� piccolo di");
define("_btfmaxlimit","Il Torrent che hai inviato contiene un file troppo grande");
define("_btillegalword","La ricerca effettuata utilizzando le parole del nome del file fa supporre che il Torrent caricato abbia a che fare con attivit� illegali.");
define("_btillegalwordinfo","Il nostro portale utilizza un filtro basato sulle parole chiave per prevenire attivit� illegali o dannose. Siamo consapevoli che nonostante siano utilizzate queste parole nel tuo file esso possa essere comunque legale. Accetta le nostre scuse e prova a caricare nuovamente un Torrent con nome leggermente diverso.");
define("_bturlinserted1","Inserimento effettuato correttamente, tra 3 secondi verrai ridiretto sulla scheda del file.<BR>Se non dovessi essere ridiretto puoi raggiungere la pagina da");
define("_bturlinserted2","questo link");
define("_btnotify","Sei stato aggiunto alla lista di notifica: se il Torrent ricever� dei commenti verrai avvisato tramite email.");
define("_btnolinkinsert","Nessun link inserito");

//TESTI PRESENTI IN UPLOAD.PHP
define("_btphotoext","Il file di immagine non ha estensione GIF, JPG o PNG");
define("_btalertmsg","Il modulo non e' stato inviato a causa dei seguenti errori:");
define("_btalertmsg2","Si prega di corregere gli errori e di inviarlo nuovamente");
define("_btfnotselected","ERRORE: file non selezionato");
define("_btalertdesc","Inserire una descrizione che specifichi la lingua e la qualit� del file, in particolare in caso di file multimediali");
define("_btalertcat","Selezionare una categoria");
define("_btconferma","Sei pronto per effettuare l'upload? Se il tuo Torrent � composto da pi� file, per cortesia ricrealo come multiarchivio contenente l'intera cartella. Altrimenti potrebbe essere inutilizzabile o dare solo problemi a chi vuole scaricarlo.");
define("_btalerturl","Inserire un link MAGNET o ED2K");
define("_btalerturlnum1","Il numero di ED2K link �");
define("_btalerturlnum2","mentre quello MAGNET �");
define("_btalerturlnum3","Il numero deve essere uguale in quanto ogni file per Torrent � composto da coppie di link");
define("_btalert5char","Il nome del file deve essere composto da almeno 5 caratteri");
define("_btofficialurl","I tracker uffciali di questo sito sono:");
define("_btseeded","Effettua l'upload di questo Torrent solo se hai intenzione di fare da seed. Un Torrent senza fonti non viene visualizzato sulla pagina principale.");
define("_btupfile","Upload del file:");
define("_bttorrentname","Nome del Torrent");
define("_btsrc_url","URL Sorgente");
define("_btcompulsory"," (Obbligatorio)");
define("_btfromtorrent","Non preoccuparti di lasciare il campo vuoto: ci pensiamo noi a prendere il nome direttamente dal file.");
define("_btdescname","Cerca almeno di dargli un nome descrittivo");
define("_btdescription","Descrizione del Torrent (obbligatorio)");
define("_btnohtml","SENZA FARE USO DI HTML");
define("_btchooseone","Scegli");
define("_bttype","Tipo");
define("_btverduplicate","Verifica Torrent simili");
define("_btduplicatinfo","Se selezionato impedisce l'upload nel caso in cui il sistema trovi un file probabilmente corrispondente. Deseleziona la casella se vuoi comunque caricare il Torrent. Ricorda che i Torrent duplicati confondono soltanto gli utenti, ed � bene avere un solo Torrent per ogni prodotto.");
define("_btupevidence","Messo in Evidenza");
define("_btupevidencinfo","Usare questa opzione con responsabilit�: solo se il file pu� davvero interessare gli utenti e quando � garantito un buon seeding (magari 24 ore su 24 per una settimana intera...)");
define("_btowner","Proprietario");
define("_btowner1","Visualizza Utente");
define("_btowner2","Modalit� Privacy");
define("_btowner3","Modalit� Stealth");
define("_btownerinfo","L'opzione 'VISUALIZZA UTENTE' permetter� agli utenti di visualizzare il proprio nick, 'PRIVACY' lo nasconde lasciando comunque attiva le funzionalit� di modifica/cancellazione nei propri torrent, 'STEALTH' impedisce qualsiasi collegamento con chi fa upload e quindi non visualizzer� il proprio nick e non sar� possibile nessun tipo di modifica al file");
define("_btupnotify","Notifica");
define("_btupnotifynfo","Sarai avvisato via email quando verr� aggiunto un commento");
define("_btfsend","Invia Torrent");
define("_btinserte2k","Inserire URL ED2K");
define("_btmagnetinsert","Inserire URL Magnet");
define("_btinsertlinktitle","Inserisci link per GNutella e eDonkey2000");
define("_btinsertlinktext","Puoi inserire un link eDonkey2000 ai tuoi file Bit Torrent per prevenire cadute del tracker. Il link rester� inserito finch� non verr� segnalato come fake o senza fonti al nostro staff");
define("_btinserttext2","Puoi inserire o solamente ED2K link oppure solamente MAGNET. Nel caso dovessero essere popolate entrambe le liste verranno associati due link per ciascun file: in altre parole il primo link ED2K e il primo link MAGNET verranno associati allo stesso file e cos� via. Specificando liste lunghe compariranno pi� link collegati allo stesso download: questa � una caratteristica molto utile quando il download viene suddiviso in pi� parti e non si utilizza Shareaza (che riconosce indifferentemente entrambi i tipi di link).");
define("_bted2kurl","Inserisci link ED2K");
define("_btsyntax","Del tipo");
define("_btfiletype","estensione");
define("_btfilesize","Proprietario");
define("_btidcode","codice_hash");
define("_btipport","ip:porta");
define("_btstatic","indica semplicemente che lavoriamo in ambiente eDonkey2000");
define("_btfinalname","� il nome del file da scaricare");
define("_btfinalsize","� la dimesione, in byte, del file");
define("_btfinalidcode","� un codice di verifica in grado di identificare SENZA ERRORI il solo unico file a cui � associato");
define("_btfinalipport","rappresenta la sorgente stabile (opzione usata da chi fa release)");
define("_btor","oppure");
define("_btaddmagnet","Aggiungi link MAGNET");
//AGGIUNTO!!!!
define("_btadded2k","Aggiungi link ED2K");
define("_bthelpupload","Serve aiuto? Leggi la <a href='modules.php?name=$name&file=upload_help'>guida</a>");
define("_btphoto","Immagine");

//TESTI CHE COMPAIONO IN ADDCOMMENT.PHP
define("_btiderror","ID non valido");
define("_btnotfoundid","Torrent inesistente");
define("_btaddcomment","Aggiungi commento a");
define("_btaddtime","Inserito il ");
define("_btby","da");
define("_btsend","Invia");

//TESTI CHE COMPAIONO IN DELETE.PHP
define("_btcannotdel","Impossibile eliminare!");
define("_btmissingdata","Dati di richiesta mancanti!");
define("_btdeldenied","Solo il proprietario o un Amministratore possono eliminare questo Torrent");
define("_btnotconfirmed","Devi essere sicuro di ci� che stai per fare");
define("_btdeleted","Torrent eliminato");
define("_btgoback","Torna indietro");


//TESTI CHE COMPAIONO IN DOWNLOAD.PHP
//LE PAROLE TRA "** **" SONO INDICATORI
define("_btantiscrocco","<p>Se vuoi continuare a scaricare senza limiti puoi creare altri **min_num** torrent contenenti, ognuno, almeno **min_size** e fare in modo che tu, o altri per te, ti mantengano sempre almeno un seeder a torrent. Ricordati che dovrai usare un tracker esterno e fare l'upload su entrambi i tracker. Per finire ricordimo che � ammesso solo materiale legale, che NON devi settare ANONIMO come privacy altrimenti il sistema non riuscir� ad agganciare i seeder al tuo account, e che devi essere in grado di moderare i permessi dei file privati. Non vengono conteggiati seeder per file non uppati col tuo account. Fenomeni come l'upload di file ripetuti o scroccati da altri utenti verranno severamente puniti con la disabilitazione dell'account! Il server sincronizza i torrent ogni 3 ore oppure ogni quarto d'ora in caso di errori del tracker esterno, quindi in certe circostanze potresti trovarti ad aspettare la sincronizzazione. Questo permetter� di aumentare il materiale condiviso costringendo tutti a sharare e favorira la crescita dei nuovi tracker.</p><p>Siamo a conoscenza del fatto che magari in questo momento potresti essere seeder di numerosi torrent, ma purtroppo non riusciamo a poterlo verificare e quindi devi fare da seeder per file uppati da te.</p><P>Per questo ti invitiamo a fare da seeder a pi� Torren che puoi. Non registrarti con un altro nick, noi tracciamo anche gli IP. Se vuoi fare una donazione al nostro sito ti becchi lo sblocco COMPLETO dei limiti di download. Indipendentemente dal metodo per contribuire ricorda di specificare nella descrizione il tuo nick. Ricorda che noi non siamo responsabili di nessun contenuto, perch� gli utenti condividono privatamente ed sono liberi di non farti accedere e bloccare determinati IP. $nukeurl effettua solo delle statistiche e non � in grado di gestire i singoli problemi legati ai Torrent, tuttavia migliaia di utenti usano il nostro motore di ricerca con soddisfazione.</p>");
define("_btnogratis","Non si vive di solo gratis!");
define("_bttodayused","Per oggi hai gi� utilizzato");
define("_bttomorrow","torrent e non � possibile utilizzarne altri, torna domani e ricorda che puoi utilizzare al massimo **maxfile** torrent al giorno.</p>");
define("_btlantoday","Per oggi tu o qualcuno nella tua LAN con IP **ip** ha gi� utilizzato ");
define("_btlantomorrow"," Torrent e non � possibile utilizzarne altri, torna domani ma ricorda che puoi utilizzare al massimo **max_num** torrent al giorno. Sappiamo che le LAN vengono penalizzate, ma � un controllo che purtroppo DEVE esserci.</p>");
define("_btthisweek","Per questa settimana hai gi� utilizzato ");
define("_btnextweek"," torrent e non � possibile utilizzarne altri. Torna la prossima settimana ma ricorda che puoi utilizzare al massimo **max_num** torrent a settimana.</p>");
define("_btthisweeklan","Per questa settimana tu o qualcun altro che ha avuto il tuo stesso indirizzo internet IP **ip** ha gi� utilizzato ");
define("_btnextweeklan"," torrent e non � possibile utilizzarne altri, torna la settimana prossima ma ricorda che puoi utilizzare al massimo **max_num** torrent a settimana.</p>");
define("_btmsgbody1","L'utente ti ha autorizzato a scaricare i file che condivide su BIT TORRENT by **nukeurl** per i quali hai fatto richiesta di scaricare: ");
define("_btmsgbody2","Da adesso puoi scaricare tranquillamente TUTTI i file di QUESTO utente. **nukeurl** protegge la tua privacy.");
define("_btmsgsubject","Autorizzazione accesso file BIT TORRENT  by **nukeurl**");
define("_btauthreqbody","L'utente **username** ha chiesto di essere autorizzato a visualizzare i file che hai condiviso su BIT TORRENT by **nukeurl**: Per autorizzarlo vai su:\n\n   **nukeurl**/modules.php?name=$name&file=mytorrents&privacy=**userid**\n\n\nSe vuoi autorizzare tutti gli utenti in attesa fai click su un qualsiasi TORRENT oppure qui:\n\n$nukeurl/modules.php?name=$name&file=mytorrents&privacy=all\n\n\nNon riceverai ulteriori notifiche email finch� non concederai o negarai l'autorizzazione a tutti gli elementi presenti.\nPer visualizzare in dettaglio gli utenti che hanno richiesto di accedere ai tuoi file:\n\n**nukeurl**/modules.php?name=$name&file=mytorrents\n\n\n**sname** protegge la tua privacy, il tuo pi� grande diritto dopo la libert�!");
define("_btautherrpending","In passato � gi� stata inviata un'email al proprietario di questo file, finch� non decider� di autorizzare o meno non potr� ricevere altre email. Al momento ha ancora **tot** utenti da autorizzare.");
define("_bterrminseed","<li>Devi fare da seeder per un totale di almeno <b>**min_share**</b>.<br>");
define("_btruleok","OK, regola rispettata");
define("_btruleko","<b>ATTENZIONE regola non rispettata</b>. ");
define("_bterrnoseeder","<b>Non stai facendo da seeder per nessun file</b>");
define("_bterrnotenoughshare1","<b>Stai facedo da seeder per un totale di");
define("_bterrnotenoughshare2",", devi fare da seeder per altri ");
define("_bterrtoosmall","<li>Devi fare da seeder per un file grande almeno <b>**min_share**</b>.<br>");
define("_bterrtoobig","<b>Il tuo file da seeder pi� grande � ");
define("_bterrmaxnumnoseed", "<li>Si possono scaricare al massimo<b>**maxfile**</b> file senza fare da seeder.<br> ");
define("_bterrmaxdownloadsize","<li>Non si pu� scaricare dopo aver superato il limit di <b>**maxsize**</b> totali.<br>");
define("_btfinalerrmsg1","In questo momento dal tuo ip <b>**ip**</b> (solo tu lo leggi) risulta che tu (o tutti gli utenti della tua LAN) hai/avete superato il limite <b>libero</b> di download concesso da questo server!<br>I limiti di questo server sono:<ol>");
define("_btfinalerrmsg2","</ol>Per continuare a scaricare <b>senza limiti</b> devi rispettare le seguenti regole:<ol>");
define("_btfinalerrmsg3","</ol><p>Fare da seeder significa eseguire uno o pi� TORRENT di cui si ha gi� il <b>file completo al 100%</b> sul proprio disco specificando come destinazione il proprio file completo (in nessun caso il file verr� modificato o cancellato).<br></p><p>Puoi anche fare da seeder condividendo un tuo file non presente in archivio caricando sul server il .torrent corrispondente dalla sezione <a href='modules.php?name=**name**&file=upload'>UPLOAD</a> e poi lanciandolo.</p><p>Infine puoi semplicemente aspettare di finire i tuoi attuali download che automaticamente diventeranno seeder se NON CHIUDERAI la finestra Bit Torrent.</p><p>Quando rispettai le regole dei server non avrai limiti ai file che puoi scaricare</p>");
define("_bterrorprivate","Questo file � privato, hai gi� inviato una richiesta di accesso ai file a questo proprietario. Finch� il proprietario non accetter� la tua richiesta non potrai scaricare nessun file da lui condiviso.");
define("_btrefused","Il proprietario ha rifiutato la tua richiesta di scaricare, non puoi inviargli ulteriori richieste.");
define("_btreqsent","E' stata inviata al proprietario di questo file un email per richiedere il permesso di accedere ai sui file, riceverai un'email quando il permesso verr� concesso.");

//TESTI CHE COMPAIONO IN EDIT.PHP
define("_btedittorrent","Modifica Torrent \"");
define("_bterreditnoowner","<h1>Accesso Negato</h1>\n<p>Solo il proprietario e gli Amministratori possono apportare modifiche</p>\n");
define("_btbanned","Bannato");
define("_btcancel","Annulla");
define("_btdelcommand","Non modificare il Torrent, ma <input type=\"submit\" value=\"CANCELLALO!\" />\n");
define("_btsure","S�: sono sicuro di volerlo fare");

//TESTI CHE COMPAIONO IN MYTORRENTS.PHP
define("_btallauthorized","Tutti gli utenti sono stati autorizzati");
define("_btauthorized","L'utente selezionato � stato autorizzato");
define("_bthasauthorized","L'utente ti ha autorizzato a scaricare i file che condivide");
define("_btnowcandownload","Da adesso puoi scaricare tranquillamente TUTTI i file di QUESTO utente.\nProteggiamo la tua privacy.");
define("_btauthmailsubj","Autorizzazione accesso file BIT TORRENT");
define("_btauthorizationrequested","I seguenti utenti hanno fatto richiesta di poter scaricare i file da te inseriti:");
define("_btnotorrents","Non ci sono Torrent");
define("_btnotorrentuploaded","Non hai caricato alcun Torrent finora");

//TESTI CHE COMPAIONO IN TAKECOMMENT.PHP
define("_btcommentkeyfound","Abbiamo effettuato una ricerca utilizzando le parole contenute nel commento. Il sistema considera che le seguenti parole potrebbero essere oggetto di attivit� illegali:<ol>");
define("_btcommentkeyfound2","</ol><p>Siamo consapevoli del fatto che il commento potrebbe essere del tutto legale, ci scusiamo dell'inconveniente e ti invitiamo a utilizzare altre parole. Questo � un filtro automatico, e non � detto che sia sempre dalla parte della ragione</p>");
define("_bttorrentmailbody","Ciao, ricevi questa email perch� ne hai fatta espressa richiesta sul servizio BIT TORRENT\nriguardo il TORRENT **nome**\n\nPuoi visualizzare questo commento facendo click su:\n\n**url_site**/modules.php?name=**name**&file=details&id=**id**&viewcomm=**newid**&sn=u#comm**newid**\n\n\nPer visualizzare il link devi essere autenticato sul sito.\n\nNon riceverai altre email riguardo questo Torrent finch� non visualizzerai i commenti.\n\n\nPer non ricevere ulteriori notifiche riguardo i commenti di questo Torrent fai click su:\n**url_site**/modules.php?name=**name**&file=details&id=**id**&cn=n");
define("_btcommentinserted","Commento inserito correttamente, tra 3 secondi verrai ridiretto sulla scheda del file.<br>Se non dovessi essere ridiretto puoi raggiungere la <a href=\"modules.php?name=**name**&file=details&id=**id**&viewcomm=**newid**#comm**newid**\">pagina da questo link</a>");

//TESTI CHE COMPAIONO IN TAKEEDIT.PHP
define("_btmissingformdata","Mancano i dati in input!");
define("_bteditfailed","Modifica non riuscita");
define("_bteditdenied","Impossibile modificare Torrent altrui");
define("_btreturl","File modificato correttamente, tra 3 secondi verrai ridiretto sulla scheda del file. Se non dovessi essere ridiretto puoi raggiungere la <a href=\"**returl**\">pagina da questo link</a>");

//TESTI CHE COMPAIONO IN TAKERATE.PHP
define("_btratefailed","Votazione fallita!");
define("_btinvalidrating","Voto non valido");
define("_btidnotorrent","ID Errato. Torrent inesistente");
define("_btnovoteowntorrent","Non puoi votare i tuoi Torrent");
define("_btalreadyrated","Torrent gi� votato");
define("_btvotedone","Votazione riuscita correttamente, tra 3 secondi verrai ridiretto sulla scheda del file.<br>Se non dovessi essere ridiretto puoi raggiungere la <a href=\"modules.php?name=**name**&details.php&id=**id**&rated=1\">pagina da questo link</a>");

//TESTI CHE COMPAIONO IN TAKEUPLOAD.PHP
define("_btuploadfailed","Upload fallito!");
define("_btemptyfname","Nome file vuoto");
define("_btinvalidfname","Nome file non valido");
define("_btfnamenotorrent","Questo file non � un Torrent (.torrent)");
define("_btferror","Errore file");
define("_bterrnofileupload","Errore grave nel file in upload.");
define("_btemptyfile","File vuoto");
define("_btnobenc","File danneggiato. Sicuro che � davvero un Torrent?");
define("_btnodictionary","Dizionario Torrent assente");
define("_btdictionarymisskey","Chiavi del Dizionario Torrent mancanti");
define("_btdictionaryinventry","Dati non validi nel Dizionario Torrent");
define("_btdictionaryinvetype","Tipo di dati nel Dizionario Torrent non validi");
define("_btinvannounce","URL Announce non valido. Deve essere ");
define("_btactualannounce","Il tracker che hai specificato � ");
define("_bttrackerdisabled","Il nostro tracker � stato disabilitato, <a href='modules.php?name=**name**&file=upload_help'>leggi la guida</a> per sapere come poter inserire torrent con tracker esterni");
define("_btinvpieces","Frazioni Torrent non valide");
define("_btmissinglength","Mancano i file e la loro grandezza");
define("_btnofilesintorrent","File del Torrent mancanti");
define("_btfnamerror","Nome file non valido");
define("_btfilenamerror","Errore nel nome del file");
define("_bttorrenttoosmall","<p>Non � possibile fare condividere un file pi� piccolo di <b>");
define("_bttorrenttoosmall2","</b></p><p>Il torrent che hai inviato riguardava un file grande <b>");
define("_btmaxuploadexceeded","Non � possibile fare l'upload pi� di **maxupload** ogni 24 ore.");
define("_btnumfileexceeded","<p>Non � possibile fare l'upload di una quantit� di file superiore a <b>**maxupload**</b> in 24 ore.</p><p>Al momento hai gi� fatto l'upload di <b>**rownum**</b> file per un totale di <b>**totsize**</b>");
define("_btsearchdupl","E' stata effettuata una ricerca utilizzando le parole del nome del file e la dimensione, il sistema considera che i seguenti file potrebbero essere fonti uguali gi� presenti:<ol>");
define("_btduplinfo","<p>Se il tuo file corrisponde ad uno di questi ti preghiamo di lanciare un .torrent gi� esistente, grazie!</p>");
define("_btsocktout","ERRORE: Socket time-out");
define("_bttrackernotresponding","Il tracker specificato non risponde.\n Devi verificare di aver scritto correttamente il nome del tracker (NIENTE SPAZI) e che esso sia in funzione. Tracker specificato:");
define("_bttrackerdata","Il tracker esterno ha risposto con dei dati non corretti. Potrebbero esserci problemi di rete sul tracker. Ti invitiamo a riprovare pi� tardi.");
define("_btuploadcomplete","Upload effettuato correttamente, tra 3 secondi verrai ridiretto sulla scheda del file. Ricordati di lanciare il .TORRENT o il tuo file non verr� visualizzato pubblicamente!<br>Se non dovessi essere ridiretto puoi raggiungere la <a href=\"modules.php?name=**name**&file=details&id=**id**&uploaded=1\">pagina da questo link</a>");
?>