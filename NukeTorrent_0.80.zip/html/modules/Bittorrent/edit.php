<?
$index = 0;
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;
if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
if (!is_user($user)) {
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}
loggedinorreturn();

include("header.php");
OpenTable();

if (!mkglobal("id"))
        die();

$id = 0 + $id;
if (!$id)
        die();

$res = $db->sql_query("SELECT * FROM torrent_torrents WHERE id = '$id'") or bterror("SELECT * FROM torrent_torrents WHERE id = '$id'");
$row = $db->sql_fetchrow($res);
if (!$row)
        die();
global $CURUSER;
stdhead(_btedittorrent . $row["name"] . "\"");
if ($CURUSER["id"] != $row["owner"] AND (!is_admin($admin))) {
        print(_bterreditnoowner);
}
else {
?>
<form method="post" action="modules.php?name=<?=$name?>&file=takeedit">
<input type="hidden" name="id" value="<?=$id?>">
<?
        if (isset($returnto))
                print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($returnto) . "\" />\n");
        echo "<TABLE>";
        tr(_bttorrentname, "<input type=\"text\" name=\"namex\" value=\"" . htmlspecialchars($row["name"]) . "\" size=\"80\" />", 1);
        tr(_btdescription, "<textarea name=\"descr\" rows=\"10\" cols=\"80\">" . htmlspecialchars($row["ori_descr"]) . "</textarea>", 1);

        $s = "<select name=\"type\">\n";

        $cats = genrelist();
        foreach ($cats as $subrow) {
                $s .= "<option value=\"" . $subrow["id"] . "\"";
                if ($subrow["id"] == $row["category"])
                        $s .= " selected=\"selected\"";
                $s .= ">" . htmlspecialchars($subrow["name"]) . "</option>\n";
        }
        $s .= "</select>\n";
        tr(_bttype, $s, 1);
        tr(_btvisible, "<input type=\"checkbox\" name=\"visible\"" . (($row["visible"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" /> Visible on main page<br />Note that the torrent will automatically become visible when there's a seeder, and will become automatically invisible (dead) when there has been no seeder for a while. Use this switch to speed the process up manually. Also note that invisible (dead) torrents can still be viewed or searched for, it's just not the default.", 1);

        $evidence = "";
        if ($row["evidence"]==1){
                $evidence="checked";
        }
        tr(_btupevidence, "<input type=\"checkbox\" name=\"evidence\" value=\"1\" $evidence> Selezionare SOLO nel caso in cui il file sia veramente <b>INTERESSANTE PER LA MAGGIORANZA DEGLI UTENTI</b> e si garantisce un seeder sicuro al giorno per almeno una settimana, e SEVERAMENTE VIETATO l'abuso di questa opzione. \n", 1);

        $privacy = "";
        if ($row["ownertype"]==1){
                $privacy=" selected";
        }
        tr(_btowner, "<select name=\"ownertype\">\n<option value=\"0\">Visualizza nick</option><option value=\"1\"".$privacy.">Privacy</option><option value=\"2\">Anonimato</option></select> L'opzione \"Visualizza nick\" permetter� agli utenti di visualizzare il proprio nick, \"Privacy\" lo nasconde lasciando comunque attiva le funzionalit� di modifica/cancellazione nei propri torrent, \"Anonimato\" impedisce qualsiasi collegamento con chi fa upload e quindi non visualizzer� il proprio nick e non sar� possibile nessun tipo di modifica al file\n", 1);

        $res2 = $db->sql_query("SELECT count(*) as tot FROM torrent_comments_notify WHERE user = '".$CURUSER["id"]."' AND torrent='$id'") or bterror("SELECT count(*) as tot FROM torrent_comments_notify WHERE user = '".$CURUSER["id"]."' AND torrent='$id'");
        $row2 = $db->sql_fetchrow($res2);
        $notify = "";
        if ($row2["tot"]==1){
                $notify = "checked";
        }
        tr(_btnotify, "<input type=\"checkbox\" name=\"notify\" value=\"1\" $notify> Si ricever� un'email quando verr� aggiunto un commento.\n", 1);

        if (is_admin($admin))
                tr(_btbanned, "<input type=\"checkbox\" name=\"banned\"" . (($row["banned"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" /> Banned", 1);

        print("<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\""._btsend."\" /> <input type=\"reset\" value=\""._btcancel."\"></td></tr>\n");
        print("</TABLE>");
        print("</form>\n");
        print("<hr />\n");
        print("<p>\n");
        print("<form method=\"post\" action=\"modules.php?name=$name&file=delete\">\n");
        print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
        if (isset($returnto))
                print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($returnto) . "\" />\n");
        print(_btdelcommand);
        print(_btsure."<input type=\"checkbox\" name=\"sure\" value=\"1\" />\n");
        print("</form>\n");
        print("</p>\n");
}

CloseTable();
include("footer.php");
?>