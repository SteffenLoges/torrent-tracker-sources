<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 1;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
global $name, $db, $torrent_global_privacy, $file;
if (!is_user($user)){
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}

include("header.php");
OpenTable();
function bark($msg) {
        genbark($msg, _bteditfailed);
}

if (!mkglobal("id:namex:descr:type"))
        bark(_btmissingformdata);

loggedinorreturn();

$res = $db->sql_query("SELECT owner, filename, save_as FROM torrent_torrents WHERE id = '$id'") or bterror("SELECT owner, filename, save_as FROM torrent_torrents WHERE id = '$id'");
$row = $db->sql_fetchrow($res);
if (!$row)
        die();

if ($CURUSER["id"] != $row["owner"] AND !is_admin($admin))
        bark(_bteditdenied);

$updateset = array();

$fname = $row["filename"];
preg_match('/^(.+)\.torrent$/si', $fname, $matches);
$shortfname = $matches[1];
$dname = $row["save_as"];

$updateset[] = "name = " . sqlesc($namex);
$updateset[] = "search_text = " . sqlesc(searchfield("$shortfname $dname $torrent"));
$updateset[] = "descr = " . sqlesc(parsedescr($descr));
$updateset[] = "ori_descr = " . sqlesc($descr);
$updateset[] = "category = '" . (0 + $type)."'";
if ($CURUSER["admin"] == "yes") {
        if ($_POST["banned"]) {
                $updateset[] = "banned = 'yes'";
                $_POST["visible"] = 0;
        }
        else
                $updateset[] = "banned = 'no'";
}

$updateset[] = "visible = '" . ($_POST["visible"] ? "yes" : "no") . "'";

global $evidence, $ownertype;
if ($evidence!=1) $evidence=0;
$updateset[] = "evidence = '$evidence'";

if ($ownertype<0 || $ownertype>2) $ownertype = 0;
if ($ownertype==2) $updateset[] = "owner = 0";
$updateset[] = "ownertype = '$ownertype'";

$sql = "UPDATE torrent_torrents SET " . join(",", $updateset) . " WHERE id = '$id'";
$db->sql_query($sql) or bterror($sql);

$returl = "modules.php?name=$name&file=details&id=$id&edited=1";
if (isset($_POST["returnto"]))
        $returl .= "&returnto=" . urlencode($_POST["returnto"]);

echo "<meta http-equiv=\"refresh\" content=\"3;url=$returl\">";
echo str_replace("**returl**",$returl,_btreturl);

global $notify;
if ($notify==1){
        $sql = "INSERT INTO torrent_comments_notify (torrent, user, can_send) VALUES ('$id', '".$CURUSER["id"]."', 1)";
}else{
        $sql = "DELETE FROM torrent_comments_notify WHERE torrent='$id' AND user='".$CURUSER["id"]."'";
}
$db->sql_query($sql);

CloseTable();
include("footer.php");
?>