<?
$name = "Bittorrent";

//NOT MODIFY AFTER

$nologin = true;
require_once("config.php");

$new_include_dir = "../../";
set_include_path(get_include_path() . ":" . $new_include_dir);
//Please use PHP 4 >= 4.3.0, PHP 5 or modify to hand

require_once("mainfile.php");
require_once("include/bittorrent.php");

$sql = "SELECT seeders AS complete, times_completed AS downloaded, leechers AS incomplete FROM torrent_torrents WHERE info_hash='".str_replace("'", "''", $info_hash)."'";
if(! $res = $db->sql_query($sql) ) die("Errore $sql");
if(! $dati = $db->sql_fetchrow($res) ) die("Dati non presenti");

echo "d5:filesd20:". $info_hash ."d8:completei". $dati[complete] ."e10:downloadedi". $dati[downloaded] ."e10:incompletei". $dati[incomplete] ."eeee";

?>