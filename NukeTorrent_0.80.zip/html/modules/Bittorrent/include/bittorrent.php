<?/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;
global $name;
if (!eregi("modules.php", $_SERVER['PHP_SELF']) AND !eregi("announce.php", $_SERVER['PHP_SELF']) AND !eregi("scrape.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

if( eregi("announce.php", $_SERVER['PHP_SELF']) OR eregi("scrape.php", $_SERVER['PHP_SELF']) ){
        require_once("config.php");

} else {
        require_once("modules/$name/config.php");
}

function bterror($sql) {
        global $db;
        $err = Array();
        $err = $db->sql_error();
        echo(_btsqlerror1.$sql);
        echo("<BR>");
        echo(_btsqlerror2.$err["code"]);
        echo(_btsqlerror3.$err["message"]);
        die();
}

function userlogin(){
        global $user, $db, $prefix, $id_user, $admin;

        global $CURUSER;
        unset($GLOBALS["CURUSER"]);
        unset($CURUSER);

        if (is_user($user)){
                //Dati user
                $userdata = base64_decode($user);
                $userdata = explode(":", $userdata);
                $id_user = $userdata[0];
        }else{
                return;
        }

        $sql = "SELECT user_email as email, user_id as id, username FROM ".$prefix."_users WHERE user_id = '$id_user'";
        if (! $res = $db->sql_query($sql) ) die("SQLError $sql");

        $row = $db->sql_fetchrow($res);
        if (!$row)
                return;

        $GLOBALS["CURUSER"] = $row;
        if (is_admin($admin)) $CURUSER["admin"]="yes";
}

function autoclean() {
        global $autoclean_interval;

        $now = time();
        $docleanup = 0;

        $res = $db->sql_query("SELECT value_u FROM torrent_avps WHERE arg = 'lastcleantime'");
        $row = $db->sql_fetchrow($res);
        if (!$row) {
                $db->sql_query("INSERT INTO torrent_avps (arg, value_u) VALUES ('lastcleantime',$now)");
                return;
        }
        $ts = $row[0];
        if ($ts + $autoclean_interval > $now)
                return;
        $ret = $db->sql_query("UPDATE torrent_avps SET value_u=$now WHERE arg='lastcleantime' AND value_u = $ts");
        if (!$db->sql_numrows($ret))
                return;

        docleanup();
}

function unesc($x) {
        if (get_magic_quotes_gpc())
                return stripslashes($x);
        return $x;
}

function mksize($s) {
        $x = 3;
        $a = array("","k","M","G");
        for (;;) {
                $v = pow(1024, $x);
                if (!$x || $s >= $v) {
                        $ss = sprintf("%.".$x."f", ($s / $v));
                        $xx = $ss . " " . $a[$x] . "B";
                        break;
                }
                $x--;
        }
        return $xx;
}

function deadtime() {
        global $announce_interval;
        return time() - floor($announce_interval * 1.3);
}

function mkprettytime($s) {
        if ($s < 0)
                $s = 0;
        $t = array();
        foreach (array("60:sec","60:min","24:hour","0:day") as $x) {
                $y = explode(":", $x);
                if ($y[0] > 1) {
                        $v = $s % $y[0];
                        $s = floor($s / $y[0]);
                }
                else
                        $v = $s;
                $t[$y[1]] = $v;
        }

        if ($t["day"])
                return $t["day"] . " day(s), " . sprintf("%02d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
        if ($t["hour"])
                return sprintf("%d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
        if ($t["min"])
                return sprintf("%d:%02d", $t["min"], $t["sec"]);
        return $t["sec"] . " secs";
}

function mkglobal($vars) {
        if (!is_array($vars))
                $vars = explode(":", $vars);
        foreach ($vars as $v) {
                if (isset($_GET[$v]))
                        $GLOBALS[$v] = unesc($_GET[$v]);
                elseif (isset($_POST[$v]))
                        $GLOBALS[$v] = unesc($_POST[$v]);
                else
                        return 0;
        }
        return 1;
}

function tr($x,$y,$noesc=0) {
        if ($noesc)
                $a = $y;
        else {
                $a = htmlspecialchars($y);
                $a = str_replace("\n", "<br />\n", $a);
        }
        print("<tr><td class=\"heading\" valign=\"top\" align=\"right\">$x</td><td valign=\"top\">$a</td></tr>\n");
}

function validfilename($name) {
        return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
}

function validemail($email) {
        return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
}

function sqlesc($x) {
        return "'".str_replace("'", "''", $x)."'";
}

function sqlwildcardesc($x) {
        return str_replace(array("%","_"), array("\\%","\\_"), str_replace("'", "''", $x));
}

function urlparse($m) {
        $t = $m[0];
        if (preg_match(',^\w+://,', $t))
                return "<a href=\"$t\">$t</a>";
        return "<a href=\"http://$t\">$t</a>";
}

function parsedescr($d) {
        $pd = str_replace(array("\n", "\r"), array("<br />\n", ""), htmlspecialchars($d));
        $pd = preg_replace_callback('�(\w+://([^\s/:@]+(:[^\s/:@]++)?@)?|\bwww\.)[\w.-]+(:\d+)?(/[-\w=./?&%+#;|@]*)?[0-9a-z/]�is', "urlparse", $pd);
        return $pd;
}
global $name;
function stdhead($title = "") {
        global $CURUSER, $currentlang, $name;


        OpenTable2();
?>
<table width="100%" cellspacing="12"><tr>
<td align="center" class="navigation"><a href="modules.php?name=<?=$name?>"><?=_btindex?></a></td>
<td align="center" class="navigation"><a href="modules.php?name=<?=$name?>&file=upload"><?=_btupload?></a></td>
<? if (!$CURUSER) { ?>
<td align="center" class="navigation"><a href="modules.php?name=Your_Account"><?=_btlogin?></a> / <a href="modules.php?name=Your_Account&op=new_user"><?=_btsignup?></a></td>
<? } else { ?>
<td align="center" class="navigation"><a href="modules.php?name=<?=$name?>&file=mytorrents"><?=_btpersonal?><?= htmlspecialchars($CURUSER["username"]) ?></a></td>
<? }
global $QUERY_STRING;
?>
<td align="center" class="navigation"><a href="modules.php?name=<?=$name?>&file=rulez"><?=_btrulez?></a></td>
<td align="center" class="navigation"><a href="modules.php?name=Forums"><?=_btforums?></a></td>
<td align="center" class="navigation"><a href="modules.php?name=<?=$name?>&file=index_help"><?=_bthelp?></a></td>
<td><a href="<?="modules.php?".$QUERY_STRING?>"><?=_btrefresh?></a></td>
<td><a href="btbackend.php"><img src="modules/<? echo $name ?>/pic/xml.gif" border="0"></a></td>
</tr>
</tr></table>
<?
        echo "<center><a href='modules.php?name=$name&file=index_help'>"._btadvinst."</a></center>";
        CloseTable2();
}

function stdfoot() {
        print("</body></html>\n");
}

function genbark($x,$y) {
        stdhead($y);
        print("<h2>" . htmlspecialchars($y) . "</h2>\n");
        print("<p>" . htmlspecialchars($x) . "</p>\n");
        stdfoot();
        exit();
}

function mksecret($len = 20) {
        $ret = "";
        for ($i = 0; $i < $len; $i++)
                $ret .= chr(mt_rand(0, 255));
        return $ret;
}

function httperr($code = 404) {
        header("HTTP/1.0 404 Not found");
        print("<h1>Not Found</h1>\n");
        print("<p>Sorry pal :(</p>\n");
        exit();
}

function loggedinorreturn() {
        global $CURUSER;
        if (!$CURUSER) {
                OpenTable();
                echo _btaccessden;
                CloseTable();
                include("footer.php");
                exit();
        }
}

function deletetorrent($id) {
        global $torrent_dir, $db;
        $db->sql_query("DELETE FROM torrent_torrents WHERE id = '$id'");
        foreach(explode(".","peers.files.comments.ratings") as $x)
                if(! $db->sql_query("DELETE FROM torrent_$x WHERE torrent = '$id'") )
                        bterror("DELETE FROM torrent_$x WHERE torrent = '$id'");
        unlink("$torrent_dir/$id.torrent");
}

function pager($rpp, $count, $href, $opts = array()) {
        $pages = ceil($count / $rpp);

        if (!$opts["lastpagedefault"])
                $pagedefault = 0;
        else {
                $pagedefault = floor(($count - 1) / $rpp);
                if ($pagedefault < 0)
                        $pagedefault = 0;
        }

        if (isset($_GET["page"])) {
                $page = 0 + $_GET["page"];
                if ($page < 0)
                        $page = $pagedefault;
        }
        else
                $page = $pagedefault;

        $pager = "";

        $mp = $pages - 1;
        $as = "<b>&lt;&lt;&nbsp;Prev</b>";
        if ($page >= 1) {
                $pager .= "<a href=\"{$href}page=" . ($page - 1) . "\">";
                $pager .= $as;
                $pager .= "</a>";
        }
        else
                $pager .= $as;
        $pager .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        $as = "<b>Next&nbsp;&gt;&gt;</b>";
        if ($page < $mp && $mp >= 0) {
                $pager .= "<a href=\"{$href}page=" . ($page + 1) . "\">";
                $pager .= $as;
                $pager .= "</a>";
        }
        else
                $pager .= $as;

        if ($count) {
                $pagerarr = array();
                $dotted = 0;
                $dotspace = 3;
                $dotend = $pages - $dotspace;
                $curdotend = $page - $dotspace;
                $curdotstart = $page + $dotspace;
                for ($i = 0; $i < $pages; $i++) {
                        if (($i >= $dotspace && $i <= $curdotend) || ($i >= $curdotstart && $i < $dotend)) {
                                if (!$dotted)
                                        $pagerarr[] = "...";
                                $dotted = 1;
                                continue;
                        }
                        $dotted = 0;
                        $start = $i * $rpp + 1;
                        $end = $start + $rpp - 1;
                        if ($end > $count)
                                $end = $count;
                        $text = "$start&nbsp;-&nbsp;$end";
                        if ($i != $page)
                                $pagerarr[] = "<a href=\"{$href}page=$i\">$text</a>";
                        else
                                $pagerarr[] = "<b>$text</b>";
                }
                $pagerstr = join(" | ", $pagerarr);
                $pagertop = "<p align=\"center\">$pager<br />$pagerstr</p>\n";
                $pagerbottom = "<p align=\"center\">$pagerstr<br />$pager</p>\n";
        }
        else {
                $pagertop = "<p align=\"center\">$pager</p>\n";
                $pagerbottom = $pagertop;
        }

        $start = $page * $rpp;

        return array($pagertop, $pagerbottom, "LIMIT $start,$rpp");
}

function downloaderdata($res) {
        global $db;
        $rows = array();
        $ids = array();
        $peerdata = array();
        while ($row = $db->sql_fetchrow($res)) {
                $rows[] = $row;
                $id = $row["id"];
                $ids[] = $id;
                $peerdata[$id] = array(downloaders => 0, seeders => 0, comments => 0);
        }

        if (count($ids)) {
                $allids = implode(",", $ids);
                if(! $res = $db->sql_query("SELECT COUNT(*) AS c, torrent, seeder FROM torrent_peers WHERE torrent IN ('$allids') GROUP BY torrent, seeder") )
                        bterror("SELECT COUNT(*) AS c, torrent, seeder FROM torrent_peers WHERE torrent IN ('$allids') GROUP BY torrent, seeder");
                while ($row = $db->sql_fetchrow($res)) {
                        if ($row["seeder"] == "yes")
                                $key = "seeders";
                        else
                                $key = "downloaders";
                        $peerdata[$row["torrent"]][$key] = $row["c"];
                }
                if(! $res = $db->sql_query("SELECT COUNT(*) AS c, torrent FROM torrent_comments WHERE torrent IN ('$allids') GROUP BY torrent") )
                        bterror("SELECT COUNT(*) AS c, torrent FROM torrent_comments WHERE torrent IN ('$allids') GROUP BY torrent");
                while ($row = $db->sql_fetchrow($res)) {
                        $peerdata[$row["torrent"]]["comments"] = $row["c"];
                }
        }

        return array($rows, $peerdata);
}

function commenttable($rows) {
        global $row;
/*        print("<table border=\"1\" align=\"center\" cellpadding=\"15\">\n");
        $count = 0;
        foreach ($rows as $row) {
                print("<tr>\n");
                print("<td>" . htmlspecialchars($row["added"]) . "</td>\n");
                if (isset($row["username"]))
                        print("<td align=\"right\"><a href=\"modules.php?name=Your_Account&op=userinfo&username=".$row["username"]."\" name=\"comm" . $row["id"] . "\">" . htmlspecialchars($row["username"]) . "</a></td>\n");
                else
                        print("<td><a name=\"comm" . $row["id"] . "\"><i>(orphaned)</i></a></td>\n");
                print("</tr>\n");
                print("<tr>\n");
                print("<td colspan=\"2\">" . $row["text"] . "</td>\n");
                print("</tr>\n");
                $count++;
        }
        print("</table>");
*/
        print("<p>\n");
        $count = 0;
        foreach ($rows as $row) {
                OpenTable();
                print($row["text"]);
                print("<br>"._btaddtime . htmlspecialchars($row["added"]) . "\n");
                if (isset($row["username"]))
                        print(_btby." <a href=\"modules.php?name=Your_Account&op=userinfo&username=".$row["username"]."\" name=\"comm" . $row["id"] . "\">" . htmlspecialchars($row["username"]) . "</a>\n");
                else
                        print(" da <a name=\"comm" . $row["id"] . "\"><i>(orphaned)</i></a>\n");
                $count++;
                CloseTable();
        }
        echo "</p>";
}

function searchfield($s) {
        return preg_replace(array('/[^a-z0-9]/si', '/^\s*/s', '/\s*$/s', '/\s+/s'), array(" ", "", "", " "), $s);
}

function genrelist() {
        global $db;
        $ret = array();
        if(! $res = $db->sql_query("SELECT id, name FROM torrent_categories ORDER BY sort_index, id") )
                bterror("SELECT id, name FROM torrent_categories ORDER BY sort_index, id");
        while ($row = $db->sql_fetchrow($res))
                $ret[] = $row;
        return $ret;
}

function linkcolor($num) {
        if (!$num)
                return "red";
        if ($num == 1)
                return "yellow";
        return "green";
}

function ratingpic($num) {
        global $pic_base_url;
        $r = round($num * 2) / 2;
        if ($r < 1 || $r > 5)
                return;
        return "<img src=\"$pic_base_url$r.gif\" border=\"0\" alt=\"rating: $num / 5\" />";
}

function torrenttable($res, $variant = "index") {
        global $db, $name;
        global $pic_base_url, $bt, $name, $torrent_global_privacy, $CURUSER, $file;
?>
<table border="0" cellpadding="3" width="100%">
<tr>
<th align="center"><?=$bt_type?></td>
<th align="center" width='48%'><?=$bt_name?> <a href='modules.php?name=<?=$name?>&file=index_help#function'><img src='modules/<?=$name?>/pic/help.gif' align='midle' border='0' alt='_btlegenda'></a></td>
<?

        if ($variant == "mytorrents")
                print("<th align=\"center\">"._btvisible."</td>\n");

echo "<th align='center'>"._btcomments."</td>
<th align='center' width='16%'>"._btstats."</td>
<th align='center' width='20%'>"._btnet."</td>
<th align='center' width='16%'>"._btsource."</td>";

        print("</tr>\n");

        while ($row = $db->sql_fetchrow($res)) {
                $id = $row["id"];
                print("<tr>\n");

                print("<td align=\"center\">");
                if (isset($row["cat_name"])) {
                        print("<a href=\"modules.php?name=$name&file=index&cat=" . $row["category"] . "\">");
                        if (isset($row["cat_pic"]) && $row["cat_pic"] != "")
                                print("<img border=\"0\" src=\"$pic_base_url" . $row["cat_pic"] . "\" alt=\"" . $row["cat_name"] . "\" />");
                        else
                                print($row["cat_name"]);
                        print("</a>");
                }
                else
                        print("-");
                print("</td>\n");

                echo "<td><table><tr><td>";
                //Type of torrent (privacy)
/*                if($row["tracker"]!=""){
                        if($row["owner"]==$CURUSER["id"]){
                                echo "<img src='".$pic_base_url."global_your.gif' border=\"0\" alt=\"_btyourfilext\">";
                        }else{
                                echo "<img src='".$pic_base_url."global.gif' border=\"0\" alt=\"_btexternal\">";
                        }
                }else*/
                if($row["tracker"]!="" || $row["type"]=="link"){
                }elseif ($row["owner"]==$CURUSER["id"]){
                                echo "<img src='".$pic_base_url."open_your.gif' border=\"0\" alt=\"_btyourfile\">";
                }elseif ($row["evidence"] != 0){
                        if (!$torrent_global_privacy ||$row["attivato"]=="0"){
                                echo "<img src='".$pic_base_url."sticky.gif' border=\"0\" alt=\"_btsticky\">";
                        }elseif ($row["attivato"]=="1"){
                                echo "<img src='".$pic_base_url."look_sticky.gif' border=\"0\" alt=\"_btauthreq\">";
                        }else{
                                echo "<img src='".$pic_base_url."look_sticky.gif' border=\"0\" alt=\"_btauthforreq\">";
                        }
                }else{
                        if(!$torrent_global_privacy||$row["attivato"]=="0"){
                                echo "<img src='".$pic_base_url."open.gif' border=\"0\" alt=\"_btdown\">";
                        }elseif ($row["attivato"]=="1"){
                                echo "<img src='".$pic_base_url."lock_request.gif' border=\"0\" alt=\"_btauthreq\">";
                        }else{
                                echo "<img src='".$pic_base_url."lock.gif' border=\"0\" alt=\"_btauthforreq\">";
                        }
                }
                echo"</td>";

                //Name
                $dispname = "<b>" . htmlspecialchars($row["name"]) . "</b>";
                print("<td><a href=\"modules.php?name=$name&file=details&");
                if ($variant == "mytorrents")
                        print("returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;");
                print("id=$id");
                if ($variant == "index")
                        print("&amp;hit=1");
                $dispname = str_replace("_", " ", $dispname);
                $dispname = str_replace(".", " ", $dispname);

                print("\">$dispname</a><br>");

                //Download torrent
                if ($variant == "index")
                        if ($row["tot_peer"]>0)
                                print("Download: <a href=\"modules.php?name=$name&file=download&id=".$row["id"] ."\">"._bttorrent."</a> \n");
                elseif ($variant == "mytorrents")
                        print("<a href=\"modules.php?name=$name&file=edit&returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;id=" . $row["id"] . "\">edit</a> \n");

                //Size
                echo mksize($row["size"]). " ";
                //File
                if ($row["type"] == "single" || $row["numfiles"]<=1)
                        print($row["numfiles"]." file");
                else {
                        if ($variant == "index")
                                print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;hit=1&amp;filelist=1\">" . $row["numfiles"] . "</a></b> file\n");
                        else
                                print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;filelist=1#filelist\">" . $row["numfiles"] . "</a></b> file");
                }


                //Date and by
                print("<br>".$row["added"]." by ");
                if ($variant == "index")
                        if (isset($row["username"]) && $row["ownertype"]==0)
                                print("<a href=\"modules.php?name=Your_Account&op=userinfo&username=".$row["username"]."\">" . htmlspecialchars($row["username"])."</a>\n");
                        else
                                print("(<i>"._btunknown."</i>)\n");

                echo "</td></tr></table></td>\n";


                if ($variant == "mytorrents") {
                        print("<td align=\"center\">");
                        if ($row["visible"] == "no")
                                print("<b>no</b>");
                        else
                                print("yes");
                        print("</td>\n");
                }

                print("<td align=\"center\">");
                if (!isset($row["rating"]))
                        print("---");
                else {
                        $rating = round($row["rating"] * 2) / 2;
                        $rating = ratingpic($row["rating"]);
                        if (!isset($rating))
                                print("---");
                        else
                                print($rating);
                }
                echo "<br>";
                if (!$row["comments"])
                        print($row["comments"] . "\n");
                else {
                        if ($variant == "index")
                                print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;hit=1&amp;tocomm=1\">" . $row["comments"] . "</a></b>\n");
                        else
                                print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;page=0#startcomments\">" . $row["comments"] . "</a></b>\n");
                }
                print("</td>\n");

                //Statistic
                if($row["type"]=="link")
                        echo "<td align=\"right\">"._btview.": ".$row["views"]."</td>\n";
                else
                        echo "<td align=\"right\">"._btview.": ".$row["views"]."<br>"._bthits.": ".$row["hits"]."<br>"._btsnatch.": <b>". $row["times_completed"] . "</b></td>\n";

                $tot = $row["tot_peer"];
                echo "<td>";
                if ($row["seeders"]==0 && $row["leechers"]<=5){
                        if ($tot==0 && ($row[ed2k]>"" || $row[magnet]>"" || $row["type"]=="link")){
                                echo"<img src='".$pic_base_url."quest.gif' border=\"0\" alt=\"$bt_unknown\" align=left>";
                                $extern_print = _btalternatesource;
                        }else{
                                echo"<img src='".$pic_base_url."red.gif' border=\"0\" alt=\"$bt_difdownload\" align=left>";
                                $extern_print = _bthard;
                        }
                }elseif( ($row["seeders"]==1 && $row["leechers"]<=5) || ($row["seeders"]==0 && $row["leechers"]<=10) ){
                        echo"<img src='".$pic_base_url."yellow.gif' border=\"0\" alt=\"$bt_probdownload\" align=left>";
                        $extern_print = _btmedium;
                }else{
                        echo"<img src='".$pic_base_url."green.gif' border=\"0\" alt=\"$bt_easydownload\" align=left>";
                        $extern_print = _bteasy;
                }
                if ($row["leechers"]>0 && $row["speed"]>0){
                        $speed_leech = round($row["speed"]/$row["leechers"]);
                        $eta_m = ($row["size"] / $speed_leech)/60; //to minutes
                        $eta = ($eta_m % 60)."m"; //minutes
                        $eta_h = floor($eta_m / 60);
                        if ($eta_h>0) $eta=$eta_h."h ".$eta;
                        $speed_leech=mksize($speed_leech)."/s";
                }else{
                        $speed_leech = "ND";
                        $eta = "ND";
                }

                //Speed tracker
                if($row["tracker"]=="" && $row["type"]!="link")
                        echo _bttorrent.": ".mksize($row["speed"])."/s<br>Leech: ".$speed_leech."<br>ETA: $eta</td>";
                else
                        echo $extern_print;

                if ($tot==0 && ($row[ed2k]>"" || $row[magnet]>"" || $row[type]=="link")){
                        echo "<td align=\"right\">ND</td>";
                }else{
                        echo "<td align=\"right\">Seeder: ";
                        if ($row["seeders"]) {
                                if ($variant == "index")
                                        print("<b><a  href=\"modules.php?name=$name&file=details&id=$id&amp;hit=1&amp;dllist=1&amp;toseeders=1#seeders\">" . $row["seeders"] . "</a></b>\n");
                                else
                                        print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;dllist=1#seeders\">" . $row["seeders"] . "</a></b>\n");
                        }else
                                print("<span>" . $row["seeders"] . "</span>\n");

                        echo "<br>Leecher: ";
                        if ($row["leechers"]) {
                                if ($variant == "index")
                                        print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;hit=1&amp;todlers=1&amp;dllist=1#leechers\">" . $row["leechers"] . "</a></b>\n");
                                else
                                        print("<b><a href=\"modules.php?name=$name&file=details&id=$id&amp;dllist=1#leechers\">" . $row["leechers"] . "</a></b>\n");
                        }else
                                print("<span>" . $row["leechers"] . "</span>\n");

                        echo "<br>TOT: <b>$tot</b></td>";
                }
        }

        print("</table>\n");

        return $rows;
}

function hash_pad($hash) {
        return str_pad($hash, 20);
}

function hash_where($name, $hash) {
        $shhash = preg_replace('/ *$/s', "", $hash);
        return "($name = " . sqlesc($hash) . " OR $name = " . sqlesc($shhash) . ")";
}

function findheader($s) {
        $headers = apache_request_headers();
        foreach ($headers as $header => $content) {
                if (!strcasecmp($header, $s)) {
                        return $content;
                }
        }
        return;
}

function browsercache($expire) {
        $now = time();
        $ifmod = findheader("If-Modified-Since");
        if (isset($ifmod)) {
                $pt = strtotime($ifmod);
                if ($pt != -1 && ($pt + $expire) >= $now) {
                        header("HTTP/1.0 304 Not Modified");
                        exit();
                }
        }

        header("Last-Modified: " . date("r", $now));
        header("Expires: " . date("r", $now + $expire));
}


/*STEALT FUNCTION START*/
        function take_number(&$page, &$index){
                $end_num=strpos($page, "e", $index);
                $element = substr($page, $index, $end_num-$index);
                $index = $end_num;
                return $element;
        }

        function take_string($page, &$index){
                $end_num=strpos($page, ":", $index+1);
                $string_len = substr($page, $index, $end_num-$index);
                $index = $end_num+$string_len;
                return substr($page, $end_num+1, $string_len);
        }

        function ergo(&$page, &$parse_array_tmp, &$index, &$max){
                while( ( ($token = substr($page, $index, 1) )   !="e" ) && ($index<$max) ){

                        if($token=="i"){
                                $index++;
                                $parse_array_tmp[]=take_number($page, $index);
                        }elseif($token>="0" && $token<="9"){
                                $parse_array_tmp[]=take_string($page, $index);
                        }elseif($token=="l"){
                                $index++;
                                $parse_array_2 = array();
                                $parse_array_tmp[] = ergo($page, $parse_array_2, $index, $max);
                        }elseif($token=="d"){
                                $index++;
                                $parse_array_2 = array();
                                $parse_array_2 = ergo($page, $parse_array_2, $index, $max);
                                $count_ar=count($parse_array_2);
                                $parse_array_3 = array();
                                for($pos = 0; $pos<$count_ar; $pos=$pos+2){
                                        $parse_array_3[ $parse_array_2[$pos] ]=$parse_array_2[ $pos+1 ];
                                }
                                $parse_array_tmp[]=$parse_array_3;
                        }else{
                                //Error
                        }
                        $index++;
                }
                return $parse_array_tmp;
        }
/*STEALT FUNCTION END*/


global $nologin,$name;
require_once("modules/$name/config.php");
//if (!$nologin){
        userlogin();
        //Delete peer in seconds
        $sql = "SELECT COUNT(*) AS tot, torrent, seeder, SUM(upload_speed) AS speed FROM torrent_peers WHERE UNIX_TIMESTAMP(SYSDATE())  - '".$time_check."' > UNIX_TIMESTAMP(`last_action`) GROUP BY torrent, seeder;";
        if (!$res = $db->sql_query($sql)) bterror($sql);
        if ( $row = $db->sql_fetchrow($res) ){
                do{
                        if ($row["seeder"]=="yes")
                                $sql = "UPDATE torrent_torrents SET seeders = seeders - '".$row["tot"]."', tot_peer = tot_peer - '".$row["tot"]."', speed = speed - '".$row["speed"]."' WHERE id='".$row["torrent"]."';";
                        else
                                $sql = "UPDATE `torrent_torrents` SET `leechers` = `leechers` - '".$row["tot"]."', `tot_peer` = `tot_peer` - '".$row["tot"]."', `speed` = `speed` - '".$row["speed"]."' WHERE `id`='".$row["torrent"]."';";
                        if(! $db->sql_query($sql) ) die("Error $sql");
                }while($row = $db->sql_fetchrow($res));
                if(! $db->sql_query("DELETE FROM torrent_peers WHERE UNIX_TIMESTAMP(SYSDATE())  - '".$time_check."' > UNIX_TIMESTAMP(`last_action`)") ) die("Error DELETE FROM torrent_peers WHERE UNIX_TIMESTAMP(SYSDATE())  - '".$time_check."' > UNIX_TIMESTAMP(`last_action`)");
        }

/*
        //Reset statistic ;-)
        $sql = "SELECT count(*) as tot, torrent, seeder FROM torrent_peers GROUP BY torrent, seeder;";
        if (!$res = $db->sql_query($sql)) die("SQLError $sql");
        if ( $row = $db->sql_fetchrow($res) ){
                do{
                        if ($row["seeder"]=="yes")
                                $sql = "UPDATE `torrent_torrents` SET `seeders`= '".$row["tot"]."' WHERE `id`='".$row["torrent"]."';";
                        else
                                $sql = "UPDATE `torrent_torrents` SET `leechers`='".$row["tot"]."' WHERE `id`='".$row["torrent"]."';";
                        $db->sql_query($sql);
                }while($row = $db->sql_fetchrow($res));
        }
*/


        $sql = "SELECT id, info_hash, tracker, type, ed2k, magnet FROM torrent_torrents WHERE tracker_update < sysdate()  -  INTERVAL $time_tracker_update MINUTE AND last_action > sysdate() - INTERVAL 15 DAY AND type <> 'link' LIMIT 1";
        $res = $db->sql_query($sql) OR bterror($sql);
        $row = $db->sql_fetchrow($res);
        if ($row){

                $sql="UPDATE torrent_torrents SET seeders=0, leechers=0, tot_peer=0, tracker_update = sysdate()- INTERVAL ".($time_tracker_update-$timeout_repeat_tu)." MINUTE WHERE id='".$row['id']."'";
                if(! $db->sql_query($sql) ) bterror($sql);

                $info_hash = $row["info_hash"];
                //error_reporting(E_ERROR | E_PARSE);

      if($extern_check) {
                $fp = fopen ($row['tracker']."?info_hash=".urlencode($row["info_hash"]), "rb");
                $sql="";
                if($fp){
                        socket_set_timeout($fp, 30);
                        $page=fread($fp, 1000000);
                        $status = socket_get_status($fp);
                        fclose($fp);
                        if (!$status['timed_out']){
                                if(substr_count($row['tracker'], "scrape")>0){
                                        $parse_array = array();
                                        $i=0;
                                        $max=strlen($page);
                                        $parse_array = ergo($page, $parse_array, $i, $max);
                                        if(is_array($parse_array["0"]["files"]["$info_hash"])){
                                                $tot_peer_ut = $parse_array["0"]["files"][ "$info_hash" ]["complete"]+$parse_array["0"]["files"][ "$info_hash" ]["incomplete"];
                                                $sql="UPDATE torrent_torrents SET tracker_update = sysdate(), times_completed=".sqlesc($parse_array["0"]["files"][ "$info_hash" ]["downloaded"]).", seeders=".sqlesc($parse_array["0"]["files"][ "$info_hash" ]["complete"]).", leechers=".sqlesc($parse_array["0"]["files"][ "$info_hash" ]["incomplete"]).", tot_peer=".sqlesc($tot_peer_ut);
                                                if ($parse_array["0"]["files"][ "$info_hash" ]["complete"]>0)
                                                        $sql.=", last_action=SYSDATE()";
                                                if ($tot_peer_ut>0 || $row[ed2k]>"" || $row[magnet]>"")
                                                        $sql.=", visible='yes'";
                                                else
                                                        $sql.=", visible='no'";
                                        }
                                }else{
                                        $count_leech = substr_count($page, "peer id");
                                        $sql = "UPDATE torrent_torrents SET tracker_update = sysdate(), seeders=0, leechers='".$count_leech."', tot_peer='".$count_leech."'";
                                        if ($count_leech>0)
                                                        $sql.=", last_action=SYSDATE(), visible='yes'";
                                }
                        }
                }

                //error_reporting(E_ERROR | E_WARNING | E_PARSE);

                if($sql!=""){
                        $sql.=" WHERE id=".$row['id'];
                        $db->sql_query($sql) or  bterror($sql);
                }

                //Hide no peer torrent
                $db->sql_query("UPDATE torrent_torrents SET visible='no' WHERE visible='yes' AND last_action < sysdate()  -  INTERVAL 60 MINUTE AND tot_peer = 0 AND ed2k='' AND magnet='' AND type<>'link'");

        }
      }
//}


?>