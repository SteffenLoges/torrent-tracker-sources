<?php
if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

OpenTable2();
?>
<table width="100%"><tr><td width="75%">Created by <a href='http://www.raulken.it' target=_blank>Raulken.it</a> - <a href='http://www.bitnile.com' target=_blank>Bitnile.com</a> - <a href='http://www.natasha.it' target=_blank>Natasha.it</a> - <a href='http://www.hyarbor.it' target=_blank>Hyarbor.it</a><BR>
<a href='http://www.raulken.co.uk' target=_blank>Raulken.co.uk</a> - <a href='http://www.raulken.ca' target=_blank>Raulken.ca</a> <br>
Developed by <a href='http://www.p2pmania.it'>P2PMania.it</a> - <a href='http://www.ffitalia.net'>FFitalia.net</a><BR>
Official Project Page on <a href="http://www.sourceforge.net/projects/nuketorrent">SourceForge</a></td>
<?
global $admin,$version;
if(is_admin($admin))
        echo "<td align=right width=\"25%\">Only ADMINs see this<BR>Ver. $version - Nov 28th 2004<br>If you have new translations plese send us tnx</td>";
?>
</tr></table>
<?
CloseTable2();
?>