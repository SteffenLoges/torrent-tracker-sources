<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;
global $user_prefix, $name;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
include("header.php");
global $db, $admin,$user,$uid;
$module_name = basename(dirname(__FILE__));
get_lang($module_name);

require_once("modules/$name/include/bittorrent.php");



function dltable($name, $arr, $torrent) {

        global $CURUSER, $admin;

        $s = "<b>" . count($arr) . " $namex</b>";
        if (!count($arr))
                return $s;
        $s .= "\n";
        $s .= "<table border=\"1\" cellpadding=\"4\" width=\"100%\">\n";
        $s .= "<tr><td class=\"heading\">ip/port</td><td class=\"heading\" align=\"right\">uploaded</td><td class=\"heading\" align=\"right\">".bt_ddownloaded."</td><td class=\"heading\" align=\"right\">"._btdcomplete."</td><td class=\"heading\" align=\"right\">"._bt_dtimeconnected."</td><td class=\"heading\" align=\"right\">"._btdidle."</td></tr>\n";
        $now = time();
        $admin = (isset($CURUSER) && $CURUSER["admin"] == "yes");

        foreach ($arr as $e) {
                $s .= "<tr>\n";
                $s .= "<td>" . ($admin ? $e["ip"] : preg_replace('/\.\d+$/', ".xxx", $e["ip"])) . ":" . (($e["connectable"] == "yes") ? $e["port"] : sprintf("(%d)", $e["port"])) . "</td>\n";
                $s .= "<td align=\"right\">" . mksize($e["uploaded"]) . "</td>\n";
                $s .= "<td align=\"right\">" . mksize($e["downloaded"]) . "</td>\n";
                $s .= "<td align=\"right\">" . sprintf("%.2f%%", 100 * (1 - ($e["to_go"] / $torrent["size"]))) . "</td>\n";
                $s .= "<td align=\"right\">" . mkprettytime($now - $e["st"]) . "</td>\n";
                $s .= "<td align=\"right\">" . mkprettytime($now - $e["la"]) . "</td>\n";
                $s .= "</tr>\n";
        }
        $s .= "</table>\n";
        return $s;
}

function spytorrent($row){
        if (!$extern_check) return false;
        $time_tracker_update = 180; //min
        $timeout_repeat_tu = 15;
        global $db, $admin;



                if($row[type]!=="link"){
                          $sql="UPDATE torrent_torrents SET seeders=0, leechers=0, tot_peer=0, tracker_update = sysdate()- INTERVAL ".($time_tracker_update-$timeout_repeat_tu)." MINUTE WHERE id='".$row['id']."'";
                        if(! $db->sql_query($sql) ) bterror($sql);

                        $info_hash = $row["info_hash"];
                        error_reporting(E_ERROR | E_PARSE);
                        $fp = fopen ($row['tracker']."?info_hash=".urlencode($row["info_hash"]), "rb");
                        $sql="";
                        if($fp){
                                socket_set_timeout($fp, 30);
                                while (!feof($fp)) {
                                        $page.=fread($fp, 10000);
                                }
                                //echo $page;
                                $status = socket_get_status($fp);
                                fclose($fp);
                                if (!$status['timed_out']){
                                        if(substr_count($row['tracker'], "scrape")>0){
                                                $parse_array = array();
                                                $i=0;
                                                $max=strlen($page);
                                                $parse_array = ergo($page, $parse_array, $i, $max);
                                                if(is_array($parse_array["0"]["files"]["$info_hash"])){
                                                        $tot_peer_ut = $parse_array["0"]["files"][ "$info_hash" ]["complete"]+$parse_array["0"]["files"][ "$info_hash" ]["incomplete"];
                                                        $sql="UPDATE torrent_torrents SET tracker_update = sysdate(), times_completed=".sqlesc($parse_array["0"]["files"][ "$info_hash" ]["downloaded"]).", seeders=".sqlesc($parse_array["0"]["files"][ "$info_hash" ]["complete"]).", leechers=".sqlesc($parse_array["0"]["files"][ "$info_hash" ]["incomplete"]).", tot_peer=".sqlesc($tot_peer_ut);
                                                        if ($parse_array["0"]["files"][ "$info_hash" ]["complete"]>0)
                                                                $sql.=", last_action=SYSDATE()";
                                                        if ($tot_peer_ut>0 || $row[ed2k]>"" || $row[magnet]>"")
                                                                $sql.=", visible='yes'";
                                                        else
                                                                $sql.=", visible='no'";
                                                }
                                        }else{
                                                $count_leech = substr_count($page, "peer id");
                                                $sql = "UPDATE torrent_torrents SET tracker_update = sysdate(), seeders=0, leechers='".$count_leech."', tot_peer='".$count_leech."'";
                                                if ($count_leech>0)
                                                                $sql.=", last_action=SYSDATE(), visible='yes'";
                                        }
                                }
                        } else die("BTERROR");

                        error_reporting(E_ERROR | E_WARNING | E_PARSE);

                        if($sql!=""){
                                $sql.=" WHERE id=".$row['id'];
                                $db->sql_query($sql) or  bterror($sql);
                        }
                }

}



$id = intval($_GET["id"]);

if (!isset($id) || !$id)
        die("No id");

$sql = "SELECT A.seeders, A.banned, A.leechers, A.info_hash, A.filename, UNIX_TIMESTAMP() - UNIX_TIMESTAMP(A.last_action) AS lastseed, A.numratings, A.name, IF(A.numratings < '$minvotes', NULL, ROUND(A.ratingsum / A.numratings, 1)) AS rating, A.save_as, A.src_url, A.descr, A.visible, A.size, A.added, A.views, A.hits, A.times_completed, A.id, A.type, A.numfiles, A.ownertype, A.evidence, A.tracker, B.name AS cat_name, C.username, A.magnet, A.ed2k, A.tracker_update, IF(A.tracker_update>(sysdate()-INTERVAL 15 MINUTE), 0, 1) as can_tracker_update FROM torrent_torrents A LEFT JOIN torrent_categories B ON A.category = B.id LEFT JOIN ".$user_prefix."_users C ON A.owner = C.user_id WHERE A.id = '$id'";

$res = $db->sql_query($sql)
        or bterror($sql);
$row = $db->sql_fetchrow($res);

$owned = false;

if (is_user($user)) {
        if (is_admin($admin) or $uid == $row["owner"]) $owned = true;
}

//TEST CODE FOR DEVELOPMENT. DOESN'T WORK UNTIL MANUALLY ACTIVATED
$debug = false;
if ($debug) {
        $open = str_replace("scrape","announce",$row["tracker"])."?info_hash=".urlencode($row["info_hash"])."&peer_id=%00%00%00%00%00Azureus9%09%40d%BE%3D%C1%8B&port=666&uploaded=0&downloaded=0&left=1&num_peers=10000";
        $fp = fopen($open,"rb") or die("errore");
        while (!feof($fp)) {
                $page.=fread($fp,1000);
        }
        //echo $page."<BR>";
        include("modules/$name/include/benc.php");
        $arr = bdec($page);
        print_r($arr["value"]["peers"]["value"]["0"]["value"]["ip"]["value"]);
}
global $admin;
if (!$row OR ($row["banned"] == "yes" AND !is_admin($admin)))
        print(_btnotorrent);
else {
        if ($_GET["hit"]) {
                $db->sql_query("UPDATE torrent_torrents SET views = views + 1 WHERE id = '$id'") or bterror("UPDATE torrent_torrents SET views = views + 1 WHERE id = '$id'");
        }

        if (!isset($_GET["page"])) {
                global $admin;

                if(strlen($row["tracker"])==0 && $row["type"]!="link"){

                        //Auto correct update peer
                        $sql_upgrade = "SELECT count(*) as tot, seeder, sum(upload_speed) as upload_speed FROM torrent_peers WHERE torrent='$id' GROUP BY seeder;";
                        if (! $res_upgrade = $db->sql_query($sql_upgrade) ) bterror($sql_upgrade);
                        $add_upload_speed = 0;
                        if ( $row_upgrade = $db->sql_fetchrow($res_upgrade) ){
                                do{
                                        if ($row_upgrade["seeder"]=="yes"){
                                                $add_seeders = $row_upgrade["tot"];
                                                $add_upload_speed += $row_upgrade["upload_speed"];
                                        }else{
                                                $add_leechers = $row_upgrade["tot"];
                                                $add_upload_speed += $row_upgrade["upload_speed"];
                                        }
                                }while($row_upgrade = $db->sql_fetchrow($res_upgrade));
                                $sql_upgrade = "UPDATE `torrent_torrents` SET `seeders`= '".$add_seeders."', `leechers`='".$add_leechers."', `tot_peer`='".($add_seeders+$add_leechers)."', `speed`='".$add_upload_speed."' WHERE `id`='$id';";
                                $db->sql_query($sql_upgrade) or bterror($sql_upgrade);
                        }
                }

                stdhead(_btddetails ."\"" . $row["name"] . "\"");

                global $owned;
                $spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

                if ($_GET["uploaded"]) {
                        print("<h2>"._btdsuccessfully."!</h2>\n");
                        print("<p>"._btdsuccessfully2."</p>\n");
                }
                elseif ($_GET["edited"]) {
                        print("<h2>"._btdsuccessfullye."!</h2>\n");
                        if (isset($_GET["returnto"]))
                                print("<p><b>"._btdgobackto." <a href=\"" . htmlspecialchars($_GET["returnto"]) . "\">"._btdwhenceyoucame."</a>.</b></p>\n");
                }
                elseif (isset($_GET["searched"])) {
                        print("<h2>"._btdyoursearchfor." \"" . htmlspecialchars($_GET["searched"]) . "\" "._btdgavesresult.":</h2>\n");
                }
                elseif ($_GET["rated"]){
                        print("<h2>"._btdratingadded."!</h2>\n");
                }
                elseif ($_GET["spytorrent"]){
                        if(strlen($row["tracker"])>0 && $row["can_tracker_update"]==1){
                                spytorrent($row);
                                echo "<meta http-equiv=\"refresh\" content=\"3;url=modules.php?name=$name&file=details&id=$id#seeders\">";
                                print("<h2>"._btdspytorrentupdate."!</h2><br>"._btdspytorrentupdate1.".<br>"._btdspytorrentupdate2." <a href=\"modules.php?name=$name&file=details&id=$id#seeders\">"._btdspytorrentupdate3."</a>\n");
                                include("footer.php");
                                die();
                        }else{
                                echo _btdspytorrentnoupdate;
                        }
                }
                elseif ($ris=$_GET["sn"]){
                        OpenTable2();
                        if ($ris=="y"){
                                print("<h2>"._btdnotifyadd."</h2>"._btdnotifyadd2."\n");
                                if(! $db->sql_query("INSERT INTO torrent_seeder_notify (torrent, user, day) VALUES ('$id', '".$CURUSER["id"]."', SYSDATE()-INTERVAL 1 DAY)") )
                                        bterror("INSERT INTO torrent_seeder_notify (torrent, user, day) VALUES ('$id', '".$CURUSER["id"]."', SYSDATE()-INTERVAL 1 DAY)");
                        }elseif($ris=="n"){
                                print("<h2>"._btdnotifydel."</h2>\n");
                                $db->sql_query("DELETE FROM torrent_seeder_notify WHERE torrent='$id' AND user='".$CURUSER["id"]."'") or bterror("DELETE FROM torrent_seeder_notify WHERE torrent='$id' AND user='".$CURUSER["id"]."'");
                        }
                        CloseTable2();
                }
                elseif ($ris=$_GET["cn"]){
                        OpenTable2();
                        if ($ris=="y"){
                                print("<h2>"._btdnotifyemailadd."</h2> "._btdnotifyemailadd1."\n");
                                if(! $db->sql_query("INSERT INTO torrent_comments_notify (torrent, user, can_send) VALUES ('$id', '".$CURUSER["id"]."', 1)") )
                                        bterror("INSERT INTO torrent_comments_notify (torrent, user, can_send) VALUES ('$id', '".$CURUSER["id"]."', 1)");
                        }elseif($ris=="n"){
                                print("<h2>"._btdnotifyemaildel."</h2> "._btdnotifyemaildel1."</h2>\n");
                                if(! $db->sql_query("DELETE FROM torrent_comments_notify WHERE torrent='$id' AND user='".$CURUSER["id"]."'") )
                                        bterror("DELETE FROM torrent_comments_notify WHERE torrent='$id' AND user='".$CURUSER["id"]."'");
                        }elseif($ris=="u"){
                                if(! $db->sql_query("UPDATE torrent_comments_notify SET can_send=1 WHERE torrent='$id' AND user='".$CURUSER["id"]."'") )
                                        bterror("UPDATE torrent_comments_notify SET can_send=1 WHERE torrent='$id' AND user='".$CURUSER["id"]."'");
                        }
                        CloseTable2();
                }

                OpenTable2();
                print("<table border=\"0\" cellspacing=\"5\" cellpadding=\"5\">\n");

                $url = "modules.php?name=$name&file=edit&id=" . $row["id"];
                if (isset($_GET["returnto"])) {
                        $addthis = "&amp;returnto=" . urlencode($_GET["returnto"]);
                        $url .= $addthis;
                        $keepget .= $addthis;
                }

                $s = "<b>" . htmlspecialchars($row["name"]) . "</b>";
                global $owned, $admin;

                if (is_admin($admin)) {
                        $s.= " $spacer<a href=\"modules.php?name=$name&file=edit&id=" . $row["id"]."\" class=\"sublink\">["._bteditthistorrent."]</a>";
                }
                tr(_btname, $s, 1);
                echo "<tr><td><hr></td><td></td></tr>";

                global $src_url;
                switch ($src_url) {
                        case "disabled" : {
                                $urldownload = "modules.php?name=$name&file=download&id=".$row["id"];
                                $displaysrc = false;
                                break;
                        }
                        case "torrent" : {
                                $urldownload = "modules.php?name=$name&file=download&id=".$row["id"];
                                if (isset($row["src_url"])) {
                                        $displaysrc = true;
                                } else {
                                        $displaysrc = false;
                                }
                                break;
                        }
                        case "url" : {
                                if (isset($row["src_url"])) {
                                        $urldownload = $row["src_url"];
                                        $displaysrc = true;
                                } else {
                                        $urldownload = "modules.php?name=$name&file=download&id=".$row["id"];
                                        $displaysrc = false;
                                }
                                break;
                        }
                        case "force" : {
                                $displaysrc = false;
                                if (isset($row["src_url"])) {
                                        $urldownload = $row["src_url"];
                                } else {
                                        $urldownload = "javascript:alert('Protezione attiva');";
                                }
                                break;
                        }
                }
                if($row["type"]!="link"){
                        tr("<a href='modules.php?name=$name&file=index_help#install'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._btdhelpdownload."'></a> "._btfilename, "<a class=\"index\" href=\"$urldownload\">" . htmlspecialchars($row["filename"]) . "</a>", 1);
                        echo "<tr><td><hr></td><td></td></tr>";
                        tr(_btdownloadas, $row["save_as"]);
                        if ($displaysrc) tr(_btsourceurl,"<A href=\"".$row["src_url"]."\">".$row["src_url"]."</a>");
                        echo "<tr><td><hr></td><td></td></tr>";
                }

                $add_network = "";
                $can_access = true;

                //Privacy
                global $torrent_global_privacy;
                if ($torrent_global_privacy && $row["owner"]!=$CURUSER["id"] && strlen($row["tracker"])==0){
                        $sql_trigger = "SELECT A.`status` FROM `torrent_global_privacy` A, `torrent_torrents` B WHERE B.`id` = '$id' AND A.`from` =  '".$id_user."' AND  B.owner=A.to AND A.`status`>=0";
                        $res_trigger = $db->sql_query($sql_trigger) or bterror($sql_trigger);
                        if ( $row_trigger = $db->sql_fetchrow($res_trigger) )
                                if($row_trigger["status"]!=0)
                                        $can_access = false;
                }

                global $down_reg;
                if (!$CURUSER["id"] && ($down_reg || $torrent_global_privacy))
                        $can_access = false;

                if($row["magnet"]){
                        if($can_access)
                                $add_network .= "<p><img src='modules/$name/pic/minisharazea.gif' align=left> <a href='".$row["magnet"]."'>Magnet Link "._btnetwork." Gnutella 2</a></p>";
                        else
                                $add_network .= "<p><img src='modules/$name/pic/minisharazea.gif' align=left> <a href=\"modules.php?name=$name&file=download&id=".$row["id"]."\">Magnet Link "._btnetwork." Gnutella 2</a></p>";
                }
                if($row["ed2k"]){
                        if($can_access)
                                $add_network .= "<p><img src='modules/$name/pic/minidonkey.gif' align=left> <a href='".$row["ed2k"]."'>Ed2k Link "._btnetwork." Edonkey Emule</a></p>";
                        else
                                $add_network .= "<p><img src='modules/$name/pic/minidonkey.gif' align=left> <a href=\"modules.php?name=$name&file=download&id=".$row["id"]."\">Ed2k Link "._btnetwork." Edonkey Emule</a></p>";
                }

                if($add_network || $row["type"]=="link"){
                        if($row["numfiles"]==1){
                                tr("<a href='modules.php?name=$name&file=details_help#network'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelpothersource."'></a> "._btothersource, $add_network, 1);
                        }else{
                                tr("<a href='modules.php?name=$name&file=details_help#network'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelpothersource."'></a> "._btothersource, "<a href=#filelist>Per le fonti alternative guardare la lista file</a>", 1);
                        }
                        echo "<tr><td><hr></td><td></td></tr>";
                }

                function hex_esc($matches) {
                        return sprintf("%02x", ord($matches[0]));
                }

                if($row["type"]=="link")
                        tr("<a href='modules.php?name=$name&file=details_help#infohash'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelpinfohash."'></a> "._bthelpinfohash, $row["info_hash"]);
                else
                        tr("Tracker",substr($row["tracker"],0,strpos($row["tracker"],"scrape")));
                        tr("<a href='modules.php?name=$name&file=details_help#infohash'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelpinfohash."'></a> "._bthelpinfohash, preg_replace_callback('/./s', "hex_esc", hash_pad($row["info_hash"])));
                echo "<tr><td><hr></td><td></td></tr>";

                if (!empty($row["descr"])){
                        tr(_btdescription, $row["descr"], 1);
                        echo "<tr><td><hr></td><td></td></tr>";
                }
                if ( $row["visible"] == "no" && $row["ed2k"]=="" && $row["magnet"]=="" ){
                        tr("<a href='modules.php?name=$name&file=details_help#visible'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='Aiuto su Visibile'></a>  "._btvisible, _btnodead, 1);
                        echo "<tr><td><hr></td><td></td></tr>";
                }
                if ($admin){
                        tr(_btbanned, $row["banned"]);
                        echo "<tr><td><hr></td><td></td></tr>";
                }
                if (isset($row["cat_name"])){
                        tr(_bttype, $row["cat_name"]);
                        echo "<tr><td><hr></td><td></td></tr>";
                }else{
                        tr(_bttypetorrent, _btnoselected);
                        echo "<tr><td><hr></td><td></td></tr>";
                }

                if($row["type"]!="link"){
                        tr(_btlastseeder, _btlastactivity." ". mkprettytime($row["lastseed"]) . _btago);
                        echo "<tr><td><hr></td><td></td></tr>";
                }

                tr(_btsize,mksize($row["size"]) . " (" . $row["size"] . " Bytes)");
                echo "<tr><td><hr></td><td></td></tr>";

                $s = "";
                $s .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td valign=\"top\">";
                if (!isset($row["rating"])) {
                        if ($minvotes > 1) {
                                $s .= str_replace("__minvotes__", $minvotes, _btminvotes);
                                if ($row["numratings"])
                                        $s .= _btonly . $row["numratings"];
                                else
                                        $s .= _btnone;
                                $s .= ")";
                        }
                        else
                                $s .= _btnovotes;
                }
                else {
                        $rpic = ratingpic($row["rating"]);
                        if (!isset($rpic))
                                $s .= "invalid?";
                        else
                                $s .= "$rpic (" . $row["rating"] . _btoo5 . $row["numratings"] .  _btvotestot.")";
                }
                $s .= "\n";
                $s .= "</td><td>$spacer</td><td valign=\"top\">";
                if (!isset($CURUSER))
                        $s .= "(<a href=\"modules.php?name=Your_Account&returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;nowarn=1\">"._btlogintorate.")";
                else {
                        $ratings = array(
                                        5 => _btvot5,
                                        4 => _btvot4,
                                        3 => _btvot3,
                                        2 => _btvot2,
                                        1 => _btvot1,
                        );
                        if (!$owned) {
                                if(! $xres = $db->sql_query("SELECT rating, added FROM torrent_ratings WHERE torrent = '$id' AND user = '" . $CURUSER["id"]."'") ) bterror("SELECT rating, added FROM torrent_ratings WHERE torrent = '$id' AND user = '" . $CURUSER["id"]."'");
                                $xrow = $db->sql_fetchrow($xres);
                                if ($xrow)
                                        $s .= "("._btyourate." \"" . $xrow["rating"] . " - " . $ratings[$xrow["rating"]] . "\" "._bton." " . $xrow["added"] . ")";
                                else {
                                        $s .= "<form method=\"post\" action=\"modules.php?name=$name&file=takerate\"><input type=\"hidden\" name=\"id\" value=\"$id\" />\n";
                                        $s .= "<select name=\"rating\">\n";
                                        $s .= "<option value=\"0\">("._btaddrating.")</option>\n";
                                        foreach ($ratings as $k => $v) {
                                                $s .= "<option value=\"$k\">$k - $v</option>\n";
                                        }
                                        $s .= "</select>\n";
                                        $s .= "<input type=\"submit\" value=\""._btvote."\" />";
                                        $s .= "</form>\n";
                                }
                        }
                }
                $s .= "</td></tr></table>";
                tr(_btrating, $s, 1);
                echo "<tr><td><hr></td><td></td></tr>";
                tr(_btadded, $row["added"]);
                echo "<tr><td><hr></td><td></td></tr>";
                tr("<a href='modules.php?name=$name&file=details_help#stats'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelpstat."'></a> "._btviews, $row["views"]);
                echo "<tr><td><hr></td><td></td></tr>";
                if($row["type"]!="link"){
                        tr(_bthits, $row["hits"]);
                        echo "<tr><td><hr></td><td></td></tr>";
                        tr(_btsnatch, $row["times_completed"] . _bttimes);
                        echo "<tr><td><hr></td><td></td></tr>";
                }
                //net
                if ($add_leechers>0 && $add_upload_speed>0){
                        $speed_leech = round($add_upload_speed/$add_leechers);
                        $eta_m = ($row["size"] / $speed_leech)/60; //to minutes
                        $eta = ($eta_m % 60)."m"; //minutes
                        $eta_h = floor($eta_m / 60);
                        if ($eta_h>0) $eta=$eta_h."h ".$eta;
                        $speed_leech=mksize($speed_leech)."/s";
                        tr(_bttorrent, mksize($add_upload_speed). "/s");
                        echo "<tr><td><hr></td><td></td></tr>";
                        tr(_btleechspeed, $speed_leech);
                        echo "<tr><td><hr></td><td></td></tr>";
                        tr(_bteta, $eta);
                        echo "<tr><td><hr></td><td></td></tr>";
                }


                tr(_btevidence, ($row["evidence"]==1) ? _btyes : _btno);
                echo "<tr><td><hr></td><td></td></tr>";

                $keepget = "";
                $uprow = (isset($row["username"]) && $row["ownertype"]==0) ? "<a href='modules.php?name=Your_Account&op=userinfo&username=".$row["username"]."'>".htmlspecialchars($row["username"])."</a>" : "<i>"._btunknown."</i>";
                tr(_btuppedby, $uprow, 1);
                echo "<tr><td><hr></td><td></td></tr>";

                if ($row["type"] == "multi" || $row["numfiles"]>1) {
                        tr(_btnumfiles, $row["numfiles"] . " "._btfiles, 1);
                        echo "<tr><td><hr></td><td></td></tr>";
                        $s = "<table border=\"0\" cellpadding=\"4\">\n";

                        if(! $subres = $db->sql_query("SELECT * FROM torrent_files WHERE torrent = '$id' ORDER BY id") )
                                bterror("SELECT * FROM torrent_files WHERE torrent = '$id' ORDER BY id");
                        while ($subrow = $db->sql_fetchrow($subres)) {
                                $s .= "<tr><td>" . preg_replace(',[^/]+$,', '<b>$0</b>', htmlspecialchars(urldecode( stripslashes($subrow["filename"])))) . "</td><td align=\"right\">" . mksize($subrow["size"]) . "</td>";
                                $add_network="";
                                if($subrow["magnet"]!=""){
                                        if($can_access)
                                                $add_network .= "<p><img src='modules/$name/pic/minisharazea.gif' align=left> <a href='".$subrow["magnet"]."'>Magnet Link "._btnetwork." Gnutella 2</a></p>";
                                        else
                                                $add_network .= "<p><img src='modules/$name/pic/minisharazea.gif' align=left> <a href=\"modules.php?name=$name&file=download&id=".$row["id"]."\">Magnet Link "._btnetwork." Gnutella 2</a></p>";
                                }
                                if($subrow["ed2k"]!=""){
                                        if($can_access)
                                                $add_network .= "<p><img src='modules/$name/pic/minidonkey.gif' align=left> <a href='".$subrow["ed2k"]."'>Ed2k Link "._btnetwork." Edonkey Emule</a></p>";
                                        else
                                                $add_network .= "<p><img src='modules/$name/pic/minidonkey.gif' align=left> <a href=\"modules.php?name=$name&file=download&id=".$row["id"]."\">Ed2k Link "._btnetwork." Edonkey Emule</a></p>";
                                }
                                if($add_network) $add_network = "<td>$add_network</td>";
                                $s .= "$add_network</tr>\n";
                        }

                        $s .= "</table>\n";
                        tr("<a name=\"filelist\">"._btfilelist."</a><br />", $s, 1);
                        echo "<tr><td><hr></td><td></td></tr>";
                }

                if($row["type"]!="link"){
                        if(strlen($row["tracker"])>0){
                                tr(_btlasttrackerupdate, $row["tracker_update"]);
                                echo "<tr><td><hr></td><td></td></tr>";

                                if($row["can_tracker_update"]==1 AND !$_GET["spytorrent"] AND $extern_check)
                                        $add_text = "<br><a href='modules.php?name=$name&file=details&id=$id&amp;spytorrent=1#peers'><img src='modules/$name/pic/torrentspy.gif' border='0'>SpyTorrent, "._btupdatesource."</a>";
                                else $add_text = "";
                                tr("<a href='modules.php?name=$name&file=details_help#ip'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelppeer."'></a> <a name=\"peers\">"._btpeers."</a><br />", $row["seeders"] . " "._btseeders.", " . $row["leechers"] . " "._btleechers." = " . ($row["seeders"] + $row["leechers"]) . " "._btpeerstot." $add_text", 1);
                                echo "<tr><td><hr></td><td></td></tr>";
                        }elseif (!$_GET["dllist"]) {
                                        tr("<a href='modules.php?name=$name&file=details_help#ip'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelppeer."'></a> "._btpeers."<br /><a href=\"modules.php?name=$name&file=details&id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[$bt_seefulllist]</a>", $row["seeders"] . " $bt_seeders, " . $row["leechers"] . " $bt_leechers = " . ($row["seeders"] + $row["leechers"]) . " $bt_peerstot", 1);
                                        echo "<tr><td><hr></td><td></td></tr>";
                        }else {

                                $downloaders = array();
                                $seeders = array();
                                if(! $subres = $db->sql_query("SELECT seeder, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, UNIX_TIMESTAMP(last_action) AS la FROM torrent_peers WHERE torrent = '$id'") )
                                        bterror("SELECT seeder, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, UNIX_TIMESTAMP(last_action) AS la FROM torrent_peers WHERE torrent = '$id'");

                                $numseed=0;
                                $numleech=0;
                                while ($subrow = $db->sql_fetchrow($subres)) {
                                        if ($subrow["seeder"] == "yes"){
                                                $seeders[] = $subrow;
                                                $numseed++;
                                        }else{
                                                $downloaders[] = $subrow;
                                                $numleech++;
                                        }
                                }
                                $strextra = "";

                                //If no source hidden file
                                if($numseed+$numleech==0) $strextra .= ", visible = 'no'";

                                $sqlupdatesource = "UPDATE torrent_torrents SET seeders='".$numseed."', leechers='".$numleech."', tot_peer='".($numseed+$numleech)."' $strextra WHERE id = '".$id."'";
                                echo $sqlupdatesource;
                                if(! $db->sql_query($sqlupdatesource) ) bterror($sqlupdatesource);

                                function leech_sort($a,$b) {
                                        $x = $a["to_go"];
                                        $y = $b["to_go"];
                                        if ($x == $y)
                                                return 0;
                                        if ($x < $y)
                                                return -1;
                                        return 1;
                                }
                                function seed_sort($a,$b) {
                                        $x = $a["uploaded"];
                                        $y = $b["uploaded"];
                                        if ($x == $y)
                                                return 0;
                                        if ($x < $y)
                                                return 1;
                                        return -1;
                                }

                                usort($seeders, "seed_sort");
                                usort($downloaders, "leech_sort");

                                tr("<a href='modules.php?name=$name&file=details_help#ip'><img src='modules/$name/pic/help.gif' align='midle' border='0' alt='"._bthelpsource."'></a> <a name=\"seeders\">"._btseeders."</a><br /><a href=\"modules.php?name=$name&file=details&id=$id$keepget\" class=\"sublink\">["._bthidelist."]</a>", dltable(_btseeders, $seeders, $row), 1);
                                echo "<tr><td><hr></td><td></td></tr>";
                                tr("<a name=\"leechers\">"._btleechers."</a><br /><a href=\"modules.php?name=$name&file=details&id=$id$keepget\" class=\"sublink\">["._bthidelist."</a>", dltable(_btleechers, $downloaders, $row), 1);
                                echo "<tr><td><hr></td><td></td></tr>";
                        }
                }

                print("</table>\n");
                CloseTable2();

                print("<hr />\n");
        }else{
                stdhead(_btcommentsfortorrent. $row["name"] . "\"");
                print("<p><a href=\"modules.php?name=$name&file=details&id=$id\">"._btbacktofull."</a></p><hr />\n");
        }

        if (is_user($user)){
                OpenTable2();
                if(! $res2 = $db->sql_query("SELECT count(*) as tot FROM torrent_comments_notify WHERE user = '".$CURUSER["id"]."' AND torrent='$id'") ) bterror("SELECT count(*) as tot FROM torrent_comments_notify");
                $row2 = $db->sql_fetchrow($res2);
                if ($row2["tot"]==1){
                        echo "<p>"._btnotnotifyemailcom." <a href='modules.php?name=$name&file=details&id=$id&cn=n'>"._btclickhere."</a></p>";
                }else{
                        echo "<p>"._btnotifyemailcom." <a href='modules.php?name=$name&file=details&id=$id&cn=y'>"._btclickhere."</a></p>";
                }

                $res2 = $db->sql_query("SELECT count(*) as tot FROM torrent_seeder_notify WHERE user = '".$CURUSER["id"]."' AND torrent='$id'") or bterror("SELECT count(*) as tot FROM torrent_seeder_notify WHERE user = '".$CURUSER["id"]."' AND torrent='$id'");
                $row2 = $db->sql_fetchrow($res2);
                if ($row2["tot"]==1){
                        echo "<p>"._btnotnotifyemail1s." <a href='modules.php?name=$name&file=details&id=$id&sn=n'>"._btclickhere."</a></p>";
                        if(! $db->sql_query("UPDATE torrent_comments_notify SET can_send=1 WHERE torrent='$id' AND user='".$CURUSER["id"]."'") ) bterror("UPDATE torrent_comments_notify SET can_send=1 WHERE torrent='$id' AND user='".$CURUSER["id"]."'");
                }else{
                        echo "<p>"._btnotifyemail1s." <a href='modules.php?name=$name&file=details&id=$id&sn=y'>"._btclickhere."</a></p>";
                }
                CloseTable2();
        }

        OpenTable2();
        print("<p><a name=\"startcomments\"></a></p>\n");
        $commentbar = "<p align=\"center\"><a class=\"index\" href=\"modules.php?name=$name&file=addcomment&id=$id\">"._btaddcomment."</a></p>\n";

        $subres = $db->sql_query("SELECT COUNT(*) FROM torrent_comments WHERE torrent = '$id'") or bterror("SELECT COUNT(*) FROM torrent_comments WHERE torrent = '$id'");
        $subrow = $db->sql_fetchrow($subres);
        $count = $subrow[0];

        if (!$count) {
                print("<p class=\"important\" align=\"center\">"._btnocommentsyet."</p>\n");
        }
        else {
                list($pagertop, $pagerbottom, $limit) = pager(20, $count, "modules.php?name=$name&file=details&id=$id&", array(lastpagedefault => 1));

                $sql = "SELECT A.id, text, A.added, username FROM torrent_comments A LEFT JOIN ".$user_prefix."_users B ON A.user = B.user_id WHERE torrent = '$id' ORDER BY A.id $limit";
                $subres = $db->sql_query($sql) or bterror($sql);
                $allrows = array();
                while ($subrow = $db->sql_fetchrow($subres))
                        $allrows[] = $subrow;

                print($commentbar);
                print($pagertop);

                commenttable($allrows);

                print($pagerbottom);
        }

        print($commentbar);
        CloseTable2();
}

include("footer.php");

?>