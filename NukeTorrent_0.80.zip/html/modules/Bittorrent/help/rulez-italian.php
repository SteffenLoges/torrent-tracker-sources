<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

require_once("mainfile.php");
global $name, $db;
require("modules/$name/config.php");
require_once("modules/$name/include/bittorrent.php");
OpenTable();
stdhead();

        $ip = $_SERVER["REMOTE_ADDR"];
        $sql_trigger = "SELECT count( A.seeder ) AS tot, A.seeder AS seed, A.ip, sum( B.size )  AS tot_size, max(B.size) as max_size FROM  `torrent_peers` A, `torrent_torrents` B WHERE A.ip =  '$ip' AND A.`torrent`  = B.`id` GROUP  BY ip, seed order by seed";
        $res_trigger = $db->sql_query($sql_trigger, $dbi) or bterror($sql_trigger);
        if ($row_trigger = $db->sql_fetchrow($res_trigger)){

                $check_seed=true;                        //If false trigger found
                $check_leech=true;                        //If false trigger found
                $print_error_seed="";
                $print_error_leech="";

                if ($min_share_seed>0){
                        $print_error_seed .=  "<li>Devi fare da seeder per un totale di almeno <b>".mksize($min_share_seed)."</b>.<br>";
                        if($row_trigger["seed"]=="yes" && $row_trigger["tot_size"]>=$min_share_seed) {
                                //if row_trigger["seed"]=="no" check only leech
                                $print_error_seed .= "OK, regola rispettata";
                        }else{
                                $check_seed = false;
                                $print_error_seed .= "<b>ATTENZIONE regola non rispettata</b>. ";
                                if ($row_trigger["seed"]=="yes")
                                        $print_error_seed .= "<b>Stai facedo da seeder per un totale di".mksize($row_trigger["tot_size"]).", devi fare da seeder per altri ".mksize($min_share_seed - $row_trigger["tot_size"]).".</b>";
                                else
                                        $print_error_seed .= "<b>Non stai facendo da seeder per nessun file</b>";
                        }
                }

                if ($min_size_seed>0){
                        $print_error_seed .=  "<li>Devi fare da seeder per un file grande almeno <b>".mksize($min_size_seed)."</b>.<br>";
                        if($row_trigger["seed"]=="yes" && $row_trigger["max_size"]>=$min_size_seed) {
                                //if row_trigger["seed"]=="no" check only leech
                                $print_error_seed .= "OK, regola rispettata";
                        }else{
                                $check_seed = false;
                                $print_error_seed .= "<b>ATTENZIONE regola non rispettata</b>. ";
                                if ($row_trigger["seed"]=="yes")
                                        $print_error_seed .= "<b>Il tuo file da seeder pi� grande � ".mksize($row_trigger["max_size"])."</b>";
                                else
                                        $print_error_seed .= "<b>Non stai facendo da seeder per nessun file</b>";
                        }
                }

                if ($row_trigger["seed"]=="yes") $row_trigger = $db->sql_fetchrow($res_trigger);

                if (!$check_seed && $row_trigger){

                        if ($max_num_file>0){
                                $print_error_leech .=  "<li>Massimo si pu�/possono scaricare <b>".$max_num_file."</b> file(s) contemporaneamente senza fare da seeder.<br> ";
                                if($max_num_file>$row_trigger["tot"]){ //a questo punto dovrebbe essere row_trigger["seed"]=="no" altrimenti vuol dire che non fa da leech
                                        $print_error_leech .= "OK, limite rispettato";
                                }else{
                                        $check_leech= false;
                                        $print_error_leech .= "<b>ATTENZIONE non � possibile superare questo limite. Stai scaricando ".$row_trigger["tot"]." file.</b>";
                                }
                        }

                        if ($max_share_size >0){
                                $print_error_leech .=  "<li>Non si pu� scaricare dopo aver superato il limit di <b>".mksize($max_share_size)."</b> totali.<br>";
                                if($max_share_size>$row_trigger["tot_size"] ){ //a questo punto dovrebbe essere row_trigger["seed"]=="no" altrimenti vuol dire che non fa da leech
                                        $print_error_leech .= "OK, limite rispettato";
                                }else{
                                        $check_leech = false;
                                        $print_error_leech .= "<b>ATTENZIONE hai superato il limite. Stai scaricando ".mksize($row_trigger["tot_size"])."</b>.";
                                }
                        }
                }

                if ($print_error_leech=="") $print_error_leech = "<li>Non hai limiti perch� stai rispettando le regole :-)";

                echo "In questo momento dal tuo ip <b>$ip</b> (solo tu lo leggi) risulta che tu (o tutti gli utenti col tuo stesso ip esterno se il tuo pc � in una lan) hai/avete la seguente situazione nei confronti dei limite di <b>libero</b> download concesso da questo server senza fare da seeder!<br>I limiti di questo server sono:<ol>$print_error_leech</ol>Per scaricare <b>senza limiti</b> devi rispettare le seguenti regole:<ol>$print_error_seed</ol><p>Fare da seeder significa eseguire uno o pi� TORRENT di cui si ha gi� il <b>file completo al 100%</b> sul proprio disco specificando come destinazione il proprio file completo (in nessun caso il file verr� modificato o cancellato).</p><p>Puoi anche fare da seeder condividendo un tuo file non presente in archivio caricando sul server il .torrent corrispondente dalla sezione <a href='modules.php?name=$name&file=upload'>UPLOAD</a> e poi lanciandolo.</p><p>Infine puoi semplicemente aspettare di finire i tuoi attuali download che automaticamente diventeranno seeder se NON CHIUDERAI la finestra Bit Torrent.</p><p>Quando rispettai le regole dei server non avrai limiti ai file che puoi scaricare :-)</p>";

        }else{
                echo "Nessun file ancora in download, visualizzerai le regole dopo aver cominciato un download";
        }

CloseTable();

?>