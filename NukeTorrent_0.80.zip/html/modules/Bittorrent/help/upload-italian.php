<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
global $name;
get_lang($name);
require_once("modules/$name/include/bittorrent.php");
OpenTable();
stdhead();
?>

<h2>Guida base all'uso di Bit Torrent</h2>

<a href='#do'>Come si fa l'upload per condividere?</a><br>
<a href='#copy'>Uppare un torrent copiato da un altro sito?</a><br>
<a href='#timeout'>Non riesco a fare l'upload del file torrent, esce una pagina bianca</a><br>
<a href='#network'>In quale caso il sistema genera i link a Gnutella e Edonkey Emule?</a><br>

<p>
<a name='do'><b>Come si fa l'upload per condividere?</b></a><br>
La cosa pi� semplice che puoi fare per condividere un file � andare sulla lista dei file gi� presenti e lanciare un .torrent di un file che hai gi� completo sul tuo pc, lui non modificher� il tuo file e far� solo dei check per capire se � veramente uguale al Torrent. Cos� facendo non devi fare nessun upload e non devi creare nessun .torrent ;-)<br>
Condividere con Bit Torrent non significa mettere 1000 file in share, ma pochi garantendo banda!<br>
Se sei un principiante (newbie) e non hai amici smanettoni che ti possano aiutare stai alla larga da questa sezione, finisci i tuoi download e poi tieni aperta la finestra: diventerai automaticamente un seeder. Quando poi riavii ti � sufficiente ripetere il download sullo stesso file. Bit Torrent, trovando il file gi� completo, non lo riscaricher� ma ti far� fare da seeder. Cos� facendo ti eviterai la complesse fasi per la creazione di un .torrent<br>
Bit Torrent � composto da un client (il programma che si installa per scaricare), dal tracker (il server che tiene traccia di chi ha il file), dai file .torrent (che sono file che contengono informazioni sul o sui file da condividere) e da un programma che genera i .torrent partendo da un file o da una cartella.<br>
Un .torrent non � il file che vuoi condividere, ma solo un insieme di informazioni che vengono generate dal file o dalla cartella che hai intenzione di condividere. Ci� permette a tutti i tracker di essere sollevati al 100% da ogni responsabilit� legale derivata dall'abuso degli utenti che utilizzano il servizio.<br>
<br>
Le fasi per creare un .torrent sono:<br>
<ol>
<li>Scaricare e installare<a href='http://www.torrentaid.com' target=_blank>TorrentAid</a>
<li>Specificare il nome del tracker! Se questo sito accetta torrent esterni puoi anche utilizzare tracker esterni registrarti a qualche altro sito che lo contiene.
<li>Rinominare i file che hanno dei punti ( <b>.</b> ) all'interno del nome sostituendoli con degli spazi o con degli underscore ( <b>_</b> ) PRIMA di creare il rispettivo .torrent . Attenzione: l'ultimo punto non deve essere eliminato, ad esempio pippo.avi resta com'� mentre pippo.ita.avi diventa "pippo ita.avi".
<li>Se avete un insieme di file (ad esempio CD1, CD2 ecc) che riguardono la stessa cosa mettete tutti i file in una cartella e specificate a TorrentAID che volete creare un .torrent da una cartella. (Se troviamo sul sito file divisi a pezzi di diversi torrent li cancelleremo!)
<li>Creato il file torrent andate sul sito del tracker e fate upload su quel sito
<li>Adesso devi fare una cosa importantissima, devi lanciare il .torrent specificando come destinazione il tuo file completo. Solo attivando per la prima volta il seeder il tuo .torrent verr� visualizzato pubblicamente.
<li>Tornare su questa pagina e fare l'upload del file .torrent che ha creato, quindi hai uppato 2 volte: prima sul sito del tracker e poi qui. Hai finito :D
</ol>
<br>
<b>FAQ sui Torrent</b>
<ul>
<li><B>E' possibile creare un .torrent da una cartella, condividendo cos� + file?</B> CERTAMENTE!
<li><B>Il Torrent contiene i miei dati personali?</B> No! Un .torrent non riporta nessun tipo di informazione su di te, ne il tuo ip!
<li><B>Posso rendermi anonimo durante il download?</B> Sicuro! Per avere maggiore anonimato puoi usare un <a href='http://www.multiproxy.org/anon_proxy.htm' target=_blank>proxy</a> per l'upload e il download dei .torrent
<li><B>Cosa posso e non posso condividere?</B> Di regola tutto ci� che pu� essere condiviso. Pertanto � assolutamente vietato condividere file protetti da diritto d'autore, materiale razzista/violento/offensivo/virus, o che possa infrangere una qualsiasi legge. Chi condivide file � responsabile del file che condivide. Noi non siamo responsabili per nessun file. Tutto ci� che non appartiene alle precedenti categorie pu� essere liberamente condiviso.
</ul>
</p>

<p>
<a name='copy'><b>Puoi tranquillamente usare qualsiasi torrent, ma ricordati di rispettare la privacy. Pi� torrent inserirai meglio andr� il sito. Uno al giorno � un valore ideale. Ricordati che puoi uppare solo torrent con fonti.</b></a><br>
</p>

<p>
<a name='timeout'><b>Non riesco a fare l'upload del file torrent, esce una pagina bianca</b></a><br>
Probabilmente il tracker specificato dal torrent � sotto sforzo, riprova tra qualche ora.
</p>

<p>
<a name='network'><b>In quale caso il sistema genera i link a Gnutella e Edonkey Emule?</b></a><br>
Quando il torrent viene creato con <a href='http://www.torrentaid.com' target='_blank'>TorrentAid</a>. Questa nuova tecnologia si sta diffondendo molto rapidamente, ed � infatti inclusa nell'ultima release di <a href="http://azureus.sourceforge.net">Azureus</a>.
<BR>A titolo di cronaca: TUTTI i prodotti utilizzati per la tecnologia Bit Torrent sono Open Source!
</p>


<?

CloseTable();

?>