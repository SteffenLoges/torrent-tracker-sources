<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
global $name,$db, $nukeurl;
require_once("modules/$name/include/bittorrent.php");
OpenTable();
stdhead();
$imagetutorial = "modules/$name/pic/tutorial/";
?>
<H1><FONT face="Verdana, Arial, Helvetica, sans-serif" color=#cc3300
size=6><STRONG>Guida a Bit-Torrent <FONT color=#336699 size=2>by <A
href="mailto:bittorrent@supereva.it">ZackS</A></FONT></STRONG></FONT></H1>
<P>&nbsp;</P>
<P><STRONG><FONT face="Verdana, Arial, Helvetica, sans-serif" color=#000000
size=2>Indice<BR><BR></FONT></STRONG><STRONG><FONT color=#000000><A
href="#1">Cos'�
Bit-Torrent</A></FONT></STRONG><BR><STRONG><FONT color=#000000 size=2><A
href="#2">Download
di un file</A></FONT></STRONG><BR><STRONG><FONT color=#336699 size=2><A
href="#3">Upload
di un file</A></FONT></STRONG><FONT size=2><BR><STRONG><FONT color=#336699><A
href="#4">Fare da
seeder di un file</A></FONT></STRONG><BR><STRONG><FONT color=#336699><A
href="#5">Cosa
fare e non fare</A><BR><A
href="modules.php?name=News&amp;file=article&amp;sid=796&amp;mode=nested&amp;order=0&amp;thold=0"
target=_blank>Privacy e file privati, perch�?</A><BR><A
href="#6">IRC
</A>
<A href="#fastweb">Bit Torrent Azereus in Lan tipo Fastweb</A></FONT></STRONG></FONT></P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<P><FONT face="Verdana, Arial, Helvetica, sans-serif" color=#000000 size=2><A
name=1></A><FONT color=#336699 size=4><STRONG>Cos'�
Bit-Torrent</STRONG></FONT></FONT></P>
<P><FONT color=#000000 size=2>Bit-Torrent � un client P2P che permette di
scaricare e condividere file (fino a qui ci siamo :D).<BR>Qual � il suo punto di
forza? Il poter scaricare un file con la massima banda in download dell'utente
senza le noiose code.</FONT><BR><FONT
face="Verdana, Arial, Helvetica, sans-serif" size=2>Il classico problema che si
pu� presentare su un server, su un sito o su altri client P2P � il non poter
riuscire a far fronte alle richieste di download per la poca banda a
disposizione.</FONT></P>
<P><IMG height=407 src="<?=$imagetutorial?>central.gif" width=499></P>
<P>Bit-Torrent usa un'altro sistema, facile e ingegnoso, ogni utente che scarica
un file diventa contemporaneamente una fonte dello stesso file anche se il
download non � stato completato, e cos� via, quindi pi� persone scaricano lo
stesso file maggiore sar� la banda a disposizione. </P>
<P>Per chiarire, il primo utente inizia a scaricare dalla fonte principale alla
massima velocit� possibile dato che � l'unico utente, contemporaneamente (dunque
prima che abbia terminato il download), rende disponibile ad altri utenti la
parte di file scaricata. Il secondo utente che richiede il file lo scarica dal
primo utente anzich� dalla fonte principale, il terzo utente lo scarica dal
secondo (e contemporaneamente anche dal primo, se ha ancora banda disponibile);
il quarto dal terzo e da tutti gli altri che hanno ancora banda disponibile, e
cos� via.</P>
<P><IMG height=407 src="<?=$imagetutorial?>torrent.gif" width=499></P>
<P>NB: <BR>- Chi fa da fonte di un file completo viene detto <STRONG><FONT
color=#000000 size=2>Seeder</FONT></STRONG><FONT color=#000000 size=2>,
chi</FONT> fa da fonte di un file non ancora completo viene detto <STRONG><FONT
color=#000000>Leecher</FONT></STRONG><FONT color=#000000>.<BR></FONT><BR>- In
questa guida mostrer� l'utilizzo di un client alternativo (Azureus) a quello di
Bit-Torrent.<BR></P>
<P>&nbsp;</P>
<P><STRONG><FONT color=#336699 size=4><A name=2></A>Download di un
file</FONT></STRONG></P>
<P><FONT face="Verdana, Arial, Helvetica, sans-serif" color=#000000
size=2><EM>File essenziali:</EM></FONT></P>
<UL>
  <LI><A title="Azureus client Java" href="http://azureus.sourceforge.net/"
  target=_blank>Azaureus client Java</A>
  <LI><A title="Java jre 1.4.1_05"
  href="http://java.sun.com/j2se/1.4.1/download.html" target=_blank>Java jre
  1.4.1_05</A> </LI></UL>
<P>Primi passi da compiere:</P>
<OL>
  <LI>Installare prima <A title="Java jre 1.4.1_05"
  href="http://java.sun.com/j2se/1.4.1/download.html" target=_blank>Java jre
  1.4.1_05</A>
  <LI>Installare dopo il client <A title="Azureus client Java"
  href="http://azureus.sourceforge.net/" target=_blank>Azureus </A>
  <LI><A
  href="modules.php?name=Your_Account&amp;op=new_user"
  target=_blank>Iscriversi sul sito</A>
  </LI></OL>
<P>Ora andate nelle sezione <A title=Bit-Torrent
href="modules.php?name=Bittorrent"
target=_blank>Bit-Torrent</A> del sito, vi comparir� una finestra come
questa:</P>
<P><IMG height=258 src="<?=$imagetutorial?>1.gif" width=764></P>
<P>&nbsp;</P>
<P>Per scaricare un file basta clickare sulla voce <FONT
color=#000000><STRONG>torrent :</STRONG></FONT></P>
<P><STRONG><FONT color=#cc3300><IMG height=64
src="<?=$imagetutorial?>2.gif" width=288></FONT></STRONG></P>
<P>&nbsp;</P>
<P><FONT color=#000000 size=2>La richiesta verr� inoltrata, successivamente al
proprietario del file arriver� una segnalazione tramite email e nella propria
sezione <A title="xxxx's Torrent"
href="modules.php?name=Bittorrent&amp;file=mytorrents"
target=_blank>xxxx's Torrent</A>:</FONT></P>
<P><IMG height=39 src="<?=$imagetutorial?>20.gif" width=703></P>
<P>&nbsp;</P>
<P>Una volta concessa l'autorizzazione vi arriver� la notifica tramite email,
seguite il link segnalato per visualizzare i dettagli del file e clickate sul
nome:</P>
<P><IMG height=204 src="<?=$imagetutorial?>21.gif" width=665></P>
<P><STRONG>IMPORTANTE: Una volta autorizzati da un utente, potere scaricare
tutti i file uppati da lui, anche futuri, senza inoltrare la richiesta una
seconda volta.</STRONG></P>
<P>&nbsp;</P>
<P>Automaticamente <STRONG>Azureus</STRONG> si aprir� mostrandovi una finestra
per scegliere dove allocare il file:</P>
<P><IMG height=313 src="<?=$imagetutorial?>3.gif" width=327></P>
<P>&nbsp;</P>
<P>Nel caso vi appaia la finestra del download di Windows scegliere l�opzione
"Apri il file dal percorso corrente":</P>
<P><IMG height=325 src="<?=$imagetutorial?>4.gif" width=442></P>
<P>&nbsp;</P>
<P>Una volta scelta la destinazione, <STRONG>Azureus</STRONG> allocher� il
file:</P>
<P><IMG height=22 src="<?=$imagetutorial?>5.gif" width=608></P>
<P>&nbsp;</P>
<P>Trovate le fonti il download parte:</P>
<P><IMG height=19 src="<?=$imagetutorial?>6.gif" width=710></P>
<P>Il gioco � fatto ;-)</P>
<P>Nel caso vogliate interrompere il download potere riprenderlo in un secondo
momento, il <STRONG>resume � supportato</STRONG>, basta avviare nuovamente
Azureus.<BR></P>
<P>&nbsp;</P>
<P><STRONG><FONT color=#336699 size=3><FONT size=4><A name=3></A>Upload di un
file</FONT><EM><U> </U></EM></FONT></STRONG></P>
<P><EM>File essenziali:</EM></P>
<UL>
  <LI><A title=Maketorrent
  href="http://krypt.dyndns.org:81/torrent/maketorrent/"
  target=_blank>Maketorrent</A> </LI></UL>
<P>Primi passi da compiere:</P>
<OL>
  <LI>Installare <A title=Maketorrent
  href="http://krypt.dyndns.org:81/torrent/maketorrent/"
  target=_blank>Maketorrent</A> ;-D </LI></OL>
<P>Una volta installato Maketorrent avviatelo, vi dovrebbe comparire una
finestra come questa:</P>
<P><IMG height=446 src="<?=$imagetutorial?>7.gif" width=461></P>
<P>&nbsp;</P>
<P>Per prima cosa inserite il tracker del sito, del tipo: <FONT
color=#000000><STRONG>http://sitodiprova.com/announce.php</STRONG></FONT></P>
<P><IMG height=446 src="<?=$imagetutorial?>8.gif" width=461></P>
<P>&nbsp;</P>
<P>Ok, adesso dobbiamo creare il nostro file <STRONG>.torrent</STRONG>, per fare
questo dobbiamo prendere alcuni accorgimenti, il file non deve contenere nessun
punto (<STRONG><FONT color=#ff0000>.</FONT></STRONG>) tranne quello che serve
per l'estensione, esempio il file [DivX] Seven<STRONG><FONT
color=#ff0000>.</FONT></STRONG>ITA<FONT
color=#3366cc><STRONG>.avi</STRONG></FONT> deve essere rinominato in [DivX]Seven
ITA<FONT color=#3366cc><STRONG>.avi<FONT
color=#000000>.</FONT></STRONG></FONT></P>
<P>Cerchiamo il file interessato tra le directory del nostro hardisk, una volta
trovato selezioniamolo e clickiamo sul pulsante "Create .torrent":</P>
<P><IMG height=443 src="<?=$imagetutorial?>9.gif" width=462></P>
<P>&nbsp;</P>
<P>Se quello che volete uppare � composto da pi� file, <STRONG><FONT
color=#000000>non create un .torrent per ogni file</FONT></STRONG> ma mettete i
file dentro una cartella e specificate a Maketorrent tale cartella.<BR>Per far
questo basta clickare sul pulsante "Simple", selezionare "1 torrent from entire
folder", clickare sul pulsante "(dir)" e selezionare la cartella.</P>
<P><IMG height=448 src="<?=$imagetutorial?>11.gif" width=489></P>
<P>&nbsp;</P>
<P>Adesso dobbiamo decidere dove salvare il nostro file <STRONG><FONT
color=#000000>.torrent</FONT></STRONG>:</P>
<P><IMG height=345 src="<?=$imagetutorial?>10.gif" width=563></P>
<P>&nbsp;</P>
<P>Scelta la destinazione Maketorrent comincer� a creare il nostro file
<STRONG>.torrent</STRONG></P>
<P><STRONG><IMG height=160 src="<?=$imagetutorial?>12.gif"
width=453></STRONG></P>
<P>&nbsp;</P>
<P>Adesso nella sezione<STRONG> <A title=Bit-Torrent
href="modules.php?name=Bittorrent"
target=_blank>Bit-Torrent</A></STRONG> del sito selezioniamo la voce "<FONT
color=#cc3300><STRONG><A title=Upload
href="modules.php?name=Bittorrent&amp;file=upload"
target=_blank>Upload</A></STRONG></FONT>", clickiamo sul pulsante "Scegli" per
selezionare il nostro file <STRONG><FONT color=#000000>.torrent</FONT></STRONG>,
finiamo di compilare il resto dei campi e clickiamo su "Do it".</P>
<P><IMG height=550 src="<?=$imagetutorial?>13.gif" width=755></P>
<P>&nbsp;</P>
<P>Finito l'upload se tutto � andato bene sarete portati alla schermata con i
dettagli del file.<BR><FONT color=#000000 size=2><STRONG>Cosa ultima e
importantissima, dovete rendere visibile il vostro file</STRONG></FONT>, per far
questo dovete lanciare per la prima volta il vostro file dal sito e specificare
come destinazione il vostro file completo.</P>
<P><IMG height=447 src="<?=$imagetutorial?>14.gif" width=625></P>
<P><STRONG>Azureus</STRONG> controller� il file, finito il check sarete seeder
del vostro file.<BR>Upload completato! :-)</P>
<P>Il vostro file da adesso � classificato come<STRONG>
privato</STRONG>.<BR>Ogni utente che chiede di scaricare il vostro file ha
bisogno della vostra autorizzazione.<BR>Tramite email o nella vostra sezione
<FONT color=#000000 size=2><A title="xxxx's Torrent"
href="modules.php?name=Bittorrent&amp;file=mytorrents"
target=_blank>xxxx's Torrent</A></FONT> potete controllare le richieste, avete
la falcolt� di autorizzare tutti gli utenti o solo una parte:</P>
<P><IMG height=133 src="<?=$imagetutorial?>22.gif" width=415></P>
<P><STRONG>IMPORTANTE: Una volta concessa l'autorizzazione, ogni futura
richiesta di quell'utente verr� automaticamente accetta su qualsiasi file uppato
da voi.</STRONG></P>
<P>&nbsp;</P>
<P>
<P><STRONG><FONT color=#336699 size=4><A name=4></A>Fare da seeder di un
file</FONT></STRONG></P>
<P><FONT color=#000000 size=2>Si pu� fare da seeder in tre maniere:</FONT></P>
<OL>
  <LI><FONT color=#000000 size=2>Facendo l'<A
  href="#3">upload</A>
  di un proprio file.</FONT>
  <LI><FONT color=#000000 size=2>Completando il </FONT>download di un file.
  (<STRONG>Azaureus</STRONG> vi metter� automaticamente come seeder)
  <LI><FONT color=#000000 size=2>Segnalandosi come fonte completa di un file
  messo in upload da un altro utente.</FONT> </LI></OL>
<P><FONT color=#000000 size=2>Vediamo di analizzare il terzo caso.</FONT></P>
<P><FONT color=#000000 size=2>Mettiamo il caso che l'utente Siffredi abbia fatto
l'upload del file [DivX - ITA] Il Gladiatore.avi da 800 Mb, nel mio hard disk ho
lo stesso film anche se con un nome diverso, per esempio Il Gladiatore.avi da
800 Mb.<BR>Per diventare seeder dobbiamo fare il download di quel file,
specificando come destinazione il file che abbiamo nel nostro hard disk, Azureus
controllera che i due file siano perfettamente uguali (stesso hash), nel caso
l'esito sia positivo diventeremo seeder.</FONT></P>
<P><FONT color=#000000 size=2>Passiamo alla pratica, nella lista dei file
disponibili c'� [XviD - ITA]Il Monaco.avi:</FONT></P>
<P><FONT color=#000000 size=2><IMG height=64
src="<?=$imagetutorial?>15.gif" width=514></FONT></P>
<P><FONT color=#000000 size=2>Clickando su <STRONG>torrent </STRONG>partir� il
download del file, come destinazione sceglieremo il file che possediamo sul
nostro hard disk:</FONT></P>
<P><FONT color=#000000 size=2><IMG height=443
src="<?=$imagetutorial?>16.gif" width=569></FONT></P>
<P>Azureus fare il check per vedere se i due file sono uguali:</P>
<P><IMG height=23 src="<?=$imagetutorial?>17.gif" width=540></P>
<P>Nei dettagli:</P>
<P><IMG height=143 src="<?=$imagetutorial?>18.gif" width=723></P>
<P>Nel caso sia uguali diventeremo seeder:</P>
<P><IMG height=25 src="<?=$imagetutorial?>19.gif" width=716></P>
<P>Operazione completata ;-)</P>
<P>&nbsp;</P>
<P><STRONG><FONT color=#336699 size=4><A name=5></A>Cosa fare e non
fare</FONT></STRONG></P>
<UL>
  <LI>Fate sempre da seeder dei vostri file, altrimenti nessuno potr�
  completarli ;-)<BR><BR>
  <LI><STRONG>Controllate spesso la vostra email o la vostra sezione
  </STRONG><FONT color=#000000 size=2><A title="xxxx's Torrent"
  href="modules.php?name=Bittorrent&amp;file=mytorrents"
  target=_blank>xxxx's Torrent</A></FONT> <STRONG>per visualizzare eventuali
  richieste di download.</STRONG><BR><BR>
  <LI>Non posizionate <STRONG>MAI</STRONG> i file che state scaricando nella
  stessa cartella di DC++ o WinMX. Bit-Torrent (o qualsiasi altro client alternativo)
  quando fa il download crea un file di dimensioni uguali a quello che state
  scaricando, successivamente lo "riempie", quindi gli utenti di DC++ vedranno
  un file completo per quanto riguarda i megabyte ma non completo a livello di
  struttura, con la conseguenza che sar� inutilizzabile e probabilmente vi coster�
  il ban dal server a cui siete collegati.<BR><BR>
  <LI>Prima di fare un upload controllate se il vostro file � gi� presente, in
  questo caso seguite la procedura per fare da <A
  href="#4">seeder</A>.<BR><BR>
  <LI>Un commento sul file � sempre gradito, soprattutto riguardo la qualit�
  audio e video dei film ;-)<BR><BR>
  <LI>Se avete poca banda in upload, non caricatevi di troppi seeders, cercate
  di fare una distribuzione equa.<BR><BR>
  <LI>Una volte finito il download, se vedete che ci sono pochi seeders di quel
  file non esitate a diventarlo.<BR><BR>
  <LI>Se avete un file condiviso in comune a Dc++ ricordate di avviare prima
  Bit-torrent, in caso contrario vi segnaler� un errore di lettura. </LI></UL>
<P><A name=6></A><STRONG><FONT color=#336699 size=4>IRC</FONT></STRONG></P>
<P><FONT color=#000000 size=2>Con <STRONG>Azureus </STRONG>� possibile
connettersi a un server IRC, funzione utile per dialogare con altri
utenti.<BR>Andate su "Visualizza" , " Configurazione" e nella sezione Irc
compilate i campi, in questo caso "Server" <STRONG>irc.raulken.it</STRONG>,
"Channel" <STRONG>#Raulken</STRONG> e "Nickname" il nome che volete usare per
chattare.<BR>Clickate sul pulsante "Salva" e chiudete la finestra.</FONT></P>
<P>&nbsp;</P>
<P><FONT color=#000000 size=2><IMG height=134
src="<?=$imagetutorial?>23.gif" width=411></FONT></P>
<P>&nbsp;</P>
<P><FONT color=#000000 size=2>Per connettersi basta andare su "Visualizza",
"Irc", si aprir� una finestra che mostrer� le informazioni relative alla
connessione al server IRC.<BR>Ora potete chattare ;-)</FONT></P>
<P>&nbsp;</P>
<P><IMG height=402 src="<?=$imagetutorial?>24.gif" width=672></P>
<P>&nbsp;</P>
<P><A name=fastweb></A><STRONG><FONT color=#336699 size=4>Usare Azereus anche in LAN come fastweb</FONT></STRONG></P>
<P>Gli utenti in lan non possono scambiarsi file direttamente perch� risultano entrambi passivi su internet, per risolvere il problema e permettere di scaricare anche degli utenti dentro la stessa lan abbiamo modificato il nostro tracker alla quale modifica bisogna aggiungere un ultimo parametro di configurazione. Anticipiamo che � molto + facile effettuare questa modifica usando Azereus, per questo basiamo il esempio su questo client che consigliamo a tutti gli utenti fastweb di scaricare. Il primo passo � ottenere il proprio ip interno, carichiamo il PROMPT DI MS-DOS ed eseguiamo il comando <b>ipconfig</b> e annotiamo l'ip corrispondente su un foglio di carta.</P>
<P><IMG src="<?=$imagetutorial?>ipconfig.gif"></P>
<P>Carichiamo Azereus e andiamo nel menu di configurazione, inseriamo nella casella "Sovrascrivi indirizzo da inviare al tracker (NAT)" l'ip che ci eravamo segnati, non resta che fare click su SALVA e riavviare Azereus, questo � tutto.</P>
<P><IMG src="<?=$imagetutorial?>azereusfastweb.jpg"></P>
<P>&nbsp;</P>
Puoi distribuire liberamente questa guida senza effettuare nessuna modifica ai link al sito www.raulken.it e all'email di ZackS
<?
CloseTable;

?>