<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
global $name,$db;
require_once("modules/$name/include/bittorrent.php");
OpenTable();
stdhead();
?>

<h2>Guida base per rendere la tua connessione attiva</h2>
<p>
<a href='#question'>Che vuol dire connessione attiva o passiva?</a><br>
<a href='#fastweb'>Sono un utente fastweb cosa posso fare?</a><br>
<a href='#lan'>Sono un utente lan (non fastweb) cosa posso fare?</a><br>
<a href='#anyconnection'>Sono un utente ne fastweb ne lan cosa posso fare?</a><br>
<a href='#seeip'>Come vedo il mio ip?</a><br>
<a href='#firewall'>A cosa serve il firewall?</a><br>
<a href='#test'>Voglio fare il test per vedere se sono attivo!</a><br>

<p>
Ricordiamo una cosa fondamentale:Un utente <b>fastweb o LAN</b> potr� avere benefici di download solamente da tracker marchiati (con il link a www.raulken.it) <b>"BitTorrent RAULKEN.IT ottimizzato per fastweb"</b> qualsiasi altro marchio o sigla da noi non certificata non vi dar� alcuna garanzia! Le ottimizzazioni sono inutili su qualsiasi altro tracker. I torrent esterni presenti su raulken.it potrebbero non avere il nostro marchio. Quando navighi su un sito che presenta in basso su tutte le pagine il nostro marchio allora stai navigando su un tracker ottimizzato per fastweb e lan.
</p>

<p>
<a name='question'><b>Che vuol dire connessione attiva o passiva?</b></a><br>
In un collegamento internet standard un qualsiasi computer pu� collegarsi con quasi altro, ovviamente ognuno deve avere il suo indirizzo internet (IP), in questo caso parliamo di connessione dove entrambi gli utenti sono attivi. In altri casi capita che molti utenti condividano la stessa connessione internet, ovvero lo stesso IP. A questo punto quando dall'esterno (da internet) si riceve una connessione il rooter (colui che condivide la stessa connessione con pi� utenti) impazzisce non sapendo a chi assegnare, tra i pc interni, la connessione. In pratica la coneessione si perde senza arrecare nessun danno al rooter. L'inverso, cio� un utente interno verso un utente esterno, � possibile. In quest'ultimo caso parliamo di connessione passiva. Durante una connessione passiva possiamo sia scaricare che inviare dati SOLO con utenti attivi, e questo limite fa perdere proprio le connessioni + veloci fastweb e lan aziendali. Il limite di non poter collegarsi tra passivi deriva dal fatto che una connessione proveniente da un PC interno al rooter A, non pu� entrare in comunicazione diretta con un PC interno al rooter B, che impazzisce, e naturalmente non � possibile neanche il viceversa. Anche utilizzando un firewall non correttamente configurato nonostante non si usi una lan si diventa passivi, a tal <a href='#firewall'>consigliamo la lettuta di questa FAQ Firewall</a>.
</p>

<p>
<a name='fastweb'><b>Sono un utente fastweb cosa posso fare?</b></a><br>
Siccome sei un utente fastweb sei dientro una LAN e non hai un tuo ip internet esclusivo, ma usi un ip condiviso con altre persone della tua stessa citt� (questo � l'unico GROSSO difetto fastweb). Puoi fin da subito dimenticare di scaricare da lan aziendali, tuttavia questa � una cosa irrilevante per un fastweb. I fastweb infatti possono configurare il proprio PC in maniera tale da poter scaricare tra altri FASTWEB felicemente a velocit� straordinarie.<br>
<table>
<tr><th>Programma usato</th><th>Cosa fare</th></tr>
<tr><td>Bit Torrent standard per principianti</td><td><a href='http://azureus.sourceforge.net' target="_blank">Installare Azuresus</a> (solo il sito � in inglese, il programma � tradotto da noi in italiano. Necessita dell'installazione di Java) e poi <a href="modules.php?name=<?=$name?>&file=help">leggere la guida a configurazione Azureus in fastweb</a></td></tr>
<tr><td>Azureus</td><td><a href="modules.php?name=<?=$name?>&file=help">Leggere la guida Configurazione Azureus in Fastweb</a></td></tr>
<tr><td>Shareaza</td><td><a href="modules.php?name=<?=$name?>&file=index_help#bestshareaza">Leggere la guida Configurazione Shareaza in Fastweb</a></td></tr>
</table>
</p>

<p>
<a name='fastweb'><b>Sono un utente lan (non fastweb) cosa posso fare?</b></a><br>
Siccome sei un utente dientro una LAN e non hai un tuo ip internet esclusivo, ma usi un ip condiviso con altre persone della tua stessa LAN puoi fin da subito dimenticare di scaricare da altre lan aziendali o fastweb. Tuttavia ricorda che bit torrent � un protocollo che premia le linee veloci, quindi se ci sar� un buon numero di connessioni attive per i torrent che stai scaricando puoi avere ottime possibilit� di andare pi� veloce di numerose ADSL. Puoi cmq provare a configurare il tuo pc utilizzando fastweb e seguendo i consigli dati ai fastweb ma ricorda che non potrai MAI scaricare dai fastweb o altre LAN, questo ti consentir� di migliorare notevolmente solamente nel raro caso in cui qualche altro utente della tua stessa lan stia scaricando lo stesso file.
</p>

<p>
<a name='anyconnection'><b>Sono un utente ne fastweb ne lan cosa posso fare?</b></a><br>
La prima cosa da fare � <a href='#test'>eseguire il test</a>, se risulti attivo non devi fare niente altro, se risulti passivo devi cercare in tutti i modi di diventare attivo seguendo i nostri consigli, nel caso dovessi scoprire qualche altro metodo ti inviatiamo a contattarci e segnalarlo.
</p>

<p>
<a name='seeip'><b>Come vedo il mio ip?</b></a><br>
In windows si carica il prompt di ms-dos e si scrive:<br>
<b>ipconfig</b><br>
Il risultato sar� qualche cosa del tipo (i numeri mostrati nell'esempi sono a caso):<br>
<code>Indirizzo IP. . . . . . . . . . . . . : 181.250.230.157</code><br>
Nell'esempio il vostro ip (interno) � 181.250.230.157, che nel caso di connessione standard non fastweb o lan corrisponde all'ip esterno.
</p>

<p>
<a name='firewall'><b>A cosa serve il firewall?</b></a><br>
Impedisce alle connessioni esterne di mettersi in contatto col vostro pc, questo limita notevolmente il p2p e trasforma la vostra connessione in passiva. Utenti veramente esperti possono configurare il firewall in maniera tale che non limiti i programmi p2p, negli altri casi consigliamo di disattivare il firewall. Eseguite prima il <a href='#test'>test</a> per capire se il vostro firewall vi limita in qualche maniera.
</p>

<p>
<a name='test'><b>Voglio fare il test per vedere se sono attivo!</b></a><br>
<?
$ip = $_SERVER["REMOTE_ADDR"];
$sql = "SELECT * FROM torrent_check_peers WHERE true_ip='$ip'";
$result = $db->sql_query($sql);
$row = $db->sql_fetchrow($result);
if(!$row){
        echo "Per cominciare il test, dopo aver scaricato ed installato un client bit torrent, deve lanciare il <a href='modules/$name/cancellami.txt.torrent' target='_blank'>download di questo torrent di prova facendo click qui</a>.";
}else{
        echo "Risultati del <a href='modules/$name/cancellami.txt.torrent' target='_blank'>Torrent di prova facendo click qui</a>.<br>";
        echo "IP utilizzato attualmente per navigare: <b>$ip</b><br>";
        echo "IP vero utilizzato che risulta utilizzato durante la connessione al tracker: <b>".$row[true_ip]."</b><br>";
        echo "IP che il client bittorrent comunica al tracker come sostituto di quello vero: <b>".$row[ip]."</b><br>";
        echo "Porta aperta (ogni torrent apre una porta): <b>".$row[port]."</b><br>";
        if($row[connectable]=="yes") echo "Modalit� ATTIVA, va bene cos� non bisogna effettuare nessuna modifica.<br>";
        else echo "Modalit� Passiva, vedere il resoconto per dei consigli.<br>";
        echo "Data ora ultimo aggiornamento tracker: <b>".$row[data]."</b><br>";
        if($row[connectable]!="yes"){
                echo "<p>Resoconto per provare a entrare in modalit� attiva:<br><ol>";
                if($row[ip]!=$row[true_ip])
                        echo "<li> IP comunicato al TRACKER e IP che veramente si � collegato al TRACKER sono discordi, provare a non forzare la modifica dell'ip nel tracker";
                echo "<li> Se hai attivo un firewall prova a disattivarlo, a chiudere e ricaricare il torrent per il test e ricaricare questa pagina. Se usi WinXP ricorda che oltre ai firewall che installi c'� anche un firewall nativo che va disattivando facendo propriet� sulla connessione nel menu START";
                echo "</ol> Quando effettui dei test prima di fare reload ricordati di guardare la data e ora di ultimo aggiornamento tracker, se noti che � sempre la stessa significa che il tracker non ha ancora effettuato nuovi controlli dall'ultimo";
        }


}


?>

</p>

<?CloseTable();?>