<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
global $name,$db, $nukeurl, $sitename;
require_once("modules/$name/include/bittorrent.php");
OpenTable();
stdhead();
?>

<h2>Guida base all'uso di bit torrent su <?=$nukeurl?></h2>

<a href='#network'>Cosa significa "Fonti Alternative"?</a><br>
<a href='#infohash'>A cosa serve il campo "Info hash"?</a><br>
<a href='#visible'>Come mai il campo Visibile indica NO?</a><br>
<a href='#edit'>Come faccio a modificare o cancellare il torrent?</a><br>
<a href='#stats'>Le statistiche sono veritiere?</a><br>
<a href='#ip'>Verr� mai mostrato il mio ip? Sono anonimo?</a><br>

<p>
<a name='network'><b>Cosa significa "Fonti Alternative"?</b></a><br>
Se il torrent � stato costruito utilizzando la tecnologia torrentaid permette il download del file anche attraverso altri network non bit torrent. Se si utilizza <a href='modules.php?name=<?=$name?>&file=index_help#install'>shareaza</a> oltre alle fonti bit torrent si potr� anche godere delle fonti di altri sistemi di fileshare, veramente utile! Inoltre se il file � fatto con tecnologia torrentaid ed � un insieme di file � possibile anche scaricare un singolo file utilizzando un network alternativo a bit torrent, per trovare il link al singolo file fare clik sulla voce file del torrent. Anche questa funzionalit� � molto utile in caso di raccolte molto grandi.
</p>

<p>
<a name='infohash'><b>A cosa serve il campo "Info hash"?</b></a><br>
Viene utilizzato da bit torrent per identificare il torrent in maniera univoca, � un campo che viene utilizzato solo a scopo informativo. Viene determinato durante la creazione del file torrent automaticamente e viene utilizzato da bit torrent per la verifica del corretto trasfermento dei dati.
</p>

<p>
<a name='visible'><b>Come mai il campo Visibile indica NO?</b></a><br>
Il campo visibile definisce se il torrent viene di default visualizzato sul sito o meno. Di solito un torrent senza fonti viene definito morto e quindi � inutile che venga visualizzato. Dipende da vari casi:
<ul>
<li>Upload torrent<br>
                Tutti i torrent che utilizzano il nostro tracker interno devono prima ricevere un seeder per essere visibili a tutti
<li>Nessuna fonte<br>Periodicamente verifichiamo che i nostri torrent abbiano fonti, in caso negativo provvediamo a dichiarare morti i torrent e non li visualizziamo tranne che nelle ricerche su richiesta. Potrebbe anche capitare che il tracker esterno sia sovraffollato e non riesca a fornirci le statistiche
</ul>
</p>

<p>
<a name='edit'><b>Come faccio a modificare o cancellare il torrent?</b></a><br>
Esiste nel dettaglio un apposito link [edit], puoi modificare/cancellare solo se sei il proprietario.
</p>

<p>
<a name='stats'>Le statistiche sono veritiere?</a><br>
Le statistiche sono facilmente falsificabili compresi gli ip. Per cui non fate affidamento su quello che vedete, � da intendersi come orientativo.
</p>

<p>
<a name='ip'>Verr� mai mostrato il mio ip? Sono anonimo?</a><br>
Il tuo ip verr� mostrato in forma incompleta, tuttavia tramite appositi software come <a href='modules.php?name=<?=$name?>&file=index_help#install'>azureus</a> � possibile vederlo facilmente! Puoi mantenere un minimo di anonimato facendo l'upload dei file utilizzando un proxy. Non � detto che una fonte sia cosciente di quello che sta scaricando, e non � detto che una fonte che si dichiara completa lo sia veramente. E' quindi impossibile determinare a monte chi � cosciente di quello che sta scaricando o individuare ip che condividono con 100% di sicurezza un determinato file. Nel caso di Torrent a tracker esterno <?=$sitename?> non memorizza ip ma effettua solo delle richieste di statistiche, questo spiega perch� non vengono visualizzati neanche parzialmente.
</p>


<?
CloseTable();
?>