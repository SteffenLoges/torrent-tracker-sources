<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
global $name,$db, $nukeurl;
require_once("modules/$name/include/bittorrent.php");
OpenTable();
stdhead();
?>

<h2>Guida base all'uso di bit torrent su <?= $nukeurl ?></h2>
<p>
<a href='#is'>Cos'� Bittorrent?</a><br>
<a href='#torrent'>Cosa sono i file torrent?</a><br>
<a href='#install'>Cosa devo installare?</a><br>
<a href='#function'>Come funziona?</a><br>
<a href='#search'>Come si ricerca?</a><br>
<a href='#maxupload'>Come mai mi riporta una velocit� di upload e come faccio a settare un massimo?</a><br>
<a href='#tracker'>Cos'� il tracker e cosa sono gli errori del tracker?</a><br>
<a href='#seeder'>Come faccio a fare da seeder?</a><br>
<a href='#upload'>Come faccio a condividere o fare l'upload del file torrent?</a><br>
<a href='#speed'>Perch� vado lento o non parte proprio?</a><br>
<a href='#privacy'>Perch� tutti i file sono privati?</a><br>
<a href='#bestshareaza'>Come posso configurare al meglio Shareaza?</a><br>
<a href='#partner'>Cosa posso fare per rendere questo servizio pi� veloce e migliore?</a><br>
<a href='#legacy'>E' legale?</a><br>
<a href='#antipiracy'>Che sistema antipirateria e anti pedofilia sono utilizzati? Cosa sono i filtri?</a>
</p>
<p>Vi consigliamo inoltre a tutti la lettura di:
<a href='#shareaza'>Che novit� introduce Shareaza?</a><br>
<a href='modules.php?name=<?=$name?>&file=upload_help'>Come condivido faccio upload? Come creo dei torrent di nuova tecnologia?</a><br>
<a href='#codec'>Come mai l'audio e disalineato o non vedo/sento?</a><br>
<a href='#open'>Come apro i seguenti file?</a>
</p>

<p>
<a name='is'><b>Cos'� Bittorrent?</b></a><br>
Torrent � un software P2P per condividere file, ha il resume ed � multidownload, cio� pi� fonti per lo stesso file! Non esistono code e in pochi minuti si comincia a scaricare ed � velocissimo. Entra anche tu :D<br>
In termini tecnici � costituito da:
<ol>
<li>un server centrale chiamato <b>Tracker</b> che contiene l'elenco di tutti gli utenti che condividono un file
<li>da un <a href='#torrent'>file con estensione .torrent</a> che contiene informazione sul file/cartella condivisa e l'indirizzo del tracker per recuperare le fonti
<li>dai <b>seeder</b> che sono gli utenti che condividono il file completo e dai <b>leech</b>, cio� gli utenti che mentre scaricano diventano fonti attive per le parti gi� scaricate
<li>dal <a href='#install'>software che si installa</a> per scaricare, senza il quale si riceve un errore quando si fa click sul link per il download dei torrenti condivisi
</ol>
Su questo server non sono contenuti i file, ma solo i <a href='#torrent'>torrent</a>, inoltre su questo server non � disponibile un tracker ma solo torrent a tracker esterni privati, � compito del proprietario del tracker gestire privatamente gli accessi ai file e verificarne la legalit�. Bit Torrent � assolutamente gratis e non contiente dialer o spyware adware, potresti trovare qualche tracker a pagamento ma questa � un'altra cosa. Se il sito indica che � per maggiorenni i minorenni non possono utilizzarlo, se non indicato i minorenni possono utilizzare questo servizio solo sotto la supervisione di un maggiorenne.
</p>

<p>
<a name='torrent'><b>Cosa sono i file torrent?</b></a><br>
Sono i file che descrivono ogni file o cartella che si decide di condividere. Contine al suo interno nome, dimensione, codici di verifica di trasferimento dati e la cosa pi� importante, ovvero l'indirizzo del <a href='#tracker'>tracker</a> per ottenere le fonti da cui scaricare. I file torrent si trovano su siti appositamente dedicati a bit torrent, come questo sito.
</p>

<p>
<a name='install'><b>Cosa devo installare?</b></a><br>
Esistono diversi programmi per utilizzare bit torrent, in base all'uso che ne vuoi fare, al tuo sistema operativo e al tuo tipo di linea, scegline uno o pi� di uno. Dopo ogni installazione � consigliato un riavvio del pc.
<ul>
<li>Se sei un grande principiante e vuoi solamente scaricare ed hai windows(qualsiasi versione) o Mac OS scarica la <a href='http://bitconjurer.org/BitTorrent/download.html' target='_blank'>versione standard di bit torrent</a>
<li>Se sei diventato abbastanza bravo e usi windows qualsiasi versione puoi usare <a href='http://www.shareaza.com/download' target='_blank'>Shareaza <img src='modules/<?=$name?>/pic/shareazabutton.gif' border=0>(in Italiano, solo il sito � inglese)</a> che ha un interfaccia molto bella e funzionale, inoltre ti permette nel caso di un torrent senza fonti (morti) di ricercare le fonti su altri network come Gnutella 2 e Edonkey Emule a patto che il torrent sia stato creato con la tecnologia <a href='http://www.torrentaid.com' target='_blank'>TorrentAid</a>. Veramente utile e consigliato al 99% degli utenti! Anche se usi fastweb ti consigliamo viviamente Shareaza!
<li>Se il tuo obbiettivo � condividere molti file con Bit Torrent oppure il tuo sistema operativo non risulta supportato da nessun client oppure usi fastweb ti consigliamo <a href='http://azureus.sourceforge.net' target='_blank'>Azureus</a> (in italiano, solo il sito � in inglese), � scritto in java(che deve essere installato prima di Azureus) e permette di essere eseguito su qualsiasi tipo di sistema operativo. Abbiamo anche scritto una apposita <a href='modules.php?name=Bittorrent&file=help'>guida</a> che andrebbe letta indipendetemente dalla scelta del programma.
<li>Se ti interessa condividere pochi file che verranno scaricati da tantissimi utenti ed usi windows ti consigliamo <a href='http://bt.degreez.net/' target='_blank'>Shadow</a> e di utilizzare la modalita Super SEEDER che � in grado di determinare le fonti che condividono con maggiore velocit� le parti inviate e favorirle per far crescere pi� velocemente la velocit� di download di tutti gli utenti. Da usare solo nel caso si faccia da unico seeder per un file richiesto da molti utenti.
</ul>
</p>

<p>
<a name='function'><b>Come funziona?</b></a><br>
Accertarsi inizialmente di aver installato e riavviato una qualsiasi versione di bit torrent, a questo punto si naviga su un sito come questo e si fa click sulla voce torrent per far partire il download. Inizialmente crea un file pari alla stessa dimensione del file finale (che da l'impressione di un super download) poi parte il download vero e proprio. E' possibile interrompere il download in qualsiasi momento e poi riprenderlo specificando come destinazione il file creato la prima volta, cos� facendo le parti di file gi� scaricate verranno recuperate. Alcuni software permettono di mettere in pausa e/o di riavviare automaticamente il download quando si ricaricano. Normalemente un download parte dopo circa 5-10 minuti di tempo necessari per trovare le fonti, ci potrebbe volere anche pi� tempo indipendentemente dalla tua velocit�.
Leggenda delle icone in tabella:
<table>
<tr><td><img src='modules/<?=$name?>/pic/global.gif'></td><td>Indica che il tracker utilizzato � esterno a questo sito. Non � richiesta nessuna autorizzazione per scaricare il torrent.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/global_your.gif'></td><td>Indica che il tracker utilizzato � esterno a questo sito. Non � richiesta nessuna autorizzazione per scaricare il torrent. Il file � stato inserito da te.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/lock.gif'></td><td>Indica che il tracker utilizzato � interno e richiede autorizzazione per il download.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/look_sticky.gif'></td><td>Indica che il tracker utilizzato � interno e richiede autorizzazione per il download. Il file � stato evidenziato come importante e di interesse genrale garantendo un seeder fisso per almeno una settimana. La garanzia non � data da noi ma dal proprietario del file.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/open_your.gif'></td><td>Indica che il tracker utilizzato � interno e richiede autorizzazione per il download. Questo file � stato inserito da te.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/open.gif'></td><td>Indica che il tracker utilizzato � interno e sei autorizzato per il download.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/lock_request.gif'></td><td>Indica che il tracker utilizzato � interno e che hai fatto richiesta al proprietario per scaricare tutti i suoi file.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/3.5.jpg'></td><td>Viene generata in base ai voti espressi dagli utenti ed � indice di qualit� del file. Ne esistono di diversi tipi in base ai giudizi.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/green.gif'></td><td>Indica un torrent con almeno sufficienti possibilit� di essere completato, avventuratevi con maggiore sicurezza su questo tipo di file.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/yellow.gif'></td><td>Indica un torrent con poche possibilit� di essere completato.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/red.gif'></td><td>Indica un torrent con scarse o nessuna possibilit� di essere completato.</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/minisharazea.gif'></td><td>Indica un torrent evoluto di tipo torrentaid con la possibilit� di ricercare fonti anche sulla net Gnutella 2 (bisogna usare Shareaza per il router da bit torrent, oppure un client indipendende specifico solo per Gnutella 2 perdendo in questo ultimo caso le fonti bit torrent).</td></tr>
<tr><td><img src='modules/<?=$name?>/pic/minidonkey.gif'></td><td>Indica un torrent evoluto di tipo torrentaid con la possibilit� di ricercare fonti anche sulla net Emule Edonkey (bisogna usare Shareaza per il router da bit torrent, oppure un client indipendende specifico solo per Emule Edonkey perdendo in questo ultimo caso le fonti bit torrent).</td></tr>
</table>


</p>

<p>
<a name='search'><b>Come si ricerca?</b></a><br>
Inserire una parola che si vuole ricercare, non utilizzare operatori logici. E' anche possibile non inserire nessun filtro sulla parola ed effettuare una ricerca solo per ottenere una disposizione secondo un criterio di ordine. I torrent si dividono in attivi, che hanno fonti in questo momento, e morti che non hanno fonti. E' possibile che un torrent di tipo torrentaid morto su bit torrent continui ad avere fonti sui network gnutella2 e/o emule edonkey. E' possibile filtrare per categoria.
</p>

<p>
<a name='maxupload'><b>Come mai mi riporta una velocit� di upload e come faccio a settare un massimo?</b></a><br>
Mentre scarichi diventi una fonte per la parte che hai scaricato. Cos� facendo tutti i client si danno una mano senza dover aspettare di avere il file completo, questo velocizzer� tutti i download ed � proprio da questa caratteristica che nasce il nome bit torrent, ovvero torrente di bit.<br>
Tutti i client, tranne quello standard per dielettanti, permettono facilmente di impostare un massimo di upload. Ricordati che minore sara il tuo upload minore sar� il tuo download.
</p>

<p>
<a name='tracker'><b>Cos'� il tracker e cosa sono gli errori del tracker?</b></a><br>
E' un server che si occupa di tenere traccia delle fonti che condividono il file, tecnicamente viene interrogato in http. Si potrebbe definire il cuore di bit torrent, senza il quale solo un sistema shareaza decentralizzato con un opportuno torrent avanzato di tipo torrentaid potrebbe far partire il download. Spesso i tracker finiscono col non riuscire a sopportare le numerose richieste e vanno offline, ovvero impazziscono, cominciano a dare strani messaggi di errore oppure non rispondono per niente. Normalmente basta lasciare aperta la finestra e se ne occupera il software di ricollegarsi al momento opportuno. Gli errori del tracker possono capitare per svariati motivi ed in nessun caso il vostro intervento pu� migliorare una situazione che non dipende da voi, vi basta sapere che gli errori non danneggiano il file. Se siete particolarmente curiosi potete chiedere il motivo dell'errore sul forum (magari prima una ricerca) ma, torno a ripetere, questo non cambier� nulla.
</p>

<p>
<a name='seeder'><b>Come faccio a fare da seeder?</b></a><br>
Seeder significa condividere un file che hai gi� completo sul tuo pc (requisito necessario). Hai 2 strade:
<ul>
<li>Lascia scaricare un file e quando ha finito non chiudi la finestra, automaticamente visto che hai il file completo diventerai seeder senza fare nulla. Questo � consigliato a tutti ed � una delle regole basi! Quando un giorno qualcuno vi toglier� l'unico seeder di un file che vi serviva forse imparerete che il download all'italiana non porta da nessuna parte, devi sempre fare da seeder per almeno 2 file che hanno pochi seeder.
<li>Il secondo metodo, solo per veri utenti esperti, consiste nel fare l'upload di un torrent. Trovi spiegazioni dettagliate nell'<a href='modules.php?name=<?=$name?>&file=upload_help'>help upload</a>
</ul>
</p>

<p>
<a name='upload'><b>Come faccio a condividere o fare l'upload del file torrent?</b></a><br>
Trovi spiegazioni dettagliate nell'<a href='modules.php?name=<?=$name?>&file=upload_help'>help upload</a>
</p>

<p>
<a name='speed'><b>Perch� vado lento o non parte proprio?</b></a><br>
La prima cosa da verificare e di essere in modalit� attiva, se non sai come fare disabilita tutti i firewall compreso quello nativo di windows xp (attivato di default). Se sei dietro lan non puoi fare nulla, se utilizzi fastweb ti consigliamo di installare Shareaza e di configurarlo come si deve, altrimenti <a href='#install'>scaricare azureus</a> nella guida troverai scritto come fare per scaricare tra <a href='modules.php?name=Bittorrent&file=help'>fastweb con Azureus</a>. Se amministri il router ti consigliamo di utilizzare azureus e di aprire determinate porte. Se sei in lan e non puoi accedere in tcp/ip ad internet non puoi scaricare. Se il torrent indica un semaforo rosso(vuol dire che non ci sono fonti) non puoi scaricare quel file a meno che tu non usi shareaza ed sia un torrent creato con torrentaid (lo riconosci dal fatto che nei dettagli sul sito visualizza i network alternativi). In ogni caso devi sapere che maggiore sar� la tua banda in upload pi� velocemente andrai, e maggiore sar� il numero di fonti pi� velocemente andrai...  in linea di massima! I file non vengono condivisi da noi ma da utenti come te, quindi non lamentarti se qualche volta, o caso sfigato pi� di una volta, il download si rallenta o va lento. Non dipende da noi! Possiamo confermarti che se tanti utenti usano felicemente bit torrent allora vuol dire che funziona, col tempo imparerai a saperlo usare al meglio e capire cosa conviene scaricare. Il semaforo potrebbe anche essere verde ma andare lento o non partire proprio anche a causa di problemi con il tracker, non c'� nulla che tu possa fare tranne che aspettare e magari mettere a scaricare qualche cosa con molte fonti per consolazione. Ricordati che bit torrent mostra il suo meglio su file che tutti vogliono e non sulle rarit�.<br>
<a href='modules.php?name=<?=$name?>&file=connection_help'>Per eseguire un test sulla tua attuale connessione fai click qui e segui i consigli</a>, da leggere con attenzione!
</p>

<p>
<a name='privacy'><b>Perch� tutti i file sono privati?</b></a><br>
Abbiamo preferito questa modalit� di accesso ai file per evitare questioni legali come accaduto anni fa con napster. Noi semplicemente offriamo connettivit� come quella che offre il tuo provider, � compito tuo scaricare e condividere solo file in norma di legge.
</p>

<p>
<a name='bestshareaza'><b>Come posso configurare al meglio Shareaza?</b></a><br>
Shareaza � un ottimo tool, che se utilizzato assieme a <a href='http://www.raulken.it/home/modules.php?name=News&file=article&sid=880' target='_blank'>Miranda</a> (noto programma multi chat ICQ/MSN/IRC ecc a PlugIn altamente personalizzabile), vi risolver� definitivamente i problemi di RAM e di caricare 1000 programmi nel vostro PC. Shareaza infatti si collega a pi� network dandovi la possibilit� di scaricare da pi� fonti contemporaneamente, scaricando vi anche torrent che a livello bit torrent possono sembrare morti!. Shareaza utilizza Gnutella 1, Gnutella 2 e Edonkey/Emule come network, analiziamoli uno alla volta
<ol>
<li>Il primo passo � <a href='#install'>installare Shareaza</a>, caricarlo ed impostare come lingua Italiano e andare ad attivare nel menu visualizza -> modalit� avanzata, se vi dimenticate di fare questo molte opzioni di ottimizzazione non saranno disponibili! Poi andate in "Strumenti -> Opzioni di Shareaza -> Generale -> Generale" e selezionate "Auto Connetti All'avvio" e "Esegui Shareaza all'avvio" � importante, cos� anche quando non scaricate condividete e quando toccher� a voi scaricare ci sar� molta pi� banda a disposizione per tutti.
<li>Cominciamo col dire che Gnutella 1 e Gnutella 2 non richiedono nessun tipo di configurazione, sono assolutamente decentralizzati e non daranno nessun tipo di problema.
<li>Edonkey (impropiamente chiamato anche emule, ma che in realt� sono solo estensioni di protocollo) invece � molto pi� complesso da configurare! Internet, come anche numerosi modelli al mondo, sono caratterizzati da client e server (un client pu� anche fare da server): il client sfrutta risorse altrui e richiede servizi ad altri, un server riceve le richieste(dei client) e le esegue. Nel caso di Edonkey ci serve <b>un solo server</b> a cui dobbiamo collegarci per eseguire ricerche e ricevere le liste degli indirizzi degli utenti che ci interessano, anche se ci colleghiamo ad un solo server � ottima norma avere liste di numerosi server poich� mano a mano che ricerchiamo fonti chiediamo al server a cui siamo collegati di prelevare fonti da altri server, da un lato diciamo al server dove reperire altre informazioni in maniera tale che possa collegarsi ad un numero sempre maggiore di server, dall'altro con una sola connessione avremo a disposizione numerose fonti anche non collegate al nostro server diretto. Gli indirizzi dei server vengonomemorizzati in dei file con estenzione .met, e bene quindi avere numerosi file .met da cui prelevare fonti! Ecco una lista di file .met che copre tutti i migliori server e che sono costantemente e frequentemente aggiornate, puoi fare click per lanciarli subito dopo aver installato shareaza e riavviato (altrimenti riceverai un errore) oppure installarle a perfezione come segue:
        <ul>
                <li><a href='ed2k://|serverlist|http://www.p2pitalia.com/elist/server_it.met|' target='_blank'>http://www.p2pitalia.com/elist/server_it.met</a> Lista server del sito <a href='http://www.p2pitalia.com' target='_blank'>p2pitalia.com</a>
                <li><a href='ed2k://|serverlist|http://www.p2pitalia.com/elist/server.met|' target='_blank'>http://www.p2pitalia.com/elist/server.met</a>
                <li><a href='ed2k://|serverlist|http://spazioinwind.libero.it/clonyitaly/eMule/MiniServers.met|' target='_blank'>http://spazioinwind.libero.it/clonyitaly/eMule/MiniServers.met</a>
                <li><a href='ed2k://|serverlist|http://ilgatto.dyndns.org/server.met|' target='_blank'>http://ilgatto.dyndns.org/server.met</a>
                <li><a href='ed2k://|serverlist|http://www.esel-paradies.de/server/server.met|' target='_blank'>http://www.esel-paradies.de/server/server.met</a>
                <li><a href='ed2k://|serverlist|http://ocbmaurice.dyndns.org/pl/slist.pl/server.met?download/server-max.met|' target='_blank'>http://ocbmaurice.dyndns.org/pl/slist.pl/server.met?download/server-max.met</a>
        </ul>
        Ora speghiamo come usare queste liste a prefezione. Caricate Shareaza e premete F9 (equivalente dal menu Visualizza->Avanzate->Servizi di Connessione) Click sul destro nella schermata bianca e selezionare Aggiungi servizio, poi aggiungere uno tra gli indirizzi proposti e attenzione a specificare come tipo <b>"Server .met URL"</b>. Dopo aver salvato (facendo click su Ok) il nostro nuovo servizio comparir� in lista, a questo punto selezionarlo con un click sul destro e scegliere la voce "Richiedi Ora". Tralasciando che Shareaza � in grado di aggiornarsi dalla lista automaticamente ogni tanto � consigliato aggiornare a mano. Ripetere le operazioni per tutti i server! A questo punto le liste sono state aggiornate e Shareaza sapr� come utilizzarle senza nessun ulteriore intervento, puoi tuttavia avviarle a mano ogni volta che vuoi per migliorare il numero di ricerche di fonti!<br>
        Se avete una linea potente tipo fastweb, alice da diversi mega, siete dietro una lan veloce andate nel munu strumenti->opzioni shareaza -> reti -> edonkey 2000 e selezionare: Autoconnetti ad ogni sessione, Cerca nei server remoti e nel campo "Ferma ricerca dopo" inserire un valore alto (10000 ad esempio) e nel campo "Connetti a non pi� di" un valore alto (2000 ad esempio); queste modifiche ci faranno avere molte pi� fonti consumando banda per�, per questo � consigliato solo per linee veloci, negli altri casi avreste un decadimento di prestazioni.<br>
        Dopo aver effettuato tutte le connessioni andare in rete es accertarsi che alla voce edonkey (l'asino) ci sia indicato HIGHID, in caso contrario disabilitare tutti i firewall compreso quello nativo di windows xp. Se sei dietro LAN al 99% non puoi fare nulla. Se sei un utente fastweb devi assolutamente connetterti ad un server interno fastweb, premi F8 (equivalente di Visualizza->Cache host) e ordina per nome (dopo aver aggiornato tutte le liste come scritto sopra) e ricerca il nome ADUNANZA, i server adnanza per edonkey fastweb sono i migliori, basta essere connesso ad un solo server per essere connessi con tutto il mondo, in alternativa ricerca un indirizzo ip nella forma aaa.222.333.444 dove aaa sia un valore piccolo pi� piccolo di 50 e gli altri numeri con valori qualsiasi, potresti trovare altri server fastweb meno popolari ma sempre super efficaci! Dopo la prima volta shareaza ricorder� il tuo server fastweb e prover� a connettersi sempre a quello, verifica periodicamente di essere connesso ad un server fastweb, i server fastweb sono accessibili solo da chi ha fastweb.
<li>Se <b>utilizzi fastweb</b> oltre alle modifiche citate nella connessione edonkey/emule devi anche fare una cosa importante, ovvero dire a tutti qual � il tuo ip interno, senza il quale non potresti scaricare tra fastweb! Nel munu strumenti->opzioni shareaza -> In Internet -> Connessione nel campo Indirizzo in Entrata -> Indirizzo metti il tuo ip interno (che trovi digitando <b>ipconfig</b> nel prompt di ms-dos in windows) poi DESELEZIONA entrambi i campi Posso accettare Connessioni in entrata e Ignora indirizzi ip privati e locali, ho detto di DESELEZIONARE occhio! Per il resto settate la vostra velocit� che � espressa in bit e non byte ( 8 bit fanno un byte ), ad esempio fastweb ha 2 MB come adsl, mentre alice e 256 <b>K</b>b occhio alla K ed M! Non smanettate con quello che non ho detto o finirete per fare casini, potete nel 99% dei casi solo peggiorare le cose siete stati avvisati.
</ol>
Finito di fare tutto ricordatevi che adesso potete scaricare dal nostro sito con tutti i protocolli, anche file che sembrano morti potrebbero risvegliarsi su altri network, non fidatevi dei file che trovate con il comando cerca su shareaza, ci sono ottime possibilit� che siano dei falsi (fake)
</p>

<p>
<a name='partner'><b>Cosa posso fare per rendere questo servizio pi� veloce e migliore?</b></a><br>
La prima regola e non chiudere mai il torrent quando hai finito di scaricare. Se vuoi avere l'aureola basta fare da seeder per 2 file per ogni file che scarichi, in generale fare da seeder per minimo 2 file! Fare da seeder per 4 file e scaricarne massimo 2 � un ottima cosa! Puoi anche aiutarci a migliorare il servizio prelevando torrent da altri siti e uppandoli qua, ti risparmierai la fatica di doverli creare, condividerai le fonti dell'altro sito e tutti i visitatori potranno godere del tuo aiuto! Se upperai un file al giorno prelevandolo da qualche altro sito migliorerai notevolmente il materiale presente. Disponiamo della migliore tecnologia multitracker & multinetwork mondiale (neanche gli americani ce l'hanno) usiamola! Quando dovete richiedere qualche informazione sui file postate un commento e NON andate mai ad effettuare richieste sul forum.
</p>

<p>
<a name='legacy'><b>E' legale?</b></a><br>
Certo che � legale, noi offriamo solo una tecnologia di connettivit� p2p e siamo assolutamente contrari ad ogni forma di pirateria. Noi non condividiamo file ed ogni condivisione presente su questo server � privata. Su questo server non ci sono file. L'utente che inserisce un torrent a tracker esterno dichiara di gestire privatamente tramite tracker e/o client le autorizzazioni agli ip desiderati lasciando libera la sola verifica quantitativa delle fonti al nostro server, il nostro tracker invece utilizza un sistema di autorizzazioni per essere utilizzato. Noi rispettiamo la vostra privacy. Se ci dovesso essere segnalazioni di materiale pedopornografico/violento/razzista ci occuperemo personalmente di denunciare l'accaduto presso le autorit� competenti. Se volete provare un software prima di comprarlo scaricate una versione valutativa dal sito ufficiale, se volete ascoltare/vedere una canzone o intro film andate sugli appositi siti, guardate la TV o accendete la radio invece di scariare un file illegale dalla rete! Il p2p serve per scambiare file free tra molte persone, anche quando le risorse economiche sono minime. Scambiandovi file illegali ucciderete il progresso. Noi siamo assolutamente contrari allo scambio illegale! Raulken.it svolge la sola funzione di motore di ricerca evoluto di bit torrent, con la possibilit� di scaricare torrent, visualizzarne le statistiche e possibilit� di inserimento commento.
</p>

<p>
<a name='antipiracy'><b>Che sistema antipirateria e anti pedofilia sono utilizzati?</b></a><br>
Raulken.it utilizza un filtro per evitare l'inserimento di file e commenti pedopornografici basato su specifiche keyword lo stesso filtro viene utilizzato per bandire keyword particolari utilizzate durante la diffusione di file illegali. Se sei il proprietario di un marchio registrato o comunque ne detieni i diritti puoi contattarci e richiedere il blocco del tuo marchio nel filtro come strumento di prevenzione di diffusione di materiale illegale o nei commenti.<br>Inoltre su segnalazione possiamo contattare e collaborare con la polizia postale delle telecomunicazioni nel caso dovessero essere condivisi file pedopornografici o materiale ritenuto illegale, grazie ad una grande collaborazione da parte dei nostri utenti.
</p>

<p>
<a name='shareaza'><b>Che novit� introduce Shareaza?</b></a><br>
Introduce una nuova tecnologia capace di lavorare su network diversi da bit torrent in grado di funzionare anche quando il tracker � gi�, scaricando inoltre utilizzando anche emule/edonkey e gnutella<br>
Inoltre permette di scaricare anche un singolo file torrent fatti con torrentaid da compilation di pi� file senza dover scaricare tutta la compilation. <a href='#install'>Lo scarichi qui</a>
</p>

<p>
<a name='open'><b>Come apro i seguenti file?</b></a><br>
<table><tr><hd>Estensioni</hd><hd>Programma</hd></tr>
<tr><td>zip rar tar gz gz2 e numerosi altri formati compressi</td><td>Sono formati compressi, utilizzare <a href='http://www.rarlab.com' target='_blank'>Winrar</a></td></tr>
<tr><td>nrg iso cue</td><td>Sono formati per il masterizzatore, utilizzare <a href='http://www.nero.com' target='_blank'>Nero</a>, se si desidera solo visualizzare e scompattare il contenuto <a href='http://www.winiso.com/' target='_blank'>Winiso</a></td></tr>
<tr><td>img mds e altri formati non nero</td><td>Sono formati per il masterizzatore, utilizzare <a href='http://www.alcohol-software.com/' target='_blank'>Alcohol 120%</a></td></tr>
<tr><td>ra ram</td><td>Installa <a href='http://www.realnetworks.com/info/freeplayer/' target='_blank'>Real Audio Free</a></td></tr>
</table>
</p>

<p>
<a name='codec'><b>Come mai l'audio e disalineato o non vedo/sento?</b></a><br>
Il disallineamento dipende quasi sicuramente dal fatto che hai un pc lento! Anche un p4 in certe situazioni � messo alle strette... riavvia il pc, chiudi tutti i programmi e lancia il filmato utilizzando BS-Player che trovi in <a href='http://www.raulken.it/modules.php?name=Downloads&d_op=viewdownloaddetails&lid=386&ttitle=K-Lite' target='_blank'>K-Lite</a> (andare in codecs), cos� avrai maggiori risorse per l'elaborazione e non finirai in disallinemaento. Prova a saltare il punto in cui si disalinea mettendo avanti a mano.<br>
Non sento/vedo l'audio/video: Disinstalla tutti i tuoi codec e prova con il pacchetto <a href='http://www.raulken.it/modules.php?name=Downloads&d_op=viewdownloaddetails&lid=386&ttitle=K-Lite' target='_blank'>K-Lite</a>, andare in CODEC PACKS.
</p>

<p>Note legali, qualsiasi pagina di questo sito � propriet� della raulken.it e non pu� essere copiata neanche parzialmente. I contenuti sono responsabilit� dei singoli utenti e sono privati.
</p>
<?CloseTable();
?>