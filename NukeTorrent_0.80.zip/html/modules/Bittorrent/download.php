<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
global $name, $user, $db, $id, $nologin, $nocheck, $user_prefix;
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");


$nologin = true;
require_once("modules/$name/include/bittorrent.php");

//SETUP VARIABILI LINGUA DINAMICHE
global $ip,$nukeurl,$sitename,$max_num_file_day_e,$max_num_file_week_e,$min_share_seed,$min_size_seed,$max_num_file,$max_share_size,$min_size_seed_e;

$antiscrocco = str_replace("**min_size**",mksize($min_size_seed_e),_btantiscrocco);
$antiscrocco = str_replace("**min_num",$min_num_seed_e,$antiscrocco);

$bttomorrow = str_replace("**max_num**",$max_num_file_day_e,_bttomorrow);

$btlantoday = str_replace("**ip**",$ip,_btlantoday);

$btlantomorrow = str_replace("**max_num**",$max_num_file_day_e,_btlantomorrow);

$btnextweek = str_replace("**max_num",$max_num_file_week_e,_btnextweek);

$btthisweeklan = str_replace("**ip**",$ip,_btthisweeklan);

$btnextweeklan = str_replace("**max_num",$max_num_file_week_e,_btnextweeklan);

$btmsgbody1 = str_replace("**nuke**",$nukeurl,_btmsgbody1);

$btmsgbody2 = str_replace("**nuke**",$nukeurl,_btmsgbody2);

$btmsgsubject = str_replace("**nuke**",$nukeurl,_btmsgsubject);

$bterrminseed = str_replace("**min_share**",mksize($min_share_seed),_bterrminseed);

$bterrtoosmall = str_replace("**min_share**",mksize($min_size_seed),_bterrtoosmall);

$bterrmaxnumnoseed = str_replace("**maxfile**",$max_num_file,_bterrmaxnumnoseed);

$bterrmaxdownloadsizemksize = str_replace("**maxsize**",$max_share_size,_bterrmaxdownloadsize);

$btfinalerrmsg1 = str_replace("**ip**",$ip,_btfinalerrmsg1);

$btfinalerrmsg3 = str_replace("**name**",$name,_btfinalerrmsg1);
//FINE SETUP LINGUA
if (!is_user($user) && ($down_reg || $torrent_global_privacy)){
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}

if($down_pied)
if(! paid() ){
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULESSUBSCRIBER."";
        if ($subscription_url != "") {
                echo "<br>"._SUBHERE."";
        }
        echo "<br><br>"._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}

$sql = "SELECT A.`id`, A.filename, A.owner, B.user_email as email, A.tracker FROM torrent_torrents A LEFT JOIN ".$user_prefix."_users B ON A.owner = B.user_id WHERE A.id = '$id'";
$res = $db-sql_query($sql) or bterror($sql);
$row = $db->sql_fetchrow($res);
if (!$row)        httperr();

$row_id_torrent = $row["id"];


$row_filename = $row["filename"];
$row_owner = $row["owner"];
$row_email = $row["email"];
$row_tracker = $row["tracker"];

unset($GLOBALS["CURUSER"]);
global $CURUSER;
$id_user = 0;
$name_user = 0;
if (is_user($user)){
        //Dati user
        $userdata = base64_decode($user);
        $userdata = explode(":", $userdata);
        $id_user = $userdata[0];
        $name_user = $userdata[1];
        $CURUSER["id"]=$id_user;
}


//Verifica i limiti sui tracker esterni
if (($extern_check) && ($down_reg) && is_user($user) && strlen($row_tracker)>0 && $row_owner!=$id_user) {

        //Se non � un utente legalizzato allora deve fare delle verifiche altrimenti � OK
        $sql = "SELECT id_user FROM `torrent_legalizeit` WHERE id_user = '$id_user'";
        $res=$db->sql_query($sql) or bterror($sql);
        if(!$row=$db->sql_fetchrow($res)){

                //Verifica se ha tutti i seeder necessari
                $sql = "SELECT count(*) as TOT FROM `torrent_torrents` WHERE owner = '$id_user' AND seeders > 0 AND size > '$min_size_seed_e'";
                $res = $db->sql_query($sql) or bterror($sql);
                $row = $db->sql_fetchrow($res);
                if($row[TOT]<$min_num_seed_e){

                        //Verifica se hai gi� scaricato quel torrent, per eventuali interruzioni
                        $sql = "SELECT count(*) as TOT FROM `torrent_download` WHERE chi = '$id_user' AND cosa = '$row_id_torrent'";
                        $res = $db->sql_query($sql) or bterror($sql);
                        $row = $db->sql_fetchrow($res);
                        if($row[TOT]==0){

                                $ip = getenv("REMOTE_ADDR"); //IP

                                //Verifica se oggi ha gi� scaricato quell'utente
                                $sql = "SELECT count(*) as TOT FROM `torrent_download` WHERE chi = '$id_user' AND quando = CURDATE()";
                                $res = $db->sql_query($sql) or bterror($sql);
                                $row = $db->sql_fetchrow($res);
                                if($row[TOT]>=$max_num_file_day_e){
                                        include("header.php");
                                        OpenTable();
                                        echo "<p><b>"._btnogratis."</b><br>"._bttodayused." ".$row[TOT]." ".$bttomorrow.$antiscrocco;
                                        CloseTable();
                                        include("footer.php");
                                        die();
                                }

                                //Verifica se oggi ha gi� scaricato quell'ip
                                $sql = "SELECT count(*) as TOT FROM `torrent_download` WHERE ip = '$ip' AND quando = CURDATE()";
                                $res = $db->sql_query($sql) or bterror($sql);
                                $row = $db->sql_fetchrow($res);
                                if($row[TOT]>=$max_num_file_day_e){
                                        include("header.php");
                                        OpenTable();
                                        echo "<p><b>"._btnogratis."</b><br>".$btlantoday.$row[TOT]._btlantomorrow.$antiscrocco;
                                        CloseTable();
                                        include("footer.php");
                                        die();
                                }

                                //Verifica se nel periodo ha gi� scaricato
                                $sql = "SELECT count(*) as TOT FROM `torrent_download` WHERE chi = '$id_user'";
                                $res = $db->sql_query($sql) or bterror($sql);
                                $row = $db->sql_fetch_array($res);
                                if($row[TOT]>=$max_num_file_week_e){
                                        include("header.php");
                                        OpenTable();
                                        echo "<p><b>"._btnogratis."</b><br>"._btthisweek.$row[TOT].$btnextweek.$antiscrocco;
                                        CloseTable();
                                        include("footer.php");
                                        die();
                                }

                                //Verifica se nel periodo ha gi� scaricato
                                $sql = "SELECT count(*) as TOT FROM `torrent_download` WHERE ip = '$ip'";
                                $res = $db->sql_query($sql) or bterror($sql);
                                $row = $db->sql_fetch_array($res);
                                if($row[TOT]>=$max_num_file_week_e){
                                        include("header.php");
                                        OpenTable();
                                        echo "<p><b>"._btnogratis."</b><br>"._btthisweeklan.$row[TOT].btnextweeklan.$antiscrocco;
                                        CloseTable();
                                        include("footer.php");
                                        die();
                                }

                                $sql = "INSERT INTO `torrent_download`(chi, quando, cosa, ip) VALUES('$id_user', CURDATE(), '$row_id_torrent', '$ip')";
                                $res = $db->sql_query($sql) or bterror($sql);

                                $sql = "DELETE FROM `torrent_download` WHERE quando <SUBDATE(SYSDATE(), INTERVAL 7 DAY)";
                                $res = $db->sql_query($sql) or bterror($sql);

                        }

                }


        }



}


//Auto autorize on download
if ($torrent_global_privacy){

                /*
                //Clear duplicate
                $sql_clear = "SELECT B.`from`, B.`to`, count(  *  )  AS TOT, MIN( B.`status`  ) as min FROM  `torrent_global_privacy` B WHERE B.from > 0 AND B.`to`  >0 AND B.`status`  >= 0 GROUP  BY B.`from`,  B.`to` ORDER  BY TOT DESC";
                $res_clear=mysql_query($sql_clear, $dbi);
                $row_clear = mysql_fetch_array($res_clear);
                while ($row_clear && $row_clear["TOT"]>1) {
                        $sql_delete = "DELETE FROM `torrent_global_privacy` WHERE `from` = '".$row_clear["from"]."' AND `to`= '".$row_clear["to"]."' AND `status`>'".$row_clear["min"]."'";
                        mysql_query($sql_delete, $dbi) or die(mysql_error(). " SQL = $sql_delete");
                        $row_clear = mysql_fetch_array($res_clear);
                }
                */


        $sql_email = "SELECT A.user_email as email, B.`from` FROM ".$user_prefix."_users A, `torrent_global_privacy` B WHERE B.`from` > 0 AND B.`to`= '$id_user' AND B.`status`=1 AND B.`from` = A.user_id";
        $sql_privacy = "UPDATE `torrent_global_privacy` SET `status` = 0 WHERE `from` > 0 AND `to`= '".$id_user."' AND `status`=1";

        $res= $db->sql_query($sql_email) or bterror($sql_email);
        while ($row = $db->sql_fetchrow($res)) {
                $body = $btmsgbody1;

                $sql_file = "SELECT A.`file`,  B.`name` FROM `torrent_file_privacy` A, `torrent_torrents` B WHERE A.`from`='".$row["from"]."' AND A.`to`='".$id_user."' AND A.`file`=B.`id`";
                $res_file = $db->sql_query($sql_file) or bterror($sql_file);
                while ($row_file = $db->sql_fetchrow($res_file)) {
                        $body.= $row_file["name"]. ":\n$url_site/modules.php?name=$name&file=details&id=".$row_file["file"]."\n";
                }

                $body.=$btmsgbody2;
                global $adminmail;
                mail($row["email"], $btmsgsubject, $body, "From: $adminmail");

                $sql_delete = "DELETE FROM `torrent_file_privacy` WHERE `to`='".$id_user."' AND  `from`='".$row["from"]."'";
                $db->sql_query($sql_delete, $dbi) or bterror($sql_delete);
        }
        $db->sql_query($sql_privacy) or bterror($sql_privacy);
}

/*
//Auto autorize
$sql_email = "SELECT A.user_email as email FROM ".$user_prefix."_users A, `torrent_global_privacy` B WHERE B.`from` > 0 AND B.`to`= '".$user_id."' AND B.`status`=1 AND B.`from` = A.user_id";
$sql_privacy = "UPDATE `torrent_global_privacy` SET `status` = 0 WHERE `from` > 0 AND `to`= '".$user_id."' AND `status`=1";
$res=mysql_query($sql_email, $dbi);
while ($row = mysql_fetch_array($res)) {
        $body = "L'utente ti ha autorizzato a scaricare i file che condivide su BIT TORRENT by $url_site
hai fatto richiesta di scaricare:
";

        $sql_file = "SELECT A.`file`,  B.`name` FROM `torrent_file_privacy` A, `torrent_torrents` B WHERE A.`from`='".$row["from"]."' AND A.`to`='".$id_user."' AND A.`file`=B.`id`";
        $res_file=mysql_query($sql_file, $dbi);
        while ($row_file = mysql_fetch_array($res_file)) {
                $body .= $row_file["name"]. ":\n$url_site/modules.php?name=$name&file=details&id=".$row_file["file"]."\n";
        }

        $body.="Da adesso puoi scaricare tranquillamente TUTTI i file di QUESTO utente.
        $url_site protegge la tua privacy.
        ";
        mail($row["email"], "Autorizzazione accesso file BIT TORRENT  by $url_site", $body, "From: webmaster@raulken.it");
        $sql_delete = "DELETE FROM `torrent_file_privacy` WHERE `to`='".$id_user."' AND  `from`='".$row["from"]."'";
        mysql_query($sql_delete, $dbi) or die(mysql_error(). " SQL = $sql_delete");
}
mysql_query($sql_privacy, $dbi) or die(mysql_error(). " SQL = $sql_privacy");
*/


//Check global privacy
if ($torrent_global_privacy && $row_owner!=$id_user && strlen($row_tracker)==0){
        $sql_trigger = "SELECT A.`status` FROM `torrent_global_privacy` A, `torrent_torrents` B WHERE B.`id` = '$id' AND A.`from` =  '".$id_user."' AND  B.owner=A.to AND A.`status`>=0";
        $res_trigger = $db->sql_query($sql_trigger, $dbi) or bterror($sql_trigger);
        if ($row_trigger = $db->sql_fetchrow($res_trigger)){
                switch ($row_trigger["status"]){
                case 0:
                        //Ok permission
                        break;
                case 1:
                        $err =  _bterrorprivate;
                        break;
                case 2:
                        $err =  _btrefused;
                        break;
                }
        }else{

                $sql = "SELECT count(*) as tot FROM `torrent_global_privacy` WHERE `from`>0 AND `to`='$row_owner' AND `status`= 1";
                $res = $db->sql_query($sql) or bterror($sql);
                $row = $db->sql_fetch_array($res);
                if ($row["tot"]=="0"){
                        $err =  _btreqsent;

                        global $sitename, $nukeurl;
                        $body = _btauthreqbody;
                        $body = str_replace("**userid**",$id_user,$body);
                        $body = str_replace("**username**",$name_user,$body);
                        $body = str_replace("**sname**",$sitename,$body);
                        $body = str_replace("**nukeurl**",$nukeurl,$body);

                        mail($row_email, _btmsgsubject, $body, "From: $adminmail");
                }else{
                        $err =  str_replace("**tot**",$row[TOT],_btautherrpending);
                }

                $sql = "INSERT INTO `torrent_global_privacy`(`from`, `to`, `status`) VALUES('".$id_user."','$row_owner','1')";
                $db->sql_query($sql) or bterror($sql);
                $sql = "INSERT INTO `torrent_file_privacy`(`from`, `to`, `file`) VALUES('".$id_user."','$row_owner','$id')";
                $db->sql_query($sql) or bterror($sql);
        }
        if ($err)        {
                        include("header.php");
                        OpenTable();
                        stdhead();
                        echo $err;
                        CloseTable();
                        include("footer.php");
                        die();
        }
}

if ($nocheck!="true"){

        $ip = $_SERVER["REMOTE_ADDR"];
        $sql_trigger = "SELECT count( A.seeder ) AS tot, A.seeder AS seed, A.ip, sum( B.size )  AS tot_size, max(B.size) as max_size FROM  `torrent_peers` A, `torrent_torrents` B WHERE A.ip =  '$ip' AND A.`torrent`  = B.`id` GROUP  BY ip, seed order by seed";
        $res_trigger = $db->sql_query($sql_trigger) or bterror($sql_trigger);
        if ($row_trigger = $db->sql_fetch_array($res_trigger)){

                $check_seed=true;                        //If false trigger found
                $check_leech=true;                        //If false trigger found
                $print_error_seed="";
                $print_error_leech="";

                if ($min_share_seed>0){
                        $print_error_seed .=  $bterrminseed;
                        if($row_trigger["seed"]=="yes" && $row_trigger["tot_size"]>=$min_share_seed) {
                                //if row_trigger["seed"]=="no" check only leech
                                $print_error_seed.= _btruleok;
                        }else{
                                $check_seed = false;
                                $print_error_seed .= _btruleko;
                                if ($row_trigger["seed"]=="yes")
                                        $print_error_seed.= _bterrnotenoughshare1.mksize($row_trigger["tot_size"])._bterrnotenoughshare2..mksize($min_share_seed - $row_trigger["tot_size"]).".</b>";
                                else
                                        $print_error_seed.= _bterrnoseeder;
                        }
                }

                if ($min_size_seed>0){
                        $print_error_seed .=  $bterrtoosmall;
                        if($row_trigger["seed"]=="yes" && $row_trigger["max_size"]>=$min_size_seed) {
                                //if row_trigger["seed"]=="no" check only leech
                                $print_error_seed.= _btruleok;
                        }else{
                                $check_seed = false;
                                $print_error_seed .= _btruleko;
                                if ($row_trigger["seed"]=="yes")
                                        $print_error_seed.= _bterrtoobig.mksize($row_trigger["max_size"])."</b>";
                                else
                                        $print_error_seed.= _bterrnoseeder;
                        }
                }

                if ($row_trigger["seed"]=="yes") $row_trigger = $db->sql_fetchrow($res_trigger);

                if (!$check_seed && $row_trigger){

                        if ($max_num_file>0){
                                $print_error_leech .=  $bterrmaxnumnoseed;
                                if($max_num_file>$row_trigger["tot"]){ //a questo punto dovrebbe essere row_trigger["seed"]=="no" altrimenti vuol dire che non fa da leech
                                        $print_error_leech.= _btruleok;
                                }else{
                                        $check_leech= false;
                                        $print_error_leech.= _btruleko;
                                }
                        }

                        if ($max_share_size >0){
                                $print_error_leech .=  $bterrmaxdownloadsize;
                                if($max_share_size>$row_trigger["tot_size"] ){ //a questo punto dovrebbe essere row_trigger["seed"]=="no" altrimenti vuol dire che non fa da leech
                                        $print_error_leech .= _btruleok;
                                }else{
                                        $check_leech = false;
                                        $print_error_leech .= _btruleko;
                                }
                        }
                }

                if ($check_seed==false && $check_leech==false){
                        include("header.php");
                        OpenTable();
                        stdhead();
                        echo _btfinalerrmsg1..$print_error_leech._btfinalerrmsg2.$print_error_seed._btfinalerrmsg3;
                        CloseTable();
                        include("footer.php");
                        die();
                }
        }
}


$fn = "$torrent_dir/".$row_id_torrent.".torrent";

if (!is_file($fn) || !is_readable($fn))
        httperr();

$sql = "UPDATE torrent_torrents SET hits = hits + 1 WHERE id = '$row_id_torrent'";
$db->sql_query($sql) or bterror($sql);

header("Content-Type: application/x-bittorrent");
header("Cache-control: private");
//header("Content-Length: ".filesize($fn));
header("Content-Disposition: filename=".$row_filename);
readfile($fn);
?>