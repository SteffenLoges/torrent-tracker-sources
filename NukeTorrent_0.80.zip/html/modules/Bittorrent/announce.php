<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
//Please change it if You change folder
$name = "Bittorrent";



//NOT MODIFY AFTER
$nologin = true;
require_once("config.php");

$new_include_dir = "../../";
set_include_path(get_include_path() . ":" . $new_include_dir);
//Please use PHP 4 >= 4.3.0, PHP 5 or modify to hand

require_once("mainfile.php");
require_once("include/bittorrent.php");
require_once("include/benc.php");

function err($msg) {
        benc_resp(array("failure reason" => array(type => "string", value => $msg)));
        exit();
}

function benc_resp($d) {
        benc_resp_raw(benc(array(type => "dictionary", value => $d)));
}

function benc_resp_raw($x) {
        header("Content-Type: text/plain");
        header("Pragma: no-cache");
        print($x);
}

$req = "info_hash:peer_id:!ip:port:uploaded:downloaded:left:!event";
foreach (explode(":", $req) as $x) {
        if ($x[0] == "!") {
                $x = substr($x, 1);
                $opt = 1;
        }
        else
                $opt = 0;
        if (!isset($_GET[$x])) {
                if (!$opt)
                        err("missing key");
                continue;
        }
        $GLOBALS[$x] = unesc($_GET[$x]);
}

foreach (array("info_hash","peer_id") as $x) {
        if (strlen($GLOBALS[$x]) != 20)
                err("invalid $x (" . strlen($GLOBALS[$x]) . " - " . urlencode($GLOBALS[$x]) . ")");
}

if (empty($ip) || !preg_match('/^(\d{1,3}\.){3}\d{1,3}$/s', $ip))
        $ip = $_SERVER["REMOTE_ADDR"];

$port = 0 + $port;
$downloaded = 0 + $downloaded;
$uploaded = 0 + $uploaded;
$left = 0 + $left;

$rsize = 50;
foreach(array("num want", "numwant", "num_want") as $k) {
        if (isset($_GET[$k])) {
                $rsize = 0 + $_GET[$k];
                break;
        }
}

if (!$port || $port > 0xffff)
        err("invalid port");

if (!isset($event))
        $event = "";

$seeder = ($left == 0) ? "yes" : "no";

$sql_select = "SELECT id, banned, name FROM torrent_torrents WHERE " . hash_where("info_hash", $info_hash);
if(! $res = $db->sql_query($sql_select) ) die("Error ".$sql_select);

if (! $torrent = $db->sql_fetchrow($res) ) err("torrent not registered with this tracker");

$torrentid = $torrent["id"];
$torrentname = $torrent["name"];

$fields = "seeder, peer_id, ip, port, uploaded, downloaded, upload_speed, UNIX_TIMESTAMP(SYSDATE())  - UNIX_TIMESTAMP(last_action) as seconds";

//Raulken
$sql_select = "SELECT $fields FROM torrent_peers WHERE torrent = '$torrentid' ORDER BY RAND() LIMIT $rsize";
if(! $res = $db->sql_query($sql_select) ) die("Error $sql_select");

$resp = "d" . benc_str("interval") . "i" . $announce_interval . "e" . benc_str("peers") . "l";
unset($self);
while ($row = $db->sql_fetchrow($res)) {
        $row["peer_id"] = hash_pad($row["peer_id"]);

        if ($row["peer_id"] === $peer_id) {
                $self = $row;
                continue;
        }

        $resp .= "d" .
                benc_str("ip") . benc_str($row["ip"]) .
                benc_str("peer id") . benc_str($row["peer_id"]) .
                benc_str("port") . "i" . $row["port"] . "e" .
                "e";
}

$resp .= "ee";

$selfwhere = "torrent = '$torrentid' AND " . hash_where("peer_id", $peer_id);

if (!isset($self)) {
        $sql_select = "SELECT $fields FROM torrent_peers WHERE $selfwhere";
        if(! $res = $db->sql_query($sql_select) ) die("Error ".$sql_select);
        $row = $db->sql_fetchrow($res);
        if ($row)
                $self = $row;
}

$updateset = array();

if ($event == "stopped") {
        if (isset($self)) {
                $sql_delete = "DELETE FROM torrent_peers WHERE $selfwhere";
                if(! $db->sql_query($sql_delete) )die("Error ".$sql_delete);
                if ($db->sql_affectedrows()) {
                        if ($self["seeder"] == "yes")
                                $updateset[] = "seeders = seeders - 1";
                        else
                                $updateset[] = "leechers = leechers - 1";
                }
                $updateset[] = "tot_peer = tot_peer - 1";
                $updateset[] = "speed = speed - '".$self["upload_speed"]."'";
        }
}
else {
        if ($event == "completed")
                $updateset[] = "times_completed = times_completed + 1";

        if (isset($self)) {

                if ($uploaded>=$self["uploaded"]){
                        $upload_speed = round( ($uploaded - $self["uploaded"]) / $self["seconds"] );
                        $updateset[] = "speed = speed -'".$self["upload_speed"]."' + '$upload_speed'";
                }else{
                        $upload_speed = 0;
                }
                if ($downloaded>=$self["downloaded"]){
                        $download_speed = round( ($downloaded - $self["downloaded"]) / $self["seconds"] );
                }else{
                        $download_speed=0;
                }

                $sql_update = "UPDATE torrent_peers SET ip = " . sqlesc($ip) . ", port = '$port', uploaded = '$uploaded', downloaded = '$downloaded', to_go = '$left', last_action = NOW(), seeder = '$seeder', download_speed='$download_speed', upload_speed='$upload_speed' WHERE $selfwhere";
                if(! $db->sql_query($sql_update) ) die("Error ".$sql_update);

                if ($db->sql_affectedrows() && $self["seeder"] != $seeder) {
                        if ($seeder == "yes") {
                                $updateset[] = "seeders = seeders + 1";
                                $updateset[] = "leechers = leechers - 1";
                        }
                        else {
                                $updateset[] = "seeders = seeders - 1";
                                $updateset[] = "leechers = leechers + 1";
                        }
                }
        }else {
                $sockres = @fsockopen($ip, $port, $errno, $errstr, 5);
                if (!$sockres)
                        $connectable = "no";
                else {
                        $connectable = "yes";
                        @fclose($sockres);
                }



                //Raulken start
                if ($seeder=="no"){

                        $sql_trigger = "SELECT count( A.seeder ) AS tot, A.seeder AS seed, A.ip, sum( B.size )  AS tot_size, max(B.size) as max_size FROM  `torrent_peers` A, `torrent_torrents` B WHERE A.ip =  '$ip' AND A.`torrent`  = B.`id` GROUP  BY ip, seed order by seed";
                        $res_trigger = $db->sql_query($sql_trigger) or die("Error SQL = $sql_trigger");
                        if ($row_trigger = $db->sql_fetchrow($res_trigger)){

                                $check_seed=true;                        // false = trigger found
                                $check_leech=true;                        // false = trigger found

                                if ($min_share_seed>0){
                                        if($row_trigger["seed"]=="yes" && $row_trigger["tot_size"]>=$min_share_seed) {
                                                //if row_trigger["seed"]=="no" check only leech
                                        }else{
                                                $check_seed = false;
                                        }
                                }

                                if ($min_size_seed>0){
                                        if($row_trigger["seed"]=="yes" && $row_trigger["max_size"]>=$min_size_seed) {
                                                //if row_trigger["seed"]=="no" check only leech
                                        }else{
                                                $check_seed = false;
                                        }
                                }

                                if ($row_trigger["seed"]=="yes") $row_trigger = $db->sql_fetchrow($res_trigger);

                                if (!$check_seed && $row_trigger){

                                        if ($max_num_file>0){
                                                if($max_num_file>$row_trigger["tot"]){ //a questo punto dovrebbe essere row_trigger["seed"]=="no" altrimenti vuol dire che non fa da leech
                                                }else{
                                                        $check_leech= false;
                                                }
                                        }

                                        if ($max_share_size >0){
                                                if($max_share_size>$row_trigger["tot_size"] ){ //a questo punto dovrebbe essere row_trigger["seed"]=="no" altrimenti vuol dire che non fa da leech
                                                }else{
                                                        $check_leech = false;
                                                }
                                        }
                                }

                                if ($check_seed==false && $check_leech==false) err("$bt_aoverlimit");
                        }
                }else{
                        $sql_trigger = "SELECT user_email FROM torrent_seeder_notify A, ".$user_prefix."_users B WHERE A.torrent = '$id' AND A.day<CURDATE() AND A.user=B.user_id";
                        $res_trigger = $db->sql_query($sql_trigger) or die("Error SQL = $sql_trigger");
                        while ($row_trigger = $db->sql_fetchrow($res_trigger)){
                                $corpo_email = "
".$bt_aemail1." \"".$torrentname."\"".$bt_aemail2."
".$url_site."/modules.php?name=$name&file=download&id=$id

".$bt_aemail3."

".$bt_aemail4."

".$url_site."/home/modules.php?name=$name&file=details&id=$id&sn=n";
                                mail($row_trigger["user_email"], "Inserimento commento al TORRENT \"$torrentname\" su $url_site", $corpo_email, "From: $email_site");
                        }
                        $sql_update = "UPDATE torrent_seeder_notify SET DAY = CURDATE() WHERE torrent = '$id' AND day<CURDATE()";
                        $db->sql_query($sql_update) or die("Error ".$sql_update);
                }
                //Raulken end

                $sql_insert = "INSERT INTO torrent_peers (connectable, torrent, peer_id, ip, port, uploaded, downloaded, to_go, started, last_action, seeder) VALUES ('$connectable', '$torrentid', " . sqlesc($peer_id) . ", " . sqlesc($ip) . ", '$port', '$uploaded', '$downloaded', '$left', NOW(), NOW(), '$seeder')";

                if( $ret = $db->sql_query($sql_insert) ){
                        if ($seeder == "yes")
                                $updateset[] = "seeders = seeders + 1";
                        else
                                $updateset[] = "leechers = leechers + 1";
                        $updateset[] = "tot_peer = tot_peer + 1";
                }
        }
}

if ($seeder == "yes") {
        if ($torrent["banned"] != "yes")
                $updateset[] = "visible = 'yes'";
        $updateset[] = "last_action = NOW()";
}

if (count($updateset)){
        $sql_update = "UPDATE torrent_torrents SET " . join(",", $updateset) . " WHERE id = '$torrentid'";
        $db->sql_query($sql_update) or die("Error SQL = ".$sql_update);
}

benc_resp_raw($resp);

?>