<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 1;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
global $name, $db, $torrent_global_privacy, $file;

$searchstr = unesc($search);
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
        unset($cleansearchstr);
include("header.php");
OpenTable();

$addparam = "";

$sqlordertype = "";
switch ($ordertype){
case 1:
        $addparam .= "ordertype=1&amp;";
        break;
default:
        $sqlordertype = "DESC";
}

$num_order = $orderby;
$sqlorderby = "";
switch ($orderby){
case 0:
        $sqlorderby = "ORDER BY torrent_torrents.id $sqlordertype";
        break;
case 1:
        $sqlorderby = "ORDER BY torrent_torrents.name $sqlordertype";
        break;
case 2:
        $sqlorderby = "ORDER BY torrent_torrents.size $sqlordertype";
        break;
case 3:
        $sqlorderby = "ORDER BY torrent_torrents.numfiles $sqlordertype";
        break;
case 4:
        $sqlorderby = "ORDER BY torrent_torrents.evidence $sqlordertype";
        break;
case 5:
        $sqlorderby = "ORDER BY torrent_torrents.comments $sqlordertype";
        break;
case 6:
        $sqlorderby = "ORDER BY rating $sqlordertype";
        break;
case 7:
        $sqlorderby = "ORDER BY times_completed $sqlordertype";
        break;
case 8:
        $sqlorderby = "ORDER BY attivato $sqlordertype";
        break;
case 9:
        $sqlorderby = "ORDER BY torrent_torrents.seeders $sqlordertype, torrent_torrents.tot_peer $sqlordertype";
        break;
case 10:
        $sqlorderby = "ORDER BY torrent_torrents.leechers $sqlordertype, torrent_torrents.tot_peer $sqlordertype";
        break;
case 11:
        $sqlorderby = "ORDER BY torrent_torrents.tot_peer $sqlordertype, torrent_torrents.seeders $sqlordertype";
        break;
default:
        $sqlorderby = "ORDER BY torrent_torrents.id $sqlordertype";
        $num_order = 0;
}
if ($num_order>0) $addparam .= "orderby=$num_order&amp;";

$wherea = array();

if ($incldead) {
        $addparam .= "incldead=" . urlencode($incldead) . "&amp;";
        if (!isset($CURUSER) || $CURUSER["admin"] != "yes")
                $wherea[] = "banned != 'yes'";
        if ($incldead == 2)
                $wherea[] = "visible='no'";
}
else
        $wherea[] = "visible='yes'";

if ($cat) {
        $wherea[] = "category = " . sqlesc($cat);
        $addparam .= "cat=" . urlencode($cat) . "&amp;";
}
$wherebase = $wherea;
if (isset($cleansearchstr)) {
        $wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
        //$wherea[] = "0";
        $addparam .= "search=" . urlencode($searchstr) . "&amp;";
//        $orderby = "";
}
$where = implode(" AND ", $wherea);

if ($where != "")
        $where = "WHERE $where";

$res = $db->sql_query("SELECT COUNT(*) FROM torrent_torrents $where")
        or bterror();
$row = $db->sql_fetchrow($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
        $wherea = $wherebase;
//        $orderby = "ORDER BY id DESC";
        $searcha = explode(" ", $cleansearchstr);
        $sc = 0;
        foreach ($searcha as $searchss) {
                if (strlen($searchss) <= 1)
                        continue;
                $sc++;
                if ($sc > 5)
                        break;
                $ssa = array();
                foreach (array("search_text", "ori_descr") as $sss)
                        $ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
                $wherea[] = "(" . implode(" OR ", $ssa) . ")";
        }
        if ($sc) {
                $where = implode(" AND ", $wherea);
                if ($where != "")
                        $where = "WHERE $where";
                $res = $db->sql_query("SELECT COUNT(*) FROM torrent_torrents $where");
                $row = $db->sql_fetchrow($res);
                $count = $row[0];
        }
}

if ($count) {
        list($pagertop, $pagerbottom, $limit) = pager($default_limit, $count, "modules.php?name=$name&". $addparam);

        $sql = "SELECT torrent_torrents.*, IF(torrent_torrents.numratings < '$minvotes', NULL, ROUND(torrent_torrents.ratingsum / torrent_torrents.numratings, 1)) AS rating, torrent_categories.name AS cat_name, torrent_categories.image AS cat_pic, U.username, P.status AS attivato FROM torrent_torrents LEFT JOIN torrent_categories ON category = torrent_categories.id LEFT JOIN ".$prefix."_users U ON torrent_torrents.owner = U.user_id LEFT JOIN torrent_global_privacy P ON ( torrent_torrents.owner = P.to AND P.from = '".$CURUSER["id"]."' AND P.status >=0 AND P.to>=0) $where $sqlorderby $limit";
        $res = $db->sql_query($sql)
                or bterror($sql);
}
else
        unset($res);

/*
if ($count == 1) {
        $row = mysql_fetch_array($res);
        header("Refresh: 0; url=modules.php?mop=modload&name=Bittorrent&file=details&id=" . $row["id"] . "&searched=" . urlencode($searchstr));
        exit();
}
*/
$additionals = 0;


if (isset($cleansearchstr))
        stdhead("Search results for \"$searchstr\"");
else {
        stdhead();


        if ($page==0 && isset($CURUSER)) {
                $additionals = 1;
                // motd
                echo $bt_start;
        }
}




$cats = genrelist();

?>
<form method="get" action="<? echo "modules.php" ?>">
<input type="hidden" name="name" value="<? echo $name ?>">
<input type="hidden" name="op" value="search">
<p align="center">
<?=_btsearch?>:
<input type="text" name="search" size="25" value="<?= htmlspecialchars($searchstr) ?>" />
<?=_btin?>
<select name="cat">
<option value="0">(<?=_btalltypes?>)</option>
<?

$catdropdown = "";
$catselect = "";
foreach ($cats as $category) {
        $catdropdown .= "<option value=\"" . $category["id"] . "\"";
        if ($category["id"] == $cat)
                $catdropdown .= " selected=\"selected\"";
        $catdropdown .= ">" . htmlspecialchars($category["name"]) . "</option>\n";
        $catselect .= "<a href='modules.php?name=$name&amp;file=index&amp;cat=".$category["id"]."'>".htmlspecialchars($category["name"])."</a> &nbsp;";
}

$deadchkbox = "<select name=\"incldead\">\n";
foreach (array(0 => _btactivetorrents, 1 => _btitm, 2 => _btstm) as $xx => $xy) {
        $deadchkbox .= "<option value=\"$xx\"";
        if ($xx == $incldead)
                $deadchkbox .= " selected=\"selected\"";
        $deadchkbox .= ">" . htmlspecialchars($xy) . "</option>\n";
}
$deadchkbox .= "</select>\n";

?>
<?= $catdropdown ?>
</select>
<?= $deadchkbox ?>
<br><?=_btorderby?>
<select name="orderby">
<option value=0><?=_btinsdate?></option>
<option value=1 <?if ($orderby==1) echo"selected";?>><?=_btname?></option>
<option value=2 <?if ($orderby==2) echo"selected";?>><?=$bt_dim?></option>
<option value=3 <?if ($orderby==3) echo"selected";?>><?=_btnfile?></option>
<option value=4 <?if ($orderby==4) echo"selected";?>><?=_btevidenced?></option>
<option value=5 <?if ($orderby==5) echo"selected";?>><?=_btcomments?></option>
<option value=6 <?if ($orderby==6) echo"selected";?>><?=_btvote?></option>
<option value=7 <?if ($orderby==7) echo"selected";?>><?=_btdownloaded?></option>
<?
if ($torrent_global_privacy){
?>
        <option value=8 <?if ($orderby==8) echo"selected";?>><?=_btprivacy?></option>
<?
}?>
<option value=9 <?if ($orderby==9) echo"selected";?>>Seeders</option>
<option value=10 <?if ($orderby==10) echo"selected";?>>Leechers</option>
<option value=11 <?if ($orderby==11) echo"selected";?>><?=_bttotsorc?></option>
</select>
<select name="ordertype">
<option value=0><?=_btdesc?></option>
<option value=1 <?if ($ordertype==1) echo"selected";?>><?=_btord?></option>
</select>
<input type="submit" value="<?php echo _btgo ?>" /> <a href='modules.php?name=<?=$name?>&file=index_help#search'><img src='modules/<?=$name?>/pic/help.gif' align='midle' border='0' alt='<?=_bthelpfind?>'></a>
</p>
</form>
<?
if ( $onlysearch==false AND  ! ($_SERVER[QUERY_STRING]=="name=Bittorrent") ){
        OpenTable2();
        echo "<center><b>"._bttype."<b><br>".$catselect."</center>";
        CloseTable2();
        echo "<br>";




        if ($page==0){

                OpenTable2();

                //Top
                $sql_best10 = "SELECT  `id`, `name`, `size`, `seeders`, `leechers`, `tot_peer` as tot, ownertype, tracker FROM  `torrent_torrents`WHERE (`seeders`=0 AND `leechers`>=10)  OR (`seeders`>=1 AND `leechers`>=5) ORDER BY tot DESC, seeders DESC, leechers DESC limit $best_limit";
                $res_best10 = $db->sql_query($sql_best10) or bterror($sql_best10);

                echo "<table><tr><th>"._bttopsource."</th></tr>";
                if ($row_best10 = $db->sql_fetchrow($res_best10)){
                        do{
                                if ($row_best10["tracker"]!="") echo "<tr><td><a href='modules.php?name=$name&file=details&id=".$row_best10["id"]."&hit=1&dllist=1#seeders'>".$row_best10["name"]."</a> ".mksize($row_best10["size"])." ".$row_best10["seeders"]." S + ".$row_best10["leechers"]." L = ".$row_best10["tot"]." fonti</td></tr>";
                                else echo "<tr><td><a href='modules.php?name=$name&file=details&id=".$row_best10["id"]."&hit=1&dllist=1#seeders'>".$row_best10["name"]."</a> ".mksize($row_best10["size"])." ".$row_best10["seeders"]." S + ".$row_best10["leechers"]." L = ".$row_best10["tot"]." fonti</td></tr>";
                        }while ($row_best10 = $db->sql_fetchrow($res_best10));
                }else{
                        echo _btnotopsource;
                }
                echo "</table>";

                echo "<br>";

                //Down
                $sql_best10 = "SELECT  `id`, `name`, `size`, `seeders`, `leechers`, `tot_peer` as tot, tracker FROM  `torrent_torrents`WHERE leechers > 0 and seeders=0 order by seeders, tot DESC, leechers DESC limit $down_limit";
                $res_best10 = $db->sql_query($sql_best10) or bterror($sql_best10);

                echo "<table><tr><th>"._btnoseeder."</th></tr>";
                echo "<tr><td>"._btnotseeder_desc."</td></tr>";
                if ($row_best10 = $db->sql_fetchrow($res_best10)){
                        do{
        echo "<tr><td><a href='modules.php?name=$name&file=details&id=".$row_best10["id"]."&hit=1&dllist=1#seeders'>".$row_best10["name"]."</a> ".mksize($row_best10["size"])." <b>".$row_best10["seeders"]." S</b> + ".$row_best10["leechers"]." L = ".$row_best10["tot"]."</td></tr>";
                        }while ($row_best10 = $db->sql_fetchrow($res_best10));
                }else{
                        echo _btnotseeder_noneed;
                }
                echo "</table>";

                CloseTable2();
        }
}



if (isset($cleansearchstr))
        print("<h2>"._btresfor." \"" . htmlspecialchars($searchstr) . "\"</h2>\n");



OpenTable2();

if ($count) {
        global $file, $onlysearch;

        if ($onlysearch==true && $_SERVER[QUERY_STRING]=="name=Bittorrent"){
                echo _btnosearch;
        }else{
                print($pagertop);
                torrenttable($res);
                print($pagerbottom);
        }
}else{
        if (isset($cleansearchstr)) {
                print(_btnotfound);
        }
        else {
                print(_btvoidcat);
        }
}
CloseTable2();

echo _bthelpindex;

require_once("include/footer.inc.php");

CloseTable();
include("footer.php");

?>