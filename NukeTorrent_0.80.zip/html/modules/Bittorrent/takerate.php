<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 1;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
global $name, $db, $torrent_global_privacy, $file;
if (!is_user($user)){
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}
include("header.php");
OpenTable();

function bark($msg) {
        genbark($msg, _btratingfailed);
}

if (!mkglobal("rating:id"))
        bark(_btmissingoformdata);

$id = 0 + $id;

$rating = 0 + $rating;
if ($rating <= 0 || $rating > 5)
        bark(_btinvalidrating);

$res = $db->sql_query("SELECT owner FROM torrent_torrents WHERE id = '$id'") or bterror("SELECT owner FROM torrent_torrents WHERE id = '$id'");
$row = $db->sql_fetchrow($res);
if (!$row)
        bark(_btidnotorrent);

if ( ($row["owner"] == $CURUSER["id"]) && $CURUSER["admin"] != "yes")
        bark(_btnovoteowntorrent);
$sql = "INSERT INTO torrent_ratings (torrent, user, rating, added) VALUES ('$id', '" . $CURUSER["id"] . "', '$rating', NOW())";
$res = $db->sql_query($sql) or bterror($sql);
if (!$res) {
        $err = Array();
        $err = $db->sql_error();
        if ($err["code"] == 1062)
                bark(_btalreadyrated);
        else
                bark($err["message"]);
}
$sql = "UPDATE torrent_torrents SET numratings = numratings + 1, ratingsum = ratingsum + '$rating' WHERE id = '$id'";
$db->sql_query($sql) or bterror($sql);

echo "<meta http-equiv=\"refresh\" content=\"3;url=modules.php?name=$name&details.php&id=$id&rated=1\">";
$btvotedone = str_replace("**name**",$name,_btvotedone);
$btvotedone = str_replace("**id**",$id,$btvotedone);
echo $btvotedone;

CloseTable();
include("footer.php");
?>