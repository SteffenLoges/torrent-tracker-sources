<?php
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                             www.sourceforge.net/projects/nuketorrent         -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/

global $admin_file;
if (!isset($admin_file) OR $admin_file == "") $admin_file = "admin"; //compatibility with Nuke 7.5
if (!eregi("".$admin_file.".php", $_SERVER['PHP_SELF'])) { die ("Access Denied"); }
adminmenu("".$admin_file.".php?op=Bittorrent", "Bit Torrent", "bittorrent.gif");
?>