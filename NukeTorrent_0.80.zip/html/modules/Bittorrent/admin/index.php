<?php
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
global $admin_file;
if (!isset($admin_file) OR $admin_file == "") $admin_file = "admin"; //compatibility with Nuke 7.5
if (!eregi("".$admin_file.".php", $_SERVER['PHP_SELF'])) { die ("Access Denied"); }
$module_name="Bittorrent";

$aid = substr("$aid", 0,25);
$row = $db->sql_fetchrow($db->sql_query("SELECT title, admins FROM ".$prefix."_modules WHERE title='$module_name'"));
$row2 = $db->sql_fetchrow($db->sql_query("SELECT name, radminsuper FROM ".$prefix."_authors WHERE aid='$aid'"));
$admins = explode(",", $row['admins']);
$auth_user = false;
if ($row2["radminsuper"] == "1") {
        $auth_user = true;
} else {
        for ($i=0; $i < sizeof($admins); $i++) {
                if ($row2['name'] == "$admins[$i]" AND $row['admins'] != "") {
                        $auth_user = true;
                }
        }
}
if (!$auth_user) {
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULESADMINS.""
        .""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}
function BitTorrentHeader() {
        global $op,$admin_file;
        echo "<CENTER>";
        OpenTable2();
        $oparray = Array(0=>"Bittorrent",1=>"Bittorrent_Config",2=>"Bittorrent_Categories");
        $langarray = Array(0=>"Admin Bit Torrent",1=>"Configurazione di Bit Torrent",2=>"Impostazioni Categorie");
        for ($i=0; $i<count($oparray); $i++) {
                echo "<INPUT type=\"button\" onclick=\"location.href('".$admin_file.".php?op=".$oparray[$i]."')\" value=\"".$langarray[$i]."\"";
                if ($op == $langarray[$i]) echo " noclick ";
                echo ">";
        }
        CloseTable2();
        echo "</CENTER>";
}
function BitTorrentAdmin() {
        global $db;
        include("header.php");
        GraphicAdmin();
        OpenTable();
        echo "<H1 align=\"center\">Amministrazione Bit Torrent</H1>";
        BitTorrentHeader();
        list ($numtorrent) = $db->sql_fetchrow($db->sql_query("SELECT count(id) as num FROM torrent_torrents;"));
        list ($numfile) = $db->sql_fetchrow($db->sql_query("SELECT count(id) as num FROM torrent_files;"));
        list ($nummagnet) = $db->sql_fetchrow($db->sql_query("SELECT count(magnet) as num FROM torrent_files WHERE magnet<>'';"));
        list ($numdonkey) = $db->sql_fetchrow($db->sql_query("SELECT count(ed2k) as num FROM torrent_files WHERE ed2k<>'';"));
        list ($numban) = $db->sql_fetchrow($db->sql_query("SELECT count(id) as num FROM torrent_torrents WHERE banned = 'yes';"));
        list ($numtrackers) = $db->sql_fetchrow($db->sql_query("SELECT count(id) as num FROM torrent_trackers;"));
        list ($version) = $db->sql_fetchrow($db->sql_query("SELECT version FROM torrent_config LIMIT 1;"));
        $best = $db->sql_fetchrowset($db->sql_query("SELECT count(A.id) as num, A.owner as owner, A.ownertype, B.username FROM torrent_torrents A LEFT JOIN nuke_users B ON A.owner = B.user_id WHERE A.ownertype <> '0' AND A.owner <> '0' GROUP BY owner ORDER BY num DESC LIMIT 5;"));
        $fp = @fopen("http://nuketorrent.sourceforge.net/lastversion","r");
        if (!$fp) {
                $lastvertext = "<B>Impossibile prelevare i dati sull'ultima versione rilasciata!</B>";
        } else {
                $version = (float) $version;
                $lastversion = (float) fgets($fp,20);
                $lastvertext = "Ultima versione: ";
                if ($version < $lastversion) {
                        $lastvertext.= "<B>$lastversion</B>";
                } else {
                        $lastvertext.= $lastversion;
                }
        }
        fclose($fp);
        echo "<P>Statistiche di utilizzo:</P>";
        echo "<UL>
        <LI>Torrent presenti: <B>$numtorrent</B></LI>
        <LI>File totali: <B>$numfile</B></LI>
        <LI>Link Magnet presenti: <B>$nummagnet</B></LI>
        <LI>Link eD2K presenti: <B>$numdonkey</B></LI>
        <LI>Torrent bannati: <B>$numban</B></LI>
        <LI>Tracker indicizzati: <B>$numtrackers</B></LI>
        </UL>";
        echo "Migliori uploaders: <UL>";
        if ($best) {
                foreach ($best as $best) {
                        echo "<LI><B>".$best["username"]."</B> con ".$best["num"]." Torrent</LI>";
                }
        } else {
                echo "Non ci sono file o gli uploader sono stealth";
        }
        echo "</UL>";
        echo "Versione Bit Torrent: $version<BR>$lastvertext";
        CloseTable();
        include("footer.php");
        die();
}
function CategoriesAdmin() {
        global $db, $admin_file, $module_name, $act, $id, $name, $sort_index, $image;
        switch ($act) {
                case "add": {
                        if (isset($name) AND isset($image) AND isset($sort_index)) {
                                $db->sql_query("INSERT INTO torrent_categories (name, sort_index, image) VALUES('".addslashes($name)."','".addslashes($index_sort)."','".addslashes($image)."');") or die("SQL ERROR");
                        }
                        break;
                }
                case "del": {
                        if (isset($id)) {
                                $db->sql_query("DELETE FROM torrent_categories WHERE id='".$id."' LIMIT 1;") or die("SQL Error");
                        }
                        break;
                }
                case "takeedit": {
                        if (isset($name) AND isset($image) AND isset($sort_index)) {
                                $db->sql_query("UPDATE torrent_categories set name = '".addslashes($name)."', index_sort = '".addslashes($index_sort)."', image ='".addslashes($image)."');") or die("SQL ERROR");
                        }
                        break;
                }
                case "edit": {
                        if (isset($act) AND $act=="edit" AND isset($id)) {
                                $act = "takeedit";
                                $row = $db->sql_fetchrow($db->sql_query("SELECT * FROM torrent_categories WHERE id = '".$id."';"));
                        } else {
                                $act = add;
                        }
                        break;
                }
        }
        include("header.php");
        GraphicAdmin();
        OpenTable();
        echo "<H1 align=\"center\">Amministrazione Bit Torrent</H1>";
        BitTorrentHeader();
        $cat = $db->sql_fetchrowset($db->sql_query("SELECT * FROM torrent_categories;"));
        echo "<H1 align=\"center\">Categorie Disponibili</H1>";
        OpenTable2();
        echo "<TABLE align=\"center\" border=\"2\" cellpadding=\"1\" cellspacing=\"1\">
        <TR><TD>ID</TD><TD>Nome</TD><TD>Indice</TD><TD>Immagine</TD><TD>Azioni</TD></TR>";
        foreach ($cat as $cat) {
                echo "<TR><TD>".$cat["id"]."</TD><TD>".$cat["name"]."</TD><TD>".$cat["sort_index"]."</TD><TD><IMG src=\"modules/$module_name/pic/".$cat["image"]."\"></TD><TD><A href=\"".$admin_file.".php?op=Bittorrent_Categories&act=del&id=".$cat["id"]."\">[Elimina]</A>&nbsp;&nbsp;<A href=\"".$admin_file.".php?op=Bittorrent_Categories&act=edit&id=".$cat["id"]."\">[Modifica]</A></TD></TR>";
        }
        echo "</TABLE>";
        CloseTable2();
        echo "<H1>Aggiungi/Modifica Categoria</H1>";

        echo "<FORM action=\"$admin_file.php?op=Bittorrent_Categories&act=$act\" method=\"POST\">";
        echo "<TABLE border=\"0\">";
        echo "<INPUT type=\"hidden\" name=\"id\" value=\"".$row["id"]."\"><BR>";
        echo "<TR><TD>Nome:</TD><TD><INPUT type=\"text\" name=\"name\" size=\"20\" value=\"".$row["name"]."\"></TD></TR>";
        echo "<TR><TD>Index:</TD><TD><INPUT type=\"text\" name=\"sort_index\" size=\"20\" value=\"".$row["sort_index"]."\"></TD></TR>";
        echo "<TR><TD>Immagine:</TD><TD><INPUT type=\"text\" name=\"image\" size=\"20\" value=\"".$row["image"]."\"></TD><TD>(directory modules/$module_name/pic/)</TD></TR>";
        echo "<TR></TR>";
        echo "<TR><TD><INPUT type=\"submit\" value=\"Invia\"><INPUT type=\"reset\" value=\"Reset\"></TD></TR>";
        echo "</TABLE>";
        echo "</FORM>";
        CloseTable();
        include("footer.php");
        die();
}
function TorrentSaveConfig() {
        global $db, $onlysearch, $max_torrent_size, $announce_interval, $minvotes, $time_tracker_update, $timeout_repeat_tu, $time_check, $best_limit, $down_limit, $default_limit, $torrent_global_privacy, $down_reg, $down_paid, $max_num_file, $max_share_size, $min_size_seed, $min_share_seed, $extern_check, $max_num_file_day_e, $max_num_file_week_e, $min_num_seed_e, $min_size_seed_e, $maxupload_day_num, $maxupload_day_share, $minupload_size_file, $announce_urls, $stealthmode, $autoclean_interval, $maximagesize, $signup_timeout, $max_dead_torrent_time, $src_url;
}
function TorrentConfig() {
        global $db, $admin_file, $act;
        if ($act == "save") {
                global $db, $onlysearch, $max_torrent_size, $announce_interval, $minvotes, $time_tracker_update, $timeout_repeat_tu, $time_check, $best_limit, $down_limit, $default_limit, $torrent_global_privacy, $down_reg, $down_paid, $max_num_file, $max_share_size, $min_size_seed, $min_share_seed, $extern_check, $max_num_file_day_e, $max_num_file_week_e, $min_num_seed_e, $min_size_seed_e, $maxupload_day_num, $maxupload_day_share, $minupload_size_file, $announce_urls, $stealthmode, $autoclean_interval, $maximagesize, $signup_timeout, $max_dead_torrent_time, $src_url;
                list ($version) = $db->sql_fetchrow($db->sql_query("SELECT version FROM torrent_config;"));
                $set = true;
                if (!isset($onlysearch)) $onlysearch = false;
                if (!isset($torrent_global_privacy)) $torrent_global_privacy = false;
                if (!isset($down_reg)) $down_reg = false;
                if (!isset($down_paid)) $down_paid = false;
                $vararray = explode(", ","onlysearch, max_torrent_size, announce_interval, minvotes, time_tracker_update, timeout_repeat_tu, time_check, best_limit, down_limit, default_limit, torrent_global_privacy, down_reg, down_paid, max_num_file, max_share_size, min_size_seed, min_share_seed, extern_check, max_num_file_day_e, max_num_file_week_e, min_num_seed_e, min_size_seed_e, maxupload_day_num, maxupload_day_share, minupload_size_file, announce_urls, stealthmode, autoclean_interval, maximagesize, signup_timeout, max_dead_torrent_time, src_url");
                foreach ($vararray as $v) {
                        if (!isset($$v)) {
                                $set = false;
                                $unst = $v;
                        }
                }
                if (!$set) die("Valore non impostato: $unst");
                $sql = "UPDATE torrent_config SET ";
                foreach ($vararray as $v) $sql.= $v." = '".$$v."', ";
                $sql.= "version = '".$version."' LIMIT 1;";
                $db->sql_query($sql) or die("SQL Error");
        }
        include("header.php");
        GraphicAdmin();
        OpenTable();
        echo "<H1 align=\"center\">Amministrazione Bit Torrent</H1>";
        BitTorrentHeader();
        $res = $db->sql_query("SELECT * from torrent_config LIMIT 1;");
        $sql = "SELECT onlysearch, max_torrent_size, announce_interval, minvotes, time_tracker_update, timeout_repeat_tu, time_check, best_limit, down_limit, default_limit, torrent_global_privacy, down_reg, down_paid, max_num_file, max_share_size, min_size_seed, min_share_seed, extern_check, max_num_file_day_e, max_num_file_week_e, min_num_seed_e, min_size_seed_e, maxupload_day_num, maxupload_day_share, minupload_size_file, announce_urls, stealthmode, autoclean_interval, maximagesize, signup_timeout, max_dead_torrent_time, src_url FROM torrent_config LIMIT 1;";
        list ($onlysearch, $max_torrent_size, $announce_interval, $minvotes, $time_tracker_update, $timeout_repeat_tu, $time_check, $best_limit, $down_limit, $default_limit, $torrent_global_privacy, $down_reg, $down_paid, $max_num_file, $max_share_size, $min_size_seed, $min_share_seed, $extern_check, $max_num_file_day_e, $max_num_file_week_e, $min_num_seed_e, $min_size_seed_e, $maxupload_day_num, $maxupload_day_share, $minupload_size_file, $announce_urls, $stealthmode, $autoclean_interval, $maximagesize, $signup_timeout, $max_dead_torrent_time, $src_url) = $db->sql_fetchrow($db->sql_query($sql));
?>
<FORM action="<?=$admin_file?>.php?op=Bittorrent_Config&act=save" method="POST">
<TABLE align="center" border="2" width="50%" cellpadding="2" id="table1">
        <TR>
                <TD>Solo ricerca</TD>
                <TD><INPUT type="checkbox" name="onlysearch" value="true" <? if ($onlysearch==true) echo "checked"; ?>></TD>
        </TR>
        <TR>
                <TD>Dimensione massima Torrent</TD>
                <TD><INPUT type="text" name="max_torrent_size" value="<?=$max_torrent_size?>"></TD>
        </TR>
        <TR>
                <TD>Intervallo minimo SpyTorrent</TD>
                <TD><INPUT type="text" name="announce_interval" value="<?=$announce_interval?>"></TD>
        </TR>
        <TR>
                <TD>Voti minim</TD>
                <TD><INPUT type="text" name="minvotes" value="<?=$minvotes?>"></TD>
        </TR>
        <TR>
                <TD>Intervallo autoscrape (minuti)</TD>
                <TD><INPUT type="text" name="time_tracker_update" value="<?=$time_tracker_update?>"></TD>
        </TR>
        <TR>
                <TD>Intervallo nuovo scrape in caso di timeout</TD>
                <TD><INPUT type="text" name="timeout_repeat_tu" value="<?=$timeout_repeat_tu?>"></TD>
        </TR>
        <TR>
                <TD>Controlli ogni (secondi)</TD>
                <TD><INPUT type="text" name="time_check" value="<?=$time_check?>"></TD>
        </TR>
        <TR>
                <TD>Rapporto seed/leech per Migliori Torrent</TD>
                <TD><INPUT type="text" name="best_limit" value="<?=$best_limit?>"></TD>
        </TR>
        <TR>
                <TD>Rapporto seed/leech per Torrent Morti</TD>
                <TD><INPUT type="text" name="down_limit" value="<?=$down_limit?>"></TD>
        </TR>
        <TR>
                <TD>Rapporto di default</TD>
                <TD><INPUT type="text" name="default_limit" value="<?=$default_limit?>"></TD>
        </TR>
        <TR>
                <TD>Modalit� Privacy</TD>
                <TD><INPUT type="checkbox" name="torrent_global_privacy" value="true" <?if ($torrent_global_privacy==true) echo "checked"?>></TD>
        </TR>
        <TR>
                <TD>Download solo utenti registrati</TD>
                <TD><INPUT type="checkbox" name="down_reg" value="true" <?if ($down_reg==true) echo "checked"?>></TD>
        </TR>
        <TR>
                <TD>Download solo utenti selezionati dall'ADMIN</TD>
                <TD><INPUT type="checkbox" name="down_paid" value="true" <?if ($down_paid==true) echo "checked"?>></TD>
        </TR>
        <TR>
                <TD>Massimo numero file ogni Torrent</TD>
                <TD><INPUT type="text" name="max_num_file" value="<?=$max_num_file?>"></TD>
        </TR>
        <TR>
                <TD>Massima dimensione share</TD>
                <TD><INPUT type="text" name="max_share_size" value="<?=$max_share_size?>"></TD>
        </TR>
        <TR>
                <TD>Minima dimensione seed</TD>
                <TD><INPUT type="text" name="min_size_seed" value="<?=$min_size_seed?>"></TD>
        </TR>
        <TR>
                <TD>Minimo Share per Seed</TD>
                <TD><INPUT type="text" name="min_share_seed" value="<?=$min_share_seed?>"></TD>
        </TR>
        <TR>
                <TD>Autoscrape</TD>
                <TD><INPUT type="text" name="extern_check" value="<?=$extern_check?>"></TD>
        </TR>
        <TR>
                <TD>File massimi al giorno</TD>
                <TD><INPUT type="text" name="max_num_file_day_e" value="<?=$max_num_file_day_e?>"></TD>
        </TR>
        <TR>
                <TD>File massimi a settimana</TD>
                <TD><INPUT type="text" name="max_num_file_week_e" value="<?=$max_num_file_week_e?>"></TD>
        </TR>
        <TR>
                <TD>Minimo numero seed</TD>
                <TD><INPUT type="text" name="min_num_seed_e" value="<?=$min_num_seed_e?>"></TD>
        </TR>
        <TR>
                <TD>Minima dimensione seed</TD>
                <TD><INPUT type="text" name="min_size_seed_e" value="<?=$min_size_seed_e?>"></TD>
        </TR>
        <TR>
                <TD>Upload massimi al giorno</TD>
                <TD><INPUT type="text" name="maxupload_day_num" value="<?=$maxupload_day_num?>"></TD>
        </TR>
        <TR>
                <TD>Share in upload massimo al giorno</TD>
                <TD><INPUT type="text" name="maxupload_day_share" value="<?=$maxupload_day_share?>"></TD>
        </TR>
        <TR>
                <TD>Dimensione minima file in upload</TD>
                <TD><INPUT type="text" name="minupload_size_file" value="<?=$minupload_size_file?>"></TD>
        </TR>
        <TR>
                <TD>Announce URL ufficiali (separati da virgola)</TD>
                <TD><TEXTAREA rows="3" cols="24" name="announce_urls"><?=$announce_urls?></TEXTAREA></TD>
        </TR>
        <TR>
                <TD>Modalit� stealth (per trovare un Torrent � obbligatoria la ricerca manuale)</TD>
                <TD><INPUT type="text" name="stealthmode" value="<?=$stealthmode?>"></TD>
        </TR>
        <TR>
                <TD>Timeout azzeramento fonti</TD>
                <TD><INPUT type="text" name="autoclean_interval" value="<?=$autoclean_interval?>"></TD>
        </TR>
        <TR>
                <TD>Dimensione massima immagini (KB)</TD>
                <TD><INPUT type="text" name="maximagesize" value="<?=$maximagesize?>"></TD>
        </TR>
        <TR>
                <TD>Timeout Signup (cambiare in caso di necessit�)</TD>
                <TD><INPUT type="text" name="signup_timeout" value="<?=$signup_timeout?>"></TD>
        </TR>
        <TR>
                <TD>Tempo massimo morte Torrent (cambiare in caso di necessit�)</TD>
                <TD><INPUT type="text" name="max_dead_torrent_time" value="<?=$max_dead_torrent_time?>"></TD>
        </TR>
        <TR>
                <TD>Modalit� URL Sorgente (vedi Guida)</TD>
                <TD><SELECT name="src_url">
<?
$srcarray = Array(1=>"disabled",2=>"torrent",3=>"url",4=>"force");
$srclangarray = Array(1=>"Disabilitato",2=>"Preferisci Torrent",3=>"Preferisci URL",4=>"Forza URL");
for ($i=1; $i<=count($srcarray); $i++) {
        echo "<OPTION value=\"".$srcarray[$i]."\">".$srclangarray[$i]."</OPTION>";
}
?>
                    </SELECT></TD>
        </TR>
</TABLE>
<INPUT type="submit" value="Invia"><INPUT type="reset" value="Reset">
</FORM>
<?
        CloseTable();
        include("footer.php");
        die();
}
switch ($op) {
        case "Bittorrent": {
                BitTorrentAdmin();
                break;
        }
        case "Bittorrent_Categories": {
                CategoriesAdmin();
                break;
        }
        case "Bittorrent_Config": {
                TorrentConfig();
                break;
        }
}
die();
?>