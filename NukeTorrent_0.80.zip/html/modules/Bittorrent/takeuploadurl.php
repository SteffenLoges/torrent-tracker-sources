<?

$index = 0;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php")
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);

loggedinorreturn();

$fname = "";
$dname = "";
$infohash = "";
$totallen = 0;

if ( !is_array($ed2klist) && !is_array($magneticlist) ){
        die(_btnolinkinsert);
}

$ed2knum = count($ed2klist);
$magneticnum = count($magneticlist);

if ($ed2knum>0 && $magneticnum>0 && $magneticnum!=$ed2knum) die(_btinseriti." ".$ed2knum." ed2klink "._btand." ".$magneticnum." magnetic link, "._btnumerror);


include("header.php");
OpenTable();

$ed2ksql = array();

//ed2k://|file|underworld.dvdrip.mux.divx.ita.dxl.avi|727601152|FCF884A731389D1C2D6378D3EC1C9284|/|sources,39.255.147.122:4662|/

if(is_array($ed2klist)){
    foreach($ed2klist as $ed2kurl){
//      printf("%s<br>\n",$ed2kurl);

                if (!empty($ed2kurl)){
                        if(strlen($ed2kurl)>200)
                                die(_btmaxchar);
                        $ed2kurlarray = explode("|", $ed2kurl);

                        if($ed2kurlarray[0]!="ed2k://")
                                die(_bted2kstart);

                        if($ed2kurlarray[1]!="file")
                                die(_bt2par." <b>"._bturlfile."</b>");

                        if(strlen($ed2kurlarray[2])==0)
                                die(_bturlcontent." <b>"._btfname."</b>");
                        $ed2kname = $ed2kurlarray[2];

                        $size = $ed2kurlarray[3]+0;
                        if($size==0)
                                die(_bturlsize." <b>"._btsz."</b>");
                        $totallen += $size;

                        if(strlen($ed2kurlarray[4])!=32)
                                die(_bturlcontent." <b>"._btidcode."</b>");
                        $infohash = substr($ed2kurlarray[4], 0, 20);

                        if($ed2kurlarray[5]!="/")
                                die(_bturlparerror." <b>/</b>");

                        if(strlen($ed2kurlarray[6])>0){
                                $param = substr($ed2kurlarray[6], 0, 8);
                                if($param!="sources,") die(_bturlsureerror);

                                $separator = strpos($ed2kurlarray[6], ":");
                                $ip = substr($ed2kurlarray[6], 8, $separator-8);
                                $port = substr($ed2kurlarray[6], $separator+1)+0;
                                if (empty($ip)) die(_btnotip);
                                if(!preg_match('/^(\d{1,3}\.){3}\d{1,3}$/s', $ip)) die(_btinvip);
                                if (empty($port)) die(_btnoport);
                                if(!($port>0 && $port<65536)) die(_btinvport);
                        }

                        if(empty($namex)) $namex = $ed2kname;

                        $sql_insert_field .= ", ed2k";
                        $sql_insert_value .= ", '".str_replace("'", "_", stripslashes($ed2kurl))."'";

                        //Insert in array sql file
                        $ed2ksql[] = str_replace("'", "_", stripslashes($ed2kurl));
                        $ed2ksqlname[] = $ed2kname;
                        $ed2ksqlsize[] = $size;
                }
        }
}

if(is_array($magneticlist)){
    foreach($magneticlist as $magneticurl){
//                printf("%s<br>\n",$magneticurl);
                   if (!empty($magneticurl)){
                        if(strlen($magneticurl)>200) die($bt_tumagnetmaxchar);
                        if(substr($magneticurl, 0, 20)!="magnet:?xt=urn:sha1:" && (substr($magneticurl, 0, 24)!="magnet:?xt=urn:bitprint:") )die("Url Protocollo Magnetic non comincia per magnet:?xt=urn:sha1: o per magnet:?xt=urn:bitprint:");
                        $infohash = substr($magneticurl, 25, 20);

                        if(substr($magneticurl, 52, 4)=="&dn=")
                                $magneticname = substr($magneticurl, 56);
                        elseif(substr($magneticurl, 96, 4)=="&dn=")
                                $magneticname = substr($magneticurl, 100);
                        else
                                die(_btparmag." &dn= "._btnopresent);

                        if(strlen($magneticname)<=4) die(_btmagchar);

                        $sql_insert_field .= ", magnet";
                        $sql_insert_value .= ", '".str_replace("'", "_", stripslashes($magneticurl))."'";

                        if(empty($namex)) $namex = $fname;

                        //Insert in array sql file
                        $magneticsql[] = str_replace("'", "_", stripslashes($magneticurl));
                        $magneticsqlname[] = $magneticname;

                }
    }
}

/* DEBUG
echo "<p>".print_r($magneticsql)."</p>";
echo "<p>".print_r($magneticsqlname)."</p>";
echo "<p>".print_r($ed2ksql)."</p>";
echo "<p>".print_r($ed2ksqlname)."</p>";
echo "<p>".print_r($ed2ksqlsize)."</p>";
*/
$torrent = $namex;
$dname = $namex;


if ($CURUSER["admin"] != "yes" && $minupload_size_file>=$totallen){
        echo "<p>"._bftminlimit." <b>".mksize($minupload_size_file)."</b></p><p>"._btfmaxlimit." <b>".mksize(".$totallen.")."</b>.";
        CloseTable();
        include("footer.php");
        die();
}

        //Filtro costruzione dal nome file lungo almeno 4 caratteri
        $materia=trim($fname);
        $pos = strrpos($materia, '.');
        if (!$pos===false)
                $materia = substr($materia, 0, $pos);
        $search = array (
                 "'[^a-zA-Z]'",                 // Remove not lecter
                 "'([\r\n])[\s]+'"                 // Remove Blank space
        );
        $replace = array (
                                          " ",
                                          "\\1"
        );
        $materia = preg_replace ($search, $replace, $materia);
        $materia=explode(" ", $materia);

        $sql_filter = "";
        foreach($materia as $x){
                $x = trim($x);
                if(strlen($x)>=3){
                                $sql_filter .= " OR keyword LIKE '".str_replace("'", "''", $x)."'";
                }
        }
        $sql_filter = "SELECT * FROM torrent_filter WHERE 1=0 ".$sql_filter;
        $res = $db->sql_query($sql_filter);
        if ($row = $db->sql_fetchrow($res)){
                echo _btillegalword.":<ol>";
                do{
                        echo "<li><b>".$row[keyword]."</b> ".$row[reason];
                }while ($row = $db->sql_fetchrow($res));
                echo "</ol><p>"._btillegalwordinfo."</p>";
                CloseTable();
                include("footer.php");
                die();
        }

        //Fine filtro


$ip = $_SERVER["REMOTE_ADDR"];
global $evidence, $ownertype;
if ($evidence!=1) $evidence =0;
if ($ownertype<0 || $ownertype>2) $ownertype = 0;

$owner = 0;
if ($ownertype!=2){
        $owner = $CURUSER["id"];
}

if($ed2knum>$magneticnum)
        $numfile = $ed2knum;
else
        $numfile = $magneticnum;

if($numfile>1){
        $sql_insert_field = "";
        $sql_insert_value = "";
}

$fname = stripslashes($fname);
$torrent = stripslashes($torrent);
$descr = stripslashes($descr);
$dname = stripslashes($dname);

$sql = "INSERT INTO torrent_torrents (search_text, filename, owner, visible, info_hash, name, size, numfiles, `type`, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$fname $dname"), $fname, $owner, "yes", $infohash, $torrent, $totallen, $numfile, "link", parsedescr($descr), $descr, 0 + $_POST["type"], $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip' $sql_insert_value)";

if(!($result = $db->sql_query($sql)))
        bterror($sql);

if(!($idtorrent = $db->sql_nextid()))
        bterror("NextID");

//if(!($idtorrent = $db->sql_nextid($sql)))
//        bterror("NextID");

//inserimento file
if($numfile>1)
        for($i=0;$i<$ed2knum || $i<$magneticnum;$i++){
                if(empty($ed2ksqlname[$i]))
                        $name_put = $magneticsqlname[$i];
                else
                        $name_put = $ed2ksqlname[$i];
                $sqlfile = "INSERT INTO torrent_files (torrent, filename, size, ed2k, magnet) VALUES ('$idtorrent', ".sqlesc($name_put).", '".$ed2ksqlsize[$i]."', '".$ed2ksql[$i]."', '".$magneticsql[$i]."')";
                if(!($result = $db->sql_query($sqlfile)))
                        bterror($sqlfile);
        }

echo "<meta http-equiv=\"refresh\" content=\"3;url=modules.php?name=$name&file=details&id=$idtorrent&uploaded=1\">";
echo _bturlinserted1." <a href=\"modules.php?name=$name&file=details&id=$idtorrent&uploaded=1\">"._bturlinserted2."</a>";

global $notify;
if($notify==1){
        $sql = "INSERT INTO torrent_comments_notify (torrent, user, can_send) VALUES ('$idtorrent', ".$CURUSER["id"].", 1)";
        $db->sql_query($sql) or die("SQL: ".$sql);
        echo  "<p>"._btnotify."</p>";
}

CloseTable();
include("footer.php");
?>