<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$nologin = true;
require_once("config.php");

$new_include_dir = "../../";

//Please use PHP 4 >= 4.3.0, PHP 5 or modify to hand
set_include_path(get_include_path() . ":" . $new_include_dir);

require_once("mainfile.php");
require_once("include/bittorrent.php");

//ob_start();

function err($msg) {
        benc_resp(array("failure reason" => array(type => "string", value => $msg)));
        exit();
}

function benc_resp($d) {
        benc_resp_raw(benc(array(type => "dictionary", value => $d)));
}

function benc_resp_raw($x) {
        header("Content-Type: text/plain");
        header("Pragma: no-cache");
        print($x);
}

$req = "info_hash:peer_id:!ip:port:uploaded:downloaded:left:!event";
foreach (explode(":", $req) as $x) {
        if ($x[0] == "!") {
                $x = substr($x, 1);
                $opt = 1;
        }
        else
                $opt = 0;
        if (!isset($_GET[$x])) {
                if (!$opt)
                        err("missing key");
                continue;
        }
        $GLOBALS[$x] = unesc($_GET[$x]);
}

foreach (array("info_hash","peer_id") as $x) {
        if (strlen($GLOBALS[$x]) != 20)
                err("invalid $x (" . strlen($GLOBALS[$x]) . " - " . urlencode($GLOBALS[$x]) . ")");
}

$true_ip = $_SERVER["REMOTE_ADDR"];
if (empty($ip) || !preg_match('/^(\d{1,3}\.){3}\d{1,3}$/s', $ip))
        $ip = $_SERVER["REMOTE_ADDR"];

$port = 0 + $port;
$downloaded = 0 + $downloaded;
$uploaded = 0 + $uploaded;
$left = 0 + $left;

$rsize = 50;


foreach(array("num want", "numwant", "num_want") as $k) {
        if (isset($_GET[$k])) {
                $rsize = 0 + $_GET[$k];
                break;
        }
}

if (!$port || $port > 0xffff)
        err("invalid port");


        //mysql_query("DELETE FROM peers WHERE id = " . $self["id"]);
        $sql_delete = "DELETE FROM torrent_check_peers WHERE true_ip=".sqlesc($true_ip)." or data<SYSDATE()- INTERVAL 1 DAY";
        $db->sql_query($sql_delete) or die("Error ".$sql_delete);

        $sockres = @fsockopen($ip, $port, $errno, $errstr, 5);
        if (!$sockres){
                $connectable = "no";
                $messaggio = $bt_capassive;
        }else {
                $connectable = "yes";
                @fclose($sockres);
                $messaggio = $bt_caactive;
        }

        $sql_insert = "INSERT INTO torrent_check_peers (connectable, true_ip, ip, port, data) VALUES ('$connectable', ".sqlesc($true_ip) . ", " . sqlesc($ip) . ", '$port', SYSDATE())";
        $db->sql_query($sql_insert) or die("Error ".$sql_insert);

        err("$messaggio");
?>