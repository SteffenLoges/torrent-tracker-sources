<?/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 1;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
global $name, $db, $torrent_global_privacy, $file;
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/include/benc.php");
require_once("modules/$name/config.php");
if (!is_user($user)){
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}
loggedinorreturn();
ini_set("upload_max_filesize",$max_torrent_size);
include("header.php");
OpenTable();

function bark($msg) {
        genbark($msg, _btuploadfailed);
}

foreach(explode(":","descr:type:namex") as $v) {
        if (!isset($_POST[$v]))
                bark(_btmissingdata);
}

if (!isset($_FILES["filex"]))
        bark(_btmissingdata);

$f = $_FILES["filex"];
$fname = unesc($f["name"]);
if (empty($fname))
        bark(_btemptyfname);
if (!validfilename($fname))
        bark(_btinvalidfname);
if (!preg_match('/^(.+)\.torrent$/si', $fname, $matches))
        bark(_btfnamenotorrent);
$shortfname = $torrent = $matches[1];
if (!empty($_POST["namex"]))
        $torrent = unesc($_POST["namex"]);

$tmpname = $f["tmp_name"];



$fp = @fopen($f["tmp_name"], "rb");
if ($fp){
        $page=fread($fp, 1000000);
        fclose($fp);
}else{
        die(_btferror);
}
$parse_array_torrent = array();
$i=0;
$max=strlen($page);
$parse_array_torrent = ergo($page, $parse_array_torrent, $i, $max);
function print_parse(&$parse_array_read){
        foreach ($parse_array_read as $key => $val){
                echo "[$key => ";
                if (is_array ($val)){
                        echo "<BLOCKQUOTE dir=ltr style='MARGIN-RIGHT: 0px'><P>";
                        print_parse($val);
                        echo "</P></BLOCKQUOTE>";
                }else{
                        echo $val;
                }
                echo "]";
        }
}
// Convert 5 Bytes to 8 Bytes Base32
function _Sha1toBase32($in){
        $Table = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

        $out = substr($Table, ((ord(substr($in, 0, 1)) >> 3)               ) & 0x1F, 1);
        $out .= substr($Table, ((ord(substr($in, 0, 1)) << 2) | (ord(substr($in, 1, 1)) >> 6)) & 0x1F, 1);
        $out .= substr($Table, ((ord(substr($in, 1, 1)) >> 1)               ) & 0x1F, 1);

        $a = (ord(substr($in, 1, 1)) << 4) & 0x00FF;
        $b = ((ord(substr($in, 2, 1))) >> 4)&0x00FF;
        $out .= substr($Table, ( $a | $b )&0x1F, 1);

        $a = ( (ord(substr($in, 2, 1))&0x00FF) << 1) &0x00FF;
        $b = ((ord(substr($in, 3, 1)) >> 7)) &0x00FF;


        $out .= substr($Table, ( $a | $b )&0x1F, 1);
        $out .= substr($Table, ((ord(substr($in, 3, 1)) >> 2)               ) & 0x1F, 1);

        $a = (ord(substr($in, 3, 1)) << 3) & 0x00FF;
        $b = ((ord(substr($in, 4, 1)) >> 5)) &0x00FF;
        $out .= substr($Table, ( $a|$b ) & 0x1F, 1);

        $out .= substr($Table, ((ord(substr($in, 4, 1))     )               ) & 0x1F, 1);
        return $out;
}

// Return a base32 representation of a sha1 hash
function Sha1toBase32($Sha1){
        //Magnetic link
        $ret="";

        $Base32 = _Sha1toBase32(substr($Sha1, 0, 5));
        $Base32 .= _Sha1toBase32(substr($Sha1, 5, 5));
        $Base32 .= _Sha1toBase32(substr($Sha1, 10, 5));
        $Base32 .= _Sha1toBase32(substr($Sha1, 15, 5));

        $ret = $Base32;
        return $ret;
}

function strtohex($strtmp){
        //Emule
        $max = strlen($strtmp);
        $hex = "";
        for($i=0; $i<$max;$i++){
                $hex .= dechex(ord(substr($strtmp, $i, 1)));
        }
        return strtoupper($hex);
}



$magnet_link = "";
$ed2k_link = "";
$sql_insert_field = "";
$sql_insert_value = "";
if($parse_array_torrent["0"]["info"]["sha1"]){
        $magnet_link = "magnet:?xt=urn:sha1:".addslashes(Sha1toBase32($parse_array_torrent["0"]["info"]["sha1"]))."&dn=".urlencode($parse_array_torrent["0"]["info"]["name"]);
        $sql_insert_field .= ", magnet";
        $sql_insert_value .= ", '$magnet_link'";
}
if($parse_array_torrent["0"]["info"]["ed2k"]){
        $ed2k_link = "ed2k://|file|".urlencode($parse_array_torrent["0"]["info"]["name"])."|".urlencode($parse_array_torrent["0"]["info"]["length"])."|".strtohex($parse_array_torrent["0"]["info"]["ed2k"])."|/";
        $sql_insert_field .= ", ed2k";
        $sql_insert_value .= ", '$ed2k_link'";
}



if (!is_uploaded_file($tmpname))
        bark(_bterrnofileupload);
if (!filesize($tmpname))
        bark(_btemptyfile);

$dict = bdec_file($tmpname, $max_torrent_size);
if (!isset($dict))
        bark(_btnobenc);

function dict_check($d, $s){
        if ($d["type"] != "dictionary")
                bark(_btnodictionary);
        $a = explode(":", $s);
        $dd = $d["value"];
        $ret = array();
        foreach ($a as $k) {
                unset($t);
                if (preg_match('/^(.*)\((.*)\)$/', $k, $m)) {
                        $k = $m[1];
                        $t = $m[2];
                }
                if (!isset($dd[$k]))
                        bark(_btdictionarymisskey);
                if (isset($t)) {
                        if ($dd[$k]["type"] != $t)
                                bark(_btdictionaryinventry);
                        $ret[] = $dd[$k]["value"];
                }
                else
                        $ret[] = $dd[$k];
        }
        return $ret;
}

function dict_get($d, $k, $t) {
        if ($d["type"] != "dictionary")
                bark(_btnodictionary);
        $dd = $d["value"];
        if (!isset($dd[$k]))
                return;
        $v = $dd[$k];
        if ($v["type"] != $t)
                bark(_btdictionaryinvetype);
        return $v["value"];
}

list($ann, $info) = dict_check($dict, "announce(string):info");
list($dname, $plen, $pieces) = dict_check($info, "name(string):piece length(integer):pieces(string)");

if (!in_array($ann, $announce_urls, 1))
        if (!$stealthmode){
                bark(_btinvannounce."<b>" . $announce_urls[0] . "</b>. "."--".$ann."--");
        }else{
                $tracker = $ann;
        }
global $nukeurl, $name, $stealthmode;

if($ann=="$nukeurl/modules/$name/announce.php" and $stealthmode) bark(str_replace("**name**",$name,_bttrackerdisabled));

if (strlen($pieces) % 20 != 0)
        bark(_btinvpieces);

$filelist = array();
$totallen = dict_get($info, "length", "integer");
if (isset($totallen)) {
        $filelist[] = array($dname, $totallen);
        $type = "single";
}
else {
        $flist = dict_get($info, "files", "list");
        if (!isset($flist))
                bark(_btmissinglength);
        if (!count($flist))
                bark(_btnofilesintorrent);
        $totallen = 0;
        foreach ($flist as $fn) {
                list($ll, $ff) = dict_check($fn, "length(integer):path(list)");
                $totallen += $ll;
                $ffa = array();
                foreach ($ff as $ffe) {
                        if ($ffe["type"] != "string")
                                bark(_btfnamerror);
                        $ffa[] = $ffe["value"];
                }
                if (!count($ffa))
                        bark(_btfilenamerror);
                $ffe = implode("/", $ffa);
                $filelist[] = array($ffe, $ll);
        }
        $type = "multi";
}

$infohash = pack("H*", sha1($info["string"]));
$descr = unesc($_POST["descr"]);
global $source_url;
if ($source_url == "http://" OR substr($source_url,0,7)!=="http://") $source_url='';


//Raulken
//$maxupload_day_num = 2; //Number of max upload a day
//$maxupload_day_share = 3 * 1024 *1048576; //Max share size to upload a day
//$minupload_size_file = 100 * 1048576; //Min size of

$sql = "SELECT  count(size) as num, sum(size) as tot_size FROM `torrent_torrents` where `added` > sysdate() - 1000000 AND owner = '".$CURUSER["id"]."'";
$res = $db->sql_query($sql) or bterror($sql);
$row = $db->sql_fetchrow($res);

if (!is_admin($admin) && $minupload_size_file>$totallen){
        echo _bttorrenttoosmall1.mksize($minupload_size_file)._bttorrenttoosmall2.mksize($totallen)."</b>.";
        CloseTable();
        include("footer.php");
        die();
}

//Max # num upload on 24h
if (!is_admin($admin) && $maxupload_day_num>0 && $maxupload_day_num<=$row["num"]){
        echo str_replace("**maxupload**",$maxupload_day_num,_btmaxuploadexceeded);
        CloseTable();
        include("footer.php");
        die();
}

//Max size share upload on 24h
if (!is_admin($admin) && $maxupload_day_share>0 && $maxupload_day_share<$row["tot_size"]+$totallen){
        $btnumfileexceeded = str_replace("**maxupload",$maxupload_day_share,_btnumfileexceeded);
        $btnumfileexceeded = str_replace("**rownum**",$row["num"],$btnumfileexceeded);
        $btnumfileexceeded = str_replace("**totsize**",mksize($row["tot_size"]),$btnumfileexceeded);
        echo $btnumfileexceeded;
        CloseTable();
        include("footer.php");
        die();
}

        //Filtro costruzione dal nome file lungo almeno 4 caratteri
        $materia=trim($fname);
        $pos = strrpos($materia, '.');
        if (!$pos===false)
                $materia = substr($materia, 0, $pos);
        $search = array (
                                         "'[^a-zA-Z]'",                 // Remove not lecter
                                         "'([\r\n])[\s]+'"                 // Remove Blank space
        );
        $replace = array (
                                          " ",
                                          "\\1"
        );
        $materia = preg_replace ($search, $replace, $materia);
        $materia=explode(" ", $materia);

        $sql_filter = "";
        foreach($materia as $x){
                $x = trim($x);
                if(strlen($x)>=3){
                                $sql_filter .= " OR keyword LIKE ".sqlesc($x)."";
                }
        }
        $sql_filter = "SELECT * FROM torrent_filter WHERE 1=0 ".$sql_filter;
        $res = $db->sql_query($sql_filter) or bterror($sql_filter);
        if ($row = $db->sql_fetchrow($res)){
                Echo _btillegalword;
                do{
                        echo "<li><b>".$row[keyword]."</b> ".$row[reason];
                }while ($row = $db->sql_fetchrow($res));
                echo _btillegalwordinfo;
                CloseTable();
                include("footer.php");
                die();
        }

        //Fine filtro


global $jump_check;
if ($jump_check){
        $materia=trim($fname);

        $pos = strrpos($materia, '.');
        if (!$pos===false)
                $materia = substr($materia, 0, $pos);

        $search = array (
                                         "'[^a-zA-Z]'",                 // Remove not lecter
                                         "'([\r\n])[\s]+'"                 // Remove Blank space
        );

        $replace = array (
                                          " ",
                                          "\\1"
        );

        $materia = preg_replace ($search, $replace, $materia);
        $materia=explode(" ", $materia);

        $sql = "";
        $sql_filter = "";
        foreach($materia as $x){
                        $x = trim($x);
                        if(strlen($x)>=5){
                                        $sql .= " OR filename LIKE ".sqlesc($x);
                        }
        }

        foreach ($filelist as $file) {
                        $sql .= " OR size=".sqlesc($file[1]);
        }

        $sql = "SELECT torrent, filename, size FROM torrent_files WHERE 1=0 ".$sql;
        $res = $db->sql_query($sql) or bterror($sql);
        if ($row = $db->sql_fetchrow($res)){
                Echo _btsearchdupl;
                do{
                        echo "<li><a href='modules.php?name=$name&file=details&id=".$row["torrent"]."&hit=1'>".$row["filename"]."</a> (".mksize($row["size"]).")";
                }while ($row = $db->sql_fetchrow($res));
                echo _btduplinfo;
                CloseTable();
                include("footer.php");
                die();
        }
}


$ip = $_SERVER["REMOTE_ADDR"];
global $evidence, $ownertype;
if ($evidence!=1) $evidence =0;
if ($ownertype<0 || $ownertype>2) $ownertype = 0;

$owner = 0;
if ($ownertype!=2){
        $owner = $CURUSER["id"];
}






if ($tracker!=""){

/*
        $slash_point=strrpos($tracker, '/');
        $pos_point=strrpos($tracker, '.');
        $tmp_tracker= substr($tracker, 0, $slash_point)."/scrape".substr($tracker, $pos_point)."?info_hash=".urlencode($infohash);
*/
        $tmp_tracker=str_replace("announce", "scrape", $tracker)."?info_hash=".urlencode($infohash);
        $tracker_db = str_replace("announce","scrape",$tracker);
        $use_std_tracker = false;
        $parse_array = array();
        $i=0;
        global $extern_check;
       if ($extern_check) {
        $fp = @fopen($tmp_tracker, "rb");
        if ($fp){
                socket_set_timeout($fp, 10);
                $page=fread($fp, 1000000);

                $status = socket_get_status($fp);
                if ($status['timed_out']) {
                    die(_btsocktout);
                }


                fclose($fp);
                $max=strlen($page);
                $parse_array = ergo($page, $parse_array, $i, $max);

                //Check data
                if ( !is_array($parse_array["0"]["files"][ "$infohash" ])  )
                        $use_std_tracker = true;
                else{
                        //check seeder
                        if ($parse_array["0"]["files"][ "$infohash" ]["complete"]<=0) die("Il tracker esterno ha risposto confermando la presenza del file ma con nessuna fonte completa. Ti ricordiamo che il file deve essere gi� presente sull'altro tracker con almeno un seeder per essere inserito sul nostro sito.");

                        $sql = "INSERT INTO torrent_torrents (search_text, filename, src_url, owner, visible, info_hash, name, size, numfiles, `type`, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip, seeders, leechers, tot_peer, times_completed, tracker, tracker_update $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $source_url, $owner, "yes", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, 0 + $_POST["type"], $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip', ".sqlesc($parse_array["0"]["files"][ "$infohash" ]["complete"]).", ".sqlesc($parse_array["0"]["files"][ "$infohash" ]["incomplete"]).", ".sqlesc($parse_array["0"]["files"][ "$infohash" ]["complete"]+$parse_array["0"]["files"][ "$infohash" ]["incomplete"]).",".sqlesc($parse_array["0"]["files"][ "$infohash" ]["downloaded"]).", '$tracker_db', SYSDATE() $sql_insert_value)";

                }
        }else{
                $use_std_tracker = true;
        }

        //Strandard Tracker
        if ($use_std_tracker){
                $add_tracker = "&peer_id=%00%00%00%00%00Azureus9%09%40d%BE%3D%C1%8B&port=666&uploaded=0&downloaded=0&left=1&num_peers=10000";
                $tracker.="?info_hash=".urlencode($infohash).$add_tracker;
                $fp = @fopen($tracker, "rb");
                if (!$fp)
                        die(_bttrackernotresponding." --".$ann."--");

                socket_set_timeout($fp, 10);
                $page=fread($fp, 1000000);

                $status = socket_get_status($fp);
                if ($status['timed_out']) {
                    die(_btsocktout);
                }

                fclose($fp);

                $peers = substr_count($page, "peer id");

                if ($peers<=0){
                        $max=strlen($page);
                        $parse_array = ergo($page, $parse_array, $i, $max);

                        if (!is_array($parse_array["0"]["peers"])){
                                die(_bttrackerdata);
                        }
                }

                $sql = "INSERT INTO torrent_torrents (search_text, filename, src_url, owner, visible, info_hash, name, size, numfiles, type, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip, leechers, tot_peer, tracker, tracker_update $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $source_url, $owner, "yes", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, 0 + $_POST["type"], $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip', '$peers', '$peers', '$tracker_db', SYSDATE() $sql_insert_value)";
        }
        } else {
                $sql = "INSERT INTO torrent_torrents (search_text, filename, src_url, owner, visible, info_hash, name, size, numfiles, type, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip, leechers, tot_peer, tracker, tracker_update $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $source_url, $owner, "yes", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, 0 + $_POST["type"], $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip', '0', '0', '$tracker_db', SYSDATE() $sql_insert_value)";
        }
}else{
        $sql = "INSERT INTO torrent_torrents (search_text, filename, src_url, owner, visible, info_hash, name, size, numfiles, type, descr, ori_descr, category, save_as, added, last_action, evidence, ownertype, ip $sql_insert_field) VALUES (" .implode(", ", array_map("sqlesc", array(searchfield("$shortfname $dname $torrent"), $fname, $source_url, $owner, "no", $infohash, $torrent, $totallen, count($filelist), $type, parsedescr($descr), $descr, 0 + $_POST["type"], $dname))) .", NOW(), NOW(), '$evidence', '$ownertype', '$ip' $sql_insert_value)";
}
$db->sql_query("INSERT INTO torrent_trackers (url) VALUES ('".$tracker."');");
$ret = $db->sql_query($sql) or bterror($sql);
$id = $db->sql_nextid();

$db->sql_query("DELETE FROM torrent_files WHERE torrent = '$id'") or bterror("DELETE FROM torrent_files WHERE torrent = '$id'");
$i=0;
foreach ($filelist as $file) {
        $ins_camp = "";
        $ins_val = ""        ;
        if ($sha1=$parse_array_torrent["0"]["info"]["files"]["$i"]["sha1"]){
                $ins_camp .= ", magnet";
                $ins_val .= ", 'magnet:?xt=urn:sha1:".addslashes(Sha1toBase32($sha1))."&dn=".urlencode($file[0])."'";
        }
        if ($ed2k=$parse_array_torrent["0"]["info"]["files"]["$i"]["ed2k"]){
                $ins_camp .= ", ed2k";
                $ins_val .= ", 'ed2k://|file|".urlencode($file[0])."|".urlencode($file[1])."|".strtohex($ed2k)."|/'";
        }

        $sql = "INSERT INTO torrent_files (torrent, filename, size $ins_camp) VALUES ('$id', ".sqlesc($file[0]).", '".$file[1]."' $ins_val)";
//        echo $sql;
        $db->sql_query($sql) or bterror($sql);
        $i++;
}

//print_parse($parse_array_torrent);

move_uploaded_file($tmpname, "$torrent_dir/$id.torrent");


echo "<meta http-equiv=\"refresh\" content=\"3;url=modules.php?name=$name&file=details&id=$id&uploaded=1\">";
$btuploadcomplete = str_replace("**name**",$name,_btuploadcomplete);
$btuploadcomplete = str_replace("**id**",$id,$btuploadcomplete);
echo $btuploadcomplete;

global $notify;
if($notify==1){
        $sql = "INSERT INTO torrent_comments_notify (torrent, user, can_send) VALUES ('$id', ".$CURUSER["id"].", 1)";
        $db->sql_query($sql) or bterror($sql);
        echo  _btnotify;
}

CloseTable();
include("footer.php");
?>