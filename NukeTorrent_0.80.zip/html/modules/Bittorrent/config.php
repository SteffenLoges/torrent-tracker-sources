<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
//Database
$dbhost = "localhost";
$dbuname = "nuke";
$dbpass = "";
$dbname = "";
$prefix = "nuke";
$user_prefix = "nuke";
$dbtype = "MySQL";


$sql = "SELECT onlysearch, max_torrent_size, announce_interval, minvotes, time_tracker_update, timeout_repeat_tu, time_check, best_limit, down_limit, default_limit, torrent_global_privacy, down_reg, down_paid, max_num_file, max_share_size, min_size_seed, min_share_seed, extern_check, max_num_file_day_e, max_num_file_week_e, min_num_seed_e, min_size_seed_e, maxupload_day_num, maxupload_day_share, minupload_size_file, announce_urls, stealthmode, autoclean_interval, maximagesize, signup_timeout, max_dead_torrent_time, src_url FROM torrent_config LIMIT 1;";
list ($onlysearch, $max_torrent_size, $announce_interval, $minvotes, $time_tracker_update, $timeout_repeat_tu, $time_check, $best_limit, $down_limit, $default_limit, $torrent_global_privacy, $down_reg, $down_paid, $max_num_file, $max_share_size, $min_size_seed, $min_share_seed, $extern_check, $max_num_file_day_e, $max_num_file_week_e, $min_num_seed_e, $min_size_seed_e, $maxupload_day_num, $maxupload_day_share, $minupload_size_file, $announce_urls, $stealthmode, $autoclean_interval, $maximagesize, $signup_timeout, $max_dead_torrent_time, $src_url, $version) = $db->sql_fetchrow($db->sql_query($sql));

$announce_urls = (array) explode(";",$announce_urls);

foreach (Array("onlysearch","torrent_global_privacy","down_reg","down_paid","extern_check","stealthmode","stealthmode") as $v) {
        if ($$v == "true") {
                $$v = true;
        } else {
                $$v = false;
        }
}
global $name, $file, $nukeurl, $adminmail;
$bt= "modules/$name/download"; // bt =directory for your downloads and tracker
$torrent_dir = "modules/$name/torrent";        # must be writable for httpd user
$url_site = $nukeurl;
$email_site = $adminmail;
$pic_base_url = "modules/$name/pic/";

//OLD CONFIG IN CASE DB DOESN'T WORK GOOD
/*
$onlysearch = false; //true for only search

$max_torrent_size = 1000000;
$announce_interval = 1800; //This value is send to client bittorrent, but the client can ignore it! seconds
$minvotes = 1;

$time_tracker_update = 180; //Esternal tracker time update in minutes
$timeout_repeat_tu = 60; //Esternal tracker repeat update on error in minutes

//Time for check dead peer internal announce
$time_check = 1800; //seconds

//index
$best_limit = 10; //Only torrent whith good peer/seeder
$down_limit = 10; //Torrent whit no seeder
$default_limit  = 10; //Limit default new on index of bit torrent

$torrent_global_privacy = false; //If true any download start after privacy ok and set $down_reg=true;
$down_reg = true;  //Registration for download
$down_paid = false; //ONLY Paid user can download

//Trigger limit for seeder
$max_num_file = 0; //Number max of file 0=no max
$max_share_size = 0 * 1048576; //MB max to trigger 0=no max * 1048576
$min_size_seed = 0 * 1048576; //Size min of single file to seed 0=no min
$min_share_seed = 0 * 1048576; //Size min of all seed file 0=no min

//External tracker limit
$extern_check = true; //Active o disabled ALL external check
$max_num_file_day_e = 0; //Number max of torrent download day 0=no max
$max_num_file_week_e = 0; //Number max of torrent download week 0=no max
$min_num_seed_e = 0; //Num min of torrent client to seed for download torrent 0=no min
$min_size_seed_e = 500 * 1048576; //Size min of single torrent client to seed for download torrent 0=no min

$maxupload_day_num = 100; //Number of max upload a day
$maxupload_day_share = 10 * 1024 *1048576; //Max share size to upload a day
$minupload_size_file = 1 * 524288; //Min size of 1048576 = 1 MB

$announce_urls = array(); # the first one will be displayed on the pages
$announce_urls[] = "$url_site/modules/Bittorrent/announce.php";

$stealthmode = true; //any tracker is ok if true, else false only this tracker
$autoclean_interval = 600;


//Image config
$maximagesize = 30;//Kbyte

//No change it please START
$signup_timeout = 86400 * 3;
$max_dead_torrent_time = 6 * 3600;
//No change it please STOP
*/
?>