<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 1;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
global $name, $db, $torrent_global_privacy, $file;

include("header.php");
OpenTable();

if (!is_user($user)){
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}

if (!mkglobal("main:id"))
        die();

$id = 0 + $id;
if (!$id)
        die();

$res = $db->sql_query("SELECT name FROM  torrent_torrents WHERE id = '$id'") or bterror("SELECT name FROM  torrent_torrents WHERE id = '$id'");
$row = $db->sql_fetchrow($res);

$nome = $row["name"] ;


        //Filtro costruzione dal nome file lungo almeno 4 caratteri
        $materia=trim($main);
        $pos = strrpos($materia, '.');
        if (!$pos===false)
                $materia = substr($materia, 0, $pos);
        $search = array (
                                         "'[^a-zA-Z]'",                 // Remove not lecter
                                         "'([\r\n])[\s]+'"                 // Remove Blank space
        );
        $replace = array (
                                          " ",
                                          "\\1"
        );
        $materia = preg_replace ($search, $replace, $materia);
        $materia = explode(" ", $materia);

        $sql_filter = "";
        $mexfound = "";
        $numkeyword = 0;
        foreach($materia as $x){
                $x = trim($x);
                if(strlen($x)>=3){
                        $numkeyword++;
                        $statement = sqlesc($x);
                        $sql_filter.= " OR keyword LIKE ".$statement;
                }
                if($numkeyword>=50){
                        $sql_filter = "SELECT * FROM torrent_filter WHERE 1=0 ".$sql_filter;
                        $res = $db->sql_query($sql_filter);
                        if ($row = $db->sql_fetchrow($res)){
                                do{
                                        $mexfound.= "<li><b>".$row[keyword]."</b> ".$row[reason];
                                }while ($row = $db->sql_fetchrow($res));
                        }
                        $sql_filter = "";
                        $numkeyword = 0;
                }
        }
        $sql_filter = "SELECT * FROM torrent_filter WHERE 1=0 ".$sql_filter;
        $res = $db->sql_query($sql_filter) or bterror($sql_filter);
        if ($row = $db->sql_fetchrow($res)){
                do{
                        $mexfound .= "<li><b>".$row[keyword]."</b> ".$row[reason];
                }while ($row = $db->sql_fetchrow($res));
        }
        if($mexfound!=""){
                Echo _btcommentkeyfound;
                echo $mexfound;
                echo _btcommentkeyfound2;
                CloseTable();
                include("footer.php");
                die();
        }


$sql = "INSERT INTO torrent_comments (user, torrent, added, text, ori_text) VALUES ('" .$CURUSER["id"] . "', '$id', NOW(), " . sqlesc(parsedescr($main)) . ", " . sqlesc($main) . ")";
$db->sql_query($sql) or bterror($sql);


$newid = $db->sql_nextid();

$db->sql_query("UPDATE torrent_torrents SET comments = comments + 1 WHERE id = '$id'") or bterror("UPDATE torrent_torrents SET comments = comments + 1 WHERE id = '$id'");

//Send notify
$sql = "SELECT user_email FROM torrent_comments_notify A, nuke_users B WHERE A.torrent = '$id' AND A.can_send=1 AND NOT(A.user='".$CURUSER["id"]."') AND A.user=B.user_id;";
$res = $db->sql_query($sql) or bterror($sql);

while($row = $db->sql_fetchrow($res)){
        $corpo_email = str_replace("**nome**",$nome,_bttorrentmailbody);
        $corpo_email = str_replace("**name**",$name,$corpo_email);
        $corpo_email = str_replace("**url_site**",$url_site,$corpo_email);
        $corpo_email = str_replace("**id**",$id,$corpo_email);
        $corpo_email = str_replace("**newid**",$newid,$corpo_email);
        global $adminmail, $sitename;
        mail($row["user_email"], "Inserimento commento al TORRENT \"$nome\" su $sitename", $corpo_email, "From: $adminmail");

}
$sqlupdate = "UPDATE torrent_comments_notify SET can_send='0' WHERE torrent='$id' AND can_send='1';";
$db->sql_query($sqlupldate);


echo "<meta http-equiv=\"refresh\" content=\"3;url="."modules.php?name=$name&file=details&id=$id&viewcomm=$newid#comm$newid"."\">";
$btcommentinserted = _btcommentinserted;
$btcommentinserted = str_replace("**name**",$name,$btcommentinserted);
$btcommentinserted = str_replace("**id**",$id,$btcommentinserted);
$btcommentinserted = str_replace("**newid**",$newid,$btcommentinserted);
echo $btcommentinserted;

CloseTable();
include("footer.php");
?>