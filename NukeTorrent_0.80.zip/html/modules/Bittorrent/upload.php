<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/

$index = 0;
global $module_name, $name;

$module_name = $name;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
global $name, $torrent_global_privacy, $file;
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
include("header.php");
$photo= "<input type=\"file\" name=\"Photo\">";
OpenTable();

loggedinorreturn();

stdhead("Upload");

?>
<script>
/*
Submit Once form validation-
� Dynamic Drive (www.dynamicdrive.com)
For full source code, usage terms, and 100's more DHTML scripts, visit http://dynamicdrive.com
*/

function submitonce(theform){
//if IE 4+ or NS 6+
if (document.all||document.getElementById){
//screen thru every element in the form, and hunt down "submit" and "reset"
for (i=0;i<theform.length;i++){
var tempobj=theform.elements[i]
if(tempobj.type.toLowerCase()=="submit"||tempobj.type.toLowerCase()=="reset")
//disable em

tempobj.disabled=true
}
}
}



        function verify(f){
                var msg;
                var error="";
                var chidarefocus=null;

                if (f.filex.value==""){
                        error+="<?= _btfnotselected ?>";
                        if (chidarefocus==null) chidarefocus=f.filex;
                }else{
                }


                if (f.descr.value==""){
                        error+="<?= _btalertdesc ?>\n";
                        if (chidarefocus==null) chidarefocus=f.descr;
                }

                if (f.type.value==""){
                        error+="<?= _btalertcat ?>\n";
                        if (chidarefocus==null) chidarefocus=f.type;
                }

                //Photo check
                estensione = f.Photo.value.substr(f.Photo.value.length-4).toLowerCase();
                if( estensione != '' )
                        if( estensione != '.gif' && estensione != '.jpg' && estensione != '.png'){
                                error+="<?= _btphotoext ?>";
                                if (chidarefocus==null) chidarefocus=f.Photo;
                        }

                if (error!=""){
                        msg =        "<?= _btalertmsg?>.\n";
                        msg +=        "<?= _btalertmsg2?>.\n\n";
                        msg +=        error;
                        alert(msg);
                        if (chidarefocus!=null){
                                chidarefocus.focus()
                        }
                        return (false);
                }else{
                        if (!confirm("<?= _btconferma ?>.")) return (false);
                        submitonce(f);
                        return (true);
                }
        }

        function verify2(f){
                var msg;
                var error="";
                var chidarefocus=null;

                if ((dati2.ed2klist.length==0) && (dati2.magneticlist.length==0)){
                        error+="<?= _btalerturl ?>\n";
                        if (chidarefocus==null) chidarefocus=f.ed2klist;
                }else
                        if ( (dati2.ed2klist.length>0) && (dati2.magneticlist.length>0) && (dati2.ed2klist.length!=dati2.magneticlist.length)){
                                error+="<?= _btalerturlnum1?> "+dati2.ed2klist.length+" <?=_btalerturlnum2?> "+dati2.magneticlist.length+" . <?=_btalerturlnum3?>.\n";
                                if (chidarefocus==null) chidarefocus=f.ed2klist;
                        }
                if ( ( (dati2.ed2klist.length>1) || (dati2.magneticlist.length>1) ) && (f.namex.value.length<5) ){
                        error+="<?= _btalert5char?>\n";
                        if (chidarefocus==null) chidarefocus=f.namex;
                }

                if (f.descr.value==""){
                        error+="<?= _btalertdesc ?>\n";
                        if (chidarefocus==null) chidarefocus=f.descr;
                }

                if (f.type.value==""){
                        error+="<?= _btalertcat ?>\n";
                        if (chidarefocus==null) chidarefocus=f.type;
                }

                //Photo check
                estensione = f.Photo.value.substr(f.Photo.value.length-4).toLowerCase();
                if( estensione != '' )
                        if( estensione != '.gif' && estensione != '.jpg' && estensione != '.png'){
                                error+="<?= _btphotoext ?>";
                                if (chidarefocus==null) chidarefocus=f.Photo;
                        }

                if (error!=""){
                        msg =        "<?= _btalertmsg1?>.\n";
                        msg +=        "<?= _btalertmsg2?>.\n\n";
                        msg +=        error;
                        alert(msg);
                        if (chidarefocus!=null){
                                chidarefocus.focus()
                        }
                        return (false);
                }else{
                        if (!confirm("<?= _btconferma?>.")) return (false);

                        //PAtch anti primo scompare
                        for(i=dati2.ed2klist.length; i>0; i--)
                                dati2.ed2klist.options[i+1] = dati2.ed2klist.options[i];
                        if(dati2.ed2klist.length>2) dati2.ed2klist.options[0].value="";
                        for(i=dati2.magneticlist.length; i>0; i--)
                                dati2.magneticlist.options[i+1] = dati2.magneticlist.options[i];
                        if(dati2.magneticlist.length>2) dati2.magneticlist.options[0].value="";


                        for(i=0; i<dati2.ed2klist.length; i++)
                                dati2.ed2klist.options[i].selected=true;

                        for(i=0; i<dati2.magneticlist.length; i++)
                                dati2.magneticlist.options[i].selected=true;



                        submitonce(f);
                        return (true);
                }
        }


</script>

<? OpenTable2(); ?>
<hr>
<?
echo _btofficialurl;
foreach($announce_urls as $annunceurl)
        "<b>$announceurl</b><br>";
?>
<form enctype="multipart/form-data" action="<?= "modules.php?name=$name&file=takeupload" ?>" method="post" id="dati" name="formdati" onsubmit="javascript:return verify(this);">
<table border="0" cellspacing="5" cellpadding="5">
<p><?=_btseeded?>.</p>
<?
tr(_btupfile, "<input type=\"file\" name=\"filex\" size=\"60\">\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_bttorrentname, "<input type=\"text\" name=\"namex\" size=\"80\"><br />("._btfromtorrent. "<b>"._btdescname."</b>)\n", 1);
global $src_url;
if ($src_url == "force") {
        $compulsory = _btcompulsory;
}
tr(_btsrc_url, "<input type=\"text\" name=\"source_url\" value=\"http://\" size=\"80\"> $compulsory<br />\n",1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btdescription."<br>("._btnohtml.")", "<textarea name=\"descr\" rows=\"10\" cols=\"80\"></textarea>", 1);

$s = "<select name=\"type\"><option value=\"\">(_btchooseone)</option>\n";
$cats = genrelist();
foreach ($cats as $row)
        $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";
$s .= "</select>\n";
echo "<tr><td><hr></td><td></td></tr>";
tr(_bttype, $s, 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btverduplicate, "<input type=\"checkbox\" name=\"jump_check\" value=\"1\" checked> "._btduplicatinfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btupevidence, "<input type=\"checkbox\" name=\"evidence\" value=\"1\"> "._btupevidencinfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btowner, "<select name=\"ownertype\">\n<option value=\"0\">"._btowner1."</option><option value=\"1\">"._btowner2."</option><option value=\"2\">"._btowner3."</option></select> "._btownerinfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btupnotify, "<input type=\"checkbox\" name=\"notify\" value=\"1\" checked> "._btupnotifynfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btphoto."<br>max ".$maximagesize." Kbyte", "<input type=\"file\" name=\"Photo\">");
?>
</table>
<hr>
<input type="submit" value="<?=_btfsend?>">
</form>
<?
CloseTable2();
OpenTable2();
?>
<script>
        function added2k(){
                mex = "<?=_btinserte2k?>";
                do{
                        urled2k = window.prompt(mex, "");
                        mex = "";
                        if(urled2k!=null){
                                if(urled2k=="") mex = "<?=_bturlnotinsert?>";
                                if(urled2k.lenght>200) mex = "<?=_btmaxchar?>";
                                if(urled2k.indexOf('ed2k://|file|')!=0) mex="<?=_bted2kstart?> ed2k://|file|";
                        }
                }while(mex!="");
                if(urled2k!=null){
                        newurl = new Option(urled2k, urled2k, true, true);
                        dati2.ed2klist.options[dati2.ed2klist.length] = newurl;
                }
        }
        function addmagnetic(){
                mex = "<?=_btmagnetinsert?>";
                do{
                        urlmagnetic = window.prompt(mex, "");
                        mex = "";
                        if(urlmagnetic!=null){
                                if(urlmagnetic.lenght>200) mex = "<?=_btmagchar?>";
                                if(urlmagnetic.indexOf('magnet:?xt=urn:sha1:')!=0 && urlmagnetic.indexOf('magnet:?xt=urn:bitprint:')!=0) mex="<?=$bt_umagnetstart?> magnet:?xt=urn:sha1: <?=$bt_uor?> magnet:?xt=urn:bitprint:";
                                if(urlmagnetic=="") mex = "<?=_btnolinkinsert?>";
                        }
                }while(mex!="");
                if(urlmagnetic!=null){
                        newurl = new Option(urlmagnetic, urlmagnetic, true, true);
                        dati2.magneticlist.options[dati2.magneticlist.length] = newurl;
                }
        }
</script>
<hr>
<p><b><?=_btinsertlinktitle?></b> <?=_btinsertlinktext?>.</p>
<p><?=_btinserttext2?>.</p>
<form enctype="multipart/form-data" action="<?= "modules.php?name=$name&file=takeuploadurl" ?>" method="post" id="dati2" name="formdati2" onsubmit="javascript:return verify2(this);">
<table border="0" cellspacing="5" cellpadding="5">
<?
tr(_bted2kurl, "<p>
<select name='ed2klist[]' id='ed2klist' size='3' multiple>
</select></p><p>"._btsyntax.": <b>ed2k://|file|</b>"._btfilename."."._btfiletype."|"._btfilesize."|"._btidcode."|/<b>|sources,<font color=red>"._btipport."</font>|/</b><br><b>ed2k://|file|</b> "._btstatic."; <b>"._btfilename."."._btfiletype."</b> "._btfinalname."; <b>"._btfilesize."</b> "._btfinalsize."; <b>"._btidcode."</b> "._btfinalidcode."; <b>|sources,<font color=red>"._btipport."</font>|/ "._btfinalipport."</p><input type='button' value='"._btadded2k."' onClick='added2k();'>", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr("$bt_umagneturl", "<p>
<select name='magneticlist[]' id='magneticlist' size='3' multiple>
</select></p><p>"._btsyntax.": magnet:?xt=urn:sha1:<b>"._btidcode."</b>&dn=<b>"._btfilename."."._btfiletype."</b> "._btor." magnet:?xt=urn:bitprint:<b>"._btidcode."1</b>.<b>"._btidcode."2</b>&dn=<b>"._btfilename."."._btfiletype."</b></p><input type='button' value='"._btaddmagnet."' onClick='addmagnetic();'>", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_bttorrentname, "<input type=\"text\" name=\"namex\" size=\"80\"><br />\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btdescription."<br>("._btnohtml.")", "<textarea name=\"descr\" rows=\"10\" cols=\"80\"></textarea>", 1);
echo "<tr><td><hr></td><td></td></tr>";

$s = "<select name=\"type\">\n<option value=\"\">("._btchooseone.")</option>\n";
$cats = genrelist();
foreach ($cats as $row)
        $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";
$s .= "</select>\n";

tr(_bttype, $s, 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btupevidence, "<input type=\"checkbox\" name=\"evidence\" value=\"1\"> "._btupevidencinfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btowner, "<select name=\"ownertype\">\n<option value=\"0\">"._btowner1."</option><option value=\"1\">"._btowner2."</option><option value=\"2\">"._btowner3."</option></select> "._btownerinfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btupnotify, "<input type=\"checkbox\" name=\"notify\" value=\"1\" checked> "._btupnotifynfo."\n", 1);
echo "<tr><td><hr></td><td></td></tr>";
tr(_btphoto."<br>max ".$maximagesize." Kbyte", $photo);
?>
</table>
<hr>
<input type="submit" value="<?=_btfsend?>">
</form>
<?CloseTable2();?>

<?
echo _bthelpupload;

CloseTable();
include("footer.php");
?>