<?/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 1;

if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");

$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");

global $module_name, $name, $db;

if (!is_user($user)) {
        $pagetitle = "- "._ACCESSDENIED."";
        include("header.php");
        title("$sitename: "._ACCESSDENIED."");
        OpenTable();
        echo "<center><b>"._RESTRICTEDAREA."</b><br><br>"
        .""._MODULEUSERS."";
        $result2 = $db->sql_query("SELECT mod_group FROM ".$prefix."_modules WHERE title='$name'");
        $row2 = $db->sql_fetchrow($result2);
        if ($row2[mod_group] != 0) {
                $result3 = $db->sql_query("SELECT name FROM ".$prefix."_groups WHERE id='$row2[mod_group]'");
                $row3 = $db->sql_fetchrow($result3);
                echo ""._ADDITIONALYGRP.": <b>$row3[name]</b><br><br>";
        }
        echo ""._GOBACK."";
        CloseTable();
        include("footer.php");
        die();
}
include("header.php");
OpenTable();
stdhead();
global $privacy,$adminmail;
if ($privacy){
        loggedinorreturn();
        stdhead($CURUSER["username"] . "'s torrents");
        /*
        //Clear duplicate
        $sql_clear = "SELECT B.from, B.to, count(  *  )  AS TOT, MIN( B.status  ) as min FROM  torrent_global_privacy B WHERE B.from > 0 AND B.to  >0 AND B.status  >= 0 GROUP  BY B.from,  B.to ORDER  BY TOT DESC";
        $res_clear=mysql_query($sql_clear, $dbi);
        $row_clear = mysql_fetch_array($res_clear);
        while ($row_clear && $row_clear["TOT"]>1) {
        $sql_delete = "DELETE FROM torrent_global_privacy WHERE from = '".$row_clear["from"]."' AND to= '".$row_clear["to"]."' AND status>'".$row_clear["min"]."'";
        mysql_query($sql_delete, $dbi) or die(mysql_error(). " SQL = $sql_delete");
        $row_clear = mysql_fetch_array($res_clear);
        }
        */
        if ($privacy=="all"){
                $sql_email = "SELECT A.user_email as email, B.from FROM ".$user_prefix."_users A, torrent_global_privacy B WHERE B.from > 0 AND B.to= '".$CURUSER["id"]."' AND B.status=1 AND B.from = A.user_id";
                $sql_privacy = "UPDATE torrent_global_privacy SET status = 0 WHERE from > 0 AND to= '".$CURUSER["id"]."' AND status=1";
                echo _btallauthorized;
        }else{
                $sql_email = "SELECT A.user_email as email, B.from FROM ".$user_prefix."_users A, torrent_global_privacy B WHERE B.from ='$privacy' AND B.to= '".$CURUSER["id"]."' AND B.status=1 AND B.from = A.user_id";
                $sql_privacy = "UPDATE torrent_global_privacy SET status = 0 WHERE from = '$privacy' AND to= '".$CURUSER["id"]."' AND status=1";
                echo _btauthorized;
        }
        $res = $db->sql_query($sql_email) or bterror($sql_email);
        while ($row = $db->sql_fetchrow($res)) {
                $body = _bthasauthorized;
                $sql_file = "SELECT A.file,  B.name FROM torrent_file_privacy A, torrent_torrents B WHERE A.from='".$row["from"]."' AND A.to='".$CURUSER["id"]."' AND A.file=B.id";
                $res_file = $db->sql_query($sql_file) or bterror($sql_file);
                while ($row_file = $db->sql_fetchrow($res_file)) {
                        $body.= $row_file["name"]. ":\n$url_site/modules.php?name=$name&file=details&id=".$row_file["file"]."\n";
                }

                $body.= _btnowcandownload;
                mail($row["email"], _btauthmailsubj, $body, "From: $adminmail");
                $sql_delete = "DELETE FROM torrent_file_privacy WHERE to='".$CURUSER["id"]."' AND  from='".$row["from"]."'";
                $db->sql_query($sql_delete) or bterror($sql_delete);
        }
        $db->sql_query($sql_privacy) or bterror($sql_privacy);
}
$sql_privacy = "SELECT A.username, A.user_id FROM ".$user_prefix."_users A, torrent_global_privacy B WHERE B.from > 0 AND B.to= '".$CURUSER["id"]."' AND B.status=1 AND B.from = A.user_id";
$res=$db->sql_query($sql_privacy) or bterror($sql_privacy);
OpenTable();
if($row = $db->sql_fetchrow($res)) {
        echo _btauthorizationrequested;
        echo "<table><tr><th>"._btuser."</th><th>Operazione</th></tr>";
        do{
                echo "<tr><td><a href='modules.php?name=Your_Account&op=userinfo&username=".$row["username"]."'>".$row["username"]."</a></td><td><a href='modules.php?name=$name&file=mytorrents&privacy=".$row["user_id"]."'>AUTORIZZA</a></td></tr>";
        }while ($row = $db->sql_fetchrow($res));
        echo "</table>";
        echo "<a href='modules.php?name=$name&file=mytorrents&privacy=all'>Autorizza tutti gli utenti presenti a scaricare";
}else{
        echo "In questo momento non sono presenti user che hanno richiesto di scaricare file(s)";
}
CloseTable();

$where = "WHERE owner = '" . $CURUSER["id"] . "' AND banned != 'yes'";
$res = $db->sql_query("SELECT COUNT(*) FROM torrent_torrents $where") or bterror("SELECT COUNT(*) FROM torrent_torrents $where");
$row = $db->sql_fetchrow($res);
$count = $row[0];

if (!$count) {
?>
<h1><?=_btnotorrents?></h1>
<p><?_btnotorrentuploaded?></p>
<?
}
else {
        list($pagertop, $pagerbottom, $limit) = pager(20, $count, "mytorrents.php?");

        $sql = "SELECT A.*, IF(A.numratings < $minvotes, NULL, ROUND(A.ratingsum / A.numratings, 1)) AS rating, B.name AS cat_name, B.image AS cat_pic FROM torrent_torrents A LEFT JOIN torrent_categories B ON A.category = B.id $where ORDER BY id DESC $limit";
        $res = $db->sql_query($sql) or bterror($sql);

        print($pagertop);

        torrenttable($res, "mytorrents");

        print($pagerbottom);
}

CloseTable();
include("footer.php");
?>