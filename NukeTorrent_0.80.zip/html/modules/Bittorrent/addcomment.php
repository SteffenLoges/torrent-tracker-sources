<?
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;


if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
require_once("mainfile.php");
global $db, $name;
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
require_once("modules/$name/include/bittorrent.php");
require_once("modules/$name/config.php");
global $torrent_global_privacy, $file;
include("header.php");
OpenTable();


$id = intval($id);
if($id<=0) die(_btiderror);

loggedinorreturn();

$sql = "SELECT name FROM torrent_torrents WHERE id = '$id' LIMIT 1";

if(! $res = $db->sql_query($sql) ) bterror($sql);
if(! $torrow = $db->sql_fetchrow($res) ) die(_btnotfound);

stdhead(_btaddcomment." \"" . htmlspecialchars($torrow["name"]) . "\"");

?>
<h2><?=_btaddcomment." ".htmlspecialchars($torrow["name"])?></h2>
<p>

<form method="post" action="<?= "modules.php?name=$name&file=takecomment" ?>">
<input type="hidden" name="id" value="<?= $id ?>">
<textarea name="main" rows="10" cols="80">
</textarea>
</p>
<p><input type="submit" value="<?=_btsend?>"></p>
</form>

<?

$sql = "SELECT A.id, A.text, A.added, B.username FROM torrent_comments A LEFT JOIN ".$prefix."_users B ON A.user = B.user_id WHERE torrent = '$id' ORDER BY A.id DESC LIMIT 5";
if(! $res = $db->sql_query($sql) ) bterror($sql);

$allrows = array();
while ( $row = $db->sql_fetchrow($res) )
        $allrows[] = $row;

if (count($allrows)) {
        print("<hr />\n");
        print("<h2>".$bt_acrecentcomm."</h2>\n");
        commenttable($allrows);
}

stdfoot();

require_once("include/footer.inc.php");

CloseTable();
include("footer.php");

?>