<?php
/*
--------------------------------------------------------------------------------
------------------------BIT TORRENT PHP NUKE------------------------------------
-                                                                              -
-  Created by Graziano Chiaiese - www.raulken.it                               -
-                             www.bitnile.com                                  -
-                         www.natasha.it                                       -
-                     www.hyarbor.it                                           -
-                                                                              -
-  Modded and Fixed by Antonio Anzivino - www.p2pmania.it                      -
-                                     www.ffitalia.net                         -                                                            -
-                                 www.sourceforge.net/projects/flashnuke       -
-                                                                              -
-                                                                              -
-     This software is distributed under GNU/GPL license.                      -
-                                                                              -
-     The authors of this software cannot be held responsible for any          -
-     illegal use you can make.                                                -
-                                                                              -
-     The authors want to remember you that spreading illegal                  -
-     files trough Filesharing Networks is illegal.                            -
-                                                                              -
-     This software has been created in order to help the                      -
-     diffusion of the Bit Torrent protocol and its clients.                   -
-                                                                              -
-     The authors DO NOT ALLOW YOU to use this software                        -
-     for piracy and child pornography.                                        -
-                                                                              -
-     "FILESHARE INSIDE" is our motto.                                         -
-                                                                              -
-     Tested under PHP Nuke 7.5. Before installing,                            -
-     please read the documentation in the README folder                       -
-                                                                              -
-     Need help? Try asking on www.bitnile.com (ENG) and                       -
-                              www.p2pmania.it (ITA) forums                    -
-                                                                              -
-                                                                              -
-----------------Copyright 2004 Hyarbor S.r.l. & P2PMania.it--------------------
--------------------------All rights reserved-----------------------------------
--------------------------------------------------------------------------------
*/
$index = 0;
if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
if(!is_admin($admin)) die("ADMIN Only");

require_once("mainfile.php");
require_once("header.php");
echo "Avvio Patch Bit Torrent<BR>";
$db->sql_query("CREATE TABLE torrent_trackers (id TINYINT(5) UNSIGNED NOT NULL AUTO_INCREMENT, url VARCHAR( 120 ) NOT NULL , update DATETIME NOT NULL , PRIMARY KEY (id) , INDEX (update) , UNIQUE (url));");
$db->sql_query("ALTER TABLE torrent_torrents ADD src_url VARCHAR(250) DEFAULT NULL AFTER save_as ;");
$db->sql_query("CREATE TABLE torrent_config (onlysearch enum('true','false') NOT NULL default 'true', max_torrent_size int(11) unsigned NOT NULL default '0',  announce_interval int(10) unsigned NOT NULL default '0',  minvotes smallint(5) unsigned NOT NULL default '0',  time_tracker_update int(10) unsigned NOT NULL default '0',  timeout_repeat_tu int(10) unsigned NOT NULL default '0',  time_check int(10) unsigned NOT NULL default '0',  best_limit smallint(5) unsigned NOT NULL default '0',  down_limit smallint(5) unsigned NOT NULL default '0',  default_limit smallint(5) unsigned NOT NULL default '0',  torrent_global_privacy enum('true','false') NOT NULL default 'true',  down_reg enum('true','false') NOT NULL default 'true',  down_paid enum('true','false') NOT NULL default 'true',  max_num_file smallint(5) unsigned NOT NULL default '0',  max_share_size bigint(8) unsigned NOT NULL default '0',  min_size_seed mediumint(8) unsigned NOT NULL default '0',  min_share_seed bigint(8) unsigned NOT NULL default '0',  extern_check enum('true','false') NOT NULL default 'true',  max_num_file_day_e smallint(5) unsigned NOT NULL default '0',  max_num_file_week_e smallint(5) unsigned NOT NULL default '0',  min_num_seed_e smallint(5) unsigned NOT NULL default '0',  min_size_seed_e bigint(8) unsigned NOT NULL default '0',  maxupload_day_num smallint(5) unsigned NOT NULL default '0',  maxupload_day_share bigint(8) unsigned NOT NULL default '0',  minupload_size_file int(10) unsigned NOT NULL default '0',  announce_urls text NOT NULL,  stealthmode enum('true','false') NOT NULL default 'true',  autoclean_interval int(10) unsigned NOT NULL default '0',  maximagesize int(10) unsigned NOT NULL default '0',  signup_timeout int(10) unsigned NOT NULL default '0',  max_dead_torrent_time int(10) unsigned NOT NULL default '0',  src_url enum('disabled','torrent','url','force') NOT NULL default 'disabled') TYPE=MyISAM;");
$db->sql_query("INSERT INTO torrent_config VALUES ('true', 1000000, 1800, 1, 180, 60, 1800, 10, 10, 10, 'true', 'true', 'false', 0, 0, 0, 0, 'false', 0, 0, 0, 524268000, 100, 10737008640, 524288, '', 'true', 600, 30, 259200, 21600, 'disabled');");

/*$res = $db->sql_query("SELECT tracker FROM torrent_torrents WHERE tracker<>'';");
while ($trackerrow = $db->sql_fetchrow($res)) {
        $trk = explode("?info_hash",$trackerrow[0]);
        $sqlupdate = "UPDATE torrent_torrents SET tracker = '".$trk[0]."' WHERE tracker = '".$trackerrow[0]."';";
        $db->sql_query($sqlupdate) or die("ERRORE SQL: $sqlupdate");
        echo "Tracker $trk[0] aggiornato. <BR>";
} */
$res = $db->sql_query("SELECT tracker FROM torrent_torrents GROUP BY tracker WHERE tracker<>'';");
while ($trackerrow = $db->sql_fetchrow($res)) {
        $db->sql_query("INSERT INTO torrent_trackers (url) VALUES ('".$trackerrow[0]."');");
}
$db->sql_query("REPAIR TABLE torrent_categories , torrent_check_peers , torrent_comments , torrent_comments_notify , torrent_config , torrent_download , torrent_file_privacy , torrent_files , torrent_filter , torrent_global_privacy , torrent_hits , torrent_legalizeit , torrent_peers , torrent_ratings , torrent_seeder_notify , torrent_torrents;");
echo "<BR>";
echo "Fine Patch Bit Torrent";
require_once("footer.php");
?>
