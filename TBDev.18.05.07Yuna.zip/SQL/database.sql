# SQL Manager 2007 for MySQL 4.0.5.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : x264


#
# Structure for the `addedrequests` table :
#

DROP TABLE IF EXISTS `addedrequests`;

CREATE TABLE `addedrequests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `requestid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM;

#
# Structure for the `avps` table :
#

DROP TABLE IF EXISTS `avps`;

CREATE TABLE `avps` (
  `arg` varchar(20) NOT NULL default '',
  `value_s` text NOT NULL,
  `value_i` int(11) NOT NULL default '0',
  `value_u` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arg`)
) ENGINE=MyISAM;

#
# Structure for the `bans` table :
#

DROP TABLE IF EXISTS `bans`;

CREATE TABLE `bans` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `addedby` int(10) unsigned NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `first` int(11) default NULL,
  `last` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `first_last` (`first`,`last`)
) ENGINE=MyISAM;

#
# Structure for the `blocks` table :
#

DROP TABLE IF EXISTS `blocks`;

CREATE TABLE `blocks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `blockid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`blockid`)
) ENGINE=MyISAM;

#
# Structure for the `bonus` table :
#

DROP TABLE IF EXISTS `bonus`;

CREATE TABLE `bonus` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `points` decimal(5,2) NOT NULL default '0.00',
  `description` text NOT NULL,
  `type` varchar(10) NOT NULL default 'traffic',
  `quanity` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `bookmarks` table :
#

DROP TABLE IF EXISTS `bookmarks`;

CREATE TABLE `bookmarks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `torrentid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `captcha` table :
#

DROP TABLE IF EXISTS `captcha`;

CREATE TABLE `captcha` (
  `imagehash` varchar(32) NOT NULL default '',
  `imagestring` varchar(8) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  KEY `imagehash` (`imagehash`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

#
# Structure for the `categories` table :
#

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sort` int(10) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `checkcomm` table :
#

DROP TABLE IF EXISTS `checkcomm`;

CREATE TABLE `checkcomm` (
  `id` int(11) NOT NULL auto_increment,
  `checkid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `offer` tinyint(4) NOT NULL default '0',
  `torrent` tinyint(4) NOT NULL default '0',
  `req` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `comments` table :
#

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `torrent` int(10) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `ori_text` text NOT NULL,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  `request` varchar(11) NOT NULL default '0',
  `offer` varchar(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `user` (`user`),
  KEY `torrent` (`torrent`)
) ENGINE=MyISAM;

#
# Structure for the `countries` table :
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `flagpic` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `faq` table :
#

DROP TABLE IF EXISTS `faq`;

CREATE TABLE `faq` (
  `id` int(10) NOT NULL auto_increment,
  `type` set('categ','item') NOT NULL default 'item',
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `flag` tinyint(1) NOT NULL default '1',
  `categ` int(10) NOT NULL default '0',
  `order` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `files` table :
#

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `size` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `torrent` (`torrent`)
) ENGINE=MyISAM;

#
# Structure for the `friends` table :
#

DROP TABLE IF EXISTS `friends`;

CREATE TABLE `friends` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `friendid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`friendid`)
) ENGINE=MyISAM;

#
# Structure for the `indexreleases` table :
#

DROP TABLE IF EXISTS `indexreleases`;

CREATE TABLE `indexreleases` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrentid` int(10) NOT NULL default '0',
  `name` text NOT NULL,
  `cat` int(10) NOT NULL default '0',
  `poster` text NOT NULL,
  `genre` text NOT NULL,
  `director` text NOT NULL,
  `actors` text NOT NULL,
  `descr` text NOT NULL,
  `time` text NOT NULL,
  `imdb` text NOT NULL,
  `added` datetime default '0000-00-00 00:00:00',
  `quality` int(5) NOT NULL default '0',
  `video_codec` int(5) NOT NULL default '0',
  `video_size` text NOT NULL,
  `video_kbps` int(5) NOT NULL default '0',
  `audio_lang` int(5) NOT NULL default '0',
  `audio_trans` int(5) NOT NULL default '0',
  `audio_codec` int(5) NOT NULL default '0',
  `audio_kbps` int(5) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `invites` table :
#

DROP TABLE IF EXISTS `invites`;

CREATE TABLE `invites` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `inviter` int(10) unsigned NOT NULL default '0',
  `inviteid` int(10) NOT NULL default '0',
  `invite` varchar(32) NOT NULL default '',
  `time_invited` datetime NOT NULL default '0000-00-00 00:00:00',
  `confirmed` char(3) NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `inviter` (`id`)
) ENGINE=MyISAM;

#
# Structure for the `messages` table :
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sender` int(10) unsigned NOT NULL default '0',
  `receiver` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `subject` varchar(255) NOT NULL default '��� ����',
  `msg` text,
  `unread` enum('yes','no') NOT NULL default 'yes',
  `poster` int(10) unsigned NOT NULL default '0',
  `location` tinyint(1) NOT NULL default '1',
  `saved` enum('no','yes') NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `receiver` (`receiver`),
  KEY `sender` (`sender`),
  KEY `poster` (`poster`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_adminlog` table :
#

DROP TABLE IF EXISTS `mybb_adminlog`;

CREATE TABLE `mybb_adminlog` (
  `uid` int(10) unsigned NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  `scriptname` varchar(50) NOT NULL default '',
  `action` varchar(50) NOT NULL default '',
  `querystring` varchar(150) NOT NULL default '',
  `ipaddress` varchar(50) NOT NULL default '',
  KEY `scriptname` (`scriptname`,`action`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_adminoptions` table :
#

DROP TABLE IF EXISTS `mybb_adminoptions`;

CREATE TABLE `mybb_adminoptions` (
  `uid` int(10) NOT NULL default '0',
  `cpstyle` varchar(50) NOT NULL default '',
  `notes` text NOT NULL,
  `permsset` int(1) NOT NULL default '0',
  `caneditsettings` char(3) NOT NULL default '',
  `caneditann` char(3) NOT NULL default '',
  `caneditforums` char(3) NOT NULL default '',
  `canmodposts` char(3) NOT NULL default '',
  `caneditsmilies` char(3) NOT NULL default '',
  `caneditpicons` char(3) NOT NULL default '',
  `caneditthemes` char(3) NOT NULL default '',
  `canedittemps` char(3) NOT NULL default '',
  `caneditusers` char(3) NOT NULL default '',
  `caneditpfields` char(3) NOT NULL default '',
  `caneditugroups` char(3) NOT NULL default '',
  `caneditaperms` char(3) NOT NULL default '',
  `caneditutitles` char(3) NOT NULL default '',
  `caneditattach` char(3) NOT NULL default '',
  `canedithelp` char(3) NOT NULL default '',
  `caneditlangs` char(3) NOT NULL default '',
  `canrunmaint` char(3) NOT NULL default '',
  `canrundbtools` char(3) NOT NULL default '',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_adminsessions` table :
#

DROP TABLE IF EXISTS `mybb_adminsessions`;

CREATE TABLE `mybb_adminsessions` (
  `sid` varchar(32) NOT NULL default '',
  `uid` int(10) unsigned NOT NULL default '0',
  `loginkey` varchar(50) NOT NULL default '',
  `ip` varchar(40) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  `lastactive` bigint(30) NOT NULL default '0'
) ENGINE=MyISAM;

#
# Structure for the `mybb_announcements` table :
#

DROP TABLE IF EXISTS `mybb_announcements`;

CREATE TABLE `mybb_announcements` (
  `aid` int(10) unsigned NOT NULL auto_increment,
  `fid` int(10) NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `subject` varchar(120) NOT NULL default '',
  `message` text NOT NULL,
  `startdate` bigint(30) NOT NULL default '0',
  `enddate` bigint(30) NOT NULL default '0',
  `allowhtml` char(3) NOT NULL default '',
  `allowmycode` char(3) NOT NULL default '',
  `allowsmilies` char(3) NOT NULL default '',
  PRIMARY KEY  (`aid`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_attachments` table :
#

DROP TABLE IF EXISTS `mybb_attachments`;

CREATE TABLE `mybb_attachments` (
  `aid` int(10) unsigned NOT NULL auto_increment,
  `pid` int(10) NOT NULL default '0',
  `posthash` varchar(50) NOT NULL default '',
  `uid` int(10) unsigned NOT NULL default '0',
  `filename` varchar(120) NOT NULL default '',
  `filetype` varchar(120) NOT NULL default '',
  `filesize` int(10) NOT NULL default '0',
  `attachname` varchar(120) NOT NULL default '',
  `downloads` int(10) unsigned NOT NULL default '0',
  `visible` int(1) NOT NULL default '0',
  `thumbnail` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`aid`),
  KEY `posthash` (`posthash`),
  KEY `pid` (`pid`,`visible`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_attachtypes` table :
#

DROP TABLE IF EXISTS `mybb_attachtypes`;

CREATE TABLE `mybb_attachtypes` (
  `atid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  `mimetype` varchar(120) NOT NULL default '',
  `extension` varchar(10) NOT NULL default '',
  `maxsize` int(15) NOT NULL default '0',
  `icon` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`atid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_awaitingactivation` table :
#

DROP TABLE IF EXISTS `mybb_awaitingactivation`;

CREATE TABLE `mybb_awaitingactivation` (
  `aid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  `code` varchar(100) NOT NULL default '',
  `type` char(1) NOT NULL default '',
  `oldgroup` bigint(30) NOT NULL default '0',
  `misc` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`aid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_badwords` table :
#

DROP TABLE IF EXISTS `mybb_badwords`;

CREATE TABLE `mybb_badwords` (
  `bid` int(10) unsigned NOT NULL auto_increment,
  `badword` varchar(100) NOT NULL default '',
  `replacement` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_banned` table :
#

DROP TABLE IF EXISTS `mybb_banned`;

CREATE TABLE `mybb_banned` (
  `uid` int(10) unsigned NOT NULL default '0',
  `gid` int(10) unsigned NOT NULL default '0',
  `oldgroup` int(10) unsigned NOT NULL default '0',
  `oldadditionalgroups` text NOT NULL,
  `olddisplaygroup` int(11) NOT NULL default '0',
  `admin` int(10) unsigned NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  `bantime` varchar(50) NOT NULL default '',
  `lifted` bigint(30) NOT NULL default '0',
  `reason` varchar(255) NOT NULL default '',
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_captcha` table :
#

DROP TABLE IF EXISTS `mybb_captcha`;

CREATE TABLE `mybb_captcha` (
  `imagehash` varchar(32) NOT NULL default '',
  `imagestring` varchar(8) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  KEY `imagehash` (`imagehash`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_datacache` table :
#

DROP TABLE IF EXISTS `mybb_datacache`;

CREATE TABLE `mybb_datacache` (
  `title` varchar(50) NOT NULL default '',
  `cache` mediumtext NOT NULL,
  PRIMARY KEY  (`title`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_events` table :
#

DROP TABLE IF EXISTS `mybb_events`;

CREATE TABLE `mybb_events` (
  `eid` int(10) unsigned NOT NULL auto_increment,
  `subject` varchar(120) NOT NULL default '',
  `author` int(10) unsigned NOT NULL default '0',
  `date` varchar(50) NOT NULL default '',
  `description` text NOT NULL,
  `private` char(3) NOT NULL default '',
  PRIMARY KEY  (`eid`),
  KEY `private` (`private`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_favorites` table :
#

DROP TABLE IF EXISTS `mybb_favorites`;

CREATE TABLE `mybb_favorites` (
  `fid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL default '0',
  `tid` int(10) unsigned NOT NULL default '0',
  `type` char(1) NOT NULL default '',
  PRIMARY KEY  (`fid`),
  KEY `uid` (`uid`),
  KEY `tid` (`tid`,`type`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_forumpermissions` table :
#

DROP TABLE IF EXISTS `mybb_forumpermissions`;

CREATE TABLE `mybb_forumpermissions` (
  `pid` int(10) unsigned NOT NULL auto_increment,
  `fid` int(10) unsigned NOT NULL default '0',
  `gid` int(10) unsigned NOT NULL default '0',
  `canview` char(3) NOT NULL default '',
  `canviewthreads` char(3) NOT NULL default '',
  `candlattachments` char(3) NOT NULL default '',
  `canpostthreads` char(3) NOT NULL default '',
  `canpostreplys` char(3) NOT NULL default '',
  `canpostattachments` char(3) NOT NULL default '',
  `canratethreads` char(3) NOT NULL default '',
  `caneditposts` char(3) NOT NULL default '',
  `candeleteposts` char(3) NOT NULL default '',
  `candeletethreads` char(3) NOT NULL default '',
  `caneditattachments` char(3) NOT NULL default '',
  `canpostpolls` char(3) NOT NULL default '',
  `canvotepolls` char(3) NOT NULL default '',
  `cansearch` char(3) NOT NULL default '',
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_forums` table :
#

DROP TABLE IF EXISTS `mybb_forums`;

CREATE TABLE `mybb_forums` (
  `fid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  `description` text NOT NULL,
  `linkto` varchar(180) NOT NULL default '',
  `type` char(1) NOT NULL default '',
  `pid` smallint(5) unsigned NOT NULL default '0',
  `parentlist` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL default '0',
  `active` char(3) NOT NULL default '',
  `open` char(3) NOT NULL default '',
  `threads` int(10) unsigned NOT NULL default '0',
  `posts` int(10) unsigned NOT NULL default '0',
  `lastpost` int(10) unsigned NOT NULL default '0',
  `lastposter` varchar(120) NOT NULL default '',
  `lastposteruid` int(10) unsigned NOT NULL default '0',
  `lastposttid` int(10) NOT NULL default '0',
  `lastpostsubject` varchar(120) NOT NULL default '',
  `allowhtml` char(3) NOT NULL default '',
  `allowmycode` char(3) NOT NULL default '',
  `allowsmilies` char(3) NOT NULL default '',
  `allowimgcode` char(3) NOT NULL default '',
  `allowpicons` char(3) NOT NULL default '',
  `allowtratings` char(3) NOT NULL default '',
  `status` int(4) NOT NULL default '1',
  `usepostcounts` char(3) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `showinjump` char(3) NOT NULL default '',
  `modposts` char(3) NOT NULL default '',
  `modthreads` char(3) NOT NULL default '',
  `modattachments` char(3) NOT NULL default '',
  `style` smallint(5) unsigned NOT NULL default '0',
  `overridestyle` char(3) NOT NULL default '',
  `rulestype` smallint(1) NOT NULL default '0',
  `rulestitle` varchar(200) NOT NULL default '',
  `rules` text NOT NULL,
  `unapprovedthreads` int(10) unsigned NOT NULL default '0',
  `unapprovedposts` int(10) unsigned NOT NULL default '0',
  `defaultdatecut` smallint(4) unsigned NOT NULL default '0',
  `defaultsortby` varchar(10) NOT NULL default '',
  `defaultsortorder` varchar(4) NOT NULL default '',
  PRIMARY KEY  (`fid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_forumsubscriptions` table :
#

DROP TABLE IF EXISTS `mybb_forumsubscriptions`;

CREATE TABLE `mybb_forumsubscriptions` (
  `fsid` int(10) unsigned NOT NULL auto_increment,
  `fid` smallint(5) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`fsid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_groupleaders` table :
#

DROP TABLE IF EXISTS `mybb_groupleaders`;

CREATE TABLE `mybb_groupleaders` (
  `lid` smallint(5) unsigned NOT NULL auto_increment,
  `gid` smallint(5) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `canmanagemembers` char(3) NOT NULL default '',
  `canmanagerequests` char(3) NOT NULL default '',
  PRIMARY KEY  (`lid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_helpdocs` table :
#

DROP TABLE IF EXISTS `mybb_helpdocs`;

CREATE TABLE `mybb_helpdocs` (
  `hid` smallint(5) unsigned NOT NULL auto_increment,
  `sid` smallint(5) unsigned NOT NULL default '0',
  `name` varchar(120) NOT NULL default '',
  `description` text NOT NULL,
  `document` text NOT NULL,
  `usetranslation` char(3) NOT NULL default '',
  `enabled` char(3) NOT NULL default '',
  `disporder` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`hid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_helpsections` table :
#

DROP TABLE IF EXISTS `mybb_helpsections`;

CREATE TABLE `mybb_helpsections` (
  `sid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  `description` text NOT NULL,
  `usetranslation` char(3) NOT NULL default '',
  `enabled` char(3) NOT NULL default '',
  `disporder` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_icons` table :
#

DROP TABLE IF EXISTS `mybb_icons`;

CREATE TABLE `mybb_icons` (
  `iid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  `path` varchar(220) NOT NULL default '',
  PRIMARY KEY  (`iid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_joinrequests` table :
#

DROP TABLE IF EXISTS `mybb_joinrequests`;

CREATE TABLE `mybb_joinrequests` (
  `rid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL default '0',
  `gid` smallint(5) unsigned NOT NULL default '0',
  `reason` varchar(250) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  PRIMARY KEY  (`rid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_mailqueue` table :
#

DROP TABLE IF EXISTS `mybb_mailqueue`;

CREATE TABLE `mybb_mailqueue` (
  `mid` int(10) unsigned NOT NULL auto_increment,
  `mailto` varchar(200) NOT NULL default '',
  `mailfrom` varchar(200) NOT NULL default '',
  `subject` varchar(200) NOT NULL default '',
  `message` text NOT NULL,
  `headers` text NOT NULL,
  PRIMARY KEY  (`mid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_moderatorlog` table :
#

DROP TABLE IF EXISTS `mybb_moderatorlog`;

CREATE TABLE `mybb_moderatorlog` (
  `uid` int(10) unsigned NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  `fid` smallint(5) unsigned NOT NULL default '0',
  `tid` int(10) unsigned NOT NULL default '0',
  `pid` int(10) unsigned NOT NULL default '0',
  `action` text NOT NULL,
  `data` text NOT NULL,
  `ipaddress` varchar(50) NOT NULL default '',
  KEY `tid` (`tid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_moderators` table :
#

DROP TABLE IF EXISTS `mybb_moderators`;

CREATE TABLE `mybb_moderators` (
  `mid` smallint(5) unsigned NOT NULL auto_increment,
  `fid` smallint(5) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `caneditposts` char(3) NOT NULL default '',
  `candeleteposts` char(3) NOT NULL default '',
  `canviewips` char(3) NOT NULL default '',
  `canopenclosethreads` char(3) NOT NULL default '',
  `canmanagethreads` char(3) NOT NULL default '',
  `canmovetononmodforum` char(3) NOT NULL default '',
  PRIMARY KEY  (`mid`),
  KEY `uid` (`uid`,`fid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_modtools` table :
#

DROP TABLE IF EXISTS `mybb_modtools`;

CREATE TABLE `mybb_modtools` (
  `tid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(200) NOT NULL default '',
  `description` text NOT NULL,
  `forums` text NOT NULL,
  `type` char(1) NOT NULL default '',
  `postoptions` text NOT NULL,
  `threadoptions` text NOT NULL,
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_mycode` table :
#

DROP TABLE IF EXISTS `mybb_mycode`;

CREATE TABLE `mybb_mycode` (
  `cid` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `description` text NOT NULL,
  `regex` text NOT NULL,
  `replacement` text NOT NULL,
  `active` char(3) NOT NULL default '',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_polls` table :
#

DROP TABLE IF EXISTS `mybb_polls`;

CREATE TABLE `mybb_polls` (
  `pid` int(10) unsigned NOT NULL auto_increment,
  `tid` int(10) unsigned NOT NULL default '0',
  `question` varchar(200) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  `options` text NOT NULL,
  `votes` text NOT NULL,
  `numoptions` smallint(5) unsigned NOT NULL default '0',
  `numvotes` smallint(5) unsigned NOT NULL default '0',
  `timeout` bigint(30) NOT NULL default '0',
  `closed` char(3) NOT NULL default '',
  `multiple` char(3) NOT NULL default '',
  `public` char(3) NOT NULL default '',
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_pollvotes` table :
#

DROP TABLE IF EXISTS `mybb_pollvotes`;

CREATE TABLE `mybb_pollvotes` (
  `vid` int(10) unsigned NOT NULL auto_increment,
  `pid` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `voteoption` smallint(5) unsigned NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  PRIMARY KEY  (`vid`),
  KEY `pid` (`pid`,`uid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_posts` table :
#

DROP TABLE IF EXISTS `mybb_posts`;

CREATE TABLE `mybb_posts` (
  `pid` int(10) unsigned NOT NULL auto_increment,
  `tid` int(10) unsigned NOT NULL default '0',
  `replyto` int(10) unsigned NOT NULL default '0',
  `fid` smallint(5) unsigned NOT NULL default '0',
  `subject` varchar(120) NOT NULL default '',
  `icon` smallint(5) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `username` varchar(80) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  `message` text NOT NULL,
  `ipaddress` varchar(30) NOT NULL default '',
  `includesig` char(3) NOT NULL default '',
  `smilieoff` char(3) NOT NULL default '',
  `edituid` int(10) unsigned NOT NULL default '0',
  `edittime` int(10) NOT NULL default '0',
  `visible` int(1) NOT NULL default '0',
  `posthash` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`pid`),
  KEY `tid` (`tid`,`uid`),
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`),
  FULLTEXT KEY `message` (`message`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_privatemessages` table :
#

DROP TABLE IF EXISTS `mybb_privatemessages`;

CREATE TABLE `mybb_privatemessages` (
  `pmid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL default '0',
  `toid` int(10) unsigned NOT NULL default '0',
  `fromid` int(10) unsigned NOT NULL default '0',
  `folder` smallint(5) unsigned NOT NULL default '1',
  `subject` varchar(120) NOT NULL default '',
  `icon` smallint(5) unsigned NOT NULL default '0',
  `message` text NOT NULL,
  `dateline` bigint(30) NOT NULL default '0',
  `status` int(1) NOT NULL default '0',
  `includesig` char(3) NOT NULL default '',
  `smilieoff` char(3) NOT NULL default '',
  `receipt` int(1) NOT NULL default '0',
  `readtime` bigint(30) NOT NULL default '0',
  PRIMARY KEY  (`pmid`),
  KEY `pmid` (`pmid`),
  KEY `uid` (`uid`,`folder`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_profilefields` table :
#

DROP TABLE IF EXISTS `mybb_profilefields`;

CREATE TABLE `mybb_profilefields` (
  `fid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `description` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL default '0',
  `type` text NOT NULL,
  `length` smallint(5) unsigned NOT NULL default '0',
  `maxlength` smallint(5) unsigned NOT NULL default '0',
  `required` char(3) NOT NULL default '',
  `editable` char(3) NOT NULL default '',
  `hidden` char(3) NOT NULL default '',
  PRIMARY KEY  (`fid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_reportedposts` table :
#

DROP TABLE IF EXISTS `mybb_reportedposts`;

CREATE TABLE `mybb_reportedposts` (
  `rid` int(10) unsigned NOT NULL auto_increment,
  `pid` int(10) unsigned NOT NULL default '0',
  `tid` int(10) unsigned NOT NULL default '0',
  `fid` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `reportstatus` int(1) NOT NULL default '0',
  `reason` varchar(250) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  PRIMARY KEY  (`rid`),
  KEY `fid` (`fid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_reputation` table :
#

DROP TABLE IF EXISTS `mybb_reputation`;

CREATE TABLE `mybb_reputation` (
  `rid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL default '0',
  `adduid` int(10) unsigned NOT NULL default '0',
  `reputation` bigint(30) NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  `comments` text NOT NULL,
  PRIMARY KEY  (`rid`),
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_searchlog` table :
#

DROP TABLE IF EXISTS `mybb_searchlog`;

CREATE TABLE `mybb_searchlog` (
  `sid` varchar(32) NOT NULL default '',
  `uid` int(10) unsigned NOT NULL default '0',
  `dateline` bigint(30) NOT NULL default '0',
  `ipaddress` varchar(120) NOT NULL default '',
  `threads` text NOT NULL,
  `posts` text NOT NULL,
  `searchtype` varchar(10) NOT NULL default '',
  `resulttype` varchar(10) NOT NULL default '',
  `querycache` text NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_sessions` table :
#

DROP TABLE IF EXISTS `mybb_sessions`;

CREATE TABLE `mybb_sessions` (
  `sid` varchar(32) NOT NULL default '',
  `uid` int(10) unsigned NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  `time` bigint(30) NOT NULL default '0',
  `location` varchar(150) NOT NULL default '',
  `useragent` varchar(100) NOT NULL default '',
  `anonymous` int(1) NOT NULL default '0',
  `nopermission` int(1) NOT NULL default '0',
  `location1` int(10) NOT NULL default '0',
  `location2` int(10) NOT NULL default '0',
  `loginattempts` tinyint(2) NOT NULL default '1',
  `failedlogin` bigint(30) NOT NULL default '0',
  PRIMARY KEY  (`sid`),
  KEY `location1` (`location1`),
  KEY `location2` (`location2`),
  KEY `time` (`time`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_settinggroups` table :
#

DROP TABLE IF EXISTS `mybb_settinggroups`;

CREATE TABLE `mybb_settinggroups` (
  `gid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `title` varchar(220) NOT NULL default '',
  `description` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL default '0',
  `isdefault` char(3) NOT NULL default '',
  PRIMARY KEY  (`gid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_settings` table :
#

DROP TABLE IF EXISTS `mybb_settings`;

CREATE TABLE `mybb_settings` (
  `sid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  `title` varchar(120) NOT NULL default '',
  `description` text NOT NULL,
  `optionscode` text NOT NULL,
  `value` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL default '0',
  `gid` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_smilies` table :
#

DROP TABLE IF EXISTS `mybb_smilies`;

CREATE TABLE `mybb_smilies` (
  `sid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL default '',
  `find` varchar(120) NOT NULL default '',
  `image` varchar(220) NOT NULL default '',
  `disporder` smallint(5) unsigned NOT NULL default '0',
  `showclickable` char(3) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_templategroups` table :
#

DROP TABLE IF EXISTS `mybb_templategroups`;

CREATE TABLE `mybb_templategroups` (
  `gid` int(10) unsigned NOT NULL auto_increment,
  `prefix` varchar(50) NOT NULL default '',
  `title` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`gid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_templates` table :
#

DROP TABLE IF EXISTS `mybb_templates`;

CREATE TABLE `mybb_templates` (
  `tid` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(120) NOT NULL default '',
  `template` text NOT NULL,
  `sid` int(10) NOT NULL default '0',
  `version` varchar(20) NOT NULL default '0',
  `status` varchar(10) NOT NULL default '',
  `dateline` int(10) NOT NULL default '0',
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_templatesets` table :
#

DROP TABLE IF EXISTS `mybb_templatesets`;

CREATE TABLE `mybb_templatesets` (
  `sid` smallint(5) unsigned NOT NULL auto_increment,
  `title` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_themes` table :
#

DROP TABLE IF EXISTS `mybb_themes`;

CREATE TABLE `mybb_themes` (
  `tid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `pid` smallint(5) unsigned NOT NULL default '0',
  `def` smallint(1) NOT NULL default '0',
  `css` text NOT NULL,
  `cssbits` text NOT NULL,
  `themebits` text NOT NULL,
  `extracss` text NOT NULL,
  `allowedgroups` text NOT NULL,
  `csscached` bigint(30) NOT NULL default '0',
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_threadratings` table :
#

DROP TABLE IF EXISTS `mybb_threadratings`;

CREATE TABLE `mybb_threadratings` (
  `rid` int(10) unsigned NOT NULL auto_increment,
  `tid` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `rating` smallint(5) unsigned NOT NULL default '0',
  `ipaddress` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`rid`),
  KEY `tid` (`tid`,`uid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_threads` table :
#

DROP TABLE IF EXISTS `mybb_threads`;

CREATE TABLE `mybb_threads` (
  `tid` int(10) unsigned NOT NULL auto_increment,
  `fid` smallint(5) unsigned NOT NULL default '0',
  `subject` varchar(120) NOT NULL default '',
  `icon` smallint(5) unsigned NOT NULL default '0',
  `poll` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `username` varchar(80) NOT NULL default '',
  `dateline` bigint(30) NOT NULL default '0',
  `firstpost` int(10) unsigned NOT NULL default '0',
  `lastpost` bigint(30) NOT NULL default '0',
  `lastposter` varchar(120) NOT NULL default '',
  `lastposteruid` int(10) unsigned NOT NULL default '0',
  `views` int(100) NOT NULL default '0',
  `replies` int(100) NOT NULL default '0',
  `closed` varchar(30) NOT NULL default '',
  `sticky` int(1) NOT NULL default '0',
  `numratings` smallint(5) unsigned NOT NULL default '0',
  `totalratings` smallint(5) unsigned NOT NULL default '0',
  `notes` text NOT NULL,
  `visible` int(1) NOT NULL default '0',
  `unapprovedposts` int(10) unsigned NOT NULL default '0',
  `attachmentcount` int(10) unsigned NOT NULL default '0',
  `deletetime` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tid`),
  KEY `fid` (`fid`,`visible`,`sticky`),
  KEY `dateline` (`dateline`),
  KEY `lastpost` (`lastpost`,`fid`),
  KEY `firstpost` (`firstpost`),
  KEY `uid` (`uid`),
  FULLTEXT KEY `subject` (`subject`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_threadsread` table :
#

DROP TABLE IF EXISTS `mybb_threadsread`;

CREATE TABLE `mybb_threadsread` (
  `tid` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `dateline` int(10) NOT NULL default '0',
  UNIQUE KEY `tiduid` (`tid`,`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_upgrade_data` table :
#

DROP TABLE IF EXISTS `mybb_upgrade_data`;

CREATE TABLE `mybb_upgrade_data` (
  `title` varchar(30) NOT NULL default '',
  `contents` text NOT NULL,
  PRIMARY KEY  (`title`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_userfields` table :
#

DROP TABLE IF EXISTS `mybb_userfields`;

CREATE TABLE `mybb_userfields` (
  `ufid` int(10) unsigned NOT NULL default '0',
  `fid1` text NOT NULL,
  `fid2` text NOT NULL,
  `fid3` text NOT NULL,
  PRIMARY KEY  (`ufid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_usergroups` table :
#

DROP TABLE IF EXISTS `mybb_usergroups`;

CREATE TABLE `mybb_usergroups` (
  `gid` smallint(5) unsigned NOT NULL auto_increment,
  `type` smallint(2) NOT NULL default '2',
  `title` varchar(120) NOT NULL default '',
  `description` text NOT NULL,
  `namestyle` varchar(200) NOT NULL default '{username}',
  `usertitle` varchar(120) NOT NULL default '',
  `stars` smallint(4) NOT NULL default '0',
  `starimage` varchar(120) NOT NULL default '',
  `image` varchar(120) NOT NULL default '',
  `disporder` smallint(6) unsigned NOT NULL default '0',
  `isbannedgroup` char(3) NOT NULL default '',
  `canview` char(3) NOT NULL default '',
  `canviewthreads` char(3) NOT NULL default '',
  `canviewprofiles` char(3) NOT NULL default '',
  `candlattachments` char(3) NOT NULL default '',
  `canpostthreads` char(3) NOT NULL default '',
  `canpostreplys` char(3) NOT NULL default '',
  `canpostattachments` char(3) NOT NULL default '',
  `canratethreads` char(3) NOT NULL default '',
  `caneditposts` char(3) NOT NULL default '',
  `candeleteposts` char(3) NOT NULL default '',
  `candeletethreads` char(3) NOT NULL default '',
  `caneditattachments` char(3) NOT NULL default '',
  `canpostpolls` char(3) NOT NULL default '',
  `canvotepolls` char(3) NOT NULL default '',
  `canusepms` char(3) NOT NULL default '',
  `cansendpms` char(3) NOT NULL default '',
  `cantrackpms` char(3) NOT NULL default '',
  `candenypmreceipts` char(3) NOT NULL default '',
  `pmquota` int(3) NOT NULL default '0',
  `cansendemail` char(3) NOT NULL default '',
  `canviewmemberlist` char(3) NOT NULL default '',
  `canviewcalendar` char(3) NOT NULL default '',
  `canaddpublicevents` char(3) NOT NULL default '',
  `canaddprivateevents` char(3) NOT NULL default '',
  `canviewonline` char(3) NOT NULL default '',
  `canviewwolinvis` char(3) NOT NULL default '',
  `canviewonlineips` char(3) NOT NULL default '',
  `cancp` char(3) NOT NULL default '',
  `issupermod` char(3) NOT NULL default '',
  `cansearch` char(3) NOT NULL default '',
  `canusercp` char(3) NOT NULL default '',
  `canuploadavatars` char(3) NOT NULL default '',
  `canratemembers` char(3) NOT NULL default '',
  `canchangename` char(3) NOT NULL default '',
  `showforumteam` char(3) NOT NULL default '',
  `usereputationsystem` char(3) NOT NULL default '',
  `cangivereputations` char(3) NOT NULL default '',
  `reputationpower` bigint(30) NOT NULL default '0',
  `maxreputationsday` bigint(30) NOT NULL default '0',
  `candisplaygroup` char(3) NOT NULL default '',
  `attachquota` bigint(30) NOT NULL default '0',
  `cancustomtitle` char(3) NOT NULL default '',
  PRIMARY KEY  (`gid`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_users` table :
#

DROP TABLE IF EXISTS `mybb_users`;

CREATE TABLE `mybb_users` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(120) NOT NULL default '',
  `password` varchar(120) NOT NULL default '',
  `salt` varchar(10) NOT NULL default '',
  `loginkey` varchar(50) NOT NULL default '',
  `email` varchar(220) NOT NULL default '',
  `postnum` int(10) NOT NULL default '0',
  `avatar` varchar(200) NOT NULL default '',
  `avatardimensions` varchar(10) NOT NULL default '',
  `avatartype` varchar(10) NOT NULL default '0',
  `usergroup` smallint(5) unsigned NOT NULL default '0',
  `additionalgroups` varchar(200) NOT NULL default '',
  `displaygroup` smallint(5) unsigned NOT NULL default '0',
  `usertitle` varchar(250) NOT NULL default '',
  `regdate` bigint(30) NOT NULL default '0',
  `lastactive` bigint(30) NOT NULL default '0',
  `lastvisit` bigint(30) NOT NULL default '0',
  `lastpost` bigint(30) NOT NULL default '0',
  `website` varchar(200) NOT NULL default '',
  `icq` varchar(10) NOT NULL default '',
  `aim` varchar(50) NOT NULL default '',
  `yahoo` varchar(50) NOT NULL default '',
  `msn` varchar(75) NOT NULL default '',
  `birthday` varchar(15) NOT NULL default '',
  `signature` text NOT NULL,
  `allownotices` char(3) NOT NULL default '',
  `hideemail` char(3) NOT NULL default '',
  `emailnotify` char(3) NOT NULL default '',
  `invisible` char(3) NOT NULL default '',
  `receivepms` char(3) NOT NULL default '',
  `pmpopup` char(3) NOT NULL default '',
  `pmnotify` char(3) NOT NULL default '',
  `remember` char(3) NOT NULL default '',
  `threadmode` varchar(8) NOT NULL default '',
  `showsigs` char(3) NOT NULL default '',
  `showavatars` char(3) NOT NULL default '',
  `showquickreply` char(3) NOT NULL default '',
  `showredirect` char(3) NOT NULL default '',
  `ppp` smallint(6) NOT NULL default '0',
  `tpp` smallint(6) NOT NULL default '0',
  `daysprune` smallint(6) NOT NULL default '0',
  `dateformat` varchar(4) NOT NULL default '',
  `timeformat` varchar(4) NOT NULL default '',
  `timezone` varchar(4) NOT NULL default '',
  `dst` varchar(4) NOT NULL default '',
  `buddylist` text NOT NULL,
  `ignorelist` text NOT NULL,
  `style` smallint(5) unsigned NOT NULL default '0',
  `away` char(3) NOT NULL default '',
  `awaydate` int(10) unsigned NOT NULL default '0',
  `returndate` varchar(15) NOT NULL default '',
  `awayreason` varchar(200) NOT NULL default '',
  `pmfolders` text NOT NULL,
  `notepad` text NOT NULL,
  `referrer` int(10) unsigned NOT NULL default '0',
  `reputation` bigint(30) NOT NULL default '0',
  `regip` varchar(50) NOT NULL default '',
  `language` varchar(50) NOT NULL default '',
  `timeonline` bigint(30) NOT NULL default '0',
  `showcodebuttons` int(1) NOT NULL default '1',
  `totalpms` int(10) NOT NULL default '0',
  `newpms` int(10) NOT NULL default '0',
  `unreadpms` int(10) NOT NULL default '0',
  PRIMARY KEY  (`uid`),
  KEY `username` (`username`),
  KEY `usergroup` (`usergroup`),
  KEY `birthday` (`birthday`)
) ENGINE=MyISAM;

#
# Structure for the `mybb_usertitles` table :
#

DROP TABLE IF EXISTS `mybb_usertitles`;

CREATE TABLE `mybb_usertitles` (
  `utid` smallint(5) unsigned NOT NULL auto_increment,
  `posts` int(10) unsigned NOT NULL default '0',
  `title` varchar(250) NOT NULL default '',
  `stars` smallint(4) NOT NULL default '0',
  `starimage` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`utid`)
) ENGINE=MyISAM;

#
# Structure for the `news` table :
#

DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `body` text NOT NULL,
  `subject` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM;

#
# Structure for the `notconnectablepmlog` table :
#

DROP TABLE IF EXISTS `notconnectablepmlog`;

CREATE TABLE `notconnectablepmlog` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `date` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `offers` table :
#

DROP TABLE IF EXISTS `offers`;

CREATE TABLE `offers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `name` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `category` int(11) NOT NULL default '0',
  `comments` int(11) NOT NULL default '0',
  `votes` smallint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM;

#
# Structure for the `offervotes` table :
#

DROP TABLE IF EXISTS `offervotes`;

CREATE TABLE `offervotes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `offerid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM;

#
# Structure for the `orbital_blocks` table :
#

DROP TABLE IF EXISTS `orbital_blocks`;

CREATE TABLE `orbital_blocks` (
  `bid` int(10) NOT NULL auto_increment,
  `bkey` varchar(15) NOT NULL default '',
  `title` varchar(60) NOT NULL default '',
  `content` text NOT NULL,
  `bposition` char(1) NOT NULL default '',
  `weight` int(10) NOT NULL default '1',
  `active` int(1) NOT NULL default '1',
  `time` varchar(14) NOT NULL default '0',
  `blockfile` varchar(255) NOT NULL default '',
  `view` int(1) NOT NULL default '0',
  `expire` varchar(14) NOT NULL default '0',
  `action` char(1) NOT NULL default '',
  `which` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`bid`),
  KEY `title` (`title`),
  KEY `weight` (`weight`),
  KEY `active` (`active`)
) ENGINE=MyISAM;

#
# Structure for the `peers` table :
#

DROP TABLE IF EXISTS `peers`;

CREATE TABLE `peers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `peer_id` varchar(20) NOT NULL default '',
  `ip` varchar(64) NOT NULL default '',
  `port` smallint(5) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `uploadoffset` bigint(20) unsigned NOT NULL default '0',
  `downloadoffset` bigint(20) unsigned NOT NULL default '0',
  `to_go` bigint(20) unsigned NOT NULL default '0',
  `seeder` enum('yes','no') NOT NULL default 'no',
  `started` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `prev_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL default 'yes',
  `userid` int(10) unsigned NOT NULL default '0',
  `agent` varchar(60) NOT NULL default '',
  `finishedat` int(10) unsigned NOT NULL default '0',
  `passkey` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `torrent_peer_id` (`torrent`,`peer_id`),
  KEY `torrent` (`torrent`),
  KEY `torrent_seeder` (`torrent`,`seeder`),
  KEY `last_action` (`last_action`),
  KEY `connectable` (`connectable`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM;

#
# Structure for the `pollanswers` table :
#

DROP TABLE IF EXISTS `pollanswers`;

CREATE TABLE `pollanswers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pollid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `selection` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`),
  KEY `selection` (`selection`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM;

#
# Structure for the `polls` table :
#

DROP TABLE IF EXISTS `polls`;

CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `question` varchar(255) NOT NULL default '',
  `option0` varchar(40) NOT NULL default '',
  `option1` varchar(40) NOT NULL default '',
  `option2` varchar(40) NOT NULL default '',
  `option3` varchar(40) NOT NULL default '',
  `option4` varchar(40) NOT NULL default '',
  `option5` varchar(40) NOT NULL default '',
  `option6` varchar(40) NOT NULL default '',
  `option7` varchar(40) NOT NULL default '',
  `option8` varchar(40) NOT NULL default '',
  `option9` varchar(40) NOT NULL default '',
  `option10` varchar(40) NOT NULL default '',
  `option11` varchar(40) NOT NULL default '',
  `option12` varchar(40) NOT NULL default '',
  `option13` varchar(40) NOT NULL default '',
  `option14` varchar(40) NOT NULL default '',
  `option15` varchar(40) NOT NULL default '',
  `option16` varchar(40) NOT NULL default '',
  `option17` varchar(40) NOT NULL default '',
  `option18` varchar(40) NOT NULL default '',
  `option19` varchar(40) NOT NULL default '',
  `sort` enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `ratings` table :
#

DROP TABLE IF EXISTS `ratings`;

CREATE TABLE `ratings` (
  `id` int(6) NOT NULL auto_increment,
  `torrent` int(10) NOT NULL default '0',
  `user` int(6) NOT NULL default '0',
  `rating` int(1) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `readtorrents` table :
#

DROP TABLE IF EXISTS `readtorrents`;

CREATE TABLE `readtorrents` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `torrentid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `read` (`userid`,`torrentid`)
) ENGINE=MyISAM;

#
# Structure for the `requests` table :
#

DROP TABLE IF EXISTS `requests`;

CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `request` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL default '0',
  `uploaded` enum('yes','no') NOT NULL default 'no',
  `filled` varchar(200) NOT NULL default '',
  `torrentid` int(10) unsigned NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `cat` int(10) unsigned NOT NULL default '0',
  `filledby` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM;

#
# Structure for the `sessions` table :
#

DROP TABLE IF EXISTS `sessions`;

CREATE TABLE `sessions` (
  `sid` varchar(32) NOT NULL default '',
  `uid` int(10) NOT NULL default '0',
  `username` varchar(40) NOT NULL default '',
  `class` tinyint(4) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  `time` bigint(30) NOT NULL default '0',
  `url` varchar(150) NOT NULL default '',
  `useragent` text,
  PRIMARY KEY  (`sid`),
  KEY `time` (`time`),
  KEY `uid` (`uid`),
  KEY `url` (`url`)
) ENGINE=MyISAM;

#
# Structure for the `simpaty` table :
#

DROP TABLE IF EXISTS `simpaty`;

CREATE TABLE `simpaty` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `touserid` int(10) unsigned NOT NULL default '0',
  `fromuserid` int(10) unsigned NOT NULL default '0',
  `fromusername` varchar(40) NOT NULL default '',
  `bad` tinyint(1) unsigned NOT NULL default '0',
  `good` tinyint(1) unsigned NOT NULL default '0',
  `type` varchar(60) NOT NULL default '',
  `respect_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `description` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `touserid` (`touserid`),
  KEY `fromuserid` (`fromuserid`),
  KEY `fromusername` (`fromusername`)
) ENGINE=MyISAM;

#
# Structure for the `sitelog` table :
#

DROP TABLE IF EXISTS `sitelog`;

CREATE TABLE `sitelog` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime default NULL,
  `color` varchar(11) NOT NULL default 'transparent',
  `txt` text,
  `type` varchar(8) NOT NULL default 'tracker',
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM;

#
# Structure for the `snatched` table :
#

DROP TABLE IF EXISTS `snatched`;

CREATE TABLE `snatched` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) default '0',
  `torrent` int(10) unsigned NOT NULL default '0',
  `port` smallint(5) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `to_go` bigint(20) unsigned NOT NULL default '0',
  `seeder` enum('yes','no') NOT NULL default 'no',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `startdat` datetime NOT NULL default '0000-00-00 00:00:00',
  `completedat` datetime NOT NULL default '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL default 'yes',
  `finished` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `snatch` (`torrent`,`userid`)
) ENGINE=MyISAM;

#
# Structure for the `stylesheets` table :
#

DROP TABLE IF EXISTS `stylesheets`;

CREATE TABLE `stylesheets` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uri` varchar(255) NOT NULL default '',
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `uri` (`uri`)
) ENGINE=MyISAM;

#
# Structure for the `thanks` table :
#

DROP TABLE IF EXISTS `thanks`;

CREATE TABLE `thanks` (
  `id` int(11) NOT NULL auto_increment,
  `torrentid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

#
# Structure for the `torrents` table :
#

DROP TABLE IF EXISTS `torrents`;

CREATE TABLE `torrents` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `info_hash` varbinary(40) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `save_as` varchar(255) NOT NULL default '',
  `search_text` text NOT NULL,
  `descr` text NOT NULL,
  `ori_descr` text NOT NULL,
  `image1` text NOT NULL,
  `image2` text NOT NULL,
  `category` int(10) unsigned NOT NULL default '0',
  `size` bigint(20) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` enum('single','multi') NOT NULL default 'single',
  `numfiles` int(10) unsigned NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `views` int(10) unsigned NOT NULL default '0',
  `hits` int(10) unsigned NOT NULL default '0',
  `times_completed` int(10) unsigned NOT NULL default '0',
  `leechers` int(10) unsigned NOT NULL default '0',
  `seeders` int(10) unsigned NOT NULL default '0',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_reseed` datetime NOT NULL default '0000-00-00 00:00:00',
  `visible` enum('yes','no') NOT NULL default 'yes',
  `banned` enum('yes','no') NOT NULL default 'no',
  `owner` int(10) unsigned NOT NULL default '0',
  `numratings` int(10) unsigned NOT NULL default '0',
  `ratingsum` int(10) unsigned NOT NULL default '0',
  `free` enum('yes','no') default 'no',
  `sticky` enum('yes','no') NOT NULL default 'no',
  `moderated` enum('yes','no') NOT NULL default 'no',
  `moderatedby` int(10) unsigned default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `info_hash` (`info_hash`),
  KEY `owner` (`owner`),
  KEY `visible` (`visible`),
  KEY `category_visible` (`category`,`visible`),
  FULLTEXT KEY `ft_search` (`search_text`,`ori_descr`)
) ENGINE=MyISAM;

#
# Structure for the `users` table :
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(40) NOT NULL default '',
  `old_password` varchar(40) NOT NULL default '',
  `passhash` varchar(32) NOT NULL default '',
  `secret` varchar(20) NOT NULL default '',
  `email` varchar(80) NOT NULL default '',
  `status` enum('pending','confirmed') NOT NULL default 'pending',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL default '0000-00-00 00:00:00',
  `editsecret` varchar(20) NOT NULL default '',
  `privacy` enum('strong','normal','low') NOT NULL default 'normal',
  `stylesheet` int(10) default '1',
  `info` text,
  `acceptpms` enum('yes','friends','no') NOT NULL default 'yes',
  `ip` varchar(15) NOT NULL default '',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `override_class` tinyint(3) unsigned NOT NULL default '255',
  `support` enum('no','yes') NOT NULL default 'no',
  `supportfor` text,
  `avatar` varchar(100) NOT NULL default '',
  `icq` varchar(255) NOT NULL default '',
  `msn` varchar(255) NOT NULL default '',
  `aim` varchar(255) NOT NULL default '',
  `yahoo` varchar(255) NOT NULL default '',
  `skype` varchar(255) NOT NULL default '',
  `mirc` varchar(255) NOT NULL default '',
  `website` varchar(50) NOT NULL default '',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `bonus` decimal(5,2) NOT NULL default '0.00',
  `title` varchar(30) NOT NULL default '',
  `country` int(10) unsigned NOT NULL default '0',
  `notifs` varchar(100) NOT NULL default '',
  `modcomment` text,
  `enabled` enum('yes','no') NOT NULL default 'yes',
  `parked` enum('yes','no') NOT NULL default 'no',
  `avatars` enum('yes','no') NOT NULL default 'yes',
  `donor` enum('yes','no') NOT NULL default 'no',
  `simpaty` int(10) unsigned NOT NULL default '0',
  `warned` enum('yes','no') NOT NULL default 'no',
  `warneduntil` datetime NOT NULL default '0000-00-00 00:00:00',
  `torrentsperpage` int(3) unsigned NOT NULL default '0',
  `topicsperpage` int(3) unsigned NOT NULL default '0',
  `postsperpage` int(3) unsigned NOT NULL default '0',
  `deletepms` enum('yes','no') NOT NULL default 'yes',
  `savepms` enum('yes','no') NOT NULL default 'no',
  `gender` enum('1','2','3') NOT NULL default '1',
  `birthday` date default '0000-00-00',
  `passkey` varchar(32) NOT NULL default '',
  `language` varchar(255) NOT NULL default 'russian',
  `invites` int(10) NOT NULL default '0',
  `invitedby` int(10) NOT NULL default '0',
  `invitedroot` int(10) NOT NULL default '0',
  `passkey_ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status_added` (`status`,`added`),
  KEY `ip` (`ip`),
  KEY `uploaded` (`uploaded`),
  KEY `downloaded` (`downloaded`),
  KEY `country` (`country`),
  KEY `last_access` (`last_access`),
  KEY `enabled` (`enabled`),
  KEY `warned` (`warned`),
  KEY `user` (`id`,`status`,`enabled`)
) ENGINE=MyISAM;

#
# Data for the `bonus` table  (LIMIT 0,100)
#

INSERT INTO `bonus` (`id`, `name`, `points`, `description`, `type`, `quanity`) VALUES
  (1,'1.0GB Uploaded',75,'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.','traffic','1073741824'),
  (2,'2.5GB Uploaded',150,'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.','traffic','2684354560'),
  (3,'5GB Uploaded',250,'With enough bonus points acquired, you are able to exchange them for an Upload Credit. The points are then removed from your Bonus Bank and the credit is added to your total uploaded amount.','traffic','5368709120'),
  (4,'3 Invites',20,'With enough bonus points acquired, you are able to exchange them for a few invites. The points are then removed from your Bonus Bank and the invitations are added to your invites amount.','invite','3');

COMMIT;

#
# Data for the `categories` table  (LIMIT 0,100)
#

INSERT INTO `categories` (`id`, `sort`, `name`, `image`) VALUES
  (1,10,'���������� ISO','appzpciso.gif'),
  (2,20,'���������� PDA','appzpda.gif'),
  (3,30,'���������� AUDIO','appzaudio.gif'),
  (4,40,'���������� MISC','appzmisc.gif'),
  (5,50,'���� PC','gamespc.gif'),
  (6,60,'���� PS2','gamesps2.gif'),
  (7,70,'���� X-Box','gamesxbox.gif'),
  (8,80,'���� PSP','gamespsp.gif'),
  (9,90,'������������','docs.gif'),
  (10,100,'������','music.gif'),
  (11,110,'�������','tv.gif'),
  (12,120,'�����','anime.gif'),
  (13,130,'������ XviD','moviesxvid.gif'),
  (14,140,'������ HDTV','movieshdtv.gif'),
  (15,150,'������ DVD','moviesdvd.gif'),
  (16,160,'�����','ebooks.gif'),
  (17,170,'XXX','xxx.gif');

COMMIT;

#
# Data for the `countries` table  (LIMIT 0,100)
#

INSERT INTO `countries` (`id`, `name`, `flagpic`) VALUES
  (87,'Antigua Barbuda','antiguabarbuda.gif'),
  (33,'Belize','belize.gif'),
  (59,'Burkina Faso','burkinafaso.gif'),
  (10,'Denmark','denmark.gif'),
  (91,'Senegal','senegal.gif'),
  (76,'Trinidad & Tobago','trinidadandtobago.gif'),
  (20,'���������','australia.gif'),
  (36,'�������','austria.gif'),
  (27,'�������','albania.gif'),
  (34,'�����','algeria.gif'),
  (12,'������','uk.gif'),
  (35,'������','angola.gif'),
  (66,'������','andorra.gif'),
  (19,'���������','argentina.gif'),
  (53,'����������','afghanistan.gif'),
  (80,'������','bahamas.gif'),
  (83,'��������','barbados.gif'),
  (16,'�������','belgium.gif'),
  (84,'���������','bangladesh.gif'),
  (101,'��������','bulgaria.gif'),
  (65,'������','bosniaherzegovina.gif'),
  (18,'��������','brazil.gif'),
  (74,'�������','vanuatu.gif'),
  (72,'�������','hungary.gif'),
  (71,'���������','venezuela.gif'),
  (75,'�������','vietnam.gif'),
  (7,'��������','germany.gif'),
  (77,'��������','honduras.gif'),
  (32,'���� ����','hongkong.gif'),
  (41,'������','greece.gif'),
  (42,'���������','guatemala.gif'),
  (40,'������������� ����������','dominicanrep.gif'),
  (100,'�����','egypt.gif'),
  (43,'�������','israel.gif'),
  (26,'�����','india.gif'),
  (13,'��������','ireland.gif'),
  (61,'��������','iceland.gif'),
  (102,'���� �� ������','jollyroger.gif'),
  (22,'�������','spain.gif'),
  (9,'������','italy.gif'),
  (82,'��������','cambodia.gif'),
  (5,'������','canada.gif'),
  (78,'���������','kyrgyzstan.gif'),
  (57,'��������','kiribati.gif'),
  (8,'�����','china.gif'),
  (52,'�����','congo.gif'),
  (96,'��������','colombia.gif'),
  (99,'����� ����','costarica.gif'),
  (51,'����','cuba.gif'),
  (85,'����','laos.gif'),
  (98,'������','latvia.gif'),
  (97,'�������','lebanon.gif'),
  (67,'�����','lithuania.gif'),
  (31,'����������','luxembourg.gif'),
  (68,'���������','macedonia.gif'),
  (39,'��������','malaysia.gif'),
  (24,'�������','mexico.gif'),
  (62,'�����','nauru.gif'),
  (60,'�������','nigeria.gif'),
  (69,'������������� �������','nethantilles.gif'),
  (15,'����������','netherlands.gif'),
  (21,'����� ��������','newzealand.gif'),
  (11,'��������','norway.gif'),
  (44,'��������','pakistan.gif'),
  (88,'��������','paraguay.gif'),
  (81,'����','peru.gif'),
  (14,'������','poland.gif'),
  (23,'����������','portugal.gif'),
  (49,'������ ����','puertorico.gif'),
  (3,'������','russia.gif'),
  (73,'�������','romania.gif'),
  (93,'�������� �����','northkorea.gif'),
  (47,'����������� �������','seychelles.gif'),
  (46,'������','serbia.gif'),
  (25,'��������','singapore.gif'),
  (63,'��������','slovenia.gif'),
  (90,'����','ussr.gif'),
  (2,'���','usa.gif'),
  (48,'�������','taiwan.gif'),
  (89,'�������','thailand.gif'),
  (92,'����','togo.gif'),
  (64,'������������','turkmenistan.gif'),
  (54,'������','turkey.gif'),
  (55,'����������','uzbekistan.gif'),
  (70,'�������','ukraine.gif'),
  (86,'�������','uruguay.gif'),
  (58,'���������','philippines.gif'),
  (4,'���������','finland.gif'),
  (6,'�������','france.gif'),
  (94,'��������','croatia.gif'),
  (45,'�����','czechrep.gif'),
  (50,'����','chile.gif'),
  (56,'���������','switzerland.gif'),
  (1,'������','sweden.gif'),
  (79,'�������','ecuador.gif'),
  (95,'�������','estonia.gif'),
  (37,'���������','yugoslavia.gif'),
  (28,'����� ������','southafrica.gif'),
  (29,'����� �����','southkorea.gif'),
  (38,'����� �����','westernsamoa.gif');

COMMIT;

#
# Data for the `countries` table  (LIMIT 100,100)
#

INSERT INTO `countries` (`id`, `name`, `flagpic`) VALUES
  (30,'������','jamaica.gif'),
  (17,'������','japan.gif');

COMMIT;

#
# Data for the `faq` table  (LIMIT 0,100)
#

INSERT INTO `faq` (`id`, `type`, `question`, `answer`, `flag`, `categ`, `order`) VALUES
  (1,'categ','� �����','',1,0,1),
  (2,'categ','User information','',1,0,2),
  (3,'categ','����������','',1,0,3),
  (4,'categ','�������','',1,0,4),
  (5,'categ','�������','',1,0,5),
  (6,'categ','How can I improve my download speed?','',1,0,6),
  (7,'categ','My ISP uses a transparent proxy. What should I do?','',1,0,7),
  (8,'categ','Why can''t I connect? Is the site blocking me?','',1,0,8),
  (9,'categ','What if I can''t find the answer to my problem here?','',1,0,9),
  (10,'item','��� ����� ������� (bittorrent)? ��� ��������� �����?','Check out <a class=altlink href=\"http://www.btfaq.com/\">Brian''s BitTorrent FAQ and Guide</a>',1,1,1),
  (11,'item','�� ��� ����������� ������ �� �������������?','�� ����� ���������� ���������� ������ ��� ���������� � ����� ������� ������. �� ������ ������ ������ ���� �� ������ ��������.',1,1,2),
  (12,'item','��� � ���� ������� ��������� ����� ������?','�� ������ ����� �� �� <a href=\"http://bit-torrent.kiev.ua/\" class=altlink_white>������ TBDev</a>. ������ �����: �� �� ������������ ��� ��������� ������ ����, ������� �� ���������� ��� ���������� ����. ���� ��� �������� - �����������, ���� ��� - ����� �����. ����������� �� ������ �� ���� ����� � ����.',1,1,3),
  (13,'item','I registered an account but did not receive the confirmation e-mail!','You can use <a class=altlink href=delacct.php>this form</a> to delete the account so you can re-register.\r\nNote though that if you didn''t receive the email the first time it will probably not\r\nsucceed the second time either so you should really try another email address.',1,2,1),
  (14,'item','I''ve lost my user name or password! Can you send it to me?','Please use <a class=altlink href=recover.php>this form</a> to have the login details mailed back to you.',1,2,2),
  (15,'item','Can you rename my account?','We do not rename accounts. Please create a new one. (Use <a href=delacct.php class=altlink>this form</a> to\r\ndelete your present account.)',1,2,3),
  (16,'item','Can you delete my (confirmed) account?','You can do it yourself by using <a href=delacct.php class=altlink>this form</a>.',1,2,4),
  (17,'item','So, what''s MY ratio?','Click on your <a class=altlink href=my.php>profile</a>, then on your user name (at the top).<br>\r\n<br>\r\nIt''s important to distinguish between your overall ratio and the individual ratio on each torrent\r\nyou may be seeding or leeching. The overall ratio takes into account the total uploaded and downloaded\r\nfrom your account since you joined the site. The individual ratio takes into account those values for each torrent.<br>\r\n<br>\r\nYou may see two symbols instead of a number: \"Inf.\", which is just an abbreviation for Infinity, and\r\nmeans that you have downloaded 0 bytes while uploading a non-zero amount (ul/dl becomes infinity); \"---\",\r\nwhich should be read as \"non-available\", and shows up when you have both downloaded and uploaded 0 bytes\r\n(ul/dl = 0/0 which is an indeterminate amount).',1,2,5),
  (18,'item','Why is my IP displayed on my details page?','Only you and the site moderators can view your IP address and email. Regular users do not see that information.',1,2,6),
  (19,'item','Help! I cannot login!? (a.k.a. Login of Death)','This problem sometimes occurs with MSIE. Close all Internet Explorer windows and open Internet Options in the control panel. Click the Delete Cookies button. You should now be able to login.\r\n',1,2,7),
  (20,'item','My IP address is dynamic. How do I stay logged in?','You do not have to anymore. All you have to do is make sure you are logged in with your actual\r\nIP when starting a torrent session. After that, even if the IP changes mid-session,\r\nthe seeding or leeching will continue and the statistics will update without any problem.',1,2,8),
  (21,'item','Why is my port number reported as \"---\"? (And why should I care?)','The tracker has determined that you are firewalled or NATed and cannot accept incoming connections.\r\n<br>\r\n<br>\r\nThis means that other peers in the swarm will be unable to connect to you, only you to them. Even worse,\r\nif two peers are both in this state they will not be able to connect at all. This has obviously a\r\ndetrimental effect on the overall speed.\r\n<br>\r\n<br>\r\nThe way to solve the problem involves opening the ports used for incoming connections\r\n(the same range you defined in your client) on the firewall and/or configuring your\r\nNAT server to use a basic form of NAT\r\nfor that range instead of NAPT (the actual process differs widely between different router models.\r\nCheck your router documentation and/or support forum. You will also find lots of information on the\r\nsubject at <a class=altlink href=\"http://portforward.com/\">PortForward</a>).',1,2,9),
  (22,'item','What are the different user classes?','<table cellspacing=3 cellpadding=0>\r\n<tr>\r\n<td class=embedded width=100 bgcolor=\"#F5F4EA\">&nbsp; <b>User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>The default class of new members.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b>Power User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Can download DOX over 1MB and view NFO files.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><img src=\"pic/star.gif\" alt=\"Star\"></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Has donated money to TBDev Yuna Scatari Edition . </td>\r\n</tr>\r\n<tr>\r\n<td class=embedded valign=top bgcolor=\"#F5F4EA\">&nbsp; <b>VIP</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Same privileges as Power User and is considered an Elite Member of TBDev Yuna Scatari Edition. Immune to automatic demotion.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b>Other</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Customised title.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><font color=\"#4040c0\">Uploader</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Same as PU except with upload rights and immune to automatic demotion.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded valign=top bgcolor=\"#F5F4EA\">&nbsp; <b><font color=\"#A83838\">Moderator</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Can edit and delete any uploaded torrents. Can also moderate usercomments and disable accounts.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><font color=\"#A83838\">Administrator</color></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Can do just about anything.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><font color=\"#A83838\">SysOp</color></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Redbeard (site owner).</td>\r\n</tr>\r\n</table>',1,2,10),
  (23,'item','How does this promotion thing work anyway?','<table cellspacing=3 cellpadding=0>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\" valign=top width=100>&nbsp; <b>Power User</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Must have been be a member for at least 4 weeks, have uploaded at least 25GB and\r\nhave a ratio at or above 1.05.<br>\r\nThe promotion is automatic when these conditions are met. Note that you will be automatically demoted from<br>\r\nthis status if your ratio drops below 0.95 at any time.</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><img src=\"pic/star.gif\" alt=\"Star\"></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Just donate, and send a message to <a class=altlink href=sendmessage.php?receiver=1>Admin</a></td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\" valign=top>&nbsp; <b>VIP</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded valign=top>Assigned by mods at their discretion to users they feel contribute something special to the site.<br>\r\n(Anyone begging for VIP status will be automatically disqualified.)</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b>Other</b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Conferred by mods at their discretion (not available to Users or Power Users).</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><font color=\"#4040c0\">Uploader</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>Appointed by Admins/SysOp (see the ''Uploading'' section for conditions).</td>\r\n</tr>\r\n<tr>\r\n<td class=embedded bgcolor=\"#F5F4EA\">&nbsp; <b><font color=\"#A83838\">Moderator</font></b></td>\r\n<td class=embedded width=5>&nbsp;</td>\r\n<td class=embedded>You don''t ask us, we''ll ask you!</td>\r\n</tr>\r\n</table>',1,2,11),
  (24,'item','Hey! I''ve seen Power Users with less than 25GB uploaded!','The PU limit used to be 10GB and we didn''t demote anyone when we raised it to 25GB.',1,2,12),
  (25,'item','Why can''t my friend become a member?','There is a 75.000 users limit. When that number is reached we stop accepting new members. Accounts inactive for more than 42 days are automatically deleted, so keep trying. (There is no reservation or queuing system, don''t ask for that.)',1,2,13),
  (26,'item','How do I add an avatar to my profile?','First, find an image that you like, and that is within the\r\n<a class=altlink href=rules.php>rules</a>. Then you will have\r\nto find a place to host it, such as our own <a class=altlink href=bitbucket-upload.php>BitBucket</a>.\r\n(Other popular choices are <a class=\"altlink\" href=\"http://photobucket.com/\">Photobucket</a>,\r\n<a class=\"altlink\" href=\"http://uploadit.org/\">Upload-It!</a> or\r\n<a class=\"altlink\" href=\"http://www.imageshack.us/\">ImageShack</a>).\r\nAll that is left to do is copy the URL you were given when\r\nuploading it to the avatar field in your <a class=\"altlink\" href=\"usercp.php\">profile</a>.<br>\r\n<br>\r\nPlease do not make a post just to test your avatar. If everything is allright you''ll see it\r\nin your details page.',1,2,14),
  (27,'item','Most common reason for stats not updating','<ul>\r\n<li>The user is cheating. (a.k.a. \"Summary Ban\")</li>\r\n<li>The server is overloaded and unresponsive. Just try to keep the session open until the server responds again. (Flooding the server with consecutive manual updates is not recommended.)</li>\r\n<li>You are using a faulty client. If you want to use an experimental or CVS version you do it at your own risk.</li>\r\n</ul>',1,3,1),
  (28,'item','Best practices','<ul>\r\n<li>If a torrent you are currently leeching/seeding is not listed on your profile, just wait or force a manual update.</li>\r\n<li>Make sure you exit your client properly, so that the tracker receives \"event=completed\".</li>\r\n<li>If the tracker is down, do not stop seeding. As long as the tracker is back up before you exit the client the stats should update properly.</li>\r\n</ul>',1,3,2),
  (29,'item','May I use any bittorrent client?','Yes. The tracker now updates the stats correctly for all bittorrent clients. However, we still recommend\r\nthat you <b>avoid</b> the following clients:<br>\r\n<ul>\r\n<li>BitTorrent++</li>\r\n<li>Nova Torrent</li>\r\n<li>TorrentStorm</li>\r\n</ul>\r\nThese clients do not report correctly to the tracker when canceling/finishing a torrent session.\r\nIf you use them then a few MB may not be counted towards\r\nthe stats near the end, and torrents may still be listed in your profile for some time after you have closed the client.<br>\r\n<br>\r\nAlso, clients in alpha or beta version should be avoided.',1,3,3),
  (30,'item','Why is a torrent I''m leeching/seeding listed several times in my profile?','If for some reason (e.g. pc crash, or frozen client) your client exits improperly and you restart it,\r\nit will have a new peer_id, so it will show as a new torrent. The old one will never receive a \"event=completed\"\r\nor \"event=stopped\" and will be listed until some tracker timeout. Just ignore it, it will eventually go away.',1,3,4),
  (31,'item','I''ve finished or cancelled a torrent. Why is it still listed in my profile?','Some clients, notably TorrentStorm and Nova Torrent, do not report properly to the tracker when canceling or finishing a torrent.\r\nIn that case the tracker will keep waiting for some message - and thus listing the torrent as seeding or leeching - until some\r\ntimeout occurs. Just ignore it, it will eventually go away.',1,3,5),
  (32,'item','Why do I sometimes see torrents I''m not leeching in my profile!?','When a torrent is first started, the tracker uses the IP to identify the user. Therefore the torrent will\r\nbecome associated with the user <i>who last accessed the site</i> from that IP. If you share your IP in some\r\nway (you are behind NAT/ICS, or using a proxy), and some of the persons you share it with are also users,\r\nyou may occasionally see their torrents listed in your profile. (If they start a torrent session from that\r\nIP and you were the last one to visit the site the torrent will be associated with you). Note that now\r\ntorrents listed in your profile will always count towards your total stats.',1,3,6),
  (33,'item','Multiple IPs (Can I login from different computers?)','Yes, the tracker is now capable of following sessions from different IPs for the same user. A torrent is associated with the user when it starts, and only at that moment is the IP relevant. So if you want to seed/leech from computer A and computer B with the same account you should access the site from computer A, start the torrent there, and then repeat both steps from computer B (not limited to two computers or to a single torrent on each, this is just the simplest example). You do not need to login again when closing the torrent.\r\n',1,3,7),
  (34,'item','How does NAT/ICS change the picture?','This is a very particular case in that all computers in the LAN will appear to the outside world as having the same IP. We must distinguish\r\nbetween two cases:<br>\r\n<br>\r\n<b>1.</b> <i>You are the single TBDev Yuna Scatari Edition users in the LAN</i><br>\r\n<br>\r\nYou should use the same TBDev Yuna Scatari Edition account in all the computers.<br>\r\n<br>\r\nNote also that in the ICS case it is preferable to run the BT client on the ICS gateway. Clients running on the other computers\r\nwill be unconnectable (their ports will be listed as \"---\", as explained elsewhere in the FAQ) unless you specify\r\nthe appropriate services in your ICS configuration (a good explanation of how to do this for Windows XP can be found\r\n<a class=altlink href=\"redirector.php?url=http://www.microsoft.com/downloads/details.aspx?FamilyID=1dcff3ce-f50f-4a34-ae67-cac31ccd7bc9&displaylang=en\">here</a>).\r\nIn the NAT case you should configure different ranges for clients on different computers and create appropriate NAT rules in the router. (Details vary widely from router to router and are outside the scope of this FAQ. Check your router documentation and/or support forum.)<br>\r\n<br>\r\n<br>\r\n<b>2.</b> <i>There are multiple TBDev Yuna Scatari Edition users in the LAN</i><br>\r\n<br>\r\nAt present there is no way of making this setup always work properly with Template Shares.\r\nEach torrent will be associated with the user who last accessed the site from within\r\nthe LAN before the torrent was started.\r\nUnless there is cooperation between the users mixing of statistics is possible.\r\n(User A accesses the site, downloads a .torrent file, but does not start the torrent immediately.\r\nMeanwhile, user B accesses the site. User A then starts the torrent. The torrent will count\r\ntowards user B''s statistics, not user A''s.)\r\n<br>\r\n<br>\r\nIt is your LAN, the responsibility is yours. Do not ask us to ban other users\r\nwith the same IP, we will not do that. (Why should we ban <i>him</i> instead of <i>you</i>?)',1,3,8),
  (36,'item','Why can''t I upload torrents?','Only specially authorized users (<font color=\"#4040c0\"><b>Uploaders</b></font>) have permission to upload torrents.',1,4,1),
  (37,'item','What criteria must I meet before I can join the <font color=\"#4040c0\">Uploader</font> team?','You must be able to provide releases that:\r\n<li>include a proper NFO</li>\r\n<li>are genuine scene releases. If it''s not on <a class=altlink <href=\"redirector.php?url=http://www.nforce.nl\">NFOrce</a> then forget it! (except music)</li>\r\n<li>are not older than seven (7) days</li>\r\n<li>have all files in original format (usually 14.3 MB RARs)</li>\r\n<li>you''ll be able to seed, or make sure are well-seeded, for at least 24 hours.</li>\r\n<li>you should have atleast 2MBit upload bandwith.</li>\r\n</ul>\r\nIf you think you can match these criteria do not hesitate to <a class=altlink href=staff.php>contact</a> one of the administrators.<br>\r\n<b>Remember!</b> Write your application carefully! Be sure to include your UL speed and what kind of stuff you''re planning to upload.<br>\r\nOnly well written letters with serious intent will be considered.',1,4,2),
  (38,'item','Can I upload your torrents to other trackers?','No. We are a closed, limited-membership community. Only registered users can use the TB tracker.\r\nPosting our torrents on other trackers is useless, since most people who attempt to download them will\r\nbe unable to connect with us. This generates a lot of frustration and bad-will against us at TBDev Yuna Scatari Edition,\r\nand will therefore not be tolerated.<br>\r\n<br>\r\nComplaints from other sites'' administrative staff about our torrents being posted on their sites will\r\nresult in the banning of the users responsible.<br>\r\n<br>\r\n(However, the files you download from us are yours to do as you please. You can always create another\r\ntorrent, pointing to some other tracker, and upload it to the site of your choice.)',1,4,3),
  (39,'item','How do I use the files I''ve downloaded?','Check out <a class=altlink href=videoformats.php>this guide</a>.',1,5,1),
  (40,'item','Downloaded a movie and don''t know what CAM/TS/TC/SCR means?','Check out <a class=altlink href=videoformats.php>this</a> guide.',1,5,2),
  (41,'item','Why did an active torrent suddenly disappear?','There may be three reasons for this:<br>\r\n(<b>1</b>) The torrent may have been out-of-sync with the site\r\n<a class=altlink href=rules.php>rules</a>.<br>\r\n(<b>2</b>) The uploader may have deleted it because it was a bad release.\r\nA replacement will probably be uploaded to take its place.<br>\r\n(<b>3</b>) Torrents are automatically deleted after 28 days.',1,5,3),
  (42,'item','How do I resume a broken download or reseed something?','Open the .torrent file. When your client asks you for a location, choose the location of the existing file(s) and it will resume/reseed the torrent.\r\n',1,5,4),
  (43,'item','Why do my downloads sometimes stall at 99%?','The more pieces you have, the harder it becomes to find peers who have pieces you are missing. That is why downloads sometimes slow down or even stall when there are just a few percent remaining. Just be patient and you will, sooner or later, get the remaining pieces.\r\n',1,5,5),
  (44,'item','What are these \"a piece has failed an hash check\" messages?','Bittorrent clients check the data they receive for integrity. When a piece fails this check it is\r\nautomatically re-downloaded. Occasional hash fails are a common occurrence, and you shouldn''t worry.<br>\r\n<br>\r\nSome clients have an (advanced) option/preference to ''kick/ban clients that send you bad data'' or\r\nsimilar. It should be turned on, since it makes sure that if a peer repeatedly sends you pieces that\r\nfail the hash check it will be ignored in the future.',1,5,6),
  (45,'item','The torrent is supposed to be 100MB. How come I downloaded 120MB?','See the hash fails topic. If your client receives bad data it will have to redownload it, therefore\r\nthe total downloaded may be larger than the torrent size. Make sure the \"kick/ban\" option is turned on\r\nto minimize the extra downloads.',1,5,7),
  (46,'item','Why do I get a \"Not authorized (xx h) - READ THE FAQ\" error?','From the time that each <b>new</b> torrent is uploaded to the tracker, there is a period of time that\r\nsome users must wait before they can download it.<br>\r\nThis delay in downloading will only affect users with a low ratio, and users with low upload amounts.<br>\r\n<br>\r\nThis applies to new users as well, so opening a new account will not help. Note also that this\r\nworks at tracker level, you will be able to grab the .torrent file itself at any time.<br>\r\n<br>\r\n<!--The delay applies only to leeching, not to seeding. If you got the files from any other source and\r\nwish to seed them you may do so at any time irrespectively of your ratio or total uploaded.<br>-->\r\nN.B. Due to some users exploiting the ''no-delay-for-seeders'' policy we had to change it. The delay\r\nnow applies to both seeding and leeching. So if you are subject to a delay and get the files from\r\nsome other source you will not be able to seed them until the delay has elapsed.',2,5,8),
  (47,'item','Why do I get a \"rejected by tracker - Port xxxx is blacklisted\" error?','Your client is reporting to the tracker that it uses one of the default bittorrent ports\r\n(6881-6889) or any other common p2p port for incoming connections.<br>\r\n<br>\r\nTBDev Yuna Scatari Edition does not allow clients to use ports commonly associated with p2p protocols.\r\nThe reason for this is that it is a common practice for ISPs to throttle those ports\r\n(that is, limit the bandwidth, hence the speed). <br>\r\n<br>\r\nThe blocked ports list include, but is not neccessarily limited to, the following:<br>\r\n<br>\r\n<table cellspacing=3 cellpadding=0>\r\n  <tr>\r\n    <td class=embedded width=\"80\">Direct Connect</td>\r\n    <td class=embedded width=\"80\" bgcolor=\"#F5F4EA\"><div align=\"center\">411 - 413</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=embedded width=\"80\">Kazaa</td>\r\n    <td class=embedded width=\"80\" bgcolor=\"#F5F4EA\"><div align=\"center\">1214</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=embedded width=\"80\">eDonkey</td>\r\n    <td class=embedded width=\"80\" bgcolor=\"#F5F4EA\"><div align=\"center\">4662</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=embedded width=\"80\">Gnutella</td>\r\n    <td class=embedded width=\"80\" bgcolor=\"#F5F4EA\"><div align=\"center\">6346 - 6347</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=embedded width=\"80\">BitTorrent</td>\r\n    <td class=embedded width=\"80\" bgcolor=\"#F5F4EA\"><div align=\"center\">6881 - 6889</div></td>\r\n </tr>\r\n</table>\r\n<br>\r\nIn order to use use our tracker you must  configure your client to use\r\nany port range that does not contain those ports (a range within the region 49152 through 65535 is preferable,\r\ncf. <a class=altlink href=\"http://www.iana.org/assignments/port-numbers\">IANA</a>). Notice that some clients,\r\nlike Azureus 2.0.7.0 or higher, use a single port for all torrents, while most others use one port per open torrent. The size\r\nof the range you choose should take this into account (typically less than 10 ports wide. There\r\nis no benefit whatsoever in choosing a wide range, and there are possible security implications). <br>\r\n<br>\r\nThese ports are used for connections between peers, not client to tracker.\r\nTherefore this change will not interfere with your ability to use other trackers (in fact it\r\nshould <i>increase</i> your speed with torrents from any tracker, not just ours). Your client\r\nwill also still be able to connect to peers that are using the standard ports.\r\nIf your client does not allow custom ports to be used, you will have to switch to one that does.<br>\r\n<br>\r\nDo not ask us, or in the forums, which ports you should choose. The more random the choice is the harder\r\nit will be for ISPs to catch on to us and start limiting speeds on the ports we use.\r\nIf we simply define another range ISPs will start throttling that range also. <br>\r\n<br>\r\nFinally, remember to forward the chosen ports in your router and/or open them in your\r\nfirewall, should you have them.',1,5,9),
  (48,'item','What''s this \"IOError - [Errno13] Permission denied\" error?','If you just want to fix it reboot your computer, it should solve the problem.\r\nOtherwise read on.<br>\r\n<br>\r\nIOError means Input-Output Error, and that is a file system error, not a tracker one.\r\nIt shows up when your client is for some reason unable to open the partially downloaded\r\ntorrent files. The most common cause is two instances of the client to be running\r\nsimultaneously:\r\nthe last time the client was closed it somehow didn''t really close but kept running in the\r\nbackground, and is therefore still\r\nlocking the files, making it impossible for the new instance to open them.<br>\r\n<br>\r\nA more uncommon occurrence is a corrupted FAT. A crash may result in corruption\r\nthat makes the partially downloaded files unreadable, and the error ensues. Running\r\nscandisk should solve the problem. (Note that this may happen only if you''re running\r\nWindows 9x - which only support FAT - or NT/2000/XP with FAT formatted hard drives.\r\nNTFS is much more robust and should never permit this problem.)',1,5,10),
  (49,'item','What''s this \"TTL\" in the browse page?','The torrent''s Time To Live, in hours. It means the torrent will be deleted\r\nfrom the tracker after that many hours have elapsed (yes, even if it is still active).\r\nNote that this a maximum value, the torrent may be deleted at any time if it''s inactive.',1,5,11),
  (50,'item','Do not immediately jump on new torrents','The download speed mostly depends on the seeder-to-leecher ratio (SLR). Poor download speed is\r\nmainly a problem with new and very popular torrents where the SLR is low.<br>\r\n<br>\r\n(Proselytising sidenote: make sure you remember that you did not enjoy the low speed.\r\n<b>Seed</b> so that others will not endure the same.)<br>\r\n<br>\r\nThere are a couple of things that you can try on your end to improve your speed:<br>\r\n<br>In particular, do not do it if you have a slow connection. The best speeds will be found around the\r\nhalf-life of a torrent, when the SLR will be at its highest. (The downside is that you will not be able to seed\r\nso much. It''s up to you to balance the pros and cons of this.)',1,6,1),
  (51,'item','Limit your upload speed','The upload speed affects the download speed in essentially two ways:<br>\r\n<ul>\r\n    <li>Bittorrent peers tend to favour those other peers that upload to them. This means that if A and B\r\n    are leeching the same torrent and A is sending data to B at high speed then B will try to reciprocate.\r\n    So due to this effect high upload speeds lead to high download speeds.</li>\r\n\r\n    <li>Due to the way TCP works, when A is downloading something from B it has to keep telling B that\r\n        it received the data sent to him. (These are called acknowledgements - ACKs -, a sort of \"got it!\" messages).\r\n        If A fails to do this then B will stop sending data and wait. If A is uploading at full speed there may be no\r\n        bandwidth left for the ACKs and they will be delayed. So due to this effect excessively high upload speeds lead\r\n        to low download speeds.</li>\r\n</ul>\r\n\r\nThe full effect is a combination of the two. The upload should be kept as high as possible while allowing the\r\nACKs to get through without delay. <b>A good thumb rule is keeping the upload at about 80% of the theoretical\r\nupload speed.</b> You will have to fine tune yours to find out what works best for you. (Remember that keeping the\r\nupload high has the additional benefit of helping with your ratio.) <br>\r\n<br>\r\nIf you are running more than one instance of a client it is the overall upload speed that you must take into account.\r\nSome clients (e.g. Azureus) limit global upload speed, others (e.g. Shad0w''s) do it on a per torrent basis.\r\nKnow your client. The same applies if you are using your connection for anything else (e.g. browsing or ftp),\r\nalways think of the overall upload speed.',1,6,2),
  (52,'item','Limit the number of simultaneous connections','Some operating systems (like Windows 9x) do not deal well with a large number of connections, and may even crash.\r\nAlso some home routers (particularly when running NAT and/or firewall with stateful inspection services) tend to become\r\nslow or crash when having to deal with too many connections. There are no fixed values for this, you may try 60 or 100\r\nand experiment with the value. Note that these numbers are additive, if you have two instances of\r\na client running the numbers add up.',1,6,3),
  (53,'item','Limit the number of simultaneous uploads','Isn''t this the same as above? No. Connections limit the number of peers your client is talking to and/or\r\ndownloading from. Uploads limit the number of peers your client is actually uploading to. The ideal number is\r\ntypically much lower than the number of connections, and highly dependent on your (physical) connection.',1,6,4),
  (54,'item','Just give it some time','As explained above peers favour other peers that upload to them. When you start leeching a new torrent you have\r\nnothing to offer to other peers and they will tend to ignore you. This makes the starts slow, in particular if,\r\nby change, the peers you are connected to include few or no seeders. The download speed should increase as soon\r\nas you have some pieces to share.',1,6,5),
  (55,'item','Why is my browsing so slow while leeching?','Your download speed is always finite. If you are a peer in a fast torrent it will almost certainly saturate your\r\ndownload bandwidth, and your browsing will suffer. At the moment there is no client that allows you to limit the\r\ndownload speed, only the upload. You will have to use a third-party solution,\r\nsuch as <a class=altlink href=\"redirector.php?url=http://www.netlimiter.com/\">NetLimiter</a>.<br>\r\n<br>\r\nBrowsing was used just as an example, the same would apply to gaming, IMing, etc...',1,6,6),
  (56,'item','What is a proxy?','Basically a middleman. When you are browsing a site through a proxy your requests are sent to the proxy and the proxy\r\nforwards them to the site instead of you connecting directly to the site. There are several classifications\r\n(the terminology is far from standard):<br>\r\n<br>\r\n\r\n\r\n<table cellspacing=3 cellpadding=0>\r\n <tr>\r\n    <td class=embedded valign=\"top\" bgcolor=\"#F5F4EA\" width=\"100\">&nbsp;Transparent</td>\r\n    <td class=embedded width=\"10\">&nbsp;</td>\r\n    <td class=embedded valign=\"top\">A transparent proxy is one that needs no configuration on the clients. It works by automatically redirecting all port 80 traffic to the proxy. (Sometimes used as synonymous for non-anonymous.)</td>\r\n </tr>\r\n <tr>\r\n    <td class=embedded valign=\"top\" bgcolor=\"#F5F4EA\">&nbsp;Explicit/Voluntary</td>\r\n    <td class=embedded width=\"10\">&nbsp;</td>\r\n    <td class=embedded valign=\"top\">Clients must configure their browsers to use them.</td>\r\n </tr>\r\n <tr>\r\n    <td class=embedded valign=\"top\" bgcolor=\"#F5F4EA\">&nbsp;Anonymous</td>\r\n    <td class=embedded width=\"10\">&nbsp;</td>\r\n    <td class=embedded valign=\"top\">The proxy sends no client identification to the server. (HTTP_X_FORWARDED_FOR header is not sent; the server does not see your IP.)</td>\r\n </tr>\r\n <tr>\r\n    <td class=embedded valign=\"top\" bgcolor=\"#F5F4EA\">&nbsp;Highly Anonymous</td>\r\n    <td class=embedded width=\"10\">&nbsp;</td>\r\n    <td class=embedded valign=\"top\">The proxy sends no client nor proxy identification to the server. (HTTP_X_FORWARDED_FOR, HTTP_VIA and HTTP_PROXY_CONNECTION headers are not sent; the server doesn''t see your IP and doesn''t even know you''re using a proxy.)</td>\r\n </tr>\r\n <tr>\r\n    <td class=embedded valign=\"top\" bgcolor=\"#F5F4EA\">&nbsp;Public</td>\r\n    <td class=embedded width=\"10\">&nbsp;</td>\r\n    <td class=embedded valign=\"top\">(Self explanatory)</td>\r\n </tr>\r\n</table>\r\n<br>\r\nA transparent proxy may or may not be anonymous, and there are several levels of anonymity.',1,7,1),
  (57,'item','How do I find out if I''m behind a (transparent/anonymous) proxy?','Try <a href=http://proxyjudge.org class=\"altlink\">ProxyJudge</a>. It lists the HTTP headers that the server where it is running\r\nreceived from you. The relevant ones are HTTP_CLIENT_IP, HTTP_X_FORWARDED_FOR and REMOTE_ADDR.<br>\r\n<br>\r\n<br>\r\n<b>Why is my port listed as \"---\" even though I''m not NAT/Firewalled?</b><a name=\"prox3\"></a><br>\r\n<br>\r\nThe TBDev Yuna Scatari Edition tracker is quite smart at finding your real IP, but it does need the proxy to send the HTTP header\r\nHTTP_X_FORWARDED_FOR. If your ISP''s proxy does not then what happens is that the tracker will interpret the proxy''s IP\r\naddress as the client''s IP address. So when you login and the tracker tries to connect to your client to see if you are\r\nNAT/firewalled it will actually try to connect to the proxy on the port your client reports to be using for\r\nincoming connections. Naturally the proxy will not be listening on that port, the connection will fail and the\r\ntracker will think you are NAT/firewalled.',1,7,2),
  (58,'item','Can I bypass my ISP''s proxy?','If your ISP only allows HTTP traffic through port 80 or blocks the usual proxy ports then you would need to use something\r\nlike <a href=http://www.socks.permeo.com>socks</a> and that is outside the scope of this FAQ.<br>\r\n<br>\r\nThe site accepts connections on port 81 besides the usual 80, and using them may be enough to fool some proxies. So the first\r\nthing to try should be connecting to www.templateshares.net:81. Note that even if this works your bt client will still try\r\nto connect to port 80 unless you edit the announce url in the .torrent file.<br>\r\n<br>\r\nOtherwise you may try the following:<br>\r\n<ul>\r\n    <li>Choose any public <b>non-anonymous</b> proxy that does <b>not</b> use port 80\r\n    (e.g. from <a href=http://tools.rosinstrument.com/proxy  class=\"altlink\">this</a>,\r\n    <a href=http://www.proxy4free.com/index.html  class=\"altlink\">this</a> or\r\n    <a href=http://www.samair.ru/proxy  class=\"altlink\">this</a> list).</li>\r\n\r\n    <li>Configure your computer to use that proxy. For Windows XP, do <i>Start</i>, <i>Control Panel</i>, <i>Internet Options</i>,\r\n    <i>Connections</i>, <i>LAN Settings</i>, <i>Use a Proxy server</i>, <i>Advanced</i> and type in the IP and port of your chosen\r\n    proxy. Or from Internet Explorer use <i>Tools</i>, <i>Internet Options</i>, ...<br></li>\r\n\r\n    <li>(Facultative) Visit <a href=http://proxyjudge.org  class=\"altlink\">ProxyJudge</a>. If you see an HTTP_X_FORWARDED_FOR in\r\n    the list followed by your IP then everything should be ok, otherwise choose another proxy and try again.<br></li>\r\n\r\n    <li>Visit Template Shares. Hopefully the tracker will now pickup your real IP (check your profile to make sure).</li>\r\n</ul>\r\n<br>\r\nNotice that now you will be doing all your browsing through a public proxy, which are typically quite slow.\r\nCommunications between peers do not use port 80 so their speed will not be affected by this, and should be better than when\r\nyou were \"unconnectable\".',1,7,3),
  (59,'item','How do I make my bittorrent client use a proxy?','Just configure Windows XP as above. When you configure a proxy for Internet Explorer you''re actually configuring a proxy for\r\nall HTTP traffic (thank Microsoft and their \"IE as part of the OS policy\" ). On the other hand if you use another\r\nbrowser (Opera/Mozilla/Firefox) and configure a proxy there you''ll be configuring a proxy just for that browser. We don''t\r\nknow of any BT client that allows a proxy to be specified explicitly.',1,7,4),
  (60,'item','Why can''t I signup from behind a proxy?','It is our policy not to allow new accounts to be opened from behind a proxy.',1,7,5),
  (61,'item','Does this apply to other torrent sites?','This section was written for Template Shares, a closed, port 80-81 tracker. Other trackers may be open or closed, and many listen\r\non e.g. ports 6868 or 6969. The above does <b>not</b> necessarily apply to other trackers.',1,7,6),
  (62,'item','Maybe my address is blacklisted?','The site blocks addresses listed in the (former) <a class=altlink href=\"http://methlabs.org/\">PeerGuardian</a>\r\ndatabase, as well as addresses of banned users. This works at Apache/PHP level, it''s just a script that\r\nblocks <i>logins</i> from those addresses. It should not stop you from reaching the site. In particular\r\nit does not block lower level protocols, you should be able to ping/traceroute the server even if your\r\naddress is blacklisted. If you cannot then the reason for the problem lies elsewhere.<br>\r\n<br>\r\nIf somehow your address is indeed blocked in the PG database do not contact us about it, it is not our\r\npolicy to open <i>ad hoc</i> exceptions. You should clear your IP with the database maintainers instead.',1,8,1),
  (63,'item','Your ISP blocks the site''s address','(In first place, it''s unlikely your ISP is doing so. DNS name resolution and/or network problems are the usual culprits.)\r\n<br>\r\nThere''s nothing we can do.\r\nYou should contact your ISP (or get a new one). Note that you can still visit the site via a proxy, follow the instructions\r\nin the relevant section. In this case it doesn''t matter if the proxy is anonymous or not, or which port it listens to.<br>\r\n<br>\r\nNotice that you will always be listed as an \"unconnectable\" client because the tracker will be unable to\r\ncheck that you''re capable of accepting incoming connections.',1,8,2),
  (64,'item','Alternate port (81)','Some of our torrents use ports other than the usual HTTP port 80. This may cause problems for some users,\r\nfor instance those behind some firewall or proxy configurations.\r\n\r\nYou can easily solve this by editing the .torrent file yourself with any torrent editor, e.g.\r\n<a href=\"http://sourceforge.net/projects/burst/\" class=\"altlink\">MakeTorrent</a>,\r\nand replacing the announce url bit-torrent.kiev.ua:81 with bit-torrent.kiev.ua:80 or just templateshares.net.<br>\r\n<br>\r\nEditing the .torrent with Notepad is not recommended. It may look like a text file, but it is in fact\r\na bencoded file. If for some reason you must use a plain text editor, change the announce url to\r\nbit-torrent.kiev.ua:80, not bit-torrent.kiev.ua. (If you''re thinking about changing the number before the\r\nannounce url instead, you know too much to be reading this.)',1,8,3),
  (65,'item','You can try these:','Post in the <a class=\"altlink\" href=\"forums.php\">Forums</a>, by all means. You''ll find they\r\nare usually a friendly and helpful place,\r\nprovided you follow a few basic guidelines:\r\n<ul>\r\n<li>Make sure your problem is not really in this FAQ. There''s no point in posting just to be sent\r\nback here.\r\n<li>Before posting read the sticky topics (the ones at the top). Many times new information that\r\nstill hasn''t been incorporated in the FAQ can be found there.</li>\r\n<li>Help us in helping you. Do not just say \"it doesn''t work!\". Provide details so that we don''t\r\nhave to guess or waste time asking. What client do you use? What''s your OS? What''s your network setup? What''s the exact\r\nerror message you get, if any? What are the torrents you are having problems with? The more\r\nyou tell the easiest it will be for us, and the more probable your post will get a reply.</li>\r\n<li>And needless to say: be polite. Demanding help rarely works, asking for it usually does\r\nthe trick.',1,9,1),
  (67,'item','What is the passkey System? How does it work? ','The passkey system has been implemented in order to substitute the ip checking system. This means that the tracker doesnt check anymore your logged ip in order to verify if you are logged in or registered with the tracker. Every user has a personal passkey, a random key generated by the system. When a user tries to download a torrent, its personal passkey is imprinted in the tracker url of the torrent, allowing to the tracker to identify any source connected on it. In this way, you can seed a torrent for example, at home and at your office simultaneously without any problem with the 2 different ips. Per torrent 3 simultaneous connections are permitted per user, and in case of leeching only 1 (That means you can leech a torrent from one location only at a time.',1,5,13),
  (68,'item','Why do i get a \"Unknown Passkey\" error? ','You will get this error, firstly if you are not registered on our tracker, or if you havent downloaded the torrent to use from our webpage, when you were logged in. In this case, just register or log in and redownload the torrent.\r\n\r\nThere is a chance to get this error also, at the first time you download anything as a new user, or at the first download after you reset your passkey. The reason is simply that the tracker reviews the changes in the passkeys every few minutes and not instantly. For that reason just leave the torrent running for a few minutes, and you will get eventually an OK message from the tracker.',1,5,14),
  (69,'item','When do i need to reset my passkey? ','<ul><li> If your passkey has been leeched and other user(s) uses it to download torrents using your account. In this case, you will see torrents stated in your account that you are not leeching or seeding .</li>\r\n<li> When your clients hangs up or your connection is terminated without pressing the stop button of your client. In this case, in your account you will see that you are still leeching/seeding the torrents even that your client has been closed. Normally these \"ghost peers\" will be cleaned automatically within 30 minutes, but if you want to resume your downloads and the tracker denied that due to the fact that you \"already are downloading the same torrents - Connection limit error\" then you should reset your passkey and redownload the torrent, then resume it. </li></ul>',1,5,15),
  (70,'item','What is DHT and Why must i turn it off?','DHT must be disabled in your client, DHT can cause your stats to be recorded incorrectly and could be seen as cheating also disable PEX (peer exchange) Anyone using this will be banned for cheating the system. Check your snatchlist regularly to ensure stats are being recorded correctly, allow 30mins for the tracker to update your stats. ',1,5,15),
  (71,'item','Recommended Clients','<b>Cross-Platform:</b><br>\r\nAzureus<br>\r\nBitTornado<br>\r\n<br>\r\n<b>Window Users:</b><br>\r\n�Torrent<br>\r\nABC<br>\r\n<br>\r\n<b>Mac Users:</b><br>\r\nTomato Torrent<br>\r\nBitRocket (lastest version)<br>\r\nrtorrent<br>\r\n<br>\r\n<b>Linux Users:</b><br>\r\nrtorrent<br>\r\nktorrent<br>\r\ndeluge<br>',1,1,4);

COMMIT;

#
# Data for the `mybb_adminoptions` table  (LIMIT 0,100)
#

INSERT INTO `mybb_adminoptions` (`uid`, `cpstyle`, `notes`, `permsset`, `caneditsettings`, `caneditann`, `caneditforums`, `canmodposts`, `caneditsmilies`, `caneditpicons`, `caneditthemes`, `canedittemps`, `caneditusers`, `caneditpfields`, `caneditugroups`, `caneditaperms`, `caneditutitles`, `caneditattach`, `canedithelp`, `caneditlangs`, `canrunmaint`, `canrundbtools`) VALUES
  (0,'','',1,'no','no','no','no','no','no','no','no','no','no','no','no','no','no','no','no','no','no'),
  (-4,'','',1,'yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','no','yes','yes','yes','yes','yes','no'),
  (1,'','',1,'yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes');

COMMIT;

#
# Data for the `mybb_attachtypes` table  (LIMIT 0,100)
#

INSERT INTO `mybb_attachtypes` (`atid`, `name`, `mimetype`, `extension`, `maxsize`, `icon`) VALUES
  (1,'Zip File','application/zip','zip',1024,'images/attachtypes/zip.gif'),
  (2,'JPEG Image','image/jpeg','jpg',500,'images/attachtypes/image.gif'),
  (3,'Text Document','text/plain','txt',200,'images/attachtypes/txt.gif'),
  (4,'GIF Image','image/gif','gif',500,'images/attachtypes/image.gif'),
  (6,'PHP File','application/octet-stream','php',500,'images/attachtypes/php.gif'),
  (7,'PNG Image','image/png','png',500,'images/attachtypes/image.gif'),
  (8,'Microsoft Word Document','application/msword','doc',1024,'images/attachtypes/doc.gif'),
  (9,'','application/octet-stream','htm',100,'images/attachtypes/html.gif'),
  (10,'','application/octet-stream','html',100,'images/attachtypes/html.gif'),
  (11,'','image/jpeg','jpeg',500,'images/attachtypes/image.gif'),
  (12,'','application/x-gzip','gz',1024,'images/attachtypes/tgz.gif'),
  (13,'','application/x-tar','tar',1024,'images/attachtypes/tar.gif'),
  (14,'','text/css','css',100,'images/attachtypes/css.gif'),
  (15,'','application/pdf','pdf',2048,'images/attachtypes/pdf.gif'),
  (16,'','image/bmp','bmp',500,'images/attachtypes/image.gif');

COMMIT;

#
# Data for the `mybb_datacache` table  (LIMIT 0,100)
#

INSERT INTO `mybb_datacache` (`title`, `cache`) VALUES
  ('version','a:2:{s:7:\"version\";s:5:\"1.2.7\";s:12:\"version_code\";i:127;}'),
  ('attachtypes','a:15:{s:3:\"zip\";a:6:{s:4:\"atid\";s:1:\"1\";s:4:\"name\";s:8:\"Zip File\";s:8:\"mimetype\";s:15:\"application/zip\";s:9:\"extension\";s:3:\"zip\";s:7:\"maxsize\";s:4:\"1024\";s:4:\"icon\";s:26:\"images/attachtypes/zip.gif\";}s:3:\"jpg\";a:6:{s:4:\"atid\";s:1:\"2\";s:4:\"name\";s:10:\"JPEG Image\";s:8:\"mimetype\";s:10:\"image/jpeg\";s:9:\"extension\";s:3:\"jpg\";s:7:\"maxsize\";s:3:\"500\";s:4:\"icon\";s:28:\"images/attachtypes/image.gif\";}s:3:\"txt\";a:6:{s:4:\"atid\";s:1:\"3\";s:4:\"name\";s:13:\"Text Document\";s:8:\"mimetype\";s:10:\"text/plain\";s:9:\"extension\";s:3:\"txt\";s:7:\"maxsize\";s:3:\"200\";s:4:\"icon\";s:26:\"images/attachtypes/txt.gif\";}s:3:\"gif\";a:6:{s:4:\"atid\";s:1:\"4\";s:4:\"name\";s:9:\"GIF Image\";s:8:\"mimetype\";s:9:\"image/gif\";s:9:\"extension\";s:3:\"gif\";s:7:\"maxsize\";s:3:\"500\";s:4:\"icon\";s:28:\"images/attachtypes/image.gif\";}s:3:\"php\";a:6:{s:4:\"atid\";s:1:\"6\";s:4:\"name\";s:8:\"PHP File\";s:8:\"mimetype\";s:24:\"application/octet-stream\";s:9:\"extension\";s:3:\"php\";s:7:\"maxsize\";s:3:\"500\";s:4:\"icon\";s:26:\"images/attachtypes/php.gif\";}s:3:\"png\";a:6:{s:4:\"atid\";s:1:\"7\";s:4:\"name\";s:9:\"PNG Image\";s:8:\"mimetype\";s:9:\"image/png\";s:9:\"extension\";s:3:\"png\";s:7:\"maxsize\";s:3:\"500\";s:4:\"icon\";s:28:\"images/attachtypes/image.gif\";}s:3:\"doc\";a:6:{s:4:\"atid\";s:1:\"8\";s:4:\"name\";s:23:\"Microsoft Word Document\";s:8:\"mimetype\";s:18:\"application/msword\";s:9:\"extension\";s:3:\"doc\";s:7:\"maxsize\";s:4:\"1024\";s:4:\"icon\";s:26:\"images/attachtypes/doc.gif\";}s:3:\"htm\";a:6:{s:4:\"atid\";s:1:\"9\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:24:\"application/octet-stream\";s:9:\"extension\";s:3:\"htm\";s:7:\"maxsize\";s:3:\"100\";s:4:\"icon\";s:27:\"images/attachtypes/html.gif\";}s:4:\"html\";a:6:{s:4:\"atid\";s:2:\"10\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:24:\"application/octet-stream\";s:9:\"extension\";s:4:\"html\";s:7:\"maxsize\";s:3:\"100\";s:4:\"icon\";s:27:\"images/attachtypes/html.gif\";}s:4:\"jpeg\";a:6:{s:4:\"atid\";s:2:\"11\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:10:\"image/jpeg\";s:9:\"extension\";s:4:\"jpeg\";s:7:\"maxsize\";s:3:\"500\";s:4:\"icon\";s:28:\"images/attachtypes/image.gif\";}s:2:\"gz\";a:6:{s:4:\"atid\";s:2:\"12\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:18:\"application/x-gzip\";s:9:\"extension\";s:2:\"gz\";s:7:\"maxsize\";s:4:\"1024\";s:4:\"icon\";s:26:\"images/attachtypes/tgz.gif\";}s:3:\"tar\";a:6:{s:4:\"atid\";s:2:\"13\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:17:\"application/x-tar\";s:9:\"extension\";s:3:\"tar\";s:7:\"maxsize\";s:4:\"1024\";s:4:\"icon\";s:26:\"images/attachtypes/tar.gif\";}s:3:\"css\";a:6:{s:4:\"atid\";s:2:\"14\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:8:\"text/css\";s:9:\"extension\";s:3:\"css\";s:7:\"maxsize\";s:3:\"100\";s:4:\"icon\";s:26:\"images/attachtypes/css.gif\";}s:3:\"pdf\";a:6:{s:4:\"atid\";s:2:\"15\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:15:\"application/pdf\";s:9:\"extension\";s:3:\"pdf\";s:7:\"maxsize\";s:4:\"2048\";s:4:\"icon\";s:26:\"images/attachtypes/pdf.gif\";}s:3:\"bmp\";a:6:{s:4:\"atid\";s:2:\"16\";s:4:\"name\";s:0:\"\";s:8:\"mimetype\";s:9:\"image/bmp\";s:9:\"extension\";s:3:\"bmp\";s:7:\"maxsize\";s:3:\"500\";s:4:\"icon\";s:28:\"images/attachtypes/image.gif\";}}'),
  ('smilies','a:9:{i:6;a:6:{s:3:\"sid\";s:1:\"6\";s:4:\"name\";s:8:\"Rolleyes\";s:4:\"find\";s:10:\":rolleyes:\";s:5:\"image\";s:27:\"images/smilies/rolleyes.gif\";s:9:\"disporder\";s:1:\"6\";s:13:\"showclickable\";s:3:\"yes\";}i:3;a:6:{s:3:\"sid\";s:1:\"3\";s:4:\"name\";s:4:\"Cool\";s:4:\"find\";s:6:\":cool:\";s:5:\"image\";s:23:\"images/smilies/cool.gif\";s:9:\"disporder\";s:1:\"3\";s:13:\"showclickable\";s:3:\"yes\";}i:7;a:6:{s:3:\"sid\";s:1:\"7\";s:4:\"name\";s:3:\"Shy\";s:4:\"find\";s:5:\":shy:\";s:5:\"image\";s:22:\"images/smilies/shy.gif\";s:9:\"disporder\";s:1:\"7\";s:13:\"showclickable\";s:3:\"yes\";}i:9;a:6:{s:3:\"sid\";s:1:\"9\";s:4:\"name\";s:2:\"At\";s:4:\"find\";s:4:\":at:\";s:5:\"image\";s:21:\"images/smilies/at.gif\";s:9:\"disporder\";s:1:\"9\";s:13:\"showclickable\";s:2:\"no\";}i:1;a:6:{s:3:\"sid\";s:1:\"1\";s:4:\"name\";s:5:\"Smile\";s:4:\"find\";s:2:\":)\";s:5:\"image\";s:24:\"images/smilies/smile.gif\";s:9:\"disporder\";s:1:\"1\";s:13:\"showclickable\";s:3:\"yes\";}i:2;a:6:{s:3:\"sid\";s:1:\"2\";s:4:\"name\";s:4:\"Wink\";s:4:\"find\";s:2:\";)\";s:5:\"image\";s:23:\"images/smilies/wink.gif\";s:9:\"disporder\";s:1:\"2\";s:13:\"showclickable\";s:3:\"yes\";}i:4;a:6:{s:3:\"sid\";s:1:\"4\";s:4:\"name\";s:8:\"Big Grin\";s:4:\"find\";s:2:\":D\";s:5:\"image\";s:26:\"images/smilies/biggrin.gif\";s:9:\"disporder\";s:1:\"4\";s:13:\"showclickable\";s:3:\"yes\";}i:5;a:6:{s:3:\"sid\";s:1:\"5\";s:4:\"name\";s:6:\"Tongue\";s:4:\"find\";s:2:\":P\";s:5:\"image\";s:25:\"images/smilies/tongue.gif\";s:9:\"disporder\";s:1:\"5\";s:13:\"showclickable\";s:3:\"yes\";}i:8;a:6:{s:3:\"sid\";s:1:\"8\";s:4:\"name\";s:3:\"Sad\";s:4:\"find\";s:2:\":(\";s:5:\"image\";s:22:\"images/smilies/sad.gif\";s:9:\"disporder\";s:1:\"8\";s:13:\"showclickable\";s:3:\"yes\";}}'),
  ('badwords','N;'),
  ('usergroups','a:7:{i:1;a:53:{s:3:\"gid\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:28:\"Unregistered / Not Logged In\";s:11:\"description\";s:0:\"\";s:9:\"namestyle\";s:10:\"{username}\";s:9:\"usertitle\";s:12:\"Unregistered\";s:5:\"stars\";s:1:\"0\";s:9:\"starimage\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:2:\"no\";s:7:\"canview\";s:3:\"yes\";s:14:\"canviewthreads\";s:3:\"yes\";s:15:\"canviewprofiles\";s:3:\"yes\";s:16:\"candlattachments\";s:2:\"no\";s:14:\"canpostthreads\";s:2:\"no\";s:13:\"canpostreplys\";s:2:\"no\";s:18:\"canpostattachments\";s:2:\"no\";s:14:\"canratethreads\";s:2:\"no\";s:12:\"caneditposts\";s:3:\"yes\";s:14:\"candeleteposts\";s:3:\"yes\";s:16:\"candeletethreads\";s:3:\"yes\";s:18:\"caneditattachments\";s:3:\"yes\";s:12:\"canpostpolls\";s:2:\"no\";s:12:\"canvotepolls\";s:2:\"no\";s:9:\"canusepms\";s:2:\"no\";s:10:\"cansendpms\";s:2:\"no\";s:11:\"cantrackpms\";s:2:\"no\";s:17:\"candenypmreceipts\";s:2:\"no\";s:7:\"pmquota\";s:1:\"0\";s:12:\"cansendemail\";s:2:\"no\";s:17:\"canviewmemberlist\";s:3:\"yes\";s:15:\"canviewcalendar\";s:3:\"yes\";s:18:\"canaddpublicevents\";s:3:\"yes\";s:19:\"canaddprivateevents\";s:2:\"no\";s:13:\"canviewonline\";s:3:\"yes\";s:15:\"canviewwolinvis\";s:2:\"no\";s:16:\"canviewonlineips\";s:2:\"no\";s:5:\"cancp\";s:2:\"no\";s:10:\"issupermod\";s:2:\"no\";s:9:\"cansearch\";s:3:\"yes\";s:9:\"canusercp\";s:2:\"no\";s:16:\"canuploadavatars\";s:2:\"no\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:2:\"no\";s:13:\"showforumteam\";s:0:\"\";s:19:\"usereputationsystem\";s:2:\"no\";s:18:\"cangivereputations\";s:2:\"no\";s:15:\"reputationpower\";s:1:\"0\";s:17:\"maxreputationsday\";s:1:\"0\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:0:\"\";}i:2;a:53:{s:3:\"gid\";s:1:\"2\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:10:\"Registered\";s:11:\"description\";s:0:\"\";s:9:\"namestyle\";s:10:\"{username}\";s:9:\"usertitle\";s:0:\"\";s:5:\"stars\";s:1:\"0\";s:9:\"starimage\";s:15:\"images/star.gif\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:2:\"no\";s:7:\"canview\";s:3:\"yes\";s:14:\"canviewthreads\";s:3:\"yes\";s:15:\"canviewprofiles\";s:3:\"yes\";s:16:\"candlattachments\";s:3:\"yes\";s:14:\"canpostthreads\";s:3:\"yes\";s:13:\"canpostreplys\";s:3:\"yes\";s:18:\"canpostattachments\";s:3:\"yes\";s:14:\"canratethreads\";s:3:\"yes\";s:12:\"caneditposts\";s:3:\"yes\";s:14:\"candeleteposts\";s:3:\"yes\";s:16:\"candeletethreads\";s:3:\"yes\";s:18:\"caneditattachments\";s:3:\"yes\";s:12:\"canpostpolls\";s:3:\"yes\";s:12:\"canvotepolls\";s:3:\"yes\";s:9:\"canusepms\";s:3:\"yes\";s:10:\"cansendpms\";s:3:\"yes\";s:11:\"cantrackpms\";s:3:\"yes\";s:17:\"candenypmreceipts\";s:3:\"yes\";s:7:\"pmquota\";s:1:\"0\";s:12:\"cansendemail\";s:3:\"yes\";s:17:\"canviewmemberlist\";s:3:\"yes\";s:15:\"canviewcalendar\";s:3:\"yes\";s:18:\"canaddpublicevents\";s:3:\"yes\";s:19:\"canaddprivateevents\";s:3:\"yes\";s:13:\"canviewonline\";s:3:\"yes\";s:15:\"canviewwolinvis\";s:2:\"no\";s:16:\"canviewonlineips\";s:2:\"no\";s:5:\"cancp\";s:2:\"no\";s:10:\"issupermod\";s:2:\"no\";s:9:\"cansearch\";s:3:\"yes\";s:9:\"canusercp\";s:3:\"yes\";s:16:\"canuploadavatars\";s:3:\"yes\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:2:\"no\";s:13:\"showforumteam\";s:2:\"no\";s:19:\"usereputationsystem\";s:3:\"yes\";s:18:\"cangivereputations\";s:3:\"yes\";s:15:\"reputationpower\";s:1:\"1\";s:17:\"maxreputationsday\";s:1:\"5\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:0:\"\";}i:3;a:53:{s:3:\"gid\";s:1:\"3\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:16:\"Super Moderators\";s:11:\"description\";s:35:\"These users can moderate any forum.\";s:9:\"namestyle\";s:64:\"<span style=\"color: #CC00CC;\"><strong>{username}</strong></span>\";s:9:\"usertitle\";s:15:\"Super Moderator\";s:5:\"stars\";s:1:\"6\";s:9:\"starimage\";s:15:\"images/star.gif\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:2:\"no\";s:7:\"canview\";s:3:\"yes\";s:14:\"canviewthreads\";s:3:\"yes\";s:15:\"canviewprofiles\";s:3:\"yes\";s:16:\"candlattachments\";s:3:\"yes\";s:14:\"canpostthreads\";s:3:\"yes\";s:13:\"canpostreplys\";s:3:\"yes\";s:18:\"canpostattachments\";s:3:\"yes\";s:14:\"canratethreads\";s:3:\"yes\";s:12:\"caneditposts\";s:3:\"yes\";s:14:\"candeleteposts\";s:3:\"yes\";s:16:\"candeletethreads\";s:3:\"yes\";s:18:\"caneditattachments\";s:3:\"yes\";s:12:\"canpostpolls\";s:3:\"yes\";s:12:\"canvotepolls\";s:3:\"yes\";s:9:\"canusepms\";s:3:\"yes\";s:10:\"cansendpms\";s:3:\"yes\";s:11:\"cantrackpms\";s:3:\"yes\";s:17:\"candenypmreceipts\";s:3:\"yes\";s:7:\"pmquota\";s:1:\"0\";s:12:\"cansendemail\";s:3:\"yes\";s:17:\"canviewmemberlist\";s:3:\"yes\";s:15:\"canviewcalendar\";s:3:\"yes\";s:18:\"canaddpublicevents\";s:3:\"yes\";s:19:\"canaddprivateevents\";s:3:\"yes\";s:13:\"canviewonline\";s:3:\"yes\";s:15:\"canviewwolinvis\";s:3:\"yes\";s:16:\"canviewonlineips\";s:3:\"yes\";s:5:\"cancp\";s:2:\"no\";s:10:\"issupermod\";s:3:\"yes\";s:9:\"cansearch\";s:3:\"yes\";s:9:\"canusercp\";s:3:\"yes\";s:16:\"canuploadavatars\";s:3:\"yes\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:3:\"yes\";s:13:\"showforumteam\";s:3:\"yes\";s:19:\"usereputationsystem\";s:3:\"yes\";s:18:\"cangivereputations\";s:3:\"yes\";s:15:\"reputationpower\";s:1:\"1\";s:17:\"maxreputationsday\";s:2:\"10\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:0:\"\";}i:4;a:53:{s:3:\"gid\";s:1:\"4\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:14:\"Administrators\";s:11:\"description\";s:39:\"The group all administrators belong to.\";s:9:\"namestyle\";s:71:\"<span style=\"color: green;\"><strong><em>{username}</em></strong></span>\";s:9:\"usertitle\";s:13:\"Administrator\";s:5:\"stars\";s:1:\"7\";s:9:\"starimage\";s:15:\"images/star.gif\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:2:\"no\";s:7:\"canview\";s:3:\"yes\";s:14:\"canviewthreads\";s:3:\"yes\";s:15:\"canviewprofiles\";s:3:\"yes\";s:16:\"candlattachments\";s:3:\"yes\";s:14:\"canpostthreads\";s:3:\"yes\";s:13:\"canpostreplys\";s:3:\"yes\";s:18:\"canpostattachments\";s:3:\"yes\";s:14:\"canratethreads\";s:3:\"yes\";s:12:\"caneditposts\";s:3:\"yes\";s:14:\"candeleteposts\";s:3:\"yes\";s:16:\"candeletethreads\";s:3:\"yes\";s:18:\"caneditattachments\";s:3:\"yes\";s:12:\"canpostpolls\";s:3:\"yes\";s:12:\"canvotepolls\";s:3:\"yes\";s:9:\"canusepms\";s:3:\"yes\";s:10:\"cansendpms\";s:3:\"yes\";s:11:\"cantrackpms\";s:3:\"yes\";s:17:\"candenypmreceipts\";s:3:\"yes\";s:7:\"pmquota\";s:1:\"0\";s:12:\"cansendemail\";s:3:\"yes\";s:17:\"canviewmemberlist\";s:3:\"yes\";s:15:\"canviewcalendar\";s:3:\"yes\";s:18:\"canaddpublicevents\";s:3:\"yes\";s:19:\"canaddprivateevents\";s:3:\"yes\";s:13:\"canviewonline\";s:3:\"yes\";s:15:\"canviewwolinvis\";s:3:\"yes\";s:16:\"canviewonlineips\";s:3:\"yes\";s:5:\"cancp\";s:3:\"yes\";s:10:\"issupermod\";s:3:\"yes\";s:9:\"cansearch\";s:3:\"yes\";s:9:\"canusercp\";s:3:\"yes\";s:16:\"canuploadavatars\";s:3:\"yes\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:3:\"yes\";s:13:\"showforumteam\";s:3:\"yes\";s:19:\"usereputationsystem\";s:3:\"yes\";s:18:\"cangivereputations\";s:3:\"yes\";s:15:\"reputationpower\";s:1:\"2\";s:17:\"maxreputationsday\";s:1:\"0\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:3:\"yes\";}i:5;a:53:{s:3:\"gid\";s:1:\"5\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:19:\"Awaiting Activation\";s:11:\"description\";s:57:\"Users that have not activated their account by email yet.\";s:9:\"namestyle\";s:10:\"{username}\";s:9:\"usertitle\";s:21:\"Account not Activated\";s:5:\"stars\";s:1:\"0\";s:9:\"starimage\";s:15:\"images/star.gif\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:2:\"no\";s:7:\"canview\";s:3:\"yes\";s:14:\"canviewthreads\";s:3:\"yes\";s:15:\"canviewprofiles\";s:3:\"yes\";s:16:\"candlattachments\";s:2:\"no\";s:14:\"canpostthreads\";s:2:\"no\";s:13:\"canpostreplys\";s:2:\"no\";s:18:\"canpostattachments\";s:2:\"no\";s:14:\"canratethreads\";s:2:\"no\";s:12:\"caneditposts\";s:2:\"no\";s:14:\"candeleteposts\";s:2:\"no\";s:16:\"candeletethreads\";s:2:\"no\";s:18:\"caneditattachments\";s:2:\"no\";s:12:\"canpostpolls\";s:2:\"no\";s:12:\"canvotepolls\";s:2:\"no\";s:9:\"canusepms\";s:2:\"no\";s:10:\"cansendpms\";s:2:\"no\";s:11:\"cantrackpms\";s:2:\"no\";s:17:\"candenypmreceipts\";s:2:\"no\";s:7:\"pmquota\";s:2:\"20\";s:12:\"cansendemail\";s:2:\"no\";s:17:\"canviewmemberlist\";s:3:\"yes\";s:15:\"canviewcalendar\";s:3:\"yes\";s:18:\"canaddpublicevents\";s:2:\"no\";s:19:\"canaddprivateevents\";s:2:\"no\";s:13:\"canviewonline\";s:3:\"yes\";s:15:\"canviewwolinvis\";s:2:\"no\";s:16:\"canviewonlineips\";s:2:\"no\";s:5:\"cancp\";s:2:\"no\";s:10:\"issupermod\";s:2:\"no\";s:9:\"cansearch\";s:3:\"yes\";s:9:\"canusercp\";s:3:\"yes\";s:16:\"canuploadavatars\";s:2:\"no\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:2:\"no\";s:13:\"showforumteam\";s:0:\"\";s:19:\"usereputationsystem\";s:2:\"no\";s:18:\"cangivereputations\";s:2:\"no\";s:15:\"reputationpower\";s:1:\"0\";s:17:\"maxreputationsday\";s:1:\"0\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:0:\"\";}i:6;a:53:{s:3:\"gid\";s:1:\"6\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:10:\"Moderators\";s:11:\"description\";s:37:\"These users moderate specific forums.\";s:9:\"namestyle\";s:64:\"<span style=\"color: #CC00CC;\"><strong>{username}</strong></span>\";s:9:\"usertitle\";s:9:\"Moderator\";s:5:\"stars\";s:1:\"5\";s:9:\"starimage\";s:15:\"images/star.gif\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:2:\"no\";s:7:\"canview\";s:3:\"yes\";s:14:\"canviewthreads\";s:3:\"yes\";s:15:\"canviewprofiles\";s:3:\"yes\";s:16:\"candlattachments\";s:3:\"yes\";s:14:\"canpostthreads\";s:3:\"yes\";s:13:\"canpostreplys\";s:3:\"yes\";s:18:\"canpostattachments\";s:3:\"yes\";s:14:\"canratethreads\";s:3:\"yes\";s:12:\"caneditposts\";s:3:\"yes\";s:14:\"candeleteposts\";s:3:\"yes\";s:16:\"candeletethreads\";s:3:\"yes\";s:18:\"caneditattachments\";s:3:\"yes\";s:12:\"canpostpolls\";s:3:\"yes\";s:12:\"canvotepolls\";s:3:\"yes\";s:9:\"canusepms\";s:3:\"yes\";s:10:\"cansendpms\";s:3:\"yes\";s:11:\"cantrackpms\";s:3:\"yes\";s:17:\"candenypmreceipts\";s:3:\"yes\";s:7:\"pmquota\";s:1:\"0\";s:12:\"cansendemail\";s:3:\"yes\";s:17:\"canviewmemberlist\";s:3:\"yes\";s:15:\"canviewcalendar\";s:3:\"yes\";s:18:\"canaddpublicevents\";s:2:\"no\";s:19:\"canaddprivateevents\";s:2:\"no\";s:13:\"canviewonline\";s:3:\"yes\";s:15:\"canviewwolinvis\";s:2:\"no\";s:16:\"canviewonlineips\";s:2:\"no\";s:5:\"cancp\";s:2:\"no\";s:10:\"issupermod\";s:2:\"no\";s:9:\"cansearch\";s:3:\"yes\";s:9:\"canusercp\";s:3:\"yes\";s:16:\"canuploadavatars\";s:3:\"yes\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:3:\"yes\";s:13:\"showforumteam\";s:3:\"yes\";s:19:\"usereputationsystem\";s:3:\"yes\";s:18:\"cangivereputations\";s:3:\"yes\";s:15:\"reputationpower\";s:1:\"1\";s:17:\"maxreputationsday\";s:2:\"10\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:0:\"\";}i:7;a:53:{s:3:\"gid\";s:1:\"7\";s:4:\"type\";s:1:\"1\";s:5:\"title\";s:6:\"Banned\";s:11:\"description\";s:46:\"This is for people who are a pain in the neck!\";s:9:\"namestyle\";s:17:\"<s>{username}</s>\";s:9:\"usertitle\";s:6:\"Banned\";s:5:\"stars\";s:1:\"0\";s:9:\"starimage\";s:15:\"images/star.gif\";s:5:\"image\";s:0:\"\";s:9:\"disporder\";s:1:\"0\";s:13:\"isbannedgroup\";s:3:\"yes\";s:7:\"canview\";s:2:\"no\";s:14:\"canviewthreads\";s:2:\"no\";s:15:\"canviewprofiles\";s:2:\"no\";s:16:\"candlattachments\";s:2:\"no\";s:14:\"canpostthreads\";s:2:\"no\";s:13:\"canpostreplys\";s:2:\"no\";s:18:\"canpostattachments\";s:2:\"no\";s:14:\"canratethreads\";s:2:\"no\";s:12:\"caneditposts\";s:2:\"no\";s:14:\"candeleteposts\";s:2:\"no\";s:16:\"candeletethreads\";s:2:\"no\";s:18:\"caneditattachments\";s:2:\"no\";s:12:\"canpostpolls\";s:2:\"no\";s:12:\"canvotepolls\";s:2:\"no\";s:9:\"canusepms\";s:3:\"yes\";s:10:\"cansendpms\";s:2:\"no\";s:11:\"cantrackpms\";s:2:\"no\";s:17:\"candenypmreceipts\";s:2:\"no\";s:7:\"pmquota\";s:1:\"0\";s:12:\"cansendemail\";s:2:\"no\";s:17:\"canviewmemberlist\";s:2:\"no\";s:15:\"canviewcalendar\";s:2:\"no\";s:18:\"canaddpublicevents\";s:2:\"no\";s:19:\"canaddprivateevents\";s:2:\"no\";s:13:\"canviewonline\";s:2:\"no\";s:15:\"canviewwolinvis\";s:2:\"no\";s:16:\"canviewonlineips\";s:2:\"no\";s:5:\"cancp\";s:2:\"no\";s:10:\"issupermod\";s:2:\"no\";s:9:\"cansearch\";s:2:\"no\";s:9:\"canusercp\";s:2:\"no\";s:16:\"canuploadavatars\";s:2:\"no\";s:14:\"canratemembers\";s:0:\"\";s:13:\"canchangename\";s:2:\"no\";s:13:\"showforumteam\";s:2:\"no\";s:19:\"usereputationsystem\";s:2:\"no\";s:18:\"cangivereputations\";s:2:\"no\";s:15:\"reputationpower\";s:1:\"0\";s:17:\"maxreputationsday\";s:1:\"0\";s:15:\"candisplaygroup\";s:3:\"yes\";s:11:\"attachquota\";s:1:\"0\";s:14:\"cancustomtitle\";s:0:\"\";}}'),
  ('stats','a:5:{s:10:\"numthreads\";s:1:\"0\";s:8:\"numposts\";s:1:\"0\";s:8:\"numusers\";s:1:\"0\";s:7:\"lastuid\";s:1:\"0\";s:12:\"lastusername\";s:0:\"\";}'),
  ('moderators','a:2:{i:1;s:0:\"\";i:2;s:0:\"\";}'),
  ('forums','a:2:{i:1;a:35:{s:3:\"fid\";s:1:\"1\";s:4:\"name\";s:11:\"My Category\";s:11:\"description\";s:0:\"\";s:6:\"linkto\";s:0:\"\";s:4:\"type\";s:1:\"c\";s:3:\"pid\";s:1:\"0\";s:10:\"parentlist\";s:1:\"1\";s:9:\"disporder\";s:1:\"1\";s:6:\"active\";s:3:\"yes\";s:4:\"open\";s:3:\"yes\";s:13:\"lastposteruid\";s:1:\"0\";s:15:\"lastpostsubject\";s:0:\"\";s:9:\"allowhtml\";s:2:\"no\";s:11:\"allowmycode\";s:3:\"yes\";s:12:\"allowsmilies\";s:3:\"yes\";s:12:\"allowimgcode\";s:3:\"yes\";s:11:\"allowpicons\";s:3:\"yes\";s:13:\"allowtratings\";s:3:\"yes\";s:6:\"status\";s:1:\"1\";s:13:\"usepostcounts\";s:3:\"yes\";s:8:\"password\";s:0:\"\";s:10:\"showinjump\";s:3:\"yes\";s:8:\"modposts\";s:2:\"no\";s:10:\"modthreads\";s:2:\"no\";s:14:\"modattachments\";s:2:\"no\";s:5:\"style\";s:1:\"0\";s:13:\"overridestyle\";s:2:\"no\";s:9:\"rulestype\";s:1:\"0\";s:10:\"rulestitle\";s:0:\"\";s:5:\"rules\";s:0:\"\";s:17:\"unapprovedthreads\";s:1:\"0\";s:15:\"unapprovedposts\";s:1:\"0\";s:14:\"defaultdatecut\";s:1:\"0\";s:13:\"defaultsortby\";s:0:\"\";s:16:\"defaultsortorder\";s:0:\"\";}i:2;a:35:{s:3:\"fid\";s:1:\"2\";s:4:\"name\";s:8:\"My Forum\";s:11:\"description\";s:0:\"\";s:6:\"linkto\";s:0:\"\";s:4:\"type\";s:1:\"f\";s:3:\"pid\";s:1:\"1\";s:10:\"parentlist\";s:3:\"1,2\";s:9:\"disporder\";s:1:\"1\";s:6:\"active\";s:3:\"yes\";s:4:\"open\";s:3:\"yes\";s:13:\"lastposteruid\";s:0:\"\";s:15:\"lastpostsubject\";s:0:\"\";s:9:\"allowhtml\";s:2:\"no\";s:11:\"allowmycode\";s:3:\"yes\";s:12:\"allowsmilies\";s:3:\"yes\";s:12:\"allowimgcode\";s:3:\"yes\";s:11:\"allowpicons\";s:3:\"yes\";s:13:\"allowtratings\";s:3:\"yes\";s:6:\"status\";s:1:\"1\";s:13:\"usepostcounts\";s:3:\"yes\";s:8:\"password\";s:0:\"\";s:10:\"showinjump\";s:3:\"yes\";s:8:\"modposts\";s:2:\"no\";s:10:\"modthreads\";s:2:\"no\";s:14:\"modattachments\";s:2:\"no\";s:5:\"style\";s:1:\"0\";s:13:\"overridestyle\";s:2:\"no\";s:9:\"rulestype\";s:1:\"0\";s:10:\"rulestitle\";s:0:\"\";s:5:\"rules\";s:0:\"\";s:17:\"unapprovedthreads\";s:1:\"0\";s:15:\"unapprovedposts\";s:1:\"0\";s:14:\"defaultdatecut\";s:1:\"0\";s:13:\"defaultsortby\";s:0:\"\";s:16:\"defaultsortorder\";s:0:\"\";}}'),
  ('usertitles','a:5:{i:0;a:5:{s:4:\"utid\";s:1:\"5\";s:5:\"posts\";s:3:\"750\";s:5:\"title\";s:13:\"Posting Freak\";s:5:\"stars\";s:1:\"5\";s:9:\"starimage\";s:0:\"\";}i:1;a:5:{s:4:\"utid\";s:1:\"4\";s:5:\"posts\";s:3:\"250\";s:5:\"title\";s:13:\"Senior Member\";s:5:\"stars\";s:1:\"4\";s:9:\"starimage\";s:0:\"\";}i:2;a:5:{s:4:\"utid\";s:1:\"3\";s:5:\"posts\";s:2:\"50\";s:5:\"title\";s:6:\"Member\";s:5:\"stars\";s:1:\"3\";s:9:\"starimage\";s:0:\"\";}i:3;a:5:{s:4:\"utid\";s:1:\"2\";s:5:\"posts\";s:1:\"1\";s:5:\"title\";s:13:\"Junior Member\";s:5:\"stars\";s:1:\"2\";s:9:\"starimage\";s:0:\"\";}i:4;a:5:{s:4:\"utid\";s:1:\"1\";s:5:\"posts\";s:1:\"0\";s:5:\"title\";s:6:\"Newbie\";s:5:\"stars\";s:1:\"1\";s:9:\"starimage\";s:0:\"\";}}'),
  ('reportedposts','a:3:{s:6:\"unread\";s:1:\"0\";s:5:\"total\";s:1:\"0\";s:12:\"lastdateline\";N;}'),
  ('mycode','N;'),
  ('posticons','a:12:{i:1;a:3:{s:3:\"iid\";s:1:\"1\";s:4:\"name\";s:4:\"MyBB\";s:4:\"path\";s:19:\"images/icons/my.gif\";}i:2;a:3:{s:3:\"iid\";s:1:\"2\";s:4:\"name\";s:11:\"Exclamation\";s:4:\"path\";s:28:\"images/icons/exclamation.gif\";}i:3;a:3:{s:3:\"iid\";s:1:\"3\";s:4:\"name\";s:8:\"Question\";s:4:\"path\";s:25:\"images/icons/question.gif\";}i:4;a:3:{s:3:\"iid\";s:1:\"4\";s:4:\"name\";s:5:\"Smile\";s:4:\"path\";s:22:\"images/icons/smile.gif\";}i:5;a:3:{s:3:\"iid\";s:1:\"5\";s:4:\"name\";s:3:\"Sad\";s:4:\"path\";s:20:\"images/icons/sad.gif\";}i:6;a:3:{s:3:\"iid\";s:1:\"6\";s:4:\"name\";s:4:\"Wink\";s:4:\"path\";s:21:\"images/icons/wink.gif\";}i:7;a:3:{s:3:\"iid\";s:1:\"7\";s:4:\"name\";s:4:\"Cool\";s:4:\"path\";s:21:\"images/icons/cool.gif\";}i:8;a:3:{s:3:\"iid\";s:1:\"8\";s:4:\"name\";s:8:\"Big Grin\";s:4:\"path\";s:24:\"images/icons/biggrin.gif\";}i:9;a:3:{s:3:\"iid\";s:1:\"9\";s:4:\"name\";s:7:\"Toungue\";s:4:\"path\";s:23:\"images/icons/tongue.gif\";}i:10;a:3:{s:3:\"iid\";s:2:\"10\";s:4:\"name\";s:8:\"Rolleyes\";s:4:\"path\";s:25:\"images/icons/rolleyes.gif\";}i:11;a:3:{s:3:\"iid\";s:2:\"11\";s:4:\"name\";s:3:\"Shy\";s:4:\"path\";s:20:\"images/icons/shy.gif\";}i:16;a:3:{s:3:\"iid\";s:2:\"16\";s:4:\"name\";s:2:\"At\";s:4:\"path\";s:19:\"images/icons/at.gif\";}}'),
  ('update_check','a:1:{s:10:\"last_check\";i:1179356973;}'),
  ('mostonline','a:2:{s:8:\"numusers\";i:0;s:4:\"time\";i:0;}'),
  ('plugins','a:1:{s:6:\"active\";a:3:{s:12:\"autosetbburl\";s:12:\"autosetbburl\";s:14:\"autosetcookies\";s:14:\"autosetcookies\";s:10:\"colornotes\";s:10:\"colornotes\";}}'),
  ('forumpermissions','N;'),
  ('mailqueue','a:2:{s:10:\"queue_size\";s:1:\"0\";s:6:\"locked\";i:0;}');

COMMIT;

#
# Data for the `mybb_forums` table  (LIMIT 0,100)
#

INSERT INTO `mybb_forums` (`fid`, `name`, `description`, `linkto`, `type`, `pid`, `parentlist`, `disporder`, `active`, `open`, `threads`, `posts`, `lastpost`, `lastposter`, `lastposteruid`, `lastposttid`, `lastpostsubject`, `allowhtml`, `allowmycode`, `allowsmilies`, `allowimgcode`, `allowpicons`, `allowtratings`, `status`, `usepostcounts`, `password`, `showinjump`, `modposts`, `modthreads`, `modattachments`, `style`, `overridestyle`, `rulestype`, `rulestitle`, `rules`, `unapprovedthreads`, `unapprovedposts`, `defaultdatecut`, `defaultsortby`, `defaultsortorder`) VALUES
  (1,'My Category','','','c',0,'1',1,'yes','yes',0,0,0,'0',0,0,'','no','yes','yes','yes','yes','yes',1,'yes','','yes','no','no','no',0,'no',0,'','',0,0,0,'',''),
  (2,'My Forum','','','f',1,'1,2',1,'yes','yes',1,3,0,'',0,0,'','no','yes','yes','yes','yes','yes',1,'yes','','yes','no','no','no',0,'no',0,'','',0,0,0,'','');

COMMIT;

#
# Data for the `mybb_helpdocs` table  (LIMIT 0,100)
#

INSERT INTO `mybb_helpdocs` (`hid`, `sid`, `name`, `description`, `document`, `usetranslation`, `enabled`, `disporder`) VALUES
  (1,1,'User Registration','Perks and privileges to user registration.','Some parts of this forum may require you to be logged in and registered. Registration is free and takes a few minutes to complete.<br />\r\n<br />\r\nYou are encouraged to register; once you register you will be able to post messages, set your own preferences, and maintain a profile.<br />\r\n<br />\r\nSome of the features that generally require registration are subscriptions, favorites, changing of styles, accessing of your myPad (simple notepad) and emailing forum members.','yes','yes',1),
  (2,1,'Updating Profile','Changing your data currently on record.','At some point during your stay, you may decide you need to update some information such as your instant messenger information, your password, or perhaps you need to change your email address. You may change any of this information from your user control panel. To access this control panel, simply click on the link in the upper right hand corner of most any page entitled \"user cp\". From there, simply choose \"Edit Profile\" and change or update any desired items, then proceed to click the submit button located at the bottom of the page for changes to take effect.','yes','yes',2),
  (3,1,'Use of Cookies on myBB','myBB uses cookies to store certain information about your registration.','myBulletinBoard makes use of cookies to store your login information if you are registered, and your last visit if you are not.<br />\r\n<br />\r\nCookies are small text documents stored on your computer; the cookies set by this forum can only be used on this website and pose no security risk.<br />\r\n<br />\r\nCookies on this forum also track the specific topics you have read and when you last read them.<br />\r\n<br />\r\nTo clear all cookies set by this forum, you can click <a href=\"misc.php?action=clearcookies\">here</a>.','yes','yes',3),
  (4,1,'Logging In and Out','How to login and logout.','When you login, you set a cookie on your machine so that you can browse the forums without having to enter in your username and password each time. Logging out clears that cookie to ensure nobody else can browse the forum as you.<br />\r\n<br />\r\nTo login, simply click the login link at the top right hand corner of the forum. To logout, click the logout link in the same place. In the event you cannot logout, clearing cookies on your machine will take the same effect.','yes','yes',4),
  (5,2,'Posting a New Topic','Starting a new thread in a forum.','When you go to a forum you are interested in and you wish to create a new topic (or thread), simply choose the button at the top and bottom of the forums entitled \"New topic\". Please take note that you may not have permission to post a new topic in every forum as your administrator may have restricted posting in that forum to staff or archived the forum entirely.','yes','yes',1),
  (6,2,'Posting a Reply','Replying to a topic within a forum.','During the course of your visit, you may encounter a thread to which you would like to make a reply. To do so, simply click the \"Post reply\" button at the bottom or top of the thread. Please take note that your administrator may have restricted posting to certain individuals in that particular forum.<br />\r\n<br />\r\nAdditionally, a moderator of a forum may have closed a thread meaning that users cannot reply to it. There is no way for a user to open such a thread without the help of a moderator or administrator.','yes','yes',2),
  (7,2,'myCode','Learn how to use myCode to enhance your posts.','You can use myCode, a simplified version of HTML, in your posts to create certain effects.\r\n<p><br />\r\n[b]This text is bold[/b]<br />\r\n&nbsp;&nbsp;&nbsp;<b>This text is bold</b>\r\n<p>\r\n[i]This text is italicized[/i]<br />\r\n&nbsp;&nbsp;&nbsp;<i>This text is italicized</i>\r\n<p>\r\n[u]This text is underlined[/u]<br />\r\n&nbsp;&nbsp;&nbsp;<u>This text is underlined</u>\r\n<p><br />\r\n[url]http://www.example.com/[/url]<br />\r\n&nbsp;&nbsp;&nbsp;<a href=\"http://www.example.com/\">http://www.example.com/</a>\r\n<p>\r\n[url=http://www.example.com/]Example.com[/url]<br />\r\n&nbsp;&nbsp;&nbsp;<a href=\"http://www.example.com/\">Example.com</a>\r\n<p>\r\n[email]example@example.com[/email]<br />\r\n&nbsp;&nbsp;&nbsp;<a href=\"mailto:example@example.com\">example@example.com</a>\r\n<p>\r\n[email=example@example.com]E-mail Me![/email]<br />\r\n&nbsp;&nbsp;&nbsp;<a href=\"mailto:example@example.com\">E-mail Me!</a>\r\n<p>\r\n[email=example@example.com?subject=spam]E-mail with subject[/email]<br />\r\n&nbsp;&nbsp;&nbsp;<a href=\"mailto:example@example.com?subject=spam\">E-mail with subject</a>\r\n<p><br />\r\n[quote]Quoted text will be here[/quote]<br />\r\n&nbsp;&nbsp;&nbsp;<quote>Quoted text will be here</quote>\r\n<p>\r\n[code]Text with preserved formatting[/code]<br />\r\n&nbsp;&nbsp;&nbsp;<code>Text with preserved formatting</code>\r\n<p><br />\r\n[img]http://www.php.net/images/php.gif[/img]<br />\r\n&nbsp;&nbsp;&nbsp;<img src=\"http://www.php.net/images/php.gif\">\r\n<p>\r\n[img=50x50]http://www.php.net/images/php.gif[/img]<br />\r\n&nbsp;&nbsp;&nbsp;<img src=\"http://www.php.net/images/php.gif\" width=\"50\" height=\"50\">\r\n<p><br />\r\n[color=red]This text is red[/color]<br />\r\n&nbsp;&nbsp;&nbsp;<font color=\"red\">This text is red</font>\r\n<p>\r\n[size=3]This text is size 3[/size]<br />\r\n&nbsp;&nbsp;&nbsp;<font size=\"3\">This text is size 3</font>\r\n<p>\r\n[font=Tahoma]This font is Tahoma[/font]<br />\r\n&nbsp;&nbsp;&nbsp;<font face=\"Tahoma\">This font is Tahoma</font>\r\n<p><br />\r\n[align=center]This is centered[/align]<div align=\"center\">This is centered</div>\r\n<p>\r\n[align=right]This is right-aligned[/align]<div align=\"right\">This is right-aligned</div>\r\n<p><br />\r\n[list]<br />\r\n[*]List Item #1<br />\r\n[*]List Item #2<br />\r\n[*]List Item #3<br />\r\n[/list]<br />\r\n<ul>\r\n<li>List item #1</li>\r\n<li>List item #2</li>\r\n<li>List Item #3</li>\r\n</ul><p><font size=1>You can make an ordered list by using [list=1] for a numbered, and [list=a] for an alphabetical list.</size>','yes','yes',3);

COMMIT;

#
# Data for the `mybb_helpsections` table  (LIMIT 0,100)
#

INSERT INTO `mybb_helpsections` (`sid`, `name`, `description`, `usetranslation`, `enabled`, `disporder`) VALUES
  (1,'User Maintenance','Basic instructions for maintaining a forum account.','yes','yes',1),
  (2,'Posting','Posting, replying, and basic usage of forum.','yes','yes',2);

COMMIT;

#
# Data for the `mybb_icons` table  (LIMIT 0,100)
#

INSERT INTO `mybb_icons` (`iid`, `name`, `path`) VALUES
  (1,'MyBB','images/icons/my.gif'),
  (2,'Exclamation','images/icons/exclamation.gif'),
  (3,'Question','images/icons/question.gif'),
  (4,'Smile','images/icons/smile.gif'),
  (5,'Sad','images/icons/sad.gif'),
  (6,'Wink','images/icons/wink.gif'),
  (7,'Cool','images/icons/cool.gif'),
  (8,'Big Grin','images/icons/biggrin.gif'),
  (9,'Toungue','images/icons/tongue.gif'),
  (10,'Rolleyes','images/icons/rolleyes.gif'),
  (11,'Shy','images/icons/shy.gif'),
  (16,'At','images/icons/at.gif');

COMMIT;

#
# Data for the `mybb_profilefields` table  (LIMIT 0,100)
#

INSERT INTO `mybb_profilefields` (`fid`, `name`, `description`, `disporder`, `type`, `length`, `maxlength`, `required`, `editable`, `hidden`) VALUES
  (1,'Location','Where in the world do you live?',1,'text',0,255,'no','yes','no'),
  (2,'Bio','Enter a few short details about yourself, your life story etc.',2,'textarea',0,0,'no','yes','no'),
  (3,'Sex','Please select your sex from the list below.',0,'select\nUndisclosed\nMale\nFemale\nOther',0,0,'no','yes','no');

COMMIT;

#
# Data for the `mybb_settinggroups` table  (LIMIT 0,100)
#

INSERT INTO `mybb_settinggroups` (`gid`, `name`, `title`, `description`, `disporder`, `isdefault`) VALUES
  (1,'banning','Banning Options','',15,'yes'),
  (2,'onlineoffline','Board Online / Offline','These settings allow you to globally turn your forums online or offline, and allow you to specify a reason for turning them off.',1,'yes'),
  (3,'calendar','Calendar','The board calendar allows the public and private listing of events and members'' birthdays. This section allows you to control and manage the settings for the Calendar.',12,'yes'),
  (4,'clickablecode','Clickable Smilies and BB Code','',17,'yes'),
  (5,'cpprefs','Control Panel Preferences (Global)','',19,'yes'),
  (6,'datetime','Date and Time Formats','Here you can specify the different date and time formats used to display dates and times on the forums.',4,'yes'),
  (7,'forumdisplay','Forum Display Options','This section allows you to manage the various settings used on the forum display (forumdisplay.php) of your boards such as enabling and disabling different features.',6,'yes'),
  (8,'forumhome','Forum Home Options','This section allows you to manage the various settings used on the forum home (index.php) of your boards such as enabling and disabling different features.',5,'yes'),
  (9,'general','General Configuration','This section contains various settings such as your board name and url, as well as your website name and url.',2,'yes'),
  (10,'memberlist','Member List','This section allows you to control various aspects of the board member listing (memberlist.php), such as how many members to show per page, and which features to enable or disable.',10,'yes'),
  (11,'portal','Portal Settings','',14,'yes'),
  (12,'posting','Posting','These options control the various elements in relation to posting messages on the forums.',9,'yes'),
  (13,'reputation','Reputation','',10,'yes'),
  (14,'privatemessaging','Private Messaging','Various options with relation to the MyBB Private Messaging system (private.php) can be managed and set here.',11,'yes'),
  (15,'server','Server and Optimization Options','These options allow you to set various server and optimization preferences allowing you to reduce the load on your server, and gain better performance on your board.',3,'yes'),
  (16,'showteam','Show Forum Team Options','This section allows you to manage settings that affect the Forum Team Page (showteam.php).',10,'yes'),
  (17,'showthread','Show Thread Options','This section allows you to manage the various settings used on the thread display page (showthread.php) of your boards such as enabling and disabling different features.',7,'yes'),
  (18,'member','User Registration and Profile Options','Here you can control various settings with relation to user account registration and account management.',8,'yes'),
  (19,'whosonline','Who''s Online','Various settings regarding the Who is Online functionality.',13,'yes'),
  (20,'search','Search System','The various settings in this group allow you to make changes to the built in search mechanism for threads and posts in MyBB,',14,'yes');

COMMIT;

#
# Data for the `mybb_settings` table  (LIMIT 0,100)
#

INSERT INTO `mybb_settings` (`sid`, `name`, `title`, `description`, `optionscode`, `value`, `disporder`, `gid`) VALUES
  (1,'bannedusernames','Banned Usernames','Ban users from registering certain usernames. You must seperate usernames with a comma.','textarea','',1,1),
  (2,'bannedips','Ban by IP','Here, you may specify IP addresses or a range of IP addresses. You must separate each IP with a comma.','textarea','',2,1),
  (3,'bannedemails','Ban by Email','You may specify specific email addresses to ban, or you may specify a domain. You must separate email addresses and domains with a comma.','textarea','',3,1),
  (4,'emailkeep','Users Keep Email','If a current user has an email already registered in your banned list, should he be allowed to keep it.','yesno','no',4,1),
  (5,'boardclosed','Board Closed','If you need to close your forums to make some changes or perform an upgrade, this is the global switch. Viewers will not be able to view your forums, however, they will see a message with the reason you specify below.<br />\r\n<br />\r\n<b>Administrators will still be able to view the forums.</b>','yesno','no',1,2),
  (6,'boardclosed_reason','Board Closed Reason','If your forum is closed, you can set a message here that your visitors will be able to see when they visit your forums.','textarea','These forums are currently closed for maintenance. Please check back later.',2,2),
  (7,'enablecalendar','Enable Calendar Functionality','If you wish to disable the calendar on your board, set this option to no.','yesno','yes',1,3),
  (8,'publiceventcolor','Public Events Color','The color that public events will be shown in on the main calendar page.','text','green',2,3),
  (9,'privateeventcolor','Private Events Color','The color that private events will be shown in on the main calendar page.','text','red',3,3),
  (10,'smilieinserter','Clickable Smilies Inserter','Clickable smilies will appear on the posting pages if this option is set to ''on''.','onoff','on',1,4),
  (11,'smilieinsertertot','No. of Smilies to show','Enter the total number of smilies to show on the clickable smilie inserter.','text','20',2,4),
  (12,'smilieinsertercols','No. of Smilie Cols to Show','Enter the number of columns you wish to show on the clickable smilie inserter.','text','4',3,4),
  (13,'cplanguage','Control Panel Language','The language of the control panel.','adminlanguage','english',1,5),
  (14,'cpstyle','Control Panel Style','The Default style that the control panel will use. Styles are inside the styles folder. A folder name inside that folder becomes the style title and style.css inside the style title folder is the css style file.','cpstyle','Axiom',2,5),
  (15,'dateformat','Date Format','The format of the dates used on the forum. This format uses the PHP date() function. We recommend not changing this unless you know what you''re doing.','text','m-d-Y',1,6),
  (16,'timeformat','Time Format','The format of the times used on the forum. This format uses PHP''s date() function. We recommend not changing this unless you know what you''re doing.','text','h:i A',2,6),
  (17,'regdateformat','Registered Date Format','The format used on showthread where it shows when the user registered.','text','M Y',3,6),
  (18,'timezoneoffset','Default Timezone Offset','Here you can set the default timezone offset for guests and members using the default offset.','php\r\n<select name=\\\"upsetting[{$setting[''sid'']}]\\\">\r\n<option value=\\\"-12\\\" \".($setting[''value''] == -12?\"selected=\\\"selected\\\"\":\"\").\">GMT -12:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -12).\")</option>\r\n<option value=\\\"-11\\\" \".($setting[''value''] == -11?\"selected=\\\"selected\\\"\":\"\").\">GMT -11:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -11).\")</option>\r\n<option value=\\\"-10\\\" \".($setting[''value''] == -10?\"selected=\\\"selected\\\"\":\"\").\">GMT -10:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -10).\")</option>\r\n<option value=\\\"-9\\\" \".($setting[''value''] == -9?\"selected=\\\"selected\\\"\":\"\").\">GMT -9:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -9).\")</option>\r\n<option value=\\\"-8\\\" \".($setting[''value''] == -8?\"selected=\\\"selected\\\"\":\"\").\">GMT -8:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -8).\")</option>\r\n<option value=\\\"-7\\\" \".($setting[''value''] == -7?\"selected=\\\"selected\\\"\":\"\").\">GMT -7:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -7).\")</option>\r\n<option value=\\\"-6\\\" \".($setting[''value''] == -6?\"selected=\\\"selected\\\"\":\"\").\">GMT -6:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -6).\")</option>\r\n<option value=\\\"-5\\\" \".($setting[''value''] == -5?\"selected=\\\"selected\\\"\":\"\").\">GMT -5:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -5).\")</option>\r\n<option value=\\\"-4\\\" \".($setting[''value''] == -4?\"selected=\\\"selected\\\"\":\"\").\">GMT -4:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -4).\")</option>\r\n<option value=\\\"-3.5\\\" \".($setting[''value''] == -3.5?\"selected=\\\"selected\\\"\":\"\").\">GMT -3:30 Hours (\".my_date($mybb->settings[''timeformat''], time(), -3.5).\")</option>\r\n<option value=\\\"-3\\\" \".($setting[''value''] == -3?\"selected=\\\"selected\\\"\":\"\").\">GMT -3:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -3).\")</option>\r\n<option value=\\\"-2\\\" \".($setting[''value''] == -2?\"selected=\\\"selected\\\"\":\"\").\">GMT -2:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -2).\")</option>\r\n<option value=\\\"-1\\\" \".($setting[''value''] == -1?\"selected=\\\"selected\\\"\":\"\").\">GMT -1:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), -1).\")</option>\r\n<option value=\\\"0\\\" \".($setting[''value''] == 0?\"selected=\\\"selected\\\"\":\"\").\">GMT (\".my_date($mybb->settings[''timeformat''], time(), 0).\")</option>\r\n<option value=\\\"+1\\\" \".($setting[''value''] == 1?\"selected=\\\"selected\\\"\":\"\").\">GMT +1:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 1).\")</option>\r\n<option value=\\\"+2\\\" \".($setting[''value''] == 2?\"selected=\\\"selected\\\"\":\"\").\">GMT +2:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 2).\")</option>\r\n<option value=\\\"+3\\\" \".($setting[''value''] == 3?\"selected=\\\"selected\\\"\":\"\").\">GMT +3:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 3).\")</option>\r\n<option value=\\\"+3.5\\\" \".($setting[''value''] == 3.5?\"selected=\\\"selected\\\"\":\"\").\">GMT +3:30 Hours (\".my_date($mybb->settings[''timeformat''], time(), 3.5).\")</option>\r\n<option value=\\\"+4\\\" \".($setting[''value''] == 4?\"selected=\\\"selected\\\"\":\"\").\">GMT +4:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 4).\")</option>\r\n<option value=\\\"+4.5\\\" \".($setting[''value''] == 4.5?\"selected=\\\"selected\\\"\":\"\").\">GMT +4:30 Hours (\".my_date($mybb->settings[''timeformat''], time(), 4.5).\")</option>\r\n<option value=\\\"+5\\\" \".($setting[''value''] == 5?\"selected=\\\"selected\\\"\":\"\").\">GMT +5:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 5).\")</option>\r\n<option value=\\\"+5.5\\\" \".($setting[''value''] == 5.5?\"selected=\\\"selected\\\"\":\"\").\">GMT +5:30 Hours (\".my_date($mybb->settings[''timeformat''], time(), 5.5).\")</option>\r\n<option value=\\\"+5.75\\\" \".($setting[''value''] == 5.75?\"selected=\\\"selected\\\"\":\"\").\">GMT +5:45 Hours (\".my_date($mybb->settings[''timeformat''], time(), 5.75).\")</option>\r\n<option value=\\\"+6\\\" \".($setting[''value''] == 9?\"selected=\\\"selected\\\"\":\"\").\">GMT +6:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 6).\")</option>\r\n<option value=\\\"+7\\\" \".($setting[''value''] == 7?\"selected=\\\"selected\\\"\":\"\").\">GMT +7:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 7).\")</option>\r\n<option value=\\\"+8\\\" \".($setting[''value''] == 8?\"selected=\\\"selected\\\"\":\"\").\">GMT +8:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 8).\")</option>\r\n<option value=\\\"+9\\\" \".($setting[''value''] == 9?\"selected=\\\"selected\\\"\":\"\").\">GMT +9:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 9).\")</option>\r\n<option value=\\\"+9.5\\\" \".($setting[''value''] == 9.5?\"selected=\\\"selected\\\"\":\"\").\">GMT +9:30 Hours (\".my_date($mybb->settings[''timeformat''], time(), 9.5).\")</option>\r\n<option value=\\\"+10\\\" \".($setting[''value''] == 10?\"selected=\\\"selected\\\"\":\"\").\">GMT +10:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 10).\")</option>\r\n<option value=\\\"+10.5\\\" \".($setting[''value''] == 10.5?\"selected=\\\"selected\\\"\":\"\").\">GMT +10:30 Hours (\".my_date($mybb->settings[''timeformat''], time(), 10.5).\")</option>\r\n<option value=\\\"+11\\\" \".($setting[''value''] == 11?\"selected=\\\"selected\\\"\":\"\").\">GMT +11:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 11).\")</option>\r\n<option value=\\\"+12\\\" \".($setting[''value''] == 12?\"selected=\\\"selected\\\"\":\"\").\">GMT +12:00 Hours (\".my_date($mybb->settings[''timeformat''], time(), 12).\")</option>\r\n</select>','+10',4,6),
  (19,'dstcorrection','Day Light Savings Time','If times are an hour out above and your timezone is selected correctly, enable day light savings time correction.','yesno','no',5,6),
  (20,'threadsperpage','Threads Per Page','The number of threads to display per page on the forum display','text','20',1,7),
  (21,'hottopic','Replies For Hot Topic','The number of replies that is needed for a topic to be considered ''hot''.','text','20',2,7),
  (22,'hottopicviews','Views For Hot Topic','The number of views a thread can have before it is considered ''hot''.','text','150',3,7),
  (23,'usertppoptions','User Selectable Threads Per Page','If you would like to allow users to select how many threads per page are shown in a forum, enter the options they should be able to select separated with commas. If this is left blank they will not be able to choose how many threads are shown per page.','text','10,20,25,30,40,50',4,7),
  (24,'dotfolders','Use ''dot'' Icons','Do you want to show dots on the thread indicators of threads users have participated in.','yesno','yes',5,7),
  (25,'browsingthisforum','Users Browsing this Forum','Here you can turn off the ''users browsing this forum'' feature.','onoff','on',6,7),
  (26,'announcementlimit','Announcements Limit','The number of forum announcements to  show in the thread listing on the forum display pages. Set to 0 to disable announcements altogether.','text','2',7,7),
  (27,'showdescriptions','Show Forum Descriptions?','This option will allow you to turn off showing the descriptions for forums.','yesno','yes',1,8),
  (28,'subforumsindex','Subforums to show on Index listing','The number of subforums that you wish to show inside forums on the index and forumdisplay pages. Set to 0 to not show the subforum list','text','2',2,8),
  (29,'subforumsstatusicons','Show Subforum Status Icons?','Show icons indicating whether or not a subforum contains new posts or not?  This won''t have any effect unless you enabled subforums display on the index.','yesno','yes',3,8),
  (30,'hideprivateforums','Hide Private Forums?','You can hide private forums by turning this option on. This option also hides forums on the forum jump and all subforums.','yesno','yes',4,8),
  (31,'modlist','Forums'' Moderator Listing','Here you can turn on or off the listing of moderators for each forum on index.php and forumdisplay.php','onoff','on',5,8),
  (32,'showbirthdays','Show Today''s Birthdays?','Do you want to show today''s birthdays on the forum homepage?','yesno','yes',6,8),
  (33,'showwol','Show Who''s Online?','Display the currently active users on the forum home page.','yesno','yes',7,8),
  (34,'showindexstats','Show Small Stats Section','Do you want to show the total number of threads, posts, members, and the last member on the forum home?','yesno','yes',8,8),
  (35,'bbname','Board Name','The name of your message boards. We recommend that it is not over 75 characters.','text','TBDev Yuna Scatari Edition Forum',1,9),
  (36,'bburl','Board URL','The url to your forums.<br />Include the http://. Do NOT include a trailing slash.','text','http://127.0.0.10/forum',2,9),
  (37,'homename','Homepage Name','The name of your homepage. This will appear in the footer with a link to it.','text','TBDev Yuna Scatari Edition Tracker',3,9),
  (38,'homeurl','Homepage URL','The full URL of your homepage. This will be linked to in the footer along with its name.','text','http://127.0.0.10/',4,9),
  (39,'adminemail','Admin Email','The administrator''s email address. This will be used for outgoing emails sent via the forums.','text','',5,9),
  (40,'contactlink','Contact Us Link','This will be used for the Contact Us link on the bottom of all the forum pages. Can either be an email address (using mailto:email@website.com) or a hyperlink.','text','mailto:',6,9),
  (41,'bblanguage','Default Language','The default language that MyBB should use for guests and for users without a selected language in their user control panel.','language','russian',7,9),
  (42,'cookiedomain','Cookie Domain','The domain which cookies should be set to. This can remain blank. It should also start with a . so it covers all subdomains.','text','',8,9),
  (43,'cookiepath','Cookie Path','The path which cookies are set to, we recommend setting this to the full directory path to your forums with a trailing slash.','text','/',9,9),
  (44,'showvernum','Show Version Numbers','Allows you to turn off the public display of version numbers in MyBB.','onoff','off',10,9),
  (45,'captchaimage','CAPTCHA Images for Registration & Posting','If yes, and GD is installed, an image will be shown during registration and posting where users are required to enter the text contained within the image to continue. This helps prevent automated registrations and postings.','onoff','on',11,9),
  (46,'reportmethod','Reported Posts Medium','Please select from the list how you want reported posts to be dealt with. Storing them in the database is probably the better of the options listed.','radio\r\ndb=Stored in the Database\r\npms=Sent as Private Messages\r\nemail=Sent via Email','db',12,9),
  (47,'statslimit','Stats Limit','The number of threads to show on the stats page for most replies and most views.','text','15',13,9),
  (48,'decpoint','Decimal Point','The decimal point you use in your region.','text','.',14,9),
  (49,'thousandssep','Thousands Numeric Separator','The punctuation you want to use .  (for example, the setting '','' with the number 1200 will give you a number such as 1,200)','text',',',15,9),
  (50,'enablememberlist','Enable Member List Functionality','If you wish to disable the member list on your board, set this option to no.','yesno','yes',1,10),
  (51,'membersperpage','Members Per Page','The number of members to show per page on the member list.','text','20',2,10),
  (52,'default_memberlist_sortby','Default Sort Field','Select the field that you want members to be sorted by default.','select\r\nregdate=Registration Date\r\npostnum=Post Count\r\nusername=Username','regdate',3,10),
  (53,'default_memberlist_order','Default Sort Order','Select the order that you want members to be sorted by default.<br />Ascending: A-Z / beginning-end<br />Descending: Z-A / end-beginning','select\r\nASC=Ascending\r\nDESC=Descending','ASC',4,10),
  (54,'portal_announcementsfid','Forum ID to pull announcements from','Please enter the forum ids (fid) of the forum(s) you wish to pull the announcements from.  Separate them with a comma (,).','text','1',1,11),
  (55,'portal_numannouncements','Number of announcements to show','Please enter the number of announcements to show on the main page.','text','10',2,11),
  (56,'portal_showwelcome','Show the Welcome box','Do you want to show the welcome box to visitors / users.','yesno','yes',3,11),
  (57,'portal_showpms','Show the number of PMs to users','Do you want to show the number of private messages the current user has in their pm system.','yesno','yes',4,11),
  (58,'portal_showstats','Show forum statistics','Do you want to show the total number of posts, threads, members and the last registered member on the portal page?','yesno','yes',5,11),
  (59,'portal_showwol','Show Who''s Online','Do you want to show the ''Who''s online'' information to users when they visit the portal page?','yesno','yes',6,11),
  (60,'portal_showsearch','Show Search Box','Do you want to show the search box, allowing users to quickly search the forums on the portal?','yesno','yes',7,11),
  (61,'portal_showdiscussions','Show Latest Discussions','Do you wish to show the current forum discussions on the portal page?','yesno','yes',8,11),
  (62,'portal_showdiscussionsnum','Number of latest discussions to show','Please enter the number of current forum discussions to show on the portal page.','text','10',9,11),
  (63,'minmessagelength','Minimum Message Length','The minimum number of characters to post.','text','5',1,12),
  (64,'maxmessagelength','Maximum Message Length','The maximum number of characters to allow in a message. A setting of 0 allows an unlimited length.','text','0',2,12),
  (65,'maxposts','Maximum Posts Per Day','This is the total number of posts allowed per user per day.  0 for unlimited.','text','0',3,12),
  (66,'postfloodcheck','Post Flood Checking','Set to on if you want to enable flood checking for posts. Specify the time between posts below.','onoff','on',4,12),
  (67,'postfloodsecs','Post Flood Time','Set the time (in seconds) users have to wait between posting, to be in effect; the option above must be on.','text','60',5,12),
  (68,'logip','Log Posting IP Addresses','Do you wish to log ip addresses of users who post, and who to you want to show ip addresses to.','radio\r\nno=Do not log IP\r\nhide=Show to Admins & Mods\r\nshow=Show to all Users','hide',6,12),
  (69,'showeditedby','Show ''edited by'' Messages','Once a post is edited by a regular user, do you want to show the edited by message?','yesno','yes',7,12),
  (70,'showeditedbyadmin','Show ''edited by'' Message for Forum Staff','Do you want to show edited by messages for forum staff when they edit their posts?','yesno','yes',8,12),
  (71,'maxpostimages','Maximum Images per Post','Enter the maximum number of images (including smilies) a user can put in their post. Set to 0 to disable this.','text','10',9,12),
  (72,'subscribeexcerpt','Amount of Characters for Subscription Previews','How many characters of the post do you want to send with the email notification of a new reply.','text','100',10,12),
  (73,'maxattachments','Maximum Attachments Per Post','The maximum number of attachments a user is allowed to upload per post.','text','5',11,12),
  (74,'attachthumbnails','Show Attached Thumbnails in Posts','Do you want to show the generated thumbnails for attached images inside the posts?','yesno','yes',12,12),
  (75,'attachthumbh','Attached Thumbnail Maximum Height','Enter the height that attached thumbnails should be generated at.','text','60',13,12),
  (76,'attachthumbw','Attached Thumbnail Maximum Width','Enter the width that attached thumbnails should be generated at.','text','60',14,12),
  (77,'edittimelimit','Edit Time Limit','The number of minutes until regular users cannot edit their own posts (if they have the permission). Enter 0 (zero) for no limit.','text','0',15,12),
  (78,'wordwrap','Number of Characters before Word Wrapping Occurs','The maximum number of characters that can be present in a word before a space is automatically inserted. (helps preservation of the forum layout). Set to 0 to disable.','text','80',16,12),
  (79,'polloptionlimit','Maximum Poll Option Length','The maximum length that each poll option can be. (Set to 0 to disable).','text','250',17,12),
  (80,'maxpolloptions','Maximum Number of Poll Options','The maximum number of options for polls that users can post.','text','10',18,12),
  (81,'enablereputation','Enable Reputation Functionality','If you wish to disable the reputation system on your board, set this option to no.','yesno','yes',1,13),
  (82,'repsperpage','Reputation Comments Per Page','Here you can enter the number of reputation comments to show per page on the reputation system','text','15',2,13),
  (83,'enablepms','Enable Private Messaging Functionality','If you wish to disable the private messaging system on your board, set this option to no.','yesno','yes',1,14),
  (84,'pmsallowhtml','Allow HTML','Selecting yes will allow HTML to be used in private messages.','yesno','no',2,14),
  (85,'pmsallowmycode','Allow MyCode','Selecting yes will allow MyCode to be used in private messages.','yesno','yes',3,14),
  (86,'pmsallowsmilies','Allow Smilies','Selecting yes will allow Smilies to be used in private messages.','yesno','yes',4,14),
  (87,'pmsallowimgcode','Allow [img] Code','Selecting yes will allow [img] Code to be used in private messages.','yesno','yes',5,14),
  (88,'gzipoutput','Use GZip Page Compression?','Do you want to compress pages in GZip format when they are sent to the browser? This means quicker downloads for your visitors, and less traffic usage for you.','yesno','no',1,15),
  (89,'gziplevel','GZip Page Compression Level','Set the level for GZip Page Compression from 0-9.  (0=no compression, 9=maximum compression).  This will only take effect if GZip Page Compression is enabled above and if your PHP version is newer than 4.2.  If you use an older version of PHP, the default compression level of the zlib library will be used instead.','text','4',2,15),
  (90,'standardheaders','Send Standard Headers','With some web servers, this option can cause problems; with others, it is needed. ','yesno','no',3,15),
  (91,'nocacheheaders','Send No Cache Headers','With this option you can prevent caching of the page by the browser.','yesno','no',4,15),
  (92,'redirects','Friendly Redirection Pages','This will enable friendly redirection pages instead of bumping the user directly to the page.','onoff','on',5,15),
  (93,'load','*NIX Load Limiting','Limit the maximum server load before myBB rejects people.  0 for none.  Recommended limit is 5.0.','text','0',6,15),
  (94,'tplhtmlcomments','Output template start/end comments?','This will enable or disable the output of template start/end comments in the HTML.','yesno','yes',7,15),
  (95,'useshutdownfunc','Use PHP''s Shutdown Functionality','This setting for the most part is best left at the default which is detected upon installation. If thread indicators are not updating as well as other meta information, set this setting to ''No''','yesno','yes',8,15),
  (96,'cssmedium','CSS Medium','Please select from the list how you want the theme and CSS data to be stored and retrieved.','php\r\n<input type=\\\"radio\\\" name=\\\"upsetting[{$setting[''sid'']}]\\\" value=\\\"db\\\" \".($setting[''value''] == ''db'' || !is_writable(MYBB_ROOT.\"/css\")?\"checked=\\\"checked\\\"\":\"\").\" /> \".($lang->setting_cssmedium_db?$lang->setting_cssmedium_db:\"Database\").\"<br />\r\n<input type=\\\"radio\\\" name=\\\"upsetting[{$setting[''sid'']}]\\\" value=\\\"file\\\" \".($setting[''value''] == ''file'' && is_writable(MYBB_ROOT.\"/css\")?\"checked=\\\"checked\\\"\":\"\").(!is_writable(MYBB_ROOT.\"/css\")?\" disabled=\\\"disabled\\\"\":\"\").\" /> \".($lang->setting_cssmedium_file?$lang->setting_cssmedium_file:\"Stored in the file system (In the ''css'' folder)\").(!is_writable(MYBB_ROOT.\"/css\")?\"<br /><br />\".($lang->setting_cssmedium_file?$lang->setting_cssmedium_file:\"To cache CSS to the file system, the CSS folder must be made writable.\"):\"\").\"','db',9,15),
  (97,'extraadmininfo','Advanced Stats / Debug information','Shows Server load, parse time, generation time, Gzip compression, etc on the bottom of all pages in the root folder. Please note that only administrators see this information.','yesno','yes',10,15),
  (98,'uploadspath','Uploads Path','The path used for all board uploads. It <b>must be chmod 777</b> (on Unix servers).','text','./uploads',11,15),
  (99,'showteamleaders','Separate Group Leaders','If set to ''yes,'' and if there are group leaders, they will be displayed above the other group members.','yesno','yes',1,16),
  (100,'postsperpage','Posts Per Page:','The number of posts to display per page. We recommend its not higher than 20 for people with slower connections.','text','10',1,17);

COMMIT;

#
# Data for the `mybb_settings` table  (LIMIT 100,100)
#

INSERT INTO `mybb_settings` (`sid`, `name`, `title`, `description`, `optionscode`, `value`, `disporder`, `gid`) VALUES
  (101,'userpppoptions','User Selectable Posts Per Page','If you would like to allow users to select how many posts are shown per page in a thread, enter the options they should be able to select separated with commas. If this is left blank they will not be able to choose how many posts are shown per page.','text','5,10,20,25,30,40,50',2,17),
  (102,'threadreadcut','Read Threads in Database (Days)','The number of days that you wish to keep thread read information in the database. For large boards, we do not recommend a high number as the board will become slower. Set to 0 to disable.','text','7',3,17),
  (103,'threadusenetstyle','Usenet Style Thread View','Selecting yes will cause posts to look similar to how posts look in USENET. No will cause posts to look the modern way.','yesno','no',4,17),
  (104,'quickreply','Show Quick Reply Form','Allows you to set whether or not the quick reply form will be shown at the bottom of threads.','onoff','on',5,17),
  (105,'multiquote','Show Multi-quote Buttons','The multi-quote button allows users to select a series of posts then click Reply and have those posts quoted in their message.','onoff','on',6,17),
  (106,'showsimilarthreads','Show ''Similar Threads'' Table','The Similar Threads table shows threads that are relevant to the thread being read. You can set the relevancy below.','yesno','no',7,17),
  (107,'similarityrating','Similar Threads Relevancy Rating','This allows you to limit similar threads to ones more relevant (0 being not relevant). This number should not be over 10 and should not be set low (<5) for large forums.','text','1',8,17),
  (108,'similarlimit','Similar Threads Limit','Here you can change the total amount of similar threads to be shown in the similar threads table. It is recommended that it is not over 15 for 56k users.','text','10',9,17),
  (109,'disableregs','Disable Registrations','Allows you to turn off the capability for users to register with one click.','yesno','no',1,18),
  (110,'regtype','Registration Method','Please select the method of registration to use when users register.','select\r\ninstant=Instant Activation\r\nverify=Send Email Verification\r\nrandompass=Send Random Password\r\nadmin=Administrator Activation','verify',2,18),
  (111,'minnamelength','Minimum Username Length','The minimum number of characters a username can be when a user registers.','text','3',3,18),
  (112,'maxnamelength','Maximum Username Length','The maximum number of characters a username can be when a user registers.','text','30',4,18),
  (113,'minpasswordlength','Minimum Password Length','The minimum number of characters a password should contain.','text','6',5,18),
  (114,'maxpasswordlength','Maximum Password Length','The maximum number of characters a password should contain.','text','30',6,18),
  (115,'customtitlemaxlength','Custom User Title Maximum Length','Maximum length a user can enter for the custom user title.','text','40',7,18),
  (116,'betweenregstime','Time Between Registrations','The amount of time (in hours) to disallow registrations for users who have already registered an account under the same ip address.','text','24',8,18),
  (117,'maxregsbetweentime','Maximum Registrations Per IP Address','This option allows you to set the maximum amount of times a certain user can register within the timeframe specified above.','text','2',9,18),
  (118,'failedlogincount','Number of times to allow failed logins','The number of times to allow someone to attempt to login. 0 to disable','text','3',10,18),
  (119,'failedlogintime','Time between failed logins','The amount of time (in minutes) before someone can try to login again, after they have failed to login the first time. Used if value above is not 0.','text','15',11,18),
  (120,'failedlogintext','Display number of failed logins','Do you wish to display a line of text telling the user how many more login attempts they have?','yesno','yes',12,18),
  (121,'usereferrals','Use Referrals System','Do you want to use the user referrals system on these forums?','yesno','yes',13,18),
  (122,'sigmycode','Allow myCode in Signatures','Do you want to allow myCode to be used in users'' signatures?','yesno','yes',14,18),
  (123,'maxsigimages','Maximum Number of Images per Signature','Enter the maximum number of images (including smilies) a user can put in their signature. Set to 0 to disable images in signatures altogether.','text','2',15,18),
  (124,'sigsmilies','Allow Smilies in Signatures','Do you want to allow smilies to be used in users'' signatures?','yesno','yes',16,18),
  (125,'sightml','Allow HTML in Signatures','Do you want to allow HTML to be used in users'' signatures?','yesno','no',17,18),
  (126,'sigimgcode','Allow [img] Code in Signatures','Do you want to allow [img] code to be used in users'' signatures?','yesno','yes',18,18),
  (127,'siglength','Length limit in Signatures','The maximum number of characters a user can place in a signature.','text','255',19,18),
  (128,'sigcountmycode','MyCode affects signature length','Do you want myCode to be counted as part of the limit when users use myCode in their signature?','yesno','yes',20,18),
  (129,'maxavatardims','Maximum Avatar Dimensions','The maximum dimensions that an avatar can be, in the format of width<b>x</b>height. If this is left blank then there will be no dimension restriction.','text','100x100',21,18),
  (130,'avatarsize','Max Uploaded Avatar Size','Maximum file size (in kilobytes) of uploaded avatars.','text','10',22,18),
  (131,'avatardir','Avatar Directory','The directory where your avatars are stored. These are used in the avatar list in the User CP.','text','images/avatars',23,18),
  (132,'avataruploadpath','Avatar Upload Path','This is the path where custom avatars will be uploaded to. This directory <b>must be chmod 777</b> (writable) for uploads to work.','text','./uploads/avatars',24,18),
  (133,'wolcutoffmins','Cut-off Time (mins)','The number of minutes before a user is marked offline. Recommended: 15.','text','15',1,19),
  (134,'refreshwol','Refresh Who''s online page','Do you want the online page to refresh after 60 seconds?','yesno','yes',2,19),
  (135,'searchtype','Search Type','Please select the type of search system you wish to use. You can either chose between \"Standard\", or \"Full Text\" (depending on your database). Fulltext searching is more powerful than the standard MyBB searching and quicker too.','php\r\n<select name=\\\"upsetting[{$setting[''sid'']}]\\\"><option value=\\\"standard\\\">\".($lang->setting_searchtype_standard?$lang->setting_searchtype_standard:\"Standard\").\"</option>\".($db->supports_fulltext(TABLE_PREFIX.\"threads\") && $db->supports_fulltext_boolean(TABLE_PREFIX.\"posts\")?\"<option value=\\\"fulltext\\\"\".($setting[''value'']==\"fulltext\"?\" selected=\\\"selected\\\"\":\"\").\">\".($lang->setting_searchtype_fulltext?$lang->setting_searchtype_fulltext:\"Full Text\").\"</option>\":\"\").\"</select>','standard',1,20),
  (136,'searchfloodtime','Search Flood Time (seconds)','Enter the time in seconds for the minimum allowed interval for searching. This prevents users from overloading your server by constantly performing searches. Set to 0 to disable.','text','60',2,20),
  (137,'minsearchword','Minimum Search Word Length','Enter the minimum number of characters an individual word in a search query can be. Set to 0 to disable (and accept the hard limit default of 3 for standard searching and 4 for MySQL fulltext searching). If you use MySQL fulltext searching and set this lower than the MySQL setting - MySQL will override it.','text','0',3,20),
  (138,'autosetbburl','Autoset forum URL','Option to make the forum try and autodetect the forum URL, this allows for more then one link to the forum.','onoff','on',17,9),
  (139,'autosetcookie','Autoset Cookie Settings','Option to make the forum try and guess the cookiepath and cookiedomain from the URL requested by the user. This overrides the two above.','onoff','off',16,9);

COMMIT;

#
# Data for the `mybb_smilies` table  (LIMIT 0,100)
#

INSERT INTO `mybb_smilies` (`sid`, `name`, `find`, `image`, `disporder`, `showclickable`) VALUES
  (1,'Smile',':)','images/smilies/smile.gif',1,'yes'),
  (2,'Wink',';)','images/smilies/wink.gif',2,'yes'),
  (3,'Cool',':cool:','images/smilies/cool.gif',3,'yes'),
  (4,'Big Grin',':D','images/smilies/biggrin.gif',4,'yes'),
  (5,'Tongue',':P','images/smilies/tongue.gif',5,'yes'),
  (6,'Rolleyes',':rolleyes:','images/smilies/rolleyes.gif',6,'yes'),
  (7,'Shy',':shy:','images/smilies/shy.gif',7,'yes'),
  (8,'Sad',':(','images/smilies/sad.gif',8,'yes'),
  (9,'At',':at:','images/smilies/at.gif',9,'no');

COMMIT;

#
# Data for the `mybb_templategroups` table  (LIMIT 0,100)
#

INSERT INTO `mybb_templategroups` (`gid`, `prefix`, `title`) VALUES
  (1,'calendar','<lang:group_calendar>'),
  (2,'editpost','<lang:group_editpost>'),
  (3,'email','<lang:group_email>'),
  (4,'emailsubject','<lang:group_emailsubject>'),
  (5,'forumbit','<lang:group_forumbit>'),
  (6,'forumjump','<lang:group_forumjump>'),
  (7,'forumdisplay','<lang:group_forumdisplay>'),
  (8,'index','<lang:group_index>'),
  (9,'error','<lang:group_error>'),
  (10,'memberlist','<lang:group_memberlist>'),
  (11,'multipage','<lang:group_multipage>'),
  (12,'private','<lang:group_private>'),
  (13,'portal','<lang:group_portal>'),
  (14,'postbit','<lang:group_postbit>'),
  (15,'redirect','<lang:group_redirect>'),
  (16,'showthread','<lang:group_showthread>'),
  (17,'usercp','<lang:group_usercp>'),
  (18,'online','<lang:group_online>'),
  (19,'moderation','<lang:group_moderation>'),
  (20,'nav','<lang:group_nav>'),
  (21,'search','<lang:group_search>'),
  (22,'showteam','<lang:group_showteam>'),
  (23,'reputation','<lang:group_reputation>'),
  (24,'newthread','<lang:group_newthread>'),
  (25,'newreply','<lang:group_newreply>'),
  (26,'member','<lang:group_member>');

COMMIT;

#
# Data for the `mybb_templates` table  (LIMIT 0,100)
#

INSERT INTO `mybb_templates` (`tid`, `title`, `template`, `sid`, `version`, `status`, `dateline`) VALUES
  (1,'forumdisplay_threadlist','<div class=\"float_right\" style=\"padding-bottom: 4px;\">\r\n\t{$newthread}\r\n</div>\r\n{$multipage}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\" >\r\n\t<tr>\r\n\t\t<td class=\"thead\" colspan=\"{$colspan}\">\r\n\t\t\t<div style=\"float: right;\">\r\n\t\t\t\t<span class=\"smalltext\"><strong><a href=\"misc.php?action=markread&amp;fid={$fid}\">{$lang->markforum_read}</a> | <a href=\"usercp2.php?action=addsubscription&amp;type=forum&amp;fid={$fid}\">{$lang->subscribe_forum}</a>{$clearstoredpass}</strong></span>\r\n\t\t\t</div>\r\n\t\t\t<div>\r\n\t\t\t\t<strong>{$foruminfo[''name'']}</strong>\r\n\t\t\t</div>\r\n\t\t</td>\r\n\t</tr>\r\n\t<tr>\r\n\t\t<td class=\"tcat\" align=\"center\" colspan=\"2\">&nbsp;</td>\r\n\t\t<td class=\"tcat\" align=\"center\" width=\"40%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=subject&amp;order=asc\">{$lang->thread}</a> {$orderarrow[''subject'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\" width=\"14%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=starter&amp;order=asc\">{$lang->author}</a> {$orderarrow[''starter'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\" width=\"7%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=replies&amp;order=desc\">{$lang->replies}</a> {$orderarrow[''replies'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\" width=\"7%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=views&amp;order=desc\">{$lang->views}</a> {$orderarrow[''views'']}</strong></span></td>\r\n\t\t{$ratingcol}\r\n\t\t<td class=\"tcat\" align=\"center\" width=\"200\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=lastpost&amp;order=desc\">{$lang->lastpost}</a> {$orderarrow[''lastpost'']}</strong></span></td>\r\n\t\t{$inlinemodcol}\r\n\t</tr>\r\n\t{$announcementlist}\r\n\t{$threads}\r\n\t<tr>\r\n\t\t<td class=\"tfoot\" align=\"right\" colspan=\"{$colspan}\">\r\n\t\t<form action=\"forumdisplay.php\" method=\"get\">\r\n\t\t\t<input type=\"hidden\" name=\"fid\" value=\"{$fid}\" />\r\n\t\t\t<select name=\"sortby\">\r\n\t\t\t\t<option value=\"subject\" {$sortsel[''subject'']}>{$lang->sort_by_subject}</option>\r\n\t\t\t\t<option value=\"lastpost\" {$sortsel[''lastpost'']}>{$lang->sort_by_lastpost}</option>\r\n\t\t\t\t<option value=\"starter\" {$sortsel[''starter'']}>{$lang->sort_by_starter}</option>\r\n\t\t\t\t<option value=\"started\" {$sortsel[''started'']}>{$lang->sort_by_started}</option>\r\n\t\t\t\t{$ratingsort}\r\n\t\t\t\t<option value=\"replies\" {$sortsel[''replies'']}>{$lang->sort_by_replies}</option>\r\n\t\t\t\t<option value=\"views\" {$sortsel[''views'']}>{$lang->sort_by_views}</option>\r\n\t\t\t</select>\r\n\t\t\t<select name=\"order\">\r\n\t\t\t\t<option value=\"asc\" {$ordersel[''asc'']}>{$lang->sort_order_asc}</option>\r\n\t\t\t\t<option value=\"desc\" {$ordersel[''desc'']}>{$lang->sort_order_desc}</option>\r\n\t\t\t</select>\r\n\t\t\t<select name=\"datecut\">\r\n\t\t\t\t<option value=\"1\" {$datecutsel[''1'']}>{$lang->datelimit_1day}</option>\r\n\t\t\t\t<option value=\"5\" {$datecutsel[''5'']}>{$lang->datelimit_5days}</option>\r\n\t\t\t\t<option value=\"10\" {$datecutsel[''10'']}>{$lang->datelimit_10days}</option>\r\n\t\t\t\t<option value=\"20\" {$datecutsel[''20'']}>{$lang->datelimit_20days}</option>\r\n\t\t\t\t<option value=\"50\" {$datecutsel[''50'']}>{$lang->datelimit_50days}</option>\r\n\t\t\t\t<option value=\"75\" {$datecutsel[''75'']}>{$lang->datelimit_75days}</option>\r\n\t\t\t\t<option value=\"100\" {$datecutsel[''100'']}>{$lang->datelimit_100days}</option>\r\n\t\t\t\t<option value=\"365\" {$datecutsel[''365'']}>{$lang->datelimit_lastyear}</option>\r\n\t\t\t\t<option value=\"9999\" {$datecutsel[''9999'']}>{$lang->datelimit_beginning}</option>\r\n\t\t\t</select>\r\n\t\t\t{$gobutton}\r\n\t\t</form>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n<div class=\"float_right\" style=\"padding-top: 4px;\">\r\n\t{$newthread}\r\n</div>\r\n{$multipage}\r\n<br style=\"clear: both;\" />\r\n{$inlinemod}\r\n\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\" >\r\n\t<tr>\r\n\t\t<td class=\"trow1\">\r\n\t\t\t<table width=\"100%\" border=\"0\">\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>\r\n\t\t\t\t\t\t<table cellspacing=\"0\" cellpadding=\"2\" style=\"white-space: nowrap; border: none\">\r\n\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/newfolder.gif\" alt=\"{$lang->new_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->new_thread}</span><br />\r\n\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/newhotfolder.gif\" alt=\"{$lang->new_hot_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->new_hot_thread}</span><br />\r\n\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/dot_folder.gif\" alt=\"{$lang->posts_by_you}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->posts_by_you}</span>\r\n\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/folder.gif\" alt=\"{$lang->no_new_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->no_new_thread}</span><br />\r\n\t\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/hotfolder.gif\" alt=\"{$lang->hot_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->hot_thread}</span><br />\r\n\t\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/lockfolder.gif\" alt=\"{$lang->locked_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->locked_thread}</span>\r\n\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t</table>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t\t<td align=\"right\">\r\n\t\t\t\t\t\t{$searchforum}<br /><br />\r\n\t\t\t\t\t\t{$forumjump}\r\n\t\t\t\t\t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n{$inline_edit_js}',-2,'122','',1179356755),
  (2,'forumdisplay_threadlist_sortrating','<option value=\"rating\" {$sortsel[''rating'']}>{$lang->sort_by_rating}</option>',-2,'120','',1179356755),
  (3,'global_boardclosed_warning','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"center\"><strong><font color=\"red\">{$lang->bbclosed_warning}</font></strong></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356755),
  (4,'post_savedraftbutton','&nbsp;<input type=\"submit\" class=\"button\" name=\"savedraft\" value=\"{$lang->save_draft}\" />',-2,'120','',1179356755),
  (5,'index','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$forums}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<thead>\r\n<tr>\r\n<td class=\"thead\">\r\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/collapse{$collapsedimg[''boardstats'']}.gif\" id=\"boardstats_img\" class=\"expander\" alt=\"[-]\" /></div>\r\n<div><strong>{$lang->boardstats}</strong></div>\r\n</td>\r\n</tr>\r\n</thead>\r\n<tbody style=\"{$collapsed[''boardstats_e'']}\" id=\"boardstats_e\">\r\n{$whosonline}\r\n{$birthdays}\r\n{$forumstats}\r\n</tbody>\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t<tr>\r\n\t\t<td class=\"trow1\">\r\n\t\t\t<table width=\"100%\">\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>\r\n\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/on.gif\" alt=\"{$lang->new_posts}\" style=\"vertical-align: middle; padding-bottom: 4px;\" /> <span class=\"smalltext\">{$lang->new_posts}</span><br />\r\n\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/off.gif\" alt=\"{$lang->no_new_posts}\" style=\"vertical-align: middle; padding-bottom: 4px;\" /> <span class=\"smalltext\">{$lang->no_new_posts}</span><br />\r\n\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/offlock.gif\" alt=\"{$lang->forum_locked}\" style=\"vertical-align: middle;\" /> <span class=\"smalltext\">{$lang->forum_locked}</span>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t\t<td style=\"vertical-align: top; text-align: right;\"><span class=\"smalltext\">{$logoutlink}<a href=\"misc.php?action=markread\">{$lang->markread}</a> | <a href=\"showteam.php\">{$lang->forumteam}</a> | <a href=\"stats.php\">{$lang->forumstats}</a></span>\r\n\t\t\t\t\t\t{$loginform}\r\n\t\t\t\t\t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (6,'header_welcomeblock_member','\t<span style=\"float:right;\">{$lang->welcome_current_time}</span>\r\n\t\t{$lang->welcome_back} (<a href=\"{$mybb->settings[''bburl'']}/usercp.php\"><strong>{$lang->welcome_usercp}</strong></a>{$admincplink} &mdash; <a href=\"{$mybb->settings[''bburl'']}/member.php?action=logout&amp;uid={$mybb->user[''uid'']}\">{$lang->welcome_logout}</a>)<br />\r\n\t\t\t\t<span class=\"links\">\r\n\t\t\t\t\t<a href=\"#\" onclick=\"MyBB.popupWindow(''{$mybb->settings[''bburl'']}/misc.php?action=buddypopup'', ''buddyList'', 170, 300);\">{$lang->welcome_open_buddy_list}</a>\r\n\t\t\t\t</span>\r\n\t\t\t\t<a href=\"{$mybb->settings[''bburl'']}/search.php?action=getnew\">{$lang->welcome_newposts}</a> | <a href=\"{$mybb->settings[''bburl'']}/search.php?action=getdaily\">{$lang->welcome_todaysposts}</a> | <a href=\"{$mybb->settings[''bburl'']}/private.php\">{$lang->welcome_pms}</a> {$lang->welcome_pms_usage}',-2,'123','',1179356755),
  (7,'postbit_online','<a href=\"online.php\"><font color=\"#15A018\"><strong>{$lang->postbit_status_online}</strong></font></a>',-2,'120','',1179356755),
  (8,'showthread_moderationoptions','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">\r\n<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\">\r\n<tr>\r\n<td>\r\n<form action=\"moderation.php\" method=\"get\" style=\"margin-top: 0; margin-bottom: 0;\">\r\n<input type=\"hidden\" name=\"modtype\" value=\"thread\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" /><span class=\"smalltext\">\r\n<strong>{$lang->moderation_options}</strong></span> <select name=\"action\" onchange=\"window.location=(''moderation.php?action=''+this.options[this.selectedIndex].value+''&amp;tid={$tid}&amp;modtype=thread'')\">\r\n<optgroup label=\"{$lang->standard_mod_tools}\">\r\n\t<option value=\"threadnotes\">{$lang->thread_notes}</option>\r\n\t<option value=\"openclosethread\">{$lang->open_close_thread}</option>\r\n\t<option value=\"deletethread\">{$lang->delete_thread}</option>\r\n\t{$adminpolloptions}\r\n\t<option value=\"deleteposts\">{$lang->delete_posts}</option>\r\n\t<option value=\"move\">{$lang->move_thread}</option>\r\n\t<option value=\"stick\">{$lang->stick_unstick_thread}</option>\r\n\t<option value=\"split\">{$lang->split_thread}</option>\r\n\t<option value=\"merge\">{$lang->merge_threads}</option>\r\n\t<option value=\"mergeposts\">{$lang->merge_posts}</option>\r\n\t<option value=\"removeredirects\">{$lang->remove_redirects}</option>\r\n\t{$approveunapprovethread}\r\n</optgroup>\r\n{$customthreadtools}\r\n</select>\r\n{$gobutton}\r\n</form>\r\n</td>\r\n<td align=\"right\">{$inlinemod}</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>',-2,'120','',1179356755),
  (9,'showthread_moderationoptions_custom','<optgroup label=\"{$lang->custom_mod_tools}\">{$customthreadtools}</optgroup>',-2,'120','',1179356755),
  (10,'showthread_moderationoptions_custom_tool','<option value=\"{$tool[''tid'']}\">{$tool[''name'']}</option>',-2,'120','',1179356755),
  (11,'showthread_inlinemoderation_custom','<optgroup label=\"{$lang->custom_mod_tools}\">{$customposttools}</optgroup>',-2,'120','',1179356755),
  (12,'showthread_inlinemoderation_custom_tool','<option value=\"{$tool[''tid'']}\">{$tool[''name'']}</option>',-2,'120','',1179356755),
  (13,'showthread_inlinemoderation','<script type=\"text/javascript\" src=\"jscripts/inline_moderation.js?ver=121\"></script>\r\n<form action=\"moderation.php\" method=\"post\" style=\"margin-top: 0; margin-bottom: 0;\">\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"modtype\" value=\"inlinepost\" />\r\n<span class=\"smalltext\"><strong>{$lang->inline_post_moderation}</strong></span>\r\n<select name=\"action\">\r\n<optgroup label=\"{$lang->standard_mod_tools}\">\r\n\t<option value=\"multideleteposts\">{$lang->inline_delete_posts}</option>\r\n\t<option value=\"multimergeposts\">{$lang->inline_merge_posts}</option>\r\n\t<option value=\"multisplitposts\">{$lang->inline_split_posts}</option>\r\n\t<option value=\"multiapproveposts\">{$lang->inline_approve_posts}</option>\r\n\t<option value=\"multiunapproveposts\">{$lang->inline_unapprove_posts}</option>\r\n</optgroup>\r\n{$customposttools}\r\n</select>\r\n<input type=\"submit\" class=\"button\" name=\"go\" value=\"{$lang->go} ({$inlinecount})\" id=\"inline_go\" />&nbsp;\r\n<input type=\"button\" onclick=\"javascript:inlineModeration.clearChecked();\" value=\"{$lang->clear}\" />\r\n</form>\r\n<script language=\"JavaScript\" type=\"text/javascript\">\r\nvar go_text = \"{$lang->inline_go}\";\r\nvar inlineType = \"thread\";\r\nvar inlineId = {$tid};\r\n</script>',-2,'120','',1179356755),
  (14,'showthread','<html>\r\n<head>\r\n<title>{$thread[''subject'']}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\">\r\n\t\t var quickdelete_confirm = \"{$lang->quickdelete_confirm}\";\r\n</script>\r\n<script type=\"text/javascript\" src=\"jscripts/thread.js?ver=121\"></script>\r\n</head>\r\n<body>\r\n{$header}\r\n{$pollbox}\r\n<div style=\"float: right; padding-bottom: 4px;\">\r\n\t{$newreply}{$newthread}\r\n</div>\r\n{$multipage}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\">\r\n\t<div style=\"float: right;\">\r\n\t\t<span class=\"smalltext\"><strong><a href=\"showthread.php?mode=threaded&amp;tid={$tid}&amp;pid={$pid}#pid{$pid}\">{$lang->threaded}</a> | <a href=\"showthread.php?mode=linear&amp;tid={$tid}&amp;pid={$pid}#pid{$pid}\">{$lang->linear}</a></strong></span>\r\n\t</div>\r\n\t<div>\r\n\t\t<strong>{$rating} {$thread[''subject'']}</strong>\r\n\t</div>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"15%\"><span class=\"smalltext\"><strong>{$lang->author}</strong></span></td>\r\n<td class=\"tcat\" width=\"85%\"><span class=\"smalltext\"><strong>{$lang->message}</strong></span></td>\r\n</tr>\r\n{$posts}\r\n{$threadpages}\r\n<tr>\r\n<td colspan=\"2\" class=\"tfoot\">\r\n<div><strong>&laquo; <a href=\"showthread.php?tid={$tid}&amp;action=nextoldest\">{$lang->next_oldest}</a> | <a href=\"showthread.php?tid={$tid}&amp;action=nextnewest\">{$lang->next_newest}</a> &raquo;</strong></div>\r\n</td>\r\n</tr>\r\n</table>\r\n<div style=\"padding-top: 4px;\">\r\n\t{$newreply}{$newthread}\r\n</div>\r\n{$threadexbox}\r\n{$quickreply}\r\n{$moderationoptions}\r\n{$similarthreads}\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\r\n \t<tr>\r\n\t\t<td class=\"trow1\">\r\n\t\t\t<table width=\"100%\">\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>\r\n\t\t\t\t\t\t<span class=\"smalltext\">\r\n\t\t\t\t\t\t\t<a href=\"printthread.php?tid={$tid}\">{$lang->view_printable}</a><br />\r\n\t\t\t\t\t\t\t<a href=\"sendthread.php?tid={$tid}\">{$lang->send_thread}</a><br />\r\n\t\t\t\t\t\t\t<a href=\"usercp2.php?action=addsubscription&amp;tid={$tid}\">{$lang->subscribe_thread}</a> | <a href=\"usercp2.php?action=addfavorite&amp;tid={$tid}\">{$lang->add_favorites}</a>\r\n\t\t\t\t\t\t</span>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t\t<td align=\"right\">\r\n\t\t\t\t\t\t{$ratethread}\r\n\t\t\t\t\t\t<br />\r\n\t\t\t\t\t\t{$forumjump}\r\n\t\t\t\t\t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (15,'showthread_ratethread','<form action=\"ratethread.php\" method=\"post\">\r\n\t<span class=\"smalltext\"><strong>{$lang->rate_thread}</strong></span>\r\n\t<select name=\"rating\">\r\n\t\t<option value=\"\">{$lang->select_rating}</option>\r\n\t\t<option value=\"5\">{$lang->rating_5}</option>\r\n\t\t<option value=\"4\">{$lang->rating_4}</option>\r\n\t\t<option value=\"3\">{$lang->rating_3}</option>\r\n\t\t<option value=\"2\">{$lang->rating_2}</option>\r\n\t\t<option value=\"1\">{$lang->rating_1}</option>\r\n\t</select>\r\n\t<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n\t{$gobutton}\r\n</form>\r\n',-2,'120','',1179356755),
  (16,'forumjump_advanced','<form action=\"forumdisplay.php\" method=\"get\">\r\n<span class=\"smalltext\"><strong>{$lang->forumjump}</strong></span>\r\n<select name=\"{$name}\" onchange=\"window.location=(''forumdisplay.php?fid=''+this.options[this.selectedIndex].value)\">\r\n<option value=\"-1\" {$jumpsel[''default'']}>{$lang->forumjump_select}</option>\r\n<option value=\"-1\">--------------------</option>\r\n<option value=\"-4\">{$lang->forumjump_pms}</option>\r\n<option value=\"-3\">{$lang->forumjump_usercp}</option>\r\n<option value=\"-5\">{$lang->forumjump_wol}</option>\r\n<option value=\"-2\">{$lang->forumjump_search}</option>\r\n<option value=\"-1\">{$lang->forumjump_home}</option>\r\n{$forumjumpbits}\r\n</select>\r\n{$gobutton}\r\n</form>\r\n',-2,'120','',1179356755),
  (17,'forumdisplay_searchforum','<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\r\n<tr><td>\r\n<form action=\"search.php\" method=\"post\">\r\n<span class=\"smalltext\"><strong>{$lang->search_forum}</strong></span> <input type=\"text\" class=\"textbox\" name=\"keywords\" /> {$gobutton}\r\n<input type=\"hidden\" name=\"action\" value=\"do_search\" />\r\n<input type=\"hidden\" name=\"forums\" value=\"{$fid}\" />\r\n<input type=\"hidden\" name=\"postthread\" value=\"1\" />\r\n</form>\r\n</td></tr>\r\n</table>',-2,'120','',1179356755),
  (18,'forumbit_depth2_forum_lastpost','<span class=\"smalltext\">\r\n<a href=\"showthread.php?tid={$lastposttid}&amp;action=lastpost\" title=\"{$full_lastpost_subject}\"><strong>{$lastpost_subject}</strong></a>\r\n<br />{$lastpost_date} {$lastpost_time}<br />{$lang->by} {$lastpost_profilelink}</span>\r\n',-2,'120','',1179356755),
  (19,'editpost','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->edit_post}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\" src=\"jscripts/post.js?ver=121\"></script>\r\n</head>\r\n<body>\r\n{$header}\r\n{$preview}\r\n{$post_errors}\r\n{$attacherror}\r\n<form action=\"editpost.php\" method=\"post\" name=\"editpost\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->delete_post}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" style=\"white-space: nowrap\"><input type=\"checkbox\" class=\"checkbox\" name=\"delete\" value=\"yes\" tabindex=\"9\" /> <strong>{$lang->delete_q}</strong></td>\r\n<td class=\"trow1\" width=\"100%\">{$lang->delete_1}<br /><span class=\"smalltext\">{$lang->delete_2}</span></td>\r\n<td class=\"trow1\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_now}\" tabindex=\"10\" /></td>\r\n</tr>\r\n</table>\r\n<input type=\"hidden\" name=\"action\" value=\"deletepost\" />\r\n<input type=\"hidden\" name=\"pid\" value=\"{$pid}\" />\r\n</form>\r\n<br />\r\n<form action=\"editpost.php\" method=\"post\" enctype=\"multipart/form-data\" name=\"input\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->edit_post}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"subject\" size=\"40\" maxlength=\"85\" value=\"{$subject}\" tabindex=\"1\" /></td>\r\n</tr>\r\n{$posticons}\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->your_message}:</strong><br /><div style=\"text-align: center;\">{$smilieinserter}</div></td>\r\n<td class=\"trow2\">\r\n<textarea name=\"message\" id=\"message\" rows=\"20\" cols=\"70\" tabindex=\"3\">{$message}</textarea>\r\n{$codebuttons}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->post_options}</strong></td>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[signature]\" value=\"yes\" tabindex=\"6\" {$postoptionschecked[''signature'']} /> {$lang->options_sig}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[emailnotify]\" value=\"yes\" tabindex=\"7\" {$postoptionschecked[''emailnotify'']} /> {$lang->options_emailnotify}</label>\r\n{$disablesmilies}</span></td>\r\n</tr>\r\n{$attachbox}\r\n{$pollbox}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_post}\" tabindex=\"3\" />  <input type=\"submit\" class=\"button\" name=\"previewpost\" value=\"{$lang->preview_post}\" tabindex=\"4\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_editpost\" />\r\n<input type=\"hidden\" name=\"pid\" value=\"{$pid}\" />\r\n<input type=\"hidden\" name=\"posthash\" value=\"{$posthash}\" />\r\n<input type=\"hidden\" name=\"attachmentaid\" value=\"\" />\r\n<input type=\"hidden\" name=\"attachmentact\" value=\"\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (20,'editpost_disablesmilies','<br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[disablesmilies]\" value=\"yes\" tabindex=\"8\" {$postoptionschecked[''disablesmilies'']} /> {$lang->options_disablesmilies}</label>',-2,'120','',1179356755),
  (21,'newreply','<html>\r\n<head>\r\n<title>{$lang->post_reply_to}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\" src=\"jscripts/post.js?ver=121\"></script>\r\n</head>\r\n<body>\r\n{$header}\r\n{$preview}\r\n{$maximageserror}\r\n{$attacherror}\r\n{$reply_errors}\r\n<form action=\"newreply.php\" method=\"post\" enctype=\"multipart/form-data\" name=\"input\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->post_new_reply}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->reply_to}</strong></span></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\" width=\"20%\"><strong>{$lang->post_subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"subject\" size=\"40\" maxlength=\"85\" value=\"{$subject}\" tabindex=\"1\" /></td>\r\n</tr>\r\n{$posticons}\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->your_message}</strong><br /><div style=\"margin:auto\">{$smilieinserter}</div></td>\r\n<td class=\"trow2\">\r\n<textarea id=\"message\" name=\"message\" rows=\"20\" cols=\"70\" tabindex=\"2\" >{$message}</textarea>\r\n{$codebuttons}\r\n{$multiquote_external}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->post_options}</strong></td>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[signature]\" value=\"yes\" tabindex=\"6\" {$postoptionschecked[''signature'']} /> {$lang->options_sig}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[emailnotify]\" value=\"yes\" tabindex=\"7\" {$postoptionschecked[''emailnotify'']} /> {$lang->options_emailnotify}</label>\r\n{$disablesmilies}\r\n</span></td>\r\n</tr>\r\n{$attachbox}\r\n{$modoptions}\r\n{$captcha}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->post_reply}\" tabindex=\"3\" accesskey=\"s\" />  <input type=\"submit\" class=\"button\" name=\"previewpost\" value=\"{$lang->preview_post}\" tabindex=\"4\" />{$savedraftbutton}</div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_newreply\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"replyto\" value=\"{$replyto}\" />\r\n<input type=\"hidden\" name=\"posthash\" value=\"{$posthash}\" />\r\n<input type=\"hidden\" name=\"attachmentaid\" value=\"\" />\r\n<input type=\"hidden\" name=\"attachmentact\" value=\"\" />\r\n<input type=\"hidden\" name=\"quoted_ids\" value=\"{$quoted_ids}\" />\r\n{$editdraftpid}\r\n</form>\r\n{$forumrules}\r\n{$threadreview}\r\n{$footer}\r\n</body>\r\n</html>',-2,'127','',1179356755),
  (22,'newreply_disablesmilies','<br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[disablesmilies]\" value=\"yes\" tabindex=\"9\" {$postoptionschecked[''disablesmilies'']} /> {$lang->options_disablesmilies}</label>',-2,'120','',1179356755),
  (23,'usercp_drafts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->drafts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\"><strong>{$lang->drafts}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" width=\"50%\"><span class=\"smalltext\"><strong>{$lang->draft_title}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"20%\"><span class=\"smalltext\"><strong>{$lang->draft_saved}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"20%\"><span class=\"smalltext\"><strong>{$lang->draft_options}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"allbox\" onclick=\"javascript:MyBB.checkAll(this.form);\" /></td>\r\n</tr>\r\n{$drafts}\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_drafts\" />\r\n<input type=\"submit\" class=\"button\" name=\"draftman\" value=\"{$lang->delete_drafts}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (24,'usercp_drafts_draft','<tr>\r\n<td class=\"{$trow}\"><strong>{$draft[''subject'']}</strong><br /><span class=\"smalltext\">{$detail}</span></td>\r\n<td class=\"{$trow}\" align=\"center\">{$savedate}, {$savetime}</td>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"{$editurl}\">{$lang->edit_draft}</a></td>\r\n<td class=\"{$trow}\" align=\"center\"><input type=\"checkbox\" class=\"checkbox\" name=\"deletedraft[{$id}]\" value=\"{$type}\" /></td>\r\n</tr>',-2,'120','',1179356755),
  (25,'newthread','<html>\r\n<head>\r\n<title>{$lang->newthread_in}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\" src=\"jscripts/post.js?ver=121\"></script>\r\n</head>\r\n<body>\r\n{$header}\r\n{$preview}\r\n{$thread_errors}\r\n{$attacherror}\r\n<form action=\"newthread.php\" method=\"post\" enctype=\"multipart/form-data\" name=\"input\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->post_new_thread}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\" width=\"20%\"><strong>{$lang->thread_subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"subject\" size=\"40\" maxlength=\"85\" value=\"{$subject}\" tabindex=\"1\" /></td>\r\n</tr>\r\n{$posticons}\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->your_message}</strong><br /><div style=\"margin:auto\">{$smilieinserter}</div></td>\r\n<td class=\"trow2\">\r\n<textarea name=\"message\" id=\"message\" rows=\"20\" cols=\"70\" tabindex=\"2\">{$message}</textarea>\r\n{$codebuttons}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->post_options}</strong></td>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[signature]\" value=\"yes\" tabindex=\"7\" {$postoptionschecked[''signature'']} /> {$lang->options_sig}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[emailnotify]\" value=\"yes\" tabindex=\"8\" {$postoptionschecked[''emailnotify'']} /> {$lang->options_emailnotify}</label>\r\n{$disablesmilies}</span></td>\r\n</tr>\r\n{$modoptions}\r\n{$attachbox}\r\n{$pollbox}\r\n{$captcha}\r\n</table>\r\n<br />\r\n<div style=\"text-align:center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->post_thread}\" tabindex=\"4\" accesskey=\"s\" />  <input type=\"submit\" class=\"button\" name=\"previewpost\" value=\"{$lang->preview_post}\" tabindex=\"5\" />{$savedraftbutton}</div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_newthread\" />\r\n<input type=\"hidden\" name=\"posthash\" value=\"{$posthash}\" />\r\n<input type=\"hidden\" name=\"fid\" value=\"{$fid}\" />\r\n<input type=\"hidden\" name=\"attachmentaid\" value=\"\" />\r\n<input type=\"hidden\" name=\"attachmentact\" value=\"\" />\r\n{$editdraftpid}\r\n</form>\r\n{$forumrules}\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (26,'newthread_disablesmilies','<br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[disablesmilies]\" value=\"yes\" tabindex=\"9\" {$postoptionschecked[''disablesmilies'']} /> {$lang->options_disablesmilies}</label>',-2,'120','',1179356755),
  (27,'usercp_nav','<td width=\"{$lang->ucp_nav_width}\" valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->ucp_nav_menu}</strong></td>\r\n</tr>\r\n{$usercpmenu}\r\n</table>\r\n</td>',-2,'120','',1179356755),
  (28,'usercp_nav_messenger','<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->ucp_nav_messenger}</strong></span></td></tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<ul class=\"usercpnav\">\r\n{$folderlinks}\r\n<li class=\"separator\">&nbsp;</li>\r\n<li><a href=\"private.php?action=send\">{$lang->ucp_nav_compose}</a></li>\r\n<li><a href=\"private.php?action=tracking\">{$lang->ucp_nav_tracking}</a></li>\r\n<li><a href=\"private.php?action=folders\">{$lang->ucp_nav_edit_folders}</a></li>\r\n<li><a href=\"private.php?action=empty\">{$lang->ucp_nav_empty_folders}</a></li>\r\n<li><a href=\"private.php?action=export\">{$lang->ucp_nav_export_messages}</a></li>\r\n</ul>\r\n</td>\r\n</tr>',-2,'120','',1179356755),
  (29,'usercp_nav_profile','<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->ucp_nav_profile}</strong></span></td></tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<ul class=\"usercpnav\">\r\n<li><a href=\"usercp.php?action=profile\">{$lang->ucp_nav_edit_profile}</a></li>\r\n<li><a href=\"usercp.php?action=options\">{$lang->ucp_nav_edit_options}</a></li>\r\n<li><a href=\"usercp.php?action=email\">{$lang->ucp_nav_change_email}</a></li>\r\n<li><a href=\"usercp.php?action=password\">{$lang->ucp_nav_change_pass}</a></li>\r\n{$changenameop}\r\n<li><a href=\"usercp.php?action=editsig\">{$lang->ucp_nav_edit_sig}</a></li>\r\n<li><a href=\"usercp.php?action=avatar\">{$lang->ucp_nav_change_avatar}</a></li>\r\n</ul>\r\n</td>\r\n</tr>',-2,'120','',1179356755),
  (30,'usercp_nav_misc','<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->ucp_nav_misc}</strong></span></td></tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<ul class=\"usercpnav\">\r\n<li><a href=\"usercp.php?action=usergroups\">{$lang->ucp_nav_usergroups}</a></li>\r\n<li><a href=\"usercp.php?action=editlists\">{$lang->ucp_nav_editlists}</a></li>\r\n<li><a href=\"usercp.php?action=attachments\">{$lang->ucp_nav_attachments}</a></li>\r\n<li>{$draftstart}<a href=\"usercp.php?action=drafts\">{$lang->ucp_nav_drafts}</a> {$draftcount}{$draftend}</li>\r\n<li><a href=\"usercp.php?action=favorites\">{$lang->ucp_nav_favorite_threads}</a></li>\r\n<li><a href=\"usercp.php?action=subscriptions\">{$lang->ucp_nav_subscribed_threads}</a></li>\r\n<li><a href=\"usercp.php?action=forumsubscriptions\">{$lang->ucp_nav_forum_subscriptions}</a></li>\r\n<li><a href=\"usercp.php?action=notepad\">{$lang->ucp_nav_notepad}</a></li>\r\n<li class=\"separator\">&nbsp;</li>\r\n<li><a href=\"member.php?action=profile&amp;uid={$mybb->user[''uid'']}\">{$lang->ucp_nav_view_profile}</a></li>\r\n<li><a href=\"usercp.php\">{$lang->ucp_nav_home}</a></li>\r\n</ul>\r\n</td>\r\n</tr>',-2,'120','',1179356755),
  (31,'usercp_profile_away','<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->away_information}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->away_status}</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\"><input type=\"radio\" class=\"radio\" name=\"away\" value=\"yes\" {$awaycheck[''yes'']} /> {$lang->im_away}</span></td>\r\n<td><span class=\"smalltext\"><input type=\"radio\" class=\"radio\" name=\"away\" value=\"no\" {$awaycheck[''no'']} /> {$lang->im_here}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->away_reason}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><input type=\"text\" class=\"textbox\" name=\"awayreason\" value=\"{$user[''awayreason'']}\" size=\"25\" /></td>\r\n</tr>\r\n</table>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"3\"><span class=\"smalltext\">{$lang->return_date}</span></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<select name=\"awayday\">\r\n<option value=\"\">&nbsp;</option>\r\n{$returndatesel}\r\n</select>\r\n</td>\r\n<td>\r\n<select name=\"awaymonth\">\r\n<option value=\"\">&nbsp;</option>\r\n<option value=\"1\" {$returndatemonthsel[''1'']}>{$lang->month_1}</option>\r\n<option value=\"2\" {$returndatemonthsel[''2'']}>{$lang->month_2}</option>\r\n<option value=\"3\" {$returndatemonthsel[''3'']}>{$lang->month_3}</option>\r\n<option value=\"4\" {$returndatemonthsel[''4'']}>{$lang->month_4}</option>\r\n<option value=\"5\" {$returndatemonthsel[''5'']}>{$lang->month_5}</option>\r\n<option value=\"6\" {$returndatemonthsel[''6'']}>{$lang->month_6}</option>\r\n<option value=\"7\" {$returndatemonthsel[''7'']}>{$lang->month_7}</option>\r\n<option value=\"8\" {$returndatemonthsel[''8'']}>{$lang->month_8}</option>\r\n<option value=\"9\" {$returndatemonthsel[''9'']}>{$lang->month_9}</option>\r\n<option value=\"10\" {$returndatemonthsel[''10'']}>{$lang->month_10}</option>\r\n<option value=\"11\" {$returndatemonthsel[''11'']}>{$lang->month_11}</option>\r\n<option value=\"12\" {$returndatemonthsel[''12'']}>{$lang->month_12}</option>\r\n</select>\r\n</td>\r\n<td>\r\n<input type=\"text\" class=\"textbox\" size=\"4\" maxlength=\"4\" name=\"awayyear\" value=\"{$returndate[''2'']}\" />\r\n</td>\r\n</tr>\r\n</table>\r\n</fieldset>',-2,'120','',1179356755),
  (32,'usercp_options','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->edit_options}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$errors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->edit_options}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"50%\" class=\"trow1\" valign=\"top\">\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->login_cookies_privacy}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"invisible\" id=\"invisible\" value=\"yes\" {$invisiblecheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"invisible\">{$lang->invisible_mode}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"remember\" id=\"remember\" value=\"yes\" {$remembercheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"remember\">{$lang->remember_me}</label></span></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->messaging_notification}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"allownotices\" id=\"allownotices\" value=\"yes\" {$allownoticescheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"allownotices\">{$lang->allow_notices}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"hideemail\" id=\"hideemail\" value=\"yes\" {$hideemailcheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"hideemail\">{$lang->allow_emails}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"emailnotify\" id=\"emailnotify\" value=\"yes\" {$emailnotifycheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"emailnotify\">{$lang->email_notify}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"receivepms\" id=\"receivepms\" value=\"yes\" {$receivepmscheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"receivepms\">{$lang->receive_pms}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"pmpopup\" id=\"pmpopup\" value=\"yes\" {$pmpopupcheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"pmpopup\">{$lang->pm_popup}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"pmnotify\" id=\"pmnotify\" value=\"yes\" {$pmnotifycheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"pmnotify\">{$lang->pm_notify}</label></span></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->date_time_options}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->date_format}</span></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<select name=\"dateformat\">\r\n<option value=\"\">{$lang->use_default}</option>\r\n<option value=\"1\" {$dateselect[''1'']}>01-25-2004</option>\r\n<option value=\"2\" {$dateselect[''2'']}>01-25-04</option>\r\n<option value=\"3\" {$dateselect[''3'']}>01.25.2004</option>\r\n<option value=\"4\" {$dateselect[''4'']}>01.25.04</option>\r\n<option value=\"5\" {$dateselect[''5'']}>25-01-2004</option>\r\n<option value=\"6\" {$dateselect[''6'']}>25-01-04</option>\r\n<option value=\"7\" {$dateselect[''7'']}>25.01.2004</option>\r\n<option value=\"8\" {$dateselect[''8'']}>25.01.04</option>\r\n<option value=\"9\" {$dateselect[''9'']}>January 25th, 2004</option>\r\n<option value=\"10\" {$dateselect[''10'']}>Saturday, January 25th, 2004</option>\r\n<option value=\"11\" {$dateselect[''11'']}>25th January 1998</option>\r\n<option value=\"12\" {$dateselect[''12'']}>Saturday, 25th January 2004</option>\r\n</select>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->time_format}</span></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<select name=\"timeformat\">\r\n<option value=\"\">{$lang->use_default}</option>\r\n<option value=\"1\" {$timeselect[''1'']}>08:15 pm</option>\r\n<option value=\"2\" {$timeselect[''2'']}>08:15 PM</option>\r\n<option value=\"3\" {$timeselect[''3'']}>20:15</option>\r\n</select>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->time_offset}</span></td>\r\n</tr>\r\n<tr>\r\n<td >{$tzselect}</td>\r\n</tr>\r\n</table>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"dst\" id=\"dst\" value=\"yes\" {$dstcheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"dst\">{$lang->dst}</label></span></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n</td>\r\n<td width=\"50%\" class=\"trow1\" valign=\"top\">\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->forum_display_options}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n{$tppselect}\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->thread_view}</span></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<select name=\"daysprune\">\r\n<option value=\"\">{$lang->use_default}</option>\r\n<option value=\"1\" {$daysprunesel[''1'']}>{$lang->thread_view_lastday}</option>\r\n<option value=\"5\" {$daysprunesel[''5'']}>{$lang->thread_view_5days}</option>\r\n<option value=\"10\" {$daysprunesel[''10'']}>{$lang->thread_view_10days}</option>\r\n<option value=\"20\" {$daysprunesel[''20'']}>{$lang->thread_view_20days}</option>\r\n<option value=\"50\" {$daysprunesel[''50'']}>{$lang->thread_view_50days}</option>\r\n<option value=\"75\" {$daysprunesel[''75'']}>{$lang->thread_view_75days}</option>\r\n<option value=\"100\" {$daysprunesel[''100'']}>{$lang->thread_view_100days}</option>\r\n<option value=\"365\" {$daysprunesel[''365'']}>{$lang->thread_view_year}</option>\r\n<option value=\"9999\" {$daysprunesel[''9999'']}>{$lang->thread_view_all}</option>\r\n</select>\r\n</td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->thread_view_options}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"showsigs\" id=\"showsigs\" value=\"yes\" {$showsigscheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"showsigs\">{$lang->show_sigs}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"showavatars\" id=\"showavatars\" value=\"yes\" {$showavatarscheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"showavatars\">{$lang->show_avatars}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"showquickreply\" id=\"showquickreply\" value=\"yes\" {$showquickreplycheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"showquickreply\">{$lang->show_quick_reply}</label></span></td>\r\n</tr>\r\n{$pppselect}\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->thread_mode}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><select name=\"threadmode\"><option value=\"\">{$lang->use_default}</option><option value=\"linear\" {$threadview[''linear'']}>{$lang->linear}</option><option value=\"threaded\" {$threadview[''threaded'']}>{$lang->threaded}</option></select></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->other_options}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"2\">\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"showredirect\" id=\"showredirect\" value=\"yes\" {$showredirectcheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"showredirect\">{$lang->show_redirect}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"showcodebuttons\" id=\"showcodebuttons\" value=\"1\" {$showcodebuttonscheck} /></td>\r\n<td><span class=\"smalltext\"><label for=\"showcodebuttons\">{$lang->show_codebuttons}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->style}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">{$stylelist}</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->board_language}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><select name=\"language\"><option value=\"\">{$lang->use_default}</option><option value=\"0\">-----------</option>{$langoptions}</select></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_options\" />\r\n<input type=\"submit\" class=\"button\" name=\"regsubmit\" value=\"{$lang->update_options}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (33,'usercp_subscriptions_none','<tr>\r\n<td class=\"trow1\" colspan=\"7\">{$lang->no_thread_subscriptions}</td>\r\n</tr>',-2,'120','',1179356755),
  (34,'usercp_drafts_none','<tr>\r\n<td class=\"trow1\" colspan=\"7\">{$lang->no_drafts}</td>\r\n</tr>',-2,'120','',1179356755),
  (35,'usercp_subscriptions_thread','<tr>\r\n<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" alt=\"\" /></td>\r\n<td align=\"center\" class=\"trow2\">{$icon}</td>\r\n<td width=\"100%\" class=\"trow1\"><a href=\"showthread.php?tid={$subscription[''tid'']}\">{$subscription[''subject'']}</a><br /><span class=\"smalltext\"><a href=\"newreply.php?tid={$subscription[''tid'']}\">{$lang->post_reply}</a> | <a href=\"usercp2.php?action=removesubscription&amp;tid={$subscription[''tid'']}\">{$lang->unsubscribe}</a></span></td>\r\n<td align=\"center\" class=\"trow2\"><a href=\"member.php?action=profile&amp;uid={$subscription[''author'']}\">{$subscription[''username'']}</a></td>\r\n<td align=\"center\" class=\"trow1\">{$subscription[''replies'']}</td>\r\n<td align=\"center\" class=\"trow2\">{$subscription[''views'']}</td>\r\n<td class=\"trow1\" style=\"white-space: nowrap\">{$lastpostdate}, {$lastposttime}<br /><span class=\"smalltext\">{$lang->by} {$lastposterlink}</span></td>',-2,'120','',1179356755),
  (36,'usercp_options_timezoneselect','<select name=\"timezoneoffset\">\r\n<option value=\"-12\" {$timezoneselect[''n120'']}>{$lang->gmt} -12:00 {$lang->hours} ({$timein[''n120'']})</option>\r\n<option value=\"-11\" {$timezoneselect[''n110'']}>{$lang->gmt} -11:00 {$lang->hours} ({$timein[''n110'']})</option>\r\n<option value=\"-10\" {$timezoneselect[''n100'']}>{$lang->gmt} -10:00 {$lang->hours} ({$timein[''n100'']})</option>\r\n<option value=\"-9\" {$timezoneselect[''n90'']}>{$lang->gmt} -9:00 {$lang->hours} ({$timein[''n90'']})</option>\r\n<option value=\"-8\" {$timezoneselect[''n80'']}>{$lang->gmt} -8:00 {$lang->hours} ({$timein[''n80'']})</option>\r\n<option value=\"-7\" {$timezoneselect[''n70'']}>{$lang->gmt} -7:00 {$lang->hours} ({$timein[''n70'']})</option>\r\n<option value=\"-6\" {$timezoneselect[''n60'']}>{$lang->gmt} -6:00 {$lang->hours} ({$timein[''n60'']})</option>\r\n<option value=\"-5\" {$timezoneselect[''n50'']}>{$lang->gmt} -5:00 {$lang->hours} ({$timein[''n50'']})</option>\r\n<option value=\"-4\" {$timezoneselect[''n40'']}>{$lang->gmt} -4:00 {$lang->hours} ({$timein[''n40'']})</option>\r\n<option value=\"-3.5\" {$timezoneselect[''n35'']}>{$lang->gmt} -3:30 {$lang->hours} ({$timein[''n35'']})</option>\r\n<option value=\"-3\" {$timezoneselect[''n30'']}>{$lang->gmt} -3:00 {$lang->hours} ({$timein[''n30'']})</option>\r\n<option value=\"-2\" {$timezoneselect[''n20'']}>{$lang->gmt} -2:00 {$lang->hours} ({$timein[''n20'']})</option>\r\n<option value=\"-1\" {$timezoneselect[''n10'']}>{$lang->gmt} -1:00 {$lang->hours} ({$timein[''n10'']})</option>\r\n<option value=\"0\" {$timezoneselect[''0'']}>{$lang->gmt} ({$timein[''0'']})</option>\r\n<option value=\"+1\" {$timezoneselect[''10'']}>{$lang->gmt} +1:00 {$lang->hours} ({$timein[''10'']})</option>\r\n<option value=\"+2\" {$timezoneselect[''20'']}>{$lang->gmt} +2:00 {$lang->hours} ({$timein[''20'']})</option>\r\n<option value=\"+3\" {$timezoneselect[''30'']}>{$lang->gmt} +3:00 {$lang->hours} ({$timein[''30'']})</option>\r\n<option value=\"+3.5\" {$timezoneselect[''35'']}>{$lang->gmt} +3:30 {$lang->hours} ({$timein[''35'']})</option>\r\n<option value=\"+4\" {$timezoneselect[''40'']}>{$lang->gmt} +4:00 {$lang->hours} ({$timein[''40'']})</option>\r\n<option value=\"+4.5\" {$timezoneselect[''45'']}>{$lang->gmt} +4:30 {$lang->hours} ({$timein[''45'']})</option>\r\n<option value=\"+5\" {$timezoneselect[''50'']}>{$lang->gmt} +5:00 {$lang->hours} ({$timein[''50'']})</option>\r\n<option value=\"+5.5\" {$timezoneselect[''55'']}>{$lang->gmt} +5:30 {$lang->hours} ({$timein[''55'']})</option>\r\n<option value=\"+5.75\" {$timezoneselect[''575'']}>{$lang->gmt} +5:45 {$lang->hours} ({$timein[''575'']})</option>\r\n<option value=\"+6\" {$timezoneselect[''60'']}>{$lang->gmt} +6:00 {$lang->hours} ({$timein[''60'']})</option>\r\n<option value=\"+7\" {$timezoneselect[''70'']}>{$lang->gmt} +7:00 {$lang->hours} ({$timein[''70'']})</option>\r\n<option value=\"+8\" {$timezoneselect[''80'']}>{$lang->gmt} +8:00 {$lang->hours} ({$timein[''80'']})</option>\r\n<option value=\"+9\" {$timezoneselect[''90'']}>{$lang->gmt} +9:00 {$lang->hours} ({$timein[''90'']})</option>\r\n<option value=\"+9.5\" {$timezoneselect[''95'']}>{$lang->gmt} +9:30 {$lang->hours} ({$timein[''95'']})</option>\r\n<option value=\"+10\" {$timezoneselect[''100'']}>{$lang->gmt} +10:00 {$lang->hours} ({$timein[''100'']})</option>\r\n<option value=\"+10.5\" {$timezoneselect[''105'']}>{$lang->gmt} +10:30 {$lang->hours} ({$timein[''105'']})</option>\r\n<option value=\"+11\" {$timezoneselect[''110'']}>{$lang->gmt} +11:00 {$lang->hours} ({$timein[''110'']})</option>\r\n<option value=\"+12\" {$timezoneselect[''120'']}>{$lang->gmt} +12:00 {$lang->hours} ({$timein[''120'']})</option>\r\n</select>',-2,'120','',1179356755),
  (37,'usercp_favorites_none','<tr>\r\n<td class=\"trow1\" colspan=\"7\">{$lang->no_favorite_threads}</td>\r\n</tr>',-2,'120','',1179356755),
  (38,'usercp_favorites_thread','<tr>\r\n<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" alt=\"\"/></td>\r\n<td align=\"center\" class=\"trow2\">{$icon}</td>\r\n<td width=\"100%\" class=\"trow1\"><a href=\"showthread.php?tid={$favorite[''tid'']}\">{$favorite[''subject'']}</a><br /><span class=\"smalltext\"><a href=\"newreply.php?tid={$favorite[''tid'']}\">{$lang->post_reply}</a> | <a href=\"usercp2.php?action=removefavorite&amp;tid={$favorite[''tid'']}\">{$lang->delete_from_favorites}</a></span></td>\r\n<td align=\"center\" class=\"trow2\"><a href=\"member.php?action=profile&amp;uid={$favorite[''author'']}\">{$favorite[''username'']}</a></td>\r\n<td align=\"center\" class=\"trow1\">{$favorite[''replies'']}</td>\r\n<td align=\"center\" class=\"trow2\">{$favorite[''views'']}</td>\r\n<td class=\"trow1\">{$lastpostdate}, {$lastposttime}<br /><span class=\"smalltext\">{$lang->by} {$lastposterlink}</span></td>\r\n</tr>',-2,'120','',1179356755),
  (39,'header_welcomeblock_member_admin',' &mdash; <a href=\"{$mybb->settings[''bburl'']}/{$config[''admin_dir'']}/index.php\">{$lang->welcome_admin}</a>',-2,'120','',1179356755),
  (40,'forumdisplay_newthread','<a href=\"newthread.php?fid={$fid}\"><img src=\"{$theme[''imglangdir'']}/newthread.gif\" alt=\"{$lang->post_thread}\" /></a>',-2,'120','',1179356755),
  (41,'showthread_threaded_bitactive','<div style=\"margin-left: {$indentsize}px;\"><strong>{$post[''subject'']}</strong> <span class=\"smalltext\">- {$lang->by} {$post[''profilelink'']} - {$postdate} {$posttime}</span></div>',-2,'120','',1179356755),
  (42,'showthread_threaded_bit','<div style=\"margin-left: {$indentsize}px;\"><a href=\"showthread.php?tid={$tid}&amp;pid={$post[''pid'']}&amp;mode=threaded\">{$post[''subject'']}</a> <span class=\"smalltext\">- {$lang->by} {$post[''profilelink'']} - {$postdate}, {$posttime}</span></div>',-2,'120','',1179356755),
  (43,'showthread_poll','<form action=\"polls.php\" method=\"get\">\r\n<input type=\"hidden\" name=\"action\" value=\"vote\" />\r\n<input type=\"hidden\" name=\"pid\" value=\"{$poll[''pid'']}\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"4\" class=\"thead\" align=\"center\"><strong>{$lang->poll} {$poll[''question'']}</strong></td>\r\n</tr>\r\n{$polloptions}\r\n</table>\r\n<table width=\"100%\" align=\"center\">\r\n<tr>\r\n<td><input type=\"submit\" class=\"button\" value=\"{$lang->vote}\" /></td>\r\n<td valign=\"top\" align=\"right\"><span class=\"smalltext\">[<a href=\"polls.php?action=showresults&amp;pid={$poll[''pid'']}\">{$lang->show_results}</a>{$edit_poll}]</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$publicnote}</span></td>\r\n</tr>\r\n</table>\r\n</form>',-2,'120','',1179356755),
  (44,'forumdisplay_inlinemoderation_custom','<optgroup label=\"{$lang->custom_mod_tools}\">{$customthreadtools}</optgroup>',-2,'120','',1179356755),
  (45,'forumdisplay_inlinemoderation_custom_tool','<option value=\"{$tool[''tid'']}\">{$tool[''name'']}</option>',-2,'120','',1179356755),
  (46,'forumdisplay_inlinemoderation','<script type=\"text/javascript\" src=\"jscripts/inline_moderation.js?ver=121\"></script>\r\n\t\t<form action=\"moderation.php\" method=\"post\">\r\n<input type=\"hidden\" name=\"fid\" value=\"{$fid}\" />\r\n<input type=\"hidden\" name=\"modtype\" value=\"inlinethread\" />\r\n<br />\r\n<div style=\"text-align: right; clear: both;\">\r\n\t<span class=\"smalltext\"><strong>{$lang->inline_thread_moderation}</strong></span>\r\n\t<select name=\"action\">\r\n\t\t<optgroup label=\"{$lang->standard_mod_tools}\">\r\n\t\t\t<option value=\"multiclosethreads\">{$lang->close_threads}</option>\r\n\t\t\t<option value=\"multiopenthreads\">{$lang->open_threads}</option>\r\n\t\t\t<option value=\"multistickthreads\">{$lang->stick_threads}</option>\r\n\t\t\t<option value=\"multiunstickthreads\">{$lang->unstick_threads}</option>\r\n\t\t\t<option value=\"multideletethreads\">{$lang->delete_threads}</option>\r\n\t\t\t<option value=\"multimovethreads\">{$lang->move_threads}</option>\r\n\t\t\t<option value=\"multiapprovethreads\">{$lang->approve_threads}</option>\r\n\t\t\t<option value=\"multiunapprovethreads\">{$lang->unapprove_threads}</option>\r\n\t\t</optgroup>\r\n\t\t{$customthreadtools}\r\n\t</select>\r\n\t<input type=\"submit\" class=\"button\" name=\"go\" value=\"{$lang->inline_go} ({$inlinecount})\" id=\"inline_go\" />&nbsp;\r\n\t<input type=\"button\" onclick=\"javascript:inlineModeration.clearChecked();\" value=\"{$lang->clear}\" class=\"button\" />\r\n</div>\r\n</form>\r\n<script language=\"JavaScript\" type=\"text/javascript\">\r\nvar go_text = \"{$lang->inline_go}\";\r\nvar inlineType = \"forum\";\r\nvar inlineId = {$fid};\r\n</script>\r\n<br />',-2,'120','',1179356755),
  (47,'report_thanks','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->report_post}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"center\">\r\n<br />\r\n<br />\r\n<strong>{$lang->thank_you}</strong>\r\n<blockquote>{$lang->post_reported}</blockquote>\r\n<br /><br />\r\n<div style=\"text-align: center;\">\r\n\t<script type=\"text/javascript\">\r\n\tdocument.write(''[<a href=\"javascript:window.close();\">{$lang->close_window}</a>]'');</script>\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'122','',1179356755),
  (48,'report','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->report_post}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"center\">\r\n<br />\r\n<br />\r\n<strong>{$lang->report_to_mod}</strong>\r\n<form action=\"report.php\" method=\"post\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_report\" />\r\n<input type=\"hidden\" name=\"pid\" value=\"{$pid}\" />\r\n<blockquote>{$lang->only_report}</blockquote>\r\n<br />\r\n<br />\r\n<span class=\"smalltext\">{$lang->report_reason}</span>\r\n<br />\r\n<input type=\"text\" class=\"textbox\" name=\"reason\" size=\"40\" maxlength=\"250\" />\r\n<br />\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->report_post}\" /></div>\r\n</form>\r\n</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (49,'report_error','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->report_post}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n<br />\r\n<table border=\"0\" cellspacing=\"1\" cellpadding=\"4\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><span class=\"smalltext\"><strong>{$mybb->settings[''bbname'']}</strong></span></td>\r\n\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$error}</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'123','',1179356755),
  (50,'redirect','<html>\r\n<head>\r\n<title>{$title}</title>\r\n<meta http-equiv=\"refresh\" content=\"2;URL={$url}\" />\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n<br />\r\n<br />\r\n<br />\r\n<br />\r\n<div style=\"margin: auto auto; width: {$lang->redirect_width}\" align=\"center\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$title}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\"><p>{$message}</p></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" align=\"right\"><a href=\"{$url}\"><span class=\"smalltext\">{$lang->click_no_wait}</span></a></td>\r\n</tr>\r\n</table>\r\n</div>\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (51,'gobutton','<input type=\"submit\" class=\"button\" value=\"{$lang->go}\" />',-2,'120','',1179356755),
  (52,'postbit_away','<a href=\"member.php?action=profile&amp;uid={$post[''uid'']}\"><font color=\"maroon\">{$lang->postbit_status_away}</font></a>',-2,'120','',1179356755),
  (53,'calendar_dayview_birthdays_bday','{$comma}<a href=\"member.php?action=profile&amp;uid={$bdays[''uid'']}\"><strong>{$bdays[''username'']}</strong></a>{$age}',-2,'120','',1179356755),
  (54,'misc_imcenter_icq','<html>\r\n<head>\r\n<title>{$lang->icq_message_center}</title>\r\n{$headerinclude}\r\n</head>\r\n<body style=\"margin:0;top:0;left:0;\" class=\"trow2\">\r\n<form action=\"http://msg.mirabilis.com/scripts/WWPMsg.dll\" method=\"get\" name=\"frmPager\">\r\n<table width=\"100%\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"2\"><strong>{$user[''username'']} - {$lang->icq_message_center}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><strong>{$navigationbar}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" align=\"center\" colspan=\"2\">#{$user[''icq'']} - {$user[''username'']}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->your_name}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"from\" style=\"width:100%\" value=\"{$mybb->user[''username'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->your_email}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"fromemail\" style=\"width:100%\" value=\"{$mybb->user[''email'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->your_message}</strong></td>\r\n<td class=\"trow1\"><textarea style=\"width:100%\" rows=\"12\" name=\"body\"></textarea></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->send_message}\"></td>\r\n</tr>\r\n</table>\r\n<input type=\"hidden\" name=\"subject\" value=\"From WebPager Panel\" />\r\n<input type=\"hidden\" name=\"to\" value=\"{$user[''icq'']}\" />\r\n</form>\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (55,'forumdisplay_thread_rating','<td align=\"center\" class=\"{$bgcolor}\"><img src=\"{$theme[''imgdir'']}/{$thread[''rating'']}\" alt=\"{$ratingvotesav}\" /></td>\r\n',-2,'120','',1179356755),
  (56,'forumdisplay_password','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->password_required} </title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"{$_SERVER[''REQUEST_URI'']}\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"2\"><strong>{$lang->password_required}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" colspan=\"2\">{$lang->forum_password_note}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->enter_password_below}</strong></td>\r\n</tr>\r\n{$pwnote}\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><input type=\"password\" class=\"textbox\" name=\"pwverify\" size=\"50\" value=\"\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->verify_forum_password}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (57,'error_maxsigimages','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->too_many_images}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$lang->too_many_sig_images}<br /><span class=\"smalltext\">{$lang->too_many_sig_images2}</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356755),
  (58,'forumbit_depth2_forum','<tr>\r\n<td class=\"{$bgcolor}\" align=\"center\" valign=\"top\"><img src=\"{$theme[''imgdir'']}/{$lightbulb[''folder'']}.gif\" alt=\"{$lightbulb[''altonoff'']}\" title=\"{$lightbulb[''altonoff'']}\" /></td>\r\n<td class=\"{$bgcolor}\" valign=\"top\">\r\n<strong><a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><div class=\"smalltext\">{$forum[''description'']}{$modlist}{$subforums}</div>\r\n</td>\r\n<td class=\"{$bgcolor}\" valign=\"top\" align=\"center\" style=\"white-space: nowrap\">{$threads}{$unapproved[''unapproved_threads'']}</td>\r\n<td class=\"{$bgcolor}\" valign=\"top\" align=\"center\" style=\"white-space: nowrap\">{$posts}{$unapproved[''unapproved_posts'']}</td>\r\n<td class=\"{$bgcolor}\" valign=\"top\" align=\"right\" style=\"white-space: nowrap\">{$lastpost}</td>\r\n</tr>',-2,'120','',1179356755),
  (59,'forumbit_depth3','{$comma}{$statusicon}<a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a>',-2,'120','',1179356755),
  (60,'forumbit_depth3_statusicon','<img src=\"{$theme[''imgdir'']}/{$lightbulb[''folder'']}.gif\" alt=\"{$lightbulb[''altonoff'']}\" title=\"{$lightbulb[''altonoff'']}\" class=\"subforumicon\" />',-2,'120','',1179356755),
  (61,'forumbit_subforums','<br />{$lang->subforums} {$sub_forums}',-2,'120','',1179356755),
  (62,'private_empty','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->empty_folders}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"private.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->empty_folders}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"3\"><span class=\"smalltext\">{$lang->empty_note}</span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->export_folder}</strong></td>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->num_messages}</strong></td>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->empty_q}</strong></td>\r\n</tr>\r\n{$folderlist}\r\n<tr>\r\n<td class=\"trow2\" align=\"center\" colspan=\"3\"><input type=\"checkbox\" class=\"checkbox\" name=\"keepunread\" value=\"yes\" checked=\"checked\" /><strong>{$lang->keep_unread}</strong></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_empty\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (63,'usercp','<html>\r\n<head>\r\n<title>{$lang->user_cp}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"{$colspan}\"><strong>{$lang->brief_summary}</strong></td>\r\n</tr>\r\n<tr>\r\n{$avatar}\r\n<td class=\"trow1\" width=\"50%\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow1\" width=\"50%\">{$username}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"50%\"><strong>{$lang->primary_usergroup}</strong></td>\r\n<td class=\"trow2\" width=\"50%\">{$usergroup}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"50%\"><strong>{$lang->registration_date}</strong></td>\r\n<td class=\"trow1\" width=\"50%\">{$regdate}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"50%\"><strong>{$lang->postnum}</strong></td>\r\n<td class=\"trow2\" width=\"50%\"><a href=\"search.php?action=finduser&amp;uid={$mybb->user[''uid'']}\">{$mybb->user[''postnum'']}</a> {$lang->posts_day}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"50%\"><strong>{$lang->email}</strong></td>\r\n<td class=\"trow1\" width=\"50%\">{$mybb->user[''email'']}</td>\r\n</tr>\r\n{$reputation}\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356755),
  (64,'usercp_reputation','<tr>\r\n<td class=\"trow2\" width=\"50%\"><strong>{$lang->reputation}</strong></td>\r\n<td class=\"trow2\" width=\"50%\">{$reputation_link} [<a href=\"reputation.php?uid={$mybb->user[''uid'']}\">{$lang->details}</a>]</td>\r\n</tr>',-2,'120','',1179356755),
  (65,'usercp_currentavatar','<td class=\"trow1\" rowspan=\"6\" valign=\"middle\" align=\"center\" width=\"1\"><img src=\"{$mybb->user[''avatar'']}\" alt=\"{$mybb->user[''username'']}\" {$avatar_width_height} /></td>',-2,'120','',1179356755),
  (66,'footer','\t\t\t<br />\r\n\t\t\t<div class=\"bottommenu\"><span class=\"smalltext\"><a href=\"{$mybb->settings[''contactlink'']}\">{$lang->bottomlinks_contactus}</a> | <a href=\"{$mybb->settings[''homeurl'']}\">{$mybb->settings[''homename'']}</a> | <a href=\"#top\">{$lang->bottomlinks_returntop}</a> | <a href=\"#content\">{$lang->bottomlinks_returncontent}</a> | <a href=\"<archive_url>\">{$lang->bottomlinks_litemode}</a> | <a href=\"{$mybb->settings[''bburl'']}/misc.php?action=syndication\">{$lang->bottomlinks_syndication}</a></span>\r\n\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t<hr class=\"hidden\" />\r\n\t\t\t<div id=\"copyright\">\r\n\t\t\t\t<div id=\"debug\"><debugstuff></div>\r\n\t\t\t\t<!-- You may NOT remove, modify or hinder the visibility of the MyBB copyright at any time.\r\n\t\t\t\t     It must contain the links to the MyBB website and be formatted appropriately.\r\n\r\n\t\t\t\t\t Failure to comply with the above will result in prosecution to the full extent of the law.\r\n\t\t\t\t\t This is free software, support us and we''ll support you. -->\r\n{$lang->powered_by} <a href=\"http://www.mybboard.net\" target=\"_blank\">MyBB</a> {$mybbversion}<br />\r\n\t\t\t\t{$lang->copyright} &copy; 2002-{$copy_year} <strong><a href=\"http://www.mybboard.net\" target=\"_blank\">MyBB Group</a></strong>\r\n\t\t\t\t<!-- End copyright -->\r\n\t\t\t\t<br />\r\n<br class=\"clear\" />\r\n\t\t</div>\r\n\t\t</div>',-2,'120','',1179356755),
  (67,'private_archive_csv','{$lang->export_date_sent},{$lang->export_folder},{$lang->export_subject},{$lang->export_to},{$lang->export_from},{$lang->export_message}\r\n{$pmsdownload}',-2,'120','',1179356755),
  (68,'usercp_profile_customtitle','<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->custom_usertitle}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->custom_usertitle_note}</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->default_usertitle}</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\"><strong>{$defaulttitle}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->current_custom_usertitle}</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\"><strong>{$user[''usertitle'']}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->new_custom_usertitle}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"usertitle\" size=\"25\" maxlength=\"{$mybb->settings[''customtitlemaxlength'']}\" value=\"{$newtitle}\" /></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\"><input type=\"checkbox\" name=\"reverttitle\" id=\"reverttitle\" class=\"checkbox\" /> {$lang->revert_usertitle}</span></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />',-2,'120','',1179356756),
  (69,'usercp_attachments_none','<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"5\">{$lang->no_attachments}</td>\r\n</tr>',-2,'120','',1179356756),
  (70,'usercp_nav_changename','<li><a href=\"usercp.php?action=changename\">{$lang->ucp_nav_change_username}</a><br /></li>',-2,'120','',1179356756),
  (71,'usercp_profile','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->edit_profile}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\" name=\"input\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$errors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->edit_profile}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"50%\" class=\"trow1\" valign=\"top\">\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->profile_required}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->change_email_notice}</strong></span></td>\r\n</tr>\r\n{$requiredfields}\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->profile_optional}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"3\"><span class=\"smalltext\">{$lang->birthday}</span></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<select name=\"bday1\">\r\n<option value=\"\">&nbsp;</option>\r\n{$bdaydaysel}\r\n</select>\r\n</td>\r\n<td>\r\n<select name=\"bday2\">\r\n<option value=\"\">&nbsp;</option>\r\n<option value=\"1\" {$bdaymonthsel[''1'']}>{$lang->month_1}</option>\r\n<option value=\"2\" {$bdaymonthsel[''2'']}>{$lang->month_2}</option>\r\n<option value=\"3\" {$bdaymonthsel[''3'']}>{$lang->month_3}</option>\r\n<option value=\"4\" {$bdaymonthsel[''4'']}>{$lang->month_4}</option>\r\n<option value=\"5\" {$bdaymonthsel[''5'']}>{$lang->month_5}</option>\r\n<option value=\"6\" {$bdaymonthsel[''6'']}>{$lang->month_6}</option>\r\n<option value=\"7\" {$bdaymonthsel[''7'']}>{$lang->month_7}</option>\r\n<option value=\"8\" {$bdaymonthsel[''8'']}>{$lang->month_8}</option>\r\n<option value=\"9\" {$bdaymonthsel[''9'']}>{$lang->month_9}</option>\r\n<option value=\"10\" {$bdaymonthsel[''10'']}>{$lang->month_10}</option>\r\n<option value=\"11\" {$bdaymonthsel[''11'']}>{$lang->month_11}</option>\r\n<option value=\"12\" {$bdaymonthsel[''12'']}>{$lang->month_12}</option>\r\n</select>\r\n</td>\r\n<td>\r\n<input type=\"text\" class=\"textbox\" size=\"4\" maxlength=\"4\" name=\"bday3\" value=\"{$bday[''2'']}\" />\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"3\"><span class=\"smalltext\">{$lang->website_url}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"3\"><input type=\"text\" class=\"textbox\" name=\"website\" size=\"25\" maxlength=\"75\" value=\"{$user[''website'']}\" /></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n{$customfields}\r\n</td>\r\n<td width=\"50%\" class=\"trow1\" valign=\"top\">\r\n{$customtitle}\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->additional_contact_details}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->icq_number}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"icq\" size=\"25\" value=\"{$user[''icq'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->aim_screenname}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"aim\" size=\"25\" value=\"{$user[''aim'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->msn}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"msn\" size=\"25\" value=\"{$user[''msn'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->yahoo_id}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"yahoo\" size=\"25\" value=\"{$user[''yahoo'']}\" /></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n{$awaysection}\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_profile\" />\r\n<input type=\"submit\" class=\"button\" name=\"regsubmit\" value=\"{$lang->update_profile}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (72,'post_attachments','<tr>\r\n<td class=\"{$bgcolor}\" valign=\"top\"><strong>{$lang->attachments}</strong><br /><span class=\"smalltext\">{$lang->attachments_desc}</span></td>\r\n<td class=\"{$bgcolor}\" valign=\"top\">\r\n<table cellspacing=\"3\" cellpadding=\"0\" border=\"0\">\r\n<tr>\r\n<td colspan=\"3\">\r\n<span class=\"smalltext\">{$lang->attach_quota} <a href=\"usercp.php?action=attachments\">{$lang->view_attachments}</a></span>\r\n</td>\r\n</tr>\r\n{$newattach}\r\n{$attachments}\r\n</table>\r\n</td>\r\n</tr>',-2,'120','',1179356756),
  (73,'usercp_attachments','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->attachments_manager}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\" name=\"attachmentsmanager\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"5\"><strong>{$lang->attachments_manager} {$usagenote}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\" width=\"40%\"><span class=\"smalltext\"><strong>{$lang->attachments_attachment}</strong></span></td>\r\n<td class=\"tcat\" width=\"40%\"><span class=\"smalltext\"><strong>{$lang->attachments_post}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"20%\"><span class=\"smalltext\"><strong>{$lang->date_uploaded}</strong></span></td>\r\n<td class=\"tcat\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"allbox\" onclick=\"javascript:MyBB.checkAll(this.form);\" /></td>\r\n</tr>\r\n{$attachments}\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_attachments\" />\r\n<input type=\"submit\" class=\"button\" value=\"{$lang->delete_attachments}\" />\r\n</div>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->attachments_stats}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->attachstats_attachs}</strong></td>\r\n<td class=\"trow1\" width=\"60%\">{$totalattachments}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->attachstats_spaceused}</strong></td>\r\n<td class=\"trow2\" width=\"60%\">{$friendlyusage} ({$percent})</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->attachstats_quota}</strong></td>\r\n<td class=\"trow1\" width=\"60%\">{$attachquota}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->attachstats_totaldl}</strong></td>\r\n<td class=\"trow2\" width=\"60%\">{$totaldownloads}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->attachstats_bandwidth}</strong></td>\r\n<td class=\"trow1\" width=\"60%\">{$bandwidth}</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (74,'usercp_attachments_attachment','<tr>\r\n<td class=\"{$altbg}\" width=\"1\">{$icon}</td>\r\n<td class=\"{$altbg}\" width=\"40%\"><a href=\"attachment.php?aid={$attachment[''aid'']}\" target=\"_blank\">{$attachment[''filename'']}</a><br /><span class=\"smalltext\">{$sizedownloads}</span></td>\r\n<td class=\"{$altbg}\"><a href=\"showthread.php?tid={$attachment[''tid'']}&amp;pid={$attachment[''pid'']}#pid{$attachment[''pid'']}\">{$attachment[''subject'']}</a><br /><span class=\"smalltext\">{$lang->attachment_thread} <a href=\"showthread.php?tid={$attachment[''tid'']}\">{$attachment[''threadsubject'']}</a></span></td>\r\n<td class=\"{$altbg}\" align=\"center\">{$attachdate}, {$attachtime}</td>\r\n<td class=\"{$altbg}\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"attachments[{$attachment[''aid'']}]\" value=\"{$attachment[''aid'']}\" /></td>\r\n</tr>',-2,'120','',1179356756),
  (75,'misc_rules_forum','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$forum[''rulestitle'']}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"{$colspan}\"><strong>{$forum[''rulestitle'']}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$forum[''rules'']}</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (76,'forumdisplay_rules','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$foruminfo[''rulestitle'']}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">{$foruminfo[''rules'']}</span></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (77,'forumdisplay_rules_link','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\"><strong><a href=\"misc.php?action=rules&amp;fid={$fid}\">{$foruminfo[''rulestitle'']}</a></strong></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (78,'forumdisplay','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$foruminfo[''name'']} </title>\r\n{$headerinclude}\r\n{$rssdiscovery}\r\n</head>\r\n<body>\r\n{$header}\r\n{$moderatedby}\r\n{$usersbrowsing}<br /><br />\r\n{$rules}\r\n{$subforums}\r\n{$threadslist}\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (79,'member_register_referrer','<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->referrer}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->referrer_desc}</span></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<input type=\"text\" class=\"textbox\" name=\"referrername\" value=\"{$referrername}\" />\r\n</td>\r\n</tr></table>\r\n</fieldset>\r\n<br />',-2,'120','',1179356756),
  (80,'usercp_usergroups_joingroup','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->request_join_usergroup}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->request_join_usergroup}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\">{$lang->join_group_moderate_note}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->user_group}</strong></td>\r\n<td class=\"trow2\">{$usergroup[''title'']}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->join_reason}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"reason\" value=\"\" size=\"50\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"usergroups\" />\r\n<input type=\"hidden\" name=\"joingroup\" value=\"{$joingroup}\" />\r\n<input type=\"hidden\" name=\"do\" value=\"joingroup\" />\r\n<input type=\"submit\" class=\"button\" value=\"{$lang->send_join_request}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (81,'usercp_avatar','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->change_avatar}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$avatar_error}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->change_avatar}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\">\r\n<table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr>\r\n<td>{$lang->avatar_note}{$avatarmsg}\r\n</td>\r\n{$currentavatar}\r\n</tr></table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->local_galleries}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->gallery}</strong></td>\r\n<td class=\"trow2\">\r\n<form method=\"post\" action=\"usercp.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"avatar\" />\r\n<select name=\"gallery\">\r\n{$galleries}\r\n</select>\r\n&nbsp;{$gobutton}\r\n</form>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->custom_avatar}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->avatar_upload}</strong></td>\r\n<td class=\"trow1\" width=\"60%\">\r\n<form enctype=\"multipart/form-data\" action=\"usercp.php\" method=\"post\">\r\n<input type=\"file\" name=\"avatarupload\" size=\"25\" />\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->avatar_url}</strong></td>\r\n<td class=\"trow2\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"avatarurl\" size=\"45\" value=\"{$avatarurl}\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_avatar\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->change_avatar}\" />\r\n<input type=\"submit\" class=\"button\" name=\"remove\" value=\"{$lang->remove_avatar}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'127','',1179356756),
  (82,'usercp_avatar_gallery','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->change_avatar}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$avatar_error}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->change_avatar}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><strong>{$lang->local_galleries}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\">\r\n<form method=\"post\" action=\"usercp.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"avatar\" />\r\n<select name=\"gallery\">\r\n{$galleries}\r\n</select>\r\n&nbsp;{$gobutton}\r\n</form>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><strong>{$lang->avatars_in_gallery}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\">\r\n<form method=\"post\" action=\"usercp.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_avatar\" />\r\n<input type=\"hidden\" name=\"gallery\" value=\"{$gallery}\" />\r\n<table width=\"100%\" cellpadding=\"4\">\r\n{$avatarlist}\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_avatar\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->change_avatar}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'123','',1179356756),
  (83,'usercp_avatar_gallery_avatar','<td width=\"20%\" align=\"center\"><label for=\"avatar-{$avatar}\"><img src=\"{$avatarpath}\" alt=\"{$avatar}\" /><br /><input type=\"radio\" class=\"radio\" name=\"avatar\" value=\"{$avatar}\" id=\"avatar-{$avatar}\" /><strong>{$avatarname}</strong></td>',-2,'120','',1179356756),
  (84,'usercp_avatar_current','<td class=\"trow1\" width=\"150\" align=\"right\"><img src=\"{$urltoavatar}\" alt=\"{$lang->avatar}\" {$avatar_width_height} /></td>',-2,'120','',1179356756),
  (85,'headerinclude','<link rel=\"alternate\" type=\"application/rss+xml\" title=\"{$lang->latest_threads} (RSS 2.0)\" href=\"{$mybb->settings[''bburl'']}/syndication.php\" />\r\n<link rel=\"alternate\" type=\"application/atom+xml\" title=\"{$lang->latest_threads} (Atom 1.0)\" href=\"{$mybb->settings[''bburl'']}/syndication.php?type=atom1.0\" />\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset={$charset}\" />\r\n<script type=\"text/javascript\" src=\"{$mybb->settings[''bburl'']}/jscripts/prototype.lite.js?ver=121\"></script>\r\n<script type=\"text/javascript\" src=\"{$mybb->settings[''bburl'']}/jscripts/moo.ajax.js?ver=121\"></script>\r\n<script type=\"text/javascript\" src=\"{$mybb->settings[''bburl'']}/jscripts/general.js?ver=121\"></script>\r\n<script type=\"text/javascript\" src=\"{$mybb->settings[''bburl'']}/jscripts/popup_menu.js?ver=121\"></script>\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"{$theme[''css_url'']}\" />\r\n<script language=\"Javascript\" type=\"text/javascript\">\r\n<!--\r\n\tvar cookieDomain = \"{$mybb->settings[''cookiedomain'']}\";\r\n\tvar cookiePath = \"{$mybb->settings[''cookiepath'']}\";\r\n\tvar newpm_prompt = \"{$lang->newpm_prompt}\";\r\n\tvar deleteevent_confirm = \"{$lang->deleteevent_confirm}\";\r\n\tvar removeattach_confirm = \"{$lang->removeattach_confirm}\";\r\n\tvar loading_text = ''{$lang->ajax_loading}'';\r\n\tvar saving_changes = ''{$lang->saving_changes}'';\r\n// -->\r\n</script>\r\n{$newpmmsg}',-2,'123','',1179356756),
  (86,'showthread_similarthreads','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"6\"><strong>{$lang->similar_threads}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->thread}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->author}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->replies}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->views}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->lastpost}</strong></span></td>\r\n</tr>\r\n{$similarthreadbits}\r\n</table>',-2,'120','',1179356756),
  (87,'nav_sep',' / ',-2,'120','',1179356756),
  (88,'post_attachments_new','<tr>\r\n<td colspan=\"3\" style=\"white-space: nowrap\"><strong>{$lang->new_attachment}</strong> <input type=\"file\" name=\"attachment\" size=\"30\" /> <input type=\"submit\" class=\"button\" name=\"newattachment\" value=\"{$lang->add_attachment}\"  tabindex=\"12\" />\r\n</td>\r\n</tr>',-2,'120','',1179356756),
  (89,'nav_sep_active',' / ',-2,'120','',1179356756),
  (90,'member_profile','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->profile}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">\r\n<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td class=\"trow1\" width=\"75%\">\r\n<span class=\"largetext\"><strong>{$formattedname}</strong></span><br />\r\n<span class=\"smalltext\">\r\n({$usertitle})<br />\r\n{$groupimage}\r\n{$userstars}<br />\r\n<br />\r\n<strong>{$lang->registration_date}</strong> {$memregdate}<br />\r\n<strong>{$lang->birthday}</strong> {$membday} {$membdayage}<br />\r\n<strong>{$lang->local_time}</strong> {$localtime}<br />\r\n</span>\r\n</td><td width=\"25%\" align=\"right\" valign=\"middle\">{$avatar}</td></tr></table>\r\n</td>\r\n</tr>\r\n{$awaybit}\r\n</table>\r\n<br />\r\n<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" align=\"center\">\r\n<tr>\r\n<td width=\"50%\" valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$lang->users_forum_info}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->joined}</strong></td>\r\n<td class=\"trow1\">{$memregdate}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->lastvisit}</strong></td>\r\n<td class=\"trow2\">{$memlastvisitdate} {$memlastvisittime}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->total_posts}</strong></td>\r\n<td class=\"trow1\">{$memprofile[''postnum'']} ({$lang->ppd_percent_total})<br /><span class=\"smalltext\">(<a href=\"search.php?action=finduserthreads&amp;uid={$uid}\">{$lang->find_threads}</a> &mdash; <a href=\"search.php?action=finduser&amp;uid={$uid}\">{$lang->find_posts}</a>)</span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->timeonline}</strong></td>\r\n<td class=\"trow2\">{$timeonline}</td>\r\n</tr>\r\n{$reputation}\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$lang->users_contact_details}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->homepage}</strong></td>\r\n<td class=\"trow1\">{$website}</td>\r\n</tr>\r\n{$sendemail}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->pm}</strong></td>\r\n<td class=\"trow2\"><a href=\"private.php?action=send&amp;uid={$memprofile[''uid'']}\">{$lang->send_pm}</a></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->icq_number}</strong></td>\r\n<td class=\"trow1\"><a href=\"javascript:;\" onclick=\"MyBB.popupWindow(''misc.php?action=imcenter&amp;imtype=icq&amp;uid={$uid}'', ''imcenter'', 450, 300);\">{$memprofile[''icq'']}</a></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->aim_screenname}</strong></td>\r\n<td class=\"trow2\"><a href=\"javascript:;\" onclick=\"MyBB.popupWindow(''misc.php?action=imcenter&amp;imtype=aim&amp;uid={$uid}'', ''imcenter'', 450, 300);\">{$memprofile[''aim'']}</a></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->yahoo_id}</strong></td>\r\n<td class=\"trow1\"><a href=\"javascript:;\" onclick=\"MyBB.popupWindow(''misc.php?action=imcenter&amp;imtype=yahoo&amp;uid={$uid}'', ''imcenter'', 450, 300);\">{$memprofile[''yahoo'']}</a></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->msn}</strong></td>\r\n<td class=\"trow2\"><a href=\"javascript:;\" onclick=\"MyBB.popupWindow(''misc.php?action=imcenter&amp;imtype=msn&amp;uid={$uid}'', ''imcenter'', 450, 300);\">{$memprofile[''msn'']}</a></td>\r\n</tr>\r\n</table>\r\n</td>\r\n<td><img src=\"{$theme[''imgdir'']}/pixel.gif\" height=\"1\" width=\"8\" alt=\"\"/></td>\r\n<td width=\"50%\" valign=\"top\">\r\n{$profilefields}\r\n{$signature}\r\n{$adminoptions}\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (91,'member_profile_adminoptions','\r\n<br /><table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" width=\"100%\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$lang->admin_options}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<ul>\r\n<li><a href=\"{$mybb->settings[''bburl'']}/{$config[''admin_dir'']}/index.php?goto=users%2Ephp%3Faction%3Dedit%26uid={$uid}\">{$lang->admin_edit_in_acp}</a></li>\r\n<li><a href=\"{$mybb->settings[''bburl'']}/{$config[''admin_dir'']}/index.php?goto=users%2Ephp%3Faction%3Dmanageban%26auid={$uid}\">{$lang->admin_ban_in_acp}</a></li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</table>\r\n',-2,'120','',1179356756),
  (92,'header_welcomeblock_guest','\t<span style=\"float:right;\">{$lang->welcome_current_time}</span>\r\n\t\t{$lang->welcome_guest} (<a href=\"{$mybb->settings[''bburl'']}/member.php?action=login\">{$lang->welcome_login}</a> &mdash; <a href=\"{$mybb->settings[''bburl'']}/member.php?action=register\">{$lang->welcome_register}</a>)',-2,'120','',1179356756),
  (93,'header','\t<a name=\"top\" id=\"top\"></a>\r\n\t<div id=\"container\">\r\n\t\t<div id=\"header\">\r\n\t\t\t<div class=\"logo\"><a href=\"{$mybb->settings[''bburl'']}/index.php\"><img src=\"{$theme[''logo'']}\" alt=\"{$mybb->settings[''bbname'']}\" /></a></div>\r\n\t\t\t<div class=\"menu\">\r\n\t\t\t\t<ul>\r\n\t\t\t\t\t<li><a href=\"{$mybb->settings[''bburl'']}/search.php\"><img src=\"{$mybb->settings[''bburl'']}/{$theme[''imgdir'']}/toplinks/search.gif\" alt=\"\" />{$lang->toplinks_search}</a></li>\r\n\t\t\t\t\t<li><a href=\"{$mybb->settings[''bburl'']}/memberlist.php\"><img src=\"{$mybb->settings[''bburl'']}/{$theme[''imgdir'']}/toplinks/memberlist.gif\" alt=\"\" />{$lang->toplinks_memberlist}</a></li>\r\n\t\t\t\t\t<li><a href=\"{$mybb->settings[''bburl'']}/calendar.php\"><img src=\"{$mybb->settings[''bburl'']}/{$theme[''imgdir'']}/toplinks/calendar.gif\" alt=\"\" />{$lang->toplinks_calendar}</a></li>\r\n\t\t\t\t\t<li><a href=\"{$mybb->settings[''bburl'']}/misc.php?action=help\"><img src=\"{$mybb->settings[''bburl'']}/{$theme[''imgdir'']}/toplinks/help.gif\" alt=\"\" />{$lang->toplinks_help}</a></li>\r\n\t\t\t\t</ul>\r\n\t\t\t</div>\r\n\t\t\t<hr class=\"hidden\" />\r\n\t\t\t<div id=\"panel\">\r\n\t\t\t\t{$welcomeblock}\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<hr class=\"hidden\" />\r\n\t\t<br class=\"clear\" />\r\n\t\t<div id=\"content\">\r\n\t\t\t{$bannedwarning}\r\n\t\t\t{$bbclosedwarning}\r\n\t\t\t{$unreadreports}\r\n\t\t\t<navigation>\r\n\t\t\t<br class=\"clear\" />',-2,'123','',1179356756),
  (94,'usercp_usergroups_leader_usergroup','<tr>\r\n<td class=\"{$trow}\"><strong>{$usergroup[''title'']}</strong></td>\r\n<td class=\"{$trow}\" align=\"center\">{$usergroup[''users'']} {$memberlistlink}</td>\r\n<td class=\"{$trow}\" align=\"center\">{$usergroup[''joinrequests'']} {$moderaterequestslink}</td>\r\n</tr>',-2,'120','',1179356756),
  (95,'usercp_usergroups_leader','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->usergroups_leader}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"35%\"><strong>{$lang->usergroup}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"32%\"><strong>{$lang->usergroup_members}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"32%\"><strong>{$lang->join_requests}</strong></td>\r\n</tr>\r\n{$groupsledlist}\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (96,'usercp_usergroups_joinable','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->usergroups_joinable}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"35%\"><strong>{$lang->usergroup}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"32%\"><strong>{$lang->join_conditions}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"32%\"><strong>{$lang->join_group}</strong></td>\r\n</tr>\r\n{$joinablegrouplist}\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (97,'usercp_usergroups_joinable_usergroup','<tr>\r\n<td class=\"{$trow}\"><strong>{$usergroup[''title'']}</strong>{$description}</td>\r\n<td class=\"{$trow}\"><span class=\"smalltext\">{$conditions}</span><br /><span class=\"smalltext\">{$usergroupleaders}</span></td>\r\n<td class=\"{$trow}\" align=\"center\">{$joinlink}</td>\r\n</tr>',-2,'120','',1179356756),
  (98,'usercp_usergroups_memberof_usergroup','<tr>\r\n<td class=\"{$trow}\"><strong>{$usergroup[''title'']}</strong>{$description}</td>\r\n<td class=\"{$trow}\" align=\"center\">{$usergroup[''usertitle'']}</td>\r\n<td class=\"{$trow}\">{$leavelink}</td>\r\n<td class=\"{$trow}\">{$displaycode}</td>\r\n</tr>',-2,'120','',1179356756),
  (99,'usercp_usergroups','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->group_memberships}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$leadinggroups}\r\n{$joinablegroups}\r\n{$membergroups}\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (100,'usercp_usergroups_memberof','<form method=\"post\" action=\"usercp.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"usergroups\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\"><strong>{$lang->usergroups_memberof}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"35%\"><strong>{$lang->usergroup}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"32%\"><strong>{$lang->usertitle}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"32%\"><strong>{$lang->usergroup_leave}</strong></td>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->display_group}</strong></td>\r\n</tr>\r\n{$memberoflist}\r\n<tr>\r\n<td class=\"tfoot\" align=\"right\" colspan=\"4\"><strong><input type=\"submit\" class=\"button\" name=\"changedisplaygroup\" value=\"{$lang->change_display_group}\" /></strong></td>\r\n</tr>\r\n</table>\r\n</form>\r\n<br />',-2,'120','',1179356756);

COMMIT;

#
# Data for the `mybb_templates` table  (LIMIT 100,100)
#

INSERT INTO `mybb_templates` (`tid`, `title`, `template`, `sid`, `version`, `status`, `dateline`) VALUES
  (101,'managegroup','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->members_of}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$joinrequests}\r\n<p>{$usergrouptype}</p>\r\n<form method=\"post\" action=\"managegroup.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_manageusers\" />\r\n<input type=\"hidden\" name=\"gid\" value=\"{$gid}\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"6\"><strong>{$lang->members_of}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"40%\"><strong>{$lang->user_name}</strong></td>\r\n<td class=\"tcat\" colspan=\"2\" align=\"center\" width=\"30%\"><strong>{$lang->contact}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"15%\"><strong>{$lang->reg_date}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"15%\"><strong>{$lang->post_count}</strong></td>\r\n<td class=\"tcat\" width=\"1\">&nbsp;</td>\r\n</tr>\r\n{$users}\r\n</table>\r\n<br />\r\n<div align=\"center\">{$remove_users}</div>\r\n</form>\r\n{$add_user}\r\n\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (102,'managegroup_removeusers','<input type=\"submit\" class=\"button\" value=\"{$lang->remove_selected}\" />',-2,'120','',1179356756),
  (103,'managegroup_adduser','<br />\r\n<form method=\"post\" action=\"managegroup.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_add\" />\r\n<input type=\"hidden\" name=\"gid\" value=\"{$gid}\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"6\"><strong>{$lang->add_member}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$lang->username}</td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"username\" size=\"40\" maxlength=\"{$mybb->settings[''maxnamelength'']}\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->add_member_submit}\" /></div>\r\n</form>',-2,'120','',1179356756),
  (104,'managegroup_user','<tr>\r\n<td class=\"{$altbg}\"><a href=\"member.php?action=profile&amp;uid={$user[''uid'']}\">{$user[''username'']}</a> {$leader}</td>\r\n<td class=\"{$altbg}\" align=\"center\">{$email}</td>\r\n<td class=\"{$altbg}\" align=\"center\">{$sendpm}</td>\r\n<td class=\"{$altbg}\" align=\"center\">{$regdate}</td>\r\n<td class=\"{$altbg}\" align=\"center\">{$user[''postnum'']}</td>\r\n<td class=\"{$altbg}\" align=\"center\">{$checkbox}</td>\r\n</tr>\r\n',-2,'120','',1179356756),
  (105,'managegroup_user_checkbox','<input type=\"checkbox\" class=\"checkbox\" name=\"removeuser[{$user[''uid'']}]\" value=\"{$user[''uid'']}\" />',-2,'120','',1179356756),
  (106,'managegroup_requestnote','<p>\r\n<strong><a href=\"managegroup.php?action=joinrequests&amp;gid={$gid}\">{$lang->pending_requests}</a></strong><br />\r\n{$lang->num_requests_pending}\r\n</p>',-2,'120','',1179356756),
  (107,'managegroup_joinrequests','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->join_requests}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$joinrequests}\r\n<form method=\"post\" action=\"managegroup.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_joinrequests\" />\r\n<input type=\"hidden\" name=\"gid\" value=\"{$gid}\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"6\"><strong>{$lang->join_requests}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"30%\"><strong>{$lang->user_name}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"40%\"><strong>{$lang->reason}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><strong>{$lang->accept}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><strong>{$lang->ignore}</strong></td>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><strong>{$lang->decline}</strong></td>\r\n</tr>\r\n{$users}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->action_requests}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (108,'managegroup_joinrequests_request','<tr>\r\n<td class=\"{$altbg}\"><a href=\"member.php?action=profile&amp;uid={$user[''uid'']}\">{$user[''username'']}</a></td>\r\n<td class=\"{$altbg}\" align=\"center\">{$user[''reason'']}</td>\r\n<td class=\"{$altbg}\" align=\"center\"><input type=\"radio\" class=\"radio\" name=\"request[{$user[''uid'']}]\" value=\"accept\" /></td>\r\n<td class=\"{$altbg}\" align=\"center\"><input type=\"radio\" class=\"radio\" name=\"request[{$user[''uid'']}]\" value=\"ignore\" checked=\"checked\" /></td>\r\n<td class=\"{$altbg}\" align=\"center\"><input type=\"radio\" class=\"radio\" name=\"request[{$user[''uid'']}]\" value=\"decline\" /></td>\r\n</tr>\r\n',-2,'120','',1179356756),
  (109,'private_send','<html>\r\n<head>\r\n<title>{$lang->compose_pm}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"private.php\" method=\"post\" name=\"input\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$preview}\r\n{$send_errors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->compose_pm}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->compose_to}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"to\" id=\"to\" size=\"40\" maxlength=\"{$mybb->settings[''maxnamelength'']}\" value=\"{$to}\" tabindex=\"1\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->compose_subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"subject\" size=\"40\" maxlength=\"85\" value=\"{$subject}\" tabindex=\"2\" /></td>\r\n</tr>\r\n{$posticons}\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->compose_message}</strong><br/><br/><div style=\"margin:auto\">{$smilieinserter}</div></td>\r\n<td class=\"trow2\">\r\n<textarea name=\"message\" id=\"message\" rows=\"20\" cols=\"60\" tabindex=\"3\">{$message}</textarea>\r\n{$codebuttons}\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->compose_options}</strong></td>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"options[signature]\" value=\"yes\" tabindex=\"8\" {$optionschecked[''signature'']} />{$lang->options_sig}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"options[disablesmilies]\" value=\"yes\" tabindex=\"9\" {$optionschecked[''disablesmilies'']} />{$lang->options_disable_smilies}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"options[savecopy]\" value=\"yes\" tabindex=\"10\" {$optionschecked[''savecopy'']} />{$lang->options_save_copy}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"options[readreceipt]\" value=\"yes\" tabindex=\"11\" {$optionschecked[''readreceipt'']} />{$lang->options_read_receipt}</label><br />\r\n</span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<input type=\"hidden\" name=\"action\" value=\"do_send\" />\r\n<input type=\"hidden\" name=\"pmid\" value=\"{$pmid}\" />\r\n<input type=\"hidden\" name=\"do\" value=\"{$do}\" />\r\n<div style=\"text-align:center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->send_message}\" tabindex=\"4\" accesskey=\"s\" />  <input type=\"submit\" class=\"button\" name=\"saveasdraft\" value=\"{$lang->save_draft}\" tabindex=\"5\" />  <input type=\"submit\" class=\"button\" name=\"preview\" value=\"{$lang->preview}\" tabindex=\"6\" /></div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n{$autocompletejs}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (110,'showthread_newreply_closed','<a href=\"newreply.php?tid={$tid}\"><img src=\"{$theme[''imglangdir'']}/closed.gif\" alt=\"{$lang->thread_closed}\" /></a>&nbsp;',-2,'120','',1179356756),
  (111,'polls_editpoll','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->edit_poll}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$preview}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->delete_poll}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" style=\"white-space: nowrap\"><input type=\"checkbox\" class=\"checkbox\" name=\"delete\" value=\"yes\" tabindex=\"9\" /><strong>{$lang->delete_q}</strong></td>\r\n<td class=\"trow1\" width=\"100%\">{$lang->delete_note}<br /><span class=\"smalltext\">{$lang->delete_note2}</span></td>\r\n<td class=\"trow1\" style=\"white-space: nowrap\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_poll}\" tabindex=\"10\" /></td>\r\n</table>\r\n<input type=\"hidden\" name=\"action\" value=\"do_deletepoll\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n<br />\r\n<form action=\"polls.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->edit_poll}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->question}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"question\" size=\"40\" maxlength=\"240\" value=\"{$question}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->num_options}</strong><br /><span class=\"smalltext\">{$lang->max_options} {$mybb->settings[''maxpolloptions'']}</span></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"numoptions\" size=\"10\" value=\"{$numoptions}\" />&nbsp;&nbsp;<input type=\"submit\" class=\"button\" name=\"updateoptions\" value=\"{$lang->update_options}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->poll_options}</strong></td>\r\n<td class=\"trow2\"><span class=\"smalltext\">{$lang->poll_options_note}</span>\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n{$optionbits}\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->options}</strong></td>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[multiple]\" value=\"yes\" {$postoptionschecked[''multiple'']} />&nbsp;{$lang->option_multiple}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[public]\" value=\"yes\" {$postoptionschecked[''public'']} />&nbsp;{$lang->option_public}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[closed]\" value=\"yes\" {$postoptionschecked[''closed'']} />&nbsp;{$lang->option_closed}</label>\r\n</span>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->poll_timeout}</strong><br /><span class=\"smalltext\">{$lang->timeout_note}</span></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"timeout\" value=\"{$timeout}\" /> {$lang->days_after} {$polldate}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_poll}\" />\r\n</div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_editpoll\" />\r\n<input type=\"hidden\" name=\"pid\" value=\"{$pid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (112,'forumbit_depth1_cat','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<thead>\r\n<tr>\r\n<td class=\"thead\" colspan=\"5\">\r\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/{$expcolimage}\" id=\"cat_{$forum[''fid'']}_img\" class=\"expander\" alt=\"{$expaltext}\" /></div>\r\n<div><strong><a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><div class=\"smalltext\">{$forum[''description'']}</div></div>\r\n</td>\r\n</tr>\r\n</thead>\r\n<tbody style=\"{$expdisplay}\" id=\"cat_{$forum[''fid'']}_e\">\r\n<tr>\r\n<td class=\"tcat\" width=\"35\">&nbsp;</td>\r\n<td class=\"tcat\"><strong>{$lang->forumbit_forum}</strong></td>\r\n<td class=\"tcat\" width=\"85\" align=\"center\" style=\"white-space: nowrap\"><strong>{$lang->forumbit_threads}</strong></td>\r\n<td class=\"tcat\" width=\"85\" align=\"center\" style=\"white-space: nowrap\"><strong>{$lang->forumbit_posts}</strong></td>\r\n<td class=\"tcat\" width=\"200\" align=\"center\"><strong>{$lang->forumbit_lastpost}</strong></td>\r\n</tr>\r\n{$sub_forums}\r\n</tbody>\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (113,'postbit_edit','<a href=\"editpost.php?pid={$post[''pid'']}\" id=\"edit_post_{$post[''pid'']}\"><img src=\"{$theme[''imglangdir'']}/postbit_edit.gif\" alt=\"{$lang->postbit_edit}\" title=\"{$lang->postbit_edit}\" /></a>\r\n<script type=\"text/javascript\">\r\n\tdocument.write(''<div id=\"edit_post_{$post[''pid'']}_popup\" class=\"popup_menu\" style=\"display: none;\"><div class=\"popup_item_container\"><a href=\"javascript:;\" onclick=\"Thread.quickEdit({$post[''pid'']});\" class=\"popup_item\">{$lang->postbit_quick_edit}<\\/a><\\/div><div class=\"popup_item_container\"><a href=\"editpost.php?pid={$post[''pid'']}\" class=\"popup_item\">{$lang->postbit_full_edit}<\\/a><\\/div><\\/div>'');\r\n\tnew PopupMenu(\"edit_post_{$post[''pid'']}\");\r\n</script>',-2,'120','',1179356756),
  (114,'postbit_email','<a href=\"member.php?action=emailuser&amp;uid={$post[''uid'']}\"><img src=\"{$theme[''imglangdir'']}/postbit_email.gif\" alt=\"{$lang->postbit_email}\" title=\"{$lang->postbit_email}\" /></a>',-2,'120','',1179356756),
  (115,'postbit_find','<a href=\"search.php?action=finduser&amp;uid={$post[''uid'']}\"><img src=\"{$theme[''imglangdir'']}/postbit_find.gif\" alt=\"{$lang->postbit_find}\" title=\"{$lang->postbit_find}\" /></a>',-2,'120','',1179356756),
  (116,'postbit_pm','<a href=\"private.php?action=send&amp;uid={$post[''uid'']}\"><img src=\"{$theme[''imglangdir'']}/postbit_pm.gif\" alt=\"{$lang->postbit_pm}\" title=\"{$lang->postbit_pm}\" /></a>',-2,'120','',1179356756),
  (117,'postbit_profile','<a href=\"member.php?action=profile&amp;uid={$post[''uid'']}\"><img src=\"{$theme[''imglangdir'']}/postbit_profile.gif\" alt=\"{$lang->postbit_profile}\" title=\"{$lang->postbit_profile}\" /></a>',-2,'120','',1179356756),
  (118,'postbit_quickdelete','<script type=\"text/javascript\">\r\ndocument.write(''<a href=\"javascript:Thread.deletePost({$post[''pid'']});\"><img src=\"{$theme[''imglangdir'']}\\/postbit_delete.gif\" alt=\"{$lang->postbit_qdelete}\" title=\"{$lang->postbit_qdelete}\" \\/><\\/a>'');\r\n</script>',-2,'120','',1179356756),
  (119,'postbit_quote','<a href=\"newreply.php?tid={$tid}&amp;pid={$post[''pid'']}\"><img src=\"{$theme[''imglangdir'']}/postbit_quote.gif\" alt=\"{$lang->postbit_quote}\" title=\"{$lang->postbit_quote}\" /></a>',-2,'120','',1179356756),
  (120,'postbit_report','<a href=\"javascript:Thread.reportPost({$post[''pid'']});\"><img src=\"{$theme[''imglangdir'']}/postbit_report.gif\" alt=\"{$lang->postbit_report}\" title=\"{$lang->postbit_report}\" /></a>',-2,'120','',1179356756),
  (121,'postbit_www','<a href=\"{$post[''website'']}\" target=\"_blank\"><img src=\"{$theme[''imglangdir'']}/postbit_www.gif\" alt=\"{$lang->postbit_website}\" title=\"{$lang->postbit_website}\" /></a>',-2,'120','',1179356756),
  (122,'polls_showresults_resultbit','<tr>\r\n<td class=\"{$optionbg}\" align=\"right\">{$option}{$votestar}</td>\r\n<td class=\"{$optionbg}\"><img src=\"{$theme[''imgdir'']}/pollbar-s.gif\" alt=\"\" /><img src=\"{$theme[''imgdir'']}/pollbar.gif\" width=\"{$imagewidth}\" height=\"10\" alt=\"{$percent}%\" /><img src=\"{$theme[''imgdir'']}/pollbar-e.gif\" alt=\"\" /><br />{$userlist}</td>\r\n<td class=\"{$optionbg}\" width=\"67\" align=\"center\"><a href=\"polls.php?action=showresults&amp;pid={$poll[''pid'']}#option{$number}\">{$votes}</a></td>\r\n<td class=\"{$optionbg}\" width=\"67\" align=\"center\">{$percent}%</td>\r\n</tr>\r\n',-2,'120','',1179356756),
  (123,'showthread_poll_resultbit','<tr>\r\n<td class=\"{$optionbg}\" align=\"right\">{$option}{$votestar}</td>\r\n<td class=\"{$optionbg}\"><img src=\"{$theme[''imgdir'']}/pollbar-s.gif\" alt=\"\" /><img src=\"{$theme[''imgdir'']}/pollbar.gif\" width=\"{$imagewidth}\" height=\"10\" alt=\"{$percent}%\" /><img src=\"{$theme[''imgdir'']}/pollbar-e.gif\" alt=\"\" /></td>\r\n<td class=\"{$optionbg}\" width=\"67\" align=\"center\"><a href=\"polls.php?action=showresults&amp;pid={$poll[''pid'']}#option{$number}\">{$votes}</a></td>\r\n<td class=\"{$optionbg}\" width=\"67\" align=\"center\">{$percent}%</td>\r\n</tr>\r\n',-2,'120','',1179356756),
  (124,'showteam_usergroup','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$usergroup[''title'']}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->uname}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->email}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->pm}</strong></span></td>\r\n</tr>\r\n{$usergrouprows}\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (125,'calendar_event','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->calendar} - {$lang->view_event}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\">\r\n<strong>{$event[''subject'']}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"30%\" class=\"trow1\"><strong>{$lang->event_date}</strong></td>\r\n<td width=\"70%\" class=\"trow1\">{$eventdate}</td>\r\n</tr>\r\n<tr>\r\n<td width=\"30%\" class=\"trow2\"><strong>{$lang->event_author}</strong></td>\r\n<td width=\"70%\" class=\"trow2\">{$eventposter}</td>\r\n</tr>\r\n<tr>\r\n<td width=\"30%\" class=\"trow1\" valign=\"top\"><strong>{$lang->event_details}</strong></td>\r\n<td width=\"70%\" class=\"trow1\">\r\n{$event[''description'']}\r\n<div style=\"float: right; width: auto; clear: both;\">{$editbutton} {$deletebutton}</div></td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (126,'showteam_moderators','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\"><strong>{$lang->moderators}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->mod_username}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->mod_forums}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->mod_email}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->mod_pm}</strong></span></td>\r\n</tr>\r\n{$modrows}\r\n</table>\r\n<br/>',-2,'120','',1179356756),
  (127,'showteam_moderators_mod','<tr>\r\n<td width=\"50%\" class=\"trow1\"><a href=\"member.php?action=profile&amp;uid={$user[''uid'']}\"><strong>{$user[''username'']}</strong></a></td>\r\n<td width=\"30%\" class=\"trow2\"><span class=\"smalltext\">{$forumslist}</span></td>\r\n<td width=\"10%\" class=\"trow2\">{$emailcode}</td>\r\n<td width=\"10%\" class=\"trow1\">{$pmcode}</td>\r\n</tr>',-2,'120','',1179356756),
  (128,'report_noreason','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->report_post}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"center\">\r\n<br />\r\n<br />\r\n<strong>{$lang->report_error}</strong>\r\n<blockquote>{$lang->no_reason}</blockquote>\r\n<br /><br />\r\n<div>\r\n\t<script type=\"text/javascript\">\r\n\tdocument.write(''[<a href=\"javascript:history.go(-1);\">{$lang->go_back}</a>]'');\r\n\tdocument.write(''[<a href=\"javascript:window.close();\">{$lang->close_window}</a>]'');</script>\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (129,'reputation','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reputation_report}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\">\r\nvar delete_reputation_confirm = \"{$lang->delete_reputation_confirm}\";\r\n</script>\r\n</head>\r\n<body>\r\n{$header}\r\n{$add_reputation}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\r\n<tr>\r\n\t<td class=\"thead\"><strong>{$lang->reputation_report}</strong></td>\r\n</tr>\r\n<tr>\r\n\t<td class=\"tcat\"><strong>{$lang->summary}</strong></td>\r\n</tr>\r\n<tr>\r\n\t<td class=\"trow1\">\r\n\t<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\r\n\t\t<tr>\r\n\t\t\t<td>\r\n\t\t\t\t<span class=\"largetext\"><strong>{$username}</strong></span><br />\r\n\t\t\t\t<span class=\"smalltext\">\r\n\t\t\t\t\t({$usertitle})<br />\r\n\t\t\t\t\t<br />\r\n\t\t\t\t\t<strong>{$lang->total_reputation}:</strong> {$user[''reputation'']}<br />\r\n\t\t\t\t\t<strong class=\"reputation_positive\">{$lang->positive_count}:</strong> {$positive_count}<br />\r\n\t\t\t\t\t<strong class=\"reputation_neutral\">{$lang->neutral_count}:</strong> {$neutral_count}<br />\r\n\t\t\t\t\t<strong class=\"reputation_negative\">{$lang->negative_count}:</strong> {$negative_count}\r\n\t\t\t\t</span>\r\n\t\t\t</td>\r\n\t\t\t<td align=\"right\" style=\"width: 300px;\">\r\n\t\t\t\t\t<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder trow2\">\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<td>&nbsp;</td>\r\n\t\t\t\t\t\t\t<td><span class=\"smalltext reputation_positive\">{$lang->positive_count}</span></td>\r\n\t\t\t\t\t\t\t<td><span class=\"smalltext reputation_neutral\">{$lang->neutral_count}</span></td>\r\n\t\t\t\t\t\t\t<td><span class=\"smalltext reputation_negative\">{$lang->negative_count}</span></td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<td style=\"text-align: right;\"><span class=\"smalltext\">{$lang->last_week}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$positive_week}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$neutral_week}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$negative_week}</span></td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<td style=\"text-align: right;\"><span class=\"smalltext\">{$lang->last_month}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$positive_month}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$neutral_month}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$negative_month}</span></td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<td style=\"text-align: right;\"><span class=\"smalltext\">{$lang->last_6months}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$positive_6months}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$neutral_6months}</span></td>\r\n\t\t\t\t\t\t\t<td style=\"text-align: center;\"><span class=\"smalltext\">{$negative_6months}</span></td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t</table>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</table>\r\n\t</td>\r\n</tr>\r\n<tr>\r\n\t<td class=\"tcat\"><strong>{$lang->comments}</strong></td>\r\n</tr>\r\n{$reputation_votes}\r\n<tr>\r\n\t<td class=\"tfoot\" align=\"right\">\r\n\t<form action=\"reputation.php\" method=\"get\">\r\n\t\t<input type=\"hidden\" name=\"uid\" value=\"{$user[''uid'']}\" />\r\n\t\t<select name=\"show\">\r\n\t\t\t<option value=\"all\" {$show_selected[''all'']}>{$lang->show_all}</option>\r\n\t\t\t<option value=\"positive\" {$show_selected[''positive'']}>{$lang->show_positive}</option>\r\n\t\t\t<option value=\"neutral\" {$show_selected[''neutral'']}>{$lang->show_neutral}</option>\r\n\t\t\t<option value=\"negative\" {$show_selected[''negative'']}>{$lang->show_negative}</option>\r\n\t\t</select>\r\n\t\t<select name=\"sort\">\r\n\t\t\t<option value=\"dateline\" {$sort_selected[''last_updated'']}>{$lang->sort_updated}</option>\r\n\t\t\t<option value=\"username\" {$sort_selected[''username'']}>{$lang->sort_username}</option>\r\n\t\t</select>\r\n\t\t{$gobutton}\r\n\t</form>\r\n\t</td>\r\n</tr>\r\n</table>\r\n<div>\r\n{$multipage}\r\n</div>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (130,'misc_buddypopup','<html>\r\n<head>\r\n<title>{$lang->buddy_list}</title>\r\n<meta http-equiv=\"refresh\" content=\"60; URL=misc.php?action=buddypopup\" />\r\n{$headerinclude}\r\n</head>\r\n<body style=\"margin:0px;top:0px;left:0px\" class=\"trow2\">\r\n<table width=\"100%\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$lang->buddy_list}</strong></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\" class=\"tcat\" align=\"center\"><strong>{$lang->online}</strong></td>\r\n</tr>\r\n{$buddys[''online'']}\r\n<tr>\r\n<td colspan=\"2\" class=\"tcat\" align=\"center\"><strong>{$lang->offline}</strong></td>\r\n</tr>\r\n{$buddys[''offline'']}\r\n<tr>\r\n<td colspan=\"2\" class=\"tfoot\" align=\"center\"><span class=\"smalltext\"><a href=\"misc.php?action=buddypopup\">{$lang->refresh}</a></span></td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (131,'misc_buddypopup_user_offline','<tr>\r\n<td class=\"trow1\" width=\"100%\"><span class=\"smalltext\">{$profile_link}</span></td>\r\n<td class=\"trow1\" align=\"right\" style=\"white-space: nowrap\"><span class=\"smalltext\">{$pmbuddy}<a href=\"misc.php?action=buddypopup&amp;removebuddy={$buddy[''uid'']}\">{$lang->delete_buddy}</a></span></td>\r\n</tr>',-2,'120','',1179356756),
  (132,'misc_buddypopup_user_online','<tr>\r\n<td class=\"trow1\" width=\"100%\"><span class=\"smalltext\">{$profile_link}</span></td>\r\n<td class=\"trow1\" align=\"right\" style=\"white-space: nowrap\"><span class=\"smalltext\">{$pmbuddy}<a href=\"misc.php?action=buddypopup&amp;removebuddy={$buddy[''uid'']}\">{$lang->delete_buddy}</a></span></td>\r\n</tr>',-2,'120','',1179356756),
  (133,'private_archive_txt','{$lang->private_messages_for}\r\n({$lang->exported_date})\r\n\r\n{$pmsdownload}',-2,'120','',1179356756),
  (134,'postbit_avatar','<img src=\"{$post[''avatar'']}\" alt=\"\" {$avatar_width_height} />',-2,'120','',1179356756),
  (135,'usercp_profile_customfield','<tr>\r\n<td><span class=\"smalltext\">\r\n{$profilefield[''name'']}:</span></td>\r\n</tr>\r\n<tr>\r\n<td>{$code}</td>\r\n</tr>\r\n',-2,'122','',1179356756),
  (136,'usercp_profile_profilefields','<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->additional_information}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\" width=\"100%\">\r\n{$customfields}\r\n</table>\r\n</fieldset>',-2,'120','',1179356756),
  (137,'private_archive','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->archive_messages}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"private.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->archive_messages}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\">{$lang->archive_note}</span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\" width=\"30%\"><strong>{$lang->folders}</strong></td>\r\n<td class=\"trow1\">{$folderlist}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\" width=\"30%\"><strong>{$lang->date_limit}</strong></td>\r\n<td class=\"trow2\"><select name=\"dayway\"><option value=\"older\">{$lang->date_limit_older}</option><option value=\"newer\">{$lang->date_limit_newer}</option><option value=\"disregard\">{$lang->date_limit_disregard}</option></select> <input type=\"text\" class=\"textbox\" name=\"daycut\" value=\"30\" size=\"3\" maxlength=\"4\" /> {$lang->date_limit_days}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\" width=\"30%\"><strong>{$lang->export_unread}</strong></td>\r\n<td class=\"trow1\"><input type=\"radio\" class=\"radio\" name=\"exportunread\" value=\"yes\" /> {$lang->yes} <input type=\"radio\" class=\"radio\" name=\"exportunread\" value=\"no\" checked=\"checked\" /> {$lang->no} </td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\" width=\"30%\"><strong>{$lang->delete_archived}</strong><br /><span class=\"smalltext\">{$lang->delete_archived_note}</span></td>\r\n<td class=\"trow2\"><input type=\"radio\" class=\"radio\" name=\"deletepms\" value=\"yes\" /> {$lang->yes} <input type=\"radio\" class=\"radio\" name=\"deletepms\" value=\"no\" checked=\"checked\" /> {$lang->no} </td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\" width=\"30%\"><strong>{$lang->export_format}</strong><br /><span class=\"smalltext\">{$lang->export_format_note}</span></td>\r\n<td class=\"trow1\"><input type=\"radio\" class=\"radio\" name=\"exporttype\" value=\"html\" checked=\"checked\" /> {$lang->export_html}<br /><input type=\"radio\" class=\"radio\" name=\"exporttype\" value=\"txt\" /> {$lang->export_txt}<br /><input type=\"radio\" class=\"radio\" name=\"exporttype\" value=\"csv\" /> {$lang->export_csv}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_export\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->archive_messages}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (138,'calendar_addevent','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->calendar} - {$lang->add_event}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$event_errors}\r\n<form action=\"calendar.php\" method=\"post\" name=\"input\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\r\n<tr>\r\n<td colspan=\"2\" width=\"100%\" class=\"thead\"><strong>{$lang->add_event}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"20%\" class=\"trow1\"><strong>{$lang->event_date}</strong></td>\r\n<td class=\"trow1\">\r\n<select name=\"month\">\r\n<option value=\"1\"{$msel[''1'']}>{$lang->month_1}</option>\r\n<option value=\"2\"{$msel[''2'']}>{$lang->month_2}</option>\r\n<option value=\"3\"{$msel[''3'']}>{$lang->month_3}</option>\r\n<option value=\"4\"{$msel[''4'']}>{$lang->month_4}</option>\r\n<option value=\"5\"{$msel[''5'']}>{$lang->month_5}</option>\r\n<option value=\"6\"{$msel[''6'']}>{$lang->month_6}</option>\r\n<option value=\"7\"{$msel[''7'']}>{$lang->month_7}</option>\r\n<option value=\"8\"{$msel[''8'']}>{$lang->month_8}</option>\r\n<option value=\"9\"{$msel[''9'']}>{$lang->month_9}</option>\r\n<option value=\"10\"{$msel[''10'']}>{$lang->month_10}</option>\r\n<option value=\"11\"{$msel[''11'']}>{$lang->month_11}</option>\r\n<option value=\"12\"{$msel[''12'']}>{$lang->month_12}</option>\r\n</select>\r\n&nbsp;\r\n<select name=\"day\">\r\n{$dayopts}\r\n</select>\r\n&nbsp;\r\n<select name=\"year\">\r\n{$yearopts}\r\n</select>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\"20%\" class=\"trow2\"><strong>{$lang->event_name}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"subject\" maxlength=\"120\" value=\"{$subject}\"/></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"20%\" class=\"trow1\"><strong>{$lang->event_details}</strong><div style=\"text-align: center;\">{$smilieinserter}</div></td>\r\n<td class=\"trow1\"><textarea name=\"description\" id=\"message\" rows=\"20\" cols=\"70\">{$description}</textarea>\r\n{$codebuttons}</td>\r\n</tr>\r\n<tr>\r\n<td width=\"20%\" class=\"trow2\"><strong>{$lang->event_options}</strong></td>\r\n<td class=\"trow2\">\r\n<input type=\"checkbox\" class=\"checkbox\" name=\"private\" value=\"yes\"{$privatecheck} /><span class=\"smalltext\">{$lang->private_option}</span><br />\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<input type=\"hidden\" name=\"action\" value=\"do_addevent\" />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->post_event}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (139,'private_folders_folder','<tr>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"folder[{$fid}]\" size=\"25\" value=\"{$foldername}\" maxlength=\"30\" /></td>\r\n</tr>',-2,'120','',1179356756),
  (140,'private_folders_folder_unremovable','<tr>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"folder[{$fid}]\" size=\"25\" value=\"{$foldername}\" /><span class=\"smalltext\">({$foldername2} - {$lang->cannot_be_removed})</span>\r\n</td>\r\n</tr>',-2,'120','',1179356756),
  (141,'showteam_usergroup_user','<tr>\r\n<td width=\"80%\" class=\"{$bgcolor}\"><a href=\"member.php?action=profile&amp;uid={$user[''uid'']}\"><strong>{$user[''username'']}</strong></a></td>\r\n<td width=\"10%\" class=\"{$bgcolor}\">{$emailcode}</td>\r\n<td width=\"10%\" class=\"{$bgcolor}\">{$pmcode}</td>\r\n</tr>',-2,'120','',1179356756),
  (142,'showteam_moderators_forum','<a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a><br/>',-2,'120','',1179356756),
  (143,'moderation_inline_deleteposts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->delete_posts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->delete_posts}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\" align=\"center\">{$lang->confirm_delete_posts}\r\n{$loginbox}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_posts}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_multideleteposts\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"posts\" value=\"{$inlineids}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (144,'calendar_dayview_birthdays','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->birthdays_on_day}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">{$birthdays}</span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n',-2,'120','',1179356756),
  (145,'calendar_dayview_event','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$event[''subject'']}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"30%\" class=\"trow1\"><strong>{$lang->event_date}</strong></td>\r\n<td width=\"70%\" class=\"trow1\">{$eventdate}</td>\r\n</tr>\r\n<tr>\r\n<td width=\"30%\" class=\"trow2\"><strong>{$lang->event_author}</strong></td>\r\n<td width=\"70%\" class=\"trow2\">{$eventposter}</td>\r\n</tr>\r\n<tr>\r\n<td width=\"30%\" class=\"trow1\" valign=\"top\"><strong>{$lang->event_details}</strong></td>\r\n<td width=\"70%\" class=\"trow1\">\r\n{$event[''description'']}\r\n<div style=\"float: right; width: auto; clear: both;\">{$editbutton} {$deletebutton}</div></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356756),
  (146,'online_today','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->online_today}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" width=\"50%\"><span class=\"smalltext\"><strong>{$lang->on_username}</strong></span></td>\r\n<td class=\"thead\" align=\"center\" width=\"50%\"><span class=\"smalltext\"><strong>{$lang->time}</strong></span></td>\r\n</tr>\r\n{$todayrows}\r\n<tr>\r\n<td align=\"center\" colspan=\"2\" class=\"trow1\" style=\"white-space: nowrap\">{$onlinetoday}</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (147,'forumdisplay_thread_modbit','<td class=\"{$bgcolor}\" align=\"center\" style=\"white-space: nowrap\"><input type=\"checkbox\" class=\"checkbox\" name=\"inlinemod_{$multitid}\" id=\"inlinemod_{$multitid}\" value=\"1\" {$inlinecheck}  /></td>',-2,'120','',1179356756),
  (148,'index_pms','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr><td class=\"thead\" colspan=\"2\"><a href=\"private.php\"><strong>{$lang->private_messages}</strong></a></td></tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" width=\"2%\"><img src=\"{$theme[''imgdir'']}/{$pmfolder}\" alt=\"{$lang->private_messages}\" /></td>\r\n<td class=\"trow1\" width=\"98%\"><span class=\"smalltext\">{$lang->pms_new}<br />{$lang->pms_unread_total}</span></td>\r\n</tr>\r\n</table>\r\n',-2,'120','',1179356756),
  (149,'forumdisplay_thread_gotounread','<a href=\"showthread.php?action=newpost&amp;tid={$thread[''tid'']}\"><img src=\"{$theme[''imgdir'']}/jump.gif\" alt=\"{$lang->goto_first_unread}\" /></a> ',-2,'120','',1179356756),
  (150,'private_tracking','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->pm_tracking}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"private.php\" method=\"post\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_tracking\" />\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"5\"><strong>{$lang->read_messages}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->message_title}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->sentto}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->dateread}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"1\"><span class=\"smalltext\"><input type=\"checkbox\" class=\"checkbox\" name=\"allbox\" onclick=\"javascript:MyBB.checkAll(this.form);\" /></span></td>\r\n</tr>\r\n{$readmessages}\r\n<tr>\r\n<td class=\"tfoot\" align=\"right\" colspan=\"5\"><strong><input type=\"submit\" class=\"button\" name=\"stoptracking\" value=\"{$lang->stop_tracking}\" /> {$lang->selected_messages}</strong></td>\r\n</tr>\r\n</table>\r\n</form>\r\n<br />\r\n<form action=\"private.php\" method=\"post\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_tracking\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"5\"><strong>{$lang->unread_messages}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->message_title}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" style=\"white-space: nowrap\"><span class=\"smalltext\"><strong>{$lang->sentto}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" style=\"white-space: nowrap\"><span class=\"smalltext\"><strong>{$lang->datesent}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"1\" style=\"white-space: nowrap\"><span class=\"smalltext\"><input type=\"checkbox\" class=\"checkbox\" name=\"allbox\" onclick=\"javascript:MyBB.checkAll(this.form);\" /></span></td>\r\n</tr>\r\n{$unreadmessages}\r\n<tr>\r\n<td class=\"tfoot\" align=\"right\" colspan=\"5\"><strong><input type=\"submit\" class=\"button\" name=\"stoptrackingunread\" value=\"{$lang->stop_tracking}\" /> / <input type=\"submit\" class=\"button\" name=\"cancel\" value=\"{$lang->cancel}\" /> {$lang->selected_messages}</strong></td>\r\n</tr>\r\n</table>\r\n</td></tr></table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (151,'moderation_threadnotes','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->thread_notes_editor}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->thread_notes_editor}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\" colspan=\"2\">{$lang->below_notes}</td>\r\n</tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><textarea name=\"threadnotes\" cols=\"80\" rows=\"10\" tabindex=\"1\">{$thread[''notes'']}</textarea></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_notes}\" tabindex=\"2\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_threadnotes\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\"><strong>{$lang->mod_logs}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->mod_username}</strong></td>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->mod_date}</strong></td>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->mod_actions}</strong></td>\r\n<td class=\"tcat\" align=\"center\"><strong>{$lang->mod_information}</strong></td>\r\n</tr>\r\n{$modactions}\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356756),
  (152,'error_maxpostimages','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->error_too_many_images}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$lang->error_too_many_images2}<br /><span class=\"smalltext\">{$lang->error_too_many_images3} {$mybb->settings[''maxpostimages'']}.</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356757),
  (153,'calendar','<html>\r\n<head>\r\n\t<title>{$mybb->settings[''bbname'']} - {$lang->calendar}</title>\r\n\t{$headerinclude}\r\n</head>\r\n<body>\r\n\t{$header}\r\n\t<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t\t<tr>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->sunday}</td>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->monday}</td>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->tuesday}</td>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->wednesday}</td>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->thursday}</td>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->friday}</td>\r\n\t\t\t<td class=\"thead\" width=\"14%\" align=\"center\">{$lang->saturday}</td>\r\n\t\t</tr>\r\n\t\t{$daybits}\r\n\t</table>\r\n\r\n\t<table width=\"100%\" align=\"center\">\r\n\t\t<tr>\r\n\t\t\t<td><span class=\"smalltext\"><a href=\"calendar.php?year={$prevyear}&amp;month={$prevmonth}\">&laquo; {$monthnames[$prevmonth]} {$prevyear}</a></span></td>\r\n\t\t\t<td align=\"right\"><span class=\"smalltext\"><a href=\"calendar.php?year={$nextyear}&amp;month={$nextmonth}\">{$monthnames[$nextmonth]} {$nextyear} &raquo;</a></span></td>\r\n\t\t</tr>\r\n\t</table>\r\n\r\n\t<br />\r\n\r\n\t<form action=\"calendar.php\" method=\"post\">\r\n\t\t<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"trow1\">\r\n\t\t\t\t\t<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<td class=\"trow1\">{$addpublicevent}{$neweventsep}{$addprivateevent}</td>\r\n\t\t\t\t\t\t\t<td class=\"trow1\" align=\"right\"><span class=\"smalltext\"><strong>{$lang->jump_month}</strong>\r\n\t\t\t\t\t\t\t<select name=\"month\">\r\n\t\t\t\t\t\t\t\t<option value=\"{$month}\">{$monthnames[$month]}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"{$month}\">----------</option>\r\n\t\t\t\t\t\t\t\t<option value=\"1\">{$lang->alt_month_1}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"2\">{$lang->alt_month_2}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"3\">{$lang->alt_month_3}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"4\">{$lang->alt_month_4}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"5\">{$lang->alt_month_5}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"6\">{$lang->alt_month_6}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"7\">{$lang->alt_month_7}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"8\">{$lang->alt_month_8}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"9\">{$lang->alt_month_9}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"10\">{$lang->alt_month_10}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"11\">{$lang->alt_month_11}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"12\">{$lang->alt_month_12}</option>\r\n\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t&nbsp;\r\n\t\t\t\t\t\t\t<select name=\"year\">\r\n\t\t\t\t\t\t\t\t<option value=\"{$year}\">{$year}</option>\r\n\t\t\t\t\t\t\t\t<option value=\"{$year}\">----------</option>\r\n\t\t\t\t\t\t\t\t{$yearsel}\r\n\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t&nbsp;\r\n\t\t\t\t\t\t\t{$gobutton}\r\n\t\t\t\t\t\t</span></td>\r\n\t\t\t\t\t</tr>\r\n\t\t\t\t</table>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</table>\r\n\t</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (154,'private_archive_html','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->private_messages_for}</title>\r\n<style type=\"text/css\">{$css}</style>\r\n</head>\r\n<body>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"1\"><span class=\"largetext\"><strong>{$lang->private_messages_for}</strong></span></td>\r\n</tr>\r\n{$pmsdownload}\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" colspan=\"1\">{$lang->exported_date}<br /><a href=\"{$mybb->settings[''bburl'']}\">{$mybb->settings[''bbname'']}</a></td>\r\n</tr>\r\n</table>\r\n</body>',-2,'120','',1179356757),
  (155,'private_messagebit','<tr>\r\n<td align=\"center\" class=\"trow1\" width=\"5%\"><img src=\"{$theme[''imgdir'']}/{$msgfolder}\" alt=\"{$msgalt}\"/></td>\r\n<td align=\"center\" class=\"trow2\" width=\"5%\">{$icon}</td>\r\n<td class=\"trow1\" width=\"35%\"><a href=\"private.php?action=read&amp;pmid={$message[''pmid'']}\">{$message[''subject'']}</a>{$denyreceipt}</td>\r\n<td align=\"center\" class=\"trow2\">{$tofromusername}</td>\r\n<td class=\"trow1\" align=\"right\" style=\"white-space: nowrap\"><span class=\"smalltext\">{$senddate} {$sendtime}</span></td>\r\n<td class=\"trow2\" align=\"center\"><input type=\"checkbox\" class=\"checkbox\" name=\"check[{$message[''pmid'']}]\" value=\"yes\" /></td>\r\n</tr>',-2,'120','',1179356757),
  (156,'private_nomessages','<tr>\r\n<td colspan=\"6\" class=\"trow1\">{$lang->nomessages}</td>\r\n</tr>',-2,'120','',1179356757),
  (157,'private_send_buddyselect','<br /><span class=\"smalltext\">{$lang->select_buddy}<br /><select name=\"buddy\" onchange=\"document.input.to.value=this.options[this.selectedIndex].value\"><option value=\"\" tabindex=\"2\">&nbsp;</option>{$buddies}</select>',-2,'120','',1179356757),
  (158,'codebuttons','<script type=\"text/javascript\" src=\"jscripts/editor.js?ver=121\"></script>\r\n<script type=\"text/javascript\">\r\n\t{$editor_language}\r\n\tvar clickableEditor = new messageEditor(\"message\", {lang: editor_language, rtl: {$lang->settings[''rtl'']}});\r\n\tclickableEditor.bindSmilieInserter(\"clickable_smilies\");\r\n</script>',-2,'120','',1179356757),
  (159,'showthread_quickreply','<br />\r\n<form method=\"post\" action=\"newreply.php\" name=\"input\">\r\n<input type=\"hidden\" name=\"subject\" value=\"RE: {$thread[''subject'']}\" />\r\n<input type=\"hidden\" name=\"action\" value=\"do_newreply\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"posthash\" value=\"{$posthash}\" />\r\n<input type=\"hidden\" name=\"quoted_ids\" value=\"\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<thead>\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\">\r\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/collapse{$collapsedimg[''quickreply'']}.gif\" id=\"quickreply_img\" class=\"expander\" alt=\"[-]\"/></div>\r\n<div><strong>{$lang->quick_reply}</strong></div>\r\n</td>\r\n</tr>\r\n</thead>\r\n<tbody style=\"{$collapsed[''quickreply_e'']}\" id=\"quickreply_e\">\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\" width=\"22%\">\r\n<strong>{$lang->message}</strong><br />\r\n<span class=\"smalltext\">{$lang->message_note}<br /><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[signature]\" value=\"yes\" {$postoptionschecked[''signature'']} />&nbsp;<strong>{$lang->signature}</strong></label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[emailnotify]\" value=\"yes\" {$postoptionschecked[''emailnotify'']} />&nbsp;<strong>{$lang->email_notify}</strong></label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[disablesmilies]\" value=\"yes\" />&nbsp;<strong>{$lang->disable_smilies}</strong></label>{$closeoption}</span>\r\n</td>\r\n<td class=\"trow1\">\r\n\t<div>\r\n\t\t<textarea style=\"width: 90%; margin: 0;\" rows=\"8\" cols=\"80\" name=\"message\" id=\"message\" tabindex=\"1\"></textarea>\r\n\t</div>\r\n\t<script type=\"text/javascript\">document.write(''<div class=\"editor_control_bar\" style=\"width: 90%; padding: 4px; margin-top: 3px; display: none;\" id=\"quickreply_multiquote\"><span class=\"smalltext\">{$lang->quickreply_multiquote_selected} <a href=\"javascript:Thread.loadMultiQuoted();\">{$lang->quickreply_multiquote_now}<\\/a> {$lang->or} <a href=\"javascript:Thread.clearMultiQuoted();\">{$lang->quickreply_multiquote_deselect}<\\/a>.<\\/span><\\/div>'');</script>\r\n</td>\r\n</tr>\r\n{$captcha}\r\n<tr>\r\n<td colspan=\"2\" align=\"center\" class=\"tfoot\"><input type=\"submit\" class=\"button\" value=\"{$lang->post_reply}\" tabindex=\"2\" accesskey=\"s\" /> <input type=\"submit\" class=\"button\" name=\"previewpost\" value=\"{$lang->preview_post}\" tabindex=\"3\" /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</form>',-2,'127','',1179356757),
  (160,'memberlist','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->member_list}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"6\"><strong>{$lang->member_list}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->username}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->email}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->website}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->location}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->joined}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->posts}</strong></span></td>\r\n</tr>\r\n{$member}\r\n<tr>\r\n<td align=\"center\" colspan=\"6\" class=\"tfoot\">\r\n<form action=\"memberlist.php\" method=\"post\">\r\n<input type=\"hidden\" name=\"page\" value=\"{$page}\" />\r\n{$lang->sort_by} <select name=\"by\">\r\n<option value=\"regdate\"{$regdatesel}>{$lang->sort_regdate}</option>\r\n<option value=\"username\"{$usernamesel}>{$lang->sort_username}</option>\r\n<option value=\"postnum\"{$postnumsel}>{$lang->sort_posts}</option>\r\n</select> {$lang->sort_in} <select name=\"order\">\r\n<option value=\"ASC\"{$ascsel}>{$lang->sort_asc}</option>\r\n<option value=\"DESC\"{$descsel}>{$lang->sort_desc}</option>\r\n</select> {$lang->order} {$lang->search_for} <input type=\"text\" class=\"textbox\" name=\"usersearch\" value=\"{$usersearch}\" size=\"20\" /> {$gobutton}\r\n</form>\r\n</td>\r\n</tr>\r\n</table>\r\n<table align=\"center\" width=\"100%\"><tr>\r\n<td><span class=\"smalltext\">[<a href=\"showteam.php\">{$lang->forumteam}</a>]</span></td>\r\n<td align=\"right\">{$multipage}</td>\r\n</tr></table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (161,'private','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->private_messaging}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"private.php\" method=\"post\" name=\"pmForm\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tr>\r\n<td class=\"trow1\">{$pmspacebar}<span class=\"smalltext\"><a href=\"private.php\">{$lang->inbox}</a> | <a href=\"private.php?action=send\">{$lang->compose_message2}</a> | <a  href=\"private.php?action=folders\">{$lang->manage_folders}</a></span></td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n{$limitwarning}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"6\"><strong>{$lang->pms_in_folder}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\" colspan=\"2\">&nbsp;</td>\r\n<td class=\"tcat\" align=\"center\" width=\"35%\"><span class=\"smalltext\"><strong>{$lang->message_title}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"30%\" style=\"white-space: nowrap\"><span class=\"smalltext\"><strong>{$sender}</strong></span></td>\r\n<td class=\"tcat\" align=\"right\"  width=\"20%\" style=\"white-space: nowrap\"><span class=\"smalltext\"><strong>{$lang->date_sent}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"5%\" style=\"white-space: nowrap\"><span class=\"smalltext\"><input name=\"allbox\" title=\"Select All\" type=\"checkbox\" class=\"checkbox\" value=\"Check All\" onClick=\"MyBB.checkAll(this.form)\" /></span></td>\r\n</tr>\r\n{$messagelist}\r\n<tr>\r\n<td class=\"tfoot\" align=\"right\" colspan=\"6\"><input type=\"submit\" class=\"button\" name=\"moveto\" value=\"{$lang->move_to}\" /> {$folderoplist} {$lang->or} <input type=\"submit\" class=\"button\" name=\"delete\" value=\"{$lang->delete}\" /> {$lang->selected_messages}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tr>\r\n<td class=\"trow1\">{$multipage}</td>\r\n<td class=\"trow1\" align=\"right\"><span class=\"smalltext\"><strong>{$lang->jump_folder} {$folderjump} <input type=\"submit\" class=\"button\" name=\"hop\" value=\"{$lang->go}\" /></strong></span></td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<input type=\"hidden\" name=\"action\" value=\"do_stuff\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (162,'private_pmspace','<span style=\"float:right\"><table cellspacing=\"0\" cellpadding=\"0\" width=\"230\" style=\"border: solid 1px #000000;\">\r\n\t<tr>\r\n\t\t<td width=\"{$spaceused}\" bgcolor=\"red\" align=\"center\"><span class=\"smalltext\"><strong>{$overhalf}</strong></span></td>\r\n\t\t<td width=\"{$spaceused2}\" bgcolor=\"green\" align=\"center\"><span class=\"smalltext\"><strong>{$belowhalf}</strong></span></td>\r\n\t\t<td width=\"130\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->pmspaceused}</strong></span></td>\r\n\t</tr>\r\n</table></span>',-2,'120','',1179356757),
  (163,'forumdisplay_announcements_announcement','<tr>\r\n<td align=\"center\" class=\"{$bgcolor}\"><img src=\"{$theme[''imgdir'']}/{$folder}\" alt=\"\"/></td>\r\n<td align=\"center\" class=\"{$bgcolor}\">&nbsp;</td>\r\n<td class=\"{$bgcolor}\"><a href=\"announcements.php?aid={$announcement[''aid'']}\">{$announcement[''subject'']}</a></td>\r\n<td align=\"center\" class=\"{$bgcolor}\"><a href=\"member.php?action=profile&amp;uid={$announcement[''uid'']}\">{$announcement[''username'']}</a></td>\r\n<td align=\"center\" class=\"{$bgcolor}\">-</td>\r\n<td align=\"center\" class=\"{$bgcolor}\">-</td>\r\n{$rating}\r\n<td class=\"{$bgcolor}\" style=\"white-space: nowrap\">{$postdate} {$posttime}</td>\r\n{$modann}\r\n</tr>\r\n',-2,'120','',1179356757),
  (164,'forumdisplay_announcements','<tr>\r\n<td class=\"trow_sep\" colspan=\"{$colspan}\">{$lang->forum_announcements}</td>\r\n</tr>\r\n{$announcements}',-2,'120','',1179356757),
  (165,'forumdisplay_sticky_sep','<tr>\r\n<td class=\"trow_sep\" colspan=\"{$colspan}\">{$lang->sticky_threads}</td>\r\n</tr>',-2,'120','',1179356757),
  (166,'forumdisplay_threads_sep','<tr>\r\n<td class=\"trow_sep\" colspan=\"{$colspan}\">{$lang->normal_threads}</td>\r\n</tr>',-2,'120','',1179356757),
  (167,'postbit','<tr>\r\n<td class=\"{$altbg}\" width=\"15%\" valign=\"top\" style=\"white-space: nowrap; text-align: center;\"><a name=\"pid{$post[''pid'']}\" id=\"pid{$post[''pid'']}\"></a>\r\n{$post[''user_details'']}\r\n</td>\r\n<td class=\"{$altbg}\" width=\"85%\" valign=\"top\">\r\n<table width=\"100%\">\r\n<tr><td>{$post[''posturl'']}{$post[''icon'']}<span class=\"smalltext\"><strong> {$post[''subject'']}</strong></span>\r\n<br />\r\n<div id=\"pid_{$post[''pid'']}\">\r\n<p>\r\n{$post[''message'']}\r\n</p>\r\n</div>\r\n{$post[''attachments'']}\r\n{$post[''signature'']}\r\n<div style=\"text-align: right; vertical-align: bottom;\">\r\n{$post[''editedmsg'']}\r\n{$post[''iplogged'']}\r\n</div>\r\n</td></tr>\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"{$altbg}\" height=\"18\" style=\"white-space: nowrap; text-align: center;\"><span class=\"smalltext\">{$post[''postdate'']} {$post[''posttime'']}</span></td>\r\n<td class=\"{$altbg}\" width=\"100%\" valign=\"middle\" height=\"18\">\r\n\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n\t<tr valign=\"bottom\">\r\n\t\t<td align=\"left\" ><span class=\"smalltext\">{$post[''button_email'']}{$post[''button_pm'']}{$post[''button_www'']}{$post[''button_find'']}</span></td>\r\n\t\t<td align=\"right\"><span class=\"smalltext\">{$post[''button_edit'']}{$post[''button_quickdelete'']}{$post[''button_quote'']}{$post[''button_multiquote'']}{$post[''button_report'']}</span></td>\r\n\t</tr>\r\n\t</table>\r\n</td>\r\n</tr>\r\n{$seperator}',-2,'121','',1179356757),
  (168,'postbit_seperator','<tr>\r\n<td class=\"trow_sep\" colspan=\"2\"><img src=\"{$theme[''imgdir'']}/pixel.gif\" height=\"1\" width=\"1\" alt=\"\" /></td>\r\n</tr>',-2,'120','',1179356757),
  (169,'forumdisplay_threadlist_clearpass',' | <a href=\"misc.php?action=clearpass&amp;fid={$fid}\">{$lang->clear_stored_password}</a>',-2,'120','',1179356757),
  (170,'portal_welcome_guesttext','<span class=\"smalltext\">{$lang->guest_welcome_registration}<br />\r\n<br />\r\n<form method=\"post\" action=\"{$portal_url}\"><input type=\"hidden\" name=\"action\" value=\"do_login\" />\r\n{$lang->username}<br />&nbsp;&nbsp;<input type=\"text\" class=\"textbox\" name=\"username\" value=\"\" /><br /><br />\r\n{$lang->password}<br />&nbsp;&nbsp;<input type=\"password\" class=\"textbox\" name=\"password\" value=\"\" /><br />\r\n<br /><input type=\"submit\" class=\"button\" name=\"loginsubmit\" value=\"{$lang->login}\" /></form>',-2,'121','',1179356757),
  (171,'portal_latestthreads_thread','<tr>\r\n<td class=\"{$altbg}\">\r\n<strong><a href=\"{$mybb->settings[''bburl'']}/showthread.php?tid={$thread[''tid'']}\">{$thread[''subject'']}</a></strong>\r\n<span class=\"smalltext\"><br />\r\n<em>{$lang->latest_threads_lastpost}</em> {$lastposterlink}<br />\r\n{$lastpostdate} {$lastposttime}<br />\r\n<strong>&raquo; </strong>{$lang->latest_threads_replies} {$thread[''replies'']}<br />\r\n<strong>&raquo; </strong>{$lang->latest_threads_views} {$thread[''views'']}\r\n</span>\r\n</td>\r\n</tr>',-2,'120','',1179356757),
  (172,'search','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->search}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form method=\"post\" action=\"search.php\"><input type=\"hidden\" name=\"action\" value=\"do_search\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$mybb->settings[''bbname'']} - {$lang->search}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"50%\"><strong>{$lang->search_keyword}</strong></td>\r\n<td class=\"tcat\" width=\"50%\"><strong>{$lang->search_username}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<table><tr>\r\n<td valign=\"top\"><input type=\"text\" class=\"textbox\" name=\"keywords\" size=\"35\" maxlength=\"250\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<span class=\"smalltext\"><input type=\"radio\" class=\"radio\" name=\"postthread\" value=\"1\" checked=\"checked\" />{$lang->search_entire_post}<br /><input type=\"radio\" class=\"radio\" name=\"postthread\" value=\"2\" />{$lang->search_titles_only}</span></td>\r\n</tr></table>\r\n</td>\r\n<td class=\"trow1\">\r\n<table><tr>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"author\" size=\"35\" maxlength=\"{$mybb->settings[''maxnamelength'']}\" /><br /><span class=\"smalltext\"><input type=\"checkbox\" class=\"checkbox\" name=\"matchusername\" value=\"1\" checked=\"checked\" />&nbsp; {$lang->match_username}</span></td>\r\n<td class=\"trow1\">&nbsp;</td>\r\n</tr></table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><strong>{$lang->search_forums}</strong></td>\r\n<td class=\"tcat\"><strong>{$lang->search_options}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" rowspan=\"5\">{$srchlist}</td>\r\n<td class=\"trow1\">\r\n<select name=\"findthreadst\">\r\n<option value=\"1\">{$lang->threads_at_least}</option>\r\n<option value=\"2\">{$lang->threads_at_most}</option>\r\n</select> <input type=\"text\" class=\"textbox\" name=\"numreplies\" size=\"2\" maxlength=\"4\" />{$lang->replies2}<br />\r\n<br />\r\n<select name=\"postdate\">\r\n<option value=\"0\">{$lang->find_anydate}</option>\r\n<option value=\"1\">{$lang->find_yesterday}</option>\r\n<option value=\"7\">{$lang->find_lastweek}</option>\r\n<option value=\"14\">{$lang->find_2weeks}</option>\r\n<option value=\"30\">{$lang->find_month}</option>\r\n<option value=\"90\">{$lang->find_3months}</option>\r\n<option value=\"180\">{$lang->find_6months}</option>\r\n<option value=\"365\">{$lang->find_year}</option>\r\n</select>&nbsp;&nbsp; <input type=\"radio\" class=\"radio\" name=\"pddir\" value=\"1\" checked=\"checked\" />{$lang->and_newer}  <input type=\"radio\" class=\"radio\" name=\"pddir\" value=\"0\" />{$lang->and_older}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><strong>{$lang->sorting_options}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<select name=\"sortby\">\r\n<option value=\"lastpost\">{$lang->sort_lastpost}</option>\r\n<option value=\"starter\">{$lang->sort_author}</option>\r\n<option value=\"forum\">{$lang->sort_forum}</option>\r\n</select> {$lang->sort_in} <input type=\"radio\" class=\"radio\" name=\"sorder\" value=\"asc\" />{$lang->sort_asc} <input type=\"radio\" class=\"radio\" name=\"sorder\" value=\"desc\" checked=\"checked\" />{$lang->sort_desc} {$lang->sort_order}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><strong>{$lang->display_options}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$lang->show_results_as} <input type=\"radio\" class=\"radio\" name=\"showresults\" value=\"threads\" checked=\"checked\" />{$lang->show_results_threads} <input type=\"radio\" class=\"radio\" name=\"showresults\" value=\"posts\" />{$lang->show_results_posts}</td>\r\n</tr>\r\n</table>\r\n<div align=\"center\"><br /><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->search}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>\r\n',-2,'120','',1179356757),
  (173,'postbit_groupimage','<img src=\"{$usergroup[''image'']}\" alt=\"{$usergroup[''title'']}\" />',-2,'120','',1179356757),
  (174,'showthread_newreply','<a href=\"newreply.php?tid={$tid}\"><img src=\"{$theme[''imglangdir'']}/newreply.gif\" alt=\"{$lang->post_reply_img}\" /></a>&nbsp;',-2,'120','',1179356757),
  (175,'showthread_newthread','<a href=\"newthread.php?fid={$fid}\"><img src=\"{$theme[''imglangdir'']}/newthread.gif\" alt=\"{$lang->post_thread}\" /></a>&nbsp;',-2,'120','',1179356757),
  (176,'member_profile_groupimage','<img src=\"{$displaygroup[''image'']}\" alt=\"{$usertitle}\" /><br />',-2,'120','',1179356757),
  (177,'misc_help_section','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\r\n<thead>\r\n<tr>\r\n<td class=\"thead\"><div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/{$expcolimage}\" id=\"sid_{$section[''sid'']}_img\" class=\"expander\" alt=\"[-]\" /></div><div><strong>{$section[''name'']}</strong></div></td>\r\n</tr>\r\n</thead>\r\n<tbody style=\"{$expdisplay}\" id=\"sid_{$section[''sid'']}_e\">\r\n<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\">{$section[''description'']}</span></td>\r\n</tr>\r\n{$helpbits}\r\n</tbody>\r\n</table>\r\n<br />',-2,'120','',1179356757),
  (178,'announcement','<html>\r\n<head>\r\n<title>{$lang->announcements}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->forum_announcement}</strong></td>\r\n</tr>\r\n{$announcement}\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>&nbsp;</strong></td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (179,'member_emailuser','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->email_user}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"member.php\" method=\"post\" name=\"input\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" width=\"100%\" class=\"thead\"><strong>{$lang->email_user}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"40%\" class=\"trow1\"><strong>{$lang->username}</strong></td>\r\n<td width=\"60%\" class=\"trow1\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"touser\" value=\"{$emailto[''username'']}\" /></td>\r\n</tr>\r\n{$guestfields}\r\n<tr>\r\n<td width=\"40%\" class=\"trow2\"><strong>{$lang->email_subject}</strong></td>\r\n<td width=\"60%\" class=\"trow2\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"subject\" /></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"40%\" class=\"trow1\"><strong>{$lang->email_message}</strong></td>\r\n<td width=\"60%\" class=\"trow1\"><textarea cols=\"50\" rows=\"10\" name=\"message\"></textarea></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<input type=\"hidden\" name=\"action\" value=\"do_emailuser\" />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->send_email}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (180,'changeuserbox','<tr>\r\n<td class=\"trow1\" width=\"20%\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow1\">{$mybb->user[''username'']} <span class=\"smalltext\">[<strong><a href=\"member.php?action=logout&amp;uid={$mybb->user[''uid'']}\">{$lang->change_user}</a></strong>]</span></td>\r\n</tr>\r\n',-2,'120','',1179356757),
  (181,'showthread_poll_results','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\" align=\"center\"><strong>{$lang->poll} {$poll[''question'']}</strong><br /><span class=\"smalltext\">{$pollstatus}</span></td>\r\n</tr>\r\n{$polloptions}\r\n<tr>\r\n<td class=\"tfoot\" align=\"right\" colspan=\"2\"><strong>{$lang->total}</strong></td>\r\n<td class=\"tfoot\" align=\"center\"><strong>{$lang->total_votes}</strong></td>\r\n<td class=\"tfoot\" align=\"center\"><strong>{$totpercent}</strong></td>\r\n</tr>\r\n</table>\r\n<table cellspacing=\"0\" cellpadding=\"2\" border=\"0\" width=\"100%\" align=\"center\">\r\n<tr>\r\n<td align=\"left\"><span class=\"smalltext\">{$lang->you_voted}</span></td>\r\n<td align=\"right\"><span class=\"smalltext\">[<a href=\"polls.php?action=showresults&amp;pid={$poll[''pid'']}\">{$lang->show_results}</a>{$edit_poll}]</span></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356757),
  (182,'polls_showresults','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->poll_results}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\" align=\"center\"><strong>{$poll[''question'']}</strong></td>\r\n</tr>\r\n{$polloptions}\r\n<tr>\r\n<td class=\"tfoot\" align=\"right\" colspan=\"2\"><strong>{$lang->poll_total}</strong></td>\r\n<td class=\"tfoot\" align=\"center\"><strong>{$poll[''numvotes'']} {$lang->poll_votes}</strong></td>\r\n<td class=\"tfoot\" align=\"center\"><strong>{$totpercent}</strong></td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (183,'member_register_password','<tr>\r\n<td><span class=\"smalltext\">{$lang->password}</span></td>\r\n<td><span class=\"smalltext\">{$lang->confirm_password}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"password\" class=\"textbox\" name=\"password\" size=\"20\" /></td>\r\n<td><input type=\"password\" class=\"textbox\" name=\"password2\" size=\"20\" /></td>\r\n</tr>\r\n',-2,'120','',1179356757),
  (184,'usercp_forumsubscriptions_forum','<tr>\r\n<td class=\"trow1\" align=\"center\" valign=\"top\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" valign=\"top\" /></td>\r\n<td class=\"trow1\" valign=\"top\">\r\n<strong><a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><span class=\"smalltext\"><a href=\"usercp2.php?action=removesubscription&amp;type=forum&amp;fid={$forum[''fid'']}\">{$lang->unsubscribe}</a> | <a href=\"newthread.php?fid={$forum[''fid'']}\">{$lang->new_thread}</a></span></td>\r\n<td class=\"trow2\" valign=\"top\" style=\"white-space: nowrap; text-align: center;\">{$posts}</td>\r\n<td class=\"trow1\" valign=\"top\" style=\"white-space: nowrap; text-align: center;\">{$threads}</td>\r\n<td class=\"trow2\" valign=\"top\" style=\"white-space: nowrap\">{$lastpost}</td>\r\n</tr>',-2,'120','',1179356757),
  (185,'newthread_postpoll','<tr>\r\n<td class=\"{$bgcolor}\" valign=\"top\">\r\n<strong>{$lang->poll}</strong><br /><span class=\"smalltext\">{$lang->poll_desc}</span>\r\n</td>\r\n<td class=\"{$bgcolor}\" valign=\"top\">\r\n<span class=\"smalltext\"><input type=\"checkbox\" class=\"checkbox\" name=\"postpoll\" value=\"yes\" {$postpollchecked} /><strong>{$lang->poll_check}</strong><br />\r\n{$lang->num_options} <input type=\"text\" class=\"textbox\" name=\"numpolloptions\" value=\"{$numpolloptions}\" size=\"10\" />{$lang->max_options}</span>\r\n</td>\r\n</tr>',-2,'120','',1179356757),
  (186,'moderation_reports','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reported_posts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"6\"><strong>{$lang->reported_posts}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><span class=\"smalltext\"><strong>{$lang->post_id}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"15%\"><span class=\"smalltext\"><strong>{$lang->poster}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"25%\"><span class=\"smalltext\"><strong>{$lang->thread}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"15%\"><span class=\"smalltext\"><strong>{$lang->reporter}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"25%\"><span class=\"smalltext\"><strong>{$lang->report_reason}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><span class=\"smalltext\"><strong>{$lang->report_time}</strong></span></td>\r\n</tr>\r\n{$reports}\r\n{$reportspages}\r\n<tr>\r\n<td class=\"tfoot\" colspan=\"6\" align=\"right\"><span class=\"smalltext\"><strong><a href=\"moderation.php?action=allreports\">{$lang->view_all_reported_posts}</a></strong></span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"hidden\" name=\"action\" value=\"do_reports\" /><input type=\"submit\" class=\"button\" name=\"reportsubmit\" value=\"{$lang->mark_read}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (187,'moderation_reports_report','<tr>\r\n<td class=\"{$trow}\" align=\"center\"><label for=\"reports_{$report[''rid'']}\"><input type=\"checkbox\" class=\"checkbox\" name=\"reports[]\" id=\"reports_{$report[''rid'']}\" value=\"{$report[''rid'']}\" />&nbsp;<a href=\"showthread.php?pid={$report[''pid'']}&amp;tid={$report[''tid'']}#pid{$report[''pid'']}\" target=\"_blank\">{$report[''pid'']}</a></label></td>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"member.php?action=profile&amp;uid={$report[''postuid'']}\" target=\"_blank\">{$report[''postusername'']}</a></td>\r\n<td class=\"{$trow}\"><a href=\"showthread.php?tid={$report[''tid'']}\" target=\"_blank\">{$report[''threadsubject'']}</a></td>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"member.php?action=profile&amp;uid={$report[''uid'']}\" target=\"_blank\">{$report[''username'']}</a></td>\r\n<td class=\"{$trow}\">{$report[''reason'']}</td>\r\n<td class=\"{$trow}\" align=\"center\" style=\"white-space: nowrap\"><span class=\"smalltext\">{$reportdate}<br />{$reporttime}</small></td>\r\n</tr>',-2,'120','',1179356757),
  (188,'moderation_reports_multipage','<tr>\r\n<td class=\"tcat\" colspan=\"6\"><span class=\"smalltext\"> {$multipage}</span></td>\r\n</tr>',-2,'120','',1179356757),
  (189,'moderation_allreports','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->all_reported_posts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<p>{$lang->unread_reports_key}</p>\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"6\"><strong>{$lang->all_reported_posts}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><span class=\"smalltext\"><strong>{$lang->post_id}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"15%\"><span class=\"smalltext\"><strong>{$lang->poster}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"25%\"><span class=\"smalltext\"><strong>{$lang->thread}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"15%\"><span class=\"smalltext\"><strong>{$lang->reporter}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"25%\"><span class=\"smalltext\"><strong>{$lang->report_reason}</strong></span></td>\r\n<td class=\"tcat\" align=\"center\" width=\"10%\"><span class=\"smalltext\"><strong>{$lang->report_time}</strong></span></td>\r\n</tr>\r\n{$allreports}\r\n{$allreportspages}\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (190,'moderation_reports_allreport','<tr>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"showthread.php?pid={$report[''pid'']}&amp;tid={$report[''tid'']}#pid{$report[''pid'']}\" target=\"_blank\">{$report[''pid'']}</a></td>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"member.php?action=profile&amp;uid={$report[''postuid'']}\" target=\"_blank\">{$report[''postusername'']}</a></td>\r\n<td class=\"{$trow}\"><a href=\"showthread.php?tid={$report[''tid'']}\" target=\"_blank\">{$report[''threadsubject'']}</a></td>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"member.php?action=profile&amp;uid={$report[''uid'']}\" target=\"_blank\">{$report[''username'']}</a></td>\r\n<td class=\"{$trow}\">{$report[''reason'']}</td>\r\n<td class=\"{$trow}\" align=\"center\" style=\"white-space: nowrap\"><span class=\"smalltext\">{$reportdate}<br />{$reporttime}</span></td>\r\n</tr>',-2,'120','',1179356757),
  (191,'moderation_allreports_multipage','<tr>\r\n<td class=\"tcat\" colspan=\"6\"><span class=\"smalltext\"> {$multipage}</span></td>\r\n</tr>',-2,'120','',1179356757),
  (192,'moderation_reports_allnoreports','<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"6\">{$lang->no_reports}</td>\r\n</tr>',-2,'120','',1179356757),
  (193,'moderation_reports_noreports','<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"6\">{$lang->no_reports}</td>\r\n</tr>',-2,'120','',1179356757),
  (194,'newthread_postpoll','<tr>\r\n<td class=\"{$bgcolor}\" valign=\"top\">\r\n<strong>{$lang->poll}</strong><br /><span class=\"smalltext\">{$lang->poll_desc}</span>\r\n</td>\r\n<td class=\"{$bgcolor}\" valign=\"top\">\r\n<span class=\"smalltext\"><input type=\"checkbox\" class=\"checkbox\" name=\"postpoll\" value=\"yes\" {$postpollchecked} /><strong>{$lang->poll_check}</strong><br />\r\n{$lang->num_options} <input type=\"text\" class=\"textbox\" name=\"numpolloptions\" value=\"{$numpolloptions}\" size=\"10\" />{$lang->max_options}</span>\r\n</td>\r\n</tr>',-2,'120','',1179356757),
  (195,'global_unreadreports','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"right\"><span class=\"smalltext\"><a href=\"moderation.php?action=reports\">{$lang->unread_reports}</a></span></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356757),
  (196,'member_login','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->login}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<form action=\"member.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->login}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"username\" size=\"25\" maxlength=\"{$mybb->settings[''maxnamelength'']}\" style=\"width: 200px;\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->password}</strong><br /><span class=\"smalltext\">{$lang->pw_note}</span></td>\r\n<td class=\"trow2\"><input type=\"password\" class=\"textbox\" name=\"password\" size=\"25\" style=\"width: 200px;\" /> (<a href=\"member.php?action=lostpw\">{$lang->lostpw_note}</a>)</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->login}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_login\" />\r\n<input type=\"hidden\" name=\"url\" value=\"{$redirect_url}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (197,'misc_imcenter_aim','<html>\r\n<head>\r\n<title>{$lang->aim_center}</title>\r\n{$headerinclude}\r\n</head>\r\n<body style=\"margin:0;left:0;top:0\" class=\"trow2\">\r\n<table width=\"100%\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"2\"><strong>{$user[''username'']} - {$lang->aim_center}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><strong>{$navigationbar}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\">\r\n<!-- Begin AIM Remote -->\r\n<table align=\"center\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\r\n<tr>\r\n<td align=\"center\" style=\"white-space: nowrap\"><a href=\"http://www.aol.co.uk/aim/index.html\"><img src=\"http://www.aol.co.uk/aim/remote/gr/aimver_man.gif\" width=\"44\" height=\"55\" alt=\"Download AIM\" /></a><img src=\"http://www.aol.co.uk/aim/remote/gr/aimver_topsm.gif\" width=\"73\" height=\"55\" alt=\"AIM Remote\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" style=\"white-space: nowrap\"><a href=\"aim:goim?screenname={$user[''aim'']}&amp;message=Hi.+Are+you+there?\"><img src=\"http://www.aol.co.uk/aim/remote/gr/aimver_im.gif\" width=\"117\" height=\"39\" alt=\"Send me an Instant Message\" /></a></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" style=\"white-space: nowrap\"><a href=\"aim:addbuddy?screenname={$user[''aim'']}\"><img src=\"http://www.aol.co.uk/aim/remote/gr/aimver_bud.gif\" width=\"117\" height=\"39\" alt=\"Add me to Your Buddy List\" /></a></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" style=\"white-space: nowrap\"><a href=\"http://www.aol.co.uk/aim/remote.html\"><img src=\"http://www.aol.co.uk/aim/remote/gr/aimver_botadd.gif\" width=\"117\" height=\"23\" alt=\"Add Remote to Your Page\" /></a></td>\r\n</tr>\r\n<td align=\"center\" style=\"white-space: nowrap\"><a href=\"http://www.aol.co.uk/aim/index.html\"><img src=\"http://www.aol.co.uk/aim/remote/gr/aimver_botdow.gif\" width=\"117\" height=\"29\" alt=\"Download AOL Instant Messenger\" /></a></td>\r\n</tr>\r\n</table>\r\n<!-- End AIM Remote -->\r\n</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (198,'misc_syndication','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->syndication}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$feedurl}\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\" width=\"100%\">\r\n<tr><td>{$lang->syndication_note}</td></tr>\r\n</table>\r\n<br />\r\n<form method=\"post\" action=\"misc.php?action=syndication\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->syndication}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\" valign=\"top\"><strong>{$lang->syndication_forum}</strong><br /><span class=\"smalltext\">{$lang->syndication_forum_desc}</span></td>\r\n<td class=\"trow1\" width=\"60%\">{$forumselect}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\" valign=\"top\"><strong>{$lang->syndication_version}</strong><br /><span class=\"smalltext\">{$lang->syndication_version_desc}</span></td>\r\n<td class=\"trow2\" width=\"60%\"><input type=\"radio\" class=\"radio\" name=\"version\" value=\"rss2.0\" {$rss2check} />&nbsp;{$lang->syndication_version_rss2}<br /><input type=\"radio\" class=\"radio\" name=\"version\" value=\"atom1.0\" {$atom1check} />&nbsp;{$lang->syndication_version_atom1}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\" valign=\"top\"><strong>{$lang->syndication_limit}</strong><br /><span class=\"smalltext\">{$lang->syndication_limit_desc}</span></td>\r\n<td class=\"trow2\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"limit\" value=\"{$limit}\" size=\"3\" /> {$lang->syndication_threads_time}</td>\r\n</tr></table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"make\" value=\"{$lang->syndication_generate}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (199,'misc_syndication_feedurl','<table border=\"0\" cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\" width=\"100%\">\r\n<tr><td>\r\n<strong>{$lang->syndication_generated_url}</strong><blockquote>\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\"><tr><td class=\"trow1\">\r\n{$url}\r\n</td></tr></table>\r\n</blockquote>\r\n</td></tr>\r\n</table>\r\n<br />',-2,'120','',1179356757),
  (200,'forumdisplay_announcement','<tr>\r\n<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/{$folder}\" /></td>\r\n<td align=\"center\" class=\"trow1\">&nbsp;</td>\r\n<td width=\"100%\" class=\"trow1\"><strong>{$lang->announcement_prefix}</strong> <a href=\"announcements.php?fid={$fid}\">{$announcement[''subject'']}</a></td>\r\n<td align=\"center\" class=\"trow1\"><a href=\"member.php?action=profile&amp;uid={$announcement[''uid'']}\">{$announcement[''username'']}</a></td>\r\n<td align=\"center\" class=\"trow1\">-</td>\r\n<td align=\"center\" class=\"trow1\">-</td>\r\n{$rating}\r\n<td class=\"trow1\" style=\"white-space: nowrap\">{$postdate} {$posttime}</td>\r\n{$modann}\r\n</tr>\r\n',-2,'120','',1179356757);

COMMIT;

#
# Data for the `mybb_templates` table  (LIMIT 200,100)
#

INSERT INTO `mybb_templates` (`tid`, `title`, `template`, `sid`, `version`, `status`, `dateline`) VALUES
  (201,'memberlist_row','<tr>\r\n<td class=\"trow1\"><a href=\"member.php?action=profile&amp;uid={$users[''uid'']}\">{$users[''username'']}</a></td>\r\n<td class=\"trow2\" align=\"center\">{$useremail}</td>\r\n<td class=\"trow1\" align=\"center\">{$usersite}</td>\r\n<td class=\"trow2\">{$users[''location'']}</td>\r\n<td class=\"trow1\">{$users[''regdate'']}</td>\r\n<td class=\"trow2\">{$users[''postnum'']}</td>\r\n</tr>',-2,'120','',1179356757),
  (202,'index_loginform','<br /><br />\r\n<form action=\"member.php\" method=\"post\">\r\n\t<input type=\"hidden\" name=\"action\" value=\"do_login\" />\r\n\t<span class=\"smalltext\"><strong>{$lang->quick_login}</strong></span>\r\n\t<input type=\"text\" class=\"textbox\" name=\"username\" title=\"{$lang->login_username}\" value=\"{$lang->login_username}\" onfocus=\"if(this.value == ''{$lang->login_username}'') { this.value=''''; }\" onblur=\"if(this.value=='''') { this.value=''{$lang->login_username}''; }\" />\r\n\t<input type=\"password\" class=\"textbox\" name=\"password\" title=\"{$lang->login_password}\" value=\"{$lang->login_password}\" onfocus=\"if(this.value == ''{$lang->login_password}'') { this.value=''''; }\" onblur=\"if(this.value=='''') { this.value=''{$lang->login_password}''; }\" />\r\n\t{$gobutton}\r\n</form>',-2,'123','',1179356757),
  (203,'multipage','<div><span class=\"smalltext\"><span class=\"pagenav\">{$lang->multipage_pages}</span>{$start} {$prevpage} {$mppage} {$nextpage} {$end}</span></div>',-2,'120','',1179356757),
  (204,'multipage_end','<span class=\"pagenavbit\"><a href=\"{$url}&amp;page={$pages}\">{$lang->multipage_last} &raquo;</a></span>',-2,'120','',1179356757),
  (205,'multipage_nextpage','<span class=\"pagenavbit\"><a href=\"{$url}&amp;page={$next}\">{$lang->multipage_next} &gt;</a></span>',-2,'120','',1179356757),
  (206,'multipage_page',' <span class=\"pagenavbit\"><a href=\"{$url}&amp;page={$i}\">{$i}</a></span>',-2,'120','',1179356757),
  (207,'multipage_page_current',' <span class=\"pagenavcurrent\">[{$i}]</span>',-2,'120','',1179356757),
  (208,'multipage_prevpage','<span class=\"pagenavbit\"><a href=\"{$url}&amp;page={$prev}\">&lt; {$lang->multipage_previous}</a></span>',-2,'120','',1179356757),
  (209,'multipage_start','<span class=\"pagenavbit\"><a href=\"{$url}&amp;page=1\">&laquo; {$lang->multipage_first}</a></span>',-2,'120','',1179356757),
  (210,'usercp_forumsubscriptions_none','<tr>\r\n<td class=\"trow1\" colspan=\"5\">{$lang->no_forum_subscriptions}</td>\r\n</tr>',-2,'120','',1179356757),
  (211,'calendar_dayview_noevents','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">{$lang->no_events}</td>\r\n</tr>\r\n</table>',-2,'120','',1179356757),
  (212,'index_whosonline','<tr>\r\n<td class=\"tcat\"><strong>{$lang->whos_online}</strong> [<a href=\"online.php\">{$lang->complete_list}</a>]</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">{$lang->online_note}<br />{$onlinemembers}</span></td>\r\n</tr>',-2,'120','',1179356757),
  (213,'index_stats','<tr><td class=\"tcat\"><strong>{$lang->boardstats}</strong></td></tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n{$lang->stats_posts_threads}<br />\r\n{$lang->stats_numusers}<br />\r\n{$lang->stats_newestuser}<br />\r\n{$lang->stats_mostonline}\r\n</span>\r\n</td>\r\n</tr>',-2,'120','',1179356757),
  (214,'moderation_deletethread','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->delete_thread}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$thread[''subject'']} - {$lang->delete_thread}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\" align=\"center\">{$lang->confirm_delete_threads}</td>\r\n</tr>\r\n{$loginbox}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_thread}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_deletethread\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356757),
  (215,'postbit_attachments_thumbnails','<span class=\"smalltext\"><strong>{$lang->postbit_attachments_thumbnails}</strong></span><br />\r\n{$post[''thumblist'']}\r\n<br />',-2,'120','',1179356757),
  (216,'forumdisplay_subforums','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"5\" align=\"center\"><strong>{$lang->sub_forums_in}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"2%\">&nbsp;</td>\r\n<td class=\"tcat\" width=\"59%\"><span class=\"smalltext\"><strong>{$lang->forumbit_forum}</strong></span></td>\r\n<td class=\"tcat\" width=\"7%\" align=\"center\" style=\"white-space: nowrap\"><span class=\"smalltext\"><strong>{$lang->forumbit_threads}</strong></span></td>\r\n<td class=\"tcat\" width=\"7%\" align=\"center\" style=\"white-space: nowrap\"><span class=\"smalltext\"><strong>{$lang->forumbit_posts}</strong></span></td>\r\n<td class=\"tcat\" width=\"15%\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->forumbit_lastpost}</strong></span></td>\r\n</tr>\r\n{$forums}\r\n</table>\r\n<br />',-2,'120','',1179356757),
  (217,'forumdisplay_threadlist_rating','<td class=\"tcat\" align=\"center\" width=\"60\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=rating&amp;order=desc\">{$lang->rating}</a> {$orderarrow[''rating'']}</strong></span></td>\r\n',-2,'120','',1179356757),
  (218,'forumdisplay_thread','<tr>\r\n\t<td align=\"center\" class=\"{$bgcolor}\" width=\"2%\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" alt=\"{$folder_label}\" title=\"{$folder_label}\" /></td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\" width=\"2%\">{$icon}</td>\r\n\t<td class=\"{$bgcolor}\">\r\n\t\t{$attachment_count}\r\n\t\t<div><span>{$prefix} {$gotounread}<a href=\"showthread.php?tid={$thread[''tid'']}\" class=\"{$inline_edit_class}\" id=\"tid_{$inline_edit_tid}\">{$thread[''subject'']}</a>{$thread[''multipage'']}</span></div>\r\n\t</td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\">{$thread[''profilelink'']}</td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\"><a href=\"javascript:MyBB.whoPosted({$thread[''tid'']});\">{$thread[''replies'']}</a>{$unapproved_posts}</td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\">{$thread[''views'']}</td>\r\n\t{$rating}\r\n\t<td class=\"{$bgcolor}\" style=\"white-space: nowrap\">\r\n\t\t<span class=\"smalltext\">{$lastpostdate} {$lastposttime}<br />\r\n\t\t<a href=\"showthread.php?action=lastpost&amp;tid={$thread[''tid'']}\">{$lang->lastpost}</a>: {$lastposterlink}</span>\r\n\t</td>\r\n{$modbit}\r\n</tr>\r\n',-2,'120','',1179356757),
  (219,'forumdisplay_orderarrow','<span class=\"smalltext\">[<a href=\"{$sorturl}&amp;sortby={$sortby}&amp;order={$oppsortnext}\">{$oppsort}</a>]</span>',-2,'120','',1179356757),
  (220,'showthread_ratingdisplay','<img src=\"{$theme[''imgdir'']}/{$thread[''rating'']}\" alt=\"{$ratingav}\" />&nbsp;&nbsp;',-2,'120','',1179356757),
  (221,'postbit_posturl','<div style=\"float: right; width: auto; vertical-align: top\"><span class=\"smalltext\"><strong>{$lang->postbit_post} <a href=\"showthread.php?tid={$tid}&amp;pid={$post[''pid'']}#pid{$post[''pid'']}\">#{$postcounter}</a></strong>{$post[''inlinecheck'']}</span></div>',-2,'120','',1179356757),
  (222,'postbit_attachments_thumbnails_thumbnail','<a href=\"attachment.php?aid={$attachment[''aid'']}\" target=\"_blank\"><img src=\"attachment.php?thumbnail={$attachment[''aid'']}\" class=\"attachment\" alt=\"\" /></a>&nbsp;&nbsp;&nbsp;',-2,'120','',1179356757),
  (223,'postbit_attachments_images_image','<img src=\"attachment.php?aid={$attachment[''aid'']}\" class=\"attachment\" alt=\"\" />&nbsp;&nbsp;&nbsp;',-2,'120','',1179356757),
  (224,'postbit_signature','<hr size=\"1\" width=\"25%\"  align=\"left\" />\r\n{$post[''signature'']}',-2,'120','',1179356757),
  (225,'post_attachments_attachment','<tr>\r\n<td width=\"5%\" align=\"center\">{$attachment[''icon'']}</td>\r\n<td style=\"white-space: nowrap\">{$attachment[''filename'']} ({$attachment[''size'']})</td>\r\n<td style=\"white-space: nowrap; text-align: right;\">{$attach_mod_options} <input type=\"submit\" class=\"button\" name=\"rem\" value=\"{$lang->remove_attachment}\" onclick=\"return Post.removeAttachment({$attachment[''aid'']});\" /> {$postinsert}</td>\r\n</tr>',-2,'120','',1179356758),
  (226,'post_attachments_attachment_unapproved','<tr>\r\n<td width=\"5%\" align=\"center\">{$attachment[''icon'']}</td>\r\n<td style=\"white-space: nowrap\"><em>{$attachment[''filename'']} ({$attachment[''size'']})</em></td>\r\n<td style=\"white-space: nowrap; text-align: right;\">{$attach_mod_options} <input type=\"submit\" class=\"button\" name=\"rem\" value=\"{$lang->remove_attachment}\" onclick=\"return Post.removeAttachment({$attachment[''aid'']});\" /> {$postinsert}</td>\r\n</tr>',-2,'120','',1179356758),
  (227,'post_attachments_attachment_mod_approve','<input type=\"submit\" class=\"button\" name=\"approveattach\" value=\"{$lang->approve_attachment}\" onclick=\"return Post.attachmentAction({$attachment[''aid'']},''approve'');\" />',-2,'120','',1179356758),
  (228,'post_attachments_attachment_mod_unapprove','<input type=\"submit\" class=\"button\" name=\"unapproveattach\" value=\"{$lang->unapprove_attachment}\" onclick=\"return Post.attachmentAction({$attachment[''aid'']},''unapprove'');\" />',-2,'120','',1179356758),
  (229,'error_attacherror','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\"><tr>\r\n<td class=\"thead\"><strong>{$lang->error_attach_file}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$attachedfile[''error'']}</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (230,'postbit_attachments','<br />\r\n<br />\r\n<fieldset>\r\n<legend><strong>{$lang->postbit_attachments}</strong></legend>\r\n{$post[''attachedthumbs'']}\r\n{$post[''attachedimages'']}\r\n{$post[''attachmentlist'']}\r\n</fieldset>',-2,'120','',1179356758),
  (231,'postbit_attachments_attachment','<br />{$attachment[''icon'']}&nbsp;&nbsp;<a href=\"attachment.php?aid={$attachment[''aid'']}\" target=\"_blank\">{$attachment[''filename'']}</a> ({$lang->postbit_attachment_size} {$attachment[''filesize'']} / {$lang->postbit_attachment_downloads} {$attachment[''downloads'']})',-2,'120','',1179356758),
  (232,'postbit_attachments_attachment_unapproved','<br /><strong>{$lang->postbit_unapproved_attachments}</strong>',-2,'120','',1179356758),
  (233,'postbit_attachments_images','<span class=\"smalltext\"><strong>{$lang->postbit_attachments_images}</strong></span><br />\r\n{$post[''imagelist'']}\r\n<br />',-2,'120','',1179356758),
  (234,'post_attachments_attachment_postinsert','<input type=\"button\" name=\"insert\" value=\"{$lang->insert_attachment_post}\" onclick=\"clickableEditor.insertAttachment({$attachment[''aid'']});\" />',-2,'120','',1179356758),
  (235,'moderation_mergeposts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->merge_posts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\"><tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->merge_posts}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\">{$lang->merge_posts_note}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->post_separator}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" colspan=\"2\"><label><input type=\"radio\" class=\"radio\" name=\"sep\" value=\"hr\" checked=\"checked\" /> {$lang->horizontal_rule}</label><br /><label><input type=\"radio\" class=\"radio\" name=\"sep\" value=\"new_line\" /> {$lang->new_line}</label></td>\r\n</tr>\r\n{$posts}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->merge_posts}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_mergeposts\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (236,'moderation_mergeposts_post','<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->posted_by} {$post[''username'']} - {$postdate} {$posttime}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"{$altbg}\" valign=\"top\" align=\"center\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"mergepost[{$post[''pid'']}]\" value=\"yes\" /></td>\r\n<td class=\"{$altbg}\">{$message}</td>\r\n</tr>',-2,'120','',1179356758),
  (237,'stats','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->board_stats}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->board_stats}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"50%\"><strong>{$lang->totals}</strong></td>\r\n<td class=\"tcat\" width=\"50%\"><strong>{$lang->averages}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\">\r\n{$lang->posts} <strong>{$stats[''numposts'']}</strong><br />\r\n{$lang->threads} <strong>{$stats[''numthreads'']}</strong><br />\r\n{$lang->members} <strong>{$stats[''numusers'']}</strong>\r\n</td>\r\n<td class=\"trow1\" rowspan=\"3\" valign=\"top\">\r\n{$lang->ppd} <strong>{$postsperday}</strong><br />\r\n{$lang->tpd} <strong>{$threadsperday}</strong><br />\r\n{$lang->mpd} <strong>{$membersperday}</strong><br />\r\n{$lang->ppm} <strong>{$postspermember}</strong><br />\r\n{$lang->rpt} <strong>{$repliesperthread}</strong>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" valign=\"top\"><strong>{$lang->general}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n{$lang->newest_member} <a href=\"member.php?action=profile&amp;uid={$stats[''lastuid'']}\"><strong>{$stats[''lastusername'']}</strong></a><br />\r\n{$lang->members_posted} <strong>{$havepostedpercent}</strong><br />\r\n{$lang->todays_top_poster}<br />\r\n{$lang->popular_forum}\r\n</td>\r\n</tr>\r\n</table>\r\n\r\n\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->most_popular}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" width=\"50%\"><strong>{$lang->most_replied_threads}</strong></td>\r\n<td class=\"tcat\" width=\"50%\"><strong>{$lang->most_viewed_threads}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\">{$mostreplies}</td>\r\n<td class=\"trow1\" valign=\"top\">{$mostviews}</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (238,'polls_newpoll','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->post_new_poll}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$preview}\r\n<form action=\"polls.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->post_new_poll}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->question}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"question\" size=\"40\" maxlength=\"240\" value=\"{$question}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->num_options}</strong><br /><span class=\"smalltext\">{$lang->max_options} {$mybb->settings[''maxpolloptions'']}</span></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"polloptions\" size=\"10\" value=\"{$polloptions}\" />&nbsp;<input type=\"submit\" class=\"button\" name=\"updateoptions\" value=\"{$lang->update_options}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->poll_options}</strong></td>\r\n<td class=\"trow2\"><span class=\"smalltext\">{$lang->poll_options_note}</span>\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n{$optionbits}\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->options}</strong></td>\r\n<td class=\"trow1\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[multiple]\" value=\"yes\" {$postoptionschecked[''multiple'']} />&nbsp;{$lang->option_multiple}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[public]\" value=\"yes\" {$postoptionschecked[''public'']} />&nbsp;{$lang->option_public}</label>\r\n</span>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->poll_timeout}</strong><br /><span class=\"smalltext\">{$lang->timeout_note}</span></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"timeout\" value=\"{$timeout}\" /> {$lang->days}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->post_new_poll}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_newpoll\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (239,'member_register_agreement','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->agreement}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<form action=\"member.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$mybb->settings[''bbname'']} - {$lang->agreement}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<p>{$lang->agreement_1}</p>\r\n<p>{$lang->agreement_2}</p>\r\n<p>{$lang->agreement_3}</p>\r\n<p>{$lang->agreement_4}</p>\r\n<p><strong>{$lang->agreement_5}</strong></p>\r\n</td>\r\n</tr>\r\n</table>\r\n\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"register\" />\r\n<input type=\"submit\" class=\"button\" name=\"agree\" value=\"{$lang->i_agree}\" />\r\n</div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'123','',1179356758),
  (240,'stats_thread','<a href=\"showthread.php?tid={$thread[''tid'']}\"><strong>{$thread[''subject'']}</strong></a> ({$numberbit} {$numbertype})<br />',-2,'120','',1179356758),
  (241,'online','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->users_online}</title>\r\n{$headerinclude}\r\n{$refresh}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->users_online}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\"><a href=\"online.php?sortby=username\"><span class=\"smalltext\"><strong>{$lang->on_username}</strong></span></a></td>\r\n<td class=\"tcat\" align=\"center\"><a href=\"online.php?sortby=time\"><span class=\"smalltext\"><strong>{$lang->time}</strong></span></a></td>\r\n<td class=\"tcat\" align=\"center\" width=\"50%\"><a href=\"online.php?sortby=location\"><span class=\"smalltext\"><strong>{$lang->location}</strong></span></a></td>\r\n</tr>\r\n{$onlinerows}\r\n<tr>\r\n<td class=\"tfoot\" colspan=\"3\" align=\"right\"><span class=\"smalltext\"><strong><a href=\"online.php?action=today\">{$lang->online_today}</a> | <a href=\"online.php\">{$lang->refresh_page}</a></strong></span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td align=\"center\" class=\"trow1\"><span class=\"smalltext\">{$lang->online_count}</span></td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (242,'portal_welcome_membertext','<span class=\"smalltext\"><em>{$lang->member_welcome_lastvisit}</em> {$lastvisit}<br />\r\n{$lang->since_then}<br />\r\n<strong>&raquo;</strong> {$lang->new_announcements}<br />\r\n<strong>&raquo;</strong> {$lang->new_threads}<br />\r\n<strong>&raquo;</strong> {$lang->new_posts}<br /><br />\r\n<a href=\"{$mybb->settings[''bburl'']}/search.php?action=getnew\">{$lang->view_new}</a><br /><a href=\"{$mybb->settings[''bburl'']}/search.php?action=getdaily\">{$lang->view_todays}</a>\r\n</span>',-2,'120','',1179356758),
  (243,'portal','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\">\r\n<tr><td valign=\"top\" width=\"200\">\r\n{$welcome}\r\n{$pms}\r\n{$search}\r\n{$stats}\r\n{$whosonline}\r\n{$latestthreads}\r\n</td>\r\n<td>&nbsp;</td>\r\n<td valign=\"top\">\r\n{$announcements}\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'127','',1179356758),
  (244,'portal_pms','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong><a href=\"{$mybb->settings[''bburl'']}/private.php\">{$lang->private_messages}</a></strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<span class=\"smalltext\">{$lang->pms_received_new}<br /><br />\r\n<strong>&raquo; </strong> <strong>{$messages[''pms_unread'']}</strong> {$lang->pms_unread}<br />\r\n<strong>&raquo; </strong> <strong>{$messages[''pms_total'']}</strong> {$lang->pms_total}</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (245,'portal_stats','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->forum_stats}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<span class=\"smalltext\">\r\n<strong>&raquo; </strong>{$lang->num_members} {$stats[''numusers'']}<br />\r\n<strong>&raquo; </strong>{$lang->latest_member} <a href=\"{$mybb->settings[''bburl'']}/member.php?action=profile&amp;uid={$stats[''lastuid'']}\">{$stats[''lastusername'']}</a><br />\r\n<strong>&raquo; </strong>{$lang->num_threads} {$stats[''numthreads'']}<br />\r\n<strong>&raquo; </strong>{$lang->num_posts} {$stats[''numposts'']}\r\n<br /><br /><a href=\"{$mybb->settings[''bburl'']}/stats.php\">{$lang->full_stats}</a>\r\n</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (246,'portal_welcome','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->welcome}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n{$welcometext}\r\n</td>\r\n</tr>\r\n</table><br />',-2,'120','',1179356758),
  (247,'portal_whosonline','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->online}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<span class=\"smalltext\">\r\n{$lang->online_users}<br /><strong>&raquo;</strong> {$lang->online_counts}<br />{$onlinemembers}\r\n</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (248,'portal_announcement_numcomments','- <a href=\"{$mybb->settings[''bburl'']}/showthread.php?tid={$announcement[''tid'']}\">{$lang->replies}</a> ({$announcement[''replies'']})',-2,'120','',1179356758),
  (249,'portal_announcement','<table cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$icon} <a href=\"{$mybb->settings[''bburl'']}/showthread.php?tid={$announcement[''tid'']}\">{$announcement[''subject'']}</a></strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" align=\"right\">\r\n<span class=\"smalltext\">{$lang->posted_by} <a href=\"{$mybb->settings[''bburl'']}/member.php?action=profile&amp;uid={$announcement[''uid'']}\">{$announcement[''username'']}</a>  - {$anndate} {$anntime} {$numcomments}</span>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<table border=\"0\" cellpadding=\"{$theme[''tablespace'']}\" width=\"100%\"><tr>{$avatar}<td class=\"trow1\"><p>{$message}</p>{$post[''attachments'']}</td></tr>\r\n<tr><td align=\"right\" colspan=\"2\" valign=\"bottom\"><span class=\"smalltext\"><a href=\"{$mybb->settings[''bburl'']}/printthread.php?tid={$announcement[''tid'']}\"><img src=\"{$mybb->settings[''bburl'']}/{$theme[''imgdir'']}/printable.gif\" alt=\"\" /></a>&nbsp;<a href=\"{$mybb->settings[''bburl'']}/sendthread.php?tid={$announcement[''tid'']}\"><img src=\"{$mybb->settings[''bburl'']}/{$theme[''imgdir'']}/send.gif\" alt=\"\" /></a></span></td></tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'123','',1179356758),
  (250,'portal_announcement_numcomments_no','- {$lang->no_replies}',-2,'120','',1179356758),
  (251,'portal_search','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->search_forums}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\">\r\n<form method=\"post\" action=\"{$mybb->settings[''bburl'']}/search.php\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_search\" />\r\n<input type=\"hidden\" name=\"postthread\" value=\"1\" />\r\n<input type=\"hidden\" name=\"forums\" value=\"all\" />\r\n<input type=\"hidden\" name=\"showresults\" value=\"threads\" />\r\n<input type=\"text\" class=\"textbox\" name=\"keywords\" value=\"\" />\r\n{$gobutton}\r\n</form><br />\r\n<span class=\"smalltext\">\r\n(<a href=\"{$mybb->settings[''bburl'']}/search.php\">{$lang->advanced_search}</a>)\r\n</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (252,'portal_latestthreads','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->latest_threads}</strong></td>\r\n</tr>\r\n{$threadlist}\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (253,'portal_whosonline_memberbit','{$comma}<a href=\"{$mybb->settings[''bburl'']}/member.php?action=profile&amp;uid={$user[''uid'']}\">{$user[''username'']}</a>{$invisiblemark}',-2,'120','',1179356758),
  (254,'usercp_favorites','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->favorites}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">\r\n<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\">\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\"><a href=\"usercp2.php?action=removefavorites\">{$lang->remove_all_favs}</a> | <a href=\"usercp.php?action=subscriptions\">{$lang->view_thread_subscriptions}</a></span></td>\r\n<td class=\"trow1\" align=\"right\">&nbsp;{$multipage}</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"3\"><span class=\"smalltext\"><strong>{$lang->thread}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->author}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->replies}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->views}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->lastpost}</strong></span></td>\r\n</tr>\r\n{$threads}\r\n</table>\r\n</td></tr></table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (255,'printthread','<html>\r\n<head>\r\n<title>{$thread[''subject'']} - {$lang->printable_version}</title>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset={$charset}\" />\r\n<style type=\"text/css\">\r\nbody { font-family: Verdana, Arial, sans-serif; font-size: 13px; }\r\n.largetext { font-family: Verdana, Arial, sans-serif; font-size: medium; font-weight: bold; }\r\n</style>\r\n</head>\r\n<body>\r\n<table width=\"98%\" align=\"center\">\r\n<tr>\r\n<td valign=\"top\"><a href=\"index.php\"><img src=\"{$theme[''logo'']}\" alt=\"{$mybb->settings[''bbname'']}\" /></a></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<span class=\"largetext\">{$thread[''subject'']} - {$lang->printable_version}</span><br />\r\n<br />\r\n+- {$mybb->settings[''bbname'']} (<em>{$mybb->settings[''bburl'']}</em>)<br />\r\n{$breadcrumb}\r\n+{$tdepth} {$lang->thread} {$thread[''subject'']} (<em>/showthread.php?tid={$tid}</em>)</td>\r\n</tr>\r\n<tr>\r\n<td><br /><hr size=\"1\" />{$postrows}</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (256,'forumdisplay_nothreads','<tr>\r\n<td colspan=\"{$colspan}\" class=\"trow1\">{$lang->nothreads}</td>\r\n</tr>',-2,'120','',1179356758),
  (257,'usercp_password','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->change_password}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$errors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->change_password}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->current_password}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\" align=\"center\"><input type=\"password\" class=\"textbox\" name=\"oldpassword\" size=\"25\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->please_enter_confirm_new_password}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->new_password}</strong></td>\r\n<td class=\"trow2\" width=\"60%\"><input type=\"password\" class=\"textbox\" name=\"password\" size=\"25\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->confirm_password}</strong></td>\r\n<td class=\"trow1\" width=\"60%\"><input type=\"password\" class=\"textbox\" name=\"password2\" size=\"25\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_password\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_password}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'122','',1179356758),
  (258,'usercp_email','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->change_email}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$errors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->change_email}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->enter_password}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\" align=\"center\"><input type=\"password\" class=\"textbox\" name=\"password\" size=\"25\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->please_enter_confirm_new_email}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->new_email}</strong></td>\r\n<td class=\"trow2\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"email\" size=\"25\" maxlength=\"150\" value=\"{$email}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->confirm_email}</strong></td>\r\n<td class=\"trow1\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"email2\" size=\"25\" maxlength=\"150\" value=\"{$email2}\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_email\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_email}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'122','',1179356758),
  (259,'private_archive_txt_folderhead','#######################################################################\r\n{$lang->folder} {$foldername}\r\n#######################################################################\r\n',-2,'120','',1179356758),
  (260,'private_archive_txt_message','{$lang->subject} {$message[''subject'']}\r\n{$tofrom} {$tofromusername}\r\n{$lang->sent} {$senddate}\r\n------------------------------------------------------------------------\r\n{$message[''message'']}\r\n------------------------------------------------------------------------\r\n\r\n',-2,'120','',1179356758),
  (261,'private_archive_html_folderhead','</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->folder} {$foldername}</strong></td>\r\n</tr>',-2,'120','',1179356758),
  (262,'private_archive_html_message','<tr>\r\n<td class=\"trow1\"><strong>{$lang->subject} {$message[''subject'']}</strong><br /><em>{$lang->to} {$message[''tousername'']}<br />{$lang->from} {$message[''fromusername'']}<br />{$lang->sent} {$senddate}</em></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\">{$message[''message'']}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" height=\"3\"><img src=\"pixel.gif\" height=\"3\" width=\"1\" alt=\"\" /></td>\r\n</tr>',-2,'120','',1179356758),
  (263,'private_archive_csv_message','{$senddate},{$foldername},{$message[''subject'']},{$message[''tousername'']},{$message[''fromusername'']},{$message[''message'']}',-2,'120','',1179356758),
  (264,'search_results_threads_thread','<tr>\r\n\t<td align=\"center\" class=\"{$bgcolor}\" width=\"2%\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" alt=\"\"/></td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\" width=\"2%\">{$icon}</td>\r\n\t<td class=\"{$bgcolor}\">{$gotounread}{$prefix} <a href=\"showthread.php?tid={$thread[''tid'']}\">{$thread[''subject'']}</a>{$thread[''multipage'']}</td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\">{$thread[''profilelink'']}</td>\r\n\t<td class=\"{$bgcolor}\">{$thread[''forumlink'']}</td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\"><a href=\"javascript:MyBB.whoPosted({$thread[''tid'']});\">{$thread[''replies'']}</a></td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\">{$thread[''views'']}</td>\r\n\t<td class=\"{$bgcolor}\" style=\"white-space: nowrap\"><span class=\"smalltext\">{$lastpostdate} {$lastposttime}<br />\r\n<a href=\"showthread.php?action=lastpost&amp;tid={$thread[''tid'']}\">{$lang->lastpost}</a>: {$lastposterlink}</span>\r\n\t</td>\r\n</tr>',-2,'120','',1179356758),
  (265,'search_results_threads','<html>\r\n\t\t<head>\r\n\t\t<title>{$mybb->settings[''bbname'']} - {$lang->search_results}</title>\r\n\t\t{$headerinclude}\r\n\t\t</head>\r\n\t\t<body>\r\n\t\t{$header}\r\n\t\t<table width=\"100%\" align=\"center\" border=\"0\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td align=\"right\" valign=\"top\">{$multipage}</td>\r\n\t\t\t</tr>\r\n\t\t</table>\r\n\t\t<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td colspan=\"8\" class=\"thead\">\r\n\t\t\t\t\t<strong>{$lang->search_results}</strong>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"tcat\" align=\"center\" colspan=\"3\" width=\"42%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=subject&amp;order=asc\">{$lang->thread}</a> {$orderarrow[''subject'']}</strong></span></td>\r\n\t\t\t\t<td class=\"tcat\" align=\"center\" width=\"14%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=starter&amp;order=asc\">{$lang->author}</a> {$orderarrow[''starter'']}</strong></span></td>\r\n\t\t\t\t<td class=\"tcat\" align=\"center\" width=\"14%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=forum&amp;order=asc\">{$lang->forum}</a> {$orderarrow[''forum'']}</strong></span></td>\r\n\t\t\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=replies&amp;order=desc\">{$lang->replies}</a> {$orderarrow[''replies'']}</strong></span></td>\r\n\t\t\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=views&amp;order=desc\">{$lang->views}</a></strong> {$orderarrow[''views'']}</span></td>\r\n\t\t\t\t<td class=\"tcat\" align=\"center\" width=\"200\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=lastpost&amp;order=desc\">{$lang->lastpost}</a> {$orderarrow[''lastpost'']}</strong></span></td>\r\n\t\t\t</tr>\r\n\t\t\t{$results}\r\n\t\t</table>\r\n\t\t<table width=\"100%\" align=\"center\" border=\"0\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td align=\"right\" valign=\"top\">{$multipage}</td>\r\n\t\t\t</tr>\r\n\t\t</table>\r\n\t\t{$footer}\r\n\t\t</body>\r\n\t\t</html>',-2,'120','',1179356758),
  (266,'search_results_posts_post','<tr>\r\n\t<td align=\"center\" class=\"{$bgcolor}\" width=\"2%\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" alt=\"\"/></td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\" width=\"2%\">{$icon}</td>\r\n\t<td class=\"{$bgcolor}\"><span class=\"smalltext\">{$lang->post_thread} <a href=\"showthread.php?tid={$post[''tid'']}\">{$post[''thread_subject'']}</a><br />{$lang->post_subject} <a href=\"showthread.php?tid={$post[''tid'']}&amp;pid={$post[''pid'']}#pid{$post[''pid'']}\">{$post[''subject'']}</a></span><br />\r\n\t<table width=\"100%\"><tr><td><span class=\"smalltext\"><em>{$prev}</em></span></td></tr></table></td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\">{$post[''profilelink'']}</td>\r\n\t<td class=\"{$bgcolor}\" >{$post[''forumlink'']}</td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\"><a href=\"javascript:MyBB.whoPosted({$post[''tid'']});\">{$post[''thread_replies'']}</a></td>\r\n\t<td align=\"center\" class=\"{$bgcolor}\">{$post[''thread_views'']}</td>\r\n\t<td class=\"{$bgcolor}\" style=\"white-space: nowrap; text-align: center;\"><span class=\"smalltext\">{$posted}</span></td>\r\n</tr>',-2,'120','',1179356758),
  (267,'reputation_add','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reputation}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t<tr>\r\n\t\t<td class=\"trow1\" style=\"padding: 20px\">\r\n\t\t\t<strong>{$vote_title}</strong><br /><br />\r\n\t\t\t<form action=\"reputation.php\" method=\"post\">\r\n\t\t\t\t<input type=\"hidden\" name=\"action\" value=\"do_add\" />\r\n\t\t\t\t<input type=\"hidden\" name=\"uid\" value=\"{$user[''uid'']}\" />\r\n\t\t\t\t{$positive_power}\r\n\t\t\t\t{$neutral_power}\r\n\t\t\t\t{$negative_power}\r\n\t\t\t\t<br /><br />\r\n\t\t\t\t<span class=\"smalltext\">{$lang->user_comments}</span>\r\n\t\t\t\t<br />\r\n\t\t\t\t<input type=\"text\" class=\"textbox\" name=\"comments\" size=\"35\" maxlength=\"250\" value=\"{$comments}\" style=\"width: 95%\" />\r\n\t\t\t\t<br /><br />\r\n\t\t\t\t<div style=\"text-align: center;\">\r\n\t\t\t\t\t<input type=\"submit\" class=\"button\" value=\"{$vote_button}\" />\r\n\t\t\t\t\t{$delete_button}\r\n\t\t\t\t</div>\r\n\t\t\t</form>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (268,'postbit_reputation','<br />{$lang->postbit_reputation} {$post[''userreputation'']}',-2,'120','',1179356758),
  (269,'moderation_threadnotes_modaction','<tr>\r\n<td class=\"{$trow}\" align=\"center\"><a href=\"member.php?action=profile&amp;uid={$modaction[''uid'']}\">{$modaction[''username'']}</a></td>\r\n<td class=\"{$trow}\" align=\"center\">{$modaction[''dateline'']}</td>\r\n<td class=\"{$trow}\" align=\"center\">{$modaction[''action'']}</td>\r\n<td class=\"{$trow}\">{$info}</td>\r\n</tr>\r\n',-2,'120','',1179356758),
  (270,'misc_smilies','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->smilies_listing}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->smilies_listing}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->name}</strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->abbreviation}</strong></span></td>\r\n</tr>\r\n{$smilies}\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (271,'search_results_posts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->search_results}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" align=\"center\" border=\"0\">\r\n\t<tr>\r\n\t\t<td align=\"right\" valign=\"top\">{$multipage}</td>\r\n\t</tr>\r\n</table>\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t<tr>\r\n\t\t<td colspan=\"8\" class=\"thead\">\r\n\t\t\t<strong>{$lang->search_results}</strong>\r\n\t\t</td>\r\n\t</tr>\r\n\t<tr>\r\n\t\t<td class=\"tcat\" align=\"center\" colspan=\"3\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=subject&amp;order=asc\">{$lang->post}</a> {$orderarrow[''subject'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=starter&amp;order=asc\">{$lang->author}</a> {$orderarrow[''starter'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=forum&amp;order=asc\">{$lang->forum}</a> {$orderarrow[''forum'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=replies&amp;order=desc\">{$lang->replies}</a> {$orderarrow[''replies'']}</strong></span></td>\r\n\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=views&amp;order=desc\">{$lang->views}</a></strong> {$orderarrow[''views'']}</span></td>\r\n\t\t<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=dateline&amp;order=desc\">{$lang->posted}</a> {$orderarrow[''dateline'']}</strong></span></td>\r\n\t</tr>\r\n\t{$results}\r\n</table>\r\n<table width=\"100%\" align=\"center\" border=\"0\">\r\n\t<tr>\r\n\t\t<td align=\"right\" valign=\"top\">{$multipage}</td>\r\n\t</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (272,'private_limitwarning','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"center\"><span class=\"smalltext\"><strong><font color=\"red\">{$lang->reached_warning}</font></strong><br />{$lang->reached_warning2}</span></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356758),
  (273,'misc_smilies_smilie','<tr>\r\n<td class=\"{$class}\" align=\"center\"><img src=\"{$smilie[''image'']}\" /></td>\r\n<td class=\"{$class}\">{$smilie[''name'']}</td>\r\n<td class=\"{$class}\">{$smilie[''find'']}</td>\r\n</tr>',-2,'120','',1179356758),
  (274,'member_emailuser_guest','<tr>\r\n<td width=\"40%\" class=\"trow2\"><strong>{$lang->your_name}</strong><br /><span class=\"smalltext\">{$lang->name_note}</span></td>\r\n<td width=\"60%\" class=\"trow2\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"fromname\" /></td>\r\n</tr>\r\n<tr>\r\n<td width=\"40%\" class=\"trow1\"><strong>{$lang->your_email}</strong><br /><span class=\"smalltext\">{$lang->email_note}</span></td>\r\n<td width=\"60%\" class=\"trow1\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"fromemail\" /></td>\r\n</tr>',-2,'120','',1179356758),
  (275,'usercp_subscriptions','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->subscriptions}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\">\r\n<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\">\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\"><a href=\"usercp2.php?action=removesubscriptions\">{$lang->remove_all_subscriptions}</a> | <a href=\"usercp.php?action=favorites\">{$lang->view_favorite_threads}</a></span></td>\r\n<td class=\"trow1\" align=\"right\">&nbsp;{$multipage}</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\" colspan=\"3\"><span class=\"smalltext\"><strong>{$lang->thread}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->author}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->replies}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->views}</strong></span></td>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->lastpost}</strong></span></td>\r\n</tr>\r\n{$threads}\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356758),
  (276,'online_today_row','<tr>\r\n<td align=\"center\" class=\"trow1\" width=\"50%\"><a href=\"member.php?action=profile&amp;uid={$online[''uid'']}\">{$username}</a>{$invisiblemark}</td>\r\n<td align=\"center\" class=\"trow2\" width=\"50%\">{$onlinetime}</td>\r\n</tr>',-2,'120','',1179356758),
  (277,'member_profile_email','<tr>\r\n<td class=\"trow2\"><strong>{$lang->email}</strong></td>\r\n<td class=\"trow2\"><a href=\"member.php?action=emailuser&amp;uid={$memprofile[''uid'']}\">{$lang->send_user_email}</a></td>\r\n</tr>',-2,'120','',1179356758),
  (278,'loginbox','<tr>\r\n<td class=\"trow2\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"username\" size=\"30\" value=\"{$username}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->password}</strong></td>\r\n<td class=\"trow1\"><input type=\"password\" class=\"textbox\" name=\"password\" size=\"30\" value=\"{$password}\" /></td>\r\n</tr>\r\n\r\n',-2,'120','',1179356758),
  (279,'misc_help_section_bit','<tr>\r\n<td width=\"100%\" class=\"{$altbg}\"><a href=\"misc.php?action=help&amp;hid={$helpdoc[''hid'']}\">{$helpdoc[''name'']}</a><br /><span class=\"smalltext\">{$helpdoc[''description'']}</span></td>\r\n</tr>\r\n',-2,'120','',1179356758),
  (280,'calendar_addpublicevent','<a href=\"calendar.php?action=addevent&amp;type=public\">{$lang->add_public_event}</a>',-2,'120','',1179356758),
  (281,'calendar_addprivateevent','<a href=\"calendar.php?action=addevent&amp;type=private\">{$lang->add_private_event}</a>',-2,'120','',1179356758),
  (282,'index_birthdays_birthday','{$comma}<a href=\"member.php?action=profile&amp;uid={$bdayuser[''uid'']}\">{$bdayuser[''username'']}</a>{$age}',-2,'120','',1179356758),
  (283,'private_tracking_readmessage','<tr>\r\n<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/old_pm.gif\" alt=\"\" /></td>\r\n<td class=\"trow2\">{$readmessage[''subject'']}</td>\r\n<td class=\"trow1\"><a href=\"member.php?action=profile&amp;uid={$readmessage[''toid'']}\">{$readmessage[''tousername'']}</a></td>\r\n<td class=\"trow2\" align=\"right\"><span class=\"smalltext\">{$readdate}<br />{$readtime}</span></td>\r\n<td class=\"trow1\"><input type=\"checkbox\" class=\"checkbox\" name=\"readcheck[{$readmessage[''pmid'']}]\" value=\"yes\" /></td>\r\n</tr>',-2,'120','',1179356758),
  (284,'private_tracking_unreadmessage','<tr>\r\n<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/new_pm.gif\" alt=\"\" /></td>\r\n<td class=\"trow2\">{$unreadmessage[''subject'']}</td>\r\n<td class=\"trow1\"><a href=\"member.php?action=profile&amp;uid={$unreadmessage[''toid'']}\">{$unreadmessage[''tousername'']}</a></td>\r\n<td class=\"trow2\" align=\"right\"><span class=\"smalltext\">{$senddate}<br />{$sendtime}</span></td>\r\n<td class=\"trow1\"><input type=\"checkbox\" class=\"checkbox\" name=\"unreadcheck[{$unreadmessage[''pmid'']}]\" value=\"yes\" /></td>\r\n</tr>',-2,'120','',1179356758),
  (285,'usercp_editlists_user','<input type=\"text\" class=\"textbox\" name=\"listuser[{$uid}]\" size=\"25\" value=\"{$username}\" /><br />',-2,'120','',1179356758),
  (286,'showthread_threadedbox','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><span class=\"smalltext\"><strong>{$lang->messages_in_thread}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$threadedbits}</td>\r\n</tr>\r\n</table>\r\n',-2,'120','',1179356758),
  (287,'showthread_multipage','<tr>\r\n<td class=\"tcat\" colspan=\"2\"> {$multipage}</td>\r\n</tr>',-2,'127','',1179356758),
  (288,'forumbit_moderators','<br />{$lang->forumbit_moderated_by} {$moderators}',-2,'120','',1179356759),
  (289,'moderation_deletepoll','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->delete_poll}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->delete_poll}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_poll}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_deletepoll\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"delete\" value=\"1\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (290,'member_profile_signature','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->users_signature}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$memprofile[''signature'']}</td>\r\n</tr>\r\n</table>',-2,'120','',1179356759),
  (291,'newreply_modoptions','<tr>\r\n<td class=\"{$bgcolor}\" valign=\"top\"><strong>{$lang->mod_options}</strong></td>\r\n<td class=\"{$bgcolor}\"><span class=\"smalltext\">\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"modoptions[closethread]\" value=\"yes\" {$closecheck} />{$lang->close_thread}</label><br />\r\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"modoptions[stickthread]\" value=\"yes\" {$stickycheck} />{$lang->stick_thread}</label>\r\n</span></td>\r\n</tr>',-2,'120','',1179356759),
  (292,'smilieinsert_getmore','<tr>\r\n<td class=\"trow2\" align=\"center\"><span class=\"smalltext\"><strong>[<a href=\"javascript:clickableEditor.openGetMoreSmilies(''clickableEditor'');\">{$lang->smilieinsert_getmore}</a>]</strong></span></td>\r\n</tr>',-2,'120','',1179356759),
  (293,'misc_smilies_popup','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->smilies_listing}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\">\r\n\tvar editor = eval(''opener.'' + ''{$editor}'');\r\n\tfunction insertSmilie(code)\r\n\t{\r\n\t\tif(editor)\r\n\t\t{\r\n\t\t\teditor.performInsert(code, \"\", true, false);\r\n\t\t}\r\n\t}\r\n</script>\r\n\r\n</head>\r\n<body>\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\"><strong>{$lang->smilies_listing}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"4\"><span class=\"smalltext\">{$lang->click_to_add}</span></td>\r\n</tr>\r\n{$smilies}\r\n<tr>\r\n<td class=\"thead\" colspan=\"4\" align=\"center\"><span class=\"smalltext\">[<a href=\"javascript:window.close();\">{$lang->close_window}</a>]</span></td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'122','',1179356759),
  (294,'misc_smilies_popup_smilie','<td class=\"{$class}\" align=\"center\"><img src=\"{$smilie[''image'']}\" alt=\"{$smilie[''find'']}\" onclick=\"insertSmilie(''{$smilie[''insert'']}'');\" /></a></td>\r\n<td class=\"{$class}\">{$smilie[''find'']}</td>',-2,'123','',1179356759),
  (295,'showteam','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->forum_team}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$grouplist}\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (296,'index_birthdays','<tr><td class=\"tcat\"><strong>{$lang->todays_birthdays}</strong></td></tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">{$bdays}</span></td>\r\n</tr>',-2,'120','',1179356759),
  (297,'moderation_getip','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->get_post_ip}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->get_post_ip}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->ip_address}</strong></td>\r\n<td class=\"trow2\">{$post[''ipaddress'']}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->hostname}<br /><span class=\"smalltext\">{$lang->if_resolvable}</span></strong></td>\r\n<td class=\"trow2\">{$hostname}</td>\r\n</tr>\r\n{$adminoptions}\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (298,'moderation_getip_adminoptions','<tr>\r\n<td class=\"trow2\"><strong>{$lang->admin_options}</strong></td>\r\n<td class=\"trow2\">\r\n\t<a href=\"{$config[''admin_dir'']}/index.php?goto=users%2Ephp%3Faction%3Dfind%26searchop%5Bsortby%5D%3Dusername%26searchop%5Border%5D%3Dasc%26search%5Bregip%5D%3D{$post[''ipaddress'']}\">{$lang->search_regip_users}</a><br />\r\n\t<a href=\"{$config[''admin_dir'']}/index.php?goto=users%2Ephp%3Faction%3Dfind%26searchop%5Bsortby%5D%3Dusername%26searchop%5Border%5D%3Dasc%26search%5Bpostip%5D%3D{$post[''ipaddress'']}\">{$lang->search_postip_users}</a>\r\n</td>\r\n</tr>',-2,'120','',1179356759),
  (299,'postbit_iplogged_hiden','<div class=\"smalltext\">{$lang->postbit_ipaddress} <a href=\"moderation.php?action=getip&amp;pid={$post[''pid'']}\">{$lang->postbit_ipaddress_logged}</a></div>',-2,'120','',1179356759),
  (300,'usercp_options_tppselect','<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->tpp}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">\r\n<select name=\"tpp\">\r\n<option value=\"\">{$lang->use_default}</option>\r\n{$tppoptions}\r\n</select>\r\n</td>\r\n</tr>',-2,'120','',1179356759);

COMMIT;

#
# Data for the `mybb_templates` table  (LIMIT 300,100)
#

INSERT INTO `mybb_templates` (`tid`, `title`, `template`, `sid`, `version`, `status`, `dateline`) VALUES
  (301,'index_logoutlink','<a href=\"member.php?action=logout&amp;uid={$mybb->user[''uid'']}\">{$lang->index_logout}</a> | ',-2,'120','',1179356759),
  (302,'postbit_iplogged_show','<div class=\"smalltext\">{$lang->postbit_ipaddress} {$post[''ipaddress'']}</div>',-2,'120','',1179356759),
  (303,'calendar_dayview','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->calendar} - {$lang->day_view}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$bdaylist}\r\n{$events}\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (304,'usercp_changeavatar','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->change_avatar}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form enctype=\"multipart/form-data\" action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><strong>{$lang->change_avatar}</strong></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" class=\"trow1\" width=\"5%\"><input type=\"radio\" class=\"radio\" name=\"avatar\" value=\"url\"{$checked[''url'']} /></td>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->avatar_url}</strong><br /><span class=\"smalltext\">{$lang->avatar_url_note}</span></td>\r\n<td class=\"trow1\" width=\"55%\"><input type=\"text\" class=\"textbox\" name=\"avatarurl\" size=\"25\" maxlength=\"100\" value=\"{$avatarurl}\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" class=\"trow2\" width=\"5%\"><input type=\"radio\" class=\"radio\" name=\"avatar\" value=\"upload\"{$checked[''upload'']} /></td>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->avatar_upload}</strong><br /><span class=\"smalltext\">{$lang->avatar_upload_note}</span></td>\r\n<td class=\"trow2\" width=\"55%\"><input type=\"file\" name=\"avatarupload\" size=\"25\" value=\"\" />{$uploadedmsg}</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" class=\"trow1\" width=\"5%\"><input type=\"radio\" class=\"radio\" name=\"avatar\" value=\"list\"{$checked[''list'']} /></td>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->avatar_list}</strong><br /><span class=\"smalltext\">{$lang->avatar_list_note}</span></td>\r\n<td class=\"trow1\" width=\"55%\">\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tr>\r\n<td valign=\"middle\">\r\n<select name=\"avatarlist\" size=\"5\" onChange=\"document.images.avatarpic.src=''{$mybb->settings[''avatardir'']}/''+this[this.selectedIndex].value;\">\r\n{$listoptions}\r\n</select>\r\n</td>\r\n<td valign=\"middle\">\r\n<img src=\"{$avatarpic}\" name=\"avatarpic\" width=\"80\" height=\"80\" />\r\n</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" class=\"trow2\" width=\"5%\"><input type=\"radio\" class=\"radio\" name=\"avatar\" value=\"none\"{$checked[''none'']} /></td>\r\n<td colspan=\"2\" class=\"trow2\" width=\"95%\"><strong>{$lang->no_avatar}</strong><br /><span class=\"smalltext\">{$lang->no_avatar_note}</span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_avatar\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->change_avatar}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (305,'usercp_notepad','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->personal_notepad}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->personal_notepad}</strong></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" class=\"trow1\" width=\"100%\">\r\n<textarea name=\"notepad\" cols=\"80\" rows=\"15\">{$mybb->user[''notepad'']}</textarea>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_notepad\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_notepad}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (306,'private_messagebit_sep','<tr>\r\n<td class=\"tcat\" align=\"center\" colspan=\"6\" height=\"1\"><img src=\"{$theme[''imgdir'']}/pixel.gif\" height=\"1\" width=\"1\" alt=\"\"/></td>\r\n</tr>\n    ',-2,'120','',1179356759),
  (307,'polls_editpoll_option','<tr>\r\n<td>{$lang->option} {$counter}:&nbsp;</td>\r\n<td><input type=\"text\" class=\"textbox\" name=\"options[{$counter}]\" value=\"{$option}\" /></td>\r\n<td>{$lang->votes}&nbsp;</td>\r\n<td><input type=\"text\" class=\"textbox\" name=\"votes[{$counter}]\" value=\"{$optionvotes}\" /></td>\r\n</tr>',-2,'120','',1179356759),
  (308,'member_resetpassword','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reset_password}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<form action=\"member.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->reset_password}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"30%\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"username\" value=\"{$user[''username'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"30%\"><strong>{$lang->activation_code}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"code\" value=\"{$code}\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"hidden\" name=\"action\" value=\"resetpassword\" /><input type=\"submit\" class=\"button\" name=\"regsubmit\" value=\"{$lang->send_password}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'127','',1179356759),
  (309,'forumdisplay_thread_multipage',' <span class=\"smalltext\">({$lang->pages} {$threadpages}{$morelink})</span>',-2,'120','',1179356759),
  (310,'forumdisplay_thread_multipage_page','<a href=\"showthread.php?tid={$thread[''tid'']}&amp;page={$i}\">{$i}</a> ',-2,'120','',1179356759),
  (311,'forumdisplay_thread_multipage_more','... <a href=\"showthread.php?tid={$thread[''tid'']}&amp;page=last\">{$lang->pages_last}</a>',-2,'120','',1179356759),
  (312,'member_profile_customfields','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$lang->users_additional_info}</strong></td>\r\n</tr>\r\n{$customfields}\r\n</table>',-2,'120','',1179356759),
  (313,'member_profile_customfields_field','<tr>\r\n<td class=\"{$bgcolor}\" width=\"40%\"><strong>{$customfield[''name'']}:</strong></td>\r\n<td class=\"{$bgcolor}\" width=\"60%\">{$customfieldval}</td>\r\n</tr>\r\n',-2,'120','',1179356759),
  (314,'forumdisplay_usersbrowsing_user','{$comma}<a href=\"member.php?action=profile&amp;uid={$user[''uid'']}\">{$user[''username'']}</a>{$invisiblemark}',-2,'120','',1179356759),
  (315,'forumdisplay_usersbrowsing','<span class=\"smalltext\">{$lang->users_browsing_forum} {$onlinemembers}{$onlinesep}{$invisonline}{$onlinesep2}{$guestsonline}</span>',-2,'120','',1179356759),
  (316,'member_lostpw','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->lost_pw}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"member.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->lost_pw_form}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->email_address}</strong></td>\r\n<td class=\"trow1\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"email\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->request_user_pass}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_lostpw\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (317,'usercp_changename','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->change_username}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$errors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->change_username}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->current_password}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\" align=\"center\"><input type=\"password\" class=\"textbox\" name=\"password\" size=\"25\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><strong>{$lang->change_username}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" width=\"40%\"><strong>{$lang->new_username}</strong></td>\r\n<td class=\"trow2\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"username\" size=\"25\" maxlength=\"{$mybb->settings[''maxnamelength'']}\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_changename\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_username}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'122','',1179356759),
  (318,'moderation_split_post','<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->posted_by} {$post[''username'']} - {$postdate} {$posttime}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"{$altbg}\" valign=\"top\" align=\"center\" width=\"5%\"><input type=\"checkbox\" class=\"checkbox\" name=\"splitpost[{$post[''pid'']}]\" value=\"yes\" /></td>\r\n<td class=\"{$altbg}\">{$message}</td>\r\n</tr>',-2,'127','',1179356759),
  (319,'newreply_threadreview_more','<tr>\r\n<td class=\"thead\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->thread_review_more}</strong></span></td>\r\n</tr>',-2,'120','',1179356759),
  (320,'usercp_forumsubscriptions_forum_lastpost','<span class=\"smalltext\"><a href=\"showthread.php?tid={$lastposttid}&amp;action=lastpost\"><strong>{$lastpostsubject}</strong></a>\r\n<br />\r\n{$lastpostdate} {$lastposttime} (<a href=\"member.php?action=profile&amp;uid={$forum[''lastposter'']}\">{$lastposter}</a>)</span>',-2,'120','',1179356759),
  (321,'misc_whoposted','<html>\r\n<head>\r\n<title>{$lang->who_posted}</title>\r\n{$headerinclude}\r\n</head>\r\n<body style=\"margin:0px;top:0px;left:0px\" class=\"trow2\">\r\n<table width=\"100%\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\"><strong>{$lang->total_posts} {$numposts}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong><a href=\"misc.php?action=whoposted&amp;tid={$tid}&amp;sort=username\">{$lang->user}</a></strong></span></td>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong><a href=\"misc.php?action=whoposted&amp;tid={$tid}&amp;sort=numposts\">{$lang->num_posts}</a></strong></span></td>\r\n</tr>\r\n{$whoposted}\r\n<tr>\r\n<td colspan=\"2\" class=\"thead\" align=\"center\"><span class=\"smalltext\">[<a href=\"javascript:self.close();\">{$lang->close_window}</a>]</span></td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (322,'misc_whoposted_poster','<tr>\r\n<td class=\"{$altbg}\">{$profile_link}</a></td>\r\n<td class=\"{$altbg}\">{$poster[''posts'']}</td>\r\n</tr>',-2,'120','',1179356759),
  (323,'moderation_deleteposts_post','<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->posted_by} {$post[''username'']} - {$postdate} {$posttime}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"{$altbg}\" valign=\"top\" align=\"center\" style=\"width:5%\"><input type=\"checkbox\" class=\"checkbox\" name=\"deletepost[{$post[''pid'']}]\" value=\"yes\" /></td>\r\n<td class=\"{$altbg}\">{$message}</td>\r\n</tr>',-2,'120','',1179356759),
  (324,'moderation_deleteposts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->delete_posts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->delete_posts}</strong></td>\r\n</tr>\r\n{$posts}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_selected_posts}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_deleteposts\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (325,'moderation_split','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->split_thread}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->split_thread}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->new_thread_info}</strong></span></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->new_subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"newsubject\" value=\"[split] {$thread[''subject'']}\" size=\"50\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->new_forum}</strong></td>\r\n<td class=\"trow1\">{$forumselect}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->posts_to_split}</strong></td>\r\n</tr>\r\n{$posts}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->split_thread}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_split\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (326,'newreply_threadreview_post','<tr>\r\n<td class=\"tcat\"><span class=\"smalltext\"><strong>{$lang->posted_by} {$post[''username'']} - {$reviewpostdate} {$reviewposttime}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"{$altbg}\">\r\n{$reviewmessage}\r\n</td>\r\n</tr>',-2,'120','',1179356759),
  (327,'newreply_threadreview','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\"><strong>{$lang->thread_review}</strong></td>\r\n</tr>\r\n{$reviewbits}\r\n{$reviewmore}\r\n</table>\r\n',-2,'120','',1179356759),
  (328,'sendthread','<html>\r\n<head>\r\n<title>{$thread[''subject'']} - {$lang->send_thread}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"sendthread.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" width=\"100%\" class=\"thead\"><strong>{$lang->send_thread}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"40%\" class=\"trow1\"><strong>{$lang->recipient}</strong><br /><span class=\"smalltext\">{$lang->recipient_note}</span></td>\r\n<td width=\"60%\" class=\"trow1\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"sendto\" /></td>\r\n</tr>\r\n{$guestfields}\r\n<tr>\r\n<td width=\"40%\" class=\"trow2\"><strong>{$lang->subject}</strong></td>\r\n<td width=\"60%\" class=\"trow2\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"subject\" value=\"{$thread[''subject'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"40%\" class=\"trow1\"><strong>{$lang->message}</strong></td>\r\n<td width=\"60%\" class=\"trow1\"><textarea cols=\"50\" rows=\"10\" name=\"message\">{$message}</textarea></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<input type=\"hidden\" name=\"action\" value=\"do_sendtofriend\" /><input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->send_thread}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (329,'sendthread_guest','<tr>\r\n<td width=\"40%\" class=\"trow2\"><strong>{$lang->your_name}</strong><br /><span class=\"smalltext\">{$lang->name_note}</span></td>\r\n<td width=\"60%\" class=\"trow2\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"fromname\" /></td>\r\n</tr>\r\n<tr>\r\n<td width=\"40%\" class=\"trow1\"><strong>{$lang->your_email}</strong><br /><span class=\"smalltext\">{$lang->email_note}</span></td>\r\n<td width=\"60%\" class=\"trow1\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"fromemail\" /></td>\r\n</tr>',-2,'120','',1179356759),
  (330,'usercp_editsig','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->edit_sig}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n{$error}\r\n{$signature}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->edit_sig}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\" width=\"40%\"><span class=\"smalltext\">{$lang->edit_sig_note}<br /><br />{$lang->edit_sig_note2}</span></td>\r\n<td class=\"trow1\" width=\"60%\"><textarea rows=\"5\" cols=\"55\" name=\"signature\">{$sig}</textarea>\r\n<br /><br /><span class=\"smalltext\">\r\n<label><input type=\"radio\" class=\"radio\" name=\"updateposts\" value=\"enable\" />&nbsp;{$lang->enable_sig_posts}</label><br />\r\n<label><input type=\"radio\" class=\"radio\" name=\"updateposts\" value=\"disable\" />&nbsp;{$lang->disable_sig_posts}</label><br />\r\n<label><input type=\"radio\" class=\"radio\" name=\"updateposts\" value=\"no\" checked=\"checked\" />&nbsp;{$lang->leave_sig_settings}</label></span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_editsig\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_sig}\" />\r\n<input type=\"submit\" class=\"button\" name=\"preview\" value=\"{$lang->preview}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (331,'private_messagebit_denyreceipt',' <span class=\"smalltext\"><a href=\"private.php?action=read&amp;pmid={$message[''pmid'']}&amp;denyreceipt=yes\">{$lang->deny_receipt}</a></span>',-2,'120','',1179356759),
  (332,'private_read','<html>\r\n<head>\r\n<title>{$lang->viewing_pm} {$pm[''subject'']}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"3\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td class=\"thead\"><strong>{$pm[''subject'']}</strong></td><td class=\"thead\" align=\"right\"><a href=\"private.php?action=send&amp;pmid={$pm[''pmid'']}&amp;do=reply\">{$lang->reply}</a> | <a href=\"private.php?action=send&amp;pmid={$pm[''pmid'']}&amp;do=forward\">{$lang->forward}</a> | <a href=\"private.php?action=delete&amp;pmid={$pm[''pmid'']}\">{$lang->delete_pm}</a></td></table></td>\r\n</tr>\r\n{$message}\r\n<tr>\r\n<td class=\"tfoot\" colspan=\"3\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td class=\"tfoot\"><strong>{$pm[''subject'']}</strong></td><td class=\"tfoot\" align=\"right\"><a href=\"private.php?action=send&amp;pmid={$pm[''pmid'']}&amp;do=reply\">{$lang->reply}</a> | <a href=\"private.php?action=send&amp;pmid={$pm[''pmid'']}&amp;do=forward\">{$lang->forward}</a> | <a href=\"private.php?action=delete&amp;pmid={$pm[''pmid'']}\">{$lang->delete_pm}</a></td></table></td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (333,'forumdisplay_inlinemoderation_col','<td class=\"tcat\" align=\"center\" width=\"1\"><input type=\"checkbox\" name=\"allbox\" onclick=\"inlineModeration.checkAll(this)\" /></td>',-2,'121','',1179356759),
  (334,'printthread_post','<strong>{$postrow[''subject'']}</strong> - <a href=\"member.php?action=profile&amp;uid={$postrow[''uid'']}\"><strong>{$postrow[''username'']}</strong></a> -  <strong>{$postrow[''date'']}</strong> <strong>{$postrow[''time'']}</strong>\r\n<br />\r\n<br />\r\n{$postrow[''message'']}\r\n<br />\r\n<br />\r\n<hr size=\"1\" />',-2,'120','',1179356759),
  (335,'error_nopermission','{$lang->error_nopermission_guest_1}\r\n<ol>\r\n<li>{$lang->error_nopermission_guest_2}</li>\r\n<li>{$lang->error_nopermission_guest_3}\r\n</li>\r\n<li>{$lang->error_nopermission_guest_4}</li>\r\n</ol>\r\n<form action=\"member.php\" method=\"post\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_login\" />\r\n<input type=\"hidden\" name=\"url\" value=\"{$url}\" />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->login}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"username\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->password}</strong></td>\r\n<td class=\"trow2\"><input type=\"password\" class=\"textbox\" name=\"password\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" colspan=\"2\"><span class=\"smalltext\" style=\"float:right; padding-top:3px;\"><a href=\"member.php?action=register\">{$lang->need_reg}</a> | <a href=\"member.php?action=lostpw\">{$lang->forgot_password}</a>&nbsp;</span>&nbsp;<input type=\"submit\" class=\"button\" value=\"{$lang->login}\" /></td>\r\n</tr>\r\n</table>\r\n</form>\r\n<br />',-2,'120','',1179356759),
  (336,'error_nopermission_loggedin','{$lang->error_nopermission_user_1}\r\n<ol>\r\n\t<li>{$lang->error_nopermission_user_2}</li>\r\n\t<li>{$lang->error_nopermission_user_3}</li>\r\n\t<li>{$lang->error_nopermission_user_4} (<a href=\"member.php?action=resendactivation\">{$lang->error_nopermission_user_resendactivation}</a>)</li>\r\n</ol>\r\n<br />\r\n{$lang->error_nopermission_user_5}',-2,'120','',1179356759),
  (337,'private_folders','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->pm_folders}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"private.php\" method=\"post\">\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->existing_folders}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">{$lang->edit_folder_note}</span></td>\r\n</tr>\r\n{$folderlist}\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->new_folders}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><span class=\"smalltext\">{$lang->add_folders_note}</span></td>\r\n</tr>\r\n{$newfolders}\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_folders\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_folders}\" />\r\n</div>\r\n</td>\r\n</tr>\r\n</table>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (338,'forumjump_bit','<option value=\"{$forum[''fid'']}\" {$optionselected}>{$depth} {$forum[''name'']}</option>',-2,'120','',1179356759),
  (339,'forumjump_special','<select name=\"{$name}\">\r\n<option value=\"index\" {$jumpsel[''default'']}>{$lang->forumjump_select}</option>\r\n<option value=\"index\">--------------------</option>\r\n{$forumjumpbits}\r\n</select>\r\n',-2,'120','',1179356759),
  (340,'moderation_move','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->move_copy_thread}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->move_copy_thread}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->new_forum}</strong></td>\r\n<td class=\"trow2\">{$forumselect}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" valign=\"top\"><strong>{$lang->method}</strong></td>\r\n<td class=\"trow2\">\r\n<label><input type=\"radio\" class=\"radio\" name=\"method\" value=\"move\" />{$lang->method_move}</label><br />\r\n<label><input type=\"radio\" class=\"radio\" name=\"method\" value=\"redirect\" checked=\"checked\" />{$lang->method_move_redirect}</label> <input type=\"text\" class=\"textbox\" name=\"redirect_expire\" size=\"3\" /> {$lang->redirect_expire_note}<br />\r\n<label><input type=\"radio\" class=\"radio\" name=\"method\" value=\"copy\" />{$lang->method_copy}</label><br />\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->move_copy_thread}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_move\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (341,'moderation_merge','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->merge_threads}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->merge_threads}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->new_subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"subject\" value=\"{$thread[''subject'']}\" size=\"40\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->thread_to_merge_with}</strong><br /><span class=\"smalltext\">{$lang->merge_with_note}</span></td>\r\n<td class=\"trow1\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"threadurl\" size=\"40\" />\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->merge_threads}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_merge\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (342,'showthread_similarthreads_bit','<tr>\r\n\t<td align=\"center\" class=\"{$trow}\" width=\"2%\">{$icon}</td>\r\n\t<td class=\"{$trow}\"><a href=\"showthread.php?tid={$similar_thread[''tid'']}\">{$similar_thread[''subject'']}</a></td>\r\n\t<td align=\"center\" class=\"{$trow}\">{$similar_thread[''profilelink'']}</td>\r\n\t<td align=\"center\" class=\"{$trow}\"><a href=\"javascript:MyBB.whoPosted({$similar_thread[''tid'']});\">{$similar_thread[''replies'']}</a></td>\r\n\t<td align=\"center\" class=\"{$trow}\">{$similar_thread[''views'']}</td>\r\n\t<td class=\"{$trow}\" style=\"white-space: nowrap\">\r\n\t\t<span class=\"smalltext\">{$lastpostdate} {$lastposttime}<br />\r\n\t\t<a href=\"showthread.php?action=lastpost&amp;tid={$similar_thread[''tid'']}\">{$lang->lastpost}</a>: {$lastposterlink}</span>\r\n\t</td>\r\n\t</tr>',-2,'120','',1179356759),
  (343,'calendar_eventbit_public','<a href=\"calendar.php?action=event&amp;eid={$event[''eid'']}\" title=\"{$event[''fullsubject'']}\"><span class=\"smalltext\"><font color=\"{$mybb->settings[''publiceventcolor'']}\">{$event[''subject'']}</font></span></a><br />',-2,'120','',1179356759),
  (344,'calendar_eventbit_private','<a href=\"calendar.php?action=event&amp;eid={$event[''eid'']}\" title=\"{$event[''fullsubject'']}\"><span class=\"smalltext\"><font color=\"{$mybb->settings[''privateeventcolor'']}\">{$event[''subject'']}</font></span></a><br />',-2,'120','',1179356759),
  (345,'calendar_daybit_today','<td width=\"14%\" height=\"90\" class=\"trow2\" valign=\"top\">\r\n<strong><a href=\"calendar.php?action=dayview&amp;year={$year}&amp;month={$month}&amp;day={$i}\">{$i}</a></strong>\r\n<br /><span class=\"smalltext\">{$birthdays}{$events[$i]}</span>\r\n</td>',-2,'120','',1179356759),
  (346,'calendar_daybit','<td width=\"14%\" height=\"90\" class=\"trow1\" valign=\"top\">\r\n<strong><a href=\"calendar.php?action=dayview&amp;year={$year}&amp;month={$month}&amp;day={$i}\">{$i}</a></strong>\r\n<br /><span class=\"smalltext\">{$birthdays}{$events[$i]}</span>\r\n</td>',-2,'120','',1179356759),
  (347,'polls_newpoll_option','<tr>\r\n<td>{$lang->option} {$i}:&nbsp;</td>\r\n<td><input type=\"text\" class=\"textbox\" name=\"options[{$i}]\" value=\"{$option}\" size=\"25\" /></td>\r\n</tr>',-2,'120','',1179356759),
  (348,'showthread_poll_option_multiple','<tr>\r\n<td class=\"trow1\" width=\"5%\"><input type=\"checkbox\" class=\"checkbox\" name=\"option[{$number}]\" id=\"option[{$number}]\" value=\"yes\" /></td>\r\n<td class=\"trow2\" colspan=\"3\">{$option}</td>\r\n</tr>',-2,'120','',1179356759),
  (349,'showthread_poll_option','<tr>\r\n<td class=\"trow1\" width=\"5%\"><input type=\"radio\" class=\"radio\" name=\"option\" id=\"option\" value=\"{$number}\" /></td>\r\n<td class=\"trow1\" colspan=\"3\">{$option}</td>\r\n</tr>',-2,'120','',1179356759),
  (350,'member_activate','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->account_activation}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<form action=\"member.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->activate_account}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"30%\"><strong>{$lang->username}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"username\" value=\"{$user[''username'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"30%\"><strong>{$lang->activation_code}</strong></td>\r\n<td class=\"trow1\"><input type=\"text\" class=\"textbox\" name=\"code\" value=\"{$code}\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"hidden\" name=\"action\" value=\"activate\" /><input type=\"submit\" class=\"button\" name=\"regsubmit\" value=\"{$lang->activate_account}\" /></div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356759),
  (351,'smilieinsert','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" width=\"150\">\r\n<tr>\r\n<td class=\"thead\"><span class=\"smalltext\"><strong>{$lang->smilieinsert}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" id=\"clickable_smilies\">\r\n{$smilies}\r\n</table>\r\n</td>\r\n</tr>\r\n{$getmore}\r\n</table>',-2,'120','',1179356759),
  (352,'misc_buddypopup_user_sendpm','<a href=\"private.php?action=send&amp;uid={$buddy[''uid'']}\" target=\"_blank\">{$lang->pm_buddy}</a>&nbsp;&nbsp;',-2,'120','',1179356760),
  (353,'usercp_editlists','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->edit_lists}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table style=\"width:auto;height:auto;vertical-align:top;\" cellpadding=\"2\">\r\n<tr>\r\n<td align=\"left\" valign=\"top\" width=\"50%\">\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\"><strong>{$lang->edit_buddy_list}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n{$buddylist}\r\n{$newlist}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" align=\"center\"><span class=\"smalltext\">{$lang->remove_add_note}</span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_editlists\" />\r\n<input type=\"hidden\" name=\"list\" value=\"buddy\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_buddy_list}\" />\r\n</div>\r\n</form>\r\n</td>\r\n<td align=\"left\" valign=\"top\" width=\"50%\">\r\n<form action=\"usercp.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\"><strong>{$lang->edit_ignore_list}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n{$ignorelist}\r\n{$newlist}\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow2\" align=\"center\"><span class=\"smalltext\">{$lang->remove_add_note}</span></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_editlists\" />\r\n<input type=\"hidden\" name=\"list\" value=\"ignore\" />\r\n<input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->update_ignore_list}\" />\r\n</div>\r\n</form>\r\n</td>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (354,'online_iplookup','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->ip_lookup}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->ip_lookup}</strong></td>\r\n</tr>\r\n<td class=\"trow2\"><strong>{$lang->ip}</strong></td>\r\n<td class=\"trow2\">{$ip}</td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->resolves_to}<br /><span class=\"smalltext\">{$lang->if_resolvable}</span></strong></td>\r\n<td class=\"trow2\">{$host}</td>\r\n</tr>\r\n{$adminoptions}\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (355,'online_iplookup_adminoptions','<tr>\r\n<td class=\"trow1\"><strong>{$lang->admin_options}</strong></td>\r\n<td class=\"trow2\">\r\n\t<a href=\"{$config[''admin_dir'']}/users.php?action=find&searchop[sortby]=username&searchop[order]=asc&search[regip]={$ip}\">{$lang->search_regip_users}</a><br />\r\n\t<a href=\"{$config[''admin_dir'']}/users.php?action=find&searchop[sortby]=username&searchop[order]=asc&search[postip]={$ip}\">{$lang->search_postip_users}</a>\r\n</td>\r\n</tr>',-2,'','',1179356760),
  (356,'online_row','<tr>\r\n<td class=\"trow1\">{$onlinename}{$userip}</td>\r\n<td align=\"center\" class=\"trow2\">{$onlinetime}</td>\r\n<td class=\"trow1\" width=\"50%\">{$locationname}</td>\r\n</tr>',-2,'120','',1179356760),
  (357,'online_row_ip','<br /><span class=\"smalltext\">{$lang->ip} {$user[''ip'']} <a href=\"online.php?action=iplookup&amp;ip={$user[''ip'']}\">{$lang->lookup}</a></span>',-2,'120','',1179356760),
  (358,'calendar_editevent','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->calendar} - {$lang->edit_event}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$event_errors}\r\n<form action=\"calendar.php\" method=\"post\" name=\"input\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td colspan=\"2\" width=\"100%\" class=\"thead\"><strong>{$lang->edit_event}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"20%\" class=\"trow1\"><strong>{$lang->event_date}</strong></td>\r\n<td class=\"trow1\">\r\n<select name=\"month\">\r\n<option value=\"1\"{$msel[''1'']}>{$lang->month_1}</option>\r\n<option value=\"2\"{$msel[''2'']}>{$lang->month_2}</option>\r\n<option value=\"3\"{$msel[''3'']}>{$lang->month_3}</option>\r\n<option value=\"4\"{$msel[''4'']}>{$lang->month_4}</option>\r\n<option value=\"5\"{$msel[''5'']}>{$lang->month_5}</option>\r\n<option value=\"6\"{$msel[''6'']}>{$lang->month_6}</option>\r\n<option value=\"7\"{$msel[''7'']}>{$lang->month_7}</option>\r\n<option value=\"8\"{$msel[''8'']}>{$lang->month_8}</option>\r\n<option value=\"9\"{$msel[''9'']}>{$lang->month_9}</option>\r\n<option value=\"10\"{$msel[''10'']}>{$lang->month_10}</option>\r\n<option value=\"11\"{$msel[''11'']}>{$lang->month_11}</option>\r\n<option value=\"12\"{$msel[''12'']}>{$lang->month_12}</option>\r\n</select>\r\n&nbsp;\r\n<select name=\"day\">\r\n{$dayopts}\r\n</select>\r\n&nbsp;\r\n<select name=\"year\">\r\n{$yearopts}\r\n</select>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\"20%\" class=\"trow2\"><strong>{$lang->event_name}</strong></td>\r\n<td  class=\"trow2\"><input type=\"text\" class=\"textbox\" size=\"50\" name=\"subject\" value=\"{$event[''subject'']}\" /></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"20%\" class=\"trow1\"><strong>{$lang->event_details}</strong><div style=\"text-align: center;\">{$smilieinserter}</div></td>\r\n<td class=\"trow1\"><textarea name=\"description\" id=\"message\" rows=\"20\" cols=\"70\">{$event[''description'']}</textarea>\r\n{$codebuttons}</td>\r\n</tr>\r\n<tr>\r\n<td width=\"20%\" class=\"trow2\"><strong>{$lang->event_options}</strong></td>\r\n<td class=\"trow2\">\r\n<input type=\"checkbox\" class=\"checkbox\" name=\"private\" value=\"yes\"{$privatecheck} /><span class=\"smalltext\">{$lang->private_option}</span><br />\r\n<input type=\"checkbox\" class=\"checkbox\" name=\"delete\" value=\"yes\" /><span class=\"smalltext\">{$lang->delete_option}</span>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<input type=\"hidden\" name=\"action\" value=\"do_editevent\" /><input type=\"hidden\" name=\"eid\" value=\"{$eid}\" />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->edit_event}\" />\r\n</div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (359,'postbit_offline','<font color=\"#C7C7C7\"><strong>{$lang->postbit_status_offline}</strong></font>',-2,'120','',1179356760),
  (360,'postbit_editedby','<p class=\"smalltext\">{$post[''editnote'']} <a href=\"member.php?action=profile&amp;uid={$post[''edituid'']}\">{$post[''editusername'']}</a>.</p>\r\n\r\n',-2,'120','',1179356760),
  (361,'member_register_requiredfields','<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->additional_info}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n{$requiredfields}\r\n</table>\r\n</fieldset>',-2,'120','',1179356760),
  (362,'member_register_customfield','<tr>\r\n<td><span class=\"smalltext\">{$profilefield[''name'']}</span></td>\r\n<tr>\r\n<td>{$code}</td>\r\n</tr>',-2,'120','',1179356760),
  (363,'error','<html>\r\n<head>\r\n<title>{$title}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><span class=\"smalltext\"><strong>{$title}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$error}</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (364,'index_whosonline_memberbit','{$comma}<a href=\"member.php?action=profile&amp;uid={$user[''uid'']}\">{$user[''username'']}</a>{$invisiblemark}',-2,'120','',1179356760),
  (365,'member_profile_away','<tr>\r\n<td class=\"trow1\" align=\"center\">\r\n<strong>{$lang->away_note}</strong><br />\r\n<span class=\"smalltext\"><em>{$lang->away_reason} {$awayreason}</em></span><br />\r\n{$lang->away_since} {$awaydate} &nbsp;&nbsp;&nbsp; {$lang->away_returns} {$returndate}\r\n</td>\r\n</tr>',-2,'120','',1179356760),
  (366,'forumdisplay_moderatedby_moderator','{$modcomma}<a href=\"member.php?action=profile&amp;uid={$moderator[''uid'']}\">{$moderator[''username'']}</a>',-2,'120','',1179356760),
  (367,'forumdisplay_moderatedby','<span class=\"smalltext\">{$lang->moderated_by} <strong>{$modlist}</strong></span><br />',-2,'120','',1179356760),
  (368,'forumbit_depth2_cat','<tr>\r\n<td class=\"tcat\">&nbsp;</td>\r\n<td class=\"tcat\" colspan=\"4\"><strong>&raquo;&nbsp;&nbsp;<a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><span class=\"smalltext\">{$forum[''description'']}{$sub_forums}</span></td></tr>',-2,'120','',1179356760),
  (369,'forumbit_depth1_cat_subforum','<tr>\r\n<td class=\"tcat\" colspan=\"6\"><strong>&raquo;&nbsp;&nbsp;<a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><span class=\"smalltext\">{$forum[''description'']}</span></td></tr>{$sub_forums}',-2,'121','',1179356760),
  (370,'misc_help','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->help_docs}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n{$sections}\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (371,'posticons','<tr>\r\n<td class=\"trow1\"><strong>{$lang->post_icon}</strong><br /><span class=\"smalltext\"><input type=\"radio\" class=\"radio\" name=\"icon\" value=\"-1\"{$no_icons_checked} />{$lang->no_post_icon}</span></td>\r\n<td class=\"trow1\" valign=\"top\">{$iconlist}</td>\r\n</tr>\r\n',-2,'120','',1179356760),
  (372,'previewpost','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->post_preview}</strong></td>\r\n</tr>\r\n{$postbit}\r\n</table>\r\n<br />',-2,'127','',1179356760),
  (373,'misc_help_helpdoc','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->help_docs}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$helpdoc[''name'']}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"100%\" class=\"trow1\">{$helpdoc[''document'']}</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (374,'usercp_options_pppselect','<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->ppp}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">\r\n<select name=\"ppp\">\r\n<option value=\"\">{$lang->use_default}</option>\r\n{$pppoptions}\r\n</select>\r\n</td>\r\n</tr>',-2,'120','',1179356760),
  (375,'usercp_forumsubscriptions','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->forum_subscriptions}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<table width=\"100%\" border=\"0\" align=\"center\">\r\n<tr>\r\n{$usercpnav}\r\n<td valign=\"top\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" width=\"1\"> </td>\r\n<td class=\"thead\" valign=\"bottom\"><span class=\"smalltext\"><strong>{$lang->forum}</strong></span></td>\r\n<td class=\"thead\" valign=\"bottom\" style=\"white-space: nowrap; text-align: center;\"><span class=\"smalltext\"><strong>{$lang->posts}</strong></span></td>\r\n<td class=\"thead\" valign=\"bottom\" style=\"white-space: nowrap; text-align: center;\"><span class=\"smalltext\"><strong>{$lang->threads}</strong></span></td>\r\n<td class=\"thead\" valign=\"bottom\" align=\"center\"><span class=\"smalltext\"><strong>{$lang->lastpost}</strong></span></td>\r\n</tr>\r\n{$forums}\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (376,'member_register_stylebit','<option value=\"{$style[''sid'']}\">{$style[''name'']}</option>',-2,'120','',1179356760),
  (377,'usercp_options_stylebit','<option value=\"{$style[''sid'']}\" {$selected}>{$style[''name'']}</option>',-2,'120','',1179356760),
  (378,'forumdisplay_password_wrongpass','<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><strong>{$lang->wrong_forum_password}</strong></td>\r\n</tr>\r\n',-2,'120','',1179356760),
  (379,'private_empty_folder','<tr>\r\n<td class=\"trow1\"><strong>{$foldername}</strong></td>\r\n<td class=\"trow1\" align=\"center\">{$foldercount}</td>\r\n<td class=\"trow1\" align=\"center\"><input type=\"checkbox\" class=\"checkbox\" name=\"empty[{$fid}]\" value=\"yes\" /></td>\r\n</tr>',-2,'120','',1179356760),
  (380,'misc_imcenter_msn','<html>\r\n<head>\r\n<title>{$lang->msn_messenger_center}</title>\r\n{$headerinclude}\r\n</head>\r\n<body style=\"margin:0;left:0;top:0\" class=\"trow2\">\r\n<table width=\"100%\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\"><strong>{$user[''username'']} - {$lang->msn_messenger_center}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$navigationbar}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\">{$lang->msn_address_is}<br />{$user[''msn'']}</td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (381,'misc_imcenter_yahoo','<html>\r\n<head>\r\n<title>{$lang->yahoo_center}</title>\r\n{$headerinclude}\r\n</head>\r\n<body style=\"margin:0;left:0;top:0\" class=\"trow2\">\r\n<table width=\"100%\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" border=\"0\" align=\"center\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" align=\"center\"><strong>{$user[''username'']} - {$lang->yahoo_center}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" align=\"center\"><span class=\"smalltext\"><strong>{$navigationbar}</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><strong>{$user[''yahoo'']}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><strong><img src=\"http://opi.yahoo.com/online?u={$user[''yahoo'']}&amp;m=g&amp;t=2\" /></strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><a href=\"http://edit.yahoo.com/config/send_webmesg?.target={$user[''yahoo'']}&amp;.src=pg\">{$lang->send_y_message}</a></span></td>\r\n</tr><tr>\r\n<td class=\"trow1\" align=\"center\" colspan=\"2\"><span class=\"smalltext\"><a href=\"http://members.yahoo.com/interests?.oc=t&amp;.kw={$user[''yahoo'']}&amp;.sb=1\">{$lang->view_y_profile}</a></td>\r\n</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (382,'usercp_editsig_current','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->current_sig}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$sigpreview}</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356760),
  (383,'usercp_editsig_preview','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\"><strong>{$lang->sig_preview}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">{$sigpreview}</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356760),
  (384,'member_resendactivation','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->resend_activation}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"member.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->resend_activation}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" width=\"40%\"><strong>{$lang->email_address}</strong></td>\r\n<td class=\"trow1\" width=\"60%\"><input type=\"text\" class=\"textbox\" name=\"email\" /></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" value=\"{$lang->request_activation}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_resendactivation\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (385,'nav','\r\n<div class=\"navigation\">\r\n{$nav}{$activesep}{$activebit}\r\n</div>',-2,'120','',1179356760),
  (386,'nav_bit','<a href=\"{$navbit[''url'']}\">{$navbit[''name'']}</a>{$sep}',-2,'120','',1179356760),
  (387,'nav_bit_active','<span class=\"active\">{$navbit[''name'']}</span>',-2,'120','',1179356760),
  (388,'moderation_inline_deletethreads','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->delete_threads}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->delete_threads}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\" colspan=\"2\" align=\"center\">{$lang->confirm_delete_threads}\r\n{$loginbox}\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->delete_threads}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_multideletethreads\" />\r\n<input type=\"hidden\" name=\"fid\" value=\"{$fid}\" />\r\n<input type=\"hidden\" name=\"threads\" value=\"{$inlineids}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (389,'postbit_inlinecheck','| <input type=\"checkbox\" class=\"checkbox\" name=\"inlinemod_{$post[''pid'']}\" id=\"inlinemod_{$post[''pid'']}\" value=\"1\" style=\"vertical-align: middle;\" {$inlinecheck}  />',-2,'120','',1179356760),
  (390,'moderation_inline_movethreads','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->move_threads}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->move_threads}</strong></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->new_forum}</strong></td>\r\n<td class=\"trow2\">{$forumselect}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->move_threads}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_multimovethreads\" />\r\n<input type=\"hidden\" name=\"fid\" value=\"{$fid}\" />\r\n<input type=\"hidden\" name=\"threads\" value=\"{$inlineids}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (391,'moderation_inline_mergeposts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->merge_posts}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->merge_posts}</strong></td>\r\n</tr>\r\n<tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->post_separator}</strong></td>\r\n<td class=\"trow2\"><label><input type=\"radio\" class=\"radio\" name=\"sep\" value=\"hr\" checked=\"checked\" />&nbsp;{$lang->horizontal_rule}</label><br /><label><input type=\"radio\" class=\"radio\" name=\"sep\" value=\"new_line\" />&nbsp;{$lang->new_line}</label></td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->merge_posts}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_multimergeposts\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"posts\" value=\"{$inlineids}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (392,'moderation_inline_splitposts','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->split_thread}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<form action=\"moderation.php\" method=\"post\">\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->split_thread}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"tcat\" colspan=\"2\"><span class=\"smalltext\"><strong>{$lang->new_thread_info}</strong></span></td>\r\n</tr>\r\n{$loginbox}\r\n<tr>\r\n<td class=\"trow2\"><strong>{$lang->new_subject}</strong></td>\r\n<td class=\"trow2\"><input type=\"text\" class=\"textbox\" name=\"newsubject\" value=\"[split] {$thread[''subject'']}\" size=\"50\" /></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\"><strong>{$lang->new_forum}</strong></td>\r\n<td class=\"trow1\">{$forumselect}</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\"><input type=\"submit\" class=\"button\" name=\"submit\" value=\"{$lang->split_thread}\" /></div>\r\n<input type=\"hidden\" name=\"action\" value=\"do_multisplitposts\" />\r\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\r\n<input type=\"hidden\" name=\"posts\" value=\"{$inlineids}\" />\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (393,'member_register_regimage','<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->image_verification}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->verification_note}</span></td>\r\n<td rowspan=\"2\" align=\"center\"><img src=\"captcha.php?action=regimage&amp;imagehash={$imagehash}\" alt=\"{$lang->image_verification}\" /><br /><span style=\"color: red;\" class=\"smalltext\">{$lang->verification_subnote}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"imagestring\" value=\"\" /><input type=\"hidden\" name=\"imagehash\" value=\"{$imagehash}\" /></td>\r\n</tr>\r\n</table>\r\n</fieldset>',-2,'120','',1179356760),
  (394,'error_inline','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\"><tr>\r\n<td class=\"thead\"><strong>{$title}</strong></td>\r\n</tr>\r\n<tr>\r\n<td class=\"trow1\">\r\n<ul>\r\n{$errorlist}\r\n</ul>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356760),
  (395,'member_register','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->registration}</title>\r\n{$headerinclude}\r\n</head>\r\n<body>\r\n{$header}\r\n<br />\r\n<form action=\"member.php\" method=\"post\">\r\n{$regerrors}\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"thead\" colspan=\"2\"><strong>{$lang->registration}</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"50%\" class=\"trow1\" valign=\"top\">\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->account_details}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->username}</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\"><input type=\"text\" class=\"textbox\" name=\"username\" size=\"40\" value=\"{$username}\" /></td>\r\n</tr>\r\n{$passboxes}\r\n<tr>\r\n<td><span class=\"smalltext\">{$lang->email}</span></td>\r\n<td><span class=\"smalltext\">{$lang->confirm_email}</span></td>\r\n</tr>\r\n<tr>\r\n<td><input type=\"text\" class=\"textbox\" name=\"email\" size=\"20\" maxlength=\"50\" value=\"{$email}\" /></td>\r\n<td><input type=\"text\" class=\"textbox\" name=\"email2\" size=\"20\" maxlength=\"50\" value=\"{$email2}\" /></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n{$requiredfields}\r\n{$referrer}\r\n{$regimage}\r\n</td>\r\n<td width=\"50%\" class=\"trow1\" valign=\"top\">\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->account_prefs}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"allownotices\" id=\"allownotices\" value=\"yes\" {$allownoticescheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"allownotices\">{$lang->allow_notices}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"hideemail\" id=\"hideemail\" value=\"yes\" {$hideemailcheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"hideemail\">{$lang->hide_email}</label></span></td>\r\n\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"emailnotify\" id=\"emailnotify\" value=\"yes\" {$emailnotifycheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"emailnotify\">{$lang->email_notify}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"receivepms\" id=\"receivepms\" value=\"yes\" {$receivepmscheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"receivepms\">{$lang->receive_pms}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"pmpopup\" id=\"pmpopup\" value=\"yes\" {$pmpopupcheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"pmpopup\">{$lang->pm_popup}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"emailpmnotify\" id=\"emailpmnotify\" value=\"yes\" {$emailpmnotifycheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"emailpmnotify\">{$lang->email_notify_newpm}</label></span></td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" width=\"1\"><input type=\"checkbox\" class=\"checkbox\" name=\"invisible\" id=\"invisible\" value=\"yes\" {$invisiblecheck} /></td>\r\n<td valign=\"top\"><span class=\"smalltext\"><label for=\"invisible\">{$lang->invisible_mode}</label></span></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->time_offset}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->time_offset_desc}</span></td>\r\n</tr>\r\n<tr>\r\n<td>{$tzselect}</td>\r\n</tr>\r\n<tr>\r\n<td valign=\"top\" colspan=\"2\"><input type=\"checkbox\" class=\"checkbox\" name=\"enabledst\" id=\"enabledst\" value=\"yes\" {$enabledstcheck} />   <span class=\"smalltext\"><label for=\"enabledst\">{$lang->enable_dst}</label></span></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n<br />\r\n<fieldset class=\"trow2\">\r\n<legend><strong>{$lang->lang_select}</strong></legend>\r\n<table cellspacing=\"0\" cellpadding=\"{$theme[''tablespace'']}\">\r\n<tr>\r\n<td colspan=\"2\"><span class=\"smalltext\">{$lang->lang_select_desc}</span></td>\r\n</tr>\r\n<tr>\r\n<td><select name=\"language\"><option value=\"\">{$lang->lang_select_default}</option><option value=\"\">-----------</option>{$langoptions}</select></td>\r\n</tr>\r\n</table>\r\n</fieldset>\r\n</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<div align=\"center\">\r\n<input type=\"hidden\" name=\"action\" value=\"do_register\" />\r\n<input type=\"submit\" class=\"button\" name=\"regsubmit\" value=\"{$lang->submit_registration}\" />\r\n</div>\r\n</form>\r\n{$footer}\r\n</body>\r\n</html>',-2,'122','',1179356760),
  (396,'global_bannedwarning','<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n<tr>\r\n<td class=\"trow1\" align=\"center\"><font color=\"red\"><strong>{$lang->banned_warning}</strong><br />\r\n{$lang->banned_warning2}: {$reason}<br />\r\n{$lang->banned_warning3}: {$banlift}<br />\r\n</font></td>\r\n</tr>\r\n</table>\r\n<br />',-2,'120','',1179356760),
  (397,'htmldoctype','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">',-2,'120','',1179356760),
  (398,'postbit_multiquote','<script type=\"text/javascript\">document.write(\"<a href=\\\"javascript:Thread.multiQuote({$post[''pid'']});\\\"><img src=\\\"{$theme[''imglangdir'']}/postbit_multiquote.gif\\\" alt=\\\"{$lang->postbit_multiquote}\\\" title=\\\"{$lang->postbit_multiquote}\\\" id=\\\"multiquote_{$post[''pid'']}\\\" /><\\/a>\");</script>',-2,'120','',1179356760),
  (399,'private_send_autocomplete','<script type=\"text/javascript\" src=\"jscripts/autocomplete.js?ver=121\"></script>\r\n<script type=\"text/javascript\">\r\n\tnew autoComplete(\"to\", \"xmlhttp.php?action=get_users\", {valueSpan: \"username\"});\r\n</script>',-2,'120','',1179356760),
  (400,'forumdisplay_threadlist_inlineedit_js','<script type=\"text/javascript\" src=\"jscripts/inline_edit.js?ver=121\"></script>\r\n<script type=\"text/javascript\">\r\n\tnew inlineEditor(\"xmlhttp.php?action=edit_subject\", {className: \"subject_editable\", spinnerImage: \"{$theme[''imgdir'']}/spinner.gif\", lang_click_edit: \"{$lang->click_hold_edit}\"});\r\n</script>',-2,'120','',1179356760);

COMMIT;

#
# Data for the `mybb_templates` table  (LIMIT 400,100)
#

INSERT INTO `mybb_templates` (`tid`, `title`, `template`, `sid`, `version`, `status`, `dateline`) VALUES
  (401,'xmlhttp_inline_post_editor','<br />\r\n\t\t<div style=\"clear: both;\">\r\n\t\t\t<div>\r\n\t\t\t\t<textarea style=\"width: 99%; padding: 4px; margin: 0;\" rows=\"12\" cols=\"80\" id=\"quickedit_{$post[''pid'']}\" />{$post[''message'']}</textarea>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"editor_control_bar\" style=\"width: 99%; padding: 4px; margin-top: 3px; text-align: right;\">\r\n\t\t\t\t<input type=\"button\" class=\"button\" onclick=\"Thread.quickEditSave({$post[''pid'']});\" value=\"{$lang->save_changes}\" />\r\n\t\t\t\t<input type=\"button\" class=\"button\" onclick=\"Thread.quickEditCancel({$post[''pid'']});\" value=\"{$lang->cancel_edit}\" />\r\n\t\t\t</div>\r\n\t\t\t<br style=\"clear: both;\" />\r\n\t\t</div>',-2,'120','',1179356760),
  (402,'reputation_vote','<tr>\r\n\t<td class=\"trow1 {$status_class}\">\r\n\t\t{$reputation_vote[''username'']}{$reputation_vote[''user_reputation'']} - {$last_updated} {$delete_link}<br /><br /></span>\r\n\t\t<strong class=\"{$vote_type_class}\">{$vote_type}:</strong> {$reputation_vote[''comments'']}\r\n\t</td>\r\n</tr>',-2,'123','',1179356760),
  (403,'reputation_addlink','<div class=\"float_right\" style=\"padding-bottom: 4px;\"><a href=\"javascript:MyBB.reputation({$user[''uid'']});\"><img src=\"{$theme[''imglangdir'']}/rateuser.gif\" alt=\"{$lang->rate_user}\" /></a></div>',-2,'120','',1179356760),
  (404,'member_profile_reputation','<tr>\r\n\t<td class=\"trow1\"><strong>{$lang->reputation}</strong></td>\r\n\t<td class=\"trow1\">{$reputation} [<a href=\"reputation.php?uid={$memprofile[''uid'']}\">{$lang->reputation_details}</a>] {$vote_link}</td>\r\n</tr>',-2,'120','',1179356760),
  (405,'reputation_no_votes','<tr>\r\n\t<td class=\"trow1\" style=\"text-align: center;\">{$lang->no_reputation_votes}</td>\r\n</tr>',-2,'120','',1179356760),
  (406,'reputation_add_error','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reputation}</title>\r\n{$headerinclude}\r\n<script type=\"text/javascript\">var showBack = {$show_back};</script>\r\n</head>\r\n<body>\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t<tr>\r\n\t\t<td class=\"trow1\" style=\"padding: 20px\">\r\n\t\t\t<strong>{$lang->error}</strong><br /><br />\r\n\t\t\t   <blockquote>{$message}</blockquote>\r\n\t\t\t\t<br /><br />\r\n\t\t\t\t<div style=\"text-align: center;\">\r\n\t\t\t\t\t<script type=\"text/javascript\">\r\n\t\t\t\t\tif(showBack == 1) { document.write(''[<a href=\"javascript:history.go(-1);\">{$lang->go_back}</a>]''); }\r\n\t\t\t\t\tdocument.write(''[<a href=\"javascript:window.close();\">{$lang->close_window}</a>]'');</script>\r\n\t\t\t\t</div>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (407,'reputation_added','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reputation}</title>\r\n{$headerinclude}\r\n</head>\r\n<body onunload=\"window.opener.location.reload();\">\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t<tr>\r\n\t\t<td class=\"trow1\" style=\"padding: 20px\">\r\n\t\t\t<strong>{$lang->vote_added}</strong><br /><br />\r\n\t\t\t   <blockquote>{$lang->vote_added_message}</blockquote>\r\n\t\t\t\t<br /><br />\r\n\t\t\t\t<div style=\"text-align: center;\">\r\n\t\t\t\t\t<script type=\"text/javascript\">document.write(''[<a href=\"javascript:window.close();\">{$lang->close_window}</a>]'');</script>\r\n\t\t\t\t</div>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (408,'reputation_deleted','<html>\r\n<head>\r\n<title>{$mybb->settings[''bbname'']} - {$lang->reputation}</title>\r\n{$headerinclude}\r\n</head>\r\n<body onunload=\"window.opener.location.reload();\">\r\n<br />\r\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\r\n\t<tr>\r\n\t\t<td class=\"trow1\" style=\"padding: 20px\">\r\n\t\t\t<strong>{$lang->vote_deleted}</strong><br /><br />\r\n\t\t\t   <blockquote>{$lang->vote_deleted_message}</blockquote>\r\n\t\t\t\t<br /><br />\r\n\t\t\t\t<div style=\"text-align: center;\">\r\n\t\t\t\t\t<script type=\"text/javascript\">document.write(''[<a href=\"javascript:window.close();\">{$lang->close_window}</a>]'');</script>\r\n\t\t\t\t</div>\r\n\t\t</td>\r\n\t</tr>\r\n</table>\r\n</body>\r\n</html>',-2,'120','',1179356760),
  (409,'forumdisplay_thread_attachment_count','<div style=\"float: right;\"><img src=\"{$theme[''imgdir'']}/paperclip.gif\" alt=\"\" title=\"{$attachment_count}\" /></div>',-2,'120','',1179356760),
  (410,'forumdisplay_rssdiscovery','<link rel=\"alternate\" type=\"application/rss+xml\" title=\"{$lang->rss_discovery_forum} (RSS 2.0)\" href=\"{$mybb->settings[''bburl'']}/syndication.php?fid={$fid}\" />\r\n<link rel=\"alternate\" type=\"application/atom+xml\" title=\"{$lang->rss_discovery_forum} (Atom 1.0)\" href=\"{$mybb->settings[''bburl'']}/syndication.php?type=atom1.0&amp;fid={$fid}\" />',-2,'120','',1179356760),
  (411,'post_captcha','<tr>\r\n<td class=\"trow2\" valign=\"top\"><strong>{$lang->image_verification}</strong></td>\r\n<td class=\"trow2\">\r\n<table style=\"width: 300px; padding: 4px;\">\r\n\t<tr>\r\n\t\t<td rowspan=\"2\" style=\"vertical-align: middle;\"><img src=\"captcha.php?imagehash={$imagehash}\" alt=\"{$lang->image_verification}\" /></td>\r\n\t\t<td><span class=\"smalltext\">{$lang->verification_note}</span></td>\r\n\t</tr>\r\n\t<tr>\r\n\t\t<td><input type=\"text\" class=\"textbox\" name=\"imagestring\" value=\"\" /><input type=\"hidden\" name=\"imagehash\" value=\"{$imagehash}\" /></td>\r\n\t</tr>\r\n</table>\r\n</td>\r\n</tr>',-2,'120','',1179356760),
  (412,'post_captcha_hidden','<input type=\"hidden\" name=\"imagehash\" value=\"{$imagehash}\" />\r\n\t<input type=\"hidden\" name=\"imagestring\" value=\"{$imagestring}\" />',-2,'120','',1179356760),
  (413,'newreply_multiquote_external','<div id=\"multiquote_unloaded\"><span class=\"smalltext\" />{$multiquote_text} <a href=\"javascript:Post.loadMultiQuoted();\">{$multiquote_quote}</a>, <a href=\"javascript:Post.clearMultiQuoted();\">{$multiquote_deselect}</a></span></div>',-2,'120','',1179356760),
  (414,'postbit_author_user','<strong><span class=\"largetext\">{$post[''profilelink'']}</span></strong><br />\r\n<span class=\"smalltext\">\r\n\t{$post[''usertitle'']}<br />\r\n\t{$post[''userstars'']}\r\n\t{$post[''groupimage'']}<br />\r\n\t{$post[''useravatar'']}<br />\r\n\t{$lang->postbit_posts} {$post[''postnum'']}<br />\r\n\t{$lang->postbit_group} {$usergroup[''title'']}<br />\r\n\t{$lang->postbit_joined} {$post[''userregdate'']}<br />\r\n\t{$lang->postbit_status} {$post[''onlinestatus'']}{$post[''replink'']}<br />\r\n</span>',-2,'120','',1179356760),
  (415,'postbit_author_guest','<strong><span class=\"largetext\">{$post[''profilelink'']}</span></strong><br />\r\n<span class=\"smalltext\">\r\n\t{$post[''usertitle'']}<br />\r\n\t{$post[''userstars'']}\r\n\t{$post[''groupimage'']}<br />\r\n\t{$post[''useravatar'']}<br />\r\n</span>',-2,'120','',1179356760),
  (416,'index_logoutlink','<a href=\"member.php?action=logout&amp;uid={$mybb->user[''uid'']}\">{$lang->index_logout}</a>',2,'120','',1177896162),
  (417,'header','<script language=\"Javascript\" type=\"text/javascript\">\nvar cookieDomain = \"{$mybb->settings[''cookiedomain'']}\";\nvar cookiePath = \"{$mybb->settings[''cookiepath'']}\";\nvar newpm_prompt = \"{$lang->newpm_prompt}\";\nvar deleteevent_confirm = \"{$lang->deleteevent_confirm}\";\nvar removeattach_confirm = \"{$lang->removeattach_confirm}\";\nvar loading_text = ''{$lang->ajax_loading}'';\nvar saving_changes = ''{$lang->saving_changes}'';\nvar quickdelete_confirm = \"{$lang->quickdelete_confirm}\";\n</script>\n<a name=\"top\"></a>\n<div id=\"container\">\n<div id=\"header\">\n<div class=\"logo\" style=\"background:#fff url(''$theme[imgdir]/logobg.gif'');\"><left><a href=\"{$mybb->settings[''bburl'']}/index.php\"><img src=\"{$theme[''logo'']}\" alt=\"{$mybb->settings[''bbname'']}\" border=\"0\" /></a></center></div>\n<br />\n\n<!-- breadcrumb, login, pm info -->\n<table class=\"tborder\" cellpadding=\"$theme[tablespace]\" cellspacing=\"$theme[borderwidth]\" border=\"0\" width=\"100%\" align=\"center\">\n<tr>\n<td class=\"trow1\" width=\"100%\">\n\n<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n<tr valign=\"bottom\">\n\n<td>&nbsp;</td>\n<td width=\"100%\"><navigation></td>\n</tr>\n</table>\n\n</td>\n\n\n<if condition=$mybb->user[''uid'']> 0 <then>\n\n<td class=\"trow2\" valign=\"top\" nowrap=\"nowrap\">\n<div class=\"smalltext\">\n$lang->welcome_back<br />\n<a href=\"private.php\">$lang->welcome_pms</a> $lang->welcome_pms_usage<BR />\n$lang->welcome_current_time\n</div>\n</td>\n\n<else />\n\n<td class=\"trow2\" nowrap=\"nowrap\" style=\"padding:0px\">\n\n<!-- login form -->\n<form action=\"member.php\" method=\"post\">\n<input type=\"hidden\" name=\"action\" value=\"do_login\" />\n<table cellpadding=\"0\" cellspacing=\"3\" border=\"0\">\n<tr>\n<td class=\"smalltext\">$lang->username</td>\n<td><input type=\"text\" name=\"username\" size=\"10\" title=\"$lang->username\" value=\"$lang->username\" onfocus=\"this.value=''''\" /></td>\n<td class=\"smalltext\" colspan=\"2\" nowrap=\"nowrap\">\n\n<label for=\"remember\">\n<input type=\"checkbox\" name=\"remember\" id=\"remember\" value=\"yes\" checked=\"checked\" />Remember?</label>\n\n</td>\n</tr>\n<tr>\n<td class=\"smalltext\">$lang->password</td>\n\n<td><input type=\"password\" name=\"password\" size=\"10\" title=\"$lang->password\" value=\"$lang->password\" onfocus=\"this.value=''''\" /></td>\n\n\n<td><input type=\"submit\" class=\"smalltext\" style=\"font-weight:normal\" value=\"OK\" /></td>\n\n</tr>\n</table>\n</form>\n\n<!-- / login form -->\n\n</td>\n\n</if>\n\n</tr>\n</table>\n\n\n<!-- / breadcrumb, login, pm info -->\n\n<table cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">\n<tr>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/index.php\"><b>Index</b></a></td>\n\n<td class=\"tcat\" align=\"center\">\n{$welcomeblock}\n\n<td class=\"tcat\" align=\"center\">\n<a href=\"{$mybb->settings[''bburl'']}/search.php\" id=\"search\" onclick=\"return openMenu(this)\" class=\"popup_button\">Search<img src=\"images/popup_down.gif\" border=\"0\" /></a></td>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/misc.php?action=rules\"><b>Rules</b></a></td>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/misc.php?action=help\"><b>{$lang->toplinks_help}</b></a></td>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/memberlist.php\"><b>Member List</b></a></td>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/calendar.php\"><b>{$lang->toplinks_calendar}</b></a></td>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/downloads.php\"><b>Downloads</b></a></td>\n$admincplink\n<if condition=$mybb->user[''uid'']> 0 <then>\n<td class=\"tcat\" align=\"center\"><a href=\"{$mybb->settings[''bburl'']}/member.php?action=logout&uid={$mybb->user[''uid'']}\" onclick=\"return log_out()\"><b>$lang->welcome_logout</b></a></td><else /></if>\n</tr></table>\n\n\n<hr class=\"hidden\" />\n</div>\n<hr class=\"hidden\" />\n<div id=\"content\">\n{$bannedwarning}\n{$bbclosedwarning}\n{$unreadreports}\n\n\n<!-- header quick search form -->\n<div class=\"menupop\" id=\"search-popup\" style=\"display:none\">\n<table cellpadding=\"4\" cellspacing=\"1\" border=\"0\">\n<tr>\n<td class=\"tcat\">Search</td>\n</tr>\n<tr>\n<td class=\"row\">\n\n<form method=\"post\" action=\"$settings[bburl]/search.php\">\n<input type=\"hidden\" name=\"action\" value=\"do_search\" />\n<input type=\"hidden\" name=\"postthread\" value=\"1\" />\n<input type=\"hidden\" name=\"forums\" value=\"all\" />\n<input type=\"hidden\" name=\"showresults\" value=\"threads\" />\n<input type=\"text\" name=\"keywords\" value=\"\" />\n$gobutton\n</td>\n</tr>\n<tr>\n<td class=\"menu_row\"><a href=\"search.php\">Advanced Search</a></td>\n</tr>\n</table>\n</div></form>\n\n<!-- / header quick search form -->\n<br />',2,'125','',1177896162),
  (418,'index','<html>\n<head>\n<title>{$mybb->settings[''bbname'']}</title>\n{$headerinclude}\n</head>\n<body>\n{$header}\n<table border=\"0\" cellspacing=\"$theme[borderwidth]\" cellpadding=\"$theme[tablespace]\" class=\"tborder\"><thead><tr>\n<td class=\"tcat\" width=\"33\">&nbsp;</td>\n<td class=\"tcat\"><strong>$lang->forumbit_forum</strong></td>\n<td class=\"tcat\" width=\"236\" align=\"center\"><strong>$lang->forumbit_lastpost</strong></td>\n<td class=\"tcat\" width=\"46\" align=\"center\" nowrap=\"nowrap\"><strong>$lang->forumbit_threads</strong></td>\n<td class=\"tcat\" width=\"50\" align=\"center\" nowrap=\"nowrap\"><strong>$lang->forumbit_posts</strong></td>\n<td class=\"tcat\" width=\"112\" align=\"center\"><strong>Moderator</strong></td></tr>{$forums}<tr>\n<td class=\"bottommenu\" colspan=\"6\" align=\"center\">\n<span class=\"smalltext\"><a href=\"misc.php?action=markread\">$lang->markread</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"showteam.php\">$lang->forumteam</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"stats.php\">$lang->forumstats</a></span></td></tr></thead></table>\n<br />\n<br />\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\n<thead>\n<tr>\n<td class=\"thead\" colspan=\"2\">\n<div><strong>{$lang->boardstats}</strong></div>\n</td>\n</tr>\n</thead>\n{$whosonline}\n{$birthdays}\n{$forumstats}\n</table>\n<br />\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tr>\n<td valign=\"middle\" align=\"left\">\n<table cellspacing=\"0\" cellpadding=\"2\" border=\"0\">\n<tr><td><img src=\"$theme[imgdir]/on.gif\" alt=\"$lang->new_posts\" /></td><td class=\"trow\"><span class=\"smalltext\">&nbsp;&nbsp;$lang->new_posts</span></td></tr>\n<tr><td><img src=\"$theme[imgdir]/off.gif\" alt=\"$lang->no_new_posts\" /></td><td class=\"trow\"><span class=\"smalltext\">&nbsp;&nbsp;$lang->no_new_posts</span></td></tr>\n<tr><td><img src=\"$theme[imgdir]/offlock.gif\" alt=\"$lang->forum_locked\" /></td><td class=\"trow\"><span class=\"smalltext\">&nbsp;&nbsp;$lang->forum_locked</span></td></tr>\n</table>\n<div align=\"right\">$logoutlink</div>\n</td></tr>\n</table>\n{$footer}\n</body>\n</html>',2,'125','',1177896162),
  (419,'index_whosonline','<tr>\n<td class=\"tcat\" colspan=\"2\">\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/stats/collapse{$collapsedimg[''online'']}.gif\" id=\"online_img\" class=\"expander\" alt=\"[-]\" /></div>\n<strong>$lang->whos_online</strong> [<a href=\"online.php\">$lang->complete_list</a>]</td>\n</tr>\n<tbody style=\"{$collapsed[''online_e'']}\" id=\"online_e\">\n<tr>\n<td class=\"trow2\" width=\"34px\"><img src=\"$theme[imgdir]/online.gif\"></td>\n<td class=\"trow1\"><span class=\"smalltext\">$lang->online_note<br />$onlinemembers</span></td>\n</tr>\n</tbody>',2,'120','',1177896162),
  (420,'forumbit_moderators','<strong>{$moderators}</strong>',2,'125','',1177896162),
  (421,'footer','<hr class=\"hidden\" />\n\t\t</div>\n<br />\n\t\t\t<div class=\"bottommenu\" align=\"right\"><span class=\"smalltext\"><a href=\"$settings[contactlink]\">$lang->bottomlinks_contactus</a> - <a href=\"$settings[homeurl]\">$settings[homename]</a> - <a href=\"#top\">$lang->bottomlinks_returntop</a> - <a href=\"#content\">$lang->bottomlinks_returncontent</a> - <a href=\"archive/index.php\">$lang->bottomlinks_litemode</a> - <a href=\"$settings[bburl]/misc.php?action=syndication\">$lang->bottomlinks_syndication</a></span>\n\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div id=\"copyright\">\n\t\t\t\t<div id=\"debug\"><debugstuff></div>\n\t\t\t\t<!-- You may NOT remove, modify or hinder the visibility of the MyBB copyright at any time.\n\t\t\t\tIt must contain the links to the MyBB website and be formatted appropriately.\n\n\t\t\t\t\t Failure to comply with the above will result in prosecution to the full extent of the law.\n\t\t\t\t\t This is free software, support us and we''ll support you. -->\n{$lang->powered_by} <strong><a href=\"http://www.mybboard.com\" target=\"_blank\">MyBB</a></strong>{$mybbversion}<br />\n\t\t\t\t{$lang->copyright} &copy; 2002-{$copy_year} <strong><a href=\"http://www.mybboard.com\" target=\"_blank\">MyBB Group</a></strong><br />\n\t\t\t\tDesigned by <strong><a href=\"http://www.slodesignz.com\" target=\"_blank\">SloDesignz.com</a></strong>\n\t\t\t\t<!-- End copyright -->\n\t\t\t\t<br />\n<br class=\"clear\" />\n\t\t</div>\n\t\t</div>',2,'125','',1177896162),
  (422,'index_stats','<tr>\n<td class=\"tcat\" colspan=\"2\">\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/stats/collapse{$collapsedimg[''boardstats'']}.gif\" id=\"boardstats_img\" class=\"expander\" alt=\"[-]\" /></div>\n<strong>$lang->boardstats</strong></td></tr>\n<tbody style=\"{$collapsed[''boardstats_e'']}\" id=\"boardstats_e\">\n<tr>\n<td class=\"trow2\" width=\"34px\"><img src=\"$theme[imgdir]/stats.gif\"></td>\n<td class=\"trow1\"><span class=\"smalltext\">\n$lang->stats_posts_threads<br />\n$lang->stats_numusers<br />\n$lang->stats_newestuser<br />\n$lang->stats_mostonline\n</span>\n</td>\n</tr>\n</tbody>',2,'120','',1177896162),
  (423,'index_birthdays','<tr><td class=\"tcat\" colspan=\"2\">\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/stats/collapse{$collapsedimg[''birthday'']}.gif\" id=\"birthday_img\" class=\"expander\" alt=\"[-]\" /></div>\n<strong>$lang->todays_birthdays</td></tr>\n<tbody style=\"{$collapsed[''birthday_e'']}\" id=\"birthday_e\">\n<tr>\n<td class=\"trow2\" width=\"34px\"><img src=\"$theme[imgdir]/birthday.gif\"></td>\n<td class=\"trow1\"><span class=\"smalltext\">$bdays</span></td>\n</tr>\n</tbody>',2,'120','',1177896162),
  (424,'nav','<div class=\"navigation\">\n<img style=\"vertical-align:bottom;\" src=\"$theme[imgdir]/nav_start.gif\"/>{$nav}{$activesep}{$activebit}\n</div>',2,'125','',1177896162),
  (425,'headerinclude','<link rel=\"alternate\" type=\"application/rss+xml\" title=\"{$lang->latest_threads} (RSS 2.0)\" href=\"{$mybb->settings[''bburl'']}/syndication.php\" />\r\n<link rel=\"alternate\" type=\"application/atom+xml\" title=\"{$lang->latest_threads} (Atom 1.0)\" href=\"{$mybb->settings[''bburl'']}/syndication.php?type=atom1.0\" />\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset={$charset}\" />\r\n<script type=\"text/javascript\" src=\"jscripts/prototype.lite.js?ver=120\"></script>\r\n<script type=\"text/javascript\" src=\"jscripts/moo.ajax.js?ver=120\"></script>\r\n<script type=\"text/javascript\" src=\"jscripts/general.js?ver=120\"></script>\r\n<script type=\"text/javascript\" src=\"jscripts/menu.js\"></script>\r\n<script type=\"text/javascript\" src=\"jscripts/mybb.js\"></script>\r\n<script type=\"text/javascript\" src=\"jscripts/popup_menu.js?ver=120\"></script>\r\n<link rel=\"shortcut icon\" href=\"images/favicon.ico\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"{$theme[''css_url'']}\" />\r\n<script language=\"Javascript\" type=\"text/javascript\">\r\nvar cookieDomain = \"{$mybb->settings[''cookiedomain'']}\";\r\nvar cookiePath = \"{$mybb->settings[''cookiepath'']}\";\r\nvar newpm_prompt = \"{$lang->newpm_prompt}\";\r\nvar deleteevent_confirm = \"{$lang->deleteevent_confirm}\";\r\nvar removeattach_confirm = \"{$lang->removeattach_confirm}\";\r\n</script>\r\n{$newpmmsg}\r\n',2,'125','',1177896162),
  (426,'header_welcomeblock_member','<a href=\"usercp.php\" id=\"usercp\" onclick=\"return openMenu(this)\" class=\"popup_button\">User CP<img src=\"images/popup_down.gif\" border=\"0\" /></a>\n\n<!-- user cp tools menu -->\n<div class=\"menupop\" id=\"usercp-popup\" style=\"display:none\">\n<table cellpadding=\"4\" cellspacing=\"1\" border=\"0\">\n\n<tr><td class=\"thead\"><b>Quick Links</b></td></tr>\n<tr><td class=\"menu_row\" ><a href=\"search.php?action=getnew\"><font color=\"#026CB1\">View New Posts</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"misc.php?action=markread\"><font color=\"#026CB1\">Mark All Forums Read</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"misc.php?action=buddypopup\"><font color=\"#026CB1\">Buddy/Ignore List</a></td></tr></font>\n\n<tr><td class=\"thead\"><font color=\"#ffffff\"><a href=\"usercp.php\"><b>User CP</b></a></font></td></tr>\n<tr><td class=\"menu_row\"><a href=\"usercp.php?action=editsig\"><font color=\"#026CB1\">Change Signature</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"usercp.php?action=avatar\"><font color=\"#026CB1\">Change Avatar</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"usercp.php?action=profile\"><font color=\"#026CB1\">Edit Profile</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"usercp.php?action=options\"><font color=\"#026CB1\">Edit Options</a></td></tr></font>\n\n<tr><td class=\"thead\"><b>Miscellaneous</b></td></tr>\n<tr><td class=\"menu_row\"> <a href=\"private.php\"><font color=\"#026CB1\">Private Messages</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"usercp.php?action=subscriptions\"><font color=\"#026CB1\">Subscribed\n\nThreads</a></td></tr></font>\n<tr><td class=\"menu_row\"><a href=\"member.php?action=profile&amp;uid={$mybb->user[''uid'']}\"><font color=\"#026CB1\">View Profile</a></td></tr></font>\n</table>\n</div>\n\n<!-- / user cp tools menu -->\n<br />',2,'125','',1177896162),
  (427,'forumbit_depth2_forum','<tr>\n<td class=\"trow2\" align=\"center\" valign=\"middle\"><img src=\"{$theme[''imgdir'']}/{$lightbulb[''folder'']}.gif\" alt=\"{$lightbulb[''altonoff'']}\" title=\"{$lightbulb[''altonoff'']}\" /></td>\n<td class=\"trow1\" valign=\"middle\">\n<strong><a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><div class=\"smalltext\">{$forum[''description'']}{$subforums}</div>\n</td>\n<td class=\"trow2\" width=\"236\" valign=\"middle\" align=\"left\" style=\"white-space: nowrap\">{$lastpost}</td>\n<td class=\"trow1\" width=\"16\" valign=\"middle\" align=\"center\" style=\"white-space: nowrap\">{$threads}{$unapproved[''unapproved_threads'']}</td>\n<td class=\"trow2\" width=\"20\" valign=\"middle\" align=\"center\" style=\"white-space: nowrap\">{$posts}{$unapproved[''unapproved_posts'']}</td>\n<td class=\"trow1\" width=\"60\" valign=\"middle\" align=\"center\" style=\"white-space: nowrap\">{$modlist}</td>\n</tr>\n\n',2,'125','',1177896162),
  (428,'forumbit_depth1_cat_subforum','<tr>\n<td class=\"tcat\" colspan=\"7\"><strong>&raquo;&nbsp;&nbsp;<a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><span class=\"smalltext\">{$forum[''description'']}</span></td></tr>{$sub_forums}',2,'120','',1177896162),
  (429,'forumbit_depth1_cat','<tr><td class=\"thead\" colspan=\"6\"><div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/{$expcolimage}\" id=\"cat_{$forum[''fid'']}_img\" class=\"expander\" alt=\"{$expaltext}\" /></div>\n<div><strong><a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><div class=\"smalltext\">{$forum[''description'']}</div></div></td></tr><tbody style=\"{$expdisplay}\" id=\"cat_{$forum[''fid'']}_e\">\n{$sub_forums}</tbody>',2,'121','',1177896162),
  (430,'header_welcomeblock_member_admin','    <td class=\"tcat\" align=\"center\"><b><a href=\"{$mybb->settings[''bburl'']}/{$config[''admin_dir'']}/index.php\">{$lang->welcome_admin}</a></b></td>\n\n',2,'125','',1177896162),
  (431,'nav_sep','>',2,'125','',1177896162),
  (432,'nav_sep_active','<br><img style=\"vertical-align:bottom;\" src=\"$theme[imgdir]/nav_end.gif\"/>',2,'125','',1177896162),
  (433,'forumbit_depth2_forum_lastpost','<span class=\"smalltext\">\n<img src=\"{$theme[''imgdir'']}/post.gif\" /> <a href=\"showthread.php?tid={$lastposttid}&amp;action=lastpost\" title=\"{$full_lastpost_subject}\"><strong>{$lastpost_subject}</strong></a><br />\n{$lang->by} {$lastpost_profilelink}<br />\n<span style=\"float:right\">{$lastpost_date} {$lastpost_time} <a href=\"showthread.php?tid={$lastposttid}&amp;action=lastpost\" title=\"{$full_lastpost_subject}\"><img src=\"{$theme[''imgdir'']}/lastpost.gif\" /></a></span></span>',2,'120','',1177896162),
  (434,'header_welcomeblock_guest','<strong><a href=\"{$mybb->settings[''bburl'']}/member.php?action=register\">{$lang->welcome_register}</a></strong>',2,'125','',1177896162),
  (435,'postbit_author_user','<strong><span class=\"largetext\">{$post[''profilelink'']}</span></strong><br />\n<span class=\"smalltext\">\n    {$post[''usertitle'']}<br />\n    {$post[''userstars'']}\n    {$post[''groupimage'']}<br />\n    {$post[''useravatar'']}<br />\n    <strong>{$lang->postbit_posts}</strong> {$post[''postnum'']}<br />\n    <strong>{$lang->postbit_group}</strong> {$usergroup[''title'']}<br />\n    <strong>{$lang->postbit_joined}</strong> {$post[''userregdate'']}<br />\n    <strong>{$lang->postbit_status}</strong> {$post[''onlinestatus'']}{$post[''replink'']}<br />\n</span>',2,'125','',1177896162),
  (436,'forumdisplay_thread','<tr>\n\t<td align=\"center\" class=\"trow1\" width=\"2%\"><img src=\"{$theme[''imgdir'']}/{$folder}.gif\" alt=\"{$folder_label}\" title=\"{$folder_label}\" /></td>\n\t<td align=\"center\" class=\"trow2\" width=\"2%\">{$icon}</td>\n\t<td class=\"trow1\">\n\t\t{$attachment_count}\n\t\t<div><span>{$prefix} {$gotounread}<a href=\"showthread.php?tid={$thread[''tid'']}\" class=\"{$inline_edit_class}\" id=\"tid_{$inline_edit_tid}\">{$thread[''subject'']}</a>{$thread[''multipage'']}</span></div>\n\t</td>\n\t<td align=\"center\" class=\"trow2\">{$thread[''profilelink'']}</td>\n\t<td align=\"center\" class=\"trow1\"><a href=\"javascript:MyBB.whoPosted({$thread[''tid'']});\">{$thread[''replies'']}</a>{$unapproved_posts}</td>\n\t<td align=\"center\" class=\"trow2\">{$thread[''views'']}</td>\n\t{$rating}\n\t<td class=\"trow2\" style=\"white-space: nowrap\">\n\t\t<span class=\"smalltext\">{$lastpostdate} {$lastposttime}<br />\n\t\t<a href=\"showthread.php?action=lastpost&amp;tid={$thread[''tid'']}\">{$lang->lastpost}</a>: {$lastposterlink}</span>\n\t</td>\n{$modbit}\n</tr>',2,'120','',1177896162),
  (437,'forumbit_depth2_cat','<tr>\n<td class=\"tcat\">&nbsp;</td>\n<td class=\"tcat\" colspan=\"4\"><strong>&raquo;&nbsp;&nbsp;<a href=\"forumdisplay.php?fid={$forum[''fid'']}\">{$forum[''name'']}</a></strong><br /><span class=\"smalltext\">{$forum[''description'']}{$sub_forums} </span></td></tr>',2,'121','',1177896162),
  (438,'forumbit_depth3_statusicon','<img src=\"{$theme[''imgdir'']}/{$lightbulb[''folder'']}.gif\" alt=\"{$lightbulb[''altonoff'']}\" title=\"{$lightbulb[''altonoff'']}\" class=\"subforumicon\" /> ',2,'121','',1177896162),
  (439,'postbit','<tr>\n<td class=\"trow2\" width=\"15%\" valign=\"top\" style=\"white-space: nowrap; text-align: center;\"><a name=\"pid{$post[''pid'']}\" id=\"pid{$post[''pid'']}\"></a>\n{$post[''user_details'']}\n</td>\n<td class=\"trow1\" width=\"85%\" valign=\"top\">\n<table width=\"100%\">\n<tr><td>{$post[''posturl'']}{$post[''icon'']}<span class=\"smalltext\"><strong> {$post[''subject'']}</strong></span>\n<br />\n<div id=\"pid_{$post[''pid'']}\">\n<p>\n{$post[''message'']}\n</p>\n</div>\n{$post[''attachments'']}\n{$post[''signature'']}\n<div style=\"text-align: right; vertical-align: bottom;\">\n{$post[''editedmsg'']}\n{$post[''iplogged'']}\n</div>\n</td></tr>\n</table>\n</td>\n</tr>\n<tr>\n<td class=\"trow2\" height=\"18\" style=\"white-space: nowrap; text-align: center;\"><span class=\"smalltext\">{$post[''postdate'']} {$post[''posttime'']}</span></td>\n<td class=\"trow1\" width=\"100%\" valign=\"middle\" height=\"18\">\n\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n\t<tr valign=\"bottom\">\n\t\t<td align=\"left\" ><span class=\"smalltext\">{$post[''button_email'']}{$post[''button_pm'']}{$post[''button_www'']}{$post[''button_find'']}</span></td>\n\t\t<td align=\"right\"><span class=\"smalltext\">{$post[''button_edit'']}{$post[''button_quickdelete'']}{$post[''button_quote'']}{$post[''button_multiquote'']}{$post[''button_report'']}</span></td>\n\t</tr>\n\t</table>\n</td>\n</tr>\n{$seperator}',2,'121','',1177896162),
  (440,'showthread','<html>\n<head>\n<title>{$thread[''subject'']}</title>\n{$headerinclude}\n<script type=\"text/javascript\">\n\t\t var quickdelete_confirm = \"{$lang->quickdelete_confirm}\";\n</script>\n<script type=\"text/javascript\" src=\"jscripts/thread.js?ver=120\"></script>\n</head>\n<body>\n{$header}\n<br />\n{$pollbox}\n<div style=\"float: left; padding-bottom: 4px;\">\n\t{$newreply}{$newthread}\n</div>\n{$multipage}\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\n<tr>\n<td class=\"thead\" colspan=\"2\">\n\t<div style=\"float: right;\">\n\t\t<span class=\"smalltext\"><strong><a href=\"showthread.php?mode=threaded&amp;tid={$tid}&amp;pid={$pid}#pid{$pid}\">{$lang->threaded}</a> | <a href=\"showthread.php?mode=linear&amp;tid={$tid}&amp;pid={$pid}#pid{$pid}\">{$lang->linear}</a></strong></span>\n\t</div>\n\t<div>\n\t\t<strong>{$rating} {$thread[''subject'']}</strong>\n\t</div>\n</td>\n</tr>\n{$posts}\n{$threadpages}\n<tr>\n<td colspan=\"2\" class=\"tfoot\">\n<div><strong>&laquo; <a href=\"showthread.php?tid={$tid}&amp;action=nextoldest\">{$lang->next_oldest}</a> | <a href=\"showthread.php?tid={$tid}&amp;action=nextnewest\">{$lang->next_newest}</a> &raquo;</strong></div>\n</td>\n</tr>\n</table>\n<div style=\"padding-top: 4px;\">\n\t{$newreply}{$newthread}\n</div>\n{$threadexbox}\n{$quickreply}\n{$moderationoptions}\n{$similarthreads}\n<br />\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\n \t<tr>\n\t\t<td class=\"trow1\">\n\t\t\t<table width=\"100%\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<span class=\"smalltext\">\n\t\t\t\t\t\t\t<a href=\"printthread.php?tid={$tid}\">{$lang->view_printable}</a><br />\n\t\t\t\t\t\t\t<a href=\"sendthread.php?tid={$tid}\">{$lang->send_thread}</a><br />\n\t\t\t\t\t\t\t<a href=\"usercp2.php?action=addsubscription&amp;tid={$tid}\">{$lang->subscribe_thread}</a> | <a href=\"usercp2.php?action=addfavorite&amp;tid={$tid}\">{$lang->add_favorites}</a>\n\t\t\t\t\t\t</span>\n\t\t\t\t\t</td>\n\t\t\t\t\t<td align=\"right\">\n\t\t\t\t\t\t{$ratethread}\n\t\t\t\t\t\t<br />\n\t\t\t\t\t\t{$forumjump}\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</table>\n\t\t</td>\n\t</tr>\n</table>\n{$footer}\n</body>\n</html>',2,'120','',1177896162),
  (441,'showthread_quickreply','<br />\n<form method=\"post\" action=\"newreply.php\" name=\"input\">\n<input type=\"hidden\" name=\"subject\" value=\"RE: {$thread[''subject'']}\" />\n<input type=\"hidden\" name=\"action\" value=\"do_newreply\" />\n<input type=\"hidden\" name=\"tid\" value=\"{$tid}\" />\n<input type=\"hidden\" name=\"posthash\" value=\"{$posthash}\" />\n<input type=\"hidden\" name=\"quoted_ids\" value=\"\" />\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\n<thead>\n<tr>\n<td colspan=\"2\" class=\"thead\">\n<div class=\"expcolimage\"><img src=\"{$theme[''imgdir'']}/collapse{$collapsedimg[''quickreply'']}.gif\" id=\"quickreply_img\" class=\"expander\" alt=\"[-]\"/></div>\n<div><strong>{$lang->quick_reply}</strong></div>\n</td>\n</tr>\n</thead>\n<tbody style=\"{$collapsed[''quickreply_e'']}\" id=\"quickreply_e\">\n<tr>\n<td class=\"trow1\" valign=\"top\" width=\"22%\">\n<strong>{$lang->message}</strong><br />\n<span class=\"smalltext\">{$lang->message_note}<br /><br />\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[signature]\" value=\"yes\" {$postoptionschecked[''signature'']} />&nbsp;<strong>{$lang->signature}</strong></label><br />\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[emailnotify]\" value=\"yes\" {$postoptionschecked[''emailnotify'']} />&nbsp;<strong>{$lang->email_notify}</strong></label><br />\n<label><input type=\"checkbox\" class=\"checkbox\" name=\"postoptions[disablesmilies]\" value=\"yes\" />&nbsp;<strong>{$lang->disable_smilies}</strong></label>{$closeoption}</span>\n</td>\n<td class=\"trow1\">\n\t<div>\n\t\t<textarea style=\"width: 90%; background-color: #FFFFFF; margin: 0;\" rows=\"8\" cols=\"80\" name=\"message\" id=\"message\" tabindex=\"1\"></textarea>\n\t</div>\n\t<script type=\"text/javascript\">document.write(''<div class=\"editor_control_bar\" style=\"width: 90%; padding: 4px; margin-top: 3px; display: none;\" id=\"quickreply_multiquote\"><span class=\"smalltext\">{$lang->quickreply_multiquote_selected} <a href=\"javascript:Thread.loadMultiQuoted();\">{$lang->quickreply_multiquote_now}<\\/a> {$lang->or} <a href=\"javascript:Thread.clearMultiQuoted();\">{$lang->quickreply_multiquote_deselect}<\\/a>.<\\/span><\\/div>'');</script>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" align=\"center\" class=\"tfoot\"><input type=\"submit\" class=\"button\" value=\"{$lang->post_reply}\" tabindex=\"2\" accesskey=\"s\" /> <input type=\"submit\" class=\"button\" name=\"previewpost\" value=\"{$lang->preview_post}\" tabindex=\"3\" /></td>\n</tr>\n</tbody>\n</table>\n</form>',2,'120','',1177896162),
  (442,'usercp_nav','<td width=\"{$lang->ucp_nav_width}\" valign=\"top\">\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"0\" class=\"tborder\">\n<tr>\n<td class=\"thead\"><strong>{$lang->ucp_nav_menu}</strong></td>\n</tr>\n{$usercpmenu}\n</table>\n</td>',2,'120','',1177896162),
  (443,'forumdisplay_threadlist','<div class=\"float_left\" style=\"padding-bottom: 4px;\">\n\t{$newthread}\n</div>\n{$multipage}\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\" >\n\t<tr>\n\t\t<td class=\"thead\" colspan=\"{$colspan}\">\n\t\t\t<div style=\"float: right;\">\n\t\t\t\t<span class=\"smalltext\"><strong><a href=\"misc.php?action=markread&amp;fid={$fid}\">{$lang->markforum_read}</a> | <a href=\"usercp2.php?action=addsubscription&amp;type=forum&amp;fid={$fid}\">{$lang->subscribe_forum}</a>{$clearstoredpass}</strong></span>\n\t\t\t</div>\n\t\t\t<div>\n\t\t\t\t<strong>{$foruminfo[''name'']}</strong>\n\t\t\t</div>\n\t\t</td>\n\t</tr>\n\t<tr>\n\t\t<td class=\"tcat\" align=\"center\" colspan=\"2\">&nbsp;</td>\n\t\t<td class=\"tcat\" align=\"center\" width=\"40%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=subject&amp;order=asc\">{$lang->thread}</a> {$orderarrow[''subject'']}</strong></span></td>\n\t\t<td class=\"tcat\" align=\"center\" width=\"14%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=starter&amp;order=asc\">{$lang->author}</a> {$orderarrow[''starter'']}</strong></span></td>\n\t\t<td class=\"tcat\" align=\"center\" width=\"7%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=replies&amp;order=desc\">{$lang->replies}</a> {$orderarrow[''replies'']}</strong></span></td>\n\t\t<td class=\"tcat\" align=\"center\" width=\"7%\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=views&amp;order=desc\">{$lang->views}</a> {$orderarrow[''views'']}</strong></span></td>\n\t\t{$ratingcol}\n\t\t<td class=\"tcat\" align=\"center\" width=\"200\"><span class=\"smalltext\"><strong><a href=\"{$sorturl}&amp;sortby=lastpost&amp;order=desc\">{$lang->lastpost}</a> {$orderarrow[''lastpost'']}</strong></span></td>\n\t\t{$inlinemodcol}\n\t</tr>\n\t{$announcementlist}\n\t{$threads}\n\t<tr>\n\t\t<td class=\"tfoot\" align=\"right\" colspan=\"{$colspan}\">\n\t\t<form action=\"forumdisplay.php\" method=\"get\">\n\t\t\t<input type=\"hidden\" name=\"fid\" value=\"{$fid}\" />\n\t\t\t<select name=\"sortby\">\n\t\t\t\t<option value=\"subject\" {$sortsel[''subject'']}>{$lang->sort_by_subject}</option>\n\t\t\t\t<option value=\"lastpost\" {$sortsel[''lastpost'']}>{$lang->sort_by_lastpost}</option>\n\t\t\t\t<option value=\"starter\" {$sortsel[''starter'']}>{$lang->sort_by_starter}</option>\n\t\t\t\t<option value=\"started\" {$sortsel[''started'']}>{$lang->sort_by_started}</option>\n\t\t\t\t{$ratingsort}\n\t\t\t\t<option value=\"replies\" {$sortsel[''replies'']}>{$lang->sort_by_replies}</option>\n\t\t\t\t<option value=\"views\" {$sortsel[''views'']}>{$lang->sort_by_views}</option>\n\t\t\t</select>\n\t\t\t<select name=\"order\">\n\t\t\t\t<option value=\"asc\" {$ordersel[''asc'']}>{$lang->sort_order_asc}</option>\n\t\t\t\t<option value=\"desc\" {$ordersel[''desc'']}>{$lang->sort_order_desc}</option>\n\t\t\t</select>\n\t\t\t<select name=\"datecut\">\n\t\t\t\t<option value=\"1\" {$datecutsel[''1'']}>{$lang->datelimit_1day}</option>\n\t\t\t\t<option value=\"5\" {$datecutsel[''5'']}>{$lang->datelimit_5days}</option>\n\t\t\t\t<option value=\"10\" {$datecutsel[''10'']}>{$lang->datelimit_10days}</option>\n\t\t\t\t<option value=\"20\" {$datecutsel[''20'']}>{$lang->datelimit_20days}</option>\n\t\t\t\t<option value=\"50\" {$datecutsel[''50'']}>{$lang->datelimit_50days}</option>\n\t\t\t\t<option value=\"75\" {$datecutsel[''75'']}>{$lang->datelimit_75days}</option>\n\t\t\t\t<option value=\"100\" {$datecutsel[''100'']}>{$lang->datelimit_100days}</option>\n\t\t\t\t<option value=\"365\" {$datecutsel[''365'']}>{$lang->datelimit_lastyear}</option>\n\t\t\t\t<option value=\"9999\" {$datecutsel[''9999'']}>{$lang->datelimit_beginning}</option>\n\t\t\t</select>\n\t\t\t{$gobutton}\n\t\t</form>\n\t\t</td>\n\t</tr>\n</table>\n<div class=\"float_left\" style=\"padding-top: 4px; padding-bottom:4px;\">\n\t{$newthread}\n</div>\n{$multipage}\n<br style=\"clear: both;\" />\n{$inlinemod}\n\n<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\" >\n\t<tr>\n\t\t<td class=\"trow1\">\n\t\t\t<table width=\"100%\" border=\"0\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<table width=\"100%\" cellspacing=\"0\" cellpadding=\"2\" style=\"white-space: nowrap; border: none\">\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<td>\n\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/newfolder.gif\" alt=\"{$lang->new_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->new_thread}</span><br />\n\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/newhotfolder.gif\" alt=\"{$lang->new_hot_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->new_hot_thread}</span><br />\n\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/dot_folder.gif\" alt=\"{$lang->posts_by_you}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->posts_by_you}</span>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t\t<td>\n\t\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/folder.gif\" alt=\"{$lang->no_new_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->no_new_thread}</span><br />\n\t\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/hotfolder.gif\" alt=\"{$lang->hot_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->hot_thread}</span><br />\n\t\t\t\t\t\t\t\t\t<img src=\"{$theme[''imgdir'']}/lockfolder.gif\" alt=\"{$lang->locked_thread}\" />&nbsp;&nbsp;<span class=\"smalltext\">{$lang->locked_thread}</span>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</table>\n\t\t\t\t\t</td>\n\t\t\t\t\t<td align=\"right\">\n\t\t\t\t\t\t{$searchforum}<br /><br />\n\t\t\t\t\t\t{$forumjump}\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</table>\n\t\t</td>\n\t</tr>\n</table>\n{$inline_edit_js}',2,'125','',1177896162),
  (444,'forumdisplay_subforums','<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\">\n<tr>\n<td class=\"thead\" colspan=\"6\" align=\"center\"><strong>{$lang->sub_forums_in}</strong></td>\n</tr>\n<tr>\n<td class=\"tcat\" width=\"33\">&nbsp;</td>\n<td class=\"tcat\"><strong>$lang->forumbit_forum</strong></td>\n<td class=\"tcat\" width=\"236\" align=\"center\"><strong>$lang->forumbit_lastpost</strong></td>\n<td class=\"tcat\" width=\"46\" align=\"center\" nowrap=\"nowrap\"><strong>$lang->forumbit_threads</strong></td>\n<td class=\"tcat\" width=\"50\" align=\"center\" nowrap=\"nowrap\"><strong>$lang->forumbit_posts</strong></td>\n<td class=\"tcat\" width=\"112\" align=\"center\"><strong>Moderator</strong></td>\n</tr>\n{$forums}\n</table>\n<br />',2,'121','',1177896162),
  (445,'forumdisplay_thread_rating','<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/{$thread[''rating'']}\" alt=\"{$ratingvotesav}\" /></td>\n',2,'121','',1177896162),
  (446,'forumdisplay_thread_modbit','<td class=\"trow1\" align=\"center\" style=\"white-space: nowrap\"><input type=\"checkbox\" class=\"checkbox\" name=\"inlinemod_{$multitid}\" id=\"inlinemod_{$multitid}\" value=\"1\" {$inlinecheck}  /></td>',2,'121','',1177896162),
  (447,'forumdisplay_announcements_announcement','<tr>\n<td align=\"center\" class=\"trow1\"><img src=\"{$theme[''imgdir'']}/{$folder}\" alt=\"\"/></td>\n<td align=\"center\" class=\"trow2\">&nbsp;</td>\n<td class=\"trow1\"><a href=\"announcements.php?aid={$announcement[''aid'']}\">{$announcement[''subject'']}</a></td>\n<td align=\"center\" class=\"trow2\"><a href=\"member.php?action=profile&amp;uid={$announcement[''uid'']}\">{$announcement[''username'']}</a></td>\n<td align=\"center\" class=\"trow1\">-</td>\n<td align=\"center\" class=\"trow2\">-</td>\n{$rating}\n<td class=\"trow2\" style=\"white-space: nowrap\">{$postdate} {$posttime}</td>\n{$modann}\n</tr>\n',2,'121','',1177896162),
  (448,'misc_rules','<head>\n<title>{$mybb->settings[''bbname'']} - Rules</title>\n{$headerinclude}\n</head>\n<body>\n\t{$header}\n\t<table border=\"0\" cellspacing=\"{$theme[''borderwidth'']}\" cellpadding=\"{$theme[''tablespace'']}\" class=\"tborder\" style=\"clear: both;\">\n\t\t<tr>\n\t\t\t<td class=\"thead\"><strong>{$mybb->settings[''bbname'']} Rules</strong></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"trow1\">{$rules_list}</td>\n\t\t</tr>\n\t</table>\n\t{$footer}\n</body>\n</html>',2,'','',1177896162);

COMMIT;

#
# Data for the `mybb_templatesets` table  (LIMIT 0,100)
#

INSERT INTO `mybb_templatesets` (`sid`, `title`) VALUES
  (1,'Default Templates'),
  (2,'BlueBulletin Templates');

COMMIT;

#
# Data for the `mybb_themes` table  (LIMIT 0,100)
#

INSERT INTO `mybb_themes` (`tid`, `name`, `pid`, `def`, `css`, `cssbits`, `themebits`, `extracss`, `allowedgroups`, `csscached`) VALUES
  (1,'MyBB Master Style',0,0,'body {\n\tbackground: #efefef;\n\tcolor: #000;\n\tfont-family: Verdana;\n\tfont-size: 13px;\n\ttext-align: center; /* IE 5 fix */\r\n\tline-height: 1.4;\n}\na:link {\n\tcolor: #026CB1;\n\ttext-decoration: none;\n}\na:visited {\n\tcolor: #026CB1;\n\ttext-decoration: none;\n}\na:hover, a:active {\n\tcolor: #000;\n\ttext-decoration: underline;\n}\n#container {\n\twidth: 95%;\n\tbackground: #fff;\r\n\tborder: 1px solid #e4e4e4;\r\n\tcolor: #000000;\r\n\tmargin: auto auto;\r\n\tpadding: 20px;\r\n\ttext-align: left; /* IE 5 fix */\n}\n#content {\n\t/* FIX: Make internet explorer wrap correctly */\r\n\twidth: auto !important;\r\n\t\n}\n.menu ul {\n\tcolor: #000000;\n\tfont-weight: bold;\n\ttext-align: right;\r\n\tpadding: 4px;\n}\n.menu ul a:link {\n\tcolor: #000000;\n\ttext-decoration: none;\n}\n.menu ul a:visited {\n\tcolor: #000000;\n\ttext-decoration: none;\n}\n.menu ul a:hover, .menu ul a:active {\n\tcolor: #4874a3;\n\ttext-decoration: none;\n}\n#panel {\n\tbackground: #efefef;\n\tcolor: #000000;\n\tfont-size: 11px;\n\tborder: 1px solid #D4D4D4;\r\n\tpadding: 8px;\n}\ntable {\n\tcolor: #000000;\n\tfont-family: Verdana;\n\tfont-size: 13px;\n}\n.tborder {\n\tbackground: #81A2C4;\n\twidth: 100%;\r\n\tmargin: auto auto;\r\n\tborder: 1px solid #0F5C8E;\n}\n.thead {\n\tbackground: #026CB1 url(images/thead_bg.gif) top left repeat-x;\n\tcolor: #ffffff;\n}\n.thead a:link {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.thead a:visited {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.thead a:hover, .thead a:active {\n\tcolor: #ffffff;\n\ttext-decoration: underline;\n}\n.tcat {\n\tbackground: #ADCBE7;\n\tcolor: #000000;\n\tfont-size: 12px;\n}\n.tcat a:link {\n\tcolor: #000000;\n}\n.tcat a:visited {\n\tcolor: #000000;\n}\n.tcat a:hover, .tcat a:active {\n\tcolor: #000000;\n}\n.trow1 {\n\tbackground: #f5f5f5;\n}\n.trow2 {\n\tbackground: #EFEFEF;\n}\n.trow_shaded {\n\tbackground: #eea8a1;\n}\n.trow_sep {\n\tbackground: #e5e5e5;\n\tcolor: #000;\n\tfont-size: 12px;\n\tfont-weight: bold;\n}\n.tfoot {\n\tbackground: #026CB1 url(images/thead_bg.gif) top left repeat-x;\n\tcolor: #ffffff;\n}\n.tfoot a:link {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.tfoot a:visited {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.tfoot a:hover, .tfoot a:active {\n\tcolor: #ffffff;\n\ttext-decoration: underline;\n}\n.bottommenu {\n\tbackground: #efefef;\n\tcolor: #000000;\n\tborder: 1px solid #4874a3;\r\n\tpadding: 6px;\n}\n.navigation {\n\tcolor: #000000;\n\tfont-size: 13px;\n\tfont-weight: bold;\n}\n.navigation a:link {\n\ttext-decoration: none;\n}\n.navigation a:visited {\n\ttext-decoration: none;\n}\n.navigation a:hover, .navigation a:active {\n\ttext-decoration: none;\n}\n.navigation .active {\n\tcolor: #000000;\n\tfont-size: small;\n\tfont-weight: bold;\n}\n.smalltext {\n\tfont-size: 11px;\n}\n.largetext {\n\tfont-size: 16px;\n\tfont-weight: bold;\n}\ninput.textbox {\n\tbackground: #ffffff;\n\tcolor: #000000;\n\tborder: 1px solid #0f5c8e;\n\tpadding: 1px;\n}\ntextarea {\n\tbackground: #ffffff;\n\tcolor: #000000;\n\tborder: 1px solid #0f5c8e;\n\tpadding: 2px;\r\n\tfont-family: Verdana;\r\n\tline-height: 1.4;\r\n\tfont-size: 13px;\n}\nselect {\n\tbackground: #ffffff;\n\tborder: 1px solid #0f5c8e;\n}\n.editor {\n\tbackground: #f1f1f1;\n\tborder: 1px solid #ccc;\n}\n.editor_control_bar {\n\tbackground: #fff;\n\tborder: 1px solid #0f5c8e;\n}\n.toolbar_normal {\n\tbackground: #f0f0f0;\n\tborder: 1px solid #f0f0f0;\n}\n.toolbar_hover {\n\tbackground: #c1d2ee;\n\tborder: 1px solid #5296f7;\n}\n.toolbar_clicked {\n\tbackground: #e1F2fe;\n\tborder: 1px solid #5296f7;\n}\n.autocomplete {\n\tbackground: #fff;\n\tborder: 1px solid #000;\n\tcolor: black;\n}\n.autocomplete_selected {\n\tbackground: #adcee7;\n\tcolor: #000;\n}\n.popup_menu {\n\tbackground: #ccc;\n\tborder: 1px solid #000;\n}\n.popup_menu .popup_item {\n\tbackground: #fff;\n\tcolor: #000;\n}\n.popup_menu .popup_item:hover {\n\tbackground: #C7DBEE;\n\tcolor: #000;\n}\n.trow_reputation_positive {\n\tbackground: #ccffcc;\n}\n.trow_reputation_negative {\n\tbackground: #ffcccc;\n}\n.reputation_positive {\n\tcolor: green;\n}\n.reputation_neutral {\n\tcolor: #444;\n}\n.reputation_negative {\n\tcolor: red;\n}\n\n/* Additional CSS (Master) */\nimg {\r\n\tborder: none;\r\n}\r\n\r\n.clear {\r\n\tclear: both;\r\n}\r\n\r\n.hidden {\r\n\tdisplay: none;\r\n\tfloat: none;\r\n\twidth: 1%;\r\n}\r\n\r\n.float_left {\r\n\tfloat: left;\r\n}\r\n\r\n.float_right {\r\n\tfloat: right;\r\n}\r\n\r\n.menu ul {\r\n\tlist-style: none;\r\n\tmargin: 0;\r\n}\r\n\r\n.menu li {\r\n\tdisplay: inline;\r\n\tpadding-left: 5px;\r\n}\r\n\r\n.menu img {\r\n\tpadding-right: 5px;\r\n\tvertical-align: top;\r\n}\r\n\r\n#panel .links {\r\n\tmargin: 0;\r\n\tfloat: right;\r\n}\r\n\r\n.expcolimage {\r\n\tfloat: right;\r\n\twidth: auto;\r\n\tvertical-align: middle;\r\n}\r\n\r\nimg.attachment {\r\n\tborder: 1px solid #E9E5D7;\r\n\tpadding: 2px;\r\n}\r\n\r\n.pagenav {\r\n\tfont-weight: bold;\r\n}\r\n\r\n.pagenavbit {\r\n\tpadding-left: 3px;\r\n}\r\n\r\n.pagenavbit a {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.pagenavcurrent {\r\n\tfont-weight: bold;\r\n\tpadding-left: 3px;\r\n}\r\n\r\nhr {\r\n\tbackground-color: #000000;\r\n\tcolor: #000000;\r\n\theight: 1px;\r\n\tborder: 0px;\r\n}\r\n\r\n#copyright {\r\n\tfont: 11px Verdana, Arial, Sans-Serif;\r\n\tmargin: 0;\r\n\tpadding: 10px 0 0 0;\r\n}\r\n\r\n#debug {\r\n\tfloat: right;\r\n\ttext-align: right;\r\n\tmargin-top: 0;\r\n}\r\n\r\n.quote_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.quote_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n}\r\n\r\n.code_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.code_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n\tfont-family: Monaco, Consolas, Courier, monospace;\r\n\tfont-size: 12px;\r\n}\r\n.usercpnav {\r\n\tlist-style: inside;\r\n\tpadding: 0;\r\n\tmargin: 0;\r\n}\r\n\r\n.usercpnav li {\r\n\tpadding: 1px;\r\n\tfont-size:11px\r\n}\r\n\r\n.usercpnav .pmfolders {\r\n\t/* PM folders on the UCP Nav menu */\r\n}\r\n\r\n.subforumicon {\r\n\tborder: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.separator {\r\n\tmargin: 5px;\r\n\tpadding: 0;\r\n\theight: 0px;\r\n\tfont-size: 1px;\r\n\tlist-style-type: none;\r\n}\r\n\r\nform {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n}\r\n\r\n.popup_menu .popup_item_container {\r\n\tmargin: 1px;\r\n\ttext-align: left;\r\n}\r\n\r\n.popup_menu .popup_item {\r\n\tdisplay: block;\r\n\tpadding: 3px;\r\n\ttext-decoration: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n.popup_menu a.popup_item:hover {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.autocomplete {\r\n\ttext-align: left;\r\n}','a:40:{s:4:\"body\";a:10:{s:10:\"background\";s:7:\"#efefef\";s:5:\"color\";s:4:\"#000\";s:11:\"font-family\";s:7:\"Verdana\";s:9:\"font-size\";s:4:\"13px\";s:10:\"font-style\";N;s:11:\"font-weight\";N;s:5:\"extra\";s:53:\"text-align: center; /* IE 5 fix */\r\nline-height: 1.4;\";s:6:\"a_link\";a:2:{s:5:\"color\";s:7:\"#026CB1\";s:15:\"text-decoration\";s:4:\"none\";}s:9:\"a_visited\";a:2:{s:5:\"color\";s:7:\"#026CB1\";s:15:\"text-decoration\";s:4:\"none\";}s:7:\"a_hover\";a:2:{s:5:\"color\";s:4:\"#000\";s:15:\"text-decoration\";s:9:\"underline\";}}s:9:\"container\";a:2:{s:5:\"width\";s:3:\"95%\";s:5:\"extra\";s:132:\"background: #fff;\r\nborder: 1px solid #e4e4e4;\r\ncolor: #000000;\r\nmargin: auto auto;\r\npadding: 20px;\r\ntext-align: left; /* IE 5 fix */\";}s:7:\"content\";a:1:{s:5:\"extra\";s:75:\"/* FIX: Make internet explorer wrap correctly */\r\nwidth: auto !important;\r\n\";}s:4:\"menu\";a:6:{s:5:\"color\";s:7:\"#000000\";s:11:\"font-weight\";s:4:\"bold\";s:5:\"extra\";s:33:\"text-align: right;\r\npadding: 4px;\";s:6:\"a_link\";a:2:{s:5:\"color\";s:7:\"#000000\";s:15:\"text-decoration\";s:4:\"none\";}s:9:\"a_visited\";a:2:{s:5:\"color\";s:7:\"#000000\";s:15:\"text-decoration\";s:4:\"none\";}s:7:\"a_hover\";a:2:{s:5:\"color\";s:7:\"#4874a3\";s:15:\"text-decoration\";s:4:\"none\";}}s:5:\"panel\";a:4:{s:10:\"background\";s:7:\"#efefef\";s:5:\"color\";s:7:\"#000000\";s:9:\"font-size\";s:4:\"11px\";s:5:\"extra\";s:41:\"border: 1px solid #D4D4D4;\r\npadding: 8px;\";}s:5:\"table\";a:3:{s:5:\"color\";s:7:\"#000000\";s:11:\"font-family\";s:7:\"Verdana\";s:9:\"font-size\";s:4:\"13px\";}s:7:\"tborder\";a:2:{s:10:\"background\";s:7:\"#81A2C4\";s:5:\"extra\";s:60:\"width: 100%;\r\nmargin: auto auto;\r\nborder: 1px solid #0F5C8E;\";}s:5:\"thead\";a:5:{s:10:\"background\";s:50:\"#026CB1 url(images/thead_bg.gif) top left repeat-x\";s:5:\"color\";s:7:\"#ffffff\";s:6:\"a_link\";a:2:{s:5:\"color\";s:7:\"#ffffff\";s:15:\"text-decoration\";s:4:\"none\";}s:9:\"a_visited\";a:2:{s:5:\"color\";s:7:\"#ffffff\";s:15:\"text-decoration\";s:4:\"none\";}s:7:\"a_hover\";a:2:{s:5:\"color\";s:7:\"#ffffff\";s:15:\"text-decoration\";s:9:\"underline\";}}s:4:\"tcat\";a:6:{s:10:\"background\";s:7:\"#ADCBE7\";s:5:\"color\";s:7:\"#000000\";s:9:\"font-size\";s:4:\"12px\";s:6:\"a_link\";a:1:{s:5:\"color\";s:7:\"#000000\";}s:9:\"a_visited\";a:1:{s:5:\"color\";s:7:\"#000000\";}s:7:\"a_hover\";a:1:{s:5:\"color\";s:7:\"#000000\";}}s:5:\"trow1\";a:1:{s:10:\"background\";s:7:\"#f5f5f5\";}s:5:\"trow2\";a:1:{s:10:\"background\";s:7:\"#EFEFEF\";}s:11:\"trow_shaded\";a:1:{s:10:\"background\";s:7:\"#eea8a1\";}s:8:\"trow_sep\";a:4:{s:10:\"background\";s:7:\"#e5e5e5\";s:5:\"color\";s:4:\"#000\";s:9:\"font-size\";s:4:\"12px\";s:11:\"font-weight\";s:4:\"bold\";}s:5:\"tfoot\";a:5:{s:10:\"background\";s:50:\"#026CB1 url(images/thead_bg.gif) top left repeat-x\";s:5:\"color\";s:7:\"#ffffff\";s:6:\"a_link\";a:2:{s:5:\"color\";s:7:\"#ffffff\";s:15:\"text-decoration\";s:4:\"none\";}s:9:\"a_visited\";a:2:{s:5:\"color\";s:7:\"#ffffff\";s:15:\"text-decoration\";s:4:\"none\";}s:7:\"a_hover\";a:2:{s:5:\"color\";s:7:\"#ffffff\";s:15:\"text-decoration\";s:9:\"underline\";}}s:10:\"bottommenu\";a:3:{s:10:\"background\";s:7:\"#efefef\";s:5:\"color\";s:7:\"#000000\";s:5:\"extra\";s:41:\"border: 1px solid #4874a3;\r\npadding: 6px;\";}s:10:\"navigation\";a:7:{s:5:\"color\";s:7:\"#000000\";s:11:\"font-family\";N;s:9:\"font-size\";s:4:\"13px\";s:11:\"font-weight\";s:4:\"bold\";s:6:\"a_link\";a:1:{s:15:\"text-decoration\";s:4:\"none\";}s:9:\"a_visited\";a:1:{s:15:\"text-decoration\";s:4:\"none\";}s:7:\"a_hover\";a:1:{s:15:\"text-decoration\";s:4:\"none\";}}s:17:\"navigation_active\";a:4:{s:5:\"color\";s:7:\"#000000\";s:11:\"font-family\";N;s:9:\"font-size\";s:5:\"small\";s:11:\"font-weight\";s:4:\"bold\";}s:9:\"smalltext\";a:2:{s:11:\"font-family\";N;s:9:\"font-size\";s:4:\"11px\";}s:9:\"largetext\";a:3:{s:11:\"font-family\";N;s:9:\"font-size\";s:4:\"16px\";s:11:\"font-weight\";s:4:\"bold\";}s:7:\"textbox\";a:4:{s:10:\"background\";s:7:\"#ffffff\";s:5:\"color\";s:7:\"#000000\";s:6:\"border\";s:17:\"1px solid #0f5c8e\";s:5:\"extra\";s:13:\"padding: 1px;\";}s:8:\"textarea\";a:4:{s:10:\"background\";s:7:\"#ffffff\";s:5:\"color\";s:7:\"#000000\";s:6:\"border\";s:17:\"1px solid #0f5c8e\";s:5:\"extra\";s:73:\"padding: 2px;\r\nfont-family: Verdana;\r\nline-height: 1.4;\r\nfont-size: 13px;\";}s:5:\"radio\";a:2:{s:10:\"background\";N;s:6:\"border\";N;}s:8:\"checkbox\";a:2:{s:10:\"background\";N;s:6:\"border\";N;}s:6:\"select\";a:2:{s:10:\"background\";s:7:\"#ffffff\";s:6:\"border\";s:17:\"1px solid #0f5c8e\";}s:6:\"button\";a:4:{s:10:\"background\";N;s:5:\"color\";N;s:6:\"border\";N;s:5:\"extra\";N;}s:6:\"editor\";a:2:{s:10:\"background\";s:7:\"#f1f1f1\";s:6:\"border\";s:14:\"1px solid #ccc\";}s:18:\"editor_control_bar\";a:2:{s:10:\"background\";s:4:\"#fff\";s:6:\"border\";s:17:\"1px solid #0f5c8e\";}s:14:\"toolbar_normal\";a:2:{s:10:\"background\";s:7:\"#f0f0f0\";s:6:\"border\";s:17:\"1px solid #f0f0f0\";}s:13:\"toolbar_hover\";a:2:{s:10:\"background\";s:7:\"#c1d2ee\";s:6:\"border\";s:17:\"1px solid #5296f7\";}s:15:\"toolbar_clicked\";a:2:{s:10:\"background\";s:7:\"#e1F2fe\";s:6:\"border\";s:17:\"1px solid #5296f7\";}s:12:\"autocomplete\";a:3:{s:10:\"background\";s:4:\"#fff\";s:6:\"border\";s:14:\"1px solid #000\";s:5:\"color\";s:5:\"black\";}s:21:\"autocomplete_selected\";a:2:{s:10:\"background\";s:7:\"#adcee7\";s:5:\"color\";s:4:\"#000\";}s:10:\"popup_menu\";a:2:{s:10:\"background\";s:4:\"#ccc\";s:6:\"border\";s:14:\"1px solid #000\";}s:10:\"popup_item\";a:2:{s:10:\"background\";s:4:\"#fff\";s:5:\"color\";s:4:\"#000\";}s:18:\"popup_item_hovered\";a:2:{s:10:\"background\";s:7:\"#C7DBEE\";s:5:\"color\";s:4:\"#000\";}s:24:\"trow_reputation_positive\";a:1:{s:10:\"background\";s:7:\"#ccffcc\";}s:24:\"trow_reputation_negative\";a:1:{s:10:\"background\";s:7:\"#ffcccc\";}s:19:\"reputation_positive\";a:1:{s:5:\"color\";s:5:\"green\";}s:18:\"reputation_neutral\";a:1:{s:5:\"color\";s:4:\"#444\";}s:19:\"reputation_negative\";a:1:{s:5:\"color\";s:3:\"red\";}}','a:6:{s:11:\"templateset\";i:1;s:6:\"imgdir\";s:6:\"images\";s:4:\"logo\";s:15:\"images/logo.gif\";s:10:\"tablespace\";s:1:\"4\";s:11:\"borderwidth\";s:1:\"1\";s:8:\"extracss\";s:2383:\"img {\r\n\tborder: none;\r\n}\r\n\r\n.clear {\r\n\tclear: both;\r\n}\r\n\r\n.hidden {\r\n\tdisplay: none;\r\n\tfloat: none;\r\n\twidth: 1%;\r\n}\r\n\r\n.float_left {\r\n\tfloat: left;\r\n}\r\n\r\n.float_right {\r\n\tfloat: right;\r\n}\r\n\r\n.menu ul {\r\n\tlist-style: none;\r\n\tmargin: 0;\r\n}\r\n\r\n.menu li {\r\n\tdisplay: inline;\r\n\tpadding-left: 5px;\r\n}\r\n\r\n.menu img {\r\n\tpadding-right: 5px;\r\n\tvertical-align: top;\r\n}\r\n\r\n#panel .links {\r\n\tmargin: 0;\r\n\tfloat: right;\r\n}\r\n\r\n.expcolimage {\r\n\tfloat: right;\r\n\twidth: auto;\r\n\tvertical-align: middle;\r\n}\r\n\r\nimg.attachment {\r\n\tborder: 1px solid #E9E5D7;\r\n\tpadding: 2px;\r\n}\r\n\r\n.pagenav {\r\n\tfont-weight: bold;\r\n}\r\n\r\n.pagenavbit {\r\n\tpadding-left: 3px;\r\n}\r\n\r\n.pagenavbit a {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.pagenavcurrent {\r\n\tfont-weight: bold;\r\n\tpadding-left: 3px;\r\n}\r\n\r\nhr {\r\n\tbackground-color: #000000;\r\n\tcolor: #000000;\r\n\theight: 1px;\r\n\tborder: 0px;\r\n}\r\n\r\n#copyright {\r\n\tfont: 11px Verdana, Arial, Sans-Serif;\r\n\tmargin: 0;\r\n\tpadding: 10px 0 0 0;\r\n}\r\n\r\n#debug {\r\n\tfloat: right;\r\n\ttext-align: right;\r\n\tmargin-top: 0;\r\n}\r\n\r\n.quote_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.quote_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n}\r\n\r\n.code_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.code_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n\tfont-family: Monaco, Consolas, Courier, monospace;\r\n\tfont-size: 12px;\r\n}\r\n.usercpnav {\r\n\tlist-style: inside;\r\n\tpadding: 0;\r\n\tmargin: 0;\r\n}\r\n\r\n.usercpnav li {\r\n\tpadding: 1px;\r\n\tfont-size:11px\r\n}\r\n\r\n.usercpnav .pmfolders {\r\n\t/* PM folders on the UCP Nav menu */\r\n}\r\n\r\n.subforumicon {\r\n\tborder: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.separator {\r\n\tmargin: 5px;\r\n\tpadding: 0;\r\n\theight: 0px;\r\n\tfont-size: 1px;\r\n\tlist-style-type: none;\r\n}\r\n\r\nform {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n}\r\n\r\n.popup_menu .popup_item_container {\r\n\tmargin: 1px;\r\n\ttext-align: left;\r\n}\r\n\r\n.popup_menu .popup_item {\r\n\tdisplay: block;\r\n\tpadding: 3px;\r\n\ttext-decoration: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n.popup_menu a.popup_item:hover {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.autocomplete {\r\n\ttext-align: left;\r\n}\";}','img {\r\n\tborder: none;\r\n}\r\n\r\n.clear {\r\n\tclear: both;\r\n}\r\n\r\n.hidden {\r\n\tdisplay: none;\r\n\tfloat: none;\r\n\twidth: 1%;\r\n}\r\n\r\n.float_left {\r\n\tfloat: left;\r\n}\r\n\r\n.float_right {\r\n\tfloat: right;\r\n}\r\n\r\n.menu ul {\r\n\tlist-style: none;\r\n\tmargin: 0;\r\n}\r\n\r\n.menu li {\r\n\tdisplay: inline;\r\n\tpadding-left: 5px;\r\n}\r\n\r\n.menu img {\r\n\tpadding-right: 5px;\r\n\tvertical-align: top;\r\n}\r\n\r\n#panel .links {\r\n\tmargin: 0;\r\n\tfloat: right;\r\n}\r\n\r\n.expcolimage {\r\n\tfloat: right;\r\n\twidth: auto;\r\n\tvertical-align: middle;\r\n}\r\n\r\nimg.attachment {\r\n\tborder: 1px solid #E9E5D7;\r\n\tpadding: 2px;\r\n}\r\n\r\n.pagenav {\r\n\tfont-weight: bold;\r\n}\r\n\r\n.pagenavbit {\r\n\tpadding-left: 3px;\r\n}\r\n\r\n.pagenavbit a {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.pagenavcurrent {\r\n\tfont-weight: bold;\r\n\tpadding-left: 3px;\r\n}\r\n\r\nhr {\r\n\tbackground-color: #000000;\r\n\tcolor: #000000;\r\n\theight: 1px;\r\n\tborder: 0px;\r\n}\r\n\r\n#copyright {\r\n\tfont: 11px Verdana, Arial, Sans-Serif;\r\n\tmargin: 0;\r\n\tpadding: 10px 0 0 0;\r\n}\r\n\r\n#debug {\r\n\tfloat: right;\r\n\ttext-align: right;\r\n\tmargin-top: 0;\r\n}\r\n\r\n.quote_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.quote_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n}\r\n\r\n.code_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.code_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n\tfont-family: Monaco, Consolas, Courier, monospace;\r\n\tfont-size: 12px;\r\n}\r\n.usercpnav {\r\n\tlist-style: inside;\r\n\tpadding: 0;\r\n\tmargin: 0;\r\n}\r\n\r\n.usercpnav li {\r\n\tpadding: 1px;\r\n\tfont-size:11px\r\n}\r\n\r\n.usercpnav .pmfolders {\r\n\t/* PM folders on the UCP Nav menu */\r\n}\r\n\r\n.subforumicon {\r\n\tborder: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.separator {\r\n\tmargin: 5px;\r\n\tpadding: 0;\r\n\theight: 0px;\r\n\tfont-size: 1px;\r\n\tlist-style-type: none;\r\n}\r\n\r\nform {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n}\r\n\r\n.popup_menu .popup_item_container {\r\n\tmargin: 1px;\r\n\ttext-align: left;\r\n}\r\n\r\n.popup_menu .popup_item {\r\n\tdisplay: block;\r\n\tpadding: 3px;\r\n\ttext-decoration: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n.popup_menu a.popup_item:hover {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.autocomplete {\r\n\ttext-align: left;\r\n}','',0),
  (2,'MyBB Default',1,1,'body {\n\tbackground: #efefef;\n\tcolor: #000;\n\tfont-family: Verdana;\n\tfont-size: 13px;\n\ttext-align: center; /* IE 5 fix */\r\n\tline-height: 1.4;\n}\na:link {\n\tcolor: #026CB1;\n\ttext-decoration: none;\n}\na:visited {\n\tcolor: #026CB1;\n\ttext-decoration: none;\n}\na:hover, a:active {\n\tcolor: #000;\n\ttext-decoration: underline;\n}\n#container {\n\twidth: 95%;\n\tbackground: #fff;\r\n\tborder: 1px solid #e4e4e4;\r\n\tcolor: #000000;\r\n\tmargin: auto auto;\r\n\tpadding: 20px;\r\n\ttext-align: left; /* IE 5 fix */\n}\n#content {\n\t/* FIX: Make internet explorer wrap correctly */\r\n\twidth: auto !important;\r\n\t\n}\n.menu ul {\n\tcolor: #000000;\n\tfont-weight: bold;\n\ttext-align: right;\r\n\tpadding: 4px;\n}\n.menu ul a:link {\n\tcolor: #000000;\n\ttext-decoration: none;\n}\n.menu ul a:visited {\n\tcolor: #000000;\n\ttext-decoration: none;\n}\n.menu ul a:hover, .menu ul a:active {\n\tcolor: #4874a3;\n\ttext-decoration: none;\n}\n#panel {\n\tbackground: #efefef;\n\tcolor: #000000;\n\tfont-size: 11px;\n\tborder: 1px solid #D4D4D4;\r\n\tpadding: 8px;\n}\ntable {\n\tcolor: #000000;\n\tfont-family: Verdana;\n\tfont-size: 13px;\n}\n.tborder {\n\tbackground: #81A2C4;\n\twidth: 100%;\r\n\tmargin: auto auto;\r\n\tborder: 1px solid #0F5C8E;\n}\n.thead {\n\tbackground: #026CB1 url(images/thead_bg.gif) top left repeat-x;\n\tcolor: #ffffff;\n}\n.thead a:link {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.thead a:visited {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.thead a:hover, .thead a:active {\n\tcolor: #ffffff;\n\ttext-decoration: underline;\n}\n.tcat {\n\tbackground: #ADCBE7;\n\tcolor: #000000;\n\tfont-size: 12px;\n}\n.tcat a:link {\n\tcolor: #000000;\n}\n.tcat a:visited {\n\tcolor: #000000;\n}\n.tcat a:hover, .tcat a:active {\n\tcolor: #000000;\n}\n.trow1 {\n\tbackground: #f5f5f5;\n}\n.trow2 {\n\tbackground: #EFEFEF;\n}\n.trow_shaded {\n\tbackground: #eea8a1;\n}\n.trow_sep {\n\tbackground: #e5e5e5;\n\tcolor: #000;\n\tfont-size: 12px;\n\tfont-weight: bold;\n}\n.tfoot {\n\tbackground: #026CB1 url(images/thead_bg.gif) top left repeat-x;\n\tcolor: #ffffff;\n}\n.tfoot a:link {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.tfoot a:visited {\n\tcolor: #ffffff;\n\ttext-decoration: none;\n}\n.tfoot a:hover, .tfoot a:active {\n\tcolor: #ffffff;\n\ttext-decoration: underline;\n}\n.bottommenu {\n\tbackground: #efefef;\n\tcolor: #000000;\n\tborder: 1px solid #4874a3;\r\n\tpadding: 6px;\n}\n.navigation {\n\tcolor: #000000;\n\tfont-size: 13px;\n\tfont-weight: bold;\n}\n.navigation a:link {\n\ttext-decoration: none;\n}\n.navigation a:visited {\n\ttext-decoration: none;\n}\n.navigation a:hover, .navigation a:active {\n\ttext-decoration: none;\n}\n.navigation .active {\n\tcolor: #000000;\n\tfont-size: small;\n\tfont-weight: bold;\n}\n.smalltext {\n\tfont-size: 11px;\n}\n.largetext {\n\tfont-size: 16px;\n\tfont-weight: bold;\n}\ninput.textbox {\n\tbackground: #ffffff;\n\tcolor: #000000;\n\tborder: 1px solid #0f5c8e;\n\tpadding: 1px;\n}\ntextarea {\n\tbackground: #ffffff;\n\tcolor: #000000;\n\tborder: 1px solid #0f5c8e;\n\tpadding: 2px;\r\n\tfont-family: Verdana;\r\n\tline-height: 1.4;\r\n\tfont-size: 13px;\n}\nselect {\n\tbackground: #ffffff;\n\tborder: 1px solid #0f5c8e;\n}\n.editor {\n\tbackground: #f1f1f1;\n\tborder: 1px solid #ccc;\n}\n.editor_control_bar {\n\tbackground: #fff;\n\tborder: 1px solid #0f5c8e;\n}\n.toolbar_normal {\n\tbackground: #f0f0f0;\n\tborder: 1px solid #f0f0f0;\n}\n.toolbar_hover {\n\tbackground: #c1d2ee;\n\tborder: 1px solid #5296f7;\n}\n.toolbar_clicked {\n\tbackground: #e1F2fe;\n\tborder: 1px solid #5296f7;\n}\n.autocomplete {\n\tbackground: #fff;\n\tborder: 1px solid #000;\n\tcolor: black;\n}\n.autocomplete_selected {\n\tbackground: #adcee7;\n\tcolor: #000;\n}\n.popup_menu {\n\tbackground: #ccc;\n\tborder: 1px solid #000;\n}\n.popup_menu .popup_item {\n\tbackground: #fff;\n\tcolor: #000;\n}\n.popup_menu .popup_item:hover {\n\tbackground: #C7DBEE;\n\tcolor: #000;\n}\n.trow_reputation_positive {\n\tbackground: #ccffcc;\n}\n.trow_reputation_negative {\n\tbackground: #ffcccc;\n}\n.reputation_positive {\n\tcolor: green;\n}\n.reputation_neutral {\n\tcolor: #444;\n}\n.reputation_negative {\n\tcolor: red;\n}\n\n/* Additional CSS (Master) */\nimg {\r\n\tborder: none;\r\n}\r\n\r\n.clear {\r\n\tclear: both;\r\n}\r\n\r\n.hidden {\r\n\tdisplay: none;\r\n\tfloat: none;\r\n\twidth: 1%;\r\n}\r\n\r\n.float_left {\r\n\tfloat: left;\r\n}\r\n\r\n.float_right {\r\n\tfloat: right;\r\n}\r\n\r\n.menu ul {\r\n\tlist-style: none;\r\n\tmargin: 0;\r\n}\r\n\r\n.menu li {\r\n\tdisplay: inline;\r\n\tpadding-left: 5px;\r\n}\r\n\r\n.menu img {\r\n\tpadding-right: 5px;\r\n\tvertical-align: top;\r\n}\r\n\r\n#panel .links {\r\n\tmargin: 0;\r\n\tfloat: right;\r\n}\r\n\r\n.expcolimage {\r\n\tfloat: right;\r\n\twidth: auto;\r\n\tvertical-align: middle;\r\n}\r\n\r\nimg.attachment {\r\n\tborder: 1px solid #E9E5D7;\r\n\tpadding: 2px;\r\n}\r\n\r\n.pagenav {\r\n\tfont-weight: bold;\r\n}\r\n\r\n.pagenavbit {\r\n\tpadding-left: 3px;\r\n}\r\n\r\n.pagenavbit a {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.pagenavcurrent {\r\n\tfont-weight: bold;\r\n\tpadding-left: 3px;\r\n}\r\n\r\nhr {\r\n\tbackground-color: #000000;\r\n\tcolor: #000000;\r\n\theight: 1px;\r\n\tborder: 0px;\r\n}\r\n\r\n#copyright {\r\n\tfont: 11px Verdana, Arial, Sans-Serif;\r\n\tmargin: 0;\r\n\tpadding: 10px 0 0 0;\r\n}\r\n\r\n#debug {\r\n\tfloat: right;\r\n\ttext-align: right;\r\n\tmargin-top: 0;\r\n}\r\n\r\n.quote_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.quote_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n}\r\n\r\n.code_header {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-bottom: 0;\r\n\tcolor: #000;\r\n\tfont-weight: bold;\r\n\tmargin: 8px auto 0 auto;\r\n\tpadding: 4px;\r\n}\r\n\r\n.code_body {\r\n\tbackground: #fff;\r\n\tborder: 1px dashed #000;\r\n\tborder-top: 0;\r\n\tcolor: #000;\r\n\tpadding: 4px;\r\n\tmargin: 0 auto 8px auto;\r\n\tfont-family: Monaco, Consolas, Courier, monospace;\r\n\tfont-size: 12px;\r\n}\r\n.usercpnav {\r\n\tlist-style: inside;\r\n\tpadding: 0;\r\n\tmargin: 0;\r\n}\r\n\r\n.usercpnav li {\r\n\tpadding: 1px;\r\n\tfont-size:11px\r\n}\r\n\r\n.usercpnav .pmfolders {\r\n\t/* PM folders on the UCP Nav menu */\r\n}\r\n\r\n.subforumicon {\r\n\tborder: 0;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.separator {\r\n\tmargin: 5px;\r\n\tpadding: 0;\r\n\theight: 0px;\r\n\tfont-size: 1px;\r\n\tlist-style-type: none;\r\n}\r\n\r\nform {\r\n\tmargin: 0;\r\n\tpadding: 0;\r\n}\r\n\r\n.popup_menu .popup_item_container {\r\n\tmargin: 1px;\r\n\ttext-align: left;\r\n}\r\n\r\n.popup_menu .popup_item {\r\n\tdisplay: block;\r\n\tpadding: 3px;\r\n\ttext-decoration: none;\r\n\twhite-space: nowrap;\r\n}\r\n\r\n.popup_menu a.popup_item:hover {\r\n\ttext-decoration: none;\r\n}\r\n\r\n.autocomplete {\r\n\ttext-align: left;\r\n}\n/* Additional CSS (Custom) */\nimg {\n\tborder: none;\n}\n\n.clear {\n\tclear: both;\n}\n\n.hidden {\n\tdisplay: none;\n\tfloat: none;\n\twidth: 1%;\n}\n\n.float_left {\n\tfloat: left;\n}\n\n.float_right {\n\tfloat: right;\n}\n\n.menu ul {\n\tlist-style: none;\n\tmargin: 0;\n}\n\n.menu li {\n\tdisplay: inline;\n\tpadding-left: 5px;\n}\n\n.menu img {\n\tpadding-right: 5px;\n\tvertical-align: top;\n}\n\n#panel .links {\n\tmargin: 0;\n\tfloat: right;\n}\n\n.expcolimage {\n\tfloat: right;\n\twidth: auto;\n\tvertical-align: middle;\n}\n\nimg.attachment {\n\tborder: 1px solid #E9E5D7;\n\tpadding: 2px;\n}\n\n.pagenav {\n\tfont-weight: bold;\n}\n\n.pagenavbit {\n\tpadding-left: 3px;\n}\n\n.pagenavbit a {\n\ttext-decoration: none;\n}\n\n.pagenavcurrent {\n\tfont-weight: bold;\n\tpadding-left: 3px;\n}\n\nhr {\n\tbackground-color: #000000;\n\tcolor: #000000;\n\theight: 1px;\n\tborder: 0px;\n}\n\n#copyright {\n\tfont: 11px Verdana, Arial, Sans-Serif;\n\tmargin: 0;\n\tpadding: 10px 0 0 0;\n}\n\n#debug {\n\tfloat: right;\n\ttext-align: right;\n\tmargin-top: 0;\n}\n\n.quote_header {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-bottom: 0;\n\tcolor: #000;\n\tfont-weight: bold;\n\tmargin: 8px auto 0 auto;\n\tpadding: 4px;\n}\n\n.quote_body {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-top: 0;\n\tcolor: #000;\n\tpadding: 4px;\n\tmargin: 0 auto 8px auto;\n}\n\n.code_header {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-bottom: 0;\n\tcolor: #000;\n\tfont-weight: bold;\n\tmargin: 8px auto 0 auto;\n\tpadding: 4px;\n}\n\n.code_body {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-top: 0;\n\tcolor: #000;\n\tpadding: 4px;\n\tmargin: 0 auto 8px auto;\n\tfont-family: Monaco, Consolas, Courier, monospace;\n\tfont-size: 12px;\n}\n.usercpnav {\n\tlist-style: inside;\n\tpadding: 0;\n\tmargin: 0;\n}\n\n.usercpnav li {\n\tpadding: 1px;\n\tfont-size:11px\n}\n\n.usercpnav .pmfolders {\n\t/* PM folders on the UCP Nav menu */\n}\n\n.subforumicon {\n\tborder: 0;\n\tvertical-align: middle;\n}\n\n.separator {\n\tmargin: 5px;\n\tpadding: 0;\n\theight: 0px;\n\tfont-size: 1px;\n\tlist-style-type: none;\n}\n\nform {\n\tmargin: 0;\n\tpadding: 0;\n}\n\n.popup_menu .popup_item_container {\n\tmargin: 1px;\n\ttext-align: left;\n}\n\n.popup_menu .popup_item {\n\tdisplay: block;\n\tpadding: 3px;\n\ttext-decoration: none;\n\twhite-space: nowrap;\n}\n\n.popup_menu a.popup_item:hover {\n\ttext-decoration: none;\n}\n\n.autocomplete {\n\ttext-align: left;\n}','a:0:{}','a:7:{s:11:\"templateset\";i:1;s:6:\"imgdir\";s:6:\"images\";s:4:\"logo\";s:15:\"images/logo.gif\";s:10:\"tablespace\";s:1:\"4\";s:11:\"borderwidth\";s:1:\"1\";s:8:\"extracss\";s:2204:\"img {\n\tborder: none;\n}\n\n.clear {\n\tclear: both;\n}\n\n.hidden {\n\tdisplay: none;\n\tfloat: none;\n\twidth: 1%;\n}\n\n.float_left {\n\tfloat: left;\n}\n\n.float_right {\n\tfloat: right;\n}\n\n.menu ul {\n\tlist-style: none;\n\tmargin: 0;\n}\n\n.menu li {\n\tdisplay: inline;\n\tpadding-left: 5px;\n}\n\n.menu img {\n\tpadding-right: 5px;\n\tvertical-align: top;\n}\n\n#panel .links {\n\tmargin: 0;\n\tfloat: right;\n}\n\n.expcolimage {\n\tfloat: right;\n\twidth: auto;\n\tvertical-align: middle;\n}\n\nimg.attachment {\n\tborder: 1px solid #E9E5D7;\n\tpadding: 2px;\n}\n\n.pagenav {\n\tfont-weight: bold;\n}\n\n.pagenavbit {\n\tpadding-left: 3px;\n}\n\n.pagenavbit a {\n\ttext-decoration: none;\n}\n\n.pagenavcurrent {\n\tfont-weight: bold;\n\tpadding-left: 3px;\n}\n\nhr {\n\tbackground-color: #000000;\n\tcolor: #000000;\n\theight: 1px;\n\tborder: 0px;\n}\n\n#copyright {\n\tfont: 11px Verdana, Arial, Sans-Serif;\n\tmargin: 0;\n\tpadding: 10px 0 0 0;\n}\n\n#debug {\n\tfloat: right;\n\ttext-align: right;\n\tmargin-top: 0;\n}\n\n.quote_header {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-bottom: 0;\n\tcolor: #000;\n\tfont-weight: bold;\n\tmargin: 8px auto 0 auto;\n\tpadding: 4px;\n}\n\n.quote_body {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-top: 0;\n\tcolor: #000;\n\tpadding: 4px;\n\tmargin: 0 auto 8px auto;\n}\n\n.code_header {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-bottom: 0;\n\tcolor: #000;\n\tfont-weight: bold;\n\tmargin: 8px auto 0 auto;\n\tpadding: 4px;\n}\n\n.code_body {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-top: 0;\n\tcolor: #000;\n\tpadding: 4px;\n\tmargin: 0 auto 8px auto;\n\tfont-family: Monaco, Consolas, Courier, monospace;\n\tfont-size: 12px;\n}\n.usercpnav {\n\tlist-style: inside;\n\tpadding: 0;\n\tmargin: 0;\n}\n\n.usercpnav li {\n\tpadding: 1px;\n\tfont-size:11px\n}\n\n.usercpnav .pmfolders {\n\t/* PM folders on the UCP Nav menu */\n}\n\n.subforumicon {\n\tborder: 0;\n\tvertical-align: middle;\n}\n\n.separator {\n\tmargin: 5px;\n\tpadding: 0;\n\theight: 0px;\n\tfont-size: 1px;\n\tlist-style-type: none;\n}\n\nform {\n\tmargin: 0;\n\tpadding: 0;\n}\n\n.popup_menu .popup_item_container {\n\tmargin: 1px;\n\ttext-align: left;\n}\n\n.popup_menu .popup_item {\n\tdisplay: block;\n\tpadding: 3px;\n\ttext-decoration: none;\n\twhite-space: nowrap;\n}\n\n.popup_menu a.popup_item:hover {\n\ttext-decoration: none;\n}\n\n.autocomplete {\n\ttext-align: left;\n}\";s:9:\"inherited\";a:5:{s:11:\"templateset\";s:1:\"1\";s:6:\"imgdir\";s:1:\"1\";s:4:\"logo\";s:1:\"1\";s:10:\"tablespace\";s:1:\"1\";s:11:\"borderwidth\";s:1:\"1\";}}','img {\n\tborder: none;\n}\n\n.clear {\n\tclear: both;\n}\n\n.hidden {\n\tdisplay: none;\n\tfloat: none;\n\twidth: 1%;\n}\n\n.float_left {\n\tfloat: left;\n}\n\n.float_right {\n\tfloat: right;\n}\n\n.menu ul {\n\tlist-style: none;\n\tmargin: 0;\n}\n\n.menu li {\n\tdisplay: inline;\n\tpadding-left: 5px;\n}\n\n.menu img {\n\tpadding-right: 5px;\n\tvertical-align: top;\n}\n\n#panel .links {\n\tmargin: 0;\n\tfloat: right;\n}\n\n.expcolimage {\n\tfloat: right;\n\twidth: auto;\n\tvertical-align: middle;\n}\n\nimg.attachment {\n\tborder: 1px solid #E9E5D7;\n\tpadding: 2px;\n}\n\n.pagenav {\n\tfont-weight: bold;\n}\n\n.pagenavbit {\n\tpadding-left: 3px;\n}\n\n.pagenavbit a {\n\ttext-decoration: none;\n}\n\n.pagenavcurrent {\n\tfont-weight: bold;\n\tpadding-left: 3px;\n}\n\nhr {\n\tbackground-color: #000000;\n\tcolor: #000000;\n\theight: 1px;\n\tborder: 0px;\n}\n\n#copyright {\n\tfont: 11px Verdana, Arial, Sans-Serif;\n\tmargin: 0;\n\tpadding: 10px 0 0 0;\n}\n\n#debug {\n\tfloat: right;\n\ttext-align: right;\n\tmargin-top: 0;\n}\n\n.quote_header {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-bottom: 0;\n\tcolor: #000;\n\tfont-weight: bold;\n\tmargin: 8px auto 0 auto;\n\tpadding: 4px;\n}\n\n.quote_body {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-top: 0;\n\tcolor: #000;\n\tpadding: 4px;\n\tmargin: 0 auto 8px auto;\n}\n\n.code_header {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-bottom: 0;\n\tcolor: #000;\n\tfont-weight: bold;\n\tmargin: 8px auto 0 auto;\n\tpadding: 4px;\n}\n\n.code_body {\n\tbackground: #fff;\n\tborder: 1px dashed #000;\n\tborder-top: 0;\n\tcolor: #000;\n\tpadding: 4px;\n\tmargin: 0 auto 8px auto;\n\tfont-family: Monaco, Consolas, Courier, monospace;\n\tfont-size: 12px;\n}\n.usercpnav {\n\tlist-style: inside;\n\tpadding: 0;\n\tmargin: 0;\n}\n\n.usercpnav li {\n\tpadding: 1px;\n\tfont-size:11px\n}\n\n.usercpnav .pmfolders {\n\t/* PM folders on the UCP Nav menu */\n}\n\n.subforumicon {\n\tborder: 0;\n\tvertical-align: middle;\n}\n\n.separator {\n\tmargin: 5px;\n\tpadding: 0;\n\theight: 0px;\n\tfont-size: 1px;\n\tlist-style-type: none;\n}\n\nform {\n\tmargin: 0;\n\tpadding: 0;\n}\n\n.popup_menu .popup_item_container {\n\tmargin: 1px;\n\ttext-align: left;\n}\n\n.popup_menu .popup_item {\n\tdisplay: block;\n\tpadding: 3px;\n\ttext-decoration: none;\n\twhite-space: nowrap;\n}\n\n.popup_menu a.popup_item:hover {\n\ttext-decoration: none;\n}\n\n.autocomplete {\n\ttext-align: left;\n}','',0);

COMMIT;

#
# Data for the `mybb_upgrade_data` table  (LIMIT 0,100)
#

INSERT INTO `mybb_upgrade_data` (`title`, `contents`) VALUES
  ('startscript','s:1:\"9\";'),
  ('upgradedetail','a:3:{s:20:\"revert_all_templates\";i:0;s:17:\"revert_all_themes\";i:0;s:19:\"revert_all_settings\";i:0;}'),
  ('currentscript','s:12:\"upgrade9.php\";');

COMMIT;

#
# Data for the `mybb_usergroups` table  (LIMIT 0,100)
#

INSERT INTO `mybb_usergroups` (`gid`, `type`, `title`, `description`, `namestyle`, `usertitle`, `stars`, `starimage`, `image`, `disporder`, `isbannedgroup`, `canview`, `canviewthreads`, `canviewprofiles`, `candlattachments`, `canpostthreads`, `canpostreplys`, `canpostattachments`, `canratethreads`, `caneditposts`, `candeleteposts`, `candeletethreads`, `caneditattachments`, `canpostpolls`, `canvotepolls`, `canusepms`, `cansendpms`, `cantrackpms`, `candenypmreceipts`, `pmquota`, `cansendemail`, `canviewmemberlist`, `canviewcalendar`, `canaddpublicevents`, `canaddprivateevents`, `canviewonline`, `canviewwolinvis`, `canviewonlineips`, `cancp`, `issupermod`, `cansearch`, `canusercp`, `canuploadavatars`, `canratemembers`, `canchangename`, `showforumteam`, `usereputationsystem`, `cangivereputations`, `reputationpower`, `maxreputationsday`, `candisplaygroup`, `attachquota`, `cancustomtitle`) VALUES
  (1,1,'Unregistered / Not Logged In','','{username}','Unregistered',0,'','',0,'no','yes','yes','yes','no','no','no','no','no','yes','yes','yes','yes','no','no','no','no','no','no',0,'no','yes','yes','yes','no','yes','no','no','no','no','yes','no','no','','no','','no','no',0,0,'yes',0,''),
  (2,1,'Registered','','{username}','',0,'images/star.gif','',0,'no','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes',0,'yes','yes','yes','yes','yes','yes','no','no','no','no','yes','yes','yes','','no','no','yes','yes',1,5,'yes',0,''),
  (3,1,'Super Moderators','These users can moderate any forum.','<span style=\"color: #CC00CC;\"><strong>{username}</strong></span>','Super Moderator',6,'images/star.gif','',0,'no','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes',0,'yes','yes','yes','yes','yes','yes','yes','yes','no','yes','yes','yes','yes','','yes','yes','yes','yes',1,10,'yes',0,''),
  (4,1,'Administrators','The group all administrators belong to.','<span style=\"color: green;\"><strong><em>{username}</em></strong></span>','Administrator',7,'images/star.gif','',0,'no','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes',0,'yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','','yes','yes','yes','yes',2,0,'yes',0,'yes'),
  (5,1,'Awaiting Activation','Users that have not activated their account by email yet.','{username}','Account not Activated',0,'images/star.gif','',0,'no','yes','yes','yes','no','no','no','no','no','no','no','no','no','no','no','no','no','no','no',20,'no','yes','yes','no','no','yes','no','no','no','no','yes','yes','no','','no','','no','no',0,0,'yes',0,''),
  (6,1,'Moderators','These users moderate specific forums.','<span style=\"color: #CC00CC;\"><strong>{username}</strong></span>','Moderator',5,'images/star.gif','',0,'no','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes',0,'yes','yes','yes','no','no','yes','no','no','no','no','yes','yes','yes','','yes','yes','yes','yes',1,10,'yes',0,''),
  (7,1,'Banned','This is for people who are a pain in the neck!','<s>{username}</s>','Banned',0,'images/star.gif','',0,'yes','no','no','no','no','no','no','no','no','no','no','no','no','no','no','yes','no','no','no',0,'no','no','no','no','no','no','no','no','no','no','no','no','no','','no','no','no','no',0,0,'yes',0,'');

COMMIT;

#
# Data for the `mybb_usertitles` table  (LIMIT 0,100)
#

INSERT INTO `mybb_usertitles` (`utid`, `posts`, `title`, `stars`, `starimage`) VALUES
  (1,0,'Newbie',1,''),
  (2,1,'Junior Member',2,''),
  (3,50,'Member',3,''),
  (4,250,'Senior Member',4,''),
  (5,750,'Posting Freak',5,'');

COMMIT;

#
# Data for the `orbital_blocks` table  (LIMIT 0,100)
#

INSERT INTO `orbital_blocks` (`bid`, `bkey`, `title`, `content`, `bposition`, `weight`, `active`, `time`, `blockfile`, `view`, `expire`, `action`, `which`) VALUES
  (1,'','�������������','<table border=\"0\"><tr>\r\n<td class=\"block\"><a href=\"admincp.php\">�������</a></td>\r\n</tr><tr>\r\n<td class=\"block\"><a href=\"users.php\">������ �������������</a></td>\r\n</tr><tr>\r\n<td class=\"block\"><a href=\"staffmess.php\">�������� ��</a></td>\r\n</tr><tr>\r\n<td class=\"block\"><a href=\"ipcheck.php\">�������� �� IP</a></td>\r\n</tr><tr>\r\n<td class=\"block\"><a href=\"logout.php\">�����</a></td>\r\n</tr></table>','r',1,1,'','',2,'0','d','all'),
  (8,'','����������','','c',7,1,'','block-stats.php',0,'0','d','ihome,'),
  (9,'','������, ������� ����� ���������','','c',6,1,'','block-helpseed.php',0,'0','d','ihome,'),
  (10,'','����������� � ��������','<p align=\"jsutify\">������������� ������� ����� - ������������ ������� � ����������, ������� ������ � ���� ����� �������� � ������������ ��� ��������������, ��������� ��� ����� ����� ���������� �����. ������������ ������ �������� ����� - �� ���������� ��� �� �����, �� ���� �������� ������ � ���������, ����������� ���� ������� ��� ����� ����� � 1, � �� ������ ������ ������������ � ���������. � �� ��������, ��� �� ��� �� �������������! (�����)</p>','c',1,1,'','',0,'0','d','rules,'),
  (2,'','�������','','c',3,1,'','block-news.php',0,'0','d','ihome,'),
  (3,'','������������','','r',2,1,'','block-online.php',0,'0','d','all'),
  (4,'','�����','','r',3,1,'','block-search.php',0,'0','d','all'),
  (5,'','�����','','c',4,1,'','block-polls.php',1,'0','d','ihome,'),
  (6,'','������','','c',5,1,'','block-releases.php',0,'0','d','ihome,'),
  (7,'','�����','','c',2,1,'','block-forum.php',0,'0','d','ihome,'),
  (11,'','�������� �������','','c',8,1,'','block-server_load.php',0,'0','d','ihome,');

COMMIT;

#
# Data for the `stylesheets` table  (LIMIT 0,100)
#

INSERT INTO `stylesheets` (`id`, `uri`, `name`) VALUES
  (1,'TBDev','TBDev'),
  (2,'Gray','Gray');

COMMIT;