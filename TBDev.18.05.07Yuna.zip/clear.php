<?

require "include/bittorrent.php";
dbconn();

stdhead();

stdfoot();

?>