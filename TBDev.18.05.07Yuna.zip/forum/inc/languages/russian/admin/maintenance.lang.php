<?php
$l['nav_cache_manager'] = "Cache Manager";
$l['nav_view_cache'] = "View Cache Contents";

$l['cache_manager'] = "Cache Manager";
$l['name'] = "Cache Name";
$l['size'] = "Size";
$l['options'] = "Options";
$l['view_contents'] = "View Contents";
$l['refresh_cache'] = "Rebuild Cache";
$l['nocache_update'] = "The cache was not able to be rebuilt because the required updated function was not found.";
$l['cache_updated'] = "The cache has been rebuilt. You will now be taken to the cache manager.";
$l['cache_empty'] = "Cache is empty.";

$l['rebuildstats'] = "Recount Statistics";
$l['rebuildstats_notice'] = "When you run the recount statistics function, your forum statistics will be recounted and updated on the forum index and statistics page.";
$l['stats_rebuilt'] = "The forum statistics have successfully been rebuilt.";

$l['proceed'] = "Proceed";
?>