<?php
$l['nav_plugins'] = "Plugin Manager";

$l['plugin_manager'] = "Plugin Manager";
$l['plugin'] = "Plugin";
$l['version'] = "Version";
$l['author'] = "Author";
$l['action'] = "Action";
$l['deactivate_plugin'] = "Deactivate";
$l['activate_plugin'] = "Activate";
$l['plugin_activated'] = "The plugin has successfully been activated.";
$l['plugin_deactivated'] = "The plugin has successfully been deactivated.";
$l['no_plugins'] = "You do not currently have any plugins installed that exist in your plugins directory.";
?>