<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: customhelpdocs.lang.php 1398 2006-04-27 07:42:09Z chris $
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Document name";
 * $l['d{hid}_desc'] = "Document description";
 * $l['d{hid}_document'] = "Document text";
 */
?>