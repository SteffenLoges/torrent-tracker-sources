<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: customhelpsections.lang.php 1398 2006-04-27 07:42:09Z chris $
 */

/*
 * Custom Help Section Translation Format
 *
 * // Help Section {sid}
 * $l['s{sid}_name'] = "Section name";
 * $l['s{sid}_desc'] = "Section description";
 */
?>