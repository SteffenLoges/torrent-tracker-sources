<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: syndication.lang.php 1399 2006-04-27 08:05:49Z chris $
 */

$l['all_forums'] = "All Forums";
$l['forum'] = "Forum:";
$l['posted_by'] = "Posted By:";
$l['on'] = "on";

?>