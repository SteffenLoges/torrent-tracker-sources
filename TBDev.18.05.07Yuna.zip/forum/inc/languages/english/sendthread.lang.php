<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: sendthread.lang.php 1398 2006-04-27 07:42:09Z chris $
 */

$l['nav_sendthread'] = "Send Thread to Friend";

$l['send_thread'] = "Send To Friend";
$l['recipient'] = "Recipient:";
$l['recipient_note'] = "Enter your friend's email address here.";
$l['subject'] = "Subject:";
$l['message'] = "Message:";
$l['your_name'] = "Your Name:";
$l['name_note'] = "You must provide a name so that the recipient knows who you are.";
$l['your_email'] = "Your Email Address:";
$l['email_note'] = "You must provide a valid email address so the recipient can reply.";

?>