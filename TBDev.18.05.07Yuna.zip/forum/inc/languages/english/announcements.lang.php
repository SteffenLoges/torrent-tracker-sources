<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: announcements.lang.php 1650 2006-06-22 00:32:13Z dennis $
 */

$l['nav_announcements'] = "Forum Announcement";
$l['announcements'] = "Announcement";
$l['forum_announcement'] = "Forum Announcement: {1}";
$l['error_invalidannouncement'] = "The announcement specified is invalid.";
?>