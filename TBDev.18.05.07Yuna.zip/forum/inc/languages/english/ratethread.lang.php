<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id$
 */

$l['redirect_threadrated'] = "Thank you, the thread has been rated successfully. You will now be returned to the thread.";

$l['error_invalidrating'] = "You have selected an invalid rating for this thread. Please go back and try again.";
$l['error_alreadyratedthread'] = "Sorry, but you have already rated this thread.";
?>