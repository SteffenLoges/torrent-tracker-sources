<?php 
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: printthread.lang.php 1651 2006-06-22 00:33:19Z Tikitiki $
 */

$l['forum'] = "Forum:";
$l['printable_version'] = "Printable Version";
$l['thread'] = "Thread:";
?>