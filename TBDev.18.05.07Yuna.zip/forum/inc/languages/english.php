<?php
/**
 * MyBB 1.2 English Language Pack
 * Copyright © 2006 MyBB Group, All Rights Reserved
 * 
 * $Id: english.php 3030 2007-04-26 00:19:47Z Tikitiki $
 */

// The friendly name of the language
$langinfo['name'] = "English (American)";

// The author of the language
$langinfo['author'] = "MyBulletinBoard";

// The language authors website
$langinfo['website'] = "http://www.mybboard.net/";

// Compatible version of MyBB
$langinfo['version'] = "127";

// Sets if the translation includes the Admin CP (1 = yes, 0 = no)
$langinfo['admin'] = 1;

// Sets if the language is RTL (Right to Left) (1 = yes, 0 = no)
$langinfo['rtl'] = 0;

// Sets the lang in the <html> on all pages
$langinfo['htmllang'] = "ru";

// Sets the character set, blank uses the default.
$langinfo['charset'] = "windows-1251";
?>