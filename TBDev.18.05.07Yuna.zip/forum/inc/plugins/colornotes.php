<?php
// Tell MyBB when to run the hooks
// $plugins->add_hook("hook name", "function name");
$plugins->add_hook("parse_message", "colornotes_run");

// The information that shows up on the plugin manager
// Note that the name of the function before _info, _activate, _deactivate must be the same as the filename before the extension.
function colornotes_info()
{
	return array(
		"name"			=> "Color Notes (CSS extras)",
		"description"	=> "CSS extras [alert], [info], [warn] tags. Ex: [alert]texthere[/alert].",
		"website"		=> "http://www.ivgeo.uni.cc/",
		"author"		=> "IV Geo",
		"authorsite"	=> "http://www.ivgeo.uni.cc/",
		"version"		=> "1.01b",
	);
}

// This function runs when the plugin is activated.
function colornotes_activate()
{
}

// This function runs when the plugin is deactivated.
function colornotes_deactivate()
{
}

// This is the function that is run when the hook is called.
// It must match the function name you placed when you called add_hook.
// You are not just limited to 1 hook per page.  You can add as many as you want.
function colornotes_run ($message)
{
    $colornotes = array(
        //Text Apperence
        '#\[alert\](.*?)\[/alert]#si' => '<span style="background: #FFF7C0 url(images/color/exc.png) center no-repeat;background-position: 15px 50%;text-align: left;margin-left: 15px;padding: 5px 20px 5px 45px;border-top: 2px solid #F7D229;border-bottom: 2px solid #F7D229;line-height: 35px;">\\1</span>',
        '#\[info\](.*?)\[/info]#si' => '<span style="background: #F8FAFC url(images/color/info.png) center no-repeat;background-position: 15px 50%;text-align: left;margin-left: 15px;padding: 5px 20px 5px 45px;border-top: 2px solid #B5D4FE;border-bottom: 2px solid #B5D4FE;line-height: 35px;">\\1</span>',
        '#\[warn\](.*?)\[/warn]#si' => '<span style="background: #FBEEF1 url(images/color/warn.png) center no-repeat;background-position: 15px 50%;text-align: left;margin-left: 15px;padding: 5px 20px 5px 45px;border-top: 2px solid #FEABB9;border-bottom: 2px solid #FEABB9;line-height: 35px;">\\1</span>',
    );
	$message = preg_replace(array_keys($colornotes), array_values($colornotes), $message);
    return $message;
}

// End of plugin.
?>
