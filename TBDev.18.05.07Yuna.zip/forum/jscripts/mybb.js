if (navigator.userAgent.indexOf("Safari") > 0)
{
  isSafari = true;
  isMoz = false;
  isIE = false;
}
else if (navigator.product == "Gecko")
{
  isSafari = false;
  isMoz = true;
  isIE = false;
}
else
{
  isSafari = false;
  isMoz = false;
  isIE = true;
}

function attachListener(element, type, listener)
{
	if(element.addEventListener)
	{
		element.addEventListener(type, listener, false);
	}
	else
	{
		element.attachEvent("on"+type, listener, false);
	}
}

function removeListener(element, type, listener)
{
	if(element.removeEventListener)
	{
		element.removeEventListener(type, listener, false);
	}
	else
	{
		element.detachEvent("on"+type, listener);
	}
}

function eventElement(event)
{
  if(isMoz)
  {
    return event.currentTarget;
  }
  else
  {
    return event.srcElement;
  }
}

function offsetTop(element)
{
	var top = element.offsetTop;
	while(element = element.offsetParent)
	{
		top += element.offsetTop;
	}
	return top;
}

function offsetLeft(element)
{
	var left = element.offsetLeft;
	while((element = element.offsetParent))
	{
		left += element.offsetLeft;
	}
	return left;
}
