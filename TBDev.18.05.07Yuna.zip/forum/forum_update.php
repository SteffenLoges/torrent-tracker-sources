<?php
/* Update Forum cache if needed. */

define("IN_MYBB", 1);
error_reporting(E_ALL & ~E_NOTICE);

require_once "./global.php";

$update = new datacache;
$update->updateversion();
$update->updateattachtypes();
$update->updatesmilies();
$update->updateposticons();
$update->updatebadwords();
$update->updateusergroups();
$update->updateforumpermissions();
$update->buildforumpermissions();
$update->updatestats();
$update->updatemoderators();
$update->updateforums();
$update->updateusertitles();
$update->updatereportedposts();
$update->updatemycode();
$update->updatemailqueue();
$update->updateupdate_check();

echo "Forum cache cleaned...";

//header('Location: index.php');
?>