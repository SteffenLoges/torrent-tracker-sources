<?php
require ('include/bittorrent.php');
gzip();
dbconn();
loggedinorreturn();
if (my_getuid($CURUSER['id'])) {
	if (isset($_GET['showthread']) AND is_valid_id($_GET['showthread']))
		header('Location: '.$DEFAULTBASEURL.'/forum/showthread.php?tid='.intval($_GET['showthread']));
	else
		header('Location: '.$DEFAULTBASEURL.'/forum');
} else
	header('Location: '.$DEFAULTBASEURL.'/forumaccount.php');
?>