<?

/*
// +--------------------------------------------------------------------------+
// | Project:    TBDevYSE - TBDev Yuna Scatari Edition                        |
// +--------------------------------------------------------------------------+
// | This file is part of TBDevYSE. TBDevYSE is based on TBDev,               |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | TBDevYSE is free software; you can redistribute it and/or modify         |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | TBDevYSE is distributed in the hope that it will be useful,              |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with TBDevYSE; if not, write to the Free Software Foundation,      |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/

require_once("include/bittorrent.php");


$id = 0 + $_GET["id"];
$md5 = $_GET["secret"];

if (!$id)
	httperr();

dbconn();


$res = sql_query("SELECT passhash, editsecret, status FROM users WHERE id = $id");
$row = mysql_fetch_array($res);

if (!$row)
	httperr();

if ($row["status"] != "pending") {
	header("Location: ok.php?type=confirmed");
	exit();
}

$sec = hash_pad($row["editsecret"]);
if ($md5 != md5($sec))
	httperr();

sql_query("UPDATE users SET status='confirmed', editsecret='' WHERE id=$id AND status='pending'");

if (!mysql_affected_rows())
	httperr();

sql_query("UPDATE ".TABLE_PREFIX."users SET usergroup='".MYBB_USER."' WHERE uid='".sqlesc($id)."'");
sql_query("DELETE FROM ".TABLE_PREFIX."awaitingactivation WHERE uid='".sqlesc($id)."' AND type='r' OR type='e'");

logincookie($id, $row["passhash"]);

//SET FORUM COOKIE.
$mybb = sql_query("SELECT uid, loginkey FROM ".TABLE_PREFIX."users WHERE uid = ".sqlesc($id));
if (mysql_num_rows($mybb) >= 1) {
	$mybbuser = mysql_fetch_array($mybb);
	my_setcookiee("mybbuser", $mybbuser['uid']."_".$mybbuser['loginkey'], null, true);
}

header("Location: ok.php?type=confirm");

?>