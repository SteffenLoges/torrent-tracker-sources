<?php
require "include/bittorrent.php";
gzip();
dbconn();
loggedinorreturn();
$res = sql_query("SELECT uid,username FROM ".TABLE_PREFIX."users WHERE uid = ".sqlesc($CURUSER['id'])." AND username = ".sqlesc($CURUSER['username']));
if (mysql_num_rows($res) >= 1) {
	stderr('Error', 'You have already an account on '.$SITENAME.' Community. Click <a href='.$DEFAULTBASEURL.'/forum/>here</a> to login.',false);
}else{
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['password'] != '') {
		if ($CURUSER['passhash'] != md5($CURUSER['secret'] . $_POST['password'] . $CURUSER['secret']))
			stderr('Error','You have entered a wrong password!');
		else {
			$id = (int) $CURUSER['id'];
			$wantusername = $CURUSER['username'];
			$wantpassword = $_POST['password'];
			$email = $CURUSER['email'];
			$timezone = '+1';
			$enabledst = 'yes';
			$ip = getip ();			
			define ('ACTIVATION', 'no');
			define ('REGISTER', true);
			define ('TYPE', 'add_forum_user');
			include_once("include/community.php");
			stderr('Done','Your forum account has been created. Click <a href='.$DEFAULTBASEURL.'/forum/>here</a> to login.',false);
		}
	}else{
		stdhead('Forum Registration');
		echo '<table border=0 cellspacing=0 cellpadding=5 width=100%>';
		echo '<div class=error><b>We are currently using a new forum system therefore you need to register. Please use form below to register.</b></div>';
		echo '<form method=post action=forumaccount.php>';
		tr('Forum User Name:', htmlspecialchars($CURUSER['username']), 1);
		tr('Forum User ID:', (int)$CURUSER['id'], 1);
		tr('Forum User Email:', htmlspecialchars($CURUSER['email']), 1);
		tr('Your Password:', '<input type=password name=password id=specialboxn>', 1);		
		tr('Make Forum User', '<input type=submit value=\'Click here to register at forums\' class=btn>', 1);
		echo '</table>';
		stdfoot();
	}
}	
?>