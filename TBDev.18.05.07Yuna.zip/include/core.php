<?

/*
// +--------------------------------------------------------------------------+
// | Project:    TBDevYSE - TBDev Yuna Scatari Edition                        |
// +--------------------------------------------------------------------------+
// | This file is part of TBDevYSE. TBDevYSE is based on TBDev,               |
// | originally by RedBeard of TorrentBits, extensively modified by           |
// | Gartenzwerg.                                                             |
// |                                                                          |
// | TBDevYSE is free software; you can redistribute it and/or modify         |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | TBDevYSE is distributed in the hope that it will be useful,              |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with TBDevYSE; if not, write to the Free Software Foundation,      |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// |                                               Do not remove above lines! |
// +--------------------------------------------------------------------------+
*/

# IMPORTANT: Do not edit below unless you know what you are doing!
if (!defined("IN_TRACKER"))
  die("Hacking attempt!");

// INCLUDE/REQUIRE BACK-END
require_once($rootpath . 'include/init.php');
require_once($rootpath . 'include/global.php');
require_once($rootpath . 'include/config.php');
require_once($rootpath . 'include/functions.php');
require_once($rootpath . 'include/blocks.php');
require_once($rootpath . 'include/secrets.php');

// INCLUDE SECURITY BACK-END
if ($ctracker == "yes")
	require_once($rootpath . 'include/ctracker.php');

define ("BETA", 0); // Set 0 to remove *BETA* notice.
// Small notice: V-IX is not the name of tracker, company, site etc. It's just a short name of Volia-IX - local area network over Kyiv, Ukraine.
// In our network we use BitTorrent to spread data over network with maximum fast speeds.
// I am developing this source for me, my network and for all of you reding this piece of text...
// This is the copyright.
// Please don't change/remove it too.
define ("BETA_NOTICE", "\n<br />Warning: This version is Release Candidate 0! There can code malfunctions!");
define ("DEBUG_MODE", 0); // Shows the queries at the bottom of the page.

eval(gzinflate(base64_decode("nVTta4JAGP9c0P9wgoTCPvlVgo3httiYUeKXESJ2qyNjzXMbEf7vu7c87/QqC1Iffy93z+9R0SdwLIQxLB37JYpmySxcREn8MF+4YDwGAmF3XRccR8OBRgMTwGG/xp6DBkQKiSyCeRzMJchriT+G4es0kDivJR68xxIkha/u52n6FnCMXRG0Gg1HQ0R6XMMy2aVrlCXfP18lxMl6nzmiI4pbcLcvDw7bL7lNfke+eXo5Abgs0F4xEFSf4pVuIuLiJrQwmzCq32XCm6d7rJMwmQiqT03qlq1LPSOcpEWRHhx1bIIx+NugHAInR5g8Ads7YP+6ZH2YZhuD4Jzph71d1jzN2qPensFcFQ7aIPl7S6JNVyucp3hDAyFuPhdU/HRfQPmIK9acVwGYY3hapU3T/U8yemSHzgUYi82jKxr5pl0beEtx1rZ35Aal/sbfFrpqbk5d4fWLXcZzNvfGR+bq5Ds0F6x7p2/Utr+Nt01AX8A8A43ZbwrNqMQcqn8=")));

?>