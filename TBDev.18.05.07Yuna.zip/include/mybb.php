<?

# IMPORTANT: Do not edit below unless you know what you are doing!
if(!defined('IN_TRACKER'))
  die('Hacking attempt!');

//----------------------------------
//---- MYBB Integration v.0.3 by xam
//----------------------------------
function get_avatar($userid,$show=false) {
	global $CURUSER,$rootpath,$pic_base_url;
	unset ($avatar);
	$res = sql_query("SELECT avatar, avatardimensions, avatartype FROM ".TABLE_PREFIX."users WHERE uid = ".sqlesc($userid));
	if (mysql_num_rows($res) >= 1) {
	$post = mysql_fetch_array($res);

	if($post['avatar']) {
			$post['avatar'] = htmlspecialchars_uni2($post['avatar']);
			$avatar_dimensions = explode("|", $post['avatardimensions']);
			if($avatar_dimensions[0] && $avatar_dimensions[1]) {
				$avatar_width_height = "width=\"{$avatar_dimensions[0]}\" height=\"{$avatar_dimensions[1]}\"";
			}
			if($post['avatartype'] == "remote" || strstr(strtolower($post["avatar"]), "http://") !== false)
				$avatar = "<img src=\"$post[avatar]\" alt=\"\" $avatar_width_height />";
			else
				$avatar = "<img src=\"forum/".str_replace("./", "", $post["avatar"])."\" $avatar_width_height />";
		} else
			$avatar = "<img src=\"".$rootpath.$pic_base_url."default_avatar.gif\" border=\"0\">";
	} else
		$avatar = "<img src=\"".$rootpath.$pic_base_url."default_avatar.gif\" border=\"0\">";
	if ($CURUSER["avatars"] == "yes" OR $show)
		return $avatar;
	else
		return;
}

function my_setcookiee($name, $value="", $expires="", $httponly=false) {
	global $mybbuser;
	if($expires == -1) {
		$expires = 0;
	}
	else if($expires == "" || $expires == null) {
		if(isset($mybbuser['remember']) && $mybbuser['remember'] == "no") {
			$expires = 0;
		} else {
			$expires = TIMENOW + (60*60*24*365); // Make the cookie expire in a years time
		}
	} else {
		$expires = TIMENOW + intval($expires);
	}
	
	// Versions of PHP prior to 5.2 do not support HttpOnly cookies and IE is buggy when specifying a blank domain so set the cookie manually
	$cookie = "Set-Cookie: {$name}=".urlencode($value);
	if($expires > 0) {
		$cookie .= "; expires=".gmdate('D, d-M-Y H:i:s \\G\\M\\T', $expires);
	}
	
	if($httponly == true) {
		$cookie .= "; HttpOnly";
	}
	header($cookie, false);
}

function my_unsetcookiee($name) {
	$expires = -3600;
	my_setcookiee($name, "", $expires);
}

function my_getuid($id) {
	$res = sql_query("SELECT uid FROM ".TABLE_PREFIX."users WHERE uid = ".sqlesc($id));
	if (mysql_num_rows($res) >= 1)
		return true;
	else
		return false;
}

//----------------------------------
//---- MYBB Integration v.0.3 by xam
//----------------------------------

?>