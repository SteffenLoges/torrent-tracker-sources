<?

$mysql_host = "localhost";
$mysql_user = "root";
$mysql_pass = "";
$mysql_db = "x264";
$mysql_charset = "cp1251";

?>