<?php
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}

$content .= "<table width=\"100%\" cellpadding=\"2\" cellspacing=\"0\"><tr><td align=\"center\" class=\"colhead\">����</td><td align=\"center\" class=\"colhead\">�����</td><td align=\"center\" class=\"colhead\">����������</td><td align=\"center\" class=\"colhead\">�������</td><td align=\"center\" class=\"colhead\">����. ���������</td></tr>";

$topics = sql_query("SELECT * FROM ".TABLE_PREFIX."threads WHERE visible = 1 ORDER BY lastpost DESC LIMIT 5");
while ($topic = mysql_fetch_array($topics)) {
	$topic_id = $topic["tid"];
	$forum_id = $topic["fid"];
	$topic_subject = $topic["subject"];
	$topic_starter_uid = $topic["uid"];
	$topic_starter_name = $topic["username"];
	$topic_started = $topic["dateline"];
	$topic_firstpost = $topic["firstpost"];
	$lastpost = $topic["lastpost"];
	$lastposter = $topic["lastposter"];
	$lastposter_uid = $topic["lastposteruid"];
	$topic_views = $topic["views"];
	$topic_replies = $topic["replies"];
	$content .= "<tr><td><a href=\"forums.php?showthread=$topic_id\">$topic_subject</a></td><td align=\"center\"><a href=\"forum/member.php?action=profile&uid=$topic_starter_uid\" title=\"".get_date_time($topic_started)."\">$topic_starter_name</a></td><td align=\"center\">$topic_views</td><td align=\"center\">$topic_replies</td><td align=\"center\"><a href=\"forum/showthread.php?action=lastpost&tid=$topic_id\" title=\"".get_date_time($lastpost)."\">$lastposter</a></td></tr>";
}

$content .= "</table>";

$blocktitle = "����� <font size=\"-2\"> - [<a class=\"altlink\" href=\"forum/search.php?action=getnew\">����� ���������</a>]</font> <font size=\"-2\">[<a class=\"altlink\" href=\"forum/search.php?action=getdaily\">��������� �� �������</a>]</font>";

?>