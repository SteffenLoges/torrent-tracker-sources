<?

require "include/bittorrent.php";
dbconn();

$REL_TPL->stdhead();

$REL_TPL->stdfoot();

?>