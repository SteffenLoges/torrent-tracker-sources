tinyMCE.addI18n('en.reltemplates_dlg',{
title:"Insert release template"
});