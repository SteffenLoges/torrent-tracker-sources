tinyMCE.addI18n('ru.stamps',{
stamps_desc: "\u0428\u0442\u0430\u043c\u043f\u044b"
});