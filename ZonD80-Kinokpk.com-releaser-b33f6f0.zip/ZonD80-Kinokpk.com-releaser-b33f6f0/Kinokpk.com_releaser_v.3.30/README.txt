Kinokpk.com relaser 3.30
------------------
Русский:

Установка:

Загрузите файлы из папки "upload" в корень вашего сайта
Перейдите на адрес http://yoursite.com/install и следуйте инструкциям установщика

Обновление с 3.00:

Загрузите файлы из папки "upload" в корень вашего сайта
Перейдите на адрес http://yoursite.com/update и следуйте инструкциям обновителя
------------------
English:

Installation:

Upload all contents from "upload" folder to the root of your site
Go to http://yoursite.com/install and follow instructions

Update from 3.00:

Upload all contents from "upload" folder to the root of your site
Go to http://yoursite.com/update and follow instructions