<?
begin_block("Donate");
echo "<BR><BR><CENTER>This would need to contain your donation code, or something. maybe even a paypal link</CENTER><BR><BR>";
end_block();
?>
