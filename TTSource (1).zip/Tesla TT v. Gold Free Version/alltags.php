<?php

require_once("include/bittorrent.php");

dbconn();
loggedinorreturn();
//stdhead('������� ������ �����');

 //////////// Array /////////////// 
        $arrSystem['Windows 3.1'] = "Windows 3.1"; 
        $arrSystem['Win16'] = "Windows 3.1"; 
        $arrSystem['16bit'] = "Windows 3.1"; 
        $arrSystem['Win32'] = "Windows 95"; 
        $arrSystem['32bit'] = "Windows 95"; 
        $arrSystem['Win 32'] = "Windows 95"; 
        $arrSystem['Win95'] = "Windows 95"; 
        $arrSystem['Windows 95/NT'] = "Windows 95"; 
        $arrSystem['Win98'] = "Windows 98"; 
        
        $arrSystem['WinVI']= "Windows Vista";
         
		          
        $arrSystem['Windows 95'] = "Windows 95"; 
        $arrSystem['Windows 98'] = "Windows 98"; 
        $arrSystem['Windows NT 5.0'] = "Windows 2000"; 
        $arrSystem['Windows NT 5.1'] = "Windows XP"; 
        $arrSystem['Windows NT 5.2'] = "Windows Server 2003 ";

        $arrSystem['Windows NT 6.0'] = "Windows Vista"; 
        $arrSystem['Windows NT 6.1'] = "Windows Seven"; 


        $arrSystem['Windows NT'] = "Windows NT"; 
        $arrSystem['WinNT'] = "Windows NT"; 
        $arrSystem['Windows ME'] = "Windows ME"; 
        $arrSystem['Windows CE'] = "Windows CE"; 
        $arrSystem['Windows'] = "Windows 95"; 
        $arrSystem['Mac_68000'] = "Macintosh"; 
        $arrSystem['Mac_PowerPC'] = "Macintosh"; 
        $arrSystem['Mac_68K'] = "Macintosh"; 
        $arrSystem['Mac_PPC'] = "Macintosh"; 
        $arrSystem['Macintosh'] = "Macintosh"; 
        $arrSystem['IRIX'] = "Unix"; 
        $arrSystem['SunOS'] = "Unix"; 
        $arrSystem['AIX'] = "Unix"; 
        $arrSystem['Linux'] = "Unix"; 
        $arrSystem['HP-UX'] = "Unix"; 
        $arrSystem['SCO_SV'] = "Unix"; 
        $arrSystem['FreeBSD'] = "Unix"; 
        $arrSystem['BSD/OS'] = "Unix"; 
        $arrSystem['OS/2'] = "OS/2"; 
        $arrSystem['WebTV/1.0'] = "WebTV/1.0"; 
        $arrSystem['WebTV/1.2'] = "WebTV/1.2"; 
        $arrBrowser['Lynx'] = "Lynx"; 
        $arrBrowser['libwww-perl'] = "Lynx"; 
        $arrBrowser['ia_archiver'] = "���-����"; 
        $arrBrowser['ArchitextSpider'] = "���-����"; 
        $arrBrowser['Lycos_Spider_(T-Rex)'] = "���-����"; 
        $arrBrowser['Scooter'] = "���-����"; 
        $arrBrowser['InfoSeek'] = "���-����"; 
        $arrBrowser['AltaVista'] = "���-����"; 
        $arrBrowser['Eule-Robot'] = "���-����"; 
        $arrBrowser['SwissSearch'] = "���-����"; 
        $arrBrowser['Checkbot'] = "���-����"; 
        $arrBrowser['Crescent Internet ToolPak'] = "���-����"; 
        $arrBrowser['Slurp'] = "���-����"; 
        $arrBrowser['WiseWire-Widow'] = "���-����"; 
        $arrBrowser['NetAttache'] = "���-����"; 
        $arrBrowser['Web21 CustomCrawl'] = "���-����"; 
        $arrBrowser['BTWebClient'] = "BTWebClient (������)"; 
        $arrBrowser['CheckUrl'] = "���-����"; 
        $arrBrowser['LinkLint-checkonly'] = "���-����"; 
        $arrBrowser['Namecrawler'] = "���-����"; 
        $arrBrowser['ZyBorg'] = "���-����"; 
        $arrBrowser['Googlebot'] = "���-����"; 
        $arrBrowser['WebCrawler'] = "���-����"; 
        $arrBrowser['WebCopier'] = "���-����"; 
        $arrBrowser['JBH Agent 2.0'] = "���-����"; 
        ///////////// Array end //////////////


  function getSystem($arrSystem,$userAgent) 
        { 
                $system = 'Other'; 
                foreach($arrSystem as $key => $value) 
                { 
                        if (strpos($userAgent, $key) !== false) 
                        { 
                                $system = $value; 
                                break; 
                        } 
                } 
                return $system; 
        } 
        
function tag_info2() {

//$result = sql_query("SELECT id, name from torrents WHERE added > DATE_SUB(NOW(),INTERVAL 3 DAY) ORDER BY times_completed DESC LIMIT 20") or sqlerr(__FILE__, __LINE__);
$dt = sqlesc(time() - 400);
$result = sql_query("SELECT ip, useragent FROM sessions WHERE time > $dt LIMIT 40") or sqlerr(__FILE__, __LINE__);
$ip = getip();
while($row = mysql_fetch_assoc($result)) {
// suck into array
if ($row['ip']==$ip)
$z="��";
else
$z="��� ��";
$arr[$row['ip']] = $z;
}
//sort array by key
@ksort($arr);

return $arr;
}

function cloud3d() {
//min / max font sizes
$small = 7;
$big = 20;
//get tag info from worker function
$tags = tag_info2();
//amounts
$minimum_count = @min(array_values($tags));
$maximum_count = @max(array_values($tags));
$spread = $maximum_count - $minimum_count;

if($spread == 0) {$spread = 1;}

$cloud_html = '';

$cloud_tags = array();
$i = 0;
if ($tags)
foreach ($tags as $tag => $count) {

$size = $small + ($count - $minimum_count) * ($big - $small) / $spread;

//spew out some html malarky!
$cloud_tags[] = "<a style='font-size:". floor($size) . "px;'>$count :> "
. htmlentities($tag,ENT_QUOTES, "cp1251") . "</a>";
$cloud_links[] = "<br/><a style='font-size:". floor($size) . "px;'>$tag</a><br/>";
$i++;
}
$cloud_links[$i-1].="��� ������� �� ������������ flash!";
$cloud_html[0] = join("", $cloud_tags);
$cloud_html[1] = join("", $cloud_links);


return $cloud_html;
}

function cloud2 ($style = '',$name = '', $color='',$bgcolor='',$width='',$height='',$speed='',$size='') {
  $tagsres = array();
  $tagsres = cloud3d();
  $tags = $tagsres[0];
  $links = $tagsres[1];
if (!$style) $style = '<style type="text/css">
.tag_cloud
{padding: 3px; text-decoration: none;
font-family: verdana; }
.tag_cloud:link { color: #0099FF; text-decoration:none;border:1px transparent solid;}
.tag_cloud:visited { color: #00CCFF; border:1px transparent solid;}
.tag_cloud:hover { color: #0000FF; background: #ddd;border:1px #bbb solid; }
.tag_cloud:active { color: #0000FF; background: #fff; border:1px transparent solid;}
#tag
{
line-height:28px;
font-family:Verdana, Arial, Helvetica, sans-serif;
text-align:justify;
}
</style>';

  $cloud_html = $style.'<div id="wrapper"><p id="tag">
  <script type="text/javascript" src="js/swfobject.js"></script>
<div id="'.($name?$name:"wpcumuluswidgetcontent").'">'.$links.'</div>
<script type="text/javascript">
var rnumber = Math.floor(Math.random()*9999999);
var widget_so = new SWFObject("swf/tagcloud.swf?r="+rnumber, "tagcloudflash", "'.($width?$width:"100%").'", "'.($height?$height:"100%").'", "'.($size?$size:"9").'", "'.($bgcolor?$bgcolor:"#ffffff ").'");
widget_so.addParam("allowScriptAccess", "always");
widget_so.addVariable("tcolor", "'.($color?$color:"0x0054a6").'");
widget_so.addVariable("tspeed", "'.($speed?$speed:"250").'");
widget_so.addVariable("distr", "true");
widget_so.addVariable("mode", "tags");
widget_so.addVariable("tagcloud", "<span>'.$tags.'</span>");
widget_so.write("'.($name?$name:"wpcumuluswidgetcontent").'");
</script></p></div>';
return $cloud_html;
}


///#ffffff  #fafafa


$content = cloud2('',"bigtagsplayer",'','','100%','400','300','');
print $content;
//stdfoot();
?> 