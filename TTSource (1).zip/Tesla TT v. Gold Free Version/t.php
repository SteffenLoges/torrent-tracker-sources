<? require "include/bittorrent.php";
dbconn(false);
stdheadchat("404 Not Found"); ?>
<style type="text/css">
<!--
.style3 {
	font-size: 36px;
	font-family: "Times New Roman", Times, serif;
}
.style4 {
	font-family: "Times New Roman", Times, serif;
	font-size: 16px;
	color: #999999;
}
.style5 {
	font-size: 48px;
	font-family: "Times New Roman", Times, serif;
	color: #006699;
}
.style6 {
	font-size: 28px;
	font-family: "Times New Roman", Times, serif;
	color: #FFFFFF;
}
-->
</style>
</head>

<body>
<p align="center" class="style5">������ ��������</p>
<p align="center" class="style6">������ �����������!</p>

</body>
<? stdfootchat();?>

<?

$ip=getenv("REMOTE_ADDR"); 
$ag=getenv("HTTP_USER_AGENT"); 
$from=getenv("HTTP_REFERER"); 
$host=getenv("REQUEST_URI"); 
$date = date("d.m.y"); 
$time= date("H:i:s"); 

if ($from){
$sf ="cache/404.txt"; 
$fpsf=fopen($sf,"a+"); 

fputs($fpsf,"����:$date ($time) Ip:$ip ($ag) ������:$from ������: $host\n"); 
fclose($fpsf); 
}

?>
