<?

require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();

function bark($msg, $error = true) {
global $tracker_lang;
stdhead(($error ? $tracker_lang['error'] : $tracker_lang['torrent']." ".$tracker_lang['bookmarked']));
   stdmsg(($error ? $tracker_lang['error'] : $tracker_lang['success']), $msg, ($error ? 'error' : 'success'));
stdfoot();
exit;
}

$returnto=getenv("HTTP_REFERER");

$id = (int) $_GET["torrent"];

if (!isset($id))
       bark($tracker_lang['torrent_not_selected']);

$res = sql_query("SELECT name FROM torrents WHERE id = ".sqlesc($id)."") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_array($res);

$go=get_row_count("bookmarks", "WHERE userid = $CURUSER[id] AND torrentid = ".sqlesc($id)."");

if ($go && !$_GET['take'])
{
$link="<a href=\"bookmark.php?torrent=$id&take=delete\">������</a> � ��������?";
}
elseif (!$go && !$_GET['take'])
{
$link="<a href=\"bookmark.php?torrent=$id&take=add\">��������</a> � ��������?";
}

$take = $_GET['take'];

if ($take=="add"){


if ($go > 0)
bark($tracker_lang['torrent']." \"".$arr['name']."\"".$tracker_lang['already_bookmarked']);

sql_query("INSERT INTO bookmarks (userid, torrentid) VALUES ($CURUSER[id], ".sqlesc($id).")") or sqlerr(__FILE__,__LINE__);

if ($returnto)
{
header("Refresh: 3; url=$returnto");
}
else {
header("Refresh: 3; url=details.php?id=$id");
}
bark($tracker_lang['torrent']." \"".$arr['name']."\"".$tracker_lang['bookmarked'],false);

}
elseif ($take=="delete")
{


if ($go)
{
sql_query("DELETE FROM bookmarks WHERE userid = $CURUSER[id] AND torrentid = ".sqlesc($id)."") or sqlerr(__FILE__,__LINE__);
}
//bark($tracker_lang['torrent']." \"".$arr['name']."\"".$tracker_lang['already_bookmarked']);

//sql_query("INSERT INTO bookmarks (userid, torrentid) VALUES ($CURUSER[id], $id)") or sqlerr(__FILE__,__LINE__);

if ($returnto)
{
header("Refresh: 3; url=$returnto");
}
else {
header("Refresh: 3; url=details.php?id=$id");
}
bark($tracker_lang['torrent']." \"".$arr['name']."\" ����� �� ��������",false);
	
}
else

//header("Refresh: 3; url=details.php?id=$id");
bark("������� $link",true);




?>