<?
require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();

if (get_user_class() < UC_MODERATOR)
    stderr("������", "������ ��������.");

$res = sql_query("SELECT COUNT(*) FROM ratings ORDER BY user DESC");
$row = mysql_fetch_array($res);
$count = $row[0];

$pea=120;
list($pagertop, $pagerbottom, $limit) = pager($pea, $count, $_SERVER["PHP_SELF"] ."?");
$res = sql_query("SELECT r.*, t.name, u.username, u.class FROM ratings AS r LEFT JOIN torrents AS t ON t.id = r.torrent LEFT JOIN users AS u ON u.id = r.user ORDER BY user $limit") or sqlerr(__FILE__, __LINE__);
stdheadchat("����� ������");
begin_frame("����� ������ [$count]");
print("<table width=\"100%\">\n");
print($pagertop);
print("<tr>
<td class=\"a\" align=\"center\">#</td>
<td class=\"a\" align=\"center\">�������</td>
<td class=\"a\" align=\"center\">������������</td>
<td class=\"a\" align=\"center\">������</td>
<td class=\"a\" align=\"center\">����</td></tr>\n");
if ($count > 0)
{
    $num = 1;
    while($row = mysql_fetch_array($res))
    {
        if (empty($row['name']))
            $name = "������� ������: " . $row['torrent'] . "";
        else
            $name = "<a href=\"details.php?id=" . $row['torrent'] . "\">" . $row['name'] . "</a>";
        if (empty($row['username']))
            $user = "������: " . $row['user'] . "";
        else
            $user = "<a href=\"userdetails.php?id=" . $row['user'] . "\">" . get_user_class_color($row['class'], $row['username']) . "</a>";
        print("<tr>
		<td>" . ($num < 10 ? "0$num" : $num) . ".</td>
		<td >$name</td>
		<td align=\"center\">$user</td>
		<td align=\"center\"><img src=\"pic/" . $row['rating'] . ".gif\" alt=\"\" /></td>
		<td align=\"center\">" . normaltime($row['added'],true) . "</td></tr>\n");
        $num++;
    }
    print("<tr><td colspan=\"5\">\n");
    print($pagerbottom);
    print("</td></tr>\n");
}
else
{
    print("<tr><td>��� ������.</td></tr>\n");
}
print("</table>\n");
end_frame();
stdfootchat();

?>