<?php
define('IN_ANNOUNCE', true);
require_once('./include/core_announce.php');

dbconn(false);

function hash_where_arr($name, $hash_arr) {
    global $db;
    $new_hash_arr = array();
    for ( $i = 0; $i < sizeof($hash_arr); ++$i ) {
        $new_hash_arr[] = sqlesc(bin2hex(urldecode($hash_arr[$i])));
    }
    return $name . ' IN (' . implode(', ', $new_hash_arr) . ' )';
}

preg_match_all('/info_hash=([^&]*)/i', $_SERVER['QUERY_STRING'], $info_hash_array);
$fields = 'info_hash, name, times_completed AS completed, seeders, leechers';


if (sizeof($info_hash_array[1])) {
    $sql = 'SELECT ' . $fields . ' FROM torrents WHERE ' . hash_where_arr('info_hash', $info_hash_array[1]);
} else {
    $sql = 'SELECT ' . $fields . ' FROM torrents ORDER BY id';
}

if (!($result = mysql_query($sql)) ) {
    err('scrape sql error: '.mysql_error());
}

if ( $row = mysql_fetch_assoc($result) ) {
    $r = 'd' . benc_str('files') . 'd';
        do {
            $r .= '20:' . pack("H*", ($row['info_hash'])) . 'd' .
                      benc_str('complete') . 'i' . $row['seeders'] . 'e' .
                      benc_str('downloaded') . 'i' . $row['completed'] . 'e' .
                      benc_str('incomplete') . 'i' . $row['leechers'] . 'e' .
                      'e';
        }
        while ($row = mysql_fetch_assoc($result));
        $r .= benc_str('flags') . 'd' . benc_str('min_request_interval') . 'i' . $announce_interval . 'ee';
        $r .= 'ee';
}
else {
    err($empty,"������� �� ��������������� �� �������: $info_hash_array (scrape)");
}
mysql_free_result($result);

benc_resp_raw($r);

?> 