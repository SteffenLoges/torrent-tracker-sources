<?php

/**
* Allows users to send email without e-mail server on the localmachine
* @package SMTP
* @author Fredrik Haugbergsmyr <smtp.lib@lagnut.net>
*/

$mechs = array('LOGIN', 'PLAIN', 'CRAM_MD5');

foreach ($mechs as $mech) {
	if (!defined($mech)) {
		define($mech, $mech);
	} elseif (constant($mech) != $mech) {
		trigger_error(sprintf("Constant %s already defined, can't proceed", $mech), E_USER_ERROR);
	}
}


/**
* @version 0.0.1
* @access public
* @todo phpdoc
*/
class sasl
{


	function _hmac_md5($key, $data)
	{
		if (strlen($key) > 64) {
			$key = pack('H32', md5($key));
        	}

		if (strlen($key) < 64) {
			$key = str_pad($key, 64, chr(0));
		}

		$k_ipad = substr($key, 0, 64) ^ str_repeat(chr(0x36), 64);
		$k_opad = substr($key, 0, 64) ^ str_repeat(chr(0x5C), 64);

		$inner = pack('H32', md5($k_ipad . $data));
		$digest = md5($k_opad . $inner);

		return $digest;
	}

	function cram_md5($user, $pass, $challenge)
	{
		var_dump($challenge);
		$chall = base64_decode($challenge);
		var_dump($chall);
		return base64_encode(sprintf('%s %s', $user, $this->_hmac_md5($pass, $chall)));
	}

	function plain($username, $password)
	{
		return base64_encode(sprintf('%c%s%c%s', 0, $username, 0, $password));
	}

	function login($input)
	{
		return base64_encode(sprintf('%s', $input));
	}
}
/**
* @version 0.0.2.2
* @access public
* @todo split messages, attachments
*/
class smtp
{


	/**
	* lagnut-smtp version, send in the headers
	*
	* @var string
	* @access private
	*/
	var $_version = '0.0.2.2';


	/**
	* Turn debugon / off
	*
	* @var bool
	* @access private
	*/
	var $_debug = false;


	/**
	* Serverconnection resource
	*
	* @var resource
	* @access private
	*/
	var $_connection = null;


	/**
	* E-mailheaders
	*
	* @var array headers
	* @access private
	*/
	var $_hdrs = array();


	/**
	* E-mailbody
	*
	* @var string
	* @access private
	*/
	var $_body = '';


	/**
	* Default Content type
	*
	* @var string
	* @access private
	*/
	var $_mime = 'text/plain';


	/**
	* Default Charset
	*
	* @var string
	* @access private
	*/
	var $_charset = 'windows-1251';


	/**
	* Class contruction, sets client headers
	*
	* @access public
	*/
	function smtp()
	{
		$this->_add_hdr('X-Mailer', sprintf('LAGNUT-SMTP/%s', $this->_version));
		$this->_add_hdr('User-Agent', sprintf('LAGNUT-SMTP/%s', $this->_version));
		$this->_add_hdr('MIME-Version', '1.0');
	}


	/**
	* Turn debugging on/off
	*
	* @access public
	* @param bool $debug command
	*/
	function debug($debug)
	{
		$this->_debug = (bool)$debug;
	}


	/**
	* Clean input to prevent injection
	*
	* @param string $input User data
	*/
	function _clean(&$input)
	{
		if (!is_string($input)) {
			return false;
		}
		$input = urldecode($input);
		$input = str_replace("\n", '', str_replace("\r", '', $input));
	}


	/**
	* Send command to server
	*
	* @access private
	* @param string $cmdcommand
	* @param optional $data data
	*/
	function _cmd($cmd, $data = false)
	{
		$this->_clean($cmd);
		$this->_clean($data);

		if ($this->_is_closed()) {
			return false;
		}

		if (!$data) {
			$command = sprintf("%s\r\n", $cmd);
		}else {
			$command = sprintf("%s: %s\r\n", $cmd,$data);
		}

		fwrite($this->_connection, $command);
		$resp = $this->_read();
		if ($this->_debug){
			printf($command);
			printf($resp);
		}
		if ($this->_is_closed($resp)) {
			return false;
		}
		return $resp;
	}


	/**
	* Collects header
	*
	* @access private
	* @param string$key
	* @param string $data
	*/
	function _add_hdr($key, $data)
	{
		$this->_clean($key);
		$this->_clean($data);
		$this->_hdrs[$key] = sprintf("%s: %s\r\n", $key, $data);
	}


	/**
	* Read server output
	*
	* @access private
	* @return string
	*/
	function _read()
	{
		if ($this->_is_closed()) {
			return false;
		}
		$o = '';
		do {
			$str = @fgets($this->_connection, 515);
			if (!$str) {
				break;
			}
			$o .= $str;
			if (substr($str, 3, 1) == ' ') {
				break;
			}
		} while (true);
		return $o;
	}


	/**
	* Checks if server denies more commands
	*
	* @access private
	* @param $int
	* @return bool true if connection is closed
	*/
	function _is_closed($response = false)
	{
		if (!$this->_connection) {
			return true;
		}
		if (isset($response{0}) && ($response{0} == 4|| $response{0}== 5)) {
			$this->close();
			return true;
		}
		return false;
	}


	/**
	* Open connection to server
	*
	* @access public
	* @param string $server SMTP server
	* @param int $port Server port
	*/
	function open($server, $port = 25)
	{
		
		$this->_connection = @fsockopen($server, $port, $e, $er, 8);

if (!@fsockopen($server, $port, $e, $er, 8))
{
 die("��c������ -> smtp.lib.php");
}
		if ($this->_is_closed()) {
			return false;
		}

		$init= $this->_read();
		if ($this->_debug){
			printf($init);
		}

		if ($this->_is_closed($init)) {
			return false;
		}
		
		$lhost = (isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : '127.0.0.1');

		if (strpos($init,'ESMTP') === false){
			$this->_cmd('HELO '. gethostbyaddr($lhost));
		} else {
			$this->_cmd('EHLO '. gethostbyaddr($lhost));
		}
	}


	/**
	* Start TLS communication
	*
	* @access public
	*/
	function start_tls()
	{
		if (!function_exists('stream_socket_enable_crypto')) {
			trigger_error('TLS is not supported', E_USER_ERROR);
			return false;
		}
		$this->_cmd('STARTTLS');
		stream_socket_enable_crypto($this->_connection, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
	}


	/**
	* Performs SMTP authentication
	*
	* @access public
	* @param string $username username
	* @param string $password password
	* @param int authentication mecanism
	*/
	function auth($username, $password, $type = LOGIN)
	{
		$sasl =& new sasl($sasl, $username, $password);
		switch ($type) {
			case PLAIN:
				$this->_cmd('AUTH PLAIN');
				$this->_cmd($sasl->plain($username, $password));
				break;
			case LOGIN:
				$this->_cmd('AUTH LOGIN');
				$this->_cmd($sasl->login($username));
				$this->_cmd($sasl->login($password));
				break;
			case CRAM_MD5:
				$resp = explode(' ', $this->_cmd('AUTH CRAM-MD5'));
				$this->_cmd($sasl->cram_md5($username, $password, trim($resp[1])));
				break;
		}
	}


	/**
	* Closes connection to the server
	*
	* @access public
	*/
	function close()
	{
		if ($this->_is_closed()) {
			return false;
		}

		$this->_cmd('RSET');
		$this->_cmd('QUIT');
		fclose($this->_connection);
		$this->_connection = null;
	}


	/**
	* E-mail sender
	*
	* @access public
	* @param string $from Sender
	*/
	function from($email, $name = '')
	{
		$from = !empty($name) ? sprintf('%s <%s>', $name, $email) : $email;
		$this->_cmd('MAIL FROM', sprintf('<%s>', $email));
		$this->_add_hdr('FROM', $from);
		$this->_add_hdr('Return-path', $email);
	}


	/**
	* Send reply-to header
	*
	* @param string $to
	*/
	function reply_to($email, $name = '')
	{
		$to = !empty($name) ? sprintf('%s <%s>', $name, $email) : $email;
		$this->_add_hdr('REPLY-TO', $to);
	}


	/**
	* E-mail reciever
	*
	* @access public
	* @param string $to Reciever
	*/
	function to($email, $name = '')
	{
		$to = !empty($name) ? sprintf('%s <%s>', $name, $email) : $email;
		$this->_cmd('RCPT TO', sprintf('<%s>', $email));
		$this->_add_hdr('TO', $to);
	}


	/**
	* MIME type
	*
	* @access public
	* @param string $mime MIME type
	*/
	function mime_charset($mime,$charset)
	{
		$this->_charset = $charset;
		$this->_mime = $mime;
		$this->_add_hdr('Content-type', sprintf('%s; charset=%s', $mime, $charset));
	}


	/**
	* E-mail subject
	*
	* @access public
	* @param string $subject subject
	*/
	function subject($subject)
	{
		$this->_clean($subject);
		$this->_add_hdr('SUBJECT', $this->encode_hdrs($subject));
	}


	/**
	* E-mail body
	*
	* @access public
	* @param string $body body
	*/
	function body($body)
	{
		$body = preg_replace("/([\n|\r])\.([\n|\r])/", "$1..$2", $body);
		$this->_body = sprintf("\r\n%s", $body);
	}


	/**
	* Send the mail
	*
	* @access public
	*/
	function send()
	{
		$resp = $this->_cmd('DATA');
		if ($this->_is_closed($resp)) {
			$this->close();
			return false;
		}
		foreach ($this->_hdrs as $header) {
			fwrite($this->_connection, $header);
			if ($this->_debug) {
				printf($header);
			}
		}
		fwrite($this->_connection,$this->_body);
		fwrite($this->_connection, "\r\n.\r\n");
		$resp = trim($this->_read());
		if ($this->_debug){
			printf("%s\r\n", $this->_body);
			printf("\r\n.\r\n");
			printf('%s', $resp);
		}
		if ((int)$resp{0} != 2) {
			return false;
		} else {
			return true;
		}
	}


	/**
	* encode headers
	*
	* @access private
	* @param string $input
	* @return string
	*/
	function encode_hdrs($input)
	{
		$replacement = preg_replace('/([\x80-\xFF])/e', '"=" . strtoupper(dechex(ord("\1")))', $input);
		$input = str_replace($input, sprintf('=?%s?Q?%s?=', $this->_charset, $replacement), $input);
		return $input;
	}


}
// ����������� ����� ������ - 7Max7, ����� ���������������� ������ �� ������, ����� �� ������� ������ �������.
?>