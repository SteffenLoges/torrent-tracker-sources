<?
if(!defined('IN_TRACKER') && !defined('IN_ANNOUNCE'))
  die("Hacking attempt init!");

if (!function_exists("htmlspecialchars_uni")) {
	function htmlspecialchars_uni($message) {
		$message = preg_replace("#&(?!\#[0-9]+;)#si", "&amp;", $message); // Fix & but allow unicode
		$message = str_replace("<","&lt;",$message);
		$message = str_replace(">","&gt;",$message);
		$message = str_replace("\"","&quot;",$message);
		$message = str_replace("  ", "&nbsp;&nbsp;", $message);
	
		$message = str_replace('script', '', $message);
        $message = str_replace('.js', '', $message);
        $message = str_replace('src=', '', $message); 
		
		return $message;
	}
}

// ���������
//define ('TABLE_PREFIX', 'mybb_'); // ����������, ��� ������.
define ('TIMENOW', time());

//$url = explode('/', $_SERVER['PHP_SELF']);

//$url = explode('/', $_SERVER['SCRIPT_NAME']); 
$url = explode('/', htmlspecialchars_uni($_SERVER['PHP_SELF']));  
array_pop($url);
$DEFAULTBASEURL = (($_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://").htmlspecialchars_uni($_SERVER['HTTP_HOST']).implode('/', $url);
$BASEURL = $DEFAULTBASEURL;

$announce_urls = array();
$announce_urls[] = "$DEFAULTBASEURL/announce.php";
//$announce_urls[] = "http://trecker-local-ru.tut.su/announce.php";
$announce_urls[] = "http://tracker.openbittorrent.com:80/announce";
$announce_urls[] = "http://tracker.publicbt.com:80/announce";
//$announce_urls[] = "http://torrent.ipnm.ru/announce";
$announce_urls[] = "http://freetorrents.org.ua:2710/announce";
//$announce_urls[] = "http://bt.rutor.org:2710/announce";


// DEFINE ������ ������
define ("UC_USER", 0);
define ("UC_POWER_USER", 1);
define ("UC_VIP", 2);
define ("UC_UPLOADER", 3);
define ("UC_MODERATOR", 4);
define ("UC_ADMINISTRATOR", 5);
define ("UC_SYSOP", 6);
define ("UC_SYS", 6);
?>