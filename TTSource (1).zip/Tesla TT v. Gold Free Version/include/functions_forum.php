<?php

function unlinks()
{
for ($x=0; $x<7; $x++){
@unlink(ROOT_PATH."cache/block-forum_$x.txt");
}
@unlink(ROOT_PATH."cache/d2825ef36118c3b508cdcda3a318d0c1.txt");
}


 
  function catch_up()
  {

    global $CURUSER, $readpost_expiry;

    $userid = $CURUSER["id"];

$dt = (time() - $readpost_expiry);

$res = mysql_query("SELECT t.id, t.lastpost FROM topics AS t LEFT JOIN posts AS p ON p.id = t.lastpost WHERE p.added > $dt") or sqlerr(__FILE__, __LINE__);

    while ($arr = mysql_fetch_assoc($res))
    {
      $topicid = $arr["id"];

      $postid = $arr["lastpost"];

      $r = mysql_query("SELECT id,lastpostread FROM readposts WHERE userid=$userid and topicid=$topicid") or sqlerr(__FILE__, __LINE__);

      if (mysql_num_rows($r) == 0)
        mysql_query("INSERT INTO readposts (userid, topicid, lastpostread) VALUES($userid, $topicid, $postid)") or sqlerr(__FILE__, __LINE__);

      else
      {
        $a = mysql_fetch_assoc($r);

        if ($a["lastpostread"] < $postid)
          mysql_query("UPDATE readposts SET lastpostread=$postid WHERE id=" . $a["id"]) or sqlerr(__FILE__, __LINE__);
      }
    }
  }

  //-------- Returns the minimum read/write class levels of a forum

  function get_forum_access_levels($forumid)
  {
    $res = mysql_query("SELECT minclassread, minclasswrite, minclasscreate FROM forums WHERE id=$forumid") or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($res) != 1)
      return false;

    $arr = mysql_fetch_assoc($res);

    return array("read" => $arr["minclassread"], "write" => $arr["minclasswrite"], "create" => $arr["minclasscreate"]);
  }

  //-------- Returns the forum ID of a topic, or false on error

  function get_topic_forum($topicid)
  {
    $res = mysql_query("SELECT forumid FROM topics WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);

    if (mysql_num_rows($res) != 1)
      return false;

    $arr = mysql_fetch_row($res);

    return $arr[0];
  }

  //-------- Returns the ID of the last post of a forum

  function update_topic_last_post($topicid,$added)
  {
  	
    $res = mysql_query("SELECT id,added FROM posts WHERE topicid=$topicid ORDER BY id DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_assoc($res) or die("�� �������� ���������");

    $postid = $arr["id"];
//die($added);
if (empty($added))
  {
 ///	die("s");
   $added= $arr["added"];
   }

//die($added);
    mysql_query("UPDATE topics SET lastpost=$postid, lastdate='$added' WHERE id=$topicid") or sqlerr(__FILE__, __LINE__);
    
  }

  function get_forum_last_post($forumid)
  {
    $res = mysql_query("SELECT lastpost FROM topics WHERE forumid=$forumid ORDER BY lastpost DESC LIMIT 1") or sqlerr(__FILE__, __LINE__);

    $arr = mysql_fetch_row($res);

    $postid = $arr[0];

    if ($postid)
      return $postid;

    else
      return 0;
  }

  //-------- Inserts a quick jump menu

  function insert_quick_jump_menu($currentforum = 0)
  {
   
   
//$dt = sqlesc(time() - 200);
//$url="forums.php";
//$url_e="/edit.php?id=$torrentid";

$dt = sqlesc(get_date_time(gmtime() - 250));


$res_s = sql_query("SELECT id, username, class FROM users FORCE INDEX(forum) WHERE forum_access<>'0000-00-00 00:00:00' and forum_access > $dt ORDER BY forum_access DESC") or sqlerr(__FILE__,__LINE__);
// or url LIKE '%$url_e%'
$lastid=0;
while ($ar_r = mysql_fetch_assoc($res_s)) {

    $username = $ar_r['username'];
    $id_use = $ar_r['id'];
if ($title_who_s)
$title_who_s.=", ";

   	$title_who_s.= "<a href=\"userdetails.php?id=$id_use\">".get_user_class_color($ar_r["class"], $ar_r["username"]) . "</a>";
   	$lastid++;

}

if ($lastid<>0){
    print("<table border='0' cellspacing='0' cellpadding='5' width='100%'>
     <tr><td class=a align=center><b>������ ����� �������������</b>: $lastid</td></tr>
    <tr><td class=b align=center>$title_who_s");
   print("</td></tr></table>");
}

// print("<table border='1' cellspacing='0' cellpadding='5' width='100%'>	<tr><td class=colhead align=center>	\n");


    $le=("<form method=get action=forums.php? name=jump><input type=hidden name=action value=viewforum>\n");
    $le.=("������� �������: ");
    $le.=("<select name=forumid onchange=\"if(this.options[this.selectedIndex].value != -1){ forms['jump'].submit() }\">\n");

    ///$res = mysql_query("SELECT * FROM forums ORDER BY name") or sqlerr(__FILE__, __LINE__);

   // while ($arr = mysql_fetch_assoc($res))
  //  {
  	$cache=new MySQLCache("SELECT id,minclassread,name FROM forums ORDER BY name", 24*3600); // 24 ���a
while ($arr=$cache->fetch_assoc()){
  	
      if (get_user_class() >= $arr["minclassread"])
        $le.=("<option value=" . $arr["id"] . ($currentforum == $arr["id"] ? " selected>" : ">") . $arr["name"] . "\n");
    }

    $le.=("</select>\n");
    $le.=("<input type=submit value='������!'>\n");
    $le.=("</form>");
 //    $le.=("</form></td></tr></table>");
    
    print("<table class=\"main\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td class=\"embedded\">\n");
    print("<div align=\"right\" class=\"success\">$le</div></td></tr></table>\n");

    
  }

  //-------- Inserts a compose frame

  function insert_compose_frame($id, $newtopic = true, $quote = false)
  {
    global $maxsubjectlength, $CURUSER;
 $forum_pic_url="/pic/forumicons/";

    if ($newtopic)
    {
      $res = mysql_query("SELECT name FROM forums WHERE id=$id") or sqlerr(__FILE__, __LINE__);

      $arr = mysql_fetch_assoc($res) or die("�������� id");

      $forumname = $arr["name"];

      print("<p align=center>����� ��������� ��� <a href=?action=viewforum&forumid=$id>$forumname</a> ������</p>\n");
    }
    else
    {
      $res = mysql_query("SELECT * FROM topics WHERE id=$id") or sqlerr(__FILE__, __LINE__);

      $arr = mysql_fetch_assoc($res) or stderr("������ ������", "������ ��������� �� �������� � ����.");

      $subject = htmlspecialchars($arr["subject"]);

      //print("<p align=center>����: <a href=?action=viewtopic&topicid=$id>$subject</a></p>");
    }

    begin_frame("���������", true);

    print("<form name=\"comment\" method=post action=forums.php?action=post>\n");

    if ($newtopic)
      print("<input type=hidden name=forumid value=$id>\n");

    else
      print("<input type=hidden name=topicid value=$id>\n");

    begin_table();

    if ($newtopic)
      print("<tr><td class=rowhead><b>���� ���������</b>: </td>" .
        "<td align=left style='padding: 0px'><input type=text size=100 maxlength=$maxsubjectlength name=subject " .
        "style='border: 0px; height: 19px'></td></tr>\n");

    if ($quote)
    {
       $postid = (int)$_GET["postid"];
       if (!is_valid_id($postid))
         header("Location: $BASEURL/forums.php");

	   $res = mysql_query("SELECT posts.*, users.username,class FROM posts LEFT JOIN users ON posts.userid = users.id WHERE posts.id=$postid") or sqlerr(__FILE__, __LINE__);

	   if (mysql_num_rows($res) != 1)
	     stderr("������", "��� ��������� � ����� id.");

	   $arr = mysql_fetch_assoc($res);
    }
if (!$newtopic) {
 // print("<table style=\"margin-top: 2px;\" cellpadding=\"5\" width=\"100%\">");
  print("<tr><td class=colhead align=\"center\" colspan=\"2\"><a name=comments></a><b><center>.::: �������� ���������  � ���� :::.</b></center></td></tr>");
  print("<tr><td width=\"100%\" align=\"center\" >");
  //print("���� ���: ");
  //print("".$CURUSER['username']."<p>");
  print("<form name=\"comment\" method=\"post\" action=\"forums.php?action=post\">");
  print("<center><table border=\"0\"><tr><td class=\"clear\">");
  print("<div align=\"center\">". textbbcode("comment","body",($quote?("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars($arr["body"])."[/quote]"):""), 1) ."</div>");
  print("</td></tr></table></center>");
  print("</td></tr><tr><td class=\"a\" align=\"center\" colspan=\"2\">");
//  print("<input type=\"hidden\" value=\"$topicid\" name=\"topicid\"/>");
  print("<input type=\"submit\" class=btn value=\"���������� ���������\" /></form>");
 // print("</td></tr></table><br>");

  //  print("".textbbcode("comment","body",($quote?(("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars($arr["body"])."[/quote]")):""))."\n");

   // print("<tr><td colspan=2 align=center><input type=\"submit\" value=\"�����������\"></td></tr>\n");
}else {


  print("<div align=\"center\">". textbbcode("comment","body",($quote?("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars($arr["body"])."[/quote]"):""), 1) ."</div>");
 }
    end_table();


    
if ($newtopic) {
print("<input type=\"submit\" class=btn value=\"���������� ���������\" /></form>");
}else
print("</form>\n");

	///	print("<p align=center><a href=tags.php target=_blank>Tags</a> | <a href=smilies.php target=_blank>Smilies</a></p>\n");

    end_frame();

    //------ Get 10 last posts if this is a reply

    if (!$newtopic)
    {
    	
      $postres = mysql_query("SELECT t.*, u.username, u.class, u.last_access, u.ip, u.signatrue,u.signature,u.avatar, u.title, u.enabled, u.warned, u.hiderating,u.uploaded,u.downloaded,u.donor
	  FROM posts as t
	  LEFT JOIN users AS u ON u.id=t.userid 	
	  WHERE t.topicid=$id ORDER BY t.id DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);

      begin_frame("��������� 10 ������������, �� ���������� � �������.");

      while ($post = mysql_fetch_assoc($postres))
      {
      	 $postid = $post["id"];

      $posterid = $post["userid"];

      $added = display_date_time($post['added']);

      $postername = $post["username"];
      $posterclass = $post["class"];
      
      	 if (empty($postername) && $posterid<>0)
      {
        $by = "<b>id</b>: $posterid";
      }
      elseif ($posterid==0 && empty($postername))
      {
      	$by="<i>��������� �� </i><font color=gray>[<b>System</b>]</font>";
      }
      else
      {
        $title = $post["title"];

        if (!$title)
          $title = get_user_class_name($post["class"]);
  
        $by = "<a href=userdetails.php?id=$posterid><b>" .get_user_class_color($posterclass,  $postername). "</b></a>
		".($post["donor"] == "yes" ? "<img src="."\"./pic/star.gif\" alt='�����'>" : "") . 
		($post["enabled"] == "no" ? "<img src=\""."\"./pic/disabled.gif\" alt=\"���� ������� ��������\" style='margin-left: 2px'>" : ($post["warned"] == "yes" ? "<img src=\"./pic/warned.gif\" alt=\"������������\" border=0>" : "")) . "
		".($title != "" ? " / ".get_user_class_color($posterclass,$title) : "")."";
      }
if ($posterid<>0 && !empty($postername)){
	     if (strtotime($post["last_access"]) > gmtime() - 600) {
			     	$online = "online";
			     	$online_text = "� ����";
			     } else {
			     	$online = "offline";
			     	$online_text = "�� � ����";
			     }
	
		    if ($arr["downloaded"] > 0) {
			    	$ratio = $post['uploaded'] / $post['downloaded'];
			    	$ratio = number_format($ratio, 2);
			    } elseif ($post["uploaded"] > 0) {
			    	$ratio = "Infinity";
			    } else {
			    	$ratio = "---";
			    }

	if ($post["hiderating"]=="yes"){
$print_ratio="<b>+100%</b>";
}
else
$print_ratio="<img src=\"pic/upl.gif\" alt=\"������\" border=\"0\" width=\"12\" height=\"12\"> ".mksize($post["uploaded"]) ." : <img src=\"pic/down.gif\" alt=\"��������\" border=\"0\" width=\"12\" height=\"12\"> ".mksize($post["downloaded"])." : $ratio";

} else {
unset($print_ratio);
unset($ratio);
unset($online_text);
unset($online);
}
      if (!empty($post["avatar"])){
      $avatar = "
	  	".($CURUSER["id"]==$posterid ? "<a href=\"my.php\"><img alt=\"������, �� ����� ������� � ���������\" title=\"������, �� ����� ������� � ���������\" width=100 height=100 src=\"./pic/avatar/".$post["avatar"]."\"/></a>":"<img width=100 height=100 src=\"./pic/avatar/".$post["avatar"]."\"/>")."";
    }
      	


       $locked = $post["locked"] == "yes";
      // $topi=$post["lastpost"];
       $posterid=$post["userid"];



        if ($post["username"]){
        $user="<a href=userdetails.php?id=$post[userid]>".get_user_class_color($post["class"], $post["username"])."</a>";
            } else {
          $user="id: ".$post["userid"];
            }
            
        print("<p class=sub>#" . $post["id"] . " ".($CURUSER["class"]>"3" ? "<img src=\"pic/button_".$online.".gif\" alt=\"".$online_text."\" title=\"".$online_text."\" style=\"position: relative; top: 2px;\" border=\"0\" height=\"14\">" : "")." $by
	  
	    ".($arr["donor"] == "yes" ? "<img src=pic/star.gif alt='�����'>" : "")
		       
		       .($arr["warned"] == "yes" ? "<img src=\"/pic/warned.gif\" alt=\"������������\">" : "") 
			   
			   .($arr["enabled"] == "no" ? "<img src=\"/pic/warned2.gif\" alt=\"��������\">" : "")
			   
			   .($posterid<>0 && !empty($postername) ? " :: $print_ratio ":"")

 .($CURUSER["cansendpm"]=='yes' && ($CURUSER["id"]<>$posterid && $posterid<>0 && !empty($postername))? ":: <a href=message.php?action=sendmessage&amp;receiver=".$posterid.">"."<img src=pic/button_pm.gif border=0 alt=\"��������� ���������\" ></a>" : "")."");

            begin_table(true);

        print("<tr valign=top><td width=100 align=left style='padding: 0px'>" .
        ($avatar ? $avatar : ""). "<br /><div></div></td><td class=comment>" . format_comment($post["body"]) . "
		  
		  	".(($post["signatrue"]=="yes" && $post["signature"])? "<p valign=down align=down><hr>".format_comment($post["signature"])."</p>": "")."
		
		</td></tr>
		  
		  <td align=center class=a>".display_date_time($post["added"])."</td>\n");


//if (!$locked || get_user_class() >= UC_MODERATOR)
	print("<td align=\"right\">"); // [<a href=?action=quotepost&topicid=$topi&postid=" . $post["id"] . "><b>����������</b></a>] - 

      if (($CURUSER["id"] == $posterid && !$locked) || get_user_class() >= UC_MODERATOR)
        print("[<a href=?action=editpost&postid=" . $post["id"] . "><b>�������������</b></a>]");

      if (get_user_class() >= UC_MODERATOR)
        print(" - [<a href=?action=deletepost&postid=" . $post["id"] . "><b>�������</b></a>]</td>");
        
        
        
        end_table();

      }

      end_frame();

    }

  insert_quick_jump_menu();

  }
  
  
  
/*
function get_time_offset() {
    
    	global $CURUSER, $CONFIG_INFO;
    	$r = 0;
    	
    	$r = ( ($CURUSER['time_offset'] != "") ? $CURUSER['time_offset'] : $CONFIG_INFO['time_offset'] ) * 3600;
			
      if ( $CONFIG_INFO['time_adjust'] )
      {
        $r += ($CONFIG_INFO['time_adjust'] * 60);
      }
      
      if ( $CURUSER['dst_in_use'] )
      {
        $r += 3600;
      }
        
        return $r;
}*/

function get_cleanup($time=false){  
   
// �������� �������� ����������� ������ ��� ������� �����...
	
$h = date('H'); // ��������� ���
if (($h >= 06)&&($h <= 12)) // ����������
{

$now = time();
$res = mysql_query("SELECT value_u FROM avps WHERE arg = 'fread_posts'") or sqlerr(__FILE__,__LINE__);
$row = mysql_fetch_array($res);
$row_time=$row["value_u"];
$now_2day=time()+(86400*3); /// ��� � ��� ���
$dt = get_date_time(gmtime());

if ($row_time<=$now){

global $readpost_expiry;

$dt = (time() - $readpost_expiry);
sql_query("DELETE readposts FROM readposts LEFT JOIN posts ON readposts.lastpostread = posts.id WHERE posts.added < $dt") or sqlerr(__FILE__,__LINE__);
$delete_readpost=mysql_affected_rows();

sql_query("DELETE FROM posts WHERE topicid not in (SELECT id FROM topics WHERE id=posts.topicid)") or sqlerr(__FILE__,__LINE__); 
$delete_posts=mysql_affected_rows();

$numo="Readposts: $delete_readpost; Posts: $delete_posts";

if (empty($row_time)) {
sql_query("INSERT INTO avps (arg, value_u,value_s,value_i) VALUES ('fread_posts',$now_2day,'$numo','$delete_readpost')");
} elseif (!empty($row_time)) {
sql_query("UPDATE avps SET value_u='$now_2day',value_s='$numo', value_i='$delete_readpost' WHERE arg='fread_posts'") or sqlerr(__FILE__,__LINE__);
}
}

}
// �������� �������� ����������� ������ ��� ������� �����...




   }
   
?>