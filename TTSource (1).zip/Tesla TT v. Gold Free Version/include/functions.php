<?
if(!defined('IN_TRACKER'))
  die('Hacking attempt!');

require_once(ROOT_PATH.'include/functions_global.php');

/// �� �������� � tls
$SITEEMAIL=$accountname="noreply@muz-tracker.net";  
$accountpassword="D2VMOzr2"; 
$smtp_host="smtp.muz-tracker.net"; 
$smtp_port="25";

/*$SITEEMAIL=$accountname="d19voll@mail.ru";  
$accountpassword="u24U7MF6"; 
$smtp_host="smtp.mail.ru"; 
$smtp_port="25";
*/
function strip_magic_quotes($arr) {
	foreach ($arr as $k => $v) {
		if (is_array($v)) {
			$arr[$k] = strip_magic_quotes($v);
			} else {
			$arr[$k] = stripslashes($v);
			}
	}
	return $arr;
}


function local_user() {
	return $_SERVER["SERVER_ADDR"] == $_SERVER["REMOTE_ADDR"];
}

function sql_query($query) {
	global $queries, $query_stat, $querytime;
	++$queries;
	$query_start_time = timer(); // Start time
	$result = mysql_query($query);
	$query_end_time = timer(); // End time
	$query_time = ($query_end_time - $query_start_time);
	$querytime = $querytime + $query_time;
	$query_time = substr($query_time, 0, 8);
	$query_stat[] = array("seconds" => $query_time, "query" => $query);
	return $result;
}


//  $lightmode = true - ���� ������ � ���� (����)
function dbconn($autoclean = false, $lightmode = false) {
	global $mysql_host_fix_by_imperator , $mysql_user_fix_by_imperator , $mysql_pass_fix_by_imperator , $mysql_db_fix_by_imperator , $mysql_charset_fix_by_imperator ;

	if (!@mysql_connect($mysql_host_fix_by_imperator , $mysql_user_fix_by_imperator , $mysql_pass_fix_by_imperator ))
	{
	  switch (mysql_errno())
	  {
	  case 2003:
	  {
	  	 die("��� ���������� � ����� ������, ��������� mysql ��������� [" . mysql_error()."]");
	  }
	  	
	  case 1040:
	  case 2002:
if ($_SERVER['REQUEST_METHOD'] == "GET"){
die("<html><head><meta http-equiv='refresh' content=\"10 $_SERVER[REQUEST_URI]\"></head><body><table border='0' width='100%' height='100%'><tr><td><h3 align='center'>�� ������ ������ ���� ������ �����������. ������� ����������� ����� 10 ������ ����� �������������...</h3></td></tr></table></body></html>");
} else {
print"<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">
<meta http-equiv=\"Content-Style-Type\" content=\"text/css\"><title></title>
<style type=\"text/css\">	body { min-width: 760px; color: #000000; background: #E3E3E3; font: 16px Verdana; }
.msg { margin: 20%; text-align: center; background: #EFEFEF; border: 1px solid #B7C0C5; }
</style></head><body>
<div class=\"msg\"><p style=\"margin: 1em 0;\">��������, � ������ ������ ������ ����������.</p>	<p style=\"margin: 1em 0;\">���������� ����� ����� ��������� �����. <br>C �� ������������� Muz-Tracker.net</p>
</div></body>";
die();
}
        default: die("[" . mysql_errno() . "] dbconn: mysql_connect: " . mysql_error());
      }
    
	}

	mysql_select_db($mysql_db_fix_by_imperator) or die("dbconn: mysql_select_db: " + mysql_error());

	mysql_query("SET NAMES $mysql_charset_fix_by_imperator");
  //mysql_query("SET NAMES SQL_BIG_TABLES = 1");
    /// SQL_BIG_TABLES = 1 - ������ �������� ���� ��������� ������ ����� ����
    
 	userlogin($lightmode);

	if (basename($_SERVER['SCRIPT_FILENAME']) == 'index.php')
		register_shutdown_function("autoclean");

	register_shutdown_function("mysql_close");
    
	unset($GLOBALS["useraccess_fix_by_imperator"],$GLOBALS["passaccess_fix_by_imperator"],$GLOBALS["mysql_pass_fix_by_imperator"],$GLOBALS["mysql_user_fix_by_imperator"],$GLOBALS["mysql_db_fix_by_imperator"],$GLOBALS["mysql_host_fix_by_imperator"]);
}

function userlogin($lightmode = false) {
global $SITE_ONLINE, $default_language, $tracker_lang, $use_lang, $use_ipbans;

unset($GLOBALS["CURUSER"]);

$ip = getip(); $nip = ip2long($ip);
//$user_sysop=$row_user["class"]==6;
if ($use_ipbans && !$lightmode) {
$res = sql_query("SELECT bans_time FROM bans FORCE INDEX(first_last) WHERE $nip >= first AND $nip <= last") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) >0) {
	$comment = mysql_fetch_assoc($res);
	$comment = "<br>��: ".format_comment($comment["bans_time"]);
header("HTTP/1.0 403 Forbidden");
print("<title>Muz-Tracker - ��� ��� $ip</title>
<script><!--
var tit = document.title;
var c = 0;
function writetitle()
{
document.title = tit.substring(0,c);
if(c==tit.length)
{
c = 0;
setTimeout(\"writetitle()\", 30000)
}
else
{
c++;
setTimeout(\"writetitle()\", 50)
}
}
writetitle()
// --></script><style type=\"text/css\">
<!--
.style4 {font-family: \"Times New Roman\", Times, serif;font-size: 16px;color: #999999;}
.style5 {font-size: 48px;font-family: \"Times New Roman\", Times, serif;color: #006699;}
.style6 {font-size: 28px;font-family: \"Times New Roman\", Times, serif;color: #FFFFFF;}
-->
</style>
<Script Language=\"JavaScript\">
  function initArray()
  {this.length = initArray.arguments.length
   for (var i = 0; i < this.length; i++)
   this[i+1] = initArray.arguments[i]}
  colorList = new initArray(\"ffffff\", \"eeeeee\", \"dddddd\", \"cccccc\",
	\"bbbbbb\", \"aaaaaa\", \"999999\", \"888888\", \"777777\", \"666666\",
	\"555555\", \"444444\", \"333333\", \"222222\", \"111111\", \"000000\",
	\"000000\", \"111111\", \"222222\", \"333333\", \"444444\", \"555555\",
	\"666666\", \"777777\", \"888888\", \"999999\", \"aaaaaa\", \"bbbbbb\",
	\"cccccc\", \"dddddd\", \"eeeeee\", \"ffffff\");
  var currentColor = 1;
  function backgroundChanger()
  {document.bgColor = colorList[currentColor];
   if (currentColor++ < 32)
     setTimeout(\"backgroundChanger()\", 5);
   else
     return}
  backgroundChanger();
</Script>
<script LANGUAGE=\"JavaScript\">
var sizes = new Array(\"0px\", \"1px\", \"2px\",\"4px\", \"8px\");
sizes.pos = 0;
function rubberBand()
{
var el = document.all.elastic;
if (null == el.direction)
el.direction = 1;
else if ((sizes.pos > sizes.length - 2) ||
(0 == sizes.pos))
el.direction *= -1;
el.style.letterSpacing = sizes[sizes.pos += el.direction];
}
</script>
<body onload=\"window.tm = setInterval('rubberBand()', 100);\">
<h1 class=\"style6\" align=\"center\">�����������!!!</h1>
<h1 class=\"style4\" id=\"elastic\" align=\"center\">�� ��������</h1>
</head>
<body>
<p align=\"center\" class=\"style5\">��� ip ����� ������������ $comment</p>
<p align=\"center\" class=\"style6\">������ �����������!</p>
</body>\n");
			die;
		}
	}
	
    /*require_once "cache/bans_cache.php";
    if(count($bans) > 0)
    {
      foreach($bans as $k) {
        if($nip >= $k['first'] && $nip <= $k['last']) {
        header("HTTP/1.0 403 Forbidden");
        print("<html><body><h1>403 Forbidden</h1>Unauthorized IP address.</body></html>\n");
        exit();
        }
      }
      unset($bans);
    }
	*/

if (!$SITE_ONLINE || empty($_COOKIE["uid"]) || empty($_COOKIE["pass"])) {

logoutcookie;
if ($use_lang)
include_once('languages/lang_' . $default_language . '/lang_main.php');
unset($GLOBALS["CURUSER"]);
user_session();

return;
}

if (strlen($_COOKIE["pass"]) <> 32) {
logoutcookie;
include_once('languages/lang_' . $default_language . '/lang_main.php');
unset($GLOBALS["CURUSER"]);
user_session();
return;
}
$id = (int) $_COOKIE["uid"];

$res = sql_query("SELECT * FROM users WHERE enabled='yes' AND status = 'confirmed' AND id = '$id'") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res);

////////////////// encode ///////////////////
if ($row["enabled"]=="no") {
$str = $row["username"];
$checksum = crc32($str);
$data = $str.":".$checksum;
$cookie = base64_encode($data);
@setcookie("offlog", $cookie, "0x7fffffff", "/");
}
////////////////// encode ///////////////////


/// ������ �� ����� ����� aka 7Max7
        if ($row["shelter"]=="ag"){
        $she_md5=$row["crc"];
		} else {
        $she_md5=$row["ip"];
        }
        $tesla_ip = "T".md5($row["id"]+$she_md5+$row["id"]);

		if ($_COOKIE["tesla"]<>$tesla_ip){
		logoutcookie;
		include_once('languages/lang_' . $default_language . '/lang_main.php');
		unset($GLOBALS["CURUSER"]);
		user_session();
		return;
    	}
/// ������ �� ����� ����� aka 7Max7
    	

   		/// ������� ����, ����� �������� ����� dump3r | phpmyadmin
        if ($_COOKIE["sxd"] || $_COOKIE["pmaPass-1"]){
        setcookie("sxd");  setcookie("phpMyAdmin"); 
		setcookie("pmaUser-1");  setcookie("pmaPass-1");
        }

        if (!$row) {
        logoutcookie;
        if ($use_lang)
        include_once('languages/lang_' . $default_language . '/lang_main.php');
        unset($GLOBALS["CURUSER"]);
        user_session();
        return;
        }
	
	$sec = hash_pad($row["secret"]);
	if ($_COOKIE["pass"] !== $row["passhash"]) {
			logoutcookie;
		if ($use_lang)
			include_once('languages/lang_' . $default_language . '/lang_main.php');
			unset($GLOBALS["CURUSER"]);
		user_session();
		return;
	}
	
	
	// ������ �������� ��� �����������
    // �������-������, ����� ������� ������������ ����� ��������� �������� ����� ��������� �����
    $seconds = 30*60; /// 30 �����
    $dt = get_date_time(gmtime() - $seconds);
    if($row['last_access'] < $dt){
    $set_checked = ", last_checked = '" .$row['last_access']. "'";
    setcookie("markview", "", 0x7fffffff, "/");
    }
    // ������ �������� ��� �����������
	

$updateset = array();

    if ($ip <> $row['ip'])
        $updateset[] = 'ip = '.sqlesc($ip); /// add .$set_checked
    if (strtotime($row['last_access']) < (strtotime(get_date_time()) - 300))
        $updateset[] = 'on_line=on_line+300, last_access = ' . sqlesc(get_date_time()).$set_checked;

    if (count($updateset))
sql_query("UPDATE users SET ".implode(", ", $updateset)." WHERE id=" . $row["id"]) or sqlerr(__FILE__,__LINE__);

    $row['ip'] = $ip;

    if ($row['monitoring']=='yes' && getenv("REQUEST_URI")<>'/' && !preg_match("/poll.core/i", $_SERVER["SCRIPT_FILENAME"]) && !preg_match("/online/i", $_SERVER["SCRIPT_FILENAME"]) && !preg_match("/shoutbox/i", $_SERVER["SCRIPT_FILENAME"]))

 //if ($row['monitoring']=='yes' && getenv("REQUEST_URI")<>'' && getenv("REQUEST_URI")<>'/' && getenv("REQUEST_URI")<>'/shoutbox.php?=undefined' && getenv("REQUEST_URI")<>'/online.php?wol=1'&& getenv("REQUEST_URI")<>'/tracker-chat.php' && getenv("REQUEST_URI")<>'/poll.core.php')
{
$userid=$row["id"];
$sf =ROOT_PATH."cache/monitoring_$userid.txt"; 

$fpsf=fopen($sf,"a+"); 
$ip=getip(); 
$ag=htmlentities(getenv("HTTP_USER_AGENT")); 
$from=htmlentities(getenv("HTTP_REFERER")); 
$host=htmlentities(getenv("REQUEST_URI")); 

$date = date("d.m.y"); 
$time= date("H:i:s"); 
fputs($fpsf,"#$host #$ip # #$date $time\n"); 
fclose($fpsf);

///// ���� ����� ���������������
include (ROOT_PATH."include/zip.lib.php");
if (@filesize($sf) >= 2000000 && @filesize($sf)<= 3000000) /// ���� ������ 2000000 ���� - 2 �����
{
$dsf=date('H-i-s');
$ziper_newname=ROOT_PATH."cache/$dsf-monitoring_$userid.zip";
$ziper = new zipfile();
$ziper->addFiles(array("$sf"));  //array of files
$ziper->output("$ziper_newname"); 
@unlink ($sf);
} elseif (@filesize($sf) >= 3000000) @unlink($sf);
/// ������ � ����� ���� ������� ��������

///// ���� ����� ���������������
}

///	if ($row['override_class'] <>"255")
//	$row['class'] = $row['override_class']; // Override class and save in GLOBAL array below.
//	$row['override']=$row['class']; 
	
	$GLOBALS["CURUSER"] = $row;

	///unset($GLOBALS["$row"]);
	if ($use_lang)
		include_once('languages/lang_' . $row['language'] . '/lang_main.php');

	if (!$lightmode)
		user_session();

}

function logincookie($id, $passhash, $shelter, $updatedb = 1, $expires = 0x7fffffff) {

	/// ������ �� ����� ����� aka 7Max7
	$crc32_now=crc32(htmlentities($_SERVER["HTTP_USER_AGENT"]));
	
	if ($shelter=="ag"){
    $she_md5=$crc32_now;
	} else
    $she_md5=getip();
    
    $tesla_ip = "T".md5($id+$she_md5+$id);
	setcookie("tesla", $tesla_ip, $expires, "/");
	setcookie("uid", $id, $expires, "/");
	setcookie("pass", $passhash, $expires, "/");

    if ($updatedb) {
    global $CURUSER;
    	
    if (!empty($crc32_now)) {
$agent = $_SERVER["HTTP_USER_AGENT"];
$hache = crc32(htmlentities($agent));
$agent = htmlentities($agent);
$time = sqlesc(get_date_time());

$ret2=sql_query("SELECT crc,idagent FROM users WHERE id=".sqlesc($id)."") or sqlerr(__FILE__,__LINE__);
$row_user = mysql_fetch_array($ret2); 
$uid=$id;

if (empty($row_user["crc"]) || $row_user["crc"]==0)
{
sql_query("INSERT INTO useragent (crc32, agent, added) VALUES (".sqlesc($hache).",".sqlesc($agent).",".sqlesc(get_date_time()).")");

$ret=sql_query("SELECT id FROM useragent WHERE crc32=".sqlesc($hache)."") or sqlerr(__FILE__,__LINE__);
$row = mysql_fetch_array($ret); 
$next_id = $row['id']; 
sql_query("UPDATE users SET crc=".sqlesc($hache).",idagent=".sqlesc($next_id.",")." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
} elseif ($row_user["crc"]<>$hache) {
$du = sql_query("SELECT id FROM useragent WHERE crc32=".sqlesc($hache)."") or sqlerr(__FILE__,__LINE__);
$rodu = mysql_fetch_array($du); $f_id = $rodu['id']; 

if (isset($f_id) && !stristr($row_user["idagent"],$f_id.",")){
$new_ids=$row_user["idagent"]."".$f_id.",";
sql_query("UPDATE users SET crc=".sqlesc($hache).",idagent=".sqlesc($new_ids)." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
}
elseif (!isset($f_id)){
sql_query("INSERT INTO useragent (crc32, agent, added) VALUES (".sqlesc($hache).",".sqlesc($agent).",".sqlesc(get_date_time()).")");

$ret2=sql_query("SELECT id FROM useragent WHERE crc32=".sqlesc($hache)."") or sqlerr(__FILE__,__LINE__);
$row2 = mysql_fetch_array($ret2); 
$new_ids2=$row_user["idagent"]."".$row2['id'].",";

if (stristr($row_user["idagent"],$row2['id'].",")){
$new_ids2=$row_user["idagent"];
}

sql_query("UPDATE users SET crc=".sqlesc($hache).",idagent=".sqlesc($new_ids2)." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
} else {
sql_query("UPDATE users SET crc=".sqlesc($hache)." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
}}
}
    	
    	
sql_query("UPDATE users SET last_login = NOW() WHERE id = $id") or sqlerr(__FILE__, __LINE__); 
    }
}

function logoutcookie() {
    setcookie("tesla", "", 0x7fffffff, "/");
	setcookie("uid", "", 0x7fffffff, "/");
	setcookie("pass", "", 0x7fffffff, "/");
}


function get_server_load() {
	global $tracker_lang, $phpver;
	if (strtolower(substr(PHP_OS, 0, 3)) === 'win') {
		
	
		
		if (class_exists("COM")) {
			if ($phpver=="4") {
				$wmi = new COM("WinMgmts:\\\\.");
				$cpus = $wmi->InstancesOf("Win32_Processor");
				$cpuload = 0;
				$i = 0;
				while ($cpu = $cpus->Next()) {
					$cpuload += $cpu->LoadPercentage;
					$i++;
				}
				$cpuload = round($cpuload / $i, 2);
				return "$cpuload";
			} else {
				$wmi = new COM("WinMgmts:\\\\.");
				$cpus = $wmi->InstancesOf("Win32_Processor");
				$cpuload = 0;
				$i = 0;
				foreach ($cpus as $cpu) {
					$cpuload += $cpu->LoadPercentage;
					$i++;
				}
				$cpuload = round($cpuload / $i, 2);
				return "$cpuload";
			}
		} else
			return $tracker_lang["unknown"];
			
		
			return 0;
	} elseif (@file_exists("/proc/loadavg")) {
		$load = @file_get_contents("/proc/loadavg");
		$serverload = explode(" ", $load);
		$serverload[0] = round($serverload[0], 4);
		if(!$serverload) {
			$load = @exec("uptime");
			$load = split("load averages?: ", $load);
			$serverload = explode(",", $load[1]);
		}
	} else {
		$load = @exec("uptime");
		$load = split("load averages?: ", $load);
		$serverload = explode(",", $load[1]);
	}
	$returnload = trim($serverload[0]);
	if(!$returnload) {
		$returnload = $tracker_lang["unknown"];
	}
	return $returnload;
}

function user_session() {
	global $CURUSER, $use_sessions, $anti_httpdoss;

	if ($anti_httpdoss==1 && empty($CURUSER) && empty($_COOKIE["tesla"]) && $_SERVER["HTTP_USER_AGENT"]<>"BTWebClient/1850(17091)") {
		
			$ip = getip();
			$dt = sqlesc(time() - 60);
			$dt3 = sqlesc(time() - 100);
            $dt2 = display_date_time(time() - 60);
       //  $unverified = number_format(get_row_count("sessions", "WHERE time>'$dt' and ip='$ip' and class='-1' LIMIT 100")); 
         
         $cache2=new MySQLCache("SELECT sid FROM sessions WHERE ip='$ip' and class='-1' LIMIT 100", 20);
        $unverified=$cache2->num_rows();
//print($unverified);
         $antiflood=$unverified>=20;
         
		if ($unverified>=4 and $unverified<8)
		{
die("<b>������� �������</b>: ���������� ���������� ������������� ����������. <br>������ � ��� ������� <b>$unverified</b> ������ � <b>$dt2 - ".display_date_time(time())." ����: 20 ���</b>");	
		sql_query("DELETE FROM sessions WHERE time>'$dt3' and ip='$ip' and class='-1' ");	
		}
		if ($unverified>=100)
		{
	   // session_destroy();
		sql_query("DELETE FROM sessions WHERE ip='$ip' and class='-1'");
	
        register_shutdown_function("mysql_close");
        
        die("<b>������� �������</b>: ���������� ���������� ������������� ����������. <br>������ � ��� ������� <b>$unverified</b> ������ � <b>$dt2 - ".display_date_time(time())." ����: 20 ���</b>");
        
      	}
      	/*	$dt4 = sqlesc(time() - 400);
	sql_query("DELETE FROM sessions WHERE time<'$dt4' and class='-1'");	
	*/
		}
		
		
		
	if (!$use_sessions || $CURUSER["id"]==92) /// || $antiflood
		return;

	$ip = getip();
	$url = getenv("REQUEST_URI");

	if (!$CURUSER) {
		$uid = -1;
		$username = '';
		$class = -1;
	} else {
		$uid = $CURUSER['id'];
		$username = $CURUSER['username'];
		$class = $CURUSER['class'];
	}
	
	$past = time() - 300;
	$sid = session_id();
	$where = array();
	$updateset = array();
	if ($sid)
		$where[] = "sid = ".sqlesc($sid);
	elseif ($uid)
		$where[] = "uid = $uid";
	else
		$where[] = "ip = ".sqlesc($ip);
		
//sql_query("DELETE FROM sessions WHERE ".implode(" AND ", $where));

	$ctime = time();
	$agent = htmlentities($_SERVER["HTTP_USER_AGENT"]);
	$hache = crc32(htmlentities($agent));
	
	$updateset[] = "sid = ".sqlesc($sid);
	
//	if ($CURUSER["id"]<>$uid && $CURUSER)
	$updateset[] = "uid = ".sqlesc($uid);
	
//	if ($CURUSER["username"]<>$username && $CURUSER)
	$updateset[] = "username = ".sqlesc($username);
	
//	if ($CURUSER["class"]<>$class && $CURUSER)
	$updateset[] = "class = ".sqlesc($class);

	$updateset[] = "time = ".sqlesc($ctime);
	$updateset[] = "url = ".sqlesc($url);
	
//	if ($CURUSER["ip"]<>$ip)
	$updateset[] = "ip = ".sqlesc($ip);

	if ($CURUSER["crc"]<>$hache)
	$updateset[] = "useragent = ".sqlesc($agent);

	$from=getenv("HTTP_REFERER"); 
   
    if ($url =="/"){$url = "/index.php";}

	if ((count($updateset)) && (stripos($from, $url)!=TRUE))
	sql_query("UPDATE sessions SET ".implode(", ", $updateset)." WHERE ".implode(" AND ", $where)) or sqlerr(__FILE__,__LINE__);
	
		
	if (mysql_modified_rows()==0)
	sql_query("INSERT INTO sessions (sid, uid, username, class, ip, time, url, useragent) VALUES (".implode(", ", array_map("sqlesc", array($sid, $uid, $username, $class, $ip, $ctime, $url, $agent))).")");

	
if ($CURUSER && !empty($agent)) {
$agent = $_SERVER["HTTP_USER_AGENT"];
$hache = crc32(htmlentities($agent));
$agent = htmlentities($agent);
$time = sqlesc(get_date_time());

if (empty($CURUSER["crc"]) || $CURUSER["crc"]==0)
{
//$ret = mysql_query("SHOW TABLE STATUS LIKE 'useragent'"); 
//$row = mysql_fetch_array($ret); 
//$next_id = $row['Auto_increment']; 


sql_query("INSERT INTO useragent (crc32, agent, added) VALUES (".sqlesc($hache).",".sqlesc($agent).",".sqlesc(get_date_time()).")")// or sqlerr(__FILE__,__LINE__)
;

$ret=sql_query("SELECT id FROM useragent WHERE crc32=".sqlesc($hache)."") or sqlerr(__FILE__,__LINE__);
$row = mysql_fetch_array($ret); 
$next_id = $row['id']; 

sql_query("UPDATE users SET crc=".sqlesc($hache).",idagent=".sqlesc($next_id.",")." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
}
elseif ($CURUSER["crc"]<>$hache)
{

$du = sql_query("SELECT id FROM useragent WHERE crc32=".sqlesc($hache)."") or sqlerr(__FILE__,__LINE__);
$rodu = mysql_fetch_array($du); $f_id = $rodu['id']; 


if (isset($f_id) && !stristr($CURUSER["idagent"],$f_id.",")){
$new_ids=$CURUSER["idagent"]."".$f_id.",";
sql_query("UPDATE users SET crc=".sqlesc($hache).",idagent=".sqlesc($new_ids)." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
}
elseif (!isset($f_id)){
//$ret2 = mysql_query("SHOW TABLE STATUS LIKE 'useragent'"); 
//$row2 = mysql_fetch_array($ret2); 
//$next_id2 = $row2['Auto_increment'];
//$new_ids2=$CURUSER["idagent"]."".$row2['Auto_increment'].",";
sql_query("INSERT INTO useragent (crc32, agent, added) VALUES (".sqlesc($hache).",".sqlesc($agent).",".sqlesc(get_date_time()).")") //or sqlerr(__FILE__,__LINE__)
;

$ret2=sql_query("SELECT id FROM useragent WHERE crc32=".sqlesc($hache)."") or sqlerr(__FILE__,__LINE__);
$row2 = mysql_fetch_array($ret2); 
$new_ids2=$CURUSER["idagent"]."".$row2['id'].",";


if (stristr($CURUSER["idagent"],$row2['id'].",")){
$new_ids2=$CURUSER["idagent"];
}

sql_query("UPDATE users SET crc=".sqlesc($hache).",idagent=".sqlesc($new_ids2)." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
}
else {
sql_query("UPDATE users SET crc=".sqlesc($hache)." WHERE id=".sqlesc($uid)."") or sqlerr(__FILE__,__LINE__);
}

}
//echo("$hache � $agent");
}


////// ��������� ���� ���� ���� 6
	if ($CURUSER["class"]>"6") {
	$culass2=$CURUSER["class"];
    $modcomm2=$CURUSER["usercomment"];
	$modcomment2 = date("Y-m-d") . " - ��������� ���� � $culass2 �� 0.\n" . $modcomm2;

	$updateset2[] = "usercomment = '$modcomment2'";
	$updateset2[] = "class = '0'";
	$updateset2[] = "monitoring='yes'";

	sql_query("UPDATE users SET " . implode(", ", $updateset2) . " WHERE id = $uid") or sqlerr(__FILE__, __LINE__);
	
	@header("Location: $DEFAULTBASEURL/index.php");
	die("}0{o}0{"); /// die - ������ ���
	}

}

function unesc($x) {
	if (get_magic_quotes_gpc())
		return stripslashes($x);
	return $x;
}

/*function gzip2() {
	if (@extension_loaded('zlib') && @ini_get('zlib.output_compression') != '1' && @ini_get('output_handler') != 'ob_gzhandler' && $use_gzip == "yes") {
		@ob_start('ob_gzhandler');
	}
}*/

function gzip() {
    
    if (!preg_match("/login/i", $_SERVER["SCRIPT_FILENAME"]) && !preg_match("/signup/i", $_SERVER["SCRIPT_FILENAME"]) && !preg_match("/recover/i", $_SERVER["SCRIPT_FILENAME"])){
    	
    global $use_gzip;
    static $already_loaded; /// ����� ������ ��� ��������
   
    if (extension_loaded('zlib') && ini_get('zlib.output_compression') <>'1' && ini_get('output_handler') <> 'ob_gzhandler' && $use_gzip=='yes' && !$already_loaded) {
        @ob_start('ob_gzhandler');
        $already_loaded = true; /// �������� ��� ������������
    } else {
      @ob_start();   //��������, ������� �� ��������� �����������, �� ����� ���� ��������, ��� ��� ��� ���������� �������� ��� ���������������� ����� ����������.
       }
       
       }
     
}

// IP ���������� ������ ��� ������� �������� ������������ ip �������
function validip($ip) {
	if (!empty($ip) && $ip == long2ip(ip2long($ip)))
	{
		// reserved IANA IPv4 addresses
		// http://www.iana.org/assignments/ipv4-address-space
		$reserved_ips = array (
				array('0.0.0.0','2.255.255.255'),
				array('10.0.0.0','10.255.255.255'),
				array('127.0.0.0','127.255.255.255'),
				array('169.254.0.0','169.254.255.255'),
				array('172.16.0.0','172.31.255.255'),
				array('192.0.2.0','192.0.2.255'),
				array('192.168.0.0','192.168.255.255'),
				array('255.255.255.0','255.255.255.255')
		);

		foreach ($reserved_ips as $r) {
				$min = ip2long($r[0]);
				$max = ip2long($r[1]);
				if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
		}
		return true;
	}
	else return false;
}

function validip_pmr($ip=false) {
	
	if (empty($ip))
	$ip=getip();
	
	if (!empty($ip) && $ip == long2ip(ip2long($ip)))
	{
		$reserved_ips = array (
				array('80.94.240.0','80.94.255.255'),
				array('77.235.96.0','77.235.127.255'),
				array('62.221.64.0','62.221.127.255'),
				array('95.153.64.0','95.153.127.255'),
				array('217.19.208.0','217.19.223.255')
		);

		foreach ($reserved_ips as $r) {
				$min = ip2long($r[0]);
				$max = ip2long($r[1]);
				if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
		}
		return true;
	}
	else return false;
}

function getip() {
	
	// Code commented due to possible hackers/banned users to fake their ip with http headers
	if (isset($_SERVER)) {
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && validip($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_CLIENT_IP']) && validip($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
	} else {
		if (getenv('HTTP_X_FORWARDED_FOR') && validip(getenv('HTTP_X_FORWARDED_FOR'))) {
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} elseif (getenv('HTTP_CLIENT_IP') && validip(getenv('HTTP_CLIENT_IP'))) {
			$ip = getenv('HTTP_CLIENT_IP');
		} else {
			$ip = getenv('REMOTE_ADDR');
		 }
	}

	return $ip;
}

function autoclean() {
	global $autoclean_interval;

	$now = time();
	$docleanup = 0;

	$res = sql_query("SELECT value_u FROM avps WHERE arg = 'lastcleantime'");
	$row = mysql_fetch_array($res);
	if (!$row) {
		sql_query("INSERT INTO avps (arg, value_u) VALUES ('lastcleantime',$now)");
		return;
	}
	$ts = $row[0];
	if ($ts + $autoclean_interval > $now)
		return;

	sql_query("UPDATE avps SET value_u=$now WHERE arg='lastcleantime' AND value_u = $ts");
	
	if (!mysql_affected_rows())	
    return;
	
	require_once(ROOT_PATH.'include/cleanup.php');

	docleanup();
}

function mksize($bytes) {
	if ($bytes < 1000 * 1024)
		return number_format($bytes / 1024, 2) . " ��";
	elseif ($bytes < 1000 * 1048576)
		return number_format($bytes / 1048576, 2) . " ��";
	elseif ($bytes < 1000 * 1073741824)
		return number_format($bytes / 1073741824, 2) . " ��";
	else
		return number_format($bytes / 1099511627776, 2) . " ��";
}

function mksizeint($bytes) {
		$bytes = max(0, $bytes);
		if ($bytes < 1000)
				return floor($bytes) . " ����";
		elseif ($bytes < 1000 * 1024)
				return floor($bytes / 1024) . " ��";
		elseif ($bytes < 1000 * 1048576)
				return floor($bytes / 1048576) . " ��";
		elseif ($bytes < 1000 * 1073741824)
				return floor($bytes / 1073741824) . " ��";
		else
				return floor($bytes / 1099511627776) . " ��";
}

function deadtime() {
	global $announce_interval;
	return time() - floor($announce_interval * 1.3);
}

function timesec($input, $time = false) {
    $search = array('January','February','March','April','May','June','July','August','September','October','November','December');
    $replace = array('������','�������','�����','������','���','����','����','�������','��������','�������','������','�������');
    $seconds = strtotime($input);
  //  if ($time == true)
     //   $data = date("j F Y � H:i:s", $seconds);
  //  else
        $data = date("H:i:s", $seconds);
    $data = str_replace($search, $replace, $data);
    return $data;
}


function normaltime($input, $time = false) {
    $search = array('January','February','March','April','May','June','July','August','September','October','November','December');
    $replace = array('������','�������','�����','������','���','����','����','�������','��������','�������','������','�������');
    $seconds = strtotime($input);
    if ($time == true)
        $data = date("j F Y � H:i:s", $seconds);
    else
        $data = date("j F Y", $seconds);
    $data = str_replace($search, $replace, $data);
    return $data;
}

function normaltime2($input, $time = false) {
     return $input;
}


function mkprettytime($s) {
    if ($s < 0)
	$s = 0;
    $t = array();
    foreach (array("60:sec","60:min","24:hour","0:day") as $x) {
		$y = explode(":", $x);
		if ($y[0] > 1) {
		    $v = $s % $y[0];
		    $s = floor($s / $y[0]);
		} else
		    $v = $s;
	$t[$y[1]] = $v;
    }

    if ($t["day"])
	return $t["day"] . "d " . sprintf("%02d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
    if ($t["hour"])
	return sprintf("%d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
	return sprintf("%d:%02d", $t["min"], $t["sec"]);
}

function mkglobal($vars) {
	if (!is_array($vars))
		$vars = explode(":", $vars);
	foreach ($vars as $v) {
		if (isset($_GET[$v]))
			$GLOBALS[$v] = unesc($_GET[$v]);
		elseif (isset($_POST[$v]))
			$GLOBALS[$v] = unesc($_POST[$v]);
		else
			return 0;
	}
	return 1;
}

function tr($x, $y, $noesc=0, $prints = true, $width = "", $relation = '') {
	if ($noesc)
		$a = $y;
	else {
		$a = htmlspecialchars_uni($y);
		$a = str_replace("\n", "<br />\n", $a);
	}
	if ($prints) {
	  $print = "<td width=\"". $width ."\" class=\"heading\" valign=\"top\" align=\"right\">$x</td>";
	  $colpan = "align=\"left\"";
	} else {
		$colpan = "colspan=\"2\"";
	}

	print("<tr".( $relation ? " relation=\"$relation\"" : "").">$print<td valign=\"top\" $colpan>$a</td></tr>\n");
}

function validfilename($name) {
	return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
}


function validimage($file_path,$blank) {
global $CURUSER;

if (!@getimagesize ($file_path)){
stderr ("������ ������", "��� �� �����������!");
}

if ($CURUSER){
$user = $CURUSER["username"];
$user_color = get_user_rgbcolor($CURUSER["class"], $CURUSER["username"]);    
}

        $file_contents = @file_get_contents($file_path);

        $functions_to_shell = array ("include", "file", "fwrite", "script", "body", "java","fopen", "fread", "require", "exec", "system", "passthru", "eval", "copy" );
        foreach ($functions_to_shell as $funct){
       if (preg_match("/" . $funct ."+(\\s||)+[(]/", $file_contents)) {
       	
      $usercomment=$CURUSER["usercomment"];
       	 
     $poput=" $user ������� ������ shell";
     if (!stristr($usercomment,$poput)!==false){
     $usercomment = get_date_time() . " ������� ������ shell.\n". $usercomment;
mysql_query("UPDATE users SET usercomment='$usercomment' WHERE id=" . $CURUSER["id"]) or sqlerr(__FILE__, __LINE__);
     }
       	
    write_log("$blank, $user ������� ������ shell.","$user_color","error");
        stderr("������ ������", "������ ����������� ������ ������ �� ������, � ��� ������������ ����������� ����������� ���� (v2)");
}
}
        
}

function validemail($email)
{
  // First, we check that there's one @ symbol, and that the lengths are right
  if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) {
    // Email invalid because wrong number of characters in one section, or wrong number of @ symbols.
    return false;
  }
  // Split it into sections to make life easier
  $email_array = explode("@", $email);
  $local_array = explode(".", $email_array[0]);
  for ($i = 0; $i < sizeof($local_array); $i++) {
     if (!ereg("^(([A-Za-z0-9!#$%&'*+/=?^_`{|}~-][A-Za-z0-9!#$%&'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i])) {
      return false;
    }
  }
  if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) { // Check if domain is IP. If not, it should be valid domain name
    $domain_array = explode(".", $email_array[1]);
    if (sizeof($domain_array) < 2) {
        return false; // Not enough parts to domain
    }
    for ($i = 0; $i < sizeof($domain_array); $i++) {
      if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$", $domain_array[$i])) {
        return false;
      }
    }
  }
  return true;
}  


function sent_mail($to,$fromname,$fromemail,$subject,$body,$multiple=false,$multiplemail='') {
	global $SITENAME,$SITEEMAIL,$smtptype,$smtp,$smtp_host,$smtp_port,$smtp_from,$smtpaddress,$accountname,$accountpassword;
	# Sent Mail Function v.05 by xam (This function to help avoid spam-filters.)
	
      $result = true;
	if ($smtptype == 'default') {
		@mail($to, $subject, $body, "From: $SITEEMAIL") or $result = false;
	} elseif ($smtptype == 'advanced') {
	# Is the OS Windows or Mac or Linux?
	if (strtoupper(substr(PHP_OS,0,3)=='WIN')) {
		$eol="\r\n";
		$windows = true;
	}
	elseif (strtoupper(substr(PHP_OS,0,3)=='MAC'))
		$eol="\r";
	else
		$eol="\n";
	$mid = md5(getip() . $fromname);
	$name = $_SERVER["SERVER_NAME"];
	$headers .= "From: $fromname <$fromemail>".$eol;
	$headers .= "Reply-To: $fromname <$fromemail>".$eol;
	$headers .= "Return-Path: $fromname <$fromemail>".$eol;
	$headers .= "Message-ID: <$mid thesystem@$name>".$eol;
	$headers .= "X-Mailer: PHP v".phpversion().$eol;
    $headers .= "MIME-Version: 1.0".$eol;
    $headers .= "Content-type: text/plain; charset=windows-1251".$eol;
    $headers .= "X-Sender: PHP".$eol;
    if ($multiple)
    	$headers .= "Bcc: $multiplemail.$eol";
	if ($smtp == "yes") {
		ini_set('SMTP', $smtp_host);
		ini_set('smtp_port', $smtp_port);
		if ($windows)
			ini_set('sendmail_from', $smtp_from);
		}

    	@mail($to, $subject, $body, $headers) or $result = false;

    	ini_restore(SMTP);
		ini_restore(smtp_port);
		if ($windows)
			ini_restore(sendmail_from);
	} elseif ($smtptype == 'external') {

		require_once(ROOT_PATH.'include/functions_smtp.lib.php');
		$mail = new smtp;
            

		
            $mail->debug(false);
		$mail->open($smtp_host, $smtp_port);
		if (!empty($accountname) && !empty($accountpassword))
			$mail->auth($accountname, $accountpassword);
		$mail->from($SITEEMAIL);
		$mail->to($to);
		$mail->subject($subject);
		$mail->body($body);
		$result = $mail->send();
		$mail->close();
	} else
		$result = false;

	return $result;
}

function sqlesc($value) {
	
    $value = str_replace("SHOW", "", $value);
    $value = str_replace("UNION", "", $value);
    $value = str_replace("SELECT", "", $value);
    $value = str_replace("CREATE", "", $value);
    $value = str_replace("UPDATE", "", $value);
    $value = str_replace("DELETE", "", $value);
    $value = str_replace("DROP", "", $value);
    $value = str_replace("INSERT", "", $value);
    $value = str_replace("$mysql_", "", $value);
    $value = str_replace("javascript:", "", $value);

	// Stripslashes
   /*if (get_magic_quotes_gpc()) {
	   $value = stripslashes($value);
   }*/
   // Quote if not a number or a numeric string
   if (!is_numeric($value)) {
	   $value = "'" . mysql_real_escape_string($value) . "'";
   }
   return $value;
}

function sqlwildcardesc($x) {
	return str_replace(array("%","_"), array("\\%","\\_"), mysql_real_escape_string($x));
}

function urlparse($m) {
	$t = $m[0];
	if (preg_match(',^\w+://,', $t))
		return "<a href=\"$t\">$t</a>";
	return "<a href=\"http://$t\">$t</a>";
}

function parsedescr($d, $html) {
	if (!$html) {
	  $d = htmlspecialchars_uni($d);
	  $d = str_replace("\n", "\n<br>", $d);
	}
	return $d;
}
		
function array_size($arr) {
    ob_start();
    print_r($arr);
    $mem = ob_get_contents();
    ob_end_clean();
    $mem = preg_replace("/\n +/", "", $mem);
    $mem = strlen($mem);
    return $mem;
}

function debug($value) {
if (isset($_GET['debug']))
{
echo("<center>");
$num=1;
foreach($GLOBALS as $key=>$value){
    $memEstimate = array_size($value);
    if ($memEstimate>="1000")
    $memEstimate="<b><font color=\"red\">".$memEstimate."</b></font>";
    else
    $memEstimate="<font color=\"blue\">".$memEstimate."</font>";
    echo("[<b>$num</b>]: <b>".$key.'</b> => '.$memEstimate);
    echo("<br>");
    $num++;
}
echo("</center>");
}
}

function stdhead($title = "", $msgalert = true) {
	global $CURUSER, $SITE_ONLINE,$ICE, $SITENAME, $DEFAULTBASEURL, $ss_uri, $tracker_lang, $default_theme;

if (isset($_GET['copyright'])){
 print "<title>�������� ����� $SITENAME</title>
<style>body {background:#0000aa;color:#ffffff;font-family:courier;font-size:12pt;text-align:center;margin:100px;} blink {color:yellow;} p {margin:30px 100px;text-align:left;} a,a:hover {color:inherit;font:inherit;} .menu {text-align:center;margin-top:50px;} </style>
</head><body>
<p><center>���� ������ �� ������ ��� ��������� <b>Tesla Tracker (TT)</b> � ".date("Y")." ����. ����������� �������� <b>7Max7</b> � <b>Imperator</b></center><br/>
* ����� ����������� ������ � ����� ������� ��� ������ ��������� ����������.<br />
* ����� ��������� ������ � ����� ������ ������� ��� ������ ��������� ����������.</p>
���� ������������ �������� ������� ���� ������ ������ <blink>_</blink></div></body>";
die;}

// Closed site notice //
$CLOSE_NOTICE = '<title>���� �������� ��������</title>
<LINK href="pic/favicon.ico" type="image/x-icon" rel="shortcut Icon"><link rel="stylesheet" href="pic/error/css.css" type="text/css"><div align=center><table width="1000" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#194731" height="100%"><tr><td width="125"><img src="pic/error/up_left.gif" alt="" width="125" height="51"></td><td height="51" width="750"><img src="pic/error/the_way.jpg" width="750" height="51"></td><td width="125"><img src="pic/error/up_right.gif" width="125" height="51"></td></tr><tr><td background="pic/error/left_bgx.jpg" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"><tr><td background="pic/error/up_left2.jpg" align="center" height="417" valign="top">&nbsp;</td></tr></table></td><td valign="top" align="center" bgcolor="#66756E" height="100%"><table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"><tr><td><img src="pic/error/logo.jpg" width="750" height="118" border="0"></td></tr><tr><td height="100%"><table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"><tr><td bgcolor="#001F10" width="2" valign="top"><img src="pic/error/pixel.gif" alt="" width="2" height="1"></td><td bgcolor="#96A79D" width="1" valign="top"><img src="pic/error/pixel.gif" alt="" width="1" height="1"></td><td bgcolor="#728079" valign="top" align="center" height="100%"><table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"><b>���� ��������� �� ������� �������������, ����� ���������� ���� ����� ���� ����� ������.<br/><br/>�������� ��� ���� ��������� �� ������������ ����������.<br></table></td><td bgcolor="#001F10" width="2" valign="top"><img src="pic/error/pixel.gif" alt="" width="2" height="1"></td></tr></table></td></tr></table></td><td background="pic/error/right_bgx.jpg" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%"><tr><td background="/pic/error/up_right2.jpg" align="center" valign="top">&nbsp;</td></tr></table></td></tr><tr><td width="125"><img src="/pic/error/down_left.gif" alt="" width="125" height="116"></td><td height="116" background="/pic/error/down.jpg" align="center" valign="bottom" style="padding-bottom: 25px"></td><td width="125"><img src="/pic/error/down_right.gif" alt="" width="125" height="116"></td></tr></table></div>
';
// end notice //

	if (!$SITE_ONLINE)
		die($CLOSE_NOTICE);

	//header("Content-Type: text/html; charset=" . $tracker_lang['language_charset']);
	//header("X-Powered-by: Tesla Tracker TT (2009) - www.muz-tracker.net");
	//header("X-Chocolate-to: ICQ 225454228 (7Max7)");
	//header("Cache-Control: no-cache");
	//header("Pragma: no-cache");
		
			if ($title == "")
			$title = $SITENAME;
		else
			$title = $SITENAME." :.: ".htmlspecialchars_uni($title);

	if (is_numeric($CURUSER["stylesheet"])) 
	{
     	$ss_a = @mysql_fetch_array(@sql_query("SELECT uri FROM stylesheets WHERE id = " . $CURUSER["stylesheet"]));
		if (!is_numeric($ss_a))
		{
		$uri=$ss_a["uri"];
		$userid=$CURUSER["id"];
		sql_query("UPDATE users SET stylesheet='$uri' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
     	$CURUSER["stylesheet"]=$uri;
        header("Location: $DEFAULTBASEURL/index.php");
		}
		else
		$CURUSER["stylesheet"] = $default_theme;
		$uri=$ss_a["uri"];
		$userid=$CURUSER["id"];
		sql_query("UPDATE users SET stylesheet='$default_theme' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
	}
	
	$ss_uri=$CURUSER["stylesheet"];
	
	if (!$CURUSER || !$CURUSER["stylesheet"])
	{
	$ss_uri = $default_theme;
	}
    else
    $ss_uri=$CURUSER["stylesheet"];

	@require_once("themes/" . $ss_uri . "/template.php");
	@require_once("themes/" . $ss_uri . "/stdhead.php");

} // stdhead


//��� ����
function stdheadchat($title = "", $msgalert = true) {
	global $CURUSER, $SITE_ONLINE,$ICE, $SITENAME, $DEFAULTBASEURL, $ss_uri, $tracker_lang, $default_theme;

//header("Content-Type: text/html; charset=" . $tracker_lang['language_charset']);
//header("X-Powered-by: Tesla Tracker TT (2009) - www.muz-tracker.net");
//header("X-Chocolate-to: ICQ 225454228 (7Max7)");
//header("Cache-Control: no-cache");
//header("Pragma: no-cache");
		
		if ($title == "")
			$title = $SITENAME;
		else
			$title = $SITENAME. " :.: " . htmlspecialchars_uni($title);

	if (is_numeric($CURUSER["stylesheet"])) 
	{
     	$ss_a = @mysql_fetch_array(@sql_query("SELECT uri FROM stylesheets WHERE id = " . $CURUSER["stylesheet"]));
		if (!is_numeric($ss_a))
		{
		$uri=$ss_a["uri"];
		$userid=$CURUSER["id"];
		sql_query("UPDATE users SET stylesheet='$uri' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
     	$CURUSER["stylesheet"]=$uri;
        header("Location: $DEFAULTBASEURL/index.php");
		}
		else
		$CURUSER["stylesheet"] = $default_theme;
		$uri=$ss_a["uri"];
		$userid=$CURUSER["id"];
		sql_query("UPDATE users SET stylesheet='$default_theme' WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
	}
	
	$ss_uri=$CURUSER["stylesheet"];
	
	if (!$CURUSER || !$CURUSER["stylesheet"])
	{	
	$ss_uri = $default_theme;
	}
    else
    $ss_uri=$CURUSER["stylesheet"];

	@require_once("themes/" . $ss_uri . "/template.php");
	@require_once("themes/" . $ss_uri . "/stdheadchat.php");

} // stdheadchat


function stdfoot() {
	global $CURUSER, $ss_uri, $tracker_lang, $queries, $tstart, $query_stat, $querytime;
	
    @require_once("themes/" . $ss_uri . "/template.php");
	@require_once("themes/" . $ss_uri . "/stdfoot.php");
		
if ((DEBUG_MODE) && count($query_stat) && (get_user_class() == UC_SYSOP)) {
	
		foreach ($query_stat as $key => $value) {
			print("<div>[<b>".($key+1)."</b>] => <b>
			
		  ".($value["seconds"] < 0.0009 ? "<font color=\"#0468f1\" title=\"������������ ������. ����� ���������� ��������.\">".$value["seconds"]."</font>":"
		  
		  ".($value["seconds"] > 0.01 ? "<font color=\"red\" title=\"������������� �������������� ������. ����� ���������� ��������� �����.\">".$value["seconds"]."</font>" : "<font color=\"blue\" title=\"������ �� ��������� � �����������. ����� ���������� ����������.\">".$value["seconds"]."</font>" )."
		  ")."
			
		</b> [$value[query]]</div>\n");
		}
	///	print("<br />");
	debug($s);
	}
	
	/*
	$r=$GLOBALS["CURUSER"];

		foreach ($r as $key => $value) {
			print("<div>[<b>".($key)."</b>] => $value</div>\n");
		}
	*/
	    //unset($GLOBALS["accountpassword"],$GLOBALS["accountname"]);
	  
	
	
}

function stdfootchat() {
	global $CURUSER, $ss_uri, $tracker_lang,$queries, $tstart, $query_stat, $querytime;

	@require_once("themes/" . $ss_uri . "/template.php");
	@require_once("themes/" . $ss_uri . "/stdfootchat.php");
			
if ((DEBUG_MODE) && count($query_stat)&&(get_user_class() == UC_SYSOP)) {
	
	foreach ($query_stat as $key => $value) {
			print("<div>[<b>".($key+1)."</b>] => <b>
			
		  ".($value["seconds"] < 0.0009 ? "<font color=\"#0468f1\" title=\"������������ ������. ����� ���������� ��������.\">".$value["seconds"]."</font>":"
		  
		  ".($value["seconds"] > 0.01 ? "<font color=\"red\" title=\"������������� �������������� ������. ����� ���������� ��������� �����.\">".$value["seconds"]."</font>" : "<font color=\"blue\" title=\"������ �� ��������� � �����������. ����� ���������� ����������.\">".$value["seconds"]."</font>" )."
		  ")."
			
		</b> [$value[query]]</div>\n");
		}
	
  debug($s);
}
}

function genbark($x,$y) {
	stdhead($y);
	print("<h2>" . htmlspecialchars_uni($y) . "</h2>\n");
	print("<p>" . htmlspecialchars_uni($x) . "</p>\n");
	stdfoot();
	exit();
}

function mksecret($length = 20) {
$set = array("a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","u","U","v","V","w","W","x","X","y","Y","z","Z","1","2","3","4","5","6","7","8","9");
	$str;
	for($i = 1; $i <= $length; $i++)
	{
		$ch = rand(0, count($set)-1);
		$str .= $set[$ch];
	}
	return $str;
}

function httperr($code = 404) {
	$sapi_name = php_sapi_name();
	if ($sapi_name == 'cgi' OR $sapi_name == 'cgi-fcgi') {
	header('Status: 404 Not Found');
	} else {
    header('HTTP/1.1 404 Not Found');
	}
	die;
}

function gmtime() {
	return strtotime(get_date_time());
}

function loggedinorreturn($nowarn = false) {
	global $CURUSER, $DEFAULTBASEURL;
	
if (!$CURUSER) {
$url=$DEFAULTBASEURL."/login.php?returnto=" . htmlentities(basename($_SERVER["REQUEST_URI"]));

if (!headers_sent()) {

header("Location: $DEFAULTBASEURL/login.php?returnto=" . htmlentities(basename($_SERVER["REQUEST_URI"])).($nowarn ? "&nowarn=1" : ""));
die;
}	else 	{
die("��������������� �� �������� ����� ������.<script>setTimeout('document.location.href=\"$url\"', 10);</script>");
	}
///   die("<script>setTimeout('document.location.href=\"$url\"', 10);</script> ������ url");
}

}

function deletetorrent($id) {
    global $torrent_dir;
    $id=(int)$id;
    $res = sql_query("SELECT save_as FROM torrents WHERE id='$id'");
	$row = mysql_fetch_array($res);
	
	if (!empty($row["save_as"])) {
    $id_t=$row["save_as"];
    }
    else
    $id_t=$id;
	

    sql_query("DELETE FROM torrents WHERE id = $id");
    sql_query("DELETE FROM bookmarks WHERE torrentid = $id");  
    sql_query("DELETE FROM snatched WHERE torrent = $id");
    sql_query("DELETE FROM report WHERE torrentid= $id");
    sql_query("DELETE FROM thanks WHERE torrentid= $id");
    //  sql_query("DELETE FROM readtorrents WHERE torrentid= $id");
    sql_query("DELETE FROM checkcomm WHERE checkid= $id AND torrent = 1");
    foreach(explode(".","peers.files.comments.ratings") as $x)
        sql_query("DELETE FROM $x WHERE torrent = $id");
    @unlink(ROOT_PATH."$torrent_dir/$id_t.torrent");
}



function pager2($rpp, $count, $href, $opts = array()) {
	$pages = ceil($count / $rpp);

	if (!$opts["lastpagedefault"])
		$pagedefault = 0;
	else {
		$pagedefault = floor(($count - 1) / $rpp);
		if ($pagedefault < 0)
			$pagedefault = 0;
	}

	if (isset($_GET["page"])) {
		if (!is_numeric($_GET["page"]))
		{
		$page = "0";
		}
		$page = (int) $_GET["page"];
		if ($page < 0)
			$page = $pagedefault;
	}
	else
		$page = $pagedefault;

	   $pager = "<td class=\"pager\">��������:</td><td class=\"pagebr\">&nbsp;</td>";

	$mp = $pages - 1;
	$as = "<b>�</b>";
	if ($page >= 1) {
		$pager .= "<td class=\"pager\">";
		$pager .= "<a href=\"{$href}page=" . ($page - 1) . "\" style=\"text-decoration: none;\">$as</a>";
		$pager .= "</td><td class=\"pagebr\">&nbsp;</td>";
	}

	$as = "<b>�</b>";
	if ($page < $mp && $mp >= 0) {
		$pager2 .= "<td class=\"pager\">";
		$pager2 .= "<a href=\"{$href}page=" . ($page + 1) . "\" style=\"text-decoration: none;\">$as</a>";
		$pager2 .= "</td>$bregs";
	}else	 $pager2 .= $bregs;

	if ($count) {
		$pagerarr = array();
		$dotted = 0;
		$dotspace = 3;
		$dotend = $pages - $dotspace;
		$curdotend = $page - $dotspace;
		$curdotstart = $page + $dotspace;
		for ($i = 0; $i < $pages; $i++) {
			if (($i >= $dotspace && $i <= $curdotend) || ($i >= $curdotstart && $i < $dotend)) {
				if (!$dotted)
				   $pagerarr[] = "<td class=\"pager\">...</td><td class=\"pagebr\">&nbsp;</td>";
				$dotted = 1;
				continue;
			}
			$dotted = 0;
			$start = $i * $rpp + 1;
			$end = $start + $rpp - 1;
			if ($end > $count)
				$end = $count;

			 $text = $i+1;
			if ($i != $page)
				$pagerarr[] = "<td class=\"pager\"><a title=\"$start&nbsp;-&nbsp;$end\" href=\"{$href}page=$i\" style=\"text-decoration: none;\"><b>$text</b></a></td><td class=\"pagebr\">&nbsp;</td>";
			else
				$pagerarr[] = "<td class=\"highlight\"><b>$text</b></td><td class=\"pagebr\">&nbsp;</td>";

				  }
		$pagerstr = join("", $pagerarr);
		$pagertop = "<table class=\"main\"><tr>$pager $pagerstr $pager2</tr></table>\n";
		$pagerbottom = "����� $count �� $i ��������� �� $rpp �� ������ ��������.<br /><br /><table class=\"main\">$pager $pagerstr $pager2</table>\n";
	}
	else {
		$pagertop = $pager;
		$pagerbottom = $pagertop;
	}

	$start = $page * $rpp;

	return array($pagertop, $pagerbottom, "LIMIT $start,$rpp");
}

function pager($rpp, $count, $href, $opts = array()) {
	$pages = ceil($count / $rpp);

	if (!$opts["lastpagedefault"])
		$pagedefault = 0;
	else {
		$pagedefault = ceil($count / $rpp);
		if ($pagedefault < 0)
			$pagedefault = 0;
	}

	if (isset($_GET["page"])) {
		
  $page = (int) $_GET["page"];
		if ($page < 0)
			$page = $pagedefault;
			
}
	else
		$page = $pagedefault;
		
	if ($_GET["page"]=="last"){
		$pagedefault = ceil($count / $rpp);
		$page = $pagedefault;
	}
		

	if ($page==0) {
		$pagipage=1;
	$start = $page  * $rpp;
	}
	else    {
		$pagipage = $page ;
	$start = ($page -1) * $rpp;
	}

    if ($pages<>0){
    	
   	
	if ( fuckIE() ) {
	$pagerr ='<div class="paginator" id="paginator1"></div>
	<div class="paginator_pages">�����: '.$pages. ' ���.</div>
	<script type="text/javascript">
	window.onload = function(){
		pag1 = new Paginator(\'paginator1\', '.$pages.', 20, "'. ($pagipage ) .'", "'.$href.'page=");
		pag2 = new Paginator(\'pag2\', '.$pages.', 20, "'. ($pagipage ) .'", "'.$href.'page=");
		Paginator.resizePaginator(pag1);
		Paginator.resizePaginator(pag2);
	}
	</script>';

	$pagerre ='<div id="dataa">
	<div class="paginator" id="pag2"></div>
	<div class="paginator_pages">���������� �������: '.$pages. ' | �� ���������: '.$rpp.' | ������: '.$count.' </div>';

	} else {
/// ��� ������

/*	pag1 = new Paginator(\'paginator1\', '.$pages.', 20, "'. ($pagipage ) .'", "'.$href.'page="); - ����� �������� window.onload ����
*/
	$pagerr ='<div class="paginator" id="paginator1"></div>
	<div class="paginator_pages">���������� �������: '.$pages. ' | �� ���������: '.$rpp.' | ������: '.$count.' </div>
	<script type="text/javascript">
	window.onload = function(){
	pag1 = new Paginator(\'paginator1\', '.$pages.', 20, "'. ($pagipage ) .'", "'.$href.'page=");
	pag2 = new Paginator(\'pag2\', '.$pages.', 20, "'. ($pagipage ) .'", "'.$href.'page=");
	Paginator.resizePaginator(pag1);
	Paginator.resizePaginator(pag2);
	}
	</script>';

	$pagerre ='<div class="paginator" id="pag2"></div>
	<div class="paginator_pages">���������� �������: '.$pages. ' | �� ���������: '.$rpp.' | ������: '.$count.' </div>
	<script type="text/javascript">
		pag2 = new Paginator(\'pag2\', '.$pages.', 20, "'. ($pagipage ) .'", "'.$href.'page=");
	</script></div>';
}

}

	return array($pagerr, $pagerre, "LIMIT $start,$rpp");
}

function fuckIE() {
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$browserIE = false;
if ( stristr($user_agent, 'MSIE 7.0') ) $browserIE = true;
if ( stristr($user_agent, 'MSIE 6.0') ) $browserIE = true;
if ( stristr($user_agent, 'MSIE 5.0') ) $browserIE = true;
return $browserIE;
}

//// ���������� ��������� �������� ����� 
function info()
{
$sf =ROOT_PATH."cache/info_cache_stat.txt"; 
$fpsf=fopen($sf,"a+"); 
$ip=getip(); 
$ag=getenv("HTTP_USER_AGENT"); 
$from=getenv("HTTP_REFERER"); 
$host=getenv("REQUEST_URI"); 
$date = date("d.m.y"); 
$time= date("H:i:s"); 
fputs($fpsf,"$date#$time#$ip#$ag#$from#$host\n"); 
fclose($fpsf); 
}


function downloaderdata($res) {
	$rows = array();
	$ids = array();
	$peerdata = array();
	while ($row = mysql_fetch_assoc($res)) {
		$rows[] = $row;
		$id = $row["id"];
		$ids[] = $id;
		$peerdata[$id] = array(downloaders => 0, seeders => 0, comments => 0);
	}

	if (count($ids)) {
		$allids = implode(",", $ids);
		$res = sql_query("SELECT COUNT(*) AS c, torrent, seeder FROM peers WHERE torrent IN ($allids) GROUP BY torrent, seeder");
		while ($row = mysql_fetch_assoc($res)) {
			if ($row["seeder"] == "yes")
				$key = "seeders";
			else
				$key = "downloaders";
			$peerdata[$row["torrent"]][$key] = $row["c"];
		}
		$res = sql_query("SELECT COUNT(*) AS c, torrent FROM comments WHERE torrent IN ($allids) GROUP BY torrent");
		while ($row = mysql_fetch_assoc($res)) {
			$peerdata[$row["torrent"]]["comments"] = $row["c"];
		}
	}

	return array($rows, $peerdata);
}

function commenttable($rows, $redaktor = "comment") {
	global $CURUSER, $avatar_max_width;

		
	$count = 0;
	foreach ($rows as $row)	{
			    if ($row["downloaded"] > 0) {
			    	$ratio = $row['uploaded'] / $row['downloaded'];
			    	$ratio = number_format($ratio, 2);
			    } elseif ($row["uploaded"] > 0) {
			    	$ratio = "Infinity";
			    } else {
			    	$ratio = "---";
			    }
			     if (strtotime($row["last_access"]) > gmtime() - 600) {
			     	$online = "online";
			     	$online_text = "� ����";
			     } else {
			     	$online = "offline";
			     	$online_text = "�� � ����";
			     }

	   print("<table width=100% border=1 cellspacing=0 cellpadding=3>");
	   print("<tr><td class=a align=\"left\" colspan=\"2\" height=\"24\">");

    if (isset($row["username"]))
		{
			$title = $row["title"];
			if ($title == ""){
				$title = get_user_class_name($row["class"]);
			}else{
				$title = htmlspecialchars_uni($title);
			}

if ($row["hiderating"]=="yes")
{
$print_ratio="<b>+100%</b>";
}
else
$print_ratio="<img src=\"pic/upl.gif\" alt=\"������\" border=\"0\" width=\"12\" height=\"12\"> ".mksize($row["uploaded"]) ." : <img src=\"pic/down.gif\" alt=\"��������\" border=\"0\" width=\"12\" height=\"12\"> ".mksize($row["downloaded"])." : $ratio";

			   print("
			   ".($CURUSER["class"]>"3" ? "<img src=\"pic/button_".$online.".gif\" alt=\"".$online_text."\" title=\"".$online_text."\" style=\"position: relative; top: 2px;\" border=\"0\" height=\"14\">" : "")."

			   "." <a name=comm". $row["id"]." href=userdetails.php?id=" . $row["user"] . " class=altlink_white ><b>". get_user_class_color($row["class"], htmlspecialchars_uni($row["username"])) . "</b></a> ::"
		       .($row["donor"] == "yes" ? "<img src=pic/star.gif alt='�����'>" : "")
		       
		       .($row["warned"] == "yes" ? "<img src=\"/pic/warned.gif\" alt=\"������������\">" : "") 
			   
			   .($row["enabled"] == "no" ? "<img src=\"/pic/warned2.gif\" alt=\"��������\">" : "") 
			   
			   . " $title :: $print_ratio :: "


 .($CURUSER["cansendpm"]=='yes' && ($CURUSER["id"]<>$row['user'])? " <a href=message.php?action=sendmessage&amp;receiver=".$row['user'].">"."<img src=pic/button_pm.gif border=0 alt=\"��������� ���������\" ></a>" : "")."
			 
			   \n");
	       
		   } else {
          print("".($row["user"] == "0" ? "<font color=gray>[<b>System</b>]</font>" : "���� ������������ ��� ������ [$row[id]]")." \n");
	       }

////�������
$avatar = (($row["avatar"]!= "") ? htmlspecialchars_uni("pic/avatar/".$row["avatar"]) : "");
    if (!$avatar){$avatar = "pic/default_avatar.gif"; }
////�������

  	$text = format_comment($row["text"]);
  	
	if ($CURUSER) {
	$text = str_replace("$CURUSER[username]","<font color=#".get_user_rgbcolor($CURUSER["class"], $CURUSER["username"]).">$CURUSER[username]</font>",$text);
	}
	if ($row["editedby"])
	{ if ($CURUSER["id"] == $row[editedby] || get_user_class() >= UC_MODERATOR)
	 {
	       //$res = mysql_fetch_assoc(sql_query("SELECT * FROM users WHERE id = $row[editedby]")) or sqlerr(__FILE__,__LINE__);
	       
	       $text .= "<p align=right><font size=1 class=small>��������� ��� ��������������� <a href=userdetails.php?id=$row[editedby]><b>
		   ".get_user_class_color($row["classbyname"] ,$row["editedbyname"])."
		   </b></a> � $row[editedat]</font></p>\n";
		   }
	 }
		print("</td></tr>");
		print("<tr valign=top>\n");
	
		print("<td style=\"padding: 0px; width: 5%;\" align=\"center\">
		".($CURUSER["id"]==$row["user"] ? "<a href=\"my.php\"><img alt=\"������, �� ����� ������� � ���������\" title=\"������, �� ����� ������� � ���������\" border=\"0\" src=$avatar width=\"$avatar_max_width\"></a>":"<img src=$avatar width=\"$avatar_max_width\">")."
		
        ".($row["support"]== "yes" ? format_comment($row["supportfor"]) : "")."

		</td>\n");
		print("<td width=100% class=text>");
		//print("<span style=\"float: right\"><a href=\"#top\"><img title=\"Top\" src=\"pic/top.gif\" alt=\"Top\" border=\"0\" width=\"15\" height=\"13\"></a></span>");
		print("$text
		
			".(($row["signatrue"]=="yes" && $row["signature"])? "<p valign=down align=down><hr>".format_comment($row["signature"])."</p>": "")."
		</td>\n");
		print("</tr>\n");
		print("<tr><td class=a align=\"center\" colspan=\"2\">");
		print"<div style=\"float: left; width: auto;\">
		[" . normaltime($row["added"],true) . "]
		</div>";

		print("<div align=\"right\">
		"
			
		.(get_user_class() >= UC_MODERATOR ? "".($row["ip"] ? "[<a href=\"usersearch.php?ip=$row[ip]\" >".$row["ip"]."</a>] " : "���������� " ) : "")
				
		.($row["user"] == "0" ? "" : "
		".($CURUSER["commentpos"] == 'yes' ? "[<a href=\"".$redaktor.".php?action=quote&amp;cid=$row[id]\" >������</a>]":"")."
		
		")

		    .($row["editedby"] && get_user_class() >= UC_MODERATOR ? "
		    ".($CURUSER["commentpos"] == 'yes' ? "[<a href=\"".$redaktor.".php?action=vieworiginal&amp;cid=$row[id]\" >��������</a>]":"")."
			
			" : "")

			.($row["user"] == $CURUSER["id"] || get_user_class() >= UC_MODERATOR ? "
			".($CURUSER["commentpos"] == 'yes' ? "[<a href=".$redaktor.".php?action=edit&amp;cid=$row[id] >��������</a>]":"")."
		
			" : "")
		    .(get_user_class() >= UC_MODERATOR ? "
		    ".($CURUSER["commentpos"] == 'yes' ? "[<a href=\"".$redaktor.".php?action=delete&amp;cid=$row[id]\" >�������</a>]":"")."
			
			" : "")
		    ."
		
		</td></tr>");
		print("</table><br>");
  }

}

function utf8_to_win($string){
for ($c=0;$c<strlen($string);$c++){
$i=ord($string[$c]);
if ($i <= 127) @$out .= $string[$c];
if (@$byte2){
$new_c2=($c1&3)*64+($i&63);
$new_c1=($c1>>2)&5;
$new_i=$new_c1*256+$new_c2;
if ($new_i==1025){
$out_i=168;
} else {
if ($new_i==1105){
$out_i=184;
} else {
$out_i=$new_i-848;
}
}
@$out .= chr($out_i);
$byte2 = false;
}
if (($i>>5)==6) {
$c1 = $i;
$byte2 = true;
}}
return $out;
}

function searchfield($s) {
	return preg_replace(array('/[^a-z0-9]/si', '/^\s*/s', '/\s*$/s', '/\s+/s'), array(" ", "", "", " "), $s);
}

function genrelist() {
	$ret = array();
//$res = sql_query("SELECT id, name FROM categories ORDER BY sort ASC");
//while ($row = mysql_fetch_array($res))

///////// cache
$cache2=new MySQLCache("SELECT id, name,(SELECT COUNT(*) FROM torrents WHERE categories.id=torrents.category) AS num_torrent FROM categories ORDER BY sort ASC", 86400); // ����
while ($row=$cache2->fetch_assoc())
///////// cache

$ret[] = $row;
return $ret;
}

function taggenrelist($cat) {
	$ret = array();
	$res = sql_query("SELECT id, name FROM tags WHERE category=$cat ORDER BY name ASC") or sqlerr(__FILE__, __LINE__); 
	while ($row = mysql_fetch_array($res))
		$ret[] = $row;
	return $ret;
}

function tag_info() {
//$result = sql_query("SELECT DISTINCT name, howmuch FROM tags WHERE howmuch > 0 ORDER BY id DESC");
//while($row = mysql_fetch_assoc($result)) {


///////// cache
$cache=new MySQLCache("SELECT DISTINCT name, howmuch FROM tags WHERE howmuch > 0 and name IS NOT NULL ORDER BY id DESC", 3600); // ��� 
while ($row=$cache->fetch_assoc()){
///////// cache

	
// suck into array
$arr[$row['name']] = $row['howmuch'];
}
//sort array by key
@ksort($arr);

return $arr;
}

function cloud() {
//min / max font sizes
$small = 10;
$big = 32;
//get tag info from worker function
$tags = tag_info();
//amounts
$minimum_count = @min(array_values($tags));
$maximum_count = @max(array_values($tags));
$spread = $maximum_count - $minimum_count;

if($spread == 0) {$spread = 1;}

$cloud_html = '';

$cloud_tags = array();

foreach ($tags as $tag => $count) {

$size = $small + ($count - $minimum_count) * ($big - $small) / $spread;
//set up colour array for font colours.
$colour_array = array('#003EFF', '#0000FF', '#7EB6FF', '#0099CC', '62B1F6');
//spew out some html malarky!
$cloud_tags[] = '<a style="font-weight:normal; color:'.$colour_array[mt_rand(0, 5)].'; font-size: '. floor($size) . 'px'
. '" class="tag_cloud" href="browse.php?tag=' . urlencode($tag) . '&cat=0&incldead=1'
. '" title="��� \''.htmlentities($tag ,ENT_QUOTES, "cp1251").'\' ������� � ' . $count . ' ���������">'
. htmlentities($tag,ENT_QUOTES, "cp1251") . '</a>('.$count.')';
}

$cloud_html = join("\n", $cloud_tags) . "\n";

return $cloud_html;
}



function linkcolor($num) {
	if (!$num)
		return "red";
//	if ($num == 1)
//		return "yellow";
	return "green";
}

function ratingpic($num) {
	global $pic_base_url, $tracker_lang;
	$r = round($num * 2) / 2;
	if ($r < 1 || $r > 5)
		return;
	return "<img src=\"$pic_base_url$r.gif\" border=\"0\" alt=\"".$tracker_lang['rating'].": $num / 5\" />";
}

function writecomment($userid, $comment) {
	$res = sql_query("SELECT modcomment FROM users WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
	$arr = mysql_fetch_assoc($res);

	$modcomment = date("d-m-Y") . " - " . $comment . "" . ($arr[modcomment] != "" ? "\n" : "") . "$arr[modcomment]";
	$modcom = sqlesc($modcomment);

	return sql_query("UPDATE users SET modcomment = $modcom WHERE id = '$userid'") or sqlerr(__FILE__, __LINE__);
}

function checknewnorrent($id, $added)
  {
    global $CURUSER;

      $coo_new = $_COOKIE["markview"];

      $diff_add = preg_replace("/[^0-9]/", "", $added);
      $diff_lch = preg_replace("/[^0-9]/", "", $CURUSER["last_checked"]);
      unset($CURUSER);
      
      if($diff_add > $diff_lch){
       
	   if($coo_new){
        if(explode("-", $coo_new)){
           if(!in_array($id, explode("-", $coo_new)))
           $new_t = true;
           
        }  else  {
           if($coo_new != $id)
           $new_t = true;
        }
        }
         else
        $new_t = true;
      }
      else
     $new_t = false;

     return $new_t;
   }

function torrenttable($res, $variant = "index") {
		global $pic_base_url, $CURUSER, $use_wait, $use_ttl, $ttl_days, $SITENAME, $tracker_lang;

?>
<style>
.effect {FILTER: alpha(opacity=50); -moz-opacity: .50; opacity: .50;}
</style>
<script type="text/javascript" src="js/ajax.js"></script>
<script type="text/javascript">
function getDetails(tid) { var det = document.getElementById('details_'+tid);
if(!det.innerHTML) {
     var ajax = new tbdev_ajax();
     ajax.onShow ('');
     var varsString = "";
     ajax.requestFile = "gettorrentdetails.php";
     ajax.setVar("tid", tid);
     ajax.method = 'POST';
     ajax.element = 'details_'+tid;
     ajax.sendAJAX(varsString); } else  det.innerHTML = '';}
</script>
<div id="loading-layer" style="display:none;font-family: Verdana;font-size: 11px;width:200px;height:50px;background:#FFF;padding:10px;text-align:center;border:1px solid #000">
     <div style="font-weight:bold" id="loading-layer-text">�������� ������. ����������, ���������...</div><br />
     <img src="pic/loading.gif" border="0" />
</div>
<?

  if ($use_wait)
  if (($CURUSER["class"] < UC_VIP) && $CURUSER) {
		  $gigs = $CURUSER["uploaded"] / (1024*1024*1024);
		  $ratio = (($CURUSER["downloaded"] > 0) ? ($CURUSER["uploaded"] / $CURUSER["downloaded"]) : 0);
		  if ($ratio < 0.5 || $gigs < 5) $wait = 48;
		  elseif ($ratio < 0.65 || $gigs < 6.5) $wait = 24;
		  elseif ($ratio < 0.8 || $gigs < 8) $wait = 12;
		  elseif ($ratio < 0.95 || $gigs < 9.5) $wait = 6;
		  else $wait = 0;
  }

print("<tr>\n");

$count_get = 0;

foreach ($_GET as $get_name => $get_value) {

$get_name = mysql_escape_string(strip_tags(str_replace(array("\"","'"),array("",""),$get_name)));

$get_value = mysql_escape_string(strip_tags(str_replace(array("\"","'"),array("",""),$get_value)));

if ($get_name != "sort" && $get_name != "type") {
if ($count_get > 0) {
$oldlink = $oldlink . "&" . $get_name . "=" . $get_value;
} else {
$oldlink = $oldlink . $get_name . "=" . $get_value;
}
$count_get++;
}

}

if ($count_get > 0) {
$oldlink = $oldlink . "&";
}


if ($_GET['sort'] == "1") {
if ($_GET['type'] == "desc") {
$link1 = "asc";
} else {
$link1 = "desc";
}
}

if ($_GET['sort'] == "2") {
if ($_GET['type'] == "desc") {
$link2 = "asc";
} else {
$link2 = "desc";
}
}

if ($_GET['sort'] == "3") {
if ($_GET['type'] == "desc") {
$link3 = "asc";
} else {
$link3 = "desc";
}
}

if ($_GET['sort'] == "4") {
if ($_GET['type'] == "desc") {
$link4 = "asc";
} else {
$link4 = "desc";
}
}

if ($_GET['sort'] == "5") {
if ($_GET['type'] == "desc") {
$link5 = "asc";
} else {
$link5 = "desc";
}
}

if ($_GET['sort'] == "7") {
if ($_GET['type'] == "desc") {
$link7 = "asc";
} else {
$link7 = "desc";
}
}

if ($_GET['sort'] == "8") {
if ($_GET['type'] == "desc") {
$link8 = "asc";
} else {
$link8 = "desc";
}
}

if ($_GET['sort'] == "9") {
if ($_GET['type'] == "desc") {
$link9 = "asc";
} else {
$link9 = "desc";
}
}

if ($_GET['sort'] == "10") {
if ($_GET['type'] == "desc") {
$link10 = "asc";
} else {
$link10 = "desc";
}
}

if ($link1 == "") { $link1 = "asc"; } // for torrent name
if ($link2 == "") { $link2 = "desc"; }
if ($link3 == "") { $link3 = "desc"; }
if ($link4 == "") { $link4 = "desc"; }
if ($link5 == "") { $link5 = "desc"; }
if ($link7 == "") { $link7 = "desc"; }
if ($link8 == "") { $link8 = "desc"; }
if ($link9 == "") { $link9 = "desc"; }
if ($link10 == "") { $link10 = "desc"; }

?>
<td class="colhead" align="center"><?=$tracker_lang['type'];?></td>
<td class="colhead" align="left"><a href="browse.php?<? print $oldlink; ?>sort=1&type=<? print $link1; ?>" class="altlink_white"><?=$tracker_lang['name'];?></a> / <a href="browse.php?<? print $oldlink; ?>sort=4&type=<? print $link4; ?>" class="altlink_white"><?=$tracker_lang['added'];?></a></td>

<?
if ($wait)
	print("<td class=\"colhead\" align=\"center\">".$tracker_lang['wait']."</td>\n");

if ($variant == "mytorrents")
	print("<td class=\"colhead\" align=\"center\">".$tracker_lang['visible']."</td>\n");


?>
<td class="colhead" align="center"><a href="browse.php?<? print $oldlink; ?>sort=2&type=<? print $link2; ?>" class="altlink_white">
<img title="���������� �� ���������� ������" src="pic/browse/nimberfiles.gif" border="0">
</a></td>
<td class="colhead" align="center"><a href="browse.php?<? print $oldlink; ?>sort=3&type=<? print $link3; ?>" class="altlink_white">
<img title="���������� �� ���������� ���������" src="pic/browse/comments.gif" border="0">
</a></td>
<? if ($use_ttl) {
?>
	<td class="colhead" align="center"><?=$tracker_lang['ttl'];?></td>
<?
}
?>
<td class="colhead" align="center"><a href="browse.php?<? print $oldlink; ?>sort=5&type=<? print $link5; ?>" >
<img title="���������� �� �������" src="pic/browse/size_file.gif" border="0">
</a></td>

<td class="colhead" align="center"><a href="browse.php?<? print $oldlink; ?>sort=7&type=<? print $link7; ?>" >
<img title="���������� �� ��������� �����" src="pic/browse/up.gif" border="0">
</a> <a href="browse.php?<? print $oldlink; ?>sort=8&type=<? print $link8; ?>"><img title="���������� �� ��������� �����" src="pic/browse/down.gif" border="0"></a>
</td>
<?

if ($variant == "index" || $variant == "bookmarks")
	print("<td class=\"colhead\" align=\"center\"><a href=\"browse.php?{$oldlink}sort=9&type={$link9}\" class=\"altlink_white\">".$tracker_lang['uploadeder']."</a></td>\n");

	
if ($variant == "index") 
            print("<td class=\"colhead\" align=\"center\">
			".($CURUSER ? "<a href=\"browse.php?{$oldlink}sort=10&type={$link10}\" class=\"altlink_white\">��������</a>":"��������")."
			</td>");


if ((get_user_class() >= UC_MODERATOR) && $variant == "index")
	print("<td class=\"colhead\" align=\"center\">
	<img title=\"�������\" src=\"pic/browse/delete.gif\" border=\"0\"></td>\n");

if ($variant == "bookmarks")
	print("<td class=\"colhead\" align=\"center\">".$tracker_lang['delete']."</td>\n");

print("</tr>\n");

print("<tbody id=\"highlighted\">");

if ((get_user_class() >= UC_MODERATOR) && $variant == "index")
	print("<form method=\"post\" action=\"deltorrent.php?mode=delete\">");

	if ($variant == "bookmarks")
		print ("<form method=\"post\" action=\"takedelbookmark.php\">");

	while ($row = mysql_fetch_assoc($res)) {
		$id = $row["id"];
		print("<tr".($row["sticky"] == "yes" ? " class=\"highlight\"" : "").">\n");


// ��������� ������� �� ����

/** Make some date varibles **/
$day_added = $row['added'];
$day_show = strtotime($day_added);
$thisdate = date('Y-m-d',$day_show);

///$numtorrents = number_format(get_row_count("torrents", "WHERE added LIKE '%".$thisdate." %'"));


/** If date already exist, disable $cleandate varible **/
if($thisdate==$prevdate){
$cleandate = '';

/** If date does not exist, make some varibles **/
}else{
$day_added = ''.date('��������, ����������� �l, j M Y ����', strtotime($row['added'])); // You can change this to something else
$cleandate = "<tr><td colspan=15 class=colhead><b>$day_added</b></td></tr>\n"; // This also...
}

/** Prevent that "torrents added..." wont appear again with the same date **/
$prevdate = $thisdate;

$man = array(
    'Jan' => '������',
    'Feb' => '�������',
    'Mar' => '�����',
    'Apr' => '������',
    'May' => '���',
    'Jun' => '����',
    'Jul' => '����',
    'Aug' => '�������',
    'Sep' => '��������',
    'Oct' => '�������',
    'Nov' => '������',
    'Dec' => '�������'
);

foreach($man as $eng => $ger){
    $cleandate = str_replace($eng, $ger,$cleandate);
}

$dag = array(
    'Mon' => ' �����������',
    'Tues' => '� �������',
    'Wednes' => ' �����',
    'Thurs' => ' �������',
    'Fri' => ' �������',
    'Satur' => ' �������',
    'Sun' => ' �����������'
);

foreach($dag as $eng => $ger){
    $cleandate = str_replace($eng.'day', $ger.'',$cleandate);
}
/** If torrents not listed by added date **/
if ($row["sticky"] == "no") // delete this line if you dont have sticky torrents or you want to display the addate for them also
if(!$_GET['sort'] && !$_GET['d']){
   echo $cleandate."\n";
}

// ��������� ������� �� ����  



	//	print("<td align=\"center\" style=\"padding: 0px\">");
		
		print("<tr>");
print("<td align=\"center\" class=\"b\" rowspan=2 width=2% style=\"padding: 5px\">");  
		
	
		if (isset($row["cat_name"])) {
			print("<a href=\"browse.php?incldead=1&cat=" . $row["category"] . "\">");
			if (isset($row["cat_pic"]) && $row["cat_pic"] != "")
				print("<img border=\"0\" class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" src=\"pic/cats/" . $row["cat_pic"] . "\" alt=\"" . $row["cat_name"] . "\" />");
			else
				print($row["cat_name"]);
			print("</a>");
		}
		else
			print("-");
		print("</td>\n");


		$dispname = $row["name"];
		
		$dispname = "". format_comment($row['name']) . "";
       //$dispname=strlen($dispname)>70?(substr($dispname,0,50)."..."):$dispname; 
		
		$thisisfree = ($row[free]=="yes" ? "<img src=\"pic/freedownload.gif\" title=\"".$tracker_lang['golden']."\" alt=\"".$tracker_lang['golden']."\">" : "");
	
	
/*	print("<td align=\"left\">".($row["sticky"] == "yes" ? "<b>������</b>: " : "")."
<img style=\"cursor:pointer;\" border=\"0\" src=\"pic/external.gif\" alt=\"������������\" title=\"������������\" onclick=\"getDetails('" .$id. "');\" /> <a href=\"details.php?");
	*/
	
print("<td colspan=\"12\" class=\"b\" align=\"left\">".($row["sticky"] == "yes" ? "������: " : "")."
<img style=\"cursor:pointer;\" src=\"pic/external.gif\" alt=\"������������\" title=\"������������\" onclick=\"getDetails('" .$id. "');\" /> 
  ".($CURUSER ? "<a href=\"details.php?" : "")."");

	//check if the torrent is new, by qwertzuiop
    if (checknewnorrent($row["id"], $row["added"]) && $CURUSER) {
    $thisische="<b><font color=\"red\" size=\"1\">[�����]</font></b>". $diff;
    }
    else
    unset($thisische);
    
	
	//	if ($variant == "mytorrents")
		//	print("returnto=" . htmlentities($_SERVER["REQUEST_URI"]) . "&amp;");
		print("".($CURUSER ? "id=$id" : "")."");
		if ($variant == "index" || $variant == "bookmarks")
		print("".($CURUSER ? "&amp;hit=1" : "")."");

		print("".($CURUSER ? "\">" : "")."<b><span title='".$row["name"]."'>".$dispname."<span></b>".($CURUSER ? "</a>" : "")." $thisisfree $thisische\n");
$bookcomm=$row["bookcomm"];
$checkcomm=$row["checkcomm"];
 if (!$checkcomm)(
 $check = "<a href=\"comment.php?action=check&amp;tid=$row[id]\"><img border=\"0\" src=\"pic/head2_2.gif\" alt=\"�������� ��������\" title=\"�������� ��������\" /></a>") ;
 else
 $check = "<a href=\"comment.php?action=checkoff&amp;tid=$row[id]\"><img class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" border=\"0\" src=\"pic/head2_2.gif\" alt=\"��������� ��������\" title=\"��������� ��������\" /></a>";
 
  if (!$bookcomm)(
 $books = "<a href=\"bookmark.php?torrent=$row[id]&take=add\"><img border=\"0\" src=\"pic/bookmark.gif\" alt=\"".$tracker_lang['bookmark_this']."\" title=\"".$tracker_lang['bookmark_this']."\" /></a>");
 else
 $books = "<a href=\"bookmark.php?torrent=$row[id]&take=delete\"><img class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" border=\"0\" src=\"pic/bookmark.gif\" alt=\"������ � ��������\" title=\"������ � ��������\" /></a>";
 

if ($variant != "bookmarks" && $CURUSER)
print("$books\n");


if ($variant != "bookmarks" && $CURUSER)
print("$check\n");


/*
// name torrent in links
$fname = $row["filename"]; 
$fname = explode(".torrent", $fname); 
$fnamenew = $fname[0].".[$SITENAME].torrent";  
*/

if (get_user_class() >= UC_ADMINISTRATOR)
			print("<a href=\"download.php?id=$id\"><img src=\"pic/download.gif\" border=\"0\" alt=\"".$tracker_lang['download']."\" title=\"".$tracker_lang['download']."\"></a>\n");


		if ($CURUSER["id"] == $row["owner"] || get_user_class() >= UC_MODERATOR)
			$owned = 1;
		else
			$owned = 0;

				if ($owned)
			print("<a href=\"edit.php?id=$row[id]\"><img border=\"0\" src=\"pic/pen.gif\" alt=\"".$tracker_lang['edit']."\" title=\"".$tracker_lang['edit']."\" /></a>\n");



print("</td></tr><tr>");
print("<td class=\"row2\" align=\"left\" class=\"small\">");  
    

if ($row["tags"]){

foreach(explode(",", $row["tags"]) as $tag) {
	
if ($tags[$row[id]])
$tags[$row[id]].=", ";
     
$tags[$row[id]].= "<a style=\"font-weight:normal;\" href=\"browse.php?tag=".urlencode($tag)."&incldead=1\">".tolower($tag)."</a>";
}
    $tags[$row[id]]="".$tags[$row[id]]."";
}
else
$tags[$row[id]]="�� �������";


if ($tags[$row[id]])
print("<br/><b>����</b>: ".$tags[$row[id]]." ".(strlen($tags[$row[id]])>200 ? "&nbsp; <br>":"")."");

$banned_view=htmlspecialchars($row["banned_reason"]);
if ($row["banned"] == "yes")
print(" <b>[</b>".normaltime($row["added"],true)."<b>]</b><br>
".(get_user_class() < UC_MODERATOR ? "�������.": "<b>������� �� �������</b>: 
".($banned_view=="" ? "�� ��������" : "$banned_view")."
")."");
else 
{


print("<b>��������</b>: ".timesec($row["added"])."");

if ($variant <> "mytorrents" && $variant <> "bookmarks" && $CURUSER ) {
$rpic = ratingpic($row["rating"]);
if ($row["rating"])
print"&nbsp; <b>������</b>: ".$row["rating"]."";
else
print"&nbsp; <b>������</b>: ���";
}

}


	               if ($wait)
								{
								  $elapsed = floor((gmtime() - strtotime($row["added"])) / 3600);
				if ($elapsed < $wait)
				{
				  $color = dechex(floor(127*($wait - $elapsed)/48 + 128)*65536);
				  print("<td class=\"row2\" align=\"center\"><nobr><font color=\"$color\">" . number_format($wait - $elapsed) . " h</font></nobr></td>\n");
				}
				else
				  print("<td class=\"row2\" align=\"center\"><nobr>".$tracker_lang['no']."</nobr></td>\n");
		}

	print("</td>\n");

		if ($variant == "mytorrents") {
			print("<td class=\"row2\" align=\"center\">");
			if ($row["visible"] == "no")
				print("<font color=\"red\"><b>".$tracker_lang['no']."</b></font>");
			else
				print("<font color=\"green\">".$tracker_lang['yes']."</font>");
			print("</td>\n");
		}

		if ($row["type"] == "single")
			print("<td class=\"row2\" align=\"center\">" . $row["numfiles"] . "</td>\n");
		else {
			if ($variant == "index")
				print("<td class=\"row2\" align=\"center\"><b>
				
					".($CURUSER ? "<a href=\"details.php?id=$id&amp;hit=1&amp;filelist=1\">" : "")."
				" . $row["numfiles"] . "
				
					".($CURUSER ? "</a>" : "")."
				</b></td>\n");
			else
				print("<td class=\"row2\" align=\"center\"><b><a href=\"details.php?id=$id&amp;filelist=1#filelist\">" . $row["numfiles"] . "</a></b></td>\n");
		}

		if (!$row["comments"])
			print("<td class=\"row2\" align=\"center\">" . $row["comments"] . "</td>\n");
		else {
			if ($variant == "index")
				print("<td class=\"row2\" align=\"center\"><b>
				".($CURUSER ? "<a href=\"details.php?id=$id&amp;hit=1&amp;tocomm=1\">" : "")."
							
				" . $row["comments"] . "
				
				".($CURUSER ? "</a>" : "")."
				</b></td>\n");
			else
				print("<td class=\"row2\" align=\"center\"><b><a href=\"details.php?id=$id&amp;page=0#startcomments\">" . $row["comments"] . "</a></b></td>\n");
		}

//		print("<td align=center><nobr>" . str_replace(" ", "<br />", $row["added"]) . "</nobr></td>\n");
				$ttl = ($ttl_days*24) - floor((gmtime() - sql_timestamp_to_unix_timestamp($row["added"])) / 3600);
				if ($ttl == 1) $ttl .= " ���"; else $ttl .= "&nbsp;�����";
		if ($use_ttl)
			print("<td class=\"row2\" align=\"center\">$ttl</td>\n");
	//	print("<td align=\"center\">" . str_replace(" ", "<br />", mksize($row["size"])) . "</td>\n");

print("<td class=\"row2\" align=\"center\">" . str_replace(" ", " ", mksize($row["size"])) . "</td>\n");


		print("<td class=\"row2\" align=\"center\">");
       
      // if (!empty($row["webseed"])){
 	  // $row["seeders"]=$row["seeders"]+1;
      // }


		if ($row["seeders"] || $row["f_seeders"]) {
			if ($variant == "index")
			{
			   if ($row["leechers"]) $ratio = $row["seeders"] / $row["leechers"]; else $ratio = 1;
				print("<b>
					".($CURUSER ? "<a href=\"details.php?id=$id&amp;hit=1&amp;toseeders=1\">" : "")."
			
				<font color=".get_slr_color($ratio).">" . ($row["seeders"]+$row["f_seeders"]) . "</font>
					".($CURUSER ? "</a>" : "")."
				</b>\n");
			}
			else
				print("<b>
				
					".($CURUSER ? "<a class=\"row2\" class=\"" . linkcolor($row["seeders"]+$row["f_seeders"]) . "\" href=\"details.php?id=$id&amp;dllist=1#seeders\">" : "")."
				" . ($row["seeders"]+$row["f_seeders"]). "
				  	".($CURUSER ? "</a>" : "")."
				  
			       </b>\n");
		}
		else
			print("<span class=\"" . linkcolor($row["seeders"]+$row["f_seeders"]) . "\">" . ($row["seeders"]+$row["f_seeders"]) . "</span>");

		print(" | ");

		if ($row["leechers"] || $row["f_leechers"]) {
			if ($variant == "index")
				print("<b>
				<a href=\"details.php?id=$id&amp;hit=1&amp;todlers=1\">
				" . number_format($row["leechers"]+$row["f_leechers"]) . ($peerlink ? "</a>" : "") .
				   "</b>\n");
			else
				print("<b>
					".($CURUSER ? "<a class=\"" . linkcolor($row["leechers"]+$row["f_leechers"]) . "\" href=\"details.php?id=$id&amp;dllist=1#leechers\">" : "")."
				
				" .($row["leechers"]+$row["f_leechers"]). "
				  
				    	".($CURUSER ? "</a>" : "")."
				  </b>\n");
		}
		else
			print("0\n");

		print("</td>");

		if ($variant == "index" || $variant == "bookmarks")
			print("<td class=\"row2\" align=\"center\">" . (isset($row["username"]) ? ("
			<a href=\"userdetails.php?id=" . $row["owner"] . "\">
			
			<b>" . get_user_class_color($row["class"], htmlspecialchars_uni($row["username"])) . "</b>
		
			  	</a>
			") : "<i>��� ������</i>") . "</td>\n");

		if ($variant == "bookmarks")
			print ("<td class=\"row2\" align=\"center\"><input type=\"checkbox\" name=\"delbookmark[]\" value=\"" . $row[bookmarkid] . "\" /></td>");



		if ((get_user_class() >= UC_SYSOP) && $row["moderated"] == "yes")(
		$sysop = "<br>[<b><a href=checkdelete.php?id=$id>�������</a></b>]");
		
		
		
		if ((get_user_class() >= UC_MODERATOR) && $variant == "index") 
		
		       if ($row["moderated"] == "no")

            {if ($CURUSER["id"] == $row["owner"])
            print("<td class=\"row2\" align=\"center\">
		 <b>
		 	<font color=\"#".get_user_rgbcolor($CURUSER["class"], $CURUSER[username])."\">����</font> </b>
	</td>\n");

            else

            print("<td class=\"row2\" align=\"center\">
			
			<a class =\"hover\"href=check.php?id=$id>
			<b>��������</b>
			
			</a>
		
			</td>\n");}

            else
            
       
		
                print("<td class=\"row2\"align=\"center\"><b>
                
			".($row["classusername"] ? "<a href=\"userdetails.php?id=$row[moderatedby]\">".get_user_class_color($row["classname"], $row["classusername"])."</a>" : "id [$row[moderatedby]]")."

				
				</b>$sysop</td>
				\n");
				

	if ((get_user_class() <= UC_UPLOADER) && $variant == "index") 
		
			
		       if ($row["moderated"] == "no")
          
            print("<td class=\"row2\" align=\"center\">
			<b>���</b></td>\n");

            else
                print("<td class=\"row2\" align=\"center\"><b>
  
     	".($row["classname"] ? "<a href=\"userdetails.php?id=$row[moderatedby]\">".get_user_class_color($row["classname"], $row["classusername"])."</a>" : "id [$row[moderatedby]]")."
                	
 
				
				</b></td>
				\n");

		/*	if ($row["moderated"] == "no")
				print("<td align=\"center\"><font color=\"red\"><b>���</b></font></td>\n");
			else
				print("<td align=\"center\"><a href=\"userdetails.php?id=$row[moderatedby]\"><font color=\"green\"><b>��</b></font></a></td>\n");
		}*/
		
		if ((get_user_class() >= UC_MODERATOR) && $variant == "index")
			print("<td class=\"row2\" align=\"center\"><input type=\"checkbox\" name=\"delete[]\" value=\"" . $id . "\" /></td>\n");


print("</tr><tr><td colspan=10><span id=\"details_" .$id. "\"></span></td>");  

print("</tr>\n");
$oldday = $day; // ������ ����
}
print("</tbody>");  
	
	
	

	if ($variant == "index" && $CURUSER)
		print("<tr><td class=\"colhead\" colspan=\"12\" align=\"center\"><a href=\"markread.php\" class=\"altlink_white\">��� �������� ���������</a></td></tr>");

	//print("</table>\n");

	if ($variant == "index") {
		if (get_user_class() >= UC_MODERATOR) {
			print("<tr><td align=\"right\" colspan=\"12\"><input type=\"submit\" value=\"�������\"></td></tr>\n");
		}
	}

	if ($variant == "bookmarks")
		print("<tr><td colspan=\"12\" align=\"right\"><input type=\"submit\" value=\"".$tracker_lang['delete']."\"></td></tr>\n");

	if ($variant == "index" || $variant == "bookmarks") {
		if (get_user_class() >= UC_MODERATOR) {
			print("</form>\n");
		}
	}

	return $rows;
}

function hash_pad($hash) {
	return str_pad($hash, 20);
}

function hash_where($name, $hash) {
	$shhash = preg_replace('/ *$/s', "", $hash);
	return "($name = " . sqlesc($hash) . " OR $name = " . sqlesc($shhash) . ")";
}

function get_user_icons($arr, $big = false) {
		if ($big) {
				$donorpic = "starbig.gif";
				$warnedpic = "warned.gif";
				$disabledpic = "disabled.gif";
				$style = "style='margin-left: 4pt'";
		} else {
				$donorpic = "star.gif";
				$warnedpic = "warned.gif";
				$disabledpic = "disabled.gif";
			//	$parkedpic = "parked.gif";
				$style = "style=\"margin-left: 2pt\"";
		}
		$pics = $arr["donor"] == "yes" ? "<img src=\"pic/$donorpic\" alt='��� �������� �����!' border=\"0\" $style>" : "";
		if ($arr["enabled"] == "yes")
		
		$pics .= $arr["num_warned"] >= "1" || $arr["warned"] == "yes" ? "<img src=pic/$warnedpic alt=\"������������\" border=0 $style>" : "";
		
		else
		
		$pics .= "<img src=\"pic/$disabledpic\" alt=\"��������\" border=\"0\" $style>\n";
		
		$pics .= $arr["parked"] == "yes" ? "<img src=pic/head2_2.gif alt=\"����������� �������\" border=\"0\" $style>" : "";
		return $pics;
}

function parked() {
	   global $CURUSER;
	   if ($CURUSER["parked"] == "yes")
		  stderr($tracker_lang['error'], "��� ������� �����������.");
}



//��������� �������
function generatePassword($length = 15) {
$set = array("a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","u","U","v","V","w","W","x","X","y","Y","z","Z","1","2","3","4","5","6","7","8","9");
	$str;
	for($i = 1; $i <= $length; $i++)
	{
		$ch = rand(0, count($set)-1);
		$str .= $set[$ch];
	}
	return $str;
}
//��������� �������

/// ���������
function location($url, $time = 0) {
	//global $DEFAULTBASEURL;
	$url = str_replace ( ">", urlencode ( ">" ), str_replace ( "<", urlencode ( "<" ), $url ) );
	//if (! preg_match ( "#http://(.*?)#si", $url ))
	//	$url = $DEFAULTBASEURL . '/' . $url;
	if (! @header ( (! $time ? "Location: " : "Refresh: " . $time . ", url=") . $url ))
		print ( '<META HTTP-EQUIV="Refresh" CONTENT="' . $time . ';url=' . $url . '/">' );
}


function cache_clean($all) {

$dh = opendir(ROOT_PATH.'cache/');
while ($file = readdir($dh)) :
if (preg_match('/^(.+)\.$/si', $file, $matches))
$file = $matches[1];
if ( stristr($file,'txt') && !stristr($file,'log_old.txt') && !stristr($file,'sqlerror.txt') && !stristr($file,'hacklog.txt') && !stristr($file,'monitoring_') && !stristr($file,'info_cache_stat') && !stristr($file,'chat_log.txt')&& !stristr($file,'error_torrent.txt')&& !stristr($file,'list.txt') )
{ @unlink(ROOT_PATH."cache/$file");}
endwhile;
closedir($dh);

}

function parse_referer($cache) {
global $refer_parse;

$referer = $_SERVER['HTTP_REFERER'];
$site = parse_url($referer, PHP_URL_HOST);

$site_own = (($_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://").htmlspecialchars_uni($_SERVER['HTTP_HOST']);

//echo "$referer,$site_own";

if($refer_parse==1 && $site_own <> $site && !empty($site) && !stristr($referer,$site_own)!== false){

if (validip_pmr()==1){
/// ��� ������
$n="num_out";
$update[] = "num_out = num_out + 1";

} else {
/// ���������� ip
$n="num_in";
$update[] = "num_in = num_in + 1";
}

///&& "www.".$_SERVER["SERVER_NAME"] != $site 
if (!stristr($site,'www')!== false){
$site="www.".$site;
}
//echo "$referer y $site_own";
$referer - str(urldecode($referer));
$referer_sql = sqlesc($referer);
$site_sql = sqlesc($site);
$time = sqlesc(get_date_time());

$a = (mysql_fetch_row(sql_query("select COUNT(*) FROM referrers WHERE refsite= 
'" . sqlwildcardesc($site) . "'"))) or sqlerr(__FILE__, __LINE__);

if ($a[0] == 0){
sql_query("INSERT INTO referrers (url, refsite, added, $n) VALUES ($referer_sql,$site_sql,$time,1)") or sqlerr(__FILE__, __LINE__);
if ($cache=="delcache" && date('i')>=30)
@unlink(ROOT_PATH."cache/block-top_refer.txt");
} else {
//$update[] = "num = num + 1";
$update[] = "lastdate = $time";
$update[] = "url = $referer_sql";

sql_query("UPDATE referrers SET " . implode(", ", $update) . " where refsite='" . sqlwildcardesc($site) . "'") or sqlerr(__FILE__, __LINE__);
if ($cache=="delcache")
@unlink(ROOT_PATH."cache/block-top_refer.txt");
}
}
}


function failedloginscheck () {
global $maxloginattempts;
$total = 0;
$ip = sqlesc(getip());
$Query = sql_query("SELECT SUM(attempts) FROM loginattempts WHERE ip=$ip") or sqlerr(__FILE__, __LINE__);
list($total) = mysql_fetch_array($Query);
if ($total >= $maxloginattempts) {
sql_query("UPDATE loginattempts SET banned = 'yes' WHERE ip=$ip") or sqlerr(__FILE__, __LINE__);
stderr("���� ������������!", "�� ������������ <b>�������� ���������� ��� - $maxloginattempts</b> � ������ ������������ ������<br>������ ��� <b>".htmlspecialchars(getip())."</b> �������.");
}}

function failedlogins ($user,$id) {
$usermy=$user;
//	die($usermy);
$a_comment="$user,";
$a_id="$id,";
$ip = sqlesc(getip());
$ip_log = getip();
$added = sqlesc(get_date_time());
$a = (mysql_fetch_row(sql_query("select COUNT(*) from loginattempts where ip=$ip"))) or sqlerr(__FILE__, __LINE__);
//die($a[0]);
$upd=remaining();
if($upd==1)
{
global $maxloginattempts;

  $type = sqlesc("bans");
  $color = sqlesc("6e7d8f");
  $text = sqlesc("������������ ������������ ���� $ip_log. �������: ������� ����� - $maxloginattempts");
  $added = sqlesc(get_date_time());
  sql_query("INSERT INTO sitelog (added, color, txt, type) VALUES($added, $color, $text, $type)");
}

if ($a[0] == 0)
{
sql_query("INSERT INTO loginattempts (ip, added, attempts, comment) VALUES ($ip,$added,1,'$id')") or sqlerr(__FILE__, __LINE__);
}
else
{
$update[] = "attempts = attempts + 1";
$update[] = "comment = CONCAT(".sqlesc($a_id)." ,comment)";
sql_query("UPDATE loginattempts SET " . implode(", ", $update) . " where ip=$ip") or sqlerr(__FILE__, __LINE__);
}

$upd2=$upd-1;
stderr("������ �����", "������ � ������� ������ ($user) �������<br> ���� �� ������� ������, ���������� <b><a href=recover.php>������������</a></b> ���.<br>
�������� ������� �����: <b>".$upd2."</b>");
}

function remaining () {
global $maxloginattempts;
$total = 0;
$ip = sqlesc(getip());
$Query = sql_query("SELECT SUM(attempts) FROM loginattempts WHERE ip=$ip") or sqlerr(__FILE__, __LINE__);
list($total) = mysql_fetch_array($Query);
$remaining = $maxloginattempts - $total;
/*if ($remaining <= 2 )
$remaining = "<font color=red size=4>".$remaining."</font>";
else
$remaining = "<font color=green size=4>".$remaining."</font>";
*/
return $remaining;
}




/// �������� �� xss ������
foreach ($_GET as $check_url) {

/*
if ( stristr($check_url,'src=') &&  (stristr($check_url,'.js')))
{
	write_log("". $CURUSER["username"]." - ".format_comment($check_url)." ����� GET.","","other");
}
*/
if (!is_array($check_url)) {
		
$check_url = str_replace('script', '', $check_url);
$check_url = str_replace('.js', '', $check_url);
$check_url = str_replace('src=', '', $check_url); 
//$check_url = str_replace('src=', '', $check_url); 
		
	/*	
		$check_url = str_replace("\"", "", $check_url);
		if ((eregi("<[^>]*script*\"?[^>]*>", $check_url)) || (eregi("<[^>]*object*\"?[^>]*>", $check_url)) ||
			(eregi("<[^>]*iframe*\"?[^>]*>", $check_url)) || (eregi("<[^>]*applet*\"?[^>]*>", $check_url)) ||
			(eregi("<[^>]*meta*\"?[^>]*>", $check_url)) || (eregi("<[^>]*style*\"?[^>]*>", $check_url)) ||
			(eregi("<[^>]*form*\"?[^>]*>", $check_url))  ||
			(eregi("\"", $check_url))) 
			{
		die ("�� ��� ��� �� �������� � ���");
		} //|| (eregi("\([^>]*\"?[^)]*\)", $check_url))
		*/
	return $check_url;
	}
}


function str($input,$html=false) 
{
    $input = trim($input); 
//// \x00, \n, \r, \, ', " and \x1a 
    $input = str_replace(x00,"x00",$input); 
    //$input = str_replace(x1a,"x1a",$input); 
    $input = str_replace("`","`",$input); 

    $input = str_ireplace("\\","",$input); 
if(!$html)    $input = htmlspecialchars($input); 
    $input = str_replace("`","`",$input); 
    $input = str_ireplace("'","'",$input); 
    $input = str_ireplace("'","&#x27;",$input); 
if(!$html)    $input = str_ireplace(">","&gt;",$input); 
if(!$html)    $input = str_ireplace("<","&lt;",$input); 

    $input = str_ireplace("&amp;","&",$input); 
    return $input; 
}

function get_seed_time($st)
{
$secs = $st;
$mins = floor($st / 60);
$hours = floor($mins / 60);
$days = floor($hours / 24);
$week = floor($days / 7);
$month = floor($week / 4);

if ($month > 0) {
$week_elapsed = floor(($st - ($month * 4 * 7 * 24 * 60 * 60)) / (7 * 24 * 60 * 60));
$days_elapsed = floor(($st - ($week * 7 * 24 * 60 * 60)) / (24 * 60 * 60));
$hours_elapsed = floor(($st - ($days * 24 * 60 * 60)) / (60 * 60));
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "$month ���. $week_elapsed ���. $days_elapsed ��. $hours_elapsed ���. $mins_elapsed ���. ".($secs_elapsed==0?"":"$secs_elapsed ���");
}
if ($week > 0) {
$days_elapsed = floor(($st - ($week * 7 * 24 * 60 * 60)) / (24 * 60 * 60));
$hours_elapsed = floor(($st - ($days * 24 * 60 * 60)) / (60 * 60));
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "$week ���. $days_elapsed ��. $hours_elapsed ���. $mins_elapsed ���. ".($secs_elapsed==0?"":"$secs_elapsed ���");
}
if ($days > 0) {
$hours_elapsed = floor(($st - ($days * 24 * 60 * 60)) / (60 * 60));
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "$days ��. $hours_elapsed ���. $mins_elapsed ���. ".($secs_elapsed==0?"":"$secs_elapsed ���");
}
if ($hours > 0) {
$mins_elapsed = floor(($st - ($hours * 60 * 60)) / 60);
$secs_elapsed = floor($st - $mins * 60);
return "$hours ���. $mins_elapsed ���. ".($secs_elapsed==0?"":"$secs_elapsed ���");
}
if ($mins > 0) {
$secs_elapsed = floor($st - $mins * 60);
return "$mins ���. ".($secs_elapsed==0?"":"$secs_elapsed ���");
}
if ($secs > 0) {
return "$secs ������.";
}
return "����� �� ��������������";
}



function karma($karma) {
    if ($karma == 0)
        $color = "#000000";
    elseif ($karma < 0)
        $color = "#FF0000";
    elseif ($karma > 0 && $karma < 10)
    {
        $color = "#000080";
        $karma = "+$karma";
    }
    elseif ($karma > 10)
    {
        $color = "#008000";
        $karma = "+$karma";
    }
    return "<font style=\"color:$color;vertical-align:top;font-size:13px;\">$karma</font>";
}




//// ������� ��� ������� php4

if(!function_exists("stripos")) {
 function stripos($haystack, $needle, $offset = 0) {
  return strpos(strtolower($haystack), strtolower($needle), $offset);
 }
}

if(!function_exists("str_ireplace")){
  function str_ireplace($search,$replace,$subject){
    $token = chr(1);
    $haystack = strtolower($subject);
    $needle = strtolower($search);
    while (($pos=strpos($haystack,$needle))!==FALSE){
      $subject = substr_replace($subject,$token,$pos,strlen($search));
      $haystack = substr_replace($haystack,$token,$pos,strlen($search));
    }
    $subject = str_replace($token,$replace,$subject);
    return $subject;
  }
}


if(!function_exists("memory_get_usage")){
function memory_get_usage(){
     $pid = getmypid();
     exec("ps -o rss -p $pid", $output);
     return $output[1] *1024;
}
}

if (!function_exists('highlight'))
{
	function highlight($search, $subject, $hlstart = '<b><font color=red>', $hlend = '</font></b>')
	{
		$srchlen = strlen($search);    // lenght of searched string
		if ($srchlen == 0)
			return $subject;
		
		$find = $subject;
		while ($find = stristr($find, $search)) // find $search text in $subject -case insensitiv
		{
			$srchtxt = substr($find,0,$srchlen);    // get new search text
			$find = substr($find,$srchlen);
			$subject = str_replace($srchtxt, $hlstart.$srchtxt.$hlend, $subject);    // highlight founded case insensitive search text
		}
		
		return $subject;
	}
}
//// ������� ��� ������� php4

/// ������� ����� �����
function gensitemap(){
$DEFAULTBASEURL = "http://".htmlspecialchars_uni($_SERVER['HTTP_HOST'])."/";

$txt = '<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="gss.xsl"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.google.com/schemas/sitemap/0.84 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';

$txt .='<url><loc>'.$DEFAULTBASEURL.'browse.php</loc><lastmod>'.t().'</lastmod><changefreq>hourly</changefreq><priority>1</priority></url>
<url><loc>'.$DEFAULTBASEURL.'</loc><lastmod>'.t().'</lastmod><changefreq>hourly</changefreq><priority>1</priority></url>';

$sql = sql_query("SELECT id,added FROM torrents ORDER BY id DESC LIMIT 500");
while($a = mysql_fetch_assoc($sql)){
$txt .='<url><loc>'.$DEFAULTBASEURL.'details.php?id='.$a['id'].'</loc><lastmod>'.t($a['added']).'</lastmod><changefreq>daily</changefreq><priority>0.50</priority></url>';
}

$sql = sql_query("SELECT id FROM categories");
while($a = mysql_fetch_assoc($sql)){
$txt .='<url><loc>'.$DEFAULTBASEURL.'browse.php?cat='.$a['id'].'</loc><lastmod>'.t().'</lastmod><changefreq>hourly</changefreq><priority>0.50</priority></url>';
}

$txt .='</urlset>';

@file_put_contents(ROOT_PATH."sitemap.xml",$txt) or stderr("������!","���������� �������� ����!");
}

function t($t=false){
    if(!$t) return date('c'); //2004-02-12T15:19:21+00:00
    return date('c',strtotime($t));
}
/// ������� ����� �����


function nicetime($input, $time = false) {
    $search = array('January','February','March','April','May','June','July','August','September','October','November','December');
    $replace = array('������','�������','�����','������','���','����','����','�������','��������','�������','������','�������');
    $seconds = strtotime($input);
    if ($time == true)
        $data = date("j F Y � H:i:s", $seconds);
    else
        $data = date("j F Y", $seconds);
    $data = str_replace($search, $replace, $data);
    return $data;
}

?>