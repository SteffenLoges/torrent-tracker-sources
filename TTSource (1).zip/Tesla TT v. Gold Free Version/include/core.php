<?
# IMPORTANT: Do not edit below unless you know what you are doing!
if (!defined("IN_TRACKER"))
  die("Hacking attempt! Core.");

// INCLUDE/REQUIRE BACK-END

require_once(ROOT_PATH.'include/init.php');
require_once(ROOT_PATH.'include/global.php');
require_once(ROOT_PATH.'include/config.php');
require_once(ROOT_PATH.'include/functions.php');
require_once(ROOT_PATH.'include/functions_cache.php');
require_once(ROOT_PATH.'include/blocks.php');
require_once(ROOT_PATH.'include/passwords.php');

// ����������� ������ �� xss ����
if ($ctracker == "1")	require_once(ROOT_PATH.'include/ctracker.php');

// LOAD GZIP/OUTPUT BUFFERING
if ($use_gzip=="yes") gzip();

/*
// Additional security countermeasures
if (ini_get('register_globals') == '1' || strtolower(ini_get('register_globals')) == 'on')
	die('��������� regiser_globals � php.ini/.htaccess (������ ������������)');
if (!ini_get('short_open_tag'))
	die('�������� short_open_tag � php.ini/.htaccess (����������� ����������)');
*/

define("BETA", 0); // Set 0 to remove *BETA* notice.

///define ("DEBUG_MODE", 0); // ����� ������������� � config.php

define("SHOW", "<script language=\"javascript\" type=\"text/javascript\" src=\"js/snow.js\"></script>");

if (!isset($HTTP_POST_VARS) && isset($_POST)) {
    $HTTP_POST_VARS = $_POST; 
    $HTTP_GET_VARS = $_GET; 
    $HTTP_SERVER_VARS = $_SERVER; 
    $HTTP_COOKIE_VARS = $_COOKIE; 
   // $HTTP_ENV_VARS = $_ENV; 
    $HTTP_POST_FILES = $_FILES; 
}

unset($HTTP_GET_VARS,$HTTP_POST_VARS,$HTTP_SERVER_VARS,$HTTP_COOKIE_VARS,$HTTP_POST_FILES);

unset($HTTP_ENV_VARS);unset($_ENV);
if ($_SERVER==$HTTP_SERVER_VARS)
unset($HTTP_SERVER_VARS);
//unset($_SERVER);





if (get_magic_quotes_gpc()) {
    if (!empty($_GET))    { $_GET    = strip_magic_quotes($_GET);    } 
    if (!empty($_POST))   { $_POST   = strip_magic_quotes($_POST);   } 
    if (!empty($_COOKIE)) { $_COOKIE = strip_magic_quotes($_COOKIE); } 
} 

if (!get_magic_quotes_gpc()) {
    if (is_array($HTTP_GET_VARS)) { 
        while (list($k, $v) = each($HTTP_GET_VARS)) { 
            if (is_array($HTTP_GET_VARS[$k])) { 
                while (list($k2, $v2) = each($HTTP_GET_VARS[$k])) { 
                    $HTTP_GET_VARS[$k][$k2] = addslashes($v2); 
                } 
                @reset($HTTP_GET_VARS[$k]); 
            } else { 
                $HTTP_GET_VARS[$k] = addslashes($v); 
            } 
        } 
        @reset($HTTP_GET_VARS); 
    } 

    if (is_array($HTTP_POST_VARS)) { 
        while (list($k, $v) = each($HTTP_POST_VARS)) { 
            if (is_array($HTTP_POST_VARS[$k])) { 
                while (list($k2, $v2) = each($HTTP_POST_VARS[$k])) { 
                    $HTTP_POST_VARS[$k][$k2] = addslashes($v2); 
                } 
                @reset($HTTP_POST_VARS[$k]); 
            } else { 
                $HTTP_POST_VARS[$k] = addslashes($v); 
            } 
        } 
        @reset($HTTP_POST_VARS); 
    } 

    if (is_array($HTTP_COOKIE_VARS)) { 
        while (list($k, $v) = each($HTTP_COOKIE_VARS)) { 
            if (is_array($HTTP_COOKIE_VARS[$k])) { 
                while (list($k2, $v2) = each($HTTP_COOKIE_VARS[$k])) { 
                    $HTTP_COOKIE_VARS[$k][$k2] = addslashes($v2); 
                } 
                @reset($HTTP_COOKIE_VARS[$k]); 
            } else { 
                $HTTP_COOKIE_VARS[$k] = addslashes($v); 
            } 
        } 
        @reset($HTTP_COOKIE_VARS); 
    } 
}


function mysql_modified_rows () {
    $info_str = mysql_info();
    $a_rows = mysql_affected_rows();
    ereg("Rows matched: ([0-9]*)", $info_str, $r_matched);
    return ($a_rows < 1)?($r_matched[1]?$r_matched[1]:0):$a_rows;
}
   
?>