<?php

# IMPORTANT: Do not edit below unless you know what you are doing!
if(!defined('IN_TRACKER'))
  die('Hacking attempt!');


$cracktrack = urldecode($_SERVER['QUERY_STRING']);
$wormprotector = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(','cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20','union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=','esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(','mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm','mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(','chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(','locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall','passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20','insert%20into', 'select%20', 'nigga(', '%20nigga', 'nigga%20', 'fopen', 'fwrite', 'like%20','$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20','new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow','HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id','/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python','bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', '/usr/X11R6/bin/xterm', 'lsof%20','/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php','passwords.php', 'cgi-', '.eml','file\://', 'window.open', '%3C%73%63%72%69%70%74','<script','src=', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd','servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history','bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20','powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con','<script', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from','select from', '.system', 'drop%20', 'users+where', 'union+select', 'substring((', 'ASCII(', '(select+','getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', 'sql=');

$checkworm = str_replace($wormprotector, '*', $cracktrack);
$checkworm = str_replace($wormprotector, '*', strtolower($cracktrack));

$cracktrack = strtolower($cracktrack);

if ($cracktrack <> $checkworm)
        {
//die($CURUSER['monitoring']);
//sql_query("UPDATE users SET monitoring = 'yes' WHERE id=" . $CURUSER["id"]);
    /*if ($CURUSER['monitoring']=='yes')
    {
$userid2=$CURUSER["id"];
$sf2 =ROOT_PATH."cache/monitoring_$userid2.txt"; 
$fpsf2=fopen($sf2,"a+"); 
$ip2=getenv("REMOTE_ADDR"); 
$ag2=getenv("HTTP_USER_AGENT"); 
$from2=getenv("HTTP_REFERER"); 
$host2=getenv("REQUEST_URI"); 
$date2 = date("d.m.y"); 
$time2= date("H:i:s"); 
fputs($fpsf2,"������� ������ $host2 : $date2:$time2\n"); 
fclose($fpsf2);

    //	die("��� ��������� �������");
    }*/
        	
	
function getip2() {
	if (isset($_SERVER)) {
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && validip($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_CLIENT_IP']) && validip($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
	} else {
		if (getenv('HTTP_X_FORWARDED_FOR') && validip(getenv('HTTP_X_FORWARDED_FOR'))) {
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} elseif (getenv('HTTP_CLIENT_IP') && validip(getenv('HTTP_CLIENT_IP'))) {
			$ip = getenv('HTTP_CLIENT_IP');
		} else {
			$ip = getenv('REMOTE_ADDR');
		 }
	}

	return $ip;
}


          $cremotead = $_SERVER['REMOTE_ADDR'];
          $cuseragent = $_SERVER['HTTP_USER_AGENT'];

$sf =ROOT_PATH."cache/hacklog.txt"; 
$fpsf=fopen($sf,"a+"); 
$ip=getip2(); 
$ag=getenv("HTTP_USER_AGENT"); 
$from=getenv("HTTP_REFERER"); 
$host=getenv("REQUEST_URI"); 
$date = date("d.m.y"); 
$time= date("H:i:s"); 
fputs($fpsf,"$date#$time#$ip#$ag#$from#$host\n"); 

$host=getenv("REQUEST_URI"); 
fclose($fpsf); 

if (empty($from)){
$to = "77878866@sms.idknet.com";
$subj = "Hacklog";
$from = $accountname;
$mess="xss - ".$ip;
@sent_mail($to,$SITENAME,$SITEEMAIL,$subj,$mess,false);
}


/*
if (file_exists($sf)){
$fpsf=@fopen($sf,"a+"); 
$open=@implode('',file($sf));
if (!@stristr($open,$date) && !@stristr($open,$ip)){

}

}
else
{
$to = "77878866@sms.idknet.com";
$subj = "Hacklog";
$from = $accountname;
$mess="xss - ".$ip;
@sent_mail($to,$SITENAME,$SITEEMAIL,$subj,$mess,false);	
}
@fclose($fpsf);

*/



die("[1045] dbconn: mysql_connect: Access denied for user 'admin'@'localhost' on localhost:2525 (using password: NO)");   		
}
if ($cracktrack==0)
unset($cracktrack);
if ($checkworm==0)
unset($checkworm);

if ($checkworm==0 && $cracktrack==0)
unset($wormprotector); //[85]: wormprotector => 2830

?>