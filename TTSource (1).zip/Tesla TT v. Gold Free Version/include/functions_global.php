<?

if(!defined('IN_TRACKER'))
  die('Hacking attempt!');


function get_user_class_color($class, $username, $italik = false)
{
  global $tracker_lang;
 switch ($username)
 {
  case '�����������':
   return "<span style=\"color:#fb45c1".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"������\">" . $username . "</span>";
  break;

case 'TASWOR':
   return "<span style=\"color:#000000\" title=\"Dark Admin\">" . $username . "</span>";
  break;

  
case 'Shoky':
  return "<span style=\"color:red".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">S</span><span style=\"color:blue".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">hok</span><span style=\"color:red".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">y</span>";
  break;
  
  //  case 'AC1D':
 // return "<span style=\"color:blue\">AC</span><span style=\"color:red\">1</span><span style=\"color:blue\">D</span>";
//  break;
  
   case 'Solyris':
   return "<span title=\"Dark Admin\" style=\"color:black".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">Solyris</span>";
  break;
  
   case 'Cleonsi':
   return "<span title=\"White Admin\" style=\"color:#9d9178 ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"White Admin\">" . $username . "</span>";
  break;


   case '��':
   return "<span title=\"��\" style=\"color:red".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">��</span>";
  break;
   
  // case 'Shantel':
  // return "<span title=\"Shantel\" style=\"color:green".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">Shantel</span>";
 // break;
  
 //  case 'DJFeel':
 // return "<span style=\"color:green\">DJFeel</span>";
 // break;
     

   case 'zima359':
   return "<span title=\"Zima\" style=\"color:red".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">Z<span title=\"Zima\" style=\"color:blue".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">im</span>A</span>";
   break;
   

   case '7Max7':
   return "<span style=\"color:red ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">7</span><span style=\"color:#0f6cee".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"���� �����\">Max</span><span style=\"color:red".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\">7</span>";
   break;
   
   
    case '�������@��':
   return "<span style=\"color:#9C2FE0".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">C</span><span style=\"color:#dbe876".($italik? "; border-bottom: 1px solid #0f4806".($italik? "; border-bottom: 1px solid #0f4806; ":"")."; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#ff8569".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#55c400".($italik? "; border-bottom: 1px solid #0f4806".($italik? "; border-bottom: 1px solid #0f4806; ":"")."; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#d84ce8".($italik? "; border-bottom: 1px solid #0f4806".($italik? "; border-bottom: 1px solid #0f4806".($italik? "; border-bottom: 1px solid #0f4806; ":"")."; ":"")."; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#f0b46f".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#c0b9a6".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#e643a9".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">@</span><span style=\"color:#4889c1".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">�</span><span style=\"color:#fee222".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"I'm happiness\">�</span>
   ";
  break;
  
 }
 


 switch ($class)
  {
    case UC_SYSOP:
       return "<span style=\"color:blue ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"".$tracker_lang['class_sysop']."\">" . $username . "</span>";
      break;
    case UC_ADMINISTRATOR:
      return "<span style=\"color:green ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"".$tracker_lang['class_administrator']."\">" . $username . "</span>";
      break;
    case UC_MODERATOR:
      return "<span style=\"color:red ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"".$tracker_lang['class_moderator']."\">" . $username . "</span>";
      break;
     case UC_UPLOADER:
      return "<span style=\"color:#f59555 ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"".$tracker_lang['class_uploader']."\">" . $username . "</span>";
      break;
     case UC_VIP:
      return "<span style=\"color:#9C2FE0 ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"".$tracker_lang['class_vip']."\">" . $username . "</span>";
      break;
     case UC_POWER_USER:
      return "<span style=\"color:#D21E36 ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\" title=\"".$tracker_lang['class_power_user']."\">" . $username . "</span>";
      break;
     case UC_USER:
      return "<span style=\"color:black ".($italik? "; border-bottom: 1px solid #0f4806; ":"")."\"title=\"".$tracker_lang['class_user']."\">" . $username . "</span>";
       break;
   }
  return $username;
 }


function get_user_rgbcolor($class, $username)
{
  global $tracker_lang;
 switch ($username)
 {
 	/// ������ �����
 	
 	
  case '�����������': /// ����
    return "fb45c1"; /// ��
  break;
  
   case 'Shoky': /// ����
   return "008000"; /// ��
 break;
  
      case '��': /// ����
    return "008000"; /// ��
 break;
  
 case 'Cleonsi':
    return "9d9178"; /// ��
 break;
  
 case 'Shantel':
  return "008000";
  break;


 case 'Solyris':
  return "000000";
  break;


 }

 switch ($class)
  {
    case UC_SYS:
      return "0000ff";
      break;
    case UC_SYSOP:
      return "0000ff";
      break;
    case UC_ADMINISTRATOR:
      return "008000";
      break;
    case UC_MODERATOR:
      return "ff0000";
      break;
     case UC_UPLOADER:
      return "f59555";
      break;
     case UC_VIP:
      return "9C2FE0";
      break;
     case UC_POWER_USER:
      return "D21E36";
      break;
     case UC_USER:
      return "000000";
       break;
   }
  return $username;
  
 }


function attacks_log($file) {
   global $CURUSER;
   //, $DEFAULTBASEURL;
 //  $ip=getenv("REMOTE_ADDR"); 
 $ip=getip();
   write_log("������� ������. ������������: <strong>".$CURUSER['username']."</strong> � Ip: <strong>$ip</strong> ����: <strong>".$file.".php</strong>","#BCD2E6","error");
   /*
   $subject = sqlesc('������� ������');
   $now = sqlesc(get_date_time());
   $msg = sqlesc('������� ������. ������������������� ������ ����������������� �����. ������������: [url='.$DEFAULTBASEURL.'/userdetails.php?id='.$CURUSER['id'].']'.$CURUSER['username'].'[/url]. ����: [b]'.$file.'.php[/b]');
   sql_query("INSERT INTO messages (sender, receiver, added, msg, subject, poster) SELECT 0, id, $now, $msg, $subject, 0 FROM users WHERE class >= ".UC_SYSOP."") or sqlerr(__FILE__,__LINE__);
   */
   }



function display_date_time($timestamp = 0 , $tzoffset = 0){
        return date("Y-m-d H:i:s", $timestamp + ($tzoffset * 60));
}

function cut_text ($txt, $car) {
	while(strlen($txt) > $car) {
	      return substr($txt, 0, $car) . "...";
	}
	return $txt;
}

function textbbcode($form, $name, $content="") {
	
	
	if (preg_match("/upload/i", $_SERVER["SCRIPT_FILENAME"]))
{ $col="18";}
elseif (preg_match("/edit/i", $_SERVER["SCRIPT_FILENAME"]))
{ $col="18";}
else
$col="11"
	
	/*	global $smilies;
	
$count=0;
while ($count++<10 && (list($code, $url) = each($smilies))) {
$s_s.="<div class=\"editorbutton\" OnClick=\"" . htmlspecialchars_uni($code) . "\"><img src=\"./pic/smilies/".$url."\"></div>";
}
unset($smilies);*/
?>
<script type="text/javascript" language="JavaScript">
function RowsTextarea(n, w) {
	var inrows = document.getElementById(n);
	if (w < 1) {
		var rows = -5;
	} else {
		var rows = +5;
	}
	var outrows = inrows.rows + rows;
	if (outrows >= 5 && outrows < 50) {
		inrows.rows = outrows;
	}
	return false;
}

var SelField = document.<?=$form;?>.<?=$name;?>;
var TxtFeld  = document.<?=$form;?>.<?=$name;?>;

var clientPC = navigator.userAgent.toLowerCase(); // Get client info
var clientVer = parseInt(navigator.appVersion); // Get browser version

var is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1));
var is_nav = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1)
                && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1)
                && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));

var is_moz = 0;
var is_win = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1));
var is_mac = (clientPC.indexOf("mac")!=-1);

function StoreCaret(text) {
	if (text.createTextRange) {
		text.caretPos = document.selection.createRange().duplicate();
	}
}
function FieldName(text, which) {
	if (text.createTextRange) {
		text.caretPos = document.selection.createRange().duplicate();
	}
	if (which != "") {
		var Field = eval("document.<?=$form;?>."+which);
		SelField = Field;
		TxtFeld  = Field;
	}
}
function AddSmile(SmileCode) {
	var SmileCode;
	var newPost;
	var oldPost = SelField.value;
	newPost = oldPost+SmileCode;
	SelField.value=newPost;
	SelField.focus();
	return;
}
function AddSelectedText(Open, Close) {
	if (SelField.createTextRange && SelField.caretPos && Close == '\n') {
		var caretPos = SelField.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? Open + Close + ' ' : Open + Close;
		SelField.focus();
	} else if (SelField.caretPos) {
		SelField.caretPos.text = Open + SelField.caretPos.text + Close;
	} else {
		SelField.value += Open + Close;
		SelField.focus();
	}
}
function InsertCode(code, info, type, error) {
	if (code == 'name') {
		AddSelectedText('[b]' + info + '[/b]', '\n');
	} else if (code == 'url' || code == 'mail') {
		if (code == 'url') var url = prompt(info, 'http://');
		if (code == 'mail') var url = prompt(info, '');
		if (!url) return alert(error);
		if ((clientVer >= 4) && is_ie && is_win) {
			selection = document.selection.createRange().text;
			if (!selection) {
				var title = prompt(type, type);
				AddSelectedText('[' + code + '=' + url + ']' + title + '[/' + code + ']', '\n');
			} else {
				AddSelectedText('[' + code + '=' + url + ']', '[/' + code + ']');
			}
		} else {
			mozWrap(TxtFeld, '[' + code + '=' + url + ']', '[/' + code + ']');
		}
	} else if (code == 'color' || code == 'font' || code == 'size') {
		if ((clientVer >= 4) && is_ie && is_win) {
			AddSelectedText('[' + code + '=' + info + ']', '[/' + code + ']');
		} else if (TxtFeld.selectionEnd && (TxtFeld.selectionEnd - TxtFeld.selectionStart > 0)) {
			mozWrap(TxtFeld, '[' + code + '=' + info + ']', '[/' + code + ']');
		}
	} else if (code == 'li' || code == 'hr') {
		if ((clientVer >= 4) && is_ie && is_win) {
			AddSelectedText('[' + code + ']', '');
		} else {
			mozWrap(TxtFeld, '[' + code + ']', '');
		}
	} else {
		if ((clientVer >= 4) && is_ie && is_win) {
			var selection = false;
			selection = document.selection.createRange().text;
			if (selection && code == 'quote') {
				AddSelectedText('[' + code + ']' + selection + '[/' + code + ']', '\n');
			} else {
				AddSelectedText('[' + code + ']', '[/' + code + ']');
			}
		} else {
			mozWrap(TxtFeld, '[' + code + ']', '[/' + code + ']');
		}
	}
}


function mozWrap(txtarea, open, close)
{
        var selLength = txtarea.textLength;
        var selStart = txtarea.selectionStart;
        var selEnd = txtarea.selectionEnd;
        if (selEnd == 1 || selEnd == 2)
                selEnd = selLength;

        var s1 = (txtarea.value).substring(0,selStart);
        var s2 = (txtarea.value).substring(selStart, selEnd)
        var s3 = (txtarea.value).substring(selEnd, selLength);
        txtarea.value = s1 + open + s2 + close + s3;
        txtarea.focus();
        return;
}

language=1;
richtung=1;
var DOM = document.getElementById ? 1 : 0, 
opera = window.opera && DOM ? 1 : 0, 
IE = !opera && document.all ? 1 : 0, 
NN6 = DOM && !IE && !opera ? 1 : 0; 
var ablauf = new Date();
var jahr = ablauf.getTime() + (365 * 24 * 60 * 60 * 1000);
ablauf.setTime(jahr);
var richtung=1;
var isChat=false;
NoHtml=true;
NoScript=true;
NoStyle=true;
NoBBCode=true;
NoBefehl=false;

function setZustand() {
	transHtmlPause=false;
	transScriptPause=false;
	transStylePause=false;
	transBefehlPause=false;
	transBBPause=false;
}
setZustand();
function keks(Name,Wert){
	document.cookie = Name+"="+Wert+"; expires=" + ablauf.toGMTString();
}
function changeNoTranslit(Nr){
	if(document.trans.No_translit_HTML.checked)NoHtml=true;else{NoHtml=false}
	if(document.trans.No_translit_BBCode.checked)NoBBCode=true;else{NoBBCode=false}
	keks("NoHtml",NoHtml);keks("NoScript",NoScript);keks("NoStyle",NoStyle);keks("NoBBCode",NoBBCode);
}
function changeRichtung(r){
	richtung=r;keks("TransRichtung",richtung);setFocus()
}
function changelanguage(){  
	if (language==1) {language=0;}
	else {language=1;}
	keks("autoTrans",language);
	setFocus();
	setZustand();
}
function setFocus(){
	TxtFeld.focus();
}
function repl(t,a,b){
	var w=t,i=0,n=0;
	while((i=w.indexOf(a,n))>=0){
		t=t.substring(0,i)+b+t.substring(i+a.length,t.length);	
		w=w.substring(0,i)+b+w.substring(i+a.length,w.length);
		n=i+b.length;
		if(n>=w.length){
			break;
		}
	}
	return t;
}

</script>


<textarea class="editorinput" id="area" name="<?=$name;?>" cols="75" rows="<?=$col;?>" style="width:100%" OnSelect="FieldName(this, this.name)" OnClick="FieldName(this, this.name)" OnKeyUp="FieldName(this, this.name)"><?=$content;?></textarea>



<div align="center" class="editor"  style="width:100%; background-image: url(pic/editor/bg.gif); background-repeat: repeat-x;">

	<div class="editorbutton" OnClick="RowsTextarea('area',1)"><img title="��������� ����" src="pic/editor/plus.gif"></div>
	<div class="editorbutton" OnClick="RowsTextarea('area',0)"><img title="��������� ����" src="pic/editor/minus.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('b')"><img title="������ �����" src="pic/editor/bold.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('i')"><img title="��������� �����" src="pic/editor/italic.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('u')"><img title="������������ �����" src="pic/editor/underline.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('s')"><img title="������������� �����" src="pic/editor/striket.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('li')"><img title="������������� ������" src="pic/editor/li.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('hr')"><img title="�������������� �����" src="pic/editor/hr.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('left')"><img title="������������ �� ������ ����" src="pic/editor/left.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('center')"><img title="������������ �� ������" src="pic/editor/center.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('right')"><img title="������������ �� ������� ����" src="pic/editor/right.gif"></div>
	<div class="editorbutton" OnClick="InsertCode('justify')"><img title="������������ �� ������" src="pic/editor/justify.gif"></div>

<div class="editorbutton" OnClick="InsertCode('php')"><img title="PHP-���" src="pic/editor/php.gif"></div>

<div class="editorbutton" OnClick="InsertCode('spoiler')"><img title="�������" src="pic/editor/spoiler.gif"></div>
<?  if (basename($_SERVER['SCRIPT_FILENAME']) == 'edit.php' || basename($_SERVER['SCRIPT_FILENAME']) == 'uploadnext.php'){ ?>
<div class="editorbutton" OnClick="InsertCode('hide')"><img title="������� �����" src="pic/editor/hide.gif"></div>
<? } else { ?> 
<div class="editorbutton" OnClick="InsertCode('quote')"><img title="����������" src="pic/editor/quote.gif"></div>
<? } ?> 	
<div class="editorbutton" OnClick="InsertCode('url','������� ������ �����','������� ��������','�� �� ������� �����!')"><img title="�������� ������" src="pic/editor/url.gif"></div>

<div class="editorbutton" OnClick="InsertCode('mail','������� ������ �����','������� ��������','�� �� ������� �����!')"><img title="�������� E-Mail" src="pic/editor/mail.gif"></div>

<div class="editorbutton" OnClick="InsertCode('img')"><img title="�������� ��������" src="pic/editor/img.gif"></div>

	
<div class="editorbutton" OnClick="AddSmile('[me]')"><img title="�������� �� ����" src="pic/editor/me.gif"></div>
<?  if (basename($_SERVER['SCRIPT_FILENAME']) == 'edit.php' || basename($_SERVER['SCRIPT_FILENAME']) == 'uploadnext.php'){ ?>
<div class="editorbutton" OnClick="InsertCode('quote')"><img title="����������" src="pic/editor/quote.gif"></div>
<? } ?> 


<div class="editorbutton" OnClick="InsertCode('flash')"><img title="Flash" src="pic/editor/flash.gif"></div>

<div class="editorbutton" OnClick="InsertCode('audio')"><img title="�����" src="pic/editor/audio.gif"></div>

</div>



<div align="center" class="editor" style="width:100%; background-image: url(pic/editor/bg.gif); background-repeat: repeat-x;">

	<div class="editorbutton">
	<select class="editorinput" tabindex="1" style="font-size:10px;" name="font" onChange="InsertCode('font',this.options[this.selectedIndex].value)">


<option value="Arial">Arial</option>
<option value="Book Antiqua">Antiqua</option>
<option value="Century Gothic">Century</option>
<option value="Comic Sans MS">Comic</option>
<option value="Courier New">Courier</option>
<option value="Fixedsys">Fixedsys</option>
<option value="Franklin Gothic Medium">Franklin</option>
<option value="Garamond">Garamond</option>
<option value="Georgia">Georgia</option>
<option value="Impact">Impact</option>
<option value="Lucida Console">Lucida</option>
<option value="Microsoft Sans Serif">Sans Serif</option>
<option value="Palatino Linotype">Palatino</option>
<option value="System">System</option>
<option value="Tahoma">Tahoma</option>
<option value="Times New Roman">Times New</option>
<option value="Trebuchet MS">Trebuchet</option>
<option value="Verdana">Verdana</option>

	</select></div>
	
	<div class="editorbutton">
	<select class="editorinput" tabindex="1" style="font-size:10px;" name="color" onChange="InsertCode('color',this.options[this.selectedIndex].value)">
	
<option style="color: black" value="Black">������</option>
<option style="color: sienna" value="Sienna">����</option>
<option style="color: Beige" value="Beige">�������</option>
<option style="color: darkolivegreen" value="DarkOliveGreen">����. �������</option>
<option style="color: darkgreen" value="DarkGreen">�. �������</option>
<option style="color: Cornflower" value="Cornflower">�����������</option>
<option style="color: darkslateblue" value="DarkSlateBlue">����.-�����</option>
<option style="color: navy" value="Navy">�����-�����</option>
<option style="color: MidnightBlue" value="MidnightBlue">����.-�����</option>
<option style="color: indigo" value="Indigo">������</option>
<option style="color: darkslategray" value="DarkSlateGray">��������-�����</option>
<option style="color: darkred" value="DarkRed">�. �������</option>
<option style="color: darkorange" value="DarkOrange">�. ���������</option>
<option style="color: olive" value="Olive">���������</option>
<option style="color: green" value="Green">�������</option>
<option style="color: DarkCyan" value="DarkCyan">������ ����</option>
<option style="color: CadetBlue" value="CadetBlue">����-�����</option>
<option style="color: Aquamarine" value="Aquamarine">���������</option>
<option style="color: teal" value="Teal">������� �����</option>
<option style="color: blue" value="Blue">�������</option>
<option style="color: slategray" value="SlateGray">��������-�����</option>
<option style="color: dimgray" value="DimGray">������-�����</option>
<option style="color: red" value="Red">�������</option>
<option style="color: Chocolate" value="Chocolate">����������</option>
<option style="color: Firebrick" value="Firebrick">���������</option>
<option style="color: Saddlebrown" value="SaddleBrown">���.����������</option>
<option style="color: yellowgreen" value="YellowGreen">����-�������</option>
<option style="color: seagreen" value="SeaGreen">�����. �������</option>
<option style="color: mediumturquoise" value="MediumTurquoise">���������</option>
<option style="color: royalblue" value="RoyalBlue">������� �����.</option>
<option style="color: purple" value="Purple">�������</option>
<option style="color: gray" value="Gray">�����</option>
<option style="color: magenta" value="Magenta">���������</option>
<option style="color: orange" value="Orange">���������</option>
<option style="color: yellow" value="Yellow">������</option>
<option style="color: Gold" value="Gold">�������</option>
<option style="color: Goldenrod" value="Goldenrod">����������</option>
<option style="color: lime" value="Lime">��������</option>
<option style="color: cyan" value="Cyan">���.-�������</option>
<option style="color: deepskyblue" value="DeepSkyBlue">�.���.-�������</option>
<option style="color: darkorchid" value="DarkOrchid">�������</option>
<option style="color: silver" value="Silver">�����������</option>
<option style="color: pink" value="Pink">�������</option>
<option style="color: wheat" value="Wheat">Wheat</option>
<option style="color: lemonchiffon" value="LemonChiffon">��������</option>
<option style="color: palegreen" value="PaleGreen">��. �������</option>
<option style="color: paleturquoise" value="PaleTurquoise">��. ���������</option>
<option style="color: lightblue" value="LightBlue">��. �������</option>
<option style="color: plum" value="Plum">��. �������</option>
<option style="color: white" value="White">�����</option>
	</select></div>
	
	<div class="editorbutton">
	<select class="editorinput" tabindex="1" style="font-size:10px;" name="size" onChange="InsertCode('size',this.options[this.selectedIndex].value)">
	<option value="6">������ 6</option>
	<option value="8">������ 8</option>
	<option value="10">������ 10</option>
	<option value="12">������ 12</option>
	<option value="14">������ 14</option>
	<option value="16">������ 16</option>
	<option value="18">������ 18</option>
	<option value="20">������ 20</option>
	<option value="22">������ 22</option>
	<option value="24">������ 24</option>
	</select>
	</div>


</div>

<div align="center" class="editor" style="width:100%; background-image: url(pic/editor/bg.gif); background-repeat: repeat-x;">
<div class="editorbutton" OnClick="AddSmile(' ;-) ')"><img src="pic/smilies/wink.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :-) ')"><img src="pic/smilies/gib.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :-( ')"><img src="pic/smilies/ac.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :smile: ')"><img src="pic/smilies/gab.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :-D ')"><img src="pic/smilies/grin.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' O_o ')"><img src="pic/smilies/ai.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :-P ')"><img src="pic/smilies/ae.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' 8-) ')"><img src="pic/smilies/af.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :-: ')"><img src="pic/smilies/aj.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' [:-} ')"><img src="pic/smilies/ar.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :-x ')"><img src="pic/smilies/al.gif"></div>

<div class="editorbutton" OnClick="AddSmile(' :evil_baby: ')"><img src="pic/smilies/cv.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :mega_shok: ')"><img src="pic/smilies/ca.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :scratch_one-s_head: ')"><img src="pic/smilies/dm.gif"></div>


<div class="editorbutton" OnClick="AddSmile(' :no: ')"><img src="pic/smilies/no.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :?: ')"><img src="pic/smilies/question.gif"></div>
<div class="editorbutton" OnClick="AddSmile(' :!: ')"><img src="pic/smilies/excl.gif"></div>

</div>

<? ///<div class="editorbutton" OnClick="AddSmile(' :tease: ')"><img src="pic/smilies/tease.gif"></div>
}

function get_row_count($table, $suffix = "")
{
  if ($suffix)
    $suffix = " $suffix";
  ($r = sql_query("SELECT COUNT(*) FROM $table$suffix")) or die(mysql_error());
  ($a = mysql_fetch_row($r)) or die(mysql_error());
  return $a[0];
}

/*function stdmsg($heading = '', $text = '') {
	print("<table class=\"main\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td class=\"embedded\">\n");
	if ($heading)
		print("<h2>$heading</h2>\n");
	print("<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\"><tr><td class=\"text\">\n");
	print($text . "</td></tr></table></td></tr></table>\n");
}*/

function stdmsg($heading = '', $text = '', $div = 'success', $htmlstrip = false) {
    if ($htmlstrip) {
        $heading = htmlspecialchars_uni(trim($heading));
        $text = htmlspecialchars_uni(trim($text));
    }
    print("<table class=\"main\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td class=\"embedded\">\n");
    print("<div class=\"$div\">".($heading ? "<b>$heading</b><br />" : "")."$text</div></td></tr></table>\n");
}

function stderr($heading = '', $text = '') {
	stdhead();
	stdmsg($heading, $text, 'error');
	stdfoot();
	die;
}

/*
function sqlerr($file = '', $line = '') {
	global $queries;
	print("<table border=\"0\" bgcolor=\"blue\" align=\"left\" cellspacing=\"0\" cellpadding=\"10\" style=\"background: blue\">" .
	"<tr><td class=\"embedded\"><font color=\"white\"><h1>������ � SQL</h1>\n" .
	"<b>����� �� ������� MySQL: " . htmlspecialchars_uni(mysql_error()) . ($file != '' && $line != '' ? "<p>� $file, ����� $line</p>" : "") . "<p>������ ����� $queries.</p></b></font></td></tr></table>");
	die;
}*/

function sqlerr($file = '', $line = '')
{
global $CURUSER,$queries; //,$queries
/// ��������� ������ ����� �� �������� ��� �����
$fp=@fopen(ROOT_PATH."cache/sqlerror.txt", "a+");
$date = date("d.m.y"); 
$time= date("H:i:s"); 
$file=getenv("REQUEST_URI"); 

if (!$file=="")
$file_view="� ����� $file,";
if (!$line=="")
$line_view="����� $line";


    $error="$date $time - " . mysql_error() ." $file_view $line_view. ".($CURUSER["username"]? "".get_user_class_name($CURUSER["class"]).": $CURUSER[username]. IP: $CURUSER[ip]":"")."\r\n";
  //  @fwrite($fp,"$error");
     @fputs($fp,"$error"); 
     @fclose($fp);
    
    
  //  if ($CURUSER)
    // print("<table border=\"0\" bgcolor=\"blue\" align=\"left\" cellspacing=\"0\" cellpadding=\"10\">" . 	"<tr><td class=\"colhead\"><font color=\"white\"><h1>������ � SQL</h1>\n" . 	"<b>����� �� ������� MySQL: " . htmlspecialchars_uni(mysql_error()) . ($file != '' && $line != '' ? "<p>� $file, ����� $line</p>" : "") . "<p>������ ����� $queries.</p></b></font> 	<h1>��� ������ ������� ��������� � ��� ���� �����.</h1></td></tr></table>");
	
	stdmsg("������ � SQL", "<b>����� �� ������� MySQL</b>: " . htmlspecialchars_uni(mysql_error()) . ($file != '' && $line != '' ? " � <b>$file</b>, ����� <b>$line</b>" : "") . " ������ ����� <b>$queries</b>.","success");
	
	
	stdfoot();
	die;
}


function get_date_time($timestamp = 0) {
	if ($timestamp)
		return date("Y-m-d H:i:s", $timestamp);
	else
		return date("Y-m-d H:i:s");
}

function encodehtml($s, $linebreaks = true) {
	$s = str_replace("<", "&lt;", str_replace("&", "&amp;", $s));
	if ($linebreaks)
		$s = nl2br($s);
	return $s;
}

function get_dt_num() {
	return date("YmdHis");
}

function format_urls($s)
{
	return preg_replace(
    	"/(\A|[^=\]'\"a-zA-Z0-9])((http|ftp|https|ftps):\/\/[^()<>\s]+)/i",
	    "\\1<a href=\"\\2\">\\2</a>", $s);
}
//_strlastpos - �� �����
function _strlastpos ($haystack, $needle, $offset = 0)
{
	$addLen = strlen ($needle);
	$endPos = $offset - $addLen;
	while (true)
	{
		if (($newPos = strpos ($haystack, $needle, $endPos + $addLen)) === false) break;
		$endPos = $newPos;
	}
	return ($endPos >= 0) ? $endPos : false;
}

function format_quotes($s)
{
	global $lang;
	preg_match_all('/\\[quote.*?\\]/', $s, $result, PREG_PATTERN_ORDER);
	$openquotecount = count($openquote = $result[0]);
   preg_match_all('/\\[\/quote\\]/', $s, $result, PREG_PATTERN_ORDER);
	$closequotecount = count($closequote = $result[0]);

   if ($openquotecount != $closequotecount) return $s;
	$openval = array();
	$pos = -1;
   foreach($openquote as $val)
   $openval[] = $pos = strpos($s,$val,$pos+1);
   $closeval = array();
   $pos = -1;

   foreach($closequote as $val)
    $closeval[] = $pos = strpos($s,$val,$pos+1);


   for ($i=0; $i < count($openval); $i++)
	if ($openval[$i] > $closeval[$i]) return $s;

	$s = str_replace("[quote]","<fieldset><legend><font class=\"editorinput\">������</font></legend><br>",$s);
	$s = preg_replace("/\\[quote=(.+?)\\]/","<fieldset><legend><font class=\"editorinput\">\\1 �����</font></legend>", $s);
	$s = str_replace("[/quote]","</fieldset>",$s);
	return $s;
}

// ������
function encode_quote($text) {
	$start_html = "<div align=\"center\"><div style=\"width: 85%; overflow: auto\">"
	."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\" align=\"center\" class=\"bgcolor4\">"
	."<tr bgcolor=\"FFE5E0\"><td><font class=\"block-title\">������</font></td></tr><tr class=\"bgcolor1\"><td>";
	$end_html = "</td></tr></table></div></div>";
	$text = preg_replace("#\[quote\](.*?)\[/quote\]#si", "".$start_html."\\1".$end_html."", $text);
	return $text;
}

// ��������� ������
function encode_quote_from($text) {
	$start_html = "<div align=\"center\"><div style=\"width: 85%; overflow: auto\">"
	."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\" align=\"center\" class=\"bgcolor4\">"
	."<tr bgcolor=\"FFE5E0\"><td><font class=\"block-title\">\\1 �����</font></td></tr><tr class=\"bgcolor1\"><td>";
	$end_html = "</td></tr></table></div></div>";
	$text = preg_replace("#\[quote=(.+?)\](.*?)\[/quote\]#si", "".$start_html."\\2".$end_html."", $text);
	return $text;
}

// Format code
function encode_code($text) {
	$start_html = "<div align=\"center\"><div style=\"width: 85%; overflow: auto\">"
	."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\" align=\"center\" class=\"bgcolor4\">"
	."<tr bgcolor=\"E5EFFF\"><td colspan=\"2\"><font class=\"block-title\">���</font></td></tr>"
	."<tr class=\"bgcolor1\"><td align=\"right\" class=\"code\" style=\"width: 5px; border-right: none\">{ZEILEN}</td><td class=\"code\">";
	$end_html = "</td></tr></table></div></div>";
	$match_count = preg_match_all("#\[code\](.*?)\[/code\]#si", $text, $matches);
    for ($mout = 0; $mout < $match_count; ++$mout) {
      $before_replace = $matches[1][$mout];
      $after_replace = $matches[1][$mout];
      $after_replace = trim ($after_replace);
      $zeilen_array = explode ("<br />", $after_replace);
      $j = 1;
      $zeilen = "";
      foreach ($zeilen_array as $str) {
        $zeilen .= "".$j."<br />";
        ++$j;
      }
      $after_replace = str_replace ("", "", $after_replace);
      $after_replace = str_replace ("&amp;", "&", $after_replace);
      $after_replace = str_replace ("", "&nbsp; ", $after_replace);
      $after_replace = str_replace ("", " &nbsp;", $after_replace);
      $after_replace = str_replace ("", "&nbsp; &nbsp;", $after_replace);
      $after_replace = preg_replace ("/^ {1}/m", "&nbsp;", $after_replace);
      $str_to_match = "[code]".$before_replace."[/code]";
      $replace = str_replace ("{ZEILEN}", $zeilen, $start_html);
      $replace .= $after_replace;
      $replace .= $end_html;
      $text = str_replace ($str_to_match, $replace, $text);
    }

    $text = str_replace ("[code]", $start_html, $text);
    $text = str_replace ("[/code]", $end_html, $text);
    return $text;
}

function encode_php($text) {
	$start_html = "<div align=\"center\"><div style=\"width: 85%; overflow: auto\">"
	."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\" align=\"center\" class=\"bgcolor4\">"
	."<tr bgcolor=\"F3E8FF\"><td colspan=\"2\"><font class=\"block-title\">PHP - ���</font></td></tr>"
	."<tr class=\"bgcolor1\"><td align=\"right\" class=\"code\" style=\"width: 5px; border-right: none\">{ZEILEN}</td><td>";
	$end_html = "</td></tr></table></div></div>";
	$match_count = preg_match_all("#\[php\](.*?)\[/php\]#si", $text, $matches);
    for ($mout = 0; $mout < $match_count; ++$mout) {
        $before_replace = $matches[1][$mout];
        $after_replace = $matches[1][$mout];
        $after_replace = trim ($after_replace);
		$after_replace = str_replace("&lt;", "<", $after_replace);
		$after_replace = str_replace("&gt;", ">", $after_replace);
		$after_replace = str_replace("&quot;", '"', $after_replace);
		$after_replace = preg_replace("/<br.*/i", "", $after_replace);
		$after_replace = (substr($after_replace, 0, 5 ) != "<?php") ? "<?php\n".$after_replace."" : "".$after_replace."";
		$after_replace = (substr($after_replace, -2 ) != "?>") ? "".$after_replace."\n?>" : "".$after_replace."";
        ob_start ();
        highlight_string ($after_replace);
        $after_replace = ob_get_contents ();
        ob_end_clean ();
		$zeilen_array = explode("<br />", $after_replace);
        $j = 1;
        $zeilen = "";
      foreach ($zeilen_array as $str) {
        $zeilen .= "".$j."<br />";
        ++$j;
      }
		$after_replace = str_replace("\n", "", $after_replace);
		$after_replace = str_replace("&amp;", "&", $after_replace);
		$after_replace = str_replace("  ", "&nbsp; ", $after_replace);
		$after_replace = str_replace("  ", " &nbsp;", $after_replace);
		$after_replace = str_replace("\t", "&nbsp; &nbsp;", $after_replace);
		$after_replace = preg_replace("/^ {1}/m", "&nbsp;", $after_replace);
		$str_to_match = "[php]".$before_replace."[/php]";
		$replace = str_replace("{ZEILEN}", $zeilen, $start_html);
      $replace .= $after_replace;
      $replace .= $end_html;
      $text = str_replace ($str_to_match, $replace, $text);
    }
	$text = str_replace("[php]", $start_html, $text);
	$text = str_replace("[/php]", $end_html, $text);
    return $text;
}


function agetostr($age)
   {
   if(($age>=5) && ($age<=14)) $str = "���";
   else {
   $num = $age - (floor($age/10)*10);

   if($num == 1) { $str = "���"; }
   elseif($num == 0) { $str = "���"; }
   elseif(($num>=2) && ($num<=4)) { $str = "����"; }
   elseif(($num>=5) && ($num<=9)) { $str = "���"; }
   }
   return $age . " " . $str ;
}

function tostr($age)
   {
  // if(($age>=5) && ($age<=14)) $str = "���";
   //else {
   $num = $age - (floor($age/10)*10);
   $num2 = (floor($age/10)*10);

   if($num == 1) { $str = "���"; }
 //  elseif($num == 0) { $str = "���"; }
   elseif(($num>=2) && ($num<=4)) { $str = "����"; }
   elseif(($num>=5) && ($num<=20)) { $str = "���"; }
 //  }
   return $age . " " . $str ;
}


function get_user_id() {
  global $CURUSER;
  return $CURUSER["id"];
}

function comment_hide($text) {
    $html = "<div align=\"left\"><div style=\"width: 100%; overflow: auto\">" 
    ."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\" align=\"center\" class=\"bgcolor4\">" 
    ."<tr bgcolor=\"red\"><td><b>������� �����</b></td></tr>
	<tr class=\"bgcolor1\">
	<td>" 
    ."<center><color=\"red\">.:: ���������� �������� �����������, ����� ������� ������� ����� ::.</color></center>
	</td></tr></table></div></div>"; 
	
    $start_html = "<div align=\"left\"><div style=\"width: 85%; overflow: auto\">" 
    ."<table width=\"100%\" cellspacing=\"1\" cellpadding=\"3\" border=\"0\" align=\"center\" class=\"bgcolor4\">" 
    ."<tr bgcolor=\"pink\"><td><font class=\"rowhead\">������� �����</font></td></tr><tr class=\"bgcolor1\"><td>"; 

    $end_html = "</td></tr></table></div></div>"; 
    if (basename($_SERVER['SCRIPT_FILENAME']) == 'details.php'){
    $id = (int) $_GET["id"];
    $res = sql_query("SELECT user FROM comments WHERE torrent=".$id." and user=".get_user_id().""); 
    while ($row = mysql_fetch_array($res)){
    $_user = $row['user']; 
    }
    }
    else
    $_user = "yes"; 
    
    if (get_user_class() >= UC_MODERATOR or $_user) 
    $text = preg_replace("#\[hide\](.*?)\[/hide\]#si", "".$start_html."\\1".$end_html."", $text); 
    else 
    $text = preg_replace("#\[hide\](.*?)\[/hide\]#si", "".$html."", $text); 

    return $text; 
}

function filter_badwords($string=false){
//setlocale (LC_ALL, "ru_RU.CP1251");

// ��������� ���������� ������� ����
$let_matches = array ("a" => "�","c" => "�","e" => "�","k" => "�","m" => "�","o" => "�","x" => "�","y" => "�","�" => "�");

//������ � �������� ������
$bad_words = array (".*��(�|�|�|�|�(�|�)).*", ".*��(�|�)�.*", "���.*", ".*���(�|�|�).*", "(�|��)��(�|�|�).*", "��.*", ".*���.*", "����.*", ".*��(�|�)(�|�|�|�).*", ".*���(�|�).*", ".*���(�|�)�.*", ".*���.*", "�(�|�)����", ".*�����.*");

function di($wor=false){
/// ��� �������� � �����
$di="<font color=gray><a title=\"��������� ��������� $wor\" style=\"cursor: help;\">��������</font>";
return $di;
}

$counter = 0;
$elems = explode(" ", $string);
$count_elems = count($elems);
for ($i=0; $i<$count_elems; $i++){
$blocked = 0;
$str_rep = eregi_replace ("[^a-zA-Z�-��-߸]", "", strtolower($elems[$i]));
for ($j=0; $j<strlen($str_rep); $j++){
foreach ($let_matches as $key => $value){
if ($str_rep[$j] == $key)
$str_rep[$j] = $value;
}}

for ($k=0; $k<count($bad_words); $k++){
if (ereg("\*$", $bad_words[$k])){
if (ereg("^".$bad_words[$k], $str_rep)){
$elems[$i] = di($str_rep);//$this->
$blocked = 1;
$counter++;
break;
}}

if ($str_rep == $bad_words[$k]){
$elems[$i] = di($str_rep);
$blocked = 1;
$counter++;
break;
}}}

if ($counter <> 0)
$string = implode(" ", $elems);
return $string;
}


function format_comment($text, $strip_html = true, $xssclean = false)
{
	global $smilies, $CURUSER,$BASEURL,$pic_base_url, $lang;	
	$s = $text;
	
	///$s = str_ireplace("pmrtorrents.com","pmrtorrent.org",$s);
	
	/*	   	
$htmltags = array(
                        '/\<b\>(.*?)\<\/b\>/is',                       
                        '/\<i\>(.*?)\<\/i\>/is',                           
                        '/\<u\>(.*?)\<\/u\>/is'
                        );

$bbtags = array(
                        '[b]$1[/b]',
                        '[i]$1[/i]',
                        '[u]$1[/u]',
                        '[list]$1[/list]'
                        );
$s = preg_replace ($htmltags, $bbtags, $s);

	*/
	
	$s = str_replace(";)", ";-)", $s);

	if ($strip_html)
	$s = htmlspecialchars($s);

	if ($xssclean)
	$s = xss_clean($s);
	// ������ ' �� ������
  ///  $s=preg_replace("/'/i"," ",$s );
	
	
		 // $sq=0;
 // while(preg_match("/\'/i",$s) && $sq%2==1) {
//  $s=preg_replace("/\'/i","<<",$s);
 // $s=preg_replace("/'/i"," ",$s );
//  $sq++;
//  }
  
//    while(preg_match("/\"/i",$s) && $sq%2==0) {
 //   $s=preg_replace("/\"/i",">>",$s);
//	$sq++;
 // }
  
	// [b]������[/b]
	$s = preg_replace("/\[b\]((\s|.)+?)\[\/b\]/", "<b>\\1</b>", $s);

	if (preg_match("#\[code\](.*?)\[/code\]#si", $s)) $s = encode_code($s);
	
	if (preg_match("#\[php\](.*?)\[/php\]#si", $s)) $s = encode_php($s);
	// [i]������[/i]
	$s = preg_replace("/\[i\]((\s|.)+?)\[\/i\]/", "<i>\\1</i>", $s);

	// [h]�������[/h]
	$s = preg_replace("/\[h\]((\s|.)+?)\[\/h\]/", "<h3>\\1</h3>", $s);

	// [u]������������[/u]
	$s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/", "<u>\\1</u>", $s);

	// [s]�����������[/s]
	$s = preg_replace("#\[s\](.*?)\[/s\]#si", "<s>\\1</s>", $s);

	// [li]
	$s = preg_replace("#\[li\]#si", "<li>", $s);
	
	// [hr]
	$s = preg_replace("#\[hr\]#si", "<hr>", $s);

	// [br]
	$s = preg_replace("#\[br\]#si", "<br>", $s);
	// [*]
	$s = preg_replace("/\[\*\]/", "<li>", $s);
	   	
///////////////////
 	   	
	// [audio]http://allsiemens.com/mp3/files/1.mp3[/audio]
	$s = preg_replace("/\[audio\]([^()<>\s]+?)\[\/audio\]/i","<embed autostart=\"false\" loop=\"false\" controller=\"true\" width=\"220\" height=\"42\" src=\\1></embed>", $s);
	   

	// [img]http://www/image.gif[/img]
	$s = preg_replace("/\[img\](http:\/\/[^\s'\"<>]+(\.(jpg|gif|png)))\[\/img\]/i", "<img border=\"0\" src=\"\\1\" alt=\"\">", $s);

	// [img=http://www/image.gif]
	$s = preg_replace("/\[img=(http:\/\/[^\s'\"<>]+(\.(gif|jpg|png)))\]/i", "<img border=\"0\" src=\"\\1\" alt=\"\">", $s);

	// [color=blue]�����[/color]
	$s = preg_replace("/\[color=([a-zA-Z]+)\]((\s|.)+?)\[\/color\]/i","<font color=\\1>\\2</font>", $s);

	// [color=#ffcc99]�����[/color]
	$s = preg_replace("/\[color=(#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])\]((\s|.)+?)\[\/color\]/i","<font color=\\1>\\2</font>", $s);

  // [url=http://www.example.com]������[/url]
    if (preg_match("/shoutbox/i", $_SERVER["SCRIPT_FILENAME"]))
        $s = preg_replace("/\[url=(http:\/\/[^()<>\s]+?)\]((\s|.)+?)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\2</a>", $s);
    else
        $s = preg_replace("/\[url=(http:\/\/[^()<>\s]+?)\]((\s|.)+?)\[\/url\]/i","<a href=\"\\1\" target=\"_self\">\\2</a>", $s);
    
    // [url]http://www.example.com[/url]
    if (preg_match("/shoutbox/i", $_SERVER["SCRIPT_FILENAME"]))
    $s = preg_replace("/\[url\](http:\/\/[^()<>\s]+?)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>", $s);
    else
        $s = preg_replace("/\[url\](http:\/\/[^()<>\s]+?)\[\/url\]/i","<a href=\"\\1\" target=\"_self\">\\1</a>", $s);
	

	// [url]http://www.example.com[/url]
	if (preg_match("/shoutbox/i", $_SERVER["SCRIPT_FILENAME"]))
	$s = preg_replace("/\[url\]([^()<>\s]+?)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>", $s);
	else
		$s = preg_replace("/\[url\]([^()<>\s]+?)\[\/url\]/i","<a href=\"\\1\" target=\"_self\">\\1</a>", $s);
	
	// �������� ������ ���� ����� ������, �������� ������������ ��� �����.
        $s = preg_replace("#\[(left|right|center|justify)\](.*?)\[/\\1\]#is", "<div align=\"\\1\">\\2</div>", $s);

	// [size=4]Text[/size] (�������� ������*)
	$s = preg_replace(
		"#\[size=([0-9]+)\](.*?)\[/size\]#si","<span style=\"font-size: \\1\">\\2</span>", $s);

// [font=Arial]Text[/font]
	$s = preg_replace("/\[font=([a-zA-Z ,]+)\]((\s|.)+?)\[\/font\]/i","<font face=\"\\1\">\\2</font>", $s);

	// ������ �������� � ����� �����������
	$s = preg_replace( "#<(\s+?)?s(\s+?)?c(\s+?)?r(\s+?)?i(\s+?)?p(\s+?)?t#is", "&lt;script", $s );
	$s = preg_replace( "#<(\s+?)?/(\s+?)?s(\s+?)?c(\s+?)?r(\s+?)?i(\s+?)?p(\s+?)?t#is", "&lt;/script", $s );
	$s = preg_replace( "/javascript/i" , "j&#097;v&#097;script", $s );
	$s = preg_replace( "/alert/i"      , "&#097;lert", $s );
	$s = preg_replace( "/about:/i"     , "&#097;bout:", $s );
	$s = preg_replace( "/onmouseover/i", "&#111;nmouseover", $s );
	$s = preg_replace( "/onclick/i"    , "&#111;nclick", $s );
	$s = preg_replace( "/onsubmit/i"   , "&#111;nsubmit", $s );
	$s = preg_replace( "/<body/i"      , "&lt;body", $s );
	$s = preg_replace( "/<html/i"      , "&lt;html", $s );
	$s = preg_replace( "/document\./i" , "&#100;ocument.", $s );
	
	$s = format_quotes($s);
	$s = format_urls($s);
	
    if (preg_match("#\[hide\](.*?)\[/hide\]#si", $s)) $s = comment_hide($s); 
    
	$s = nl2br($s);

	// [pre]Preformatted[/pre]	
	$s = preg_replace("/\[pre\](.*?)\[\/pre\]/is", "<pre>".htmlentities('\\1')."</pre>", $s);

	// [nfo]NFO-preformatted[/nfo]
	$s = preg_replace("/\[nfo\](.*?)\[\/nfo\]/is", "<tt><nobr><font face='MS Linedraw' size='2' style='font-size: 10pt; line-height: 10pt'>\\1</font></nobr></tt>", $s);		

	// [highlight]Highlight text[/highlight]
    $s = preg_replace("/\[highlight\]((\s|.)+?)\[\/highlight\]/", "<table border=0 cellspacing=0 cellpadding=1>"."<tr><td bgcolor=white><b>\\1</b></td></tr>"."</table>", $s);
  		
  	
	$s = preg_replace("/\[highback\]((\s|.)+?)\[\/highback\]/", "<span onmouseout=\"this.style.color='#DDDDDD';\" onmouseover=\"this.style.color='#0F6CEE';\" style=\"background: #DDDDDD none repeat scroll 0% 0%; color: #DDDDDD; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; cursor: help;\">\\1</span>", $s);
	  	

    $s = preg_replace("/\[legend=\s*((\s|.)+?)\s*\]((\s|.)+?)\[\/legend\]/i",   
        "<fieldset><legend>\\1</legend>\\3</fieldset>", $s,1);  
        
    $s = preg_replace("/\[legend\]\s*((\s|.)+?)\s*\[\/legend\]\s*/i",   
         "<fieldset>\\1</fieldset>", $s,1);  //<legend></legend>
  	
	  	
  	// [light]Highlight text[/light]
    $s = preg_replace("/\[light=([a-zA-Z�-��-�0-9_]+)\]((\s|.)+?)\[\/light\]/", "<script language=\"JavaScript1.2\">
<!--
var ns6=document.getElementById&&!document.all?1:0 var head=\"display:''\"  var folder='' function expandit(curobj){ folder=ns6?curobj.nextSibling.nextSibling.style:document.all[curobj.sourceIndex+1].style if (folder.display==\"none\") folder.display=\"\" else folder.display=\"none\" }
//-->
</script><center><h3 style=\"cursor:hand\" onClick=\"expandit(this)\">\\1</h3><span style=\"display:none\" style=&{head};>\\2</span></center>", $s);
  		

  // [marquee]Marquee[/marquee]
    $s = preg_replace("/\[marquee\]((\s|.)+?)\[\/marquee\]/", "<marquee behavior=\"alternate\">\\1</marquee>", $s);

 
    //[hr=#ffffff] [hr=red]
   // $s = preg_replace("/\[hr=((#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])|([a-zA-z]+))\]/i", "<hr color=\"\\1\"/>", $s);


    //[flash=320x240]http://somesite.com/test.swf[/flash]
    $s = preg_replace("/\[flash=(\d{1,3}):(\d{1,3})\]((www.|http:\/\/|https:\/\/)[^\s]+(\.swf))\[\/flash\]/i","<param name=movie value=\\3/><embed width=\\1 height=\\2 src=\\3></embed>", $s);

    //[flash]http://somesite.com/test.swf[/flash]
    $s = preg_replace("/\[flash]((www.|http:\/\/|https:\/\/)[^\s'\"<>&]+(\.swf))\[\/flash\]/i","<param name=movie value=\\1/><embed width=470 height=310 src=\\1></embed>", $s);


    // [mcom]Text[/mcom]
   $s = preg_replace("/\[mcom\]\s*((\s|.)+?)\s*\[\/mcom\]\s*/i","<span style=\"font-size: 18pt; line-height: 50%;\"><div style=\"border-color: red; background-color: red; color: white; text-align: center; font-weight: bold; font-size: small;\"><b>\\1</b></div></span>", $s);
   
	// [pi]
    $s = str_replace ("[pi]", "<br><center>&nbsp;--------------<b>����� ������</b>--------------</center><br>", $s);

	// [me]
    $s = str_replace ("[me]", "<script type=\"text/javascript\" src=js/blink.js></script><blink>
	<b><font title='IMHO - ���� ������!' color=red>IMHO</b></font></blink>&nbsp;", $s);



	// Maintain spacing
//	$s = str_replace("  ", " &nbsp;", $s);
	
	//linebreak
	$s = wordwrap($s, 97, "\n", 1);

    // YouTube Vids [video=http://www.youtube.com/watch?v=4HmeA_vHjzY]
    $s = preg_replace("/\[video=[^\s'\"<>]*youtube.com.*v=([^\s'\"<>]+)\]/ims", "<object width=\"500\" height=\"410\"><param name=\"movie\" value=\"http://www.youtube.com/v/\\1\"></param><embed src=\"http://www.youtube.com/v/\\1\" type=\"application/x-shockwave-flash\" width=\"500\" height=\"410\"></embed></object>", $s);
    
    // Google Vids
    $s = preg_replace("/\[video=[^\s'\"<>]*video.google.com.*docid=(-?[0-9]+).*\]/ims", "<embed style=\"width:500px; height:410px;\" id=\"VideoPlayback\" align=\"middle\" type=\"application/x-shockwave-flash\" src=\"http://video.google.com/googleplayer.swf?docId=\\1\" allowScriptAccess=\"sameDomain\" quality=\"best\" bgcolor=\"#ffffff\" scale=\"noScale\" wmode=\"window\" salign=\"TL\"  FlashVars=\"playerMode=embedded\"> </embed>", $s);


//[spoiler]��� �������[/spoiler] 

        global $nummatch;
 
        while(preg_match("/\[spoiler=\s*((\s|.)+?)\s*\]((\s|.)+?)\[\/spoiler\]/i",$s)) {
        $s = preg_replace("/\[spoiler=\s*((\s|.)+?)\s*\]((\s|.)+?)\[\/spoiler\]/i",   
        "
        <div style='border: 1px solid #E0E0E0; padding: 3px'>   
        <div style=\"cursor: pointer;\" style='padding-bottom: 3px' class='clickable' onclick=\"javascript: show_hide('s$nummatch')\" title='��������/������ �������' tooltip='��������'>   
        <img id='pics$nummatch' src='pic/plus.gif' border='0' title='��������/������ �������' tooltip='��������'> \\1</div>   
        <div id='ss$nummatch' style='DISPLAY: none; border: 1px dashed #E0E0E0; padding: 2px'>\\3</div>   
        </div>", $s,1);    

        $nummatch=$nummatch+1;
        if($nummatch>100) break; }

        while(preg_match("/\[spoiler\]\s*((\s|.)+?)\s*\[\/spoiler\]\s*/i",$s)) {
        $s = preg_replace("/\[spoiler\]\s*((\s|.)+?)\s*\[\/spoiler\]\s*/i",   
        "
        <div style='border: 1px solid #E0E0E0; padding: 3px'>   
        <div style=\"cursor: pointer;\" style='padding-bottom: 3px' class='clickable' onclick=\"javascript: show_hide('s$nummatch')\" title='��������/������ �������'>   
        <img id='pics$nummatch'src='pic/plus.gif' border='0' title='��������/������ �������' tooltip='��������'> ������� �����  
        </div>   
        <div id='ss$nummatch' style='DISPLAY: none; border: 1px dashed #E0E0E0; padding: 2px'>\\1</div>          </div>", $s,1);    
        $nummatch=$nummatch+1;  /// ������� � 1 �� 5 
        if($nummatch>100) break;  
}

    if (preg_match("/message/i", $_SERVER["SCRIPT_FILENAME"]))
    $s=filter_badwords($s);

	reset($smilies);
	while (list($code, $url) = each($smilies))
	

if (preg_match("/shoutbox/i", $_SERVER["SCRIPT_FILENAME"])){
$s = str_ireplace($code, "<img border=\"0\" onclick=\"parent.document.shoutform.shout.focus();parent.document.shoutform.shout.value=parent.document.shoutform.shout.value+' " . htmlspecialchars_uni($code) . " ';return false;\" style=\"font-weight: italic;\" src=\"pic/smilies/$url\" alt=\"" . htmlspecialchars_uni($code) . "\">", $s); } else {
$s = str_ireplace($code, "<img border=\"0\" src=\"pic/smilies/$url\" alt=\"" . htmlspecialchars_uni($code) . "\">", $s);
}

	/*
	reset($privatesmilies);
	while (list($code, $url) = each($privatesmilies))
		$s = str_replace($code, "<img border=\"0\" src=\"pic/smilies/$url\">", $s);
		
		*/


	return $s;
	unset($smilies);    //unset($privatesmilies);
}

function get_user_class() {
  global $CURUSER;
  return $CURUSER["class"];
}

function get_user_class_name($class) {
  global $tracker_lang;
  switch ($class) {
    case UC_USER: return $tracker_lang['class_user'];

    case UC_POWER_USER: return $tracker_lang['class_power_user'];

    case UC_VIP: return $tracker_lang['class_vip'];

    case UC_UPLOADER: return $tracker_lang['class_uploader'];

    case UC_MODERATOR: return $tracker_lang['class_moderator'];

    case UC_ADMINISTRATOR: return $tracker_lang['class_administrator'];

    case UC_SYSOP: return $tracker_lang['class_sysop'];
  }
  return "";
}

function is_valid_user_class($class) {
  return is_numeric($class) && floor($class) == $class && $class >= UC_USER && $class <= UC_SYSOP;
}

function is_valid_id($id) {
  return is_numeric($id) && ($id > 0) && (floor($id) == $id);
}

function sql_timestamp_to_unix_timestamp($s) {
  return mktime(substr($s, 11, 2), substr($s, 14, 2), substr($s, 17, 2), substr($s, 5, 2), substr($s, 8, 2), substr($s, 0, 4));
}

  function get_ratio_color($ratio) {
    if ($ratio < 0.1) return "#ff0000";
    if ($ratio < 0.2) return "#ee0000";
    if ($ratio < 0.3) return "#dd0000";
    if ($ratio < 0.4) return "#cc0000";
    if ($ratio < 0.5) return "#bb0000";
    if ($ratio < 0.6) return "#aa0000";
    if ($ratio < 0.7) return "#990000";
    if ($ratio < 0.8) return "#880000";
    if ($ratio < 0.9) return "#770000";
    if ($ratio < 1) return "#660000";
    return "#000000";
  }



  function get_slr_color($ratio) {
    if ($ratio < 0.025) return "#ff0000";
    if ($ratio < 0.05) return "#ee0000";
    if ($ratio < 0.075) return "#dd0000";
    if ($ratio < 0.1) return "#cc0000";
    if ($ratio < 0.125) return "#bb0000";
    if ($ratio < 0.15) return "#aa0000";
    if ($ratio < 0.175) return "#990000";
    if ($ratio < 0.2) return "#880000";
    if ($ratio < 0.225) return "#770000";
    if ($ratio < 0.25) return "#660000";
    if ($ratio < 0.275) return "#550000";
    if ($ratio < 0.3) return "#440000";
    if ($ratio < 0.325) return "#330000";
    if ($ratio < 0.35) return "#220000";
    if ($ratio < 0.375) return "#110000";
    return "#000000";
  }

  function get_comm_color($stepen) {
  if ($stepen < 5) return "#2e0101";
  if ($stepen < 10) return "#610000";
  if ($stepen < 15) return "#960505";
  if ($stepen < 20) return "#930000";
  if ($stepen < 25) return "#460088";
  if ($stepen < 25) return "#460088";
  if ($stepen < 25) return "#460088";
  if ($stepen < 30) return "#000388";
  if ($stepen < 35) return "#0005c5";
  if ($stepen < 40) return "#0208ff";
  if ($stepen < 50) return "#3802ff";
  if ($stepen < 60) return "#7902ff";
  if ($stepen < 70) return "#af02ff";
  if ($stepen < 80) return "#ff02f0";
  if ($stepen < 90) return "#ff029d";
  if ($stepen <> 100) return "#ff023e";

 
  //  return "#000000";
  }

function write_log($text, $color = "transparent", $type = "tracker") {
  $type = sqlesc($type);
  $color = sqlesc($color);
  $text = sqlesc($text);
  $added = sqlesc(get_date_time());
  sql_query("INSERT INTO sitelog (added, color, txt, type) VALUES($added, $color, $text, $type)");
}

function check_banned_emails ($email) {
$allowed_emails=array( 
"rambler.ru"=>1,
"gmail.com"=>2,
"live.ru"=>3,
"mail.ru"=>4,
"idknet.com"=>5,
"yandex.ru"=>6
); 

    $expl = explode("@", $email); 
    $wildemail = "*@".$expl[1]; 
    if($expl[2]!="")
     stderr("������!","�������� �����!", false);    
    if (!array_key_exists($expl[1], $allowed_emails))
      stderr("������!","���� ����� ������ �������!<br /><br /><strong>��������� ����� �� �������</strong>:<br>@rambler.ru<br>@gmail.com<br>@live.ru<br>@mail.ru<br>@idknet.com", false); 
    $res = mysql_query("SELECT id, comment FROM bannedemails WHERE email = ".sqlesc($email)." OR email = ".sqlesc($wildemail)."") or sqlerr(__FILE__, __LINE__); 
    if ($arr = mysql_fetch_assoc($res)) 
    stderr("������!","���� ����� ������ �������!<br /><br /><strong>�������</strong>: $arr[comment]", false); 
}

function random_color() {
	$allsymb="0123456789ABCDEF";
	$color="#";
	for($i=0;$i<6;$i=$i) 
	{
		$n=rand (0,15);
		if ($n) 
		{
			$color.= $allsymb[$n];
			$i++;
		}
	}
	return $color;
	/// ��������� ��� ����� � #
}

function mtime($time, $ntime, $end1, $end2, $end3) {
	$mtime = "" . $time;
	$time = $mtime [strlen ( $mtime ) - 1];
	$time2 = $mtime [strlen ( $mtime ) - 2] . $mtime [strlen ( $mtime ) - 1];
	return $mtime . " " . $ntime . ($time > 1 && $time < 5 && ! ($time2 >= 10 && $time2 < 20) ? $end1 : ($time >= 5 || $time == 0 || $time2 >= 10 && $time2 < 20 ? $end2 : ($time == 1 ? $end3 : "")));
}


function get_elapsed_time($U,$showseconds=true){
    if(!$U) return "N/A";
    $N = time();
    if ($N>=$U)
    $diff = $N-$U;
    else
    $diff = $U-$N;
    //year (365 days) = 31536000
    //month (30 days) = 2592000
    //week = 604800
    //day = 86400
    //hour = 3600

    if($diff>=31536000){
        $Iyear = floor($diff/31536000);
        $diff = $diff-($Iyear*31536000);
    }
    if($diff>=2629800){    //2592000 seconds in month with 30 days
        $Imonth = floor($diff/2629800);
        $diff = $diff-($Imonth*2629800);
    }
    if($diff>=604800){
        $Iweek = floor($diff/604800);
        $diff = $diff-($Iweek*604800);
    }
    if($diff>=86400){
        $Iday = floor($diff/86400);
        $diff = $diff-($Iday*86400);
    }
    if($diff>=3600){
        $Ihour = floor($diff/3600);
        $diff = $diff-($Ihour*3600);
    }
    if($diff>=60){
        $Iminute = floor($diff/60);
        $diff = $diff-($Iminute*60);
    }
    if($diff>0){
        $Isecond = floor($diff);
    }

    $j = " ";

    $ret = "";

    if(isset($Iyear)) $ret .= $Iyear." ".rusdate($Iyear,'year').$j;
    if(isset($Imonth)) $ret .= $Imonth ." ".rusdate($Imonth ,'month').$j;
    if(isset($Iweek)) $ret .= $Iweek ." ".rusdate($Iweek ,'week').$j;
    if(isset($Iday)) $ret .= $Iday ." ".rusdate($Iday ,'day').$j;
    if(isset($Ihour)) $ret .= $Ihour ." ".rusdate($Ihour ,'hour').$j;
    if(isset($Iminute)) $ret .= $Iminute ." ".rusdate($Iminute ,'minute').$j;

//    if($showseconds==false && $Iminute<1)$Iminute=0;
    if($showseconds==false && $Iminute<1 && $Ihour<1 && $Iday<1 && $Iweek<1 && $Imonth<1 && $Iyear<1)return rusdate(0 ,'minute');

    if(($Isecond>0 OR $ret=="") AND $showseconds==true){
        if($ret=="" AND !isset($Isecond))$Isecond=0;
        $ret .= $Isecond ." ".rusdate($Isecond ,'second').$j;
    }
    return $ret;
}

function rusdate($num,$type){
    $rus = array (
        "year"    => array( "���", "���", "����", "����", "����", "���", "���", "���", "���", "���"),
        "month"  => array( "�������", "�����", "������", "������", "������", "�������", "�������", "�������", "�������", "�������"),
        "week"  => array( "������", "������", "������", "������", "������", "������", "������", "������", "������", "������"),
        "day"   => array( "����", "����", "���", "���", "���", "����", "����", "����", "����", "����"),
        "hour"    => array( "�����", "���", "����", "����", "����", "�����", "�����", "�����", "�����", "�����"),
        "minute" => array( "�����", "������", "������", "������", "������", "�����", "�����", "�����", "�����", "�����"),
        "second" => array( "������", "�������", "�������", "�������", "�������", "������", "������", "������", "������", "������"),
    );

    $num = intval($num);
    if (10 < $num && $num < 20) return $rus[$type][0];
    return $rus[$type][$num % 10];
}



function toupper($content) {
$content = strtr($content, "��������������������������������",
"�����Ũ��������������������������");
return strtoupper($content);
}


function tolower($content) {
$content = strtr($content, "�����Ũ��������������������������",
"��������������������������������");
//return strtolower($content);
return mb_strtolower($content, 'cp1251');
}

function check_images($file){
    $h1count = preg_match_all('/(<img)\s (src="([a-zA-Z0-9\.;:\/\?&=_|\r|\n]{1,})")/isxmU',$file,$patterns);
    $imagesarray = array();
    array_push($imagesarray,$patterns[3]);
    array_push($imagesarray,$patterns[0]);
    
  $images = $imagesarray[0];
  $imagecodes = $imagesarray[1];
  if ($images)
    foreach ($images as $key => $image) {
      if (!@getimagesize($image)) {$bb[] = $imagecodes[$key]; $html[] = $image; }
    }
 if ($bb)
 $code = str_replace($bb,$html,$code);
 return $file;
}


function StdDecodePeerId($id_data, $id_name){
$version_str = "";
for ($i=0; $i<=strlen($id_data); $i++){
$c = $id_data[$i];
if ($id_name=="BitTornado" || $id_name=="ABC") {
if ($c!='-' && ctype_digit($c)) $version_str .= "$c.";
elseif ($c!='-' && ctype_alpha($c)) $version_str .= (ord($c)-55).".";
else break;
}
elseif($id_name=="BitComet"||$id_name=="BitBuddy"||$id_name=="Lphant"||$id_name=="BitPump"||$id_name=="BitTorrent Plus! v2") {
if ($c != '-' && ctype_alnum($c)){
$version_str .= "$c";
if($i==0) $version_str = intval($version_str) .".";
}
else{
$version_str .= ".";
break;
}
}
else {
if ($c != '-' && ctype_alnum($c)) $version_str .= "$c.";
else break;
}
}
$version_str = substr($version_str,0,strlen($version_str)-1);
return "$id_name $version_str";
}
function MainlineDecodePeerId($id_data, $id_name){
$version_str = "";
for ($i=0; $i<=strlen($id_data); $i++){
$c = $id_data[$i];
if ($c != '-' && ctype_alnum($c)) $version_str .= "$c.";
}
$version_str = substr($version_str,0,strlen($version_str)-1);
return "$id_name $version_str";
}
function DecodeVersionString ($ver_data, $id_name){
$version_str = "";
$version_str .= intval(ord($ver_data[0]) + 0).".";
$version_str .= intval(ord($ver_data[1])/10 + 0);
$version_str .= intval(ord($ver_data[1])%10 + 0);
return "$id_name $version_str";
}

function getagent($httpagent, $peer_id="") {
// if($peer_id!="") $peer_id=hex2bin($peer_id);
if(substr($peer_id,0,3)=='-AX') return StdDecodePeerId(substr($peer_id,4,4),"BitPump"); # AnalogX BitPump
if(substr($peer_id,0,3)=='-BB') return StdDecodePeerId(substr($peer_id,3,5),"BitBuddy"); # BitBuddy
if(substr($peer_id,0,3)=='-BC') return StdDecodePeerId(substr($peer_id,4,4),"BitComet"); # BitComet
if(substr($peer_id,0,3)=='-BS') return StdDecodePeerId(substr($peer_id,3,7),"BTSlave"); # BTSlave
if(substr($peer_id,0,3)=='-BX') return StdDecodePeerId(substr($peer_id,3,7),"BittorrentX"); # BittorrentX
if(substr($peer_id,0,3)=='-CT') return "Ctorrent $peer_id[3].$peer_id[4].$peer_id[6]"; # CTorrent
if(substr($peer_id,0,3)=='-KT') return StdDecodePeerId(substr($peer_id,3,7),"KTorrent"); # KTorrent
if(substr($peer_id,0,3)=='-LT') return StdDecodePeerId(substr($peer_id,3,7),"libtorrent"); # libtorrent
if(substr($peer_id,0,3)=='-LP') return StdDecodePeerId(substr($peer_id,4,4),"Lphant"); # Lphant
if(substr($peer_id,0,3)=='-MP') return StdDecodePeerId(substr($peer_id,3,7),"MooPolice"); # MooPolice
if(substr($peer_id,0,3)=='-MT') return StdDecodePeerId(substr($peer_id,3,7),"Moonlight"); # MoonlightTorrent
if(substr($peer_id,0,3)=='-PO') return StdDecodePeerId(substr($peer_id,3,7),"PO Client"); #unidentified clients with versions
if(substr($peer_id,0,3)=='-QT') return StdDecodePeerId(substr($peer_id,3,7),"Qt 4 Torrent"); # Qt 4 Torrent
if(substr($peer_id,0,3)=='-RT') return StdDecodePeerId(substr($peer_id,3,7),"Retriever"); # Retriever
if(substr($peer_id,0,3)=='-S2') return StdDecodePeerId(substr($peer_id,3,7),"S2 Client"); #unidentified clients with versions
if(substr($peer_id,0,3)=='-SB') return StdDecodePeerId(substr($peer_id,3,7),"Swiftbit"); # Swiftbit
if(substr($peer_id,0,3)=='-SN') return StdDecodePeerId(substr($peer_id,3,7),"ShareNet"); # ShareNet
if(substr($peer_id,0,3)=='-SS') return StdDecodePeerId(substr($peer_id,3,7),"SwarmScope"); # SwarmScope
if(substr($peer_id,0,3)=='-SZ') return StdDecodePeerId(substr($peer_id,3,7),"Shareaza"); # Shareaza
if(preg_match("/^RAZA ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches)) return "Shareaza $matches[1]";
if(substr($peer_id,0,3)=='-TN') return StdDecodePeerId(substr($peer_id,3,7),"Torrent.NET"); # Torrent.NET
if(substr($peer_id,0,3)=='-TR') return StdDecodePeerId(substr($peer_id,3,7),"Transmission"); # Transmission
if(substr($peer_id,0,3)=='-TS') return StdDecodePeerId(substr($peer_id,3,7),"TorrentStorm"); # Torrentstorm
if(substr($peer_id,0,3)=='-UR') return StdDecodePeerId(substr($peer_id,3,7),"UR Client"); # unidentified clients with versions
if(substr($peer_id,0,3)=='-UT') return StdDecodePeerId(substr($peer_id,3,7),"uTorrent"); # uTorrent
if(substr($peer_id,0,3)=='-XT') return StdDecodePeerId(substr($peer_id,3,7),"XanTorrent"); # XanTorrent
if(substr($peer_id,0,3)=='-ZT') return StdDecodePeerId(substr($peer_id,3,7),"ZipTorrent"); # ZipTorrent
if(substr($peer_id,0,3)=='-bk') return StdDecodePeerId(substr($peer_id,3,7),"BitKitten"); # BitKitten
if(substr($peer_id,0,3)=='-lt') return StdDecodePeerId(substr($peer_id,3,7),"libTorrent"); # libTorrent
if(substr($peer_id,0,3)=='-pX') return StdDecodePeerId(substr($peer_id,3,7),"pHoeniX"); # pHoeniX
if(substr($peer_id,0,2)=='BG') return StdDecodePeerId(substr($peer_id,2,4),"BTGetit"); # BTGetit
if(substr($peer_id,2,2)=='BM') return DecodeVersionString(substr($peer_id,0,2),"BitMagnet"); # BitMagnet
if(substr($peer_id,0,2)=='OP') return StdDecodePeerId(substr($peer_id,2,4),"Opera"); # Opera
if(substr($peer_id,0,4)=='270-') return "GreedBT 2.7.0"; # GreedBT
if(substr($peer_id,0,4)=='271-') return "GreedBT 2.7.1"; # GreedBT 2.7.1
if(substr($peer_id,0,4)=='346-') return "TorrentTopia"; # TorrentTopia
if(substr($peer_id,0,3)=='-AR') return "Arctic Torrent"; # Arctic (no way to know the version)
if(substr($peer_id,0,3)=='-G3') return "G3 Torrent"; # G3 Torrent
if(substr($peer_id,0,6)=='BTDWV-') return "Deadman Walking"; # Deadman Walking
if(substr($peer_id,5,7)=='Azureus') return "Azureus 2.0.3.2"; # Azureus 2.0.3.2
if(substr($peer_id,0,8 )=='PRC.P---') return "BitTorrent Plus! II"; # BitTorrent Plus! II
if(substr($peer_id,0,8 )=='S587Plus') return "BitTorrent Plus!"; # BitTorrent Plus!
if(substr($peer_id,0,7)=='martini') return "Martini Man"; # Martini Man
if(substr($peer_id,4,6)=='btfans') return "SimpleBT"; # SimpleBT
if(substr($peer_id,3,9)=='SimpleBT?') return "SimpleBT"; # SimpleBT
if(ereg("MFC_Tear_Sample", $httpagent)) return "SimpleBT";
if(substr($peer_id,0,5)=='btuga') return "BTugaXP"; # BTugaXP
if(substr($peer_id,0,5)=='BTuga') return "BTuga"; # BTugaXP
if(substr($peer_id,0,5)=='oernu') return "BTugaXP"; # BTugaXP
if(substr($peer_id,0,10)=='DansClient') return "XanTorrent"; # XanTorrent
if(substr($peer_id,0,16)=='Deadman Walking-') return "Deadman"; # Deadman client
if(substr($peer_id,0,8 )=='XTORR302') return "TorrenTres 0.0.2"; # TorrenTres
if(substr($peer_id,0,7)=='turbobt') return "TurboBT ".(substr($peer_id,7,5)); # TurboBT
if(substr($peer_id,0,7)=='a00---0') return "Swarmy"; # Swarmy
if(substr($peer_id,0,7)=='a02---0') return "Swarmy"; # Swarmy
if(substr($peer_id,0,7)=='T00---0') return "Teeweety"; # Teeweety
if(substr($peer_id,0,7)=='rubytor') return "Ruby Torrent v".ord($peer_id[7]); # Ruby Torrent
if(substr($peer_id,0,5)=='Mbrst') return MainlineDecodePeerId(substr($peer_id,5,5),"burst!"); # burst!
if(substr($peer_id,0,4)=='btpd') return "BT Protocol Daemon ".(substr($peer_id,5,3)); # BT Protocol Daemon
if(substr($peer_id,0,8 )=='XBT022--') return "BitTorrent Lite"; # BitTorrent Lite based on XBT code
if(substr($peer_id,0,3)=='XBT') return StdDecodePeerId(substr($peer_id,3,3), "XBT"); # XBT Client
if(substr($peer_id,0,4)=='-BOW') return StdDecodePeerId(substr($peer_id,4,5),"Bits on Wheels"); # Bits on Wheels
if(substr($peer_id,1,2)=='ML') return MainlineDecodePeerId(substr($peer_id,3,5),"MLDonkey"); # MLDonkey
if(substr($peer_id,0,8 )=='AZ2500BT') return "AzureusBitTyrant 1.0/1";
if($peer_id[0]=='A') return StdDecodePeerId(substr($peer_id,1,9),"ABC"); # ABC
if($peer_id[0]=='R') return StdDecodePeerId(substr($peer_id,1,5),"Tribler"); # Tribler
if($peer_id[0]=='M'){
if(preg_match("/^Python/", $httpagent, $matches)) return "Spoofing BT Client"; # Spoofing BT Client
return MainlineDecodePeerId(substr($peer_id,1,7),"Mainline"); # Mainline BitTorrent with version
}
if($peer_id[0]=='O') return StdDecodePeerId(substr($peer_id,1,9),"Osprey Permaseed"); # Osprey Permaseed
if($peer_id[0]=='S'){
if(preg_match("/^BitTorrent\/3.4.2/", $httpagent, $matches)) return "Spoofing BT Client"; # Spoofing BT Client
return StdDecodePeerId(substr($peer_id,1,9),"Shad0w"); # Shadow's client
}
if($peer_id[0]=='T'){
if(preg_match("/^Python/", $httpagent, $matches)) return "Spoofing BT Client"; # Spoofing BT Client
return StdDecodePeerId(substr($peer_id,1,9),"BitTornado"); # BitTornado
}
if($peer_id[0]=='U') return StdDecodePeerId(substr($peer_id,1,9),"UPnP"); # UPnP NAT Bit Torrent
# Azureus / Localhost
if(substr($peer_id,0,3)=='-AZ') {
if(preg_match("/^Localhost ([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches)) return "Localhost $matches[1]";
if(preg_match("/^BitTorrent\/3.4.2/", $httpagent, $matches)) return "Spoofing BT Client"; # Spoofing BT Client
if(preg_match("/^Python/", $httpagent, $matches)) return "Spoofing BT Client"; # Spoofing BT Client
return StdDecodePeerId(substr($peer_id,3,7),"Azureus");
}
if(ereg("Azureus", $peer_id)) return "Azureus 2.0.3.2";
# BitComet/BitLord/BitVampire/Modded FUTB BitComet
if(substr($peer_id,0,4)=='exbc' || substr($peer_id,1,3)=='UTB'){
if(substr($peer_id,0,4)=='FUTB') return DecodeVersionString(substr($peer_id,4,2),"BitComet Mod1");
elseif(substr($peer_id,0,4)=='xUTB') return DecodeVersionString(substr($peer_id,4,2),"BitComet Mod2");
elseif(substr($peer_id,6,4)=='LORD') return DecodeVersionString(substr($peer_id,4,2),"BitLord");
elseif(substr($peer_id,6,3)=='---' && DecodeVersionString(substr($peer_id,4,2),"BitComet")=='BitComet 0.54') return "BitVampire";
else return DecodeVersionString(substr($peer_id,4,2),"BitComet");
}
# Rufus
if(substr($peer_id,2,2)=='RS'){
for ($i=0; $i<=strlen(substr($peer_id,4,9)); $i++){
$c = $peer_id[$i+4];
if (ctype_alnum($c) || $c == chr(0)) $rufus_chk = true;
else break;
}
if ($rufus_chk) return DecodeVersionString(substr($peer_id,0,2),"Rufus"); # Rufus
}
# BitSpirit
if(substr($peer_id,14,6)=='HTTPBT' || substr($peer_id,16,4)=='UDP0') {
if(substr($peer_id,2,2)=='BS') {
if($peer_id[1]==chr(0)) return "BitSpirit v1";
if($peer_id[1]== chr(2)) return "BitSpirit v2";
}
return "BitSpirit";
}
#BitSpirit
if(substr($peer_id,2,2)=='BS') {
if($peer_id[1]==chr(0)) return "BitSpirit v1";
if($peer_id[1]==chr(2)) return "BitSpirit v2";
return "BitSpirit";
}
# eXeem beta
if(substr($peer_id,0,3)=='-eX') {
$version_str = "";
$version_str .= intval($peer_id[3],16).".";
$version_str .= intval($peer_id[4],16);
return "eXeem $version_str";
}
if(substr($peer_id,0,2)=='eX') return "eXeem"; # eXeem beta .21
if(substr($peer_id,0,12)==(chr(0)*12) && $peer_id[12]==chr(97) && $peer_id[13]==chr(97)) return "Experimental 3.2.1b2"; # Experimental 3.2.1b2
if(substr($peer_id,0,12)==(chr(0)*12) && $peer_id[12]==chr(0) && $peer_id[13]==chr(0)) return "Experimental 3.1"; # Experimental 3.1
//if(substr($peer_id,0,12)==(chr(0)*12)) return "Mainline (obsolete)"; # Mainline BitTorrent (obsolete)
//return "$httpagent [$peer_id]";
return "����������� ������";
}



define ("VERSION", "<b>.:$SITENAME <a href=\"http://www.muz-tracker.net/\" class=\"copyright\" alt=\"���� ������ �� ������ ��� ��������� Tesla Tracker (TT) � ".date("Y")." ����. ����������� �������� Dimton � ������.\" title=\"���� ������ �� ������ ��� ��������� Tesla Tracker (TT) � ".date("Y")." ����. ����������� �������� 7Max7 � Imperator.\"/>�</a> ".date("Y")." v.Gold:.<b>");
define ("TBVERSION", "");
?>