<?
if(!defined('IN_TRACKER'))  die('Hacking attempt! Global');

$zodiac[] = array("�������", "capricorn.gif", "22-12");
$zodiac[] = array("�������", "sagittarius.gif", "23-11");
$zodiac[] = array("��������", "scorpio.gif", "24-10");
$zodiac[] = array("����", "libra.gif", "24-09");
$zodiac[] = array("����", "virgo.gif", "24-08");
$zodiac[] = array("���", "leo.gif", "23-07");
$zodiac[] = array("���", "cancer.gif", "22-06");
$zodiac[] = array("��������", "gemini.gif", "22-05");
$zodiac[] = array("�����", "taurus.gif", "21-04");
$zodiac[] = array("����", "aries.gif", "22-03");
$zodiac[] = array("����", "pisces.gif", "21-02");
$zodiac[] = array("�������", "aquarius.gif", "21-01");

$smilies = array(
  ";-)" => "wink.gif",
  ":-)" => "gib.gif",
  ":-(" => "ac.gif",
  ":smile:" => "gab.gif",
  ":-D" => "grin.gif",
    ":lol:" => "bj.gif",
  "O_o" => "ai.gif",
  ":-p" => "ae.gif", 
"8-)" => "af.gif", 
":-:" => "aj.gif", 
":'(" => "ak.gif",
":-x" => "al.gif",
":evil:" => "evil.gif",
":no:" => "no.gif",
":?:" => "question.gif",
":!:" => "excl.gif",
":hmm:" => "hmm.gif",
":hmmm:" => "hmmm.gif",
":idea:" => "idea.gif",
":love:" => "love.gif",
":nuke:" => "nuke.gif",
":thumbsup:" => "thumbsup.gif",
":thumbsdown:" => "thumbsdown.gif",
":tease:" => "tease.gif",
":wall:" => "wall.gif",
//">:o" => "am.gif",
":-|" => "an.gif",
":-/" => "ao.gif",
":jokingly:" => "ap.gif",
"]:->" => "aq.gif",
"[:-}" => "ar.gif",
":kissed:" => "as.gif",
":-!" => "at.gif",
":tired:" => "au.gif",
":evil_baby:" => "cv.gif",
":stop:" => "av.gif",
":kissing:" => "aw.gif",
"@}->--" => "ax.gif",
":thumbs_up" => "ay.gif",
":drink:" => "az.gif",
"@=" => "bb.gif",
":help:" => "bc.gif",
":m:" => "bd.gif",
"%)" => "be.gif",
":ok:" => "bf.gif",
":wassup:" => "bg.gif",
":sorry:" => "bh.gif",
":bravo:" => "bi.gif",
":pardon:" => "bk.gif",
":no:" => "bl.gif",
":crazy:" => "bm.gif",
":dont_know:" => "bn.gif",
":dance:" => "bo.gif",
":yahoo:" => "bp.gif",
":blush:" => "ah.gif",
":new_pack:" => "bq.gif",
":tease:" => "br.gif",
":saliva:" => "bs.gif",
":wild:" => "bu.gif",
":training:" => "bv.gif",
":focus:" => "bw.gif",
":hang:" => "bx.gif",
":dance:" => "by.gif",
":dance2:" => "bz.gif",
":mega_shok:" => "ca.gif",
":to_pick_ones_nose:" => "cb.gif",
":yu:" => "cc.gif",
":hunter:" => "cd.gif",
":kuku:" => "ce.gif",
":fuck:" => "cf.gif",
":fan:" => "cg.gif",
":ass:" => "ch.gif",
":locomotive:" => "ci.gif",
":concussion:" => "ck.gif",
":pleasantry:" => "cl.gif",
":disappear:" => "cm.gif",
":suicide:" => "cn.gif",
":pilot:" => "co.gif",
":down:" => "cp.gif",
":energy:" => "cq.gif",
":stinker:" => "cr.gif",
":preved:" => "cs.gif",
":i-m_so_happy:" => "ct.gif", 
":prankster:" => "cu.gif", 
":boast:" => "cw.gif", 
":thank_you:" => "cx.gif", 
":lovers:" => "lovers.gif", 
":shout:" => "cy.gif", 
":victory:" => "cz.gif", 
":wink:" => "da.gif", 
":spiteful:" => "db.gif", 
":this:" => "dd.gif", 
":don-t_mention:" => "de.gif", 
":sarcastic_hand:" => "df.gif", 
":fie:" => "dg.gif", 
":swoon:" => "dh.gif", 
":scare:" => "di.gif", 
":anger:" => "dj.gif", 
":yess:" => "dk.gif", 
":vava:" => "dl.gif", 
":scratch_one-s_head:" => "dm.gif", 
":nono:" => "dn.gif",
":whistle:" => "do.gif", 
":umnik:" => "dp.gif", 
":zoom:" => "dq.gif", 
":heat:" => "dr.gif", 
":declare:" => "ds.gif", 
":idea:" => "dt.gif", 
":on_the_quiet:" => "du.gif", 
":give_heart:" => "dv.gif", 
":give_flowers:" => "dw.gif", 
":friends:" => "dx.gif", 
":punish:" => "dy.gif", 
":porka:" => "dz.gif", 
":party:" => "ea.gif", 
":girl_smile:" => "eb.gif", 
":tender:" => "ec.gif", 
":flirt:" => "ed.gif", 
":curtsey:" => "ee.gif", 
":gogot:" => "ef.gif", 
":girl_wink:" => "eg.gif", 
":girl_blum:" => "eh.gif", 
":girl_hide:" => "ei.gif", 
":girl_crazy:" => "ej.gif", 
":girl_wacko:" => "ek.gif", 
":girl_in_love:" => "el.gif", 
":girl_dance:" => "em.gif", 
":kiss2:" => "en.gif", 
":girl_pinkglassesf:" => "eo.gif", 
":girl_mad:" => "ep.gif", 
":histeric:" => "eq.gif", 
":girl_sigh:" => "er.gif", 
":girl_sad:" => "es.gif", 
":girl_cray:" => "et.gif", 
":girl_cray2:" => "eu.gif", 
":girl_impossible:" => "ev.gif", 
":girl_drink:" => "ew.gif", 
":girl_mirror:" => "ex.gif", 
":nails:" => "ey.gif", 
":girl_hospital:" => "ez.gif", 
":girl_kid:" => "fa.gif", 
":girl_hair_drier:" => "fb.gif", 
":girl_witch:" => "fc.gif", 
":first_movie:" => "fd.gif", 
":slap_in_the_face:" => "fe.gif", 
":friendship:" => "ff.gif", 
":girl_kisses:" => "fg.gif", 
":on_hands:" => "fh.gif", 
":it_is_love:" => "fi.gif", 
":supper_for_a_two:" => "fj.gif", 
":sex_behind:" => "fk.gif", 
//":sex_bed:" => "fl.gif", 
":baby1:" => "fm.gif", 
":baby2:" => "fn.gif", 
":baby3:" => "fo.gif", 
":baby4:" => "fp.gif", 
":baby5:" => "fq.gif", 
":music_forge:" => "fr.gif", 
":music_saxophone:" => "fs.gif", 
":music_flute:" => "ft.gif", 
":music_violin:" => "fu.gif", 
":music_piano:" => "fv.gif", 
":music_drums:" => "fw.gif", 
":music_accordion:" => "fx.gif", 
":vinsent:" => "fy.gif", 
":frenk:" => "fx.gif", 
":tommy:" => "ga.gif", 
":big_boss:" => "gb.gif", 
":hi:" => "gc.gif", 
":buba:" => "gd.gif", 
":russian_ru:" => "ge.gif", 
":brunette:" => "gf.gif", 
":girl_devil:" => "gg.gif", 
":girl_werewolf:" => "gh.gif", 
":queen:" => "gi.gif", 
":king:" => "gj.gif",
 ":beach:" => "gk.gif",
  ":smoke:" => "gl.gif",
   ":scenic:" => "gm.gif",
    ":reader:" => "gn.gif",
	 ":read:" => "go.gif",
	  ":rtfm:" => "gp.gif",
	   ":to_keep_order:" => "gq.gif",
	    ":wizard:" => "gr.gif",
    ":lazy:" => "gs.gif",
	 ":dental:" => "gt.gif",
	  ":superstition:" => "gu.gif",
	   ":crazy_pilot:" => "gv.gif",
	    ":to_become_senile:" => "gw.gif",
		 ":download:" => "gx.gif",
		  ":telephone:" => "gy.gif",
	   ":diver:" => "gz.gif",
    ":wake_up:" => "ha.gif", 
	":ice_cream:" => "hb.gif",
	 ":journalist:" => "hc.gif", 
	 ":soap_bubbles:" => "hd.gif",
    ":body_builder:" => "he.gif",
	 ":cup_of_coffee:" => "hf.gif", 
	 ":soccer:" => "hg.gif", 
	 ":swimmer:" => "hh.gif",
    ":pirate:" => "hi.gif", 
	":clown:" => "hj.gif",
	 ":jester:" => "hk.gif", 
	 ":cannibal_drums:" => "hl.gif",
	  ":pioneer:" => "hm.gif", 
	  ":moil:" => "hn.gif",
	 ":paint:" => "ho.gif",
	  ":superman:" => "hp.gif",
	  ":cold:" => "hq.gif",
	   ":illness:" => "hr.gif",
	 ":winner:" => "hs.gif",
	  ":police:" => "ht.gif",
	  ":toilet_plums:" => "hu.gif",
	   ":death:" => "hv.gif",
    ":zombie:" => "hw.gif", 
	":ufo:" => "hx.gif",
	 ":sun:" => "hy.gif", 
	 ":pumpkin_grief:" => "hz.gif",
	  ":pumpkin_smile:" => "ia.gif",
    ":pooh_go:" => "ib.gif",
        ":cupidon:" => "cupidgirl.gif",
         ":oops:" => "eu.gif",
":usall:" => "ew.gif",
":too:" => "ex.gif",

);

/*$privatesmilies = array(
 // ":)" => "smile1.gif",
 // ";)" => "wink.gif",
  ":D" => "grin.gif",
  ":P" => "tongue.gif",
  ":(" => "sad.gif",
  ":'(" => "cry.gif",
  ":|" => "noexpression.gif",
  // "8)" => "cool1.gif",   we don't want this as a smilie...
  ":Boozer:" => "alcoholic.gif",
  ":deadhorse:" => "deadhorse.gif",
  ":spank:" => "spank.gif",
  ":yoji:" => "yoji.gif",
  ":locked:" => "locked.gif",
  ":grrr:" => "angry.gif", 			// legacy
  "O:-" => "innocent.gif",			// legacy
  ":sleeping:" => "sleeping.gif",	// legacy
  "-_-" => "unsure.gif",			// legacy
  ":clown:" => "clown.gif",
  ":mml:" => "mml.gif",
  ":rtf:" => "rtf.gif",
  ":morepics:" => "morepics.gif",
  ":rb:" => "rb.gif",
  ":rblocked:" => "rblocked.gif",
  ":maxlocked:" => "maxlocked.gif",
  ":hslocked:" => "hslocked.gif",
);
*/
// Set this to the line break character sequence of your system
//$linebreak = "\r\n";


function ajaxerr($text, $width="135") 
{
  print("<div id='ajaxerror' style='width: ".$width."px;'>$text</div>\n"); 
  return; 
}

function ajaxsucc($text, $width="135") 
{
  print("<div id=ajaxsuccess style='width: ".$width."px;'>$text</div>\n"); 
  return; 
}  


function accessadministration() {
loggedinorreturn();
global $CURUSER;

$config_file='include/passwords.php'; 
$check=fopen($config_file,'r'); 
$contents=fread($check,filesize($config_file)); 
fclose($check); 
if (filesize($config_file) > 10) {
include($config_file); 
define ('USERACCSESS',$useraccess_fix_by_imperator); 
define ('PASSACCSESS',$passaccess_fix_by_imperator); 
}

if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER']<>USERACCSESS || md5(md5($_SERVER['PHP_AUTH_PW']))<>PASSACCSESS) {
header("WWW-Authenticate: Basic realm=\"Administration\""); 
header("HTTP/1.0 401 Unauthorized");

$host=getenv("REQUEST_URI"); $ip=getenv("REMOTE_ADDR"); 
// write_log("������� ����� ".$CURUSER["username"]." � ������������ ������ �����. ������. Ip: <strong>$ip</strong>. ����: <strong>".$host."</strong>","#BCD2E6","error"); 
stdheadchat();
print("".$CURUSER["username"]." ������� �� �����. <br><br><h3>������ ��������!</h3><br><br>
�������� ���� <a href=\"$from\">������</a> ������? <br><br> ��� �� �� <a href=\"index.php\">�������</a> �����.
<br><br><br>");
stdfootchat();die;
}
}

function message_to_icq($to_icq,$to_message) {
if (ctype_digit($to_icq)){
////////// icq //////////
class WebIcqLite_TLV {var $type;var $size;var $error; var $types = array('UIN'=> 1,'DATA'=> 2,'CLIENT'=> 3,'ERROR_URL'=> 4,'RECONECT_HERE'=> 5, 'COOKIE' => 6, 'SNAC_VERSION' => 7, 'ERROR_SUBCODE' => 8, 'DISCONECT_REASON' => 9, 'RECONECT_HOST' => 10, 'URL' => 11,'DEBUG_DATA' => 12, 'SERVICE' => 13, 'CLIENT_COUNTRY' => 14, 'CLIENT_LNG' => 15, 'SCRIPT' => 16, 'USER_EMAIL' => 17, 'OLD_PASSWORD' => 18, 'REG_STATUS' => 19, 'DISTRIB_NUMBER' => 20, 'PERSONAL_TEXT' => 21, 'CLIENT_ID' => 22, 'CLI_MAJOR_VER' => 23,'CLI_MINOR_VER' => 24, 'CLI_LESSER_VER' => 25, 'CLI_BUILD_NUMBER' => 26,
// 'PASSWORD' => 37
);
function setTLV($type, $value, $length = false){switch ($length){case 1: $format = 'c';break;case 2: $format = 'n';break;case 4: $format = 'N';break;default: $format = 'a*';break;}if ($length === false){$length = strlen($value);}return pack('nn'.$format, $this->types[$type], $length, $value);}function getTLV($data){$arr = unpack('n2', substr($data, 0, 4));$this->type = $arr[1]; $this->size = $arr[2];return substr($data, 4, $this->size);}function getTLVFragment($data){$frg = unpack('cid/cversion/nsize', substr($data, 0, 4));$frg['data'] = substr($data, 4, $frg['size']);return $frg;}}class WebIcqLite_SNAC extends WebIcqLite_TLV {var $request_id = 0;var $uin;function setSNAC0102(){$this->request_id++;$out = pack('nnnN', 1, 2, 0, $this->request_id); $out .= pack('n*', 1, 3, 272, 650); $out .= pack('n*', 2, 1, 272, 650); $out .= pack('n*', 3, 1, 272, 650); $out .= pack('n*', 21, 1, 272, 650); $out .= pack('n*', 4, 1, 272, 650); $out .= pack('n*', 6, 1, 272, 650); $out .= pack('n*', 9, 1, 272, 650); $out .= pack('n*', 10, 1, 272, 650);return $out;}function setSNAC0406($uin, $message){$this->request_id++; $cookie = microtime();$out = pack('nnnNdnca*', 4, 6, 0, $this->request_id, $cookie, 2, strlen($uin), $uin);
$capabilities = pack('H*', '094613494C7F11D18222444553540000'); // utf-8 support
// '97B12751243C4334AD22D6ABF73F1492' rtf support
$data = pack('nd', 0, $cookie).$capabilities; $data .= pack('nnn', 10, 2, 1); $data .= pack('nn', 15, 0); $data .= pack('nnvvddnVn', 10001, strlen($message)+62, 27, 8, 0, 0, 0, 3, $this->request_id); $data .= pack('nndnn', 14, $this->request_id, 0, 0, 0); $data .= pack('ncvnva*', 1, 0, 0, 1, (strlen($message)+1), $message); $data .= pack('H*', '0000000000FFFFFF00'); $out .= $this->setTLV('RECONECT_HERE', $data); $out .= $this->setTLV('CLIENT', '');return $out;}function setSNAC0406offline($uin, $message){$this->request_id++; $cookie = microtime();$out = pack('nnnNdnca*', 4, 6, 0, $this->request_id, $cookie, 1, strlen($uin), $uin);$data = pack('ccnc', 5, 1, 1, 1); $data .= pack('ccnnna*', 1, 1, strlen($message)+4, 3, 0, $message);$out .= $this->setTLV('DATA', $data); $out .= $this->setTLV('CLIENT', ''); $out .= $this->setTLV('COOKIE', '');return $out;}function getSNAC0407($body){if (strlen($body)){$msg = unpack('nfamily/nsubtype/nflags/Nrequestid/N2msgid/nchannel/cnamesize', $body);if ($msg['family'] == 4 && $msg['subtype'] == 7){$body = substr($body, 21);$from = substr($body, 0, $msg['namesize']);$channel = $msg['channel'];$body = substr($body, $msg['namesize']);$msg = unpack('nwarnlevel/nTLVnumber', $body);$body = substr($body, 4);for ($i = 0; $i <= $msg['TLVnumber']; $i++){$part = $this->getTLV($body);$body = substr($body, 4 + $this->size);if ($channel == 1 && $this->type == 2){while (strlen($part)){$frg = $this->getTLVFragment($part);if ($frg['id'] == 1 && $frg['version'] == 1){return array('from' => $from, 'message' => substr($frg['data'], 4));}$part = substr($part, 4+$frg['size']);}return false;}}}}return false;}function dump($str){$f = fopen('dump', 'a'); fwrite($f, $str); fclose($f);}}class WebIcqLite_FLAP extends WebIcqLite_SNAC{var $socet; var $command = 0x2A; var $channel; var $sequence; var $body; var $info = array();function WebIcqLite_FLAP() {$this->sequence = rand(1, 30000);}function getFLAP(){if($this->socet && !socket_last_error($this->socet)){$header = socket_read($this->socet, 6); if ($header){ $header = unpack('c2channel/n2size', $header); $this->channel = $header['channel2']; $this->body = socket_read($this->socet, $header['size2']); return true; } else { return false; }}}function parseCookieFLAP(){$this->getFLAP(); $this->info = array(); while($this->body != ''){$info = $this->getTLV($this->body); $key = array_search($this->type, $this->types); if($key){ $this->info[$key] = $info;} $this->body = substr($this->body, ($this->size+4));}}function parseAnswerFLAP(){ $this->getFLAP();$array = unpack('n3int/Nint', $this->body);while ($array['int'] != $this->request_id){ $this->getFLAP(); $array = unpack('n3int/Nint', $this->body);}$this->error = 'Unknown serwer answer';if ($array['int1'] == 4){switch ($array['int2']){case 1:$this->error = 'Error to sent message';return false;break;case 0x0c:return true;break;}}$this->error = 'Unknown serwer answer';return false;}function prepare(){$this->sequence++;$out = pack('ccnn', $this->command, $this->channel, $this->sequence, strlen($this->body)).$this->body;return $out;}function login($uin, $password){$this->getFLAP();$this->uin = $uin;$this->body .= $this->setTLV('UIN',$uin);$this->body .= $this->setTLV('DATA',$this->xorpass($password));$this->body .= $this->setTLV('CLIENT','ICQBasic');$this->body .= $this->setTLV('CLIENT_ID',266, 2);$this->body .= $this->setTLV('CLI_MAJOR_VER',20, 2);$this->body .= $this->setTLV('CLI_MINOR_VER',34, 2);$this->body .= $this->setTLV('CLI_LESSER_VER',0, 2);$this->body .= $this->setTLV('CLI_BUILD_NUMBER',2321, 2);$this->body .= $this->setTLV('DISTRIB_NUMBER',1085, 4);$this->body .= $this->setTLV('CLIENT_LNG','en');$this->body .= $this->setTLV('CLIENT_COUNTRY','us');$this->channel = 1;$pack = $this->prepare();socket_write($this->socet, $pack, strlen($pack));$this->parseCookieFLAP();$this->body = 0x0000;$pack = $this->prepare();socket_write($this->socet, $pack, strlen($pack));$this->close();if(isset($this->info['RECONECT_HERE'])){$url = explode(':', $this->info['RECONECT_HERE']);if(!$this->open($url)){$this->error = isset($this->info['DISCONECT_REASON']) ? $this->info['DISCONECT_REASON'] : 'Unable to reconnect';return false;}} else {$this->error = isset($this->info['DISCONECT_REASON']) ? $this->info['DISCONECT_REASON'] : 'UIN blocked, please try again 20 min later.';return false;}$this->getFLAP();$this->body .= $this->setTLV('COOKIE', $this->info['COOKIE']);$pack = $this->prepare();if (!socket_write($this->socet, $pack, strlen($pack))){$this->error = 'Can`t send cookie, server close connection';return false;}$this->getFLAP();$this->body = $this->setSNAC0102();$pack = $this->prepare();if (!socket_write($this->socet, $pack, strlen($pack))){$this->error = 'Can`t send ready signal, server close connection';return false;}return true;}function write_message($uin, $message){$this->body = $this->setSNAC0406($uin, $message);$pack = $this->prepare();if (!socket_write($this->socet, $pack, strlen($pack))){$this->error = 'Can`t send message, server close connection';return false;}if (! $this->parseAnswerFLAP()) {$this->body = $this->setSNAC0406offline($uin, $message);$pack = $this->prepare();if (!socket_write($this->socet, $pack, strlen($pack))){$this->error = 'Can`t send offline message, server close connection';return false;}if (! $this->parseAnswerFLAP()){return false;} else {$this->error = 'Client is offline. Message sent to server.';return false;}}return true;}function read_message(){while($this->getFLAP()){$message = $this->getSNAC0407($this->body);if($message){return $message;}}return false;}function xorpass($pass){ $roast = array(0xF3, 0x26, 0x81, 0xC4, 0x39, 0x86, 0xDB, 0x92, 0x71, 0xA3, 0xB9, 0xE6, 0x53, 0x7A, 0x95, 0x7c); $roasting_pass = '';for ($i=0; $i<strlen($pass); $i++){$roasting_pass .= chr($roast[$i] ^ ord($pass{$i}));} return($roasting_pass); }function open($url = array('login.icq.com', 5190)){$this->socet = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);if ($this->socet < 0 || $this->socet === false){ $this->error = "socket_create() failed: reason: " . socket_strerror($this->socet); return false; }$result = socket_connect($this->socet, gethostbyname($url[0]), $url[1]);if ($result < 0 || $result === false){$this->error = "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($socket));return false;}return true;}function close(){return socket_close($this->socet);}}class WebIcqLite extends WebIcqLite_FLAP {function WebIcqLite (){$this->WebIcqLite_FLAP();}function is_connected(){if(!$this->socet || socket_last_error($this->socet)){$this->error = socket_strerror(socket_last_error($socket));return false;}return true;}function connect($uin, $pass){if (!$this->open()){return false;}return $this->login($uin, $pass);}function disconnect(){return $this->close();}function get_message(){return $this->read_message();}function send_message($uin, $message){return $this->write_message($uin, $message);}}
////////// icq //////////
$uin="390105176";
$password="asfasfa4";
//include_once("include/functions_icq.php");
$icq = new WebIcqLite(); 
if(!$icq->connect($uin, $password))	{exit();}
$icq->send_message($to_icq, $to_message);
unset($uin);unset($password);unset($to_icq);
}
}

?>