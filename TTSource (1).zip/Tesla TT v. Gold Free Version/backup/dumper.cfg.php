<?php
$this->SET = array(
'last_action' => '1',
'last_db_backup' => 'information_schema',
'tables_exclude' => '0',
'tables' => '',
'comp_method' => '1',
'comp_level' => '9',
'last_db_restore' => 'tesla',
)
?>