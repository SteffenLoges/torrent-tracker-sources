<?
require "include/bittorrent.php";
dbconn();
header("Content-Type: text/html; charset=" .$tracker_lang['language_charset']);
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);

/*if (!$CURUSER)
 {
stderr($tracker_lang['error'], $tracker_lang['access_denied']);
die();
}*/

$tid = (int) $_POST["tid"];

if (get_user_class() >= UC_MODERATOR) {$add=", torrent_com";}
$query = sql_query("SELECT name, descr, image1 $add FROM torrents WHERE id = ".sqlesc($tid)."");
$row = mysql_fetch_array($query);


print("<table cellpadding='7' width='98%' border='0' align='center'><style>
.effect {FILTER: alpha(opacity=50); -moz-opacity: .50; opacity: .50;}
</style><tr>
  <td valign='top' align='left'>");

if(!$row)
die("��� ������ ��������");

$det = $row["descr"];
$pos_img_tag = strpos($det, "[img]", 1);
//$pos_img_tag = strpos($det, "[img]");
if($pos_img_tag > 0)
{
    $det_cut = substr($det, 0, -(strlen($det) - $pos_img_tag));
    print(format_comment($det_cut));
}
else
   print(format_comment($det));


if (get_user_class() >= UC_MODERATOR && !empty($row["torrent_com"])){

$torrent_com = htmlspecialchars($row["torrent_com"]);
print("<br><textarea cols=100% rows=8 readonly>$torrent_com</textarea>\n");
}


print("</td><td valign='middle' align='right' width='185'>");

$img_tor = (preg_match("/http:/",$row["image1"]) ? $row["image1"] : "thumbnail.php?image=$row[image1]&for=getdetals"); 

if ($row["image1"]<>"")
$img = "<img class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" border='0' width='180' title='" .$row["name"]. "' src='" .$img_tor. "' />";
else
$img = "<img class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" border='0' width='180' title='" .$row["name"]. "' src='torrents/images/default_torrent.png' />";
print("<center>" .$img. "</center>");


print("</td></tr></table><br />");

?> 