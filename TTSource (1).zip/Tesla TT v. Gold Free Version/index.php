<?
///mysql_query("CREATE DATABASE `tesla` DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci;");
require "include/bittorrent.php";
gzip();
dbconn();



//echo" ".md5(md5("t3st"))." ";
/*

$fop = fopen ("t/questions.txt", "r+");
 $num=0;
while (!feof($fop))
{
$read = fgets($fop, 100000);
list($vopros,$otvet) = split('#',$read);
echo "$vopros : $otvet <br>";

$sq=sql_query("SELECT id FROM vquestions WHERE answer=".sqlesc($otvet)." limit 1") or sqlerr(__FILE__, __LINE__); 
$r_bot=mysql_fetch_array($sq);

if (empty($r_bot["id"])){
sql_query("INSERT INTO vquestions (question,answer) VALUES (" .  sqlesc($vopros) . ", " . sqlesc($otvet) . ")") or sqlerr(__FILE__, __LINE__); 
}

 $num++;
 echo " <br><b>$num</b>";
}

*/
/*	
$she_md51=$CURUSER["crc"];

$tesla_ip1 = md5(md5($she_md5)+133);


$she_md52=$CURUSER["ip"];
$tesla_ip2 = md5(md5($she_md52)+133);


        
echo "$she_md51 � $tesla_ip1 <br>$she_md52 � $tesla_ip2";
die;
*/


if ($CURUSER["id"]==2 && $_GET["id"]=="1"){
$sq=sql_query("SELECT id,filename FROM files") or sqlerr(__FILE__, __LINE__); 
while ($r_bot=mysql_fetch_array($sq)){
$id=$r_bot["id"];
$filename=utf8_to_win($r_bot["filename"]);

$filename=iconv("utf-8", "windows-1251", $r_bot["filename"]);
sql_query("UPDATE files SET filename=".sqlesc($filename)." WHERE id=".sqlesc($id)."") or sqlerr(__FILE__, __LINE__); 
}
}





//die;
if ($CURUSER && $_SERVER["REQUEST_METHOD"] == "POST"){
if ($_POST["gismeteo_id"]){
$gis_ident=(int)$_POST["gismeteo_id"];
$expires = 0x7fffffff;
setcookie("gismeteo", $gis_ident, $expires, "/");
$_COOKIE["gismeteo"]=$gis_ident;
//header("Refresh: 0; url=index.php");
//die("���������� ���������");
}

if ($_POST["gis_reset"]){
$_COOKIE["gismeteo"]="";
setcookie("gismeteo", "", 0x7fffffff, "/");
//header("Refresh: 0; url=index.php");
//die("���������� ���������");
}
}


stdhead($tracker_lang['homepage']);


parse_referer("delcache");

stdfoot();
?>