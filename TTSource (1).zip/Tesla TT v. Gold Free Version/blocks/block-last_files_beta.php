<?

if (!defined('BLOCK_FILE')) {
Header("Location: ../index.php");
exit;
}


$cacheStatFile = "cache/block-last_files_beta.txt"; 
$expire = 3*60; // 3 minutes 
if (file_exists($cacheStatFile) && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filemtime($cacheStatFile) > (time() - $expire)) { 
   $content.=file_get_contents($cacheStatFile); 
} else 
{



$limit = "12";

$blocktitle = "$limit ��������� ��������� (beta)";

$res = sql_query("SELECT torrents. * FROM torrents WHERE category <> 17 ORDER BY  id  DESC LIMIT 0 , $limit") or sqlerr(__FILE__, __LINE__);
$num = mysql_num_rows($res);
if ($num > 0) {
    $content .= "<table  align=\"center\" border=\"1\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"90%\" id=\"table\"> ";
    $nc=1;
    for ($i = 0; $i < $num; ++$i) {
    while ($row = mysql_fetch_assoc($res)) {
        if ($nc == 1) { $content .= "<tr>"; }
        $content .= "<td>";
if($row[image1]=="")
         $row[image1]="default_torrent.png";  
        
    $i++;  
$content .= "<div><div>
  ".($CURUSER ? "<a href=\"details.php?id=" . $row[id] ."\" >" : "")."


<img class=\"glossy\" src='thumbnail.php?image=$row[image1]&for=beta'\" border=\"0\"
 width=\"85\" height=\"85\"  border=\"0\" />
  ".($CURUSER ? "</a>" : "")."

</div></center></hr>";

$content .= "<div align=\"center\"><font color=\"red\">�������: ". $row['seeders'] ."��</font><br><font color=\"green\">������: ". $row['leechers'] ."� </div>";

//$content .= "<center><a href=details.php?id=$row[id]>  <font color=red><b>������: $row[times_completed]</b></font></a></center>";
       
$content .= "</td>";
        ++$nc;
        if ($nc == 7) { $nc=1; $content .= "</tr>"; }
    }
}
$content .= "</tr></table>";
}

else
	$content .= "<center>��� ������ �� ���� �������...</center>\n";




  $fp = fopen($cacheStatFile,"w");
   if($fp)
   { 
    fputs($fp, $content); 
    fclose($fp); 
   }
 }
if (get_user_class() >= UC_SYSOP)
{
$content.= ("<p align=right><font class=small>Time cache now ".date('H:i:s', filemtime($cacheStatFile)).". Next ".date((time() - $expire) -  filemtime($cacheStatFile))."</font></p>");
}
?> 