<?
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}

global $CURUSER;

$title_who = array();

$dt = sqlesc(time() - 180);
///[6] =>  0.000392   [SELECT DISTINCT s.uid, s.username, s.class, s.url FROM sessions AS s WHERE s.time > 1251798782 ORDER BY s.class DESC]
//sql_query("ALTER TABLE sessions ADD KEY sid_id (sid, uid);");


$result = sql_query("SELECT DISTINCT s.uid, s.username, s.class, s.url, f.blocks
FROM sessions AS s FORCE INDEX(sid_id) 
LEFT JOIN friends AS f ON f.friendid = s.uid 
WHERE f.friendid = s.uid  and f.userid='$CURUSER[id]' and friendid=s.uid and s.time > $dt and f.blocks='0' GROUP BY s.uid ORDER BY s.class  DESC") or sqlerr(__FILE__, __LINE__);
$total=0;

while ($row=mysql_fetch_assoc($result))
{
	
$uname=$row["username"];
$class=$row["class"];
$url=$row["url"];
$uid=$row["uid"];


   if (stristr($url,"receiver=".$CURUSER["id"])) {
   	$title_mes[$uname] = "<img border=\"0\" src=\"./pic/balloon--arrow.png\" title=\"��� ����� ���������\"/>";
    }


    if (!empty($uname)) {
    	if (stristr($url,'shoutbox.php')) {
   	$title_who[] = "<a href=\"userdetails.php?id=".$uid."\">".get_user_class_color($class, $uname,1)."$title_mes[$uname]";
    }
	else
	 	$title_who[] = "<a href=\"userdetails.php?id=".$uid."\">".get_user_class_color($class, $uname)."$title_mes[$uname]";
	}


      $total++;

}


if (count($title_who)) {

$content .= "<table border=\"0\" width=\"100%\"><tr valign=\"middle\"><td align=\"left\" class=\"embedded\">������ � ������ [$total]: <hr></td></tr><tr><td class=\"embedded\">".@implode(", ", $title_who)."";

} else {

$content .= "<table border=\"0\" width=\"100%\"><tr valign=\"middle\"><td align=\"center\" class=\"embedded\"><center>��� <b><a title=\"� ������ ������\" href=\"friends.php\">������</a></b> � ���� �� ��������� 3 ������.</center>\n";

}

$content.="</tr></table>\n"; 



$blocktitle = "���� ������";
?>