<?php

if (!defined('BLOCK_FILE')) {
header("Location: ../index.php");
exit;
}

$res = mysql_query("SELECT id, category, seeders, image1, leechers, name, times_completed from torrents WHERE added > DATE_SUB(NOW(),INTERVAL 6 DAY) ORDER BY times_completed DESC LIMIT 6") or sqlerr(__FILE__, __LINE__);


$num = mysql_num_rows($res);

if ($num > 0) {
//$content .= "<table border=1 cellspacing=0 cellpadding=5 width=100%><tr>";
$content .= "<table border=1 cellspacing=0 cellpadding=5 width=100%><tr><td class=block>";

//$content .= "<MARQUEE behavior= \"scroll\" align=\"left\" direction= \"up\" height=\"220\" scrollamount= \"2\" scrolldelay= \"55\" >";
$content .= "<MARQUEE behavior= \"scroll\" align=\"left\" direction= \"up\" height=\"220\" scrollamount= \"2\" scrolldelay= \"65\" onmouseover= \"this.stop()\" onmouseout='this.start()'>";

for ($i = 0; $i < $num; ++$i)
{
while ($row = mysql_fetch_assoc($res)) {
//$content .= "<center><a href=details.php?id=$row[id]><b>$row[name]</b></a></center>";
$content .= "<center><a href=details.php?id=$row[id]><img alt='$row[name]' border='0' width=\"100%\" height=\"100%\" src='torrents/images/$row[image1]'/></a><br> <align=center><font color=red><span title=\"�������\">" .number_format($row['seeders'])."</span><font color=green><span title=\"������\">"." ".number_format($row['leechers'])."<font color=blue><span title=\"����� ������� ���\">"." ".number_format($row['times_completed'])."</font></center>";
$content .= "<p>";
}
}
}
$content .= "</marquee></tr></td></table>";

?> 