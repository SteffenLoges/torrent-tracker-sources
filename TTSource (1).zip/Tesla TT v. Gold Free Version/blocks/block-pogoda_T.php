<?php

if (!defined('BLOCK_FILE')) {
header("Location: ../index.php");
exit;
}

$content=<<<BLOCKHTML
<p align="center">

<script>URL='http://img.gismeteo.ru/flash/120x60_2.swf?city=33829&cset=7';w='120';h='60';value='33829&cset=7';lang='ru'</script><script src='http://informer.gismeteo.ru/flash/fcode.js'></script>

</p>
BLOCKHTML;




?>