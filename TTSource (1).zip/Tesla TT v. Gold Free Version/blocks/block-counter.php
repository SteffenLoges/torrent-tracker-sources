<?php
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}
	$cacheStatFile = "cache/block-counter.txt"; 
$expire = 2*60; // 2 minutes 
if (file_exists($cacheStatFile) && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filemtime($cacheStatFile) > (time() - $expire)) { 
   $content.=file_get_contents($cacheStatFile); 
} else 
{ 


$dt24 = gmtime() - 86400;
$dt24 = sqlesc(get_date_time($dt24));

$dt7 = gmtime() - 604800;
$dt7 = sqlesc(get_date_time($dt7));

$dt30 = gmtime() - 2678400;
$dt30 = sqlesc(get_date_time($dt30));


$dt356 = gmtime() - 31536000;
$dt356 = sqlesc(get_date_time($dt356));

$dtall = gmtime() - 315360000;
$dtall = sqlesc(get_date_time($dtall));

$result = mysql_query("SELECT SUM(last_access >= $dt24) AS totalol24,
SUM(last_access >= $dt7) AS totalol7,
SUM(last_access >= $dt30) AS totalol30,
SUM(last_access >= $dt356) AS totalol356,
SUM(last_access >= $dtall) AS totalolall 
 FROM users") or sqlerr(__FILE__, __LINE__);

while ($row = mysql_fetch_array ($result))
{
$totalonline24 = $row["totalol24"];
if (empty($totalonline24))
$totalonline24=0;
$totalonline7 = $row["totalol7"];
if(empty($totalonline7))
$totalonline7=0;
$totalonline30 = $row["totalol30"];
if(empty($totalonline30))
$totalonline30=0;
$totalonline356 = $row["totalol356"];
if (empty($totalonline356))
$totalonline356=0;
$totalonlineall = $row["totalolall"];
if (empty($totalonlineall))
$totalonlineall=0;
}



$content .= "<center>
<table border=\"0\" cellspacing=\"1\" cellpadding=\"5\" width=\"80%\">
<tr><td class=\"a\" align=\"left\">�� ����</td><td class=\"a\" align=\"right\">$totalonline24</td></tr>
<tr><td class=\"b\" align=\"left\">�� ������</td><td class=\"b\" align=\"right\">$totalonline7</td></tr>
<tr><td class=\"a\" align=\"left\">�� �����</td><td class=\"a\" align=\"right\">$totalonline30</td></tr>
<tr><td class=\"b\" align=\"left\">�� ���</td><td class=\"b\" align=\"right\">$totalonline356</td></tr>
<tr><td class=\"a\" align=\"left\">�� �� �����</td><td class=\"a\" align=\"right\">$totalonlineall</td></tr>
</table>
</center>";


$fp = fopen($cacheStatFile,"w");
   if($fp)
   { 
    fputs($fp, $content); 
    fclose($fp); 
   }
 }


if (get_user_class() >= UC_SYSOP)
{
$content.= ("<p align=right><font class=small>Time cache now ".date('H:i:s', filemtime($cacheStatFile)).". Next ".date((time() - $expire) -  filemtime($cacheStatFile))."</font></p>");
}
?>