<?
if (!defined('BLOCK_FILE')) {
header("Location: ../index.php");
exit;
}

global $tracker_lang;

$content = "<center><a class=\"menu\" href=\"http://www.utorrent.com/download.php\">uTorrent</center></a>"   
          ."<center><a class=\"menu\" href=\"http://www.bitcomet.com/doc/download.htm\">BitComet</center></a>";
?>