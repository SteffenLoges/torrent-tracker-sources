<?
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}


$content ="
<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444535933597700\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\"100%\" height=\"100%\">
       <param name=\"movie\" value=\"http://www.maksim777.idknet.com/hi.swf />
       <param name=\"quality\" value=\"high\">
       <embed src=\"http://www.maksim777.idknet.com/hi.swf? \" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\"width=\"100%\" height=\"100%\" ></embed></object>

";

?>