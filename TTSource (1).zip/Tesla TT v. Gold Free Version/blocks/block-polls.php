<?
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}
//$cacheStatFile = "cache/polls/block-polls-".$CURUSER[id].".txt"; 
global $CURUSER ,$tracker_lang, $ss_uri;


$blocktitle = $tracker_lang['poll'].(get_user_class() >= UC_MODERATOR ? "<font class=\"small\"> - [<a class=\"altlink_white\" href=\"makepoll.php?returnto=main\"><b>".$tracker_lang['create']."</b></a>]" : "");

if ($CURUSER)
{
?>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/poll.core.js"></script>
<link href="js/poll.core.css" type="text/css" rel="stylesheet" />
<script type="text/javascript">$(document).ready(function(){loadpoll();});</script>
<?
 $content.="
<table width=\"100%\" class=\"main\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"10\">
<tr>
<td class=\"text\" align=\"center\">
<div id=\"poll_container\">
<div id=\"loading_poll\" style=\"display:none\"></div>
<noscript>
<b>���������� �������� ����� ��������</b>
</noscript>
</div>
<br/>
</td>
</tr>
</table> ";
}
else
{
$content .= "<table class=\"main\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\"><tr><td class=\"text\">";
$content .= "<div align=\"center\"><h3>��� ����� ������ ���������</h3></div>\n";
$content .= "</td></tr></table>";
}

?>