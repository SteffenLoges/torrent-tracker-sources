<?
if (!defined('BLOCK_FILE')) {
header("Location: ../index.php");
exit;
}

/// �������� �� ����� �����������

$cacheStatFile = "cache/block-friends.txt";
$expire = 15*60; // 15 ������
if (file_exists($cacheStatFile) && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filemtime($cacheStatFile) > (time() - $expire)) {
   $content.=file_get_contents($cacheStatFile);
} else
{


$content.="<style>.effect {FILTER: alpha(opacity=50); -moz-opacity: .50; opacity: .50;}</style>
<center><table id=\"table10\" style=\"WIDTH: 130px\" cellSpacing=\"0\" cellPadding=\"0\" border=\"0\">
<tr>
<td class=\"tabletitle\" style=\"PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 1px; PADDING-TOP: 1px\">

<tr>
<td width=\"130\"><br>
<br>
<br>

<script>
nereidFadeObjects = new Object();
nereidFadeTimers = new Object();
function nereidFade(object, destOp, rate, delta){
if (!document.all)
return
if (object != '[object]'){ //do this so I can take a string too
setTimeout('nereidFade('+object+','+destOp+','+rate+','+delta+')',0);
return;
}
clearTimeout(nereidFadeTimers[object.sourceIndex]);
diff = destOp-object.filters.alpha.opacity;
direction = 1;
if (object.filters.alpha.opacity > destOp){
direction = -1;
}
delta=Math.min(direction*diff,delta);
object.filters.alpha.opacity+=direction*delta;
if (object.filters.alpha.opacity != destOp){
nereidFadeObjects[object.sourceIndex]=object;
nereidFadeTimers[object.sourceIndex]=setTimeout('nereidFade(nereidFadeObjects['+object.sourceIndex+'],'+destOp+','+rate+','+delta+')',rate);
}
} </script>

<CENTER><MARQUEE BEHAVIOR='SCROLL' ALIGN='CENTER' VALIGN='BOTTOM' DIRECTION='UP' SCROLLAMOUNT='1' SCROLLDELAY='1' ONMOUSEOVER='this.stop()' ONMOUSEOUT='this.start()'>
<div align='center'>
<table class='FormTABLE' cellpadding='4' cellspacing='0'>
";


$res = sql_query("SELECT * FROM friendsblock WHERE visible='yes' ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);
while ($arr = mysql_fetch_assoc($res))


//if(list($width, $height) = @getimagesize($arr["image"])) {

$content.="<tr><td height='5'><p align='center'><a href='$arr[url]' target='_blank'><img class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" src='$arr[image]' width='88' height='31' border='0' style='filter:alpha(opacity=30)' onMouseOver='nereidFade(this,100,10,30)' onMouseOut='nereidFade(this,30,10,5)' alt='$arr[descr]'></a>
</a>\n"; 

//}

$content.="</td></p></center></a></td></tr> </table></MARQUEE></p><p></p></td></p></center></a></td></tr></p><p></p></table>";


         $fp = fopen($cacheStatFile,"w");
   if($fp)
   { 
    fputs($fp, $content); 
    fclose($fp); 
   }
 }


if (get_user_class() >= UC_SYSOP)
{
$content.= ("<p align=right><font class=small>Time cache now ".date('H:i:s', filemtime($cacheStatFile)).". Next ".date((time() - $expire) -  filemtime($cacheStatFile))."</font></p>");
}
 
?> 