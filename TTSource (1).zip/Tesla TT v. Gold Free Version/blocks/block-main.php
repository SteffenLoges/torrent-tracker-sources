<?php 
// Made by MGrafik 
if (!defined('BLOCK_FILE')) { 
 Header("Location: ../index.php"); 
 exit; 
} 
global $CURUSER, $tracker_lang, $minvotes; 
$count = get_row_count("torrents","WHERE ontop='yes'"); 
$blocktitle = "���� ������".(get_user_class() >= UC_VIP ? "<font class=\"small\"> - [<a class=\"altlink\" href=\"upload.php\"><b>�����</b></a>]</font>" : ""); 
$content .= "<table cellspacing=\"0\" cellpadding=\"5\" width=\"100%\"><tr><td>"; 
if (!$count) { 
    $content .= "��� ������� �� �������..."; 
} else { 
  ///  include "include/codecs.php"; 
  $video_codec = array(
	1 => "H.263",
	2 => "H.264",
	3 => "VPx",
	4 => "DivX 3.x",
	5 => "DivX 4.x",
	6 => "DivX 5.x",
	7 => "DivX 6.x",
	8 => "XviD",
	9 => "MPEG 1",
	10 => "MPEG 2 SVCD",
	11 => "MPEG 2 DVD",
	12 => "ASF",
	13 => "WMV"

);

$audio_codec = array(
	1 => "MP3",
	2 => "MP3 Pro",
	3 => "AC3",
	4 => "AC3 2.0",
	5 => "AC3 5.1",
	6 => "WMA",
	7 => "AAC",
	8 => "OGG",
	9 => "MP2"
);

$audio_lang = array(
	1 => "�������",
	2 => "����������",
	3 => "����������",
	4 => "��������",
	5 => "��������",
	6 => "���������",
	7 => "��������"
);

$audio_trans = array(
	1 => "��� ��������",
	2 => "�������������",
	3 => "����������������",
	4 => "������������ ����������",
	5 => "����������� ����������",
	6 => "����������� ����������"
);

$release_quality = array(
	1 => "HD DVD",
	2 => "HDTV",
	3 => "HDTVRip",
	4 => "DVD-9",
	5 => "DVD-5",
	6 => "DVDRip",
	7 => "DVDScr",
	8 => "Scr",
	9 => "SatRip",
	10 => "TVRip",
	11 => "TC",
	12 => "Super-TS",
	13 => "TS",
	14 => "CAM"
);
   // $perpage = 5; 
    //list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] . "?" ); 
  //  $content .= $pagertop; 
    $content .= "</td></tr>"; 
    $sql = "SELECT torrents.name, torrents.image1 AS image1, torrents.descr, torrents.id, torrents.comments, torrents.leechers, torrents.seeders, torrents.free AS free, torrents.numratings, torrents.ratingsum, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, visible, category FROM torrents LEFT JOIN categories ON torrents.category = categories.id WHERE ontop='yes' ORDER BY added  DESC $limit";  
       $result = mysql_query($sql) or die('No torrents found');  
    while( $row = mysql_fetch_assoc($result) ) {  
    $catid = $row["category"]; 
       $sql1 = "SELECT categories.name, categories.image FROM categories WHERE categories.id = '$catid'";  
       $result1 = mysql_query($sql1) or die('No categories found'); 
       $row1 = mysql_fetch_assoc($result1); 

       $image1 = "" .$row["image1"]. "";  
    $content .= "<tr><td>"; 
       $content .= '<table class="main" border="1" cellpadding="5" cellspacing="0" width="100%"><tbody><tr>'; 
    $content .= '<td class="colhead"'; 
       $content .= ' colspan="2"'; 
       $content .= ' align="center">';  

       $content .= '<a href="details.php?id=' . $row['id'] . '&hit=1"><b>' . $row['name'] . ' </b>'; 
    if($row['free']=='yes') 
           $content .= ' <img src="./pic/freedownload.gif" border=0 title="������� �������" alt="������� �������">'; 
       $content .= '    </a></td>';  



       //$content .= '<td align=center class=rowhead width=45><center></center></td>';  
       //$content .= '<td class=rowhead><center></center></td>';  
       $content .= '</tr><tr valign="top"><td align="center" width="140">';  

       $content .= '<img src="torrents/images/' . $image1 . '" border="0" width="180"></td><td><div align="left"><a href="browse.php?cat=' . $row['category'] . '"><img tooltip="' . $row1['name'] . '" src="pic/cats/' . $row1['image'] . '" align="right" border="0"></a>';  
   
       // ��� ���� ��������� ���������� ��������  
      if (strlen($row['descr']) > 300) $row['descr'] = substr($row['descr'], 0, 300); 
    $content .= '' . format_comment($row['descr']) . '<a tooltip="' . $row['name'] . '" href="details.php?id=' . $row['id'] . '" alt="' . $row['name'] . '">...</a>';

       $content .= '</div><tr><td><center>'; 
//rating 

if (!isset($row["rating"])) { 
                        if ($minvotes > 1) { 
                                $content .= sprintf($tracker_lang['not_enough_votes'], $minvotes); 
                                if ($row["numratings"]) 
                                        $content .= sprintf($tracker_lang['only_votes'], $row["numratings"]); 
                                else 
                                        $content .= $tracker_lang['none_voted']; 
                                $content .= ")"; 
                        } 
                        else 
                                $content .= $tracker_lang['no_votes']; 
                } 
                else { 
                        $rpic = ratingpic($row["rating"]); 
                        if (!isset($rpic)) 
                                $content .= $tracker_lang['none_voted']; 
                        else 
                                $content .= $rpic; 
  
                } 
               // $s .= "\n"; 
               // $s .= "</td><td class=embedded>$spacer</td><td valign=\"top\" class=embedded>"; 

// 

    $content .= '</center></td><td><div align="right">�������: <font color="red">'. $row['seeders'] .'&nbsp;&nbsp;</font> ������: <font color="green">'. $row['leechers'] .'</font> &nbsp;&nbsp;������������: '. $row['comments'] .' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [<a tooltip="' . $row['name'] . '" href="details.php?id=' . $row['id'] . '" alt="' . $row['name'] . '"><b>���������</b></a>]</div></tr></td></tr></tbody>';  
       $content .=  '</tr></table>';  

    } 
    $content .= "<tr><td>"; 
    $content .= $pagerbottom; 
    $content .= "</td></tr>"; 
} 
$content .= "</table>"; 

// Made by MGrafik 
?> 