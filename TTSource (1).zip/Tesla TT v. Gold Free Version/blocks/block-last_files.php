<?
if (!defined('BLOCK_FILE')) {
Header("Location: ../index.php");
exit;
}


$cacheStatFile = "cache/block-last_files.txt"; 
$expire = 3*60; // 3 minutes 
if (file_exists($cacheStatFile) && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filemtime($cacheStatFile) > (time() - $expire)) { 
   $content.=file_get_contents($cacheStatFile); 
} else 
{


$blocktitle = "��������� �������";
/*
 0.001449 �� 
 0.000833 �
 */
$res = sql_query("SELECT t.times_completed,t.f_seeders,t.f_leechers,t.name,t.seeders,t.owner, t.webseed, t.leechers,t.image1,t.id,t.hits, t.views,t.moderatedby, t.moderated,users.username AS us,users.class AS cl,
 m.class AS classname, m.username AS classusername
FROM torrents AS t FORCE INDEX(category_visible)
LEFT JOIN users ON t.owner = users.id  
LEFT JOIN users AS m ON t.moderatedby = m.id 
WHERE t.banned = 'no' and t.moderated = 'yes' ORDER BY  t.added DESC LIMIT 0 , 8") or sqlerr(__FILE__, __LINE__);
$num = mysql_num_rows($res);
if ($num > 0) {
    $content .= "<table border=\"1\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"100%\" id=\"table\"> ";
    $nc=1;
    
 
    for ($i = 0; $i < $num; ++$i) {
    while ($row = mysql_fetch_assoc($res)) {

        if ($nc == 1) { $content .= "<tr>"; }

        $content .= "<td>";
        $ip = getip();
if ($_SERVER["SERVER_ADDR"] == $ip && !file_exists("torrents/images/".$row["image1"])){
if ($array) {$array.=",";}
$array.=$row["id"];
unset($row["image1"]);
}

if($row["image1"]=="")
         $row["image1"]="default_torrent.png";  
    $i++;  


    $content .= "<td align=\"center\" valign=\"top\" width=\"25%\">"; 
    $content .= "<a href=details.php?id=$row[id]><img class=\"glossy\"
 src='thumbnail.php?image=$row[image1]&for=block' \" height=\"140\" width=\"140\"  border=\"0\" /><br>".(format_comment($row[name]))."</a>"; 
 

if (!empty($row["webseed"])){
$row['seeders']=$row['seeders']+1;
}

$content .= '</center><b><div align="center"><font color=red>�������: '. ($row['seeders']+$row['f_seeders']) .'��</font> <font color=green>������: '. ($row['leechers']+$row['f_leechers']).'</b></div></font>';


/*
$content .= "<center>
<b>������: $row[times_completed]</b>";

  if ($row["free"]=="yes")
    {
$content .= ".<img style=\"border:none\" alt=\"������\" title=\"������\" src=\"pic/freedownload.gif\">.";
}
else $content .= ".:::.";

$content .= "<b>����: $row[hits]</b><br>
<font color=blue><b>����������: $row[views]</b></font>

</center>";*/
if ($row["owner"]==$row["moderatedby"]){

$content.= "<b>������ � ��������:<br> ".($row["us"] ? "<a href=userdetails.php?id=" . $row["owner"] . ">".get_user_class_color($row["cl"],$row["us"])."</a>":"��� ������")."</b>\n";
}
 else
{
$content .= "<b>�����: ".($row['us'] ?"<a href=userdetails.php?id=" . $row["owner"] . ">".get_user_class_color($row['cl'],$row['us'])."</a>":"��� ������")."

</b><br>";
 
if ($row["moderated"] == "yes"){
$content .= "<b>�������:</b> <b><a href=\"userdetails.php?id=$row[moderatedby]\">". get_user_class_color($row["classname"], htmlspecialchars_uni($row["classusername"])) . "	</a></b><br>\n";} else {
$content .= "<b>��������:</b> <b>���</b><br>\n";
}
}

     
       
$content .= "</td>";
        ++$nc;
        if ($nc == 5) { $nc=1; $content .= "</tr>"; }
      //  if ($nc == 9) { $nc=1; $content .= "</tr>"; }
    }
}
$content .= "</tr></table>";

if (isset($array)){
//	die($array);
$sql="UPDATE torrents SET image1='' WHERE id IN (" . implode(",", array($array)) . ")";
sql_query($sql) or sqlerr(__FILE__,__LINE__);
//$content .= "$array";
}
}

else
	$content .= "<center>��� ������ �� ���� �������...</center>\n";








          $fp = fopen($cacheStatFile,"w");
   if($fp)
   { 
    fputs($fp, $content); 
    fclose($fp); 
   }
 }
 
if (get_user_class() >= UC_SYSOP)
{
$content.= ("<p align=right><font class=small>Time cache now ".date('H:i:s', filemtime($cacheStatFile)).". Next ".date((time() - $expire) -  filemtime($cacheStatFile))."</font></p>");
}

?> 