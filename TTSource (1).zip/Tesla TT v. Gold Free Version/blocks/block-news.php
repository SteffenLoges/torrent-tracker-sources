<?
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}

global $CURUSER,$tracker_lang;

if ($CURUSER){
$archive="<font class=\"small\"> - [<a class=\"altlink_white\" href=\"newsarchive.php\"><b>����� ��������</b></a>]</font>";
}
$blocktitle = $tracker_lang['news'].(get_user_class() >= UC_ADMINISTRATOR ? "<font class=\"small\"> - [<a class=\"altlink_white\" href=\"news.php\"><b>".$tracker_lang['create']."</b></a>]</font>" : "")."
$archive"
;

if (!$CURUSER){
  $cacheStatFile = "cache/block-news_guest.txt"; 
     $expire = 60*60; // 60  minutes 
}
if ($CURUSER && (get_user_class() < UC_ADMINISTRATOR)){
  $cacheStatFile = "cache/block-news_users.txt"; 
   $expire =45*60; // 45 minutes 
}
if ($CURUSER && (get_user_class() >= UC_ADMINISTRATOR)){
 $cacheStatFile = "cache/block-news_admins.txt"; 
 $expire =60*60; // 60 minutes 
}

if (file_exists($cacheStatFile) && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filemtime($cacheStatFile) > (time() - $expire)) { 
   $content.=file_get_contents($cacheStatFile); 
} else 
{




$resource = sql_query("SELECT * FROM news ORDER BY added DESC LIMIT 2") or sqlerr(__FILE__, __LINE__);

//$content .= "<script language=\"javascript\" type=\"text/javascript\" src=\"js/show_hide.js\"></script>";
//<a href=\"javascript: show_hide('s1')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pics1\" title=\"��������\"></a>

/*
,
 (SELECT username FROM users WHERE id=news.editby) AS user,
 (SELECT username FROM users WHERE id=news.userid) AS addeduser

*/

if (mysql_num_rows($resource)) {
    $content .= "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\">";
    while($array = mysql_fetch_array($resource)) {
    	
    	$comments = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM comments WHERE  torrent=0 and poll=0 and offer=0 and news = ".$array['id']));
    	
		if ($news_flag == 0) {
			
 	
					if (get_user_class() >= UC_ADMINISTRATOR) {
	            $as.= " <b>[</b><a href=\"news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . htmlentities($_SERVER['PHP_SELF']) . "\">�������������</a><b>]</b> - ";
	            $as .= "<b>[</b><a href=\"news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . htmlentities($_SERVER['PHP_SELF']) . "\">�������</a><b>]</b> - ";
	    	}
	    	
	    	

if ($array['user']){  $b="<b>[</b>".$array['user']." - ".$array['edittime']."<b>]</b>"; }
else
$b="";

  //$body1 = "". format_comment($array['body']) . "";
  //$array['body']=strlen($array['body'])>90?(substr($array['body'],0,90)."..."):$body1;
	    	

 //   $content .= "<br/><hr />"; 
//	$comments_color = "<b><font color=\"".get_comm_color($comments[0])."\">$comments[0]</font></b>";
	$comments_color = $comments[0];

if ($CURUSER){
	
      $fe .= "<div align=\"center\"><b>������������</b>: $comments_color</div>";
    $fe .= "<div align=\"right\">$as <b>[</b><a href=\"newsoverview.php?id=".$array['id']."\">��������������</a><b>]</b></div>";
      }
      
      $dt_date = get_date_time(gmtime() - 86400*2);
      if ($array['added']>$dt_date){
      $blosk="block";
      }
      else
      $blosk="none";
      
      	$content .="<span style=\"cursor: pointer;\" onclick=\"javascript: show_hide('s".$array["id"]."')\"><img border=\"0\" src=\"pic/minus.gif\" id=\"pics".$array["id"]."\" title=\"������\"></span>&nbsp;"."<span style=\"cursor: pointer;\" onclick=\"javascript: show_hide('s".$array["id"]."')\"><b>����</b>: ".$array['subject']." - <b>���������</b>: ".normaltime($array['added'],true)."\n"."</span>\n"."<span id=\"ss".$array["id"]."\" style=\"display: $blosk;\">".format_comment($array['body'])."</span></span>$fe<br>";
	
		
		
			//	$content .="<div title=\"������ ����� ���������� ���������� �������\" class=\"dhtmlgoodies_question\"><b>����</b>: ".$array['subject']." - <b>���������</b>: ".normaltime($array['added'],true)."</div><div class=\"dhtmlgoodies_answer\"> <div>".format_comment($array['body'])."</div></div>$fe";
			
	$news_flag = 1;

    	} else {
    		
    		
    		
	/*	$content .=
			"<span style=\"cursor: pointer;\" onclick=\"javascript: show_hide('s".$array["id"]."')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pics".$array["id"]."\" title=\"��������\"></span>&nbsp;"
			."<span style=\"cursor: pointer;\" onclick=\"javascript: show_hide('s".$array["id"]."')\">".date("d.m.Y",strtotime($array['added']))." - \n"
			."<b>".$array['subject']."</b></span>\n"
			."<span id=\"ss".$array["id"]."\" style=\"display: none;\">".format_comment($array['body'])."</span>";

			$content .= "<br /><hr />";
			
			*/
			
			
					if (get_user_class() >= UC_ADMINISTRATOR) {
	            $as2= " <b>[</b><a href=\"news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . htmlentities($_SERVER['PHP_SELF']) . "\">�������������</a><b>]</b> - ";
	            $as21 = "<b>[</b><a href=\"news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . htmlentities($_SERVER['PHP_SELF']) . "\">�������</a><b>]</b> - ";
	    	}
			
			
			
			
				$comments_color2 = $comments[0];

if ($CURUSER){
      $fe2 = "<div align=\"center\"><b>������������</b>: $comments_color2</div>";
    $fe2 .= "<div align=\"right\"> $as2 $as21 <b>[</b><a href=\"newsoverview.php?id=".$array['id']."\">��������������</a><b>]</b></div>";
      }
		
		
			$content .=
			"<span style=\"cursor: pointer;\" onclick=\"javascript: show_hide('s".$array["id"]."')\"><img border=\"0\" src=\"pic/plus.gif\" id=\"pics".$array["id"]."\" title=\"��������\"></span>&nbsp;"
			."<span style=\"cursor: pointer;\" onclick=\"javascript: show_hide('s".$array["id"]."')\"><b>����</b>: ".$array['subject']." - <b>���������</b>: ".normaltime($array['added'],true)."</span>\n"
			."<span id=\"ss".$array["id"]."\" style=\"display: none;\">".format_comment($array['body'])."</span>";

			$content .= "<br />";	
	//	$content .="<div title=\"������ ����� ���������� ���������� �������\" class=\"dhtmlgoodies_question\"> <b>����</b>: ".$array['subject']." - <b>���������</b>: ".normaltime($array['added'],true)."</div><div class=\"dhtmlgoodies_answer\"> <div>".format_comment($array['body'])."</div></div>$fe2";

    	}
	}
	$content .= "</table>$fe2\n";
} else {
	$content .= "<table class=\"main\" align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\"><tr><td >";
	$content .= "<div align=\"center\"><h3>".$tracker_lang['no_news']."</h3></div>\n";
	$content .= "</td></tr></table>";
}


$fp = fopen($cacheStatFile,"w");
   if($fp)
   { 
    fputs($fp, $content); 
    fclose($fp); 
   }
}

if (get_user_class() >= UC_ADMINISTRATOR){
$content.= ("<p align=right><font class=small>Time cache now ".date('H:i:s', filemtime($cacheStatFile)).". Next ".date((time() - $expire) -  filemtime($cacheStatFile))."</font></p>");
}
?>