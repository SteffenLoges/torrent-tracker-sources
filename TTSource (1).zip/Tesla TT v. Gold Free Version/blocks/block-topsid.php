<?php
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}

$cacheStatFile = "cache/block-topsid.txt";
$expire = 3*60; // 3 �����s
if (file_exists($cacheStatFile) && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filesize($cacheStatFile)<>0 && filemtime($cacheStatFile) > (time() - $expire)) {
   $content.=file_get_contents($cacheStatFile);
} else
{
	
$blocktitle = "������� ������";


$seeds_sql = sql_query("SELECT *, COUNT(*) AS tnum FROM peers FORCE INDEX(torrent_seeder) WHERE seeder = 'yes' GROUP BY userid ORDER BY `tnum` DESC LIMIT 0 , 10");

$content .= "<table width=\"100%\">
<td align=\"center\" class=\"b\" width=\"80%\">�����</td>
<td align=\"center\" class=\"b\" width=\"20%\">�������</td>\n";
$sf=0;
 while($seeds_array = mysql_fetch_array($seeds_sql)) {
  $sa = mysql_fetch_array(sql_query("SELECT username,class FROM users WHERE id = ".$seeds_array['userid']));
  $name = "<a href=\"userdetails.php?id=".$seeds_array['userid']."\">".get_user_class_color($sa["class"], $sa["username"])." ";
  $number = round($seeds_array['tnum']);
$content .= "<tr>
<td align=\"center\" width=\"70%\">$name</td>
<td align=\"center\" width=\"30%\">$number</td></tr>\n";
$sf++;
  }
  if ($sf==0)
{
$content .= "<tr>
<td align=\"center\" width=\"70%\">���</td>
<td align=\"center\" width=\"30%\">������</td></tr>\n";
}
$content .= "</table>\n";

}

         $fp = fopen($cacheStatFile,"w");
   if($fp)
   { 
    fputs($fp, $content); 
    fclose($fp); 
   }
 


if (get_user_class() >= UC_SYSOP)
{
$content.= ("<p align=right><font class=small>Time cache now ".date('H:i:s', filemtime($cacheStatFile)).". Next ".date((time() - $expire) -  filemtime($cacheStatFile))."</font></p>");
}
?> 