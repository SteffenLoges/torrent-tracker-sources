<?
if (!defined('BLOCK_FILE')) {
header("Location: ../index.php");
exit;
}

$blocktitle = "�������� ���";



$content=  "
<div align=\"center\">

<!-- begin of Top100 code -->
<script id=\"top100Counter\" type=\"text/javascript\" src=\"http://counter.rambler.ru/top100.jcn?1872998\"></script><noscript><img src=\"http://counter.rambler.ru/top100.cnt?1872998\" alt=\"\" width=\"1\" height=\"1\" border=\"0\"/></noscript>
<!-- end of Top100 code -->



<script type=\"text/javascript\">
var __rt= Math.round(Math.random() * 100000);
document.write('<scr'+'ipt language=\"javascript\" type=\"text/javascript\" src=\"http://id15350.luxup.ru/show/11411/?div=lx_11411&rt='+__rt+'&r='+escape(document.referrer)+'\"><'+'/scr'+'ipt>');
</script>

<div id=\"lx_11411\"></div>


</div>";

//$content .= "<center><img src=\"counter/counter.php\" width=88 height=31 border=0></center>";

 
?>