<? if (!defined('BLOCK_FILE')) {
header("Location: ../index.php");
exit;
}

$blocktitle = "�������� �������"; 

$add_sql_WHERE="WHERE image1 IS NOT NULL  ORDER BY added LIMIT 20";
///AND ontop='yes' 
$col=number_format(get_row_count("torrents", $add_sql_WHERE));
if ($col<=4){$col2=$col;}
else {$col2=4;}

if ($col>20)
$col=20;
$res = sql_query("SELECT id, image1, name FROM torrents $add_sql_WHERE") or sqlerr(__FILE__, __LINE__);
$num = mysql_num_rows($res);//rand()


?>

<script type="text/javascript" src="carousel/utilities.js"></script>
<style type="text/css">
.effect {FILTER: alpha(opacity=50); -moz-opacity: .50; opacity: .50;}

.carousel-component { 
	position:relative;
	overflow:hidden;   
	display:none;
	
}
				
.carousel-component ul.carousel-list { 
	width:10000000px;
	position:relative;
	z-index:1; 
}

.carousel-component .carousel-list li { 
	float:left;
	list-style:none;
	overflow:hidden;    
}

.carousel-component .carousel-vertical li { 
	margin-bottom:0px;
	float:left;
    clear:left;  
	overflow:hidden;
	display:block;
}

.carousel-component ul.carousel-vertical {
}

.carousel-component .carousel-clip-region { 
	overflow:hidden; /* Secret to the clipping */
	margin:0px auto;
	position:relative; 
}


.carousel-component { 
	background:#d3d3d3;
	padding:0px;
	-moz-border-radius:6px;
	color:#618cbe;
}
.carousel-component ul.carousel-list { 
	margin:0px;
	padding:0px;
	line-height:0px;
}
.carousel-component .carousel-list li { 
	text-align:center;
	margin:0px;
	padding:0px;
	font:10px verdana,arial,sans-serif;
	color:#666;
}
.carousel-component .carousel-vertical li { 
}
.carousel-component ul.carousel-vertical { 
}

.carousel-component {
    padding:8px 16px 4px 16px;
    margin:0px;
}

.carousel-component .carousel-list li {
    margin:4px;
    width:140px; /* img width is 75 px from flickr + a.border-left (1) + a.border-right(1) + 
                   img.border-left (1) + img.border-right (1)*/
    height:200px; /* image + row of text (87) + border-top (1) + border-bottom(1) + margin-bottom(4) */

}

.carousel-component .carousel-list li a { 
    display:block;
    border:1px solid #e2edfa;
    outline:none;
}

.carousel-component .carousel-list li a:hover { 
    border: 1px solid #aaaaaa; 
}

.carousel-component .carousel-list li img { 
    border:1px solid #999;
    display:block; 
}
                                
.carousel-component .carousel-prev { 
    position:absolute;
    top:40px;
    z-index:3;
    cursor:pointer; 
    left:5px; 
}

.carousel-component .carousel-next { 
    position:absolute;
    top:40px;
    z-index:3;
    cursor:pointer; 
    right:5px; 
}
</style>

<script type="text/javascript">

var handlePrevButtonState = function(type, args) {

    var enabling = args[0];
    var leftImage = args[1];
    if(enabling) {
        leftImage.src = "carousel/images/left-enabled.gif";    
    } else {
        leftImage.src = "carousel/images/left-disabled.gif";    
    }
    
};

var handleNextButtonState = function(type, args) {

    var enabling = args[0];
    var rightImage = args[1];
    
    if(enabling) {
        rightImage.src = "carousel/images/right-enabled.gif";
    } else {
        rightImage.src = "carousel/images/right-disabled.gif";
    }
    
};


var carousel; // for ease of debugging; globals generally not a good idea
var pageLoad = function() 
{
    carousel = new YAHOO.extension.Carousel("mycarousel", 
        {
            numVisible:        <?=$col2;?>,
            animationSpeed:    0.75,
            scrollInc:         3,
            navMargin:         20,
            prevElement:     "prev-arrow",
            nextElement:     "next-arrow",
            size:             <?=$col;?>,///20
            prevButtonStateHandler:   handlePrevButtonState,
            nextButtonStateHandler:   handleNextButtonState
        }
    );

};

YAHOO.util.Event.addListener(window, 'load', pageLoad);

</script>

<?
$content .= "<div id=\"doc\" class=\"yui-t7\" align=\"center\">
<div id=\"bd\">

<!-- Carousel Structure -->
<div id=\"mycarousel\" class=\"carousel-component\">
    <div class=\"carousel-prev\">

        <img id=\"prev-arrow\" class=\"left-button-image\" 
            src=\"carousel/images/left-enabled.gif\" alt=\"���������� ���������\"/>
    </div>
    <div class=\"carousel-next\">
        <img id=\"next-arrow\" class=\"right-button-image\" 
            src=\"carousel/images/right-enabled.gif\" alt=\"��������� ���������\"/>
    </div>
    <div class=\"carousel-clip-region\">
        <ul class=\"carousel-list\">";

if ($num > 0)
{
for ($i = 0; $i < $num; ++$i)
    {
    while ($row = mysql_fetch_assoc($res)) 
        {

$content .= "<li id=\"mycarousel-item-1\"><a href=details.php?id=$row[id]><img title=\"$row[name]\" class=effect onmouseover=\"this.className='effect1'\" onmouseout=\"this.className='effect'\" width=\"100%\" height=\"100%\" src='thumbnail.php?image=$row[image1]&for=getdetals' ></a></li>";
}
    }
    }
$content .= "</ul>

</div>
</div>
</div>
</div>";

?> 