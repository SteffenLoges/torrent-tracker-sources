<?php
if (!defined('BLOCK_FILE')) {
 Header("Location: ../index.php");
 exit;
}

global $tracker_lang;	

$content = "


<a class=\"menu\" href=\"index.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'index.php' ? "<b>".$tracker_lang['homepage']."</b>":"".$tracker_lang['homepage']."")."</a>"

."<a class=\"menu\" href=\"browse.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'browse.php' ? "<b>".$tracker_lang['browse']."</b>":"".$tracker_lang['browse']."")."</a>"
."<a class=\"menu\" href=\"detailsoff.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'detailsoff.php' ? "<b>������� | �������</b>":"�������")."</a>"
         //  ."<a class=\"menu\" href=\"viewoffers.php\">&nbsp;".$tracker_lang['offers']."</a>"
        //   ."<a class=\"menu\" href=\"forums.php\">&nbsp;".$tracker_lang['forum']."</a>"
           
           
           ."<a class=\"menu\" href=\"rules.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'rules.php' ? "<b>".$tracker_lang['rules']."</b>":"".$tracker_lang['rules']."")."</a>"
           
          // ."<a class=\"menu\" href=\"rules.php\">&nbsp;".$tracker_lang['rules']."</a>"
         
		 ."<a class=\"menu\" href=\"faq.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'faq.php' ? "<b>".$tracker_lang['faq']."</b>":"".$tracker_lang['faq']."")."</a>"
       //    ."<a class=\"menu\" href=\"faq.php\">&nbsp;".$tracker_lang['faq']."</a>"
       	 ."<a class=\"menu\" href=\"tags.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'tags.php' ? "<b>".$tracker_lang['tags']."</b>":"".$tracker_lang['tags']."")."</a>"
         //  ."<a class=\"menu\" href=\"tags.php\">&nbsp;".$tracker_lang['tags']."</a>"
         ."<a class=\"menu\" href=\"topten.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'topten.php' ? "<b>".$tracker_lang['topten']."</b>":"".$tracker_lang['topten']."")."</a>"
         
            ."<a class=\"menu\" href=\"newsarchive.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'newsarchive.php' ? "<b>����� ��������</b>":"����� ��������")."</a>"
            
            
            
		 //  ."<a class=\"menu\" href=\"topten.php\">&nbsp;".$tracker_lang['topten']."</a>"
          ."<a class=\"menu\" href=\"formats.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'formats.php' ? "<b>".$tracker_lang['formats']."</b>":"".$tracker_lang['formats']."")."</a>"
		  
		 ."<a class=\"menu\" href=\"groups.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'groups.php' ? "<b>������</b>":"������")."</a>" 
		     ."<a class=\"menu\" href=\"comments_last.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'comments_last.php' ? "<b>�����������</b>":"�����������")."</a>" 
		
		  ;
		 
		   //."<a class=\"menu\" href=\"formats.php\">&nbsp;".$tracker_lang['formats']."</a>";

if (get_user_class() >= UC_MODERATOR)
 $content.= "<a class=\"menu\" href=\"log.php\">&nbsp;".(basename($_SERVER['SCRIPT_FILENAME']) == 'log.php' ? "<b>".$tracker_lang['log']."</b>":"".$tracker_lang['log']."")."</a>";


$blocktitle = "<center>".$tracker_lang['main_menu']."</center>";
?>