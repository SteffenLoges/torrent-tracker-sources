<? 
require_once("include/bittorrent.php");
gzip();
dbconn(false);
setlocale(LC_ALL, 'ru_RU.CP1251');
///loggedinorreturn();
 
parse_referer("empty");

print"<style type=\"text/css\">
<!--
input.searchgif{
background:#FFFFFF url(pic/browse/search.gif) no-repeat scroll 0 50%;
color:#000000;
padding-left:18px;
}
-->
</style>";
//if (get_user_class() < UC_USER)
//	stderr($tracker_lang['error'], $tracker_lang['access_denied']);

parked();
$cats = genrelist();

$check = (int) $_GET["check"]; // ����� ���� 1 ��� 2
if ($check==2 && $CURUSER)
{
$searchstr = unesc($_GET["search_descr"]);
}
else
{
$searchstr = unesc($_GET["search"]);
}
$cleansearchstr = htmlspecialchars($searchstr);
if (empty($cleansearchstr))
unset($cleansearchstr);

$tagstr = unesc($_GET["tag"]);
$cleantagstr = htmlspecialchars($tagstr);



if (empty($cleantagstr))
unset($cleantagstr);


if ($_GET['sort'] && $_GET['type']) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
case '1': $column = "name"; break;
case '2': $column = "numfiles"; break;
case '3': $column = "comments"; break;
case '4': $column = "added"; break;
case '5': $column = "size"; break;
case '6': $column = "times_completed"; break;
case '7': $column = "seeders"; break;
case '8': $column = "leechers"; break;
case '9': $column = "owner"; break;
case '10': $column = "moderatedby"; break;
default: $column = "id"; break;
}

switch($_GET['type']) {
case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
}

$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";
} else {
$orderby = "ORDER BY torrents.sticky ASC, torrents.added DESC";
$pagerlink = "";
}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1){
        $addparam .= "incldead=1&amp;";
        if (!isset($CURUSER) || get_user_class() < UC_ADMINISTRATOR)
        $wherea[] = "banned <> 'yes'";
}
elseif ($_GET["incldead"] == 2){
        $addparam .= "incldead=2&amp;";
        $wherea[] = "visible = 'no'";
        $wherea[] = "banned = 'no'";
}
elseif ($_GET["incldead"] == 3){
        $addparam .= "incldead=3&amp;";
        $wherea[] = "free = 'yes'";
     // $wherea[] = "visible = 'yes'";
        $wherea[] = "banned = 'no'";
}
elseif ($_GET["incldead"] == 4){
        $addparam .= "incldead=4&amp;";
        $wherea[] = "seeders = 0";
        $wherea[] = "visible = 'yes'";
        $wherea[] = "banned = 'no'";
}

elseif ($_GET["incldead"] == 5){
        $addparam .= "incldead=5&amp;";
     // $wherea[] = "free = 'yes'";
        $wherea[] = "moderatedby = 'no'";
}

elseif ($_GET["incldead"] == 6){
        $addparam .= "incldead=6&amp;";
    //  $wherea[] = "free = 'yes'";
        $wherea[] = "banned = 'yes'";
}
elseif ($_GET["incldead"] == 7){
        $addparam .= "incldead=7&amp;";
    //  $wherea[] = "free = 'yes'";
        $wherea[] = "tags = ''";
}
elseif ($_GET["incldead"] == 8 && get_user_class() > UC_USER){
        $addparam .= "incldead=8&amp;";
        $wherea[] = "owner = '$CURUSER[id]'";
}
elseif ($_GET["incldead"] == 9){
        $addparam .= "incldead=9&amp;";
        $wherea[] = "image1 = ''";
}
elseif ($_GET["incldead"] == 10){
        $addparam .= "incldead=10&amp;";
        $wherea[] = "multitracker = 'yes'";
}
elseif ($_GET["incldead"] == 11){
        $addparam .= "incldead=11&amp;";
        $wherea[] = "picture1 <>''";
        $wherea[] = "picture4 <>''";
}
else 
$wherea[] = "visible = 'yes'";

$category = (int)$_GET["cat"];

if ($category && $CURUSER) {
$res9 = sql_query("SELECT username,id,catedit FROM users FORCE INDEX(user) WHERE class='".UC_MODERATOR."' and id<>'92' and enabled='yes'") or sqlerr(__FILE__,__LINE__);
	while ($arr = mysql_fetch_assoc($res9)) 
 {
 //	if ($category=="1")
 //	$category="01";
 	
    $cat="[cat$category]";
    $username = $arr['username'];
    $catedit = $arr['catedit'];
    $id = $arr['id'];

    if ($todayactive)
    $todayactive.=", ";

    $link="<a title=\"��������� ������� ��� ����������\">*</a>";

    if (stristr("$catedit", "$cat") && $catedit!=""){
    $todayactive.= "<b><a href=userdetails.php?id=$id >".get_user_class_color(UC_MODERATOR, $username) . "</a></b>$link";
    }

    if ($catedit==""){
   $todayactive.= "<b><a href=userdetails.php?id=$id >".get_user_class_color(UC_MODERATOR,$username) . "</a></b>";
    }

}

$todayactive = str_ireplace(", ,", ", ", $todayactive);
//$todayactive = str_ireplace(", , ", ", ", $todayactive);


$name_class="$todayactive";
}

if ($_GET["all"]<>1)
unset($_GET["all"]);
else {
$all = $_GET["all"];
}

if (!$all)
        if (!$_GET && $CURUSER["notifs"])
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $cat[id];
            if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }
        elseif ($category)
        {
          if (!is_valid_id($category))
            stderr($tracker_lang['error'], "Invalid category ID.");
          $wherecatina[] = $category;
          $addparam .= "cat=$category&amp;";
        }
        else
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $_GET["c$cat[id]"];
            if ($_GET["c$cat[id]"])
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }

if ($all)
{
  $wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
        $wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
        $wherea[] = "category = $wherecatina[0]";

$wherebase = $wherea;

if (isset($cleansearchstr))
{
	


if ($on_search_log==1) {
// �������� ����

$seconds = 60*60*168; // ������
$dt = get_date_time(gmtime() - $seconds);
$searchcloud = sqlesc($cleansearchstr); 

if ($check<>2 && $CURUSER["added"]<$dt && $CURUSER["uploaded"]<>0 && $CURUSER["downloaded"]<>0){
@unlink(ROOT_PATH."cache/block-clouds.txt"); // ��� ����������� ��������, ������� ��� ����� ���������� ���


	$time = sqlesc(get_date_time());
$r = mysql_fetch_array(sql_query("SELECT COUNT(*) FROM searchcloud WHERE searchedfor = $searchcloud"), MYSQL_NUM); 
$a = $r[0]; 
if ($a)
sql_query("UPDATE searchcloud SET howmuch = howmuch + 1 WHERE searchedfor = $searchcloud"); 
else 
sql_query("INSERT INTO searchcloud (searchedfor, howmuch, added) VALUES ($searchcloud, 1, $time)");  
// �������� ����
}}

   // 	$wherea[] = "torrents.descr LIKE '%" . sqlwildcardesc($searchss) . "%'";
        if ($check=="2" && $CURUSER){
        $wherea[] = "torrents.descr LIKE '%" . sqlwildcardesc($searchstr) . "%'";
        }
        else 
        {
        $wherea[] = "torrents.name LIKE '%" . sqlwildcardesc($searchstr) . "%'";
        }
        $addparam .= "search=" . urlencode($searchstr) . "&amp;";


if ($check<>2 && $CURUSER["added"]<$dt && $CURUSER["uploaded"]<>0 && $CURUSER["downloaded"]<>0){
	
if (!$CURUSER){
$user_data=getenv("REMOTE_ADDR"); 
}
if ($CURUSER){
$user = $CURUSER["username"];
$user_ip1=getenv("REMOTE_ADDR"); 
//$user_data="$user (".$user_ip1.")"; 
$user_data="$user"; 
}

$user_color = get_user_rgbcolor($CURUSER["class"], $CURUSER["username"]);
write_log("$user_data ����� $searchcloud\n", "$user_color","search");
}

}

if (isset($cleantagstr))
{
		$wherea[] = "torrents.tags LIKE '%" . sqlwildcardesc($tagstr) . "%'";
        $addparam .= "tag=" . urlencode($tagstr) . "&";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
        $where .= ($where ? " AND " : "") . "category IN (" . $wherecatin . ")";

if ($where<>"")
$where = "WHERE $where";

$res = sql_query("SELECT COUNT(*) FROM torrents FORCE INDEX(category_visible) $where") or sqlerr(__FILE__,__LINE__);
$row = mysql_fetch_array($res);
$count = $row[0];
$num_torrents = $count;

if (!$count && isset($cleansearchstr)) {
        $wherea = $wherebase;
        //$orderby = "ORDER BY id DESC";
        $searcha = explode(" ", $cleansearchstr);
        $sc = 0;
        foreach ($searcha as $searchss) {
                if (strlen($searchss) <= 1)
                        continue;
                $sc++;
                if ($sc > 5)
                        break;
                $ssa = array();
                

        if ($check=="2" && $CURUSER){
        $sesql="descr";
        }
        else
        $sesql="name";
        
		$ssa[] = "torrents.$sesql LIKE '%" . sqlwildcardesc($searchss) . "%'";
        }
        if ($sc) 
		{
         $where = implode(" AND ", $wherea);
          if (!empty($where))
         $where = "WHERE $where";
       //  $res = sql_query("SELECT COUNT(*) FROM torrents $where");
        // $row = mysql_fetch_array($res);
       //  $count = $row[0];
        }
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
        $torrentsperpage = 25;

if ($count)
{
    if ($addparam != "") {
 if ($pagerlink != "") {
  if ($addparam{strlen($addparam)-1} != ";") { // & = &amp;
    $addparam = $addparam . "&" . $pagerlink;
  } else {
    $addparam = $addparam . $pagerlink;
  }
 }
    } else {
 $addparam = $pagerlink;
    }
        list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);
        $query = "SELECT torrents.id, torrents.moderated, torrents.f_seeders,torrents.f_leechers,torrents.moderatedby, torrents.moderatordate, 
		b.class AS classname, b.username AS classusername,
		".($CURUSER["id"] ? " bs.id AS bookcomm, ch.checkid AS checkcomm,":"")."
       	 torrents.category, torrents.tags, torrents.leechers, torrents.seeders, torrents.free,torrents.banned, torrents.banned_reason, torrents.webseed, torrents.name, torrents.times_completed, torrents.size, torrents.added, torrents.comments, torrents.numfiles, torrents.filename, torrents.sticky, torrents.owner," .
        "IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, 
		users.username, users.class FROM torrents FORCE INDEX(category_visible)
		LEFT JOIN categories ON category = categories.id
		LEFT JOIN users ON torrents.owner = users.id
		LEFT JOIN users AS b ON torrents.moderatedby = b.id

		".($CURUSER["id"] ? "LEFT JOIN bookmarks AS bs ON bs.userid = $CURUSER[id] and bs.torrentid = torrents.id 
		LEFT JOIN checkcomm AS ch ON ch.userid = $CURUSER[id] AND ch.checkid = torrents.id AND ch.torrent = 1
		":"")."
		 $where $orderby $limit";
        $res = sql_query($query) or sqlerr(__FILE__,__LINE__);
		
		//die("��������������� �� �������� 500.<script>setTimeout('document.location.href=\"500.php\"', 10);</script>");;
}
/*
/// ����
9 (queries) - 91.22% (php) - 8.78% (0.0119 => sql) - 1606 �� (use memory) 
/// �����
9 (queries) - 93.14% (php) - 6.86% (0.0117 => sql) - 1606 �� (use memory)
*/
else
unset($res);

if ($check==2 && $CURUSER){
$vari="� ���������";
}
else
$vari="� ���������";

if (isset($cleansearchstr))    
stdheadchat("���������� ������ $vari �� "." \"$searchstr\"");

if (isset($cleantagstr)){
stdheadchat("���������� ������ �� ����: " . htmlspecialchars($tagstr));
}

else

stdheadchat($tracker_lang['browse']);

?>

<style type="text/css" media=screen>

  a.catlink:link, a.catlink:visited{
                text-decoration: none;
        }
  a.catlink:hover {
	border-top: dashed 1px #c3c5c6;
	padding: 0px;
        }
</style>

<script language="javascript" type="text/javascript" src="js/ajax.js"></script>
<div id="loading-layer" style="display:none;font-family: Verdana;font-size: 11px;width:200px;height:50px;background:#FFF;padding:10px;text-align:center;border:1px solid #000">
     <div style="font-weight:bold" id="loading-layer-text">��������. ����������, ���������...</div><br />
     <img src="pic/loading.gif" border="0" />
</div>



<table class="embedded" cellspacing="0" cellpadding="5" width="100%">
<tr><td class="colhead" align="center" colspan="12">������ ��������� � ���� � ���</td></tr>
<tr><td colspan="12">

<form method="get" action="browse.php">
<table class="embedded" align="center">
<tr>
<td class="bottom">
        <table class="bottom">
        <tr>

<?
$i = 0;
foreach ($cats as $cat)
{
        $catsperrow = 5;
        print(($i && $i % $catsperrow == 0) ? "</tr><tr>" : "");
        print("<td class=\"bottom\" style=\"padding-bottom: 2px;padding-left: 7px\"><input name=\"c$cat[id]\" type=\"checkbox\" " . (in_array($cat[id],$wherecatina) ? "checked " : "") . "value=\"1\">
        ".(in_array($cat[id],$wherecatina) ? "<a class=\"catlink\" title=\"" . htmlspecialchars($cat[name]) . " - $cat[num_torrent] ��������(��)\" href=\"browse.php?incldead=1&cat=$cat[id]\">" . htmlspecialchars($cat[name]) . "</a>" : "<b><a class=\"catlink\" title=\"" . htmlspecialchars($cat[name]) . " - $cat[num_torrent] ��������(��)\" href=\"browse.php?incldead=1&cat=$cat[id]\">" . htmlspecialchars($cat[name]) . "</a></b>")."
		
		<span style=\"cursor: pointer;\" onclick=\"javascript: show_tags(".$cat["id"].");\"><img border=\"0\" src=\"pic/tags.gif\" title=\"�������� ����\"></span></td></td>\n");
        $i++;
}

$alllink = "<div align=\"left\">(<a href=\"browse.php?all=1\"><b>".$tracker_lang['show_all']."</b></a>)</div>";

$ncats = count($cats);
$nrows = ceil($ncats/$catsperrow);
$lastrowcols = $ncats % $catsperrow;

if ($lastrowcols != 0)
{
        if ($catsperrow - $lastrowcols != 1)
                {
                        print("<td class=\"bottom\" rowspan=\"" . ($catsperrow  - $lastrowcols - 1) . "\">&nbsp;</td>");
                } /// ��������
}
?>
    </tr>
        </table>
        
  <div id="tags"></div>
  
</td>
</tr>
</form>
<tr><td class="a">
<form method="get" action="browse.php">
<center>

<?
if (!$check)
$checked="checked";
if ($check=="1")
$checked_1="checked";
if ($CURUSER) {
print"<label><input name=\"check\" $checked $checked_1 type=\"radio\" value=\"1\">&nbsp;
�� �������� ��������:</label>
<input type=\"text\" id=\"searchinput\" name=\"search\" size=\"40\" autocomplete=\"off\" class=\"searchgif\" ondblclick=\"suggest(event.keyCode,this.value);\" onkeyup=\"suggest(event.keyCode,this.value);\" onkeypress=\"return noenter(event.keyCode);\" value=\"".($check==2 ? "":htmlspecialchars($searchstr))."\" />
";
}
else
print"
�� �������� ��������:
<input type=\"text\" id=\"searchinput\" name=\"search\" size=\"40\" autocomplete=\"off\" class=\"searchgif\" ondblclick=\"suggest(event.keyCode,this.value);\" onkeyup=\"suggest(event.keyCode,this.value);\" onkeypress=\"return noenter(event.keyCode);\" value=\"".($check==2 ? "":htmlspecialchars($searchstr))."\" />
";
?>


<?=$tracker_lang['in'];?> 
<select name="incldead">
<option value="0"><?=$tracker_lang['active'];?></option>
<option value="1" <? print($_GET["incldead"] == 1 ? " selected" : ""); ?>><?=$tracker_lang['including_dead'];?></option>
<option value="2"<? print($_GET["incldead"] == 2 ? " selected" : ""); ?>><?=$tracker_lang['only_dead'];?></option>
<option value="3"<? print($_GET["incldead"] == 3 ? " selected" : ""); ?>><?=$tracker_lang['golden_torrents'];?></option>
<option value="4"<? print($_GET["incldead"] == 4 ? " selected" : ""); ?>><?=$tracker_lang['no_seeds'];?></option>
<option value="5"<? print($_GET["incldead"] == 5 ? " selected" : ""); ?>>�� �����������</option>
<option value="6"<? print($_GET["incldead"] == 6 ? " selected" : ""); ?>>����������</option>
<option value="7"<? print($_GET["incldead"] == 7 ? " selected" : ""); ?>>��� �����</option>

<? if (get_user_class() > UC_USER){ ?>
<option value="9"<? print($_GET["incldead"] == 9 ? " selected" : ""); ?>>��� �������</option>
<? } ?>

<? if (get_user_class() > UC_USER){ ?>
<option value="8"<? print($_GET["incldead"] == 8 ? " selected" : ""); ?>>���� ��������</option>
<? } ?>

<option value="10"<? print($_GET["incldead"] == 10 ? " selected" : ""); ?>>���������������</option>
<option value="11"<? print($_GET["incldead"] == 11 ? " selected" : ""); ?>>�� �����������</option>

</select>
<select name="cat">
<option value="0">�� ��������� ���</option>
<?


//$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
if ($cat["id"] == $_GET["cat"])
$catdropdown .= " selected=\"selected\"";
$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

?>
<?= $catdropdown ?>
</select>

<?
if ($check=="2") {
$checked_2="checked";
$viewcheck=htmlspecialchars($searchstr);
}
if ($CURUSER) {
print"</br>
<label><input name=\"check\" $checked_2 type=\"radio\" value=\"2\">&nbsp;
�� �������� ��������:</label>
<input type=\"text\" id=\"searchinput\" name=\"search_descr\" size=\"40\" value=\"$viewcheck\" class=\"searchgif\"/> 
";
}
?>

<input class="btn" type="submit" value="<?=$tracker_lang['search'];?>!" />
</br></br>

</center>
</form>
<script language="JavaScript" src="js/suggest.js" type="text/javascript"></script>
<div id="suggcontainer" style="text-align: left; width: 520px; display: none;">
<div id="suggestions" style="cursor: default; position: absolute; background-color: #FFFFFF; border: 1px solid #777777;"></div>
</div>
</td></tr></table>

<?

if (isset($cleantagstr)){
print("<tr><td class=\"rowhead\" colspan=\"12\">���������� ������ �� ����: \"" . htmlspecialchars($tagstr) . "\"</td></tr>\n");
}


if (isset($cleansearchstr))
print("<tr><td class=\"colhead\" colspan=\"12\">��������� ������ $vari ��� \"" . htmlspecialchars($searchstr) . "\"</td></tr>\n");

print("</td></tr>");


  if ($name_class) {
        print("<tr><td class=\"index\" colspan=\"12\">");
        print("<b>������ ��������� ��������� ����� ������������� ����������</b>: $name_class");
        print("</td></tr>");}

if ($num_torrents) {
	
	  
	
        print("<tr><td class=\"index\" colspan=\"12\">");
        print($pagertop);
        print("</td></tr>");

        torrenttable($res, "index");

        print("<tr><td class=\"index\" colspan=\"12\">");
        print($pagerbottom);
        print("</td></tr>");

}
else {
        if (isset($cleansearchstr)) {
                print("<tr><td align=\"center\" class=\"index\" colspan=\"12\">�� ������� �������� ������ �� ��������. <br><b>���������� �������� ��� ������, � �������� �� ������� ������� � �.�.</b></td></tr>\n");
                //print("<p>���������� �������� ������ ������.</p>\n");
        }
        else {
                print("<tr><td align=\"center\" class=\"index\" colspan=\"12\">".$tracker_lang['nothing_found']."</td></tr>\n");
                //print("<p>��������, ������ ��������� ������.</p>\n");
        }
}




print("</table></table>");

stdfootchat(); 

?>