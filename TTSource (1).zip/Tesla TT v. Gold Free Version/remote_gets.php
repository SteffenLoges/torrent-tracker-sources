<?

/**
 * @author 7Max7
 * @copyright 2009
 */


require_once('include/bittorrent.php'); 
dbconn(); 

if (get_user_class() < UC_MODERATOR){
stderr("��������", "������ ��� ����������"); 
die();
}

require_once('include/benc.php');

$dt_multi = sqlesc(get_date_time(gmtime() - 86400));

$sql = sql_query("SELECT id, info_hash FROM torrents WHERE multitracker = 'yes' AND multi_time<$dt_multi"); 
while($torrent = mysql_fetch_array($sql)) 
{
    $tracker_cache = array(); 
    $f_peers = 0; 
    $f_seeders = 0; 
    $announce_list = $announce_urls;
    
    foreach($announce_list as $announce) 
    {
        $response = get_remote_peers($announce, $torrent['info_hash'],true); 
        print_r($response); echo "<br>"; 
        if($response['state']=='ok') 
        {
            $tracker_cache[] = $response['tracker'].':'.($response['leechers'] ? $response['leechers'] : 0).':'.($response['seeders'] ? $response['seeders'] : 0); 
            $f_peers += $response['leechers']; 
            $f_seeders += $response['seeders']; 
        }
        else 
            $tracker_cache[] = $response['tracker'].':false'; 
    }
    $tracker_cache = implode("\n",$tracker_cache); 
       $now = get_date_time();
    sql_query("UPDATE LOW_PRIORITY torrents SET f_seeders = ".$f_peers.', f_leechers = '.$f_seeders.', f_trackers = '.sqlesc($tracker_cache).', multi_time='.sqlesc($now).' WHERE id = '.$torrent['id']) or sqlerr(__FILE__,__LINE__);
}

?>