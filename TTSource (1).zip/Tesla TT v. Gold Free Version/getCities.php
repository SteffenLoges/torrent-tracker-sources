<? require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
header('Content-Type: text/html; charset=windows-1251');

if(isset($_GET['countryCode'])) {
$codecity=(int) $_GET['countryCode'];

$nau=0;
$res = sql_query("SELECT name, id FROM cities WHERE country_id = ".sqlesc($codecity)."") or sqlerr(__FILE__, __LINE__);
while($row = mysql_fetch_array($res)){
echo "obj.options[obj.options.length] = new Option('".$row["name"]."','".((int)$row["id"])."');\n"; 
$nau++;
}

if (empty($row) && $nau==0){
echo "obj.options[obj.options.length] = new Option('��� ������� ��� ������','0');\n"; 
}

}
?>