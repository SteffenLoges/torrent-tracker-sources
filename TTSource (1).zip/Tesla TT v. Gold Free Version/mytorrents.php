<? require_once("include/bittorrent.php");
dbconn(false);
loggedinorreturn();
stdhead("��� ��������");

$where = "WHERE owner = " . $CURUSER["id"] . " AND banned <> 'yes'";
$res = sql_query("SELECT COUNT(*) FROM torrents $where") or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count) {
	stdmsg($tracker_lang['error'], "�� �� ��������� �������� �� ���� ������.");
	stdfoot();
	die();
}
else {
?>
<table class="embedded" cellspacing="0" cellpadding="3" width="100%">
<tr><td class="colhead" align="center" colspan="12">��� ������� ��������</td></tr>
<?

	list($pagertop, $pagerbottom, $limit) = pager(20, $count, "mytorrents.php?");

	$res = sql_query("SELECT torrents.type, 
	bs.id AS bookcomm, ch.checkid AS checkcomm,
	torrents.comments, torrents.leechers,torrents.tags, torrents.seeders, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, torrents.id, categories.name AS cat_name, categories.image AS cat_pic, torrents.name, filename, numfiles, added, size, views, visible, free, hits, times_completed, category FROM torrents LEFT JOIN bookmarks AS bs ON bs.userid = $CURUSER[id] and bs.torrentid = torrents.id LEFT JOIN checkcomm AS ch ON ch.userid = $CURUSER[id] AND ch.checkid = torrents.id AND ch.torrent = 1 LEFT JOIN categories ON torrents.category = categories.id $where ORDER BY id DESC $limit") or sqlerr(__FILE__, __LINE__);

	print("<tr><td class=\"index\" colspan=\"12\">");
	print($pagertop);
	print("</td></tr>");

	torrenttable($res, "mytorrents");

	print("<tr><td class=\"index\" colspan=\"12\">");
	print($pagerbottom);
	print("</td></tr>");

	print("</table>");

}

stdfoot();

?>