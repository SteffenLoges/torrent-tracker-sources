<?
require "include/bittorrent.php";
dbconn();

$passkey = @htmlentities($_GET["passkey"]);

if (strlen($passkey) <> 32 && !empty($passkey))
exit("�������� �������. ���������� ��������� ������");


if ($passkey) {
$user = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM users WHERE passkey = ".sqlesc($passkey)));
if ($user[0] <> 1)
exit();
}
else
loggedinorreturn();

$feed = $_GET["feed"];
if ($feed <> "dl")
unset($feed);

// name a category
$res = mysql_query("SELECT id, name FROM categories");
while($cat = mysql_fetch_assoc($res))
$category[$cat['id']] = $cat['name'];

// RSS Feed description
$DESCR = "RSS ��������";

// by category ?
$cat_get = (int) $_GET['cat'];
if ($cat_get)
$cats = explode(",", $cat_get);
if ($cats)
$where = "category IN (".implode(", ", array_map("sqlesc", $cats)).") AND";

// start the RSS feed output
header("Content-Type: application/xml");
print("<?xml version=\"1.0\" encoding=\"windows-1251\" ?>\n<rss version=\"0.91\">\n<channel>\n" .
"<title>" . $SITENAME . "</title>\n<link>" . $DEFAULTBASEURL . "</link>\n<description>" . $DESCR . "</description>\n" .
"<language>en-usde</language>\n<copyright>Copyright � 2006 " . $SITENAME . "</copyright>\n<webMaster>" . $SITEEMAIL . "</webMaster>\n" .
"<image><title><![CDATA[" . $SITENAME . "]]></title>\n<url>" . $DEFAULTBASEURL . "/pic/favicon.ico</url>\n<link>" . $DEFAULTBASEURL . "</link>\n" .
"<width>16</width>\n<height>16</height>\n<description><![CDATA[" . $DESCR . "]]></description>\n<generator><![CDATA[7Max7 for Tesla]]></generator>\n</image>\n");

// get all vars
$res = mysql_query("SELECT id,name,descr,filename,size,category,seeders,leechers,added,image1 FROM torrents WHERE $where visible='yes' ORDER BY added DESC LIMIT 15") or sqlerr(__FILE__, __LINE__);
while ($row = mysql_fetch_row($res)){
list($id,$name,$descr,$filename,$size,$cat,$seeders,$leechers,$added,$image1) = $row;

// seeders ?
if($seeders != 1){
$s = "��";
$aktivs="$seeders ���������($s)";
}
else
$aktivs="��� ���������";

// leechers ?
if ($leechers != 1){
$l = "��";
$aktivl="$leechers ��������($l)";
}
else
$aktivl="��� ��������";

// ddl or detail ?
if ($feed == "dl")
$link = "$DEFAULTBASEURL/download.php?id=$id";
else
$link = "$DEFAULTBASEURL/details.php?id=$id&amp;hit=1";

// measure the totalspeed
if ($seeders >= 1 && $leechers >= 1){
$spd = mysql_query("SELECT (t.size * t.times_completed + SUM(p.downloaded)) / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS totalspeed FROM torrents AS t LEFT JOIN peers AS p ON t.id = p.torrent WHERE p.seeder = 'no' AND p.torrent = '$id' GROUP BY t.id ORDER BY added ASC LIMIT 15") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_assoc($spd);
$totalspeed = mksize($a["totalspeed"]) . "/���";
}
else
$totalspeed = "��� ��������";

// output of all data
echo("<item><title><![CDATA[" . $name . "]]></title>\n<link>" . $link . "</link>\n<description><![CDATA[
".(empty($image1)? "":"<img border='0' src='thumbnail.php?image=$image1&for=details'/>")." <br> \n<b>���������</b>: " . $category[$cat] . "<br>  \n <b>������</b>: " . mksize($size) . "<br> \n <b>������</b>: " . $aktivs . " � " . $aktivl . "<br> \n <b>��������</b>: " . $totalspeed . "<br> \n <b>��������</b>: " . $added . "<br> \n <b>��������</b>:\n " . format_comment($descr) . "\n]]></description>\n</item>\n");
}

echo("</channel>\n</rss>\n");
?>