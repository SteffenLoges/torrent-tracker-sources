<?
require_once("include/bittorrent.php");
dbconn();
loggedinorreturn();
///info();

$torrentid = (int) $_POST["torrentid"];
$off_reqtid = ($_POST["off_req"]=="yes"? "yes":"no");
$rating = (float) $_POST["rating"];

if (!empty($torrentid) && $off_reqtid<>"yes") { /// ���� ������� ///

if ($_POST["ajax"] <> "yes") {
    stdmsg($tracker_lang["error"], "��� �� ��� ������ ??!");
	exit();
}

$chk = mysql_fetch_array(sql_query("SELECT torrent FROM ratings WHERE user=" . sqlesc($CURUSER["id"]) . " AND torrent=" . sqlesc($torrentid) . " LIMIT 1"));
if ($chk) {
    exit();
}

sql_query("INSERT INTO ratings (torrent, user, rating, added) VALUES (" . sqlesc($torrentid) . ", " . sqlesc($CURUSER["id"]) . ", " . sqlesc($rating) . ", NOW())")or sqlerr(__FILE__, __LINE__);
sql_query("UPDATE torrents SET numratings = numratings + 1, ratingsum = ratingsum + " . sqlesc($rating) . " WHERE id = " . sqlesc($torrentid) ."")or sqlerr(__FILE__, __LINE__);

}
elseif (!empty($torrentid) && $off_reqtid=="yes") { /// ���� ������ ///

if ($_POST["ajax"] <> "yes") {
    stdmsg($tracker_lang["error"], "��� �� ��� ������ ?!!");
	exit();
}

$chk = mysql_fetch_array(sql_query("SELECT off_req FROM ratings WHERE user=" .sqlesc($CURUSER["id"]) . " AND off_req=" . sqlesc($torrentid) . " LIMIT 1"));
if ($chk) {
    exit();
}

sql_query("INSERT INTO ratings (off_req, user, rating, added) VALUES (" . sqlesc($torrentid) . ", " . $CURUSER["id"] . ", " . sqlesc($rating) . ", NOW())")or sqlerr(__FILE__, __LINE__);
sql_query("UPDATE off_reqs SET numratings = numratings + 1, ratingsum = ratingsum + " . sqlesc($rating) . " WHERE id = " . sqlesc($torrentid) ."")or sqlerr(__FILE__, __LINE__);


}

if (empty($torrentid) || $_POST["ajax"] != "yes")
{
    stdmsg($tracker_lang["error"], "��� �� ��� ������ ?!!!!");
	exit();
}


?>