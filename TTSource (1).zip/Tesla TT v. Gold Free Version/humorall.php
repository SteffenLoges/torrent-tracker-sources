<? 

require "include/bittorrent.php"; 
gzip();
dbconn(false); 
loggedinorreturn(); 

/*
if (get_user_class() < UC_MODERATOR) 
{
attacks_log('humorall'); stderr($tracker_lang['error'], $tracker_lang['access_denied']);
die();
}
*/

if (get_user_class() > UC_MODERATOR && isset($_POST["delmp"])) {
$link="humorall.php?page=".(int) $_GET["page"];
//accessadministration();
sql_query("DELETE FROM humor WHERE id IN (" . implode(", ", array_map("sqlesc", $_POST["delmp"])) . ")
") or sqlerr(__FILE__, __LINE__); //(" . implode(", ", $_POST["delmp"]) . ")

sql_query("DELETE FROM karma WHERE type='humor' AND value IN (" . implode(", ", array_map("sqlesc", $_POST["delmp"])) . ")") or sqlerr(__FILE__, __LINE__); 

@header("Location: $DEFAULTBASEURL/$link") or die("��������������� �� ��� �� ��������.<script>setTimeout('document.location.href=\"$DEFAULTBASEURL/$link\"', 10);</script>");
}


$res2 = sql_query("SELECT COUNT(*) FROM humor $where")or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res2); 
$count = $row[0]; 
$perpage = 60;
list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" ); 

stdheadchat("������� ��������; ����� $perpage �� $count ����������"); 
echo $pagertop; 

$idu=$CURUSER["id"];
$res = sql_query("SELECT h.id,h.karma,h.uid,h.date,h.txt,u.class,u.username,
(SELECT COUNT(*) FROM karma WHERE type='humor' AND value = h.id AND user = $idu) AS canrate
FROM humor AS h
LEFT JOIN users AS u ON h.uid = u.id 
ORDER BY h.id DESC $limit") or sqlerr(__FILE__, __LINE__); 
//print($pagerbottom); 
//print("<h1>���� �������� ($perpage ��������� �� ��������)</h1>\n"); 
print("<table border=0 cellspacing=0 cellpadding=5>\n"); 
  
/*
r.last_access AS receiver_a, r.id AS receiver_id ,r.username AS receiver_u,r.class AS receiver_c

*/



if (get_user_class() > UC_MODERATOR) {
echo"<form method=\"post\" action=\"humorall.php?page=".(int)$_GET["page"]."\">";
}


  print("<tr>
  <td class=a align=center>�����</td>
   <td class=a align=center>�����</td>
  <td class=a align=center>�������</td>
  ".(get_user_class() > UC_MODERATOR ? "<td class=a>�������</td>":"<td class=a>ID</td>")."
  </tr>\n");
   while ($arr = mysql_fetch_assoc($res))
  {

////////////// ��� �������
    if (!$arr["username"]){
    $sender = "<center><font color=red>[<b>id ".$arr["uid"]."</b>]</font><br><b>������</b></center>";
    }
    else
    $sender = "<center><a href=userdetails.php?id=" . $arr["uid"] . "><b>".get_user_class_color($arr["class"], $arr["username"])."</b></a></center>";
    
  
    $txt = $arr["txt"];
    $txt = str_replace('script', '', $txt);
    $txt = str_replace('js', '', $txt);
    $txt = str_replace('src=', '', $txt); 

    $date = format_comment($arr["date"]); 
  
                ?>
                    <script language="JavaScript" type="text/javascript">
                    /*<![CDATA[*/
                        function karma(id, type, act) {
                        jQuery.post("karma.php",{"id":id,"act":act,"type":type},function (response) {
                            jQuery("#karma" + id).empty();
                            jQuery("#karma" + id).append(response);
                        });
                        }
                    /*]]>*/
                    </script>
                <?



        if ($arr["canrate"] > 0)// || || $arr["uid"] == $CURUSER["id"]
            $karma2="<span><img src=\"pic/minus-dis.png\" title=\"�� �� ������ ����������\" alt=\"\" /> " . karma($arr["karma"]) . " <img src=\"pic/plus-dis.png\" title=\"�� �� ������ ����������\" alt=\"\" /></span>\n";
        else
            $karma2="<span id=\"karma$arr[id]\"><img src=\"pic/minus.png\" style=\"cursor:pointer;\" title=\"��������� �����\" alt=\"\" onclick=\"javascript: karma('$arr[id]', 'humor', 'minus');\" /> " . karma($arr["karma"]) . " <img src=\"pic/plus.png\" style=\"cursor:pointer;\" onclick=\"javascript: karma('$arr[id]', 'humor', 'plus');\" title=\"��������� �����\" alt=\"\" /></span>\n";

    
  print("<tr>
  <td class=b>$txt</td>
  <td class=b align=center>$date</td>
  <td align=\"center\" id=\"karma\">$sender $karma2</td>"); 
  
if (get_user_class() > UC_MODERATOR) {
  if ($_GET["check"] == "yes") {
    echo("<TD class=a align=center><INPUT type=\"checkbox\" checked name=\"delmp[]\" value=\"" . $arr['id'] . "\"><br>".$arr["id"]."</TD>\n</TR>\n"); 
   }
   else { 
    echo("<TD class=a align=center><INPUT type=\"checkbox\" name=\"delmp[]\" value=\"" . $arr['id'] . "\"><br>".$arr["id"]."</TD>\n</TR>\n"); 
   }
}
else
  print("<td class=b align=center>".$arr['id']."</td>"); 

}
  print("</table>"); 


if (get_user_class() > UC_MODERATOR) {
?>
<a href="humorall.php?&page=<? echo $_GET["page"];?>action=<? echo htmlentities($_get["action"]); ?>&box=<? echo $_get["box"]; ?>&check=yes">�������� ��</a> | <a href="humorall.php?&page=<? echo $_GET["page"];?>action=<? echo htmlentities($_GET["action"]); ?>&box=<? echo $_GET["box"]; ?>&check=no">����� ���������</a><br>
<input type="submit" value="������� ���������� ���������" /> <br><br>
</form>
<br>

<?
}

print($pagerbottom); 
stdfootchat(); 
?>