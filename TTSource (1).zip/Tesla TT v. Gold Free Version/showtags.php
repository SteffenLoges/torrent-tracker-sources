<?
require_once("include/bittorrent.php");
dbconn();

//loggedinorreturn();
//parked();

header ("Content-Type: text/html; charset=" . $tracker_lang['language_charset']);

$category = (int) $_POST["cat"];

if (empty($category)) {
	stdmsg($tracker_lang["error"], "�� ������� ���� ��������!");
	die;
}

$res = sql_query("SELECT name FROM categories WHERE id=".sqlesc($category)) or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res);

//$cat_num = number_format(get_row_count("torrents", "WHERE category=".sqlesc($category)));

$r = "<br><span id=\"ss".$category."\" style=\"display: block;\"><fieldset id='tags' style='border: 2px solid gray;min-width:95%;display: block;'><legend> ���� ��� ��������� \"<b>".$row["name"]."</b>\" <a href=\"#\" style=\"font-weight:normal\" onClick=\"javascript:this.style.display='none';document.getElementById('ss".$category."').innerHTML='';\">[��������]</a></legend><table class=\"bottom\"><tr>";
        $tags = taggenrelist($category);
        if (!$tags)
        $r .= "<span style=\"font-size:12px\"> ��� ����� � ��������� ���������</span>";
        else {
        $j = 0;
        foreach ($tags as $row)
            {
            $tagsperrow = 7;
            $r .= ($j && $j % $tagsperrow == 0) ? "</tr><tr>" : "";
    	    $r .= "<td class=\"bottom\" style=\"padding-bottom: 2px;padding-left: 7px\"><b style='color: gray'>&#187 </b><a style=\"font-weight: normal;\" href=\"browse.php?tag=".$row["name"]."&incldead=1\">".htmlspecialchars($row["name"])."</a> </td>";
            $j++;
            }
        }
$r .= "</tr></table></fieldset></span><br>";
echo $r;

?>