<?
require_once("include/bittorrent.php");
dbconn();


	
		
mysql_query("TRUNCATE TABLE attachments");
mysql_query("TRUNCATE TABLE bonus");
mysql_query("TRUNCATE TABLE bans");

mysql_query("TRUNCATE TABLE bannedemails");
mysql_query("TRUNCATE TABLE bookmarks");
mysql_query("TRUNCATE TABLE captcha");
//mysql_query("TRUNCATE TABLE categories");
mysql_query("TRUNCATE TABLE checkcomm");
mysql_query("TRUNCATE TABLE cheaters");
mysql_query("TRUNCATE TABLE comments");
mysql_query("TRUNCATE TABLE files");
mysql_query("TRUNCATE TABLE friends");
mysql_query("TRUNCATE TABLE friendsblock");
//mysql_query("TRUNCATE TABLE groups");

mysql_query("TRUNCATE TABLE humor"); /// ������ �����
 
mysql_query("TRUNCATE TABLE invites");
mysql_query("TRUNCATE TABLE messages");
//mysql_query("TRUNCATE TABLE mybonus");
//mysql_query("TRUNCATE TABLE much_on");

//mysql_query("INSERT INTO `much_on` VALUES (1, '1987-03-10 12:12:12', 'yes')");

mysql_query("TRUNCATE TABLE news");
//mysql_query("TRUNCATE TABLE newscomments");
//mysql_query("TRUNCATE TABLE notconnectablepmlog");

mysql_query("TRUNCATE TABLE peers");
mysql_query("TRUNCATE TABLE pollanswers");

mysql_query("TRUNCATE TABLE polls");
mysql_query("TRUNCATE TABLE ratings");

mysql_query("TRUNCATE TABLE report");
mysql_query("TRUNCATE TABLE off_reqs");
mysql_query("TRUNCATE TABLE searchcloud");

sql_query("INSERT INTO searchcloud (howmuch, searchedfor) VALUES (".sqlesc(0).", ".sqlesc(Tesla).")"); 

mysql_query("TRUNCATE TABLE sessions");
mysql_query("TRUNCATE TABLE shoutbox");
mysql_query("TRUNCATE TABLE simpaty");
mysql_query("TRUNCATE TABLE sitelog");
mysql_query("TRUNCATE TABLE snatched");
mysql_query("TRUNCATE TABLE thanks");
mysql_query("TRUNCATE TABLE tags");

sql_query("INSERT INTO tags (category, name, howmuch) VALUES (".sqlesc(1).", ".sqlesc(Tesla).", 1)"); 

mysql_query("TRUNCATE TABLE referrers");

mysql_query("TRUNCATE TABLE torrents");
mysql_query("TRUNCATE TABLE uploadapp");
mysql_query("TRUNCATE TABLE users");

mysql_query("TRUNCATE TABLE useragent");
mysql_query("TRUNCATE TABLE readposts");


mysql_query("TRUNCATE TABLE karma");
mysql_query("TRUNCATE TABLE loginattempts");

mysql_query("TRUNCATE TABLE topics");		
mysql_query("TRUNCATE TABLE posts");		

$dh = opendir('cache/');
while ($file = readdir($dh)) :
if (preg_match('/^(.+)\.$/si', $file, $matches))
$file = $matches[1];
if ( stristr($file,'txt'))
{ unlink("cache/$file");}
endwhile;
closedir($dh);

$dh = opendir('torrents/');
while ($file = readdir($dh)) :
if (preg_match('/^(.+)\.$/si', $file, $matches))
$file = $matches[1];
if ( stristr($file,'torrent'))
{ unlink("torrents/$file");}
endwhile;
closedir($dh);




		
		die("������ ������ ���� �� ������� ��������! �������, ��� ����, �� �����!");
             

             
    
?>