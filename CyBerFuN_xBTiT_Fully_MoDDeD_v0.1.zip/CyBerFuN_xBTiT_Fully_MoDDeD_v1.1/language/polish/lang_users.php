<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Znajdź Usera";
$language["USER_LEVEL"]      = "Ranga";
$language["ALL"]             = "Wszyscy";
$language["SEARCH"]          = "Szukaj";
$language["USER_NAME"]       = "Nick";
$language["USER_LEVEL"]      = "Ranga";
$language["USER_JOINED"]     = "Dołączył/-a";
$language["USER_LASTACCESS"] = "Ostatnie logowanie";
$language["USER_COUNTRY"]    = "Kraj";
$language["RATIO"]           = "Ratio";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Edytyj";
$language["DELETE"]          = "Usuń";
$language["NO_USERS_FOUND"]  = "Nie znaleziono usera!";
$language["UNKNOWN"]         = "Nieznany";

?>