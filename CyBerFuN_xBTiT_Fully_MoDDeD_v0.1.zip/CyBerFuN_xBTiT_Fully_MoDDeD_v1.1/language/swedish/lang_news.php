<?php
$language['ERR_NO_TITLE'] = 'Du m�ste ange en nyhetsrubrik';
?>