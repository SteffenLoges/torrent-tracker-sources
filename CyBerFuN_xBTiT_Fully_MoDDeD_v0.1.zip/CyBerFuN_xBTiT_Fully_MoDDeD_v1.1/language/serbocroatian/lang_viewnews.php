<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Dodao";
$language["POSTED_DATE"] = "Dana";
$language["TITLE"]       = "Naziv";
$language["ADD"]         = "Dodaj";

?>