<?php
$language["FEATURED_TORRENT"] = "Featured Torrent";
$language["CURRENT_FEATURE"] = "Currently Featured";
$language["FRM_CONFIRM"] = "Submit";
$language["FRM_CANCEL"] = "Cancel";
$language["LST_TORRENTS"] = "Latest Uploads";
?>
