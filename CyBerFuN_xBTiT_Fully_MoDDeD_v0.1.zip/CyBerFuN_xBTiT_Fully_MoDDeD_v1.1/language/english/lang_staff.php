<?php

$language["STAFF_HEADER"]   =   "Before contacting any of our staff via PM please bear in mind we are very busy and recommend you to check <a href='index.php?page=forum'>the forum</a> first before asking questions. If you are rude to staff don't expect a reply.<br /><br /><b>If you don't get a reply chances are the answer to your question has been answered many times in <a href='index.php?page=forum'>the forum</a>.</b>";
$language["AVATAR"]         =   "Avatar";
$language["NICKNAME"]       =   "Nickname";
$language["ONLINE_STATUS"]  =   "Online status";

?>