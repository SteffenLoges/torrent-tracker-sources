<?php
$language['ERR_NO_TITLE'] = 'You must provide a Title for your news';
?>
