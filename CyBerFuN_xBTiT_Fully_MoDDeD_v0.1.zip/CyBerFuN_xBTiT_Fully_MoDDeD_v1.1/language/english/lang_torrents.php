<?php
$language['TORRENT_SEARCH'] = 'Search Torrents';
$language['TORRENT_STATUS'] = 'Status';
$language['CATEGORY_FULL'] = 'Category';
$language['ALL'] = 'All';
$language['ACTIVE_ONLY'] = 'Active only';
$language['DEAD_ONLY'] = 'Dead only';
$language['SEARCH'] = 'Search';
$language['CATEGORY'] = 'Cat.';
$language['FILE'] = 'Name';
$language['COMMENT'] = 'Com.';
$language['RATING'] = 'Rating';
$language['DOWN'] = 'Dl';
$language['ADDED'] = 'AddDate';
$language['SIZE'] = 'Size';
$language['UPLOADER'] = 'Uploader';
$language['SHORT_S'] = 'S';
$language['SHORT_L'] = 'L';
$language['SHORT_C'] = 'C';
$language['DOWNLOADED'] = 'Down';
$language['SPEED'] = 'Speed';
$language['AVERAGE'] = 'Av.';
$language['VOTE'] = 'Vote!';
$language['VOTES_RATING'] = 'votes (rating';
$language['FIVE_STAR'] = '5 stars';
$language['FOUR_STAR'] = '4 stars';
$language['ONE_STAR'] = '1 star';
$language['THREE_STAR'] = '3 stars';
$language['TWO_STAR'] = '2 stars';
$language['YOU_RATE'] = 'you rated this torrent as';
$language['ADD_RATING'] = 'add rating';
$language['RATING'] = 'Rating';
$language['ERR_NO_VOTE'] = 'You must choose a value to vote.';
$language['VOTES'] = 'Votes';
$language['SHOW_HIDE'] = 'Show/Hide Files';
// Torrent's Thanks (AJAX version)
$language["THANKS_BE_FIRST"] = "Nobody thanks for this torrent, be the first!";
$language["THANKS_USERS"] = "Who thanks";
$language["THANKS_YOU"] = "Say Thank You!";
// Torrent's Thanks (AJAX version)
?>
