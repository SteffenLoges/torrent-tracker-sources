<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = 'Find User';
$language['USER_LEVEL']      = 'User Level';
$language['ALL']             = 'All';
$language['SEARCH']          = 'Search';
$language['USER_NAME']       = 'Username';
$language['USER_LEVEL']      = 'Userlevel';
$language['USER_JOINED']     = 'Joined on';
$language['USER_LASTACCESS'] = 'Last access';
$language['USER_COUNTRY']    = 'Country';
$language['RATIO']           = 'Ratio';
$language['USERS_PM']        = 'PM';
$language['EDIT']            = 'Edit';
$language['DELETE']          = 'Delete';
$language['NO_USERS_FOUND']  = 'No users found!';
$language['UNKNOWN']         = 'Unknown';

?>