<?php
$language["ERR_NO_TITLE"]="Vous devez donner un titre � votre nouvelle";
?>