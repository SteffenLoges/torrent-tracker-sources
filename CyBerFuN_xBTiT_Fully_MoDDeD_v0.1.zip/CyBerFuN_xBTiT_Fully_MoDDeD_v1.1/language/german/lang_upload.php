<?php
$language["NOT_SHA"]="SHA1 Funktion nicht verf�gbar. Du brauchst PHP 4.3.0 oder h�her.";
$language["NOT_AUTHORIZED_UPLOAD"]="Du hast keine Berechtigung zum uploaden!";
$language["FILE_UPLOAD_ERROR_1"]="Kann die upgeloadete Datei nicht lesen";
$language["FILE_UPLOAD_ERROR_3"]="Datei ist leer";
$language["FACOLTATIVE"]="optional";
$language["FILE_UPLOAD_ERROR_2"]="Datei Upload Fehler";
$language["ERR_PARSER"]="Da scheint ein Fehler in Deinem Torrent zu sein. Der Parser akzeptiert ihn nicht.";
$language["WRITE_CATEGORY"]="Du musst die Torrent Kategorie ausw�hlen...";
$language["DOWNLOAD"]="Dowmload";
$language["MSG_UP_SUCCESS"]="Upload gelungen! Der Torrent wurde eingef�gt.";
$language["MSG_DOWNLOAD_PID"]="PID system active f�gt Deinem Torrent Deine PID hinzu";
$language["EMPTY_DESCRIPTION"]="Du musst eine Beschreibung einf�gen!";
$language["EMPTY_ANNOUNCE"]="Ank�ndigung ist leer";
$language["FILE_UPLOAD_ERROR_1"]="Kann die upgeloadete Datei nicht lesen";
$language["FILE_UPLOAD_ERROR_2"]="Fehler beim uploaden der Datei";
$language["FILE_UPLOAD_ERROR_3"]="Datei ist leer";
$language["NO_SHA_NO_UP"]="Upload einer Datei nicht verf�gbar - keine SHA1 Funktion.";
$language["NOT_SHA"]="SHA1 Funktion nicht verf�gbar. Du brauchst PHP 4.3.0 oder h�her.";
$language["ERR_PARSER"]="Da scheint ein Fehler in Deinem Torrent zu sein. Der Parser akzeptiert ihn nicht.";
$language["WRITE_CATEGORY"]="Du musst die Torrent Kategorie ausw�hlen...";
$language["ERR_HASH"]="Info hash MUSS genau 40 hex bytes betragen.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Externe Torrents sind nicht erlaubt";
$language["ERR_MOVING_TORR"]="Fehler beim verschieben des Torrents...";
$language["ERR_ALREADY_EXIST"]="Dieser Torrent ist in unser Datenbank bereits vorhanden.";
$language["MSG_DOWNLOAD_PID"]="PID system active f�gt Deinem Torrent Deine PID hinzu";
$language["MSG_UP_SUCCESS"]="Upload gelungen! Der Torrent wurde eingef�gt.";

?>