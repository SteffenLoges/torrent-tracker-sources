<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

//AJAX Poll System Hack Start - 5:03 PM 3/24/2007
$language["POLL_ID"]="ID";
$language["LATEST_POLL"]="th&#259;m d&#242; &#253; ki&#7871;n m&#7899;i nh&#7845;t";
$language["CAST_VOTE"]="&#253; ki&#7871;n c&#7911;a t&#244;i";
$language["FETCHING_RESULTS"]="k&#7871;t qu&#7843; c&#7911;a g&#243;p &#253; ki&#7871;n. xin ch&#7901;...";
$language["POLL_TITLE"]="t&#7921;a &#273;&#7873; th&#259;m d&#242; &#253; ki&#7871;n";
$language["POLL_TITLE_MISSING"]="thi&#7871;u t&#7921;a &#273;&#7873; th&#259;m d&#242; &#253; ki&#7871;n";
$language["POLLING_SYSTEM"]="h&#7879; th&#7889;ng b&#7887; phi&#7871;u AJAX";
$language["CURRENT_POLLS"]="nh&#7919;ng &#253; ki&#7871;n";
$language["POLL_STARTED"]="b&#7855;t &#273;&#7847;u v&#224;o";
$language["POLL_ENDED"]="ch&#7845;m d&#7913;t v&#224;o";
$language["POLL_LASTED"]="cu&#7889;i c&#249;ng";
$language["POLL_BY"]="b&#7855;t &#273;&#7847;u do";
$language["POLL_VOTES"]="nh&#7919;ng &#253; ki&#7871;n";
$language["POLL_STILL_ACTIVE"]="c&#242;n ho&#7841;t &#273;&#7897;ng";
$language["POLL_NEW"]="m&#7899;i";
$language["POLL_START_NEW"]="b&#7855;t &#273;&#7847;u th&#259;m d&#242; &#253; ki&#7871;n m&#7899;i";
$language["POLL_ACTIVE"]=" ho&#7841;t &#273;&#7897;ng ";
$language["POLL_ACTIVE_TRUE"]=" ho&#7841;t &#273;&#7897;ng ";
$language["POLL_ACTIVE_FALSE"]="b&#7845;t &#273;&#7897;ng";
$language["POLL_OPTION"]=" s&#7921; l&#7921;a ch&#7885;n ";
$language["POLL_OPTIONS"]=" nh&#7919;ng s&#7921; l&#7921;a ch&#7885;n ";
$language["POLL_MOVE"]="di chuy&#7875;n xu&#7889;ng d&#432;&#7899;i";
$language["POLL_NEW_OPTIONS"]=" nh&#7919;ng s&#7921; l&#7921;a ch&#7885;n ";
$language["POLL_SAVE"]="c&#7845;t gi&#7917; l&#7841;i";
$language["POLL_CANCEL"]="h&#7891;i b&#7887;";
$language["POLL_DELETE"]=" x&#243;a b&#7887; ";
$language["POLL_DEL_CONFIRM"]="Click OK x&#243;a b&#7887; ";
$language["POLL_VOTERS"]="nh&#7919;ng ng&#432;&#7901;i g&#243;p &#253; ki&#7871;n";
$language["POLL_IP_ADDRESS"]="&#273;&#7883;a ch&#7881; IP";
$language["POLL_DATE"]="ng&#224;y";
$language["POLL_USER"]="th&#224;nh vi&#234;n";
$language["POLL_ACCOUNT_DEL"]="<i>x&#243;a b&#7887; ch&#432;&#417;ng m&#7909;c</i>";
$language["POLL_BACK"]="tr&#7903; l&#7841;i";
$language["YEAR"]="n&#259;m";
$language["MONTH"]="th&#225;ng";
$language["WEEK"]="tu&#7847;n";
$language["DAY"]="ng&#224;y";
$language["HOUR"]="gi&#7901;";
$language["MINUTE"]="ph&#250;t";
$language["SECOND"]="gi&#226;y";
$language["YEARS"]="n&#259;m";
$language["MONTHS"]="nh&#7919;ng th&#225;ng";
$language["WEEKS"]="nh&#7919;ng tu&#7847;n";
$language["DAYS"]="nh&#7919;ng ng&#224;y";
$language["HOURS"]="nh&#7919;ng gi&#7901;";
$language["MINUTES"]="nh&#7919;ng ph&#250;t";
$language["SECONDS"]="nh&#7919;ng gi&#226;y";
//AJAX Poll System Hack Stop
?>  
