<?php
$language["NOT_SHA"]="SHA1 functie niet beschikbaar. U heeft nodig PHP 4.3.0 of beter.";
$language["NOT_AUTHORIZED_UPLOAD"]="U bent niet bevoegd om te uploaden!";
$language["FILE_UPLOAD_ERROR_1"]="Kan het geuploade bestand niet lezen";
$language["FILE_UPLOAD_ERROR_3"]="Bestand heeft geen grootte";
$language["FACOLTATIVE"]="optioneel";
$language["FILE_UPLOAD_ERROR_2"]="Fout tijdens uploaden";
$language["ERR_PARSER"]="Er schijnt een fout te zitten in uw torrentbestand. De decoder heeft dit niet geaccepteerd.";
$language["WRITE_CATEGORY"]="U moet een categorie selecteren...";
$language["DOWNLOAD"]="Downloaden";
$language["MSG_UP_SUCCESS"]="De upload is gelukt! De torrent is toegevoegd.";
$language["MSG_DOWNLOAD_PID"]="PID systeem is actief, download de torrent opnieuw met uw PID";
$language["EMPTY_DESCRIPTION"]="U moet een beschrijving opgeven!";
$language["EMPTY_ANNOUNCE"]="Herkenningslink is leeg";
$language["FILE_UPLOAD_ERROR_1"]="Kan geuploade bestand niet lezen";
$language["FILE_UPLOAD_ERROR_2"]="Fout tijdens uploaden";
$language["FILE_UPLOAD_ERROR_3"]="Bestand heeft geen grootte";
$language["NO_SHA_NO_UP"]="Uploaden van bestanden niet beschikbaar - geen SHA1 functie.";
$language["NOT_SHA"]="SHA1 functie niet beschikbaar. U heeft nodig PHP 4.3.0 of beter.";
$language["ERR_PARSER"]="Er schijnt een fout te zitten in uw torrentbestand. De decoder heeft dit niet geaccepteerd.";
$language["WRITE_CATEGORY"]="U moet een categorie selecteren...";
$language["ERR_HASH"]="Info hash MOET precies 40 hex bytes zijn.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Externe torrents zijn niet toegestaan";
$language["ERR_MOVING_TORR"]="Fout tijdens verplaatsen van torrent...";
$language["ERR_ALREADY_EXIST"]="Deze torrent bestaat al in onze database.";
$language["MSG_DOWNLOAD_PID"]="PID systeem is actief, download de torrent opnieuw met uw PID";
$language["MSG_UP_SUCCESS"]="De upload is gelukt! De torrent is toegevoegd.";

?>