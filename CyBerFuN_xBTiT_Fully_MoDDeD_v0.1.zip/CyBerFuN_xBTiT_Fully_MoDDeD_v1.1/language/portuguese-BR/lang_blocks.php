<?php
$language["BLOCK_USER"]="Info. Usuário";
$language["BLOCK_INFO"]="Info. Tracker";
$language["BLOCK_MENU"]="Menu Principal";
$language["BLOCK_CLOCK"]="Relógio";
$language["BLOCK_FORUM"]="Fórum";
$language["BLOCK_LASTMEMBER"]="Último Membro";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Online Hoje";
$language["BLOCK_SHOUTBOX"]="Caixa de Mensagem";
$language["BLOCK_TOPTORRENTS"]="Torrents mais populares";
$language["BLOCK_LASTTORRENTS"]="Últimos Torrents";
$language["BLOCK_NEWS"]="Últimas Notícias";
$language["BLOCK_SERVERLOAD"]="Server Load";
$language["BLOCK_POLL"]="Enquete";
$language["BLOCK_SEEDWANTED"]="Torrents Procurando Seed";
$language["BLOCK_PAYPAL"]="Doações";
$language["BLOCK_MAINTRACKERTOOLBAR"]="	Barra de ferramentas principal Tracker";
$language["BLOCK_MAINUSERTOOLBAR"]="	Barra de ferramentas principal usuário";
$language["WELCOME_LASTUSER"]=" Bem-vindo ao nosso Tracker ";
$language["BLOCK_MINCLASSVIEW"]="Rank mínimo que pode visualizar";
$language["BLOCK_MAXCLASSVIEW"]="Rank máximo que pode visualizar";
?>
