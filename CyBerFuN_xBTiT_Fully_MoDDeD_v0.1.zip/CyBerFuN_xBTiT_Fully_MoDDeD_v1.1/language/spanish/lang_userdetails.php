<?php

// USERDETAILS.PHP LANGUAGE FILE

$language['USERNAME']           = 'Usuario';
$language['EMAIL']              = 'Email';
$language['LAST_IP']            = '�ltima Ip';
$language['USER_LEVEL']         = 'Ranking';
$language['USER_JOINED']        = 'Registrado';
$language['USER_LASTACCESS']    = '�ltimo Acceso';
$language['PEER_COUNTRY']       = 'Pa�s';
$language['USER_LOCAL_TIME']    = 'Hora Local del Usuario';
$language['DOWNLOADED']         = 'Descargado';
$language['UPLOADED']           = 'Subido';
$language['RATIO']              = 'Ratio';
$language['FORUM']              = 'Foro';
$language['POSTS']              = 'Publicaciones';
$language['POSTS_PER_DAY']      = '%s publicaciones por d�a';
$language['TORRENTS']           = 'Torrents';
$language['FILE']               = 'Archivo';
$language['ADDED']              = 'A�adido';
$language['SIZE']               = 'Tama�o';
$language['SHORT_S']            = 'S';
$language['SHORT_L']            = 'L';
$language['SHORT_C']            = 'C';
$language['NO_TORR_UP_USER']    = '�El usuario no ha subido ning�n torrent todav�a!';
$language['ACTIVE_TORRENT']     = 'Torrents Activos';
$language['PEER_STATUS']        = 'Estado';
$language['NO_ACTIVE_TORR']     = 'No hay Torrents Activos';
$language['PEER_CLIENT']        = 'Cliente';
$language['EDIT']               = 'Editar';
$language['DELETE']             = 'Borrar';
$language['PM']                 = 'MP';
$language['BACK']               = 'Volver';
$language['NO_HISTORY']         = 'No hay historia para mostrar...';
?>