<?php
$language["ERR_NO_TITLE"]="Címet és a hírt is ki kell tölteni";
?>