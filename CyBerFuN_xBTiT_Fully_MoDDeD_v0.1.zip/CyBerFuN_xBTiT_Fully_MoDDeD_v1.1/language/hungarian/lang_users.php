<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Tag keresése";
$language["USER_LEVEL"]      = "Tag rangja";
$language["ALL"]             = "Mind";
$language["SEARCH"]          = "Keres";
$language["USER_NAME"]       = "Tag neve";
$language["USER_LEVEL"]      = "Tag rangja";
$language["USER_JOINED"]     = "Csatl. ideje";
$language["USER_LASTACCESS"] = "legutóbbi bejelentkezés";
$language["USER_COUNTRY"]    = "Ország";
$language["RATIO"]           = "Arány";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Szerkeszt";
$language["DELETE"]          = "Töröl";
$language["NO_USERS_FOUND"]  = "Nem találtam ilyen felhasználót!";
$language["UNKNOWN"]         = "Ismeretlen";

?>