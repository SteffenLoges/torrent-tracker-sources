<br>
<center><b>Popular Torrent Search Cloud</b></center>
<?php
require_once 'include/cloud.conf.php';
?>
<div class="tag_cloud">
<?php
print cloud();
?>
</div>
<br>