<?php

// CyBerFuN.ro & xList.ro

// xList .::. Paypal Block
// http://tracker.cyberfun.ro/
// http://www.cyberfun.ro/
// http://xlist.ro/
// Modified By CyBerNe7

block_begin("Donate");
?>
<table width="100%" align="center" border="0" cellspacing="1" cellpadding="4">
<tr>
  <td align="center" valign="top">
  <img src="images/makedonation.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" />
  </td>
</tr>
</table>
<?php
block_end();
?>