<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once "config.php";
connect ($dbhost, $dbuser, $dbpass, $database);

if (trim($_GET['term']) == '')
{
stheader('Search');
echo '<div class="location"><a href="/">Home</a> :: <a href="/search.php">Search</a></div>';
echo '<center>Fill out the search form</center>';
footer();
die;
}

// Search in cat
$cats = strip_tags($_GET['cat']);

if ($cats == '1' || $cats == '2' || $cats == '3' || $cats == '4' || $cats == '5' || $cats == '6' || $cats == '7')
{
$searchcat = " AND maincat = \"$cats\" ";
}

stheader('Search');
echo '<div class="location"><a href="/">Home</a> :: <a href="/search.php">Search</a></div>';
$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid WHERE torrents.torrentname LIKE '%".strip_tags(str_replace(' ','%',$_GET['term']))."%' $searchcat ORDER BY added DESC") or die (mysql_error());
$count = mysql_num_rows($result);

if ($count == 0)
{
echo '<h1>0 No torrents where found matching your query ('.htmlentities($_GET['term']).')</h1>';
footer();
die;
}

echo '<h1>'.$count.' results for '.htmlentities($_GET['term']).'</h1>';
echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><th>Category</th><th>Date</th><th>Filename</th><th>Size</th><th>Seeds</th><th>Peers</th></tr>';


while ($row = mysql_fetch_array($result))
{
extract($row);

echo '<tr>';
echo '<td><a href="/cat.php?id='.$maincat.'">'.$name.'</a></td>';
echo '<td>'.substr($added,-9).'</td>';
echo '<td><a href="/download.php?id='.$hash.'"><img src="/images/d.gif" alt="[d]" /></a> '.regicon($registration,$tracker).' '.desc($description).'<a href="/details.php?id='.$id.'">'.$torrentname.'</a></td>';
echo '<td align="right">'.torsize($size).'</td>';
echo '<td class="d">'.getpeer($seeds).'</td>';
echo '<td class="d">'.getpeer($peers).'</td>';
echo '</tr>';


}
echo '</table>';



footer();
?>