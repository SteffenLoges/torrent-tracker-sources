<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/

require_once 'config.php';
connect ($dbhost, $dbuser, $dbpass, $database);

$result = mysql_query("SELECT * FROM ban WHERE ip = '$REMOTE_ADDR'");
if (mysql_num_rows($result) == 1)
{
stheader('You have been banned from this section!');
echo '<h1>Banned!</h1>You have been banned from this section of the site for a very very very good reason, if you think a mistake has been made feel free to contact one of the admins';
footer();
die;
}

// trigger the upload part of this script
if (isset($_FILES['torrent']))
{



// ALL VARS (i THINK)
$upfile 		= $_FILES['torrent']['tmp_name'];
$torrent 		= torrent_info_file($upfile);
$tracker 		= strip_tags($torrent['announce']);
$tracker 		= strip_tags(str_replace('announce', 'scrape', $tracker));
$infohash 		= strip_tags($torrent['hash']);
$stats 			= torrent_scrape_url($tracker, $torrent['hash']);
$seeds 			= strip_tags($stats['seeds']);
$peers 			= strip_tags($stats['peers']);
$size 			= strip_tags($torrent['size']);
$torrentname 	= trim(strip_tags($_POST['filename']));
$subcat 		= strip_tags($_POST['type']);
$description	= strip_tags(trim($_POST['info']));
$registration 	= strip_tags($_POST['reg']);
$date 			= date('YmdHis');
$updated 		= date('YmdHis');
$maincat 		= mysql_query("SELECT catid FROM categories WHERE subid = '$subcat' LIMIT 1");
$maincat 		= mysql_fetch_row($maincat);
$maincat 		= $maincat[0];



if ($torrentname == '')
{
stheader($title);
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo "Fill out the entire form!!";
@unlink($filename);
footer(); 
die;
}




if ($registration == '')
{
stheader($title);
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo "Fill out the entire form!!";
@unlink($filename);
footer(); 
die;
}

if ($subcat == '')
{
stheader($title);
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo "Fill out the entire form!!";
@unlink($filename);
footer(); 
die;
}


// check tracker url (remove if you want udp:// torrents to be allowed)
if (!substr($tracker, 0, 7) =='http://')
{
stheader($title);
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo "This torrent does not have a valid tracker!!";
@unlink($filename);
footer(); 
die;
}

// check if torrent has tracker
if ($tracker == '')
{
stheader($title);
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo "This torrent does not have a valid tracker!";
@unlink($filename);
footer(); 
die;
}

// check if torrent excists in the database
$result= mysql_query ("SELECT * FROM torrents WHERE hash = '$infohash'");
if (mysql_num_rows($result) == 1)
{
stheader($title);
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo "This file already exists in our database...";
@unlink($filename);
footer(); 
die;
}

// Create flag for description
if (mb_strlen($description) == 0)
{
$desc_enum = 0;
}
else
{
$desc_enum = 1;
}

// no explenation needed here
move_uploaded_file($upfile , $btdir.'/'. $infohash .'.bogtor') or die("Error moving torrent...");


// Drop torrent stats into db
mysql_query("INSERT INTO torrents 
(torrentname,hash,maincat,subcat,tracker,size,seeds,peers,added,updated,registration,description) VALUES 
('$torrentname','$infohash','$maincat','$subcat','$tracker','$size','$seeds','$peers','$date','$updated','$registration','$desc_enum')") or die (mysql_error());



// Write description to a seperate table

mysql_query ("INSERT INTO description (id, descr) VALUES ('$desc_id','$description')") or die (mysql_error());


// Update stats
mysql_query("UPDATE categories SET torrents = torrents+1 WHERE subid = '$subcat'");
stheader('Upload done, thank you!');
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
echo 'success';
footer();




}
// If nothing has been uploaded
else
{

stheader('Upload a torrent');
echo '<div class="location"><a href="/">Home</a> :: <a href="/upload.php">Upload a torrent</a></div>';
?>



<form enctype="multipart/form-data" method="post" action="/upload.php">
<table width="100%" cellpadding="0" cellspacing="0" border="0">

<tr>
<td>Select a torrent file</td>
<td><input type="file" name="torrent" size="40"/></td>
</tr>

<tr>
<td>Select a category</td>
<td><select name="type">
<option value="">(Choose)</option>
<?
/* fetch the categories from sql */
$result = mysql_query("SELECT * FROM categories ORDER BY name, subname ASC") or sqlerr();    
while ($row = mysql_fetch_assoc($result))
{
echo "<option value=\"";
echo $row['subid'];
echo "\">";
echo htmlentities ($row['name']);
echo " &raquo; ";
echo htmlentities ($row['subname']);
echo "</option>";
} 
?>
</select>
</td>
</tr>

<tr>
<td>Choose a name</td>
<td><input type="text" name="filename" onkeyup="this.value = this.value.slice(0, 100)" size="40" /></td>
</tr>

<tr>
<td>Needs registration?</td>
<td> yes<input name="reg" type="radio" value="1" /> no <input name="reg" type="radio" value="0" /></td>
</tr>

<tr>
<td valign = "top"><strong>Description</strong> (optional)</td>  
<td><textarea name="info" rows="15" cols="60" onkeyup="this.value = this.value.slice(0, 2000)"></textarea></td>
</tr>

<tr>
<td></td>  
<td>
<input name="submit" type="submit" value="Upload Torrent" />
</td>
</tr>

</table>
</form>

  
<? 
footer();
}
?>

