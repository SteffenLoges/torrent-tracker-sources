<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/

$cat[] = 1;
$cat[] = 2;
$cat[] = 3;
$cat[] = 4;
$cat[] = 5;
$cat[] = 6;
$cat[] = 7;

require_once 'config.php';
connect ($dbhost, $dbuser, $dbpass, $database);
stheader ('Browse all categories');
echo '<div class="location"><a href="/">Home</a> :: <a href="/browse.php">Browse all categories</a></div>';
foreach ($cat as $val)
{
// the query to fetch the cat details
$result = mysql_query("SELECT * FROM categories WHERE catid='".$val."' ORDER BY subname ASC") or die (mysql_error());
$result_catname = mysql_query("SELECT DISTINCT (name) FROM categories WHERE catid='".$val."'") or die (mysql_error());

// the catname
$namerow =  mysql_fetch_row($result_catname); 

// print out everything else


echo '<br /><h1>'.$namerow[0].'</h1>';

echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><th>Category</th><th>Torrents</th></tr>';

while ($row = mysql_fetch_array($result))
{
extract($row);
echo '<tr>';
echo '<td width="15%">';
echo $torrents;
echo '</td>';
echo '</td>';
echo '<td><a href="/subcat.php?id='.$subid.'">'.$name.' :: ';
echo $subname;
echo '</a></td>';
echo '</td>';


echo '</tr>';
}
echo '</table>';
}
footer();
?>