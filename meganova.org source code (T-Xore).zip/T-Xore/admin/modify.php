<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);
$id = $_GET['id'];

$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid WHERE id = '$id'") or die (mysql_error());
if (mysql_num_rows($result) == 0)
{
adminheader('Modify');
echo 'Not found';
footer(); die;
}


while ($row = mysql_fetch_array($result))
{

adminheader('Modify');
extract($row);

function regset($registration)
{
if ($registration == 1)
{
return 'yes <input  name="reg" type="radio" value="1" checked="checked" /> no <input name="reg" type="radio" value="0" />';
}
else
{
return 'yes <input  name="reg" type="radio" value="1" /> no <input name="reg" type="radio" value="0" checked="checked" />';
}
}

function descset($description,$id)
{
if ($description == 1)
{
$desc_result = mysql_query("SELECT * FROM description WHERE id = '$id' LIMIT 1") or die (mysql_error());
while ($row = mysql_fetch_array($desc_result))
{
extract($row);
return strip_tags($descr);
}
}
}



echo '<h1>Modify '.htmlentities($torrentname).'</h1>';
echo '<form action="domod.php" method="post">';
echo '<table class="det" cellpadding="0" cellspacing="0" border="0"';
echo '<tr>';
echo '<td>';
echo 'Torrentname';
echo '</td>';
echo '<td>';
echo '<input type="text" name="torrentname" value="'.strip_tags($torrentname).'" size="50" />';
echo '</td>';
echo '</tr>';
echo '<tr>';
echo '<td>';
echo 'Hash';
echo '</td>';
echo '<td>';
echo '<input disabled type="text" name="hash" value="'.strip_tags($hash).'" size="50"  />';
echo '<input type="hidden" name="torid" value="'.$id.'" />';
echo '</td>';
echo '</tr>';
echo '<tr>';
echo '<td>';
echo 'Tracker';
echo '</td>';
echo '<td>';
echo htmlentities($tracker);
echo '</td>';
echo '</tr>';
echo '<tr>';
echo '<td>Tracker requires registration</td>';
echo '<td>'.regset($registration).'</td>';
echo '</tr>';
echo '<tr>';
echo '<td valign="top">Description</td>';
echo '<td><textarea name="description" cols="60" rows="15">'.descset($description,$id).'</textarea></td>';
echo '</tr>';
echo '<tr>';
echo '<td>Submit</td>';
echo '<td><input type="submit" name="submit" value="submit"></td>';
echo '</tr>';

echo '</table>';
echo '</form>';
}


?>

