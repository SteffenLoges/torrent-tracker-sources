<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/



// GLOBALS
@ini_set("max_execution_time", "3600");
@ini_set ( "memory_limit", "128M");
$y = 0;
// Connect to database
require_once '../config.php';
require_once 'secure.php';
require_once '../BDecode.php';
connect ($dbhost, $dbuser, $dbpass, $database);


// Lower the priority of this apache process
@exec('renice +20 '.getmypid());
ob_implicit_flush();
adminheader('Admin section : Update Torrent Stats');

// Fetch Trackers From sql
$result = mysql_query("SELECT DISTINCT tracker FROM torrents ORDER BY id DESC") or die(mysql_error());

echo '<h1>Updating all torrents in '.mysql_num_rows($result).' Trackers</h1><pre>';


while($row = mysql_fetch_assoc($result)) 
{
$tracker = $row['tracker'];
$tracker = trim(str_replace('/announce', '/scrape', $tracker));

echo "Fetching From :\t<span title=\"$tracker\">".substr($tracker,0,20)."</span>\t\t";
@ob_flush();


@$fp = file_get_contents($tracker);
if(!$fp) 
{
echo "\t Tracker is not responding<br />";
@ob_flush();
}
else
{
$stats = BDecode($fp);
$query  = "SELECT hash, seeds, peers ";
$query .= "FROM torrents ";
$query .= "WHERE tracker = '".$row['tracker']."'";
$res_tor = mysql_query($query) or die('Error in SQL query: '.mysql_error());

while($row_tor = mysql_fetch_assoc($res_tor)) 
{
$y++;
$binhash = addslashes(pack("H*", $row_tor['hash']));
$hash = $row_tor['hash'];
$_seeds = $stats['files'][$binhash]['complete'];
$_peers = $stats['files'][$binhash]['incomplete'];
$last_update = date("YmdHis");


@mysql_query("UPDATE torrents SET  seeds = '$_seeds', peers = '$_peers', updated= '$last_update' WHERE hash = '$hash' LIMIT 1") or die(mysql_error());
}
mysql_free_result($res_tor);
echo " :: ";
echo "	$y torrents have been updated<br />";

@ob_flush();
}
}
mysql_free_result($result);

echo "</pre><h3>$y torrents have been updated</h3>";

footer();





?>

