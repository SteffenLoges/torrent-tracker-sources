<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);


$torrentname 	= $_POST['torrentname'];
$id			 	= $_POST['torid'];
$registration 	= $_POST['reg'];
$description 	= trim($_POST['description']);

echo $typ;
if (mb_strlen(trim($description)) == 0)
{
$enum = 0;

}
else
{
$enum = 1;
}


$result = mysql_query("SELECT * FROM categories WHERE subid = '$typ' LIMIT 1");
while ($row = mysql_fetch_array($result))
{
extract($row);

}

mysql_query("UPDATE torrents SET torrentname='$torrentname',registration = '$registration', description = '$enum' WHERE id = '$id'") or die (mysql_error());




// Set or unset description
mysql_query("UPDATE description SET descr = '$description' WHERE id='$id'") or die (mysql_error());








adminheader('Modify');

echo '<h1>Details have been updated.</h1>';
echo '<a href="/admin/new.php">click here to go back</a>';

footer();


?>

