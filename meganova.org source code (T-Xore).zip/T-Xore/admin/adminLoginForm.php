<!-- doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN"-->
<html>
<head>
	<TITLE>Admin Center Login</TITLE>
	<meta name="robots" content="noindex,nofollow">
</head>
<body onload="window.document.adminLoginForm.formuser.focus()">
<!--START OF adminLoginForm.php -->
<blockquote>
	<p><br></p>
	<!--  -->
	<form method="post" name="adminLoginForm" action="adminLogin.php">
	<?php $loginAttempts = !isset($_POST['loginAttempts'])?1:$_POST['loginAttempts'] + 1;?>
		<input type="hidden" name="loginAttempts" value="<?php echo $loginAttempts;?>">
		<table border="0" cellpadding="5">
			<tr>
				<th colspan=2>Login to Admin Center</th>
			</tr>

			<tr>
				<td align="right">Admin User Name</td>
				<td>
					<input type="text" name="formuser" value="<?php echo $formuser;?>">
				</td>
			</tr>

			<tr>
				<td>Admin Password</td>
				<td>
					<input type="password" name="formpassword" value="<?php echo $formpassword;?>">
				</td>
			</tr>

			<tr>
				<td colspan=2>
					<input class="submit" type="submit" name="submit" value="Login to Admin Center">
				</td>
			</tr>
		</table>
	</form>
</blockquote>		
<!--END of adminLoginForm.php -->
</body>
</html>