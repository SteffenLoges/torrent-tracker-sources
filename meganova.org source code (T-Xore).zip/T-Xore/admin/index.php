<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);



adminheader('Controle center');
echo '<h1>Administration section</h1>';
echo '<ul>';
echo '<li><a href="/admin/uda.php">Update Torrents</a> - Updates all torrents</li>';
echo '<li><a href="/admin/new.php">Manage New</a> - Manage new torrents</li>';
echo '<li><a href="/admin/recount.php">Recount stats</a> - Recount all stats for the browse.php file</li>';
echo '</ul>';
footer();


?>
