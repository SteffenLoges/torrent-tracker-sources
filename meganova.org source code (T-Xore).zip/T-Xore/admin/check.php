<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);



adminheader('Version');
$file = file_get_contents('http://www.devnova.org/version.txt');
$vars = explode('|',$file);

if ($vars[0] == $version)
{
echo '<h1>You have the latest Version of T-Xore</h1>';
}
else
{
echo $vars[1];
}

footer();


?>
