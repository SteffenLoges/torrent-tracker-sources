<?php
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/

session_start();
if(   (!isset($_SESSION['adminUser'])) || (!isset($_SESSION['adminPassword'])) ) {
	include_once("adminLogin.php");
	exit;
}

if( ($_SESSION['adminUser'] != $admin_user) || ($_SESSION['adminPassword'] != $admin_pass) ) {

	include_once("adminLogin.php");
	exit;
}else{?>


<?php }?>