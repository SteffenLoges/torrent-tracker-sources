<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/

require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);
adminheader('Managelast 200 torrents');

$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid ORDER BY added DESC LIMIT 200") or die (mysql_error());
$count = mysql_num_rows($result);

if ($count == 0)
{
echo '<h1>No Torrents</h1>';
footer();
die;
}

echo '<h1>Showing Last '.$count.' Torrents</h1>';
echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><th>Category</th><th>Date</th><th>Filename</th><th>Size</th><th>Seeds</th><th>Peers</th><th>Delete</th><th>Modify</th><th>Ban</th></tr>';


while ($row = mysql_fetch_array($result))
{
extract($row);

echo '<tr>';
echo '<td><a href="/cat.php?id='.$maincat.'">'.$name.'</a></td>';
echo '<td>'.substr($added,-9).'</td>';
echo '<td><a href="/download.php?id='.$hash.'"><img src="/images/d.gif" alt="[d]" /></a> '.regicon($registration,$tracker).' '.desc($description).'<a href="/details.php?id='.$id.'">'.$torrentname.'</a></td>';
echo '<td align="right">'.torsize($size).'</td>';
echo '<td class="d">'.getpeer($seeds).'</td>';
echo '<td class="d">'.getpeer($peers).'</td>';
echo '<td class="d"><a href="/admin/delete.php?id='.$id.'">Delete</a></td>';
echo '<td class="d"><a href="/admin/modify.php?id='.$id.'">Modify</a></td>';
echo '<td class="d"><a href="/admin/ban.php?ip='.$ip.'">'.$ip.'</a></td>';
echo '</tr>';


}
echo '</table>';



footer();
?>