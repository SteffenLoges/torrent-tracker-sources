<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);


if ($_GET ['b'] == 1)
{
adminheader('Ban Complete');
$results = mysql_query("INSERT INTO  ban (ip , reason) VALUES ('".$_GET ['ip']."','".$_GET ['reason']."')")  or die (mysql_error());
echo "$ip has succesfully been banned";
footer();
}

else
{
adminheader('Ban');
?>
<h1>Ban users</h1><br />
<form action="" method="get">
<h5>ip</h5>
<input type="text" name="ip" value="<?= $_GET['ip']?>" size="50" />
<h5>reason</h5>
<input type="text" name="reason" value="" size="50" />
<input type="hidden" name="b" value="1" /><br />
<input name="Submit" type="submit" value="Submit" />
</form>
<br /><br />
<?
}

$result= mysql_query ("SELECT * FROM ban") or die (mysql_error);

echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0">';
echo '<tr>';
echo '<th>Banned Ip</th>';
echo '<th>Ban reason</th>';
echo '<th>Unban</th>';
echo '</tr>';


while($row= mysql_fetch_array ($result))
{
extract ($row);

echo '<tr>';
echo '<td>'.$ip.'</td>';
echo '<td>'.$reason.'</td>';
echo '<td>'.$ip.' - Do-it</td>';
echo '</tr>';

}
echo "</table>";  
  
footer();
?>
