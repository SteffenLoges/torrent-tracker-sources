<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/

@ini_set("max_execution_time", "3600");
@ini_set ( "memory_limit", "128M");


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);


$result = mysql_query("SELECT * FROM categories");
while ($row = mysql_fetch_array($result))
{
extract($row);
$count = mysql_num_rows(mysql_query("SELECT * FROM torrents WHERE subcat = '$subid'"));
mysql_query("UPDATE categories SET torrents='$count' WHERE subid='$subid'");
}





adminheader('Recount done');
echo '<h1>Re-counter torrent stats for each cat.</h1>';

footer();


?>