<?php
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once("../config.php");


$loginAttempts = !isset($_POST['loginAttempts'])?1:$_POST['loginAttempts'];
$formuser = !isset($_POST['formuser'])?NULL:$_POST['formuser'];
$formpassword = !isset($_POST['formpassword'])?NULL:$_POST['formpassword'];
if(($formuser != $admin_user ) || ($formpassword != $admin_pass )) {
	if ($loginAttempts == 0) { /* 3 strikes and they're out */
		$_POST['loginAttempts'] = 1;
		include("adminLoginForm.php");
		exit;
	}else{
		if ( $loginAttempts >= 3 ) {
			echo "<blink><p align='center' style=\"font-weight:bold;font-size:170px;color:red;font-family:sans-serif;\">Log In<br>Failed.</p></blink>";		
			exit;
		}else{
			include("adminLoginForm.php");
			exit;
		}
	}
}


if (($formuser == $admin_user ) && ($formpassword == $admin_pass )) {	// test for valid username and password
	session_start();
	$_SESSION['adminUser'] = $admin_user;
	$_SESSION['adminPassword'] = $admin_pass;
	$SID = session_id();
echo"<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=index.php\">";

}	
?>