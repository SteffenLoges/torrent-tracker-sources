<?php
require "../config.php";
?>