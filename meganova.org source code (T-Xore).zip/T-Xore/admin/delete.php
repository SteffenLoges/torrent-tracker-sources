<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once '../config.php';
require_once 'secure.php';
connect ($dbhost, $dbuser, $dbpass, $database);

$id = $_GET['id'];

$result = mysql_query("SELECT * FROM torrents WHERE id = '$id' LIMIT 1");
if (mysql_num_rows($result) == 0)
{
die ('Not found');
}


while ($row = mysql_fetch_array($result))
{
extract($row);
mysql_query("UPDATE categories SET torrents = 'torrents-1' WHERE subid = '$subcat' LIMIT 1") or die (mysql_error());
mysql_query("DELETE FROM comments WHERE id = '$id' LIMIT 1") or die (mysql_error());
mysql_query("DELETE FROM torrents WHERE id = '$id' LIMIT 1") or die (mysql_error());
@unlink('.'.$btdir.'/'.$hash.'.bogtor');
}
header("Location: new.php");

?>

