<?
require_once "config.php";
connect ($dbhost, $dbuser, $dbpass, $database);
stheader('About');
echo '<div class="location"><a href="/">Home</a> :: <a href="/about.php">About</a></div>';
echo '<h1>Put your content in here</h1>';
footer();
?>