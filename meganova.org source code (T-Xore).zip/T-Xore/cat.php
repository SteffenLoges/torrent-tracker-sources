<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once 'config.php';
connect ($dbhost, $dbuser, $dbpass, $database);

// the query to fetch the cat details
$result = mysql_query("SELECT * FROM categories WHERE catid='".strip_tags(trim($_GET['id']))."' ORDER BY subname ASC") or die (mysql_error());
$result_catname = mysql_query("SELECT DISTINCT (name) FROM categories WHERE catid='".strip_tags(trim($_GET['id']))."'") or die (mysql_error());

// die if dont exist
if (mysql_num_rows($result)== 0)
{
stheader('Category not found!');
echo '<center>No such category</center>';
footer();
die;
}

// the catname
$namerow =  mysql_fetch_row($result_catname); 

// print out everything else
stheader ('Category : '.$namerow[0]);
echo '<div class="location"><a href="/">Home</a> :: <a href="/cat.php?id='.strip_tags(trim($_GET['id'])).'">'.$namerow[0].'</a></div>';
echo '<h1>'.$namerow[0].'</h1>';

echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><th>Category</th><th>Torrents</th></tr>';

while ($row = mysql_fetch_array($result))
{
extract($row);
echo '<tr>';
echo '<td width="15%">';
echo $torrents;
echo '</td>';
echo '<td><a href="/subcat.php?id='.$subid.'">'.$name.' :: ';
echo $subname;
echo '</a></td>';
echo '</tr>';
}
echo '</table>';
footer();
?>