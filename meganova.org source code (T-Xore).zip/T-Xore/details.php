<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once "config.php";
connect ($dbhost, $dbuser, $dbpass, $database);


// Check if a comment was posted
if ($_POST['submitted'] == '')
{

// The details query
$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid WHERE torrents.id ='".strip_tags(trim($_GET['id']))."'") or die (mysql_error());
$count = mysql_num_rows($result);
if ($count == 0)
{
stheader('Torrent Not Found');
echo '<br /><h1>Torrent not found</h1>';
footer();
die;
}


// extract data from sql
while ($row = mysql_fetch_array($result))
{
extract($row);

stheader('Torrent Details for: '.htmlentities($torrentname));

?>
<script type="text/javascript">
function expandcontract(tbodyid,dis) {
  document.getElementById(tbodyid).style.display = dis;
}
</script>
<?
$tracker = parse_url($tracker);

// Display upload description
if ($description == 1)
{

$result_desc = mysql_query("SELECT descr FROM description where id = '".strip_tags(trim($_GET['id']))."' LIMIT 1");
while ($row = mysql_fetch_array($result_desc))
{
extract($row);
$description = '<tr><td colspan="2"><center><br /><h1>Description</h1><div id="desc">'.nl2br(str_replace('  ','&nbsp;&nbsp;',$descr)).'</div></center><br /></td></tr>';
}
}
else
{
$description = '';
}

echo '<div class="location"><a href="/">Home</a> :: <a href="/cat.php?id='.$maincat.'">'.$name.'</a> :: <a href="/subcat.php?id='.$subid.'">'.$subname.'</a> :: <a href="/details.php?id='.$id.'">'.htmlentities($torrentname).'</a></div>';
// Display torrent details
echo '<h1>'.htmlentities($torrentname).'</h1>';
echo '<table class="det" cellpadding="0" cellspacing="0" border="0">';
echo '<tr><td width="15%">Download</td><td>: <a href="/download.php?id='.htmlentities($hash).'">'.htmlentities($torrentname).'</a> &raquo; (<a href="magnet:?xt=urn:btih:'. strtoupper(base32_encode(pack("H*", $hash))).'">Magnet Link</a>)</td></tr>';
echo '<tr><td>Category</td><td>: <a href="/cat.php?id='.$maincat.'">'.$name.'</a> &raquo; <a href="/subcat.php?id='.$subid.'">'.$subname.'</a></td></tr>';
echo '<tr><td>Size</td><td>: '.torsize($size).'</td></tr>';
echo '<tr><td>Seeds</td><td>: '.getpeer($seeds).'</td></tr>';
echo '<tr><td>Peers</td><td>: '.getpeer($peers).'</td></tr>';
echo '<tr><td>Tracker</td><td>: http://'.htmlentities($tracker['host']).' ('.detreg($registration).')</td></tr>';
echo '<tr><td>Added</td><td>: '.$added.'</td></tr>';
echo '<tr><td>Updated</td><td>: '.$updated.'</td></tr>';
echo '<tr><td>Hash</td><td>: '.htmlentities($hash).'</td></tr>';
echo '<tr><td>Alternative</td><td>: The file <em>'.htmlentities($torrentname).'</em>  might also be available on UseNeXT <strong><a href="http://www.usenext.de/index.cfm?TD=377528">Click here to download the UseneXT client</strong></a></td></tr>'.$description;
echo '</table>';




// Display toggle files link
echo '<br /><a href="#det" onclick="expandcontract(\'files\',\'\')">View Included Files</a> :: <a href="#" onclick="expandcontract(\'files\',\'none\')">Hide Included Files</a><br /><br />';


// Display internal files
echo '<a name="det"></a>';
echo '<table class="det" cellpadding="0" cellspacing="0" border="0">';
echo '<tbody id="files" style="display:none">';
@showfiles($hash);
echo '</tbody></table>';

// Fetch comments from sql
$result = mysql_query("SELECT * FROM comments WHERE id ='".strip_tags(trim($_GET['id']))."'");
$comment_count = mysql_num_rows($result);

// div colors
$color1 = 'class="light"';
$color2 = 'class="dark"';
$row_count = 0; 

echo '<br /><h1>Comments ('.$comment_count.')</h1>';
if (!$comment_count == 0)
{
echo '<div class="commentwrapper">';
while ($row = mysql_fetch_array($result))

{
extract($row);
$row_color = ($row_count % 2) ? $color1 : $color2; 
echo '<div '.$row_color.'><strong>'.htmlentities($name).'</strong> On <strong>'.$date.'</strong><br /><br />'.nl2br(htmlentities($post)).'</div><br /><br />';
$row_count++;
}
}


$result = mysql_query("SELECT * FROM ban WHERE ip = '$REMOTE_ADDR'");
if (mysql_num_rows($result) == 1)
{
echo '<br /><h1>You cant add any comments!</h1>You cant add any comments because you where banned for some reason.';
footer();
die;
}
echo '<br /><form id="comment" action="/details.php?id='.strip_tags(trim($_GET['id'])).'" method="post">';
echo '<input name="user" value="name" onclick=\'value=""\' /><br /><br />';
echo '<textarea name="comment" cols="50" rows="7"></textarea><br />';
echo '<input type="submit" name="submitted" value="submit" /></form></div>';
}


footer();
}


// Handle posted comment
else
{
$result = mysql_query("SELECT * FROM ban WHERE ip = '$REMOTE_ADDR'");
if (mysql_num_rows($result) == 1)
{
stheader('You have been banned from this section!');
echo '<h1>Banned!</h1>You have been banned from this section of the site for a very very very good reason, if you think a mistake has been made feel free to contact one of the admins';
footer();
die;
}

stheader('Comment submitted');
$commentid = strip_tags(trim($_GET['id']));
$name = trim($_POST['user']);
$comment = trim($_POST['comment']);
$ip= $REMOTE_ADDR;
$date = date('YmdHis');
mysql_query("INSERT INTO comments (id,ip,date,name,post) VALUES ('$commentid','$ip','$date','$name','$comment')");
echo '<center><h1>Comment posted! Thanks.</h1><a href="/details.php?id='.strip_tags($_GET['id']).'">Click here to view your posting</a></center>';
footer();
}
?>