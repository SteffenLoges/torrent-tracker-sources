<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/



/* 
	check if file is being accessed directly
*****************************************/
if (eregi('config.php',$_SERVER['PHP_SELF'])) {die;}


//        <<<    start config

/*
	General db config
******************************************/
$dbhost 	= 'localhost'; // Host 
$dbuser 	= ''; // Username
$dbpass 	= ''; // Database password
$database 	= ''; // Database name
$btdir 		= './torrent/'; //  torrent folder
$sitename	= 'T-Xore'; // you could also use <img src="logo.png"> etc... result will be displayed on every page (top)
$admin_user = 'admin';
$admin_pass = 'pass';
$version	= '1'; // Only change this when you have a newer version installed (change after every update

/*

//        end config   >>>



	Connect to the database
*******************************************/
function connect ($dbhost, $dbuser, $dbpass, $database)
{
$errormes = 'The sql server has encountered a problem, we are trying to fix it as soon as possible';
@$connection = mysql_connect($dbhost, $dbuser, $dbpass);
@mysql_select_db($database) or die($errormes);
}

// Sql category search extension
function catsearch ($mcat)
{
if ($mcat == '1' || $mcat == '2' || $mcat == '3' || $mcat == '4' || $mcat == '5' || $mcat == '6' || $mcat == '7')
{
return "AND torrents.maincat = '$mcat'";
}
}




// Escape url (for scraping)
function escape_url($url) 
{
$ret = '';
for($i = 0; $i < strlen($url); $i+=2)
$ret .= '%'.$url[$i].$url[$i + 1];
return $ret;
}

/* return description icon */
function desc($val)
{
if ($val == 1)
{
return '<img class="r" src="/images/i.gif" alt="[i]" title="Description included" />';
}
}

/* return registration icon */
function regicon($val,$tracker)
{
if ($val == 1)
{
$uri = parse_url($tracker);
return '<img class="r" src="/images/r.gif" alt="[r]" title="Tracked by: '.htmlentities($uri['host']).'" />';
}
}

/* return registration value on details page*/
function detreg($val)
{
if ($val == 1)
{
$uri = parse_url($tracker);
return 'registration required';
}
else
{
return 'No registration required';
}
}

/*
	Magnet Link
*********************************************/
function base32_encode ($inString)
{
$outString = '';
$compBits = '';
$BASE32_TABLE = array(
                         '00000' => 0x61,
                         '00001' => 0x62,
                         '00010' => 0x63,
                         '00011' => 0x64,
                         '00100' => 0x65,
                         '00101' => 0x66,
                         '00110' => 0x67,
                         '00111' => 0x68,
                         '01000' => 0x69,
                         '01001' => 0x6a,
                         '01010' => 0x6b,
                         '01011' => 0x6c,
                         '01100' => 0x6d,
                         '01101' => 0x6e,
                         '01110' => 0x6f,
                         '01111' => 0x70,
                         '10000' => 0x71,
                         '10001' => 0x72,
                         '10010' => 0x73,
                         '10011' => 0x74,
                         '10100' => 0x75,
                         '10101' => 0x76,
                         '10110' => 0x77,
                         '10111' => 0x78,
                         '11000' => 0x79,
                         '11001' => 0x7a,
                         '11010' => 0x32,
                         '11011' => 0x33,
                         '11100' => 0x34,
                         '11101' => 0x35,
                         '11110' => 0x36,
                         '11111' => 0x37,
                         );
   
   /* Turn the compressed string into a string that represents the bits as 0 and 1. */
   for ($i = 0; $i < strlen($inString); $i++) {
       $compBits .= str_pad(decbin(ord(substr($inString,$i,1))), 8, '0', STR_PAD_LEFT);
   }
   
   /* Pad the value with enough 0's to make it a multiple of 5 */
   if((strlen($compBits) % 5) != 0) {
       $compBits = str_pad($compBits, strlen($compBits)+(5-(strlen($compBits)%5)), '0', STR_PAD_RIGHT);
   }
   
   /* Create an array by chunking it every 5 chars */
   $fiveBitsArray = split("\n",rtrim(chunk_split($compBits, 5, "\n")));
   
   /* Look-up each chunk and add it to $outstring */
   foreach($fiveBitsArray as $fiveBitsString) {
       $outString .= chr($BASE32_TABLE[$fiveBitsString]);
   }
   
   return $outString;
}


/*  Fetch torrent meta info  No hussle here just go along with it */
function torrent_info_file($file) 
{
require_once 'BDecode.php';
require_once 'BEncode.php';
$torrent = BDecode(file_get_contents($file));
$ret = array();
$countfiles = count($torrent['info']['files']);
if($countfiles == 0) 
{
$ret['files'] = 1;
$size = $torrent['info']['length'];
$ret['fileinfo'][0]['name'] = $torrent['info']['name'];
$ret['fileinfo'][0]['size'] = $size;
}
else 
{
$ret['files'] = $countfiles;
$size = 0;
for($i = 0; $i < $countfiles; $i++) 
{
$ret['fileinfo'][$i]['name'] = $torrent['info']['name'];
for($j = 0; $j < count($torrent['info']['files'][$i]['path']); $j++)
$ret['fileinfo'][$i]['name'] .= '/'.$torrent['info']['files'][$i]['path'][$j];
$ret['fileinfo'][$i]['size'] = $torrent['info']['files'][$i]['length'];
$size += $torrent['info']['files'][$i]['length'];
}
}
$announce = $torrent['announce'];
$announce = preg_replace('/\\?passkey=(.*)/', '', $announce); 
$announce = preg_replace('/\\/tracker\\/(.*)\\/announce/', '/tracker//announce', $announce); 
$ret['announce'] = $announce;
$ret['scrape'] = str_replace('announce', 'scrape', $announce);
$ret['size'] = $size;
$ret['hash'] = sha1(BEncode($torrent['info']));
return $ret;
}


/* fetch torrent seeds and peers */
function torrent_scrape_url($scrape, $hash) 
{
require_once 'BDecode.php';
@$fp = file_get_contents($scrape.'?info_hash='.escape_url($hash));
$ret = array();
if(!$fp) 
{
$ret['seeds'] = -1;
$ret['peers'] = -1;
}
else 
{
$stats = BDecode($fp);
$binhash = addslashes(pack("H*", $hash));
$seeds = $stats['files'][$binhash]['complete'];
$peers = $stats['files'][$binhash]['incomplete'];
$ret['seeds'] = $seeds;
$ret['peers'] = $peers;
}
return $ret;
}

/* return peers and seeds */
function getpeer($var)
{
if ($var == -1)
{
return '---';
}
else
{
return $var;
}
}



/*
	Seeders and peers (dont mind the function name)
************************************************/
function seeders ($peers)
{

if ($peers == -1)
{
$peers = '<div class="u">---</div>';
}
if ($peers == 0)
{
$peers = '<div class="r">'.$peers.'</div>';
}
if ($peers > 0)
{
$peers = '<div class="g">'.$peers.'</div>';
}

return $peers;
}


/*
	Get size and suffix
******************************************/
function torsize ($size)
{
if ($size >= 1099511627776) 	{$size = round($size / 1024 / 1024 / 1024 / 1024, 2).' TB';} 
elseif ($size >= 1073741824) 	{$size = round($size / 1024 / 1024 / 1024, 2).' GB';} 
elseif ($size >= 1048576) 		{$size = round($size / 1024 / 1024, 2).' MB';} 
elseif ($size >= 1024) 			{$size = round($size / 1024, 2).' KB';}
else 							{$size = $size.' Byte';}
return $size;
}


/*
	Tracker registration
******************************************/
function regi ($reqreg, $tracker)
{
if ($reqreg == 1)
{
$uri = parse_url($tracker);
return '<a href="/faq.html" title="tracked by: '.htmlentities($uri['host']).'"><img src="/images/reg.gif" class="treg" alt="tracked by: '.htmlentities($uri['host']).'" /></a> ';
}
}


/*
	Tracker for details page
*/
function trackeruri ($tracker)
{
preg_match("/^(http:\/\/)?([^\/]+)/i", "$tracker", $matches);
return ("$matches[1]$matches[2]");
}


/*
	Print out header
*******************************************/
function stheader($title)
{
global $sitename;
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="/stylesheet.css" type="text/css" />
<title>T-Xore : '; 

if ($title == '')
{
$title = 'Beyond Bittorrent!'; 
}

echo htmlentities($title);




echo '</title>
</head><body><a name="start"></a><h1>'.$sitename.'</h1></a><div id="menu">
<a href="/">Home</a> | <a href="/browse.php">Browse</a> | <a href="/search.php">Search</a> | <a href="/upload.php">Upload</a> | <a href="/about.php">About</a></div>
<center><form id="search" action="/search.php"><input name="term" /> <select name="cat"><option value="0">-All-</option><option value="6">Anime</option><option value="4">Games</option><option value="7">Misc</option><option value="1">Movies</option><option value="3">Music</option><option value="2">Series</option><option value="5">Software</option></select> <input type="submit" value="search" /></form></center><br />';
}



/*
	Print out Admin header
*******************************************/
function adminheader($title)
{
global $sitename;
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="/stylesheet.css" type="text/css" />
<title>T-Xore Administration: '; 


echo htmlentities($title);
echo '</title>
</head><body>
<h1>'.$sitename.'</h1></a><div id="menu">
<a href="/">Go back to the site</a> | <a href="/admin/">Admin section</a> | <a href="/admin/uda.php">Update Torrents</a> | <a href="/admin/new.php">Manage New</a> | <a href="/admin/recount.php">Recount stats</a> | <a href="/admin/check.php">Check Version</a> | <a href="/admin/adminLogOut.php">Logout</a></div>';
}


/*
	Print out footer (also for admin pages
*******************************************/

function footer ()
{
echo '</body></html>';
}



/* show files contained in a torrent */

function showfiles($hash) 
{
$filename = $hash;
global $btdir;
require_once("BDecode.php") ;
require_once("BEncode.php") ;
require_once("config.php") ;

$filename = "./$btdir/$filename.bogtor";

$stream = @file_get_contents("$filename");


if ($stream == FALSE) 
{
echo '<tr><td>No details availiable...</td></tr>';
}
if(!isset($stream))
{
echo '<tr><td>No details availiable...</td></tr>';
break;
}
else
{
$array = BDecode($stream);
if ($array === FALSE)
{
echo '<tr><td>No details availiable...</td></tr>';
break;
}
else
{
if(array_key_exists("info", $array) === FALSE){
echo '<tr><td>No details availiable...</td></tr>';
break;
}
else
{
$infovariable = $array["info"];
if (isset($infovariable["files"]))  
{

$filecount = "";
foreach ($infovariable["files"] as $file)
{

$row_color = ($row_count % 2) ? $color1 : $color2; 

$filecount += "1";
$multiname = $file['path'];
$multitorrentsize = torsize ($file['length']);
$torrentsize += $file['length'];
$combinedsize = torsize($torrentsize);
$strname = strip_tags ($multiname[0]);

$strname = htmlentities($strname);
$strname = strip_tags($strname);

echo "<tr><td width=\"15%\">$multitorrentsize</td><td>: $strname</td></tr>";
$row_count++;
} 
}
else 
{
$singletf = $infovariable['name'] ;
$singletf  = strip_tags($singletf );
$torrentsize = torsize($infovariable['length']);

$singletf = htmlentities($singletf);
$singletf = strip_tags($singletf);

echo "<tr><td width=\"15%\">$torrentsize</td><td>: $singletf</td></tr>";
}
}
}
}
}
?>
