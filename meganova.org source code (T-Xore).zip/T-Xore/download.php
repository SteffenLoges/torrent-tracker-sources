<?

require_once 'config.php';

connect ($dbhost, $dbuser, $dbpass, $database);

if(ini_get('zlib.output_compression'))
ini_set('zlib.output_compression','Off');


$id=$_GET['id'];


$result= mysql_query ("SELECT * FROM torrents WHERE hash = '$id'") or die ("query error"); 

while($row = mysql_fetch_array ($result))
{
extract ($row);

$filepath=$btdir.'/'.$hash . '.bogtor';
}

if ($torrentname == '')
{
die('Torrent not found');
}

if (!is_file($filepath) || !is_readable($filepath))
{
die('<h1>No such torrent, perhaps missing</h1>');
}




header("Content-Type: application/x-bittorrent");
header( "Content-Disposition: attachment; filename=\"$torrentname.torrent\"");

?>
