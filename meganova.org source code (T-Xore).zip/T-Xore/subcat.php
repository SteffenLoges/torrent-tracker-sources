<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/


require_once "config.php";
connect ($dbhost, $dbuser, $dbpass, $database);


$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid WHERE subid = '".strip_tags(trim($_GET['id']))."' ORDER BY added DESC") or die (mysql_error());
$result_subcatname = mysql_query("SELECT DISTINCT name,catid,subname,subid FROM categories WHERE subid='".strip_tags(trim($_GET['id']))."'") or die (mysql_error());

$count = mysql_num_rows($result);
$namerow =  mysql_fetch_row($result_subcatname); 


// Non htmlentities are allowed in title (converted automaticly by function
stheader ('Sub category : '.$namerow[0].' > '.$namerow[2]);


if ($count == 0){
echo '<h1>No torrents in this subcat or no such subcat at all</h1>';
footer();
die;
}

echo '<div class="location"><a href="/">Home</a> :: <a href="/cat.php?id='.$namerow[1].'">'.$namerow[0].'</a> :: <a href="/subcat.php?id='.$namerow[3].'">'.$namerow[2].'</a></div>';
echo '<h1>'.$count.' torrents in '.$namerow[2].'</h1>';
echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><th>Date</th><th>Filename</th><th>Size</th><th>Seeds</th><th>Peers</th></tr>';


while ($row = mysql_fetch_array($result)){
extract($row);

echo '<tr>';

echo '<td>'.substr($added,-9).'</td>';
echo '<td><a href="/download.php?id='.$hash.'"><img src="/images/d.gif" alt="[d]" /></a> '.regicon($registration,$tracker).' '.desc($description).'<a href="/details.php?id='.$id.'">'.$torrentname.'</a></td>';
echo '<td align="right">'.torsize($size).'</td>';
echo '<td class="d">'.getpeer($seeds).'</td>';
echo '<td class="d">'.getpeer($peers).'</td>';
echo '</tr>';

}
echo '</table>';



footer();
?>