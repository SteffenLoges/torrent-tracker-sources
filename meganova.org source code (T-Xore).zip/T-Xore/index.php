<?
/*
		Project : T-Xore    version      0.0.1      released     on 03/2006   By  Bogaa 
		This piece of software is free to use by anyone and may be redistributed
		and modified by anyone in any way. We   can't be held   liable for damage
		or copyright infringement claims. Read the documentation!
		
		Bogaa's Homepage : http://www.meganova.org
		Project Homepage  : http://www.devnova.org
*/
/*	cat. array
*******************/
$catt[0] =	1;
$catt[1] =	2;
$catt[2] =	3;
$catt[3] =	4;
$catt[4] =	5;
$catt[5] =	6;
$catt[6] =	7;


$catnamet[1]	=	'Movies';
$catnamet[2]	=	'Series';
$catnamet[3]	=	'Music';
$catnamet[4]	=	'Games';
$catnamet[5]	=	'Software';
$catnamet[6]	=	'Anime';
$catnamet[7]	=	'Misc';


require_once "config.php";
connect ($dbhost, $dbuser, $dbpass, $database);
stheader('');
echo '<div class="location"><a href="/">Home</a> :: <a href="/">Latest files</a></div>';
$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid WHERE added > '".date('Ymd')."' ORDER BY added DESC") or die (mysql_error());
$count = mysql_num_rows($result);

if ($count == 0)
{
echo '<h1>0 Torrents added today</h1>';
footer();
die;
}

echo '<h1>'.$count.' torrents added today</h1><br />';

foreach ($catt as $catval)
{
$result = mysql_query("SELECT * FROM torrents LEFT JOIN categories ON torrents.subcat = categories.subid WHERE added > '".date('Ymd')."' AND maincat = '$catval' ORDER BY added DESC") or die (mysql_error());

if (mysql_num_rows($result) == 0)
{
}
else
{
echo '<a name="'.$catnamet[$catval].'"></a><h1 class="hl"><a href="/cat/'.$catval.'.html">'.$catnamet[$catval].'</a></h1>';
echo '<table class="tor" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><th>Category</th><th>Date</th><th>Filename</th><th>Size</th><th>Seeds</th><th>Peers</th></tr>';


while ($row = mysql_fetch_array($result))
{
extract($row);

echo '<tr>';
echo '<td><a href="/cat.php?id='.$maincat.'">'.$name.'</a></td>';
echo '<td>'.substr($added,-9).'</td>';
echo '<td><a href="/download.php?id='.$hash.'"><img src="/images/d.gif" alt="[d]" /></a> '.regicon($registration,$tracker).' '.desc($description).'<a href="/details.php?id='.$id.'">'.$torrentname.'</a></td>';
echo '<td align="right">'.torsize($size).'</td>';
echo '<td class="d">'.getpeer($seeds).'</td>';
echo '<td class="d">'.getpeer($peers).'</td>';
echo '</tr>';


}
echo '</table><br />';
}
}


footer();
?>