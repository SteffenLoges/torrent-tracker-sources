
CREATE TABLE avps (
  arg varchar(20) NOT NULL default '',
  value_i int(11) NOT NULL default '0',
  value_u int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (arg)
) TYPE=HEAP;



CREATE TABLE categories (
  id int(10) unsigned NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  sort_index int(10) unsigned NOT NULL default '0',
  image varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;


CREATE TABLE comments (
  id int(10) unsigned NOT NULL auto_increment,
  user int(10) unsigned NOT NULL default '0',
  torrent int(10) unsigned NOT NULL default '0',
  added datetime NOT NULL default '0000-00-00 00:00:00',
  text text NOT NULL,
  ori_text text NOT NULL,
  PRIMARY KEY  (id),
  KEY user (user),
  KEY torrent (torrent)
) TYPE=MyISAM;


CREATE TABLE files (
  id int(10) unsigned NOT NULL auto_increment,
  torrent int(10) unsigned NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  size bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY torrent (torrent)
) TYPE=MyISAM;

CREATE TABLE hits (
  id int(10) unsigned NOT NULL auto_increment,
  page varchar(20) NOT NULL default '',
  period datetime NOT NULL default '0000-00-00 00:00:00',
  count bigint(20) unsigned NOT NULL default '0',
  runs bigint(20) unsigned NOT NULL default '0',
  runtime double NOT NULL default '0',
  user_cpu double NOT NULL default '0',
  sys_cpu double NOT NULL default '0',
  PRIMARY KEY  (id),
  UNIQUE KEY hit (period,page)
) TYPE=MyISAM;

CREATE TABLE peers (
  torrent int(10) unsigned NOT NULL default '0',
  peer_id char(20) binary NOT NULL default '',
  ip char(15) NOT NULL default '',
  port smallint(5) unsigned NOT NULL default '0',
  uploaded bigint(20) unsigned NOT NULL default '0',
  downloaded bigint(20) unsigned NOT NULL default '0',
  to_go bigint(20) unsigned NOT NULL default '0',
  seeder enum('yes','no') NOT NULL default 'no',
  started datetime NOT NULL default '0000-00-00 00:00:00',
  last_action datetime NOT NULL default '0000-00-00 00:00:00',
  connectable enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (torrent,peer_id),
  KEY torrent (torrent)
) TYPE=HEAP;


CREATE TABLE ratings (
  torrent int(10) unsigned NOT NULL default '0',
  user int(10) unsigned NOT NULL default '0',
  rating tinyint(3) unsigned NOT NULL default '0',
  added datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (torrent,user),
  KEY user (user)
) TYPE=MyISAM;


CREATE TABLE torrents (
  id int(10) unsigned NOT NULL auto_increment,
  info_hash varchar(20) binary NOT NULL default '',
  name varchar(255) NOT NULL default '',
  filename varchar(255) NOT NULL default '',
  save_as varchar(255) NOT NULL default '',
  search_text text NOT NULL,
  descr text NOT NULL,
  ori_descr text NOT NULL,
  category int(10) unsigned NOT NULL default '0',
  size bigint(20) unsigned NOT NULL default '0',
  added datetime NOT NULL default '0000-00-00 00:00:00',
  type enum('single','multi') NOT NULL default 'single',
  numfiles int(10) unsigned NOT NULL default '0',
  views int(10) unsigned NOT NULL default '0',
  hits int(10) unsigned NOT NULL default '0',
  times_completed int(10) unsigned NOT NULL default '0',
  last_action datetime NOT NULL default '0000-00-00 00:00:00',
  visible enum('yes','no') NOT NULL default 'yes',
  owner int(10) unsigned NOT NULL default '0',
  numratings int(10) unsigned NOT NULL default '0',
  ratingsum int(10) unsigned NOT NULL default '0',
  seeders int(10) unsigned NOT NULL default '0',
  leechers int(10) unsigned NOT NULL default '0',
  comments int(10) unsigned NOT NULL default '0',
  banned enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (id),
  UNIQUE KEY info_hash (info_hash),
  KEY owner (owner),
  KEY visible (visible),
  KEY category_visible (category,visible),
  FULLTEXT KEY ft_search (search_text,ori_descr)
) TYPE=MyISAM;

CREATE TABLE users (
  id int(10) unsigned NOT NULL auto_increment,
  username varchar(40) NOT NULL default '',
  password varchar(40) NOT NULL default '',
  secret varchar(20) binary NOT NULL default '',
  email varchar(80) NOT NULL default '',
  status enum('pending','confirmed') NOT NULL default 'pending',
  added datetime NOT NULL default '0000-00-00 00:00:00',
  last_login datetime NOT NULL default '0000-00-00 00:00:00',
  last_access datetime NOT NULL default '0000-00-00 00:00:00',
  admin enum('yes','no') NOT NULL default 'no',
  editsecret varchar(20) binary NOT NULL default '',
  privacy enum('strong','normal','low') NOT NULL default 'normal',
  descr text NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY username (username),
  KEY status_added (status,added)
) TYPE=MyISAM;


INSERT INTO categories VALUES (1,'Movies',10,'film.jpg');
INSERT INTO categories VALUES (2,'Music',20,'music.jpg');
INSERT INTO categories VALUES (3,'TV',30,'tv3.jpg');
INSERT INTO categories VALUES (4,'Games',40,'games.jpg');
INSERT INTO categories VALUES (5,'Applications',50,'apps.jpg');
INSERT INTO categories VALUES (6,'Miscellaneous',1000,'misc.jpg');
INSERT INTO categories VALUES (7,'Pr0n',70,'pr0n.jpg');
INSERT INTO categories VALUES (8,'Pictures',80,'pics.jpg');
INSERT INTO categories VALUES (9,'Anime',90,'anime.jpg');
INSERT INTO categories VALUES (10,'Comics',100,'comics.jpg');
INSERT INTO categories VALUES (11,'Books',110,'books2.jpg');
INSERT INTO categories VALUES (13,'Music Videos',25,'mvid6.jpg');

