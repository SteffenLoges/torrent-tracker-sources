for x in ../*.php; do X="$(basename "$x" .php)"; ln -s "$x" "$X".phps; ln -s "$x" "$X".txt; done
