<?

require_once("include/bittorrent.php");

hit_start();

dbconn();
$id = 0 + $matches[1];

hit_count();

if (!mkglobal("type")){
	die();
}


if ($type == "signup" && mkglobal("email")) {
	stdhead("User signup");

echo'<table border="0" cellspacing="0" cellpadding="0" width="70%" align=center><td bgcolor="#ECECEC" height="100" style="border-style: solid; border-width: 1" bordercolor="#888886" width="100%"><font face=arial size=3>';
	print("<center>Anmeldung erfolgreich! Du wirst jetzt zur Login Seite weitergeleitet.\n");	
	echo '<meta http-equiv="refresh" content="3;url=login.php"></td></table>';
	stdfoot();
}

else{
	die();
}


hit_end();




?>
