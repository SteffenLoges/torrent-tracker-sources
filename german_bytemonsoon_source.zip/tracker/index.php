<?

function getmicrotime(){ 
    list($usec, $sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
    } 
$time_start = getmicrotime();


#ob_start();
ob_start("ob_gzhandler");

require_once('include/bittorrent.php');

hit_start();

dbconn();

hit_count();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
	unset($cleansearchstr);

$orderby = "ORDER BY torrents.id DESC";

$addparam = "";
$wherea = array();

if ($_GET["incldead"]) {
	$addparam .= "incldead=1&amp;";
	if (!isset($CURUSER) || $CURUSER["admin"] != "yes")
		$wherea[] = "banned != 'yes'";
}
else
	$wherea[] = "visible = 'yes'";

if ($_GET["cat"]) {
	$wherea[] = "category = " . sqlesc($_GET["cat"]);
	$addparam .= "cat=" . urlencode($_GET["cat"]) . "&amp;";
}
$wherebase = $wherea;
if (isset($cleansearchstr)) {
	$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
	//$wherea[] = "0";
	$addparam .= "search=" . urlencode($searchstr) . "&amp;";
	$orderby = "";
}
$where = implode(" AND ", $wherea);
if ($where != "")
	$where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where")
	or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
	$wherea = $wherebase;
	$orderby = "ORDER BY id DESC";
	$searcha = explode(" ", $cleansearchstr);
	$sc = 0;
	foreach ($searcha as $searchss) {
		if (strlen($searchss) <= 1)
			continue;
		$sc++;
		if ($sc > 5)
			break;
		$ssa = array();
		foreach (array("search_text", "ori_descr") as $sss)
			$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
		$wherea[] = "(" . implode(" OR ", $ssa) . ")";
	}
	if ($sc) {
		$where = implode(" AND ", $wherea);
		if ($where != "")
			$where = "WHERE $where";
		$res = mysql_query("SELECT COUNT(*) FROM torrents $where");
		$row = mysql_fetch_array($res);
		$count = $row[0];
	}
}

if ($count) {
	list($pagertop, $pagerbottom, $limit) = pager(20, $count, "./?" . $addparam);

	#$query = "SELECT torrents.filename, torrents.seeders, torrents.leechers, torrents.comments, torrents.type, torrents.id, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, torrents.name, numfiles, save_as, torrents.added, size, times_completed, views, hits, category, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	$query = "SELECT torrents.*, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	$res = mysql_query($query)
		or die(mysql_error());
}
else
	unset($res);

if ($count == 1) {
	$row = mysql_fetch_array($res);
	header("Refresh: 0; url=details.php?id=" . $row["id"] . "&searched=" . urlencode($searchstr));
	hit_end();
	exit();
}

$additionals = 0;

if (isset($cleansearchstr))
	stdhead("Search results for \"$searchstr\"");
else {
	stdhead();

	if ($_SERVER["QUERY_STRING"] == "") {
		$additionals = 1;
		// motd
?>
<script language="javascript">
<!--
if (parent.frames.length > 0) {
	parent.location.href = self.document.location;
}
// -->
</script>
<font size=2 face=arial>


<table border="0" cellspacing="0" cellpadding="0" width="70%" align=center>
<td bgcolor="#FFFFCC" height="1" style="border-style: solid; border-width: 1" bordercolor="#888886" width="100%"><font face=arial size=1><b>
<img src="warn.gif" border=0 align=left>Disclaimer: Keine dieser Files sind hier auf dem Server gehostest. Hier gibt es nur sogenannte Bittorrent Metafiles, welche von den Usern hochgeladen werden. Diese Seite wird nicht benutzt um Copyright gesch�tztes Material zu verbreiten, und Ihr solltet keine Sachen herunterladen sofern ihr nicht selber Eigent�mer dieser Sachen seit. Der Administrator dieser Seite (www.babasboard.de) hat keinerlei Einfluss darauf was die User hier posten.</b>
</b></td></table>

<?
	}
}

$cats = genrelist();

?>
<form method="get" action="./">
<p align="center">
Suche:
<input type="text" name="search" size="40" value="<?= htmlspecialchars($searchstr) ?>" style="font-family: v; font-size: 8pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 3; padding-right: 3; padding-top: 1; padding-bottom: 1"/>
in
<select name="cat">
<option value="0">(alles)</option>
<?

$catdropdown = "";
foreach ($cats as $cat) {
	$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
	if ($cat["id"] == $_GET["cat"])
		$catdropdown .= " selected=\"selected\"";
	$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

$deadchkbox = "<input type=\"checkbox\" name=\"incldead\" value=\"1\"";
if ($_GET["incldead"])
	$deadchkbox .= " checked=\"checked\"";
$deadchkbox .= " /> inkl. toter Torrents\n";

?>
<?= $catdropdown ?>
</select>
<?= $deadchkbox ?>
<input type="submit" value="Suche!" style="font-family: v; font-size: 8pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 3; padding-right: 3; padding-top: 1; padding-bottom: 1"/>
</p>
</form>
<form method="get" action="./">
<p align="center">
<i>-- oder --</i> Zeige alles von:
<select name="cat">
<option value="0">(alles)</option>
<?= $catdropdown ?>
</select>
<?= $deadchkbox ?>
<input type="submit" value="Los!" style="font-family: v; font-size: 8pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 3; padding-right: 3; padding-top: 1; padding-bottom: 1"/>
</p>
</form>
<?

if (isset($cleansearchstr))
	print("<h2>Suchergebnisse f�r \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
	print($pagertop);

	torrenttable($res);

	print($pagerbottom);
}
else {
	if (isset($cleansearchstr)) {
		print("<h2>Nix gefunden!</h2>\n");
		print("<p>Versuche es nochmal mit einer anderen Sucheingabe.</p>\n");
	}
	else {
		print("<h2>Nix hier!</h2>\n");
		print("<p>Sorry Kumpel :(</p>\n");
	}
}

if ($additionals) {

include('news.txt');
?>

<?
$time_end = getmicrotime();
$time = $time_end - $time_start;

echo "<BR><font size=1 face=arial>Seite aufgebaut in $time Sekunden</font><BR>";


}

stdfoot();

hit_end();

?>
