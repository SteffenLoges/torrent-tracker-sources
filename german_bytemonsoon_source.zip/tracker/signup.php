<?

require_once("include/bittorrent.php");

stdhead("Signup");

?>
<form method="post" action="takesignup.php">
<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#646262" width="50%" border="1" >
<td>
<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#D6D9DB" width="100%" border="1" >
<tr><td background="cell5.gif" bgcolor=005FB4 colspan="2" align=left><font size=3 color=white face=arial>Anmeldungs Formular</td></tr>



<tr><td align="right" bgcolor=ECECEC class="heading"><font face=arial size=2>Username:</td><td bgcolor=F7F7F7><input type="text" size="40" name="wantusername" /></td></tr>
<tr><td align="right" bgcolor=ECECEC class="heading"><font face=arial size=2>Passwort</td><td bgcolor=F7F7F7><input type="password" size="40" name="wantpassword" /></td></tr>
<tr><td align="right" bgcolor=ECECEC class="heading"><font face=arial size=2>wiederholen:</td><td bgcolor=F7F7F7><input type="password" size="40" name="passagain" /></td></tr>
<tr><td align="right" bgcolor=ECECEC class="heading"><font face=arial size=2>Email Addresse:</td><td bgcolor=F7F7F7><input type="text" size="40" name="email" /></td></tr>
<tr><td align="right" bgcolor=ECECEC class="heading"><font face=arial size=2>wiederholen:</td><td bgcolor=F7F7F7><input type="text" size="40" name="emailagain" /></td></tr>
<tr><td colspan="2" align="center" bgcolor=F7F7F7><input type="submit" value="Sign up!" style="font-family: v; font-size: 8pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 3; padding-right: 3; padding-top: 1; padding-bottom: 1"/></td></tr>
<tr><td colspan="2" align="center" bgcolor=ECECEC><font face=arial size=2>Beachte: Du must Cookies akzeptieren um dich anzumelden.</td></tr>
</table>

</td></table>
</form>
<?

stdfoot();

?>
