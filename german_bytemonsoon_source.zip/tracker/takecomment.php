<?

require_once("include/bittorrent.php");

hit_start();

dbconn();

hit_count();

if (!isset($CURUSER))
	die();

if (!mkglobal("main:id"))
	die();

$id = 0 + $id;
if (!$id)
	die();

$res = mysql_query("SELECT 1 FROM torrents WHERE id = $id");
$row = mysql_fetch_array($res);
if (!$row)
	die();

mysql_query("INSERT INTO comments (user, torrent, added, text, ori_text) VALUES (" .
		$CURUSER["id"] . ",$id, NOW(), " . sqlesc(parsedescr($main)) . "," . sqlesc($main) . ")");

$newid = mysql_insert_id();

mysql_query("UPDATE torrents SET comments = comments + 1 WHERE id = $id");

header("Refresh: 0; url=details.php?id=$id&viewcomm=$newid#comm$newid");

hit_end();

?>
