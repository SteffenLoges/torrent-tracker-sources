<?

require_once("include/bittorrent.php");

hit_start();

dbconn();

hit_count();

function bark($msg) {
	genbark($msg, "Bewertung fehlgeschlagen!");
}

if (!isset($CURUSER))
	bark("Du musst angemeldet sein um zu bewerten");

if (!mkglobal("rating:id"))
	bark("mhh?");

$id = 0 + $id;
if (!$id)
	bark("unzul�ssige ID");

$rating = 0 + $rating;
if ($rating <= 0 || $rating > 5)
	bark("unzul�ssige Bewertung");

$res = mysql_query("SELECT owner FROM torrents WHERE id = $id");
$row = mysql_fetch_array($res);
if (!$row)
	bark("Keine Torrents");

if ($row["owner"] == $CURUSER["id"])
	bark("Du kannst deine eigenen Torrents nicht bewerten.");

$res = mysql_query("INSERT INTO ratings (torrent, user, rating, added) VALUES ($id, " . $CURUSER["id"] . ", $rating, NOW())");
if (!$res) {
	if (mysql_errno() == 1062)
		bark("Du hast dieses Torrent schon bewertet.");
	else
		bark(mysql_error());
}

mysql_query("UPDATE torrents SET numratings = numratings + 1, ratingsum = ratingsum + $rating WHERE id = $id");

header("Refresh: 0; url=details.php?id=$id&rated=1");

hit_end();

?>
