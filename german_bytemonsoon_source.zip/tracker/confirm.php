<?

require_once("include/bittorrent.php");

hit_start();

if (!preg_match(':^/(\d{1,10})/([\w]{32})$:', $_SERVER["PATH_INFO"], $matches))
	httperr();

//$id = 0 + $matches[1];
//$md5 = $matches[2];

if (!$id)
	httperr();

dbconn();

hit_count();

$res = mysql_query("SELECT password, secret, status FROM users WHERE id = $id");
$row = mysql_fetch_array($res);

if (!$row)
	httperr();

if ($row["status"] != "pending") {
	header("Refresh: 0; url=../../ok.php?type=confirmed");
	exit();
}

$sec = hash_pad($row["secret"]);
if ($md5 != md5($sec))
	httperr();

$newsec = mksecret();

mysql_query("UPDATE users SET secret=" . sqlesc($newsec) . ", status='confirmed' WHERE id=$id AND secret=" . sqlesc($row["secret"]) . " AND status='pending'");

if (!mysql_affected_rows())
	httperr();

logincookie($id, $row["password"], $newsec);

header("Refresh: 0; url=../../ok.php?type=confirm");

hit_end();

?>
