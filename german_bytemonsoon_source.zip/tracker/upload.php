<?

require_once("include/bittorrent.php");

hit_start();

dbconn();

hit_count();

loggedinorreturn();

stdhead("Upload");

?>
<form enctype="multipart/form-data" action="takeupload.php" method="post">
<input type="hidden" name="MAX_FILE_SIZE" value="<?=$max_torrent_size?>" />
<p>Die Tracker Announce Url lautet: <b><?= $announce_urls[0] ?></b></p>
<p><b>Nur hochgeladene Torrents k�nnen geseedet werden!</b> Hochgeladene Torrents bleiben solange auf der Hauptseite unsichtbar, bis du mit dem seeden angefangen hast.</p>
<table border="2" cellspacing="5" cellpadding="5">
<?

tr("Datei", "<input type=\"file\" name=\"file\" size=\"60\" />\n", 1);
tr("Torrent Name", "<input type=\"text\" name=\"name\" size=\"80\" /><br />(Nimm es vom File Name. <b>Bitte benutze ordentliche Namen.</b>)\n", 1);
tr("Beschreibung<br />(kein Html erlaubt)", "<textarea name=\"descr\" rows=\"10\" cols=\"80\"></textarea>", 1);

$s = "<select name=\"type\">\n<option value=\"0\">(w�hle aus)</option>\n";

$cats = genrelist();
foreach ($cats as $row)
	$s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";

$s .= "</select>\n";
tr("Typ", $s, 1);

?>
<tr><td align="center" colspan="2"><input type="submit" value="Tu es!" /></td></tr>
</table>
</form>
<?

stdfoot();

hit_end();

?>
