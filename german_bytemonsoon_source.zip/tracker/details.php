<?
function getmicrotime(){ 
    list($usec, $sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
    } 
$time_start = getmicrotime();

#ob_start();
ob_start("ob_gzhandler");

require_once("include/bittorrent.php");

hit_start();

function dltable($name, $arr, $torrent) {
	global $CURUSER;

	$s = "<b>" . count($arr) . " $name</b>";
	if (!count($arr))
		return $s;
	$s .= "\n";
	$s .= "<table border=\"1\" cellpadding=\"4\" width=\"100%\">\n";
	$s .= "<tr><td class=\"heading\">IP/Port</td><td class=\"heading\" align=\"right\">Hochgeladen</td><td class=\"heading\" align=\"right\">Heruntergeladen</td><td class=\"heading\" align=\"right\">Komplett</td><td class=\"heading\" align=\"right\">Verbundene Zeit</td><td class=\"heading\" align=\"right\">Lehrlauf</td></tr>\n";
	$now = time();
	$admin = (isset($CURUSER) && $CURUSER["admin"] == "yes");

	foreach ($arr as $e) {
		$s .= "<tr>\n";
		$s .= "<td>" . ($admin ? $e["ip"] : preg_replace('/\.\d+$/', ".xxx", $e["ip"])) . ":" . (($e["connectable"] == "yes") ? $e["port"] : sprintf("(%d)", $e["port"])) . "</td>\n";
		$s .= "<td align=\"right\">" . mksize($e["uploaded"]) . "</td>\n";
		$s .= "<td align=\"right\">" . mksize($e["downloaded"]) . "</td>\n";
		$s .= "<td align=\"right\">" . sprintf("%.2f%%", 100 * (1 - ($e["to_go"] / $torrent["size"]))) . "</td>\n";
		$s .= "<td align=\"right\">" . mkprettytime($now - $e["st"]) . "</td>\n";
		$s .= "<td align=\"right\">" . mkprettytime($now - $e["la"]) . "</td>\n";
		$s .= "</tr>\n";
	}
	$s .= "</table>\n";
	return $s;
}

dbconn();

hit_count();

$id = $_GET["id"];
$id = 0 + $id;
if (!isset($id) || !$id)
	die();

$res = mysql_query("SELECT torrents.seeders, torrents.banned, torrents.leechers, torrents.info_hash, torrents.filename, UNIX_TIMESTAMP() - UNIX_TIMESTAMP(torrents.last_action) AS lastseed, torrents.numratings, torrents.name, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, torrents.owner, torrents.save_as, torrents.descr, torrents.visible, torrents.size, torrents.added, torrents.views, torrents.hits, torrents.times_completed, torrents.id, torrents.type, torrents.numfiles, categories.name AS cat_name, users.username FROM torrents LEFT JOIN categories ON torrents.category = categories.id LEFT JOIN users ON torrents.owner = users.id WHERE torrents.id = $id")
	or die();
$row = mysql_fetch_array($res);

$owned = $admin = 0;
if (isset($CURUSER)) {
	if ($CURUSER["admin"] == "yes")
		$owned = $admin = 1;
	elseif ($CURUSER["id"] == $row["owner"])
		$owned = 1;
}

if (!$row || ($row["banned"] == "yes" && !$admin))
	print("keine Torrents");
else {
	if ($_GET["hit"]) {
		mysql_query("UPDATE torrents SET views = views + 1 WHERE id = $id");
		if ($_GET["tocomm"])
			header("Refresh: 0; url=details.php?id=$id&page=0#startcomments");
		elseif ($_GET["filelist"])
			header("Refresh: 0; url=details.php?id=$id&filelist=1#filelist");
		elseif ($_GET["toseeders"])
			header("Refresh: 0; url=details.php?id=$id&dllist=1#seeders");
		elseif ($_GET["todlers"])
			header("Refresh: 0; url=details.php?id=$id&dllist=1#leechers");
		else
			header("Refresh: 0; url=details.php?id=$id");
		hit_end();
		exit();
	}

	if (!isset($_GET["page"])) {
		stdhead("Details f�r Torrent \"" . $row["name"] . "\"");

		if (isset($CURUSER) && ($CURUSER["id"] == $row["owner"] || $CURUSER["admin"] == "yes"))
			$owned = 1;
		else
			$owned = 0;

		$spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

		if ($_GET["uploaded"]) {
			print("<h2>Erfolgreich Hochgeladen!</h2>\n");
			print("<p>Du kannst nun mit dem Seeden beginnen. <b>Beachte:</b> das Torrent wird solange unsichtbar bleiben bis du es tust!</p>\n");
		}
		elseif ($_GET["edited"]) {
			print("<h2>Erfolgreich bearbeitet!</h2>\n");
			if (isset($_GET["returnto"]))
				print("<p><b>Gehe zur�ck zu <a href=\"" . htmlspecialchars($_GET["returnto"]) . "\">woher du kamst</a>.</b></p>\n");
		}
		elseif (isset($_GET["searched"])) {
			print("<h2>Deine Suche nach \"" . htmlspecialchars($_GET["searched"]) . "\" ergab ein einzelnes Ergebnis:</h2>\n");
		}
		elseif ($_GET["rated"])
			print("<h2>Bewertung hinzugef�gt!</h2>\n");

		//print("<table border=\"2\" cellspacing=\"5\" cellpadding=\"5\">\n");
echo '<center>';
echo '<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#646262" width="60%" border="1" ><td>';
echo '<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#D6D9DB" width="100%" border="1" >';

		$url = "edit.php?id=" . $row["id"];
		if (isset($_GET["returnto"])) {
			$addthis = "&amp;returnto=" . urlencode($_GET["returnto"]);
			$url .= $addthis;
			$keepget .= $addthis;
		}
		$editlink = "a href=\"$url\" class=\"sublink\"";

		$s = "<b>" . htmlspecialchars($row["name"]) . "</b>";
		if ($owned)
			$s .= " $spacer<$editlink>[Torrent bearbeiten]</a>";
		//tr("Name", $s, 1);
echo '<tr><td background="cell5.gif" bgcolor=005FB4 colspan="2" align=left><font size=2 color=white face=arial>'.$s.'</td></tr>';

		tr("Name", "<a class=\"index\" href=\"download.php?id=$id&file=" . rawurlencode($row["filename"]) . "\">" . htmlspecialchars($row["filename"]) . "</a>", 1);
		tr("Download Name", $row["save_as"]);

		function hex_esc($matches) {
			return sprintf("%02x", ord($matches[0]));
		}
		tr("Info Hash", preg_replace_callback('/./s', "hex_esc", hash_pad($row["info_hash"])));

		if (!empty($row["descr"]))
			tr("Beschreibung", $row["descr"], 1);
		if ($row["visible"] == "no")
			tr("Sichtbar", "<b>nein</b> (tot)", 1);
		if ($admin)
			tr("Gebannt", $row["banned"]);

		if (isset($row["cat_name"]))
			tr("Typ", $row["cat_name"]);
		else
			tr("Typ", "(keiner gew�hlt)");

		tr("Letzter Seed", "Letzte Aktivit�t " . mkprettytime($row["lastseed"]) . " vor");
		tr("Gr��e",mksize($row["size"]) . " (" . $row["size"] . " Bytes)");

		$s = "";
		$s .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td valign=\"top\">";
		if (!isset($row["rating"])) {
			if ($minvotes > 1) {
				$s .= "Keine (Ben�tigt min $minvotes Bewertungen und hat ";
				if ($row["numratings"])
					$s .= "nur " . $row["numratings"];
				else
					$s .= "keine";
				$s .= ")";
			}
			else
				$s .= "noch keine";
		}
		else {
			$rpic = ratingpic($row["rating"]);
			if (!isset($rpic))
				$s .= "unzul�ssig?";
			else
				$s .= "$rpic (" . $row["rating"] . " von 5 mit " . $row["numratings"] . " Bewertung(en) total)";
		}
		$s .= "\n";
		$s .= "</td><td>$spacer</td><td valign=\"top\">";
		if (!isset($CURUSER))
			$s .= "(<a href=\"login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;nowarn=1\">Log in</a> zum Bewerten)";
		else {
			$ratings = array(
					5 => "Kewl!",
					4 => "h�bsch",
					3 => "m�ssig",
					2 => "sch�n schlecht",
					1 => "Scheisse!",
			);
			if (!$owned || $admin) {
				$xres = mysql_query("SELECT rating, added FROM ratings WHERE torrent = $id AND user = " . $CURUSER["id"]);
				$xrow = mysql_fetch_array($xres);
				if ($xrow)
					$s .= "(Du bewertetest das Torrent als \"" . $xrow["rating"] . " - " . $ratings[$xrow["rating"]] . "\" am " . $xrow["added"] . ")";
				else {
					$s .= "<form method=\"post\" action=\"takerate.php\"><input type=\"hidden\" name=\"id\" value=\"$id\" />\n";
					$s .= "<select name=\"rating\">\n";
					$s .= "<option value=\"0\">(Bewertung abgeben)</option>\n";
					foreach ($ratings as $k => $v) {
						$s .= "<option value=\"$k\">$k - $v</option>\n";
					}
					$s .= "</select>\n";
					$s .= "<input type=\"submit\" value=\"Bewerte!\" />";
					$s .= "</form>\n";
				}
			}
		}
		$s .= "</td></tr></table>";
		tr("Bewertung", $s, 1);

		tr("Hinzugef�gt am", $row["added"]);
		tr("Views", $row["views"]);
		tr("Hits", $row["hits"]);
		tr("Snatched", $row["times_completed"] . " time(s)");

		$keepget = "";
		$uprow = isset($row["username"]) ? htmlspecialchars($row["username"]) : "<i>unbekannt</i>";
		if ($owned)
			$uprow .= " $spacer<$editlink>[Torrent bearbeiten]</a>";
		tr("Hochgeladen von", $uprow, 1);

		if ($row["type"] == "multi") {
			if (!$_GET["filelist"])
				tr("Files<br /><a href=\"details.php?id=$id&amp;filelist=1$keepget#filelist\" class=\"sublink\">[Liste anzeigen]</a>", $row["numfiles"] . " Files", 1);
			else {
				tr("Files", $row["numfiles"] . " Files", 1);

				$s = "<table border=\"1\" cellpadding=\"4\">\n";

				$subres = mysql_query("SELECT * FROM files WHERE torrent = $id ORDER BY id");
				while ($subrow = mysql_fetch_array($subres)) {
					$s .= "<tr><td>" . preg_replace(',[^/]+$,', '<b>$0</b>', htmlspecialchars($subrow["filename"])) . "</td><td align=\"right\">" . mksize($subrow["size"]) . "</td></tr>\n";
				}

				$s .= "</table>\n";
				tr("<a name=\"filelist\">File Liste</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[Schlie�e Liste]</a>", $s, 1);
			}
		}

		if (!$_GET["dllist"]) {
			/*
			$subres = mysql_query("SELECT seeder, COUNT(*) FROM peers WHERE torrent = $id GROUP BY seeder");
			$resarr = array(yes => 0, no => 0);
			$sum = 0;
			while ($subrow = mysql_fetch_array($subres)) {
				$resarr[$subrow[0]] = $subrow[1];
				$sum += $subrow[1];
			}
			tr("Peers<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[See full list]</a>", $resarr["yes"] . " seeder(s), " . $resarr["no"] . " leecher(s) = $sum peer(s) total", 1);
			*/
			tr("Peers<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[Liste anzeigen]</a>", $row["seeders"] . " Seeder, " . $row["leechers"] . " Leecher = " . ($row["seeders"] + $row["leechers"]) . " Peers total", 1);
		}
		else {
			$downloaders = array();
			$seeders = array();
			$subres = mysql_query("SELECT seeder, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, UNIX_TIMESTAMP(last_action) AS la FROM peers WHERE torrent = $id");
			while ($subrow = mysql_fetch_array($subres)) {
				if ($subrow["seeder"] == "yes")
					$seeders[] = $subrow;
				else
					$downloaders[] = $subrow;
			}

			function leech_sort($a,$b) {
				$x = $a["to_go"];
				$y = $b["to_go"];
				if ($x == $y)
					return 0;
				if ($x < $y)
					return -1;
				return 1;
			}
			function seed_sort($a,$b) {
				$x = $a["uploaded"];
				$y = $b["uploaded"];
				if ($x == $y)
					return 0;
				if ($x < $y)
					return 1;
				return -1;
			}

			usort($seeders, "seed_sort");
			usort($downloaders, "leech_sort");

			tr("<a name=\"seeders\">Seeder</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[Schlie�e  Liste]</a>", dltable("Seeder", $seeders, $row), 1);
			tr("<a name=\"leechers\">Leecher</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[Schlie�e Liste]</a>", dltable("Leecher", $downloaders, $row), 1);
		}

		print("</table></td></table>\n");

		print("<hr />\n");
	}
	else {
		stdhead("Kommentare \"" . $row["name"] . "\"");
		print("<p><a href=\"details.php?id=$id\">Zur�ck zu allen Details</a></p><hr />\n");
	}

	print("<p><a name=\"startcomments\"></a></p>\n");

	$commentbar = "<p align=\"center\"><a class=\"index\" href=\"addcomment.php?id=$id\">Kommentar abgeben</a></p>\n";

	$subres = mysql_query("SELECT COUNT(*) FROM comments WHERE torrent = $id");
	$subrow = mysql_fetch_array($subres);
	$count = $subrow[0];

	if (!$count) {
		print("<p class=\"important\" align=\"center\">Kein Kommentar</p>\n");
	}
	else {
		list($pagertop, $pagerbottom, $limit) = pager(20, $count, "details.php?id=$id&", array(lastpagedefault => 1));

		$subres = mysql_query("SELECT comments.id, text, comments.added, username FROM comments LEFT JOIN users ON comments.user = users.id WHERE torrent = $id ORDER BY comments.id $limit");
		$allrows = array();
		while ($subrow = mysql_fetch_array($subres))
			$allrows[] = $subrow;

		print($commentbar);
		print($pagertop);

		commenttable($allrows);

		print($pagerbottom);
	}

	print($commentbar);
}
$time_end = getmicrotime();
$time = $time_end - $time_start;

echo "<BR><font size=1 face=arial>Seite aufgebaut in $time Sekunden</font><BR>";

stdfoot();

hit_end();

?>
