<?
require_once("include/bittorrent.php");

//$id = $matches[1];

$id = intval($id);


hit_start();

if (!preg_match(':^/(\d{1,10})/(.+)\.torrent$:', $_SERVER["PATH_INFO"], $matches)){
	//httperr();
}
if (!$id){
	//httperr();
}
dbconn();

hit_count();

$res = mysql_query("SELECT 1 FROM torrents WHERE id = $id");
$row = mysql_fetch_array($res);

$fn = "$torrent_dir/$id.torrent";

if (!$row || !is_file($fn) || !is_readable($fn))
	httperr();


mysql_query("UPDATE torrents SET hits = hits + 1 WHERE id = $id");
header("Content-disposition: filename=".$file);
header("Content-Type: application/x-bittorrent");
readfile($fn);
//echo $id;



hit_end();

?>
