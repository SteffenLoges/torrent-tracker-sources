<?
$mysql_host = "localhost";
$mysql_user = "user";   # eurer mysql admin usernamen eingeben
$mysql_pass = "pass";   # eurer mysql admin passwort eingeben
$mysql_db = "database";  # den namen euren mysql datenbank eintragen
?>
