<?

require_once("secrets.php");
require_once("cleanup.php");


$max_torrent_size = 1000000;
$announce_interval = 1800;
$signup_timeout = 86400 * 3;
$minvotes = 1;
$max_dead_torrent_time = 6 * 3600;

$torrent_dir = "torrents/";	# mit chmod auf 777 setzen

# nur die erste Announce Url wird im Tracker angezeigt
$announce_urls = array();
$announce_urls[] = "http://www.eureurl.de/tracker/announce.php";  # Achtung hier solltet ihr eure Url eintragen


$autoclean_interval = 600;
//$pic_base_url = "http://static.bytemonsoon.com:56134/";
$pic_base_url = "pic/";





function dbconn($autoclean = 1) {
	global $mysql_host, $mysql_user, $mysql_pass, $mysql_db;

	@mysql_pconnect($mysql_host, $mysql_user, $mysql_pass)
		or die(mysql_error());
	mysql_select_db($mysql_db)
		or die(mysql_error());

	userlogin();

	if ($autoclean)
		register_shutdown_function("autoclean");
}

function userlogin() {
	unset($GLOBALS["CURUSER"]);
	if (empty($_COOKIE["uid"]) || empty($_COOKIE["pass"]))
		return;
	$id = 0 + $_COOKIE["uid"];
	if (!$id || strlen($_COOKIE["pass"]) != 32)
		return;
	$res = mysql_query("SELECT admin, email, id, username, password, secret, status, privacy FROM users WHERE id = $id AND status = 'confirmed'");
	$row = mysql_fetch_array($res);
	if (!$row)
		return;
	$sec = hash_pad($row["secret"]);
	if ($_COOKIE["pass"] !== md5($sec . $row["password"] . $sec))
		return;
	$GLOBALS["CURUSER"] = $row;
	mysql_query("UPDATE users SET last_access = NOW() WHERE id = " . $row["id"]);
}

function autoclean() {
	global $autoclean_interval;

	$now = time();
	$docleanup = 0;

	$res = mysql_query("SELECT value_u FROM avps WHERE arg = 'lastcleantime'");
	$row = mysql_fetch_array($res);
	if (!$row) {
		mysql_query("INSERT INTO avps (arg, value_u) VALUES ('lastcleantime',$now)");
		return;
	}
	$ts = $row[0];
	if ($ts + $autoclean_interval > $now)
		return;
	mysql_query("UPDATE avps SET value_u=$now WHERE arg='lastcleantime' AND value_u = $ts");
	if (!mysql_affected_rows())
		return;

	docleanup();
}

function unesc($x) {
	if (get_magic_quotes_gpc())
		return stripslashes($x);
	return $x;
}

function mksize($s) {
	$x = 3;
	$a = array("","k","M","G");
	for (;;) {
		$v = pow(1024, $x);
		if (!$x || $s >= $v) {
			$ss = sprintf("%.".$x."f", ($s / $v));
			$xx = $ss . " " . $a[$x] . "B";
			break;
		}
		$x--;
	}
	return $xx;
}

function deadtime() {
	global $announce_interval;
	return time() - floor($announce_interval * 1.3);
}

function mkprettytime($s) {
	if ($s < 0)
		$s = 0;
	$t = array();
	foreach (array("60:sec","60:min","24:hour","0:day") as $x) {
		$y = explode(":", $x);
		if ($y[0] > 1) {
			$v = $s % $y[0];
			$s = floor($s / $y[0]);
		}
		else
			$v = $s;
		$t[$y[1]] = $v;
	}

	if ($t["day"])
		return $t["day"] . " day(s), " . sprintf("%02d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
	if ($t["hour"])
		return sprintf("%d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
	if ($t["min"])
		return sprintf("%d:%02d", $t["min"], $t["sec"]);
	return $t["sec"] . " secs";
}

function mkglobal($vars) {
	if (!is_array($vars))
		$vars = explode(":", $vars);
	foreach ($vars as $v) {
		if (isset($_GET[$v]))
			$GLOBALS[$v] = unesc($_GET[$v]);
		elseif (isset($_POST[$v]))
			$GLOBALS[$v] = unesc($_POST[$v]);
		else
			return 0;
	}
	return 1;
}

function tr($x,$y,$noesc=0) {
	if ($noesc)
		$a = $y;
	else {
		$a = htmlspecialchars($y);
		$a = str_replace("\n", "<br />\n", $a);
	}
	print("<tr><td class=\"heading\" valign=\"top\" align=\"left\" bgcolor=F7F7F7><font size=2><b>$x</b></td><td valign=\"top\" bgcolor=ECECEC ><font size=2>$a</td></tr>\n");
}

function validfilename($name) {
	return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
}

function validemail($email) {
	return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
}

function sqlesc($x) {
	return "'".mysql_real_escape_string($x)."'";
}

function sqlwildcardesc($x) {
	return str_replace(array("%","_"), array("\\%","\\_"), mysql_real_escape_string($x));
}

function urlparse($m) {
	$t = $m[0];
	if (preg_match(',^\w+://,', $t))
		return "<a href=\"$t\">$t</a>";
	return "<a href=\"http://$t\">$t</a>";
}

function parsedescr($d) {
	$pd = str_replace(array("\n", "\r"), array("<br />\n", ""), htmlspecialchars($d));
	$pd = preg_replace_callback('�(\w+://([^\s/:@]+(:[^\s/:@]++)?@)?|\bwww\.)[\w.-]+(:\d+)?(/[-\w=./?&%+#;|@]*)?[0-9a-z/]�is', "urlparse", $pd);
	return $pd;
}

function stdhead($title = "") {
	global $CURUSER;
	header("Content-Type: text/html; charset=iso-8859-1");
	//header("Pragma: No-cache");
	if ($title == "")
		$title = "Bytemonsoon";
	else
		$title = "Bytemonsoon - " . htmlspecialchars($title);


$trackertitle = "";

?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">

<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Mein Tracker</title>
<style type="text/css">
A.report:link { COLOR: #FFFFFF;
                    TEXT-DECORATION: none;}
A.report:visited { COLOR: #FFFFFF;
                    TEXT-DECORATION: none;}
A.report:active { COLOR: #FFFFFF;
                     TEXT-DECORATION: none;}
A.report:hover { COLOR: #E97828;
                      TEXT-DECORATION: none;}
BODY {
	SCROLLBAR-BASE-COLOR: #CFD3D7;
	SCROLLBAR-ARROW-COLOR: #062E54;
}
SELECT {
	FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif;
	FONT-SIZE: 11px;
	COLOR: #000000;
	BACKGROUND-COLOR: #CFCFCF
}
TEXTAREA, .bginput {
	FONT-SIZE: 12px;
	FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif;
	COLOR: #000000;
	BACKGROUND-COLOR: #CFCFCF
}
.textbox {
	FONT-SIZE: 10px;
	FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif;
	COLOR: #000000;
                border-top:1px solid;
                border-bottom:1px solid;
                border-left: 1px solid;
                border-right:1px solid;
                BORDER-COLOR: #000000;
                width: 158px;
                height: 15px;
	BACKGROUND-COLOR: #F2F2F2
}
A:link, A:visited, A:active {
	COLOR: #154C89;
}
A:hover {
	COLOR: #E97828;
}
#cat A:link, #cat A:visited, #cat A:active {
	COLOR: #062E54;
	TEXT-DECORATION: none;
}
#cat A:hover {
	COLOR: #062E54;
	TEXT-DECORATION: underline;
}
#ltlink A:link, #ltlink A:visited, #ltlink A:active {
	COLOR: #154C89;
	TEXT-DECORATION: none;
}
#ltlink A:hover {
	COLOR: #E97828;
	TEXT-DECORATION: underline;
}
.thtcolor {
	COLOR: #CFD3D7;
}
</style>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
<div align="center">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="100%">
    <tr>
      <td width="989" height="88" align="center" background="header.jpg" colspan="2">

      <BR><p align=center><font size=4 color=white face=arial>   <?
echo $trackertitle;
      ?>
      </p></font>


  </tr>
    <tr>
      <td width="25" height="27" background="cell2.gif">&nbsp;</td>
      <td width="964" height="27" background="cell2.gif">
<font face=arial size=2>

&nbsp;&nbsp;<a href="./">Index</a>&nbsp;&nbsp;
<a href="upload.php">Upload</a>&nbsp;&nbsp;
<? if (!$CURUSER) { ?>
<a href="login.php">Login</a> / <a href="signup.php">Signup</a>&nbsp;&nbsp;
<? } else { ?>
<a href="my.php"> <?= htmlspecialchars($CURUSER["username"]) ?>'s Privatbereich</a>&nbsp;&nbsp;
<? } ?>

<a href="http://www.stahlmantel.net/bitguide/">Forum</a>&nbsp;&nbsp;


 </tr>
    <tr>
      <td width="100%" height="22" background="cell3.gif" align="right" colspan="2">
      <p align="right">
      </td>
    </tr>
    <tr>
      <td width="100%" height="650" colspan="2">



<font face=arial size=2>


<?
}

function stdfoot() {
	//include('tracking');
	print('</td></tr><tr><td width="100%" height="21" background="cell4.gif" colspan="2"><font face=arial size=1>Source code developed by dfx. Install script and modification by woolly. Translated into german by datafat</td></tr></table></div></body></html>');
}

function genbark($x,$y) {
	stdhead($y);
	print("<h2>" . htmlspecialchars($y) . "</h2>\n");
	print("<p>" . htmlspecialchars($x) . "</p>\n");
	stdfoot();
	exit();
}

function mksecret($len = 20) {
	$ret = "";
	for ($i = 0; $i < $len; $i++)
		$ret .= chr(mt_rand(0, 255));
	return $ret;
}

function httperr($code = 404) {
	header("HTTP/1.0 404 Not found");
	print("<h1>Nicht gefunden</h1>\n");
	print("<p>Sorry Kumpel :(</p>\n");
	exit();
}

function logincookie($id, $password, $secret, $updatedb = 1) {
	$md5 = md5($secret . $password . $secret);

	setcookie("uid", $id, 0x7fffffff, "/");
	setcookie("pass", $md5, 0x7fffffff, "/");

	if ($updatedb)
		mysql_query("UPDATE users SET last_login = NOW() WHERE id = $id");
}

function logoutcookie() {
	setcookie("uid", "", 0x7fffffff, "/");
	setcookie("pass", "", 0x7fffffff, "/");
}

function loggedinorreturn() {
	global $CURUSER;
	if (!$CURUSER) {
		header("Refresh: 0; url=login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		exit();
	}
}

function deletetorrent($id) {
	global $torrent_dir;
	mysql_query("DELETE FROM torrents WHERE id = $id");
	foreach(explode(".","peers.files.comments.ratings") as $x)
		mysql_query("DELETE FROM $x WHERE torrent = $id");
	unlink("$torrent_dir/$id.torrent");
}

function pager($rpp, $count, $href, $opts = array()) {
	$pages = ceil($count / $rpp);

	if (!$opts["lastpagedefault"])
		$pagedefault = 0;
	else {
		$pagedefault = floor(($count - 1) / $rpp);
		if ($pagedefault < 0)
			$pagedefault = 0;
	}

	if (isset($_GET["page"])) {
		$page = 0 + $_GET["page"];
		if ($page < 0)
			$page = $pagedefault;
	}
	else
		$page = $pagedefault;

	$pager = "";

	$mp = $pages - 1;
	$as = "<b>&lt;&lt;&nbsp;Prev</b>";
	if ($page >= 1) {
		$pager .= "<a href=\"{$href}page=" . ($page - 1) . "\">";
		$pager .= $as;
		$pager .= "</a>";
	}
	else
		$pager .= $as;
	$pager .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	$as = "<b>Next&nbsp;&gt;&gt;</b>";
	if ($page < $mp && $mp >= 0) {
		$pager .= "<a href=\"{$href}page=" . ($page + 1) . "\">";
		$pager .= $as;
		$pager .= "</a>";
	}
	else
		$pager .= $as;

	if ($count) {
		$pagerarr = array();
		$dotted = 0;
		$dotspace = 3;
		$dotend = $pages - $dotspace;
		$curdotend = $page - $dotspace;
		$curdotstart = $page + $dotspace;
		for ($i = 0; $i < $pages; $i++) {
			if (($i >= $dotspace && $i <= $curdotend) || ($i >= $curdotstart && $i < $dotend)) {
				if (!$dotted)
					$pagerarr[] = "...";
				$dotted = 1;
				continue;
			}
			$dotted = 0;
			$start = $i * $rpp + 1;
			$end = $start + $rpp - 1;
			if ($end > $count)
				$end = $count;
			$text = "$start&nbsp;-&nbsp;$end";
			if ($i != $page)
				$pagerarr[] = "<a href=\"{$href}page=$i\">$text</a>";
			else
				$pagerarr[] = "<b>$text</b>";
		}
		$pagerstr = join(" | ", $pagerarr);
		$pagertop = "<p align=\"center\">$pager<br />$pagerstr</p>\n";
		$pagerbottom = "<p align=\"center\">$pagerstr<br />$pager</p>\n";
	}
	else {
		$pagertop = "<p align=\"center\">$pager</p>\n";
		$pagerbottom = $pagertop;
	}

	$start = $page * $rpp;

	return array($pagertop, $pagerbottom, "LIMIT $start,$rpp");
}

function downloaderdata($res) {
	$rows = array();
	$ids = array();
	$peerdata = array();
	while ($row = mysql_fetch_assoc($res)) {
		$rows[] = $row;
		$id = $row["id"];
		$ids[] = $id;
		$peerdata[$id] = array(downloaders => 0, seeders => 0, comments => 0);
	}

	if (count($ids)) {
		$allids = implode(",", $ids);
		$res = mysql_query("SELECT COUNT(*) AS c, torrent, seeder FROM peers WHERE torrent IN ($allids) GROUP BY torrent, seeder");
		while ($row = mysql_fetch_assoc($res)) {
			if ($row["seeder"] == "yes")
				$key = "seeders";
			else
				$key = "downloaders";
			$peerdata[$row["torrent"]][$key] = $row["c"];
		}
		$res = mysql_query("SELECT COUNT(*) AS c, torrent FROM comments WHERE torrent IN ($allids) GROUP BY torrent");
		while ($row = mysql_fetch_assoc($res)) {
			$peerdata[$row["torrent"]]["comments"] = $row["c"];
		}
	}

	return array($rows, $peerdata);
}

function commenttable($rows) {
	print("<table border=\"1\" align=\"center\" cellpadding=\"15\">\n");
	$count = 0;
	foreach ($rows as $row) {
		print("<tr>\n");
		if (isset($row["username"]))
			print("<td class=\"heading\"><a name=\"comm" . $row["id"] . "\">" . htmlspecialchars($row["username"]) . "</a></td>\n");
		else
			print("<td><a name=\"comm" . $row["id"] . "\"><i>(orphaned)</i></a></td>\n");
		print("<td align=\"right\" class=\"heading\">" . htmlspecialchars($row["added"]) . "</td>\n");
		print("</tr>\n");
		print("<tr>\n");
		print("<td colspan=\"2\">" . $row["text"] . "</td>\n");
		print("</tr>\n");
		$count++;
	}
	print("</table>");
}

function searchfield($s) {
	return preg_replace(array('/[^a-z0-9]/si', '/^\s*/s', '/\s*$/s', '/\s+/s'), array(" ", "", "", " "), $s);
}

function genrelist() {
	$ret = array();
	$res = mysql_query("SELECT id, name FROM categories ORDER BY sort_index, id");
	while ($row = mysql_fetch_array($res))
		$ret[] = $row;
	return $ret;
}

function linkcolor($num) {
	if (!$num)
		return "red";
	if ($num == 1)
		return "yellow";
	return "green";
}

function ratingpic($num) {
	global $pic_base_url;
	$r = round($num * 2) / 2;
	if ($r < 1 || $r > 5)
		return;
	return "<img src=\"$pic_base_url$r.gif\" border=\"0\" alt=\"rating: $num / 5\" />";
}

function torrenttable($res, $variant = "index") {
	global $pic_base_url;
?>
<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#646262" width="95%" border="1" >
<td>
<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#D6D9DB" width="100%" border="1" >
<tr>

<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Typ</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Name</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>&nbsp;</td>
<?

	if ($variant == "mytorrents")
		print("<td class=\"heading\" align=\"center\">Visible</td>\n");

?>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Files</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Kom.</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Bewertung</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Hinzugef�gt am</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Gr��e</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Views</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Hits</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Snatched</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Seeders</td>
<td background="cell5.gif" bgcolor=005FB4 align=center><font size=2 color=white face=arial>Leechers</td>
<td background=cell5.gif bgcolor=005FB4 align=center><font size=2 color=white face=arial>Hochgeladen von</td>

<?

	//if ($variant == "index")
		//print("Upped by</td>\n");

	print("</tr>\n");

	while ($row = mysql_fetch_assoc($res)) {
		$id = $row["id"];
		print("<tr>\n");

		print("<td bgcolor=ECECEC align=center>");
		if (isset($row["cat_name"])) {
			print("<a href=\"./?cat=" . $row["category"] . "\">");
			if (isset($row["cat_pic"]) && $row["cat_pic"] != "")
				print("<img border=\"0\" src=\"$pic_base_url" . $row["cat_pic"] . "\" alt=\"" . $row["cat_name"] . "\" />");
			else
				print($row["cat_name"]);
			print("</a>");
		}
		else
			print("-");
		print("</td>\n");

		$dispname = "<b>" . htmlspecialchars($row["name"]) . "</b>";
		print("<td bgcolor=F7F7F7 align=center><font size=2><a href=\"details.php?");
		if ($variant == "mytorrents")
			print("returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;");
		print("id=$id");
		if ($variant == "index")
			print("&amp;hit=1");
		print("\">$dispname</a></td>\n");

		if ($variant == "index")
			print("<td bgcolor=ECECEC align=center><a href=\"download.php?id=$id&file=" . rawurlencode($row["filename"]) . "\"><img src=dl.gif border=0></a></td>\n");
		elseif ($variant == "mytorrents")
			print("<td bgcolor=ECECEC align=center><a href=\"edit.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;id=" . $row["id"] . "\">edit</a></td>\n");

		if ($variant == "mytorrents") {
			print("<td bgcolor=F7F7F7 align=center>");
			if ($row["visible"] == "no")
				print("<b>no</b>");
			else
				print("yes");
			print("</td>\n");
		}

		if ($row["type"] == "single")
			print("<td bgcolor=ECECEC align=center><font size=2 face=arial>" . $row["numfiles"] . "</td>\n");
		else {
			if ($variant == "index")
				print("<td bgcolor=ECECEC align=center><b><font size=2 face=arial><a href=\"details.php?id=$id&amp;hit=1&amp;filelist=1\">" . $row["numfiles"] . "</a></b></td>\n");
			else
				print("<td bgcolor=ECECEC align=center><b><font size=2 face=arial><a href=\"details.php?id=$id&amp;filelist=1#filelist\">" . $row["numfiles"] . "</a></b></td>\n");
		}

		if (!$row["comments"])
			print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial>" . $row["comments"] . "</td>\n");
		else {
			if ($variant == "index")
				print("<td bgcolor=F7F7F7 align=center><b><font size=2 face=arial><a href=\"details.php?id=$id&amp;hit=1&amp;tocomm=1\">" . $row["comments"] . "</a></b></td>\n");
			else
				print("<td bgcolor=F7F7F7 align=center><b><font size=2 face=arial><a href=\"details.php?id=$id&amp;page=0#startcomments\">" . $row["comments"] . "</a></b></td>\n");
		}

		print("<td bgcolor=ECECEC align=center>");
		if (!isset($row["rating"]))
			print("---");
		else {
			$rating = round($row["rating"] * 2) / 2;
			$rating = ratingpic($row["rating"]);
			if (!isset($rating))
				print("---");
			else
				print($rating);
		}
		print("</td>\n");

		print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial>" . str_replace(" ", "<br />", $row["added"]) . "</td>\n");
		print("<td bgcolor=ECECEC align=center><font size=2 face=arial>" . mksize($row["size"]) . "</td>\n");
		print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial>" . $row["views"] . "</td>\n");
		print("<td bgcolor=ECECEC align=center><font size=2 face=arial>" . $row["hits"] . "</td>\n");
		print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial>" . $row["times_completed"] . " time(s)</td>\n");

		if ($row["seeders"]) {
			if ($variant == "index")
				print("<td bgcolor=ECECEC align=center><b><font size=2 face=arial><a class=\"" . linkcolor($row["seeders"]) . "\" href=\"details.php?id=$id&amp;hit=1&amp;toseeders=1\">" . $row["seeders"] . "</a></b></td>\n");
			else
				print("<td bgcolor=ECECEC align=center><b><font size=2 face=arial><a class=\"" . linkcolor($row["seeders"]) . "\" href=\"details.php?id=$id&amp;dllist=1#seeders\">" . $row["seeders"] . "</a></b></td>\n");
		}
		else
			print("<td bgcolor=ECECEC align=center><font size=2 face=arial><span class=\"" . linkcolor($row["seeders"]) . "\">" . $row["seeders"] . "</span></td>\n");

		if ($row["leechers"]) {
			if ($variant == "index")
				print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial><b><a class=\"" . linkcolor($row["leechers"]) . "\" href=\"details.php?id=$id&amp;hit=1&amp;todlers=1\">" . $row["leechers"] . "</a></b></td>\n");
			else
				print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial><b><a class=\"" . linkcolor($row["leechers"]) . "\" href=\"details.php?id=$id&amp;dllist=1#leechers\">" . $row["leechers"] . "</a></b></td>\n");
		}
		else
			print("<td bgcolor=F7F7F7 align=center><font size=2 face=arial><span class=\"" . linkcolor($row["leechers"]) . "\">" . $row["leechers"] . "</span></td>\n");

		if ($variant == "index")
			print("<td bgcolor=ECECEC align=center><font size=2 face=arial>" . (isset($row["username"]) ? htmlspecialchars($row["username"]) : "<i>(unknown)</i>") . "</td>\n");

		print("</tr>\n");
	}

	print("</table></td></table>\n");

	return $rows;
}

function hit_start() {
	return;
	global $RUNTIME_START, $RUNTIME_TIMES;
	$RUNTIME_TIMES = posix_times();
	$RUNTIME_START = gettimeofday();
}

function hit_count() {
	return;
	global $RUNTIME_CLAUSE;
	if (preg_match(',([^/]+)$,', $_SERVER["SCRIPT_NAME"], $matches))
		$path = $matches[1];
	else
		$path= "(unknown)";
	$period = date("Y-m-d H") . ":00:00";
	$RUNTIME_CLAUSE = "page = " . sqlesc($path) . " AND period = '$period'";
	$update = "UPDATE hits SET count = count + 1 WHERE $RUNTIME_CLAUSE";
	mysql_query($update);
	if (mysql_affected_rows())
		return;
	$ret = mysql_query("INSERT INTO hits (page, period, count) VALUES (" . sqlesc($path) . ", '$period', 1)");
	if (!$ret)
		mysql_query($update);
}

function hit_end() {
	return;
	global $RUNTIME_START, $RUNTIME_CLAUSE, $RUNTIME_TIMES;
	if (empty($RUNTIME_CLAUSE))
		return;
	$now = gettimeofday();
	$runtime = ($now["sec"] - $RUNTIME_START["sec"]) + ($now["usec"] - $RUNTIME_START["usec"]) / 1000000;
	$ts = posix_times();
	$sys = ($ts["stime"] - $RUNTIME_TIMES["stime"]) / 100;
	$user = ($ts["utime"] - $RUNTIME_TIMES["utime"]) / 100;
	mysql_query("UPDATE hits SET runs = runs + 1, runtime = runtime + $runtime, user_cpu = user_cpu + $user, sys_cpu = sys_cpu + $sys WHERE $RUNTIME_CLAUSE");
}

function hash_pad($hash) {
	return str_pad($hash, 20);
}

function hash_where($name, $hash) {
	$shhash = preg_replace('/ *$/s', "", $hash);
	return "($name = " . sqlesc($hash) . " OR $name = " . sqlesc($shhash) . ")";
}

?>
