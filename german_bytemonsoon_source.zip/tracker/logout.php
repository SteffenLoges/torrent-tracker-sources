<?

require_once("include/bittorrent.php");

logoutcookie();

header("Refresh: 0; url=./");

?>
