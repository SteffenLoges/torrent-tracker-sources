<?

require_once("include/bittorrent.php");

hit_start();

function bark($msg) {
	genbark($msg, "Bearbeitung fehlgeschlagen!");
}

dbconn();

hit_count();

loggedinorreturn();

if (!mkglobal("email:chpassword:passagain"))
	bark("");

$set = array();

$updateset = array();
$changedemail = $newsecret = 0;

if ($chpassword != "") {
	if (strlen($chpassword) > 40)
		bark("Sorry, Passwort ist zu lang (maximal 40 Zeichen)");
	if ($chpassword != $passagain)
		bark("Die Passw�rter passten nicht �berein. Versuch es nochmal.");
	$updateset[] = "password = " . sqlesc($chpassword);
	$newsecret = 1;
}

if ($email != $CURUSER["email"]) {
	if (!validemail($email))
		bark("Das sieht mir aber nicht nach einer g�ltigen Email Addresse aus.");
	$changedemail = 1;
}

/*
if ($privacy != "normal" && $privacy != "low" && $privacy != "strong")
	bark("whoops");

$updateset[] = "privacy = '$privacy'";
*/

/* ****** */

$urladd = "";

if ($newsecret) {
	$sec = mksecret();
	$updateset[] = "secret = " . sqlesc($sec);
	logincookie($CURUSER["id"], $chpassword, $sec);
}

if ($changedemail) {
	$sec = mksecret();
	$hash = md5($sec . $email . $sec);
	$obemail = urlencode($email);
	$updateset[] = "editsecret = " . sqlesc($sec);
	$thishost = $_SERVER["HTTP_HOST"];
	$thisdomain = preg_replace('/^www\./is', "", $thishost);
	$body = <<<EOD
Du hast verlangt das in deinem Profil (username {$CURUSER["username"]})
auf $thisdomain nun diese neue  Email Addresse  ($email) als Kontakt
benutzt werden soll.

Willst du das nicht, ignoriere diese Email. Die Person die das verlangt
hat, hatte deine IP Addresse {$_SERVER["REMOTE_ADDR"]}. Bitte nicht anworten.

Wenn du dein Profil doch �ndern willst, klicke hier auf diesen Link:

http://$thishost/confirmemail.php/{$CURUSER["id"]}/$hash/$obemail

Deine neue Email Addresse wird in dein Profil eingef�gt solbald du dies getan hast.
Andererseits bleibt dein Profil unge�ndert.


liebe Gr��e,

EOD;

	mail($email, "$thisdomain profile change confirmation", $body, "From: $thisdomain site robot <noreply@$thisdomain>");

	$urladd .= "&mailsent=1";
}

mysql_query("UPDATE users SET " . implode(",", $updateset) . " WHERE id = " . $CURUSER["id"]);

header("Refresh: 0; url=my.php?edited=1" . $urladd);

hit_end();

?>
