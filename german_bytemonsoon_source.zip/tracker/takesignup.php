<?

require_once("include/bittorrent.php");

hit_start();

if (!mkglobal("wantusername:wantpassword:passagain:email:emailagain"))
	die();

function bark($msg) {
	genbark($msg, "Anmeldung fehlgeschlagen!");
}

if (empty($wantusername) || empty($wantpassword) || empty($email))
	bark("Lasse kein Feld lehr.");

if ($wantpassword != $passagain)
	bark("Passwort passt nicht �berein. Versuch es nochmal");

if (strtolower($email) != strtolower($emailagain))
	bark("Email passt nicht �berein! Versuch es nochmal");

if (strlen($wantpassword) > 40)
	bark("Sorry, das Passwort ist zu lang (maximal 40 Zeichen)");

if (!validemail($email))
	bark("Das sieht mir nicht nach einer g�ltigen Email Addresse aus.");

if (!preg_match('/^[a-z][\w.-]*$/is', $wantusername) || strlen($wantusername) > 40)
	bark("ung�ltiger Username.");

dbconn();

hit_count();

$secret = mksecret();

$ret = mysql_query("INSERT INTO users (username, password, secret, email, status, added) VALUES (" .
		implode(",", array_map("sqlesc", array($wantusername, $wantpassword, $secret, $email, 'confirmed'))) .
		", NOW())");

if (!$ret) {
	if (mysql_errno() == 1062)
		bark("Username already exists!");
	bark("borked");
}

$id = mysql_insert_id();
$psecret = md5($secret);
$thishost = $_SERVER["HTTP_HOST"];
$thisdomain = preg_replace('/^www\./is', "", $thishost);

$body = <<<EOD
Du hast dich angemeldet bei $thisdomain und du hast diese Email
Addresse ($email) f�r den User Kontakt angegeben.

Wenn du dieses nicht getan hast, ignoriere diese Email. Die Person die dieses
getan hat, hatte deine IP {$_SERVER["REMOTE_ADDR"]}. Bitte nicht antworten.

Um diese Email zu best�tigen, klicke bitte nun auf diesen Link:

http://$thishost/confirm.php/$id/$psecret

Nachdem du dies getan hast, wird dein Account aktiviert. Wenn du es nicht machst,
Wird dein Account in einigen Tagen gel�scht.

liebe Gr��e,

EOD;

//mail($email, "$thisdomain user registration confirmation", $body, "From: $thisdomain site robot <noreply@$thisdomain>");

header("Refresh: 0; url=ok.php?type=signup&email=" . urlencode($email));

hit_end();

?>
