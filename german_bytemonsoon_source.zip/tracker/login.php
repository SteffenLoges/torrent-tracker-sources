<?

require_once("include/bittorrent.php");

hit_start();

dbconn();

hit_count();

stdhead("Login");

unset($returnto);
if (!empty($_GET["returnto"])) {
	$returnto = $_GET["returnto"];
	if (!$_GET["nowarn"]) {
		print("<h1>Nicht eingeloggt!</h1>\n");
		print("<p><b>Error:</b> Die Seite die du besuchen wolltest kann nicht angezeigt werden, wenn du nicht eingeloggt bist.</p>\n");
	}
}

?>

<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#646262" width="50%" border="1" >
<td>
<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#D6D9DB" width="100%" border="1" >
<tr>

<td background="cell5.gif" bgcolor=005FB4 align=left><font size=3 color=white face=arial>Bitte Login      <font size=1>(Du musst Cookies akzeptieren um dich anzumelden.)</td>
</tr>
<form method="post" action="takelogin.php">
<tr><td align="center" class="heading" bgcolor=ECECEC><font size=2><BR>Username:<input type="text" size="40" name="username" /><BR><BR></td></tr>
<tr><td align="center" class="heading" bgcolor=F7F7F7><font size=2><BR>Password:<input type="password" size="40" name="password" /><BR><BR></td></tr>
<tr><td colspan="2" align="center" bgcolor=ECECEC><BR><input type="submit" value="Log in!" style="font-family: v; font-size: 8pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 3; padding-right: 3; padding-top: 1; padding-bottom: 1"/><BR><BR> </td></tr>
</table></table>
<?

if (isset($returnto))
	print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($returnto) . "\" />\n");

?>
</form>
<BR><font size=2><center><b>Du hast noch keinen Account?</b> <a href="signup.php">Meld dich an</a> gleich jetzt!</center>
<?

stdfoot();

hit_end();

?>
