
<title>Bytemonsoon v2.0 tracker RC1 Setup</title>

<font face=arial size=2>
<?
if(isset($step)){
if($step == "info"){
phpinfo();


}else{

if($step == "2"){


$SQL_SERVER = $_POST[ "hostname" ];
$SQL_USER = $_POST[ "username" ];
$SQL_PASS = $_POST[ "password" ];
$SQL_DB = $_POST[ "dbname" ];

if( ( $db = mysql_connect( $SQL_SERVER , $SQL_USER , $SQL_PASS ) ) && mysql_select_db( $SQL_DB , $db ) )
{

echo'Die Verbindung zu deinem Mysql Server wurde hergestellt. Nun dr�cke weiter um in der Installation fortzufahren.';

?>

<form enctype="multipart/form-data" action="install.php?step=3" method="post">
<?
echo'<input type="hidden" value="'.$SQL_SERVER.'" name="hostname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_USER.'" name="username" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_PASS.'" name="password" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_DB.'" name="dbname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
?>
<BR><BR>

<input type="submit" value="Weiter" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1"><BR></form>


<?



}else{

echo'Verbindung fehlgeschlagen, bitte versuche es nochmal.';


}

}
}














}else{
echo'<font size=2 face=arial>';
echo'Willkommen bei der Installation des Bytemonsoon v2.0 Tracker RC1. Nun wird gleich dein Tracker aufgesetzt und in k�rze online sein. Du ben�tigst PHP Version 4.3.x oder h�her damit dieses Script hier funktioniert. Klicke <a href="install.php?step=info">hier</a> um herauszufinden, welche Version du hast.';
?>
<form enctype="multipart/form-data" action="install.php?step=2" method="post">
<BR>MYSQL Datenbank Hostname(IP oder Domainnamen des Servers, geb einfach localhost ein, wenn du es nicht so genau weisst.): <BR><input type="text" name="hostname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">
<BR>MYSQL User Name: <BR><input type="text" name="username" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">
<BR>MYSQL Passwort: <BR><input type="password" name="password" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">
<BR>MYSQL Datenbank Name: <BR><input type="text" name="dbname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">

<BR><BR>

<input type="submit" value="Weiter" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1"><BR></form>
<?

}




if($step == "3"){

$SQL_SERVER = $_POST[ "hostname" ];
$SQL_USER = $_POST[ "username" ];
$SQL_PASS = $_POST[ "password" ];
$SQL_DB = $_POST[ "dbname" ];



$filehandle = fopen("include/secrets.php","r+");

$stuff = '<?'
	."\n"
	.'$mysql_host = "'.$SQL_SERVER.'";'
	."\n"	
	.'$mysql_user = "'.$SQL_USER.'";'
	."\n"
	.'$mysql_pass = "'.$SQLPASS.'";'
	."\n"
	.'$mysql_db = "'.$SQL_DB.'";'
	."\n"
	.'?>'

."";


fwrite($filehandle,$stuff);



fclose($filehandle);


echo 'Konfigurationsfile wurde geschrieben, Weiter wird die Datenbank aufgesetzt.';




?>

<form enctype="multipart/form-data" action="install.php?step=4" method="post">
<?
echo'<input type="hidden" value="'.$SQL_SERVER.'" name="hostname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_USER.'" name="username" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_PASS.'" name="password" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_DB.'" name="dbname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
?>
<BR><BR>

<input type="submit" value="Weiter" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1"><BR></form>


<?







}

if($step == "4"){

$SQL_SERVER = $_POST[ "hostname" ];
$SQL_USER = $_POST[ "username" ];
$SQL_PASS = $_POST[ "password" ];
$SQL_DB = $_POST[ "dbname" ];


if( ( $db = mysql_connect( $SQL_SERVER , $SQL_USER , $SQL_PASS ) ) && mysql_select_db( $SQL_DB , $db ) )
{



if(mysql_query("CREATE TABLE avps (  arg varchar(20) NOT NULL default '',  value_i int(11) NOT NULL default '0',  value_u int(10) unsigned NOT NULL default '0',  PRIMARY KEY  (arg)) TYPE=HEAP")){



echo 'Tabelle aufgesetzt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}


if(mysql_query("CREATE TABLE categories (  id int(10) unsigned NOT NULL auto_increment,  name varchar(30) NOT NULL default '',  sort_index int(10) unsigned NOT NULL default '0',  image varchar(255) NOT NULL default '',  PRIMARY KEY  (id)) TYPE=MyISAM")){



echo 'Tabelle categories angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}


if(mysql_query("CREATE TABLE comments (  id int(10) unsigned NOT NULL auto_increment,  user int(10) unsigned NOT NULL default '0',  torrent int(10) unsigned NOT NULL default '0',  added datetime NOT NULL default '0000-00-00 00:00:00',  text text NOT NULL,  ori_text text NOT NULL,  PRIMARY KEY  (id),  KEY user (user),  KEY torrent (torrent)) TYPE=MyISAM")){


echo 'Tabelle comments angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}



if(mysql_query("CREATE TABLE files (  id int(10) unsigned NOT NULL auto_increment,  torrent int(10) unsigned NOT NULL default '0',  filename varchar(255) NOT NULL default '',  size bigint(20) unsigned NOT NULL default '0',  PRIMARY KEY  (id),  KEY torrent (torrent)) TYPE=MyISAM")){


echo 'Tabelle files angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}



if(mysql_query("CREATE TABLE hits (  id int(10) unsigned NOT NULL auto_increment,  page varchar(20) NOT NULL default '',  period datetime NOT NULL default '0000-00-00 00:00:00',  count bigint(20) unsigned NOT NULL default '0',  runs bigint(20) unsigned NOT NULL default '0',  runtime double NOT NULL default '0',  user_cpu double NOT NULL default '0',  sys_cpu double NOT NULL default '0',  PRIMARY KEY  (id),  UNIQUE KEY hit (period,page)) TYPE=MyISAM")){


echo 'Tabelle hits angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup nocheinmal.';
}


if(mysql_query("CREATE TABLE peers (  torrent int(10) unsigned NOT NULL default '0',  peer_id char(20) binary NOT NULL default '',  ip char(15) NOT NULL default '',  port smallint(5) unsigned NOT NULL default '0',  uploaded bigint(20) unsigned NOT NULL default '0',  downloaded bigint(20) unsigned NOT NULL default '0',  to_go bigint(20) unsigned NOT NULL default '0',  seeder enum('yes','no') NOT NULL default 'no',  started datetime NOT NULL default '0000-00-00 00:00:00',  last_action datetime NOT NULL default '0000-00-00 00:00:00',  connectable enum('yes','no') NOT NULL default 'yes',  PRIMARY KEY  (torrent,peer_id),  KEY torrent (torrent)) TYPE=HEAP")){


echo 'Tabelle peers angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}


if(mysql_query("CREATE TABLE ratings (  torrent int(10) unsigned NOT NULL default '0',  user int(10) unsigned NOT NULL default '0',  rating tinyint(3) unsigned NOT NULL default '0',  added datetime NOT NULL default '0000-00-00 00:00:00',  PRIMARY KEY  (torrent,user),  KEY user (user)) TYPE=MyISAM")){


echo 'Tabelle ratings angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("CREATE TABLE torrents (  id int(10) unsigned NOT NULL auto_increment,  info_hash varchar(20) binary NOT NULL default '',  name varchar(255) NOT NULL default '',  filename varchar(255) NOT NULL default '',  save_as varchar(255) NOT NULL default '',  search_text text NOT NULL,  descr text NOT NULL,  ori_descr text NOT NULL,"
  ."category int(10) unsigned NOT NULL default '0',  size bigint(20) unsigned NOT NULL default '0',  added datetime NOT NULL default '0000-00-00 00:00:00',  type enum('single','multi') NOT NULL default 'single',  numfiles int(10) unsigned NOT NULL default '0',  views int(10) unsigned NOT NULL default '0',  hits int(10) unsigned NOT NULL default '0',  times_completed int(10) unsigned NOT NULL default '0',  last_action datetime NOT NULL default '0000-00-00 00:00:00',"
  ."visible enum('yes','no') NOT NULL default 'yes',  owner int(10) unsigned NOT NULL default '0',  numratings int(10) unsigned NOT NULL default '0',  ratingsum int(10) unsigned NOT NULL default '0',  seeders int(10) unsigned NOT NULL default '0',  leechers int(10) unsigned NOT NULL default '0',  comments int(10) unsigned NOT NULL default '0',  banned enum('yes','no') NOT NULL default 'no',  PRIMARY KEY  (id),  UNIQUE KEY info_hash (info_hash),  KEY owner (owner),  KEY visible (visible),  KEY category_visible (category,visible),  FULLTEXT KEY ft_search (search_text,ori_descr)) TYPE=MyISAM")){


echo 'Tabelle torrents angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("CREATE TABLE users (  id int(10) unsigned NOT NULL auto_increment,  username varchar(40) NOT NULL default '',  password varchar(40) NOT NULL default '',  secret varchar(20) binary NOT NULL default '',  email varchar(80) NOT NULL default '',  status enum('pending','confirmed') NOT NULL default 'pending',  added datetime NOT NULL default '0000-00-00 00:00:00',  last_login datetime NOT NULL default '0000-00-00 00:00:00',  last_access datetime NOT NULL default '0000-00-00 00:00:00',  admin enum('yes','no') NOT NULL default 'no',  editsecret varchar(20) binary NOT NULL default '',  privacy enum('strong','normal','low') NOT NULL default 'normal',  descr text NOT NULL,  PRIMARY KEY  (id),  UNIQUE KEY username (username),  KEY status_added (status,added)) TYPE=MyISAM")){


echo 'Tabelle users angelegt';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}






}else{

echo'B�hser Fehler aufgetreten, versuche das Setup noch einmal auszuf�hren.';
}










?>

<form enctype="multipart/form-data" action="install.php?step=5" method="post">
<?
echo'<input type="hidden" value="'.$SQL_SERVER.'" name="hostname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_USER.'" name="username" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_PASS.'" name="password" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_DB.'" name="dbname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<BR><BR>Please Enter Your Desired Admin Username:<BR><input type="text" name="adminuser" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<BR><BR>Please Enter Your Desired Admin password:<BR><input type="text" name="adminpass" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';


?>
<BR><BR>

<input type="submit" value="Weiter" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1"><BR></form>


<?







}









if($step == "5"){

require_once("include/bittorrent.php");

$SQL_SERVER = $_POST[ "hostname" ];
$SQL_USER = $_POST[ "username" ];
$SQL_PASS = $_POST[ "password" ];
$SQL_DB = $_POST[ "dbname" ];
$wantusername = $_POST[ "adminuser" ];
$wantpassword = $_POST[ "adminpass" ];
$secret = mksecret();
$thishost = $_SERVER["HTTP_HOST"];
$email = 'admin@'.$thishost;

if( ( $db = mysql_connect( $SQL_SERVER , $SQL_USER , $SQL_PASS ) ) && mysql_select_db( $SQL_DB , $db ) )
{


if(mysql_query("INSERT INTO categories VALUES (1,'Movies',10,'film.jpg')")){


echo 'Daten werden nun in die Kategorien geschreiben';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}




if(mysql_query("INSERT INTO categories VALUES (2,'Music',20,'music.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (3,'TV',30,'tv3.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren';
}







if(mysql_query("INSERT INTO categories VALUES (4,'Games',40,'games.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (5,'Applications',50,'apps.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (6,'Miscellaneous',1000,'misc.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (7,'Pr0n',70,'pr0n.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (8,'Pictures',80,'pics.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (9,'Anime',90,'anime.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (10,'Comics',100,'comics.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (11,'Books',110,'books2.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}

if(mysql_query("INSERT INTO categories VALUES (13,'Music Videos',25,'mvid6.jpg')")){


echo 'Daten wurden erfolgreich in die Kategorien geschrieben<BR>';
echo'<BR>';
}else{

echo'Error, L�sche alle Tabellen und versuche das Setup noch einmal auszuf�hren.';
}









if(mysql_query("INSERT INTO users (username, password, secret, email, status, added) VALUES (" .
		implode(",", array_map("sqlesc", array($wantusername, $wantpassword, $secret, $email , 'confirmed'))) .
		", NOW())")){

echo '<BR>Admin Account angelegt';

echo '<BR>Gratuliere! Du hast soeben einen Tracker aufgesetzt. Bitte l�sche (oder umbenenne) die install.php aus Sicherheitsgr�nden.';
echo '<BR>Du musst jetzt nur noch in include/bittorrent.php manuell die korrenkte Announce Url eintragen. Evt m�sst ihr noch die';
echo '<BR>secret.php etwas anpassen .. sprich mysql user und pass angeben.';

}else{
echo'Error';
}





?>

<form enctype="multipart/form-data" action="index.php" method="post">
<?
echo'<input type="hidden" value="'.$SQL_SERVER.'" name="hostname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_USER.'" name="username" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_PASS.'" name="password" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
echo'<input type="hidden" value="'.$SQL_DB.'" name="dbname" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">';
?>
<BR><BR>

<input type="submit" value="Finish" style="font-family: v; font-size: 10pt; color: #5E6A7B; border: 1px solid #5E6A7B; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1"><BR></form>


<?



}else{

echo'Verbindung fehlgeschlagen, bitte versuche es nochmal.';


}











}










?>

<BR><BR><BR>Install script coded by woolly. translated into german by datafat
