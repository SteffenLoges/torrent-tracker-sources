mysqldump --no-data -uroot -p bytemonsoon_com > database.sql
mysqldump --no-create-info -uroot -p bytemonsoon_com categories >> database.sql
