<?

require_once("include/bittorrent.php");

hit_start();

function bark($msg) {
	genbark($msg, "L�schen fehlgeschlagen!");
}

if (!mkglobal("id"))
	bark("Daten werden vermisst");

$id = 0 + $id;
if (!$id)
	die();

dbconn();

hit_count();

loggedinorreturn();

$res = mysql_query("SELECT owner FROM torrents WHERE id = $id");
$row = mysql_fetch_array($res);
if (!$row)
	die();

if (!isset($CURUSER) || ($CURUSER["id"] != $row["owner"] && $CURUSER["admin"] != "yes"))
	bark("Du bist nicht der Inhaber! Was hat das zu bedeuten?\n");

if (!$_POST["sure"])
	bark("Ich kann nichts l�schen, wenn du dir nicht vollkommen sicher bist.\n");

deletetorrent($id);

stdhead("Torrent gel�scht!");

if (isset($_POST["returnto"]))
	$ret = "<a href=\"" . htmlspecialchars($_POST["returnto"]) . "\">Geh zur�ck von wo du kamst</a>";
else
	$ret = "<a href=\"./\">Zur�ck zum Index</a>";

?>
<h2>Torrent gel�scht!</h2>
<p><?= $ret ?></p>
<?

stdfoot();

hit_end();

?>
