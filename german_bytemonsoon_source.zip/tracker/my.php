<?

require_once("include/bittorrent.php");

hit_start();

dbconn();

hit_count();

loggedinorreturn();

stdhead($CURUSER["username"] . "'s privater Bereich");

if ($_GET["edited"]) {
	print("<h1>Profil ge�ndert!</h1>\n");
	if ($_GET["mailsent"])
		print("<h2>Best�tigungs Email wurde versandt!</h2>\n");
}
elseif ($_GET["emailch"])
	print("<h1>Email Addresse ge�ndert!</h1>\n");
else
	print("<h1>Wilkommen, " . htmlspecialchars($CURUSER["username"]) . "!</h1>\n");

?>
<table border="1" cellpadding="10" align="center">
<tr>
<td align="center" width="50%"><a href="logout.php" class="biglink">Logout</a></td>
<td align="center" width="50%"><a href="mytorrents.php" class="biglink">Torrents anzeigen oder bearbeiten </a></td>
</tr>
<tr>
<td colspan="2">
<form method="post" action="takeprofedit.php">
<table border="1" cellpadding="10" width="100%">
<tr><td colspan="2" class="heading" align="center">Dein Profil</td></tr>
<?

$res = mysql_query("SELECT COUNT(*) FROM torrents WHERE owner=" . $CURUSER["id"]);
$row = mysql_fetch_array($res);
tr("hochgeladene Torrents", $row[0]);

$res = mysql_query("SELECT COUNT(*) FROM ratings WHERE user=" . $CURUSER["id"]);
$row = mysql_fetch_array($res);
tr("abgegebene Bewertungen", $row[0]);

$res = mysql_query("SELECT COUNT(*) FROM comments WHERE user=" . $CURUSER["id"]);
$row = mysql_fetch_array($res);
tr("geschriebene Kommentare", $row[0]);

print("<tr><td colspan=\"2\" class=\"heading\" align=\"center\">Bearbeite deine Einstellungen</td></tr>\n");

tr("Email Addresse", "<input type=\"text\" name=\"email\" size=\"40\" value=\"" . htmlspecialchars($CURUSER["email"]) . "\" />", 1);
print("<tr><td colspan=\"2\"><b>Beachte:</b> Wenn du deine Email Addresse �nderst,<br />erh�lts du eine weitere Best�tigungs Email. Du <br /> musst diese beantworten damit deine neue <br /> Email Addresse zu deinem Profil hinzugef�gt wird. <br />Wenn du es nicht machst, bleibt deine Email Addresse <br /> unver�ndert<br /></td></tr>\n");
tr("neues Passwort", "<input type=\"password\" name=\"chpassword\" size=\"40\" />", 1);
tr("wiederholen", "<input type=\"password\" name=\"passagain\" size=\"40\" />", 1);

function priv($name, $descr) {
	global $CURUSER;
	if ($CURUSER["privacy"] == $name)
		return "<input type=\"radio\" name=\"privacy\" value=\"$name\" checked=\"checked\" /> $descr";
	return "<input type=\"radio\" name=\"privacy\" value=\"$name\" /> $descr";
}

/* tr("Privacy level",  priv("normal", "Normal") . " " . priv("low", "Low (email address will be shown)") . " " . priv("strong", "Strong (no info will be made available)"), 1); */

?>
<tr><td colspan="2" align="center"><input type="submit" value="Abschicken!" /> <input type="reset" value="R�ckg�ngig machen!" /></td></tr>
</table>
</form>
</td>
</tr>
</table>
<?

stdfoot();

hit_end();

?>
