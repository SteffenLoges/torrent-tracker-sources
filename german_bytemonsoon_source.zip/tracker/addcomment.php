<?

require_once("include/bittorrent.php");

hit_start();

if (!mkglobal("id"))
	die();

$id = 0 + $id;
if (!$id)
	die();

dbconn();

hit_count();

loggedinorreturn();

$res = mysql_query("SELECT name FROM torrents WHERE id = $id");
$torrow = mysql_fetch_array($res);
if (!$torrow)
	die();

stdhead("Kommentar abgegeben zu \"" . $torrow["name"] . "\"");

?>
<h2>Kommentar abgeben zu "<?= htmlspecialchars($torrow["name"]) ?>"</h2>
<p>
<form method="post" action="takecomment.php">
<input type="hidden" name="id" value="<?= $id ?>" />
<textarea name="main" rows="20" cols="60"></textarea>
</p>
<p><input type="submit" value="Tu es!" /></p>
</form>
<?

$res = mysql_query("SELECT comments.id, text, comments.added, username FROM comments LEFT JOIN users ON comments.user = users.id WHERE torrent = $id ORDER BY comments.id DESC LIMIT 5");

$allrows = array();
while ($row = mysql_fetch_array($res))
	$allrows[] = $row;

if (count($allrows)) {
	print("<hr />\n");
	print("<h2></h2>\n");
	commenttable($allrows);
}

stdfoot();

hit_end();

?>
