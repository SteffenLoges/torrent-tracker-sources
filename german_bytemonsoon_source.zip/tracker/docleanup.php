<?

require_once("include/bittorrent.php");

dbconn();

docleanup();

?>
