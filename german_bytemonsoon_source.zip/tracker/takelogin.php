<?

require_once("include/bittorrent.php");

hit_start();

if (!mkglobal("username:password"))
	die();

dbconn();

hit_count();

function bark() {
	genbark("Login fehlgeschlagen!", "falscher Username oder Passwort");
}

$res = mysql_query("SELECT id, password, secret FROM users WHERE username = " . sqlesc($username) . " AND status = 'confirmed'");
$row = mysql_fetch_array($res);

if (!$row)
	bark();

if ($row["password"] != $password)
	bark();

logincookie($row["id"], $row["password"], hash_pad($row["secret"], 20));

if (!empty($_POST["returnto"]))
	header("Refresh: 0; url=" . $_POST["returnto"]);
else
	header("Refresh: 0; url=my.php");

hit_end();

?>
