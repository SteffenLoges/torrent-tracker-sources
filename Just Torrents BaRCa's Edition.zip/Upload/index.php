<?
ob_start("ob_gzhandler");

require "include/bittorrent.php";

dbconn(true);
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  $choice = $_POST["choice"];
  if ($CURUSER && $choice != "" && $choice < 256 && $choice == floor($choice))
  {
    $res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
    $arr = mysql_fetch_assoc($res) or die("No poll");
    $pollid = $arr["id"];
    $userid = $CURUSER["id"];
    $res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid && userid=$userid") or sqlerr();
    $arr = mysql_fetch_assoc($res);
    if ($arr) die("Dupe vote");
    mysql_query("INSERT INTO pollanswers VALUES(0, $pollid, $userid, $choice)") or sqlerr();
    if (mysql_affected_rows() != 1)
      stderr("Error", "An error occured. Your vote has not been counted.");
    header("Location: $BASEURL/");
    die;
  }
  else
    stderr("Error", "Please select an option.");
}

$a = @mysql_fetch_assoc(@mysql_query("SELECT id,username FROM users WHERE status='confirmed' ORDER BY id DESC LIMIT 1"))/* or die(mysql_error())*/;
if ($CURUSER)
  $latestuser = "<a href=userdetails.php?id=" . $a["id"] . ">" . $a["username"] . "</a>";
else
  $latestuser = $a['username'];

$registered = number_format(get_row_count("users"));
$unverified = number_format(get_row_count("users", "WHERE status='pending'"));
$torrents = number_format(get_row_count("torrents"));
$dead = number_format(get_row_count("torrents", "WHERE visible='no'"));

$seeders = number_format(get_row_count("peers", "WHERE seeder='yes'"));
$leechers = number_format(get_row_count("peers", "WHERE seeder='no'"));
$warned_users = number_format(get_row_count("users", "WHERE warned = 'yes'"));
$disabled = number_format(get_row_count("users", "WHERE enabled = 'no'"));
$uploaders = number_format(get_row_count("users", "WHERE class = ".UC_UPLOADER));
$vip = number_format(get_row_count("users", "WHERE class = ".UC_VIP));
if ($leechers == 0)
  $ratio = 0;
else
  $ratio = round($seeders / $leechers * 100);
$peers = number_format($seeders + $leechers);
$seeders = number_format($seeders);
$leechers = number_format($leechers);

$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$result = mysql_query("SELECT SUM(last_access >= $dt) AS totalol FROM users") or sqlerr(__FILE__, __LINE__);

while ($row = mysql_fetch_array ($result))
{
$totalonline = $row["totalol"];
}

$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$res = mysql_query("SELECT id, username, class, donor, warned, parked FROM users WHERE last_access >= $dt ORDER BY username") or print(mysql_error());
while ($arr = mysql_fetch_assoc($res))

{
if ($activeusers) $activeusers .= ",\n";
switch ($arr["class"])
{
case UC_MIP:
   $arr["username"] = "<font color=#0F6CEE>" . $arr["username"] . "</font>";
   break;
case UC_SYSOP:
   $arr["username"] = "<font color=red>" . $arr["username"] . "</font>";
   break;
case UC_ADMINISTRATOR:
   $arr["username"] = "<font color=blue>" . $arr["username"] . "</font>";
   break;
case UC_MODERATOR:
   $arr["username"] = "<font color=green>" . $arr["username"] . "</font>";
   break;
case UC_UPLOADER:
   $arr["username"] = "<font color=orange>" . $arr["username"] . "</font>";
   break;
case UC_VIP:
   $arr["username"] = "<font color=#9C2FE0>" . $arr["username"] . "</font>";
   break;
case UC_POWER_USER:
   $arr["username"] = "<font color=#D21E36>" . $arr["username"] . "</font>";
   break;

}
$donator = $arr["donor"] === "yes";
if ($donator)
 $activeusers .= "<nobr>";
$warned = $arr["warned"] === "yes";
if ($warned)
 $activeusers .= "<nobr>";
$parked = $arr["parked"] === "yes";
if ($parked)
 $activeusers .= "<nobr>";
if ($CURUSER)
$activeusers .= "<a href=userdetails.php?id={$arr["id"]}><b>{$arr["username"]}</b></a>";
else
$activeusers .= "<b>{$arr["username"]}</b>";
if ($donator)
$activeusers .= "<img src={$pic_base_url}star.gif alt='Donated {$$arr["donor"]}'></nobr>";
if ($warned)
$activeusers .= "<img src={$pic_base_url}warned.gif alt='Warned {$$arr["warned"]}'></nobr>";
if ($parked)
$activeusers .= "<img src={$pic_base_url}parked.gif alt='Parked {$$arr["warned"]}'></nobr>";
}
if (!$activeusers)
$activeusers = "������ �������� ������������� �� ��������� 15 �����.";

stdhead("�������");
//echo "<font class=small>Welcome to our newest member, <b>$latestuser</b>!</font>\n";

print("<table width=100% class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>");
print("<h2>�������");
if (get_user_class() >= UC_ADMINISTRATOR)
        print(" - <font class=small>[<a class=altlink href=news.php><b>�������</b></a>]</font>");
print("</h2>\n");
$res = mysql_query("SELECT * FROM news WHERE ADDDATE(added, INTERVAL 45 DAY) > NOW() ORDER BY added DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0)
{
        print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n<ul>");
        while($array = mysql_fetch_array($res))
        {
          print("<b>���������</b>: " . gmdate("d.m.Y",strtotime($array['added'])) . "<br /><b>���������:</b> ".$array['subject']."<br /><br />" . nl2br(format_comment($array['body'])));
    if (get_user_class() >= UC_ADMINISTRATOR)
    {
            print(" <font size=\"-2\">[<a class=altlink href=news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>E</b></a>]</font>");
            print(" <font size=\"-2\">[<a class=altlink href=news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><b>D</b></a>]</font>");
    }
    print("<br /><br />");
  }
  print("</ul></td></tr></table>\n");
}

?>

<?

 if ($CURUSER)
{
  // Get current poll
  $res = mysql_query("SELECT * FROM polls ORDER BY added DESC LIMIT 1") or sqlerr();
  if($pollok=(mysql_num_rows($res)))
  {
          $arr = mysql_fetch_assoc($res);
          $pollid = $arr["id"];
          $userid = $CURUSER["id"];
          $question = $arr["question"];
          $o = array($arr["option0"], $arr["option1"], $arr["option2"], $arr["option3"], $arr["option4"],
            $arr["option5"], $arr["option6"], $arr["option7"], $arr["option8"], $arr["option9"],
            $arr["option10"], $arr["option11"], $arr["option12"], $arr["option13"], $arr["option14"],
            $arr["option15"], $arr["option16"], $arr["option17"], $arr["option18"], $arr["option19"]);

  // Check if user has already voted
          $res = mysql_query("SELECT * FROM pollanswers WHERE pollid=$pollid AND userid=$userid") or sqlerr();
          $arr2 = mysql_fetch_assoc($res);
  }

  print("<h2>�����");

  if (get_user_class() >= UC_MODERATOR)
  {
          print("<font class=small>");
                print(" - [<a class=altlink href=makepoll.php?returnto=main><b>�������</b></a>]\n");
                if($pollok) {
                  print(" - [<a class=altlink href=makepoll.php?action=edit&pollid=$arr[id]&returnto=main><b>�������������</b></a>]\n");
                        print(" - [<a class=altlink href=polls.php?action=delete&pollid=$arr[id]&returnto=main><b>�������</b></a>]");
                }
                print("</font>");
        }
        print("</h2>\n");
        if($pollok) {
                print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>\n");
          print("<table class=main border=1 cellspacing=0 cellpadding=0><tr><td class=text>");
          print("<p align=center><b>$question</b></p>\n");
          $voted = $arr2;
          if ($voted)
          {
            // display results
            if ($arr["selection"])
              $uservote = $arr["selection"];
            else
              $uservote = -1;
                        // we reserve 255 for blank vote.
            $res = mysql_query("SELECT selection FROM pollanswers WHERE pollid=$pollid AND selection < 20") or sqlerr();

            $tvotes = mysql_num_rows($res);

            $vs = array(); // array of
            $os = array();

            // Count votes
            while ($arr2 = mysql_fetch_row($res))
              $vs[$arr2[0]] += 1;

            reset($o);
            for ($i = 0; $i < count($o); ++$i)
              if ($o[$i])
                $os[$i] = array($vs[$i], $o[$i]);

            function srt($a,$b)
            {
              if ($a[0] > $b[0]) return -1;
              if ($a[0] < $b[0]) return 1;
              return 0;
            }

            // now os is an array like this: array(array(123, "Option 1"), array(45, "Option 2"))
            if ($arr["sort"] == "yes")
                    usort($os, srt);

            print("<table class=main width=100% border=0 cellspacing=0 cellpadding=0>\n");
            $i = 0;
            while ($a = $os[$i])
            {
              if ($i == $uservote)
                $a[1] .= "&nbsp;*";
              if ($tvotes == 0)
                      $p = 0;
              else
                      $p = round($a[0] / $tvotes * 100);
              if ($i % 2)
                $c = "";
              else
                $c = " bgcolor=#ECE9D8";
              print("<tr><td width=1% class=embedded$c><nobr>" . $a[1] . "&nbsp;&nbsp;</nobr></td><td width=99% class=embedded$c>" .
                "<img src=./themes/V-IX/images/bar_left.gif><img src=./themes/V-IX/images/bar.gif height=9 width=" . ($p * 3) .
                "><img src=./themes/V-IX/images/bar_right.gif> $p%</td></tr>\n");
              ++$i;
            }
            print("</table>\n");
                        $tvotes = number_format($tvotes);
            print("<p align=center>�������: $tvotes</p>\n");
          }
          else
          {
            print("<form method=post action=index.php>\n");
            $i = 0;
            while ($a = $o[$i])
            {
              print("<input type=radio name=choice value=$i>$a<br>\n");
              ++$i;
            }
            print("<br>");
            print("<input type=radio name=choice value=255>������ ����� (��� \"� ������ ���� ������� ����������!\")<br>\n");
            print("<p align=center><input type=submit value='����������!' class=btn></p>");
          }
?>
</td></tr></table>
<?
if ($voted)
  print("<p align=center><a href=polls.php>������� ������</a></p>\n");
?>
</td></tr></table>

<?
        } else {
                echo "<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>\n";
          echo "<table class=main border=1 cellspacing=0 cellpadding=0><tr><td class=text>";
          echo"<p align=center><h3>��� �������</h3></p>\n";
          echo "</td></tr></table></td></tr></table>";
        }
}
?>
<IFRAME name="shout_frame" src="/ttshout.php" frameborder="0" marginheight="0" marginwidth="0" width="95%" height="415" scrolling="yes" align="middle"></IFRAME>
<h2>��� ������</h2>
<table width="100%" border="1" cellspacing="0" cellpadding="10"><tr><td align="left">
<table class="main" border="1" cellspacing="0" cellpadding="5">
<h2>&nbsp;����� ������ (<?=$totalonline?>):</h2>
<br>
&nbsp;<?=$activeusers?><br>
<br>
&nbsp;����� ������ (<?=$guests_online?>):
<br>
&nbsp;��������� ������������������ ������������: <b><?=$latestuser?></b>.<br>
</table>
</td></tr></table>
<center><b>
         - <font color=#0F6CEE><u>Mip</u></font> 
         - <font color=red><u>SySoP</u></font>
         - <font color=blue><u>Administrator</u></font>
         - <font color=green><u>Moderator</u></font>
         - <font color=orange><u>Uploader</u></font>
         - <font color=#9C2FE0><u>VIP</u></font>
         - <font color=#D21E36><u>Power User</u></font>
         - <u>User</u>
</u></b></center>

<? begin_frame("����������"); ?>
<!--<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td align=center>-->
<table width=100% class=main border=0 cellspacing=0 cellpadding=2><td align=center>
<table class=main border=1 cellspacing=0 cellpadding=5>

<table width=100% class=main border=0 cellspacing=0 cellpadding=10>
  <tr>
    <td width="50%" align="center" style="border: none;"><table class=main border=1 cellspacing=0 cellpadding=5>

<tr><td class=rowhead>������������������</td><td align=right><?=$registered?></td></tr>
<tr><td class=rowhead>����������������</td><td align=right><?=$unverified?></td></tr>
<tr><td class=rowhead>��������������&nbsp;<img src="/pic/warned.gif" border=0 align=absbottom></td><td align=right><?=$warned_users?></td></tr>
<tr><td class=rowhead>�����������&nbsp;<img src="/pic/disabled.gif" border=0 align=absbottom></td><td align=right><?=$disabled?></td></tr>
<tr><td class=rowhead><font color="orange">����������</font></td><td align=right><?=$uploaders?></td></tr>
<tr><td class=rowhead><font color="#9C2FE0">VIP</font></td><td align=right><?=$vip?></td></tr>

</table></td>
<td width="50%" align="center" style="border: none;"><table class=main border=1 cellspacing=0 cellpadding=5>

<tr><td class=rowhead>���������</td><td align=right><?=$torrents?></td></tr>
<tr><td class=rowhead>������� ���������</td><td align=right><?=$dead?></td></tr>
<tr><td class=rowhead>�������� �����������</td><td align=right><?=$peers?></td></tr>
<? if (isset($peers)) { ?>
<tr><td class=rowhead>���������&nbsp;&nbsp;<img src="./themes/V-IX/images/arrowup.gif" border=0 align=absbottom></td><td align=right><?=$seeders?></td></tr>
<tr><td class=rowhead>��������&nbsp;&nbsp;<img src="./themes/V-IX/images/arrowdown.gif" border=0 align=absbottom></td><td align=right><?=$leechers?></td></tr>
<tr><td class=rowhead>���������/�������� (%)</td><td align=right><?=$ratio?></td></tr>
<? } ?>

</table></td>

</table>
</td></tr></table>
<? end_frame(); ?>




<h2>������, ������� ����� ���������</h2>
<b><center><font color=#FF6633>������ ���, ��� ������� �������!!!</font></center>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>
<?
$res = mysql_query("SELECT id, name, seeders, leechers FROM torrents WHERE leechers > 0 AND seeders = 0 ORDER BY leechers DESC LIMIT 40") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0) {
while ($arr = mysql_fetch_assoc($res)) {
$torrname = htmlspecialchars($arr['name']);
if (strlen($torrname) > 55)
$torrname = substr($torrname, 0, 55) . "...";
$ttl = (28*24) - floor((gmtime() - sql_timestamp_to_unix_timestamp($arr["added"])) / 3600);
print("<b><a href=\"details.php?id=".$arr['id']."&hit=1\" alt=\"".$arr['name']."\" title=\"".$arr['name']."\">".$torrname."</a></b><font color=#0099FF><b> (������: ".number_format($arr['leechers'])/*, ".$completed."% ���������*/.")</b></font><br />\n");
}
} else
print("<b> ��� ���������, ������� ����� ��������� </b>\n");
print ("</font>
</b>
</td></tr></table>");
?>

<?begin_frame("�������� �� ������",true,5);?>
<table class=main border=0 width=100%><tr><td style='padding: 0px; background-image: url(/pic/loadbarbg.gif); background-repeat: repeat-x'>
<? $percent = min(100, round(exec('ps ax | grep -c apache') / 256 * 100));
if ($percent <= 70) $pic = "loadbargreen.gif";
elseif ($percent <= 90) $pic = "loadbaryellow.gif";
else $pic = "loadbarred.gif";
$width = $percent * 4;
print("<img height=15 width=$width src=\"/pic/$pic\" alt='$percent%'>"); ?>
</td></tr></table>
<?end_frame();?>



<p><font class="small">None of the files shown here are actually hosted on this server. The links are provided solely by this site's users. The administrator of this site  cannot be held responsible for what its users post, or any other actions of its users.
You can't upload any files which are copyrighted by they autors, and also files of illegal maintenance!
If you're against placing of some information here - please contact with Administration.</font></p>


</td></tr></table>

<td valign="top" width="15%">
<?
//  blok_menu("<center>������</center>", "********* - 4" , "155");
//  echo "<br>";

/*
	$utils = '<u><font color="#be5c15"><b>�������</b></font></u><br>
&nbsp;&nbsp;-&nbsp;<a href="http://prdownloads.sourceforge.net/gordianknot/" target="_blank"><font class="small" color="brown">Gordian Knot</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://prdownloads.sourceforge.net/virtualdub/" target="_blank"><font class="small" color="brown">VirtualDub</font></a><br>

&nbsp;&nbsp;-&nbsp;<a href="http://prdownloads.sourceforge.net/virtualdubmod/" target="_blank"><font class="small" color="brown">VirtualDub Mod</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/ac3fix.htm" target="_blank"><font class="small" color="brown">AC3fix 0.3</font></a>
<br><br>

<u><font color="#be5c15"><b>DVD</b></font></u><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/DVD_Decrypter.htm" target="_blank"><font class="small" color="brown">DVD Decrypter 3.5.4.0 </font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.afterdawn.com/software/video_software/dvd_rippers/dvd_shrink.cfm" target="_blank"><font class="small" color="brown">DVD Shrink v3.2.0.15</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/Stinky_MPEG_2_Codec.htm" target="_blank"><font class="small" color="brown">MPEG2 Codec </font></a>

<br>
<br>
<u><font color="#be5c15"><b>�����/����� ������</b></font></u><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/Koepi_XviD.htm" target="_blank"><font class="small" color="brown">Koepi\'s XviD �����</font></a><br>

&nbsp;&nbsp;-&nbsp;<a href="http://www.divx.com/divx/?src=toptab_divx_from_/index.php" target="_blank"><font class="small" color="brown">DivX</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/K_Lite_Codec_Pack.htm" target="_blank"><font class="small" color="brown">K-Lite ����� �������</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/AC3_Filter.htm" target="_blank"><font class="small" color="brown">AC3 Filter</font></a><br>

&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/Matroska_Pack.htm" target="_blank"><font class="small" color="brown">Matroska</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/Vorbis_Ogg_ACM.htm" target="_blank"><font class="small" color="brown">Vorbis Ogg</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.free-codecs.com/download/GSpot.htm" target="_blank"><font class="small" color="brown">GSpot</font></a><br><br>

<u><font color="#be5c15"><b>������������</b></font></u><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.miranda-im.org/" target="_blank"><font class="small" color="brown">Miranda</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://www.skype.com/" target="_blank"><font class="small" color="brown">Skype</font></a><br>

&nbsp;&nbsp;-&nbsp;<a href="http://www.icq.com/" target="_blank"><font class="small" color="brown">ICQ</font></a>
<br><br>
<u><font color="#be5c15"><b>�������������</b></font></u><br>
&nbsp;&nbsp;-&nbsp;<a href="http://bsplayer.org/index.php?p=download" target="_blank"><font class="small" color="brown">BSPlayer</font></a><br>

&nbsp;&nbsp;-&nbsp;<a href="http://www.softella.com/" target="_blank"><font class="small" color="brown">LightAlloy</font></a><br>
&nbsp;&nbsp;-&nbsp;<a href="http://forum.inmatrix.com/index.php?showtopic=480" target="_blank"><font class="small" color="brown">ZoomPlayer</font></a><br><br></div>';

  blok_menu("<center>��������</center>", $utils, "155");
  echo "<br>";*/

  	$search = '<table width="100%">
               <tr><td class="embedded">
               &nbsp;��������
               <form method="get" action=browse.php>
               <input type="text" name="search" size="20" value="" /></td></tr>
               <tr><td class="embedded" style="padding-top: 3px;">

               <input type="submit" value="������!" /></td></tr>
               </form>
               </table>
               <table width="100%">
               <tr><td class="embedded">
               &nbsp;�������
               <form method="get" action=viewrequests.php>
               <input type="text" name="search" size="20" value="" /></td></tr>
               <tr><td class="embedded" style="padding-top: 3px;">

               <input type="submit" value="������!" /></td></tr>
               </form>
               </table>
               <table width="100%">
               <tr><td class="embedded">
               &nbsp;�����������
               <form method="get" action=viewoffers.php>
               <input type="text" name="search" size="20" value="" /></td></tr>
               <tr><td class="embedded" style="padding-top: 3px;">

               <input type="submit" value="������!" /></td></tr>
               </form>
               </table>

               <table width="100%">
               <tr><td class="embedded">
               &nbsp;�����
               <form method="get" action="forums.php?">
               <input type=hidden name=action value=search>
               <input type="text" name="keywords" size="20" value="" /></td></tr>

               <tr><td class="embedded" style="padding-top: 3px;">
               <input type="submit" value="������!" /></td></tr>
               </form>
               </table>';

  blok_menu("<center>�����</center>", $search , "155");
  echo "<br>\n";

?>

</td>

<?
stdfoot();
?>