<?

///////////////////////////////////////////////////////////////
//
//
//		Shoutbox Hack for TorrentTrader RC2.
//		
//			Coded by: PseudoX
//			Contact: pseudox@gmail.com
//
//		Feel free to use this on your own tracker
//		also to modify to suit your needs, just 
//		keeps this comment at the top and all is 
//		good.
//
//
///////////////////////////////////////////////////////////////


//Disclaimer:
//anything u screw up, is your fault. i take no responsibility.

//Copyright:
//feel free to modify/change or hack this to bits, or even rerelease it (modified signifcantly) under your name 
//ASLONG AS I STILL HAVE CREDIT SOMEWHERE. ie. Bob's Shoutbox (based on PseudoX's code)

?>




<?
require_once("include/bittorrent.php");
require_once('include/secrets.php');
dbconn(false);
$local_time = get_date_time(time());

// SET TO TRUE TO CENSOR WORDS
$CENSORWORDS = true;


function CensorWords($msg)
{
global $CENSORWORDS;
if ($CENSORWORDS)
{
$query = 'SELECT * FROM shoutbox_censor';
$result = mysql_query($query);
	while ($row = mysql_fetch_assoc($result))
	{
	$msg = str_replace($row['word'], '[censored]', $msg);

	}
}
return $msg;

}

function ReplaceSmilies($msg)
{
global $SITEURL;
$query = 'SELECT * FROM shoutbox_emoticons';
$result = mysql_query($query);

	while ($row = mysql_fetch_assoc($result))
	{
	$imagelink = '<img src="'.$SITEURL.'/images/shoutbox/'.$row['image'].'">';
	$msg = str_replace($row['text'], $imagelink, $msg);
	}
	
	return $msg;
}

function MakeSQLSafe($msg)
{

//this will allow all punctuation in the message, and also prevent sql injection.

$msg = str_replace("'", '&#39;', $msg);
$msg = str_replace("--", '&#45;&#45;', $msg);

return $msg;
};

function MakeHTMLSafe($msg)
{

//this will stop people from using javascript and html tags in their posts.

$msg = str_replace('<', '&lt;', $msg);
$msg = str_replace('>', '&gt;', $msg);
$msg = str_replace('javascript:', 'javascript&#58;', $msg);

//replace [url] tags with a proper link
$msg = preg_replace("/\[url\]([^[]+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>",$msg);

return $msg;
}

//deleting msges
if (isset($_GET['del']))
{
		//no sql injection
		if (is_numeric($_GET['del']))
		{
		$query = "SELECT * FROM shoutbox WHERE msgid=".$_GET['del'] ;
		$result = mysql_query($query);
		}
		else {echo "invalid msg id STOP TRYING TO INJECT SQL";exit;}

	$row = mysql_fetch_row($result);
		
		if ( (get_user_class() >= UC_MODERATOR) || ($CURUSER['username'] == $row[1]) )
		{	
			$query = "DELETE FROM shoutbox WHERE msgid=".$_GET['del'] ;
			mysql_query($query);	
		}


}

//adding msges
if ($_POST['message'] > '')
	{
		
		if (isset($CURUSER))
		{
		
		//this will check to see if there has already been an identical message posted (preventing double posts)
		
		$query = "SELECT COUNT(*) FROM shoutbox WHERE message='".MakeSQLSafe($_POST['message'])."'";
		$result = mysql_query($query);

		$row = mysql_fetch_row($result);
		if ($row[0] == '0')
		{
		
		//add the message if all is ok. (not a doublepost)
		$query = "INSERT INTO shoutbox (msgid, user, message, date, userid) VALUES (NULL, '".$CURUSER['username']."', '".MakeSQLSafe($_POST['message'])."', '".$local_time."', '".$CURUSER['id']."')";
		mysql_query($query);

		}
		}
	}

//get the current theme

  if ($CURUSER)
  {
    $ss_a = @mysql_fetch_array(@mysql_query("select uri from stylesheets where id=" . $CURUSER["stylesheet"]));
    if ($ss_a) $ss_uri = $ss_a["uri"];
  }
  if (!$ss_uri)
  {
    ($r = mysql_query("SELECT uri FROM stylesheets WHERE id=1")) or die(mysql_error());
    ($a = mysql_fetch_array($r)) or die(mysql_error());
    $ss_uri = $a["uri"];
  }


?>
<HTML>
<HEAD>
<TITLE><?=$SITENAME?> Shoutbox</TITLE>
<META HTTP-EQUIV="refresh" content="100">
<link rel="stylesheet" type="text/css" href="themes/<?=$ss_uri?>/theme.css" />
<link rel="stylesheet" type="text/css" href="themes/Filelist/ttshout.css" />
</HEAD>

<?

//when you post a message, if you uncomment this, the page will jump down to the shoutbox. it will also do it when you load the site.
//   not really recommended

//echo '<BODY style="font-family: verdana; color: black; float: middle" onLoad="GiveMsgBoxFocus();">';


echo '<BODY>';

?>
<SCRIPT LANGUAGE="JAVASCRIPT">
<!-- 
function GiveMsgBoxFocus()
{
document.ttshoutform.message.focus();
}

function ShowSmilies() {
  var SmiliesWindow = window.open("<?=$SITEURL?>/ttshout_smilies.php", "Smilies","width=200,height=200,resizable=yes,scrollbars=yes,toolbar=no,location=no,directories=no,status=no");
}

//-->
</SCRIPT>
<?
if(!isset($_GET['history']))
{ 
echo '
<div class="contain">
<table border="0" style="width: 99%; table-layout:fixed">';
}
else
{
echo '
<div class="history">';

//page numbers

$query = 'SELECT COUNT(*) FROM shoutbox';
$result = mysql_query($query);
$row = mysql_fetch_row($result);
echo '<div align="middle">Pages: ';
$pages = round($row[0] / 100) + 1;
$i = 1;
while ($pages > 0)
{
echo "<a href='".$SITEURL."/ttshout.php?history=1&page=".$i."'>[".$i."]</a>&nbsp;";
$i++;
$pages--;
}


echo '
</div></br><table border="0" style="width: 99%; table-layout:fixed">';
}

if (isset($_GET['history']))
{
	if (isset($_GET['page']))
	{
		if($_GET['page'] > '1')
		{
		$lowerlimit = $_GET['page'] * 100 - 100;
		$upperlimit = $_GET['page'] * 100;
		}
		else
		{
		$lowerlimit = 0;
		$upperlimit = 100;
		}
	}
	else
	{
		$lowerlimit = 0;
		$upperlimit = 100;
	}
	
	$query = 'SELECT * FROM shoutbox ORDER BY msgid DESC LIMIT '.$lowerlimit.','.$upperlimit;
	//echo $query;
}
else
{
	$query = 'SELECT * FROM shoutbox ORDER BY msgid DESC LIMIT 70';
}
//echo $query;
$result = mysql_query($query);
$alt = false;

while ($row = mysql_fetch_assoc($result)) {


//alternate the colours
if ($alt)
{
	echo '<tr class="noalt">';
	$alt = false;
}
else
{
	echo '<tr class="alt">';
	$alt = true;
}

echo '<td style="font-size: 9px; width: 118px;">';
echo "<div align='left' style='float: left'>";

echo date('jS M, g:ia', sql_timestamp_to_unix_timestamp($row['date']));

echo "</div>";
if ( (get_user_class() >= UC_MODERATOR) || ($CURUSER['username'] == $row['user']) )
{

echo "<div align='right' style='float: right'><a href='".$SITEURL."/ttshout.php?del=".$row['msgid']."' style='font-size: 8px'>[D]</a><div>";
}

echo	'</td><td style="font-size: 12px; padding-left: 5px">
<a href="'.$SITEURL.'/userdetails.php?id='.$row['userid'].'" target="_parent"><b>'.$row['user'].':</b>
</a>&nbsp;&nbsp;'.nl2br(ReplaceSmilies(MakeHTMLSafe(CensorWords($row['message']))));

echo	'</td></tr>';


}
?>

</table>
</div>
<br>

<?

//if the user is logged in, show the shoutbox, if not, dont.
if(!isset($_GET['history']))
{

if (isset($CURUSER))
{

echo "
<form name='ttshoutform' action='".$SITEURL."/ttshout.php' method='post'>
<table style='width: 100%'>
<tr class='messageboxback'>
<td width='88%'>
<input type='text' name='message' class='msgbox'>
</td>
<td width='9%'>
<input type='submit' name='submit' value='Shout it!' class='shoutbtn'>
</td>
<td style='font-size: 8px';>
<a href='javascript:ShowSmilies();'>Smiles</div>
<br>
<a href='".$SITEURL."/ttshout.php?history=1' target='_blank'>History</a>
</td>
</tr>
</table>
";
echo "</form>";


}
else
{
echo "<br /><div class='error'>You must login to shout.</div>";
}

}

?>
</BODY>
</HTML>