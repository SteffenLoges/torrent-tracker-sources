<html><head>
<title><?= $title ?></title>
<link rel="stylesheet" href="./themes/<?=$ss_uri."/".$ss_uri?>.css" type="text/css">
<script language="javascript" type="text/javascript" src="js/functions.js"></script>
<link rel="alternate" type="application/rss+xml" title="��������� ��������" href="<?=$DEFAULTBASEURL?>/rss.php">
<link rel="shortcut icon" href="/favicon.gif" type="image/x-icon" />

</head>
<body>

<!--<table width="100%" height="100" border="0" cellpadding="0" cellspacing="0">
 <tr>
   <td width="50%" background="./themes/V-IX/images/sf_logo.jpg" style="border-right: none"><a href="<?=$DEFAULTBASEURL?>"><img src="./themes/V-IX/images/logo_left.jpg" alt="<?=$SITENAME?>" title="<?=$SITENAME?>" border="0" /></a></td>
   <td width="50%" background="./themes/V-IX/images/sf_logo.jpg" style="border-left: none">Banner Goes Here</td>
 </tr>
</table>-->

<table width=100% cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>

<td class=clear width=49%>
<!--
<table border=0 cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>

<td class=clear>
<img src=./themes/V-IX/images/star20.gif style='margin-right: 10px'>
</td>
<td class=clear>
<font color=white><b>Current funds: $0</b></font>
</td>
</tr>
</table>
-->

</td>
<td class=clear>
<div align=center>
<a href="<?=$DEFAULTBASEURL?>"><img style="border:none" alt="<?=$SITENAME?>" title="<?=$SITENAME?>" src="./themes/V-IX/images/logo.jpg" width="979" height="88"></a>
</div>
</td>
<td class=clear width=49% align=right>
</td>

</tr></table>

<!-- Top Navigation Menu for unregistered-->
<table width="100%" border="0" cellspacing="0" cellpadding="2"><tr>
<td align="center" class="topnav">&nbsp;<a href=/><font color=#BE5C15>�������</font></a>
<? if ($CURUSER) { ?>
&nbsp;&#8226;&nbsp;
<a href=browse.php><font color=#BE5C15>�������</font></a>
<? } ?>
<? if (get_user_class() >= UC_UPLOADER) { ?>
&nbsp;&#8226;&nbsp;
<a href=upload.php><font color=#BE5C15>������</font></a>
<? } ?>
&nbsp;&#8226;&nbsp;
<a href=forums.php><font color=#BE5C15>�����</font></a>
&nbsp;&#8226;&nbsp;
<a href=rules.php><font color=#BE5C15>�������</font></a>
&nbsp;&#8226;&nbsp;
<a href=faq.php><font color=#BE5C15>����</font></a>
<? if ($CURUSER) { ?>
&nbsp;&#8226;&nbsp;
<!--<a href=helpdesk.php><font color=#BE5C15>���. ���������</font></a>
&nbsp;&#8226;&nbsp;-->
<a href=staff.php><font color=#BE5C15>�������������</font></a>
<? } ?>
</td></tr>
</table>
<!-- /////// Top Navigation Menu for unregistered-->

<!-- /////// some vars for the statusbar;o) //////// -->

<? if ($CURUSER) { ?>

<?

$datum = getdate();

$datum[hours] = sprintf("%02.0f", $datum[hours]);

$datum[minutes] = sprintf("%02.0f", $datum[minutes]);

$datum[seconds] = sprintf("%02.0f", $datum[seconds]);

$uped = mksize($CURUSER['uploaded']);

$downed = mksize($CURUSER['downloaded']);

if ($CURUSER["downloaded"] > 0)

{

$ratio = $CURUSER['uploaded'] / $CURUSER['downloaded'];

$ratio = number_format($ratio, 3);

$color = get_ratio_color($ratio);

if ($color)

$ratio = "<font color=$color>$ratio</font>";

}

else

if ($CURUSER["uploaded"] > 0)

$ratio = "Inf.";

else

$ratio = "---";

if ($CURUSER['donor'] == "yes")

$medaldon = "<img src=pic/star.gif alt=donor title=donor>";

if ($CURUSER['warned'] == "yes")

$warn = "<img src=pic/warned.gif alt=warned title=warned>";

//// check for messages ////////////////// 
        $res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location=1") or print(mysql_error()); 
        $arr1 = mysql_fetch_row($res1); 
        $messages = $arr1[0]; 
        $res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location=1 AND unread='yes'") or print(mysql_error()); 
        $arr1 = mysql_fetch_row($res1); 
        $unread = $arr1[0]; 
        $res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE sender=" . $CURUSER["id"] . " AND saved='yes'") or print(mysql_error()); 
        $arr1 = mysql_fetch_row($res1); 
        $outmessages = $arr1[0]; 
        if ($unread) 
                $inboxpic = "<img height=14px style=border:none alt=inbox title='���� ����� ���������' src=pic/pn_inboxnew.gif>"; 
        else 
                $inboxpic = "<img height=14px style=border:none alt=inbox title='��� ����� ���������' src=pic/pn_inbox.gif>";

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='yes'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeseed = $row[0];

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='no'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeleech = $row[0];

//// end

?>

<!-- //////// start the statusbar ///////////// -->

</table>

<p>

<? }?>

<!-- /////////// here we go, with the menu //////////// -->

<?php

$w = "width=100%";
//if ($_SERVER["REMOTE_ADDR"] == $_SERVER["SERVER_ADDR"]) $w = "width=984";

?>
<table class=mainouter <?=$w; ?> border="1" cellspacing="0" cellpadding="5">

<!------------- MENU ------------------------------------------------------------------------>

<? $fn = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], "/") + 1); ?>
<tr><td class=outer align=center colspan="3">
<table class=main width=700 cellspacing="0" cellpadding="5" border="0">
<tr>

<td align="center" class="navigation"><a href=/>�������</a></td>
<? if ($CURUSER) { ?>
<td align="center" class="navigation"><a href=/browse.php>�������</a></td>
<? } ?>
<!--<td align="center" class="navigation"><a href=/search.php>�����</a></td>-->
<? if (get_user_class() >= UC_UPLOADER) { ?>
<td align="center" class="navigation"><a href=/upload.php>������</a></td>
<? } ?>
<? if (!$CURUSER) { ?>
<td align="center" class="navigation">
<a href=login.php>����</a> / <a href=/signup.php>�����������</a>
</td>
<? } else { ?>
<td align="center" class="navigation"><a href=/bookmarks.php>��������</a></td>
<? } ?>
<td align="center" class="navigation"><a href=/forums.php>�����</a></td>
<td align="center" class="navigation"><a href=/topten.php>Top 10</a></td>
<!--<td align="center" class="navigation"><a href=/log.php>Log</a></td>-->
<td align="center" class="navigation"><a href=/rules.php>�������</a></td>
<!--<td align="center" class="navigation"><a href=/faq.php>����</a></td>-->
<!--<td align="center" class="navigation"><a href=/links.php>������</a></td>-->
<? if ($CURUSER) { ?>
<td align="center" class="navigation"><a href=/staff.php>�������������</a></td>
<? } ?>
</tr>
</table>
</td>
</tr>
<tr>
<td valign="top" width="15%">
<?

if ($messages) {
                $message_in = "<span class=\"smallfont\">&nbsp;<a href=\"message.php\">$inboxpic</a> $messages " . sprintf($tracker_lang["new_pms"], $unread) . "</span>";
                if ($outmessages)
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> $outmessages</span>";
                else
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> 0</span>";
        }
        else {
                $message_in = "<span class=\"smallfont\">&nbsp;<a href=\"message.php\"><img height=\"14px\" style=\"border:none\" alt=\"���������\" title=\"���������\" src=\"pic/pn_inbox.gif\"></a> 0</span>";
                if ($outmessages)
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> $outmessages</span>";
                else
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> 0</span>";
        }

/*if ($messages){
$message_in = "<a href=inbox.php>$inboxpic</a> $messages ($unread ���" .($unread > 1 ? "��" : "��") . ")";
if ($outmessages)
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages";
else
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0";
}
else
{
$message_in = "<a href=inbox.php><img height=14px style=border:none alt=inbox title=inbox src=pic/pn_inbox.gif></a> 0";
if ($outmessages)
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages";
else
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0";
}*/

if ($CURUSER) {

$ss_r = mysql_query("SELECT * from stylesheets ORDER by id ASC") or die;
$ss_sa = array();
while ($ss_a = mysql_fetch_array($ss_r))
{
  $ss_id = $ss_a["id"];
  $ss_name = $ss_a["name"];
  $ss_sa[$ss_name] = $ss_id;
}
reset($ss_sa);
while (list($ss_name, $ss_id) = each($ss_sa))
{
  if ($ss_id == $CURUSER["stylesheet"]) $ss = " selected"; else $ss = "";
  $stylesheets .= "<option value=$ss_id$ss>$ss_name</option>\n";
}

	$userbar = "<a href=/my.php><img src=" . ( $CURUSER["avatar"] ? $CURUSER["avatar"] : "/pic/default_avatar.gif" ) . "  width=100 alt=������ title=������ border=0 /></a>
	<br>
	<font color=1900D1>�������:</font>&nbsp;$ratio<br>
	<font color=green>������:</font>&nbsp;$uped<br>
	<font color=red>������:</font>&nbsp;$downed<br>
	<font color=blue>��:</font>&nbsp;$message_in $message_out<br>
	��������:&nbsp;<img alt=\"������\" title=\"������\" src=\"./themes/V-IX/images/arrowup.gif\">&nbsp;<font color=green><span class=\"smallfont\">$activeseed</span></font>&nbsp;<img alt=\"������\" title=\"������\" src=\"./themes/V-IX/images/arrowdown.gif\">&nbsp;<font color=red><span class=\"smallfont\">$activeleech</span></font><br>
	�����:&nbsp;$datum[hours]:$datum[minutes]:$datum[seconds]<br>
	<font color=#FF6600>��� IP: " . $_SERVER["REMOTE_ADDR"] . "</font><br>
	�����: <select name=stylesheet onchange=\"window.location='/?styleid='+this.options[this.selectedIndex].value\">\n$stylesheets\n</select>
	<br>
	<center>[<a href=/logout.php>�����</a>]</center>
	";
} else {
	$userbar = '<center><form method="post" action="takelogin.php">
<br>
�����: <br>
<input type="text" size=20 name="username" /><br>
������: <br>

<input type="password" size=20 name="password" /><br>
<!--<input type=checkbox name=logout value="yes">���������<br>-->
<input type="submit" value="����!" class=btn><br><br>
</form></center>
<a class="menu" href="signup.php"><center><font color=red>�����������</font></center></a>';
}

if ($CURUSER['override_class'] != 255) $usrclass = "&nbsp;<img src=pic/warning.gif title=".get_user_class_name($CURUSER['class'])." alt=".get_user_class_name($CURUSER['class']).">&nbsp;";

elseif(get_user_class() >= UC_MODERATOR) $usrclass = "&nbsp;<a href=setclass.php><img src=pic/warning.gif title=\"".get_user_class_name($CURUSER['class'])."\" alt=\"".get_user_class_name($CURUSER['class'])."\" border=\"0\"></a>&nbsp;";

  blok_menu("<center>������, " . ( $CURUSER ? "<a href=$BASEURL/userdetails.php?id=" . $CURUSER["id"] . ">" . $CURUSER["username"] . "</a>&nbsp;".$usrclass."&nbsp;" : "�����" ) . $medaldon . $warn , $userbar , "155");
  echo "<br>";

  $mainmenu = "<a class=\"menu\" href=\"/index.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�������</a>"
           ."<a class=\"menu\" href=\"/browse.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�������</a>"
           ."<a class=\"menu\" href=\"/viewrequests.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�������</a>"
           ."<a class=\"menu\" href=\"/viewoffers.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�����������</a>"
           ."<a class=\"menu\" href=\"/forums.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�����</a>"
           ."<a class=\"menu\" href=\"/log.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;������</a>"
           ."<a class=\"menu\" href=\"/rules.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�������</a>"
           ."<a class=\"menu\" href=\"/faq.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;����</a>"
           ."<a class=\"menu\" href=\"/topten.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;��� 10</a>"
           ."<a class=\"menu\" href=\"/formats.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;������� ������</a>";

  blok_menu("<center>������� ����</center>", $mainmenu , "155");
  echo "<br>";

if ($CURUSER) {

  $usermenu = "<a class=\"menu\" href=\"/my.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;������ ����������</a>"
           ."<a class=\"menu\" href=\"/userdetails.php?id=".$CURUSER["id"]."\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�������</a>"
           ."<a class=\"menu\" href=\"/bookmarks.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;��������</a>"
           ."<a class=\"menu\" href=\"/mybonus.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;<font color=green>��� ������</font></a>"
//           ."<a class=\"menu\" href=\"/bitbucket-upload.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�������� ��������</a>"
           ."<a class=\"menu\" href=\"/dox.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�����-�������</a>"
           ."<a class=\"menu\" href=\"/invite.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;����������</a>"
           ."<a class=\"menu\" href=\"/users.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;������������</a>"
           ."<a class=\"menu\" href=\"/friends.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;��� ������</a>"
           ."<a class=\"menu\" href=\"/subnet.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;������</a>"
           ."<a class=\"menu\" href=\"/mytorrents.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;��� ��������</a>"
           ."<a class=\"menu\" href=\"/logout.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�����!</a>";

  blok_menu("<center>������������ ����</center>", $usermenu , "155");
  echo "<br>";

  $messages = "<a class=\"menu\" href=\"/message.php\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;����������</a>"
           ."<a class=\"menu\" href=\"/message.php?action=viewmailbox&box=-1\">&nbsp;<img src=./themes/V-IX/images/left.gif border=\"0\">&nbsp;�����������</a>";
  
  blok_menu("<center>���������</center>", $messages , "155");
  echo "<br>";
}

  $bt_clients = '&nbsp;&nbsp;<a href="http://bitconjurer.org/BitTorrent/download.html" target="_blank"><font class=small color=green>�����������</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://azureus.sourceforge.net/" target="_blank"><font class=small color=green>Azureus (Java)</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://www.bittornado.com/" target="_blank"><font class=small color=green>BitTornado</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://www.utorrent.com/" target="_blank" ><font class=small color=green>�Torrent</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://www.bitcomet.com/" target="_blank"><font class=small color=green>BitComet</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://www.bitlord.com/" target="_blank"><font class=small color=green>BitLord</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://www.macupdate.com/info.php/id/7170" target="_blank"><font class="small" color=green>Acquisition (Mac)</font></a><br>'
  			.'&nbsp;&nbsp;<a href="http://www.167bt.com/intl/" target="_blank"><font class=small color=green>BitSpirit</font></a><br>'
  			.'<hr width=100% color=#ffc58c size=1>
<font class=small color=red>&nbsp;&nbsp;������� ������������� ����</font>';

  blok_menu("<center>������� �������</center>", $bt_clients , "155");
  echo "<br>";

?>
</td>

<td align=center valign=top class=outer style="padding-top: 10px; padding-bottom: 10px">
<?

if ($CURUSER) {
$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location=1 AND unread='yes'"); 
        $arr1 = mysql_fetch_row($res1); 
        $unread = $arr1[0]; 
        if ($unread) 
        { 
                print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background: red'>\n"); 
                print("<b><a href=message.php><font color=white>� ��� $unread �����(��) ���������(��)!</font></a></b>"); 
                print("</td></tr></table></p>\n"); 
        }
}

/*if ($unread)
{
  print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background: red'>\n");
  print("<b><a href=$BASEURL/inbox.php><font color=white>� ��� ���� $unread ����������" . ($unread > 1 ? "��" : "��") . " ��������" . ($unread > 1 ? "�" : "�") . "!</font></a></b>");
  print("</td></tr></table></p>\n");
}*/

if ($CURUSER['override_class'] != 255 && $CURUSER) // Second condition needed so that this box isn't displayed for non members/logged out members.
 {
  print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=green><tr><td style='padding: 10px; background: green'>\n");
  print("<b><a href=$BASEURL/restoreclass.php><font color=white>�� ��������� ��� ����� ������ �������. ������� ���� ��� ��������.</font></a></b>");
  print("</td></tr></table></p>\n");
 }