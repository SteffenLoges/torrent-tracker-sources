<html><head>
<title><?= $title ?></title>
<link rel="stylesheet" href="./themes/<?=$ss_uri."/".$ss_uri?>.css" type="text/css">
<script language="javascript" type="text/javascript" src="js/functions.js"></script>
<link rel="alternate" type="application/rss+xml" title="��������� ��������" href="<?=$DEFAULTBASEURL?>/rss.php">
<link rel="shortcut icon" href="/favicon.gif" type="image/x-icon" />

</head>
<body>

<!--<table width="100%" height="100" border="0" cellpadding="0" cellspacing="0">
 <tr>
   <td width="50%" background="./themes/StreamZone/images/sf_logo.jpg" style="border-right: none"><a href="<?=$DEFAULTBASEURL?>"><img src="./themes/StreamZone/images/logo_left.jpg" alt="<?=$SITENAME?>" title="<?=$SITENAME?>" border="0" /></a></td>
   <td width="50%" background="./themes/StreamZone/images/sf_logo.jpg" style="border-left: none">Banner Goes Here</td>
 </tr>
</table>-->

<table width="100%" cellspacing="0" cellpadding="0" style='background: transparent'>
<tr>
<td class="embedded" width="49%">
<!--
<table border=0 cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>

<td class=clear>
<img src=/pic/star20.gif style='margin-right: 10px'>
</td>
<td class=clear>
<font color=white><b>Current funds: <?=$FUNDS?></b></font>
</td>
</tr>
</table>
-->

</td>
<td class="embedded">
<div align="center">
<img src="./themes/StreamZone/images/logo.gif" align="middle" alt="" />
</div>
</td>
<td class="embedded" width="49%" align="right">
</td>
</tr></table>

<!-- /////// some vars for the statusbar;o) //////// -->

<? if ($CURUSER) { ?>

<?

$datum = getdate();

$datum[hours] = sprintf("%02.0f", $datum[hours]);

$datum[minutes] = sprintf("%02.0f", $datum[minutes]);

$datum[seconds] = sprintf("%02.0f", $datum[seconds]);

$uped = mksize($CURUSER['uploaded']);

$downed = mksize($CURUSER['downloaded']);

if ($CURUSER["downloaded"] > 0)

{

$ratio = $CURUSER['uploaded'] / $CURUSER['downloaded'];

$ratio = number_format($ratio, 3);

$color = get_ratio_color($ratio);

if ($color)

$ratio = "<font color=$color>$ratio</font>";

}

else

if ($CURUSER["uploaded"] > 0)

$ratio = "Inf.";

else

$ratio = "---";

if ($CURUSER['donor'] == "yes")

$medaldon = "<img src=pic/star.gif alt=donor title=donor>";

if ($CURUSER['warned'] == "yes")

$warn = "<img src=pic/warned.gif alt=warned title=warned>";

//// check for messages ////////////////// 
        $res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location=1") or print(mysql_error()); 
        $arr1 = mysql_fetch_row($res1); 
        $messages = $arr1[0]; 
        $res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location=1 AND unread='yes'") or print(mysql_error()); 
        $arr1 = mysql_fetch_row($res1); 
        $unread = $arr1[0]; 
        $res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE sender=" . $CURUSER["id"] . " AND saved='yes'") or print(mysql_error()); 
        $arr1 = mysql_fetch_row($res1); 
        $outmessages = $arr1[0]; 
        if ($unread) 
                $inboxpic = "<img height=14px style=border:none alt=inbox title='���� ����� ���������' src=pic/pn_inboxnew.gif>"; 
        else 
                $inboxpic = "<img height=14px style=border:none alt=inbox title='��� ����� ���������' src=pic/pn_inbox.gif>";

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='yes'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeseed = $row[0];

$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='no'") or print(mysql_error());

$row = mysql_fetch_row($res2);

$activeleech = $row[0];

//// end

?>

<!-- //////// start the statusbar ///////////// -->

</table>

<p>

<table align="center" cellpadding="4" cellspacing="0" border="0" style="width:100%">
<tr>
<td class="tablea"><table align="center" style="width:100%" cellspacing="0" cellpadding="0" border="0">
<tr>
<td class="bottom" align="left"><span class="smallfont">������, <b><a href="userdetails.php?id=<?=$CURUSER['id']?>"><?=$CURUSER['username']?></a></b><?=$medaldon?><?=$warn?>&nbsp; [<a href="logout.php">�����</a>]<br/>
<font color=1900D1>�������:</font> <?=$ratio?>&nbsp;&nbsp;<font color=green>������:</font> <font color=black><?=$uped?></font>&nbsp;&nbsp;<font color=darkred>������:</font> <font color=black><?=$downed?></font>&nbsp;&nbsp;<font color=1900D1>��������:&nbsp;</font></span> <img alt="�������" title="�������" src="./themes/PowerOn/images/arrowup.gif">&nbsp;<font color=black><span class="smallfont"><?=$activeseed?></span></font>&nbsp;&nbsp;<img alt="������" title="������" src="./themes/PowerOn/images/arrowdown.gif">&nbsp;<font color=black><span class="smallfont"><?=$activeleech?></span></font></td>
<td class="bottom" align="right"><span class="smallfont">������� �����: <?echo "$datum[hours]:$datum[minutes]";?><br/>
<?
if ($messages){
print("<span class=smallfont><a href=message.php>$inboxpic</a> $messages ($unread New)</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=message.php?action=viewmailbox&box=-1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=message.php?action=viewmailbox&box=-1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0</span>");
}
else
{
print("<span class=smallfont><a href=message.php><img height=14px style=border:none alt=inbox title=inbox src=pic/pn_inbox.gif></a> 0</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=message.php?action=viewmailbox&box=-1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=message.php?action=viewmailbox&box=-1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0</span>");
}
print("&nbsp;<a href=friends.php><img style=border:none alt=Buddylist title=Buddylist src=pic/buddylist.gif></a>");
print("&nbsp;<a href=getrss.php><img style=border:none alt=Rss title=Rss src=pic/rss.gif></a>");
?>
</span></td>

</tr>
</table></table>
<br />

<? }?>

<!-- /////////// here we go, with the menu //////////// -->

<?php

$w = "width=100%";
//if ($_SERVER["REMOTE_ADDR"] == $_SERVER["SERVER_ADDR"]) $w = "width=984";

?>
<table class=mainouter <?=$w; ?> border="1" cellspacing="0" cellpadding="5">

<!------------- MENU ------------------------------------------------------------------------>

<? $fn = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], "/") + 1); ?>
<tr><td class=outer align=center colspan="3">
<table class=main width=700 cellspacing="0" cellpadding="5" border="0">
<tr>

<td align="center" class="navigation"><a href=/>�������</a></td>
<? if ($CURUSER) { ?>
<td align="center" class="navigation"><a href=/browse.php>�������</a></td>
<? } ?>
<!--<td align="center" class="navigation"><a href=/search.php>�����</a></td>-->
<? if (get_user_class() >= UC_UPLOADER) { ?>
<td align="center" class="navigation"><a href=/upload.php>������</a></td>
<? } ?>
<? if (!$CURUSER) { ?>
<td align="center" class="navigation">
<a href=login.php>����</a> / <a href=/signup.php>�����������</a>
</td>
<? } else { ?>
<td align="center" class="navigation"><a href=/bookmarks.php>��������</a></td>
<? } ?>
<td align="center" class="navigation"><a href=/forums.php>�����</a></td>
<td align="center" class="navigation"><a href=/topten.php>Top 10</a></td>
<!--<td align="center" class="navigation"><a href=/log.php>Log</a></td>-->
<td align="center" class="navigation"><a href=/rules.php>�������</a></td>
<!--<td align="center" class="navigation"><a href=/faq.php>����</a></td>-->
<!--<td align="center" class="navigation"><a href=/links.php>������</a></td>-->
<? if ($CURUSER) { ?>
<td align="center" class="navigation"><a href=/staff.php>�������������</a></td>
<? } ?>
</tr>
</table>
</td>
</tr>
<tr>
<td valign="top" width="15%">
<?

if ($messages) {
                $message_in = "<span class=\"smallfont\">&nbsp;<a href=\"message.php\">$inboxpic</a> $messages " . sprintf($tracker_lang["new_pms"], $unread) . "</span>";
                if ($outmessages)
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> $outmessages</span>";
                else
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> 0</span>";
        }
        else {
                $message_in = "<span class=\"smallfont\">&nbsp;<a href=\"message.php\"><img height=\"14px\" style=\"border:none\" alt=\"���������\" title=\"���������\" src=\"pic/pn_inbox.gif\"></a> 0</span>";
                if ($outmessages)
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> $outmessages</span>";
                else
                        $message_out = "<span class=\"smallfont\">&nbsp;<a href=\"message.php?action=viewmailbox&box=-1\"><img height=\"14px\" style=\"border:none\" alt=\"" . "�����������" . "\" title=\"" . "�����������" . "\" src=\"pic/pn_sentbox.gif\"></a> 0</span>";
        }

/*if ($messages){
$message_in = "<a href=inbox.php>$inboxpic</a> $messages ($unread ���" .($unread > 1 ? "��" : "��") . ")";
if ($outmessages)
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages";
else
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0";
}
else
{
$message_in = "<a href=inbox.php><img height=14px style=border:none alt=inbox title=inbox src=pic/pn_inbox.gif></a> 0";
if ($outmessages)
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages";
else
$message_out = "&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0";
}*/

if ($CURUSER) {

$ss_r = mysql_query("SELECT * from stylesheets ORDER by id ASC") or die;
$ss_sa = array();
while ($ss_a = mysql_fetch_array($ss_r))
{
  $ss_id = $ss_a["id"];
  $ss_name = $ss_a["name"];
  $ss_sa[$ss_name] = $ss_id;
}
reset($ss_sa);
while (list($ss_name, $ss_id) = each($ss_sa))
{
  if ($ss_id == $CURUSER["stylesheet"]) $ss = " selected"; else $ss = "";
  $stylesheets .= "<option value=$ss_id$ss>$ss_name</option>\n";
}

	$userbar = "<a href=/my.php><img src=" . ( $CURUSER["avatar"] ? $CURUSER["avatar"] : "/pic/default_avatar.gif" ) . "  width=100 alt=������ title=������ border=0 /></a>
	<br>
	<font color=1900D1>�������:</font>&nbsp;$ratio<br>
	<font color=green>������:</font>&nbsp;$uped<br>
	<font color=red>������:</font>&nbsp;$downed<br>
	<font color=blue>��:</font>&nbsp;$message_in $message_out<br>
	��������:&nbsp;<img alt=\"������\" title=\"������\" src=\"./themes/StreamZone/images/arrowup.gif\">&nbsp;<font color=green><span class=\"smallfont\">$activeseed</span></font>&nbsp;<img alt=\"������\" title=\"������\" src=\"./themes/StreamZone/images/arrowdown.gif\">&nbsp;<font color=red><span class=\"smallfont\">$activeleech</span></font><br>
	�����:&nbsp;$datum[hours]:$datum[minutes]:$datum[seconds]<br>
	<font color=#FF6600>��� IP: " . $_SERVER["REMOTE_ADDR"] . "</font><br>
	�����: <select name=stylesheet onchange=\"window.location='/?styleid='+this.options[this.selectedIndex].value\">\n$stylesheets\n</select>
	<br>
	<center>[<a href=/logout.php>�����</a>]</center>
	";
} else {
	$userbar = '<center><form method="post" action="takelogin.php">
<br>
�����: <br>
<input type="text" size=20 name="username" /><br>
������: <br>

<input type="password" size=20 name="password" /><br>
<!--<input type=checkbox name=logout value="yes">���������<br>-->
<input type="submit" value="����!" class=btn><br><br>
</form></center>
<a class="menu" href="signup.php"><center><font color=red>�����������</font></center></a>';
}

if ($CURUSER['override_class'] != 255) $usrclass = "&nbsp;<img src=pic/warning.gif title=".get_user_class_name($CURUSER['class'])." alt=".get_user_class_name($CURUSER['class']).">&nbsp;";

elseif(get_user_class() >= UC_MODERATOR) $usrclass = "&nbsp;<a href=setclass.php><img src=pic/warning.gif title=\"".get_user_class_name($CURUSER['class'])."\" alt=\"".get_user_class_name($CURUSER['class'])."\" border=\"0\"></a>&nbsp;";

  blok_menu("<center>������, " . ( $CURUSER ? "<a href=$BASEURL/userdetails.php?id=" . $CURUSER["id"] . "><font color=white>" . $CURUSER["username"] . "</font></a>&nbsp;".$usrclass."&nbsp;" : "�����" ) . $medaldon . $warn , $userbar , "135");
  echo "<br>";

  $mainmenu = "&nbsp;<img src=./themes/StreamZone/images/folder.gif border=\"0\">&nbsp;<a href=\"/browse.php\">�����</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/folder.gif border=\"0\">&nbsp;<a href=\"/browse.php?incldead=4\">��� �������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/folder.gif border=\"0\">&nbsp;<a href=\"/viewrequests.php\">�������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/folder.gif border=\"0\">&nbsp;<a href=\"/viewoffers.php\">�����������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/folder.gif border=\"0\">&nbsp;<a href=\"/upload".(get_user_class() >= UC_UPLOADER ? "" : "app").".php\">���������</a>";

  blok_menu("<center>��������</center>", $mainmenu , "135");
  echo "<br>";

  $community = "&nbsp;<img src=./themes/StreamZone/images/users.gif border=\"0\">&nbsp;<a href=\"/phpbb2.php\">������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/users.gif border=\"0\">&nbsp;<a href=\"/users.php\">������������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/users.gif border=\"0\">&nbsp;<a href=\"/topten.php\">��� 10</a><br />";
  
  blok_menu("<center>����������</center>", $community , "135");
  echo "<br>";

if ($CURUSER) {

  $personal = "&nbsp;<img src=./themes/StreamZone/images/user.gif border=\"0\">&nbsp;<a href=\"/my.php\">������ ����������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/user.gif border=\"0\">&nbsp;<a href=\"/userdatais.php?id=".$CURUSER["id"]."\">��� �������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/user.gif border=\"0\">&nbsp;<a href=\"/bookmarks.php\">��� ��������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/user.gif border=\"0\">&nbsp;<a href=\"/friends.php\">������������ ����</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/user.gif border=\"0\">&nbsp;<a href=\"/mybonus.php\">��� �����</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/user.gif border=\"0\">&nbsp;<a href=\"/topten.php\">��� 10</a><br />";
  
  blok_menu("<center>������������</center>", $personal , "135");
  echo "<br>";

}

  $other = "&nbsp;<img src=./themes/StreamZone/images/smile.gif border=\"0\">&nbsp;<a href=\"/getrss.php\">RSS</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/pig.gif border=\"0\">&nbsp;<a href=\"/donate.php\">������������</a><br />";
  
  blok_menu("<center>������</center>", $other , "135");
  echo "<br>";

  $rules = "&nbsp;<img src=./themes/StreamZone/images/warning.gif border=\"0\">&nbsp;<a href=\"/rules.php\">�������</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/warning.gif border=\"0\">&nbsp;<a href=\"/faq.php\">����</a><br />";
  
  blok_menu("<center>�������</center>", $rules , "135");
  echo "<br>";

  $staff = "&nbsp;<img src=./themes/StreamZone/images/support.gif border=\"0\">&nbsp;<a href=\"/staff.php\">�������������</a><br />";
  
  blok_menu("<center>�������������</center>", $staff , "135");
  echo "<br>";

  $bt_clients = "&nbsp;<img src=./themes/StreamZone/images/up_down.gif border=\"0\">&nbsp;<a href=\"url=http://azureus.sourceforge.net/\">Azureus</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/up_down.gif border=\"0\">&nbsp;<a href=\"http://www.167bt.com/intl/\">BitSpirit</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/up_down.gif border=\"0\">&nbsp;<a href=\"http://www.bitcomet.com/\">BitComet</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/up_down.gif border=\"0\">&nbsp;<a href=\"http://www.bitconjurer.org/BitTorrent\">BitTorrent</a><br />"
           ."&nbsp;<img src=./themes/StreamZone/images/up_down.gif border=\"0\">&nbsp;<a href=\"http://www.utorrent.com\">�Torrent</a><br />";
  
  blok_menu("<center>��-�������</center>", $bt_clients , "135");
  echo "<br>";

?>
</td>

<td align=center valign=top class=outer style="padding-top: 10px; padding-bottom: 10px">
<?

if ($CURUSER) {
$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location=1 AND unread='yes'"); 
        $arr1 = mysql_fetch_row($res1); 
        $unread = $arr1[0]; 
        if ($unread) 
        { 
                print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background: red'>\n"); 
                print("<b><a href=message.php><font color=white>� ��� $unread �����(��) ���������(��)!</font></a></b>"); 
                print("</td></tr></table></p>\n"); 
        }
}

/*if ($unread)
{
  print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=red><tr><td style='padding: 10px; background: red'>\n");
  print("<b><a href=$BASEURL/inbox.php><font color=white>� ��� ���� $unread ����������" . ($unread > 1 ? "��" : "��") . " ��������" . ($unread > 1 ? "�" : "�") . "!</font></a></b>");
  print("</td></tr></table></p>\n");
}*/

if ($CURUSER['override_class'] != 255 && $CURUSER) // Second condition needed so that this box isn't displayed for non members/logged out members.
 {
  print("<p><table border=0 cellspacing=0 cellpadding=10 bgcolor=green><tr><td style='padding: 10px; background: green'>\n");
  print("<b><a href=$BASEURL/restoreclass.php><font color=white>�� ��������� ��� ����� ������ �������. ������� ���� ��� ��������.</font></a></b>");
  print("</td></tr></table></p>\n");
 }