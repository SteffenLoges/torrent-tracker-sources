<?
  print("</td></tr></table>\n");
  print("<table class=bottom width=100% border=0 cellspacing=0 cellpadding=0><tr valign=top>\n");
  print("<td width=49% class=bottom><div align=center><br><b>Powered by <a href=http://www.tbdev.net target=_blank>TBDev</a> ".TBVERSION.COPYRIGHT."<br />".HELPERS."</b></div></td>\n");
  print("</tr></table>\n");
  print("</body></html>\n");
?>