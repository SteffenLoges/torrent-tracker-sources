<?
$rconpassword = "mypass";
?>
