<?php
ob_start("ob_gzhandler");
require_once("include/bittorrent.php");

dbconn();
loggedinorreturn();
//curlocation($PHP_SELF);

stdhead("�����������");

begin_main_frame();

print("<h1 align=center>�����������</h1>\n");
if (get_user_class() > UC_POWER_USER) {
print("<p align=center><a href=offers.php?action=new>����������</a>");
}

$categ = $_GET["category"];
$offerorid = $_GET["offerorid"];
$sort = $_GET["sort"];
$search = $_GET["search"];
$filter = $_GET["filter"];

$search = " AND offers.name like '%$search%' ";


if ($sort == "votes")
$sort = " order by votes desc ";
else if ($sort == "name")
$sort = " order by name ";
else if ($sort == "comments")
$sort = " order by comments desc ";
else
$sort = " order by added desc ";


if ($offerorid <> NULL)
{
if (($categ <> NULL) && ($categ <> 0))
$categ = "WHERE offers.category = " . $categ . " AND offers.userid = " . $offerorid;
else
$categ = "WHERE offers.userid = " . $offerorid;
}

else if ($categ == 0)
$categ = '';
else
$categ = "WHERE offers.category = " . $categ;

$res = mysql_query("SELECT count(offers.id) FROM offers inner join categories on offers.category = categories.id inner join users on offers.userid = users.id $categ $filter") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];


$perpage = 50;

list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" . "category=" . $_GET["category"] . "&sort=" . $_GET["sort"] . "&" );

echo $pagertop;

$res = mysql_query("SELECT users.downloaded, users.uploaded, users.username, offers.id, offers.userid, offers.name, offers.added, offers.votes, categories.name as cat FROM offers inner join categories on offers.category = categories.id inner join users on offers.userid = users.id $categ $filter $search $sort $limit") or sqlerr();
$num = mysql_num_rows($res);

print("<form method=get action=viewoffers.php>");
?>
<select name="category">
<option value="0">(�������� ���)</option>
<?

$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

?>
<?= $catdropdown ?>
</select>
<?
print("<input type=submit align=center value=��������>");
print("</form><br />");

print("<form method=get action=viewoffers.php>");
print("<b>������ �����������: </b><input type=text size=40 name=search>");
print("&nbsp;<input type=submit align=center value=������>\n");
print("</form><p></p><br />");

print("<table border=1 width=750 cellspacing=0 cellpadding=5>\n");
print("<tr><td class=colhead align=center width=42>���.</td><td class=colhead align=left><a href=". $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=name class=altlink_white>�����������</a></td><td class=colhead align=center width=150><a href=" . $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=added class=altlink_white>���������</a></td><td class=colhead align=center><a href=" . $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=comments class=altlink_white>�����������</a></td><td class=colhead align=center>����������</td><td class=colhead align=center><a href=" . $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=votes class=altlink_white>�������</a></td></tr>\n");

for ($i = 0; $i < $num; ++$i)
{
$arr = mysql_fetch_assoc($res);
if ($arr["downloaded"] > 0)
{
$ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
$ratio = "<font color=" . get_ratio_color($ratio) . "><b>$ratio</b></font>";
}
else if ($arr["uploaded"] > 0)
$ratio = "Inf.";
else
$ratio = "---";
if ($arr["votes"] == 0) $zvote = "$arr[votes]"; else $zvote = "<b>$arr[votes]</b>";


$url = "offers.php?action=edit&id=$arr[id]";
if (isset($_GET["returnto"])) {
$addthis = "&amp;returnto=" . urlencode($_GET["returnto"]);
$url .= $addthis;
$keepget .= $addthis;
}
$editlink = "a href=\"$url\" class=\"sublink\"";

if ($CURUSER["id"] != $num["userid"] && get_user_class() < UC_MODERATOR){
$zedit = "";
} else {
$zedit = "&nbsp;<$editlink><img border=\"0\" src=\"/pic/pen.gif\" alt=\"�������������\" title=\"�������������\" /></a>";
}


$addedby = "<td style='padding: 0px' align=center ><a href=userdetails.php?id=$arr[userid]><b>$arr[username] ($ratio)</b></a></td>";
$rez = mysql_query("select comments from offers where id=$arr[id]");
$comm = mysql_fetch_array($rez);
if ($comm[comments] == 0)
$comment = "0";
else
$comment = "<a href=offers.php?id=$arr[id]#startcomments><b>$comm[comments]</b></a>";

$crez = mysql_query("select name as cat_name, image as cat_pic from categories where name='$arr[cat]'") or sqlerr(__FILE__,__LINE__);
$crow = mysql_fetch_assoc($crez);
print("<tr><td align=center style='padding: 0px'>");
if (isset($crow["cat_name"])) {
if (isset($crow["cat_pic"]) && $crow["cat_pic"] != "")
print("<img border=\"0\" src=\"$pic_base_url" . $crow["cat_pic"] . "\" alt=\"" . $crow["cat_name"] . "\" title=\"" . $crow["cat_name"] . "\" />");
else
print($crow["cat_name"]);
print("</a>");
}
else
print("-");
print("</td>\n");
print("<td align=left ><a href=offers.php?id=$arr[id]><b>$arr[name]</b></a>$zedit</td>" .
"<td align=center >$arr[added]</td><td align=center >$comment</td>$addedby<td align=center><a href=votesview.php?offerid=$arr[id]>$zvote<br><a href=offers.php?action=vote&voteid=$arr[id]>����������</td></tr>\n");
}

print("</table>\n");
echo $pagerbottom;

end_main_frame();

stdfoot();
die;

?>