<?
  require "include/bittorrent.php";
  dbconn(false);

  loggedinorreturn();

  // delete items older than a week
  $secs = 24 * 60 * 60;
  stdhead("��� �����");
  mysql_query("DELETE FROM sitelog WHERE " . gmtime() . " - UNIX_TIMESTAMP(added) > $secs") or sqlerr(__FILE__, __LINE__);
  $res = mysql_query("SELECT added, txt FROM sitelog ORDER BY added DESC") or sqlerr(__FILE__, __LINE__);
  print("<h1>��� �����</h1>\n");
  if (mysql_num_rows($res) == 0)
    print("<b>��� ����</b>\n");
  else
  {
    print("<table border=1 cellspacing=0 cellpadding=5>\n");
    print("<tr><td class=colhead align=left>����</td><td class=colhead align=left>�����</td><td class=colhead align=left>��������</td></tr>\n");
    while ($arr = mysql_fetch_assoc($res))
    {
      $date = substr($arr['added'], 0, strpos($arr['added'], " "));
      $time = substr($arr['added'], strpos($arr['added'], " ") + 1);
      print("<tr><td>$date</td><td>$time</td><td align=left>$arr[txt]</td></tr>\n");
    }
    print("</table>");
  }
  print("<p>����� ������� � GMT.</p>\n");
  stdfoot();
  
?>