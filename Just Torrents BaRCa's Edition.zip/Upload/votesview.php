<?

require "include/bittorrent.php";

dbconn(false);

loggedinorreturn();

if ($_GET[requestid])
{
        $requestid = $_GET[requestid];
        $res2 = mysql_query("SELECT COUNT(addedrequests.id) FROM addedrequests INNER JOIN users ON addedrequests.userid = users.id INNER JOIN requests ON addedrequests.requestid = requests.id WHERE addedrequests.requestid =$requestid") or die(mysql_error());
        $row = mysql_fetch_array($res2);
        $count = $row[0];
        $perpage = 50;
         list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" );
         $res = mysql_query("SELECT users.id as userid,users.username, users.downloaded, users.uploaded, users.class, requests.id as requestid, requests.request FROM addedrequests INNER JOIN users ON addedrequests.userid = users.id INNER JOIN requests ON addedrequests.requestid = requests.id WHERE addedrequests.requestid =$requestid $limit") or sqlerr();
         stdhead("������������");
         $res2 = mysql_query("SELECT request FROM requests WHERE id=$requestid");
         $arr2 = mysql_fetch_assoc($res2);

         print("<h1>������������ ��� <a href=requests.php?id=$requestid><b>$arr2[request]</b></a></h1>");
         print("<p>���������� �� ���� <a href=requests.php?action=vote&voteid=$requestid><b>������</b></a></p>");

         echo $pagertop;

         if (mysql_num_rows($res) == 0)
                 print("<p align=center><b>������ �� �������</b></p>\n");
         else
         {
                 print("<table border=1 cellspacing=0 cellpadding=5>\n");
                 print("<tr><td class=colhead>���</td><td class=colhead align=left>��������</td><td class=colhead align=left>������</td></tr>\n");
                 while ($arr = mysql_fetch_assoc($res))
                 {
                         if ($arr["downloaded"] > 0)
                         {
                                 $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
                                 $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
                         }
                         elseif ($arr["uploaded"] > 0)
                                 $ratio = "Inf.";
                         else
                                 $ratio = "---";
                         $uploaded =mksize($arr["uploaded"]);
                         $downloaded = mksize($arr["downloaded"]);

                         print("<tr><td><a href=userdetails.php?id=$arr[userid]><b>" . get_user_class_color($arr["class"],$arr["username"]) . "($ratio)</b></a></td><td align=left>$uploaded</td><td align=left>$downloaded</td></tr>\n");
                 }
                 print("</table>\n");
         }
}
if ($_GET[offerid])
{
        $offerid = $_GET[offerid];
        $res2 = mysql_query("SELECT COUNT(offervotes.id) FROM offervotes INNER JOIN users ON offervotes.userid = users.id INNER JOIN offers ON offervotes.offerid = offers.id WHERE offervotes.offerid =$offerid") or sqlerr(__FILE__,__LINE__);
        $row = mysql_fetch_array($res2);
        $count = $row[0];
        $perpage = 50;
        list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" );

        $res = mysql_query("SELECT users.id as userid, users.username, users.downloaded, users.uploaded, users.class, offers.id AS offerid, offers.name FROM offervotes INNER JOIN users ON offervotes.userid = users.id INNER JOIN offers ON offervotes.offerid = offers.id WHERE offervotes.offerid =$offerid $limit") or sqlerr(__FILE__,__LINE__);
        stdhead("������������");
        $res2 = mysql_query("SELECT name FROM offers WHERE id=$offerid");
        $arr2 = mysql_fetch_assoc($res2);
        print("<h1>������������ ��� <a href=offers.php?id=$offerid><b>$arr2[name]</b></a></h1>");
        print("<p>���������� �� ��� <a href=offers.php?action=vote&voteid=$offerid><b>�����������</b></a></p>");

        echo $pagertop;

        if (mysql_num_rows($res) == 0)
                print("<p align=center><b>������ �� �������</b></p>\n");
        else
        {
                print("<table border=1 cellspacing=0 cellpadding=5>\n");
                print("<tr><td class=colhead>���</td><td class=colhead align=left>��������</td><td class=colhead align=left>������</td></tr>\n");
                while ($arr = mysql_fetch_assoc($res))
                {
                        if ($arr["downloaded"] > 0)
                        {
                                $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
                                $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
                        }
                        elseif ($arr["uploaded"] > 0)
                                $ratio = "Inf.";
                        else
                                $ratio = "---";
                        $uploaded =mksize($arr["uploaded"]);
                        $downloaded = mksize($arr["downloaded"]);
                        print("<tr><td><a href=userdetails.php?id=$arr[userid]><b>" . get_user_class_color($arr["class"],$arr["username"]) . "($ratio)</b></a></td><td align=left>$uploaded</td><td align=left>$downloaded</td></tr>\n");
                }
                print("</table>\n");
        }
}


stdfoot();

?>