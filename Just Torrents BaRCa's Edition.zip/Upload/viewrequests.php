<?php
ob_start("ob_gzhandler");
require_once("include/bittorrent.php");

dbconn();
loggedinorreturn();

if ($_GET["delreq"])
{
        if (get_user_class() >= UC_MODERATOR)
        {
                if (empty($_GET["delreq"]))
                        stderr("������","�� ���������� ������ �����.");
                mysql_query("DELETE FROM requests WHERE id IN (" . implode(", ", $_GET[delreq]) . ")");
                mysql_query("DELETE FROM addedrequests WHERE requestid IN (" . implode(", ", $_GET[delreq]) . ")");
                mysql_query("DELETE FROM comments WHERE request IN (" . implode(", ", $_GET[delreq]) . ")");
                mysql_query("DELETE FROM checkcomm WHERE checkid IN (" . implode(", ", $_GET[delreq]) . ") AND req = 1");
                stderr("�������","������ ������� ������.<br><a href=viewrequests.php>� ������ ��������</a>");
        }
        else
                stderr("������","� ��� ��� ���� ��� �������� ��������");
}


stdhead("������ ��������");

begin_main_frame();

print("<h1>������ ��������</h1>\n");
print("<p><a href=requests.php?action=new>������� ������</a>&nbsp;&nbsp;<a href=viewrequests.php?requestorid=$CURUSER[id]>���������� ��� �������</a></p>\n");

print("<p><a href=". $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&sort=" . $_GET[sort] . "&filter=true>�������� �����������</a></p>\n");
$categ = $_GET["category"];
$requestorid = $_GET["requestorid"];
$sort = $_GET["sort"];
$search = $_GET["search"];
$filter = $_GET["filter"];

$search = " AND requests.request like '%$search%' ";


if ($sort == "votes")
       $sort = " order by hits desc ";
elseif ($sort == "request")
       $sort = " order by request ";
elseif ($sort == "added")
       $sort = "order by added desc ";
elseif ($sort == "comm")
       $sort = "order by comments desc ";
else
       $sort = " order by added desc ";


if ($filter == "true")
       $filter = " AND requests.filledby = 0 ";
else
       $filter = "";


if ($requestorid <> NULL)
       {
       if (($categ <> NULL) && ($categ <> 0))
 $categ = "WHERE requests.cat = " . $categ . " AND requests.userid = " . $requestorid;
       else
 $categ = "WHERE requests.userid = " . $requestorid;
       }

else if ($categ == 0)
       $categ = '';
else
       $categ = "WHERE requests.cat = " . $categ;


$res = mysql_query("SELECT count(requests.id) FROM requests inner join categories on requests.cat = categories.id inner join users on requests.userid = users.id  $categ $filter $search") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];


$perpage = 50;

 list($pagertop, $pagerbottom, $limit) = pager($perpage, $count, $_SERVER["PHP_SELF"] ."?" . "category=" . $_GET["category"] . "&sort=" . $_GET["sort"] . "&" );

echo $pagertop;

$res = mysql_query("SELECT users.downloaded, users.uploaded, users.username, requests.filled, requests.filledby, requests.id, requests.userid, requests.request, requests.added, requests.hits, requests.comments, categories.name as cat_name, categories.image as cat_img FROM requests inner join categories on requests.cat = categories.id inner join users on requests.userid = users.id  $categ $filter $search $sort $limit") or sqlerr();
$num = mysql_num_rows($res);



print("<form method=get action=viewrequests.php>");
?>
<select name="category">
<option value="0">(�������� ���)</option>
<?

$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
   $catdropdown .= "<option value=\"" . $cat["id"] . "\"";
   $catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

?>
<?= $catdropdown ?>
</select>
<?
print("<input type=submit align=center value=��������>\n");
print("</form>\n<p></p>");

print("<form method=get action=viewrequests.php>");
print("<b>������ �������: </b><input type=text size=40 name=search>");
print("&nbsp;<input type=submit align=center value=������>\n");
print("</form><p></p><br />");

print("<form method=get action=$SERVER[PHP_SELF]>\n");
print("<table border=1 width=830 cellspacing=0 cellpadding=4>\n");
print("<tr><td class=\"colhead\" align=\"center\">���</td><td class=colhead align=left><a href=". $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=request class=altlink_white>������</a></td><td class=colhead align=center width=150><a href=" . $_SERVER[PHP_SELF] ."?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=added class=altlink_white>��������</a></td><td class=colhead align=center>��������</td><td class=colhead align=center>��������?</td><td class=colhead align=center>��������</td><td class=colhead align=center><a href=" . $_SERVER[PHP_SELF] . "?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=votes class=altlink_white>�������</a></td><td class=colhead align=center><a href=" . $_SERVER[PHP_SELF] . "?category=" . $_GET[category] . "&filter=" . $_GET[filter] . "&sort=comm class=altlink_white>����.</a></td>" .  (get_user_class() >= UC_MODERATOR?"<td class=colhead align=center>�������</td>": "") . "</tr>\n");
for ($i = 0; $i < $num; ++$i)
{



 $arr = mysql_fetch_assoc($res);

if ($arr["downloaded"] > 0)
   {
     $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
     $ratio = "<font color=" . get_ratio_color($ratio) . "><b>$ratio</b></font>";
   }
   else if ($arr["uploaded"] > 0)
       $ratio = "Inf.";
   else
       $ratio = "---";


$res2 = mysql_query("SELECT username from users where id=" . $arr[filledby]);
$arr2 = mysql_fetch_assoc($res2);
if ($arr2[username])
       $filledby = $arr2[username];
else
       $filledby = " ";
$addedby = "<td style='padding: 0px' align=center><a href=userdetails.php?id=$arr[userid]><b>$arr[username] ($ratio)</b></a></td>\n";
$filled = $arr[filled];
if ($filled != '')
       $filled = "<a href=$arr[filled]><font color=green><b>��</b></font></a>\n";
else
       $filled = "<a href=requests.php?id=$arr[id]><font color=red><b>���</b></font></a>\n";

if ($arr[comments] == 0)
$comment = "0";
else
$comment = "<a href=requests.php?id=$arr[id]#startcomments><b>$arr[comments]</b></a>";


 print("<tr><td style='padding: 0px' width=62><img border=\"0\" src=\"$pic_base_url" . $arr["cat_img"] . "\" alt=\"" . $arr["cat_name"] . "\" /></td>\n<td align=left><a href=requests.php?id=$arr[id]><b>$arr[request]</b></a></td>\n<td align=center>$arr[added]</td>$addedby<td align=center>$filled</td>\n<td align=center><a href=userdetails.php?id=$arr[filledby]><b>$arr2[username]</b></a></td>\n<td align=center><a href=votesview.php?requestid=$arr[id]><b>$arr[hits]</b></a></td>\n<td align=center>$comment</td>" .  (get_user_class() >= UC_MODERATOR?"<td align=center><input type=\"checkbox\" name=\"delreq[]\" value=\"" . $arr[id] . "\" /></td>": "") . "</tr>\n");
}

print("</table>\n");
if (get_user_class() >= UC_MODERATOR)
print("<p><input type=submit value=�������></p>");
print("</form>");

echo $pagerbottom;
end_main_frame();
stdfoot();
die;

?>