<?
require_once("include/bittorrent.php");
dbconn();

loggedinorreturn();
/*
parked();
*/

$userid = $CURUSER["id"];
$torrentid = $_POST["torrentid"];
if (isset($userid) && isset($torrentid))
{
$res = mysql_query("INSERT INTO thanks (torrentid, userid) VALUES ($torrentid, $userid)");
header("Location: $BASEURL/details.php?id=$torrentid&thanks=1");
}
else {
header("Location: $BASEURL/browse.php");
}
?>