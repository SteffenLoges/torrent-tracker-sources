<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");

function getagent($httpagent, $peer_id="")
{
	if (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_B([0-9][0-9|*])(.+)$)/", $httpagent, $matches))
	return "Azureus/$matches[1]";
	elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_CVS)/", $httpagent, $matches))
	return "Azureus/$matches[1]";
	elseif (preg_match("/^Java\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
	return "Azureus/<2.0.7.0";
	elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
	return "Azureus/$matches[1]";
	elseif (preg_match("/BitTorrent\/S-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
	return "Shadow's/$matches[1]";
	elseif (preg_match("/BitTorrent\/U-([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
	return "UPnP/$matches[1]";
	elseif (preg_match("/^BitTor(rent|nado)\\/T-(.+)$/", $httpagent, $matches))
	return "BitTornado/$matches[2]";
	elseif (preg_match("/^BitTornado\\/T-(.+)$/", $httpagent, $matches))
	return "BitTornado/$matches[1]";
	elseif (preg_match("/^BitTorrent\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
	return "ABC/$matches[1]";
	elseif (preg_match("/^ABC ([0-9]+\.[0-9]+(\.[0-9]+)*)\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
	return "ABC/$matches[1]";
	elseif (preg_match("/^Python-urllib\/.+?, BitTorrent\/([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
	return "BitTorrent/$matches[1]";
	elseif (ereg("^BitTorrent\/BitSpirit$", $httpagent))
	return "BitSpirit";
	elseif (ereg("^DansClient", $httpagent))
	return "XanTorrent";
	elseif (preg_match("/^BitTorrent\/brst(.+)/", $httpagent, $matches))
	return "Burst/$matches[1]";
	elseif (preg_match("/^RAZA (.+)$/", $httpagent, $matches))
	return "Shareaza/$matches[1]";
	elseif (preg_match("/Rufus\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
	return "Rufus/$matches[1]";
	elseif (preg_match("/^BitTorrent\\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
{
	if(substr($peer_id, 0, 6) == "exbc\08")
	return "BitComet/0.56";
	elseif(substr($peer_id, 0, 6) == "exbc\09")
	return "BitComet/0.57";
	elseif(substr($peer_id, 0, 6) == "exbc\0:")
	return "BitComet/0.58";
	elseif(substr($peer_id, 0, 8) == "-BC0059-")
	return "BitComet/0.59";
	elseif(substr($peer_id, 0, 8) == "-BC0060-")
	return "BitComet/0.60";
	elseif(substr($peer_id, 0, 8) == "-BC0061-")
	return "BitComet/0.61";
	elseif(substr($peer_id, 0, 8) == "-BC0062-")
	return "BitComet/0.62";
	elseif(substr($peer_id, 0, 8) == "-BC0063-")
	return "BitComet/0.63";
	elseif(substr($peer_id, 0, 8) == "-BC0064-")
	return "BitComet/0.64";
	elseif(substr($peer_id, 0, 8) == "-BC0065-")
	return "BitComet/0.65";
	elseif(substr($peer_id, 0, 8) == "-BC0066-")
	return "BitComet/0.66";
	elseif(substr($peer_id, 0, 8) == "-BC0067-")
	return "BitComet/0.67";
	elseif(substr($peer_id, 0, 8) == "-BC0068-")
	return "BitComet/0.68";
	elseif(substr($peer_id, 0, 7) == "exbc\0L")
	return "BitLord/1.0";
	else
	return "BitTorrent/$matches[1]";
}
	elseif (preg_match("/^Python-urllib\\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
	return "G3 Torrent";
	elseif (preg_match("/MLdonkey( |\/)([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
	return "MLdonkey$matches[1]";
	elseif (preg_match("/ed2k_plugin v([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
	return "eDonkey/$matches[1]";
	else
	return "---";
}

function dltable($name, $arr, $torrent)
{

	global $CURUSER;
	$s = "<b>" . count($arr) . " $name</b>\n";
	if (!count($arr))
		return $s;
	$s .= "\n";
	$s .= "<table width=100% class=main border=1 cellspacing=0 cellpadding=5>\n";
	$s .= "<tr><td class=colhead>����/IP</td>" .
          "<td class=colhead align=center>����&nbsp;������</td>".
          "<td class=colhead align=right>������</td>".
          "<td class=colhead align=right>������</td>".
          "<td class=colhead align=right>������</td>" .
          "<td class=colhead align=right>�������</td>" .
          "<td class=colhead align=right>����.</td>" .
          "<td class=colhead align=right>���������</td>" .
          "<td class=colhead align=right>���������</td>" .
          "<td class=colhead align=right>�����������</td>" .
          "<td class=colhead align=left>������</td></tr>\n";
	$now = time();
	$moderator = (isset($CURUSER) && get_user_class() >= UC_MODERATOR);
$mod = get_user_class() >= UC_MODERATOR;
	foreach ($arr as $e) {


                // user/ip/port
                // check if anyone has this ip
                ($unr = mysql_query("SELECT username, privacy FROM users WHERE id=$e[userid] ORDER BY last_access DESC LIMIT 1")) or die;
                $una = mysql_fetch_array($unr);
				if ($una["privacy"] == "strong") continue;
		$s .= "<tr>\n";
                if ($una["username"])
                  $s .= "<td><a href=userdetails.php?id=$e[userid]><b>$una[username]</b></a></td>\n";
                else
                  $s .= "<td>" . ($mod ? $e["ip"] : preg_replace('/\.\d+$/', ".xxx", $e["ip"])) . "</td>\n";
		$secs = max(1, ($now - $e["st"]) - ($now - $e["la"]));
		$revived = $e["revived"] == "yes";
        $s .= "<td align=center>" . ($e[connectable] == "yes" ? "<font color=green>��</font>" : "<font color=red>���</font>") . "</td>\n";
		$s .= "<td align=right>" . mksize($e["uploaded"]) . "</td>\n";
		$s .= "<td align=right><nobr>" . mksize(($e["uploaded"] - $e["uploadoffset"]) / $secs) . "/s</nobr></td>\n";
		$s .= "<td align=right>" . mksize($e["downloaded"]) . "</td>\n";
		if ($e["seeder"] == "no")
			$s .= "<td align=right><nobr>" . mksize(($e["downloaded"] - $e["downloadoffset"]) / $secs) . "/s</nobr></td>\n";
		else
			$s .= "<td align=right><nobr>" . mksize(($e["downloaded"] - $e["downloadoffset"]) / max(1, $e["finishedat"] - $e[st])) .	"/s</nobr></td>\n";
                if ($e["downloaded"])
				{
                  $ratio = floor(($e["uploaded"] / $e["downloaded"]) * 1000) / 1000;
                    $s .= "<td align=\"right\"><font color=" . get_ratio_color($ratio) . ">" . number_format($ratio, 3) . "</font></td>\n";
				}
	               else
                  if ($e["uploaded"])
                    $s .= "<td align=right>Inf.</td>\n";
                  else
                    $s .= "<td align=right>---</td>\n";
		$s .= "<td align=right>" . sprintf("%.2f%%", 100 * (1 - ($e["to_go"] / $torrent["size"]))) . "</td>\n";
		$s .= "<td align=right>" . mkprettytime($now - $e["st"]) . "</td>\n";
		$s .= "<td align=right>" . mkprettytime($now - $e["la"]) . "</td>\n";
		$s .= "<td align=left>" . htmlspecialchars(getagent($e["agent"])) . "</td>\n";
		$s .= "</tr>\n";
	}
	$s .= "</table>\n";
	return $s;
}

dbconn(false);

loggedinorreturn();

$id = 0 + $_GET["id"];

if (!isset($id) || !$id)
	die();

$res = mysql_query("SELECT torrents.seeders, torrents.banned, torrents.leechers, torrents.info_hash, torrents.filename, UNIX_TIMESTAMP() - UNIX_TIMESTAMP(torrents.last_action) AS lastseed, torrents.numratings, torrents.name, IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, torrents.owner, torrents.save_as, torrents.descr, torrents.visible, torrents.size, torrents.added, torrents.views, torrents.hits, torrents.times_completed, torrents.id, torrents.type, torrents.numfiles, torrents.image1, torrents.image2, categories.name AS cat_name, users.username FROM torrents LEFT JOIN categories ON torrents.category = categories.id LEFT JOIN users ON torrents.owner = users.id WHERE torrents.id = $id")
	or sqlerr();
$row = mysql_fetch_array($res);

$owned = $moderator = 0;
	if (get_user_class() >= UC_MODERATOR)
		$owned = $moderator = 1;
	elseif ($CURUSER["id"] == $row["owner"])
		$owned = 1;
//}

if (!$row || ($row["banned"] == "yes" && !$moderator))
	stderr("������", "������ �������� �� ����������.");
else {
	if ($_GET["hit"]) {
		mysql_query("UPDATE torrents SET views = views + 1 WHERE id = $id");
		if ($_GET["tocomm"])
			header("Location: $BASEURL/details.php?id=$id&page=0#startcomments");
		elseif ($_GET["filelist"])
			header("Location: $BASEURL/details.php?id=$id&filelist=1#filelist");
		elseif ($_GET["toseeders"])
			header("Location: $BASEURL/details.php?id=$id&dllist=1#seeders");
		elseif ($_GET["todlers"])
			header("Location: $BASEURL/details.php?id=$id&dllist=1#leechers");
		else
			header("Location: $BASEURL/details.php?id=$id");
		exit();
	}

	if (!isset($_GET["page"])) {
		stdhead("������ �������� \"" . $row["name"] . "\"");

		if ($CURUSER["id"] == $row["owner"] || get_user_class() >= UC_MODERATOR)
			$owned = 1;
		else
			$owned = 0;

		$spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

		if ($_GET["uploaded"]) {
			print("<h2>�������� �������!</h2>\n");
			print("<p>�� ������ �������� �������. <b>������</b> ��� ������� �� ����� ����� ���� �� �� ������� ���������!</p>\n");
		}
		elseif ($_GET["edited"]) {
			print("<h2>�������� �������������!</h2>\n");
			if (isset($_GET["returnto"]))
				print("<p><b><a href=\"" . htmlspecialchars($_GET["returnto"]) . "\">�����</a></b></p>\n");
		}
		elseif (isset($_GET["searched"])) {
			print("<h2>Your search for \"" . htmlspecialchars($_GET["searched"]) . "\" gave a single result:</h2>\n");
		}
		elseif ($_GET["rated"]) {
			print("<h2>����� ��������!</h2>\n");
		}
		elseif ($_GET["thanks"])
 			print("<h2>������� ���������!</h2>\n");

$s=$row["name"];
		print("<h1>$s <a href=\"bookmark.php?torrent=$row[id]\"><img border=\"0\" src=\"/pic/bookmark.png\" alt=\"� ��������\" title=\"� ��������\"></a></h1>\n");
                print("<table width=\"750\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\n");

		$url = "edit.php?id=" . $row["id"];
		if (isset($_GET["returnto"])) {
			$addthis = "&amp;returnto=" . urlencode($_GET["returnto"]);
			$url .= $addthis;
			$keepget .= $addthis;
		}
		$editlink = "a href=\"$url\" class=\"sublink\"";

		$s = "<b>" . htmlspecialchars($row["name"]) . "</b>";
		if ($owned)
			$s .= " $spacer<$editlink>[�������������]</a>";
		tr("��������", $s, 1);

		print("<tr><td class=rowhead width=1%>�������</td><td width=99% align=left><a class=\"index\" href=\"download.php/$id/" . rawurlencode($row["filename"]) . "\">" . htmlspecialchars($row["filename"]) . "</a></td></tr>");
//		tr("Downloads&nbsp;as", $row["save_as"]);

		function hex_esc($matches) {
			return sprintf("%02x", ord($matches[0]));
		}
		tr("��� ������", preg_replace_callback('/./s', "hex_esc", hash_pad($row["info_hash"])));
		if ($row["image1"] != "" OR $row["image2"] != "") {
  		if ($row["image1"] != "")
    		$img1 = "<a href='viewimage.php?pic=$row[image1]'><img border='0' src='thumbnail.php?$row[image1]'></a>";
  		if ($row["image2"] != "")
    		$img2 = "<a href='viewimage.php?pic=$row[image2]'><img border='0' src='thumbnail.php?$row[image2]'></a>";
  		tr("��������", $img1 . "&nbsp&nbsp" . $img2, 1);
 }
		if (!empty($row["descr"]))
			tr("��������", str_replace(array("\n", "  "), array("<br>\n", "&nbsp; "), format_comment(htmlspecialchars($row["descr"]))), 1);
// }
/*if (get_user_class() >= UC_POWER_USER && $row["nfosz"] > 0)
  print("<tr><td class=rowhead>NFO</td><td align=left><a href=viewnfo.php?id=$row[id]><b>View NFO</b></a> (" .
     mksize($row["nfosz"]) . ")</td></tr>\n");*/
		if ($row["visible"] == "no")
			tr("�������", "<b>���</b> (�������)", 1);
		if ($moderator)
			tr("�������", ($row["banned"] == 'no' ? '���' : '��') );

		if (isset($row["cat_name"]))
			tr("���", $row["cat_name"]);
		else
			tr("���", "(�� �������)");

		tr("���������", "��������� ��� ��� ����� " . mkprettytime($row["lastseed"]) . " �����");
		tr("������",mksize($row["size"]) . " (" . number_format($row["size"]) . " ����)");

		$s = "";
		$s .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td valign=\"top\" class=embedded>";
		if (!isset($row["rating"])) {
			if ($minvotes > 1) {
				$s .= "none yet (needs at least $minvotes votes and has got ";
				if ($row["numratings"])
					$s .= "only " . $row["numratings"];
				else
					$s .= "none";
				$s .= ")";
			}
			else
				$s .= "��� �������";
		}
		else {
			$rpic = ratingpic($row["rating"]);
			if (!isset($rpic))
				$s .= "invalid?";
			else
				$s .= "$rpic (" . $row["rating"] . " �� 5 � " . $row["numratings"] . " ��������)";
		}
		$s .= "\n";
		$s .= "</td><td class=embedded>$spacer</td><td valign=\"top\" class=embedded>";
		if (!isset($CURUSER))
			$s .= "(<a href=\"login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;nowarn=1\">Log in</a> to rate it)";
		else {
			$ratings = array(
					5 => "�������!",
					4 => "������",
					3 => "���������",
					2 => "�����",
					1 => "������!",
			);
			if (!$owned || $moderator) {
				$xres = mysql_query("SELECT rating, added FROM ratings WHERE torrent = $id AND user = " . $CURUSER["id"]);
				$xrow = mysql_fetch_array($xres);
				if ($xrow)
					$s .= "(�� ������� ���� ������� ��� \"" . $xrow["rating"] . " - " . $ratings[$xrow["rating"]] . "\")";
				else {
					$s .= "<form method=\"post\" action=\"takerate.php\"><input type=\"hidden\" name=\"id\" value=\"$id\" />\n";
					$s .= "<select name=\"rating\">\n";
					$s .= "<option value=\"0\">�������������</option>\n";
					foreach ($ratings as $k => $v) {
						$s .= "<option value=\"$k\">$k - $v</option>\n";
					}
					$s .= "</select>\n";
					$s .= "<input type=\"submit\" value=\"�����!\" />";
					$s .= "</form>\n";
				}
			}
		}
		$s .= "</td></tr></table>";
		tr("�������", $s, 1);

		tr("��������", $row["added"]);
		tr("����������", $row["views"]);
		tr("����", $row["hits"]);
		tr("�������", $row["times_completed"] . " ���");

		$keepget = "";
		$uprow = (isset($row["username"]) ? ("<a href=userdetails.php?id=" . $row["owner"] . "><b>" . htmlspecialchars($row["username"]) . "</b></a>") : "<i>������</i>");
/*
		if ($owned)
			$uprow .= " $spacer<$editlink><b>[�������������]</b></a>";
*/
		tr("�����", $uprow, 1);

		if ($row["type"] == "multi") {
			if (!$_GET["filelist"])
				tr("������<br /><a href=\"details.php?id=$id&amp;filelist=1$keepget#filelist\" class=\"sublink\">[���������� ������]</a>", $row["numfiles"] . " ������", 1);
			else {
				tr("������", $row["numfiles"] . " ������", 1);

				$s = "<table class=main border=\"1\" cellspacing=0 cellpadding=\"5\">\n";

				$subres = mysql_query("SELECT * FROM files WHERE torrent = $id ORDER BY id");
$s.="<tr><td class=colhead>����</td><td class=colhead align=right>������</td></tr>\n";
				while ($subrow = mysql_fetch_array($subres)) {
					$s .= "<tr><td>" . $subrow["filename"] .
                            "</td><td align=\"right\">" . mksize($subrow["size"]) . "</td></tr>\n";
				}

				$s .= "</table>\n";
				tr("<a name=\"filelist\">������ ������</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[������� ������]</a>", $s, 1);
			}
		}

		if (!$_GET["dllist"]) {
			/*
			$subres = mysql_query("SELECT seeder, COUNT(*) FROM peers WHERE torrent = $id GROUP BY seeder");
			$resarr = array(yes => 0, no => 0);
			$sum = 0;
			while ($subrow = mysql_fetch_array($subres)) {
				$resarr[$subrow[0]] = $subrow[1];
				$sum += $subrow[1];
			}
			tr("Peers<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[See full list]</a>", $resarr["yes"] . " seeder(s), " . $resarr["no"] . " leecher(s) = $sum peer(s) total", 1);
			*/
			tr("���������<br /><a href=\"details.php?id=$id&amp;dllist=1$keepget#seeders\" class=\"sublink\">[���������� ������]</a>", $row["seeders"] . " ���������, " . $row["leechers"] . " �������� = " . ($row["seeders"] + $row["leechers"]) . " ����������", 1);
		}
		else {
			$downloaders = array();
			$seeders = array();
			$subres = mysql_query("SELECT seeder, finishedat, downloadoffset, uploadoffset, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, agent, UNIX_TIMESTAMP(last_action) AS la, userid FROM peers WHERE torrent = $id") or sqlerr();
			while ($subrow = mysql_fetch_array($subres)) {
				if ($subrow["seeder"] == "yes")
					$seeders[] = $subrow;
				else
					$downloaders[] = $subrow;
			}

			function leech_sort($a,$b) {
                                if ( isset( $_GET["usort"] ) ) return seed_sort($a,$b);				
                                $x = $a["to_go"];
				$y = $b["to_go"];
				if ($x == $y)
					return 0;
				if ($x < $y)
					return -1;
				return 1;
			}
			function seed_sort($a,$b) {
				$x = $a["uploaded"];
				$y = $b["uploaded"];
				if ($x == $y)
					return 0;
				if ($x < $y)
					return 1;
				return -1;
			}

			usort($seeders, "seed_sort");
			usort($downloaders, "leech_sort");

			tr("<a name=\"seeders\">���������</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[������� ������]</a>", dltable("���������", $seeders, $row), 1);
			tr("<a name=\"leechers\">��������</a><br /><a href=\"details.php?id=$id$keepget\" class=\"sublink\">[������� ������]</a>", dltable("��������", $downloaders, $row), 1);
		}
		        //.torrent file info link
                if (get_user_class() >= UC_MODERATOR)
                {
                tr("������ � �������", "<a href=\"torrent_info.php?id=$id\">������ � �������</a>", 1);
                }

$torrentid = $_GET["id"];
   $thanks_sql = mysql_query("SELECT * FROM thanks where torrentid=$torrentid");
   $thanks_all = mysql_numrows($thanks_sql);
   if ($thanks_all) {
   while($rows_t = mysql_fetch_array($thanks_sql)) {
   $thanks_userid = $rows_t["userid"];
   $user_sql = mysql_query("SELECT * FROM users where id=$thanks_userid");
   $rows_a = mysql_fetch_array($user_sql);
   $username_t = $rows_a["username"];
   $thanksby =  $thanksby."<a href='userdetails.php?id=$thanks_userid'>$username_t</a>, ";
   }
   $t_userid = $CURUSER["id"];
   $tsql = mysql_query("SELECT COUNT(*) FROM thanks where torrentid=$torrentid and userid=$t_userid");
   $trows = mysql_fetch_array($tsql);
   $t_ab = $trows[0];
   if ($t_ab == "0") {
   $thanksby = $thanksby." <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"�������\">
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>";
   }
   else {
   $thanksby = $thanksby." <form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"�������\" disabled>
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>";
   }
   }
   else {
   $thanksby = "�����
<form action=\"thanks.php\" method=\"post\">
<input type=\"submit\" name=\"submit\" value=\"�������\">
<input type=\"hidden\" name=\"torrentid\" value=\"$torrentid\">
</form>
   ";
   }
       tr("�������&nbsp;�������:",$thanksby,1);

		print("</table></p>\n");
	}
	else {
		stdhead("����������� � \"" . $row["name"] . "\"");
		print("<h1>����������� � <a href=details.php?id=$id>" . $row["name"] . "</a></h1>\n");
//		print("<p><a href=\"details.php?id=$id\">Back to full details</a></p>\n");
	}

	print("<p><a name=\"startcomments\"></a></p>\n");

	$checkcomm = mysql_num_rows(mysql_query("SELECT * FROM checkcomm WHERE userid = $CURUSER[id] AND checkid = $id")); 
    $check = (!$checkcomm ? "<a class=index href=comment.php?action=check&amp;tid=$id>������� �� �������������</a>" : "<a class=index href=details.php?action=checkoff&amp;tid=$id>��������� ��������</a>"); 
    $commentbar = "<p align=center><a class=index href=comment.php?action=add&amp;tid=$id>�������� �����������</a>&nbsp;&nbsp;&nbsp;&nbsp;$check</p>\n";

	$subres = mysql_query("SELECT COUNT(*) FROM comments WHERE torrent = $id");
	$subrow = mysql_fetch_array($subres);
	$count = $subrow[0];

	if (!$count) {
		print("<h2>��� ������������</h2>\n");
	}
	else {
		list($pagertop, $pagerbottom, $limit) = pager(20, $count, "details.php?id=$id&", array(lastpagedefault => 1));

		$subres = mysql_query("SELECT comments.id, text, user, comments.added, editedby, editedat, avatar, warned, ".
                  "username, title, class, donor, parked FROM comments LEFT JOIN users ON comments.user = users.id WHERE torrent = " .
                  "$id ORDER BY comments.id $limit") or sqlerr(__FILE__, __LINE__);
		$allrows = array();
		while ($subrow = mysql_fetch_array($subres))
			$allrows[] = $subrow;

		print($commentbar);
		print($pagertop);

		commenttable($allrows);

		print($pagerbottom);
	}

	print($commentbar);
}

stdfoot();

?>