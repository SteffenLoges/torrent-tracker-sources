<?

$mysql_host = "localhost";
$mysql_user = "USER";
$mysql_pass = "PASS";
$mysql_db = "TABLE";

?>

