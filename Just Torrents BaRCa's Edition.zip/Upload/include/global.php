<?

$zodiac[] = array("�������", "capricorn.gif", "22-12");
$zodiac[] = array("�������", "sagittarius.gif", "23-11");
$zodiac[] = array("��������", "scorpio.gif", "24-10");
$zodiac[] = array("����", "libra.gif", "24-09");
$zodiac[] = array("����", "virgo.gif", "24-08");
$zodiac[] = array("���", "leo.gif", "23-07");
$zodiac[] = array("���", "cancer.gif", "22-06");
$zodiac[] = array("��������", "gemini.gif", "22-05");
$zodiac[] = array("�����", "taurus.gif", "21-04");
$zodiac[] = array("����", "aries.gif", "22-03");
$zodiac[] = array("����", "pisces.gif", "21-02");
$zodiac[] = array("�������", "aquarius.gif", "21-01");

function get_user_class_color($class, $username)
{
  switch ($class)
  {
   case UC_MIP:
      return "<span style=\"color:#0F6CEE\" title=\"Mip\">" . $username . "</span>";
      break;
 case UC_SYSOP:
      return "<span style=\"color:red\" title=\"SySoP\">" . $username . "</span>";
      break;
    case UC_ADMINISTRATOR:
      return "<span style=\"color:blue\" title=\"Administrator\">" . $username . "</span>";
      break;
    case UC_MODERATOR:
      return "<span style=\"color:green\" title=\"Moderator\">" . $username . "</span>";
      break;
     case UC_UPLOADER:
      return "<span style=\"color:orange\" title=\"Uploader\">" . $username . "</span>";
      break;
     case UC_VIP:
      return "<span style=\"color:#9C2FE0\" title=\"VIP\">" . $username . "</span>";
      break;
     case UC_POWER_USER:
      return "<span style=\"color:#D21E36\" title=\"Power user\">" . $username . "</span>";
      break;
  }
  return "$username";
}

function display_date_time($timestamp = 0 , $tzoffset = 0){
        return date("Y-m-d H:i:s", $timestamp + ($tzoffset * 60));
}

function textbbcode($form,$name,$content="") {
?>

<script language="JavaScript" type="text/javascript">
function SmileIT(smile,form,text){
  document.forms[form].elements[text].value = document.forms[form].elements[text].value+" "+smile+" ";
  document.forms[form].elements[text].focus();
}

function PopMoreSmiles(form,name) {
        link='moresmiles.php?form='+form+'&text='+name
        newWin=window.open(link,'moresmile','height=500,width=300,resizable=yes,scrollbars=yes');
        if (window.focus) {newWin.focus()}
}
// bbCode control by
// subBlue design
// www.subBlue.com

// Startup variables
var imageTag = false;
var theSelection = false;

// Check for Browser & Platform for PC & IE specific bits
// More details from: http://www.mozilla.org/docs/web-developer/sniffer/browser_type.html
var clientPC = navigator.userAgent.toLowerCase(); // Get client info
var clientVer = parseInt(navigator.appVersion); // Get browser version

var is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1));
var is_nav = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1)
                && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1)
                && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));
var is_moz = 0;

var is_win = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1));
var is_mac = (clientPC.indexOf("mac")!=-1);

// Define the bbCode tags
bbcode = new Array();
bbtags = new Array('[b]','[/b]','[i]','[/i]','[u]','[/u]','[quote]','[/quote]','[pre]','[/pre]','[*]','[*]','[*]','[*]','[img]','[/img]','[url]','[/url]');
imageTag = false;

// Replacement for arrayname.length property
function getarraysize(thearray) {
        for (i = 0; i < thearray.length; i++) {
                if ((thearray[i] == "undefined") || (thearray[i] == "") || (thearray[i] == null))
                        return i;
                }
        return thearray.length;
}

// Replacement for arrayname.push(value) not implemented in IE until version 5.5
// Appends element to the array
function arraypush(thearray,value) {
        thearray[ getarraysize(thearray) ] = value;
}

// Replacement for arrayname.pop() not implemented in IE until version 5.5
// Removes and returns the last element of an array
function arraypop(thearray) {
        thearraysize = getarraysize(thearray);
        retval = thearray[thearraysize - 1];
        delete thearray[thearraysize - 1];
        return retval;
}
function bbstyle(bbnumber) {
        var txtarea = document.<?=$form?>.<?=$name?>;

        txtarea.focus();
        donotinsert = false;
        theSelection = false;
        bblast = 0;

        if (bbnumber == -1) { // Close all open tags & default button names
                while (bbcode[0]) {
                        butnumber = arraypop(bbcode) - 1;
                        txtarea.value += bbtags[butnumber + 1];
                        buttext = eval('document.<?=$form?>.addbbcode' + butnumber + '.value');
                        eval('document.<?=$form?>.addbbcode' + butnumber + '.value ="' + buttext.substr(0,(buttext.length - 1)) + '"');
                }
                imageTag = false; // All tags are closed including image tags :D
                txtarea.focus();
                return;
        }

        if ((clientVer >= 4) && is_ie && is_win)
        {
                theSelection = document.selection.createRange().text; // Get text selection
                if (theSelection) {
                        // Add tags around selection
                        document.selection.createRange().text = bbtags[bbnumber] + theSelection + bbtags[bbnumber+1];
                        txtarea.focus();
                        theSelection = '';
                        return;
                }
        }
        else if (txtarea.selectionEnd && (txtarea.selectionEnd - txtarea.selectionStart > 0))
        {
                mozWrap(txtarea, bbtags[bbnumber], bbtags[bbnumber+1]);
                return;
        }

        // Find last occurance of an open tag the same as the one just clicked
        for (i = 0; i < bbcode.length; i++) {
                if (bbcode[i] == bbnumber+1) {
                        bblast = i;
                        donotinsert = true;
                }
        }

        if (donotinsert) {                // Close all open tags up to the one just clicked & default button names
                while (bbcode[bblast]) {
                                butnumber = arraypop(bbcode) - 1;
                                txtarea.value += bbtags[butnumber + 1];
                                buttext = eval('document.<?=$form?>.addbbcode' + butnumber + '.value');
                                eval('document.<?=$form?>.addbbcode' + butnumber + '.value ="' + buttext.substr(0,(buttext.length - 1)) + '"');
                                imageTag = false;
                        }
                        txtarea.focus();
                        return;
        } else { // Open tags

                if (imageTag && (bbnumber != 14)) {                // Close image tag before adding another
                        txtarea.value += bbtags[15];
                        lastValue = arraypop(bbcode) - 1;        // Remove the close image tag from the list
                        document.<?=$form?>.addbbcode14.value = "Img";        // Return button back to normal state
                        imageTag = false;
                }

                // Open tag
                txtarea.value += bbtags[bbnumber];
                if ((bbnumber == 14) && (imageTag == false)) imageTag = 1; // Check to stop additional tags after an unclosed image tag
                arraypush(bbcode,bbnumber+1);
                eval('document.<?=$form?>.addbbcode'+bbnumber+'.value += "*"');
                txtarea.focus();
                return;
        }
        storeCaret(txtarea);
}

function bbfontstyle(bbopen, bbclose) {
        var txtarea = document.<?=$form?>.<?=$name?>;

        if ((clientVer >= 4) && is_ie && is_win) {
                theSelection = document.selection.createRange().text;
                if (!theSelection) {
                        txtarea.value += bbopen + bbclose;
                        txtarea.focus();
                        return;
                }
                document.selection.createRange().text = bbopen + theSelection + bbclose;
                txtarea.focus();
                return;
        }
        else if (txtarea.selectionEnd && (txtarea.selectionEnd - txtarea.selectionStart > 0))
        {
                mozWrap(txtarea, bbopen, bbclose);
                return;
        }
        else
        {
                txtarea.value += bbopen + bbclose;
                txtarea.focus();
        }
        storeCaret(txtarea);
}

// From [url]http://www.massless.org/mozedit/[/url]
function mozWrap(txtarea, open, close)
{
        var selLength = txtarea.textLength;
        var selStart = txtarea.selectionStart;
        var selEnd = txtarea.selectionEnd;
        if (selEnd == 1 || selEnd == 2)
                selEnd = selLength;

        var s1 = (txtarea.value).substring(0,selStart);
        var s2 = (txtarea.value).substring(selStart, selEnd)
        var s3 = (txtarea.value).substring(selEnd, selLength);
        txtarea.value = s1 + open + s2 + close + s3;
        return;
}

// Insert at Claret position. Code from
// [url]http://www.faqts.com/knowledge_base/view.phtml/aid/1052/fid/130[/url]
function storeCaret(textEl) {
        if (textEl.createTextRange) textEl.caretPos = document.selection.createRange().duplicate();
}

var selection = false; // Selection data

// Catching selection
function catchSelection()
{
        if (window.getSelection)
        {
                selection = window.getSelection().toString();
        }
        else if (document.getSelection)
        {
                selection = document.getSelection();
        }
        else if (document.selection)
        {
                selection = document.selection.createRange().text;
        }
}

// Putting username to the post box
    function ins(name){
    var input=document.<?=$form?>.<?=$name?>;
    input.value=input.value+"[b]"+name+"[/b]"+": ";
}

function storeCaret(textEl) {
        if (textEl.createTextRange) textEl.caretPos = document.selection.createRange().duplicate();
}


var l_letter=new Array('`','1','2','3','4','5','6','7','8','9','0','-','=','q','w','e','r','t','y','u','i','o','p','[',']','BackSpace','Shift','a','s','d','f','g','h','j','k','l',';',"'",'Enter','CapsLock','z','x','c','v','b','n','m',',','.','/','\\','Rus/Lat','Undo',' ','Clear');var lb_letter=new Array('~','!','@','#','$','%','^','&','*','(',')','_','+','Q','W','E','R','T','Y','U','I','O','P','{','}','BackSpace','Shift','A','S','D','F','G','H','J','K','L',':','"','Enter','CapsLock','Z','X','C','V','B','N','M','<','>','?','|','Rus/Lat','Undo',' ','Clear');var r_letter=new Array('�','1','2','3','4','5','6','7','8','9','0','-','=','�','�','�','�','�','�','�','�','�','�','�','�','BackSpace','Shift','�','�','�','�','�','�','�','�','�','�','�','Enter','CapsLock','�','�','�','�','�','�','�','�','�','.','\\','Rus/Lat','Undo',' ','Clear');var rb_letter=new Array('�','!','"','�',';','%',':','?','*','(',')','_','+','�','�','�','�','�','�','�','�','�','�','�','�','BackSpace','Shift','�','�','�','�','�','�','�','�','�','�','�','Enter','CapsLock','�','�','�','�','�','�','�','�','�',',','\\','Rus/Lat','Undo',' ','Clear');var ltype=new Array(2,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,3,3,3,2,2,3,3,3,3,3,3,3,3,3,3,3,2,2,3,3,3,3,3,3,3,3,3,2,2,0,0,3,3,3,3);var letter=new Array(l_letter,lb_letter,r_letter,rb_letter);var dec1=new Array(1040,1041,1062,1044,1045,1060,1043,1061,1048,1049,1050,1051,1052,1053,1054,1055,1070,1056,1057,1058,1059,1042,1065,1061,1067,1047,1072,1073,1094,1076,1077,1092,1075,1093,1080,1081,1082,1083,1084,1085,1086,1087,1102,1088,1089,1090,1091,1074,1097,1093,1099,1079,1100,1098);var dec2=new Array(1071,1041,1063,1044,1069,1060,1046,1065,1048,1049,1050,1051,1052,1053,1025,1055,1070,1056,1064,1058,1070,1042,1065,1061,1067,1046,1103,1073,1095,1076,1101,1092,1078,1097,1080,1081,1082,1083,1084,1085,1105,1087,1102,1088,1096,1090,1102,1074,1097,1093,1099,1078,1068,1066);var dec3=new Array(1060,1048,1057,1042,1059,1040,1055,1056,1064,1054,1051,1044,1068,1058,1065,1047,1049,1050,1067,1045,1043,1052,1062,1063,1053,1071,1092,1080,1089,1074,1091,1072,1087,1088,1096,1086,1083,1076,1100,1090,1097,1079,1081,1082,1099,1077,1075,1084,1094,1095,1085,1103,1093,1098,1078,1101,1073,1102,46,1061,1066,1046,1069,1041,1070,44,1105,1025);var keymode=2;var savemode=0;var btn_first=9;var qn=55;var shift=false;var capslock=false;var apostr=false;var formname="",textname="";var undotext="";var op;var par=new String(location.search);var sag=new String(navigator.userAgent);var use_kb=false;var show_rules=false;var sag=new String(navigator.userAgent);var sap=new String(navigator.appName);var isIE=false;var isOP7=false;var isOP8=false;var isMOZ=false;if(sap=="Microsoft Internet Explorer"&&sag.indexOf("pera")==-1)isIE=true;else if(sag.indexOf("pera 7")>-1||sag.indexOf("pera/7")>-1)isOP7=true;else if(sap=="Netscape")isMOZ=true;else if(sag.indexOf("pera 8")>-1||sag.indexOf("pera/8")>-1){isOP8=true;isMOZ=true;}function kb_help(subj){var t='';if(isIE)t='tmz';else if(isOP7)t='to7';else if(isOP8)t='tmz';else if(isMOZ)t='tmz';helpline(t);}function kb_close(){var expire=new Date();var expdate=expire.getTime()+31536000000;use_kb=false;show_rules=false;expire.setTime(expdate);document.getElementById("kb_keyb").style.position="absolute";document.getElementById("kb_keyb").style.visibility="hidden";document.getElementById("kb_rules").style.position="absolute";document.getElementById("kb_rules").style.visibility="hidden";document.getElementById("kb_off").style.position="static";document.getElementById("kb_off").style.visibility="visible";document.getElementById("kb_trules").style.position="absolute";document.getElementById("kb_trules").style.visibility="hidden";if(isIE)document.cookie="kb_layout="+document.<?=$form?>.decflag.value+";expires="+expire.toGMTString();}function kb_show(){var lyt,val,i;var txtarea=document.<?=$form?>.<?=$name?>;use_kb=true;document.getElementById("kb_keyb").style.position="static";document.getElementById("kb_keyb").style.visibility="visible";document.getElementById("kb_rules").style.position="static";document.getElementById("kb_rules").style.visibility="visible";document.getElementById("kb_off").style.position="absolute";document.getElementById("kb_off").style.visibility="hidden";document.getElementById("kb_trules").style.position="absolute";document.getElementById("kb_trules").style.visibility="hidden";if(isIE){lyt=document.cookie.split(';');for(i=0;i<lyt.length;i++){if(lyt[i].indexOf('kb_layout')>0){val=lyt[i].split('=');document.<?=$form?>.decflag.value=val[1];}}}undotext=txtarea.value;storeCaret(txtarea);txtarea.focus();}function kb_rules(){if(!show_rules){document.getElementById("kb_keyb").style.position="absolute";document.getElementById("kb_keyb").style.visibility="hidden";document.getElementById("kb_trules").style.position="static";document.getElementById("kb_trules").style.visibility="visible";}else{document.getElementById("kb_keyb").style.position="static";document.getElementById("kb_keyb").style.visibility="visible";document.getElementById("kb_trules").style.position="absolute";document.getElementById("kb_trules").style.visibility="hidden";}show_rules=!show_rules;}function clr(){undotext=document.<?=$form?>.<?=$name?>.value;document.<?=$form?>.<?=$name?>.value="";document.<?=$form?>.<?=$name?>.focus();return false;}function undo(){var txtarea=document.<?=$form?>.<?=$name?>;var s=txtarea.value;txtarea.value=undotext;undotext=s;txtarea.focus();storeCaret(txtarea);return false;}function changeLetter(n){var i,tg;var off=1;if((n!=5)&&shift) keymode ^=1;keymode ^= n & 3;shift=((n==5)&&!shift);for(i=0;i<qn;off++){tg=document.<?=$form?>.elements[off].className;if(tg=="b30"||tg=="b80"||tg=="b100"||tg=="b300"){document.<?=$form?>.elements[off].value=letter[(shift)?(keymode|(((ltype[i]>>(keymode>>1))&1)^1)):(keymode&((ltype[i]>>(keymode>>1))|2))][i];i++;}}document.<?=$form?>.<?=$name?>.focus();return false;}function delLetter(){if(isOP7)return;var txtarea=document.<?=$form?>.<?=$name?>;var str=new String(txtarea);var del=1;if(txtarea.createTextRange&&txtarea.caretPos){var caretPos=txtarea.caretPos;caretPos.moveStart('character',-1);caretPos.text='';}else if(txtarea.value!=''&&txtarea.selectionEnd&&(txtarea.selectionStart|txtarea.selectionStart==0)){if(txtarea.selectionEnd>txtarea.value.length)txtarea.selectionEnd=txtarea.value.length;var startPos=txtarea.selectionStart;txtarea.value=txtarea.value.slice(0,startPos-1)+txtarea.value.slice(startPos);txtarea.selectionStart=startPos-1;txtarea.selectionEnd=startPos-1;}else if(str.length>0){if(str.charAt(str.length-1)=='\n') del=2;txtarea.value=str.substr(0,str.length-del);}txtarea.focus();storeCaret(txtarea);return false;}function addl(but){var txtarea=document.<?=$form?>.<?=$name?>;var chr=(but=='Enter') ? '\n' :but;if((txtarea.value!=''&&txtarea.selectionEnd&&(txtarea.selectionStart|txtarea.selectionStart==0))||isOP8||isOP7 ){if(txtarea.selectionEnd>txtarea.value.length){txtarea.selectionEnd=txtarea.value.length;}var startPos=txtarea.selectionStart;txtarea.value=txtarea.value.slice(0,startPos)+chr+txtarea.value.slice(startPos);txtarea.selectionStart=startPos+1;txtarea.selectionEnd=startPos+1;}else if(txtarea.createTextRange&&txtarea.caretPos&&!(isOP8||isOP7)){var caretPos=txtarea.caretPos;caretPos.text=chr;}else{txtarea.value+=chr;}if(shift){shift=false;changeLetter(1);}txtarea.focus();storeCaret(txtarea);}function init(){undotext=document.<?=$form?>.<?=$name?>.value;changeLetter(0);return false;}function decode_char(code){var i=-1;if(code>=65&&code<=90) i=code-65;else if(code>=97&&code<=122) i=code-71;if(i==-1)switch(code){case 91:i=52;break;case 93:i=53;break;case 39:apostr=!apostr;return '';}if(i!=-1) code=(apostr)?dec2[i]:dec1[i];apostr=false;return String.fromCharCode(code);}function translit(){var txtarea=document.<?=$form?>.<?=$name?>;var e='',c='';apostr=false;if(txtarea.value!=''&&txtarea.selectionEnd&&(txtarea.selectionStart|txtarea.selectionStart==0)){if(txtarea.selectionEnd>txtarea.value.length){txtarea.selectionEnd=txtarea.value.length;}var startPos=txtarea.selectionStart;var endPos=txtarea.selectionEnd;for(i=0;i<= endPos-startPos-1;i++)e+=decode_char(txtarea.value.charCodeAt(i+startPos));txtarea.value=txtarea.value.slice(0,startPos)+e+txtarea.value.slice(endPos);txtarea.selectionStart=startPos;txtarea.selectionEnd=startPos+e.length;}else if(txtarea.createTextRange&&txtarea.caretPos){var caretPos=txtarea.caretPos;for(i=0;i<= caretPos.text.length;i++)e+=decode_char(caretPos.text.charCodeAt(i));caretPos.text=e;}else{for(i=0;i<= txtarea.value.length;i++)e+=decode_char(txtarea.value.charCodeAt(i));txtarea.value=e;}txtarea.focus();storeCaret(txtarea);}function decode(evt){if((document.<?=$form?>.decflag.type!="select-one")||(document.<?=$form?>.decflag.value==0))return true;var code=evt.keyCode?evt.keyCode:evt.charCode?evt.charCode:evt.which?evt.which:0;var newc=code,i=-1;if(code>=65&&code<=90) i=code-65;else if(code>=97&&code<=122) i=code-71;if(document.<?=$form?>.decflag.value==1){if(i==-1)switch(code){case 91:i=52;break;case 93:i=53;break;case 39:apostr=!apostr;return !apostr;}if(i!=-1)newc=(apostr)?dec2[i]:dec1[i];apostr=false;}else{if(i==-1){switch(code){case 91:i=(capslock)?59:52;break;case 93:i=(capslock)?60:53;break;case 59:i=(capslock)?61:54;break;case 39:i=(capslock)?62:55;break;case 44:i=(capslock)?63:56;break;case 46:i=(capslock)?64:57;break;case 47:i=58;break;case 123:i=(capslock)?52:59;break;case 125:i=(capslock)?53:60;break;case 58:i=(capslock)?54:61;break;case 34:i=(capslock)?55:62;break;case 60:i=(capslock)?56:63;break;case 62:i=(capslock)?57:64;break;case 63:i=65;break;case 96:i=(capslock)?67:66;break;case 126:i=(capslock)?66:67;break;}}else{if(i<26) capslock=!evt.shiftKey;else capslock=evt.shiftKey;}if(i!=-1){newc=dec3[i];}}if(isIE){evt.keyCode=newc;}else if(isMOZ&&code!=newc&&evt.which!=0){evt.preventDefault();addl(String.fromCharCode(newc));}storeCaret(document.<?=$form?>.<?=$name?>);return true;}
</script>
<table width="100%" cellpadding="0" cellspacing="0">
  <tr>
    <td class=embedded colspan=3>
    <table cellpadding="2" cellspacing="1">
    <tr>
    <td>
    <input type="button" accesskey="b" name="addbbcode0" value=" B " style="font-weight:bold; width:30px" onClick="bbstyle(0)" />
    <input type="button" accesskey="i" name="addbbcode2" value=" i " style="font-style:italic; width:30px" onClick="bbstyle(2)" />
    <input type="button" accesskey="u" name="addbbcode4" value=" u " style="text-decoration: underline; width:30px" onClick="bbstyle(4)"/>
    <input type="button" accesskey="l" name="addbbcode10" value="������" style="width:50px" onClick="bbstyle(10)" />
    <input type="button" accesskey="q" name="addbbcode6" value="������" style="width:50px" onClick="bbstyle(6)" />
    <input type="button" accesskey="c" name="addbbcode8" value="���" style="width:40px" onClick="bbstyle(8)" />
    <input type="button" accesskey="p" name="addbbcode14" value="Img" style="width:40px"  onClick="bbstyle(14)" />
    <input type="button" accesskey="w" name="addbbcode16" value="URL" style="text-decoration: underline; width:40px" onClick="bbstyle(16)" />
    &nbsp;&nbsp;&nbsp;<a href="tags.php" target="_blank">��� ����</a>
    </td>
    </tr>
    <tr>
    <td>���� ������:
        <select name="addbbcode18" onChange="bbfontstyle('[color=' + this.form.addbbcode18.options[this.form.addbbcode18.selectedIndex].value + ']', '[/color]');this.selectedIndex=0;">
        <option style="color:black;" value="black" class="genmed">������</option>
        <option style="color:darkred;" value="darkred" class="genmed">�����-�������</option>
        <option style="color:red;" value="red" class="genmed">�������</option>
        <option style="color:orange;" value="orange" class="genmed">����������</option>
        <option style="color:brown;" value="brown" class="genmed">����������</option>
        <option style="color:yellow;" value="yellow" class="genmed">������</option>
        <option style="color:green;" value="green" class="genmed">�������</option>
        <option style="color:olive;" value="olive" class="genmed">���������</option>
        <option style="color:cyan;" value="cyan" class="genmed">�������</option>
        <option style="color:blue;" value="blue" class="genmed">�����</option>
        <option style="color:darkblue;" value="darkblue" class="genmed">�����-�����</option>
        <option style="color:indigo;" value="indigo" class="genmed">������</option>
        <option style="color:violet;" value="violet" class="genmed">����������</option>
        <option style="color:white;" value="white" class="genmed">�����</option>
        </select>&nbsp;������ ������:<select name="addbbcode20" onChange="bbfontstyle('[size=' + this.form.addbbcode20.options[this.form.addbbcode20.selectedIndex].value + ']', '[/size]')"">
        <option value="1" class="genmed">���������</option>
        <option value="2" selected class="genmed">�����������</option>
        <option value="4" class="genmed">�������</option>
        <option  value="7" class="genmed">��������</option>
        </select>
        <a href="javascript:bbstyle(-1)" class="genmed">������� ��� ����</a>
        </td>
        </tr>

  </tr>
  <tr>
    <td>
    <textarea name="<?=$name;?>" wrap="virtual" rows="15" cols="85" onKeyPress="if(use_kb) return decode(event);" onFocus="storeCaret(this);"  onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);"><? echo $content; ?></textarea>
    </td>
  </tr>
        </table>
    <td>
    <table cellpadding="3" cellspacing="1">
    <?

    global $smilies;
    while ((list($code, $url) = each($smilies)) && $count<20) {
       if ($count % 4==0)
          print("<tr>");

          print("\n<td class=embedded style='padding: 3px; margin: 2px'><a href=\"javascript: SmileIT('".str_replace("'","\'",$code)."','$form','$name')\"><img border=0 src=pic/smilies/".$url."></a></td>");
          $count++;

       if ($count % 4==0)
          print("</tr>");
    }
    ?>
    </table>
 <center><a href="javascript: PopMoreSmiles('<? echo $form; ?>','<? echo $name; ?>')"><? echo "��� ������";?></a></center>
    </td>
  </tr>
          <!-- MAIL.RU KEYBOARD BEGIN -->
        <tr>
          <td class="embedded" colspan=3>
                  <div id="kb_off" style=""><span class="a" onMouseOver="this.style.color='blue';" onMouseOut="this.style.color='black'" onclick="kb_show();">�������� ����������</span></div>
                <div id="kb_trules" style="position:absolute; visibility:hidden;">
                <table><tr><td nowrap="nowrap" colspan="10" class="embedded"><b>������� ���������</b><td colspan="2" class="embedded"><span class="a" onMouseOver="this.style.color='blue';" onMouseOut="this.style.color='black'" onclick="kb_rules();">�������� ����������</span></td><tr valign="top">
                        <td nowrap="nowrap" class="embedded"><b>� <br>� <br>� <br>� <br>� <br>� </b></td><td nowrap="nowrap" width="55" class="embedded">- a<br>- b<br>- v<br>- g<br>- d<br>- e</td>
                        <td nowrap="nowrap" class="embedded"><b>&euml; <br>� <br>� <br>� <br>� <br>� </b></td><td nowrap="nowrap" width="55" class="embedded">- 'o<br>- 'z ('g)<br>- z<br>- i<br>- j<br>- k</td>
                        <td nowrap="nowrap" class="embedded"><b>� <br>� <br>� <br>� <br>� <br>� </b></td><td nowrap="nowrap" width="55" class="embedded">- l<br>- m<br>- n<br>- o<br>- p<br>- r</td>
                        <td nowrap="nowrap" class="embedded"><b>� <br>� <br>� <br>� <br>� <br>� </b></td><td nowrap="nowrap" width="55" class="embedded">- s<br>- t<br>- u<br>- f<br>- h<br>- c</td>
                        <td nowrap="nowrap" class="embedded"><b>� <br>� <br>� <br>� <br>� <br>� </b></td><td nowrap="nowrap" width="55" class="embedded">- 'c<br>- 's<br>- w ('h)<br>- ]<br>- y<br>- [</td>
                        <td nowrap="nowrap" class="embedded"><b>� <br>� <br>� <br>' </b></td><td nowrap="nowrap" width="55" class="embedded">- 'e<br>- q ('u)<br>- 'a<br>- ''</td>
                </tr></table>
                </div>
                <div id="kb_keyb" style="position:absolute; visibility:hidden;">
                  <table><tr><td align="center" style="border:none;">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30"><br>
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width=&quot;30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <script>if(!(isOP7||isOP8))document.write('<input type="button" value="" name="dell" onMouseUp="return delLetter();" width="80" class="b80">');else document.write('<input type="button" value="" name="dell" width="80" class="b80" disabled="disabled">');</script><br>
                        <input type="button" value="" onClick="return changeLetter(5);" width="80" class="b80">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="100" class="b100"><br>
                        <input type="button" value="" onClick="return changeLetter(1);" width="80" class="b80">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="30" class="b30">
                        <input type="button" value="" onClick="return changeLetter(2);" width="80" class="b80"><br>
                        <input type="button" value="" onClick="return undo();" width="80" class="b80">
                        <input type="button" value="" onMouseUp="return addl(this.value);" width="300" class="b300">
                        <input type="button" value="" onClick="return clr();" width="80" class="b80"><br />
                        <script>init();</script>
                </td>
                </tr></table></div>
          </td>
                        <td class="embedded" valign="top"><b>������� ����������</b>
                        <div id="kb_rules" style="position:absolute;visibility:hidden;">
                        <script>if(isMOZ||isIE)document.write("���������: <select name='decflag' onChange='document.<?=$form?>.<?=$name?>.focus();' style='font-size:9px;position:relative;top:2px'><option value=0>�����������<option value=1 selected>��������<option value=2>������������</select><br />");</script>
                        <span class="a" onMouseOver="this.style.color='blue';" onMouseOut="this.style.color='black'; window.status=''" onclick="translit();">��������</span><br />
                        <span class="a" onMouseOver="this.style.color='blue';" onMouseOut="this.style.color='black'" onclick="kb_rules();">������� ���������</span><br />
                        <span class="a" onMouseOver="this.style.color='blue';" onMouseOut="this.style.color='black'" onclick="kb_close();">�������� ����������</span>
                        </div>
          </td>
        </tr>
        <!-- MAIL.RU KEYBOARD END -->
</table>
<?
}

$smilies = array(
  ":-)" => "smile1.gif",
  ":smile:" => "smile2.gif",
  ":-D" => "grin.gif",
  ":lol:" => "laugh.gif",
  ":w00t:" => "w00t.gif",
  ":-P" => "tongue.gif",
  ";-)" => "wink.gif",
  ":-|" => "noexpression.gif",
  ":-/" => "confused.gif",
  ":-(" => "sad.gif",
  ":'-(" => "cry.gif",
  ":weep:" => "weep.gif",
  ":-O" => "ohmy.gif",
  ":o)" => "clown.gif",
  "8-)" => "cool1.gif",
  "|-)" => "sleeping.gif",
  ":innocent:" => "innocent.gif",
  ":whistle:" => "whistle.gif",
  ":unsure:" => "unsure.gif",
  ":closedeyes:" => "closedeyes.gif",
  ":cool:" => "cool2.gif",
  ":fun:" => "fun.gif",
  ":thumbsup:" => "thumbsup.gif",
  ":thumbsdown:" => "thumbsdown.gif",
  ":blush:" => "blush.gif",
  ":unsure:" => "unsure.gif",
  ":yes:" => "yes.gif",
  ":no:" => "no.gif",
  ":love:" => "love.gif",
  ":?:" => "question.gif",
  ":!:" => "excl.gif",
  ":idea:" => "idea.gif",
  ":arrow:" => "arrow.gif",
  ":arrow2:" => "arrow2.gif",
  ":hmm:" => "hmm.gif",
  ":hmmm:" => "hmmm.gif",
  ":huh:" => "huh.gif",
  ":geek:" => "geek.gif",
  ":look:" => "look.gif",
  ":rolleyes:" => "rolleyes.gif",
  ":kiss:" => "kiss.gif",
  ":shifty:" => "shifty.gif",
  ":blink:" => "blink.gif",
  ":smartass:" => "smartass.gif",
  ":sick:" => "sick.gif",
  ":crazy:" => "crazy.gif",
  ":wacko:" => "wacko.gif",
  ":alien:" => "alien.gif",
  ":wizard:" => "wizard.gif",
  ":wave:" => "wave.gif",
  ":wavecry:" => "wavecry.gif",
  ":baby:" => "baby.gif",
  ":angry:" => "angry.gif",
  ":ras:" => "ras.gif",
  ":sly:" => "sly.gif",
  ":devil:" => "devil.gif",
  ":evil:" => "evil.gif",
  ":evilmad:" => "evilmad.gif",
  ":sneaky:" => "sneaky.gif",
  ":axe:" => "axe.gif",
  ":slap:" => "slap.gif",
  ":wall:" => "wall.gif",
  ":rant:" => "rant.gif",
  ":jump:" => "jump.gif",
  ":yucky:" => "yucky.gif",
  ":nugget:" => "nugget.gif",
  ":smart:" => "smart.gif",
  ":shutup:" => "shutup.gif",
  ":shutup2:" => "shutup2.gif",
  ":crockett:" => "crockett.gif",
  ":zorro:" => "zorro.gif",
  ":snap:" => "snap.gif",
  ":beer:" => "beer.gif",
  ":beer2:" => "beer2.gif",
  ":drunk:" => "drunk.gif",
  ":strongbench:" => "strongbench.gif",
  ":weakbench:" => "weakbench.gif",
  ":dumbells:" => "dumbells.gif",
  ":music:" => "music.gif",
  ":stupid:" => "stupid.gif",
  ":dots:" => "dots.gif",
  ":offtopic:" => "offtopic.gif",
  ":spam:" => "spam.gif",
  ":oops:" => "oops.gif",
  ":lttd:" => "lttd.gif",
  ":please:" => "please.gif",
  ":sorry:" => "sorry.gif",
  ":hi:" => "hi.gif",
  ":yay:" => "yay.gif",
  ":cake:" => "cake.gif",
  ":hbd:" => "hbd.gif",
  ":band:" => "band.gif",
  ":punk:" => "punk.gif",
	":rofl:" => "rofl.gif",
  ":bounce:" => "bounce.gif",
  ":mbounce:" => "mbounce.gif",
  ":thankyou:" => "thankyou.gif",
  ":gathering:" => "gathering.gif",
  ":hang:" => "hang.gif",
  ":chop:" => "chop.gif",
  ":rip:" => "rip.gif",
  ":whip:" => "whip.gif",
  ":judge:" => "judge.gif",
  ":chair:" => "chair.gif",
  ":tease:" => "tease.gif",
  ":box:" => "box.gif",
  ":boxing:" => "boxing.gif",
  ":guns:" => "guns.gif",
  ":shoot:" => "shoot.gif",
  ":shoot2:" => "shoot2.gif",
  ":flowers:" => "flowers.gif",
  ":wub:" => "wub.gif",
  ":lovers:" => "lovers.gif",
  ":kissing:" => "kissing.gif",
  ":kissing2:" => "kissing2.gif",
  ":console:" => "console.gif",
  ":group:" => "group.gif",
  ":hump:" => "hump.gif",
  ":hooray:" => "hooray.gif",
  ":happy2:" => "happy2.gif",
  ":clap:" => "clap.gif",
  ":clap2:" => "clap2.gif",
	":weirdo:" => "weirdo.gif",
  ":yawn:" => "yawn.gif",
  ":bow:" => "bow.gif",
	":dawgie:" => "dawgie.gif",
	":cylon:" => "cylon.gif",
  ":book:" => "book.gif",
  ":fish:" => "fish.gif",
  ":mama:" => "mama.gif",
  ":pepsi:" => "pepsi.gif",
  ":medieval:" => "medieval.gif",
  ":rambo:" => "rambo.gif",
  ":ninja:" => "ninja.gif",
  ":hannibal:" => "hannibal.gif",
  ":party:" => "party.gif",
  ":snorkle:" => "snorkle.gif",
  ":evo:" => "evo.gif",
  ":king:" => "king.gif",
  ":chef:" => "chef.gif",
  ":mario:" => "mario.gif",
  ":pope:" => "pope.gif",
  ":fez:" => "fez.gif",
  ":cap:" => "cap.gif",
  ":cowboy:" => "cowboy.gif",
  ":pirate:" => "pirate.gif",
  ":pirate2:" => "pirate2.gif",
  ":rock:" => "rock.gif",
  ":cigar:" => "cigar.gif",
  ":icecream:" => "icecream.gif",
  ":oldtimer:" => "oldtimer.gif",
	":trampoline:" => "trampoline.gif",
	":banana:" => "bananadance.gif",
  ":smurf:" => "smurf.gif",
  ":yikes:" => "yikes.gif",
  ":osama:" => "osama.gif",
  ":saddam:" => "saddam.gif",
  ":santa:" => "santa.gif",
  ":indian:" => "indian.gif",
  ":pimp:" => "pimp.gif",
  ":nuke:" => "nuke.gif",
  ":jacko:" => "jacko.gif",
  ":ike:" => "ike.gif",
  ":greedy:" => "greedy.gif",
	":super:" => "super.gif",
  ":wolverine:" => "wolverine.gif",
  ":spidey:" => "spidey.gif",
  ":spider:" => "spider.gif",
  ":bandana:" => "bandana.gif",
  ":construction:" => "construction.gif",
  ":sheep:" => "sheep.gif",
  ":police:" => "police.gif",
	":detective:" => "detective.gif",
  ":bike:" => "bike.gif",
	":fishing:" => "fishing.gif",
  ":clover:" => "clover.gif",
  ":horse:" => "horse.gif",
  ":shit:" => "shit.gif",
  ":soldiers:" => "soldiers.gif",
);

$privatesmilies = array(
  ":)" => "smile1.gif",
//  ";)" => "wink.gif",
  ":wink:" => "wink.gif",
  ":D" => "grin.gif",
  ":P" => "tongue.gif",
  ":(" => "sad.gif",
  ":'(" => "cry.gif",
  ":|" => "noexpression.gif",
  // "8)" => "cool1.gif",   we don't want this as a smilie...
  ":Boozer:" => "alcoholic.gif",
  ":deadhorse:" => "deadhorse.gif",
  ":spank:" => "spank.gif",
  ":yoji:" => "yoji.gif",
  ":locked:" => "locked.gif",
  ":grrr:" => "angry.gif", 			// legacy
  "O:-" => "innocent.gif",			// legacy
  ":sleeping:" => "sleeping.gif",	// legacy
  "-_-" => "unsure.gif",			// legacy
  ":clown:" => "clown.gif",
  ":mml:" => "mml.gif",
  ":rtf:" => "rtf.gif",
  ":morepics:" => "morepics.gif",
  ":rb:" => "rb.gif",
  ":rblocked:" => "rblocked.gif",
  ":maxlocked:" => "maxlocked.gif",
  ":hslocked:" => "hslocked.gif",
);

// Set this to the line break character sequence of your system
$linebreak = "\r\n";

function get_row_count($table, $suffix = "")
{
  if ($suffix)
    $suffix = " $suffix";
  ($r = mysql_query("SELECT COUNT(*) FROM $table$suffix")) or die(mysql_error());
  ($a = mysql_fetch_row($r)) or die(mysql_error());
  return $a[0];
}

function stdmsg($heading, $text)
{
  print("<table class=main width=750 border=0 cellpadding=0 cellspacing=0><tr><td class=embedded>\n");
  if ($heading)
    print("<h2>$heading</h2>\n");
  print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n");
  print($text . "</td></tr></table></td></tr></table>\n");
}


function stderr($heading, $text)
{
  stdhead();
  stdmsg($heading, $text);
  stdfoot();
  die;
}

function sqlerr($file = '', $line = '')
{
  print("<table border=0 bgcolor=blue align=left cellspacing=0 cellpadding=10 style='background: blue'>" .
    "<tr><td class=embedded><font color=white><h1>SQL Error</h1>\n" .
  "<b>" . mysql_error() . ($file != '' && $line != '' ? "<p>in $file, line $line</p>" : "") . "</b></font></td></tr></table>");
  die;
}

// Returns the current time in GMT in MySQL compatible format.
function get_date_time($timestamp = 0)
{
  if ($timestamp)
    return date("Y-m-d H:i:s", $timestamp);
  else
    return gmdate("Y-m-d H:i:s");
}

function encodehtml($s, $linebreaks = true)
{
  $s = str_replace("<", "&lt;", str_replace("&", "&amp;", $s));
  if ($linebreaks)
    $s = nl2br($s);
  return $s;
}

function get_dt_num()
{
  return gmdate("YmdHis");
}

function format_urls($s)
{
	return preg_replace(
    	"/(\A|[^=\]'\"a-zA-Z0-9])((http|ftp|https|ftps|irc):\/\/[^()<>\s]+)/i",
	    "\\1<a href=\"\\2\">\\2</a>", $s);
}

/*

// Removed this fn, I've decided we should drop the redir script...
// it's pretty useless since ppl can still link to pics...
// -Rb

function format_local_urls($s)
{
	return preg_replace(
    "/(<a href=redir\.php\?url=)((http|ftp|https|ftps|irc):\/\/(www\.)?torrentbits\.(net|org|com)(:8[0-3])?([^<>\s]*))>([^<]+)<\/a>/i",
    "<a href=\\2>\\8</a>", $s);
}
*/

//Finds last occurrence of needle in haystack
//in PHP5 use strripos() instead of this
function _strlastpos ($haystack, $needle, $offset = 0)
{
	$addLen = strlen ($needle);
	$endPos = $offset - $addLen;
	while (true)
	{
		if (($newPos = strpos ($haystack, $needle, $endPos + $addLen)) === false) break;
		$endPos = $newPos;
	}
	return ($endPos >= 0) ? $endPos : false;
}

function format_quotes($s)
{
  while ($old_s != $s)
  {
  	$old_s = $s;

	  //find first occurrence of [/quote]
	  $close = strpos($s, "[/quote]");
	  if ($close === false)
	  	return $s;

	  //find last [quote] before first [/quote]
	  //note that there is no check for correct syntax
	  $open = _strlastpos(substr($s,0,$close), "[quote");
	  if ($open === false)
	    return $s;

	  $quote = substr($s,$open,$close - $open + 8);

	  //[quote]Text[/quote]
	  $quote = preg_replace(
	    "/\[quote\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
	    "<p class=sub><b>Quote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\1</td></tr></table><br>", $quote);

	  //[quote=Author]Text[/quote]
	  $quote = preg_replace(
	    "/\[quote=(.+?)\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
	    "<p class=sub><b>\\1 wrote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\2</td></tr></table><br>", $quote);

	  $s = substr($s,0,$open) . $quote . substr($s,$close + 8);
  }

	return $s;
}

function format_comment($text, $strip_html = true)
{
	global $smilies, $privatesmilies;

	$s = $text;

  // This fixes the extraneous ;) smilies problem. When there was an html escaped
  // char before a closing bracket - like >), "), ... - this would be encoded
  // to &xxx;), hence all the extra smilies. I created a new :wink: label, removed
  // the ;) one, and replace all genuine ;) by :wink: before escaping the body.
  // (What took us so long? :blush:)- wyz

	$s = str_replace(";)", ":wink:", $s);

	if ($strip_html)
		$s = htmlspecialchars($s);

	// [*]
	$s = preg_replace("/\[\*\]/", "<li>", $s);

	// [b]Bold[/b]
	$s = preg_replace("/\[b\]((\s|.)+?)\[\/b\]/", "<b>\\1</b>", $s);

	// [i]Italic[/i]
	$s = preg_replace("/\[i\]((\s|.)+?)\[\/i\]/", "<i>\\1</i>", $s);

	// [u]Underline[/u]
	$s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/", "<u>\\1</u>", $s);

	// [u]Underline[/u]
	$s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/i", "<u>\\1</u>", $s);

	// [img]http://www/image.gif[/img]
	$s = preg_replace("/\[img\]([^\s'\"<>]+?)\[\/img\]/i", "<img border=0 src=\"\\1\" onload=\"imgFit(this, 500);\" onclick=\"imgFit(this, 500);\">", $s);

	// [img=http://www/image.gif]
	$s = preg_replace("/\[img=([^\s'\"<>]+?)\]/i", "<img border=0 src=\"\\1\">", $s);

	// [color=blue]Text[/color]
	$s = preg_replace(
		"/\[color=([a-zA-Z]+)\]((\s|.)+?)\[\/color\]/i",
		"<font color=\\1>\\2</font>", $s);

	// [color=#ffcc99]Text[/color]
	$s = preg_replace(
		"/\[color=(#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])\]((\s|.)+?)\[\/color\]/i",
		"<font color=\\1>\\2</font>", $s);

	// [url=http://www.example.com]Text[/url]
	$s = preg_replace(
		"/\[url=([^()<>\s]+?)\]((\s|.)+?)\[\/url\]/i",
		"<a href=\"\\1\">\\2</a>", $s);

	// [url]http://www.example.com[/url]
	$s = preg_replace(
		"/\[url\]([^()<>\s]+?)\[\/url\]/i",
		"<a href=\"\\1\">\\1</a>", $s);

	// [size=4]Text[/size]
	$s = preg_replace(
		"/\[size=([1-7])\]((\s|.)+?)\[\/size\]/i",
		"<font size=\\1>\\2</font>", $s);

	// [font=Arial]Text[/font]
	$s = preg_replace(
		"/\[font=([a-zA-Z ,]+)\]((\s|.)+?)\[\/font\]/i",
		"<font face=\"\\1\">\\2</font>", $s);

    //[quote]Text[/quote]
    $s = preg_replace(
      "/\[quote\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
      "<p class=sub><b>������:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\1</td></tr></table><br>", $s);

    //[quote=Author]Text[/quote]
    $s = preg_replace(
      "/\[quote=(.+?)\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
      "<p class=sub><b>\\1 �����(�):</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\2</td></tr></table><br>", $s);

	// [flash]http://www.svt.se/hogafflahage/hogafflaHage_site/Kor/hestekor.swf[/flash]
	$s = preg_replace(
	   "/\[flash\]([^()<>\s]+?)\[\/flash\]/i",
	   "<object><param name=movie value=\\1/><embed width=470 height=310 src=\\1></embed></object>", $s);

	// [audio].mp3[/audio]
	$s = preg_replace(
	   "/\[audio\]([^()<>\s]+?)\[\/audio\]/i",
	   "<embed autostart=false loop=false  controller=true width=220 height=42 src=\\1></embed>", $s);

	// Quotes
	$s = format_quotes($s);

	// URLs
	$s = format_urls($s);
//	$s = format_local_urls($s);

	// Linebreaks
//	$s = nl2br($s);

	// [pre]Preformatted[/pre]
	$s = preg_replace("/\[pre\]((\s|.)+?)\[\/pre\]/i", "<tt><nobr>\\1</nobr></tt>", $s);

	// [nfo]NFO-preformatted[/nfo]
	$s = preg_replace("/\[nfo\]((\s|.)+?)\[\/nfo\]/i", "<tt><nobr><font face='MS Linedraw' size=2 style='font-size: 10pt; line-height: " .
		"10pt'>\\1</font></nobr></tt>", $s);

	// Maintain spacing
	$s = str_replace("  ", " &nbsp;", $s);

	// [center]
	$s = preg_replace("/\[center\]((\s|.)+?)\[\/center\]/i", "<center>\\1</center>", $s);

	reset($smilies);
	while (list($code, $url) = each($smilies))
		$s = str_replace($code, "<img border=0 src=\"/pic/smilies/$url\" alt=\"" . htmlspecialchars($code) . "\">", $s);

	reset($privatesmilies);
	while (list($code, $url) = each($privatesmilies))
		$s = str_replace($code, "<img border=0 src=\"/pic/smilies/$url\">", $s);

	return $s;
}

define ('UC_USER', 0);
define ('UC_POWER_USER', 1);
define ('UC_VIP', 2);
define ('UC_UPLOADER', 3);
define ('UC_MODERATOR', 4);
define ('UC_ADMINISTRATOR', 5);
define ('UC_SYSOP', 6);
define ('UC_MIP', 7);

function get_user_class()
{
  global $CURUSER;
  return $CURUSER["class"];
}

function get_user_class_name($class)
{
  switch ($class)
  {
    case UC_USER: return "User<img src= http://www.geotorrents.com/pic/user.jpg  style>";

    case UC_POWER_USER: return "Power User <img src= http://www.geotorrents.com/pic/power.jpg style>";

    case UC_VIP: return "<img src= http://www.geotorrents.com/pic/vip.jpg  style>VIP";

    case UC_UPLOADER: return "<img src= http://www.geotorrents.com/pic/uploader.jpg style>Uploader";

    case UC_MODERATOR: return "Moderator<img src=pic/mod.gif style>";

    case UC_ADMINISTRATOR: return "Administrator<img src=pic/admin.gif style>";

    case UC_SYSOP: return "SySoP<img src=pic/sysop.gif style>";
    
    case UC_MIP: return "Mip<img src=pic/staffleader.gif style>";
}
  return "";
}

function is_valid_user_class($class)
{
  return is_numeric($class) && floor($class) == $class && $class >= UC_USER && $class <= UC_SYSOP;
}

function is_valid_id($id)
{
  return is_numeric($id) && ($id > 0) && (floor($id) == $id);
}

function sql_timestamp_to_unix_timestamp($s)
{
  return mktime(substr($s, 11, 2), substr($s, 14, 2), substr($s, 17, 2), substr($s, 5, 2), substr($s, 8, 2), substr($s, 0, 4));
}

  function get_ratio_color($ratio)
  {
    if ($ratio < 0.1) return "#ff0000";
    if ($ratio < 0.2) return "#ee0000";
    if ($ratio < 0.3) return "#dd0000";
    if ($ratio < 0.4) return "#cc0000";
    if ($ratio < 0.5) return "#bb0000";
    if ($ratio < 0.6) return "#aa0000";
    if ($ratio < 0.7) return "#990000";
    if ($ratio < 0.8) return "#880000";
    if ($ratio < 0.9) return "#770000";
    if ($ratio < 1) return "#660000";
    return "#000000";
  }

  function get_slr_color($ratio)
  {
    if ($ratio < 0.025) return "#ff0000";
    if ($ratio < 0.05) return "#ee0000";
    if ($ratio < 0.075) return "#dd0000";
    if ($ratio < 0.1) return "#cc0000";
    if ($ratio < 0.125) return "#bb0000";
    if ($ratio < 0.15) return "#aa0000";
    if ($ratio < 0.175) return "#990000";
    if ($ratio < 0.2) return "#880000";
    if ($ratio < 0.225) return "#770000";
    if ($ratio < 0.25) return "#660000";
    if ($ratio < 0.275) return "#550000";
    if ($ratio < 0.3) return "#440000";
    if ($ratio < 0.325) return "#330000";
    if ($ratio < 0.35) return "#220000";
    if ($ratio < 0.375) return "#110000";
    return "#000000";
  }

function write_log($text)
{
  $text = sqlesc($text);
  $added = sqlesc(get_date_time());
  mysql_query("INSERT INTO sitelog (added, txt) VALUES($added, $text)") or sqlerr(__FILE__, __LINE__);
}

function get_elapsed_time($ts)
{
  $mins = floor((gmtime() - $ts) / 60);
  $hours = floor($mins / 60);
  $mins -= $hours * 60;
  $days = floor($hours / 24);
  $hours -= $days * 24;
  $weeks = floor($days / 7);
  $days -= $weeks * 7;
  $t = "";
  if ($weeks > 0)
    return "$weeks �����" . ($weeks > 1 ? "�" : "�");
  if ($days > 0)
    return "$days �" . ($days > 1 ? "���" : "���");
  if ($hours > 0)
    return "$hours ���" . ($hours > 1 ? "��" : "");
  if ($mins > 0)
    return "$mins �����" . ($mins > 1 ? "" : "�");
  return "< 1 min";
}

?>