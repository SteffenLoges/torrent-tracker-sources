<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


dbconn(false);

loggedinorreturn();
parked();

$cats = genrelist();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
unset($cleansearchstr);

// sorting by MarkoStamcar

if ($_GET['sort'] && $_GET['type']) {

$column = '';
$ascdesc = '';

switch($_GET['sort']) {
case '1': $column = "name"; break;
case '2': $column = "numfiles"; break;
case '3': $column = "comments"; break;
case '4': $column = "added"; break;
case '5': $column = "size"; break;
case '6': $column = "times_completed"; break;
case '7': $column = "seeders"; break;
case '8': $column = "leechers"; break;
case '9': $column = "owner"; break;
case '10': $column = "ratingsum / numratings"; break;
default: $column = "id"; break;
}

    switch($_GET['type']) {
  case 'asc': $ascdesc = "ASC"; $linkascdesc = "asc"; break;
  case 'desc': $ascdesc = "DESC"; $linkascdesc = "desc"; break;
  default: $ascdesc = "DESC"; $linkascdesc = "desc"; break;
    }


$orderby = "ORDER BY torrents." . $column . " " . $ascdesc;
$pagerlink = "sort=" . intval($_GET['sort']) . "&type=" . $linkascdesc . "&";

} else {

$orderby = "ORDER BY torrents.id DESC";
$pagerlink = "";

}

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
	$addparam .= "incldead=1&amp;";
	if (!isset($CURUSER) || get_user_class() < UC_ADMINISTRATOR)
		$wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
	$addparam .= "incldead=2&amp;";
		$wherea[] = "visible = 'no'";
}
elseif ($_GET["incldead"] == 3)
{
	$addparam .= "incldead=3&amp;";
		$wherea[] = "free = 'yes'";
       	$wherea[] = "visible = 'yes'";
}
elseif ($_GET["incldead"] == 4)
{
	$addparam .= "incldead=4&amp;";
		$wherea[] = "seeders = 0";
		$wherea[] = "visible = 'yes'";
}
	else
		$wherea[] = "visible = 'yes'";

$category = (int)$_GET["cat"];

$all = $_GET["all"];

if (!$all)
	if (!$_GET && $CURUSER["notifs"])
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $cat[id];
	    if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
	    {
	      $wherecatina[] = $cat[id];
	      $addparam .= "c$cat[id]=1&amp;";
	    }
	  }
	}
	elseif ($category)
	{
	  if (!is_valid_id($category))
	    stderr("Error", "Invalid category ID.");
	  $wherecatina[] = $category;
	  $addparam .= "cat=$category&amp;";
	}
	else
	{
	  $all = True;
	  foreach ($cats as $cat)
	  {
	    $all &= $_GET["c$cat[id]"];
	    if ($_GET["c$cat[id]"])
	    {
	      $wherecatina[] = $cat[id];
	      $addparam .= "c$cat[id]=1&amp;";
	    }
	  }
	}

if ($all)
{
	$wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
	$wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
	$wherea[] = "category = $wherecatina[0]";

$wherebase = $wherea;

if (isset($cleansearchstr))
{
	$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
	//$wherea[] = "0";
	$addparam .= "search=" . urlencode($searchstr) . "&amp;";
	//$orderby = "";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
	$where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
	$where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
	$wherea = $wherebase;
	//$orderby = "ORDER BY id DESC";
	$searcha = explode(" ", $cleansearchstr);
	$sc = 0;
	foreach ($searcha as $searchss) {
		if (strlen($searchss) <= 1)
			continue;
		$sc++;
		if ($sc > 5)
			break;
		$ssa = array();
		foreach (array("search_text", "ori_descr") as $sss)
			$ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
		$wherea[] = "(" . implode(" OR ", $ssa) . ")";
	}
	if ($sc) {
		$where = implode(" AND ", $wherea);
		if ($where != "")
			$where = "WHERE $where";
		$res = mysql_query("SELECT COUNT(*) FROM torrents $where");
		$row = mysql_fetch_array($res);
		$count = $row[0];
	}
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
	$torrentsperpage = 15;

if ($count)
{
    if ($addparam != "") {
 if ($pagerlink != "") {
  if ($addparam{strlen($addparam)-1} != ";") { // & = &amp;
    $addparam = $addparam . "&" . $pagerlink;
  } else {
    $addparam = $addparam . $pagerlink;
  }
 }
    } else {
 $addparam = $pagerlink;
    }
	list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);
	$query = "SELECT torrents.id, torrents.category, torrents.leechers, torrents.seeders, torrents.free, torrents.name, torrents.times_completed, torrents.size, torrents.added, torrents.comments,torrents.numfiles,torrents.filename,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
	"IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	"categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
	$res = mysql_query($query) or die(mysql_error());
}
else
	unset($res);
if (isset($cleansearchstr))
	stdhead("���������� ������ ��� \"$searchstr\"");
else
	stdhead("�������");

?>

<STYLE TYPE="text/css" MEDIA=screen>

  a.catlink:link, a.catlink:visited{
		text-decoration: none;
	}

	a.catlink:hover {
		color: #A83838;
	}

</STYLE>

<form method="get" action="browse.php">
<table class=bottom>
<tr>
<td class=bottom>
	<table class=bottom>
	<tr>

<?
$i = 0;
foreach ($cats as $cat)
{
	$catsperrow = 5;
	print(($i && $i % $catsperrow == 0) ? "</tr><tr>" : "");
	print("<td class=bottom style=\"padding-bottom: 2px;padding-left: 7px\"><input name=c$cat[id] type=\"checkbox\" " . (in_array($cat[id],$wherecatina) ? "checked " : "") . "value=1><a class=catlink href=browse.php?cat=$cat[id]>" . htmlspecialchars($cat[name]) . "</a></td>\n");
	$i++;
}

$alllink = "<div align=left>(<a href=browse.php?all=1><b>�������� ���</b></a>)</div>";

$ncats = count($cats);
$nrows = ceil($ncats/$catsperrow);
$lastrowcols = $ncats % $catsperrow;

if ($lastrowcols != 0)
{
	if ($catsperrow - $lastrowcols != 1)
		{
			print("<td class=bottom rowspan=" . ($catsperrow  - $lastrowcols - 1) . ">&nbsp;</td>");
		}
}
?>
	</tr>
	</table>
</td>

<td class=bottom>
<table class=main>
	<tr>
		<td class=bottom style="padding: 1px;padding-left: 10px">
			<select name=incldead>
<option value="0">��������</option>
<option value="1"<? print($_GET["incldead"] == 1 ? " selected" : ""); ?>>������� �������</option>
<option value="2"<? print($_GET["incldead"] == 2 ? " selected" : ""); ?>>������ �������</option>
<option value="3"<? print($_GET["incldead"] == 3 ? " selected" : ""); ?>>������� �������</option>
<option value="4"<? print($_GET["incldead"] == 4 ? " selected" : ""); ?>>��� �����</option>
			</select>
  	</td>
<?
	print("<td class=bottom style=\"padding-left: 5px\">$alllink</td>\n");
if ($ncats % $catsperrow == 0)
	print("<td class=bottom style=\"padding-left: 15px\" rowspan=$nrows valign=center align=right>$alllink</td>\n");
?>

  </tr>
  <tr>
  	<td class=bottom style="padding: 1px;padding-left: 10px">
  	<div align=center>
  		<input type="submit" class=btn value="������!"/>
  	</div>
  	</td>
  </tr>
  </table>
</td>
</tr>
</table>
</form>

<p><p>
<table width=750 class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>
<form method="get" action=browse.php>
<p align="center">
�����:
<input type="text" name="search" size="40" value="<?= htmlspecialchars($searchstr) ?>" />
�
<select name="cat">
<option value="0">(��� ����)</option>
<?


$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
if ($cat["id"] == $_GET["cat"])
$catdropdown .= " selected=\"selected\"";
$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

$deadchkbox = "<input type=\"checkbox\" name=\"incldead\" value=\"1\"";
if ($_GET["incldead"] == 1 OR $_GET["incldead"] == 2)
$deadchkbox .= " checked=\"checked\"";
$deadchkbox .= " /> ������� �������\n";

?>
<?= $catdropdown ?>
</select>
<input type="submit" value="�����!" />
<br />
<?= $deadchkbox ?>
</form>
</td></tr></table>

<?

if (isset($cleansearchstr))
print("<h2>���������� ������ ��� \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
	print($pagertop);

	torrenttable($res);

	print($pagerbottom);
}
else {
	if (isset($cleansearchstr)) {
		print("<h2>������ �� �������</h2>\n");
		print("<p>���������� �������� ������ ������.</p>\n");
	}
	else {
		print("<h2>������ �� �������</h2>\n");
		//print("<p>��������, ������ ��������� ������.</p>\n");
	}
}

stdfoot();

?>