<?

require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();

if (!isset($_GET[user]))
       $user = $CURUSER[id];
else
       $user = $_GET[user];


$res = mysql_query("SELECT username FROM users WHERE id = $user") or sqlerr();
$arr = mysql_fetch_array($res);

stdhead("��������");

$res = mysql_query("SELECT COUNT(id) FROM bookmarks WHERE userid = $user");
$row = mysql_fetch_array($res);
$count = $row[0];

list($pagertop, $pagerbottom, $limit) = pager(25, $count, "bookmarks.php?");

$res = mysql_query("SELECT bookmarks.id as bookmarkid, users.username,users.id as owner, torrents.id, torrents.name, torrents.type, torrents.comments, torrents.leechers, torrents.seeders, ROUND(torrents.ratingsum / torrents.numratings) AS rating, categories.name AS cat_name, categories.image AS cat_pic, torrents.save_as, torrents.numfiles, torrents.added, torrents.filename, torrents.size, torrents.views, torrents.visible, torrents.free, torrents.hits, torrents.times_completed, torrents.category FROM bookmarks LEFT JOIN torrents ON bookmarks.torrentid = torrents.id LEFT JOIN users on torrents.owner = users.id LEFT JOIN categories ON torrents.category = categories.id WHERE bookmarks.userid = $user ORDER BY torrents.id DESC $limit") or sqlerr();

print($pagertop);
torrenttable($res, "index", TRUE);
print($pagerbottom);

stdfoot();

?>