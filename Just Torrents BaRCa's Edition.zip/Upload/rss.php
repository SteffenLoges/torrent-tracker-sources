<?
require "include/bittorrent.php";
dbconn();

$passkey = $_GET["passkey"];
if ($passkey) {
$user = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM users WHERE passkey = '$passkey'"));
if ($user[0] != 1)
exit();
} else
loggedinorreturn();

$feed = $_GET["feed"];

// name a category
$res = mysql_query("SELECT id, name FROM categories");
while($cat = mysql_fetch_assoc($res))
$category[$cat['id']] = $cat['name'];

// RSS Feed description
$DESCR = "RSS Feeds";

// by category ?
if ($_GET['cat'])
$cats = explode(",", $_GET["cat"]);
if ($cats)
$where ="category IN (".implode(", ", $cats).") AND";

// start the RSS feed output
header("Content-Type: application/xml");
print("<?xml version=\"1.0\" encoding=\"windows-1251\" ?>\n<rss version=\"0.91\">\n<channel>\n" .
"<title>" . $SITENAME . "</title>\n<link>" . $BASEURL . "</link>\n<description>" . $DESCR . "</description>\n" .
"<language>en-usde</language>\n<copyright>Copyright � 2006 " . $SITENAME . "</copyright>\n<webMaster>" . $SITEEMAIL . "</webMaster>\n" .
"<image><title>" . $SITENAME . "</title>\n<url>" . $BASEURL . "/favicon.gif</url>\n<link>" . $BASEURL . "</link>\n" .
"<width>16</width>\n<height>16</height>\n<description>" . $DESCR . "</description>\n</image>\n");

// get all vars
$res = mysql_query("SELECT id,name,descr,filename,size,category,seeders,leechers,added FROM torrents WHERE $where visible='yes' ORDER BY added DESC LIMIT 15") or sqlerr(__FILE__, __LINE__);
while ($row = mysql_fetch_row($res)){
list($id,$name,$descr,$filename,$size,$cat,$seeders,$leechers,$added,$catname) = $row;

// seeders ?
if(($seeders) != 1){
$s = "��";
$aktivs="$seeders ���������($s)";
}
else
$aktivs="��� ���������";

// leechers ?
if ($leechers !=1){
$l = "��";
$aktivl="$leechers ��������($l)";
}
else
$aktivl="��� ��������";

// ddl or detail ?
if ($feed == "dl")
$link = "$BASEURL/download.php/$id/". ($passkey ? "$passkey/" : "") ."$filename";
else
$link = "$BASEURL/details.php?id=$id&amp;hit=1";

// measure the totalspeed
if ($seeders >= 1 && $leechers >= 1){
$spd = mysql_query("SELECT (t.size * t.times_completed + SUM(p.downloaded)) / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS totalspeed FROM torrents AS t LEFT JOIN peers AS p ON t.id = p.torrent WHERE p.seeder = 'no' AND p.torrent = '$id' GROUP BY t.id ORDER BY added ASC LIMIT 15") or sqlerr(__FILE__, __LINE__);
$a = mysql_fetch_assoc($spd);
$totalspeed = mksize($a["totalspeed"]) . "/s";
}
else
$totalspeed = "��� ��������";

// output of all data
echo("<item><title>" . htmlspecialchars($name) . "</title>\n<link>" . $link . "</link>\n<description>\n���������: " . $category[$cat] . " \n ������: " . mksize($size) . "\n ������: " . $aktivs . " � " . $aktivl . "\n ��������: " . $totalspeed . "\n ��������: " . $added . "\n ��������:\n " . htmlspecialchars($descr) . "\n</description>\n</item>\n");
}

echo("</channel>\n</rss>\n");
?>