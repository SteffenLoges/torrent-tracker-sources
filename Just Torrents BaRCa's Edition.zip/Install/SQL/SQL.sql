-- phpMyAdmin SQL Dump
-- version 2.6.1-rc1
-- http://www.phpmyadmin.net
-- 
-- ჰოსტი: localhost
-- შექმნის დრო: Oct 20, 2006 at 08:16 PM
-- სერვერის ვერსია: 4.0.27
-- PHP ვერსია: 4.4.1
-- 
-- მონაცემთა ბაზა: `just_cn`
-- 

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `addedrequests`
-- 

CREATE TABLE `addedrequests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `requestid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `addedrequests`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `avps`
-- 

CREATE TABLE `avps` (
  `arg` varchar(20) NOT NULL default '',
  `value_s` text NOT NULL,
  `value_i` int(11) NOT NULL default '0',
  `value_u` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arg`)
) TYPE=MyISAM;

-- 
-- მონაცემები ცხრილიდან  `avps`
-- 

INSERT INTO `avps` VALUES ('lastcleantime', '', 0, 1161359813);

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `bans`
-- 

CREATE TABLE `bans` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `addedby` int(10) unsigned NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `first` int(11) default NULL,
  `last` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `first_last` (`first`,`last`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `bans`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `blocks`
-- 

CREATE TABLE `blocks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `blockid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`blockid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `blocks`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `bookmarks`
-- 

CREATE TABLE `bookmarks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `torrentid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `bookmarks`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `categories`
-- 

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sort` int(10) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=9 ;

-- 
-- მონაცემები ცხრილიდან  `categories`
-- 

INSERT INTO `categories` VALUES (6, 60, 'TV', 'cat_episodes.gif');
INSERT INTO `categories` VALUES (4, 40, 'kinoebi', 'cat_movies.gif');
INSERT INTO `categories` VALUES (3, 30, 'Music', 'cat_music.gif');
INSERT INTO `categories` VALUES (2, 20, 'Tamashebi', 'cat_games.gif');
INSERT INTO `categories` VALUES (1, 10, 'programebi', 'cat_apps.gif');
INSERT INTO `categories` VALUES (7, 70, 'Anime', 'cat_anime.gif');
INSERT INTO `categories` VALUES (8, 80, 'XXX', 'cat_xxx.gif');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `checkcomm`
-- 

CREATE TABLE `checkcomm` (
  `id` int(11) NOT NULL auto_increment,
  `checkid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `offer` tinyint(4) NOT NULL default '0',
  `torrent` tinyint(4) NOT NULL default '0',
  `req` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `checkcomm`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `comments`
-- 

CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `torrent` int(10) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `ori_text` text NOT NULL,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  `request` varchar(11) NOT NULL default '0',
  `offer` varchar(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user` (`user`),
  KEY `torrent` (`torrent`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `comments`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `countries`
-- 

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `flagpic` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=106 ;

-- 
-- მონაცემები ცხრილიდან  `countries`
-- 

INSERT INTO `countries` VALUES (1, 'Geo', 'geo.gif');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `dox`
-- 

CREATE TABLE `dox` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime default NULL,
  `title` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `size` int(10) unsigned NOT NULL default '0',
  `uppedby` int(10) unsigned NOT NULL default '0',
  `url` varchar(255) NOT NULL default '',
  `hits` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `dox`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `files`
-- 

CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `size` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `torrent` (`torrent`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `files`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `forums`
-- 

CREATE TABLE `forums` (
  `sort` tinyint(3) unsigned NOT NULL default '0',
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `description` varchar(200) default NULL,
  `minclassread` tinyint(3) unsigned NOT NULL default '0',
  `minclasswrite` tinyint(3) unsigned NOT NULL default '0',
  `postcount` int(10) unsigned NOT NULL default '0',
  `topiccount` int(10) unsigned NOT NULL default '0',
  `minclasscreate` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- მონაცემები ცხრილიდან  `forums`
-- 

INSERT INTO `forums` VALUES (1, 1, 'Flame', 'zogadi tema', 0, 0, 1, 1, 0);

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `friends`
-- 

CREATE TABLE `friends` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `friendid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`friendid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `friends`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `guests`
-- 

CREATE TABLE `guests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL default '',
  `time_accessed` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=30 ;

-- 
-- მონაცემები ცხრილიდან  `guests`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `messages`
-- 

CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sender` int(10) unsigned NOT NULL default '0',
  `receiver` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `subject` varchar(255) NOT NULL default 'Без темы',
  `msg` text,
  `unread` enum('yes','no') NOT NULL default 'yes',
  `poster` int(10) unsigned NOT NULL default '0',
  `location` tinyint(1) NOT NULL default '1',
  `saved` enum('no','yes') NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `receiver` (`receiver`),
  KEY `sender` (`sender`),
  KEY `poster` (`poster`)
) TYPE=MyISAM AUTO_INCREMENT=16 ;

-- 
-- მონაცემები ცხრილიდან  `messages`
-- 

INSERT INTO `messages` VALUES (1, 0, 3, '2006-10-20 09:29:14', 'Без темы', '�� ���� �������� �� ''�������������'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (2, 0, 3, '2006-10-20 10:05:20', 'Без темы', '�� ���� ����������� �� ''������� ������������'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (3, 0, 3, '2006-10-20 11:44:12', 'Без темы', '�� ���� �������� �� ''<img src= http://www.geotorrents.com/pic/uploader.jpg style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (4, 0, 3, '2006-10-20 11:56:35', 'Без темы', '�� ���� �������� �� ''Moderator<img src=pic/mod.gif style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (5, 0, 3, '2006-10-20 11:56:42', 'Без темы', '�� ���� ����������� �� ''Power User <img src= http://www.geotorrents.com/pic/power.jpg style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (6, 0, 3, '2006-10-20 11:56:47', 'Без темы', '�� ���� ����������� �� ''User<img src= http://www.geotorrents.com/pic/user.jpg  style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (7, 0, 3, '2006-10-20 11:56:55', 'Без темы', '�� ���� �������� �� ''Administrator<img src=pic/admin.gif style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (8, 0, 3, '2006-10-20 11:57:01', 'Без темы', '�� ���� �������� �� ''SySoP<img src=pic/sysop.gif style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (9, 0, 3, '2006-10-20 11:57:12', 'Без темы', '�� ���� ����������� �� ''Power User <img src= http://www.geotorrents.com/pic/power.jpg style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (10, 0, 3, '2006-10-20 12:28:01', 'Без темы', '�� ���� �������� �� ''<img src= http://www.geotorrents.com/pic/uploader.jpg style>Uploader'' TheGame.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (11, 0, 7, '2006-10-20 12:39:18', 'Без темы', '�� ���� �������� �� ''Administrator<img src=pic/admin.gif style>'' TheGame.', 'no', 0, 1, 'no');
INSERT INTO `messages` VALUES (12, 0, 3, '2006-10-20 13:18:45', 'Без темы', '�� ���� ����������� �� ''Power User <img src= http://www.geotorrents.com/pic/power.jpg style>'' BARCA.', 'yes', 0, 1, 'no');
INSERT INTO `messages` VALUES (13, 0, 8, '2006-10-20 15:11:09', 'Без темы', '�� ���� �������� �� ''Administrator<img src=pic/admin.gif style>'' BARCA.', 'no', 0, 1, 'no');
INSERT INTO `messages` VALUES (15, 1, 8, '2006-10-20 15:57:38', 'Re: A', 'ki :D\r\n\r\n-------- MaSaKeLa �����(�): --------\r\nAK XAR?', 'no', 1, 1, 'no');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `news`
-- 

CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `body` text NOT NULL,
  `subject` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `news`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `notconnectablepmlog`
-- 

CREATE TABLE `notconnectablepmlog` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `date` datetime default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `notconnectablepmlog`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `offers`
-- 

CREATE TABLE `offers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `name` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `category` int(11) NOT NULL default '0',
  `comments` int(11) NOT NULL default '0',
  `votes` smallint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `offers`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `offervotes`
-- 

CREATE TABLE `offervotes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `offerid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `offervotes`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `peers`
-- 

CREATE TABLE `peers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `peer_id` varchar(20) NOT NULL default '',
  `ip` varchar(64) NOT NULL default '',
  `port` smallint(5) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `to_go` bigint(20) unsigned NOT NULL default '0',
  `seeder` enum('yes','no') NOT NULL default 'no',
  `started` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL default 'yes',
  `userid` int(10) unsigned NOT NULL default '0',
  `agent` varchar(60) NOT NULL default '',
  `finishedat` int(10) unsigned NOT NULL default '0',
  `downloadoffset` bigint(20) unsigned NOT NULL default '0',
  `uploadoffset` bigint(20) unsigned NOT NULL default '0',
  `passkey` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `torrent_peer_id` (`torrent`,`peer_id`),
  KEY `torrent` (`torrent`),
  KEY `torrent_seeder` (`torrent`,`seeder`),
  KEY `last_action` (`last_action`),
  KEY `connectable` (`connectable`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `peers`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `pollanswers`
-- 

CREATE TABLE `pollanswers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pollid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `selection` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`),
  KEY `selection` (`selection`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

-- 
-- მონაცემები ცხრილიდან  `pollanswers`
-- 

INSERT INTO `pollanswers` VALUES (1, 1, 1, 4);
INSERT INTO `pollanswers` VALUES (2, 1, 5, 255);
INSERT INTO `pollanswers` VALUES (3, 1, 6, 0);
INSERT INTO `pollanswers` VALUES (4, 1, 7, 0);
INSERT INTO `pollanswers` VALUES (5, 1, 8, 0);

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `polls`
-- 

CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `question` varchar(255) NOT NULL default '',
  `option0` varchar(40) NOT NULL default '',
  `option1` varchar(40) NOT NULL default '',
  `option2` varchar(40) NOT NULL default '',
  `option3` varchar(40) NOT NULL default '',
  `option4` varchar(40) NOT NULL default '',
  `option5` varchar(40) NOT NULL default '',
  `option6` varchar(40) NOT NULL default '',
  `option7` varchar(40) NOT NULL default '',
  `option8` varchar(40) NOT NULL default '',
  `option9` varchar(40) NOT NULL default '',
  `option10` varchar(40) NOT NULL default '',
  `option11` varchar(40) NOT NULL default '',
  `option12` varchar(40) NOT NULL default '',
  `option13` varchar(40) NOT NULL default '',
  `option14` varchar(40) NOT NULL default '',
  `option15` varchar(40) NOT NULL default '',
  `option16` varchar(40) NOT NULL default '',
  `option17` varchar(40) NOT NULL default '',
  `option18` varchar(40) NOT NULL default '',
  `option19` varchar(40) NOT NULL default '',
  `sort` enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- მონაცემები ცხრილიდან  `polls`
-- 

INSERT INTO `polls` VALUES (1, '2006-10-19 20:23:41', 'kai saitia ? :D', 'ki', 'ki :lol:', 'ki :D', 'ki :lol:', 'dzaan magaria :lol: :lol: :lol:', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `posts`
-- 

CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `topicid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `body` text,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `userid` (`userid`),
  FULLTEXT KEY `body` (`body`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- 
-- მონაცემები ცხრილიდან  `posts`
-- 

INSERT INTO `posts` VALUES (1, 1, 6, '2006-10-20 12:24:46', 'Ilaparaketmrazec gidnat :)', 0, '0000-00-00 00:00:00');
INSERT INTO `posts` VALUES (2, 1, 1, '2006-10-20 16:01:06', 'mshia :lol:', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `ratings`
-- 

CREATE TABLE `ratings` (
  `id` int(6) NOT NULL auto_increment,
  `torrent` int(10) NOT NULL default '0',
  `user` int(6) NOT NULL default '0',
  `rating` int(1) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `ratings`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `readposts`
-- 

CREATE TABLE `readposts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `topicid` int(10) unsigned NOT NULL default '0',
  `lastpostread` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`id`),
  KEY `topicid` (`topicid`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

-- 
-- მონაცემები ცხრილიდან  `readposts`
-- 

INSERT INTO `readposts` VALUES (1, 6, 1, 1);
INSERT INTO `readposts` VALUES (2, 1, 1, 2);
INSERT INTO `readposts` VALUES (3, 8, 1, 1);

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `requests`
-- 

CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `request` varchar(225) default NULL,
  `descr` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL default '0',
  `uploaded` enum('yes','no') NOT NULL default 'no',
  `filled` varchar(200) NOT NULL default '',
  `torrentid` int(10) unsigned NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `cat` int(10) unsigned NOT NULL default '0',
  `filledby` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `requests`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `sb_config`
-- 

CREATE TABLE `sb_config` (
  `admin_name` varchar(32) NOT NULL default '',
  `admin_pass` varchar(32) NOT NULL default '',
  `admin_email` varchar(60) NOT NULL default '',
  `shout_limit` int(11) NOT NULL default '0',
  `spam_limit` int(11) NOT NULL default '0',
  `date_format` varchar(10) NOT NULL default '',
  `allowed_tags` varchar(20) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- მონაცემები ცხრილიდან  `sb_config`
-- 

INSERT INTO `sb_config` VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@domain.com', 20, 30, '', '<a><b><i><u>');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `sb_shouts`
-- 

CREATE TABLE `sb_shouts` (
  `ID` int(11) NOT NULL auto_increment,
  `timenow` varchar(20) NOT NULL default '',
  `author` varchar(50) NOT NULL default '',
  `homepage` varchar(50) default NULL,
  `shout` text NOT NULL,
  `ip` varchar(15) NOT NULL default '',
  `spam` int(20) NOT NULL default '0',
  KEY `ID` (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `sb_shouts`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `shoutbox`
-- 

CREATE TABLE `shoutbox` (
  `msgid` int(10) unsigned NOT NULL auto_increment,
  `user` varchar(50) NOT NULL default '0',
  `message` text,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `userid` int(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`msgid`),
  KEY `msgid` (`msgid`)
) TYPE=MyISAM AUTO_INCREMENT=20 ;

-- 
-- მონაცემები ცხრილიდან  `shoutbox`
-- 

INSERT INTO `shoutbox` VALUES (18, 'MaSaKeLa', ';)', '2006-10-20 19:23:45', 8);
INSERT INTO `shoutbox` VALUES (19, 'BARCA', 'ver gavakete caucasusze ar gaketda :D', '2006-10-20 19:40:25', 1);
INSERT INTO `shoutbox` VALUES (17, 'MaSaKeLa', ':) GEOTORENIVIT IKNEBAO AB :d', '2006-10-20 19:23:36', 8);
INSERT INTO `shoutbox` VALUES (16, 'BARCA', 'ki', '2006-10-20 19:23:13', 1);
INSERT INTO `shoutbox` VALUES (15, 'MaSaKeLa', 'AK XAR?', '2006-10-20 19:20:36', 8);

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `shoutbox_censor`
-- 

CREATE TABLE `shoutbox_censor` (
  `word` varchar(10) default '0',
  KEY `word` (`word`)
) TYPE=MyISAM;

-- 
-- მონაცემები ცხრილიდან  `shoutbox_censor`
-- 

INSERT INTO `shoutbox_censor` VALUES ('cock');
INSERT INTO `shoutbox_censor` VALUES ('fuck');
INSERT INTO `shoutbox_censor` VALUES ('shit');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `shoutbox_emoticons`
-- 

CREATE TABLE `shoutbox_emoticons` (
  `id` int(9) NOT NULL auto_increment,
  `text` varchar(20) NOT NULL default '',
  `image` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=24 ;

-- 
-- მონაცემები ცხრილიდან  `shoutbox_emoticons`
-- 

INSERT INTO `shoutbox_emoticons` VALUES (1, '%-|', 'confused.gif');
INSERT INTO `shoutbox_emoticons` VALUES (2, '%-(', 'sigh.gif');
INSERT INTO `shoutbox_emoticons` VALUES (3, 'X-|', 'sleep.gif');
INSERT INTO `shoutbox_emoticons` VALUES (4, ':-(', 'upset.gif');
INSERT INTO `shoutbox_emoticons` VALUES (5, '$-|', 'rolleyes.gif');
INSERT INTO `shoutbox_emoticons` VALUES (6, ':mad:', 'mad.gif');
INSERT INTO `shoutbox_emoticons` VALUES (7, ':yes:', 'yes.gif');
INSERT INTO `shoutbox_emoticons` VALUES (8, ':no:', 'no.gif');
INSERT INTO `shoutbox_emoticons` VALUES (9, ':shy:', 'shy.gif');
INSERT INTO `shoutbox_emoticons` VALUES (10, ':laugh:', 'laugh.gif');
INSERT INTO `shoutbox_emoticons` VALUES (11, ':dead:', 'dead.gif');
INSERT INTO `shoutbox_emoticons` VALUES (12, ':cry:', 'cry.gif');
INSERT INTO `shoutbox_emoticons` VALUES (13, ':-)', 'smile.gif');
INSERT INTO `shoutbox_emoticons` VALUES (14, ':-(', 'sad.gif');
INSERT INTO `shoutbox_emoticons` VALUES (15, ';-)', 'smilewinkgrin.gif');
INSERT INTO `shoutbox_emoticons` VALUES (16, ':-|', 'none.gif');
INSERT INTO `shoutbox_emoticons` VALUES (17, 'B-)', 'cool.gif');
INSERT INTO `shoutbox_emoticons` VALUES (18, ':-D', 'biggrin.gif');
INSERT INTO `shoutbox_emoticons` VALUES (19, ':-b', 'bigrazz.gif');
INSERT INTO `shoutbox_emoticons` VALUES (20, ':-o', 'bigeek.gif');
INSERT INTO `shoutbox_emoticons` VALUES (21, ':)', 'smile.gif');
INSERT INTO `shoutbox_emoticons` VALUES (22, ':D', 'biggrin.gif');
INSERT INTO `shoutbox_emoticons` VALUES (23, ':(', 'sad.gif');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `sitelog`
-- 

CREATE TABLE `sitelog` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime default NULL,
  `txt` text,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- 
-- მონაცემები ცხრილიდან  `sitelog`
-- 

INSERT INTO `sitelog` VALUES (1, '2006-10-19 20:54:30', 'User account 123333 was deleted by BARCA');
INSERT INTO `sitelog` VALUES (2, '2006-10-20 11:20:05', 'User account MostWanteD was deleted by BARCA');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `stylesheets`
-- 

CREATE TABLE `stylesheets` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uri` varchar(255) NOT NULL default '',
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- 
-- მონაცემები ცხრილიდან  `stylesheets`
-- 

INSERT INTO `stylesheets` VALUES (1, 'V-IX', 'V-IX');
INSERT INTO `stylesheets` VALUES (2, 'StreamZone', 'StreamZone');

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `thanks`
-- 

CREATE TABLE `thanks` (
  `torrentid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `thanks`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `topics`
-- 

CREATE TABLE `topics` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `subject` varchar(40) default NULL,
  `locked` enum('yes','no') NOT NULL default 'no',
  `forumid` int(10) unsigned NOT NULL default '0',
  `lastpost` int(10) unsigned NOT NULL default '0',
  `sticky` enum('yes','no') NOT NULL default 'no',
  `views` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`),
  KEY `subject` (`subject`),
  KEY `lastpost` (`lastpost`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- მონაცემები ცხრილიდან  `topics`
-- 

INSERT INTO `topics` VALUES (1, 6, 'TOPIC FOR OFFTOPIC', 'no', 1, 2, 'no', 7);

-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `torrents`
-- 

CREATE TABLE `torrents` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `info_hash` varchar(20) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `save_as` varchar(255) NOT NULL default '',
  `search_text` text NOT NULL,
  `descr` text NOT NULL,
  `ori_descr` text NOT NULL,
  `image1` text NOT NULL,
  `image2` text NOT NULL,
  `category` int(10) unsigned NOT NULL default '0',
  `size` bigint(20) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` enum('single','multi') NOT NULL default 'single',
  `numfiles` int(10) unsigned NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `views` int(10) unsigned NOT NULL default '0',
  `hits` int(10) unsigned NOT NULL default '0',
  `times_completed` int(10) unsigned NOT NULL default '0',
  `leechers` int(10) unsigned NOT NULL default '0',
  `seeders` int(10) unsigned NOT NULL default '0',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `visible` enum('yes','no') NOT NULL default 'yes',
  `banned` enum('yes','no') NOT NULL default 'no',
  `owner` int(10) unsigned NOT NULL default '0',
  `numratings` int(10) unsigned NOT NULL default '0',
  `ratingsum` int(10) unsigned NOT NULL default '0',
  `nfo` text NOT NULL,
  `free` enum('yes','no') default 'no',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `info_hash` (`info_hash`),
  KEY `owner` (`owner`),
  KEY `visible` (`visible`),
  KEY `category_visible` (`category`,`visible`),
  FULLTEXT KEY `ft_search` (`search_text`,`ori_descr`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- მონაცემები ცხრილიდან  `torrents`
-- 


-- --------------------------------------------------------

-- 
-- ცხრილის სტრუქტურა. ცხრილი: `users`
-- 

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(40) NOT NULL default '',
  `old_password` varchar(40) NOT NULL default '',
  `passhash` varchar(32) NOT NULL default '',
  `secret` varchar(20) NOT NULL default '',
  `email` varchar(80) NOT NULL default '',
  `status` enum('pending','confirmed') NOT NULL default 'pending',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL default '0000-00-00 00:00:00',
  `editsecret` varchar(20) NOT NULL default '',
  `privacy` enum('strong','normal','low') NOT NULL default 'normal',
  `stylesheet` int(10) default '1',
  `info` text,
  `acceptpms` enum('yes','friends','no') NOT NULL default 'yes',
  `ip` varchar(15) NOT NULL default '',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `override_class` tinyint(3) unsigned NOT NULL default '255',
  `support` enum('no','yes') NOT NULL default 'no',
  `supportfor` varchar(60) default NULL,
  `avatar` varchar(100) NOT NULL default '',
  `icq` varchar(255) NOT NULL default '',
  `msn` varchar(255) NOT NULL default '',
  `aim` varchar(255) NOT NULL default '',
  `yahoo` varchar(255) NOT NULL default '',
  `skype` varchar(255) NOT NULL default '',
  `mirc` varchar(255) NOT NULL default '',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `title` varchar(30) NOT NULL default '',
  `country` int(10) unsigned NOT NULL default '0',
  `notifs` varchar(100) NOT NULL default '',
  `modcomment` text NOT NULL,
  `enabled` enum('yes','no') NOT NULL default 'yes',
  `parked` enum('yes','no') NOT NULL default 'no',
  `avatars` enum('yes','no') NOT NULL default 'yes',
  `donor` enum('yes','no') NOT NULL default 'no',
  `warned` enum('yes','no') NOT NULL default 'no',
  `warneduntil` datetime NOT NULL default '0000-00-00 00:00:00',
  `torrentsperpage` int(3) unsigned NOT NULL default '0',
  `topicsperpage` int(3) unsigned NOT NULL default '0',
  `postsperpage` int(3) unsigned NOT NULL default '0',
  `deletepms` enum('yes','no') NOT NULL default 'yes',
  `savepms` enum('yes','no') NOT NULL default 'no',
  `gender` enum('Парень','Девушка','Н/Д') NOT NULL default 'Парень',
  `birthday` date default '0000-00-00',
  `passkey` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status_added` (`status`,`added`),
  KEY `ip` (`ip`),
  KEY `uploaded` (`uploaded`),
  KEY `downloaded` (`downloaded`),
  KEY `country` (`country`),
  KEY `last_access` (`last_access`),
  KEY `enabled` (`enabled`),
  KEY `warned` (`warned`)
) TYPE=MyISAM AUTO_INCREMENT=9 ;

-- 
-- მონაცემები ცხრილიდან  `users`
-- 

INSERT INTO `users` VALUES (1, 'BARCA', '', '44a9237921f49aa66f6d8454ba1102b1', 'ɨ?뎐۷Κ???}[?Q?', 'Barc@avoe.ge', 'confirmed', '2006-10-19 20:09:18', '2006-10-20 00:09:28', '2006-10-20 16:02:01', '', 'normal', 1, '', 'yes', '88.210.208.91', 7, 255, 'yes', 'all about torrent', 'http://images.ge/uploads/6b59de8ea7.gif', '', '', '', '', 'fcbarca2', '', 123321123321123321, 123321123333333, 'JusTSySoP', 1, '', '', 'yes', 'no', 'yes', 'yes', 'no', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'no', '', '1993-01-25', '052db3a8e2962137969a6a2ed1da750f');
INSERT INTO `users` VALUES (3, 'CooL_LevA', '', 'a6b7e2cc66368f2ed0754f2c3c846c16', '��|�}Ԋ���ֱ��эu', 'cool_kvercxi@caucasus.net', 'confirmed', '2006-10-20 13:28:50', '0000-00-00 00:00:00', '2006-10-20 13:28:50', '', 'normal', 1, NULL, 'yes', '', 1, 255, 'no', '', '', '', '', '', '', '', '', 0, 0, '', 0, '', '', 'yes', 'no', 'yes', 'no', 'no', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'no', 'Парень', '0000-00-00', '');
INSERT INTO `users` VALUES (6, 'TheGame', '', 'cccfa11881091ff7aa0641ff7f35486f', 'ז`$?Ļ?ot;੾?+? si', 'ika_mer@hotmail.com', 'confirmed', '2006-10-20 11:57:31', '2006-10-20 15:58:21', '2006-10-20 12:44:13', ']?Û?????s[ο?', 'normal', 1, NULL, 'yes', '88.210.199.35', 6, 255, 'yes', 'all about torrent', '', '', '', '', '', '', '', 1111111111, 111, '', 1, '', '', 'yes', 'no', 'yes', 'yes', 'no', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'no', 'Парень', '1920-01-01', '');
INSERT INTO `users` VALUES (7, 'Baraba', '', '63100d478c3ccaacf578f97f39bcdc6c', '��Z���n,\rWůz�3w���7', 'Baraba2@rambler.ru', 'confirmed', '2006-10-20 12:32:42', '2006-10-20 16:39:57', '2006-10-20 13:28:19', '��IpO��z��V��� �͙', 'normal', 1, NULL, 'yes', '80.241.240.73', 5, 255, 'no', '', '', 'ar maqvs', 'ar maqvs', 'ar maqvs', 'ar maqvs', 'Levani8318', 'ar maqvs', 0, 0, '', 1, '', '2006-10-20 - ������� �� ''Administrator'' TheGame.\r\n', 'yes', 'no', 'yes', 'no', 'no', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'no', '', '1970-05-09', '');
INSERT INTO `users` VALUES (8, 'MaSaKeLa', '', '7756aa79b885c0297b4f2823cc18c89d', '\0���; �������r�', 'ESM_SIXA@YAHOO.COM', 'confirmed', '2006-10-20 14:58:30', '2006-10-20 19:19:50', '2006-10-20 16:10:38', '\nM�0�[��R��q��V��f', 'normal', 1, '', 'yes', '212.72.155.13', 5, 255, 'no', '', '', '', '', '', '', '', '', 0, 0, '', 7, '', ' BARCA.\r\n', 'yes', 'no', 'yes', 'no', 'no', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'no', '', '1990-10-13', 'f67304c84fc9fd530be65e33a44e9adb');
