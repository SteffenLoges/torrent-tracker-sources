<?
ob_start("ob_gzhandler");
require_once "backend/functions.php";
userlogin();
loggedinonly();

//SOME FUNCTIONS AND SQL
function maketable($res)
{
  $ret = "<table class=table_table border=1 cellspacing=0 cellpadding=2>" .
    "<tr><td class=table_head>" . NAME . "</td><td class=table_head align=center>" . SIZE . "</td><td class=table_head align=center>" . UPLOADED . "</td>\n" .
    "<td class=table_head align=center>" . DOWNLOADED . "</td><td class=table_head align=center>" . RATIO . "</td></tr>\n";
  while ($arr = mysql_fetch_assoc($res))
  {
    $res2 = mysql_query("SELECT name,size FROM torrents WHERE id=$arr[torrent] ORDER BY name");
    $arr2 = mysql_fetch_assoc($res2);
    if ($arr["downloaded"] > 0)
    {
      $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 2);
      $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";
    }
    else
      if ($arr["uploaded"] > 0)
        $ratio = "Inf.";
      else
        $ratio = "---";
    $ret .= "<tr><td class=table_col1><a href=torrents-details.php?id=$arr[torrent]&amp;hit=1><b>" . htmlspecialchars($arr2[name]) . "</b></a></td><td align=center class=table_col2>" . mksize($arr2["size"]) . "</td><td align=center class=table_col1>" . mksize($arr["uploaded"]) . "</td><td align=center class=table_col2>" . mksize($arr["downloaded"]) . "</td><td align=center class=table_col1>$ratio</td></tr>\n";
  }
  $ret .= "</table>\n";
  return $ret;
}

$user = (string)$_GET['user'];

if (!validusername($user))
  bark("Can't show details", "Bad Username.");

//$r = @mysql_query("SELECT * FROM users WHERE id=$id") or sqlerr();
//$user = mysql_fetch_array($r) or  bark("Can't show details", "No user with ID $id.");
if (!file_exists("{$site_config['userdir']}/".strtolower($user).".dat"))
	bark("Can't show details", "No such user");

$user = readuserfile("{$site_config['userdir']}/".strtolower($user).".dat");

if ($user["status"] == "pending") die;
/*$r = mysql_query("SELECT * FROM torrents WHERE owner=$id ORDER BY name ASC") or sqlerr();
if (mysql_num_rows($r) > 0)
{
  $torrents = "<table class=table_table border=1 cellspacing=0 cellpadding=2>\n" .
    "<tr><td class=table_head>" . NAME . "</td><td class=table_head>" . SEEDS . "</td><td class=table_head>" . LEECH . "</td></tr>\n";
  while ($a = mysql_fetch_assoc($r))
  {
      $torrents .= "<tr><td class=table_col1><a href=torrents-details.php?id=" . $a["id"] . "&hit=1><b>" . htmlspecialchars($a["name"]) . "</b></a></td>" .
        "<td align=right class=table_col2>$a[seeders]</td><td align=right class=table_col1>$a[leechers]</td></tr>\n";
  }
  $torrents .= "</table>";
}

$res87 = mysql_query("SELECT COUNT(*) FROM torrents WHERE owner=$id") or sqlerr();
$arr387 = mysql_fetch_row($res87);
$torrenttorrents = $arr387[0];*/

$torrentsposted = 0;
	if (!file_exists("data/torrents.dat"))
		touch("data/torrents.dat");
	
	$source = fopen("data/torrents.dat", "r");
    while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s\n")) {
		list ($info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader) = $info;
		if ($uploader == $user['username']) $torrentsposted++;
	}
	fclose($source);

if ($user["ip"] && !(get_user_class() < UC_JMODERATOR && $user["class"] >= UC_UPLOADER))
{
	$limited = $CURUSER['id'] != $id && get_user_class() < UC_JMODERATOR;
  if ($limited)
    $ip = substr($user["ip"], 0, strrpos($user["ip"], ".") + 1) . "xxx";
  else
    $ip = $user["ip"];
  $dom = @gethostbyaddr($user["ip"]);
  if ($dom == $user["ip"] || @gethostbyname($dom) != $user["ip"])
    $addr = $ip;
  else
  {
    $dom = strtoupper($dom);
    $domparts = explode(".", $dom);
    $domain = $domparts[count($domparts) - 2];
    if ($domain == "COM" || $domain == "CO" || $domain == "NET" || $domain == "NE" || $domain == "ORG" || $domain == "OR" )
      $l = 2;
    else
      $l = 1;
    if ($limited)
      while (substr_count($dom, ".") > $l)
        $dom = substr($dom, strpos($dom, ".") + 1);
    $addr = "$ip ($dom)";
  }
}
if ($user[added] == "0000-00-00 00:00:00")
  $joindate = 'N/A';
else
  $joindate = "$user[added] (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($user["added"])) . " ago)";
$lastseen = $user["last_access"];
if ($lastseen == "0000-00-00 00:00:00")
	$lastseen = "never";
else
	$lastseen .= " (" . get_elapsed_time(sql_timestamp_to_unix_timestamp($lastseen)) . " ago)";

if ($user['donated'] > 0)
  $don = "<img src=pic/starbig.gif>";

/*$res = mysql_query("SELECT name,flagpic FROM countries WHERE id=$user[country] LIMIT 1") or sqlerr();
if (mysql_num_rows($res) == 1)
{
  $arr = mysql_fetch_assoc($res);
  $country = "$arr[name]";
} // How should i do countries?

$res = mysql_query("SELECT torrent,uploaded,downloaded FROM peers WHERE ip='$user[ip]' AND seeder='no'");
if (mysql_num_rows($res) > 0)
  $leeching = maketable($res);
$res = mysql_query("SELECT torrent,uploaded,downloaded FROM peers WHERE ip='$user[ip]' AND seeder='yes'");
if (mysql_num_rows($res) > 0)
  $seeding = maketable($res);
  
  */

$avatar = $user["avatar"];
if (!$avatar) {
	$avatar = "images/default_avatar.gif";
}

$enabled = $user["enabled"] == 'yes';
$warned = $user["warned"] == 'yes';
$privacylevel = $user["privacy"];

//Table formatting starts here ***************************
site_header("User Details for " . $user["username"]);
begin_frame("User Details for " . $user["username"] . "");
?>
<table width=100% border=0><tr><td width=50% valign=top>
	<table width=100% border=0 cellpadding=0 cellspacing=0><tr><td width=100% valign=top>

<table width=100% border=1 align=center cellpadding=2 cellspacing=1 style='border-collapse: collapse' bordercolor=#646262>
<TR><TD width=100% valign=middle class=table_head height=30><b>Viewing Profile: <?=$user["username"]?> </b></TD></TR>
<TR><TD><DIV style="margin-left: 8pt">
<?
print("<h1>$user[username]</h1><img width=80 height=80 src=$avatar alt=$title><br><b><i>$user[title]</b></i>");
if (!$enabled)
  print("<br><b>" . ACCOUNT_DISABLED . "</b>");

?>
<BR>Joined: <?=$joindate?>
<BR>User Class: <?=get_user_class_name($user["class"])?>
<BR><BR><a href=account-torrents.php?id=<?=$user[id]?>><b>View File Upload/Download Details</b></a>
<BR><BR></div>
</TD></TR></TABLE>
<BR>
		<table width=100% border=1 align=center cellpadding=2 cellspacing=1 style='border-collapse: collapse' bordercolor=#646262><TR><TD width=100% valign=middle class=table_head height=30><B>Information:</B></TD></TR>
		<TR><TD>
			<table width=100% border=0 cellspacing=0 cellpadding=3>
			<tr><td><?echo "" . LAST_ACCESS . "";?>: </td><td align=left><?=$lastseen?></td></tr>
			<tr><td><?echo "" . COUNTRY . "";?>: </td><td align=left><?=$CURUSER['country']?></td></tr>
			<tr><td><?echo "" . AGE . "";?>: </td><td align=left><?=$user["age"]?></td></tr>
			<tr><td><?echo "" . GENDER . "";?>: </td><td align=left><?=$user["gender"]?></td></tr>
			<tr><td><?echo "" . CLIENT . "";?>: </td><td align=left><?=$user["client"]?></td></tr>
			<tr><td><?echo "" . WARNED . "";?>: </td><td align=left><?=$user["warned"]?></td></tr>
			<tr><td><?echo "" . TORRENTS_POSTED . "";?>: </td><td align=left><?=$torrentsposted?></td></tr>
			</TABLE>
		</TD></TR></TABLE>
<!--  -->
	</TD></TR></TABLE>
	<td width=10 valign=top>&nbsp;</td>
</td><td width=50% valign=top>
	<table width=100% border=0 cellpadding=0 cellspacing=0><tr><td width=100% valign=top>
		<table width=100% border=1 align=center cellpadding=2 cellspacing=1 style='border-collapse: collapse' bordercolor=#646262><TR><TD width=100% valign=middle class=table_head height=30><B>Statistics:</B></TD></TR>
		<TR><TD>
		<table width=100% border=0 cellspacing=0 cellpadding=3>
		<?
		if ($privacylevel == "strong"){?>
			<tr><td><?echo "" . UPLOADED . "";?>: </td><td align=left>---</td></tr>
			<tr><td><?echo "" . DOWNLOADED . "";?>: </td><td align=left>---</td></tr>
		<?}else{?>
<tr><td><?echo "" . UPLOADED . "";?>: </td><td align=left><?=mksize($user["uploaded"])?></td></tr>
<tr><td><?echo "" . DOWNLOADED . "";?>: </td><td align=left><?=mksize($user["downloaded"])?></td></tr>
<tr><td><?echo "Avg Daily DL:";?></td><td align=left><?=mksize($user["downloaded"] / $user["added"])?></td></tr>
<tr><td><?echo "Avg Daily UL:";?></td><td align=left><?=mksize($user["uploaded"] / $user["added"])?></td></tr>
<?
		}

  if ($user["downloaded"] > 0)
  {
    $sr = $user["uploaded"] / $user["downloaded"];
    if ($sr >= 4)
      $s = "w00t";
    else if ($sr >= 2)
      $s = "grin";
    else if ($sr >= 1)
      $s = "smile1";
    else if ($sr >= 0.5)
      $s = "noexpression";
    else if ($sr >= 0.25)
      $s = "sad";
    else
      $s = "cry";
    $sr = "<table border=0 cellspacing=0 cellpadding=0><tr><td class=embedded><font color=" . get_ratio_color($sr) . ">" . number_format($sr, 2) . "</font></td><td class=embedded>&nbsp;&nbsp;<img src=$site_config[SITEURL]/images/smilies/$s.gif></td></tr></table>";
    print("<tr><td style='vertical-align: middle'>" . RATIO . ": </td><td align=left valign=center style='padding-top: 1px; padding-bottom: 0px'>$sr</td></tr>\n");
  }
  ?>
		</table>
		</TD></TR>
		</TABLE>

		<?
		//now do the mod only stuff
if (get_user_class() >= UC_JMODERATOR)
{?>
		<br>
		<table width=100% border=1 align=center cellpadding=2 cellspacing=1 style='border-collapse: collapse' bordercolor=#646262><TR><TD width=100% valign=middle bgcolor=green height=30><B>Moderator Only:</B></TD></TR>
		<TR><TD>
		<table width=100% border=0 cellspacing=0 cellpadding=3>
   <?
	print("<tr><td>Email: </td><td align=left>$user[email] - <a href=account-inbox.php?receiver=$user[username]>Send PM</a></td></tr>\n");
  if ($addr)
    print("<tr><td>IP Address: </td><td align=left>$user[ip]</td></tr>\n");
    print("<tr><td>Host: </td><td align=left>$dom</td></tr>\n");
	?>
	<tr><td><?echo "" . UPLOADED . "";?>: </td><td align=left><?=mksize($user["uploaded"])?></td></tr>
	<tr><td><?echo "" . DOWNLOADED . "";?>: </td><td align=left><?=mksize($user["downloaded"])?></td></tr>
	<tr><td><?echo "" . DONATED . "";?>: </td><td align=left><?=$user["donated"]?></td></tr>
		</table>
		</td></tr></table>
<?}?>

	</td></tr></table>
</td></tr></table><BR>
<?
if ($torrents)
  print("<B>" . UPLOADED_TORRENTS . ":</B><BR>$torrents<BR><BR>");
if ($seeding)
  print("<B>" . CURRENTLY_SEEDING . ":</B><BR>$seeding<BR><BR>");
if ($leeching)
  print("<B>" . CURRENTLY_LEECHING . ":</B><br>$leeching<BR><BR>");
end_frame();

echo "<br /><br />";

if (get_user_class() >= UC_JMODERATOR && ($CURUSER["class"] > $user["class"] || get_user_class() >= UC_ADMINISTRATOR))
{
  begin_frame("Moderator Options", center);
  print("<form method=post action=modtask.php>\n");
  print("<input type=hidden name='action' value='edituser'>\n");
  print("<input type=hidden name='username' value='$user[username]'>\n");
  print("<table border=0 cellspacing=0 cellpadding=3>\n");
  print("<tr><td>Title</td><td align=left><input type=text size=60 name=title value=\"$user[title]\"></tr>\n");
$avatar = htmlspecialchars($user["avatar"]);
  //print("<tr><td>Signature</td><td align=left><textarea type=text cols=50 rows=10 name=signature>".htmlspecialchars($user["signature"])."</textarea></tr>\n");
$signature = htmlspecialchars($user["signature"]);
  print("<tr><td>Uploaded</td><td align=left><input type=text size=30 name=uploaded value=\"$user[uploaded]\">&nbsp;&nbsp;".mksize($user[uploaded])."</tr>\n");
  print("<tr><td>Downloaded</td><td align=left><input type=text size=30 name=downloaded value=\"$user[downloaded]\">&nbsp;&nbsp;".mksize($user[downloaded])."</tr>\n");
  print("<tr><td>Avatar URL</td><td align=left><input type=text size=60 name=avatar value=\"$avatar\"></tr>\n");
  print("<tr><td>IP Address</td><td align=left><input type=text size=20 name=ip value=\"$ip\"></tr>\n");
  print("<tr><td>Class</td><td align=left><select name=class>\n");
 $maxclass = get_user_class();
  for ($i=0; $i < $maxclass; $i++) {
  $s = get_user_class_name($i);
  if ($s === false) continue;
  print("<option value=$i" . ($user["class"] == $i ? " selected" : "") . ">".$s."</option>\n");
  }
  if (get_user_class() == UC_ADMINISTRATOR) print("<option value=".UC_ADMINISTRATOR.">".get_user_class_name(UC_ADMINISTRATOR)."</option>\n");
  print("</select></td></tr>\n");

	$modcomment = htmlspecialchars($user["modcomment"]);
  print("<tr><td>US$&nbsp;Donated</td><td align=left><input type=text size=4 name=donated value=$user[donated]></tr>\n");
  print("<tr><td>Password</td><td align=left><input type=password size=60 name=password value=\"$user[password]\"></tr>\n");
  print("<tr><td>Change Password:</td><td align=left><input type=checkbox name=chgpasswd value='yes'/></td></tr>");
  print("<tr><td>Mod Comment</td><td align=left><textarea cols=60 rows=8 name=modcomment>$modcomment</textarea></td></tr>\n");
  print("<tr><td>Account:</td><td align=left><input name=enabled value=yes type=radio" . ($enabled ? " checked" : "") . ">Enabled <input name=enabled value=no type=radio" . (!$enabled ? " checked" : "") . ">Disabled</td></tr>\n");
  print("<tr><td>Warned: </td><td align=left><input name=warned value=yes type=radio" . ($warned == 'yes' ? " checked" : "") . ">Yes <input name=warned value=no type=radio" . (!$warned ? " checked" : "") . ">No</td></tr>\n");
  print("<tr><td colspan=2><input type=submit class=btn value='Okay'></td></tr>\n");
  print("</table>\n");
  print("</form>\n");

  print("<BR><center><a href=admin.php?act=deluser&user=".$user["username"].">DELETE ACCOUNT</a><BR>(There will be <b>NO</b> further confirmation)</center>");

  end_frame();


  echo "<br /><br />";

begin_frame("IP Ban", center);
	print("<table border=0 cellspacing=0 cellpadding=3>\n");
	print("<form method=post action=admin.php?act=bans&do=add>\n");
	print("<tr><td class=rowhead>First IP</td><td><input type=text name=first size=40 value=$user[ip]></td>\n");
	print("<tr><td class=rowhead>Last IP</td><td><input type=text name=last size=40 value=$user[ip]></td>\n");
	print("<tr><td class=rowhead>Comment</td><td><input type=text name=comment size=40></td>\n");
	print("<tr><td colspan=2><input type=submit value='Okay' class=btn></td></tr>\n");
	print("</form>\n</table>\n");
	end_frame();

}
site_footer();

?>