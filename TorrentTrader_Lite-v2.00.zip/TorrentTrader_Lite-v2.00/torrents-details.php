<?
//
// - Theme And Language Updated 26.Nov.05
//
require_once("backend/functions.php");
require_once("backend/benc.php");
userlogin();
$info_hash = $_GET['info_hash'];

if ($site_config['LOGGEDINONLY'])
	loggedinorreturn();

  if (strlen($info_hash) != 40 || !file_exists('torrents/'.$info_hash.'.torrent'))
	stderr(FILE_NOT_FOUND, TORRENT_NOT_FOUND."<BR><BR><a href='index.php'>Click here</a> to go back to the index.");

//AGENT DETECT
function getagent($httpagent, $peer_id="")
{
if (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_B([0-9][0-9|*])(.+)$)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]\_CVS)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/^Java\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Azureus/<2.0.7.0";
elseif (preg_match("/^Azureus ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Azureus/$matches[1]";
elseif (preg_match("/BitTorrent\/S-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "Shadow's/$matches[1]";
elseif (preg_match("/BitTorrent\/U-([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "UPnP/$matches[1]";
elseif (preg_match("/^BitTor(rent|nado)\\/T-(.+)$/", $httpagent, $matches))
return "BitTornado/$matches[2]";
elseif (preg_match("/^BitTornado\\/T-(.+)$/", $httpagent, $matches))
return "BitTornado/$matches[1]";
elseif (preg_match("/^BitTorrent\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC/$matches[1]";
elseif (preg_match("/^ABC ([0-9]+\.[0-9]+(\.[0-9]+)*)\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC/$matches[1]";
elseif (preg_match("/^ABC\/ABC-([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "ABC $matches[1]";
elseif (preg_match("/^Python-urllib\/.+?, BitTorrent\/([0-9]+\.[0-9]+(\.[0-9]+)*)/", $httpagent, $matches))
return "BitTorrent/$matches[1]";
elseif (ereg("^BitTorrent\/BitSpirit$", $httpagent))
return "BitSpirit";
elseif (substr($peer_id, 0, 5) == "-BB09")
return "BitBuddy/0.9xx";
elseif (ereg("^DansClient", $httpagent))
return "XanTorrent";
elseif (substr($peer_id, 0, 8) == "-KT1100-")
return "KTorrent/1.1";
elseif (preg_match("/^BitTorrent\/brst(.+)/", $httpagent, $matches))
return "Burst/$matches[1]";
elseif (preg_match("/^RAZA (.+)$/", $httpagent, $matches))
return "Shareaza/$matches[1]";
elseif (preg_match("/Rufus\/([0-9]+\.[0-9]+\.[0-9]+)/", $httpagent, $matches))
return "Rufus/$matches[1]";
elseif (preg_match("/^BitTorrent\\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
{
if(substr($peer_id, 0, 6) == "exbc\08")
return "BitComet/0.56";
elseif(substr($peer_id, 0, 6) == "exbc\09")
return "BitComet/0.57";
elseif(substr($peer_id, 0, 6) == "exbc\0:")
return "BitComet/0.58";
elseif(substr($peer_id, 0, 8) == "-BC0059-")
return "BitComet/0.59";
elseif(substr($peer_id, 0, 8) == "-BC0060-")
return "BitComet/0.60";
elseif(substr($peer_id, 0, 8) == "-BC0061-")
return "BitComet/0.61";
elseif ((strpos($httpagent, 'BitTorrent/4.1.2')!== false) && (substr($peer_id, 2, 2) == "BS"))
return "BitSpirit/v3";
elseif(substr($peer_id, 0, 7) == "exbc\0L")
return "BitLord/1.0";
elseif(substr($peer_id, 0, 7) == "exbcL")
return "BitLord/1.1";
else
return "BitTorrent/$matches[1]";
}
elseif (preg_match("/^Python-urllib\\/([0-9]+\\.[0-9]+(\\.[0-9]+)*)/", $httpagent, $matches))
return "G3 Torrent";
elseif (preg_match("/MLdonkey( |\/)([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "MLdonkey$matches[1]";
elseif (preg_match("/ed2k_plugin v([0-9]+\\.[0-9]+).*/", $httpagent, $matches))
return "eDonkey/$matches[1]";
elseif (ereg("^uTorrent", $httpagent))
{
if(substr($peer_id, 0, 8) == "-UT1130-")
return "uTorrent 1.1.3";
if(substr($peer_id, 0, 8) == "-UT1140-")
return "uTorrent 1.1.4";
if(substr($peer_id, 0, 8) == "-UT1150-")
return "uTorrent 1.1.5";
if(substr($peer_id, 0, 8) == "-UT1161-")
return "uTorrent 1.1.6.1";
if(substr($peer_id, 0, 8) == "-UT1171-")
return "uTorrent 1.1.7.1";
if(substr($peer_id, 0, 8) == "-UT1172-")
return "uTorrent 1.1.7.2";
if(substr($peer_id, 0, 8) == "-UT1200-")
return "uTorrent/1.2";
if(substr($peer_id, 0, 8) == "-UT1220-")
return "uTorrent/1.2.2";
if(substr($peer_id, 0, 8) == "-UT123B-")
return "uTorrent/1.2.3b";
if(substr($peer_id, 0, 8) == "-UT1300-")
return "uTorrent/1.3.0";
if(substr($peer_id, 0, 8) == "-UT1400-")
return "uTorrent/1.4.0";
else
return "uTorrent";
}
else
return ($httpagent != "" ? $httpagent : "---");
}

//PEERS TABLE FUNCTION
function dltable($name, $arr, $torrent)
{
	global $CURUSER;
	$s = "<b>" . count($arr) . " $name</b>\n";

	$s .= "\n";
	$s .= "<table class=table_table cellspacing=0 cellpadding=3 width=95%>\n";
	$s .= "<tr><td class=table_head>" . USERNAME . "/IP</td>" .
          "<td class=table_head>" . PORT . "</td>".
          "<td class=table_head>" . UPLOADED . "</td>".
          "<td class=table_head>" . DOWNLOADED . "</td>" .
          "<td class=table_head>" . RATIO . "</td>" .
          "<td class=table_head>" . COMPLETE . "</td>" .
          "<td class=table_head>" . CONNECTED . "</td>" .
          "<td class=table_head><b>" . IDLE . "</b></td>".
          "<td class=table_head><b>Client</b></td></tr>\n";
		  
	if (!count($arr)) {
		$s .= "<tr><td class=table_col1 width=300%>Nothing to show.</td></tr></table>";
		return $s;
	}
	$now = time();
	
	//DEFINE MODERATOR
	$moderator = (isset($CURUSER) && get_user_class() >= UC_MODERATOR);
	$mod = get_user_class() >= UC_MODERATOR;

	foreach ($arr as $e) {
		$s .= "<tr>\n";

                if ($e["username"])
                $s .= "<td class=table_col1><a href=account-details.php?user=$e[username]><b>$e[username]</b></a></td>\n";
                else
                  $s .= "<td class=table_col1>" . ($mod ? $e["ip"] : preg_replace('/\.\d+$/', ".xxx", $e["ip"])) . "</td>\n";
        //$s .= "<td class=table_col2>" . ($e[connectable] == "yes" ? $e["port"] : "---") . "</td>\n";
		$s .= "<td class=table_col2>$e[port]</td>\n";
		$s .= "<td class=table_col1>" . mksize($e["uploaded"]) . "</td>\n";
		$s .= "<td class=table_col2>" . mksize($e["downloaded"]) . "</td>\n";
                if ($e["downloaded"])
                {
                  $ratio = $e["uploaded"] / $e["downloaded"];
                  if ($ratio < 0.1)
                    $s .= "<td class=table_col2><font color=#ff0000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.2)
                    $s .= "<td class=table_col2><font color=#ee0000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.3)
                    $s .= "<td class=table_col2><font color=#dd0000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.4)
                    $s .= "<td class=table_col2><font color=#cc0000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.5)
                    $s .= "<td class=table_col2><font color=#bb0000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.6)
                    $s .= "<td class=table_col2><font color=#aa0000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.7)
                    $s .= "<td class=table_col2><font color=#990000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.8)
                    $s .= "<td class=table_col2><font color=#880000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 0.9)
                    $s .= "<td class=table_col2><font color=#770000>" . number_format($ratio, 2) . "</font></td>\n";
                  else if ($ratio < 1)
                    $s .= "<td class=table_col2><font color=#660000>" . number_format($ratio, 2) . "</font></td>\n";
                  else
                    $s .= "<td class=table_col2>" . number_format($ratio, 2) . "</td>\n";
                }
                else
                  if ($e["uploaded"])
                    $s .= "<td class=table_col2>Inf.</td>\n";
                  else
                    $s .= "<td class=table_col2>---</td>\n";
		$s .= "<td class=table_col1>" . sprintf("%.2f%%", 100 * (1 - ($e["to_go"] / $torrent["size"]))) . "</td>\n";
		$s .= "<td class=table_col2>" . mkprettytime($now - $e["st"]) . "</td>\n";
		$s .= "<td class=table_col1>" . mkprettytime($now - $e["la"]) . "</td>\n";
		$s .= "<td class=table_col2 align=right>" . htmlspecialchars(getagent($e["client"],$e["peer_id"])) . "</td>\n";
		$s .= "</tr>\n";
	}
	$s .= "</table>\n";
	return $s;
}
//END PEERS TABLE FUNCTION

//************ DO SOME "GET" STUFF BEFORE PAGE LAYOUT ***************

$owned = $moderator = 0;
if (get_user_class() >= UC_MODERATOR)
	$owned = $moderator = 1;
elseif ($CURUSER["username"] == $row["uploader"])
	$owned = 1;

$row['banned'] = file_exists("./data/$info_hash.dat.lock");

if ($row["banned"] && !$moderator){
	site_header();
	begin_frame("Error");
	print("<br><BR><center>" . TORRENT_NOT_FOUND . "</center><br><BR>");
	end_frame();
	site_footer();
	exit();
}

        if (!file_exists('data/'.$info_hash.'.dat'))
        touch('data/'.$info_hash.'.dat');

        $source = fopen('data/'.$info_hash.'.dat','r+');
        flock($source, LOCK_EX) ;
		$count_s = $count_l = 0;
		$tdownloaded = 0;
		$seeders = $downloaders = array();
        while ($info = fscanf ($source, "%s %s %s %d %d %ld %ld %ld %d %s %s %d\n")) {
        list ($ip, $prev_info_hash, $peerid,$port,$seeder,$uploaded,$downloaded,$left,$last_action, $user, $client, $started) = $info;
         if ($info_hash ==  $prev_info_hash)
          {
          if (floor((strtotime('now') - $last_action) / 60) < 60)
            {
				$tdownloaded += $downloaded;
                $pcontent .= sprintf("%s %s %s %d %d %ld %ld %ld %d %s %s %d\n",$ip, $prev_info_hash, $peerid,$port,$seeder,$uploaded,$downloaded,$left,$last_action, $user,$client,$started);
                if ($seeder == 1)
                {
				$seeders[] = array("client" => str_replace("_", " ", $client), "peer_id" => str_replace("_", " ", $peerid), "port" => $port, "ip" => $ip, "uploaded" => $uploaded, "downloaded" => $downloaded, "to_go" => $left, "la" => $last_action, "username" => $user, "st" => $started);
                $count_s += 1;
                } else {
				$downloaders[] = array("client" => str_replace("_", " ", $client), "peer_id" => str_replace("_", " ", $peerid), "port" => $port, "ip" => $ip, "uploaded" => $uploaded, "downloaded" => $downloaded, "to_go" => $left, "la" => $last_action, "username" => $user, "st" => $started);
                $count_l += 1;
                }
            }
          }

        }
        rewind($source);
        ftruncate($source,0);
        fwrite($source,$pcontent);
        flock($source, LOCK_UN);
        fclose($source);

        $source = fopen('data/torrents.dat','r+');
        flock($source, LOCK_EX) ;
        $found = 0 ;
        while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n")) {
        list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$tseeders,$tleechers,$completed,$hits,$user,$views,$added) = $info;

         if ($info_hash == $prev_info_hash)
          {
            // found it
            $row['name']  = $name;
            $row['filename'] = $filename;
            $row['seeders']  = $count_s;
            $row['leechers'] = $count_l;
            $row['completed']  = $completed;
            $row['hits']  = $hits;
            $row['size']  = $size;
            $row['numfiles']  = $numfiles;
            $row['descr']  = str_replace("\\n", "\n", $descr);
            $row['category']  = $category;
			$row['uploader'] = $user;
			$row['info_hash'] = $info_hash;
			$row['views'] = ($_GET['hit']?$views+1:$views);
			$row['visible'] = $visible;
			$row['added'] = get_date_time($added);;
            $found += 1;
            $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$count_s,$count_l,$completed,$hits, $user, $row['views'],$added);
         }
         else
         $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$tseeders,$tleechers,$completed,$hits,$user,$views,$added);
        }
        rewind($source);
        ftruncate($source,0);
        fwrite($source,$content);
        flock($source, LOCK_UN);
        fclose($source);

		if ($_GET['hit']) {
			header("Location: torrents-details.php?info_hash=$info_hash");
			die;
		}

		site_header("Details for torrent \"" . $row["name"] . "\"");

		$spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

		if ($_GET["uploaded"]) {
			bark2("Successfully uploaded!", "You can start seeding now. <b>Note</b> that the torrent won't be visible until you do that!");
		}
		elseif ($_GET["edited"]) {
			bark2("Success", "Edited OK!");
			if (isset($_GET["returnto"]))
				print("<p><b>Go back to <a href=\"" . htmlspecialchars($_GET["returnto"]) . "\">previous page</a>.</b></p>\n");
		}
		elseif (isset($_GET["searched"])) {
			bark2("Success", "Your search for \"" . htmlspecialchars($_GET["searched"]) . "\" gave a single result:");
		}
		elseif ($_GET["rated"])
			bark2("Success", "" . RATING_THANK . "");
//END "GET" STUFF

$url = "torrents-edit.php?info_hash=$info_hash";
	if (isset($_GET["returnto"])) {
		$addthis = "&returnto=" . urlencode($_GET["returnto"]);
		$url .= $addthis;
		$keepget .= $addthis;
	}
		
$editlink = "a href=\"$url\" class=\"sublink\"";
if ($owned)
	$editit .= "<$editlink> [" . EDIT_TORRENT . "]</a>";

//progress bar
$seedersProgressbar = array();
$leechersProgressbar = array();
//$resProgressbar = mysql_query("SELECT p.seeder, p.to_go, t.size FROM torrents AS t LEFT JOIN peers AS p ON t.id = p.torrent WHERE  p.torrent = '$id'") or sqlerr();
$progressPerTorrent = 0;
$iProgressbar = 0;
/*while ($rowProgressbar = mysql_fetch_array($resProgressbar)) {
 $progressPerTorrent += sprintf("%.2f", 100 * (1 - ($rowProgressbar["to_go"] / $rowProgressbar["size"])));    
 $iProgressbar++;
}*/
if ($iProgressbar == 0) 
$iProgressbar = 1;
$progressTotal = sprintf("%.2f", $progressPerTorrent / $iProgressbar);
//end progress bar

//START OF PAGE LAYOUT HERE
begin_frame("" . TORRENT_DETAILS_FOR . " \"" . $row["name"] . "\"");

echo "<TABLE BORDER=0 WIDTH=100%><TR><TD ALIGN=RIGHT>$editit</TD></TR></TABLE>";

echo "<BR><table cellpadding=3 width=100% border=0>";
echo "<TR><TD width=70% align=left valign=top><table width=100% cellspacing=0 cellpadding=3 border=0>";

print("<tr><td align=left colspan=2><b>" . TDESC . ":</b><br>" .  format_comment($row['descr']) . "<BR><BR></td></tr>");

print("<tr><td align=left><b>" . NAME . ":</b></td><td>" . htmlspecialchars($row["name"]) . "</td></tr>");

print("<tr><td align=left><b>" . TORRENT . ":</b></td><td><a href=\"download.php?info_hash=$info_hash&action=torrent\">" . htmlspecialchars($row["filename"]) . "</a></td></tr>");

print("<tr><td align=left><b>" . TTYPE . ":</b></td><td>" . $row["category"] . "</td></tr>");

print("<tr><td align=left><b>" . TOTAL_SIZE . ":</b></td><td>" . mksize($row["size"]) . " </td></tr>");

print("<tr><td align=left><b>" . INFO_HASH . ":</b></td><td>" . $row["info_hash"] . "</td></tr>");
		
if($row["privacy"] == "strong" && get_user_class() < UC_MODERATOR AND $CURUSER["id"] != $row["owner"]){
print("<tr><td align=left><b>" . ADDED_BY . ":</b></td><td>Anonymous</td></tr>");
}else{
print("<tr><td align=left><b>" . ADDED_BY . ":</b></td><td><a href=account-details.php?user=" . $row["uploader"] . ">" . $row["uploader"] . "</a></td></tr>");
}

print("<tr><td align=left><b>" . DATE_ADDED . ":</b></td><td>" . $row["added"] . "</td></tr>");
print("<tr><td align=left><b>" . VIEWS . ":</b></td><td>" . $row["views"] . "</td></tr>");
print("<tr><td align=left><b>" . HITS . ":</b></td><td>" . $row["hits"] . "</td></tr>");


echo "</table></TD><TD align=right valign=top><table width=100% cellspacing=0 cellpadding=3 border=0>";

if ($row["banned"]){
	print ("<tr><td valign=top align=right><B>" . DOWNLOAD . ": </B>BANNED!</td></tr>");
}else{
	print ("<tr><td valign=top align=right><a href=\"download.php?info_hash=$info_hash&action=torrent\"><img src=images/download.png border=0></td></tr>");
}

print("<tr><td valign=top align=right><B>" . AVAILABILITY . ":</B><br>" . get_percent_completed_image(floor($progressTotal)) . " (".round($progressTotal)."%)</td></tr>");
print("<tr><td valign=top align=right><B>" . SEEDS . ": <font color=green>" . $row["seeders"] . "</font></B></td></tr>");
print("<tr><td valign=top align=right><B>" . LEECH . ": <font color=red>" . $row["leechers"] . "</font></B></td></tr>");
//speed mod
/*$resSpeed = mysql_query("SELECT seeders,leechers FROM torrents WHERE $where visible='yes' and id = $id ORDER BY added DESC LIMIT 15") or sqlerr(__FILE__, __LINE__); 
if ($rowTmp = mysql_fetch_row($resSpeed))
       list($seedersTmp,$leechersTmp) = $rowTmp;  
if ($seedersTmp >= 1 && $leechersTmp >= 1){ 
       $speedQ = mysql_query("SELECT (t.size * t.times_completed + SUM(p.downloaded)) / (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(added)) AS totalspeed FROM torrents AS t LEFT JOIN peers AS p ON t.id = p.torrent WHERE p.seeder = 'no' AND p.torrent = '$id' GROUP BY t.id ORDER BY added ASC LIMIT 15") or sqlerr(__FILE__, __LINE__); 
       $a = mysql_fetch_assoc($speedQ); 
       $totalspeed = mksize($a["totalspeed"]) . "/s"; 
} 
else */
	if ($row['seeders'] > 0 && $row['leechers'] > 0) {
	$totalspeed = ($row['size'] * $row['completed'] + $tdownloaded) / time()-strtotime($row['added']);
	$totalspeed = mksize($totalspeed)."/s";
	}else
       $totalspeed = "No traffic currently recorded";  
print("<tr><td valign=top align=right><B>Total Speed: <font color=green>$totalspeed</font></B></td></tr>");
//end speed mod
print("<tr><td valign=top align=right><B>" . COMPLETED . ": " . $row["completed"] . "</B></td></tr>");
print("<tr><td valign=top align=right><B>" . LAST_SEEDED . ": </b>" . mkprettytime($row["lastseed"]) . " ago</td></tr>");

echo "</table>";

if (get_user_class() >= UC_MODERATOR) {
	echo "<br><BR><table width=100% cellspacing=0 cellpadding=3 style='border-collapse: collapse' bordercolor=#33CC00 border=1>";
	print("<tr><td valign=top align=center><B>" . MODERATOR_ONLY . "</B></td></tr>");

	echo "<br /><br />";
    print("<tr><td><form method=\"post\" action=\"torrents-delete.php\">\n");
    print("<input type=\"hidden\" name=\"info_hash\" value=\"$info_hash\">\n");
    if (isset($_GET["returnto"]))
        print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" />\n");
    print("<B>" . REASON_FOR_DELETE . ":</B> <input type=text size=33 name=reason> <input type=submit value='" . DELETE_IT . "' style='height: 25px'>\n");
    print("</form>\n");
    print("</p>\n");
	print("</td></tr>");

	print("<tr><td valign=top align=left><B>" . BANNED . ": </B> " . ($row["banned"] ? "Yes":"No") . "<br><B>" . VISIBLE . ": </B>" . ($row["visible"]?"Yes":"No") . "</td></tr>");
	echo "</table>";
}

echo "</td></tr></table>";

echo "<table width=100%>";
//DO FILE LIST STUFF
			if (!$_GET["filelist"]){
				print("<tr><td valign=top align=left><B>" . FILE_LIST . ": </b><a href=\"torrents-details.php?info_hash=$info_hash&filelist=1$keepget#filelist\" class=\"sublink\">[" . SHOW . "]</a></td></tr>");
			}else {
				print("<tr><td valign=top align=left><B>" . FILE_LIST . ": </b></td><td>");

				$s = "<table class=main border=\"1\" cellspacing=0 cellpadding=\"5\">\n";
				$s.="<tr><td class=colhead>" . PATH . "</td><td class=colhead align=left>" . SIZE . "</td></tr>\n";
				
				$tmp = bdec_file("./torrents/$info_hash.torrent", $site_config['max_torrent_size']);
		if ($row['numfiles'] == 1)
			$s .= "<tr><td>".$tmp['value']['info']['value']['name']['value']."</td><td class=table_col2>".mksize($tmp['value']['info']['value']['length']['value'])."</td></tr>";
		else
			foreach ($tmp['value']['info']['value']['files']['value'] as $file)
				$s .= "<tr><td>".$file['value']['path']['value'][0]['value']."</td><td class=table_col2>".mksize($file['value']['length']['value'])."</td></tr>";
			unset($tmp);
				$s .= "</table>\n";
				tr("<a name=\"filelist\">" . FILE_LIST . "</a><br /><a href=\"torrents-details.php?info_hash=$info_hash$keepget\" class=\"sublink\">[" . HIDE . "]</a>", $s, 1);
			}

//DO PEERS LIST STUFF
if (!$_GET["dllist"]) {
	/*$subres = mysql_query("SELECT seeder, COUNT(*) FROM peers WHERE torrent = $id GROUP BY seeder");
	$resarr = array(yes => 0, no => 0);
			$sum = 0;
			while ($subrow = mysql_fetch_array($subres)) {
				$resarr[$subrow[0]] = $subrow[1];
				$sum += $subrow[1];
			}*/
	$resarr = array('yes' => $row['seeders'], 'no' => $row['leechers']);
	$sum = $row['seeders']+$row['leechers'];
	
	print("<tr><td valign=top align=left><B>" . PEERS . ": $sum </b><a href=\"torrents-details.php?info_hash=$info_hash&dllist=1$keepget#seeders\" class=\"sublink\">[" . SHOW . "]</a></td></tr>");
}else {
	/*$downloaders = array();
	$seeders = array();
	$subres = mysql_query("SELECT peer_id, client, seeder, ip, port, uploaded, downloaded, to_go, UNIX_TIMESTAMP(started) AS st, connectable, UNIX_TIMESTAMP(last_action) AS la FROM peers WHERE torrent = $id") or sqlerr();
		while ($subrow = mysql_fetch_array($subres)) {
				if ($subrow["seeder"] == "yes")
					$seeders[] = $subrow;
				else
					$downloaders[] = $subrow;
			}*/

function leech_sort($a,$b) {
  if ( isset( $_GET["usort"] ) ) return seed_sort($a,$b);
        $x = $a["to_go"];
		$y = $b["to_go"];
				if ($x == $y)
					return 0;
				if ($x < $y)
					return -1;
				return 1;
}
			
function seed_sort($a,$b) {
		$x = $a["uploaded"];
		$y = $b["uploaded"];
				if ($x == $y)
					return 0;
				if ($x < $y)
					return 1;
				return -1;
}
usort($seeders, "seed_sort");
usort($downloaders, "leech_sort");

print("<tr><td valign=top align=left><B>" . SEEDS . " </b>" . dltable(" " . SEEDS . "(s) <a href=\"torrents-details.php?info_hash=$info_hash$keepget\" class=\"sublink\">[" . HIDE. "]</a>", $seeders, $row) . " </td></tr>");

print("<tr><td valign=top align=left><B>" . LEECH . " </b>" . dltable(" " . LEECH . "(s) <a href=\"torrents-details.php?info_hash=$info_hash$keepget\" class=\"sublink\">[" . HIDE . "]</a>", $downloaders, $row) . " </td></tr>");

		}
echo "</table>";

echo "<BR><BR>";

//DISPLAY NFO BLOCK
$nfo = htmlspecialchars(@file_get_contents("./torrents/$info_hash.nfo"));
//-----------------------------------------------
function my_nfo_translate($nfo)
{
        $trans = array(
        "\x80" => "&#199;", "\x81" => "&#252;", "\x82" => "&#233;", "\x83" => "&#226;", "\x84" => "&#228;", "\x85" => "&#224;", "\x86" => "&#229;", "\x87" => "&#231;", "\x88" => "&#234;", "\x89" => "&#235;", "\x8a" => "&#232;", "\x8b" => "&#239;", "\x8c" => "&#238;", "\x8d" => "&#236;", "\x8e" => "&#196;", "\x8f" => "&#197;", "\x90" => "&#201;",
        "\x91" => "&#230;", "\x92" => "&#198;", "\x93" => "&#244;", "\x94" => "&#246;", "\x95" => "&#242;", "\x96" => "&#251;", "\x97" => "&#249;", "\x98" => "&#255;", "\x99" => "&#214;", "\x9a" => "&#220;", "\x9b" => "&#162;", "\x9c" => "&#163;", "\x9d" => "&#165;", "\x9e" => "&#8359;", "\x9f" => "&#402;", "\xa0" => "&#225;", "\xa1" => "&#237;",
        "\xa2" => "&#243;", "\xa3" => "&#250;", "\xa4" => "&#241;", "\xa5" => "&#209;", "\xa6" => "&#170;", "\xa7" => "&#186;", "\xa8" => "&#191;", "\xa9" => "&#8976;", "\xaa" => "&#172;", "\xab" => "&#189;", "\xac" => "&#188;", "\xad" => "&#161;", "\xae" => "&#171;", "\xaf" => "&#187;", "\xb0" => "&#9617;", "\xb1" => "&#9618;", "\xb2" => "&#9619;",
        "\xb3" => "&#9474;", "\xb4" => "&#9508;", "\xb5" => "&#9569;", "\xb6" => "&#9570;", "\xb7" => "&#9558;", "\xb8" => "&#9557;", "\xb9" => "&#9571;", "\xba" => "&#9553;", "\xbb" => "&#9559;", "\xbc" => "&#9565;", "\xbd" => "&#9564;", "\xbe" => "&#9563;", "\xbf" => "&#9488;", "\xc0" => "&#9492;", "\xc1" => "&#9524;", "\xc2" => "&#9516;", "\xc3" => "&#9500;",
        "\xc4" => "&#9472;", "\xc5" => "&#9532;", "\xc6" => "&#9566;", "\xc7" => "&#9567;", "\xc8" => "&#9562;", "\xc9" => "&#9556;", "\xca" => "&#9577;", "\xcb" => "&#9574;", "\xcc" => "&#9568;", "\xcd" => "&#9552;", "\xce" => "&#9580;", "\xcf" => "&#9575;", "\xd0" => "&#9576;", "\xd1" => "&#9572;", "\xd2" => "&#9573;", "\xd3" => "&#9561;", "\xd4" => "&#9560;",
        "\xd5" => "&#9554;", "\xd6" => "&#9555;", "\xd7" => "&#9579;", "\xd8" => "&#9578;", "\xd9" => "&#9496;", "\xda" => "&#9484;", "\xdb" => "&#9608;", "\xdc" => "&#9604;", "\xdd" => "&#9612;", "\xde" => "&#9616;", "\xdf" => "&#9600;", "\xe0" => "&#945;", "\xe1" => "&#223;", "\xe2" => "&#915;", "\xe3" => "&#960;", "\xe4" => "&#931;", "\xe5" => "&#963;",
        "\xe6" => "&#181;", "\xe7" => "&#964;", "\xe8" => "&#934;", "\xe9" => "&#920;", "\xea" => "&#937;", "\xeb" => "&#948;", "\xec" => "&#8734;", "\xed" => "&#966;", "\xee" => "&#949;", "\xef" => "&#8745;", "\xf0" => "&#8801;", "\xf1" => "&#177;", "\xf2" => "&#8805;", "\xf3" => "&#8804;", "\xf4" => "&#8992;", "\xf5" => "&#8993;", "\xf6" => "&#247;",
        "\xf7" => "&#8776;", "\xf8" => "&#176;", "\xf9" => "&#8729;", "\xfa" => "&#183;", "\xfb" => "&#8730;", "\xfc" => "&#8319;", "\xfd" => "&#178;", "\xfe" => "&#9632;", "\xff" => "&#160;",
        );
        $trans2 = array("\xe4" => "&auml;",        "\xF6" => "&ouml;",        "\xFC" => "&uuml;",        "\xC4" => "&Auml;",        "\xD6" => "&Ouml;",        "\xDC" => "&Uuml;",        "\xDF" => "&szlig;");
        $all_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $last_was_ascii = False;
        $tmp = "";
        $nfo = $nfo . "\00";
        for ($i = 0; $i < (strlen($nfo) - 1); $i++)
        {
                $char = $nfo[$i];
                if (isset($trans2[$char]) and ($last_was_ascii or strpos($all_chars, ($nfo[$i + 1]))))
                {
                        $tmp = $tmp . $trans2[$char];
                        $last_was_ascii = True;
                }
                else
                {
                        if (isset($trans[$char]))
                        {
                                $tmp = $tmp . $trans[$char];
                        }
                        else
                        {
                            $tmp = $tmp . $char;
                        }
                        $last_was_ascii = strpos($all_chars, $char);
                }
        }
        return $tmp;
}
$nfo = my_nfo_translate($nfo);
//-----------------------------------------------

if (!$nfo) {
	print("<BR>");
}else{
    begin_frame("" . NFO . " for $row[name]</a>");
    begin_table();
        print("<tr><td class=alt2>\n");
   //     print("<br><pre><font face='MS Linedraw' size=2 style='font-size: 10pt; line-height: 10pt'>" . format_urls($nfo) . "</font></pre>\n");
     print("<br><pre>" . format_urls($nfo) . "</pre>\n");
    end_table();
        //print("<p align=center>" . FOR_BEST_RESULTS . "</p>\n");
    end_frame();
}

end_frame();

site_footer();

?>