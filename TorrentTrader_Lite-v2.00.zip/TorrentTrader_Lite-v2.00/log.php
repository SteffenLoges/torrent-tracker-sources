<?if (strpos($_SERVER['PHP_SELF'], 'log.php')) { require_once('backend/functions.php'); httperr(); }?>
[2007-09-04 22:42:27] Torrent "test" was uploaded by admin
[2007-09-04 23:00:02] Torrent test (afde5f0470e1cc3e2665cbd8c05247a31143e19d) was deleted by admin (gone)

