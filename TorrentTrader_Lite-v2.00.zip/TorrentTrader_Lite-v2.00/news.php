<?
/**
 * TorrentTrader Lite v1.1
  *  - Released under the GPL licence
 *  - Support/Hacks/Discussion @ http://www.torrenttrader.org
 **/

$news_array = array();

$news_array[] =
array(
"date" => "30/08/2007",
"author" => "<a href='http://www.torrenttrader.org'>TorrentialStorm</a>",
"title"=> "TorrentTrader Lite v2.00",
"content" => "Todo:
<ul>
	<li>Finish Staff CP (Done \"Main Settings\" and \"Site Log\" so far)</li>
	<li>Finish modtask.php</li>
	<li>Make news/categories editable via Staff CP</li>
	<li>Ban torrents in details & Staff CP</li>
	<li>Allow users to change the theme & language</li>
	<li>Take search out of index</li>
	<li>Today's torrents, member list, etc...</li>
	<li>Donations block?</li>
</ul>
Changes:
<ul>
	<li>Theme changed to TorrentRoots</li>
	<li>When you finish a torrent you get moved to seeders instead of removed.</li>
	<li>seeder/leecher count changed when you stop the torrent.</li>
	<li>New details page.</li>
	<li>Added banners, sponsors & disclaimer</li>
	<li>News can now be turned on/off</li>
	<li>Added IRC Announce code to torrents-upload</li>
	<li>Changed \"Description\" on upload page to &lt;textarea&gt;</li>
</ul>
This is still in developement. Please report any bugs to <b>TorrentialStorm</b> @ <a href='http://www.torrenttrader.org'>http://www.TorrentTrader.org</a>"
);
?>