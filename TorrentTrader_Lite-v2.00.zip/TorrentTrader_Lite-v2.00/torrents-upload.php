<?

require_once("backend/functions.php");
require_once("backend/benc.php");

userlogin();
loggedinonly();

if ($site_config['UPLOADERSONLY'])
	uploaderonly();

$submit = (int)$_GET['submit'];

  site_header();

  if (!$_POST)
  {
  $submit_form = UPLOAD_ANNOUNCE.":<br><ul>" ;
  foreach ($site_config['announce_urls'] as $value)
                 $submit_form .= "<li><b>$value</b></li>";
  $submit_form .= '</ul><br><br>
  			<form enctype="multipart/form-data" action="" method="post"><table border="0" cellspacing="0">
				<tr>
					<td>'.UPLOAD_TORRENT.'</td>
					<td><input type="file" name="torrent" style="width:400px;"></td>
				</tr>
                <tr>
                    <td>'.UPLOAD_IMAGE.'</b></td>
                    <td><input type="file" name="image" style="width:400px;"></td>
                </tr>
                <tr>
                    <td>'.UPLOAD_NFO.'</td>
                    <td><input type="file" name="nfo" style="width:400px;"></td>
                </tr>
                <tr>
					<td>'.UPLOAD_NAME.'</td>
					<td><input type="text" name="torrentname" style="width:400px;"></td>

				</tr>
				<tr>
					<td>'.UPLOAD_DESCRIPTION.'</td>
					<td><textarea name="description" rows=10 style="width:400px;"></textarea></td>
				</tr>
				<tr>
					<td>'.UPLOAD_CATEGORY.'</td><td>
                     <select name="category" size="1" style="width:300px;">
                        <option>'.UPLOAD_ALL_CATEGORIES.'</option>';

                     foreach ($categories as $value)
                        $submit_form .='<option value="'.$value.'">'.$value.'</option>';

                      $submit_form .=  '</select>
                        </td>
				</tr>
				<tr>
					<td></td>
					<td align="right"><input type="submit" name="upload_do" value="'.UPLOAD_UPLOAD.'" style="padding:0;background-color:#ffffc0;border:0;color:#FF0000;font-weight:bold"></td>
				</tr>

			</table></form>
            <br><a href="index.php"><strong>'.UPLOAD_RETURN.'</strong></a>
            ';


  main_box(UPLOAD_SUBMIT,$submit_form);
  }
  else
  {
  	foreach(explode(":","description:category:torrentname") as $v) {
	if ($_POST[$v] == "")
    	{
  		$message = UPLOAD_ERROR_01 ;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }
  	}

  	if (!isset($_FILES["torrent"]))
    	{
  		$message = UPLOAD_ERROR_02 ;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }

	  $f = $_FILES["torrent"];
	  $fname = $f["name"];
	  if (empty($fname))
      	{
  		$message = UPLOAD_ERROR_03;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }


	  $descr = (string)($_POST["description"]);
   	  $categ = (string)$_POST["category"];
      $torrentname =  (string)$_POST["torrentname"];



	  if (!preg_match('/^(.+)\.torrent$/si', $fname, $matches))
         {
  		$message = UPLOAD_ERROR_04;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }

      if ($categ == UPLOAD_ALL_CATEGORIES)
        {
        $message = UPLOAD_ERROR_05;
        main_box(UPLOAD_ERROR,$umessage."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }

	  $shortfname = $matches[1];

	  $tmpname = $f["tmp_name"];
	  if (!is_uploaded_file($tmpname))
      	{
  		$message = UPLOAD_ERROR_06;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }

      if (is_uploaded_file($_FILES["image"]["tmp_name"]))
      {
        if (strtolower(substr($_FILES["image"]["name"],-1,3)) != 'jpg')
        $message = UPLOAD_ERROR_07;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
      }


      if (is_uploaded_file($_FILES["nfo"]["tmp_name"]))
      {
        if (strtolower(substr($_FILES["image"]["name"],-1,3)) != 'nfo')
        $message = UPLOAD_ERROR_08;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
      }

      move_uploaded_file($tmpname, "torrents/".$fname);
      if (is_uploaded_file($_FILES["image"]["tmp_name"]))
      move_uploaded_file($_FILES["image"]["tmp_name"],"torrents/".$_FILES["image"]["name"]);
      if (is_uploaded_file($_FILES["nfo"]["tmp_name"]))
      move_uploaded_file($_FILES["nfo"]["tmp_name"],"torrents/".$_FILES["nfo"]["name"]);

	  $dict = bdec_file("torrents/".$fname, filesize("torrents/".$fname));
	  if (!isset($dict))
      	{
        unlink("torrents/".$fname);
        if (file_exists("torrents/".$_FILES["image"]["name"]))
        unlink("torrents/".$_FILES["image"]["name"]);
        if (file_exists("torrents/".$_FILES["nfo"]["name"]))
        unlink("torrents/".$_FILES["nfo"]["name"]);
  		$message = UPLOAD_ERROR_09;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();
        }

	  function dict_check($d, $s) {
	    if ($d["type"] != "dictionary")
            {
            unlink("torrents/".$fname);
            if (file_exists("torrents/".$_FILES["image"]["name"]))
            unlink("torrents/".$_FILES["image"]["name"]);
            if (file_exists("torrents/".$_FILES["nfo"]["name"]))
            unlink("torrents/".$_FILES["nfo"]["name"]);
	        $message = UPLOAD_ERROR_10;
            main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
            site_footer();
            }
	    $a = explode(":", $s);
	    $dd = $d["value"];
	    $ret = array();
	    foreach ($a as $k) {
	        unset($t);
	        if (preg_match('/^(.*)\((.*)\)$/', $k, $m)) {
	            $k = $m[1];
	            $t = $m[2];
	        }
	        if (!isset($dd[$k]))
            {
                unlink("torrents/".$fname);
                if (file_exists("torrents/".$_FILES["image"]["name"]))
                unlink("torrents/".$_FILES["image"]["name"]);
                if (file_exists("torrents/".$_FILES["nfo"]["name"]))
                unlink("torrents/".$_FILES["nfo"]["name"]);
	            $message = UPLOAD_ERROR_11;
                main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
                site_footer();
            }
	        if (isset($t)) {
	            if ($dd[$k]["type"] != $t)
                {
                    unlink("torrents/".$fname);
                    if (file_exists("torrents/".$_FILES["image"]["name"]))
                    unlink("torrents/".$_FILES["image"]["name"]);
                    if (file_exists("torrents/".$_FILES["nfo"]["name"]))
                    unlink("torrents/".$_FILES["nfo"]["name"]);
	                $message = UPLOAD_ERROR_12;
                    main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
                    site_footer();
                }
	            $ret[] = $dd[$k]["value"];
	        }
	        else
	            $ret[] = $dd[$k];
	    }
	    return $ret;
	  }

	  function dict_get($d, $k, $t) {
	    if ($d["type"] != "dictionary")
        {
        unlink("torrents/".$fname);
        if (file_exists("torrents/".$_FILES["image"]["name"]))
        unlink("torrents/".$_FILES["image"]["name"]);
        if (file_exists("torrents/".$_FILES["nfo"]["name"]))
        unlink("torrents/".$_FILES["nfo"]["name"]);
        $message = UPLOAD_ERROR_13;
        main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
        site_footer();

        }
	    $dd = $d["value"];
	    if (!isset($dd[$k]))
	        return;
	    $v = $dd[$k];
	    if ($v["type"] != $t)
        {
            unlink("torrents/".$fname);
            if (file_exists("torrents/".$_FILES["image"]["name"]))
            unlink("torrents/".$_FILES["image"]["name"]);
            if (file_exists("torrents/".$_FILES["nfo"]["name"]))
            unlink("torrents/".$_FILES["nfo"]["name"]);
            $message = UPLOAD_ERROR_14;
            main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
            site_footer();

        }
	    return $v["value"];
	  }

      list($ann, $info) = dict_check($dict, "announce(string):info");
      $url_ann = array() ;
      $a=0;
      $announcelist = dict_get($dict, "announce-list","list");

        if (isset($announcelist) && count($announcelist))
            {
                  foreach ($announcelist as $fn) {
                    $hi = $fn["value"];

                     for ($i=0;$i < count($hi);$i++  )
                      {
                      $url_ann[] =  $hi[$i]["value"] ;
                      }
                  }
                  for ($j=0;$j<count($announce_urls);$j++)
                   {
                  for ($k=0;$k<count($url_ann);$k++)
                  {
                  if  ($announce_urls[$j]==$url_ann[$k])  $a+=1;
                  }
                   }
                 if ($a<1)
                 {
                 unlink("torrents/".$fname);
                 if (file_exists("torrents/".$_FILES["image"]["name"]))
                 unlink("torrents/".$_FILES["image"]["name"]);
                 if (file_exists("torrents/".$_FILES["nfo"]["name"]))
                 unlink("torrents/".$_FILES["nfo"]["name"]);
                 $message =  UPLOAD_ERROR_15 ;
                 foreach ($announce_urls as $value)
                 $message .= "<li>$value</li>";
                 $message .="</b>";
                 main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
                 site_footer();
                 }
             }
         else
            {
			     $tmphex = sha1($info["string"]);
				 $hexhash = strtolower($tmphex);
                 if (!in_array($ann, $site_config['announce_urls'], 1))
                 {
                 unlink("torrents/".$fname);
                 if (file_exists("torrents/".$_FILES["image"]["name"]))
					@unlink("torrents/".$_FILES["image"]["name"]);
                 if (file_exists("torrents/".$_FILES["nfo"]["name"]))
					@unlink("torrents/".$_FILES["nfo"]["name"]);
                 $message =  UPLOAD_ERROR_15 ;

				$source = fopen('data/torrents.dat','r+');
				flock($source, LOCK_EX);
				while ($line = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %s %s\n")) {
					list ($prev_info_hash, $prev_filename, $prev_name,$prev_size,$prev_numfiles,$prev_descr,$prev_category,$seeders,$leechers,$completed,$hits,$user,$views,$date,$time) = $line;
					if ($hexhash !=  $prev_info_hash)
						$content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %s %s\n",$prev_info_hash, $prev_filename, $prev_name,$prev_size,$prev_numfiles,$prev_descr,$prev_category,$seeders,$leechers,$completed,$hits,$user,$views,$date,$time);
				}
				ftruncate($source, 0);
				fwrite($source, $content);
				flock($source, LOCK_UN);
				fclose($source);

                 foreach ($announce_urls as $value)
                 $message .= "<li>$value</li>";
                 $message .="</b>";
                 main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
                 site_footer();
                 }
            }
      list($dname, $plen, $pieces) = dict_check($info, "name(string):piece length(integer):pieces(string)");

      $filelist = array();
      $totallen = dict_get($info, "length", "integer");
        if (isset($totallen)) {
          $filelist[] = array($dname, $totallen);
          $type = "single";
        }
        else {
          $flist = dict_get($info, "files", "list");
          if (!isset($flist))
          {
              unlink("torrents/".$fname);
              if (file_exists("torrents/".$_FILES["image"]["name"]))
              unlink("torrents/".$_FILES["image"]["name"]);
              if (file_exists("torrents/".$_FILES["nfo"]["name"]))
              unlink("torrents/".$_FILES["nfo"]["name"]);
              $message = UPLOAD_ERROR_16;
              main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
              site_footer();
          }
          if (!count($flist))
          {
          $message = UPLOAD_ERROR_17;
          unlink("torrents/".$fname);
          if (file_exists("torrents/".$_FILES["image"]["name"]))
          unlink("torrents/".$_FILES["image"]["name"]);
          if (file_exists("torrents/".$_FILES["nfo"]["name"]))
          unlink("torrents/".$_FILES["nfo"]["name"]);
          main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
          site_footer();
          }
          $totallen = 0;
          foreach ($flist as $fn) {
              list($ll, $ff) = dict_check($fn, "length(integer):path(list)");
              $totallen += $ll;
              $ffa = array();
              foreach ($ff as $ffe) {
                  if ($ffe["type"] != "string")
                      $message = UPLOAD_ERROR_18;
                  $ffa[] = $ffe["value"];
              }
              if (!count($ffa))
                  $message = UPLOAD_ERROR_18;
              $ffe = implode("/", $ffa);
              $filelist[] = array($ffe, $ll);
          }
          $type = "multi";
        }

      $tmphex = sha1($info["string"]);
      $hexhash = strtolower($tmphex);

   	  if (strlen($hexhash) != 40)
         {
             unlink("torrents/".$fname);
             if (file_exists("torrents/".$_FILES["image"]["name"]))
             unlink("torrents/".$_FILES["image"]["name"]);
             if (file_exists("torrents/".$_FILES["nfo"]["name"]))
             unlink("torrents/".$_FILES["nfo"]["name"]);
             $message = UPLOAD_ERROR_19;
             main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
             site_footer();
         }

      if (file_exists('data/'.$hexhash.'.dat.lock'))
         {
             unlink("torrents/".$fname);
             if (file_exists("torrents/".$_FILES["image"]["name"]))
             unlink("torrents/".$_FILES["image"]["name"]);
             if (file_exists("torrents/".$_FILES["nfo"]["name"]))
             unlink("torrents/".$_FILES["nfo"]["name"]);
             $message = UPLOAD_ERROR_20;
             main_box(UPLOAD_ERROR,$message."<br><br><a href=\"?\"><strong>".UPLOAD_RELOAD."</strong></a>");
             site_footer();
         }


        // we insert the torrent into the database
      if (!file_exists('data/torrents.dat')) touch('data/torrents.dat');


        $source = fopen('data/torrents.dat','r+');
        flock($source, LOCK_EX);

        // we first check the torrent was not already added
        while ($line = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n")) {
        list ($prev_info_hash, $prev_filename, $prev_name,$prev_size,$prev_numfiles,$prev_descr,$prev_category,$seeders,$leechers,$completed,$hits,$user,$views,$added) = $line;
        if ($hexhash ==  $prev_info_hash)
          {
             main_box(UPLOAD_ERROR,UPLOAD_ERROR_21.'<br><br><a href="?"><strong>'.UPLOAD_RELOAD.'</strong></a>');
             flock($source, LOCK_UN);
             fclose($source);
             site_footer();
         }
         $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n",$prev_info_hash, $prev_filename, $prev_name,$prev_size,$prev_numfiles,$prev_descr,$prev_category,$seeders,$leechers,$completed,$hits,$user,$views,$added);
        }
        // we update the hit counter for this torrent
        $content = sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n",$hexhash,str_replace(chr(0),"_",str_replace(" ","_",$fname)),str_replace(chr(0),"_",str_replace(" ","_",$torrentname)),$totallen,count($filelist),str_replace(chr(0),"_",str_replace(" ","_",str_replace(array("\r\n","\n"), "\\n",$descr))),str_replace(" ", "_",$categ),"0","0","0","0", $CURUSER['username'],0,time()).$content;
        rewind($source);
        ftruncate($source,0);
        fwrite($source, $content);
        flock($source, LOCK_UN);
        fclose($source);



        rename("./torrents/".$fname, "./torrents/".$hexhash.".torrent");

        if (file_exists("torrents/".$_FILES["image"]["name"]))
        @rename("torrents/".$_FILES["image"]["name"],"./torrents/".$hexhash.".jpg");
        if (file_exists("torrents/".$_FILES["nfo"]["name"]))
        @rename("torrents/".$_FILES["nfo"]["name"],"./torrents/".$hexhash.".nfo");
		
		write_log("Torrent \"$torrentname\" was uploaded by " . $CURUSER["username"]);

		if ($site_config['IRCANNOUNCE']) {
			$msg_bt = chr(3)."9".chr(2)." $site_config[SITENAME]".chr(2)." -".chr(3)."10 New Torrent: (".chr(3)."15 $torrent".chr(3)."10 ) Size: (".chr(3)."15 ".mksize($totallen).chr(3)."10 )  Category: (".chr(3)."15 ". $category.chr(3)."10 ) Uploader: (".chr(3)."15 $user".chr(3)."10 ) Link: (".chr(3)."15 $site_config[SITEURL]/torrents-details.php?info_hash=$info_hash&hit=1".chr(3)."10 )\r\n"; 
			$fs = fsockopen($site_config['ANNOUNCEIP'], $site_config['ANNOUNCEPORT'], $errno, $errstr);
			if($fs) { 
				fwrite($fs, $msg_bt); 
				fclose($fs); 
			} 
		}


        main_box(UPLOAD_SUCCESS,UPLOAD_THANKS.'<br><br><a href="index.php"><strong>'.UPLOAD_RETURN.'</strong></a>');



	  }


      site_footer();
?>