<?
$site_config = array();
// Default Language / Theme Settings
$site_config['language'] = "english.lang";
$site_config['theme'] = "default";

// Site Settings
$site_config['SITENAME'] = "TorrentTrader Lite v1 - www.torrenttrader.org";
$site_config['SITEEMAIL'] = "noreply@changeme.com";
$site_config['SITEURL'] = "http://10.0.0.4/ttl13";
$site_config['SITE_ONLINE'] = true;
$site_config['OFFLINEMSG'] = "Site down for a while.";
$site_config['UPLOADERSONLY'] = true;
$site_config['LOGGEDINONLY'] = false;
$site_config['MAXDISPLAYLENGTH'] = 35;
$site_config['TORRENTSPERPAGE'] = 30;

// File paths
$site_config['userdir'] = "./users/";

//Setup Site Blocks
$site_config['NEWSON'] = true;
$site_config['DONATEON'] = false;
$site_config['DISCLAIMERON'] = true;

//Setup IRC Announcer
$site_config['IRCANNOUNCE'] = false;
$site_config['ANNOUNCEIP'] = "127.0.0.1";
$site_config['ANNOUNCEPORT'] = "2500";

//WAIT TIME VARS
$site_config['GIGSA'] = "1";
$site_config['RATIOA'] = "0.50";
$site_config['WAITA'] = "24";
$site_config['GIGSB'] = "3";
$site_config['RATIOB'] = "0.65";
$site_config['WAITB'] = "12";
$site_config['GIGSC'] = "5";
$site_config['RATIOC'] = "0.80";
$site_config['WAITC'] = "6";
$site_config['GIGSD'] = "7";
$site_config['RATIOD'] = "0.95";
$site_config['WAITD'] = "2";

// Tracker Settings
$site_config['torrent_dir'] = "";
$site_config['announce_urls'] = array();
$site_config['announce_urls'][] = "http://10.0.0.4/ttl13/announce.php";
$site_config['MEMBERSONLY'] = false;
$site_config['MEMBERSONLY_WAIT'] = false;

// Advanced Settings for announce
$site_config['max_torrent_size'] = "1000000";
$site_config['max_nfo_size'] = "1000000";
$site_config['max_image_size'] = "1000000";
$site_config['announce_interval'] = "1800";
$site_config['maxsiteusers'] = "10000";
?>