<?php

require_once('config.php');
require_once("smilies.php");

// Categories need moving...
$categories = array();
$categories[] = "Anime";
$categories[] = "Games";
$categories[] = "Movies";
$categories[] = "Music";

// So do countries...
$countries = array();
$countries[] = "Afghanistan";
$countries[] = "Albania";
$countries[] = "Algeria";
$countries[] = "Andorra";
$countries[] = "Angola";
$countries[] = "Antigua Barbuda";
$countries[] = "Argentina";
$countries[] = "Australia";
$countries[] = "Austria";
$countries[] = "Bahamas";
$countries[] = "Bangladesh";
$countries[] = "Barbados";
$countries[] = "Belgium";
$countries[] = "Belize";
$countries[] = "Bosnia Herzegovina";
$countries[] = "Brazil";
$countries[] = "Burkina Faso";
$countries[] = "Cambodia";
$countries[] = "Canada";
$countries[] = "Chile";
$countries[] = "China";
$countries[] = "Colombia";
$countries[] = "Congo";
$countries[] = "Croatia";
$countries[] = "Cuba";
$countries[] = "Czech Republic";
$countries[] = "Denmark";
$countries[] = "Dominican Republic";
$countries[] = "Ecuador";
$countries[] = "England";
$countries[] = "Estonia";
$countries[] = "Finland";
$countries[] = "France";
$countries[] = "Germany";
$countries[] = "Greece";
$countries[] = "Guatemala";
$countries[] = "Honduras";
$countries[] = "Hong Kong";
$countries[] = "Hungary";
$countries[] = "Iceland";
$countries[] = "India";
$countries[] = "Ireland";
$countries[] = "Israel";
$countries[] = "Italy";
$countries[] = "Jamaica";
$countries[] = "Japan";
$countries[] = "Kiribati";
$countries[] = "Kyrgyzstan";
$countries[] = "Laos";
$countries[] = "Lithuania";
$countries[] = "Luxembourg";
$countries[] = "Malaysia";
$countries[] = "Mexico";
$countries[] = "Nauru";
$countries[] = "Netherlands";
$countries[] = "Netherlands Antilles";
$countries[] = "New Zealand";
$countries[] = "Nigeria";
$countries[] = "North Korea";
$countries[] = "Norway";
$countries[] = "Pakistan";
$countries[] = "Paraguay";
$countries[] = "Peru";
$countries[] = "Philippines";
$countries[] = "Poland";
$countries[] = "Portugal";
$countries[] = "Puerto Rico";
$countries[] = "Romania";
$countries[] = "Russia";
$countries[] = "Scotland";
$countries[] = "Senegal";
$countries[] = "Serbia";
$countries[] = "Seychelles";
$countries[] = "Singapore";
$countries[] = "Slovenia";
$countries[] = "South Africa";
$countries[] = "South Korea";
$countries[] = "Spain";
$countries[] = "Sweden";
$countries[] = "Switzerland";
$countries[] = "Taiwan";
$countries[] = "Thailand";
$countries[] = "Togo";
$countries[] = "Trinidad & Tobago";
$countries[] = "Turkey";
$countries[] = "Turkmenistan";
$countries[] = "Ukraine";
$countries[] = "Union of Soviet Socialist Republics";
$countries[] = "United Kingdom";
$countries[] = "United States of America";
$countries[] = "Uruguay";
$countries[] = "Uzbekistan";
$countries[] = "Vanuatu";
$countries[] = "Venezuela";
$countries[] = "Vietnam";
$countries[] = "Western Samoa";
$countries[] = "Yugoslavia";


if (!isset($site_config['language']))
	$site_config['language'] ="english.lang";

require_once("languages/".$site_config['language']);
	
define("UC_USER", 0);
define("UC_UPLOADER", 5);
define("UC_VIP", 10);
define("UC_MODERATOR", 15);
define("UC_SMODERATOR", 20);
define("UC_ADMINISTRATOR", 25);


function site_header($title="") {
	GLOBAL $site_config, $CURUSER, $ss_uri, $categories;

	if (!$site_config['SITE_ONLINE'])
		die("<title>Site Offline</title><body>".$site_config['OFFLINE_MSG']);

	if($title != "")
		$title = $site_config['SITENAME']."&nbsp;.::.&nbsp;".$title;
	else
		$title = $site_config['SITENAME'];

	if (!$ss_uri)
		$ss_uri = "default";

	require_once("themes/$ss_uri/block.php");
	require_once("themes/$ss_uri/header.php");
}

function main_box($title, $content) {
	begin_frame($title);
	echo $content;
	end_frame();
}

function site_footer() {
	GLOBAL $ss_uri;
	require_once("themes/$ss_uri/footer.php");
	ob_end_flush();
	die;
}

function euclidivision($nombre , $diviseur){
	$nombre = intval($nombre)+0;
	$diviseur = intval($diviseur)+0;

	if ($diviseur == 0){ return array();}
	if ($nombre == 0){ return array($nombre, $diviseur);}

	$quotient = floor($nombre/$diviseur);
	$reste = $nombre - $quotient*$diviseur;

	if ($reste < 0){
		if ($diviseur > 0){
			$quotient--;
			$reste += $diviseur;
		} else {
			$quotient++;
			$reste -= $diviseur;
		}
	}
	return array($quotient, $reste);
}

function mkprettytime($s) {
	if ($s < 0)
		$s = 0;
	$t = array();
	foreach (array("60:sec","60:min","24:hour","0:day") as $x) {
		$y = explode(":", $x);
		if ($y[0] > 1) {
			$v = $s % $y[0];
			$s = floor($s / $y[0]);
		}else
			$v = $s;
		$t[$y[1]] = $v;
	}

	if ($t["day"])
		return $t["day"] . "d " . sprintf("%02d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
	if ($t["hour"])
		return sprintf("%d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
	if ($t["min"])
		return sprintf("%d:%02d", $t["min"], $t["sec"]);
	return $t["sec"] . " secs";
}


function stderr($heading = "", $text, $sort = "Error") {
	site_header("$sort: $heading"); 
	begin_frame("<font color=#FFFFFF>$sort: $heading</font>", center);
	echo $text;
	end_frame();
	site_footer();
	die;
}

function bark($heading = "Error", $text, $sort = "Error") {
	site_header("$sort: $heading");
	begin_frame("<font color=#FFFFFF>$sort: $heading</font>", center);
	echo $text;
	end_frame();
	site_footer();
	die;
}

function bark2($heading = "Error", $text, $sort = "Error") {
	print("<div align=\"center\"><br /><table border=\"0\" width=\"500\" cellspacing=\"0\" cellpadding=\"0\"><tr>\n");
	print("<td bgcolor=\"#FFFFFF\" align=\"center\" style=\"border-style: dotted; border-width: 1px\" bordercolor=\"#CC0000\">\n");
	print("<font face=\"Verdana\" size=\"1\"><font color=\"#CC0000\"><b>$heading</b></font><br />$text</font></td>\n");
	print("</tr></table></div><br />\n");
}

function genbark($x,$y='') {
    site_header($y);
    begin_frame("<font color=#FFFFFF>Error - ". htmlspecialchars($y) ."</font>", center);
    print("<p>" . htmlspecialchars($x) . "</p>\n");
    end_frame();
    site_footer();
    exit();
}

function loggedinonly() {
	GLOBAL $CURUSER;
	if (!$CURUSER) {
		header("Refresh: 0; url=account-login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		die;
	}
}

function tr($x,$y,$noesc=0) {
	if ($noesc)
		$a = $y;
	else {
		$a = htmlspecialchars($y);
		$a = str_replace("\n", "<br />\n", $a);
	}
	print("<tr><td class=\"heading\" valign=\"top\" align=\"right\">$x</td><td valign=\"top\" align=left>$a</td></tr>\n");
}

function begin_table($width="100%", $align="center") {
	print("<table align=$align cellpadding=\"0\" cellspacing=\"0\" class=\"ttable_headouter\" width=$width><tr><td>"
	."<table align=center cellpadding=\"1\" cellspacing=\"0\" class=\"ttable_headinner\" width=100%>\n"); 
	}

function end_table() {
	print("</table></td></tr></table>\n");
}

function validusername($username) {
	$allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_!^�$%&()+= ";
	for ($i = 0; $i < strlen($username); ++$i)
		if (strpos($allowedchars, $username[$i]) === false)
			return false;
	return true;
}

function userlogin() {
	GLOBAL $site_config, $countries;
	unset($GLOBALS["CURUSER"]);
	$ip = getip();

	if (empty($_COOKIE["uid"]) || empty($_COOKIE["pass"]) || !$site_config['SITE_ONLINE'])
		return;

	if (strlen($_COOKIE["pass"]) != 32) {
		logoutcookie();
		return;
	}

	$file = "{$site_config['userdir']}/{$_COOKIE['uid']}.dat";

	if (!file_exists($file)) {
		logoutcookie();
		return;
	}

	GLOBAL $CURUSER;
	$arr = readuserfile($file);

	if ($arr["confirmed"] != "yes") {
		logoutcookie();
		return;
	}
	
	if (md5(hash_pad($arr['secret']).$arr['password'].hash_pad($arr['secret'])) != $_COOKIE['pass']) {
		logoutcookie();
		return;
	}
	$CURUSER = $arr;

	if ($CURUSER['ip'] != $ip)
		$CURUSER['ip'] = $ip;

	$CURUSER['last_access'] = get_date_time();
	writeuserfile($file, $CURUSER);
}

function mksecret($len = 20) {
	$ret = "";
	for ($i = 0; $i < $len; $i++)
		$ret .= chr(mt_rand(0, 255));
	return $ret;
}

function logincookie($username, $password, $secret, $expires = 0x7fffffff) {
	$md5 = md5($secret . $password . $secret);
	setcookie("uid", $username, $expires, "/");
	setcookie("pass", $md5, $expires, "/");

}

function logoutcookie() {
setcookie("uid", "null", time(), "/");
setcookie("pass", "null", time(), "/");
}

function sql_timestamp_to_unix_timestamp($s) {
	return mktime(substr($s, 11, 2), substr($s, 14, 2), substr($s, 17, 2), substr($s, 5, 2), substr($s, 8, 2), substr($s, 0, 4));
}

function write_log($text) {
	if($log=fopen("log.php","a")) {
		fwrite($log, "[".get_date_time()."] $text\r\n");
		fclose($log);
	}
}


function validip($ip)
{
	if (!empty($ip) && ip2long($ip)!=-1)
	{
		$reserved_ips = array (
				array('0.0.0.0','2.255.255.255'),
//				array('10.0.0.0','10.255.255.255'),
//				array('127.0.0.0','127.255.255.255'),
				array('169.254.0.0','169.254.255.255'),
				array('172.16.0.0','172.31.255.255'),
				array('192.0.2.0','192.0.2.255'),
				array('192.168.0.0','192.168.255.255'),
				array('255.255.255.0','255.255.255.255')
		);

		foreach ($reserved_ips as $r)
		{
				$min = ip2long($r[0]);
				$max = ip2long($r[1]);
				if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
		}
		return true;
	}
	else return false;
}

function getip()
{
	global $HTTP_SERVER_VARS;
	if (validip($HTTP_SERVER_VARS['HTTP_CLIENT_IP'])) return $HTTP_SERVER_VARS['HTTP_CLIENT_IP'];
	elseif ($HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR']!="")
	{
		$forwarded=str_replace(",","",$HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR']);
		$forwarded_array=split(" ",$forwarded);
		foreach($forwarded_array as $value)	if (validip($value)) return $value;
	}
	return $HTTP_SERVER_VARS['REMOTE_ADDR'];
}

function hash_pad($hash) {
	return str_pad($hash, 20);
}


function validfilename($name) {
	return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
}

function validemail($email) {
	return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
}

// Returns the current time in GMT in MySQL compatible format.
function get_date_time($timestamp = 0)
{
	if ($timestamp)
		return date("Y-m-d H:i:s", $timestamp);
	else
		return date("Y-m-d H:i:s", time());
}

function encodehtml($s, $linebreaks = true) {
	$s = str_replace("<", "&lt;", str_replace("&", "&amp;", $s));
	if ($linebreaks)
	$s = nl2br($s);
	return $s;
}

function get_dt_num() {
return gmdate("YmdHis");
}

function unesc($x) {
	if (get_magic_quotes_gpc())
		return stripslashes($x);
	return $x;
}

function mksize($bytes) {
	if ($bytes < 1024)
		return number_format($bytes, 2)." B";
	if ($bytes < 1024 * 1024)
		return number_format($bytes / 1024, 2) . " KB";
	if ($bytes < 1024 * 1048576)
		return number_format($bytes / 1048576, 2) . " MB";
	if ($bytes < 1024 * 1073741824)
		return number_format($bytes / 1073741824, 2) . " GB";
	return number_format($bytes / 1099511627776, 2) . " TB";
}

function mksizekb($bytes)
{
  return number_format($bytes / 1024) . " KB";
}

function mksizemb($bytes)
{
  return number_format($bytes / 1048576,2) . " MB";
}

function mksizegb($bytes)
{
  return number_format($bytes / 1073741824,2) . " GB";
}

function readuserfile($file) {
	$fs = fopen($file, 'r');
	if (!fs)
		return false;
	$arr = unserialize(fread($fs, filesize($file)));
	fclose($fs);
	return $arr;
}

function writeuserfile($file, $data) {
	$fs = fopen($file, "w");
	if (!fs)
		return false;
	fwrite($fs, serialize($data));
	fclose($fs);
	return true;
}

function uploaderonly() {
	GLOBAL $CURUSER;
	if ($CURUSER['class'] < 5) {
		header("Refresh: 0; url=account-login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		die;
	}
}

function viponly() {
	GLOBAL $CURUSER;
	if ($CURUSER['class'] < 10) {
		header("Refresh: 0; url=account-login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		die;
	}
}

function modonly() {
	GLOBAL $CURUSER;
	if ($CURUSER['class'] < 15) {
		header("Refresh: 0; url=account-login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		die;
	}
}

function smodonly() {
	GLOBAL $CURUSER;
	if ($CURUSER['class'] < 20) {
		header("Refresh: 0; url=account-login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		die;
	}
}

function adminonly() {
	GLOBAL $CURUSER;
	if ($CURUSER['class'] < 25) {
		header("Refresh: 0; url=account-login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
		die;
	}
}

function get_user_class() {
	return $GLOBALS['CURUSER']['class'];
}

function get_user_class_name($s=null) {
	if (is_null($s)) $s = $GLOBALS['CURUSER']['class'];
	switch ($s) {
		case UC_USER:
			return "User";
			break;
		case UC_UPLOADER:
			return "Uploader";
			break;
		case UC_VIP:
			return "VIP";
			break;
		case UC_MODERATOR:
			return "Moderator";
			break;
		case UC_SMODERATOR:
			return "Super Moderator";
			break;
		case UC_ADMINISTRATOR:
			return "Administrator";
			break;
	}
	return false;
}

function get_elapsed_time($ts)
{
	$mins = floor((strtotime(date("Y-m-d H:i:s")) - $ts) / 60);
	$hours = floor($mins / 60);
	$mins -= $hours * 60;
	$days = floor($hours / 24);
	$hours -= $days * 24;
	$weeks = floor($days / 7);
	$days -= $weeks * 7;
	$t = "";
	if ($weeks)
		return "$weeks week" . ($weeks > 1 ? "s" : "");
	if ($days)
		return "$days day" . ($days > 1 ? "s" : "");
	if ($hours)
		return "$hours hour" . ($hours > 1 ? "s" : "");
	if ($mins)
		return "$mins min" . ($mins > 1 ? "s" : "");
	return "< 1 min";
}

  function get_ratio_color($ratio)
  {
	if ($ratio < 0.1) return "#ff0000";
	if ($ratio < 0.2) return "#ee0000";
	if ($ratio < 0.3) return "#dd0000";
	if ($ratio < 0.4) return "#cc0000";
	if ($ratio < 0.5) return "#bb0000";
	if ($ratio < 0.6) return "#aa0000";
	if ($ratio < 0.7) return "#990000";
	if ($ratio < 0.8) return "#880000";
	if ($ratio < 0.9) return "#770000";
	if ($ratio < 1) return "#660000";
	return "#000000";
}

function httperr($code=404) {
	switch ($code) {
		case '403':
			header("HTTP/1.0 403 Forbidden");
			print("<h1>Forbidden</h1>");
			break;
		case '404':
			header("HTTP/1.0 404 Not found");
			print("<h1>Not found</h1>");
			break;
		default:
			header("HTTP/1.0 404 Not found");
			print("<h1>Not found</h1>");
	}
	die;
}

function is_valid_user_class($class) {
	return is_numeric($class) && floor($class) == $class && $class >= UC_USER && $class <= UC_ADMINISTRATOR && get_user_class_name($class) !== false;
}

function format_comment($text, $strip_html = true, $strip_slash = true)
{
	global $smilies, $privatesmilies, $site_config;

	$s = $text;

	if ($strip_html)
		$s = htmlspecialchars($s);

	if ($strip_slash)
		$s = stripslashes($s);

	// [*]
	$s = preg_replace("/\[\*\]/", "<li>", $s);

	// [b]Bold[/b]
	$s = preg_replace("/\[b\]((\s|.)+?)\[\/b\]/", "<b>\\1</b>", $s);

	// [i]Italic[/i]
	$s = preg_replace("/\[i\]((\s|.)+?)\[\/i\]/", "<i>\\1</i>", $s);

	// [u]Underline[/u]
	$s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/", "<u>\\1</u>", $s);

	// [u]Underline[/u]
	$s = preg_replace("/\[u\]((\s|.)+?)\[\/u\]/i", "<u>\\1</u>", $s);

	// [img]http://www/image.gif[/img]
	$s = preg_replace("/\[img\](http:\/\/[^\s'\"<>]+(\.gif|\.jpg|\.png|\.bmp|\.jpeg))\[\/img\]/i", "<img border=0 src=\"\\1\">", $s);

	// [img=http://www/image.gif]
	$s = preg_replace("/\[img=(http:\/\/[^\s'\"<>]+(\.gif|\.jpg|\.png|\.bmp|\.jpeg))\]/i", "<img border=0 src=\"\\1\">", $s);

	// [color=blue]Text[/color]
	$s = preg_replace(
		"/\[color=([a-zA-Z]+)\]((\s|.)+?)\[\/color\]/i",
		"<font color=\\1>\\2</font>", $s);

	// [color=#ffcc99]Text[/color]
	$s = preg_replace(
		"/\[color=(#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])\]((\s|.)+?)\[\/color\]/i",
		"<font color=\\1>\\2</font>", $s);

	// [url=http://www.example.com]Text[/url]
	$s = preg_replace(
		"/\[url=((http|ftp|https|ftps|irc):\/\/[^<>\s]+?)\]((\s|.)+?)\[\/url\]/i",
		"<a href=redirect.php?url=\\1>\\3</a>", $s);

	// [url]http://www.example.com[/url]
	$s = preg_replace(
		"/\[url\]((http|ftp|https|ftps|irc):\/\/[^<>\s]+?)\[\/url\]/i",
		"<a href=redirect.php?url=\\1>\\1</a>", $s);

	// [size=4]Text[/size]
	$s = preg_replace(
		"/\[size=([1-7])\]((\s|.)+?)\[\/size\]/i",
		"<font size=\\1>\\2</font>", $s);

	// [font=Arial]Text[/font]
	$s = preg_replace(
		"/\[font=([a-zA-Z ,]+)\]((\s|.)+?)\[\/font\]/i",
		"<font face=\"\\1\">\\2</font>", $s);

	//[quote]Text[/quote]
	$s = preg_replace(
		"/\[quote\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
		"<p class=sub><b>Quote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\1</td></tr></table><br />", $s);

	//[quote=Author]Text[/quote]
	$s = preg_replace(
		"/\[quote=(.+?)\]\s*((\s|.)+?)\s*\[\/quote\]\s*/i",
		"<p class=sub><b>\\1 wrote:</b></p><table class=main border=1 cellspacing=0 cellpadding=10><tr><td style='border: 1px black dotted'>\\2</td></tr></table><br />", $s);
                
        //[hr]
        $s = preg_replace("/\[hr\]/i", "<hr>", $s);

        //[hr=#ffffff] [hr=red]
        $s = preg_replace("/\[hr=((#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])|([a-zA-z]+))\]/i", "<hr color=\"\\1\"/>", $s);

        //[swf]http://somesite.com/test.swf[/swf]
        $s = preg_replace("/\[swf\]((www.|http:\/\/|https:\/\/)[^\s]+(\.swf))\[\/swf\]/i",
        "<param name=movie value=\\1/><embed width=470 height=310 src=\\1></embed>", $s);

        //[swf=http://somesite.com/test.swf]
        $s = preg_replace("/\[swf=((www.|http:\/\/|https:\/\/)[^\s]+(\.swf))\]/i",
        "<param name=movie value=\\1/><embed width=470 height=310 src=\\1></embed>", $s);

	// URLs
	$s = format_urls($s);

	// Linebreaks
	$s = nl2br($s);

	// Maintain spacing
	$s = str_replace("  ", " &nbsp;", $s);

	reset($smilies);
	while (list($code, $url) = each($smilies))
		$s = str_replace($code, "<img border=0 src=" . $site_config['SITEURL'] . "/images/smilies/$url>", $s);

	reset($privatesmilies);
	while (list($code, $url) = each($privatesmilies))
		$s = str_replace($code, "<img border=0 src=" . $site_config['SITEURL'] . "/images/smilies/$url>", $s);

	return $s;
}

function format_urls($s)
{
return preg_replace(
    "/(\A|[^=\]'\"a-zA-Z0-9])((http|ftp|https|ftps|irc):\/\/[^<>\s]+)/i",
    "\\1<a href=redirect.php?url=\\2>\\2</a>", $s);
//  return preg_replace( "/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i", "<a href=\"\\0\">\\0</a>", $txt );
}

function get_percent_completed_image($p) {
 GLOBAL $site_config;
 $maxpx = "30"; // Maximum amount of pixels for the progress bar

 if ($p == 0) $progress = "<img src=\"" . $site_config['SITEURL'] . "/images/progbar-rest.gif\" height=9 width=" . ($maxpx) . " />";
 if ($p >= 100) $progress = "<img src=\"" . $site_config['SITEURL'] . "/images/progbar-green.gif\" height=9 width=" . ($maxpx) . " />";
 if ($p >= 1 && $p <= 30) $progress = "<img src=\"" . $site_config['SITEURL'] . "/images/progbar-red.gif\" height=9 width=" . ($p*($maxpx/100)) . " /><img src=\"" . $site_config['SITEURL'] . "/images/progbar-rest.gif\" height=9 width=" . ((100-$p)*($maxpx/100)) . " />";
 if ($p >= 31 && $p <= 65) $progress = "<img src=\"" . $site_config['SITEURL'] . "/images/progbar-yellow.gif\" height=9 width=" . ($p*($maxpx/100)) . " /><img src=\"" . $site_config['SITEURL'] . "/images/progbar-rest.gif\" height=9 width=" . ((100-$p)*($maxpx/100)) . " />";
 if ($p >= 66 && $p <= 99) $progress = "<img src=\"" . $site_config['SITEURL'] . "/images/progbar-green.gif\" height=9 width=" . ($p*($maxpx/100)) . " /><img src=\"" . $site_config['SITEURL'] . "/images/progbar-rest.gif\" height=9 width=" . ((100-$p)*($maxpx/100)) . " />";
 return "<img src=\"" . $site_config['SITEURL'] . "/images/bar_left.gif\" />" . $progress ."<img src=\"" . $site_config['SITEURL'] . "/images/bar_right.gif\" />";
}

?>