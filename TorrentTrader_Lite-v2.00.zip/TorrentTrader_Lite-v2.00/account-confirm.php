<?
//
// Confirm account Via email and send PM
//
require_once("functions.php");
userlogin();
GLOBAL $site_config;

$u = $_GET["u"];
$md5 = $_GET["secret"];

if (!$u)
	httperr();

$user_filename = $site_config['userdir'].'/'.strtolower($u).".date";

userlogin();

if(!file_exists($user_filename)
httperr();

$user = readuserfile($user_filename);

if ($user["confirmed"]) {
	header("Refresh: 0; url=account-confirm-ok.php?type=confirmed");
	exit();
}

$user['confirmed'] = 'yes';

$sec = hash_pad($user["secret"]);
if ($md5 != md5($sec))
	httperr();

$newsec = mksecret();

logincookie($user["username"], $user["password"], $newsec);

header("Refresh: 0; url=account-confirm-ok.php?type=confirm");

?>
