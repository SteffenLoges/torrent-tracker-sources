<?
require("backend/functions.php");
require("backend/benc.php");
userlogin();

  $info_hash = (string)$_GET['info_hash'];
  $action = (string)$_GET['action'];

  if ($action == "nfo")
    {
        if ( !file_exists('torrents/'.$info_hash.'.nfo'))
          {
          // invalid info_hash format
          header("Location: index.php");
          exit();
          }
          else
          {
               // we display the torrent
            $fn = 'torrents/'.$info_hash.'.nfo';
            header("Pragma: public");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Content-Type: text/plain");
            $user_agent = strtolower ($_SERVER["HTTP_USER_AGENT"]);

            if ((is_integer (strpos($user_agent, "msie"))) && (is_integer (strpos($user_agent, "win")))) {
              header( "Content-Disposition: filename=".$info_hash.'.nfo');
            } else {
              header( "Content-Disposition: attachment; filename=".$info_hash.'.nfo');
            }

            header("Content-Transfer-Encoding: binary");
            header("Content-Length: ".filesize($fn));


            @readfile($fn);
            exit();
          }
    }
  else if ($action == "image")
    {
        if ( !file_exists('torrents/'.$info_hash.'.jpg'))
          {
          // invalid info_hash format
          header("Location: index.php");
          exit();
          }
          else
          {
               // we display the torrent
            $fn = 'torrents/'.$info_hash.'.jpg';
            header("Pragma: public");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            $user_agent = strtolower ($_SERVER["HTTP_USER_AGENT"]);

            if ((is_integer (strpos($user_agent, "msie"))) && (is_integer (strpos($user_agent, "win")))) {
              header( "Content-Disposition: filename=".$info_hash.'.jpg');
            } else {
              header( "Content-Disposition: attachment; filename=".$info_hash.'.jpg');
            }

            header("Content-Transfer-Encoding: binary");
            header("Content-Length: ".filesize($fn));


            @readfile($fn);
            exit();
          }

    }
  else if ($action = "torrent")
    {

      if (strlen($info_hash) != 40 || !file_exists('torrents/'.$info_hash.'.torrent'))
      {
      // invalid info_hash format
      header("Location: index.php");
      exit();
      }
      else
      {
            // we check if the info_hash is in database
            $source = fopen('data/torrents.dat','r+');
            flock($source, LOCK_EX) ;
            $found = 0 ;
            while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s\n")) {
            list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader) = $info;
             if ($info_hash ==  $prev_info_hash)
              {
                // found
                $fname = $filename;
                $found += 1;
                $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits+1,$uploader);
             }
             else
             $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits);
            }
            // we update the hit counter for this torrent
            rewind($source);
            ftruncate($source,0);
            fwrite($source, $content);
            flock($source, LOCK_UN);
            fclose($source);

            if ($found == 0)
            {
            // not found
            header("Location: index.php");
            exit();
            }




            // we display the torrent
         	$fn = 'torrents/'.$info_hash.'.torrent';
				
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Content-Type: application/x-bittorrent");
			header("Content-Disposition: attachment; filename=\"$filename\"");
    	    header("Content-Transfer-Encoding: binary");
    	    

    	    $dict = bdec_file($fn, 1000000);
			$dict['value']['announce']['value'] .= "?user=".urlencode($CURUSER['username']);
			$dict['value']['announce']['strlen'] = strlen($dict['value']['announce']['value']);
			$benc = benc($dict);
			echo $benc;
    	    exit();
        }
      }
  else
    {
        header("Location: index.php");
        exit();
    }







?>