</TD></TR>
              </TBODY></TABLE></TD></TR></TBODY></TABLE><BR>
    </TD></TR>
  <TR>
    <TD class=bottomarea style="PADDING-BOTTOM: 5px; PADDING-TOP: 3px">
      <TABLE cellSpacing=3 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
			<TD style="PADDING-TOP: 8px" align=right><IMG alt="Return to top" hspace=2 src="themes/default/images/up_arrow.gif" align=absBottom><A href="#top">Return to top</A></TD>
		</TR>
<?
// Variables for Start Time 
$totaltime = array_sum(explode(" ", microtime())) - $GLOBALS['tstart'];
printf("<TR><TD align=middle>Page generated in %f seconds!</TD></TR>", $totaltime);
?>
<TR><TD align=middle>Powered by <a href="http://www.torrenttrader.org" target=_blank>TorrentTrader Lite v1.0.3</a></TD></TR>
<TR><TD align=middle>Theme: TorrentRoots for TT Classic. Modified for TT Lite by <a href="http://www.torrenttrader.org">TorrentialStorm</a></TD></TR>
</TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>
<DIV id=stat style="LEFT: 0px; VISIBILITY: hidden; POSITION: absolute; TOP: 0px"></DIV>
<DIV style="LEFT: 0px; VISIBILITY: hidden; POSITION: absolute; TOP: 0px"></DIV></BODY></HTML>
