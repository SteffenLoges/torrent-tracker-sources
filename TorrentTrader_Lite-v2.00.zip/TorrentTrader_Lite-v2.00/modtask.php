<?
require "backend/functions.php";
userlogin();
loggedinonly();
modonly();

$action = $_POST["action"];
$username = $_POST['username'];

if ($action == 'edituser') {
	$userid = $_POST["userid"];
	$title = $_POST["title"];
	$downloaded = $_POST["downloaded"];
	$uploaded = $_POST["uploaded"];
	$signature = $_POST["signature"];
	$avatar = $_POST["avatar"];
	$ip = $_POST["ip"];
	$class = $_POST["class"];
	$donated = $_POST["donated"];
	$password = $_POST["password"];
	$warned = $_POST["warned"];
	$modcomment = $_POST["modcomment"];
	$enabled = $_POST["enabled"];
	$invites = $_POST["invites"];

	if (!is_valid_user_class($class))
		genbark("Editing Failed", "Invalid UserID");

	$file = "$site_config[userdir]/".strtolower($username).".dat";
	if (!$user=readuserfile($file))
		die("Error opening user file.");
	if ($user['class'] != $class) {
		// You cant demote admins!
		if ((get_user_class() == UC_ADMINISTRATOR) && ($user['username'] == $CURUSER['username']))
			genbark("Editing Failed", "You can't demote admins for security reasons.");
		// User may not demote someone with same or higher class than himself!
		elseif ($uc >= get_user_class())
			genbark("Editing Failed", "You may not demote someone with same or higher class than yourself");
		// All ok, update db
		else {
			$user['class'] = $class;
		}
	}
	
	$user['title'] = $title;
	$user['downloaded'] = $downloaded;
	$user['uploaded'] = $uploaded;
	//$user['signature'] = $signature;
	$user['avatar'] = $avatar;
	$user['ip'] = $ip;
	$user['donated'] = $donated;
	$user['warned'] = $warned;
	$user['modcomment'] = $modcomment;
	$user['enabled'] = $enabled;
	
	write_log($CURUSER['username']." has edited user: $user's details");
  
	$chgpasswd = $_POST['chgpasswd']=='yes' ? true : false;
	if ($chgpasswd) {
		if(md5($password) != $user['password']){
			$user['password'] = md5($password);
			write_log($CURUSER['username']." has changed password for user: $user");
		}
	}
	writeuserfile($file, $user);
	header("Location: account-details.php?user=$username");
	die;
}

if ($action == "banuser")
{
  die("Note finished");
  $userid = $_POST["userid"];
  $what = $_POST["what"];
  if (!is_valid_id($userid))
	genbark("Not a vaild Userid");
  $comment = $_POST['comment'];
  if (!$comment)
	genbark("Error:", "Please explain why you are banning this user!");
  $r = mysql_query("SELECT username,ip FROM users WHERE id=$userid") or sqlerr();
  $a = mysql_fetch_assoc($r);
  $username = $a["username"];
  $ip = $a["ip"];
  if ($what == "subnet")
  	$ip = substr($ip, 0, strrpos($ip, ".")) . ".*";
  else
	if ($what == 'ip')
	  $extra = " OR ip='" . substr($ip, 0, strrpos($ip, ".")) . ".*'";
	else
	  genbark("Heh", "Select what to ban!");
  $r = mysql_query("SELECT * FROM bans WHERE ip='$ip'$extra") or sqlerr();
  if (mysql_num_rows($r) > 0)
	genbark("Error", "IP/subnet is already banned");
  else {
	$dt = get_date_time();
	$comment = sqlesc($comment);
	mysql_query("INSERT INTO bans (userid, first, last, added, addedby, comment) VALUES($userid, '$ip', '$ip', '$dt', $CURUSER[id], $comment)") or sqlerr();
	mysql_query("UPDATE users SET secret='' WHERE id=$userid") or sqlerr();
	$returnto = $_POST["returnto"];
	header("Location: $returnto");
	die;
  }
}

if ($action == "enableaccount")
{
  die("Not finished");
  $userid = $_POST["id"];
  $res = mysql_query("SELECT * FROM users WHERE id='$userid'") or sqlerr();
  if (mysql_num_rows($res) != 1)
	genbark("User $userid not found!");
  $secret = sqlesc(mksecret());
  mysql_query("UPDATE users SET secret=" . $secret . " WHERE id=$userid") or sqlerr();
  header("Location: account-details.php?id=$userid");
  die;
}

genbark("Error","This task is not found");

?>