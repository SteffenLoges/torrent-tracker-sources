<?
//
// CSS and language updated 30.11.05
//
require_once("backend/functions.php");

userlogin();
loggedinonly();

if (!$_POST['info_hash'])
	genbark("missing form data");

$info_hash = $_POST['info_hash'];

if (!file_exists("./torrents/$info_hash.torrent"))
	stderr(FILE_NOT_FOUND, TORRENT_NOT_FOUND."<BR><BR><a href='index.php'>Click here</a> to go back to the index.");

$source = fopen('data/torrents.dat','r+');
flock($source, LOCK_EX) ;
while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %s %s\n")) {
	list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$user,$views,$date,$time) = $info;
	if ($info_hash == $prev_info_hash) {
		$row['name'] = $name;
		$row['uploader'] = $user;
	}else
	$content .= $info;
}

if (!$row)
	stderr(FILE_NOT_FOUND, TORRENT_NOT_FOUND."<BR><BR><a href='index.php'>Click here</a> to go back to the index.");

flock($source, LOCK_UN);

if ($CURUSER["username"] != $row["uploader"] && get_user_class() < UC_MODERATOR){
bark("Error", "" . CANT_EDIT_TORRENT . "");
die;
}

$reason = trim($_POST["reason"]);
if (!$reason){
bark("Error", "" . REASON_FOR_DELETE . "");
die;
}
flock($source, LOCK_EX);
rewind($source);
ftruncate($source,0);
fwrite($source,$content);
flock($source, LOCK_UN);
fclose($source);

@unlink("./torrents/$info_hash.torrent");
@unlink("./torrents/$info_hash.nfo");
@unlink("./torrents/$info_hash.jpg");
@unlink("./data/$info_hash.dat");


write_log("Torrent $row[name] ($info_hash) was deleted by $CURUSER[username] ($reason)\n");

site_header("Torrent deleted!");
begin_frame();

if (isset($_POST["returnto"]))
	$ret = "<BR><BR><a href=\"" . htmlspecialchars($_POST["returnto"]) . "\">Back</a><BR>";
else
	$ret = "<BR><BR><a href=\"index.php\">Back to index</a><BR>";

echo TORRENT_DELETED;
?>
<BR><p><?=$ret?></p></br>

<?
end_frame();

site_footer();
?>