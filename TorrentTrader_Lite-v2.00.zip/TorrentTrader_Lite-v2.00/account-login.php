<?
//
// CSS and Language updated 30.11.05
//
require_once("backend/functions.php");
unset($returnto);
if (!empty($_GET["returnto"])) {
	$returnto = $_GET["returnto"];
	if (!$_GET["nowarn"]) {
		$message = "" . SORRY_MEMBERS_ONLY . "";
	}
}

	if (!empty($username)) {
	$password = md5($password);

	$file = $site_config['userdir'].strtolower($username).'.dat';
	if (!file_exists($file))
		$message = "" . USERNAME_WRONG . "";
	if (empty($message)) {
	if (!($user=readuserfile($file))) die;
	if ($user["password"] != $password)
		$message = "" . PASSWORD_WRONG . "";
	elseif (!$user["enabled"])
		$message = "" . ACCOUNT_DISABLED . "";
	elseif (!$user["confirmed"])
		$message = "" . ACCOUNT_PENDING . "";
	else {
		logincookie($username, $password, hash_pad($user["secret"]));
		if (!empty($_POST["returnto"])) {
			header("Refresh: 0; url=" . $_POST["returnto"]);
			die();
		}
		else {
			header("Refresh: 0; url=index.php");
			die();
		}
	}
}
}

//logoutcookie();

site_header("Login");

begin_frame("" . LOGIN . "");

if ($message != "")
	bark2("Access Denied", $message);
?>

<form method="post" action="account-login.php">
	<div align="center">
	<table border="0" cellpadding=5>
		<tr><td><B><?echo "" . USERNAME . "";?>:</B></td><td align=left><input type="text" size=40 name="username" /></td></tr>
		<tr><td><B><?echo "" . PASSWORD . "";?>:</B></td><td align=left><input type="password" size=40 name="password" /></td></tr>
		<tr><td colspan="2" align="center"><input type="submit" value="<?echo "" . LOGIN . "";?>" class=btn><BR><BR><i><?echo "" . COOKIES . "";?></i></td></tr>
	</table>
	</div>
<?

if (isset($returnto))
	print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($returnto) . "\" />\n");

?>

</form>
<p align="center"><a href="account-signup.php"><?echo "" . REGISTERNEW . "";?></a> | <a href="account-recover.php"><?echo "" . RECOVER_ACCOUNT . "";?></a> | <a href="account-delete.php"><?echo "" . DELETE_ACCOUNT . "";?></a></p>

<?
end_frame();
site_footer();
?>