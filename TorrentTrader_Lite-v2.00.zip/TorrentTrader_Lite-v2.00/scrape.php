<?


    ob_start('ob_gzhandler');

/*******************************************************************\
* benc Functions (last edited by SqrtBoy 12-01-05 @ 17.25)           *
*  - detect the type of an object and bencode it                     *
\*******************************************************************/

    function benc($obj) {
    if (!is_array($obj) || !isset($obj["type"]) || !isset($obj["value"]))
        return;
    $c = $obj["value"];
    switch ($obj["type"]) {
        case "string":
            return benc_str($c);
        case "integer":
            return benc_int($c);
        case "list":
            return benc_list($c);
        case "dictionary":
            return benc_dict($c);
        default:
            return;
        }
    }

/*******************************************************************\
* benc_str Functions (last edited by SqrtBoy 12-01-05 @ 17.25)       *
*  - bencode a string                                                *
\*******************************************************************/

    function benc_str($s) {
        return strlen($s) . ":$s";
    }

    function benc_int($i) {
        return "i" . $i . "e";
    }

/*******************************************************************\
* benc_list Functions (last edited by SqrtBoy 12-01-05 @ 17.26)      *
*  - bencode a list                                                  *
\*******************************************************************/

    function benc_list($a) {
        $s = "l";
        foreach ($a as $e) {
            $s .= benc($e);
        }
        $s .= "e";
        return $s;
    }

/*******************************************************************\
* benc_dict Functions (last edited by SqrtBoy 12-01-05 @ 17.30)      *
*  -bencode a dictionnary                                            *
\*******************************************************************/

    function benc_dict($d) {
        $s = "d";
        $keys = array_keys($d);
        sort($keys);
        foreach ($keys as $k) {
            $v = $d[$k];
            $s .= benc_str($k);
            $s .= benc($v);
        }
        $s .= "e";
        return $s;
    }

/*******************************************************************\
* err Functions (last edited by SqrtBoy 12-01-05 @ 17.30)            *
*  - display errors                                                  *
\*******************************************************************/

    function err($msg)
    {
    	benc_resp(array('failure reason' => array(type => 'string', value => $msg)));
        exit();
    }

/*******************************************************************\
* benc_resp Functions (last edited by SqrtBoy 12-01-05 @ 17.30)      *
*                                                                    *
\*******************************************************************/

    function benc_resp($d)
    {
    	benc_resp_raw(benc(array(type => 'dictionary', value => $d)));
    }

/*******************************************************************\
* benc_resp_raw Functions (last edited by SqrtBoy 12-01-05 @ 17.30)  *
*  - outputs the msg to webbrowser                                   *
\*******************************************************************/

    function benc_resp_raw($x)
    {
    	header('Content-Type: text/plain');
    	header('Pragma: no-cache');
    	print($x);
    }

/*******************************************************************\
* hex2bin Functions (last edited by SqrtBoy 12-01-05 @ 17.30)        *
*  - converts hex value into  ascii equivalent                       *
\*******************************************************************/

    function hex2bin($hexdata) {
      $bindata = "";
      for ($i=0;$i<strlen($hexdata);$i+=2) {
        $bindata.=chr(hexdec(substr($hexdata,$i,2)));
      }

      return $bindata;
    }

    // we parse the info_hash correctly
    $usehash = false;
    if (isset($_GET['info_hash']))
    {
    	if (get_magic_quotes_gpc())
    		$info_hash = stripslashes($_GET['info_hash']);
    	else
    		$info_hash = (string)$_GET['info_hash'];
    	if (strlen($info_hash) == 20)
    		$info_hash = bin2hex($info_hash);
    	else if (strlen($info_hash) != 40)
    		err(SCRAPE_INVALID_HASH);
    	$info_hash = strtolower($info_hash);
    	$usehash = true;
    }

    if ($usehash)
    {
    // single scrape

            $source = fopen('data/torrents.dat','r');
            flock($source, LOCK_EX) ;
            $found = 0 ;
            // we check if the info_hash is in database
            while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d\n")) {
            list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits) = $info;
            if ($prev_info_hash == $info_hash)
                {
                         $resp = 'd5:filesd';
                         $resp .= '20:'.hex2bin($info_hash).'d';
                         $resp .= '8:completei'.$seeders.'e';
                         $resp .= '10:downloadedi'.$completed.'e';
                         $resp .= '10:incompletei'.$leechers.'e';
                         if (isset($name))
                         $resp .= '4:name'.strlen($name).':'.$name.'e';
                         $resp .= 'e';
                         $resp .= 'ee';
                         $found += 1;
                         break;
                }

            }

            flock($source, LOCK_UN);
            fclose($source);

            // not found
            if ($found == 0)   err($info_hash.SCRAPE_HASH_NOT_FOUND);
    }
    else
    {
    // global scrape
    $resp = 'd5:filesd';


    $source = fopen('data/torrents.dat','r');
    flock($source, LOCK_EX) ;
    $found = 0 ;
    while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d\n")) {
    list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits) = $info;
        $resp .= '20:'.hex2bin($prev_info_hash).'d';
        $resp .= '8:completei'.$seeders.'e';
        $resp .= '10:downloadedi'.$completed.'e';
        $resp .= '10:incompletei'.$leechers.'e';
        if (isset($name))
        $resp .= '4:name'.strlen($name).':'.$name.'e';
        $resp .= 'e';
        $found += 1;
    }
    flock($source, LOCK_UN);
    fclose($source);

    $resp .= 'ee';




    }

    // scrape is sent to browser
    benc_resp_raw($resp);
    exit();


?>