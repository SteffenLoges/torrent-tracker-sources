<?php

    require_once('backend/functions.php');
	userlogin();

    site_header("Home");
    $keywords = '' ;
    $cat = '' ;
    if (isset($_POST['keywords']))
    $keywords = (string)$_POST['keywords'] ;
    if (isset($_POST['category']))
    $cat = (string)$_POST['category'] ;

    if (isset($_GET['page']))
    $page = (int)$_GET['page'] ;


    // we display the search box
    $content = '
           <div align="justify">
           <table align="center" width="100%" style="border-style: dashed; border-width: 1px; border-color: #AAAAAA;">
           <tr><td>
           <form action="index.php" method="post">
               <table align="center" border="0" cellspacing="0">
                        <tr>
                            <td>'.INDEX_KEYWORDS.'</td>
                            <td><input type="text" name="keywords" style="width:300px;" value="'.$keywords.'"></td>

                        </tr>

                        <tr>
                            <td>'.INDEX_CATEGORY.'</td><td>
                            <select name="category" size="1" style="width:300px;">
                            <option>'.INDEX_ALL_CATEGORIES.'</option>';

                     foreach ($categories as $value)
                        $content .='<option value="'.$value.'">'.$value.'</option>';

                      $content .=  '</select>
                            </td>

                        </tr>
                        <tr>
                            <td></td>
							<td align="right"><input type="submit" value="'.INDEX_SEARCH.'" /></td>

                        </tr>
                    </table></form>
           </td></tr>
           </table>
           </div>';

    // we list the torrents on the tracker
    $content .= '<br><br>
    <div align="justify">
    <table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse;border:1px solid #646262;" width="100%" border="1"><tr>
    <td>
    <table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse;border: 1px solid #D6D9DB" width="100%" border="1">
    <tr>
    <td bgcolor="F9F9F9" align=center width="10%">'.INDEX_TYPE.'</td>

    <td bgcolor="F9F9F9" align=center width="30%">'.INDEX_NAME.'</td>
    <td bgcolor="F9F9F9" align=left width="5%"></td>
    <td bgcolor="F9F9F9" align=center width="14%">'.INDEX_SIZE.'</td>
	<td bgcolor="F9F9F9" align=center width="10%">Uploader</td>
    <td bgcolor="F9F9F9" align=center width="7%">'.INDEX_COMPLETED.'</td>
    <td bgcolor="F9F9F9" align=center width="10%">'.INDEX_SEEDERS.'</td>
    <td bgcolor="F9F9F9" align=center width="11%">'.INDEX_LEECHERS.'</td>
    </tr>';

    // if not exists already, we create it
    if (!file_exists('data/torrents.dat'))
		touch('data/torrents.dat');

    $source = fopen('data/torrents.dat','r');
    flock($source, LOCK_EX) ;
    $cnt = 0;

    $total = 0;
	
	$files = 0;
	$totalsize = 0;

    while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d\n")) {
    if (!file_exists('data/'.$info_hash.'.dat.lock'))
    $total++;
    }

    rewind($source);

    list($quotient,$reste) = euclidivision($total,$site_config['TORRENTSPERPAGE']);

    if ($page == "")
    $page = 0;

    // we process the search form and display the results
    while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %s %s\n")) {
    list ($info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader,$views,$date,$time) = $info;

    // has the torrent been banned from server ?
    if (file_exists('data/'.$info_hash.'.dat.lock'))
    continue;

	$files += $numfiles;
	$totalsize += $size;

    $totseeders += $seeders;
    $totleechers += $leechers;

    $category = "<img src='./images/categories/".$category.".gif' alt='".$category."'>";
    $newname = substr($name, 0, $site_config['MAXDISPLAYLENGTH']);
    if ($newname != $name)
    $name = htmlspecialchars("$newname...");
    else
    $name = htmlspecialchars($name);

    if ($cnt >= $page*$site_config['TORRENTSPERPAGE'] && $cnt < ($page+1)*$site_config['TORRENTSPERPAGE'])
    {
        // user entered a word to search and changed the default category
        if ($keywords != "" && ($cat != "" && $cat != INDEX_ALL_CATEGORIES) )
        {
            if (eregi($cat,$category) && (eregi($keywords,$name) || eregi($keywords,$filename) || eregi($keywords,$descr)))
            {
             $content .=
            '<tr>
                           <td align=center width="10%">'.$category.'</td>
                            <td align=left width="30%">&nbsp;<a href="torrents-details.php?info_hash='.$info_hash.'">'.$name.'</a></td>
                            <td align=left width="5%"><a href="download.php?action=torrent&amp;info_hash='.$info_hash.'">&nbsp;<img src="images/download.gif" border=0 alt="Download"></a><a href="torrents-details.php?info_hash='.$info_hash.'">&nbsp;<img src="images/details.gif" border=0 alt="Details"></a></td>
                            <td align=center width="14%">'.mksize($size).'</td>
							<td align=center width="10%">'.$uploader.'</td>
                            <td align=center width="7%">'.$completed.'</td>
                            <td align=center width="10%"><font color=green>'.$seeders.'</font></td>
                            <td align=center width="11%"><font color=blue>'.$leechers.'</font></td>

            </tr>';
            $cnt++;
            }
        }
        // user just changed the default category
        else if ($keywords == "" && ($cat != "" && $cat != "All Categories") )
        {
            if (eregi($cat,$category))
            {
            $content .=
            '<tr>
                           <td align=center width="10%">'.$category.'</td>

                            <td align=left width="30%">&nbsp;<a href="torrents-details.php?info_hash='.$info_hash.'&hit=1">'.$name.'</a></td>
                            <td align=left width="5%"><a href="download.php?action=torrent&amp;info_hash='.$info_hash.'">&nbsp;<img src="images/download.gif" border=0 alt="Download"></a><a href="torrents-details.php?info_hash='.$info_hash.'">&nbsp;<img src="images/details.gif" border=0 alt="Details"></a></td>
                            <td align=center width="14%">'.mksize($size).'</td>
							<td align=center width="10%">'.$uploader.'</td>
                            <td align=center width="7%">'.$completed.'</td>
                            <td align=center width="10%"><font color=green>'.$seeders.'</font></td>
                            <td align=center width="11%"><font color=blue>'.$leechers.'</font></td>

            </tr>';
            }
        }
        // user set category to "All Categories" but is looking for a special torrent
        else  if ( $keywords != "" && ($cat == "" || $cat == "All Categories"))
        {
            if ( (eregi($keywords,$name) || eregi($keywords,$filename) || eregi($keywords,$descr)))
            {
            $content .=
            '<tr>
                           <td align=center width="10%">'.$category.'</td>

                            <td align=left width="30%">&nbsp;<a href="torrents-details.php?info_hash='.$info_hash.'">'.$name.'</a></td>
                            <td align=left width="5%"><a href="download.php?action=torrent&amp;info_hash='.$info_hash.'">&nbsp;<img src="images/download.gif" border=0 alt="Download"></a><a href="torrents-details.php?info_hash='.$info_hash.'">&nbsp;<img src="images/details.gif" border=0 alt="Details"></a></td>
                            <td align=center width="14%">'.mksize($size).'</td>
							<td align=center width="10%">'.$uploader.'</td>
                            <td align=center width="7%">'.$completed.'</td>
                            <td align=center width="10%"><font color=green>'.$seeders.'</font></td>
                            <td align=center width="11%"><font color=blue>'.$leechers.'</font></td>

            </tr>';
            }
        }
        // user is not doing a search
        else
        {
            $content .=
            '<tr>
                           <td align=center width="10%">'.$category.'</td>
                            <td align=left width="30%">&nbsp;<a href="torrents-details.php?info_hash='.$info_hash.'&hit=1">'.$name.'</a></td>
                            <td align=left width="5%"><a href="download.php?action=torrent&amp;info_hash='.$info_hash.'">&nbsp;<img src="images/download.gif" border=0 alt="Download"></a><a href="torrents-details.php?info_hash='.$info_hash.'">&nbsp;<img src="images/details.gif" border=0 alt="Details"></a></td>
                            <td align=center width="14%">'.mksize($size).'</td>
							<td align=center width="10%">'.$uploader.'</td>
                            <td align=center width="7%">'.$completed.'</td>
                            <td align=center width="10%"><font color=green>'.$seeders.'</font></td>
                            <td align=center width="11%"><font color=blue>'.$leechers.'</font></td>

            </tr>';
        }
    }
    $cnt++;
    }

    flock($source, LOCK_UN);
    fclose($source);

    // no result was found
    if ($cnt == 0)
    $content .= '<td align="center" colspan=7><br>
        <table border="0" width="500" cellspacing="0" cellpadding="0"><tr>
        <td bgcolor="#FFFFFF" align="center" style="border-style: dotted; border: 1px solid red;">
        <font face="Verdana" size="1">'.NO_RESULTS.'</font></td>
        </tr></table><br>';

    $content .=' </table></td></tr></table>';

    /*if ($quotient > 0)
    {
      $content .= '<div align=center>'.INDEX_PAGE.': ';
      if ($reste==0)
        $lim = $quotient-1;
      else $lim = $quotient;

      for ($i=0;$i<=$lim;$i++)
      $content .= '<a href="?page='.$i.'">'.($i+1).'</a>&nbsp;';
      $content .= '</div>';
    }*/

    $content .='</div>';
    if (!isset($totseeders))
    $totseeders = 0;
    if (!isset($totleechers))
    $totleechers = 0;

	$peers = $totseeders+$totleechers;
	$files = number_format($files);
	$totalsize = mksize($totalsize);
	$content .= "<BR><BR><center>Tracking $cnt torrent".($cnt > 1 || $cnt == 0 ? "s":"")." with $peers peer".($peers > 1 || $peers == 0 ? "s":"").
	" ($totseeders seeder".($totseeders > 1 || $totseeders == 0 ? "s":"").", $totleechers leecher".($totleechers > 1 || $totleechers == 0 ? "s":"").")".
	"<BR>Number of files: $files ($totalsize)</center>";

	if ($site_config['NEWSON']) {
		require_once('news.php');
		begin_frame(SITENEWS);
		if (count($news_array)) {
			foreach ($news_array as $new) {
				echo "<strong>{$new['title']}</strong> (<i>Posted on {$new['date']} by {$new['author']}</i>)";
				echo '<TABLE CELLSPACING="0" CELLPADDING="0" BORDER="0" WIDTH="100%"><tr><TD style="background-image: url(images/line.gif)"><IMG SRC="images/transparent.gif" alt="" WIDTH="1" HEIGHT="1"></TD></tr></TABLE>';
                echo "{$new['content']}<br><br>";
            }
		}else
			echo "No news";
		end_frame();
	}

	begin_frame(BROWSE_TORRENTS);
	echo $content;
	end_frame();
	
	if ($site_config['DISCLAIMERON']) {
	begin_frame(DISCLAIMER);
	echo file_get_contents("disclaimer.txt")."<BR><BR>";
	end_frame();
	}

    site_footer();
?>