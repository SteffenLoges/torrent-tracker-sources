<?

require_once("backend/functions.php");
userlogin();
GLOBAL $countries;

/*$nuIP = getip();
$dom = @gethostbyaddr($nuIP);
if ($dom == $nuIP || @gethostbyname($dom) != $nuIP)
  $dom = "";
else
  $dom = strtoupper($dom);
  preg_match('/^(.+)\.([A-Z]{2,3})$/', $dom, $tldm);
  $dom = $tldm[2];
}*/

if ($wantusername != "") {
  $message == "";

  if (empty($wantpassword) || empty($email))
	$message = "Don't leave any required field blank.";
  if (strlen($wantusername) > 20)
	$message = "Sorry, username is too long (max is 20 chars)";
  if ($wantpassword != $passagain)
	$message = "The passwords didn't match! Must've typoed. Try again.";
  if (strlen($wantpassword) < 6)
	$message = "Sorry, password is too short (min is 6 chars)";
  if (strlen($wantpassword) > 40)
	$message = "Sorry, password is too long (max is 40 chars)";
  if ($wantpassword == $wantusername)
 	$message = "Sorry, password cannot be same as user name.";
  if (!validemail($email))
	$message = "That doesn't look like a valid email address.";
  if (!validusername($wantusername))
	$message = "Invalid username.";

// check if username is already in use

$file = "$site_config[userdir]/".strtolower($wantusername).".dat";
if (file_exists($file))
$message = "The username \"$wantusername\" is already in use";

  // check if email addy is already in use
/*  $a = (@mysql_fetch_row(@mysql_query("select count(*) from users where email='$email'"))) or die(mysql_error());
  if ($a[0] != 0)
    $message = "The e-mail address $email is already in use."; */

  $secret = mksecret();
  $wantpassword = md5($wantpassword);
  
  if (glob("$site_config[userdir]/*.dat") === false)
	$admin = true;
  else
	$admin = false;


$ip = getip();

if (empty($message)) {

$userfile = array();
$userfile['username'] = $wantusername;
$userfile['password'] = $wantpassword;
$userfile['secret'] = $secret;
$userfile['email'] = $email;
$userfile['downloaded'] = 0;
$userfile['uploaded'] = 0;
$userfile['confirmed'] = "yes";
$userfile['donated'] = 0;
$userfile['enabled'] = "yes";
$userfile['added'] = get_date_time();
if ($admin)
	$userfile['class'] = UC_ADMINISTRATOR;
else
	$userfile['class'] = UC_USER;
$userfile['ip'] = $ip;
$userfile['age'] = $age;
$userfile['country'] = $country;
$userfile['gender'] = $gender;
$userfile['client'] = $client;
$userfile['warned'] = "no";
$userfile['theme'] = $site_config['theme'];
$userfile['language'] = $site_config['language'];


if(!writeuserfile($file, $userfile))
	$message = "Error creating user";

if ($message == "") {

 write_log("User account \"$wantusername\" was created");

    $psecret = md5($secret);

    $body = <<<EOD
Your account at $site_config[SITENAME] has been : APPROVED

To confirm your user registration, you have to follow this link:

$site_config[SITEURL]/account-confirm.php?u=$wantusername&secret=$psecret

After you do this, you will be able to use your new account.
If you fail to do this, your account will be deleted within a few days.

$site_config[SITENAME] Admin
EOD;
    ini_set("sendmail_from", ""); // Null envelope (Return-Path: <>)
    mail($email, "Your $site_config[SITENAME] User Account", $body, "From: $site_config[SITENAME] <$site_config[SITEEMAIL]>");

    header("Refresh: 0; url=account-confirm-ok.php?type=signup&email=" . urlencode($email));
    die;
  }
}
}

site_header("Signup");

begin_frame("Signup");

if ($message != "")
	bark2("Signup Failed", $message);
?>

<? echo "" . COOKIES . "";?>
<p>
<form method="post" action="account-signup.php">
	<table cellSpacing="0" cellPadding="2" border="0" >
			<tr>
				<td>Username: <font class="small"><font color="#FF0000">*</font></td>
				<td><input type="text" size="40" name="wantusername" value="<? echo $wantusername; ?>" /></td>
			</tr>
			<tr>
				<td>Password: <font class="small"><font color="#FF0000">*</font></td>
				<td><input type="password" size="40" name="wantpassword" /></td>
			</tr>
			<tr>
				<td>Confirm: <font class="small"><font color="#FF0000">*</font></td>
				<td><input type="password" size="40" name="passagain" /></td>
			</tr>
			<tr>
				<td>Email: <font class="small"><font color="#FF0000">*</font></td>
				<td><input type="text" size="40" name="email" value="<? echo $email; ?>" /></td>
			</tr>
			<tr>
				<td>Age:</td>
				<td><input type="text" size="40" name="age" maxlength="3" value="<? echo $age; ?>" /></td>
			</tr>
			<tr>
			<td>Country:</td>
				<td>
					<select name="country" size="1">
						<option value=''>---- None selected ----</option>
						<?for ($i=0; $i<count($countries); $i++) echo "<option value='$countries[$i]'>$countries[$i]</option>\n";?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Gender:</td>
				<td>
					<input type="radio" name="gender" value="Male">Male
					&nbsp;&nbsp;
					<input type="radio" name="gender" value="Female">Female
				</td>
			</tr>
			<tr>
				<td>Preferred BitTorrent Client:</td>
				<td><input type="text" size="40" name="client"  maxlength="20" value="<? echo $client; ?>" /></td>
			</tr>
			<tr>
				<td>Signup Time:</td>
				<td><b><? print date("D dS M, Y h:i a"); ?></b></td>
			</tr>
			<tr>
				<td align="middle" colSpan="2">
                <input type="submit" value="Sign Up" />
              </td>
			</tr>
	</table>
</form>

<?

end_frame();
site_footer();

?>