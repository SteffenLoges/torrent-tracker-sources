<?
/**
 * TorrentTrader v1.0.3 LITE
 *  - Coded by Sqrtboy (sqrtboy@phpsoft.org)
 *  - Released under the GPL licence
 *  - Support/Hacks/Discussion @ http://www.torrenttrader.com
 **/


    ob_start('ob_gzhandler');
    require_once('backend/functions.php');
    if (!isset($language))
    $language="english.lang";

    require_once("languages/".$language);
	
	$uname = strtolower($_GET['user']);
	if (empty($uname) || !validusername($uname)) err("You must download the torrent after uploading.");
	$file = "$site_config[userdir]/$uname.dat";
	
	$ip = $_GET['ip'];
	if (!validip($ip))
		$ip = getip();
	
	if (!file_exists($file)) err("Unknown user ($uname - $ip). Please go to $site_config[SITEURL] to sign up or login.");
	$CURUSER = readuserfile($file);
	if ($CURUSER['ip'] != $ip || $CURUSER['confirmed'] == 'no') err("Unknown user ($uname - $ip). Please go to $site_config[SITEURL] to sign up or login.");


/*******************************************************************\
* Bencoding Functions (last edited by SqrtBoy 12-01-05 @ 17.10)      *
*  - to create bencoded data                                         *
\*******************************************************************/

    function benc($obj) {
    if (!is_array($obj) || !isset($obj["type"]) || !isset($obj["value"]))
        return;
    $c = $obj["value"];
    switch ($obj["type"]) {
        case "string":
            return benc_str($c);
        case "integer":
            return benc_int($c);
        case "list":
            return benc_list($c);
        case "dictionary":
            return benc_dict($c);
        default:
            return;
        }
    }

    function benc_str($s) {
        return strlen($s) . ":$s";
    }

    function benc_int($i) {
        return "i" . $i . "e";
    }

    function benc_list($a) {
        $s = "l";
        foreach ($a as $e) {
            $s .= benc($e);
        }
        $s .= "e";
        return $s;
    }

    function benc_dict($d) {
        $s = "d";
        $keys = array_keys($d);
        sort($keys);
        foreach ($keys as $k) {
            $v = $d[$k];
            $s .= benc_str($k);
            $s .= benc($v);
        }
        $s .= "e";
        return $s;
    }

/*******************************************************************\
* hex2bin Functions (last edited by SqrtBoy 12-01-05 @ 17.10)        *
*  - converts hex value into  ascii equivalent                       *
\*******************************************************************/

    function hex2bin($hex)
    {
            $result = '';
            for ($i = 0; $i < strlen($hex); $i += 2)
                    $result .= chr(hexdec(substr($hex,$i,2)));
            return $result;
    }


/*******************************************************************\
* err Functions (last edited by SqrtBoy 12-01-05 @ 20.31)           *
*  - display an error msg                                           *
\*******************************************************************/
    function err($msg,$redirect=false)
    {
    global $siteurl;
    if ($redirect)
    {
    echo '<br><br><center><b><font size=4>'.$msg.'</font></b>';
    echo "<meta http-equiv='refresh' content='3;url=".$siteurl."'>";
    exit();
    }
    else
    {
    	benc_resp(array('failure reason' => array(type => 'string', value => $msg)));
        exit();
    }
    }

/*******************************************************************\
* benc_resp Functions (last edited by SqrtBoy 12-01-05 @ 20.31)      *
*                                                                    *
\*******************************************************************/

    function benc_resp($d)
    {
    	benc_resp_raw(benc(array(type => 'dictionary', value => $d)));
    }

/*******************************************************************\
* Get IP Functions (last edited by SqrtBoy 12-01-05 @ 17.10)        *
*  - validip/getip courtesy of manolete (manolete@myway.com)        *
\*******************************************************************/

    function benc_resp_raw($x)
    {
    	header('Content-Type: text/plain');
    	header('Pragma: no-cache');
    	echo $x;
		ob_end_flush();
        exit();
    }

    $agent = $_SERVER['HTTP_USER_AGENT'];
	$client = str_replace(" ", "_", $agent);
    // Deny access made with a browser...
    //if (ereg('^Mozilla\\/', $agent) || ereg('^Opera\\/', $agent) || ereg('^Links ', $agent) || ereg('^Lynx\\/', $agent))
       //err(ANNOUNCE_REDIRECTING,true);


    $req = 'info_hash:peer_id:port:uploaded:downloaded:left:!event';
    foreach (explode(':', $req) as $x)
    {
    	if ($x[0] == '!')
    	{
    		$x = substr($x, 1);
    		$opt = 1;
    	}
    	else
    		$opt = 0;
    	if (!isset($_GET[$x]))
    	{
    		if (!$opt)
    			err('Missing Key: '.$x);
    		continue;
    	}
        if (get_magic_quotes_gpc())
        $GLOBALS[$x] = stripslashes($_GET[$x]);
        else $GLOBALS[$x] = $_GET[$x];
    }

	if (strlen($info_hash) == 40) $info_hash = hex2bin($info_hash);
    foreach (array('info_hash','peer_id') as $x)
    {
    	if (strlen($GLOBALS[$x]) != 20)
    		err("Invalid $x (" . strlen($GLOBALS[$x]) . " - " . urlencode($GLOBALS[$x]) . ")");
    }

    $num_want = 50;
    foreach(array('num want', 'numwant', 'num_want') as $k)
    {
    	if (isset($_GET[$k]))
    	{
    		$num_want = (int)$_GET[$k];
    		break;
    	}
    }

    if (!$port || $port > 0xffff)
    	err(ANNOUNCE_INVALID_PORT);


    if (!isset($event))
    	$event = '';

    $seeder = ($left == 0) ? 1 : 0;
    // Windows compatibility section -- required for Windows servers

    if (isset($info_hash))
    {
    	if (strlen($info_hash) == 20)
    		$info_hash = bin2hex($info_hash);
    	else if (strlen($info_hash) != 40)
    		err('Invalid info hash value: $info_hash');
    	$info_hash = strtolower($info_hash);

    }

    $peerid = str_replace(chr(0),"_",$peerid);

    // we check if the info_hash is in database
    $source = fopen('data/torrents.dat','r+');
    flock($source, LOCK_EX) ;
    $found = 0 ;
    while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n")) {
    list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader,$views,$added) = $info;
     if ($info_hash ==  $prev_info_hash)
      {
        // found
        $row['seeders']  = $seeders;
        $row['leechers'] = $leechers;
        $row['completed']  = $completed;
        $row['hits']  = $hits;
        $row['size']  = $size;
        $row['numfiles']  = $numfiles;
        $row['descr']  = $descr;
        $row['category']  = $category;
        $fname = $filename;
        $found += 1;
     }
    }
    flock($source, LOCK_UN);
    fclose($source);

    if ($found == 0 || file_exists('data/'.$info_hash.'.dat.lock'))
    {
    // not found
    err(ANNOUNCE_HASH_NOT_FOUND . $info_hash);
    }

    // we create it if not existing already
    if (!file_exists('data/'.$info_hash.'.dat'))
    touch('data/'.$info_hash.'.dat');

    if (file_exists('data/'.$info_hash.'.dat.lock'))
    err(ANNOUNCE_HASH_BANNED);

    if (isset($_GET['compact']))
    $compact = (int)$_GET['compact'];
    else
    $compact = 0;


    if($compact != 1)
    $resp = 'd8:completei'.$row['seeders'].'e10:incompletei'.$row['leechers'].'e8:intervali'.$site_config['announce_interval'].'e5:peersl' ;
    else
    $resp = 'd8:completei'.$row['seeders'].'e10:incompletei'.$row['leechers'].'e8:intervali'.$site_config['announce_interval'].'e5:peers' ;

    $source = fopen('data/'.$info_hash.'.dat','r+');
    flock($source, LOCK_EX) ;
    $cnt = 0;
    while ($info = fscanf ($source, "%s %s %s %d %d %ld %ld %ld %d %s %s\n")) {
    list ($prev_ip, $prev_info_hash, $prev_peer_id,$prev_port,$prev_seeder,$prev_uploaded,$prev_downloaded,$prev_left,$prev_last_action,$prev_username,$prev_client) = $info;

        switch ($event)
        {
            case "stopped":
                break;
            default:
                if ($cnt < $num_want)
                {
                    if($compact != 1)
                    {
                    $prev_peer_id = hash_pad($prev_peer_id);

                      $resp .= 'd' .
                        benc_str('ip') . benc_str($prev_ip) ;
                        if (!$_GET['no_peer_id']) {
                            $resp .= benc_str('peer id') . benc_str($prev_peer_id);
                        }
                        $resp .= benc_str('port') . benc_int($prev_port);
                        $resp .= 'e';
                    }
                    else
                    {
                    $peer_ip = explode('.', $prev_ip);
                    $peer_ip = pack('C*', $peer_ip[0], $peer_ip[1], $peer_ip[2], $peer_ip[3]);
                    $peer_port = pack('n*', (int)$prev_port);
                    $time = intval((time() % 7680) / 60);
                    if($_GET['left'] == 0)
                    $time += 128;

                    $time = pack('C', $time);

                    $peer[] = $time . $peer_ip . $peer_port;
                    $peer_num++;
                    }
                }
                break;
        }
    $cnt++;
    }

    $o = '';
    if ($compact != 1)
    $resp .= 'ee';
    else
    {
    for($i=0;$i<$peer_num;$i++)
        {
            $o .= substr($peer[$i], 1, 6);
        }
        $resp .= strlen($o) . ':' . $o . 'e' ;
    }


    // now we add the peer to the current list of peers:
    rewind($source);
    $row['seeders'] = 0;
    $row['leechers'] = 0;

    if ($seeder == 1)
    $row['seeders'] += 1;
    else
    $row['leechers'] += 1;
	
	while ($info = fscanf ($source, "%s %s %s %d %d %ld %ld %ld %d %s %s %d\n")) {
		list ($prev_ip, $prev_info_hash, $prev_peer_id,$prev_port,$prev_seeder,$prev_uploaded,$prev_downloaded,$prev_left,$prev_last_action, $prev_username,$prev_client,$prev_started) = $info;
		if ($prev_peer_id == str_replace(chr(0),"_",str_replace(" ","_",$peer_id))) {
			$CURUSER['uploaded'] += ($uploaded - $prev_uploaded);
			$CURUSER['downloaded'] += ($downloaded - $prev_downloaded);
			write_log("downloaded: $downloaded | prev_downloaded: $prev_downloaded");
			writeuserfile($file,$CURUSER);
			$started = $prev_started;
		}
	}
    rewind($source);
	if ($event == 'started') $started = time();
    if ($event != 'stopped')
    $content = sprintf("%s %s %s %d %d %d %d %d %d %s %s %d\n",$ip, $info_hash, str_replace(chr(0),"_",str_replace(" ","_",$peer_id)),$port,$seeder,$uploaded,$downloaded,$left,strtotime("now"), $uname, $client,$started);
    while ($info = fscanf ($source, "%s %s %s %d %d %ld %ld %ld %d %s %s %d\n")) {
    list ($prev_ip, $prev_info_hash, $prev_peer_id,$prev_port,$prev_seeder,$prev_uploaded,$prev_downloaded,$prev_left,$prev_last_action, $prev_username, $prev_client,$prev_started) = $info;
        // we do not add old peers and duplicate peers
        if (floor((strtotime('now') - $prev_last_action) / 60) < 60 && ($prev_peer_id != str_replace(chr(0),"_",str_replace(" ","_",$peer_id))) )
        {
            $content .= sprintf("%s %s %s %d %d %ld %ld %ld %d %s %s %d\n",$prev_ip, $prev_info_hash, $prev_peer_id,$prev_port,$prev_seeder,$prev_uploaded,$prev_downloaded,$prev_left,$prev_last_action, $prev_username, $prev_client, $prev_started);
            if ($prev_seeder == 1)
            $row['seeders'] += 1;
            else
            $row['leechers'] += 1;
        }
    }

    rewind($source);
    ftruncate($source,0);
    fwrite($source, $content);
    flock($source, LOCK_UN);
    fclose($source);



    // we check if the info_hash is in database
    $source = fopen('data/torrents.dat','r+');
    flock($source, LOCK_EX) ;
    $content = '';
    while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n")) {
    list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader,$views,$added) = $info;
     if ($info_hash ==  $prev_info_hash)
     {
        if ($event == "completed")
            $row['completed'] += 1;
		if ($event == "stopped")
			if ($seeder == 0)
				$row['leechers'] -= 1;
			else
				$row['seeders'] -= 1;
        $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$row['seeders'],$row['leechers'],$row['completed'],$hits,$uploader,$views,$added);
     }
     else
     $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s %d %d\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader,$views,$added);
    }


    // we update the data for this torrent
    rewind($source);
    ftruncate($source,0);
    fwrite($source, $content);
    flock($source, LOCK_UN);
    fclose($source);


    // finally we send the data to the client
    benc_resp_raw($resp);
?>