<?

  require_once("backend/functions.php");
  require_once("backend/benc.php");
  userlogin();

  $info_hash = (string)$_GET['info_hash'];

  if (strlen($info_hash) != 40 || !file_exists('torrents/'.$info_hash.'.torrent') || file_exists('data/'.$info_hash.'.dat.lock'))
	stderr(FILE_NOT_FOUND, TORRENT_NOT_FOUND."<BR><BR><a href='index.php'>Click here</a> to go back to the index.");


          // seeders table
        $seeders_display .=
        '<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse;border-color:#646262" width="100%" border="1"><tr>
        <td>
        <table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse;border-color:#D6D9DB" width="100%" border="1">
        <tr>
		<td bgcolor="F9F9F9" align=center width="15%">Username</td>';
        if (get_user_class() >= UC_MODERATOR)
			$seeders_display .= '<td bgcolor="F9F9F9" align=center width="10%">'.DETAILS_IP.'</td>';
        $seeders_display .= '<td bgcolor="F9F9F9" align=center width="10%">'.DETAILS_PORT.'</td>
        <td bgcolor="F9F9F9" align=center width="20%">'.DETAILS_UL.'</td>
        <td bgcolor="F9F9F9" align=center width="20%">'.DETAILS_DL.'</td>
        <td bgcolor="F9F9F9" align=center width="15%">'.DETAILS_LEFT.'</td>
        <td bgcolor="F9F9F9" align=center width="15%">'.DETAILS_IDLE.'</td>
        </tr>';

        // leechers table
        $leechers_display .=
        '<table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse;border-color:#646262" width="100%" border="1"><tr>
        <td>
        <table align=center cellpadding="0" cellspacing="0" style="border-collapse: collapse;border-color:#D6D9DB" width="100%" border="1">
        <tr>
		<td bgcolor="F9F9F9" align=center width="15%">Username</td>';
        if (get_user_class() >= UC_MODERATOR)
			$leechers_display .= '<td bgcolor="F9F9F9" align=center width="10%">'.DETAILS_IP.'</td>';
        $leechers_display .= '<td bgcolor="F9F9F9" align=center width="10%">'.DETAILS_PORT.'</td>
        <td bgcolor="F9F9F9" align=center width="20%">'.DETAILS_UL.'</td>
        <td bgcolor="F9F9F9" align=center width="20%">'.DETAILS_DL.'</td>
        <td bgcolor="F9F9F9" align=center width="15%">'.DETAILS_LEFT.'</td>
        <td bgcolor="F9F9F9" align=center width="15%">'.DETAILS_IDLE.'</td>
        </tr>';

        // we create it if doesn't exist already
        if (!file_exists('data/'.$info_hash.'.dat'))
        touch('data/'.$info_hash.'.dat');

        $source = fopen('data/'.$info_hash.'.dat','r+');
        flock($source, LOCK_EX) ;
        while ($info = fscanf ($source, "%s %s %s %d %d %ld %ld %ld %d %s\n")) {
        list ($ip, $prev_info_hash, $peerid,$port,$seeder,$uploaded,$downloaded,$left,$last_action, $user) = $info;
         if ($info_hash ==  $prev_info_hash)
          {
          if (floor((strtotime('now') - $last_action) / 60) < 60)
            {
                $pcontent .= sprintf("%s %s %s %d %d %ld %ld %ld %d %s\n",$ip, $prev_info_hash, $peerid,$port,$seeder,$uploaded,$downloaded,$left,$last_action, $user);
                if ($seeder == 1)
                {
                // it's a seeder
                $seeders_display .=
                '<tr>
					<td align=center width="15%"><a href="account-details.php?user='.$user.'">'.$user.'</a></td>';
					if (get_user_class() >= UC_MODERATOR)
						$seeders_display .= '<td align=center width="10%">'.$ip.'</td>';
						//$seeders_display .= '<td align=center width="10%">'.preg_replace('/\.\d+\.\d+$/', ".x.x", $ip).'</td>';
                    $seeders_display .= '<td align=center width="10%">'.$port.'</td>
                    <td align=center width="20%"><font color=green>'.mksize($uploaded).'</font></td>
                    <td align=center width="20%"><font color=blue>'.mksize($downloaded).'</font></td>
                    <td align=center width="15%">'.mksize($left).'</td>
                    <td align=center width="15%">'.mkprettytime(strtotime('now')-$last_action).'</td>
                </tr>';
                $count_s += 1;
                }
                else
                {
                // it's a leecher
                $leechers_display .=
                '<tr>
					<td align=center width="15%"><a href="account-details.php?user='.$user.'">'.$user.'</a></td>';
					if (get_user_class() >= UC_MODERATOR)
						$leechers_display .= '<td align=center width="10%">'.$ip.'</td>';
						//$leechers_display .= '<td align=center width="10%">'.preg_replace('/\.\d+\.\d+$/', ".x.x", $ip).'</td>';
                    $leechers_display .= '<td align=center width="10%">'.$port.'</td>
                    <td align=center width="20%"><font color=green>'.mksize($uploaded).'</font></td>
                    <td align=center width="20%"><font color=blue>'.mksize($downloaded).'</font></td>
                    <td align=center width="15%">'.mksize($left).'</td>
                    <td align=center width="15%">'.mkprettytime(strtotime('now')-$last_action).'</td>
                </tr>';
                $count_l += 1;
                }
            }
          }

        }
        rewind($source);
        ftruncate($source,0);
        fwrite($source,$pcontent);
        flock($source, LOCK_UN);
        fclose($source);

        // no leecher found
        if ($count_l == 0)
        $leechers_display .= '<tr><td align="center" colspan=8><br>
            <table border="0" width="500" cellspacing="0" cellpadding="0"><tr>
            <td bgcolor="#FFFFFF" align="center" style="border-style: dotted; border-width: 1px;border-color:red">
            <font face="Verdana" size="1">'.DETAILS_NO_LEECHERS.'</font></td>
            </tr></table><br></td></tr></table></td></tr></table>';
        else  $leechers_display .="</table></td></tr></table>";

        // no seeder found
        if ($count_s == 0)
        $seeders_display .= '<tr><td align="center" colspan=8><br>
            <table border="0" width="500" cellspacing="0" cellpadding="0"><tr>
            <td bgcolor="#FFFFFF" align="center" style="border-style: dotted; border-width: 1px; border-color:red">
            <font face="Verdana" size="1">'.DETAILS_NO_SEEDERS.'</font></td>
            </tr></table><br></td></tr></table></td></tr></table>';
        else $seeders_display .="</table></td></tr></table>";


        // we check if the info_hash exists in our database
        $source = fopen('data/torrents.dat','r+');
        flock($source, LOCK_EX) ;
        $found = 0 ;
        while ($info = fscanf ($source, "%s %s %s %ld %d %s %s %d %d %d %d %s\n")) {
        list ($prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$user) = $info;

         if ($info_hash ==  $prev_info_hash)
          {
            // found it
            $row['name']  = $name;
            $row['filename'] = $filename;
            $row['seeders']  = $seeders;
            $row['leechers'] = $leechers;
            $row['completed']  = $completed;
            $row['hits']  = $hits;
            $row['size']  = $size;
            $row['numfiles']  = $numfiles;
            $row['descr']  = $descr;
            $row['category']  = $category;
			$row['uploader'] = $user;
			$row['info_hash'] = $info_hash;
            $found += 1;
            $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$count_s,$count_l,$completed,$hits, $user);
         }
         else
         $content .= sprintf("%s %s %s %ld %d %s %s %d %d %d %d %s\n",$prev_info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$user);
        }
        rewind($source);
        ftruncate($source,0);
        fwrite($source,$content);
        flock($source, LOCK_UN);
        fclose($source);

        if ($found == 0)
			stderr(FILE_NOT_FOUND, TORRENT_NOT_FOUND."<BR><BR><a href='index.php'>Click here</a> to go back to the index.");

        site_header("Details for: {$row['name']}");

		begin_frame($row['name']);

        // now we can post some content on the site
        echo '<a href="index.php"><strong>'.DETAILS_RETURN.'</strong></a><br><br>
        <table align="left" width="100%" border="0" cellspacing="0" cellpadding="3">
                 <tr>
                    <td><strong>'.DETAILS_NAME.'</strong></td>
                    <td>'.$row['name'].'</td>
                </tr>
                <tr>
                    <td><strong>'.DETAILS_HASH.'</strong></td>
                    <td>'.$info_hash.'</td>
                </tr>
				<tr>
					<td><strong>'.DETAILS_FILENAME.'</strong></td>
					<td>'.$row['filename'].'</td>
                </tr>
				<tr>
					<td><strong>Uploader:</strong></td>
					<td><a href=account-details.php?user='.$row['uploader'].'>'.$row['uploader'].'</a></td>
                <tr>
                    <td><strong>'.DETAILS_DOWNLOAD.'</strong></td>
                    <td><a href="download.php?action=torrent&amp;info_hash='.$info_hash.'">'.DETAILS_DOWNLOAD_NOW.'</a></td>
                </tr>';
        if (file_exists("torrents/".$info_hash.".nfo"))
        {
                echo '<tr>
                    <td><strong>'.DETAILS_NFO_DOWNLOAD.'</strong></td>
                    <td><a href="download.php?action=nfo&amp;info_hash='.$info_hash.'">'.DETAILS_NFO_DOWNLOAD_NOW.'</a></td>
                </tr>';
        }

        if (file_exists("torrents/".$info_hash.".jpg"))
        {
                echo
                '<tr>
                    <td><strong>'.DETAILS_IMG_DOWNLOAD.'</strong></td>
                    <td><a href="download.php?action=image&amp;info_hash='.$info_hash.'">'.DETAILS_IMG_DOWNLOAD_NOW.'</a></td>
                </tr>';
        }

        echo
                '<tr>
					<td><strong>'.DETAILS_STATUS.'</strong></td>
					<td><font color=green><b>'.$row['seeders'].'</b></font> '.DETAILS_SEEDERS.' , <font color="blue"><b>'.$row['leechers'].'</b></font> '.DETAILS_LEECHERS.' , '.DETAILS_COMPLETED.' <b>'.$row['completed'].'</b> '.DETAILS_TIMES.'</td>
                </tr>
                <tr>
					<td><strong>'.DETAILS_HITS.'</strong></td>
					<td>'.$row['hits'].'</td>
                </tr>
                <tr>
					<td><strong>'.DETAILS_SIZE.'</strong></td>
					<td>'.mksize($row['size']).'</td>
                </tr>
                <tr>
					<td><strong>'.DETAILS_NUMBEROFFILES.'</strong></td>
					<td>'.$row['numfiles'].'</td>
                </tr>';
				echo "<tr><td><strong>".FILE_LIST."</strong></td><td>";
				if ($_GET['flist']) {
				echo "<a href='torrents-details.php?info_hash=$info_hash'>[".HIDE."]</a></td><tr><td>&nbsp;</td><td>";
				begin_table("0", "left");
				$tmp = bdec_file("./torrents/$info_hash.torrent", $site_config['max_torrent_size']);
				echo "<tr><td class=alt3 align=left><font size=1 face=Verdana color=white>Filename</td><td class=alt3 align=left><font size=1 face=Verdana color=white>Size</td></tr>";
		if ($row['numfiles'] == 1)
			echo "<tr><td class=alt1>".$tmp['value']['info']['value']['name']['value']."</td><td class=alt2>".mksize($tmp['value']['info']['value']['length']['value'])."</td></tr>";
		else
			foreach ($tmp['value']['info']['value']['files']['value'] as $file) {
				echo "<tr><td class=alt1>".$file['value']['path']['value'][0]['value']."</td><td class=alt2>".mksize($file['value']['length']['value'])."</td></tr>";
		}
		end_table();
		}else echo "<a href='torrents-details.php?info_hash=$info_hash&flist=1'>[".SHOW."]</a>";
		echo "</td></tr>";
		unset($tmp);
                echo '<tr>
					<td><strong>'.DETAILS_DESCRIPTION.'</strong></td>
					<td>'.str_replace("_"," ",$row['descr']).'</td>
                </tr>
                <tr>
					<td><strong>'.DETAILS_CATEGORY.'</strong></td>
					<td>'.$row['category'].'</td>
                </tr>
                <tr>
                    <td><strong>'.DETAILS_SEEDS.'</strong></td>
                    <td>'.$seeders_display.'</td>
                </tr>
                <tr>
                    <td><strong>'.DETAILS_LEECHS.'</strong></td>
                    <td>'.$leechers_display.'</td>
                </tr>

        </table> ';

		end_frame();


site_footer();
?>