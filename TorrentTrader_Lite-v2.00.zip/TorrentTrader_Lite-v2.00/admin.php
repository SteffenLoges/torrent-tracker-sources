<?
require_once("backend/functions.php");
userlogin();
modonly();

function autolink($al_url, $al_msg)	// create autolink
{
	echo "\n<meta http-equiv=\"refresh\" content=\"3; URL=$al_url\">\n";
	echo "<b>$al_msg</b>\n";
	echo "<p>\n<b>Redirecting ...</b>\n";
	echo "<p>\n[ <a href='$al_url'>link</a> ]\n";
	echo "</td>\n</tr>\n</table>\n</td>\n</tr>\n</table>\n</body>\n</html>\n";
	site_footer();
	exit;
}

function adminmenu() {
$ttversion = 1.04;

begin_frame("Admin Menu");
print "<CENTER>[A] Admin Only - [S] Super Moderator Only<br><BR></CENTER>\n";

$file = @file_get_contents('http://www.torrentialstorm.net/version.txt');

if ($ttversion >= $file){
	echo "<center><b>You have the latest Version of TorrentTrader Installed: v$file</b></center><BR>";
}else{
	echo "<center><b><font color=red>NEW Version of TorrentTrader now available: v$file you have v$ttversion<BR> Please visit <a href=http://www.torrenttrader.org>TorrentTrader.org</a> to upgrade.</font></b></center><BR>";
}

?>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<TR>
	<td width=%20 align=center><a href='admin.php?act=settings'><img src="./images/admin/settings.png" border=0 width=32 height=32><br>Main Settings</a> [A]</td>
<!--	<td width=%20 align=center><a href='statistics.php'><img src="./images/admin/statistics.gif" border=0 width=32 height=32><br>Statistics</a></td>
	<td width=%20 align=center><a href='admin.php?act=trackerload'><img src="./images/admin/trackerload.png" border=0 width=32 height=32><br>Tracker Load</a></td>
	<td width=%20 align=center><a href='admin.php?act=donations''><img src="./images/admin/donations.gif" border=0 width=32 height=32><br>Donations</a> [A]</td>-->
	<td width=%20 align=center>&nbsp;</td>
	<td width=%20 align=center>&nbsp;</td>
	<td width=%20 align=center>&nbsp;</td>
</tr>
<tr><td colspan=5>&nbsp;</td></tr>
<TR>
	<!--<td width=%20 align=center><a href='admin.php?act=news'><img src="./images/admin/news.png" border=0 width=32 height=32><br>Site News</a></td>
	<td width=%20 align=center><a href='admin.php?act=sitetexts''><img src="./images/admin/disclaimer.gif" border=0 width=32 height=32><br>Disclaimer</a></td>-->
	<td width=%20 align=center>&nbsp;</td>
	<td width=%20 align=center>&nbsp;</td>
	<td width=%20 align=center>&nbsp;</td>
	<td width=%20 align=center>&nbsp;</td>
</tr>
<tr><td colspan=5>&nbsp;</td></tr>
<TR>
<!--	<td width=%20 align=center><a href='admin.php?act=lang'><img src="./images/admin/langs.png" border=0 width=32 height=32><br>Languages</a> [A]</td>
	<td width=%20 align=center><a href='admin.php?act=style'><img src="./images/admin/themes.gif" border=0 width=32 height=32><br>Themes</a> [A]</td>-->
	<td width=%20 align=center><a href='admin.php?act=view_log'><img src="./images/admin/log.gif" border=0 width=32 height=32><br>Site Log</a></td>
	<td width=%20 align=center><a href='admin.php?act=ircannounce''><img src="./images/admin/ircann.png" border=0 width=32 height=32><br>IRC Announcer</a></td>
	<td width=%20 align=center>&nbsp;</td>
	<td width=%20 align=center>&nbsp;</td>
</tr>
<!--<tr><td colspan=5>&nbsp;</td></tr>
<TR>
	<td width=%20 align=center><a href='staffmess.php'><img src="./images/admin/massmessage.gif" border=0 width=32 height=32><br>Mass Message</a> [A]</td>
	<td width=%20 align=center><a href='admin.php?act=banner'><img src="./images/admin/banners.gif" border=0 width=32 height=32><br>Banners / Sponsor</a> [A]</td>
	<td width=%20 align=center><a href='admin.php?act=userdonations'><img src="./images/admin/donors.gif" border=0 width=32 height=32><br>Donors</a> [A]</td>
	<td width=%20 align=center><a href='admin.php?act=forum'><img src="./images/admin/forums.gif" border=0 width=32 height=32><br>Forum Management</a> [A]</td>
	<td width=%20 align=center><a href='admin.php?act=peerg''><img src="./images/admin/peerg.gif" border=0 width=32 height=32><br>PeerGuardian IP Import</a><BR>[DISABLED]</td>
</tr>
<tr><td colspan=5>&nbsp;</td></tr>
<TR>
	<td width=%20 align=center><a href='admin-search.php'><img src="./images/admin/userssearch.gif" border=0 width=32 height=32><br>User Search</a></td>
	<td width=%20 align=center><a href='admin.php?act=users'><img src="./images/admin/users.gif" border=0 width=32 height=32><br>Users</a></td>
	<td width=%20 align=center><a href='admin.php?act=rws-watched'><img src="./images/admin/watchedusers.gif" border=0 width=32 height=32><br>Ratio Warn System<BR>Watched Users</a></td>
	<td width=%20 align=center><a href='admin.php?act=rws-warned'><img src="./images/admin/warnedusers.gif" border=0 width=32 height=32><br>Ratio Warn System<BR>Warned Users</a></td>
	<td width=%20 align=center><a href='ipsearch.php''><img src="./images/admin/duplicate.gif" border=0 width=32 height=32><br>Duplicate IPs</a></td>
</tr>
<tr><td colspan=5>&nbsp;</td></tr>
<TR>
	<td width=%20 align=center><a href='iptest.php'><img src="./images/admin/ipchecker.gif" border=0 width=32 height=32><br>IP Checker</a></td>
	<td width=%20 align=center><a href='findnotconnectable.php'><img src="./images/admin/unconnectable.gif" border=0 width=32 height=32><br>Unconnectable Users</a> [A]</td>
	<td width=%20 align=center><a href='admin.php?act=warneddaccounts'><img src="./images/admin/warnedaccounts.gif" border=0 width=32 height=32><br>Warned Accounts</a></td>
	<td width=%20 align=center><a href='admin.php?act=disabledaccounts'><img src="./images/admin/disabledaccounts.gif" border=0 width=32 height=32><br>Disabled Accounts</a></td>
	<td width=%20 align=center><a href='admin.php?act=bans''><img src="./images/admin/blocked.gif" border=0 width=32 height=32><br>Blocked / Banned IPs</a></td>
</tr>
<tr><td colspan=5>&nbsp;</td></tr>
<TR>
	<td width=%20 align=center><a href='admin.php?act=confirmreg'><img src="./images/admin/confirmaccounts.gif" border=0 width=32 height=32><br>Confirm Accounts</a></td>
	<td width=%20 align=center><a href='admin-confirmall.php'><img src="./images/admin/autoconfirm.gif" border=0 width=32 height=32><br>Auto Confirm<br>Accounts</a> [A]</td>
	<td width=%20 align=center><a href='uploadapp.php'><img src="./images/admin/uploadervote.gif" border=0 width=32 height=32><br>Uploader Applications</a></td>
	<td width=%20 align=center><a href='uploaders.php'><img src="./images/admin/uploaders.gif" border=0 width=32 height=32><br>Uploaders Management</a></td>
	<td width=%20 align=center><a href='admin-delreq.php'''><img src="./images/admin/requests.gif" border=0 width=32 height=32><br>Requests</a></td>
</tr>
<tr><td colspan=5>&nbsp;</td></tr>
<TR>
	<td width=%20 align=center><a href='admin-category.php'><img src="./images/admin/categories.gif" border=0 width=32 height=32><br>Categories</a> [S]</td>
	<td width=%20 align=center><a href='admin.php?act=torrents'><img src="./images/admin/torrents.gif" border=0 width=32 height=32><br>Torrent Management</td>
	<td width=%20 align=center><a href='admin.php?act=bannedtorrents'><img src="./images/admin/bannedtorrents.gif" border=0 width=32 height=32><br>Banned Torrents</a></td>
	<td width=%20 align=center><a href='trackers.php'><img src="./images/admin/external.gif" border=0 width=32 height=32><br>External Trackers</a></td>
	<td width=%20 align=center><a href='admin.php?act=msgspy'><img src="./images/admin/messagespy.gif" border=0 width=32 height=32><br>Message Spy</a> [A]</td>
</tr>-->
</table>

	<?
	end_frame();
	echo "<BR>";
}

$act = isset($_GET['act']) ? $_GET['act'] : $_POST['act'];

site_header("Staff CP");

adminmenu();

// Main Settings
if ($act == "settings") {
	adminonly();
			begin_frame("Site Settings", center);
		// page submitted, update
		if ($_POST['do'] == 'save')
		{
		if ($$_POST['MEMBERSONLY'] == "1")
			$MEMBERSONLY = "true";
		else
			$MEMBERSONLY = "false";

		if ($_POST['MEMBERSONLY_WAIT'] == "1")
			$MEMBERSONLY_WAIT = "true";
		else
			$MEMBERSONLY_WAIT = "false";
			
		if ($_POST['RATIO_WARNINGON'] == "1")
			$RATIO_WARNINGON = "true";
		else
			$RATIO_WARNINGON = "false";

		if ($_POST['LOGGEDINONLY'] == "1")
			$LOGGEDINONLY = "true";
		else
			$LOGGEDINONLY = "false";

		if ($_POST['NEWSON'] == "1")
			$NEWSON = "true";
		else
			$NEWSON = "false";

		if ($_POST['UPLOADERSONLY'] == "1")
			$UPLOADERSONLY = "true";
		else
			$UPLOADERSONLY = "false";

		if ($_POST['DONATEON'] == "1")
			$DONATEON = "true";
		else
			$DONATEON = "false";

		if ($_POST['DISCLAIMERON'] == "1")
			$DISCLAIMERON = "true";
		else
			$DISCLAIMERON = "false";

		if ($_POST['IRCANNOUNCE'] == "1")
			$IRCANNOUNCE = "true";
		else
			$IRCANNOUNCE = "false";

			$config_settings_data = <<<EOD
<?
\$site_config = array();
// Default Language / Theme Settings
\$site_config['language'] = "$_POST[LANGUAGE]";
\$site_config['theme'] = "$_POST[THEME]";

// Site Settings
\$site_config['SITENAME'] = "$SITENAME";
\$site_config['SITEEMAIL'] = "$SITEEMAIL";
\$site_config['SITEURL'] = "$SITEURL";
\$site_config['SITE_ONLINE'] = $SITE_ONLINE;
\$site_config['OFFLINEMSG'] = "$OFFLINEMSG";
\$site_config['UPLOADERSONLY'] = $UPLOADERSONLY;
\$site_config['LOGGEDINONLY'] = $LOGGEDINONLY;
\$site_config['MAXDISPLAYLENGTH'] = $MAXDISPLAYLENGTH;
\$site_config['TORRENTSPERPAGE'] = $TORRENTSPERPAGE;

// File paths
\$site_config['userdir'] = "$_POST[USERDIR]";

//Setup Site Blocks
\$site_config['NEWSON'] = $NEWSON;
\$site_config['DONATEON'] = $DONATEON;
\$site_config['DISCLAIMERON'] = $DISCLAIMERON;

//Setup IRC Announcer
\$site_config['IRCANNOUNCE'] = $IRCANNOUNCE;
\$site_config['ANNOUNCEIP'] = "$ANNOUNCEIP";
\$site_config['ANNOUNCEPORT'] = "$ANNOUNCEPORT";

//WAIT TIME VARS
\$site_config['GIGSA'] = "$GIGSA";
\$site_config['RATIOA'] = "$RATIOA";
\$site_config['WAITA'] = "$WAITA";
\$site_config['GIGSB'] = "$GIGSB";
\$site_config['RATIOB'] = "$RATIOB";
\$site_config['WAITB'] = "$WAITB";
\$site_config['GIGSC'] = "$GIGSC";
\$site_config['RATIOC'] = "$RATIOC";
\$site_config['WAITC'] = "$WAITC";
\$site_config['GIGSD'] = "$GIGSD";
\$site_config['RATIOD'] = "$RATIOD";
\$site_config['WAITD'] = "$WAITD";

// Tracker Settings
\$site_config['torrent_dir'] = "$torrent_dir";
\$site_config['announce_urls'] = array();
\$site_config['announce_urls'][] = "$announce_urls";
\$site_config['MEMBERSONLY'] = $MEMBERSONLY;
\$site_config['MEMBERSONLY_WAIT'] = $MEMBERSONLY_WAIT;

// Advanced Settings for announce
\$site_config['max_torrent_size'] = "$max_torrent_size";
\$site_config['max_nfo_size'] = "$max_nfo_size";
\$site_config['max_image_size'] = "$max_image_size";
\$site_config['announce_interval'] = "$announce_interval";
\$site_config['maxsiteusers'] = "$maxsiteusers";
?>
EOD;

			// create backup of config.php file first
			$old_config_file_read_handle = fopen("backend/config.php", "r");
			$old_config_file_write_handle = fopen("backend/oldconfig.php", "w");

			$old_config_file_contents = fread($old_config_file_read_handle, filesize("backend/config.php"));
			fwrite ($old_config_file_write_handle, $old_config_file_contents);

			fclose ($old_config_file_read_handle);
			fclose ($old_config_file_write_handle);

			// write onto current config file
			$new_config_file_handle = fopen("backend/config.php", "w");
			fwrite ($new_config_file_handle, $config_settings_data);
			fclose ($new_config_file_handle);
			//begin_frame("","center");
			print("<table border=0 cellspacing=0 cellpadding=5><td><center>");
			autolink("admin.php?act=settings", "Your Settings Were Updated");
			print("</center></td></tr></table>");
			//end_frame();

		}

		?>

		<form action='admin.php' method='post'>
		<input type='hidden' name='act' value='settings'>
		<input type='hidden' name='do' value='save'>
		<div align="center">
		<table width='100%' cellspacing='3' cellpadding='3'>
		<tr>
		<td colspan="2"><b><font face="Verdana" size="1">
		Tracker Configuration<br /></font><font size="1" face="Times New Roman">&#9492;
		</font></b><font size="1" face="Verdana">Here you can configure your
		trackers main settings</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Site Name:</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='SITENAME' value='<?=$site_config['SITENAME']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Tracker URL:</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='SITEURL' value='<?=$site_config['SITEURL']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Announce Url:</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='announce_urls' value='<?=$site_config['announce_urls'][0]?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Default Theme: (folder name)</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='THEME' value='<?=$site_config['theme']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Folder to store users in:</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='USERDIR' value='<?=$site_config['userdir']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Default Language: (filename)</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='LANGUAGE' value='<?=$site_config['language']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Maximum Users Accounts:</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='maxsiteusers' value='<?=$site_config['maxsiteusers']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Email: (Signup emails etc will be sent from this address)</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='SITEEMAIL' value='<?=$site_config['SITEEMAIL']?>' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Tracker Status:</font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<select name='SITE_ONLINE'>
		<option value='true'  <? if($site_config['SITE_ONLINE'])  echo "selected"; ?>>ONLINE
		<option value='false' <? if(!$site_config['SITE_ONLINE']) echo "selected"; ?>>OFFLINE
		</select></font></td>
		</tr>
		<tr>
		<td valign="top"><font face="Verdana" size="1">Site Offline Message:<br><i> (HTML Allowed)</i></font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<textarea name='OFFLINEMSG' cols="38" rows="8"><?=$site_config['OFFLINEMSG']?></textarea></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Require Members To Register:</font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='MEMBERSONLY' value='1' <? if($site_config['MEMBERSONLY'])  echo "checked"; checked ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='MEMBERSONLY' value='0'<? if(!$site_config['MEMBERSONLY']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Only Logged In Members Can View/Download Torrents:<br></font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='LOGGEDINONLY' value='1' <? if($site_config['LOGGEDINONLY'])  echo "checked"; checked ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='LOGGEDINONLY' value='0'<? if(!$site_config['LOGGEDINONLY']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Wait Times Enabled?<br><i>(See Below For Full Details)</i></font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='MEMBERSONLY_WAIT' value='1' <? if($site_config['MEMBERSONLY_WAIT'])echo "checked"; checked ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='MEMBERSONLY_WAIT' value='0'<? if(!$site_config['MEMBERSONLY_WAIT']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1" align="right">Wait Times<br></font></td>
		<td align='left'>
		<b>A) </b>RATIO: <<input type='text' name='RATIOA' value='<?=$site_config['RATIOA']?>' maxlength='4' size='4'>GIGS: <<input type='text' name='GIGSA' value='<?=$site_config['GIGSA']?>' maxlength='4' size='4'> WAIT: <input type='text' name='WAITA' value='<?=$site_config['WAITA']?>' maxlength='2' size='3'>Hrs
		<BR><BR>
		<b>B) </b>RATIO: <<input type='text' name='RATIOB' value='<?=$site_config['RATIOB']?>' maxlength='4' size='4'>GIGS: <<input type='text' name='GIGSB' value='<?=$site_config['GIGSB']?>' maxlength='4' size='4'> WAIT: <input type='text' name='WAITB' value='<?=$site_config['WAITB']?>' maxlength='2' size='3'>Hrs
		<BR><BR>
		<b>C) </b>RATIO: <<input type='text' name='RATIOC' value='<?=$site_config['RATIOC']?>' maxlength='4' size='4'>GIGS: <<input type='text' name='GIGSC' value='<?=$site_config['GIGSC']?>' maxlength='4' size='4'> WAIT: <input type='text' name='WAITC' value='<?=$site_config['WAITC']?>' maxlength='2' size='3'>Hrs
		<BR><BR>
		<b>D) </b>RATIO: <<input type='text' name='RATIOD' value='<?=$site_config['RATIOD']?>' maxlength='4' size='4'>GIGS: <<input type='text' name='GIGSD' value='<?=$site_config['GIGSD']?>' maxlength='4' size='4'> WAIT: <input type='text' name='WAITD' value='<?=$site_config['WAITD']?>' maxlength='2' size='3'>Hrs
		<BR><BR>
		</td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Restrict Uploads To Uploader Class?</font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='UPLOADERSONLY' value='1' <? if($site_config['UPLOADERSONLY'])  echo "checked"; checked ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='UPLOADERSONLY' value='0'<? if(!$site_config['UPLOADERSONLY']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td colspan="2">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2"><b><font face="Verdana" size="1">
		Blocks Management<br /></font><font size="1" face="Times New Roman">&#9492;
		</font></b><font size="1" face="Verdana">Here you can configure the blocks on the site</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Torrent Name Max Length Before Cut-Off: </font><br><i>(if name is longer it will be shortend with ... added)</i>&nbsp;&nbsp;<font color=red>REQUIRED</font> </td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='MAXDISPLAYLENGTH' value='<?=$site_config['MAXDISPLAYLENGTH']?>' maxlength='3' size='5'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Torrents per Page:</font><BR><font color=red>REQUIRED</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='TORRENTSPERPAGE' value='<?=$site_config['TORRENTSPERPAGE']?>' maxlength='3' size='5'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Site News Block Enabled?</font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='NEWSON' value='1' <? if($site_config['NEWSON'])  echo "checked"; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='NEWSON' value='0'<? if(!$site_config['NEWSON']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Donate Block Enabled?</font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='DONATEON' value='1' <? if($site_config['DONATEDON'])  echo "checked"; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='DONATEON' value='0'<? if(!$site_config['DONATEON']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Disclaimer Block Enabled?</font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='DISCLAIMERON' value='1' <? if($site_config['DISCLAIMERON'])  echo "checked"; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='DISCLAIMERON' value='0'<? if(!$site_config['DISCLAIMERON']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td colspan="2">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2"><b><font face="Verdana" size="1">
		IRC Announcer Settings<br /></font><font size="1" face="Times New Roman">&#9492;
		</font></b><font face="Verdana" size="1">This is where you can adjust the settings for the IRC announcer.  This announces all torrents uploaded and new forum topics.  Click <a href=admin.php?act=ircannounce>HERE</a> instructions on how to setup.</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">IRC Torrent/Forum Announcer Enabled?</font></td>
		<td align='left'>
		<font face="Verdana"><b>
		<font size="1">YES</font></b><font size="1">
		<input style='border:0;background:#eeeeee' type='radio' name='IRCANNOUNCE' value='1' <? if($site_config['IRCANNOUNCE'])  echo "checked";?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <b>NO</b>
		<input style='border:0;background:#eeeeee' type='radio' name='IRCANNOUNCE' value='0'<? if(!$site_config['IRCANNOUNCE']) echo "checked"; ?>>
		</font></font> <font size="1" face="Verdana">&nbsp;
		</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">IP Address Of Target PC To Announce On: </font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='ANNOUNCEIP' value='<?=$site_config['ANNOUNCEIP']?>' maxlength='400' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">PORT Of Targer PC To Announce On: </font></td>
		<td align='left'>
		<font size="1" face="Verdana">
		<input type='text' name='ANNOUNCEPORT' value='<?=$site_config['ANNOUNCEPORT']?>' maxlength='5' size='50'></font></td>
		</tr>
		<tr>
		<td colspan="2">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2"><b><font face="Verdana" size="1">
		Advanced Settings<br /></font><font size="1" face="Times New Roman">&#9492;
		</font></b><font face="Verdana" size="1">These settings are for advanced
		users only. If you do not understand what they do, do
		<font color="#CC0000">NOT </font>modify them.</font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Maximum Torrent Size
		(in bytes)</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='max_torrent_size' value='<?=$site_config['max_torrent_size']?>' maxlength='50' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Maximum NFO Size (in
		bytes)</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='max_nfo_size' value='<?=$site_config['max_nfo_size']?>' maxlength='50' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Maximum Image (in
		bytes)</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='max_image_size' value='<?=$site_config['max_image_size']?>' maxlength='50' size='50'></font></td>
		</tr>
		<tr>
		<td><font face="Verdana" size="1">Torrent Announce
		Interval (in seconds)</font></td>
		<td align='left'><font size="1" face="Verdana">
		<input type='text' name='announce_interval' value='<?=$site_config['announce_interval']?>' maxlength='50' size='50'></font></td>
		</tr>
		<tr>
		<td colspan="2">&nbsp;</td>
		</tr>
		<tr>
		<td align='left'></td><td align='left'>
			<font size="1" face="Verdana">
			<input type='submit' value='Update Settings'>&nbsp;
			<input type='reset' value='Reset'></font></td>
		</tr>

		<? // print errors if appeared
		if($error_fp != "")
		{
		echo "<tr>\n";
		echo "<td colspan='2' align='center' style='border:3px red solid; background:#eeeeee'><b>COULD NOT SAVE SETTINGS:</b><br />$error_fp</td>\n";
		echo "</tr>\n";
		}
		?>

		</table></div>


		<?
		end_frame();
		print("</form>");

}

if ($act == "view_log") {
	begin_frame("Site Log", "justify");
	$log = file_get_contents("log.php");
	$log = explode("\r\n", $log);
	array_shift($log);
	if (empty($log[0]))
		echo "Nothing to show.";
	else{
		begin_table();
		print("<tr><td class=alt3 align=left><font size=1 face=Verdana color=white>Date</td><td class=alt3 align=left><font size=1 face=Verdana color=white>Time</td><td class=alt3 align=left><font size=1 face=Verdana color=white>Event</td></tr>\n");
		foreach ($log as $line) {
				$line = trim($line);
				$date = substr($line, 1, strpos($line, " "));
				$time = substr($line, strpos($line, " ")+1, strpos($line, "]")-strpos($line, " ")-1);
				$text = substr($line, strpos($line, "]")+1);
				echo("<tr><td class=alt1>$date</td><td class=alt2>$time</td><td class=alt1 align=left>$text</td></tr>\n");
			}
		end_table();
	}
	
	echo "<BR>";
	end_frame();
}

// IRC Announce
if ($act == "ircannounce") {
	adminonly();
	begin_frame("IRC Announce Config", left);
		
	if ($site_config['IRCANNOUNCE']){
		echo "IRC Announce is <b>enabled</b>.<br>";
		echo "IRC Announce IP: $site_config[ANNOUNCEIP]<br>";
		echo "IRC Announce Port: $site_config[ANNOUNCEPORT]";
	}else
		echo "IRC Announce is <b>disabled</b>. <a href=admin.php?act=settings>Click here</a> to to turn on IRC Announce.";

		echo "These settings can be changed via <a href=admin.php?act=settings>Site Settings</a> in the <a href=admin.php?act=settings>Admin CP</a>.";
		end_frame();
		
		begin_frame("mIRC Client Script", left);
		echo "The following code is required on the computer the announce messages will be sent from. Save as \"tbs_ia.mrc\".<br>";
		begin_block("Contents of TBS_IA.mrc");				
		echo nl2br(file_get_contents("backend/tbs_ia.mrc"));
		end_block();
			
		echo "<br<br>";
		echo "Or you can <a href=$site_config[SITEURL]/backend/tbs_ia.mrc>click here</a> to <a href=$SITEURL/backend/tbs_ia.mrc>download</a> the file without copy/pasting it.<br>";
		echo "<br><br><br>";
		echo "<b><u>Instructions for installation</u></b>: <br>
			1. Start-up and run mIRC.<br>
			2. Load the script in mIRC.<br>
				&nbsp;&nbsp;� Tools -> Script Editor and select Remote<br>
				&nbsp;&nbsp;� File -> Load and select tbs_ia.mrc It will give a warning. Answer yes and it will ask you chan and port.<br>
				&nbsp;&nbsp;� File -> Save & Exit and connect to server and join the channel.<br>
			3. Restart mIRC (VERY IMPORTANT!)";
		echo "<br><br>";
		echo "Now, check your server screen on IRC once its loaded. If you see \"port xxxx is not free! Listener not started!\" then you have to try another port
				or check your firewall settings, etc.<br>";
		echo "Remember, the port must be OPEN on your local machine.<br>";
		end_frame();
}

site_footer();
?>