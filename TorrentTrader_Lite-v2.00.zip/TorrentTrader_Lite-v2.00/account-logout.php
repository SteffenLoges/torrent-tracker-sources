<?
// Logout of site, clear cookie and return to index
require_once("backend/functions.php");
logoutcookie();
Header("Location: $siteurl/index.php");

?>
