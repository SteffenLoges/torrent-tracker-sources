<?php
/**
 * TorrentTrader v1.0.4 LITE 
 *  - Coded by TorrentialStorm
 *  - Released under the GPL licence
 *  - Support/Hacks/Discussion @ http://www.torrenttrader.org
 **/



  require_once("backend/functions.php");

  $Feed = '<?xml version="1.0" encoding="ISO-8859-1"?>
  <rss version="2.0">
    <channel>
        <title>'.$sitetitle.' RSS Feed</title>
    <link>'.$siteurl.'</link>
    <description>'.RSS_POWERED_BY.'2.00</description>
    <language>en-us</language>';

  $source = fopen('data/torrents.dat','r');
  flock($source, LOCK_EX) ;
  $cnt = 0;
  while ($info = fscanf ($source, "%s %s %s %d %d %s %s %d %d %d %d %s %d %d\n")) {
  list ($info_hash, $filename, $name,$size,$numfiles,$descr,$category,$seeders,$leechers,$completed,$hits,$uploader,$views,$added) = $info;
  $cnt ++;
  if ($cnt > 20) break;
  $Feed .= '
  <item>
    <title>'.htmlentities($name).'</title>
    <category>'.$category.'</category>
    <description>[ Seeders: '.$seeders.' - Leechers: '.$leechers.' - Times completed: '.$completed.' - Uploader: '.$uploader.' - Added: '.date('H:i:s d/m/y',$added).' ] '.htmlentities(str_replace("\\n", " ", $descr)).'</description>
    <guid>'.$site_config['SITEURL'].'/torrents-details.php?info_hash='.$info_hash.'&amp;hit=1</guid>
    <enclosure url="'.$site_config['SITEURL'].'/download.php?info_hash='.$info_hash.'&amp;action=torrent" length="'.$size.'" type="application/x-bittorrent" />
  </item>';
  }

  flock($source, LOCK_UN);
  fclose($source);


  $Feed .= '</channel>
  </rss>';

  header("Content-type: text/xml");
  echo $Feed;
  die();
  ?>