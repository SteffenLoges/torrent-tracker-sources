/**
 * TorrentTrader v2.00 LITE
 *  - Coded by TorrentialStorm
 *  - Released under the GPL licence
 *  - Support/Hacks/Discussion @ http://www.torrenttrader.org
 **/



What is Torrent Trader Lite ?
---------------------------------------------

Torrent Trader Lite is an open source php bittorrent tracker that works without MySql.
With a very intuitive interface, it will help you to distribute your files, without requiring you hours of work !

What are its main features ?
# PHP only: no mysql database required
# Has search, browse per category, RSS2, upload, torrent banning,news posting ... options
# Very easy to customize
# Details about the torrents are displayed: info_hash,description,seeders,leechers ...
# It is open source, so everyone can contribute
# You can block torrents that you do not want to be tracked with a file lock
# ...

How to install it:
---------------------------------------------

1) Extract all files from the archive to anywhere on your hard drive
2) Upload all these files on your web server with your ftp client
3) CHMOD "data", "torrents", "users", "log.php", "backend/config.php" and "backend/oldconfig.php" to 777
4) Change the settings in backend/config.php

How to update from a previous version ?
---------------------------------------------

1) Extract all files from the archive to anywhere on your hard drive
2) Replace all php files with the new ones.

How to block a torrent from being shared with Torrent Trader Lite ?
---------------------------------------------

Just note the info_hash of the torrent you would like to ban, and in the "data" folder, create a file called:
(info_hash).dat.lock where you replace "(info_hash)" with the value you want
To remove the ban, just remove the corresponding .lock file.

How to add a news to my site ?
--------------------------------------------
Edit the news.php file, trying to follow the provided example, in order to add news.

Where to contact ?
---------------------------------------------

Website: http://www.torrenttrader.org
Irc: irc.p2p-network.net , channel: #torrenttrader

Changelog
---------------------------------------------
v2.00:
- Account System Added
- Changed theme
- fixed a few bugs in announce.php
- the rest are in news.php

v1.0.3:
- fixed a bug with file size
- fixed a bug with completed times
- fixed several bugs in announce.php
- fixed a bug with single scrape in scrape.php
- limited display of torrent's name to 35 characters on index.php
- added category images
- added ability to upload NFO files with torrents
- added ability to upload screenshots with torrents
- added multiple pages browsing
- included support for multiples languages
- fixed various bugs
- html code is now HTML 4.01 W3C validated
- css code is now W3C validated


v1.0.2:
- fixed a bug with magic_quote_gpc
- fixed a cleanup bug
- added theme variable in config.php and ability to change themes on the site
- improved rss2 script
- improved script performance
- added sha1 function for php versions prior to 4.3
- put categories in config.php
- you can add news to your site quite easily by editing news.php

v1.0.1:
- fixed a bug with cleanup
- added display of "Tracking X torrents with Y peers (A seeders and B leechers)"
- fixed major bug in upload.php

