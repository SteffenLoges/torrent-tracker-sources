<?php
/**
 * $Id: admin.php v 1.21 02 july 2004 Catwolf Exp $
 * Module: WF-Downloads
 * Version: v2.0.5a
 * Release Date: 26 july 2004
 * Author: WF-Sections
 * Licence: GNU
 */
 
// Blocks
define("_MB_XTORRENT_DISP","Display");
define("_MB_XTORRENT_FILES","Files");
define("_MB_XTORRENT_CHARS","Length of the title");
define("_MB_XTORRENT_LENGTH"," characters");
?>