<?php
/**
 * $Id: header.php v 1.0.2 02 july 2004 Liquid Exp $
 * Module: WF-Downloads
 * Version: v2.0.5a
 * Release Date: 26 july 2004
 * Author: WF-Sections
 * Licence: GNU
 */
 
include_once '../../mainfile.php';
include XOOPS_ROOT_PATH.'/modules/xtorrent/include/functions.php';

$myts = & MyTextSanitizer :: getInstance(); // MyTextSanitizer object
?>