<?

// +--------------------------------------------------------------------------+
// | Project:   Solstice NVTracker (W3C) - NetVision BitTorrent Tracker       |
// +--------------------------------------------------------------------------+
// | This file is part of NVTracker. NVTracker is based on BTSource,          |
// | originally by RedBeard of TorrentBits, extensively modified by Solstice. |
// |                                                                          |
// | Updates by Solstice:                                                     |
// | - Tidy                                                                   |
// | - W3C Html 4.01 Transitional                                             |
// | - W3C CSS Level 3                                                        |
// |                                                                          |
// | This file has been originally validated by http://validator.w3.org       |
// |                                                                          |
// | NVTracker is free software; you can redistribute it and/or modify        |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | NVTracker is distributed in the hope that it will be useful,             |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen d�rfen nicht entfernt werden!    Do not remove above lines! |
// +--------------------------------------------------------------------------+

require_once("include/bittorrent.php");
dbconn();

session_start();



if ($_POST['take'] == 'yes')
{
hit_start();

$res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
$arr = mysql_fetch_row($res);
if ($arr[0] >= $GLOBALS["MAX_USERS"])
	stderr("Fehler", "Sorry, das Benutzerlimit wurde erreicht. Bitte versuche es sp�ter erneut.");

if (!mkglobal("wantusername:wantpassword:passagain:email"))
	die();

function bark($msg) {
  stdhead();
	stdmsg("Registrierung fehlgeschlagen!", $msg);
  stdfoot();
  exit;
}

function validusername($username)
{
	if ($username == "")
	  return false;

	// The following characters are allowed in user names
	$allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	for ($i = 0; $i < strlen($username); ++$i)
	  if (strpos($allowedchars, $username[$i]) === false)
	    return false;

	return true;
}

function isportopen($port)
{
	global $HTTP_SERVER_VARS;
	$sd = @fsockopen($HTTP_SERVER_VARS["REMOTE_ADDR"], $port, $errno, $errstr, 1);
	if ($sd)
	{
		fclose($sd);
		return true;
	}
	else
		return false;
}

function isproxy()
{
	$ports = array(80, 88, 1075, 1080, 1180, 1182, 2282, 3128, 3332, 5490, 6588, 7033, 7441, 8000, 8080, 8085, 8090, 8095, 8100, 8105, 8110, 8888, 22788);
	for ($i = 0; $i < count($ports); ++$i)
		if (isportopen($ports[$i])) return true;
	return false;
}

session_start();

if ($GLOBALS['proofcodeon'])
if ($_SESSION["proofcode"] == "" || $_POST["proofcode"] == "" || strtolower($_POST["proofcode"]) != strtolower($_SESSION["proofcode"]))
        bark("Der Anmeldungscode ist ung�ltig.");

if (empty($wantusername) || empty($wantpassword) || empty($email))
	bark("Du musst alle Felder ausf�llen.");

if (strlen($wantusername) > 12)
	bark("Sorry, Dein Benutzername ist zu lang (Maximum sind 12 Zeichen)");

if ($wantpassword != $passagain)
	bark("Die Passw�rter stimmen nicht �berein! Du musst Dich vertippt haben. bitte versuche es erneut!");

if (strlen($wantpassword) < 6)
	bark("Sorry, Dein Passwort ist zu kurz (Mindestens 6 Zeichen)");

if (strlen($wantpassword) > 40)
	bark("Sorry, Dein Passwort ist zu lang (Maximal 40 Zeichen)");

if ($wantpassword == $wantusername)
	bark("Sorry, Dein Passwort darf nicht mit Deinem Benutzernamen identisch sein.");

if (!validemail($email))
	bark("Die E-Mail Adresse sieht nicht so aus, als ob sie g�ltig w�re.");

if (!validusername($wantusername))
	bark("Ung�ltiger Benutzername.");

// make sure user agrees to everything...
if ($_POST["rulesverify"] != "yes" || $_POST["faqverify"] != "yes" || $_POST["ageverify"] != "yes")
	stderr("Anmeldung fehlgeschlagen", "Sorry, aber Du bist nicht daf�r qualifiziert, ein Mitglied dieser Seite zu werden.");

// check if email addy is already in use
$a = (@mysql_fetch_row(@mysql_query("select count(*) from users where email='$email'"))) or die(mysql_error());
if ($a[0] != 0)
  bark("Die E-Mail Adresse $email wird schon verwendet.");

// Trash-/Freemail Anbieter sind nicht gew�nscht.
if ($GLOBALS['emailvalidation'] != "false")
foreach ($GLOBALS["EMAIL_BADWORDS"] as $badword) {
    if (preg_match("/".preg_quote($badword)."/i", $email))
	stderr("Anmeldung fehlgeschlagen", "Diese E-Mail Adresse kann nicht f�r eine Anmeldung an diesem Tracker verwendet werden. Wir akzeptieren keine Wegwerf-Mailadressen!");
}

hit_count();

$secret = mksecret();
$wantpasshash = md5($secret . $wantpassword . $secret);
$editsecret = mksecret();
$passkey = mksecret(8);

$arr = mysql_fetch_assoc(mysql_query("SELECT `id` FROM `stylesheets` WHERE `default`='yes'"));
$stylesheet = $arr["id"];

if ($GLOBALS['emailvalidation'] != "false")
$status = 'pending';
else
$status = 'confirmed';

$ret = mysql_query("INSERT INTO users (username, passhash, passkey, secret, editsecret, email, status, stylesheet, added) VALUES (" .
		implode(",", array_map("sqlesc", array($wantusername, $wantpasshash, $passkey, $secret, $editsecret, $email, $status, $stylesheet))) .
		",'" . get_date_time() . "')");

if (!$ret) {
	if (mysql_errno() == 1062)
		bark("Der Benutzername existiert bereits!");
	bark("borked");
}

$id = mysql_insert_id();

//write_log("User account $id ($wantusername) was created");

$psecret = md5($editsecret);

$body = 'Du oder jemand anderes hat auf {'.$GLOBALS["SITENAME"].'} einen neuen Account erstellt und
diese E-Mail Adresse ('.$email.') daf�r verwendet.

Wenn Du den Account nicht erstellt hast, ignoriere diese Mail. In diesem
Falle wirst Du von uns keine weiteren Nachrichten mehr erhalten. Die
Person, die Deine E-Mail Adresse benutzt hat, hatte die IP-Adresse
{'.$_SERVER["REMOTE_ADDR"].'}. Bitte antworte nicht auf diese automatisch
erstellte Nachricht

Um die Anmeldung zu best�tigen, folge bitte dem folgenden Link:

'.$DEFAULTBASEURL.'/confirm.php?id='.$id.'&secret='.$psecret.'

Wenn du dies getan hast, wirst Du in der Lage sein, Deinen neuen Account zu
verwenden. Wenn die Aktivierung fehlschl�gt, oder Du diese nicht vornimmst,
wird Dein Account innerhalb der n�chsten Tage wieder gel�scht.
Wir empfehlen Dir dringlichst, die Regeln und die FAQ zu lesen, bevor Du
unseren Tracker verwendest.';


if ($GLOBALS['emailvalidation'] != "false")
{
sendmail($email, $GLOBALS["SITENAME"]." Anmeldebest�tigung", $body);
header("Refresh: 0; url=ok.php?type=signup&email=" . urlencode($email));
}
else
header("Refresh: 0; url=ok.php?type=confirm");

hit_end();

}





if ($_SESSION["proofcode"] != "" && $_POST["proofcode"] != "" && strtolower($_POST["proofcode"]) == strtolower($_SESSION["proofcode"]))
    $code_ok = TRUE;
else
    $code_ok = FALSE;

if ($code_ok || !$GLOBALS['proofcodeon']) {
    $res = mysql_query("SELECT COUNT(*) FROM users") or sqlerr(__FILE__, __LINE__);
    $arr = mysql_fetch_row($res);
    if ($arr[0] >= $GLOBALS["MAX_USERS"]) {
            $_SESSION["proofcode"] = "";
            stderr("Sorry", "Das aktuelle Benutzerlimit (" . number_format($GLOBALS["MAX_USERS"]) . ") wurde erreicht. Inactive Accounts werden regelm��ig gel�scht, versuche es also einfach sp�ter nochmal...");
    }
} else {
    /* Zufallsgenerator initialisieren */
    srand(microtime()*360000);
    
    /* Im Code benutzte Zeichen */
    $chars = "ABCDEFGHIJKLMNOPSTUWXYZ";
    
    /* Zeichenfolge generieren */
    $_SESSION["proofcode"] = "";
    for ($I=0; $I<6; $I++) $_SESSION["proofcode"] .= $chars[rand(0, strlen($chars)-1)];
}

stdhead("Anmeldung");

if ($success == 'yes')
stdsuccess("Account erfolgreich erstellt");

if ($code_ok || $GLOBALS['proofcodeon'] != 'yes') {
echo '<form method="post" action="'.$self.'">
<input type="hidden" name="proofcode" value="'.$_SESSION["proofcode"].'" >
<input type="hidden" name="take" value="yes">';

    begin_frame("Neuen Account erstellen", FALSE, "650px");
?>
<p>Hinweis: Du musst Cookies akzeptieren, um Dich Anmelden und Einloggen zu k&ouml;nnen!</p>
<table border="0" cellspacing="1" cellpadding="4" class="tableinborder" summary="none">
<tr><td align="right" class="tableb">Gew&uuml;nschter Benutzername:</td><td class="tablea" align=left><input type="text" size="20" name="wantusername" ></td></tr>
<tr><td align="right" class="tableb">W&auml;hle ein Passwort:</td><td class="tablea" align=left><input type="password" size="20" name="wantpassword" ></td></tr>
<tr><td align="right" class="tableb">Gebe Dein Passwort erneut ein:</td><td class="tablea" align=left><input type="password" size="20" name="passagain" ></td></tr>
<tr valign=top><td align="right" class="tableb">E-Mail Adresse:</td><td class="tablea" align=left><input type="text" size="30" name="email" >
<table width=350 border=0 cellspacing=0 cellpadding=0 summary="none"><tr><td><font class=small>Die angegebene E-Mail Adresse muss g&uuml;ltig sein.
Du wirst eine Best&auml;tigungsmail von uns erhalten, auf die Du antworten musst. Deine E-Mail Adresse wird nirdgendwo auf dem Tracker &ouml;ffentlich angezeigt.</font>
</td></tr></table>
</td></tr>
<tr><td align="right" class="tableb"></td><td class="tablea" align=left><input type=checkbox name=rulesverify value=yes> Ich habe die Regeln gelesen.<br>
<input type=checkbox name=faqverify value=yes> Ich werde die FAQ lesen, bevor ich Fragen an einen Moderator oder Admin stelle.<br>
<input type=checkbox name=ageverify value=yes> Ich bin mindestens 16 Jahre alt.</td></tr>
<tr><td align="center" class="tableb"></td><td align="center" class="tableb"><input type="submit" value="Ab damit!"></td></tr>
</table>
<?
end_frame();
echo "</form>";
} else {
    begin_frame("Neuen Account erstellen", FALSE, "650px");
?>
<p>Hinweis: Du musst Cookies akzeptieren, um Dich Anmelden und Einloggen zu k&ouml;nnen!</p>
<p>Um die Anmeldung durchf�hren zu k�nnen, musst Du zuerst einen Pr�fungscode eingeben.
Durch die Angabe dieses Pr�fcodes wird das Verwenden automatischer Registrierungstools
verhindert. Nach der Eingabe des Codes kannst Du mit der Anmeldung fortfahren, sofern
Accounts frei sind.</p>
<p>Gro�-/Kleinschreibung spielt keine Rolle. Wenn Du den Code nicht lesen kannst, lade die Seite erneut.</p>
<form method="post" action="signup.php">
<center>
<? begin_table(); ?>
<tr><td class="tablea"><img src="proofimg.php?<?=SID?>" width="300" height="80" alt="Der Browser muss Grafiken anzeigen k�nnen, um die Anmeldung durchzuf�hren!"></td></tr>
<tr><td class="tablea">Code eingeben: <input type="text" size="20" name="proofcode"></td></tr>
<tr><td class="tableb" style="text-align:center"><input type="submit" value="Code pr�fen"></td></tr>
<? end_table(); ?>
</center>
</form>
<?
end_frame();
}


stdfoot();

?>