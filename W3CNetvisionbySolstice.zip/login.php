<?

// +--------------------------------------------------------------------------+
// | Project:   Solstice NVTracker (W3C) - NetVision BitTorrent Tracker       |
// +--------------------------------------------------------------------------+
// | This file is part of NVTracker. NVTracker is based on BTSource,          |
// | originally by RedBeard of TorrentBits, extensively modified by Solstice. |
// |                                                                          |
// | Updates by Solstice:                                                     |
// | - Tidy                                                                   |
// | - W3C Html 4.01 Transitional                                             |
// | - W3C CSS Level 3                                                        |
// |                                                                          |
// | This file has been originally validated by http://validator.w3.org       |
// |                                                                          |
// | NVTracker is free software; you can redistribute it and/or modify        |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | NVTracker is distributed in the hope that it will be useful,             |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen d�rfen nicht entfernt werden!    Do not remove above lines! |
// +--------------------------------------------------------------------------+

require_once("include/bittorrent.php");

hit_start();

dbconn();

hit_count();


$self = explode ("?", $_SERVER["PHP_SELF"]);
$self = $self[0];
$self = preg_replace("/(.+?)\/(.+?)/is",  "\\2", $self); //Now it don't cares in which folder the file is.  
$self = preg_replace('/\//', '', $self);  //then $self is everytime the basefile even if the $action is set.

if ($_POST['take'] == 'yes')
{
if (!mkglobal("username:password"))
	die("Hier ist was faul...");

function bark($text = "Benutzername oder Passwort ung�ltig")
{
  stderr("Login fehlgeschlagen!", $text);
}

session_start();

$res = mysql_query("SELECT * FROM users WHERE username = " . sqlesc($username) . " AND status = 'confirmed'");
$row = mysql_fetch_assoc($res);

if (!$row)
	bark("Diesen User gibt es nicht");

if ($row["passhash"] != md5($row["secret"] . $password . $row["secret"]))
	bark("Passwort falsch");

if ($row["enabled"] == "no")
	bark("Dieser Account wurde deaktiviert.");

logincookie($row["id"], $row["passhash"]);

$ip = getip();

$_SESSION["userdata"] = $row;
$_SESSION["userdata"]["ip"] = $ip;

mysql_query("UPDATE users SET last_access='" . date("Y-m-d H:i:s") . "', ip='$ip' WHERE id=" . $row["id"]); // or die(mysql_error());

if (!empty($_POST["returnto"]))
	header("Location: ".$BASEURL.$_POST["returnto"]);
else
	header("Location: $BASEURL/".$GLOBALS['loginreturnto']."?".SID);

}

stdhead("Login");

unset($returnto);
if (!empty($_GET["returnto"])) {
	$returnto = $_GET["returnto"];
	if (!$_GET["nowarn"]) {

?>
<table summary="none" cellpadding="4" cellspacing="1" border="0" style="width:100%" class="tableinborder">
 <tr class="tabletitle" style="width:100%">
  <td colspan="10" style="width:100%"><center><span class="normalfont"><b> Nicht angemeldet! </b></span></center></td> 
 </tr><tr><td style="width:100%" class="tablea"><img src="<?=$GLOBALS["PIC_BASE_URL"]?>warned16.gif" alt='warning'> Die gew&uuml;nschte Seite ist nur angemeldeten Benutzern
 zug&auml;nglich.</td></tr></table><br>
<?
	}
}

?>
<form method="post" action="<?=$self?>">
<input type='hidden' name='take' value='yes'>
<table cellpadding="4" cellspacing="1" border="0" style="width:100%" class="tableinborder" summary="none">
 <tr class="tabletitle" style="width:100%">
  <td colspan="10" style="width:100%"><center><span class="normalfont"><b> Tracker Login </b></span></center></td> 
 </tr><tr><td style="width:100%" class="tablea"><center>
<p>Hinweis: Du musst Deinen Browser so eingestellt haben, dass er Cookies akzeptiert, damit Du
Dich einloggen kannst.</p>
<table border="0" cellspacing="1" cellpadding="4" class="tableinborder"  summary="none">
<tr><td class=tableb align=left>Benutzername:</td><td class=tablea align=left><input type="text" size=40 name="username"></td></tr>
<tr><td class=tableb align=left>Passwort:</td><td class=tablea align=left><input type="password" size=40 name="password"></td></tr>
<tr><td class=tablea colspan="2" align="center"><input type="submit" value="Log in!" class=btn></td></tr>
</table>
<?

if (isset($returnto))
	print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($returnto) . "\" />\n");

?>

Du hast noch keinen Account? <a href="signup.php">Registriere Dich</a> hier!
</center>
</td></tr></table>
</form>
<?

stdfoot();

hit_end();

?>
