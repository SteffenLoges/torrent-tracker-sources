<?

require_once("include/bittorrent.php");
dbconn(false);



$self = explode ("?", $_SERVER["PHP_SELF"]);
$self = $self[0];
$self = preg_replace("/(.+?)\/(.+?)/is",  "\\2", $self); //Now it don't cares in which folder the file is.  
$self = preg_replace('/\//', '', $self);  //then $self is everytime the basefile even if the $action is set.


if ($CURUSER) {
        $ss_a = @mysql_fetch_assoc(@mysql_query("SELECT `uri` FROM `stylesheets` WHERE `id`=" . $CURUSER["stylesheet"]));
        if ($ss_a) $GLOBALS["ss_uri"] = $ss_a["uri"];
    }

    if (!$GLOBALS["ss_uri"]) {
        ($r = mysql_query("SELECT `uri` FROM `stylesheets` WHERE `default`='yes'")) or die(mysql_error());
        ($a = mysql_fetch_assoc($r)) or die(mysql_error());
        $GLOBALS["ss_uri"] = $a["uri"];
        }
  	 
if (isset($_GET['del']))
{
if (is_numeric($_GET['del']))
{
$query = "SELECT * FROM shoutbox WHERE id=".$_GET['del'];
$result = mysql_query($query);
}
else {
echo "<center>keine g�ltige Mitteilungs-ID</center>";
exit;}

$row = mysql_fetch_row($result);

if ( (get_user_class() >= UC_MODERATOR) )
{
$query = "DELETE FROM shoutbox WHERE id=".$_GET['del'];
mysql_query($query);
}
}


if (isset($_GET['hid']))
{
if (is_numeric($_GET['hid']))
{
$query = "SELECT * FROM shoutbox WHERE id=".$_GET['hid'];
$result = mysql_query($query);
}
else {
echo "<center>keine g�ltige Mitteilungs-ID</center>";
exit;}
$nummer = $_GET['hid'];
$row = mysql_fetch_row($result);

$query = "UPDATE shoutbox SET visible = 'no' WHERE id = $nummer LIMIT 1";
if ( (get_user_class() >= UC_ADMINISTRATOR) )
{
 mysql_query($query);
}
}


if (isset($_GET['view']))
{
if (is_numeric($_GET['view']))
{
$query = "SELECT * FROM shoutbox WHERE id=".$_GET['view'];
$result = mysql_query($query);
}
else {
echo "<center>keine g�ltige Mitteilungs-ID</center>";
exit;}
$nummer = $_GET['view'];
$row = mysql_fetch_row($result);

$query = "UPDATE shoutbox SET visible = 'yes' WHERE id = $nummer LIMIT 1";
if ( (get_user_class() >= UC_ADMINISTRATOR) )
{
 mysql_query($query);
}
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<title>Sols Diskussionsrunde</title>
<META HTTP-EQUIV=REFRESH CONTENT="50; URL=<?=$self?>">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
.small {font-size: 9pt; font-weight: bold; font-family: tahoma; }
.date {font-size: 9pt;}
</style>
<link rel="stylesheet" href="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"] . "/" . $GLOBALS["ss_uri"]?>.css" type="text/css">
<STYLE TYPE="text/css">BODY {
SCROLLBAR-3DLIGHT-COLOR: #004E98;
SCROLLBAR-ARROW-COLOR: #004E98;
SCROLLBAR-DARKSHADOW-COLOR: white;
SCROLLBAR-BASE-COLOR: white;
}
</STYLE>
</head>
<body background="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/shoutbox_back.gif">
<script type="text/javascript" src="include/js/rainbowtext.js"></script>
<?

$text=trim($_GET["shbox_text"]);
if($_GET["sent"]=="yes" && $text !="")
{
$userid=$CURUSER["id"];
$username=$CURUSER["username"];
$date=time();
$text=trim($_GET["shbox_text"]);

$r = @mysql_query("SELECT * FROM users WHERE id=$CURUSER[id]");
$user = mysql_fetch_array($r);

if ($CURUSER["username"] == "System")
$text= "[b][color=Orange][font=Comic Sans MS][size=4]". sqlesc($text) ."[/size][/font][/color][/b]";

$text = str_replace(";", "X", $text);
$text = str_replace("\'", "X", $text);
$text = str_replace("\"", "X", $text);
sqlesc($text);

mysql_query("INSERT INTO shoutbox (id, userid, username, date, text, visible) VALUES ('id'," . sqlesc($userid) . ", " . sqlesc($username) . ", $date, " . sqlesc($text) . ", 'yes')") or sqlerr(__FILE__, __LINE__);

}
if ($_GET["history"] != "")
 $res = mysql_query("SELECT * FROM shoutbox ORDER BY date DESC LIMIT 100") or sqlerr(__FILE__, __LINE__);
else
 $res = mysql_query("SELECT * FROM shoutbox ORDER BY date DESC LIMIT 40") or sqlerr(__FILE__, __LINE__);

if (mysql_num_rows($res) == 0)
print("\n");
else
{
print("<table border=0 cellspacing=0 cellpadding=2 width='100%' align='left' class='small'>\n");

while ($arr = mysql_fetch_assoc($res))
{
$res2 = mysql_query("SELECT username,class,avatar,donor,title,enabled,warned FROM users WHERE id=$arr[userid]") or sqlerr(__FILE__, __LINE__);
$arr2 = mysql_fetch_assoc($res2);

if (get_user_class() >= UC_ADMINISTRATOR) {
  $hid="<a href='".$self."?hid=".$arr[id]."' title=\"Beitrag ausblenden\"><font color='yellow'>-</font></a>";
}
if (get_user_class() >= UC_ADMINISTRATOR) {
  $view="<a href='".$self."?view=".$arr[id]."' title=\"Beitrag wieder anzeigen\"><font color='green'>0</font></a>";
}
if ($arr[visible] == "yes")
  $button = $hid;
else
  $button = $view;

if (get_user_class() >= UC_MODERATOR) {
  $del="<a href='".$self."?del=".$arr[id]."' title=\"Beitrag l�schen\"><font color='red'>X</font></a>";
}

  $text = $arr["text"];
  if ($_GET["history"] != "")
    print("<tr><td class='date' style=\"width:100px\" valign=\"top\">(".strftime("%d.%m. %H:%M",$arr["date"]).")</td><td valign=\"top\">$del</td><td valign=\"top\">$button</td><td valign=\"top\"><a href='userdetails.php?id=".$arr["userid"]."' target='_top'><font class=" .get_class_color($arr2["class"]) . ">" . $arr["username"] . "</font></a></td><td valign=\"top\">".format_comment($text)."</td></tr>\n");
  else
    if ($arr[visible] == "yes")
      print("<tr><td class='date' style=\"width:100px\" valign=\"top\">(".strftime("%d.%m. %H:%M",$arr["date"]).")</td><td valign=\"top\">$del</td><td valign=\"top\">$button</td><td valign=\"top\"><a href='userdetails.php?id=".$arr["userid"]."' target='_top'><font class=" .get_class_color($arr2["class"]) . ">" . $arr["username"] . "</font></a></td><td valign=\"top\">".format_comment($text)."</td></tr>\n");
}
print("</table>");
}
?>
</body>
</html>