<?

// +--------------------------------------------------------------------------+
// | Project:   Solstice NVTracker (W3C) - NetVision BitTorrent Tracker       |
// +--------------------------------------------------------------------------+
// | This file is part of NVTracker. NVTracker is based on BTSource,          |
// | originally by RedBeard of TorrentBits, extensively modified by Solstice. |
// |                                                                          |
// | Updates by Solstice:                                                     |
// | - V2 Update                                                              |
// | - W3C Html 4.01 Transitional                                             |
// | - W3C CSS Level 3                                                        |
// |                                                                          |
// | This file has been originally validated by http://validator.w3.org       |
// |                                                                          |
// | NVTracker is free software; you can redistribute it and/or modify        |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | NVTracker is distributed in the hope that it will be useful,             |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen d�rfen nicht entfernt werden!    Do not remove above lines! |
// +--------------------------------------------------------------------------+


require_once ("include/bittorrent.php");
dbconn();

$startdat = get_config_data("aur_startdat");
$enddat = get_config_data("aur_enddat");
$maxclass = get_config_data("aur_maxclass");
$viewrights = get_config_data("aur_viewrights");
$editrights = get_config_data("aur_editrights");
$bdtypwebseed = get_config_data("aur_dbtyp");

loggedinorreturn();
if (get_user_class() < $viewrights)
  stderr("Fehler","Zugriff verweigert");

$self = explode ("?", $_SERVER["PHP_SELF"]);
$self = $self[0];
$self = preg_replace("/(.+?)\/(.+?)/is",  "\\2", $self); //Now it don't cares in which folder the file is.  
$self = preg_replace('/\//', '', $self);  //then $self is everytime the basefile even if the $action is set.


$start = explode(".",$startdat);
$end   = explode(".",$enddat);

// Start:
$dstart = (intval($start[0]) ? $start[0]:0);
$mstart = (intval($start[1]) ? $start[1]:0);
$ystart = (intval($start[2]) ? $start[2]:0);

// Ende:
$dend = (intval($end[0]) ? $end[0]:0);
$mend = (intval($end[1]) ? $end[1]:0);
$yend = (intval($end[2]) ? $end[2]:0);

stdhead();



if (get_user_class() >= $editrights)
{
if ($_GET['action'] != 'config')
{
            begin_table();
echo "<tr><td class='tablea'><a href='".$self."?action=config'>Zur Konfiguration</a></td></tr>";
            end_table();
}
else
{
begin_frame("Konfiguration", true);

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
set_config_data("aur_startdat",mysql_real_escape_string($_POST['startdat']));
set_config_data("aur_enddat",mysql_real_escape_string($_POST['enddat']));
set_config_data("aur_maxclass",mysql_real_escape_string($_POST['maxclass']));
set_config_data("aur_viewrights",mysql_real_escape_string($_POST['viewrights']));
set_config_data("aur_editrights",mysql_real_escape_string($_POST['editrights']));
set_config_data("aur_dbtyp",mysql_real_escape_string($_POST['dbtyp']));

            begin_table(true);
echo "<tr><td class='tablea' style='width:100%'><center><font color='red'><b>Aktualisierung erfolgreich</b></font></center></td></tr>";
            end_table();

// Aktualisieren der Werte f�r die jetzig erstellte Datei mit den neuen Werten.
$startdat = get_config_data("aur_startdat");
$enddat = get_config_data("aur_enddat");
$maxclass = get_config_data("aur_maxclass");
$viewrights = get_config_data("aur_viewrights");
$editrights = get_config_data("aur_editrights");
$bdtypwebseed = get_config_data("aur_dbtyp");

$start = explode(".",$startdat);
$end   = explode(".",$enddat);

// Start:
$dstart = (intval($start[0]) ? $start[0]:0);
$mstart = (intval($start[1]) ? $start[1]:0);
$ystart = (intval($start[2]) ? $start[2]:0);

// Ende:
$dend = (intval($end[0]) ? $end[0]:0);
$mend = (intval($end[1]) ? $end[1]:0);
$yend = (intval($end[2]) ? $end[2]:0);
}

echo "<form method='POST' action='".$self."?action=config'>";
begin_table();
echo "<tr><td class='tablea' style='width:20%'>Startdatum:</td><td class='tablea' style='width:80%'><input type='text' name='startdat' value='".$startdat."'> (Format: Tag.Monat.Jahr)</td></tr>";
echo "<tr><td class='tablea' style='width:20%'>Enddatum:</td><td class='tablea' style='width:80%'><input type='text' name='enddat' value='".$enddat."'> (Format: Tag.Monat.Jahr)</td></tr>";

echo "<tr><td class='tablea' style='width:20%'>Uploader:</td><td class='tablea' style='width:80%'><select name='maxclass'>";
        for ($i = 0; $i <= get_user_class(); ++$i)
        if (get_user_class_name($i) != "")
            echo "<option value=$i" . ($maxclass == $i ? " selected" : "") . ">" . get_user_class_name($i)."</option>";
echo "</select>(Bis welchen Rang darf an der Uploadrallye teilgenommen werden?)</td></tr>";




echo "<tr><td class='tablea' style='width:20%'>Einsehrechte:</td><td class='tablea' style='width:80%'><select name='viewrights'>";
        for ($i = 0; $i <= get_user_class(); ++$i)
        if (get_user_class_name($i) != "")
            echo "<option value=$i" . ($viewrights == $i ? " selected" : "") . ">" . get_user_class_name($i)."</option>";
echo "</select>(Ab welchem Rang darf der Inhalt dieser Datei eingesehen werden?)</td></tr>";


echo "<tr><td class='tablea' style='width:20%'>Konfigurationsrechte:</td><td class='tablea' style='width:80%'><select name='editrights'>";
        for ($i = 0; $i <= get_user_class(); ++$i)
        if (get_user_class_name($i) != "")
            echo "<option value=$i" . ($editrights == $i ? " selected" : "") . ">" . get_user_class_name($i)."</option>";
echo "</select>(Ab welchem Rang darf diese Datei konfiguriert werden?)</td></tr>";


echo "<tr><td class='tablea' style='width:20%'>Datenbankeintrag Webseed:</td><td class='tablea' style='width:80%'><select name='dbtyp'>";
     echo "<option value='webseed'" . ($bdtypwebseed == 'webseed' ? " selected" : "") . ">webseed</option>";
     echo "<option value='webseeder'" . ($bdtypwebseed == 'webseeder' ? " selected" : "") . ">webseeder</option>";
     echo "<option value='rooter'" . ($bdtypwebseed == 'rooter' ? " selected" : "") . ">rooter</option>";
     echo "<option value=' '" . ($bdtypwebseed == ' ' ? " selected" : "") . ">Keine Unterscheidung</option>";
echo "</select>(Welchen Namen hat der Datenbankeintrag der f�r Webseederkennzeichung zust�ndig ist?)</td></tr>";



echo "<tr><td class='tablea' style='width:20%'>Abschicken:</td><td class='tablea' style='width:80%'><input type='submit' value='Ab damit'></td></tr>";
end_table();
echo "</form>";
            begin_table();
echo "<tr><td class='tablea'><a href='".$self."'>Zur�ck</a></td></tr>";
            end_table();
end_frame();
}

}

if (makehours(date("Y-m-d")) > makehours($yend."-".$mend."-".$dend." 0:0:0")) {
stdmsg("Achtung!","<center>Die letzte Uploadrallye war vom ".$dstart.".".$mstart.".".$ystart." bis zum ".$dend.".".$mend.".".$yend."</center>");
stdfoot();
die();
} elseif (makehours(date("Y-m-d")) < makehours($ystart."-".$mstart."-".$dstart." 0:0:0")) {
stdmsg("Achtung!","<center>Die n�chste Uploadrallye ist erst am ".$dstart.".".$mstart.".".$ystart." bis zum ".$dend.".".$mend.".".$yend." geplant</center>"); 
stdfoot();
die();
} else { 
$is = "Die aktuelle Uploadrallye ist vom ".$dstart.".".$mstart.".".$ystart." bis zum ".$dend.".".$mend.".".$yend." berechnet";

}

begin_frame($is, true);
if ($bdtypwebseed != " ")
{
$root = "u.".$bdtypwebseed." = 'yes' AND";
$noroot = "u.".$bdtypwebseed." != 'yes' AND";


        // SHOWS THE STATISTICS OF THE WEBSEED-UPLOADERS
        $res = mysql_query("SELECT COUNT(*) FROM torrents") or sqlerr(__FILE__, __LINE__);
        $n = mysql_fetch_row($res);
        $n_tor = $n[0];

        $res = mysql_query("SELECT COUNT(*) FROM peers") or sqlerr(__FILE__, __LINE__);
        $n = mysql_fetch_row($res);
        $n_peers = $n[0];

        $uporder = $_GET['uporder'];
        $catorder = $_GET["catorder"];

        if ($uporder == "lastul")
            $orderby = "last DESC, name";
        elseif ($uporder == "torrents")
            $orderby = "n_t DESC, name";
        elseif ($uporder == "peers")
            $orderby = "n_p DESC, name";
        else
            $orderby = "n_t DESC, name";

        $query = "SELECT u.id, u.class, u.username AS name, MAX(t.added) AS last, COUNT(DISTINCT t.id) AS n_t, COUNT(p.id) as n_p
        FROM users as u LEFT JOIN torrents as t ON u.id = t.owner LEFT JOIN peers as p ON t.id = p.torrent WHERE ".$root." u.class <= ".$maxclass." AND t.added > '$ystart-$mstart-$dstart $hstart:00:00' AND t.added < '$yend-$mend-$dend $hend:00:00'
        GROUP BY u.id UNION SELECT u.id, u.class, u.username AS name, MAX(t.added) AS last, COUNT(DISTINCT t.id) AS n_t, COUNT(p.id) as n_p
        FROM users as u JOIN torrents as t ON u.id = t.owner LEFT JOIN peers as p ON t.id = p.torrent WHERE  ".$root." u.class <= ".$maxclass." AND t.added > '$ystart-$mstart-$dstart $hstart:00:00' AND t.added < '$yend-$mend-$dend $hend:00:00'
        GROUP BY u.id ORDER BY $orderby";

        $res = mysql_query($query) or sqlerr(__FILE__, __LINE__);

        if (mysql_num_rows($res) == 0)
            stdmsg("Sorry...", "<center>Keine Uploader! (Webseeder)</center>");
        else {
            begin_frame("Aktions Uploads: (Webseeder)", true);
            begin_table();
            print("<tr>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=uploader&amp;catorder=$catorder\" class=tablecatlink>Uploader</a></td>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=lastul&amp;catorder=$catorder\" class=tablecatlink>Letzter Upload</a></td>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=torrents&amp;catorder=$catorder\" class=tablecatlink>Torrents</a></td>\n
        <td class=tablecat>Proz.</td>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=peers&amp;catorder=$catorder\" class=tablecatlink>Peers</a></td>\n
        <td class=tablecat>Proz.</td>\n
        </tr>\n");
            while ($uper = mysql_fetch_array($res)) {
                print("<tr><td class=tablea><a href='userdetails.php?id=" . $uper['id'] . "'><font class=\"" . get_class_color($uper["class"]) . "\"><b>" . $uper['name'] . "</b></font></a></td>\n");
                print("<td class=tableb " . ($uper['last']?(">" . $uper['last'] . " (vor " . get_elapsed_time(sql_timestamp_to_unix_timestamp($uper['last'])) . ")"):" style=\"text-align: center;\">---") . "</td>\n");
                print("<td class=tablea style=\"text-align: right;\">" . $uper['n_t'] . "</td>\n");
                print("<td class=tableb style=\"text-align: right;\">" . ($n_tor > 0?number_format(100 * $uper['n_t'] / $n_tor, 1) . "%":"---") . "</td>\n");
                print("<td class=tablea style=\"text-align: right;\">" . $uper['n_p'] . "</td>\n");
                print("<td class=tableb style=\"text-align: right;\">" . ($n_peers > 0?number_format(100 * $uper['n_p'] / $n_peers, 1) . "%":"---") . "</td></tr>\n");
            }
            end_table();
            end_frame();
        }
       
}


        // SHOWS THE STATISTICS OF THE UPLOADERS
        $res = mysql_query("SELECT COUNT(*) FROM torrents") or sqlerr(__FILE__, __LINE__);
        $n = mysql_fetch_row($res);
        $n_tor = $n[0];

        $res = mysql_query("SELECT COUNT(*) FROM peers") or sqlerr(__FILE__, __LINE__);
        $n = mysql_fetch_row($res);
        $n_peers = $n[0];

        $uporder = $_GET['uporder'];
        $catorder = $_GET["catorder"];

        if ($uporder == "lastul")
            $orderby = "last DESC, name";
        elseif ($uporder == "torrents")
            $orderby = "n_t DESC, name";
        elseif ($uporder == "peers")
            $orderby = "n_p DESC, name";
        else
            $orderby = "n_t DESC, name";

        $query = "SELECT u.id, u.class, u.username AS name, MAX(t.added) AS last, COUNT(DISTINCT t.id) AS n_t, COUNT(p.id) as n_p
        FROM users as u LEFT JOIN torrents as t ON u.id = t.owner LEFT JOIN peers as p ON t.id = p.torrent WHERE ".$noroot." u.class <= ".$maxclass." AND t.added > '$ystart-$mstart-$dstart $hstart:00:00' AND t.added < '$yend-$mend-$dend $hend:00:00'
        GROUP BY u.id UNION SELECT u.id, u.class, u.username AS name, MAX(t.added) AS last, COUNT(DISTINCT t.id) AS n_t, COUNT(p.id) as n_p
        FROM users as u JOIN torrents as t ON u.id = t.owner LEFT JOIN peers as p ON t.id = p.torrent WHERE  ".$noroot." u.class <= ".$maxclass." AND t.added > '$ystart-$mstart-$dstart $hstart:00:00' AND t.added < '$yend-$mend-$dend $hend:00:00'
        GROUP BY u.id ORDER BY $orderby";

        $res = mysql_query($query) or sqlerr(__FILE__, __LINE__);

        if (mysql_num_rows($res) == 0)
            stdmsg("Sorry...", "<center>Keine Uploader!</center>");
        else {
            begin_frame("Aktions Uploads (Keine Webseeds):", true);
            begin_table();
            print("<tr>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=uploader&amp;catorder=$catorder\" class=tablecatlink>Uploader</a></td>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=lastul&amp;catorder=$catorder\" class=tablecatlink>Letzter Upload</a></td>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=torrents&amp;catorder=$catorder\" class=tablecatlink>Torrents</a></td>\n
        <td class=tablecat>Proz.</td>\n
        <td class=tablecat><a href=\"" . $self . "?act=upstats&amp;uporder=peers&amp;catorder=$catorder\" class=tablecatlink>Peers</a></td>\n
        <td class=tablecat>Proz.</td>\n
        </tr>\n");
            while ($uper = mysql_fetch_array($res)) {
                print("<tr><td class=tablea><a href='userdetails.php?id=" . $uper['id'] . "'><font class=\"" . get_class_color($uper["class"]) . "\"><b>" . $uper['name'] . "</b></font></a></td>\n");
                print("<td class=tableb " . ($uper['last']?(">" . $uper['last'] . " (vor " . get_elapsed_time(sql_timestamp_to_unix_timestamp($uper['last'])) . ")"):" style=\"text-align: center;\">---") . "</td>\n");
                print("<td class=tablea style=\"text-align: right;\">" . $uper['n_t'] . "</td>\n");
                print("<td class=tableb style=\"text-align: right;\">" . ($n_tor > 0?number_format(100 * $uper['n_t'] / $n_tor, 1) . "%":"---") . "</td>\n");
                print("<td class=tablea style=\"text-align: right;\">" . $uper['n_p'] . "</td>\n");
                print("<td class=tableb style=\"text-align: right;\">" . ($n_peers > 0?number_format(100 * $uper['n_p'] / $n_peers, 1) . "%":"---") . "</td></tr>\n");
            }
            end_table();
            end_frame();
    }

   end_frame();

        stdfoot();
        ?>