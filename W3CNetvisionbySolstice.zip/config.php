<?
require_once("include/bittorrent.php");

dbconn(false);
loggedinorreturn();

if (get_user_class() < UC_SYSOP)
stderr("Error", "Du bist es nicht wert, diese Seite zu betrachten. Geh nach Hause zu deiner Mama!!!");


if (get_user_class() < UC_SYSOP) $action = "";
elseif (isset($_POST["action"])) $action = htmlentities(trim($_POST["action"]));
elseif (isset($_GET["action"])) $action = htmlentities(trim($_GET["action"]));
else $action = "view";

stdhead("Konfiguration");


$CONF["PIC_URL"] = $GLOBALS["PIC_BASE_URL"].$GLOBALS["ss_uri"]."/";
$dbname          = "config";

if ($action == "delete")
{
  $id  = intval($_GET["id"]);
if (isset($_POST["accept"]))
{
  $sql = "DELETE FROM ".$dbname." WHERE id = " . $id . " LIMIT 1";
  mysql_query($sql);
  
  $result = "<span style=\"color:green\">Der Konfigurationseintrag (" . $id . ") wurde erfolgreich gel&ouml;scht.</span>";

  print("  <table cellpadding=\"4\" cellspacing=\"1\"  style=\"width:700\" class=\"tableinborder\">\n");
  print("    <tr><td class=\"tabletitle\">Konfigurationseintrag '" . $id . "' l&ouml;schen</td></tr>\n");
  print("    <tr>\n");
  print("      <td class=\"tablea\">" . $result . "</td>\n");
  print("    </tr>\n");
  print("    <tr><td class=\"tabletitle\" style=\"text-align:center\"><b><a href=\"" . $_SERVER["PHP_SELF"] . "\">Weiter</a></b></td></tr>\n");
  print("  </table>\n");
}
else
{
  print("\n<form method=\"post\" action=\"" . $_SERVER["PHP_SELF"] . "?action=delete&amp;id=".$id."\">\n");  
  print("  <table cellpadding=\"4\" cellspacing=\"1\"  style=\"width:100%\" class=\"tableinborder\">\n");
  print("    <tr><td class=\"tabletitle centr\"><span style=\"color:red;\"><b>GEFAHR! Zusammenbruch der Webseitenstruktur wahrscheinlich! </b> <br />Konfigurationseintrag '" . $id . "' mitsamt <b>ALLEN</b> Werten l&ouml;schen? </td></tr>\n");
  print("    <tr>\n");
  print("      <td class=\"tablea\" style=\"text-align:center\">  <input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"submit\" value=\"Ja!\" >  </td>\n");
  print("    </tr>\n");
  print("  </table>\n");
  print("</form>\n");
}

}
if ($action == "update")
{
  $id        = intval($_POST["id"]);

  if (trim(strtoupper($_POST["name"])) != "" && $id)
  {
  	$_POST["bereich"] = ($_POST["neubereich"] != "" ? $_POST["neubereich"] : $_POST["bereich"]);
    $sql = "UPDATE ".$dbname." SET name = " . sqlesc(str_replace(" ", "_", trim($_POST["name"]))) . ",  title = " . sqlesc(trim($_POST["title"])) . ",  descr = " . sqlesc(trim($_POST["descr"])) . ", ordernum = ".sqlesc(intval($_POST["ordernum"])).", bereich = ".sqlesc(trim($_POST["bereich"]))." WHERE id = " . $id . " LIMIT 1";
    $err = mysql_query($sql) or sqlerr(__FILE__, __LINE__);

    if ($err) $result = "<span style=\"color:green\">Der Konfigurationseintrag " . $name . " wurde erfolgreich ge&auml;ndert.</span>";
    else $result = "<span style=\"color:red\">Fehler beim Bearbeiten des Konfigurationseintrags  " . $name . "</span><br>" . $sql;
    
    print("  <table cellpadding=\"4\" cellspacing=\"1\"  style=\"width:100%\" class=\"tableinborder\">\n");
    print("    <tr>\n");
    print("      <td class=\"tableb\">Konfigurationseintrag <b>" . $name . "</b> bearbeiten</td>\n");
    print("    </tr>\n");
    print("    <tr>\n");
    print("      <td class=\"tablea\">" . $result . "</td>\n");
    print("    </tr>\n");
    print("    <tr><td class=\"tabletitle\" ><b><a href=\"" . $_SERVER["PHP_SELF"] . "\">Weiter</a></b></td></tr>\n");
    print("  </table>\n");
  }
  else
  {
    print("  <table cellpadding=\"4\" cellspacing=\"1\"  style=\"width:700\" class=\"tableinborder\">\n");
    print("    <tr>\n");
    print("      <td class=\"tableb\"><b>!! FEHLER !!</b></td>\n");
    print("    </tr>\n");
    print("    <tr>\n");
    print("      <td class=\"tablea\">Es sind nicht alle Angaben vollst�ndig (Interner Name fehlt!)</td>\n");
    print("    </tr>\n");
    print("    <tr><td class=\"tabletitle\" style=\"text-align:center\"><b><a href=\"javascript:history.back()\">Zur&uuml;ck</a></b></td></tr>\n");
    print("  </table>\n");
  }
}
if ($action == "edit" && is_numeric($_GET["id"]))
{
  $id  = intval($_GET["id"]);
  $sql = "SELECT * FROM ".$dbname." WHERE id = " . $id . " LIMIT 1";
  $res = mysql_query($sql) or sqlerr(__FILE__, __LINE__);
  $arr = mysql_fetch_assoc($res);
  
  
  print("\n<form method=\"post\" action=\"" . $_SERVER["PHP_SELF"] . "\">\n");
  print("<table summary=\"\" style=\"width:100%;\" cellpadding=\"5\" cellspacing=\"1\" class=\"tableinborder\">\n");
  print("  <tr>\n");
  print("    <td class=\"tableb\" colspan=\"2\">Konfigurationseintrag <b>" . $arr["title"] . "</b> bearbeiten</td>\n");
  print("  </tr>\n");
  
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Interner Name</td>\n");
  print("    <td class=\"tablea\"><input type=\"text\" value=\"" . $arr["name"] . "\" onclick=\"alert('Interne Namen �ndern hat empfindlichen Einfluss auf die Stabilit�t der Webseitenstruktur! �nderung NICHT empfohlen');\" name=\"name\" size=\"50\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Titel</td>\n");
  print("    <td class=\"tablea\"><input type=\"text\" value=\"" . $arr["title"] . "\" name=\"title\" size=\"50\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Beschreibung</td>\n");
  print("    <td class=\"tablea\"><textarea cols=\"30\" rows=\"5\" name=\"descr\">" . $arr["descr"] . "</textarea></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Wichtigkeit (Zahl!)</td>\n");
  print("    <td class=\"tablea\"><input type=\"text\" name=\"ordernum\" value=\"".$arr["ordernum"]."\" size=\"5\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  
  $ress = mysql_query("SELECT DISTINCT bereich FROM ".$dbname." ORDER BY id ASC");
  $bereiche = "<select name=\"bereich\" >";
  while ($ergs = mysql_fetch_assoc($ress))
  { $bereiche .= "<option value=\"".$ergs["bereich"]."\" ".($ergs["bereich"] == $arr["bereich"] ? "selected=\"selected\"" : "")." >".$ergs["bereich"]."</option>";  }
  $bereiche .= "</select>";
  
  print("    <td class=\"tablea\" style=\"width:110px;\">Bereich</td>\n");
  print("    <td class=\"tablea\"> ".$bereiche." <br />oder neuer Bereich: <input type=\"text\" name=\"neubereich\" size=\"35\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tabletitle\" colspan=\"2\" style=\"text-align:center\"><input type=\"submit\" />    <input type=\"hidden\" value=\"update\" name=\"action\" /><input type=\"hidden\" value=\"" . $id . "\" name=\"id\" />   </td>\n");
  print("  </tr>\n");
  print("</table>\n");
  print("</form>\n\n");
}

if ($action == "insert")
{
  $name = str_replace(" ", "_", trim($_POST["name"]));

  if ($name != "")
  {
  	$_POST["bereich"] = ($_POST["neubereich"] != "" ? $_POST["neubereich"] : $_POST["bereich"]);
    $sql = "INSERT INTO ".$dbname." (id, name, title, descr, ordernum, bereich) VALUES (NULL , " . sqlesc($name) . ", " . sqlesc(trim($_POST["title"])) . ", " . sqlesc(trim($_POST["descr"])) . ",".sqlesc(intval($_POST["ordernum"]))."," . sqlesc(trim($_POST["bereich"])) . ")";
    $err = mysql_query($sql) or sqlerr(__FILE__, __LINE__);

    if ($err) $result = "<span style=\"color:green\">Der Konfigurationseintrag " . trim($_POST["title"]) . " wurde erfolgreich angelegt.</span>";
    else $result = "<span style=\"color:red\">Fehler beim Anlegen des Konfigurationseintrags  " . $name . "</span><br>" . $sql;
    print("  <table cellpadding=\"4\" cellspacing=\"1\"  style=\"width:700\" class=\"tableinborder\">\n");
    print("    <tr>\n");
    print("      <td class=\"tableb\"><b>Neues Thema erstellen</b></td>\n");
    print("    </tr>\n");
    print("    <tr>\n");
    print("      <td class=\"tablea\">" . $result . "</td>\n");
    print("    </tr>\n");
    print("    <tr><td class=\"tabletitle\" style=\"text-align:center\"><b><a href=\"" . $_SERVER["PHP_SELF"] . "\">Weiter</a></b></td></tr>\n");
    print("  </table>\n");
  }
  else
  {
    print("  <table cellpadding=\"4\" cellspacing=\"1\"  style=\"width:700\" class=\"tableinborder\">\n");
    print("    <tr>\n");
    print("      <td class=\"tableb\"><b>!! FEHLER !!</b></td>\n");
    print("    </tr>\n");
    print("    <tr>\n");
    print("      <td class=\"tablea\">Es sind nicht alle Angaben vollst�ndig (Interner Name fehlt!)</td>\n");
    print("    </tr>\n");
    print("    <tr><td class=\"tabletitle\" style=\"text-align:center\"><b><a href=\"javascript:history.back()\">Zur&uuml;ck</a></b></td></tr>\n");
    print("  </table>\n");
  }
}

if ($action == "new")
{
  print("\n<form method=\"post\" action=\"" . $_SERVER["PHP_SELF"] . "\">\n");  
  print("<table summary=\"\" style=\"width:100%;\" cellpadding=\"5\" cellspacing=\"1\"  class=\"tableinborder\" >\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" colspan=\"2\">Neuen Konfigurationseintrag anlegen</td>\n");
  print("  </tr>\n");

  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Interner Name</td>\n");
  print("    <td class=\"tablea\"><input type=\"text\" name=\"name\" size=\"50\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Titel</td>\n");
  print("    <td class=\"tablea\"><input type=\"text\"  name=\"title\" size=\"50\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Beschreibung</td>\n");
  print("    <td class=\"tablea\"><textarea cols=\"30\" rows=\"5\" name=\"descr\"></textarea></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tablea\" style=\"width:110px;\">Wichtigkeit (Zahl!)</td>\n");
  print("    <td class=\"tablea\"><input type=\"text\" name=\"ordernum\" size=\"5\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  
  $ress = mysql_query("SELECT DISTINCT bereich FROM ".$dbname." ORDER BY id ASC");
  $bereiche = "<select name=\"bereich\" >";
  while ($ergs = mysql_fetch_assoc($ress))
  { $bereiche .= "<option value=\"".$ergs["bereich"]."\">".$ergs["bereich"]."</option>";  }
  $bereiche .= "</select>";
  
  print("    <td class=\"tablea\" style=\"width:110px;\">Bereich</td>\n");
  print("    <td class=\"tablea\"> ".$bereiche." <br />oder neuer Bereich: <input type=\"text\" name=\"neubereich\" size=\"35\" /></td>\n");
  print("  </tr>\n");
  print("  <tr>\n");
  print("    <td class=\"tabletitle\" colspan=\"2\" style=\"text-align:center\"><input type=\"submit\" />  <input type=\"hidden\" value=\"insert\" name=\"action\" />   </td>\n");
  print("  </tr>\n");
  print("</table>\n");
  print("</form>\n\n");
}
if ($action == "view")
{
	 if ($_SERVER["REQUEST_METHOD"] == "POST")
	 {
       $allconf = mysql_query("SELECT name,id FROM ".$dbname."");
       while ($each = mysql_fetch_assoc($allconf))
       {
	 	   mysql_query("UPDATE ".$dbname." SET wert=".sqlesc($_POST[$each["name"]])." WHERE id=".$each["id"]);
       }      
	 }
	 
 print("<form method=\"post\" action=\"" . $_SERVER["PHP_SELF"] . "\">\n");
 print("<table summary=\"\" style=\"width:100%\" cellpadding=\"5\" cellspacing=\"1\" class=\"tableinborder\">\n");

  $ress = mysql_query("SELECT DISTINCT bereich FROM ".$dbname." ORDER BY bereich ASC");
  while ($ergs = mysql_fetch_assoc($ress))
    {
  $c = 0;
  print("  <tr><td colspan=\"3\" style=\"text-align:left\" class=\"tableb\"><img id=\"".str_replace(" ", "_", $ergs["bereich"])."img\" src=\"".$CONF["PIC_URL"]."plus.gif\" alt=\"Auf/Zuklappen\" title=\"Auf/Zuklappen\" onclick=\" if (document.getElementById('".str_replace(" ", "_", $ergs["bereich"])."').style.display == 'none'){ document.getElementById('".str_replace(" ", "_", $ergs["bereich"])."'+'img').src = '".$GLOBALS["PIC_BASE_URL"].$GLOBALS["ss_uri"]."/minus.gif'; document.getElementById('".str_replace(" ", "_", $ergs["bereich"])."').style.display = 'block'; } else { document.getElementById('".str_replace(" ", "_", $ergs["bereich"])."'+'img').src = '".$GLOBALS["PIC_BASE_URL"].$GLOBALS["ss_uri"]."/plus.gif'; document.getElementById('".str_replace(" ", "_", $ergs["bereich"])."').style.display = 'none'; }\" />  <b>".$ergs["bereich"]."</b></td></tr>\n");
    print("  <tr><td colspan=\"3\" style=\"text-align:center\" class=\"tablea\">\n");
      print(" <div id=\"".str_replace(" ", "_", $ergs["bereich"])."\" style=\"display:none;\"> \n");
      print("<table summary=\"".str_replace(" ", "_", $ergs["bereich"])."\" style=\"width:100%\" cellpadding=\"5\" cellspacing=\"1\">\n");
       $sql = "SELECT * FROM ".$dbname." WHERE bereich='".$ergs["bereich"]."' ORDER BY ordernum DESC";
       $res = mysql_query($sql);
       while ($configs = mysql_fetch_assoc($res))
       { 
       $edit   = "<a href=\"" . $_SERVER["PHP_SELF"] . "?action=edit&amp;id=" . $configs["id"] . "\" onclick=\" return confirm('Dies bearbeitet die Beschreibung und andere Grundlegende Dinge dieses Konfigurationseintrags, nicht dessen Wert. Trotzdem fortfahren?');\" ><img src=\"".$CONF["PIC_URL"]."edit.png\" alt=\"Bearbeiten\" title=\"Bearbeiten\" style=\"vertical-align: middle;border:none;width:16px;height:16px;\" /></a>";
       $delete = "<a href=\"" . $_SERVER["PHP_SELF"] . "?action=delete&amp;id=" . $configs["id"] . "\" onclick=\" return confirm('Die L�schung von Konfigurationen kann zu Seitenausf�llen f�hren. M�chten sie diese Konfigurationseinstellung trotzdem l�schen?');\" ><img src=\"".$CONF["PIC_URL"]."editdelete.png\" alt=\"L&ouml;schen\" title=\"L&ouml;schen\" style=\"vertical-align: middle;border:none;width:16px;height:16px;\" /></a>";
       print("  <tr class=\"table".($c++%2 == 0 ? "a" : "b")."\"><td style=\"text-align:center;width:10px;\"><img src=\"".$CONF["PIC_URL"]."help.png\" onmousemove=\"info('".$configs["title"]."','".$configs["descr"]."');\" onmouseout=\"hideLayer()\" alt=\"Info\" /></td><td style=\"text-align:right;width:200px;\">".$configs["title"]."</td><td style=\"text-align:left;\"><input type=\"text\" value=\"".$configs["wert"]."\" name=\"".$configs["name"]."\" size=\"50\" /></td><td style=\"text-align:left;\">&nbsp;".$configs["name"]."</td><td style=\"text-align:left;width:16px;\">".$configs["ordernum"]."</td><td style=\"text-align:left;width:32px;\">".$edit.$delete."</td></tr>\n");
       }
        print("  <tr><td colspan=\"5\" style=\"text-align:center\"><input type=\"submit\" value=\"Speichern\" /></td></tr>\n");
        print("  <tr><td colspan=\"5\" style=\"text-align:center\">  &nbsp;  </td></tr>\n");
      print("</table>\n");
      print(" </div> \n");

    print("  </td></tr>\n"); 
    }   
  print("  <tr><td colspan=\"3\" style=\"text-align:center\"></td></tr>\n");
 print("</table>\n");
 print("</form>\n\n");
 
  print("<br />\n\n");
  print("\n<form method=\"post\" action=\"" . $_SERVER["PHP_SELF"] . "\">\n");
  print("<table summary=\"\" style=\"width:100%\" cellpadding=\"5\" cellspacing=\"1\"   class=\"tableinborder\">\n");
  print("  <tr>\n");
  print("    <td style=\"text-align:center\" class=\"tablea\"><input type=\"submit\" value=\"Neu anlegen\" />    <input type=\"hidden\" value=\"new\" name=\"action\" />    </td>\n");
  print("  </tr>\n");
  print("</table>\n");
  print("</form>\n\n");
 
}

stdfoot();
?>
