<?$urlshout="shbox.php"?>
<table cellpadding="4" cellspacing="1" border="0" style="width:100%" class="tableinborder" summary="none">
<tr class="tabletitle" style="width:100%">
<?
print("<td colspan=10 style='width:100%'><center><span class=normalfont><b> ..::SHOUTBOX::.. </b></span></center></td>");
?>
</tr><tr>
<td class=text style="width:100%">
<script type="text/javascript">
function mySubmit() {
setTimeout('document.shbox.reset()',50);
}
</SCRIPT>
<?

?>
<iframe src='<?=$urlshout?>' style="width:100%" height='290' frameborder='0' name='sbox' marginwidth='0' marginheight='0'></iframe><br><br>

<form action='<?=$urlshout?>' method='get' target='sbox' name='shbox' onSubmit="mySubmit()">
<script  type="text/javascript">
var b_open = 0;
var i_open = 0;
var u_open = 0;
var color_open = 0;
var list_open = 0;
var quote_open = 0;
var html_open = 0;

var myAgent = navigator.userAgent.toLowerCase();
var myVersion = parseInt(navigator.appVersion);

var is_ie = ((myAgent.indexOf("msie") != -1) && (myAgent.indexOf("opera") == -1));
var is_nav = ((myAgent.indexOf('mozilla')!=-1) && (myAgent.indexOf('spoofer')==-1)
&& (myAgent.indexOf('compatible') == -1) && (myAgent.indexOf('opera')==-1)
&& (myAgent.indexOf('webtv') ==-1) && (myAgent.indexOf('hotjava')==-1));

var is_win = ((myAgent.indexOf("win")!=-1) || (myAgent.indexOf("16bit")!=-1));
var is_mac = (myAgent.indexOf("mac")!=-1);
var bbtags = new Array();
function cstat() {
var c = stacksize(bbtags);
if ( (c < 1) || (c == null) ) {c = 0;}
if ( ! bbtags[0] ) {c = 0;}
document.shbox.tagcount.value = "Schliesse letzten, Offene "+c;
}
function stacksize(thearray) {
for (i = 0; i < thearray.length; i++ ) {
if ( (thearray[i] == "") || (thearray[i] == null) || (thearray == 'undefined') ) {return i;}
}
return thearray.length;
}
function pushstack(thearray, newval) {
arraysize = stacksize(thearray);
thearray[arraysize] = newval;
}
function popstackd(thearray) {
arraysize = stacksize(thearray);
theval = thearray[arraysize - 1];
return theval;
}
function popstack(thearray) {
arraysize = stacksize(thearray);
theval = thearray[arraysize - 1];
delete thearray[arraysize - 1];
return theval;
}
function closeall() {
if (bbtags[0]) {
while (bbtags[0]) {
tagRemove = popstack(bbtags)
if ( (tagRemove != 'color') ) {
doInsert("[/"+tagRemove+"]", "", false);
eval("document.shbox." + tagRemove + ".value = ' " + tagRemove + " '");
eval(tagRemove + "_open = 0");
} else {
doInsert("[/"+tagRemove+"]", "", false);
}
cstat();
return;
}
}
document.shbox.tagcount.value = "Schliesse letzten, Offene 0";
bbtags = new Array();
document.shbox.shbox_text.focus();
}
function add_code(NewCode) {
document.shbox.shbox_text.value += NewCode;
document.shbox.shbox_text.focus();
}
function alterfont(theval, thetag) {
if (theval == 0) return;
if(doInsert("[" + thetag + "=" + theval + "]", "[/" + thetag + "]", true)) pushstack(bbtags, thetag);
document.shbox.color.selectedIndex = 0;
cstat();
}
function tag_url() {
var FoundErrors = '';
var enterURL = prompt("Du musst eine Url eintragen", "http://");
var enterTITLE = prompt("Du musst einen Titel eintragen", "");
if (!enterURL || enterURL=="") {FoundErrors += " " + "Du musst eine Url angeben,";}
if (!enterTITLE) {FoundErrors += " " + "Du musst einen Titel angeben";}
if (FoundErrors) {alert("Fehler!"+FoundErrors);return;}
doInsert("[url="+enterURL+"]"+enterTITLE+"[/url]", "", false);
}
function tag_list() {
var FoundErrors = '';
var enterTITLE = prompt("Gebe ein Bestandteil der Liste an. Wenn es sich um das Ende der Liste handelt dann klicke auf 'cancel' oder lasse das Feld leer", "");
if (!enterTITLE) {FoundErrors += " " + "Gebe ein Bestandteil der Liste an. Wenn es sich um das Ende der Liste handelt dann klicke auf 'cancel' oder lasse das Feld leer";}
if (FoundErrors) {alert("Fehler!"+FoundErrors);return;}
doInsert("[*]"+enterTITLE+"", "", false);

}
function tag_image() {
var FoundErrors = '';
var enterURL = prompt("Du musst die ganze Bild url eintragen", "http://");
if (!enterURL || enterURL=="http://") {
alert("Fehler!"+"Du musst die ganze Bild url eintragen");
return;
}
doInsert("[img]"+enterURL+"[/img]", "", false);
}
function tag_email() {
var emailAddress = prompt("Du musst eine email Addresse angeben", "");
if (!emailAddress) {
alert("Fehler!"+"Du musst eine email Addresse angeben");
return;
}
doInsert("[email]"+emailAddress+"[/email]", "", false);
}
function doInsert(ibTag, ibClsTag, isSingle)
{
var isClose = false;
var obj_ta = document.shbox.shbox_text;
if ( (myVersion >= 4) && is_ie && is_win) {
if(obj_ta.isTextEdit){
obj_ta.focus();
var sel = document.selection;
var rng = sel.createRange();
rng.colapse;
if((sel.type == "Text" || sel.type == "None") && rng != null){
if(ibClsTag != "" && rng.text.length > 0)
ibTag += rng.text + ibClsTag;
else if(isSingle) isClose = true;
rng.text = ibTag;
}
}
else{
if(isSingle) isClose = true;
obj_ta.value += ibTag;
}
} else {
if(isSingle) isClose = true;
obj_ta.value += ibTag;
}
obj_ta.focus();
// obj_ta.value = obj_ta.value.replace(/ /, " ");
return isClose;
}
function em(theSmilie)
{
doInsert(" " + theSmilie + " ", "", false);
}



function ShowTags() {
  var TagsWindow = window.open("/tags.php", "Tags","")
}



function winop()
{
windop = window.open("smilies.php","mywin","");
}

function addText(theTag, theClsTag, isSingle, theForm)
{
    var isClose = false;
    var message = theForm.shbox_text;
    var set=false;
      var old=false;
      var selected="";

      if(navigator.appName=="Netscape" &&  message.textLength>=0 ) { // mozilla, firebird, netscape
          if(theClsTag!="" && message.selectionStart!=message.selectionEnd) {
              selected=message.value.substring(message.selectionStart,message.selectionEnd);
              str=theTag + selected+ theClsTag;
              old=true;
              isClose = true;
          }
        else {
            str=theTag;
        }

        message.focus();
        start=message.selectionStart;
        end=message.textLength;
        endtext=message.value.substring(message.selectionEnd,end);
        starttext=message.value.substring(0,start);
        message.value=starttext + str + endtext;
        message.selectionStart=start;
        message.selectionEnd=start;

        message.selectionStart = message.selectionStart + str.length;

        if(old) { return false; }

        set=true;

        if(isSingle) {
            isClose = false;
        }
    }
    if ( (myVersion >= 4) && is_ie && is_win) {  // Internet Explorer
        if(message.isTextEdit) {
            message.focus();
            var sel = document.selection;
            var rng = sel.createRange();
            rng.colapse;
            if((sel.type == "Text" || sel.type == "None") && rng != null){
                if(theClsTag != "" && rng.text.length > 0)
                    theTag += rng.text + theClsTag;
                else if(isSingle)
                    isClose = true;

                rng.text = theTag;
            }
        }
        else{
            if(isSingle) isClose = true;

            if(!set) {
                      message.value += theTag;
                  }
        }
    }
    else
    {
        if(isSingle) isClose = true;

        if(!set) {
                  message.value += theTag;
              }
    }

    message.focus();

    return isClose;
}


function simpletag(thetag)
{
var tagOpen = eval(thetag + "_open");
if (tagOpen == 0) {
if(doInsert("[" + thetag + "]", "[/" + thetag + "]", true))
{
eval(thetag + "_open = 1");
eval("document.shbox." + thetag + ".value += '*'");
pushstack(bbtags, thetag);
cstat();
}
}
else {
lastindex = 0;
for (i = 0; i < bbtags.length; i++ ) {
if ( bbtags[i] == thetag ) {
lastindex = i;
}
}

while (bbtags[lastindex]) {
tagRemove = popstack(bbtags);
doInsert("[/" + tagRemove + "]", "", false)
if ((tagRemove != 'COLOR') ){
eval("document.shbox." + tagRemove + ".value = ' " + tagRemove + " '");
eval(tagRemove + "_open = 0");
}
}
cstat();
}
}
</script>
<center><table width=600  cellspacing=0 cellpadding=1><tr>
<td colSpan="1">
<table  cellSpacing="1" cellPadding="1"><tr><td class="embedded">
<input style="font-weight: bold;font-size:9px;" type=button name="b" value="B" onclick="javascript: simpletag('b')" >
<input class="codebuttons" style="font-style: italic;font-size:10px;" type=button name="i" value="I" onclick="javascript: simpletag('i')" >
<input class="codebuttons" style="text-decoration: underline;font-size:9px;" type=button name="u" value="U" onclick="javascript: simpletag('u')" >
<input class="codebuttons" style="font-size:10px;" type=button name='url' value='URL' onclick='tag_url()' >
<input class="codebuttons" style="font-size:10px;" type=button name="IMG" value="IMG" onclick="javascript: tag_image()" >
<input type=button style="font-size:9px;" name="list" value="List" onclick="tag_list()" >
<input class="codebuttons" style="font-size:10px;" type=button name="quote" value="Quote" onclick="javascript: simpletag('quote')" >
<input style="font-size:9px;width:188" type=button onclick='javascript:closeall();' name='tagcount' value="Alle Tags schliessen">
</td>
</tr><tr>
<td>
<table width=600  cellspacing=0 cellpadding=1> 
<tr>
<td colSpan="1">
<table cellSpacing="1" cellPadding="1">
<tr>
<td class=embedded><select name='color' class='codebuttons' onchange="alterfont(this.options[this.selectedIndex].value, 'color')">
<option value='0'>------- Farbe -------</option>
<option style="BACKGROUND-COLOR: black" value="Black">Black
</option>
<option style="BACKGROUND-COLOR: sienna" value="Sienna">
Sienna</option>

<option style="BACKGROUND-COLOR: darkolivegreen" value="DarkOliveGreen">
Dark Olive Green</option>
<option style="BACKGROUND-COLOR: darkgreen" value="DarkGreen">
Dark Green</option>

<option style="BACKGROUND-COLOR: darkslateblue" value="DarkSlateBlue">
Dark Slate Blue</option>
<option style="BACKGROUND-COLOR: navy" value="Navy">Navy
</option>
<option style="BACKGROUND-COLOR: indigo" value="Indigo">
Indigo</option>
<option style="BACKGROUND-COLOR: darkslategray" value="DarkSlateGray">
Dark Slate Gray</option>

<option style="BACKGROUND-COLOR: darkred" value="DarkRed">
Dark Red</option>
<option style="BACKGROUND-COLOR: darkorange" value="DarkOrange">
Dark Orange</option>

<option style="BACKGROUND-COLOR: olive" value="Olive">Olive
</option>
<option style="BACKGROUND-COLOR: green" value="Green">Green
</option>
<option style="BACKGROUND-COLOR: teal" value="Teal">Teal
</option>
<option style="BACKGROUND-COLOR: blue" value="Blue">Blue
</option>
<option style="BACKGROUND-COLOR: slategray" value="SlateGray">
Slate Gray</option>

<option style="BACKGROUND-COLOR: dimgray" value="DimGray">
Dim Gray</option>
<option style="BACKGROUND-COLOR: red" value="Red">Red
</option>
<option style="BACKGROUND-COLOR: sandybrown" value="SandyBrown">

Sandy Brown</option>
<option style="BACKGROUND-COLOR: yellowgreen" value="YellowGreen">
Yellow Green</option>
<option style="BACKGROUND-COLOR: seagreen" value="SeaGreen">
Sea Green</option>
<option style="BACKGROUND-COLOR: mediumturquoise" value="MediumTurquoise">
Medium Turquoise</option>

<option style="BACKGROUND-COLOR: royalblue" value="RoyalBlue">
Royal Blue</option>
<option style="BACKGROUND-COLOR: purple" value="Purple">
Purple</option>

<option style="BACKGROUND-COLOR: gray" value="Gray">Gray
</option>
<option style="BACKGROUND-COLOR: magenta" value="Magenta">
Magenta</option>
<option style="BACKGROUND-COLOR: orange" value="Orange">
Orange</option>
<option style="BACKGROUND-COLOR: yellow" value="Yellow">
Yellow</option>

<option style="BACKGROUND-COLOR: lime" value="Lime">Lime
</option>
<option style="BACKGROUND-COLOR: cyan" value="Cyan">Cyan
</option>
<option style="BACKGROUND-COLOR: deepskyblue" value="DeepSkyBlue">
Deep Sky Blue</option>

<option style="BACKGROUND-COLOR: darkorchid" value="DarkOrchid">
Dark Orchid</option>
<option style="BACKGROUND-COLOR: silver" value="Silver">
Silver</option>
<option style="BACKGROUND-COLOR: pink" value="Pink">Pink
</option>
<option style="BACKGROUND-COLOR: wheat" value="Wheat">Wheat

</option>
<option style="BACKGROUND-COLOR: lemonchiffon" value="LemonChiffon">
Lemon Chiffon</option>
<option style="BACKGROUND-COLOR: palegreen" value="PaleGreen">
Pale Green</option>
<option style="BACKGROUND-COLOR: paleturquoise" value="PaleTurquoise">

Pale Turquoise</option>
<option style="BACKGROUND-COLOR: lightblue" value="LightBlue">
Light Blue</option>
<option style="BACKGROUND-COLOR: plum" value="Plum">Plum
</option>
<option style="BACKGROUND-COLOR: white" value="White">White

</option>
</select>

<select name='font' class='codebuttons' onchange="alterfont(this.options[this.selectedIndex].value, 'font')">
<option value='0'>-------- Schrift ---------</option>
<option value="Arial">Arial</option>
<option value="Arial Black">Arial Black</option>

<option value="Arial Narrow">Arial Narrow</option>
<option value="Book Antiqua">Book Antiqua</option>
<option value="Century Gothic">Century Gothic</option>

<option value="Comic Sans MS">Comic Sans MS</option>
<option value="Courier New">Courier New</option>
<option value="Fixedsys">Fixedsys</option>
<option value="Franklin Gothic Medium">Franklin Gothic
Medium</option>
<option value="Garamond">Garamond</option>
<option value="Georgia">Georgia</option>

<option value="Impact">Impact</option>
<option value="Lucida Console">Lucida Console</option>

<option value="Lucida Sans Unicode">Lucida Sans Unicode
</option>
<option value="Microsoft Sans Serif">Microsoft Sans Serif
</option>
<option value="Palatino Linotype">Palatino Linotype</option>
<option value="System">System</option>
<option value="Tahoma">Tahoma</option>
<option value="Times New Roman">Times New Roman</option>
<option value="Trebuchet MS">Trebuchet MS</option>

<option value="Verdana">Verdana</option>

</select>

<select name='size' class='codebuttons' onchange="alterfont(this.options[this.selectedIndex].value, 'size')">
<option value='0'>---- Gr�sse ----</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>

<option value="6">6</option>

<option value="7">7</option>
</select>
<input  type='submit' name='submit' style="width:115"  value='Okay!' class='shoutbtn'>
  <a href='javascript:ShowTags();'>Tags</a>
</tr>
</table>
</td></tr>
</table>
</td>
</tr>
<tr>
<td><br><input type='text' name='shbox_text' size='85'><input type='hidden' name='sent' value='yes'> <a href='shoutbox4.php' target='sbox'>Refresh</a><br>
</td>
</tr>
</table>
</td>

</tr>
</table></center></form>
</td>
</tr>
</table>