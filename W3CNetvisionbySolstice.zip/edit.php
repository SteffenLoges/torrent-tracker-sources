<?

// +--------------------------------------------------------------------------+
// | Project:   Solstice NVTracker (W3C) - NetVision BitTorrent Tracker       |
// +--------------------------------------------------------------------------+
// | This file is part of NVTracker. NVTracker is based on BTSource,          |
// | originally by RedBeard of TorrentBits, extensively modified by Solstice. |
// |                                                                          |
// | Updates by Solstice:                                                     |
// | - Tidy                                                                   |
// | - W3C Html 4.01 Transitional                                             |
// | - W3C CSS Level 3                                                        |
// |                                                                          |
// | This file has been originally validated by http://validator.w3.org       |
// |                                                                          |
// | NVTracker is free software; you can redistribute it and/or modify        |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | NVTracker is distributed in the hope that it will be useful,             |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen d�rfen nicht entfernt werden!    Do not remove above lines! |
// +--------------------------------------------------------------------------+

require_once("include/bittorrent.php");

hit_start();

if (!mkglobal("id"))
	die();

$id = 0 + $id;
if (!$id)
	die();

dbconn();

hit_count();

loggedinorreturn();

$self = explode ("?", $_SERVER["PHP_SELF"]);
$self = $self[0];
$self = preg_replace("/(.+?)\/(.+?)/is",  "\\2", $self); //Now it don't cares in which folder the file is.  
$self = preg_replace('/\//', '', $self);  //then $self is everytime the basefile even if the $action is set.

$post = $_POST["post"];

if ($post == 'take')
{

function bark($msg) {
	genbark($msg, "Edit failed!");
}

if (!mkglobal("id:name:descr:type"))
	bark("Fehlende Formulardaten!");

$id = 0 + $id;
if (!$id)
	die();

$GLOBALS["uploaderrors"] = Array();

$res = mysql_query("SELECT torrents.owner, torrents.numpics, torrents.filename, torrents.save_as, torrents.activated, users.class FROM torrents LEFT JOIN users ON torrents.owner=users.id WHERE torrents.id = $id");
$row = mysql_fetch_array($res);
if (!$row)
	die();

if ($CURUSER["id"] != $row["owner"] && !(get_user_class() >= UC_MODERATOR || ($row["activated"] == "no" && get_user_class() == UC_GUTEAM && $row["class"] < UC_UPLOADER)))
	bark("Das ist nicht Dein Torrent! Wie konnte das passieren?\n");

$updateset = array();

$fname = $row["filename"];
preg_match('/^(.+)\.torrent$/si', $fname, $matches);
$shortfname = $matches[1];
$dname = $row["save_as"];

$nfoaction = $_POST['nfoaction'];
if ($nfoaction == "update")
{
  $nfofile = $_FILES['nfo'];
  if (!$nfofile) die("No data " . var_dump($_FILES));
  if ($nfofile['size'] > 65535)
    bark("NFO is too big! Max 65,535 bytes.");
  $nfofilename = $nfofile['tmp_name'];
  if (@is_uploaded_file($nfofilename) && @filesize($nfofilename) > 0) {
    $nfo = str_replace("\x0d\x0d\x0a", "\x0d\x0a", file_get_contents($nfofilename));
    $updateset[] = "nfo = " . sqlesc($nfo);
    // Create NFO image
    gen_nfo_pic($nfo, $GLOBALS["BITBUCKET_DIR"]."/nfo-$id.png");
  }
}
else
  if ($nfoaction == "remove")
    $updateset[] = "nfo = ''";

$picaction = $_POST['picaction'];

if ($picaction == "update") {
    
    if ($row["numpics"] >0) {
        for ($I=1; $I<=$row["numpics"]; $I++) {
            @unlink($GLOBALS["BITBUCKET_DIR"]."/t-$id-$I.jpg");
            @unlink($GLOBALS["BITBUCKET_DIR"]."/f-$id-$I.jpg");
        }
    }
    
    // Handle picture uploads
    $picnum = 0;
    if ($_FILES["pic1"]["name"] != "") {
        if (torrent_image_upload($_FILES["pic1"], $id, $picnum+1))
            $picnum++;
    }
    
    if ($_FILES["pic2"]["name"] != "") {
        if (torrent_image_upload($_FILES["pic2"], $id, $picnum+1))
            $picnum++;
    }
    
    $updateset[] = "numpics = " . $picnum;
}

if ($_POST["stripasciiart"] == "1") {
    $descr = strip_ascii_art($descr);
}

$updateset[] = "name = " . sqlesc($name);
$updateset[] = "search_text = " . sqlesc(searchfield("$shortfname $dname $torrent"));
$updateset[] = "descr = " . sqlesc($descr);
$updateset[] = "ori_descr = " . sqlesc($descr);
$updateset[] = "category = " . (0 + $type);
if ($CURUSER["admin"] == "yes") {
	if ($_POST["banned"]) {
		$updateset[] = "banned = 'yes'";
		$_POST["visible"] = 0;
	}
	else
		$updateset[] = "banned = 'no'";
}

// Only allow torrent to be visible/alive if activated
if ($row["activated"] == "yes")
    $updateset[] = "visible = '" . ($_POST["visible"] ? "yes" : "no") . "'";

mysql_query("UPDATE torrents SET " . join(",", $updateset) . " WHERE id = $id");

write_log("torrentedit", "Der Torrent <a href=\"details.php?id=$id\">$id ($name)</a> wurde von '<a href=\"userdetails.php?id=$CURUSER[id]\">$CURUSER[username]</a>' bearbeitet.");

if (count($GLOBALS["uploaderrors"])) {
    $errstr = "<p>Beim Hochladen der Vorschaubilder sind Fehler aufgetreten:</p><ul>";
    foreach ($GLOBALS["uploaderrors"] as $error)
        $errstr .= "<li>$error</li>\n";
    $errstr .= "</ul><p>Alle anderen �nderungen wurden jedoch �bernommen. Bitte bearbeite den Torrent erneut, um ";
    $errstr .= "neue Vorschaubilder hochzuladen.</p>";
    $errstr .= "<p><a href=\"details.php?id=$id&edited=1\">Weiter zur Detailansicht des Torrents</p>";
    stderr("Fehler beim Bilderupload", $errstr);
}

$done = 'OK';
}

$res = mysql_query("SELECT torrents.*,users.class FROM torrents LEFT JOIN users ON torrents.owner=users.id WHERE torrents.id = $id");
$row = mysql_fetch_array($res);
if (!$row)
	die();

stdhead("Torrent \"" . $row["name"] . "\" bearbeiten");
if ($done == 'OK')
stdsuccess("Torrent erfolgreich editiert");



if (!isset($CURUSER) || !($CURUSER["id"] == $row["owner"] || get_user_class() >= UC_MODERATOR || ($row["activated"] == "no" && get_user_class() == UC_GUTEAM && $row["class"] < UC_UPLOADER))) {
echo '<table summary="none" cellpadding="4" cellspacing="1" border="0" style="width:650px" class="tableinborder">
 <tr class="tabletitle" style="width:100%">
  <td colspan="10" style="width:100%"><span class="normalfont"><center><b> Du darfst diesen Torrent nicht bearbeiten </b></center></span></td> 
 </tr><tr><td style="width:100%" class="tablea">Du bist nicht
 der rechtm&auml;&szlig;ige Besitzer, oder Du bist nicht korrekt
 <a href="login.php?returnto=<?=urlencode($_SERVER["REQUEST_URI"])?>&amp;nowarn=1">eingeloggt</a>.
</td></tr>';
echo "</table>";

}
else {
echo "<form method='post' action='".$self."' enctype='multipart/form-data'>\n";
echo "<input type='hidden' name='post' value='take'>";
echo "<table summary='none' cellpadding='4' cellspacing='1' border='0' style='width:650px' class='tableinborder'>
 <tr class='tabletitle' style='width:100%'>
  <td colspan='10' style='width:100%'><center><span class='normalfont'><b>Torrent bearbeiten</b></span></center>";
	print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
	if (isset($_GET["returnto"]))
		print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" >\n"); 
echo "</td></tr>";       

	tr("Torrent Name", "<input type=\"text\" name=\"name\" value=\"" . htmlspecialchars($row["name"]) . "\" size=\"80\" >", 1);
	tr("NFO Datei", "<input type=radio name=nfoaction value='keep' checked>Aktuelle beibehalten<br>".
	"<input type=radio name=nfoaction value='update'>�ndern:<br><input type=file name=nfo size=60>", 1);
if ((strpos($row["ori_descr"], "<") === false) || (strpos($row["ori_descr"], "&lt;") !== false))
  $c = "";
else
  $c = " checked";

       tr("Bilder", "<input type=radio name=picaction value='keep' checked>Aktuelle beibehalten<br>"
	."<input type=radio name=picaction value='update'>�ndern (leer lassen, um Bilder zu l�schen):<br>"
       ."$s<input type=\"file\" name=\"pic1\" size=\"80\"><br>(Optional. Wird oberhalb der "
       ."Torrentbeschreibung angezeigt. Max. Gr��e: ".mksizeint($GLOBALS["MAX_UPLOAD_FILESIZE"]).")<br><br>\n"
       ."<input type=\"file\" name=\"pic2\" size=\"80\"><br>(Optional. Wird oberhalb der "
       ."Torrentbeschreibung angezeigt. Max. Gr��e: ".mksizeint($GLOBALS["MAX_UPLOAD_FILESIZE"]).")\n", 1);
  
	tr("Beschreibung", "<textarea name=\"descr\" rows=\"15\" cols=\"80\">" . htmlspecialchars($row["ori_descr"]) . "</textarea>".
       "<br><input type=\"checkbox\" name=\"stripasciiart\" value=\"1\"> ASCII-Art automatisch entfernen" .
       "<br>(HTML ist <b>nicht</b> erlaubt. Klick <a href=tags.php>hier</a>, f&uuml;r die Ansicht des BB-Codes.)", 1);

	$s = "<select name=\"type\">\n";

	$cats = genrelist();
	foreach ($cats as $subrow) {
		$s .= "<option value=\"" . $subrow["id"] . "\"";
		if ($subrow["id"] == $row["category"])
			$s .= " selected=\"selected\"";
		$s .= ">" . htmlspecialchars($subrow["name"]) . "</option>\n";
	}

	$s .= "</select>\n";
	tr("Type", $s, 1);
	tr("Visible", "<input type=\"checkbox\" name=\"visible\"" . (($row["visible"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" > Visible on main page<br ><table summary='none' border=0 cellspacing=0 cellpadding=0 width=420><tr><td class=embedded>Note that the torrent will automatically become visible when there's a seeder, and will become automatically invisible (dead) when there has been no seeder for a while. Use this switch to speed the process up manually. Also note that invisible (dead) torrents can still be viewed or searched for, it's just not the default.</td></tr></table>", 1);

	if ($CURUSER["class"] >= UC_MODERATOR)
		tr("Gebannt", "<input type=\"checkbox\" name=\"banned\"" . (($row["banned"] == "yes") ? " checked=\"checked\"" : "" ) . " value=\"1\" > Diesen Torrent bannen", 1);

	print("<tr><td class=\"tablea\" colspan=\"2\" align=\"center\"><input type=\"submit\" value='�ndern!' style='height: 25px; width: 100px'> <input type=reset value='R�ckg�ngig' style='height: 25px; width: 100px'></td></tr>\n");
	print("</table>\n");
	print("</form>\n");
	print("<br>\n");
	print("<form method=\"post\" action=\"delete.php\">\n");
  print("<table summary='none' border=\"0\" cellspacing=\"1\" cellpadding=\"4\" style=\"width:650px;\" class=\"tableinborder\">\n");
  print("<tr class=\"tabletitle\"><td colspan=\"2\"><center><span class=\"normalfont\"><b>Torrent l�schen. Grund:</b></span></center></td></tr>");
  print("<tr><td class=\"tableb\"><input name=\"reasontype\" type=\"radio\" value=\"1\">&nbsp;Tot </td><td class=\"tablea\"> 0 Seeder, 0 Leecher = 0 Peers gesamt</td></tr>\n");
  print("<tr><td class=\"tableb\"><input name=\"reasontype\" type=\"radio\" value=\"2\">&nbsp;Doppelt</td><td class=\"tablea\"><input type=\"text\" size=\"60\" name=\"reason[]\"></td></tr>\n");
  print("<tr><td class=\"tableb\"><input name=\"reasontype\" type=\"radio\" value=\"3\">&nbsp;Nuked</td><td class=\"tablea\"><input type=\"text\" size=\"60\" name=\"reason[]\"></td></tr>\n");
  print("<tr><td class=\"tableb\"><input name=\"reasontype\" type=\"radio\" value=\"4\">&nbsp;Regelbruch</td><td class=\"tablea\"><input type=\"text\" size=\"60\" name=\"reason[]\">(req)</td></tr>");
  print("<tr><td class=\"tableb\"><input name=\"reasontype\" type=\"radio\" value=\"5\" checked>&nbsp;Anderer</td><td class=\"tablea\"><input type=\"text\" size=\"60\" name=\"reason[]\">(req)");
	print("<input type=\"hidden\" name=\"id\" value=\"$id\">\n");
	if (isset($_GET["returnto"]))
		print("<input type=\"hidden\" name=\"returnto\" value=\"" . htmlspecialchars($_GET["returnto"]) . "\" >\n");
  print("</td></tr>\n");
  print("<tr><td class=\"tablea\" colspan=\"2\" align=\"center\"><input type=submit value='L�schen!' style='height: 25px'></td></tr>\n");
  print("</table>");
	print("</form>\n");

}

stdfoot();

hit_end();

?>