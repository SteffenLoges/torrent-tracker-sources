<html>
<head>
<title>Figg Disch Und Stirb</title>
</head>
<body>
<h1><?

$headlines = Array(
    "Mir schei�egal wie oft du das noch probierst... ehrlich!",
    "Anwalt informiert... Anwalt verstorben... Gerichtstermin vereinbart... Staat pleite...!",
    "Obama bin Laden!",
    "Geh kacken!",
    "If you don't know about W3C go fuck off and drink 3 WC!",
    "Hei�, schwarz, und echt lecker!",
    "Deine Mutti sollte dir mal die Windeln wechseln... stinkt ja f�rchterlich!",
    "Meins!",
    "Ich glaub ich muss gleich ma echt wild um mich w�ten Junge!",
    "Ich tret' dir deine fiesen Z�hne einzeln aus der Fresse!"
);

shuffle($headlines);
echo $headlines[0];

?></h1>
<p>Diese Fehlermeldung wird Ihnen pr�sentiert von <?

$user = Array(
    "Solstice",
);

shuffle($user);
echo $user[0];

?> und:</p>
<p><?

$sponsors = Array(
    "HOMBACHER - Die Pferdesalami", 
    "Knallmayr Prohomo - Jetzt auch als Z�pfchen!", 
    "Microsoft Windoof wiXP Homo Edition",
    "SpreizP(r)o - Das Analspekulum f�r den Genie�er",
    "Subway - Eat Fresh!",
    "McDonalds - Ich Liebe Es!",
    "Clearasil - F�r Benni nur das Beste",
    "Gilette - F�r das Beste im Mann",
    "GEZ - Schon abGEZockt?",
    "USA World Domination Tour - Bombing a country near you",
    "oekos - Die Schule f�r Deutsch",
    "THW - Trinken, Helfen, Weitersaufen",
    "Beerdigungsinstitut IKEA - wohnst du schon oder lebst du noch?",
    "Hakle Feucht",
    "Flutschi Anal - F�r die Lust durchs Hinterst�bchen.",
    "J�rgen Domian - Die einzige Person, die ihnen vor dem Suizid noch zuh�rt",
    "Bundeswehr - Lern schiessen, treff' Freunde",
    "1337 - Da werden Sie gegangen",
);

shuffle($sponsors);
echo $sponsors[0];

?></p>
</body>
</html>
