<?php


// Bitbucket V3 Update by Solstice
// Basefile originally by Cerberus


require_once(dirname(__FILE__) . "/include/bittorrent.php");

dbconn();
loggedinorreturn();

$PICS_PER_ROW = 6;
$TABLE_WIDTH = "800px";
$CAN_VIEW = UC_MODERATOR;

if (isset($_POST["action"])) $action = trim(htmlentities($_POST["action"]));
elseif (isset($_GET["action"])) $action = trim(htmlentities($_GET["action"]));
else $action = "view";

$out = "";

if ($action == "delete")
{
  $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
  $out .= "  <tr><td class=\"tabletitle\" style=\"text-align: center\" colspan=\"2\"><b>.: Datei l&ouml;schen :.</b></td></tr>\n";

  $userid   = ((isset($_GET["id"])) ? intval($_GET["id"]) : intval($CURUSER["id"]));  


if ($_POST["delpic"])
{
foreach ($_POST["delpic"] as $id)
if (!bbdelete($id, $userid , TRUE))
  {
    $out .= "  <tr>\n";
    $out .= "    <td class=\"tablea\"><font color=\"red\">Diese Datei geh&ouml;rt nicht Dir, oder Sie wurde bereits gel&ouml;scht.</font><br><a href=\"" . $_SERVER["PHP_SELF"] . (isset($_GET["id"]) ? "?id=" . $userid : "") . "\">Zur&uuml;ck zum BitBucket &rArr;</a></td>\n";
    $out .= "  </tr>\n";
  }
else
  {
    $out .= "  <tr>\n";
    $out .= "    <td class=\"tablea\"><font color=\"green\">Die Datei wurde erfolgreich gel�scht</font></td>\n";
    $out .= "  </tr>\n";
  }
}
else
if (!bbdelete($_GET["fileid"], $userid , TRUE))
  {
    $out .= "  <tr>\n";
    $out .= "    <td class=\"tablea\"><font color=\"red\">Diese Datei geh&ouml;rt nicht Dir, oder Sie wurde bereits gel&ouml;scht.</font><br><a href=\"" . $_SERVER["PHP_SELF"] . (isset($_GET["id"]) ? "?id=" . $userid : "") . "\">Zur&uuml;ck zum BitBucket &rArr;</a></td>\n";
    $out .= "  </tr>\n";
  }
else
  {
    $out .= "  <tr>\n";
    $out .= "    <td class=\"tablea\"><font color=\"green\">Die Datei wurde erfolgreich gel�scht</font></td>\n";
    $out .= "  </tr>\n";
  }


  $out .= "  <tr>\n";
  $out .= "    <td class=\"tabletitle\" style=\"text-align: center;\" colspan=\"2\"><a href=\"" . $_SERVER["PHP_SELF"] . (isset($_GET["id"]) ? "?id=" . intval($_GET["id"]) : "") . "\">weiter &rArr;</a></td>\n";
  $out .= "  </tr>\n";
  $out .= "</table>\n";
}

if ($action == "upload")
{
  $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
  $out .= "  <tr><td class=\"tabletitle\" style=\"text-align: center\" colspan=\"2\"><b>.: Dateiupload :.</b></td></tr>\n";

$return = upload($_FILES["file"],$_POST);
  if (is_array($return))
  {
    $out .= "  <tr>\n";
    $out .= "    <td class=\"tablea\">".$return[1]."</td>\n";
    $out .= "  </tr>\n";
  }
  else
 {
    $out .= "  <tr>\n";
    $out .= "    <td class=\"tablea\">Upload erfolgreich</td>\n";
    $out .= "  </tr>\n";
 }
  
  $out .= "  <tr>\n";
  $out .= "    <td class=\"tabletitle\" style=\"text-align: center;\" colspan=\"2\"><a href=\"" . $_SERVER["PHP_SELF"] . "\">weiter &rArr;</a></td>\n";
  $out .= "  </tr>\n";
  $out .= "</table>\n";
}


if ($action == "view")
{
  $view = TRUE;
  if (isset($_GET["id"]) && (intval($_GET["id"]) != $CURUSER["id"]) )
  {
    $userid = intval($_GET["id"]);

    $res = mysql_query("SELECT username,class FROM users WHERE id = " . $userid . " LIMIT 1");
    if (mysql_num_rows($res) == 0)
    {
      $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tabletitle\" style=\"text-align: center;\"><b>.: Fehler :.</b></td>\n";
      $out .= "  </tr>\n";      
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tableb\">Es existiert kein User mit der ID '" . $userid . "'!</td>\n";
      $out .= "  </tr>\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tabletitle\" style=\"text-align: center;\"><a href=\"" . $_SERVER["PHP_SELF"] . "\">weiter &rArr;</a></td>\n";
      $out .= "  </tr>\n";
      $out .= "</table>";
      $view = FALSE;
    }
    
    $arr = mysql_fetch_assoc($res);

    if (($CURUSER["class"] < $CAN_VIEW) || ($CURUSER["class"] <= $arr["class"]))
    {
      $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tabletitle\" style=\"text-align: center;\"><b>.: Fehler :.</b></td>\n";
      $out .= "  </tr>\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tableb\">Du hast keine Rechte, den BitBucket-Inhalt dieses Benutzers anzusehen oder zu &auml;ndern!</td>\n";
      $out .= "  </tr>\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tabletitle\" style=\"text-align: center;\"><a href=\"" . $_SERVER["PHP_SELF"] . "\">weiter &rArr;</a></td>\n";
      $out .= "  </tr>\n";
      $out .= "</table>";
      $view = FALSE;
    }

    $username  = $arr["username"];
    $userclass = $arr["class"];  
  }
  else
  {
    $userid    = intval($CURUSER["id"]);
    $username  = htmlentities($CURUSER["username"]);
    $userclass = intval($CURUSER["class"]);
  }

  if ($view)
  {
    if ($userclass >= $MORE_UPLOAD) $maxbucketsize = $GLOBALS["MAX_BITBUCKET_SIZE_UPLOADER"];
    else $maxbucketsize = $GLOBALS["MAX_BITBUCKET_SIZE_USER"];

    $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
    $out .= "  <tr><td class=\"tabletitle\" style=\"text-align: center\">Bitbucket v3.0 von " . $username . "</td></tr>\n";
    $out .= "</table>\n";

    $out .= "<br>\n";

    if ($userid == $CURUSER["id"])
    {
      $out .= "<form method=\"post\" action=\"" . $_SERVER["PHP_SELF"] . "\" enctype=\"multipart/form-data\">\n";
      $out .= "<input type=\"hidden\" name=\"action\" value=\"upload\">\n";
      $out .= "<input type=\"hidden\" name=\"id\" value=\"" . $userid . "\">\n";
      $out .= "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"" . $GLOBALS["MAX_UPLOAD_FILESIZE"] . "\">\n";
      $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
      $out .= "  <tr>\n";
      $out .= "    <td colspan=\"2\" class=\"tabletitle\" style=\"text-align: center\"><b>Neue Datei hochladen</b> - Maximale Dateigr&ouml;&szlig;e: " . mksize($GLOBALS["MAX_UPLOAD_FILESIZE"]) . "</td>\n";
      $out .= "  </tr>\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tableb\">Datei</td><td class=\"tablea\"><input type=\"file\" name=\"file\" size=\"80\"><br>Es werden <u>KEINE</u> Sonderzeichen im Namen unterst&uuml;tzt!</td>\n";
      $out .= "  </tr>\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tableb\">Avatar</td><td class=\"tablea\"><input type=\"checkbox\" id=\"avatar\" name=\"is_avatar\" value=\"1\"><label for=\"avatar\"> Dieses Bild ist ein Avatar, und soll automatisch auf die richtige Gr&ouml;&szlig;e gebracht werden.</label><br><i>(Nur JPEG und PNG)</i></td>\n";
      $out .= "  </tr>\n";
      $out .= "  <tr>\n";
      $out .= "    <td class=\"tablea\" colspan=\"2\" style=\"text-align: center\"><input type=\"submit\" value=\"Hochladen\" class=\"btn\"></td>\n";
      $out .= "  </tr>\n";
      $out .= "</table>\n";
      $out .= "</form>\n";
    }
    else
    {
      $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
      $out .= "  <tr><td class=\"tablea\" style=\"text-align: center\"><a href=\"userdetails.php?id=" . $userid . "\">Zur&uuml;ck zum Profil von " . $username . "</a></td></tr>\n";
      $out .= "</table>\n";
    }
    $out .= "<br>\n";

    $res_val = mysql_query("SELECT COUNT(*) AS numfiles, SUM(size) AS size FROM bitbucket WHERE user = " . $userid . " LIMIT 1");
    $arr_val = mysql_fetch_array($res_val);
    $res     = mysql_query("SELECT * FROM bitbucket WHERE user = " . $userid);

    $out .= "<form action=\"".$_SERVER[PHP_SELF]."\" method=\"POST\">";
    $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
    $out .= "  <tr><td class=\"tabletitle\" style=\"text-align: center\" colspan=\"".$PICS_PER_ROW."\">Der BitBucket von <b>" . $username . "</b> enth&auml;lt momentan folgende Bilddateien</td></tr>\n";

    if ($arr_val["numfiles"] == 0)
      $out .= "  <tr><td class=\"tablea\" colspan=\"".$PICS_PER_ROW."\"><i>Es sind zurzeit keine Dateien im BitBucket vorhanden.</i></td></tr>\n";
    else
    {
      $out .= "<tr><td class=\"tablea\" colspan=\"".$PICS_PER_ROW."\"><center><input type=\"hidden\" value=\"delete\" name=\"action\"><input type=\"submit\" value=\"Markierte l�schen!\"/></center></td></tr>";
      $imgline = "  <tr>\n";
      $descline = "  <tr>\n";
      $cnt = 0;
      $rows = 0;
      $num  = mysql_num_rows($res);
      while ($fileinfo = mysql_fetch_array($res))
      {
        if ($cnt > 0 && $cnt%$PICS_PER_ROW == 0)
        {
       $fixedcols = 0;
       $rows++;
       $out .= $imgline  . "  </tr>\n";
       $out .= $descline . "  </tr>\n";
       $imgline  = "  <tr>\n";
       $descline = "  <tr>\n";
     }

     $bilder_ges_uebrig = $num-$rows*$PICS_PER_ROW;
     $aktuelles_bild = ($cnt+1)%$PICS_PER_ROW;

     if ($bilder_ges_uebrig >= $PICS_PER_ROW || $num <= $PICS_PER_ROW)
     $colspan = 1;
     else
     {
     if ($aktuelles_bild >= floor($bilder_ges_uebrig/2))
     $colspan = ceil( ($PICS_PER_ROW-$fixedcols++)/$bilder_ges_uebrig );
     else
     $colspan = floor($PICS_PER_ROW/$bilder_ges_uebrig);
     //echo "Bilder �brig: ".$bilder_ges_uebrig."<br>";
     //echo "Aktuelles Bild: ".$aktuelles_bild."<br>";
     //echo "Colspan: ".$colspan." --> ".$fixedcols." -->".($PICS_PER_ROW-($fixedcols-1))/$bilder_ges_uebrig."<br><br>";
     }

     $picid = $fileinfo["id"];
     $imgline  .= "    <td class=\"tablea\" colspan=\"".$colspan."\" style=\"text-align: center; vertical-align: middle;\"><a href=\"" . $GLOBALS["BITBUCKET_DIR"] . "/" . $fileinfo["filename"] . "\" rel=\"lightbox[bilder]\" title=\"" . htmlspecialchars($fileinfo["originalname"]) . "\"><img src=\"" . $GLOBALS["BITBUCKET_DIR"] . "/" . $fileinfo["filename"] . "\" width=\"100\" alt=\"" . htmlspecialchars($fileinfo["originalname"]) . "\" title=\"" . htmlspecialchars($fileinfo["originalname"]) . "\" border=\"0\" /></a></td>\n";
     $descline .= "    <td class=\"tableb\" colspan=\"".$colspan."\" style=\"text-align: center; vertical-align: top;\"><a href=\"" . $GLOBALS["BITBUCKET_DIR"] . "/" . $fileinfo["filename"] . "\">" . htmlspecialchars($fileinfo["originalname"]) . "</a><br>\n";
     $descline .= "(". mksize($fileinfo["size"]).") <a href=\"" . $_SERVER["PHP_SELF"] . "?action=delete" . (isset($_GET["id"]) ? "&amp;id=" . $userid . "&amp;" : "&amp;") . "fileid=" . $fileinfo["id"] . "\"><img src=\"" . $GLOBALS["PIC_BASE_URL"] . "editdelete.png\" width=\"16\" height=\"16\" alt=\"L&ouml;schen\" style=\"border:none; vertical-align:middle;\"></a><br>";
     $descline .= "<input name=\"delpic[]\" type=\"checkbox\" value=\"".$fileinfo["id"]."\"><font class=\"smallfont\"><b>Del</b></font></td>\n";     
        $cnt++;
      }
      $out .= $imgline  . "  </tr>\n";
      $out .= $descline . "  </tr>\n";
      $out .= "<tr><td class=\"tablea\" colspan=\"".$PICS_PER_ROW."\"><center><input type=\"hidden\" value=\"delete\" name=\"action\"><input type=\"submit\" value=\"Markierte l�schen!\"/></center></td></tr>";
    }
    
    $out .= "</table>\n";
    $out .= "</form>";
    $out .= "<br>\n";

    $out .= "<table summary=\"\" style=\"width:" . $TABLE_WIDTH . ";\" cellpadding=\"4\" cellspacing=\"1\" align=\"center\" border=\"0\" class=\"tableinborder\">\n";
    $out .= "  <tr><td class=\"tabletitle\" style=\"text-align: center\">BitBucket Speicherplatznutzung von <b>" . $username . "</b></td></tr>\n";

    $percent = min(300,round($arr_val["size"]/$maxbucketsize*100));
    $width = $percent * 4;

    $balken = "<tr><td style=\"padding: 0px; background-image: url('" . $GLOBALS["PIC_BASE_URL"] . "loadbarbg.gif'); background-repeat: repeat-x;\"><div style=\"padding:0px; width:300px; height:15px;\"><div style=\"border:none; width:" . $width . "px; height:15px; background-image:url('" . $GLOBALS["PIC_BASE_URL"] . "ryg-verlauf.jpg'); background-repeat:no-repeat;\"></div></div></td>";
    $info   = "<td>&nbsp;&nbsp;&nbsp;" . mksize($arr_val["size"]) . " von " . mksize($maxbucketsize) . " in " . $arr_val["numfiles"] . " Dateien belegt (" . $percent . "%)</td></tr>\n";

    $out .= "  <tr><td class=\"tablea\"><center><table style=\"text-align: center\">" . $balken . $info . "</table></center></td></tr>\n";
    $out .= "</table>\n";
  }
}


stdhead("Bitbucket v3.0" . (($username != "") ? " von " . $username : ""));

print ($out);

stdfoot();
?>