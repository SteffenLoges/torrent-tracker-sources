<?php
require_once "secrets.php";
/************************************************************
* Tracker configuration
* 
* Please read the comments before changing anything!
* Database configuration: see secrets.php
**************************************************************/
//mysql_connect($mysql_host, $mysql_user, $mysql_pass);
//mysql_select_db($mysql_db);
mysql_connect($mysql["host"], $mysql["user"], $mysql["pass"]);
mysql_select_db($mysql["db"]);

$g = mysql_query("SELECT name,wert FROM config");
while ($c = mysql_fetch_assoc($g))
{
$GLOBALS[$c["name"]] = $c["wert"];
}  

define (CLIENT_AUTH_IP, 0);
define (CLIENT_AUTH_PASSKEY, 1);

define (PASSKEY_USE_PARAM, 0);
define (PASSKEY_USE_SUBDOMAIN, 1);

define (DOWNLOAD_REWRITE, 0);
define (DOWNLOAD_ATTACHMENT, 1);

// Badwords in email addresses, matches everywhere
$GLOBALS["EMAIL_BADWORDS"] = array(
    "sofort-mail", 
    "lycos", 
    "yahoo", 
    "dfgh", 
    "hotmail", 
    "spamgourmet", 
    "trash-mail",
    "freenet.de",
    "rocketmail",
    "mailinator",
    "msn.com",
    "msn.de",
    "spammotel",
    "fakemail",
    "germanmail",
    "discardmail",
    "spacemail",
    "mail.ru",
    "mytrashmail",
    "jetable",
    "spam.la",
    // DynDNS.org Hosts anfang
    "homeip",
    "ath.cx",
    "blogdns",
    "dnsalias",
    "dvrdns",
    "dynalias",
    "dyndns",
    "game-host.org",
    "game-server.cc",
    "getmyip.com",
    "gotdns",
    "ham-radio-op.net",
    "homedns",
    "homeftp",
    "homelinux",
    "homeunix",
    "is-a-geek",
    "isa-geek",
    "kicks-ass",
    "merseine.nu",
    "mine.nu",
    "myphotos.cc",
    "podzone",
    "serveftp",
    "servegame",
    "shacknet.nu",
    // DynDNS.org Hosts ende
    "dyn.pl",
    "bbth3c",
);

// Array of banned peer ids. Match is done only at the beginning of the string.
$GLOBALS["BAN_PEERIDS"] = array(
    "A\x02\x06\x09-",
    "-�Z{�"
);

// Array of banned user agents, only exact matches
$GLOBALS["BAN_USERAGENTS"] = array(
    "Azureus 2.1.0.0",
    "Azureus 2.2.0.3_B1",
    "Azureus 2.2.0.3_B4",
    "Azureus 2.2.0.3_B29",
    "BitComet",
    "Python-urllib/2.0a1"
);

?>