<?

$file = $_SERVER["DOCUMENT_ROOT"]."/include/secrets.php"; // Zus�tzlicher / wegen Freehostern (kotz), Falls es doppelt wird macht es nix aus...

if (!file_exists($file))
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
<title>Installation</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?
if (!$_POST["step"])
{
?>
Installationsscript<br />	
Dieses Script soll ihnen helfen ihre Source zu Installieren und f�hrt die n�tigsten Dinge f�r sie aus, <br />
geben sie also in ihrem Interesse die richtigen Daten an<br />
<?
if (!@fopen($file,w))
echo "<span style='color:red'>Bitte geben sie dem include Ordner mindestens die Rechte 647, damit dieses Installationsprogramm alles N�tige zur Installation veranlassen kann.</span><br />
Rechte vergeben und dann:<br />"
?>
<form method="post" action="">
<input type="hidden" name="step" value="1" />
<input type="submit" value="Weiter" />
</form>
<?
@unlink($file);
}
elseif ($_POST["step"] == 1)
   {
   	if (@fopen($file,w)) 
   	{
   ?>
   <form method="post" action="">
   <input type="hidden" name="step" value="2" />
   Datenbankverbindung:<br />
   Host/IP: <input name="host" value="localhost" /> (Url oder IP) Standard: localhost<br />
   Datenbank: <input name="db" value="w3ctracker" />  (Datenbankname) Standard: w3ctracker <input type="radio" name="create" value="1" /> Datenbank erstellen <input type="radio" name="create" value="0" checked="checked" /> Datenbank bereits vorhanden   <br />
   Beachten sie, dass bei "Datenbank erstellen" der unten angegebene Benutzer die Rechte dazu hat und der Datenbankname keine Leerzeichen und Sonderzeichen aufweist!<br />
   Benutzername: <input name="user" value="root" />  (Benutzername der SQL-DB) Standard: root <br />
   Passwort: <input name="pass" value="" />  (Passwort der SQL-DB) <br />	
   <input type="submit" value="Weiter" />
   </form>
   <?
   @unlink($file);
   }
   else
   {
   ?>
   Zuerst die korrekten Rechte geben bitte -> <? echo $_SERVER["DOCUMENT_ROOT"]."include/"; ?> Ordner Rechte 647! <br />
   	<form method="post" action="">
   	<input type="hidden" name="step" value="1" />
   	<input type="submit" value="Ja OK" />
   	</form>
   	<?
   } 
  
  
   }
elseif ($_POST["step"] == 2)
   {
   	if (@mysql_connect($_POST["host"],$_POST["user"],$_POST["pass"]))
   	{
   		 echo "<span style='color:green'>Verbindung zur Datenbank erfolgreich hergestellt</span><br />";
   		if ($_POST["create"] == 1)
   		 if (mysql_query("CREATE DATABASE ".$_POST["db"]))
   		 {
   		 echo "<span style='color:green'>Datenbank erfolgreich erstellt</span><br />";
   		?>
   	 	<form method="post" action="">
      <input type="hidden" name="step" value="3" />
      <input type="hidden" name="host" value="<? echo $_POST["host"]; ?>" />
      <input type="hidden" name="db" value="<? echo $_POST["db"]; ?>" />
      <input type="hidden" name="user" value="<? echo $_POST["user"]; ?>" />
      <input type="hidden" name="pass" value="<? echo $_POST["pass"]; ?>" />
      <input type="submit" value="Einf�gen der Datenbankdaten" />
      </form>
      <?
   		 }
   		 else
   		 {
   	 	  ?>
   	 	  Die Rechte des Benutzers sind unzureichend um eine Datenbank zu erstellen!
   	   	<form method="post" action="">
        <input type="hidden" name="step" value="1" />
        <input type="submit" value="Zur�ck" />
        </form>
      <?
   		 }
   		 elseif (mysql_select_db($_POST["db"]))
   		 {
   		 echo "<span style='color:green'>Auswahl der Datenbank erfolgreich</span><br />";
   		?>
   	 	<form method="post" action="">
      <input type="hidden" name="step" value="3" />
      <input type="hidden" name="host" value="<? echo $_POST["host"]; ?>" />
      <input type="hidden" name="db" value="<? echo $_POST["db"]; ?>" />
      <input type="hidden" name="user" value="<? echo $_POST["user"]; ?>" />
      <input type="hidden" name="pass" value="<? echo $_POST["pass"]; ?>" />
      <input type="submit" value="Einf�gen der Datenbankdaten" />
      </form>
      <?
   		 }
   		 else
   		 {
   	 	?>
   	 	Die Datenbankdaten scheinen nicht zu stimmen, Host, Username und Passwort m�ssen richtig sein!
   	 	<form method="post" action="">
      <input type="hidden" name="step" value="1" />
      <input type="submit" value="Zur�ck" />
      </form>
      <?
   		 }
   	}
   	else
   	 {
   	 	?>
   	 	Die Datenbankdaten scheinen nicht zu stimmen, Host, Username und Passwort m�ssen richtig sein!
   	 	<form method="post" action="">
      <input type="hidden" name="step" value="1" />
      <input type="submit" value="Zur�ck" />
      </form>
      <?
   	 }
   }
elseif ($_POST["step"] == 3)
   {

   	mysql_connect($_POST["host"],$_POST["user"],$_POST["pass"]);
   	if (mysql_select_db($_POST["db"]))
   {
   $file2 = $_SERVER["DOCUMENT_ROOT"]."/include/w3c.sql"; // Zus�tzlicher / wegen Freehostern (kotz), Falls es doppelt wird macht es nix aus...

   $import = file_get_contents($file2);
   $import = preg_replace ("%/\*(.*)\*/%Us", '', $import);
   $import = preg_replace ("%^--(.*)\n%mU", '', $import);
   $import = preg_replace ("%^$\n%mU", '', $import);

   mysql_real_escape_string($import); 
   $import = explode (";", $import); 
   if ($_POST["retry"] != 1)
   {
   foreach ($import as $imp)
    {
    if ($imp != '' && $imp != ' ')
     mysql_query($imp);
    }
    $erg = mysql_fetch_assoc(mysql_query("SELECT wert FROM config WHERE name='SITE_ONLINE'"));
    if ($erg["wert"])
     mysql_query("UPDATE config SET wert='http://".$_SERVER["HTTP_HOST"]."' WHERE name='DEFAULTBASEURL'");
   }
    $erg2 = mysql_fetch_assoc(mysql_query("SELECT wert FROM config WHERE name='DEFAULTBASEURL'"));
    if ($erg2["wert"] == "http://".$_SERVER["HTTP_HOST"])
     {
     	if (!@unlink($file2))
      echo "<span style='color:red'>".$file2." konnte nicht gel�scht werden, bitte tun sie das aus Sicherheitsgr�nden manuell</span><br />";
      
      echo "<span style='color:green'>Daten erfolgreich eingetragen</span><br />";
      
      $secretcontent = '<?
      $mysql["host"] = "'.$_POST["host"].'";
      $mysql["user"] = "'.$_POST["user"].'";
      $mysql["pass"] = "'.$_POST["pass"].'";
      $mysql["db"]   = "'.$_POST["db"].'";
      ?>';
      $handle = @fopen($file,w);
       if (@fwrite($handle,$secretcontent))
         echo "<span style='color:green'>secrets.php erfolgreich gespeichert, Installation abgeschlossen</span><br />";
       else
       {
       	echo "<span style='color:red'>Secrets.php konnte nicht geschrieben werden, unzureichende Ordner/Benutzerrechte! Bitte geben sie dem Ordner include mindestens die Rechte 647 !</span><br />";
       ?>
   	 	<form method="post" action="">
      <input type="hidden" name="step" value="3" />
      <input type="hidden" name="retry" value="1" />
      <input type="hidden" name="host" value="<? echo $_POST["host"]; ?>" />
      <input type="hidden" name="db" value="<? echo $_POST["db"]; ?>" />
      <input type="hidden" name="user" value="<? echo $_POST["user"]; ?>" />
      <input type="hidden" name="pass" value="<? echo $_POST["pass"]; ?>" />
      <input type="submit" value="Nochmal versuchen" />
      </form>
      <?
       }
     }
     else
      echo "<span style='color:red'>Daten konnten nicht eingetragen werden, Unbekannter Fehler</span><br />";
   }
   else
    { 
    	?>
    	Leider ist ein Fehler aufgetreten, bitte probiere es nocheinmal.
    	<form method="post" action="">
      <input type="hidden" name="step" value="1" />
      <input type="submit" value="Zur�ck" />
      </form>
    	<?
    }
 
 
   }
?>
</body>
</html>
<?
die();
}
?>