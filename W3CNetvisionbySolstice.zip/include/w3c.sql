-- phpMyAdmin SQL Dump
-- version 2.9.1.1-Debian-10
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Erstellungszeit: 03. Januar 2010 um 16:56
-- Server Version: 5.0.32
-- PHP-Version: 5.2.0-8+etch13

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `accounts`
-- 

CREATE TABLE `accounts` (
  `userid` int(10) NOT NULL default '0',
  `chash` varchar(32) NOT NULL default '',
  `lastaccess` datetime NOT NULL default '0000-00-00 00:00:00',
  `username` varchar(64) NOT NULL default '',
  `email` varchar(128) NOT NULL default '',
  `baduser` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`userid`,`chash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `accounts`
-- 

INSERT INTO `accounts` (`userid`, `chash`, `lastaccess`, `username`, `email`, `baduser`) VALUES 
(1, 'e38fc791705e3fea7f5bcfc5c836c808', '2010-01-03 15:22:44', 'Solstice', '', 0);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `announcedelay`
-- 

CREATE TABLE `announcedelay` (
  `peer_id` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `first` int(10) unsigned NOT NULL default '0',
  `second` int(10) unsigned NOT NULL default '0',
  `quantity` bigint(20) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `announcedelay`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `avps`
-- 

CREATE TABLE `avps` (
  `arg` varchar(20) NOT NULL default '',
  `value_s` text NOT NULL,
  `value_i` int(11) NOT NULL default '0',
  `value_u` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `avps`
-- 

INSERT INTO `avps` (`arg`, `value_s`, `value_i`, `value_u`) VALUES 
('lastcleantime', '', 0, 1262528564),
('seeders', '', 0, 0),
('leechers', '', 0, 0);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `bans`
-- 

CREATE TABLE `bans` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `addedby` int(10) unsigned NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `first` int(11) default NULL,
  `last` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `first_last` (`first`,`last`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `bans`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `bitbucket`
-- 

CREATE TABLE `bitbucket` (
  `id` int(11) NOT NULL auto_increment,
  `user` int(11) NOT NULL default '0',
  `filename` varchar(40) NOT NULL default '',
  `size` int(11) NOT NULL default '0',
  `originalname` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

-- 
-- Daten f�r Tabelle `bitbucket`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `blocks`
-- 

CREATE TABLE `blocks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `blockid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`blockid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `blocks`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `casino_bank`
-- 

CREATE TABLE `casino_bank` (
  `userid` int(10) unsigned NOT NULL default '0',
  `passphrase` varchar(32) NOT NULL default '',
  `balance` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `casino_bank`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `categories`
-- 

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

-- 
-- Daten f�r Tabelle `categories`
-- 

INSERT INTO `categories` (`id`, `name`, `image`) VALUES 
(1, 'Software/PC ISO', 'cat_apps.gif'),
(4, 'Games/PC ISO', 'cat_games.gif'),
(5, 'Movies/SVCD', 'cat_movies3.gif'),
(6, 'Audio', 'cat_music.gif'),
(7, 'Serien', 'cat_episodes.gif'),
(9, 'Sonstiges', 'cat_misc.gif'),
(12, 'Games/Konsolen', 'cat_games3.gif'),
(23, 'Anime', 'cat_anime.gif'),
(19, 'Movies/XviD', 'cat_movies2.gif'),
(20, 'Movies/DVD-R', 'cat_movies4.gif'),
(21, 'Games/PC Rips', 'cat_games2.gif'),
(22, 'Software/Sonstiges', 'cat_apps2.gif'),
(24, 'H�rspiel/H�rbuch', 'cat_music2.gif'),
(25, 'Doku/Magazin', 'cat_documentation.gif'),
(26, 'Movies/(M)VCD', 'cat_movies5.gif');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `comments`
-- 

CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user` int(10) unsigned NOT NULL default '0',
  `torrent` int(10) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `ori_text` text NOT NULL,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `user` (`user`),
  KEY `torrent` (`torrent`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Daten f�r Tabelle `comments`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `completed`
-- 

CREATE TABLE `completed` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `torrent_id` int(11) NOT NULL default '0',
  `torrent_name` varchar(255) NOT NULL default '',
  `torrent_category` int(10) NOT NULL default '0',
  `complete_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `completed`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `config`
-- 

CREATE TABLE `config` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `wert` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `descr` text NOT NULL,
  `ordernum` int(11) default '0',
  `bereich` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79 ;

-- 
-- Daten f�r Tabelle `config`
-- 

INSERT INTO `config` (`id`, `name`, `wert`, `title`, `descr`, `ordernum`, `bereich`) VALUES 
(8, 'MAX_USERS', '3000', 'Max. Useranzahl', 'Gibt an wieviele User max. auf dieser Seite registriert sein k�nnen. Bei �berschreitung dieser Marke ist keine Registration mehr m�glich bis wieder Pl�tze frei werden', 0, 'Globale Seitenkonfiguration'),
(9, 'SITENAME', 'W3C NV by Solstice', 'Seiten Name', 'Repr�sentiert den Namen der Seite an div. Orten wie zb. im Browsertab u.v.m.', 0, 'Globale Seitenkonfiguration'),
(10, 'MAX_TORRENT_SIZE', '1024 * 1024', 'Max. Torrentgr��e', 'Diese Einstellung begrenzt die maximale Gr��e einer hochgeladenen Torrent-Metadatei. Da diese Dateien selten gr��er als 1 MB sind, kann die Standardeinstellung beibehalten werden.', 0, 'Trackerkonfiguration'),
(11, 'ANNOUNCE_INTERVAL', '60 * 20', 'Announce Updateintervall', 'Diese Option gibt einen Empfehlungswert f�r Reannounces an, also den Zeitraum, nach dem Clients einen erneuten Announce-Aufruf machen sollen. Leider beachten nur wenige Clients diese Vorgabe, und haben ein festes oder vom Benutzer definierbares Intervall. Aus diesem Grunde sollte die Zeit nicht weniger als 20 Minuten (1200 Sekunden) betragen, da sonst Benutzer von Clients mit l�ngerem festen Intervall dauernd aus der Peerliste entfernt werden.', 0, 'Trackerkonfiguration'),
(12, 'MINVOTES', '1', 'Min. Votes', 'Legt fest, wie viele Bewertungen ein Torrent bereits haben muss, damit die Wertung angezeigt wird. Standart: -> 1 <-', 0, 'Seitenkonfiguration'),
(13, 'CLIENT_AUTH', 'CLIENT_AUTH_PASSKEY', 'Benutzeridentifizierung der Announce', 'Legt die Art der Benutzeridentifizierung bei Announce-Aufrufen fest. CLIENT_AUTH_IP ist die alte Methode, die einen Benutzer anhand der IP identifiziert, die er beim Aufruf der Torrent-Seite hatte. Diese Methode hat den Nachteil, dass nur ein Benutzer pro IP den Tracker nutzen kann. CLIENT_AUTH_PASSKEY ist daher die neue, bevorzugte Methode, bei der in der Announce-URL ein eindeutiger Schl�ssel �bergeben wird, der einem Benutzer zugeordnet ist. Diese Methode kann jedoch mit einigen Clients zu Problemen f�hren, falls diese die Announce-URL nicht korrekt aufbauen. Standart: -> CLIENT_AUTH_PASSKEY <-', 0, 'Trackerkonfiguration'),
(14, 'PASSKEY_SOURCE', 'PASSKEY_USE_PARAM', 'Passkey Quelle', 'Gibt die Quelle f�r den Passkey an. Diese Option h�ngt eng mit der Einstellung PASSKEY_ANNOUNCE_URL zusammen, da sie vorgibt, ob der Passkey aus einem zus�tzlichen Parameter >passkey< oder aus der Subdomain ausgelesen wird. Da die Subdomain-Variante jedoch nur selten praktikabel ist, sollte diese Option auf PASSKEY_USE_PARAM stehen bleiben. Standart: -> PASSKEY_USE_PARAM <-', 0, 'Trackerkonfiguration'),
(15, 'DOWNLOAD_METHOD', 'DOWNLOAD_ATTACHMENT', 'Download Methode', 'Definiert die Download-Methode f�r Torrent-Dateien. Der Tracker bietet zwei M�glichkeiten an, eine Torrent-Datei herunterzuladen. Bei der Attachment-Methode wird eine spezielle Kombination von HTTP-Headern benutzt, um dem Browser mitzuteilen, dass die Daten wie ein eMail-Attachment behandelt werden sollen. Dies erm�glicht es, einen Dateinamen anzugeben, der nicht dem des aufgerufenen Scripts entspricht. Jedoch existieren einige Browser, die mit mit dieser Methode Probleme haben. Aus diesem Grund kann �ber die Option DOWNLOAD_REWRITE im Zusammenspiel mit einem korrekt konfigurierten Apache-Modul >mod_rewrite< eine URL simuliert werden, die dem Browser vort�uscht, tats�chlich eine .torrent-Datei herunterzuladen. Da die Konfiguration von mod_rewrite aber oft problematisch ist, sollte die Attachment-Methode benutzt werden. Standart: > DOWNLOAD_ATTACHMENT <', 0, 'Trackerkonfiguration'),
(16, 'DYNAMIC_RSS', 'TRUE', 'Dyn. Rss Feeds (True/False)', 'Schaltet, ob Dynamisches Rss erlaubt ist, oder nicht.', 0, 'Globale Seitenkonfiguration'),
(17, 'MAX_UPLOAD_FILESIZE', '1048576', 'Maximale Filegr��e', 'Maximale Gr��e einer Datei in Bytes, die in den BitBucket hochgeladen werden darf.', 0, 'Upload und Bitbucket'),
(18, 'MAX_BITBUCKET_SIZE_USER', '1048576', 'BitBucket Gr��e User', 'Maximale Gr��e des BitBuckets f�r einen normalen Benutzer in Bytes (R�nge unterhalb Uploader). Standart: > 1024 * 1024 <', 40, 'Upload und Bitbucket'),
(19, 'MAX_BITBUCKET_SIZE_UPLOADER', '5242880', 'BitBucket Gr��e Uploader', 'Maximale Gr��e des BitBuckets f�r Uploader oder h�her in Bytes. Standart: > 5 * 1024 * 1024 <', 30, 'Upload und Bitbucket'),
(20, 'BROWSE_CATS_PER_ROW', '5', 'Kategorien pro Zeile', 'Legt fest, wie viele Kategorien in der Torrent�bersicht pro Zeile angezeigt werden. Bei langen Kategorienamen kann der Wert reduziert werden, um Zeilenumbr�che zu vermeiden. Standart: > 5 < ', 0, 'Seitenkonfiguration'),
(21, 'ONLY_LEECHERS_WAIT', 'FALSE', 'Wartezeit Leecher', 'Legt fest, ob Wartezeiten nur gelten, wenn der Benutzer den Torrent noch nicht komplett hat. Ist diese Option auf Aktiviert gesetzt, k�nnen Benutzer den Torrent starten, wenn sie diesen fertig haben, bei Deaktiviert ist das nicht m�glich. Beachte aber, dass es m�glich ist, den Torrent dennoch zu leechen, sollte diese Option auf Aktiviert gesetzt sein! Standart: > Deaktiviert <', 0, 'Trackerkonfiguration'),
(22, 'NOWAITTIME_ONLYSEEDS', 'FALSE', 'Wartezeit Seeder', 'Wenn diese Option auf Aktiviert gesetzt wird, ist es auch bei Torrents, f�r die die Wartezeit explizit aufgehoben wurde, nicht m�glich, zu leechen, sofern man noch eine Wartezeit f�r diesen Torrent h�tte. Diese Option wird in der Regel immer auf Deaktiviert stehen, ansonsten gilt auch hier, dass es dennoch m�glich ist, zu cheaten, wenn diese auf Aktiviert gestellt wird. Standart: > Deaktiviert <', 0, 'Trackerkonfiguration'),
(23, 'WAIT_TIME_RULES', '0.2:2:0:48|0.4:4:0:24|0.6:6:0:12|0.9:8:0:6', 'Wartezeit / Regeln', 'Diese Option legt die Wartezeit-Regeln fest. Die Syntax der Regeln mag auf den ersten Blick verwirrend erscheinen, folgt aber einem Muster. Jede einzelne Regel besteht aus vier Zahlen, durch Doppelpunkte getrennt. Mehrere Regeln werden durch einen senkrechten Balken | voneinander getrennt. Die vier Zahlen haben, in dieser Reihenfolge, folgende Bedeutung:<br> <br>* Maximale Ratio, bis zu der diese Regel gilt (Punkt ist Dezimaltrennzeichen!)<br>* Maximaler Upload in GB, bis zu dem diese Regel gilt (Punkt ist Dezimaltrennzeichen!) <br>* Maximale Registrierungszeit, die der Benutzer haben darf, damit diese Regel wirkt <br>* Wartezeit in Stunden. <br><br>Jede Regel wird mit dem Profil des betreffenden Benutzers abgeglichen, und dann am Ende die h�chste Wartezeit verwendet, die eine zutreffende Regel geliefert hat. Dies bedeutet, wenn zwei Regeln zutreffen, und eine 6 und die andere 12 Stunden Wartezeit festlegen, hat der Benutzer 12 Stunden Wartezeit. Die Registrierungszeit kann entweder 0 oder * sein, was wie >unendlich< ausgelegt werden kann, sprich dieser Teil trifft immer zu. Oder die Zeit kann mittels des Formates #w#d angegeben werden, wobei # eine Zahl repr�sentiert. Es k�nnen auch nur Tage oder Wochen angegeben werden. Beispiele: 2w, 2w3d, 5d.', 0, 'Torrent Regelwerke'),
(24, 'TORRENT_RULES', '0:0:10:2:12|1.01:5:10:3:13|2.01:20:10:4:14', 'Torrent / Regeln', 'Diese Option kontrolliert die Torrent-Begrenzung nach Ratio und Upload-Menge. Wie bei den Wartezeit-Regeln gilt auch hier eine spezielle Syntax. Jede einzelne Regel besteht aus f�nf Zahlen, durch Doppelpunkte getrennt. Mehrere Regeln werden durch einen senkrechten Balken | voneinander getrennt. Die f�nf Zahlen haben, in dieser Reihenfolge, folgende Bedeutung: <br><br>* Mindest-Ratio, damit dieses Limit gilt (Punkt ist Dezimaltrennzeichen!)<br>* Mindest-Upload in GB, damit dieses Limit gilt (Punkt ist Dezimaltrennzeichen!)<br>* Maximale Anzahl Seeds<br>* Maximale Anzahl Leeches<br>* Maximale Anzahl aktiver Torrents insgesamt (Seeds+Leeches)<br><br>Die Regeln werden mit dem Benutzerprofil verglichen, und diejenige mit der h�chsten Zahl gesamter Torrents, die auf das Profil des Benutzers passt, wird verwendet.', 0, 'Torrent Regelwerke'),
(25, 'MAX_PASSKEY_IPS', '5', 'Ips pro passkey', 'Legt fest, wie viele verschiedene IPs ein Benutzer gleichzeitig nutzen darf. Zu den IPs z�hlen sowohl Seitenbesucher als auch aktive Torrents (Peer-IPs). Ist das Limit bereits erreicht, wird dem Benutzer der Zugang zur Seite verwehrt. Diese Option dient dazu, das PassKey-Sharing zu vermeiden. Standart: > 5 <', 0, 'Trackerkonfiguration'),
(26, 'RATIOFAKER_THRESH', '1024 * 1024', 'Ratiofaker Erkennung', 'Legt fest, ab welcher �bertragungsrate ein Ratiofaker-Eintrag im Benutzerprofil erstellt wird. Bei Trackern, die kein Speedlimit haben, sollte dieser Wert auf ca. 5 MB pro Sekunde gesetzt werden. Ratiofaker-Tools haben normalerweise Uploadraten im GB/s-Bereich.', 0, 'Trackerkonfiguration'),
(27, 'ALWAYS_DEEP_CLEAN', 'TRUE', 'Gr�ndliche Reinigung', 'Ist diese Option auf Aktiviert gesetzt, wird immer ein sogenanntes >Deep<-Cleaning durchgef�hrt. Dabei werden auch verwaiste Dateien (Torrents, Bitbucket-Inhalte) entfernt und Datenbank-Cleanups durchgef�hrt. Da dieses Verfahren recht zeitintensiv ist, sollte es auf gr��eren Trackern lediglich manuell �ber den Aufruf hxxp://tracker/docleanup.php?deep=1 von einem angemeldeten Administrator oder SysOp durchgef�hrt werden. Standart: >Aktiviert<', 0, 'Globale Seitenkonfiguration'),
(28, 'MAX_DEAD_TORRENT_TIME', '2', 'Max. Torrent Deadtime', 'Gibt an wielange ein Torrent ohne Seeder weiterexistieren kann (in Tagen), bevor er automatisch vom System gel�scht wird.', 0, 'Trackerkonfiguration'),
(29, 'MAX_TORRENT_TTL', '28', 'Torrent Lebenszeit (TTL)(Tage)', 'Legt fest, wie lange ein Torrent >lebt< (Time To Live). ein Torrent wird als >lebendig< angesehen, solange er nicht als Tot markiert wurde, und die mit dieser Option festgelegte Zeit nicht abgelaufen ist. Solange ein Torrent also noch Peers hat, wird er nicht gel�scht. Standart > 28 <', 0, 'Trackerkonfiguration'),
(30, 'SIGNUP_TIMEOUT', '48', 'Anmeldefrist (in h)', 'Gibt an wielange ein User Zeit hat, auf die Best�tigungs E-mail zu antworten, bis der Account wieder ung�ltig wird.', 0, 'Globale Seitenkonfiguration'),
(31, 'INACTIVE_TIMEOUT', '30', 'Inaktive Accounts l�schung (Tage)', 'Legt die Anzahl Tage fest, nach denen ein inaktiver Benutzer vom Tracker gel�scht wird. Account ab Rang >VIP< aufw�rts werden nicht automatisch gel�scht! Standart: > 30 <', 0, 'Seitenkonfiguration'),
(32, 'DISABLED_TIMEOUT', '3', 'Gnadenfrist (Tage)', 'Legt die Anzahl Tage fest, nach denen ein deaktivierter Account gel�scht wird. Dies erm�glicht es, eine Art >Einspruchsfrist< zu gew�hren, um so den Account bei Bedarf wieder reaktivieren zu k�nnen. Standart: > 3 <', 0, 'Seitenkonfiguration'),
(34, 'AUTOCLEAN_INTERVAL', '3000 * 60', 'Autoclean Interval (Sekunden)', 'Legt fest, wie oft das Cleanup-Script aufgerufen wird. Dieses Script entfernt inaktive Peers, Torrents und Benutzer, und f�hrt noch andere regelm��ig anfallenden Arbeiten aus. Sollte der Tracker sehr gro� und stark besucht sein, sollte der Wert h�her gesetzt werden. Beachte aber, dass dann verwaiste Peers eventuell erst nach l�ngerer Zeit entfernt werden. Standart: > 3000 * 60 <', 0, 'Globale Seitenkonfiguration'),
(35, 'PM_PRUNE_DAYS', '0', 'PM Autodelete (Tage)', 'Legt fest, ob Private Nachrichten nach einer bestimmten Anzahl Tage automatisch gel�scht werden sollen, unabh�ngig von der Benutzereinstellung. Die Angabe von 0 deaktiviert diese Funktion, und erm�glicht es, Nachrichten unbegrenzt zu speichern. Standart: > 0 <', 0, 'Seitenkonfiguration'),
(36, 'TORRENT_DIR', 'torrents', 'Torrent Ordner', 'Gibt den Ordner an, in dem alle hochgeladenen .torrent-Dateien abgelegt werden. Der Webserver MUSS Schreibzugriff auf diesen Ordner haben! Standart: > torrents <', 0, 'Ordnerkonfiguration'),
(37, 'BITBUCKET_DIR', 'bitbucket', 'Bitbucket Ordner', 'Dieser Ordner enth�lt alle BitBucket-Uploads, NFO-bilder sowie die Torrent-Bilder. Dieser Ordner MUSS ein Unterordner des Tracker-Roots sein, und MUSS �ffentlich lesbar sein (via Browser). Ebenfalls MUSS der Webserver auf diesen Ordner Schreibzugriff haben. Ein Referrer-Check f�r diesen Ordner z.B. via .htaccess/mod_rewrite ist empfehlenswert, um Hotlinking zu erschweren. Standart: > bitbucket <', 0, 'Ordnerkonfiguration'),
(38, 'PIC_BASE_URL', 'pic/', 'Grafiken Verzeichnis', 'Gibt die URL an, unter der alle festen Interface-Bilder gespeichert sind z.B. Styles, Smilies, ... Die URL MUSS einen abschlie�enden Slash enthalten! Standart: > pic/ <', 0, 'Ordnerkonfiguration'),
(39, 'PORTAL_LINK', 'board/', 'Forumverzeichnis', 'Gibt die URL an, mittels derer das Tracker-Portal erreichbar ist. Ist diese Option leer, wird der Portal-Link nicht im Men� angezeigt. Standart: > board/ <', 0, 'Ordnerkonfiguration'),
(40, 'ANNOUNCE_URLS1', 'http://mytracker.example.com:80/announce.php', 'Announce URL', 'Dieses Feld enth�lt alle f�r diesen Tracker akzeptierten Announce-URLs. Zwar ist die Angabe bei Verwendung von Passkeys �berfl�ssig, da die Announce-URL im Torrent beim Download ersetzt wird, aber die URL wird dennoch gepr�ft. Der erste Eintrag in diesem Array wird auf der Upload-Seite als Announce-URL angezeigt.', 0, 'Trackerkonfiguration'),
(41, 'ANNOUNCE_URLS', 'http://mytracker.example.com/announce.php', 'Announce URL', 'Dieses Feld enth�lt alle f�r diesen Tracker akzeptierten Announce-URLs. Zwar ist die Angabe bei Verwendung von Passkeys �berfl�ssig, da die Announce-URL im Torrent beim Download ersetzt wird, aber die URL wird dennoch gepr�ft. Der erste Eintrag in diesem Array wird auf der Upload-Seite als Announce-URL angezeigt.', 0, 'Trackerkonfiguration'),
(42, 'PASSKEY_ANNOUNCE_URL', 'http://mytracker.example.com:80/announce.php?passkey={KEY}', 'Announce URL mit Platzhalter', 'Announce URL mit Platzhalter.', 0, 'Trackerkonfiguration'),
(43, 'DEFAULTBASEURL', '', 'Tracker URL', 'Dieses Feld enth�lt eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschlie�ender Slash (/) angeh�ngt werden!', 0, 'Globale Seitenkonfiguration'),
(44, 'TRACKERDOMAINS', '', 'Trackerdomains 1', 'Dieses Feld enth�lt eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschlie�ender Slash (/) angeh�ngt werden!', 0, 'Trackerkonfiguration'),
(45, 'TRACKERDOMAINS1', '', 'Trackerdomains 2', 'Dieses Feld enth�lt eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschlie�ender Slash (/) angeh�ngt werden!', 0, 'Trackerkonfiguration'),
(46, 'TRACKERDOMAINS2', '', 'Trackerdomains 3', 'Dieses Feld enth�lt eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschlie�ender Slash (/) angeh�ngt werden!', 0, 'Trackerkonfiguration'),
(47, 'TRACKERDOMAINS3', '', 'Trackerdomains 4', 'Dieses Feld enth�lt eine Liste aller Domains, unter denen der Tracker erreichbar ist. Dieses Feld wird vom Redirector-Script verwendet, um zwischen lokalen und externen Links zu unterscheiden. Da dies keine URL ist, darf kein http:// vorangestellt, und kein abschlie�ender Slash (/) angeh�ngt werden!', 0, 'Trackerkonfiguration'),
(48, 'SITEEMAIL', 'noreply@mytracker.example.com', 'Administrator Email', 'EMail-Adresse des Teams oder des Besitzers! Alle EMails z.B. Registrierungsbenachrichtigungen haben als Absender diese Adresse.', 0, 'Seitenkonfiguration'),
(64, 'SITE_ONLINE', '1', 'Seite Aktiv (Ja = 1/Nein = 0)', 'Gibt an ob die Seite aktiviert ist.\r\nAchtung! Bei 0 ist diese Konfigurationsoberfl�che nicht mehr verf�gbar!', 0, 'Globale Seitenkonfiguration'),
(63, 'MEMBERSONLY', 'TRUE', 'Nur Angemeldete User', 'Einstellung ob Nur angemeldete User diese Seite Nutzen k�nnen.\r\nMomentan wird keine andere einstellung als true unterst�tzt.', 0, 'Globale Seitenkonfiguration'),
(65, 'proofcodeon', 'false', 'Captcha einschalten?', 'Mit dieser Einstellung (true/false) wird das Captcha an und ausgeschalten', 0, 'Globale Seitenkonfiguration'),
(66, 'emailvalidation', 'false', 'Email Best�tigung', 'Mit dieser einstellung wird festgelegt ob Neuregistrierte erst eine Email best�tigen m�ssen bevor sie freigeschalten werden (true/false)', 0, 'Globale Seitenkonfiguration'),
(67, 'EMAIL_BADWORDS_CHECKING', 'false', 'Badword Check bei Emails', 'Legt fest, ob die Email bei der Registierung auf evtl Spammail getestet werden soll. (true/false)', 0, 'Globale Seitenkonfiguration'),
(68, 'loginreturnto', 'index.php', 'Nach Login auf die Seite:', 'Seite auf die der User nach dem Login geleitet werden soll.', 0, 'Globale Seitenkonfiguration'),
(69, 'SMTP_MAIL', '', 'Smtp Administrator Email', 'Versende Account der SMTP Emails', 50, 'SMTP Konfiguration'),
(70, 'SMTP_USERID', '', 'Smtp User ID', 'ID des Smtp User Accounts.\r\nBei Zweifeln beim Provider nachfragen.', 40, 'SMTP Konfiguration'),
(71, 'SMTP_PASS', '', 'Smtp User Passwort', 'Passwort zum connecten zum Smtp Account', 30, 'SMTP Konfiguration'),
(72, 'SMTP_MAILSERVER', '', 'Smtp Mailserver', 'Mailserver des Postausgangs f�r SMTP. Bei Zweifeln beim Provider fragen.', 20, 'SMTP Konfiguration'),
(73, 'SMTP_PORT', '25', 'Smtp Port', 'Smtp-port beim Provider.\r\nStandardm�ssig fast �berall Port 25.', 10, 'SMTP Konfiguration'),
(74, 'STANDARDW3C', '<img src=''include/W3C/w3chtml.png'' alt=''W3C Html''> <img src=''include/W3C/vcss.png'' alt=''W3C Css''>', 'Html f�r Seitenauszeichnungen', 'Html zur Anzeige von Auszeichnungen der Seite im Footer', 0, 'Seitenkonfiguration'),
(75, 'MODIFIER', '', 'Coder und Designer der Seite', 'Zb. modified by *Codername*', 0, 'Seitenkonfiguration'),
(77, 'memberspublic', 'no', 'Aktive Mitglieder �ffentlich', 'Ob Aktive Mitglieder �ffentlich angezeigt werden sollen. (yes/no)', 0, 'Seitenkonfiguration'),
(76, 'newspublic', 'no', 'News �ffentlich? (yes/no)', 'Ob die News f�r unangemeldete einsehbar sind.', 0, 'Seitenkonfiguration');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `countries`
-- 

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `flagpic` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=106 ;

-- 
-- Daten f�r Tabelle `countries`
-- 

INSERT INTO `countries` (`id`, `name`, `flagpic`) VALUES 
(1, 'Sweden', 'sweden.gif'),
(2, 'United States of America', 'usa.gif'),
(3, 'Russia', 'russia.gif'),
(4, 'Finland', 'finland.gif'),
(5, 'Canada', 'canada.gif'),
(6, 'France', 'france.gif'),
(7, 'Germany', 'germany.gif'),
(8, 'China', 'china.gif'),
(9, 'Italy', 'italy.gif'),
(10, 'Denmark', 'denmark.gif'),
(11, 'Norway', 'norway.gif'),
(12, 'United Kingdom', 'uk.gif'),
(13, 'Ireland', 'ireland.gif'),
(14, 'Poland', 'poland.gif'),
(15, 'Netherlands', 'netherlands.gif'),
(16, 'Belgium', 'belgium.gif'),
(17, 'Japan', 'japan.gif'),
(18, 'Brazil', 'brazil.gif'),
(19, 'Argentina', 'argentina.gif'),
(20, 'Australia', 'australia.gif'),
(21, 'New Zealand', 'newzealand.gif'),
(23, 'Spain', 'spain.gif'),
(24, 'Portugal', 'portugal.gif'),
(25, 'Mexico', 'mexico.gif'),
(26, 'Singapore', 'singapore.gif'),
(70, 'India', 'india.gif'),
(65, 'Albania', 'albania.gif'),
(29, 'South Africa', 'southafrica.gif'),
(30, 'South Korea', 'southkorea.gif'),
(31, 'Jamaica', 'jamaica.gif'),
(32, 'Luxembourg', 'luxembourg.gif'),
(33, 'Hong Kong', 'hongkong.gif'),
(34, 'Belize', 'belize.gif'),
(35, 'Algeria', 'algeria.gif'),
(36, 'Angola', 'angola.gif'),
(37, 'Austria', 'austria.gif'),
(38, 'Yugoslavia', 'yugoslavia.gif'),
(39, 'Western Samoa', 'westernsamoa.gif'),
(40, 'Malaysia', 'malaysia.gif'),
(41, 'Dominican Republic', 'dominicanrep.gif'),
(42, 'Greece', 'greece.gif'),
(43, 'Guatemala', 'guatemala.gif'),
(44, 'Israel', 'israel.gif'),
(45, 'Pakistan', 'pakistan.gif'),
(46, 'Czech Republic', 'czechrep.gif'),
(47, 'Serbia', 'serbia.gif'),
(48, 'Seychelles', 'seychelles.gif'),
(49, 'Taiwan', 'taiwan.gif'),
(50, 'Puerto Rico', 'puertorico.gif'),
(51, 'Chile', 'chile.gif'),
(52, 'Cuba', 'cuba.gif'),
(53, 'Congo', 'congo.gif'),
(54, 'Afghanistan', 'afghanistan.gif'),
(55, 'Turkey', 'turkey.gif'),
(56, 'Uzbekistan', 'uzbekistan.gif'),
(57, 'Switzerland', 'switzerland.gif'),
(58, 'Kiribati', 'kiribati.gif'),
(59, 'Philippines', 'philippines.gif'),
(60, 'Burkina Faso', 'burkinafaso.gif'),
(61, 'Nigeria', 'nigeria.gif'),
(62, 'Iceland', 'iceland.gif'),
(63, 'Nauru', 'nauru.gif'),
(64, 'Slovenia', 'slovenia.gif'),
(66, 'Turkmenistan', 'turkmenistan.gif'),
(67, 'Bosnia Herzegovina', 'bosniaherzegovina.gif'),
(68, 'Andorra', 'andorra.gif'),
(69, 'Lithuania', 'lithuania.gif'),
(71, 'Netherlands Antilles', 'nethantilles.gif'),
(72, 'Ukraine', 'ukraine.gif'),
(73, 'Venezuela', 'venezuela.gif'),
(74, 'Hungary', 'hungary.gif'),
(75, 'Romania', 'romania.gif'),
(76, 'Vanuatu', 'vanuatu.gif'),
(77, 'Vietnam', 'vietnam.gif'),
(78, 'Trinidad &amp; Tobago', 'trinidadandtobago.gif'),
(79, 'Honduras', 'honduras.gif'),
(80, 'Kyrgyzstan', 'kyrgyzstan.gif'),
(81, 'Ecuador', 'ecuador.gif'),
(82, 'Bahamas', 'bahamas.gif'),
(83, 'Peru', 'peru.gif'),
(84, 'Cambodia', 'cambodia.gif'),
(85, 'Barbados', 'barbados.gif'),
(86, 'Bangladesh', 'bangladesh.gif'),
(87, 'Laos', 'laos.gif'),
(88, 'Uruguay', 'uruguay.gif'),
(89, 'Antigua Barbuda', 'antiguabarbuda.gif'),
(90, 'Paraguay', 'paraguay.gif'),
(93, 'Thailand', 'thailand.gif'),
(92, 'Union of Soviet Socialist Republics', 'ussr.gif'),
(94, 'Senegal', 'senegal.gif'),
(95, 'Togo', 'togo.gif'),
(96, 'North Korea', 'northkorea.gif'),
(97, 'Croatia', 'croatia.gif'),
(98, 'Estonia', 'estonia.gif'),
(99, 'Colombia', 'colombia.gif'),
(100, 'Lebanon', 'lebanon.gif'),
(101, 'Latvia', 'latvia.gif'),
(102, 'Costa Rica', 'costarica.gif'),
(103, 'Egypt', 'egypt.gif'),
(104, 'Bulgaria', 'bulgaria.gif'),
(105, 'Isla de Muerte', 'jollyroger.gif');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `files`
-- 

CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `size` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `torrent` (`torrent`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=138 ;

-- 
-- Daten f�r Tabelle `files`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `forums`
-- 

CREATE TABLE `forums` (
  `sort` tinyint(3) unsigned NOT NULL default '0',
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `description` varchar(200) default NULL,
  `minclassread` tinyint(3) unsigned NOT NULL default '0',
  `minclasswrite` tinyint(3) unsigned NOT NULL default '0',
  `postcount` int(10) unsigned NOT NULL default '0',
  `topiccount` int(10) unsigned NOT NULL default '0',
  `minclasscreate` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- 
-- Daten f�r Tabelle `forums`
-- 

INSERT INTO `forums` (`sort`, `id`, `name`, `description`, `minclassread`, `minclasswrite`, `postcount`, `topiccount`, `minclasscreate`) VALUES 
(3, 1, 'Support', 'Hier bekommt ihr Hilfe f�r alle Trackerprobleme, die NICHT in der FAQ beschrieben sind.', 0, 0, 0, 0, 0),
(4, 2, 'Support for English Users', 'If you are an english speaking user and have a question or a problem, you can post it here.', 0, 0, 0, 0, 0),
(0, 3, 'SysOp-Talk', 'SysOps willkommen, alle anderen m�ssen draussen bleiben ;)', 6, 6, 0, 0, 6),
(1, 4, 'Mod-Talk', '', 4, 4, 0, 0, 4),
(2, 5, 'Uploader-Talk', 'Falls die Uploader untereinander etwas besprechen m�ssen', 3, 3, 0, 0, 3),
(0, 6, 'Off Topic', '', 0, 0, 0, 0, 0),
(6, 7, 'Ich k�nnte anbieten', 'Der Name sagt wohl alles ;)', 0, 0, 0, 0, 0),
(7, 8, 'Umfragen', 'Hier k�nnt ihr �ber die aktuelle Umfrage diskutieren', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `friends`
-- 

CREATE TABLE `friends` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `friendid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userfriend` (`userid`,`friendid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `friends`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `messages`
-- 

CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `sender` int(10) unsigned NOT NULL default '0',
  `receiver` int(10) unsigned NOT NULL default '0',
  `folder_in` int(10) NOT NULL default '0',
  `folder_out` int(10) NOT NULL default '0',
  `added` datetime default NULL,
  `subject` varchar(255) NOT NULL default '(Kein Betreff)',
  `msg` text,
  `unread` enum('yes','no') NOT NULL default 'yes',
  `poster` bigint(20) unsigned NOT NULL default '0',
  `mod_flag` enum('','open','closed') NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `receiver` (`receiver`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Daten f�r Tabelle `messages`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `modcomments`
-- 

CREATE TABLE `modcomments` (
  `id` int(11) NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `userid` int(10) unsigned NOT NULL default '0',
  `moduid` int(10) unsigned NOT NULL default '0',
  `txt` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=78 ;

-- 
-- Daten f�r Tabelle `modcomments`
-- 

INSERT INTO `modcomments` (`id`, `added`, `userid`, `moduid`, `txt`) VALUES 
(64, '2010-01-03 15:01:42', 1, 1, 'Titel ge�ndert auf ''Source Coder''.');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `news`
-- 

CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `title` varchar(255) NOT NULL default '',
  `body` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Daten f�r Tabelle `news`
-- 

INSERT INTO `news` (`id`, `userid`, `added`, `title`, `body`) VALUES 
(1, 1, '2008-11-13 09:42:22', 'testnews', 'hi');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `nowait`
-- 

CREATE TABLE `nowait` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `torrent_id` int(10) unsigned NOT NULL default '0',
  `status` enum('pending','granted','rejected') NOT NULL default 'pending',
  `grantor` int(10) NOT NULL default '0',
  `msg` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `nowait`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `peers`
-- 

CREATE TABLE `peers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `torrent` int(10) unsigned NOT NULL default '0',
  `peer_id` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `ip` varchar(64) NOT NULL default '',
  `port` smallint(5) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `to_go` bigint(20) unsigned NOT NULL default '0',
  `seeder` enum('yes','no') NOT NULL default 'no',
  `started` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `connectable` enum('yes','no') NOT NULL default 'yes',
  `userid` int(10) unsigned NOT NULL default '0',
  `agent` varchar(60) NOT NULL default '',
  `finishedat` int(10) unsigned NOT NULL default '0',
  `downloadoffset` bigint(20) unsigned NOT NULL default '0',
  `uploadoffset` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `torrent_peer_id` (`torrent`,`peer_id`),
  KEY `torrent` (`torrent`),
  KEY `torrent_seeder` (`torrent`,`seeder`),
  KEY `last_action` (`last_action`),
  KEY `connectable` (`connectable`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Daten f�r Tabelle `peers`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `pmfolders`
-- 

CREATE TABLE `pmfolders` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `parent` int(10) unsigned NOT NULL default '0',
  `owner` int(10) unsigned NOT NULL default '0',
  `name` varchar(128) NOT NULL default '',
  `sortfield` varchar(64) NOT NULL default 'added',
  `sortorder` varchar(4) NOT NULL default 'DESC',
  `prunedays` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- 
-- Daten f�r Tabelle `pmfolders`
-- 

INSERT INTO `pmfolders` (`id`, `parent`, `owner`, `name`, `sortfield`, `sortorder`, `prunedays`) VALUES 
(1, 0, 1, '__inbox', 'added', 'DESC', 0),
(2, 0, 1, '__outbox', 'added', 'DESC', 0),
(3, 0, 1, '__system', 'added', 'DESC', 0),
(4, 0, 1, '__mod', 'added', 'DESC', 0),
(5, 0, 3, '__inbox', 'added', 'DESC', 0),
(6, 0, 3, '__outbox', 'added', 'DESC', 0),
(7, 0, 3, '__system', 'added', 'DESC', 0),
(8, 0, 3, '__mod', 'added', 'DESC', 0);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `pollanswers`
-- 

CREATE TABLE `pollanswers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pollid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `selection` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`),
  KEY `selection` (`selection`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `pollanswers`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `polls`
-- 

CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `question` varchar(255) NOT NULL default '',
  `option0` varchar(150) NOT NULL default '',
  `option1` varchar(150) NOT NULL default '',
  `option2` varchar(150) NOT NULL default '',
  `option3` varchar(150) NOT NULL default '',
  `option4` varchar(150) NOT NULL default '',
  `option5` varchar(150) NOT NULL default '',
  `option6` varchar(150) NOT NULL default '',
  `option7` varchar(150) NOT NULL default '',
  `option8` varchar(150) NOT NULL default '',
  `option9` varchar(150) NOT NULL default '',
  `option10` varchar(150) NOT NULL default '',
  `option11` varchar(150) NOT NULL default '',
  `option12` varchar(150) NOT NULL default '',
  `option13` varchar(150) NOT NULL default '',
  `option14` varchar(150) NOT NULL default '',
  `option15` varchar(150) NOT NULL default '',
  `option16` varchar(150) NOT NULL default '',
  `option17` varchar(150) NOT NULL default '',
  `option18` varchar(150) NOT NULL default '',
  `option19` varchar(150) NOT NULL default '',
  `sort` enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `polls`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `posts`
-- 

CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `topicid` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `added` datetime default NULL,
  `body` text,
  `editedby` int(10) unsigned NOT NULL default '0',
  `editedat` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `userid` (`userid`),
  FULLTEXT KEY `body` (`body`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `posts`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `ratiostats`
-- 

CREATE TABLE `ratiostats` (
  `userid` int(10) unsigned NOT NULL default '0',
  `timecode` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` enum('daily','hourly') NOT NULL default 'hourly',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`userid`,`timecode`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `ratiostats`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `readposts`
-- 

CREATE TABLE `readposts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `topicid` int(10) unsigned NOT NULL default '0',
  `lastpostread` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`id`),
  KEY `topicid` (`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `readposts`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `shoutbox`
-- 

CREATE TABLE `shoutbox` (
  `id` smallint(6) NOT NULL auto_increment,
  `userid` smallint(6) NOT NULL default '0',
  `username` varchar(25) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  `text` text NOT NULL,
  `visible` enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=323 ;

-- 
-- Daten f�r Tabelle `shoutbox`
-- 

INSERT INTO `shoutbox` (`id`, `userid`, `username`, `date`, `text`, `visible`) VALUES 
(322, 1, 'Solstice', 1262595604, '[rain]Viel Spass mit meiner �berarbeiteten W3C NV-Source![/rain]', 'yes');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `sitelog`
-- 

CREATE TABLE `sitelog` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `typ` enum('torrentupload','torrentedit','torrentdelete','promotion','demotion','addwarn','remwarn','accenabled','accdisabled','accdeleted','waitgrant','waitreject','passkeyreset','torrentgranted') NOT NULL default 'torrentupload',
  `added` datetime default NULL,
  `txt` text,
  PRIMARY KEY  (`id`),
  KEY `added` (`added`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

-- 
-- Daten f�r Tabelle `sitelog`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `startstoplog`
-- 

CREATE TABLE `startstoplog` (
  `userid` int(10) NOT NULL default '0',
  `event` enum('start','stop') NOT NULL default 'start',
  `datetime` datetime NOT NULL default '0000-00-00 00:00:00',
  `torrent` int(10) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  `peerid` varchar(20) NOT NULL default '',
  `useragent` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `startstoplog`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `stylesheets`
-- 

CREATE TABLE `stylesheets` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uri` varchar(255) NOT NULL default '',
  `name` varchar(64) NOT NULL default '',
  `default` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Daten f�r Tabelle `stylesheets`
-- 

INSERT INTO `stylesheets` (`id`, `uri`, `name`, `default`) VALUES 
(2, 'coolblue', 'CoolBlue', 'yes'),
(3, 'nightshift', 'Nightshift', 'no'),
(1, 'attraction', 'Attraction', 'no'),
(4, 'luminair', 'Luminair', 'no'),
(5, 'poison', 'Poison', 'no'),
(6, 'the_shining', 'The Shining', 'no');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `test`
-- 

CREATE TABLE `test` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `type` enum('radio','checkbox') NOT NULL default 'radio',
  `question` text NOT NULL,
  `answers` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Daten f�r Tabelle `test`
-- 

INSERT INTO `test` (`id`, `type`, `question`, `answers`) VALUES 
(1, 'checkbox', 'Was darf ich in meinem BitBucket speichern?', 'a:6:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:59:"Filmplakate, CD-Covers und Sample-Screenshots f�r Releases.";s:7:"correct";i:1;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:93:"Dateien und Downloads aller Art, falls mein Free-Webspace bei Arcor etc. nicht mehr ausreicht";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:74:"Nur Bilder, jedoch keine mit pornographischen oder gewaltt�tigen Inhalten.";s:7:"correct";i:1;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:69:"Bilder, Videos und MP3s, jedoch nur bis zu einer Dateigr��e von 5 MB.";s:7:"correct";i:0;}i:4;a:3:{s:2:"id";i:5;s:6:"answer";s:48:"Nur ein Avatar-Bild in der Gr��e 150x150 Punkte.";s:7:"correct";i:0;}i:5;a:3:{s:2:"id";i:6;s:6:"answer";s:75:"Auch Screenshots und Wallpaper, solange diese nicht gr��er als 256 KB sind.";s:7:"correct";i:1;}}'),
(2, 'checkbox', 'Welche Client-Ports sind auf diesem Tracker blockiert?', 'a:6:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:2:"80";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:4:"1214";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:4:"4662";s:7:"correct";i:1;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:9:"6881-6889";s:7:"correct";i:1;}i:4;a:3:{s:2:"id";i:5;s:6:"answer";s:5:"27005";s:7:"correct";i:0;}i:5;a:3:{s:2:"id";i:6;s:6:"answer";s:11:"45300-45350";s:7:"correct";i:0;}}'),
(3, 'radio', 'Welche Voraussetzung muss erf�llt sein, um eine Wartezeitaufhebung erfolgreich beantragen zu k�nnen?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:49:"Es sind weniger als drei Stunden Wartezeit �brig.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:73:"Der Benutzer muss den festen Willen haben, diese Datei leechen zu wollen.";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:114:"Der Benutzer muss einen wichtigen Grund haben, z.B. m�chte er den Film etc. seiner Mutter zum Geburtstag schenken.";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:61:"Der Benutzer hat die Datei schon und m�chte diese nur seeden.";s:7:"correct";i:1;}}'),
(4, 'radio', 'Welche Mindestgr��e m�ssen Torrents haben, die auf den Tracker geladen werden?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:5:"10 MB";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:5:"30 MB";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:6:"100 MB";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:4:"1 GB";s:7:"correct";i:0;}}'),
(5, 'radio', 'Was sollte auf jeden Fall im Torrentnamen stehen?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:17:"Name der Trackers";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:20:"Sprache des Releases";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:16:"Name des Seeders";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:17:"Gru� an die Mutti";s:7:"correct";i:0;}}'),
(6, 'radio', 'Nach wie vielen Tagen werden inaktive Accounts automatisch gel�scht?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:13:"Nach 30 Tagen";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:13:"Nach 42 Tagen";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:13:"Nach 60 Tagen";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:13:"Nach 72 Tagen";s:7:"correct";i:0;}}'),
(7, 'radio', 'Welche Datenmenge darf ein Webseeder maximal hochladen?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:62:"Ca. 200% der Torrentgr��e, bei hoher Nachfrage ggf. auch mehr.";s:7:"correct";i:1;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:60:"So viel wie der Server des Webseeders noch Traffic �ber hat.";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:49:"Bis der Webseeder auf Platz 1 der Uploader steht.";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:54:"Auf diesem Tracker muss gar nichts hochgeladen werden.";s:7:"correct";i:0;}}'),
(8, 'radio', 'Was sollte man tun, wenn man ein Release fertig runtergeladen hat (100%)?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:79:"Die Daten mehrfach auf CD/DVD brennen und auf dem n�chsten Flohmarkt verkaufen.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:83:"Das Release noch im Client aktiv lassen und bestenfalls nochmal komplett hochladen.";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:75:"Sofort stoppen, damit man mehr Bandbreite f�r das n�chste Release frei hat.";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:50:"Das Release sofort auf anderen Trackern hochladen.";s:7:"correct";i:0;}}'),
(9, 'radio', 'Was kannst Du machen, wenn Du eine Frage hast oder Dir wegen einer Regel unsicher bist?', 'a:3:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:93:"Ich melde mich im Board an, und er�ffne in m�glichst vielen Foren ein thema mit meiner Frage.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:76:"Ich benutze den "IRC-Chat"-Link im Men�, und frage die Benutzer dort um Rat.";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:68:"Ich will hier nur Releases leechen, da bleibt f�r Fragen keine Zeit.";s:7:"correct";i:0;}}'),
(10, 'radio', 'Was bedeutet "Anti-Leech-Tracker"?', 'a:3:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:115:"Auf einem Anti-Leech-Tracker kann man Saugen bis die Leitung gl�ht, da viele Leute mit dicken Leitungen aktiv sind.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:112:"Anti-Leech hei�t "Nehmen und Geben", sprich es m�ssen auch Daten hochgeladen werden, um dabei bleiben zu d�rfen.";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:135:"Ein "Anti-Leech-Tracker" ist ein neues Fahrzeug zur Bek�mpfung.von Blutegeln auf Reisfeldern, damit die Arbeiter nicht gebissen werden.";s:7:"correct";i:0;}}'),
(11, 'radio', 'Was ist eine Ratio?', 'a:3:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:103:"Ratio ist eine Abk�rzung von Rotation. Je h�her die Rotation, desto schlechter ist es f�r den Benutzer.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:86:"Das ist falsch geschrieben und hei�t Ration, ein Wort f�r eine t�gliche Portion Essen.";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:112:"Die Ratio ist das Verh�ltnis der hochgeladenen Daten zu den heruntergeladenen. Je h�her die Ratio, desto besser.";s:7:"correct";i:1;}}'),
(12, 'radio', 'Was bedeutet es, wenn Du als nicht erreichbar angezeigt wirst?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:97:"Ein SysOp hat versucht, Dich �ber Deine E-Mail-Adresse zu erreichen, aber das hat nicht geklappt.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:65:"Dein (DSL-)Provider hat die Nutzung von BitTorrent eingeschr�nkt.";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:104:"Dein Client-Port ist f�r Rechner im Internet nicht offen, da Du einen Router oder eine Firewall benutzt.";s:7:"correct";i:1;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:77:"Nicht erreichbar sein ist gut, denn dann kann man Dich nicht zur�ckverfolgen.";s:7:"correct";i:0;}}'),
(13, 'checkbox', 'Welche der folgenden Aussagen treffen zu, damit Du Uploader werden kannst und bleibst?', 'a:7:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:72:"Ich muss lediglich einen Moderator bitten, mir diesen Rang zu verleihen.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:48:"Ich muss eine gute Upload-Geschwindigkeit haben.";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:64:"Ich muss mindestens 4 Releases innerhalb von 28 Tagen hochladen.";s:7:"correct";i:1;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:66:"Wenn ich einen Rootserver besitze, werde ich automatisch Uploader.";s:7:"correct";i:0;}i:4;a:3:{s:2:"id";i:5;s:6:"answer";s:49:"Ich muss schon mindestens 5 GB hochgeladen haben.";s:7:"correct";i:1;}i:5;a:3:{s:2:"id";i:6;s:6:"answer";s:35:"Meine Ratio muss gr��er als 1 sein.";s:7:"correct";i:1;}i:6;a:3:{s:2:"id";i:7;s:6:"answer";s:46:"T-DSL 6000 ist Minimum, um Uploader zu werden.";s:7:"correct";i:0;}}'),
(14, 'radio', 'Wo kannst Du Dein Avatar-Bild ablegen?', 'a:3:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:96:"Ich lege es nirgends ab, sondern verlinke das Bild direkt von der Seite wo ich es gefunden habe.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:113:"Ich lade es auf meine private Website, so k�nnen andere Benutzer auch direkt �ber meine Domain sehen wer ich bin.";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:91:"Ich lade das Bild auf den Tracker-Server, dort wird mir Platz daf�r zur Verf�gung gestellt.";s:7:"correct";i:1;}}'),
(15, 'radio', 'Was machst Du, wenn Du eine Verwarnung wegen zu wenig Upload erhalten hast?', 'a:4:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:59:"Ich l�sche den Account und lege mir einfach einen Neuen an.";s:7:"correct";i:0;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:97:"Ich versuche, so lange Daten hochzuladen bis das Verh�ltnis zum Download wieder ausgeglichen ist.";s:7:"correct";i:1;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:70:"Ich packe meine DoS-Tools aus und lege den Tracker f�r einen Tag lahm.";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:72:"Gar nichts, die Verwarnung wird nach einer Woche automatisch aufgehoben.";s:7:"correct";i:0;}}'),
(16, 'radio', 'Wie viele Torrents darfst Du gleichzeitig leechen?', 'a:5:{i:0;a:3:{s:2:"id";i:1;s:6:"answer";s:97:"Die Menge ist abh�ngig davon, wie viel ich bislang hochgeladen habe, und wie gut meine Ratio ist.";s:7:"correct";i:1;}i:1;a:3:{s:2:"id";i:2;s:6:"answer";s:51:"Ich darf maximal 10 Torrent zeitgleich runterladen.";s:7:"correct";i:0;}i:2;a:3:{s:2:"id";i:3;s:6:"answer";s:91:"Wenn ich gerade mindestens einen Torrent hochlade, darf ich in der Zeit keinen runterladen.";s:7:"correct";i:0;}i:3;a:3:{s:2:"id";i:4;s:6:"answer";s:148:"Die Menge ist abh�ngig von meiner Internetgeschwindigkeit. Ein T-DSL 6000 Benutzer darf z.B. 6 Torrents zeitgleich saugen (Bandbreite in KBit/1000).";s:7:"correct";i:0;}i:4;a:3:{s:2:"id";i:5;s:6:"answer";s:27:"Es gibt keine Beschr�nkung.";s:7:"correct";i:0;}}');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `topics`
-- 

CREATE TABLE `topics` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL default '0',
  `subject` varchar(40) default NULL,
  `locked` enum('yes','no') NOT NULL default 'no',
  `forumid` int(10) unsigned NOT NULL default '0',
  `lastpost` int(10) unsigned NOT NULL default '0',
  `sticky` enum('yes','no') NOT NULL default 'no',
  `views` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `userid` (`userid`),
  KEY `subject` (`subject`),
  KEY `lastpost` (`lastpost`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten f�r Tabelle `topics`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `torrents`
-- 

CREATE TABLE `torrents` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `info_hash` varchar(20) character set latin1 collate latin1_bin NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `save_as` varchar(255) NOT NULL default '',
  `search_text` text NOT NULL,
  `descr` text NOT NULL,
  `ori_descr` text NOT NULL,
  `category` int(10) unsigned NOT NULL default '0',
  `size` bigint(20) unsigned NOT NULL default '0',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` enum('single','multi') NOT NULL default 'single',
  `numfiles` int(10) unsigned NOT NULL default '0',
  `numpics` int(1) NOT NULL default '0',
  `comments` int(10) unsigned NOT NULL default '0',
  `views` int(10) unsigned NOT NULL default '0',
  `hits` int(10) unsigned NOT NULL default '0',
  `times_completed` int(10) unsigned NOT NULL default '0',
  `leechers` int(10) unsigned NOT NULL default '0',
  `seeders` int(10) unsigned NOT NULL default '0',
  `last_action` datetime NOT NULL default '0000-00-00 00:00:00',
  `visible` enum('yes','no') NOT NULL default 'yes',
  `banned` enum('yes','no') NOT NULL default 'no',
  `activated` enum('yes','no') NOT NULL default 'yes',
  `owner` int(10) unsigned NOT NULL default '0',
  `gu_agent` int(10) unsigned NOT NULL default '0',
  `numratings` int(10) unsigned NOT NULL default '0',
  `ratingsum` int(10) unsigned NOT NULL default '0',
  `nfo` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `info_hash` (`info_hash`),
  KEY `owner` (`owner`),
  KEY `visible` (`visible`),
  KEY `category_visible` (`category`,`visible`),
  FULLTEXT KEY `ft_search` (`search_text`,`ori_descr`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Daten f�r Tabelle `torrents`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `traffic`
-- 

CREATE TABLE `traffic` (
  `userid` int(11) unsigned NOT NULL default '0',
  `torrentid` int(11) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloadtime` int(11) unsigned NOT NULL default '0',
  `uploadtime` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`userid`,`torrentid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten f�r Tabelle `traffic`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur f�r Tabelle `users`
-- 

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(40) NOT NULL default '',
  `old_password` varchar(40) NOT NULL default '',
  `passhash` varchar(32) NOT NULL default '',
  `passkey` tinyblob NOT NULL,
  `secret` tinyblob NOT NULL,
  `email` varchar(80) NOT NULL default '',
  `status` enum('pending','confirmed') NOT NULL default 'confirmed',
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL default '0000-00-00 00:00:00',
  `editsecret` tinyblob NOT NULL,
  `privacy` enum('strong','normal','low') NOT NULL default 'normal',
  `stylesheet` int(10) default '1',
  `info` text,
  `acceptpms` enum('yes','friends','no') NOT NULL default 'yes',
  `ip` varchar(15) NOT NULL default '',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `avatar` varchar(100) NOT NULL default '',
  `uploaded` bigint(20) unsigned NOT NULL default '0',
  `downloaded` bigint(20) unsigned NOT NULL default '0',
  `title` varchar(30) NOT NULL default '',
  `country` int(10) unsigned NOT NULL default '0',
  `notifs` varchar(200) NOT NULL default '',
  `enabled` enum('yes','no') NOT NULL default 'yes',
  `accept_rules` enum('yes','no') NOT NULL default 'yes',
  `accept_email` enum('yes','friends','no') NOT NULL default 'friends',
  `avatars` enum('yes','no') NOT NULL default 'yes',
  `donor` enum('yes','no') NOT NULL default 'no',
  `oldtorrentlist` enum('yes','no') NOT NULL default 'no',
  `displaysearch` enum('yes','no') NOT NULL default 'yes',
  `warned` enum('yes','no') NOT NULL default 'no',
  `log_ratio` enum('yes','no') NOT NULL default 'no',
  `statbox` enum('top','bottom','hide') NOT NULL default 'top',
  `warneduntil` datetime NOT NULL default '0000-00-00 00:00:00',
  `torrentsperpage` int(3) unsigned NOT NULL default '0',
  `topicsperpage` int(3) unsigned NOT NULL default '0',
  `postsperpage` int(3) unsigned NOT NULL default '0',
  `deletepms` enum('yes','no') NOT NULL default 'yes',
  `savepms` enum('yes','no') NOT NULL default 'no',
  `hideuseruploads` enum('yes','no') NOT NULL default 'no',
  `wgeturl` enum('yes','no') NOT NULL default 'no',
  `showcols` text NOT NULL,
  `tlimitall` int(10) NOT NULL default '0',
  `tlimitseeds` int(10) NOT NULL default '0',
  `tlimitleeches` int(10) NOT NULL default '0',
  `allowupload` enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status_added` (`status`,`added`),
  KEY `ip` (`ip`),
  KEY `uploaded` (`uploaded`),
  KEY `downloaded` (`downloaded`),
  KEY `country` (`country`),
  KEY `last_access` (`last_access`),
  KEY `enabled` (`enabled`),
  KEY `warned` (`warned`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

-- 
-- Daten f�r Tabelle `users`
-- 

INSERT INTO `users` (`id`, `username`, `old_password`, `passhash`, `passkey`, `secret`, `email`, `status`, `added`, `last_login`, `last_access`, `editsecret`, `privacy`, `stylesheet`, `info`, `acceptpms`, `ip`, `class`, `avatar`, `uploaded`, `downloaded`, `title`, `country`, `notifs`, `enabled`, `accept_rules`, `accept_email`, `avatars`, `donor`, `oldtorrentlist`, `displaysearch`, `warned`, `log_ratio`, `statbox`, `warneduntil`, `torrentsperpage`, `topicsperpage`, `postsperpage`, `deletepms`, `savepms`, `hideuseruploads`, `wgeturl`, `showcols`, `tlimitall`, `tlimitseeds`, `tlimitleeches`, `allowupload`) VALUES 
(1, 'Solstice', '', 'f82f0749d66ef48055fb98fdf9754b1e', 0x5190da962396ea5d, 0x5bf0544319b4c9df8091b904d96df59429d75a25, '', 'confirmed', '2008-11-05 09:54:04', '2009-12-19 12:51:10', '2010-01-03 15:22:44', 0xfc84f383891349e641e575e17b0d3c430aaac464, 'normal', 2, '', 'friends', '82.212.58.205', 100, 'http://lisus.de/Avatar.php?get=150', 0, 0, 'Source Coder', 0, '[pm]', 'yes', 'yes', 'friends', 'yes', 'no', 'no', 'yes', 'no', 'no', 'top', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'yes', 'no', 'no', '', 0, 0, 0, 'yes'),
(25, 'Admin', '', '84ffd8c56a7406e9b09e7a8648b83d15', 0xfcf6d07d5b96dd12, 0x9dfe94b0e64283f641529b1364be2a098dcbbbe2, 'admin@lisus.de', 'confirmed', '2010-01-04 10:23:35', '2010-01-04 10:42:43', '2010-01-04 10:42:50', '', 'normal', 1, NULL, 'yes', '82.212.58.205', 100, '', 0, 0, '', 0, '', 'yes', 'yes', 'friends', 'yes', 'no', 'no', 'yes', 'no', 'no', 'top', '0000-00-00 00:00:00', 0, 0, 0, 'yes', 'no', 'no', 'no', '', 0, 0, 0, 'yes');
