<?php

// +--------------------------------------------------------------------------+
// | Project:   Solstice NVTracker (W3C) - NetVision BitTorrent Tracker       |
// +--------------------------------------------------------------------------+
// | This file is part of NVTracker. NVTracker is based on BTSource,          |
// | originally by RedBeard of TorrentBits, extensively modified by Solstice. |
// |                                                                          |
// | Updates by Solstice:                                                     |
// | - Tidy                                                                   |
// | - W3C Html 4.01 Transitional                                             |
// | - W3C CSS Level 3                                                        |
// |                                                                          |
// | This file has been originally validated by http://validator.w3.org       |
// |                                                                          |
// | NVTracker is free software; you can redistribute it and/or modify        |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 2 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | NVTracker is distributed in the hope that it will be useful,             |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen d�nicht entfernt werden!    Do not remove above lines! |
// +--------------------------------------------------------------------------+

function local_user()
{
    global $HTTP_SERVER_VARS;

    return $HTTP_SERVER_VARS["SERVER_ADDR"] == $HTTP_SERVER_VARS["REMOTE_ADDR"];
} 
        
require_once("include/install.php");
require_once("include/secrets.php");
require_once("include/config.php");
require_once("include/global.php");
require_once("include/pmfunctions.php");
require_once("include/cleanup.php");
require_once("include/shoutcast.php");
require_once("include/SMTP/smtp.lib.php");

/**
 * *** validip/getip courtesy of manolete <manolete@myway.com> ***
 */
// IP Validation

function stdsuccess($text = "Aktion erfolgreich")
{
echo "<table summary='none' cellpadding='4' cellspacing='1' border='0' style='width:650px' class='tableinborder'>
<tr style='width:100%'><td class='tablea'><center><b><font color='red'>".$text."</font></b></center></td></tr></table>";
}

function makehours($date)  // by Solstice
{
$arr1 = explode(" ","$date");
$timebig = explode("-","$arr1[0]");
$timetiny = explode(":","$arr1[1]");
$yearreg = $timebig[0];
$monthreg = $timebig[1];
$dayreg = $timebig[2];
$hourreg = $timetiny[0];


$hours = ( ($yearreg*365*24)+($monthreg*30*24)+($dayreg*24)+$hourreg );

return $hours;
}


function sendmail($email,$header,$msg)
{

// initiate smtp object
$mail = new smtp;
// connect to smtp server, write your isp smtp url here the random port is 25
$mail->open($GLOBALS['SMTP_MAILSERVER'], $GLOBALS['SMTP_PORT']);
// Remove // for secure mode
//$mail->start_tls();
// Write your auth stuff here if nott add // before
$mail->auth($GLOBALS['SMTP_USERID'], $GLOBALS['SMTP_PASS']);

// Write your email address here  [email]noreply@gmail.com[/email]
$mail->from($GLOBALS['SMTP_MAIL']);


$mail->to("$email");

$mail->subject("$header");


// E-Mail TExt
$mail->body("$msg");

$mail->send();

$mail->close();  

}


/////////////////////////////////////////////////Poster Upload by Solstice/Begin//////////////////////////////////////
function bb_err($type)
{
$error[0] = true;
$error[1] = $type;
return $error;
}

function upload($file, $post = 0,$smilie = 'no')
{

if ($file["size"] > 0)
{

     if ($file["error"] != UPLOAD_ERR_OK)
		return bb_err("<font color=\"red\">FEHLER!! -- Es Trat ein Fehler beim Empfang der Datei auf</font>");

global $CURUSER;
$maxfilesize = $GLOBALS["MAX_UPLOAD_FILESIZE"];

if ($CURUSER["class"]>=UC_UPLOADER) 
    $maxbucketsize = $GLOBALS["MAX_BITBUCKET_SIZE_UPLOADER"];

	 $regExp = "/^[ a-zA-Z0-9_-]([ a-zA-Z0-9_-]*\.?[ a-zA-Z0-9_-])*\.[a-zA-Z]{3,4}$/i";


    	$bucketsize = @mysql_result(mysql_query("SELECT SUM(size) FROM bitbucket WHERE user=".$CURUSER["id"]),0);
      if (preg_match($regExp,$file["name"]) && ($file["size"] > 0) && ($file["size"] <= $GLOBALS["MAX_UPLOAD_FILESIZE"]) 
          && (($file["type"] == "image/gif") || ($file["type"] == "image/jpg") || ($file["type"] == "image/pjpeg")
              || ($file["type"] == "image/png") || ($file["type"] == "image/jpeg")))
     	if ($bucketsize+$file["size"]<=$maxbucketsize)
{
	   $filename = md5_file($file["tmp_name"]);
       $filename = md5($filename.$file["name"]);
	   
	$it = exif_imagetype($file["tmp_name"]);
	if ($it != IMAGETYPE_GIF && $it != IMAGETYPE_JPEG && $it != IMAGETYPE_PNG)
		return bb_err("<font color=\"red\">FEHLER!! -- Sorry, die hochgeladene Datei konnte nicht als g&uuml;ltige Bilddatei verifiziert werden.</font>");

	$i = strrpos($file["name"], ".");
	if ($i !== false)
	   {
		$ext = strtolower(substr($file["name"], $i));
		if (($it == IMAGETYPE_GIF && $ext != ".gif") || ($it == IMAGETYPE_JPEG && $ext != ".jpg" && $ext != ".jpeg") || ($it == IMAGETYPE_PNG && $ext != ".png") )
	    return bb_err("<font color=\"red\">FEHLER!! -- Ung&uuml;tige Dateinamenerweiterung: <b>".htmlentities($ext)."</b></font>");

        $erg = mysql_query("SELECT user FROM bitbucket WHERE originalname=".sqlesc($file["name"]));
		$count = mysql_num_rows($erg);
		if ($count > 0)
		$filename = md5(rand(0,500000).$filename);
		$filename .= $ext;
		}
		else
		return bb_err("<font color=\"red\">FEHLER!! -- Die Datei muss eine Dateinamenerweiterung besitzen.</font>");

	$tgtfile = $GLOBALS["BITBUCKET_DIR"]."/".$filename;


    if ($post["is_avatar"] == "1") 
	{
        $img = resize_image($file["name"], $file["tmp_name"], $tgtfile);
        if (!$img)
		{
			imagedestroy($img);
			return bb_err("<font color=\"red\">FEHLER!! -- Die Datei wurde nicht als Avatar eingetragen</font>");
        }
		imagedestroy($img);
		
        $file["size"] = filesize($tgtfile);
        if ($bucketsize+filesize($tgtfile)>$maxbucketsize) 
		{
			unlink($tgtfile);
			return bb_err("Sorry, Dein BitBucket ist zu voll, um diese Datei als Avatar aufnehmen zu k&ouml;nnen. Bitte l&ouml;sche erst eine oder mehrere Dateien, bevor Du eine weitere hochl&auml;dst.");
        }
		else 
		{
		if (!move_uploaded_file($file["tmp_name"], $tgtfile))
		return bb_err("<font color=\"red\"><b>Fehler beim Ablegen der Datei.</b></font><br><br>Es ist ein Fehler aufgetreten beim speichern der Datei ausgetreten.<br>Die Datei wurde nicht abgespeichert.");
		$filename = basename($tgtfile);
			mysql_query("INSERT INTO bitbucket (`user`,`filename`,`size`,`originalname`) VALUES (" . intval($CURUSER["id"]) . ", " . sqlesc($filename) . ", " . floatval($file["size"]) . "," . sqlesc($file["name"]) . ")") or sqlerr(__FILE__, __LINE__);;
                     mysql_query("UPDATE users SET avatar = " . sqlesc($tgtfile) . " WHERE id = " . intval($CURUSER["id"]) . " LIMIT 1") or sqlerr(__FILE__, __LINE__);;
		}
    }
	else 
	{
		if (!move_uploaded_file($file["tmp_name"], $tgtfile))
		return bb_err("<font color=\"red\"><b>Fehler beim ablegen der Datei.</b></font><br><br>Es ist ein Fehler aufgetreten beim speichern der Datei ausgetreten.<br>Die Datei wurde nicht abgespeichert.");

		mysql_query("INSERT INTO bitbucket (`user`,`filename`,`size`,`originalname`) VALUES (".sqlesc($CURUSER["id"]).",".sqlesc($filename).",".sqlesc($file["size"]).",".sqlesc($file["name"]).")") or sqlerr(__FILE__, __LINE__); 	} 
}
else return bb_err("Sorry, Dein BitBucket ist zu voll, um diese Datei aufnehmen zu k&ouml;nnen. Bitte l&ouml;sche erst eine oder mehrere Dateien, bevor Du eine weitere hochl&auml;dst.");
else return bb_err("Die Datei konnte nicht als G&uuml;ltige Bilddatei identifiziert werden 2");

}
else return bb_err("<font color=\"red\"><b>Beim Upload ist ein Fehler aufgetreten!</b></font><br>Die hochgeladene Datei ist nicht g&uuml;ltig!!");

		$url = str_replace(" ", "%20", htmlspecialchars($GLOBALS["BITBUCKET_DIR"]."/".$filename));
return $url;
}

function bbdelete($file_name,$userid = 0, $modcomment = false)
{
if (is_numeric($file_name))
{
$where = " id = ".sqlesc($file_name);
$a = mysql_fetch_assoc(mysql_query("SELECT filename FROM bitbucket WHERE id = ".sqlesc($file_name)));
$file_name2 = $a['filename'];
}
else
{
$file_name = explode("/",$file_name);
$cnt = 0;
if (is_array($file_name))
foreach($file_name as $f)
{
if ($file_name[$cnt+1] == "")
$file_name2 = $file_name[$cnt++];
}
else
$file_name2 = $file_name;
$where = " `filename`=".sqlesc($file_name2);
}

$bucketfile = mysql_fetch_assoc(mysql_query("SELECT originalname FROM bitbucket WHERE filename=".sqlesc($file_name2)));


global $CURUSER;
if ($file_name2 != "supportfilesharing.gif")
{

if ($userid == 0)
$userid = $CURUSER["id"];
if ($CURUSER["id"] == $userid || get_user_class() >= UC_MODERATOR)
{
             @mysql_query("DELETE FROM bitbucket WHERE ".$where." AND user = '".$userid."' LIMIT 1");
        	@unlink($GLOBALS["BITBUCKET_DIR"]."/".$file_name2);
			
	if ($modcomment)
	{
	 $comment = date("j.n.Y") . " - Die Datei '" . $bucketfile["originalname"] . "' wurde von '" . $CURUSER["username"] . "' aus dem BitBucket gelöscht.";
     write_modcomment($userid, $CURUSER["id"], $comment);
	}
			
}
else
return FALSE;

}

return TRUE;
}
//////////////////////////////////////////////////Poster Upload by Solstice /End/////////////////////////////////////



function validip($ip)
{
    if (!empty($ip) && ip2long($ip) != -1) {
        // reserved IANA IPv4 addresses
        // http://www.iana.org/assignments/ipv4-address-space
        $reserved_ips = array (
            array('0.0.0.0', '2.255.255.255'),
            array('10.0.0.0', '10.255.255.255'),
            array('127.0.0.0', '127.255.255.255'),
            array('169.254.0.0', '169.254.255.255'),
            array('172.16.0.0', '172.31.255.255'),
            array('192.0.2.0', '192.0.2.255'),
            array('192.168.0.0', '192.168.255.255'),
            array('255.255.255.0', '255.255.255.255')
            );

        foreach ($reserved_ips as $r) {
            $min = ip2long($r[0]);
            $max = ip2long($r[1]);
            if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
        } 
        return true;
    } else return false;
} 
// Patched function to detect REAL IP address if it's valid
function getip()
{
    if (validip($_SERVER['HTTP_CLIENT_IP']))
        return $_SERVER['HTTP_CLIENT_IP'];
    elseif ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") {
        $forwarded = str_replace(",", "", $_SERVER['HTTP_X_FORWARDED_FOR']);
        $forwarded_array = split(" ", $forwarded);
        foreach($forwarded_array as $value) if (validip($value)) return $value;
    } 
    return $_SERVER['REMOTE_ADDR'];
} 

function userlogin()
{
    global $SITE_ONLINE;
    unset($GLOBALS["CURUSER"]);

    $ip = getip();
    $nip = ip2long($ip);
    $res = mysql_query("SELECT * FROM bans WHERE $nip >= first AND $nip <= last") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0) {
        header("HTTP/1.0 403 Forbidden");
        print("<html><body><h1>403 Forbidden</h1>Unauthorized IP address.</body></html>\n");
        die;
    } 
    // Neues sessionbasiertes Login f�sere Performance und Anzeige neuer Torrents
    session_start();

    if (!$SITE_ONLINE || (!isset($_SESSION["userdata"]) && (empty($_COOKIE["uid"]) || empty($_COOKIE["pass"]))))
        return;

    if (isset($_SESSION["userdata"])) {
        // Aktivierungsstatus und IP pr�Session hijacking vermeiden)
        $enabled = mysql_fetch_assoc(mysql_query("SELECT COUNT(*) AS `cnt` FROM `users` WHERE `id` = " . $_SESSION["userdata"]["id"] . " AND `enabled`='yes' AND `status` = 'confirmed'"));
        if ($enabled["cnt"] != 1 || $_SESSION["userdata"]["ip"] != $ip) {
            session_unset();
            session_destroy();
            return;
        } 
        $GLOBALS["CURUSER"] = $_SESSION["userdata"];
    } else {
        // Keine Session aktiv, login via Cookie
        $id = 0 + $_COOKIE["uid"];
        if (!$id || strlen($_COOKIE["pass"]) != 32)
            return;
        $res = mysql_query("SELECT * FROM users WHERE id = $id AND enabled='yes' AND status = 'confirmed'"); // or die(mysql_error());
        $row = mysql_fetch_array($res);
        if (!$row)
            return;
        $sec = hash_pad($row["secret"]);
        if ($_COOKIE["pass"] !== $row["passhash"])
            return;

        $row['ip'] = $ip;
        $GLOBALS["CURUSER"] = $row;
        $_SESSION["userdata"] = $row;

        if (isset($_COOKIE["passhash"])) {
            $res = mysql_query("SELECT * FROM `accounts` WHERE `userid`=" . $GLOBALS["CURUSER"]["id"] . " AND `chash`=" . sqlesc($_COOKIE["passhash"]));
            if (mysql_num_rows($res))
                mysql_query("UPDATE `accounts` SET `lastaccess`=NOW() WHERE `userid`=" . $GLOBALS["CURUSER"]["id"]);
            else {
                $res = mysql_query("SELECT * FROM `accounts` WHERE `chash`=" . sqlesc($_COOKIE["passhash"]));
                if (mysql_num_rows($res)) {
                    $data = mysql_fetch_assoc($res);
                    $baduser = $data["baduser"];
                } else {
                    $baduser = 0;
                } 
                mysql_query("INSERT INTO `accounts` (`userid`,`chash`,`lastaccess`,`username`,`email`,`baduser`) VALUES (" . $row["id"] . "," . sqlesc($_COOKIE["passhash"]) . ", NOW(), " . sqlesc($row["username"]) . ", " . sqlesc($row["email"]) . ", " . $baduser . ")");
            } 
        } else {
            $res = mysql_query("SELECT * FROM `accounts` WHERE `userid`=" . $GLOBALS["CURUSER"]["id"]);
            if (mysql_num_rows($res)) {
                mysql_query("UPDATE `accounts` SET `lastaccess`=NOW() WHERE `userid`=" . $GLOBALS["CURUSER"]["id"]);
                $data = mysql_fetch_assoc($res);
                $hash = $data["chash"];
            } else {
                $hash = md5($row["username"] . mksecret() . $row["username"]);
                mysql_query("INSERT INTO `accounts` (`userid`,`chash`,`lastaccess`,`username`,`email`,`baduser`) VALUES (" . $row["id"] . "," . sqlesc($hash) . ", NOW(), " . sqlesc($row["username"]) . ", " . sqlesc($row["email"]) . ", 0)");
            } 
            setcookie("passhash", $hash, 0x7fffffff, "/");
        } 
    } 

    if ($GLOBALS["CURUSER"]["id"] != 1010) 
        // Letzten Zugriff aktualisieren
        mysql_query("UPDATE users SET last_access='" . date("Y-m-d H:i:s") . "', ip='$ip' WHERE id=" . $GLOBALS["CURUSER"]["id"]); // or die(mysql_error());
    if ($GLOBALS["CURUSER"]["accept_rules"] == "no" && !preg_match("/(takeprofedit|rules|faq|logout|delacct)\\.php$/", $_SERVER["PHP_SELF"])) {
        header("Location: rules.php?accept_rules");
        die();
    } 
} 

function logincookie($id, $passhash, $updatedb = 1, $expires = 0x7fffffff)
{
    setcookie("uid", $id, $expires, "/");
    setcookie("pass", $passhash, $expires, "/");

    if ($updatedb)
        mysql_query("UPDATE users SET last_login = NOW() WHERE id = $id");
} 

function logoutcookie()
{
    setcookie("uid", "", 0x7fffffff, "/");
    setcookie("pass", "", 0x7fffffff, "/");
    session_unset();
    session_destroy();
} 

function loggedinorreturn()
{
    global $CURUSER, $DEFAULTBASEURL;
    if (!$CURUSER) {
        header("Location: $DEFAULTBASEURL/login.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]));
        exit();
    } 
} 

function autoclean()
{
    $now = time();
    $docleanup = 0;

    $res = mysql_query("SELECT value_u FROM avps WHERE arg = 'lastcleantime'");
    $row = mysql_fetch_array($res);
    if (!$row) {
        mysql_query("INSERT INTO avps (arg, value_u) VALUES ('lastcleantime',$now)");
        return;
    } 
    $ts = $row[0];
    if ($ts + $GLOBALS["AUTOCLEAN_INTERVAL"] > $now)
        return;
    mysql_query("UPDATE avps SET value_u=$now WHERE arg='lastcleantime' AND value_u = $ts");
    if (!mysql_affected_rows())
        return;

    docleanup();
} 

function unesc($x)
{
    if (get_magic_quotes_gpc())
        return stripslashes($x);
    return $x;
} 

function mksize($bytes)
{
    if ($bytes < 1000 * 1024)
        return number_format($bytes / 1024, 2, ",", ".") . " KB";
    elseif ($bytes < 1000 * 1048576)
        return number_format($bytes / 1048576, 2, ",", ".") . " MB";
    elseif ($bytes < 1000 * 1073741824)
        return number_format($bytes / 1073741824, 2, ",", ".") . " GB";
    elseif ($bytes < 1000 * 1099511627776)
        return number_format($bytes / 1099511627776, 2, ",", ".") . " TB";
    else
        return number_format($bytes / 1125899906842624, 2, ",", ".") . " PB";
} 

function mksizeint($bytes)
{
    $bytes = max(0, $bytes);
    if ($bytes < 1000)
        return number_format(floor($bytes), 0, ",", ".") . " B";
    elseif ($bytes < 1000 * 1024)
        return number_format(floor($bytes / 1024), 0, ",", ".") . " KB";
    elseif ($bytes < 1000 * 1048576)
        return number_format(floor($bytes / 1048576), 0, ",", ".") . " MB";
    elseif ($bytes < 1000 * 1073741824)
        return number_format(floor($bytes / 1073741824), 0, ",", ".") . " GB";
    elseif ($bytes < 1000 * 1099511627776)
        return number_format(floor($bytes / 1099511627776), 0, ",", ".") . " TB";
    else
        return number_format(floor($bytes / 1125899906842624), 0, ",", ".") . " PB";
} 

function deadtime()
{
    return time() - floor($GLOBALS["ANNOUNCE_INTERVAL"] * 1.3);
} 

function mkprettytime($s)
{
    if ($s < 0)
        $s = 0;
    $t = array();
    foreach (array("60:sec", "60:min", "24:hour", "0:day") as $x) {
        $y = explode(":", $x);
        if ($y[0] > 1) {
            $v = $s % $y[0];
            $s = floor($s / $y[0]);
        } else
            $v = $s;
        $t[$y[1]] = $v;
    } 

    if ($t["day"])
        return $t["day"] . "d " . sprintf("%02d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
    if ($t["hour"])
        return sprintf("%d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]); 
    // if ($t["min"])
    return sprintf("%d:%02d", $t["min"], $t["sec"]); 
    // return $t["sec"] . " secs";
} 

function mkglobal($vars)
{
    if (!is_array($vars))
        $vars = explode(":", $vars);
    foreach ($vars as $v) {
        if (isset($_GET[$v]))
            $GLOBALS[$v] = unesc($_GET[$v]);
        elseif (isset($_POST[$v]))
            $GLOBALS[$v] = unesc($_POST[$v]);
        else
            return 0;
    } 
    return 1;
} 

function tr($x, $y, $noesc = 0)
{
    if ($noesc)
        $a = $y;
    else {
        $a = htmlspecialchars($y);
        $a = str_replace("\n", "<br>\n", $a);
    } 
    print("<tr><td class=\"tableb\" valign=\"top\" align=\"left\">$x</td><td class=\"tablea\" valign=\"top\" align=left>$a</td></tr>\n");
} 

function validfilename($name)
{
    return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
} 

function validemail($email)
{
    return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
} 

function sqlesc($x)
{
    return "'" . mysql_real_escape_string($x) . "'";
} 

function sqlwildcardesc($x)
{
    return str_replace(array("%", "_"), array("\\%", "\\_"), mysql_real_escape_string($x));
} 

function urlparse($m)
{
    $t = $m[0];
    if (preg_match(',^\w+://,', $t))
        return "<a href=\"$t\">$t</a>";
    return "<a href=\"http://$t\">$t</a>";
} 

function parsedescr($d, $html)
{
    if (!$html) {
        $d = htmlspecialchars($d);
        $d = str_replace("\n", "\n<br>", $d);
    } 
    return $d;
} 

function ratiostatbox()
{
    global $CURUSER;

    if ($CURUSER) {
        $ratio = ($CURUSER["downloaded"] > 0?number_format($CURUSER["uploaded"] / $CURUSER["downloaded"], 3, ",", "."):"Inf.");
        $seedsarr = @mysql_fetch_assoc(mysql_query("SELECT COUNT(*) AS `cnt` FROM `peers` WHERE `userid`=" . $CURUSER["id"] . " AND `seeder`='yes'"));
        $seeds = $seedsarr["cnt"];
        $leechesarr = @mysql_fetch_assoc(mysql_query("SELECT COUNT(*) AS `cnt` FROM `peers` WHERE `userid`=" . $CURUSER["id"] . " AND `seeder`='no'"));
        $leeches = $leechesarr["cnt"];
        $tlimits = get_torrent_limits($CURUSER);

        if ($ratio < 0.5) {
            $ratiowarn = " style=\"background-color:red;color:white;\"";
        } elseif ($ratio < 0.75) {
            $ratiowarn = " style=\"background-color:#FFFF00;color:black;\"";
        } 

        if ($tlimits["seeds"] >= 0) {
            if ($tlimits["seeds"] - $seeds < 1)
                $seedwarn = " style=\"background-color:red;color:white;\"";
            $tlimits["seeds"] = " / " . $tlimits["seeds"];
        } else
            $tlimits["seeds"] = "";
        if ($tlimits["leeches"] >= 0) {
            if ($tlimits["leeches"] - $leeches < 1)
                $leechwarn = " style=\"background-color:red;color:white;\"";
            $tlimits["leeches"] = " / " . $tlimits["leeches"];
        } else
            $tlimits["leeches"] = "";
        if ($tlimits["total"] >= 0) {
            if ($tlimits["total"] - $leeches + $seeds < 1)
                $totalwarn = " style=\"background-color:red;color:white;\"";
            $tlimits["total"] = " / " . $tlimits["total"];
        } else
            $tlimits["total"] = "";

        ?>
              <tr><td class="tabletitle" style="padding: 4px;"><b><?=htmlspecialchars($CURUSER["username"])?> :.</b></td></tr>
              <tr><td class="tablea" style="padding-left: 4px;">
	            <table cellspacing="0" cellpadding="2" border="0" style="width:140px;" summary="none">
		          <tr><td><b>Download:</b></td><td style="text-align:right"><?=mksize($CURUSER["downloaded"])?></td></tr>
		          <tr><td><b>Upload:</b></td><td style="text-align:right"><?=mksize($CURUSER["uploaded"])?></td></tr>
		          <tr><td><b>Ratio:</b></td><td style="text-align:right;color:<?=get_ratio_color($ratio)?>"><?=$ratio?></td></tr>
		          <tr><td colspan="2">&nbsp;</td></tr>
		          <tr<?=$seedwarn?>><td><b>Seeds:</b></td><td style="text-align:right"><?=$seeds . $tlimits["seeds"]?></td></tr>
		          <tr<?=$leechwarn?>><td><b>Leeches:</b></td><td style="text-align:right"><?=$leeches . $tlimits["leeches"]?></td></tr>
		          <tr<?=$totalwarn?>><td><b>Gesamt:</b></td><td style="text-align:right"><?=($seeds + $leeches) . $tlimits["total"]?></td></tr>
		        </table>
              </td></tr>
<?php } 
} 

function stdhead($title = "", $msgalert = true)
{
dbconn();

    global $CURUSER, $HTTP_SERVER_VARS, $PHP_SELF;

    if (!$GLOBALS["SITE_ONLINE"])
        die("Die Seite ist momentan aufgrund von Wartungsarbeiten nicht verf�<br>");

    header("Content-Type: text/html; charset=iso-8859-1");
    header("Pragma: No-cache");
    header("Expires: 300");
    header("Cache-Control: private");

    if ($title == "")
        $title = $GLOBALS["SITENAME"];
    else
        $title = $GLOBALS["SITENAME"] . " :: " . htmlspecialchars($title);

    if ($CURUSER) {
        $ss_a = @mysql_fetch_assoc(@mysql_query("SELECT `uri` FROM `stylesheets` WHERE `id`=" . $CURUSER["stylesheet"]));
        if ($ss_a) $GLOBALS["ss_uri"] = $ss_a["uri"];
    } 

    if (!$GLOBALS["ss_uri"]) {
        ($r = mysql_query("SELECT `uri` FROM `stylesheets` WHERE `default`='yes'")) or die(mysql_error());
        ($a = mysql_fetch_assoc($r)) or die(mysql_error());
        $GLOBALS["ss_uri"] = $a["uri"];
    } 

    if ($msgalert && $CURUSER) {
        $res = mysql_query("SELECT COUNT(*) FROM `messages` WHERE `folder_in`<>0 AND `receiver`=" . $CURUSER["id"] . " && `unread`='yes'") or die("OopppsY!");
        $arr = mysql_fetch_row($res);
        $unread = $arr[0];
        if ($CURUSER["class"] >= UC_MODERATOR) {
            $res = mysql_query("SELECT COUNT(*) FROM `messages` WHERE `sender`=0 AND `receiver`=0 && `mod_flag`='open'") or die("OopppsY!");
            $arr = mysql_fetch_row($res);
            $unread_mod = $arr[0];
        } 
    } 

    $fn = substr($PHP_SELF, strrpos($PHP_SELF, "/") + 1);
    $logo_pic = $GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"] . "/";
    if (file_exists($logo_pic . "logo.gif")) $logo_pic .= "logo.gif";
    if (file_exists($logo_pic . "logo_top.gif")) $logo_pic .= "logo_top.gif";
    if (file_exists($logo_pic . "logo.jpg")) $logo_pic .= "logo.jpg";
    if (file_exists($logo_pic . "logo_top.jpg")) $logo_pic .= "logo_top.jpg";
    if (file_exists("header.jpg")) $logo_pic .= "header.jpg";
    if (file_exists($logo_pic . "header.gif")) $logo_pic .= "header.gif";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ger">
<head>
<? if ($CURUSER) { 
session_unset();
$_COOKIE["uid"] = mysql_fetch_assoc(mysql_query("SELECT id FROM users WHERE id = " . $CURUSER["id"]));
 } ?> 
<title><?=$title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="300">
<meta http-equiv="cache-control" content="no-cache">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="MSSmartTagsPreventParsing" content="true">
<link rel="stylesheet" href="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"] . "/" . $GLOBALS["ss_uri"]?>.css" type="text/css">
<script type="text/javascript" src="include/js/mouseover.js"></script>
<script type="text/javascript" src="include/js/mousepos.js"></script>
</head>
<body>
<div id="object1" style="position:absolute; z-index:+1" ></div>

<table style="width:100%" cellpadding="0" cellspacing="1" align="center" border="0" class="tableoutborder" summary="none">
  <tr>
    <td class="mainpage" align="center">
      <table style="width:100%" border="0" cellspacing="0" cellpadding="0" summary="none">
        <tr> 
          <td class="logobackground" align="left"><a href="index.php"><img src="<?=$logo_pic?>" border="0" alt="NetVision" title="NetVision" ></a></td>
        </tr>
            <?php if ($GLOBALS["PORTAL_LINK"] != "") { ?>
        <tr>
          <td align="right" class="topbuttons" nowrap="nowrap"><span class="smallfont">
        <a href="<?=$GLOBALS["PORTAL_LINK"]?>"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/top_portal.gif" border="0" alt="" title="Zum Portal" ></a>
            </span>
          </td>
        </tr>
           <?  } ?>
      </table>
</td>
  </tr>
    </table>

      <table style="width:100%" border="0" cellspacing="0" cellpadding="0" summary="none">
        <tr>
          <td valign="top" align="left" style="padding: 5px;width:150px">
            <table cellspacing="0" cellpadding="0" border="0" style="width:150px" summary="none"><tr>
            <td align="left"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/obenlinks.gif" alt="" title="" ></td>
            <td style="width:100%" class="obenmitte"></td>
            <td align="right"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/obenrechts.gif" alt="" title="" ></td>
            </tr></table>
            <table cellpadding="0" cellspacing="1" border="0" style="width:100%" class="tableinborder" summary="none">
            <?php if ($CURUSER && $CURUSER["statbox"] == "top") ratiostatbox();
    ?>              
              <tr><td class="tabletitle" style="padding: 4px;"><b>W3C NetVision :.</b></td></tr>

<?  if ($GLOBALS['newspublic'] == 'yes' || $CURUSER) {?>            
  <tr><td class="tablea"><a style="display:block;padding:4px;" href="index.php" title="Neuigkeiten vom Team sowie allgemeine Tracker-Stats und Umfragen">Tracker-News</a></td></tr>
<? } ?>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="faq.php" title="Oft gestellte Fragen zu diversen trackerspezifischen Themen">FAQ</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="rules.php" title="Alle Verhaltensregeln f&uuml;r den Tracker - LESEPFLICHT!">Regeln</a></td></tr>
              <?php if ($CURUSER) {
        if ($GLOBALS["IRCAVAILABLE"]) {

            ?>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="chat.php" title="IRC-Serverdaten und ein einfach zu benutzendes Java-Applet">IRC Chat</a></td></tr>
              <?php } 

        ?>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="users.php" title="Liste aller Mitglieder, inkl. Suchfunktion">Mitglieder</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="topten.php" title="Diverse Top-Listen">Top 10</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="staff.php" title="Schnelle &Uuml;bersicht &uuml;ber das  Trackerteam">Team</a></td></tr>
              <tr><td class="tabletitle" style="padding: 4px;"><b>Torrents :.</b></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="browse.php" title="Verf&uuml;gbare Torrents anzeigen oder suchen">Durchsuchen</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="upload.php" title="Lade einen eigenen Torrent auf den Tracker hoch">Hochladen</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="mytorrents.php" title="Hier werden alle von Dir hochgeladenen Torrents angezeigt">Meine Torrents</a></td></tr>
              <?php if (get_user_class() >= UC_GUTEAM) {
            ?>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="guestuploads.php" title="Zeigt alle noch nicht freigeschalteten Gastuploads">Neue Gastuploads</a></td></tr>              
              <?php } 
        ?>
              <tr><td class="tabletitle" style="padding: 4px;"><b>Mein Account :.</b></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="userdetails.php?id=<?=$CURUSER["id"]?>" title="Deine Statistik-Seite, die auch andere Benutzer sehen">Mein Profil</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="my.php" title="Hier kannst Du Deine Einstellungen &auml;ndern">Profil bearbeiten</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="friends.php" title="Eine Liste Deiner &quot;Freunde&quot; auf dem Tracker">Buddyliste</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="messages.php" title="Pers&ouml;nliche Nachrichten lesen und beantworten">Nachrichten<?php
        if ($unread || $unread_mod)
            echo "&nbsp;&nbsp;";

        if ($unread) {
            echo "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . "multipage.gif\" border=\"0\"> <b>$unread</b>";
            if ($unread_mod)
                echo "&nbsp;&nbsp;";
        } 

        if ($unread_mod) {
            echo "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . "multipagemod.gif\" border=\"0\"> <b>$unread_mod</b>";
        } 

        ?></a>
              </td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="bitbucket.php" title="Hier kannst Du Avatare und andere Bilder ablegen">BitBucket</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="logout.php" title="Beendet Deine Sitzung und l&ouml;scht die Autologin-Cookies">Ausloggen</a></td></tr>
              <?php if (get_user_class() >= UC_MODERATOR) {

            ?>
              <tr><td class="tabletitle" style="padding: 4px;"><b>Administration :.</b></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="log.php" title="Tracker-Logbuch anzeigen">Site Log</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="usersearch.php" title="Suche nach Benutzern &uuml;ber diverse Angaben">Benutzersuche</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="staff.php?act=last" title="Liste aller Benutzer, nach Anmeldedatum sortiert">Neueste Benutzer</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="staff.php?act=ban" title="Hier kannst Du IP-Bereiche vom Tracker aussperren">IPs sperren</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="staff.php?act=upstats" title="Schnelle &Uuml;bersicht &uuml;ber die Uploadaktivit&auml;ten">Uploader-Stats</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="bitbucket-gallery.php" title="Zeigt s&auml;mtliche BitBucket-Bilder an, nach Benutzern sortiert">BitBucket Gallerie</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="startstoplog.php" title="Diverse Werzeuge, die mit dem Eventlog verkn&uuml;pft sind">Start-/Stop-Log</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="bans.php" title="Bans">User bannen</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="rallye.php" title="Upload-Rallye">Uploadrallye verwalten</a></td></tr>

              <?php if (get_user_class() >= UC_ADMINISTRATOR) {

                ?>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="adduser.php" title="Hier kannst Du einen neuen Account anlegen, der sofort aktiv ist">Account erstellen</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="staff.php?act=cleanaccs" title="Benutzer nach Ratio- und Aktivit&auml;tskriterien suchen und deaktivieren">Accountbereinigung</a></td></tr>
              <?php } 
        } 
    } else {

        ?>
              <tr><td class="tabletitle"><b>Account :.</b></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="signup.php">Registrieren</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="login.php">Einloggen</a></td></tr>
              <tr><td class="tablea"><a style="display:block;padding:4px;" href="recover.php">PW vergessen?</a></td></tr>
              <?php } 
    if ($CURUSER && $CURUSER["statbox"] == "bottom") ratiostatbox();

    ?>
            </table>
            <table cellspacing="0" cellpadding="0" border="0" style="width:150px" summary="none"><tr>
            <td align="left"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/untenlinks.gif" alt="" title="" ></td>
            <td style="width:100%" class="untenmitte" align="center"></td>
            <td align="right"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/untenrechts.gif" alt="" title="" ></td>
            </tr></table>
          </td>
          <td valign="top" align="center" style="padding: 5px;width:100%">
<?php

} // stdhead


function stdfoot()
{
?>
          </td>
        </tr>
      </table>

<table summary="none" cellpadding="4" cellspacing="1" border="0" style="width:100%" class="tableinborder">
 <tr>
  <td class="tabletitle" colspan="10" width="100%"><center><b>W3C NV by Solstice<?=$GLOBALS["MODIFIER"]?></b></center></td> 
 </tr><tr><td width="100%" class="tablea"><center><?=$GLOBALS["STANDARDW3C"]?></center></td></tr></table><br>

</body>
</html>
<?php
} 

function genbark($x, $y)
{
    stdhead($y);

    ?>
<table cellpadding="4" cellspacing="1" border="0" style="width:100%" class="tableinborder" summary="none">
 <tr>
  <td class="tabletitle" colspan="10" width="100%"><span class="normalfont"><center><b> <?=htmlspecialchars($y)?> </b></center></span></td> 
 </tr><tr><td width="100%" class="tablea"><?=htmlspecialchars($x)?></td></tr></table><br>
<?php
    stdfoot();
    exit();
} 

function mksecret($len = 20)
{
    $ret = "";
    for ($i = 0; $i < $len; $i++)
    $ret .= chr(mt_rand(0, 255));
    return $ret;
} 

function httperr($code = 404)
{
    header("HTTP/1.0 404 Not found");
    print("<h1>Not Found</h1>\n");
    print("<p>Sorry pal :(</p>\n");
    exit();
} 

function gmtime()
{
    return strtotime(get_date_time());
} 

function deletetorrent($id, $owner = 0, $comment = "")
{
    global $CURUSER;

    $torrent = mysql_fetch_assoc(mysql_query("SELECT name,numpics FROM torrents WHERE id = $id")); 
    // Delete pictures associated with torrent
    if ($torrent["numpics"] > 0) {
        for ($I = 1; $I <= $torrent["numpics"]; $I++) {
            @unlink($GLOBALS["BITBUCKET_DIR"] . "/t-$id-$I.jpg");
            @unlink($GLOBALS["BITBUCKET_DIR"] . "/f-$id-$I.jpg");
        } 
    } 
    // Delete NFO image
    @unlink($GLOBALS["BITBUCKET_DIR"] . "/nfo-$id.png");
    mysql_query("DELETE FROM torrents WHERE id = $id");
    mysql_query("DELETE FROM traffic WHERE torrentid = $id");
    foreach(explode(".", "peers.files.comments.ratings.nowait") as $x)
    mysql_query("DELETE FROM $x WHERE torrent = $id");
    @unlink($GLOBALS["TORRENT_DIR"] . "/$id.torrent"); 
    // Send notification to owner if someone else deleted the torrent
    if ($CURUSER && $owner > 0 && $CURUSER["id"] != $owner) {
        $msg = sqlesc("Dein Torrent '$torrent[name]' wurde von [url=$DEFAULTBASEURL/userdetails.php?id=" . $CURUSER["id"] . "]" . $CURUSER["username"] . "[/url] gel�t.\n\n[b]Grund:[/b]\n" . $comment);
        sendPersonalMessage(0, $owner, "Einer Deiner Torrents wurde gel�t", $msg, PM_FOLDERID_SYSTEM, 0);
    } 
} 

function pager($perpage, $count, $href = "", $range = "1")
{
    if (!$href)
    $href = $_SERVER["PHP_SELF"]."?";
$range++; // Die Umgebung muss die Aktuelle Seite auch einmal mitzählen;
    $pages = ceil($count / $perpage);

    if (intval($_GET["page"]) > 0)
         $page = intval($_GET["page"]);
    else $page = 1;

$pback = "";
if ($page-3 > 0)
$pback .= "<a href=\"".$href."page=1\"><b>&lt;&lt;&lt; </b></a>&nbsp;&nbsp;";
if ($page-$range > 0)
$pback .= "<a href=\"".$href."page=" .($page - $range). "\"><b>&lt;&lt; </b></a>&nbsp;&nbsp;";
if ($page-1 > 0)
$pback .= "<a href=\"".$href."page=" .($page - 1). "\"><b>&lt;&nbsp;Zur&uuml;ck</b></a>";

$pforw = "";
if ($page+1 <= $pages)
$pforw .= "<a href=\"".$href."page=" .($page + 1). "\"><b>Weiter&nbsp;&gt;     </b></a>";
if ($page+$range <= $pages)
$pforw .= "&nbsp;&nbsp;<a href=\"".$href."page=" .($page + $range). "\"><b>&gt;&gt; </b></a>";
if ($page+3 <= $pages)
$pforw .= "&nbsp;&nbsp;<a href=\"".$href."page=" .($pages). "\"><b>&gt;&gt;&gt; </b></a>";

$pagesbetween = array();
for($c = 1;$c <= $pages;$c++)
{
 $pagebetween = ($page == $c ? "<span style='font-size:1.3em;color:red;'><b>".$c."</b></span>" : "<a href=\"".$href."page=".$c."\"><span style='color:orangered;'><b>".$c."</b></span></a>");

 if ($pages > $range*2)
 {
     if ($c <= $range || $c > $pages-$range)
      $pagesbetween[] = $pagebetween;
     else
       if ($c > $page-$range && $c < $page+$range)
        $pagesbetween[] = $pagebetween; 
       elseif ($c == $page-$range || $c == $page+$range )
        $pagesbetween[] = "...";
 }
 else
 $pagesbetween[] = $pagebetween;
}
if ($pages > 1) $pagernav = $pback."  ".implode(", ",$pagesbetween)."  ".$pforw;
$limit = " LIMIT ".(($page-1)*$perpage).",".$perpage;
return array($pagernav,$pagernav,$limit);
}

function downloaderdata($res)
{
    $rows = array();
    $ids = array();
    $peerdata = array();
    while ($row = mysql_fetch_assoc($res)) {
        $rows[] = $row;
        $id = $row["id"];
        $ids[] = $id;
        $peerdata[$id] = array(downloaders => 0, seeders => 0, comments => 0);
    } 

    if (count($ids)) {
        $allids = implode(",", $ids);
        $res = mysql_query("SELECT COUNT(*) AS c, torrent, seeder FROM peers WHERE torrent IN ($allids) GROUP BY torrent, seeder");
        while ($row = mysql_fetch_assoc($res)) {
            if ($row["seeder"] == "yes")
                $key = "seeders";
            else
                $key = "downloaders";
            $peerdata[$row["torrent"]][$key] = $row["c"];
        } 
        $res = mysql_query("SELECT COUNT(*) AS c, torrent FROM comments WHERE torrent IN ($allids) GROUP BY torrent");
        while ($row = mysql_fetch_assoc($res)) {
            $peerdata[$row["torrent"]]["comments"] = $row["c"];
        } 
    } 

    return array($rows, $peerdata);
} 

function commenttable($rows)
{
    global $CURUSER, $HTTP_SERVER_VARS;

    $count = 0;
    foreach ($rows as $row) {
        begin_table(true);
        print("<colgroup><col width=\"150\"><col width=\"600\"></colgroup>\n");
        print("<tr><td colspan=\"2\" class=\"tablecat\">#" . $row["id"] . " by ");
        if (isset($row["username"])) {
            $title = $row["title"];
            if ($title == "")
                $title = get_user_class_name($row["class"]);
            else
                $title = htmlspecialchars($title);
            print("<a name=\"comm" . $row["id"] . "\" href=\"userdetails.php?id=" . $row["user"] . "\"><b>" .
                htmlspecialchars($row["username"]) . "</b></a>" . get_user_icons(array("donor" => $row["donor"], "enabled" => $row["enabled"], "warned" => $row["warned"])) . " ($title)\n");
        } else
            print("<a name=\"comm" . $row["id"] . "\"><i>(Gel�t)</i></a>\n");

        print(" am " . $row["added"] .
            ($row["user"] == $CURUSER["id"] || get_user_class() >= UC_MODERATOR ? " - [<a href=\"comment.php?action=edit&amp;cid=$row[id]\">Bearbeiten</a>]" : "") .
            (get_user_class() >= UC_MODERATOR ? " - [<a href=\"comment.php?action=delete&amp;cid=$row[id]\">L�en</a>]" : "") .
            ($row["editedby"] && get_user_class() >= UC_MODERATOR ? " - [<a href=\"comment.php?action=vieworiginal&amp;cid=$row[id]\">Original anzeigen</a>]" : "") . "</td></tr>\n");
        $avatar = ($CURUSER["avatars"] == "yes" ? htmlspecialchars($row["avatar"]) : "");
        if (!$avatar)
            $avatar = $GLOBALS["PIC_BASE_URL"] . "default_avatar.gif";
        $text = stripslashes(format_comment($row["text"]));
        if ($row["editedby"])
            $text .= "<p><font size=\"1\" class=\"small\">Zuletzt von <a href=\"userdetails.php?id=".$row["editedby"]."\"><b>".$row["username"]."</b></a> am ".$row["editedat"]." bearbeitet</font></p>\n";
print(" <tr valign=\"top\">\n
        <td class=\"tableb\" align=\"center\" style=\"padding: 0px;width: 150px\"><img width=\"150\" src=\"".$avatar."\" alt=\"Avatar von ".$row["username"]."\"></td>\n
        p<td class=\"tablea\">".$text."</td>\n
        </tr>\n
     ");
        end_table();
    } 
} 

function searchfield($s)
{
    return preg_replace(array('/[^a-z0-9]/si', '/^\s*/s', '/\s*$/s', '/\s+/s'), array(" ", "", "", " "), $s);
} 

function genrelist()
{
    $ret = array();
    $res = mysql_query("SELECT id, name FROM categories ORDER BY name");
    while ($row = mysql_fetch_array($res))
    $ret[] = $row;
    return $ret;
} 

function linkcolor($num)
{
    if ($num == 0)
        return "red";
    return "black";
} 

function ratingpic($num)
{
    $r = round($num * 2) / 2;
    if ($r < 1 || $r > 5)
        return;
    return "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . "$r.gif\" border=\"0\" alt=\"rating: $num / 5\" >";
} 

function browse_sortlink($field, $params)
{
    if ($field == $_GET["orderby"]) {
        return "browse.php?orderby=$field&amp;sort=" . ($_GET["sort"] == "asc" ? "desc" : "asc") . "&amp;$params";
    } else {
        return "browse.php?orderby=$field&amp;sort=" . ($_GET["sort"] == "desc" ? "desc" : "asc") . "&amp;$params";
    } 
} 

function torrenttable_row_oldschool($torrent_info)
{
    global $CURUSER;

    if (strlen($torrent_info["name"]) > 45)
        $displayname = substr($torrent_info["name"], 0, 45) . "...";
    else
        $displayname = $torrent_info["name"];

    $returnto = "&amp;returnto=" . urlencode($_SERVER["REQUEST_URI"]);
    $baselink = "details.php?id=" . $torrent_info["id"];
    if ($torrent_info["variant"] == "index") {
        $baselink .= "&amp;hit=1";
        $filelistlink = $baselink . "&amp;filelist=1";
        $commlink = $baselink . "&amp;tocomm=1";
        $seederlink = $baselink . "&amp;toseeders=1";
        $leecherlink = $baselink . "&amp;todlers=1";
        $snatcherlink = $baselink . "&amp;tosnatchers=1";
    } else {
        $baselink .= $returnto;
        $filelistlink = $baselink . "&amp;filelist=1#filelist";
        $commlink = $baselink . "&amp;page=0#startcomments";
        $seederlink = $baselink . "&amp;dllist=1#seeders";
        $leecherlink = $baselink . "&amp;dllist=1#leechers";
        $snatcherlink = $baselink . "&amp;snatcher=1#snatcher";
    } 

    if ($torrent_info["leechers"])
        $ratio = $torrent_info["seeders"] / $torrent_info["leechers"];
    elseif ($torrent_info["seeders"])
        $ratio = 1;
    else
        $ratio = 0;

    $seedercolor = get_slr_color($ratio);

    ?>
<tr>
  <td class="tableb" valign="top" style="width:1px;padding:0px;"><?php
    if (!isset($torrent_info["cat_pic"]))
        if ($torrent_info["cat_name"] != "")
            echo "<a href=\"browse.php?cat=" . $torrent_info["category"] . "\">" . $torrent_info["cat_name"] . "</a>";
        else
            echo "-";
        else
            echo "<a href=\"browse.php?cat=" . $torrent_info["category"] . "\"><img src=\"" . $GLOBALS["PIC_BASE_URL"] . $torrent_info["cat_pic"] . "\" alt=\"" . $torrent_info["cat_name"] . "\" title=\"" . $torrent_info["cat_name"] . "\" border=\"0\"></a>";

        ?></td>
  <td class="tablea" style="text-align:left;vertical-align:middle;" nowrap="nowrap"><?php if (isset($torrent_info["uploaderclass"]) && $torrent_info["uploaderclass"] < UC_UPLOADER) {
            echo '<font color="red">[GU]</font> ';
        } 

        ?><a href="<?=$baselink?>" title="<?=htmlspecialchars($torrent_info["name"]);

        ?>"><b><?=htmlspecialchars($displayname)?></b></a><?php if ($torrent_info["variant"] != "guestuploads" && $torrent_info["is_new"]) echo " <font style=\"color:red\">(NEU)</font>";

        ?></td>
  <?php if ($torrent_info["variant"] == "mytorrents") {
            ?>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><a href="edit.php?id=<?=$torrent_info["id"] . $returnto?>">Bearbeiten</a></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><?=($torrent_info["visible"] == "yes"?"Ja":"Nein")?></td>
  <?php } elseif ($torrent_info["variant"] == "guestuploads") {
            ?>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><?php if ($torrent_info["gu_agent"] > 0) echo "Ja";
            else echo "<font color=\"red\">Nein</font>";
            ?></td>  
  <?php } elseif ($torrent_info["has_wait"]) {

            ?>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><?php echo "<font color=\"", $torrent_info["wait_color"], "\">", $torrent_info["wait_left"], "<br>Std.</font>";

            ?></td>
  <?php } 

        ?>
  <td class="tablea" style="text-align:right;vertical-align:middle;" nowrap="nowrap"><a href="<?=$filelistlink?>"><?=$torrent_info["numfiles"]?></a></td>
  <td class="tablea" style="text-align:right;vertical-align:middle;" nowrap="nowrap"><a href="<?=$commlink?>"><?=$torrent_info["comments"]?></a></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><?=str_replace("&nbsp;", "<br>", $torrent_info["added"])?></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><?=str_replace(" ", "<br>", $torrent_info["ttl"])?></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><?=str_replace(" ", "<br>", mksize($torrent_info["size"]))?></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><div style="border:1px solid black;padding:0px;width:60px;height:10px;"><div style="border:none;width:<?=60 * $torrent_info["dist"] / 100?>px;height:10px;background-image:url(<?=$GLOBALS["PIC_BASE_URL"]?>ryg-verlauf-small.png);background-repeat:no-repeat;"></div></div></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><a href="<?=$snatcherlink?>"><?=$torrent_info["times_completed"]?></a></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><a href="<?=$seederlink?>"><font color="<?=$seedercolor?>"><?=intval($torrent_info["seeders"])?></font></a></td>
  <td class="tablea" style="text-align:center;vertical-align:middle;" nowrap="nowrap"><a href="<?=$leecherlink?>"><font color="<?=linkcolor($torrent_info["seeders"])?>"><?=intval($torrent_info["leechers"])?></font></a></td>
  <td class="tablea" style="text-align:left;vertical-align:middle;" nowrap="nowrap">D:&nbsp;<?=$torrent_info["dlspeed"]?>&nbsp;KB/s<br>U:&nbsp;<?=$torrent_info["ulspeed"]?>&nbsp;KB/s</td>
  <?php if ($torrent_info["variant"] == "index") {

            ?>
  <td class="tablea" style="text-align:left;vertical-align:middle;" nowrap="nowrap"><?=$torrent_info["uploaderlink"]?></td>
  <?php } 

        ?>  
</tr>
<?php
    } 

    function torrenttable_row($torrent_info)
    {
        global $CURUSER;

        $returnto = "&amp;returnto=" . urlencode($_SERVER["REQUEST_URI"]);
        $baselink = "details.php?id=" . $torrent_info["id"];
        if ($torrent_info["variant"] == "index") {
            $baselink .= "&amp;hit=1";
            $filelistlink = $baselink . "&amp;filelist=1";
            $commlink = $baselink . "&amp;tocomm=1";
            $seederlink = $baselink . "&amp;toseeders=1";
            $leecherlink = $baselink . "&amp;todlers=1";
            $snatcherlink = $baselink . "&amp;tosnatchers=1";
        } else {
            $baselink .= $returnto;
            $filelistlink = $baselink . "&amp;filelist=1#filelist";
            $commlink = $baselink . "&amp;page=0#startcomments";
            $seederlink = $baselink . "&amp;dllist=1#seeders";
            $leecherlink = $baselink . "&amp;dllist=1#leechers";
            $snatcherlink = $baselink . "&amp;snatcher=1#snatcher";
        } 

        if ($torrent_info["leechers"])
            $ratio = $torrent_info["seeders"] / $torrent_info["leechers"];
        elseif ($torrent_info["seeders"])
            $ratio = 1;
        else
            $ratio = 0;

        $seedercolor = get_slr_color($ratio);

        $res = mysql_query("SELECT DISTINCT(user_id) as id, username, class, peers.id as peerid FROM completed,users LEFT JOIN peers ON peers.userid=users.id AND peers.torrent=" . $torrent_info["id"] . " AND peers.seeder='yes' WHERE completed.user_id=users.id AND completed.torrent_id=" . $torrent_info["id"] . " ORDER BY complete_time DESC LIMIT 10");

        $last10users = "";
        while ($arr = mysql_fetch_assoc($res)) {
            if ($last10users) $last10users .= ", ";
            $arr["username"] = "<font class=\"" . get_class_color($arr["class"]) . "\">" . $arr["username"] . "</font>";
            if ($arr["peerid"] > 0) {
                $arr["username"] = "<b>" . $arr["username"] . "</b>";
            } 
            $last10users .= "<a href=\"userdetails.php?id=" . $arr["id"] . "\">" . $arr["username"] . "</a>";
        } 

        if ($last10users == "")
            $last10users = "Diesen Torrent hat noch niemand fertiggestellt.";
        else
            $last10users .= "<br><br>(Fettgedruckte User seeden noch)";

        if ($GLOBALS["DOWNLOAD_METHOD"] == DOWNLOAD_REWRITE)
            $download_url = "download/" . $torrent_info["id"] . "/" . rawurlencode($torrent_info["filename"]);
        else
            $download_url = "download.php?torrent=" . $torrent_info["id"];

        ?>
<tr>
  <td class="tableb" valign="top" style="color:#FFFFFF;width:1px;"><?php
        if (!isset($torrent_info["cat_pic"]))
            if ($torrent_info["cat_name"] != "")
                echo "<a href=\"browse.php?cat=" . $torrent_info["category"] . "\">" . $torrent_info["cat_name"] . "</a>";
            else
                echo "-";
            else
                echo "<a href=\"browse.php?cat=" . $torrent_info["category"] . "\"><img src=\"" . $GLOBALS["PIC_BASE_URL"] . $torrent_info["cat_pic"] . "\" alt=\"" . $torrent_info["cat_name"] . "\" title=\"" . $torrent_info["cat_name"] . "\" border=\"0\"></a>";

            ?></td>
  <td class="tablea" valign="top" align="left">
    <table cellpadding="2" cellspacing="2" border="0" style="width:100%" summary="none">
      <colgroup>
        <col width="20%">
        <col width="20%">
        <col width="20%">
        <col width="20%">
        <col width="20%">
      </colgroup>
      <tr>
        <td colspan="4" nowrap>
          <a href="javascript:expandCollapse('<?=$torrent_info["id"]?>');"><img id="plusminus<?=$torrent_info["id"]?>" src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/plus.gif" alt="Auf-/Zuklappen" border="0"></a>
          <?php if ($torrent_info["variant"] != "index") {

                ?>[ <a href="edit.php?id=<?=$torrent_info["id"] . $returnto?>">Bearbeiten</a> ]<?php } 

            ?>
          <?php if (isset($torrent_info["uploaderclass"]) && $torrent_info["uploaderclass"] < UC_UPLOADER) {
                echo '<font color="red">[GU]</font> ';
            } 

            ?>
          <a href="<?=$baselink?>"><b><?=$torrent_info["name"]?></b></a><?php if ($torrent_info["variant"] != "guestuploads" && $torrent_info["is_new"]) echo " <font style=\"color:red\">(NEU)</font>";
            if ($torrent_info["variant"] == "guestuploads" && $torrent_info["gu_agent"] > 0) echo " <font style=\"color:red\">(Bereits in Bearbeitung)</font>";

            ?>
        </td>
        <td nowrap>
          <?=($torrent_info["variant"] == "mytorrents"?"Hochgeladen am:":"Von: " . $torrent_info["uploaderlink"])?>
        </td>
      </tr>
      <tr>
        <td style="font-size:90%"><b><?=mksize($torrent_info["size"])?></b> in <b><?=$torrent_info["numfiles"]?></b> <a href="<?=$filelistlink?>">Datei(en)</a></td>
        <td style="font-size:90%">
          <b><font color="<?=$seedercolor?>"><?=intval($torrent_info["seeders"])?></font></b> <a href="<?=$seederlink?>">Seeder</a> &amp;
          <b><font color="<?=linkcolor($torrent_info["seeders"])?>"><?=intval($torrent_info["leechers"])?></font></b> <a href="<?=$leecherlink?>">Leecher</a></td>
        <td style="font-size:90%"><b><?=$torrent_info["times_completed"]?></b>x <a href="<?=$snatcherlink?>">heruntergeladen</a></td>
        <td style="font-size:90%"><b><?=$torrent_info["comments"]?></b> <a href="<?=$commlink?>">Kommentare</a></td>
        <td style="font-size:90%"><?=$torrent_info["added"]?></td>
      </tr>
    </table>
    <div id="details<?=$torrent_info["id"]?>" style="display:none;">
      <?php
            if ($torrent_info["seeders"] == 0 && $torrent_info["variant"] == "index")
                echo "<div style=\"padding:4px;\"><b><font color=\"red\">HINWEIS:</font></b> Es sind keine Seeder f�sen Torrent aktiv. ",
                "Dies bedeutet, dass Du diesen Torrent wahrscheinlich nicht fertigstellen kannst, solange nicht wieder ein Seeder aktiv wird. ",
                "Sollte der Torrent l㭧ere Zeit inaktiv gewesen und als \"Tot\" markiert worden sein, solltest Du im Forum um einen Reseed bitten, ",
                "Falls Du noch Interesse daran hast.</div>";

            ?>
      <table cellspacing="2" cellpadding="2" border="0" class="inposttable" style="width:100%;" summary="none">
        <colgroup>
          <col width="20%">
          <col width="80%">
        </colgroup>
        <?php
            if ($torrent_info["variant"] == "mytorrents") {
                echo "<tr><td nowrap valign=\"top\"><b>Sichtbar:</b></td><td>", ($torrent_info["visible"] == "yes"?"Ja":"Nein, dieser Torrent ist inaktiv und als \"Tot\" markiert"), "</td></tr>";
            } 
            if ($torrent_info["has_wait"]) {
                echo "<tr><td nowrap valign=\"top\"><b>Wartezeit:</b></td><td><font color=\"",
                $torrent_info["wait_color"], "\">", $torrent_info["wait_left"],
                " Stunde(n)</font></td></tr>";
            } 

            ?>
        <tr><td nowrap="nowrap" valign="top"><b>Letzte 10 Downloader:</b></td><td><?=$last10users?></td></tr>
        <tr><td nowrap="nowrap" valign="top"><b>&Oslash; Downloadgeschw.:</b></td><td><?=$torrent_info["dlspeed"]?> KB/s (<?php echo $torrent_info["dlspeed"] * ($torrent_info["leechers"] + $torrent_info["seeders"]);

            ?> KB/s gesamt)</td></tr>
        <tr><td nowrap="nowrap" valign="top"><b>&Oslash; Uploadgeschw.:</b></td><td><?=$torrent_info["ulspeed"]?> KB/s (<?php echo $torrent_info["ulspeed"] * ($torrent_info["leechers"] + $torrent_info["seeders"]);

            ?> KB/s gesamt)</td></tr>
        <tr><td nowrap="nowrap" valign="top"><b>Letzte Aktivit&auml;t:</b></td><td><?=$torrent_info["last_action"]?></td></tr>
        <tr><td nowrap="nowrap" valign="top"><b>Verbleibende Zeit:</b></td><td><?=$torrent_info["ttl"]?> (falls inaktiv, sonst l&auml;nger)</td></tr>
        <tr><td nowrap="nowrap" valign="top"><b>&Oslash; Verteilung:</b></td><td><div style="border:1px solid black;padding:0px;width:300px;height:15px;"><div style="border:none;width:<?=300 * $torrent_info["dist"] / 100?>px;height:15px;background-image:url(<?=$GLOBALS["PIC_BASE_URL"]?>ryg-verlauf.png);background-repeat:no-repeat;"></div></div></td></tr>
      </table>
    </div>
  <td class="tableb" valign="top" align="center" style="width:22px;padding:4px;padding-top:10px;">
    <?php if ($torrent_info["variant"] == "guestuploads") {
                if ($torrent_info["gu_agent"] == 0)
                    echo "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . "nodl.png\" width=\"22\" height=\"22\" alt=\"Nicht in Bearbeitung\" title=\"Nicht in Bearbeitung\">";
                else
                    echo "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . "taken.png\" width=\"22\" height=\"22\" alt=\"Bereits in Bearbeitung\" title=\"Bereits in Bearbeitung\">";
            } else {
                if ($torrent_info["activated"] == "yes") {
                    if (!isset($torrent_info["wait_left"]) || $torrent_info["wait_left"] == 0) {

                        ?>
    <a href="<?=$download_url?>"><img src="<?=$GLOBALS["PIC_BASE_URL"]?>download.png" width="22" height="22" alt="Torrent herunterladen" title="Torrent herunterladen" border="0"></a>
    <?php } else {

                        ?>
    <img src="<?=$GLOBALS["PIC_BASE_URL"]?>nodl.png" width="22" height="22" alt="Wartezeit nicht abgelaufen" title="Wartezeit nicht abgelaufen" border="0"
    <?php } 
                } else {

                    ?>
    <img src="<?=$GLOBALS["PIC_BASE_URL"]?>nodl.png" width="22" height="22" alt="Torrent nicht freigeschaltet" title="Torrent nicht freigeschaltet" border="0"
    <?php } 
            } 

            ?>
  </td>
</tr>
<?php
        } 

        function torrenttable($res, $variant = "index", $addparam = "")
        {
            global $CURUSER; 
            // Sortierkriterien entfernen
            $addparam_nosort = preg_replace(array("/orderby=(.*?)&amp;/i", "/sort=(.*?)&amp;/i"), array("", ""), $addparam); 
            // Hat dieser Benutzer Wartezeit?
            $has_wait = get_wait_time($CURUSER["id"], 0, true);

            ?>
<script type="text/javascript">

function expandCollapse(torrentId)
{
    var plusMinusImg = document.getElementById("plusminus"+torrentId);
    var detailRow = document.getElementById("details"+torrentId);

    if (plusMinusImg.src.indexOf("<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/plus.gif") >= 0) {
        plusMinusImg.src = "<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/minus.gif";
        detailRow.style.display = "block";
    } else {
        plusMinusImg.src = "<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/plus.gif";
        detailRow.style.display = "none";
    }
}

</script>
<table cellspacing="0" cellpadding="0" border="0" style="width:100%" summary="none"><tr>
        <td align="left"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/obenlinks.gif" alt="" title="" ></td>
<td style="width:100%" class="obenmitte"></td>
        <td align="right"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/obenrechts.gif" alt="" title="" ></td>
</tr></table>
<?php

            if ($CURUSER["oldtorrentlist"] == "yes") {

                ?>
<table border="0" cellspacing="1" cellpadding="4" class="tableinborder" style="width:100%" summary="none">
<tr>
  <td class="tablecat" align="center">Typ</td>
  <td class="tablecat" align="left">Name</td>
  <?php if ($variant == "mytorrents") {

                    ?>
  <td class="tablecat" align="center">Bearbeiten</td>
  <td class="tablecat" align="center">Sichtbar</td>  
  <?php } elseif ($variant == "guestuploads") {

                    ?>
  <td class="tablecat" align="center">In&nbsp;Bearbeitung</td>
  <?php } elseif ($has_wait) {

                    ?>
  <td class="tablecat" align="center">Wartez.</td>  
  <?php } 

                ?>
  <td class="tablecat" align="right">Dateien</td>
  <td class="tablecat" align="right">Komm.</td>
  <td class="tablecat" align="center">Hinzugef.</td>
  <td class="tablecat" align="center">TTL</td>
  <td class="tablecat" align="center">Gr&ouml;&szlig;e</td>
  <td class="tablecat" align="center">Verteilung</td>
  <td class="tablecat" align="center">Fertig</td>
  <td class="tablecat" align="right">Seeder</td>
  <td class="tablecat" align="right">Leecher</td>
  <td class="tablecat" align="left">&Oslash;&nbsp;Geschw.</td>
  <?php if ($variant == "index") {

                    ?>
  <td class="tablecat" align="center">Uploader</td>          
  <?php } 

                ?>
</tr>               
            <?php
            } else {

                ?>
<table border="0" cellspacing="1" cellpadding="0" class="tableinborder" style="width:100%" summary="none">
  <colgroup>
    <col width="32">
    <col width="100%">
    <col width="22">
  </colgroup>
            <?php
            } while ($row = mysql_fetch_assoc($res)) {
                $id = $row["id"];

                $torrent_info = array();
                $torrent_info["id"] = $row["id"];
                $torrent_info["name"] = htmlspecialchars($row["name"]);
                $torrent_info["activated"] = (isset($row["activated"])?$row["activated"]:"yes");
                $torrent_info["gu_agent"] = (isset($row["gu_agent"])?$row["gu_agent"]:0);
                $torrent_info["filename"] = $row["filename"];
                $torrent_info["variant"] = $variant;
                $torrent_info["category"] = $row["category"];
                $torrent_info["cat_name"] = $row["cat_name"];
                $torrent_info["type"] = $row["type"];
                $torrent_info["numfiles"] = ($row["type"] == "single"?1:$row["numfiles"]);
                $torrent_info["size"] = $row["size"];
                $torrent_info["times_completed"] = intval($row["times_completed"]);
                $torrent_info["seeders"] = $row["seeders"];
                $torrent_info["leechers"] = $row["leechers"];
                $torrent_info["uploaderlink"] = (isset($row["username"]) ? ("<a href=\"userdetails.php?id=" . $row["owner"] . "\"><b>" . htmlspecialchars($row["username"]) . "</b></a>") : "<i>(Gel�t)</i>");
                $torrent_info["added"] = str_replace(" ", "&nbsp;", date("d.m.Y H:i:s", sql_timestamp_to_unix_timestamp($row["added"])));
                $torrent_info["comments"] = $row["comments"];
                $torrent_info["visible"] = $row["visible"];
                $torrent_info["last_action"] = str_replace(" ", "&nbsp;", date("d.m.Y H:i:s", sql_timestamp_to_unix_timestamp($row["last_action"])));

                if (isset($row["cat_pic"]) && $row["cat_pic"] != "")
                    $torrent_info["cat_pic"] = $row["cat_pic"];

                if (isset($row["uploaderclass"]))
                    $torrent_info["uploaderclass"] = $row["uploaderclass"];

                $torrent_info["has_wait"] = $has_wait;
                if ($has_wait) {
                    $torrent_info["wait_left"] = get_wait_time($CURUSER["id"], $id);
                    $torrent_info["wait_color"] = dechex(floor(127 * ($wait_left) / 48 + 128) * 65536);
                } 

                $speedres = mysql_query("SELECT ROUND(AVG((downloaded - downloadoffset) / (UNIX_TIMESTAMP() - UNIX_TIMESTAMP(`started`)))/1024, 2) AS dlspeed, ROUND(AVG((uploaded - uploadoffset) / (UNIX_TIMESTAMP() - UNIX_TIMESTAMP(`started`)))/1024, 2) AS ulspeed FROM peers WHERE torrent=$id");
                $speed = mysql_fetch_assoc($speedres);
                if ($speed["dlspeed"] == 0) $speed["dlspeed"] = "0";
                if ($speed["ulspeed"] == 0) $speed["ulspeed"] = "0";
                $torrent_info["dlspeed"] = $speed["dlspeed"];
                $torrent_info["ulspeed"] = $speed["ulspeed"];

                $distres = mysql_query("SELECT ROUND(AVG((" . $row["size"] . " - `to_go`) / " . $row["size"] . " * 100),2) AS `dist` FROM `peers` WHERE torrent=$id");
                $dist = mysql_fetch_assoc($distres);
                $torrent_info["dist"] = $dist["dist"];

                $ttl = (28 * 24) - floor((time() - sql_timestamp_to_unix_timestamp($row["added"])) / 3600);
                if ($ttl == 1) $ttl .= " Stunde";
                else $ttl .= " Stunden";
                $torrent_info["ttl"] = $ttl;

                $newadd = "";

                $torrentunix = sql_timestamp_to_unix_timestamp($row["added"]);
                $accessunix = sql_timestamp_to_unix_timestamp($CURUSER["last_access"]);

                if ($torrentunix >= $accessunix)
                    $torrent_info["is_new"] = true;

                if ($CURUSER["oldtorrentlist"] == "yes") {
                    torrenttable_row_oldschool($torrent_info);
                } else {
                    torrenttable_row($torrent_info);
                } 
            } 

            ?>
</table>
<table cellspacing="0" cellpadding="0" border="0" style="width:100%" summary="none"><tr>
        <td align="left"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/untenlinks.gif" alt="" title="" ></td>
<td style="width:100%" class="untenmitte" align="center"></td>
        <td align="right"><img src="<?=$GLOBALS["PIC_BASE_URL"] . $GLOBALS["ss_uri"]?>/untenrechts.gif" alt="" title="" ></td>
</tr></table>
<?php
            return $rows;
        } 

        function hit_start()
        {
            global $RUNTIME_START, $RUNTIME_TIMES; 
            // $RUNTIME_TIMES = posix_times();
            $RUNTIME_START = gettimeofday();
        } 

        function hit_count()
        {
            return;
            global $RUNTIME_CLAUSE;
            if (preg_match(',([^/]+)$,', $_SERVER["SCRIPT_NAME"], $matches))
                $path = $matches[1];
            else
                $path = "(unknown)";
            $period = date("Y-m-d H") . ":00:00";
            $RUNTIME_CLAUSE = "page = " . sqlesc($path) . " AND period = '$period'";
            $update = "UPDATE hits SET count = count + 1 WHERE $RUNTIME_CLAUSE";
            mysql_query($update);
            if (mysql_affected_rows())
                return;
            $ret = mysql_query("INSERT INTO hits (page, period, count) VALUES (" . sqlesc($path) . ", '$period', 1)");
            if (!$ret)
                mysql_query($update);
        } 

        function hit_end()
        {
            return;
            global $RUNTIME_START, $RUNTIME_CLAUSE, $RUNTIME_TIMES;
            if (empty($RUNTIME_CLAUSE))
                return;
            $now = gettimeofday();
            $runtime = ($now["sec"] - $RUNTIME_START["sec"]) + ($now["usec"] - $RUNTIME_START["usec"]) / 1000000;
            $ts = posix_times();
            $sys = ($ts["stime"] - $RUNTIME_TIMES["stime"]) / 100;
            $user = ($ts["utime"] - $RUNTIME_TIMES["utime"]) / 100;
            mysql_query("UPDATE hits SET runs = runs + 1, runtime = runtime + $runtime, user_cpu = user_cpu + $user, sys_cpu = sys_cpu + $sys WHERE $RUNTIME_CLAUSE");
        } 

        function hash_pad($hash)
        {
            return str_pad($hash, 20);
        } 

        function hash_where($name, $hash)
        {
            $shhash = preg_replace('/ *$/s', "", $hash);
            return "($name = " . sqlesc($hash) . " OR $name = " . sqlesc($shhash) . ")";
        } 

        function get_user_icons($arr, $big = false)
        {
            if ($big) {
                $donorpic = "starbig.png";
                $warnedpic = "warnedbig.gif";
                $disabledpic = "disabledbig.png";
                $newbiepic = "pacifierbig.png";
                $style = "style=\"margin-left:4pt;vertical-align:middle;\"";
            } else {
                $donorpic = "star.png";
                $warnedpic = "warned.gif";
                $disabledpic = "disabled.png";
                $newbiepic = "pacifier.png";
                $style = "style=\"margin-left:2pt;vertical-align:middle;\"";
            } 

            $pics = $arr["donor"] == "yes" ? "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . $donorpic . "\" alt=\"Spender\" title=\"Dieser Benutzer hat mit einer Spende zum Erhalt des Trackers beigetragen\" border=0 $style>" : "";

            if (isset($arr["warned"]) && $arr["warned"] == "yes")
                $pics .= "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . $warnedpic . "\" alt=\"Verwarnt\" title=\"Dieser Benutzer wurde verwarnt\" border=0 $style>";

            if (isset($arr["enabled"]) && $arr["enabled"] == "no")
                $pics .= "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . $disabledpic . "\" alt=\"Deaktiviert\" title=\"Dieser Benutzer ist deaktiviert\" border=0 $style>";

            $timeadded = intval(sql_timestamp_to_unix_timestamp($arr["added"]));
            if ($timeadded > 0 && time() - $timeadded < 604800)
                $pics .= "<img src=\"" . $GLOBALS["PIC_BASE_URL"] . $newbiepic . "\" alt=\"Newbie\" title=\"Ist noch neu hier\" border=0 $style>";
            return $pics;
        } 


        ?>
