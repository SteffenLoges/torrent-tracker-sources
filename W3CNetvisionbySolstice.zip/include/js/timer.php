<?
function makebin($dez)
{
if ($dez<0)
$dez = 0;

$num = $dez/2;
while ($num >= 1)
if ($dez/$num > 1)
{
$ar .= 1;
$dez = $dez - $num;
$num = $num/2;
}
else
{
$ar .= 0;
$num = $num/2;
}
return $ar;
}

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$cpu = intval($_POST["cpu"]);
$prescaler = intval($_POST["prescaler"]);
$s_freq =  intval($_POST["freq"]);
$s_zeit =  intval($_POST["zeits"]);

if (isset($s_zeit))
$fout = 1/($s_zeit/1000);
else
$fout = $s_freq;

$ftimer = $cpu/$prescaler;

$T3 = $ftimer/$fout;

echo "Ergebnis: T3 = ".$T3;
echo "<br>Ergebnis Bin�r: T3 = ".makebin($T3);


}

?>


<form method=post action=timer.php>
Cpu <input name=cpu value=<?=$cpu?>> (in Hz)<br>
Prescaler <input name=prescaler value=<?=$prescaler?>><br>
Gesuchte Frequenz fout:<input name=freq value=<?=$s_freq?>>  (in Hz)<br>
Alternativ Zeitspanne:<input name=zeits value=<?=$s_zeit?>> (in Milli-Sek)<br>
<input type=submit>
</form>
