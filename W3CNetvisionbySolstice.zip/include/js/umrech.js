<!-- Funktionen fuer Umrechner -->
<!--
function ZeichenErgaenzen(Zeichen)
{
 document.Rechner.Ein.value = document.Rechner.Ein.value + Zeichen;
}
function UmrBinDez(BinChar)
{
 var prfKz = 1; var prfBin = "01";
 for (var ind = 0; ind < BinChar.length; ind++)
  if (prfBin.indexOf(BinChar.charAt(ind)) < 0 ) prfKz = -1;
 if (prfKz == -1)
 {
  document.Rechner.Aus.value = "keine Bin�r-Zahl";
  document.Rechner.Ein.focus();
 }
 else
 {
  var DezZahl = parseInt(BinChar, 2);
  document.Rechner.Aus.value = DezZahl;
 }
}
function UmrBinHex(BinChar)
{
 var prfKz = 1; var prfBin = "01";
 for (var ind = 0; ind < BinChar.length; ind++)
  if (prfBin.indexOf(BinChar.charAt(ind)) < 0 ) prfKz = -1;
 if (prfKz == -1)
 {
  document.Rechner.Aus.value = "keine Bin�r-Zahl";
  document.Rechner.Ein.focus();
 }
 else
 {
  var DezZahl = parseInt(BinChar, 2);
  var HexChar = DezZahl.toString(16);
  document.Rechner.Aus.value = HexChar;
  document.Rechner.Aus.value = document.Rechner.Aus.value.toUpperCase();
 }
}
function UmrDezBin(DezChar)
{
 var prfKz = 1; var prfDez = "0123456789";
 for (var ind = 0; ind < DezChar.length; ind++)
  if (prfDez.indexOf(DezChar.charAt(ind)) < 0 ) prfKz = -1;
 if (prfKz == -1)
 {
  document.Rechner.Aus.value = "keine Dezimal-Zahl";
  document.Rechner.Ein.focus();
 }
 else
 {
  var DezZahl = parseInt(DezChar);
  var BinChar = DezZahl.toString(2);
  document.Rechner.Aus.value = BinChar;
 }
}
function UmrDezHex(DezChar)
{
 var prfKz = 1; var prfDez = "0123456789";
 for (var ind = 0; ind < DezChar.length; ind++)
  if (prfDez.indexOf(DezChar.charAt(ind)) < 0 ) prfKz = -1;
 if (prfKz == -1)
 {
  document.Rechner.Aus.value = "keine Dezimal-Zahl";
  document.Rechner.Ein.focus();
 }
 else
 {
  var DezZahl = parseInt(DezChar);
  var HexChar = DezZahl.toString(16);
  document.Rechner.Aus.value = HexChar;
  document.Rechner.Aus.value = document.Rechner.Aus.value.toUpperCase();
 }
}
function UmrHexBin(HexChar)
{
 var prfKz = 1; var prfHex = "0123456789abcdefABCDEF";
 for (var ind = 0; ind < HexChar.length; ind++)
  if (prfHex.indexOf(HexChar.charAt(ind)) < 0 ) prfKz = -1;
 if (prfKz == -1)
 {
  document.Rechner.Aus.value = "keine Hexa-Zahl";
  document.Rechner.Ein.focus();
 }
 else
 {
  document.Rechner.Ein.value = document.Rechner.Ein.value.toUpperCase();
  var DezZahl = parseInt(HexChar, 16);
  var BinChar = DezZahl.toString(2);
  document.Rechner.Aus.value = BinChar;
 }
}
function UmrHexDez(HexChar)
{
 var prfKz = 1; var prfHex = "0123456789abcdefABCDEF";
 for (var ind = 0; ind < HexChar.length; ind++)
  if (prfHex.indexOf(HexChar.charAt(ind)) < 0 ) prfKz = -1;
 if (prfKz == -1)
 {
  document.Rechner.Aus.value = "keine Hexa-Zahl";
  document.Rechner.Ein.focus();
 }
 else
 {
  document.Rechner.Ein.value = document.Rechner.Ein.value.toUpperCase();
  var DezZahl = parseInt(HexChar, 16);
  document.Rechner.Aus.value = DezZahl;
 }
}
function BlauGelb(nr)
{
 var schalt = "schalt" + nr;
 document.getElementById(schalt).className = "gelb";
}
function GelbBlau(nr)
{
 var schalt = "schalt" + nr;
 document.getElementById(schalt).className = "blau";
}
function InfoHilfe()
{
 var grenze = Number.MAX_VALUE;
 alert
 ("Bin�r-/Dezimal-/Hexa-Umrechner Version 1.00 (besonders\n" +
  "n�tzlich f�r Programmierer, die oft ihren Taschenrechner\n" +
  "vergessen)\n\n" +
  "�2003 und alle Rechte bei www.edv-beratung-thomas.de\n\n" +
  "Das Programm ben�tigt eingeschaltetes JavaScript.\n\n" +
  "Um das Programmfenster klein zu halten, wurden Ein- und\n" +
  "Ausgabefeld in der Anzeige begrenzt. Sie k�nnen dennoch\n" +
  "\"l�ngere\" Zahlen umrechnen lassen bis zur JavaScript-\n" +
  "Obergrenze von " + grenze + ".\n\n" +
  "Verwenden Sie bei Bedarf die Zwischenablage: Sie k�nnen\n" +
  "eine Zahl mit STRG + V in das Eingabefeld einf�gen und das\n" +
  "Ergebnis mit STRG + C aus dem Ausgabefeld kopieren.\n\n" +
  "Eingabe in Exponential-Schreibweise ist nicht m�glich.");
}
//-->