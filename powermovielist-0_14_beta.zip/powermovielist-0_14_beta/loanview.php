<?php
/** powermovielist view loan information
 * $Id: loanview.php,v 1.15 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "loanview.php";
include("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Loan);

include("top.html");
echo "<center><h1>$strLoanCenterView</h1><BR> <BR><table width=95% border=2>";

if ($_GET['op'] == "cart")	{

$strSql = "SELECT * FROM " . $CFG['Prefix'] . "loanstatus WHERE UserID=$ActiveUser[ID] AND status=1 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);

echo "<TR>
	<TD class='top'>$strLinkNr</TD>
	<TD class='top'>$strTitle</TD>
	<TD class='top'>$strBorrow_Duration</TD>
	<TD class='top'>$strOwner</TD>
	<TD class='top'>$strComments</TD>
	<TD class='top'>$strOptions</TD>
</TR>
";
for($i=0;$i<$num;$i++) {
	$row = mysql_fetch_assoc($result);
echo "	<TR class='row";
echo $i%2+1;
echo "'>
		<TD>" . ($i+1) . "</TD>
		<TD>";
		$strSql = "SELECT ListID FROM " . $CFG['Prefix'] . "movies WHERE ID=$row[MovieID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't  execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		$row1=mysql_fetch_assoc($result1);
		$title=GetMovieTitle($row['MovieID'], $row1['ListID']);
		echo $title;
				
echo "	</TD>
		<TD><CENTER>$row[Duration] Days <form name=\"DurationForm\" method=\"post\" action=\"loan.php$GlobalArg&op=DurationRequest&MovieID=$row[MovieID]\"><input type=\"text\" size=\"1\" name=\"Duration\"><input type=\"submit\" name=\"Submit\" value=\"$strUpdate\"></form></CENTER></TD>
		<TD>";
		$strSql = "SELECT " . $CFG['Prefix'] . "users.name FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "lists," . $CFG['Prefix'] . "users WHERE " . $CFG['Prefix'] . "movies.ID=$row[MovieID] AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=" . $CFG['Prefix'] . "users.ID";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$owner=mysql_fetch_assoc($result1);
		echo $owner['name'];
echo" 	</TD>
		<TD><CENTER>$row[Comment]<form name=\"CommentsForm\" method=\"post\" action=\"loan.php$GlobalArg&op=Commentscart&MovieID=$row[MovieID]\"><input type=\"text\" size=\"5\" name=\"Comments\"><input type=\"submit\" name=\"Submit\" value=\"$strUpdate\"></form></CENTER></TD>";		
echo"	<TD>
		<a href='loan.php".$GlobalArg."&op=delete_cart&MovieID=".$row['MovieID']."' target=_top><B>$strDelete</B></a>  /  
		<a href='loan.php".$GlobalArg."&op=reserve_item&MovieID=".$row['MovieID']."' target=_top><B>$strReserve</B></a> </TD>
	</TR>
";
}
}

if ($_GET['op'] == "request")	{
$strSql = "SELECT " . $CFG['Prefix'] . "loanstatus.* FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "loanstatus," . $CFG['Prefix'] . "lists WHERE " . $CFG['Prefix'] . "movies.ID=" . $CFG['Prefix'] . "loanstatus.MovieID AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=$ActiveUser[ID] AND status=2 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);

echo "<TR>
	<TD class='top'>$strLinkNr</TD>
	<TD class='top'>$strTitle</TD>
	<TD class='top'>$strDateOfRequest</TD>
	<TD class='top'>$strBorrow_Duration</TD>
	<TD class='top'>$strRequestor</TD>
	<TD class='top'>$strComments</TD>
	<TD class='top'>$strOptions</TD>
</TR>
";

for($i=0;$i<$num;$i++) {
	$row = mysql_fetch_assoc($result);
echo "	<TR class='row";
echo $i%2+1;
echo "'>
		<TD>" . ($i+1) . "</TD>
		<TD>";
		$strSql = "SELECT ListID FROM " . $CFG['Prefix'] . "movies WHERE ID=$row[MovieID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't  execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		$row1=mysql_fetch_assoc($result1);
		$title=GetMovieTitle($row['MovieID'], $row1['ListID']);
		echo $title;
echo "	</TD>
		<TD><CENTER>$row[date]</CENTER></TD>";
echo "	<TD><CENTER>$row[Duration] Days <form name=\"DurationForm\" method=\"post\" action=\"loan.php$GlobalArg&op=DurationApprove&MovieID=$row[MovieID]\"><input type=\"text\" size=\"1\" name=\"Duration\"><input type=\"submit\" name=\"Submit\" value=\"$strUpdate\"></form></CENTER></TD>
		<TD>";
		$strSql = "SELECT name FROM " . $CFG['Prefix'] . "users WHERE ID=$row[UserID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row2=mysql_fetch_assoc($result1);
		echo $row2['name'];
echo" 	</TD>
<TD><CENTER>$row[Comment]<form name=\"CommentsForm\" method=\"post\" action=\"loan.php$GlobalArg&op=Commentsrequests&MovieID=$row[MovieID]\"><input type=\"text\" size=\"5\" name=\"Comments\"><input type=\"submit\" name=\"Submit\" value=\"$strUpdate\"></form></CENTER></TD>";		echo"	<TD>
		<a href='loan.php".$GlobalArg."&op=delete_request&MovieID=".$row['MovieID']."&UserID=".$row['UserID']."' target=_top><B>$strDelete</B></a>  /  
		<a href='loan.php".$GlobalArg."&op=approve_item&MovieID=".$row['MovieID']."&UserID=".$row['UserID']."' target=_top><B>$strLoan</B></a> </TD>
	</TR>
";
}
}
	
if ($_GET['op'] == "loans")	{
$strSql = "SELECT " . $CFG['Prefix'] . "loanstatus.* FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "loanstatus," . $CFG['Prefix'] . "lists WHERE " . $CFG['Prefix'] . "movies.ID=" . $CFG['Prefix'] . "loanstatus.MovieID AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=$ActiveUser[ID] AND status=3 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);

echo "<TR>
	<TD class='top'>$strLinkNr</TD>
	<TD class='top'>$strTitle</TD>
	<TD class='top'>$strDateOfLoan</TD>
	<TD class='top'>$strDueBack</TD>
	<TD class='top'>$strBorrower</TD>
	<TD class='top'>$strComments</TD>
	<TD class='top'>$strOptions</TD>
</TR>
";

for($i=0;$i<$num;$i++) {
	$row = mysql_fetch_assoc($result);
echo "	<TR class='row";
echo $i%2+1;
echo "'>
		<TD>" . ($i+1) . "</TD>
		<TD>";
		$strSql = "SELECT ListID FROM " . $CFG['Prefix'] . "movies WHERE ID=$row[MovieID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't  execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		$row1=mysql_fetch_assoc($result1);
		$title=GetMovieTitle($row['MovieID'], $row1['ListID']);
		echo $title;
echo "	</TD>
		<TD><CENTER>$row[date]</CENTER></TD>
		<TD><CENTER>";
$duedate = strtotime($row['date']);
$duedate = $duedate+(60*60*24*$row['Duration']);
echo date("Y-m-d",$duedate);
echo "  </CENTER></TD>
		<TD>";
		$strSql = "SELECT name FROM " . $CFG['Prefix'] . "users WHERE ID=$row[UserID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row2=mysql_fetch_assoc($result1);
		echo $row2['name'];
echo" 	</TD>
<TD><CENTER>$row[Comment]<form name=\"CommentsForm\" method=\"post\" action=\"loan.php$GlobalArg&op=Commentsloans&MovieID=$row[MovieID]\"><input type=\"text\" size=\"5\" name=\"Comments\"><input type=\"submit\" name=\"Submit\" value=\"$strUpdate\"></form></CENTER></TD>";		echo"	<TD>
		<a href='loan.php".$GlobalArg."&op=delete_loan&MovieID=".$row['MovieID']."&UserID=".$row['UserID']."' target=_top><B>$strDelete</B></a> </TD>
	</TR>
";
}
}

if ($_GET['op'] == "borrowed")	{

$strSql = "SELECT * FROM " . $CFG['Prefix'] . "loanstatus WHERE UserID=$ActiveUser[ID] AND status=3 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);

echo "<TR>
	<TD class='top'>$strLinkNr</TD>
	<TD class='top'>$strTitle</TD>
	<TD class='top'>$strDateOfLoan</TD>
	<TD class='top'>$strDueBack</TD>
	<TD class='top'>$strComments</TD>
	<TD class='top'>$strOwner</TD>
	</TR>
";
for($i=0;$i<$num;$i++) {
	$row = mysql_fetch_assoc($result);
echo "	<TR class='row";
echo $i%2+1;
echo "'>
		<TD>" . ($i+1) . "</TD>
		<TD>";
		$strSql = "SELECT ListID FROM " . $CFG['Prefix'] . "movies WHERE ID=$row[MovieID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't  execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		$row1=mysql_fetch_assoc($result1);
		$title=GetMovieTitle($row['MovieID'], $row1['ListID']);
		echo $title;
				
echo "	</TD>
		<TD><CENTER>$row[date]</CENTER></TD>
		<TD><CENTER>";
$duedate = strtotime($row['date']);
$duedate = $duedate+(60*60*24*$row['Duration']);
echo date("Y-m-d",$duedate);
echo "  </CENTER></TD>
		<TD><CENTER>$row[Comment]</CENTER></TD>";
echo"	<TD>";
		$strSql = "SELECT " . $CFG['Prefix'] . "users.name FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "lists," . $CFG['Prefix'] . "users WHERE " . $CFG['Prefix'] . "movies.ID=$row[MovieID] AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=" . $CFG['Prefix'] . "users.ID";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row2=mysql_fetch_assoc($result1);
		echo $row2['name'];
echo" 	</TD>
		</TR>
";
}
}


echo "</table></CENTER>\n";

?>