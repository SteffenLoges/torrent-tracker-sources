<?php
/** powermovielist edit rights
 * $Id: editgrouprights.php,v 1.5 2005/10/25 18:15:51 niko Exp $
*/
$FILE_SELF = "editgrouprights.php";
include_once("application.php");

if($CFG['ListType'] >= 2) {
	include("top.html");
	echo "This feature is not enabled for this list. Please use another list-type.";
	exit;
}

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

$Title = "Usergroup-Rights";
$TitlePl = "Usergroup-Rights";

$SelectFrom = "$CFG[Prefix]usergroup.UG_ID, Name, Permissions, FetchRights";
$Table = "$CFG[Prefix]usergroup";
$joinTable = "LEFT JOIN $CFG[Prefix]group2list ON $CFG[Prefix]group2list.UG_ID=$Table.UG_ID AND $CFG[Prefix]group2list.L_ID=$ActiveList[ID]";

$Filter = "";
$FilterVal = "";

$SessionVar = "editgrouprights";

$primaryKey = "UG_ID";

$DisplayFilterButton = "search";
$i=0;
$DisplayFilter[$i]['name'] = "name";
$DisplayFilter[$i]['text'] = $strSearchFor;
$DisplayFilter[$i]['type'] = "text";
$DisplayFilter[$i]['sql'] = "(name LIKE '%_Text%')";

$ShowEditLinks = false;
$DisplayFormList = true;
$HideAddLink = true;


$i=0;
$Show[$i]['name'] = "Name";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = "Group";
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;
$Show[$i]['sortkey'] = "name";
$Show[$i]['sortdir'] = 0;
$Show[$i]['sortdef'] = true;
$i++;
$Show[$i]['text'] = "Permissions";
$Show[$i]['name'] = "Permissions";
$Show[$i]['type'] = "editlistbox";
$Show[$i]['delemiter'] = "|";
$Show[$i]['prop'] = $strUserRights[0]."|".$strUserRights[1];
$Show[$i]['values'] = "0|1";
if($Active!="index") {
    $Show[$i]['prop'] .= "|".$strUserRights[2]."|".$strUserRights[3]."|".$strUserRights[4]."|".$strUserRights[5];
    $Show[$i]['values'] .= "|2|3|4|5";
}
$Show[$i]['main'] = true;
if($Active!="index") {
    $i++;
    $Show[$i]['text'] = "Fetch-Rights";
    $Show[$i]['name'] = "FetchRights";
    $Show[$i]['type'] = "func";
    $Show[$i]['func'] = "printFetch";
    $Show[$i]['main'] = true;
}
$i++;
$Show[$i]['name'] = "users";
$Show[$i]['type'] = "func";
$Show[$i]['text'] = "Users";
$Show[$i]['comm'] = "";
$Show[$i]['func'] = "printUsers";
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

if(!($action=="" || $action=="listsave"))
	ErrorExit("invalid action!");

$DOC_TITLE = $Title;
include("top.html");


if($action=="listsave")
{
    foreach($_POST['Permissions'] as $UG_ID=>$Permissions) {
        if($Permissions==0) {
            $strSql = "DELETE FROM $CFG[Prefix]group2list WHERE UG_ID=$UG_ID AND L_ID='$ActiveList[ID]'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        } else {
            if(isset($_POST['FetchRights'][$UG_ID])) {
                $Fetch = 1;
            } else {
                $Fetch = 0;
            }
            $strSql = "REPLACE INTO $CFG[Prefix]group2list (UG_ID, L_ID, Permissions, FetchRights) VALUES ('$UG_ID', '$ActiveList[ID]', '$Permissions', '$Fetch')";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }
    }
    $action = "";
    $_GET['action'] = "";
}


include("edit.php");


include("bottom.html");


function printUsers($ID) {
    global $GlobalArg,$CFG, $pmldb;
    $strSql = "SELECT COUNT(u2g.U_ID) FROM $CFG[Prefix]user2group u2g WHERE u2g.UG_ID='$ID'";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row = mysql_fetch_row($result);
    if($row[0] > 8) {
        echo $row[0]." users";
    } else {
        $strSql = "SELECT u.Name FROM $CFG[Prefix]user2group u2g, $CFG[Prefix]users u WHERE u2g.U_ID=u.ID AND u2g.UG_ID='$ID'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $fs="";
        while($row=mysql_fetch_row($result)) {
            $fs .= $row[0].", ";
        }
        if($fs=="")
            $fs="none";
        else
            $fs=substr($fs,0,-2); //trim the ", "
        echo $fs;
    }
}
function printFetch($ID, $row)
{
    if($row['Permissions']==-1) return;
    if($row['Permissions']<PML_Rights_Add) return;
    $Sel = $row['FetchRights'];
    echo "<INPUT TYPE='checkbox' NAME='FetchRights[" . $ID . "]' value='set'";
    if($Sel) echo " checked";
    echo ">";
}
?>