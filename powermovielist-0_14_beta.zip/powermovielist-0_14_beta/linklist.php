<?php
/** powermovielist edit linklist
 * $Id: linklist.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "linklist.php";
$LoadSmarty=true;
include_once("application.php");

if($CFG['ListType'] >= 2 || $CFG['LinkListType']==PML_LinkListType_None) {
	include("top.html");
	echo "This feature is not enabled for this list. Try to use another ListType and activate the LinkList.";
	exit;
}

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";


if($action=="add" || $action=="edit") {
	$ID = $_GET['ID'];
	if($action=="edit") {
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist WHERE ID=$ID";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		$row1 = mysql_fetch_assoc($result);
	}

	$UserText =  '<SELECT NAME="inUser">\n';
	$i=0;

	if($CFG['EnableIndex']) {
		//Index-Page:
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name LIKE 'index'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_array($result);
		$UserText .= '<option value="' . $row['ID'] . '"';
		$UserText .= '>' . addslashes($row['title']) . "</option>\n";
		if($action=="edit") {
			if($row1['ListID']==$row['ID']) $SelEditIndex = 0;
		}
	}

	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name NOT LIKE 'index'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	for($i=0;$i<mysql_num_rows($result);$i++) {
		$row = mysql_fetch_array($result);
		$UserText .= '<option value="' . $row['ID'] . '"';
		$UserText .= '>' . addslashes($row['name'])." (".addslashes($row['title']) . ")</option>\n";
		if($action=="edit") {
			if($row1['ListID']==$row['ID']) $SelEditIndex = $i+1;
		}
	}
	$UserText .= '</SELECT>';
	$UserText = str_replace("\n", "\\n", $UserText);

	$UrlText = '<INPUT TYPE="text" NAME="inUrl" size=40>';

	$JavaScriptText = "
function ShowUser(SelIndex) {
  document.getElementById('inTypeField').innerHTML='$UserText';
  document.getElementById('inTypeHead').innerHTML='List:';
  if(SelIndex)
	  document.Form1.inUser.selectedIndex=SelIndex;
}
function ShowUrl(UrlText) {
  if(!UrlText) UrlText='http://';
  document.getElementById('inTypeField').innerHTML='<INPUT TYPE=\"text\" NAME=\"inUrl\" size=40 VALUE=\"'+UrlText+'\">';
  document.getElementById('inTypeHead').innerHTML='Url:';
}
";

if($action=="add") {
	$OnLoad = "ShowUser();";
} else {
	//echo $SelEditIndex;
	//exit;
	if($row1['Type']=="User")
		$OnLoad = "ShowUser($SelEditIndex);";
	else
		$OnLoad = "ShowUrl('$row1[Url]');";
}
}

$DOC_TITLE = "Edit Link-List";
include("top.html");






if($action=="up") {
	$ID = $_GET['ID'];
	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist ORDER BY SortOrder";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
	$num = mysql_num_rows($result);
	for($i=0;$i<$num;$i++) {
		$row = mysql_fetch_assoc($result);
		if($row['ID']==$ID) {
			if($i==0) //ist bereits ganz oben...
				break;
			$strSql = "UPDATE " . $CFG['Prefix'] . "linklist SET SortOrder='$lastorderid' WHERE ID=$ID";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
			$strSql = "UPDATE " . $CFG['Prefix'] . "linklist SET SortOrder='$row[SortOrder]' WHERE ID=$lastid";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
			break;
		}
		$lastorderid=$row['SortOrder'];
		$lastid=$row['ID'];
	}
} //endif $action

if($action=="down") {
	$ID = $_GET['ID'];
	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist ORDER BY SortOrder";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
	$num = mysql_num_rows($result);
	for($i=0;$i<$num;$i++) {
		$row = mysql_fetch_assoc($result);
		if($row['ID']==$ID) {
			if($i==$num-1) //ist bereits ganz oben...
				break;
			$lastorderid=$row['SortOrder'];
			$lastid=$row['ID'];
			$row=mysql_fetch_assoc($result);
			$strSql = "UPDATE " . $CFG['Prefix'] . "linklist SET SortOrder='$lastorderid' WHERE ID=$row[ID]";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
			$strSql = "UPDATE " . $CFG['Prefix'] . "linklist SET SortOrder='$row[SortOrder]' WHERE ID=$lastid";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
			break;
		}
	}

} //endif $action


if($action=="del") {
	$ID = $_GET['ID'];
	$strSql = "DELETE FROM " . $CFG['Prefix'] . "linklist WHERE ID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		

} //endif $action

if($action=="add" || $action=="edit") {
echo "<h1>";
if($action=="add") echo $strLinkAdd;
if($action=="edit") echo $strLinkEdit;
echo "</h1>";
?>
<FORM NAME='Form1' METHOD=POST ACTION="linklist.php?action=<?php echo $action?>save<?php if($action=="edit") echo "&ID=$row1[ID]";?>">
<TABLE>
<TR>
	<TD valign=top align=right><?php echo $strLinkText?>:</TD>
	<TD><INPUT TYPE="text" NAME="inText" size=30 VALUE="<?php if($action=="edit") echo $row1['Text']?>"></TD>
	<TD></TD>
</TR>
<TR>
	<TD valign=top align=right><?php echo $strLinkType?>:</TD>
	<TD>
		<INPUT TYPE="radio" NAME="inType" VALUE="User" onClick="ShowUser()"<?php if($action=="add" || ($action=="edit"&&$row1['Type']=="User")) echo " checked";?>><?php echo $strLinkTypList?><br>
		<INPUT TYPE="radio" NAME="inType" VALUE="Url" onClick="ShowUrl()"<?php if($action=="edit"&&$row1['Type']=="Url") echo " checked";?>><?php echo $strLinkTypUrl?>
	</TD>
	<TD></TD>
</TR>

<TR>
	<TD valign=top align=right>
<div id="inTypeHead">
User/Url:
</div>
	</TD>
	<TD>
<div id="inTypeField">
<?php echo str_replace("\\'","'",$UserText)?>
<br>
<?php echo $UrlText?>
</div>
</TD>
<TR>
	<TD></TD>
	<TD><INPUT TYPE="submit"></TD>
	<TD></TD>
</TR>
</TABLE>
</FORM>
<?
exit;
} //endif $action







if($action=="addsave") {
	$ID = $_GET['ID'];

	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist ORDER BY SortOrder DESC";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_assoc($result);
	$inSortOrder = $row['SortOrder']+1;
	
	$strSql = "INSERT INTO " . $CFG['Prefix'] . "linklist (Type, ListID, Url, Text, SortOrder) VALUES ('$_POST[inType]', '$_POST[inUser]', '$_POST[inUrl]', '$_POST[inText]', '$inSortOrder')";
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	echo "$strLinkSaved<br>";
}

if($action=="editsave") {
	$ID = $_GET['ID'];

	$strSql = "UPDATE " . $CFG['Prefix'] . "linklist SET Type='$_POST[inType]', ListID='$_POST[inUser]', Url='$_POST[inUrl]', Text='$_POST[inText]' WHERE ID=$ID";
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	echo "$strLinkSaved<br>";
}


$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist ORDER BY SortOrder";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);
echo "<h1>$strLinkEditList</h1>
<table>
<TR>
	<TD class='top'>$strLinkNr</TD>
	<TD class='top'>$strLinkText</TD>
	<TD class='top'>$strLinkType</TD>
	<TD class='top'>$strLinkUrlUser</TD>
	<TD class='top'>$strLinkHdEdit</TD>
</TR>
";

for($i=0;$i<$num;$i++) {
	$row = mysql_fetch_assoc($result);
echo "	<TR class='row";
echo $i%2+1;
echo "'>
		<TD>" . ($i+1) . "</TD>
		<TD>$row[Text]</TD>
		<TD>$row[Type]</TD>
		<TD>";
		if($row['Type']=="User") {
			$strSql = "SELECT name FROM " . $CFG['Prefix'] . "lists WHERE ID=$row[ListID]";
			$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
			$row1=mysql_fetch_assoc($result1);
			if($row1['name']=="")
				echo "Index-Page";
			else
				echo $row1['name'];
		} else
			echo $row['Url'];
		
echo "	</TD>
		<TD><a href='linklist.php".$GlobalArg."action=up&ID=$row[ID]'>up</a> 
			<a href='linklist.php".$GlobalArg."action=down&ID=$row[ID]'>down</a> 
			<a href='linklist.php".$GlobalArg."action=del&ID=$row[ID]'>del</a> 
			<a href='linklist.php".$GlobalArg."action=edit&ID=$row[ID]'>edit</a> 
	</TR>
";
}
echo "</table>\n";

echo "<br><a href='linklist.php".$GlobalArg."action=add'>$strLinkAdd</a><br>\n";


//clear smarty-cache for all lists, all templates
if($action=="addsave" || $action=="editsave" || $action=="up" || $action=="down" || $action=="del") {
	$smarty->clear_cache(null,"list");
}


include("bottom.html");
?>