<?
/** powermovielist install and config script
 * $Id: install.php,v 1.39 2006/01/01 12:23:55 niko Exp $
*/
$StartTime = microtime();

define("PML_Update_AllOK", 1);
define("PML_Update_Notice", 2);
define("PML_Update_Warning", 3);
define("PML_Update_Error", 4);

$InfoMsg['install'] = "<table width=\"90%\" border=\"0\">
  <tr>
    <td><b>Requirements:</b></td>
  </tr>
  <tr>
    <td>
      <ul>
        <li>a running Web-Server with <a href='http://www.php.net/'>PHP4</a> and <a href='http://www.mysql.org/'>MySQL</a>
        <li>a lot of movies</li>
      </ul>
    </td>
  </tr>
  <tr>
    <td><b>Recommended:</b></td>
  </tr>
  <tr>
    <td>
      <ul>
        <li>a Linux-Server</li>
        <li>Apache Web-Server</li>
        <li>the gd-libaries for PHP</li>
        <li>fast Internet-Connection</li>
        <li>even more moviez ;-)</li>
      </ul>
    </td>
  </tr>

  <tr>
    <td><b>Installation:</b></td>
  </tr>
  <tr>
    <td>
      <ol>
        <li>copy all files into a dir of your web-server</li>
        <li>the dir where you copied the PowerMovieList has to be writable for the install-script (eg. chown wwwrun &lt;dir&gt;)</li>
        <li>open install.php in your browser</li>
        <li>enter all information</li>		
        <li>done! (hopefully ;-)</li>
      </ol>
    </td>
  </tr>
  <tr>
    <td>
      If you have any questions or you found a bug, please visit <a href=\"http://www.powermovielist.com/\">www.powermovielist.com</a> and leave a message in the forum (board)
    </td>
  </tr>
</table>\n";
$InfoMsg['update'] = "<table width=\"90%\" border=\"0\">
  <tr>
    <td><b>How to update:</b></td>
  </tr>
  <tr>
    <td>
      <ol>
        <li><b>important:</b> backup your database</li>
        <li>unpack all files to the pml-directory (you have done that allready :D)
        <li>check again that the backup did indeed work...</li>
        <li>then click update on this page</li>
        <li>done! (hopefully ;-)</li>
        <li>if you get any errormessages, ask for help on <a href=\"http://www.powermovielist.com/\">www.powermovielist.com</a> in the board</li>
      </ol>
    </td>
  </tr>
  <tr>
        <td>
          If you have any questions or you found a bug, please visit <a href=\"http://www.powermovielist.com/\">www.powermovielist.com</a> and leave a message in the forum (board)
        </td>
  </tr>
</table>\n";

include("version.php");
require_once("functions.php");

@error_reporting(E_ALL);

$FILE_SELF = "install.php";

if(isset($_GET['action'])) $action = $_GET['action']; else $action="";

if($action=="") {
	if(!file_exists(getcwd()."/config.inc.php")) {
		$action = "install1";
	} else {
		include("config.inc.php"); //get the current vesion-build-nr
        if(!isset($ConfigVerBuild)) $ConfivVerBuild=0;
        if($ConfigVerBuild==0) {
            die("your config.inc.php is invalid!");
        }
		if($ConfigVerBuild!=$VerBuild)
			$action = "update1";
		else
			$action = "config";
	}
}

switch($action) {
	case "info":
	case "showinfo";
		if(file_exists(getcwd()."/config.inc.php")) {
			//if allready installed speradmin-rights are required
			require("application.php");
			RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
		}
		phpinfo();
		exit;
		break;
	case "install1":
		if(!isset($CFG['Debug'])) $CFG['Debug'] = false;

		if(file_exists(getcwd()."/config.inc.php"))
			die("can't install, is allready installed");

		$GlobalArg = "?";
		PrintInfo("install1");
		break;
	case "install2":
		if(!isset($CFG['Debug'])) $CFG['Debug'] = false;

		if(file_exists(getcwd()."/config.inc.php"))
			die("can't install, is allready installed");

		$GlobalArg = "?";
		//the settings have to be:
		//  magic_quotes_gpc on
		//  magic_quotes_runtime off
		if(get_magic_quotes_gpc()==0 || get_magic_quotes_runtime()==1) {			
			PrintInfo("magicquoteserr");
		}

		if(!is_writeable(getcwd()."/")) {
			PrintInfo("installcfgwriteerr");
		}
		PrintInfo("install2");
		break;
	case "install3":
		if(!isset($CFG['Debug'])) $CFG['Debug'] = false;

		if(file_exists(getcwd()."/config.inc.php"))
			die("can't install, is allready installed");

		$GlobalArg = "?";
		
		$PostImport = array("DatabaseAdress","DatabaseUser","DatabasePass","DatabaseName");
		foreach($PostImport as $Dat) {
			if(!isset($_POST[$Dat]))
				die("error: _POST[$Dat] not set");
			$CFG[$Dat] = $_POST[$Dat];
		}

		//check database-connection		
		$pmldb = mysql_connect($CFG['DatabaseAdress'], $CFG['DatabaseUser'], $CFG['DatabasePass']);
		if(!$pmldb) {
			PrintInfo("cantconnect", mysql_error($pmldb));
		}
		if(!mysql_select_db($CFG['DatabaseName'], $pmldb)) {			
			if(!pml_mysql_query("CREATE DATABASE `$CFG[DatabaseName]`", $pmldb)) {
				PrintInfo("cantcreatedb", mysql_error($pmldb));
			}
			mysql_select_db($CFG['DatabaseName'], $pmldb);
		}

		//check if there isnt allready a pml-installation in the db
		$strSql = "SHOW TABLES FROM `$CFG[DatabaseName]`";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		while($row = mysql_fetch_row($result)) {
			if(substr($row[0],0,4)=="pml_") {
				PrintInfo("dbnotempty");
			}
		}
		
		//display select list-type (+ info/help)
		PrintInfo("install3");
		break;
	case "install4":
		if(!isset($CFG['Debug'])) $CFG['Debug'] = false;

		if(file_exists(getcwd()."/config.inc.php"))
			die("can't install, is allready installed");

		$GlobalArg = "?";
		$PostImport = array("DatabaseAdress","DatabaseUser","DatabasePass","DatabaseName","ListType");
		foreach($PostImport as $Dat) {
			if(!isset($_POST[$Dat]))
				die("error: _POST[$Dat] not set");
			$CFG[$Dat] = $_POST[$Dat];
		}

		PrintInfo("install4");
		break;
	case "install5":
		if(!isset($CFG['Debug'])) $CFG['Debug'] = false;

		if(file_exists(getcwd()."/config.inc.php"))
			die("can't install, is allready installed");

		$GlobalArg = "?";
		$PostImport = array("DatabaseAdress","DatabaseUser","DatabasePass","DatabaseName","ListType","HttpPath","AdminEmail","LinkListType");
		foreach($PostImport as $Dat) {
			if(!isset($_POST[$Dat]))
				die("error: _POST[$Dat] not set");
			$CFG[$Dat] = $_POST[$Dat];
		}
		if(substr($CFG['HttpPath'],-1,1)!="/") $CFG['HttpPath'] .= "/";  //add slash at the end...

		$PostImport = array("EnableIndex","ShowRegisterList","ShowRegisterUser","UseActivate","EnableImportSettings","EnableCoverCreate","UseCache");
		foreach($PostImport as $Dat) {
			$CFG[$Dat] = isset($_POST[$Dat]);
		}

		/*   == disabled, as on the time of the installation smarty-security can't be false - this check has to be done in update and config
		//  - warning for smarty-security + import-setting
		if($CFG['EnableImportSettings']=="TRUE" && $CFG['SmartySecurity']=="FALSE") {
			echo "<br><br><b>WARNING:</b> you disabled smarty-security and enabled the import-settings-feature! If your templates won't work with smarty-security enabled you really should disable import-settings!<br>To enable smarty-security edit config.inc.php manually.<br><br>\n";
		} */

		if($CFG['EnableImportSettings']) {
			//check if dirs are writeable
			$Dat = array("fetch","image/logos","templates/index","templates/list","templates/popup","css");
			foreach($Dat as $Dir) {
				if(!is_writeable(getcwd()."/".$Dir."/")) {
					PrintInfo("importsetnotwriteable", $Dir, $Dat);
				}
			}
		}
		
		$CFG['CacheDir'] = "./cache/";
		$CFG['UploadDir'] = "./upload/";
		$CFG['CompileDir'] = "./templates_c/";		
		$CFG['CompileDir'] = "./templates_c/";
        $CFG['SmartyCacheDir'] = "./smarty_cache/";
        $CFG['FetchCacheDir'] = "./fetch_cache/";
		
		if(!IsWriteable($CFG['CacheDir'])) {
			PrintInfo("notwriteable", $CFG['CacheDir']);
		}
		if(!IsWriteable($CFG['UploadDir'])) {
			PrintInfo("notwriteable", $CFG['UploadDir']);
		}
		if(!IsWriteable($CFG['CompileDir'])) {
			PrintInfo("notwriteable", $CFG['CompileDir']);
		}
		if(!IsWriteable($CFG['SmartyCacheDir'])) {
			PrintInfo("notwriteable", $CFG['SmartyCacheDir']);
		}
		if(!IsWriteable($CFG['FetchCacheDir'])) {
			PrintInfo("notwriteable", $CFG['FetchCacheDir']);
		}


	//some default-config-vaiables
        $CFG['UseUserStatus'] = false;
        $CFG['SmartyCacheHandler'] = "";
        $CFG['AllowCommentVoteGuest'] = true;
        $CFG['UseCounter'] = true;
        $CFG['CacheLifetimeList'] = 60*60*24;
        $CFG['CacheLifetimeIndex'] = 60*15;
        $CFG['CacheClearOnChangeList'] = true;
        $CFG['BadwordsFile'] = "";
        $CFG['PopupBadwordsRedirect'] = "";
        $CFG['EMailBlackListFile'] = "";
        $CFG['ShowUserDetails'] = true;

		$CFG['CustomPropTypes'][101]['name'] = "Date Added";
		$CFG['CustomPropTypes'][101]['sqlFunc'] = "propTypeDateAddedSql";
		$CFG['CustomPropTypes'][102]['name'] = "Clicks";
		$CFG['CustomPropTypes'][102]['sqlFunc'] = "propTypeClicksSql";
		$CFG['CustomPropTypes'][103]['name'] = "User Added";
		$CFG['CustomPropTypes'][103]['sqlFunc'] = "propTypeUserAddedSql";
		$CFG['CustomPropTypes'][104]['name'] = "Number of Comments";
		$CFG['CustomPropTypes'][104]['sqlFunc'] = "propTypeCommentsSql";

		$StatusMsg = "";

		$strSql = implode(file("tables.sql"),"");
        $Dat = array();
        PMA_splitSqlFile($Dat, $strSql);
		
		ConnectDatabase();

        foreach($Dat as $strSql) {
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }
        $StatusMsg .= "tables created...<br>\n";

        $strSql = "INSERT INTO pml_users (ID,name) VALUES (1,'Guest')";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $strSql = "INSERT INTO pml_lists (ID,name,title,listtpl,StdPerPage) VALUES (1,'index','Index-Page','index.tpl',5)";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);				
        $strSql = "INSERT INTO pml_usergroup (UG_ID, Name, IsDefault) VALUES (1, 'Default', '1');";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $strSql = "INSERT INTO pml_group2list (UG_ID, L_ID, Permissions) VALUES (1, 1, '".PML_Rights_View."');";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $strSql = "INSERT INTO pml_user2group (U_ID, UG_ID) VALUES ('1', '1')";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$StatusMsg .= "guest-user and index-page created...<br>\n";
        
        //eintrag in linklist erstellen
        $strSql = "INSERT INTO pml_linklist (Type,ListID,Text,SortOrder) VALUES ('User','1','Index-Page',1)";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        
        //insert default indexitems
        $strSql = array();
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Poster', 1, 'Poster', 1)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Title', 2, 'Title', 1)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Year', 3, 'Year', 1)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Genre', 4, 'Genre', 0)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Starring', 5, 'Starring', 0)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('DateAdded', 6, 'Added', 0)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Comment', 7, 'Comment', 0)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('UserName', 8, 'Added By', 0)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('ListName', 9, 'ListName', 1)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('ListTitle', 10, 'ListTitle', 1)";
        $strSql[] = "INSERT INTO pml_indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Plot', 11, 'Plot', 1)";
        foreach($strSql as $i) {
            pml_mysql_query($i, $pmldb) or trigger_error("can't execute:<pre>$i</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }

        //set the standard-values for the rest of the config-options:
		$CFG['Prefix'] = "pml_";		
		$CFG['MaxExecutionTime'] = 30;
		$CFG['Debug'] = FALSE;
		$CFG['MaxUploadSize'] = 51200;
		if(!defined("SMARTY_DIR"))
			define("SMARTY_DIR", getcwd()."/smarty/");
		$CFG['CacheDir'] = "./cache/";
		$CFG['CacheDirHttp'] = $CFG['CacheDir'];        
		$CFG['UploadDir'] = "./upload/";
		$CFG['UploadDirHttp'] = $CFG['UploadDir'];        
        $CFG['FetchCacheDir'] = "./fetch_cache/";

        $CFG['SmartyCacheDir'] = "./smarty_cache/";
		$CFG['CompileDir'] = "./templates_c/";
		$CFG['SmartySecurity'] = TRUE;
        if(ini_get("safe_mode")=="1") $CFG['SmartyUseSubDirs'] = false; else $CFG['SmartyUseSubDirs'] = true;
        $CFG['UserClass'] = "standalone.php";
        $CFG['UploadExt'] = ".jpg;.jepg;.gif;.png;.html;.htm;.txt;.doc;.torrent;.zip;.gz;.rar;.ace;.nfo";
		$CFG['DisablePropTypes'] = array();
		$CFG['AddDownloadLinkFields'] = array();
    	$CFG['UseDloadLog'] = true;
        $CFG['UseDloadCounter'] = true;
    	$CFG['UseStatistics'] = true;

		WriteConfig($CFG);
		$StatusMsg .= "config.inc.php written...<br>\n";
        
        $Dat = $_SERVER['REQUEST_URI'];
        $Pos=strpos($Dat, "install.php");
        $Dat = substr($Dat, 0, $Pos);
        $Dat .= "redirect.php";
        $Dat = "ErrorDocument 404 ".$Dat;
        $fp = @fopen(".htaccess","w");
        if(!$fp) {
            $StatusMsg .= "WARNING: .htaccess could not be created! you can't use yourpage.com/listname shortcuts!<br>\n";
        } else {
            @fwrite($fp, $Dat);
            @fclose($fp);
            $StatusMsg .= ".htaccess written...<br>\n";
        }

		PrintInfo("installdone", $StatusMsg);
		break;
	case "config":
		if(!file_exists(getcwd()."/config.inc.php"))
			die("can't config, please install first");
		include("config.inc.php");
		if($ConfigVerBuild!=$VerBuild)
			die("can't config, update first");
		
		require("application.php");
		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

		PrintInfo("config");
		break;
	case "configsave":
		if(!file_exists(getcwd()."/config.inc.php"))
			die("can't config, please install first");
		include("config.inc.php");
		if($ConfigVerBuild!=$VerBuild)
			die("can't config, update first");

		$LoadSmarty = true;
		require("application.php");
		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
        
        $smarty->clear_all_cache();

        $PostImport = array("ListType","HttpPath","AdminEmail","LinkListType");
		foreach($PostImport as $Dat) {
			if(!isset($_POST[$Dat]))
				die("error: _POST[$Dat] not set");
			$CFG[$Dat] = $_POST[$Dat];
		}
		if(substr($CFG['HttpPath'],-1,1)!="/") $CFG['HttpPath'] .= "/";  //add slash at the end...

		$PostImport = array("EnableIndex","ShowRegisterList","ShowRegisterUser","UseActivate","EnableImportSettings","EnableCoverCreate","UseCache");
		foreach($PostImport as $Dat) {
			$CFG[$Dat] = isset($_POST[$Dat]);
		}

		if(!is_writeable(getcwd()."/config.inc.php")) {
			PrintInfo("config", "can't write config.inc.php, please make it writeable so that the settings can be saved.");
		}

		WriteConfig($CFG);

        //check if guest-users exists, if not create one
        $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE name='Guest'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        if(mysql_num_rows($result)==0) {
                $strSql = "INSERT INTO " . $CFG['Prefix'] . "users (name) VALUES ('Guest')";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }

        //check if index-page exists, if not create it
        $strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name='index'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        if(mysql_num_rows($result)==0) {
                $strSql = "INSERT INTO " . $CFG['Prefix'] . "lists (name,title,listtpl,StdPerPage) VALUES ('index','Index-Page','index.tpl','5')";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }

        if(!$CFG['EnableIndex']) {
            //if index-page disabled, remove it from the linklist (if it exists on there)
            $strSql = "SELECT " . $CFG['Prefix'] . "linklist.ID FROM " . $CFG['Prefix'] . "lists," . $CFG['Prefix'] . "linklist
            WHERE " . $CFG['Prefix'] . "linklist.ListID = " . $CFG['Prefix'] . "lists.ID
            AND " . $CFG['Prefix'] . "lists.name='index'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if(mysql_num_rows($result)!=0) {
                $row = mysql_fetch_array($result);
                $strSql = "DELETE FROM " . $CFG['Prefix'] . "linklist WHERE ID=$row[ID]";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            }
        } else {
            //if index-page enabled, add a entry to the linklist if none exists
            $strSql = "SELECT " . $CFG['Prefix'] . "linklist.ID FROM " . $CFG['Prefix'] . "lists," . $CFG['Prefix'] . "linklist
            WHERE " . $CFG['Prefix'] . "linklist.ListID = " . $CFG['Prefix'] . "lists.ID
            AND " . $CFG['Prefix'] . "lists.name='index'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if(mysql_num_rows($result)==0) {
                $strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist ORDER BY SortOrder DESC";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $row = mysql_fetch_array($result);
                $SortOrder = $row['SortOrder']+1;

                $strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name='index'";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $row = mysql_fetch_array($result);

                $strSql = "INSERT INTO " . $CFG['Prefix'] . "linklist (Type,ListID,Text,SortOrder) VALUES ('User','$row[ID]','Index-Page','$SortOrder')";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);			
            }
        }

		if(isset($_GET['displayagain'])) {
			PrintInfo("config");
		} else {
			PrintInfo("configwritten");
		}
		break;
	case "update1":
		if(!file_exists(getcwd()."/config.inc.php"))
			die("can't update, please install first");
		include("config.inc.php");
		if($ConfigVerBuild==$VerBuild)
			die("can't update, as there is no new version!");		

		if(!isset($ConfigVerBuild)) { //************** ALTE versions-nummer, $ConfigVerBuild wird von $ConfigVersion errechnet
			ereg("([0-9]+).([0-9]+).([0-9]+)( ?)([a-zA-Z]*)", $ConfigVersion ,$y);
			$ConfigVerBuild = $y[1]*10000 + $y[2]*100 + $y[3];
		}
		if($ConfigVerBuild < 730) { //upgrading from lower than 0.7.30
			$DOC_TITLE = "Upgrade-Error";
			include("top.html");
			echo "You use a very old version of the PowerMovieList ($ConfigVersion) and want to upgrade to $Version.<br>
				It is not possible to upgrade directly from a version lower than 0.7.30 to 0.8.0 or higher. First you have to do the upgrade to <b>0.7.30</b>, then to <b>0.10.0</b> and then you can do the update to $Version.<br>
				Please go to the <a href='http://www.powermovielist.com/'>PowerMovieList-Homepage</a> where you will find these versions to download";
			include("bottom.html");
			exit;
		}
		if($ConfigVerBuild < 939) { //upgrading from lower than 0.10.0 (Build 939)
			$DOC_TITLE = "Upgrade-Error";
			include("top.html");
			echo "You use an old version of the PowerMovieList ($ConfigVersion) and want to upgrade to $Version.<br>
				It is not possible to upgrade directly from a version lower than 0.10.0. First you have to do the upgrade to <b>0.10.0</b>, then you can do the update to $Version.<br>
				Please go to the <a href='http://www.powermovielist.com/'>PowerMovieList-Homepage</a> where you will find this version to download";
			include("bottom.html");
			exit;
		}
		
		$CheckNewVersion = false;
		require("application.php");
		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

		PrintInfo("update", getUpdateWarnings($ConfigVerBuild));
		break;
	case "update2":
		if(!file_exists(getcwd()."/config.inc.php"))
			die("can't update, please install first");
		include("config.inc.php");
  
		if($ConfigVerBuild==$VerBuild)
			die("can't update, as there is no new version!!");
		if(!isset($ConfigVerBuild))
			die("too old version, update first to 0.7.30");
		if($ConfigVerBuild < 938)
			die("too old version, update first to 0.10.0");

		$CheckNewVersion = false;
		require("application.php");
		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

		$UpdateMessage = "";

		$UpdateError = 0;
		for($Build=$ConfigVerBuild+1;$Build<=$VerBuild;$Build++) {
			@set_time_limit(30);
            $ret = DoUpdate($Build);
            if($ret > $UpdateError)
                $UpdateError = $ret;
            echo "<br>";
            if($UpdateError==PML_Update_Error)
                break;
			WriteConfig($CFG, $Build);
		}

        $UpdateMessage .= "<br>deleting the smarty-cache...<br>\n";        
        require(SMARTY_DIR."Smarty.class.php");
        $smarty = new Smarty;
        $smarty->compile_check = true;
        $smarty->debugging = $CFG['Debug'];
        $smarty->compile_dir = $CFG['CompileDir'];
        $smarty->cache_dir = $CFG['SmartyCacheDir'];
        $smarty->use_sub_dirs = false;
        $smarty->security = $CFG['SmartySecurity'];
        $smarty->secure_dir = array("templates/", "smarty/");
        if($CFG['UseCache']) {
            $smarty->caching = 2; //each cache can have his individual live-time (index-page has a lower!)
        }
        $smarty->clear_all_cache();
        $smarty->clear_compiled_tpl();        

        if(isset($ErrorFileCreateError)) { //script was not able to log the error messages into the file 'updaterror'
            echo "<br><b>IMPORTANT:</b> the file 'updaterror' was <b>NOT</b> created as the script didn't have the rights to do that. So please copy all error-messages displayed here!<br>\n";
        }

        switch($UpdateError) {
            case PML_Update_AllOK:
                $UpdateMessage .= "<br><b>update sucessfuly done...</b>";
                break;
            case PML_Update_Notice:
            case PML_Update_Warning:
                $UpdateMessage .= "<br><b>the update didn't work perfect</b> If not all data was converted correctly, look into the file 'updaterror' where all the update-errors where logged. If you need help, goto <a href='http://www.powermovielist.com/'>www.powermovielist.com</a> and ask for help in the board!</b>";
                break;
            case PML_Update_Error:
                $UpdateMessage .= "<br><b>Update FAILED!</b> Look into the file 'updaterror' where all the update-errors where logged. If you need help, goto <a href='http://www.powermovielist.com/'>www.powermovielist.com</a> and ask for help in the board!</b>";
                break;
		}
		if($ConfigVerBuild < 982) {
			$type = "updatedoneconvert";
		} else {
			$type = "updatedone";
		}
		PrintInfo($type, $UpdateMessage);
		break;
}

function PrintInfo($Type, $Message = "", $Data = array()) {
global $InfoMsg, $CFG, $ActiveList;
	switch($Type) {
		case "install1":
		case "install2":
		case "install3":
		case "install4";
			$DOC_TITLE = "PowerMovieList - Installation";
			$Title = "PowerMovieList-Installation";
			break;
		case "installcfgwriteerr":
		case "cantconnect":
		case "cantcreatedb":
		case "dbnotempty":
		case "magicquoteserr":
		case "importsetnotwriteable":
		case "notwriteable":        
        case "confignotwriteable":
			$DOC_TITLE = "PowerMovieList - Installation-Error";
			$Title = "PowerMovieList-Installation: Error";
			break;
		case "installdone":
			$DOC_TITLE = "PowerMovieList - Installation Completed";
			$Title = "PowerMovieList-Installation: Completed";
			break;
		case "config":
		case "configwritten":
			$DOC_TITLE = "PowerMovieList - Config";
			$Title = "global configuration";
			break;
		case "update":
		case "updatedone":
			$DOC_TITLE = "PowerMovieList - Update";
			$Title = "PowerMovieList-Update";
			break;
	}
	include("top.html");
	echo "  <form name='form1' method='post' action='";
	switch($Type) {
		case "install1":
		case "installcfgwriteerr":
		case "magicquoteserr":
			echo "install.php".$GLOBALS['GlobalArg']."action=install2";			
			break;
		case "install2":
		case "cantconnect":
		case "cantcreatedb":
		case "dbnotempty":
			echo "install.php".$GLOBALS['GlobalArg']."action=install3";			
			break;
		case "install3":
			echo "install.php".$GLOBALS['GlobalArg']."action=install4";			
			break;
		case "install4";
		case "importsetnotwriteable":
		case "notwriteable":        
        case "confignotwriteable":
			echo "install.php".$GLOBALS['GlobalArg']."action=install5";
			break;
		case "installdone":
            echo "edituser.php?action=add";			
			break;
		case "config":
			echo "install.php".$GLOBALS['GlobalArg']."action=configsave";
			break;
		case "configwritten":
			echo "";
			break;
		case "update":
			echo "install.php".$GLOBALS['GlobalArg']."action=update2";
			break;
		case "updatedone":
			echo "index.php";
			break;
		case "updatedoneconvert":
			echo "convert-structure.php";
			break;
	}
	echo "'><br>\n";
	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>
	<tr class=top><td colspan=2>
	<b><font size=+2>\n";
	echo $Title;
	echo "</font><br>Version $GLOBALS[Version]</b>\n";
	echo "</td></tr>\n";	
    echo "</table>\n";
    echo "<br>\n";
    echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
	switch($Type) {
		case "install1":
			echo "<tr class=row2><td colspan=2>\n";
			echo $InfoMsg['install'];
			echo "</td></tr>\n";			
			echo "<tr class=top><td colspan='2'>Step 1: Information</td></tr>\n";
			echo "<tr class=row1><td colspan='2'>this installation-script will now help you to install the PowerMovieList with all the right settings for your needs. Please follow the five steps to complete the installation.</td></tr>\n";
			echo "<tr class=row2><td colspan='2'><input type='submit' value='continue'></td></tr>\n";
			break;
		case "magicquoteserr":
			echo "<tr class=row2><td colspan=2>\n";
			echo "<b>ERROR:</b> Your magic_quotes-settings differ from the default-settings. You can't use this script with different settings.<br>Please edit your php.ini and set <b>magic_quotes_gpc on</b> and <b>magic_quotes_runtime off</b>.<br>You could also use a .htaccess-file (for apache!) to set that.";
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan='2'><input type='submit' value='retry'></td></tr>\n";
			break;
		case "installcfgwriteerr":
			echo "<tr class=row2><td colspan=2>\n";
			echo "<b>ERROR:</b> can't create new config.inc.php, as the script doesn't have the rights to do this. Make sure it has write-rights to to folder where it is installed. You can remove the rights again after the installation.";
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan='2'><input type='submit' value='retry'></td></tr>\n";
			break;
		case "install2":
			echo "<tr class=top><td colspan=2>\n";
		    echo "Step 2: Database-Connection (MySql)\n";			
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
		    echo "You must have access to a MySql-Server, where all the data will be saved. Enter your connection-information here.\n";			
			echo "</td></tr>\n";
			PrintDatabaseConnection(); //use default-values
			echo "<tr class=row2><td>&nbsp;</td><td><input type='submit' value='continue'></td></tr>\n";
			break;
		case "cantconnect":
		case "cantcreatedb":
		case "dbnotempty":
			if($Type=="cantconnect") $ErrorMsg = "Can't connect to the MySql-Server: $Message";
			if($Type=="cantcreatedb") $ErrorMsg = "Can't create new database: $Message";
			if($Type=="dbnotempty") $ErrorMsg = "There allready is an installation of the PowerMovieList in this database.<br>Please use another database, empty the existing one or change the prefix of the existing installation (although it wouldn't make much sense as one single installation supports multiple lists).";
			echo "<tr class=top><td colspan=2>\n";
		    echo "Step 2: Database-Connection (MySql)\n";			
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
		    echo "<font color='red'><b>ERROR:</b> $ErrorMsg</font>\n";
			echo "</td></tr>\n";
			PrintDatabaseConnection($CFG);
			echo "<tr class=row2><td>&nbsp;</td><td><input type='submit' value='retry'></td></tr>\n";
			break;
		case "install3":
			echo "<tr class=top><td colspan=2>\n";
		    echo "Step 3: List-Type\n";			
			foreach($CFG as $k=>$i) {
				echo "<input type='hidden' name='$k' value='$i'>\n";
			}
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
			echo "<b>There are three list-types available, please select the type of list you want to have.</b>";
			echo "<ul>
			  <li><b>full-mode:</b> all features: the whole right-management and multiple users are activated</li>
			  <li><b>simple-mode:</b> right-management disabled, ever user has one list</li>
			  <li><b>sigle-user-mode:</b> only one list without right-management and multiple users</li>
			</ul>\n";
			echo "</td></tr>\n";
			PrintListType(false); //not full text, default value
			echo "<tr class=row2><td>&nbsp;</td><td><input type='submit' value='continue'></td></tr>\n";
			break;
		case "install4":
			echo "<tr class=top><td colspan=2>\n";
		    echo "Step 4: Configuration\n";			
			foreach($CFG as $k=>$i) {
				echo "<input type='hidden' name='$k' value='$i'>\n";
			}
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
			echo "Now please set the rest of the configuration. You must enter the correct http-path of the list (the entered value doesn't have to be correct, please check it), and a valid emailaddress of the admin.<br>The other configuration-options are just here to activate/disable some features. It's also possible to change these later on in your configuration-menu.";
			echo "</td></tr>\n";
			PrintGlobalOptions($CFG['ListType']); //default values
			echo "<tr class=row2><td>&nbsp;</td><td><input type='submit' value='continue'></td></tr>\n";
			break;
		case "importsetnotwriteable":
		case "notwriteable":        
        case "confignotwriteable":
			if($Type=="importsetnotwriteable") $ErrorMsg = "You have enabled the import-settings-feature. With this feature the following folders have to be writable by the script: <i>". implode(", ", $Data)."</i><br>\n<b>".getcwd()."/".$Message."/ is not writeable!</b><br>\nEither you change the rights for there folders, or for more security you can disable this feature.";
			if($Type=="notwriteable") $ErrorMsg = "Can't write to $Message. Please give write-permissions to this directory/file!";
            if($Type=="confignotwriteable") $ErrorMsg = "Can't create the config.inc.php file in the installation-root-folder! Please give wwwrun for the installation write-rights, you should remove them later.";
			echo "<tr class=top><td colspan=2>\n";
		    echo "Step 4: Configuration\n";			
			foreach($CFG as $k=>$i) {
				echo "<input type='hidden' name='$k' value='$i'>\n";
			}
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
			echo "<font color='red'><b>ERROR:</b> $ErrorMsg</font>\n";
			echo "</td></tr>\n";
			PrintGlobalOptions($CFG['ListType'], $CFG);
			echo "<tr class=row2><td>&nbsp;</td><td><input type='submit' value='retry'></td></tr>\n";
			break;
		case "installdone":
			echo "<tr class=top><td colspan=2>\n";
		    echo "Step 5: Installation\n";			
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
			echo $Message;
			echo "<br><b>installation completed...</b>\n";
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
            echo "Please create a new user NOW, the first one created will have super-admin-rights. Click continue to create the new user.";
			echo "</td></tr>\n";
			echo "<tr class=row2><td>&nbsp;</td><td><input type='submit' value='continue'></td></tr>\n";
			break;
		case "config":
			echo "<tr class=row2><td colspan=2>\n";
			if($Message!="") {
				echo "<font color='red'><b>ERROR:</b> $Message</font>\n";
			} else {			
				echo "Here you can change most of the important global settings. To change the other global settings, you have to open config.inc.php and edit this file directly (in most cases you won't have to do this).";
			}
			echo "</td></tr>\n";
			PrintListType(true,$CFG, true);
			PrintGlobalOptions($CFG['ListType'], $CFG);
			echo "<tr class=row1><td>&nbsp;</td><td><input type='submit' value='save'></td></tr>\n";
			break;
		case "configwritten":
			echo "<tr class=row2><td colspan=2>\n";
			echo "new config.inc.php written...";
			echo "</td></tr>\n";
			break;
		case "update":
			echo "<tr class=row2><td colspan=2>\n";
			echo "You installed a new Version of the PowerMovieList. As this new version has some changes in the database-structure, you have to convert you database from the old version to the new one.<br>This script should do that for you.";
			echo "</td></tr>\n";
			echo "<tr class=row1><td colspan=2>\n";
			echo $InfoMsg['update'];
			echo "</td></tr>\n";
            if($Message!="") {
                echo "<tr class=row2><td colspan=2>\n";
                echo "<b>Warning:</b><br>";
                echo $Message;
                echo "</td></tr>\n";
            }
			echo "<tr class=row1><td>&nbsp;</td><td><input type='submit' value='do the update'></td></tr>\n";
			break;
		case "updatedone":
			echo "<tr class=row1><td colspan=2>\n";
			echo $Message;
			echo "</td></tr>\n";
			echo "<tr class=row1><td>&nbsp;</td><td><input type='submit' value='back to the list'></td></tr>\n";
			break;
		case "updatedoneconvert":
			echo "<tr class=row1><td colspan=2>\n";
			echo $Message;
			echo "</td></tr>\n";
			echo "<tr class=row1><td>&nbsp;</td><td><input type='submit' value='continue converting db-stucture'></td></tr>\n";
			break;
	}
	echo "</table>";
	echo "</form>";
	include("bottom.html");
	exit;
}



function PrintDatabaseConnection($CFG=array('DatabaseAdress'=>'localhost', 'DatabaseUser'=>'root', 'DatabasePass'=>'', 'DatabaseName'=>'movie')) {
?>
    <tr class='row2'>
      <td align='right'>
        <b>server-address:</b>
      </td>
      <td>
        <input type="text" name="DatabaseAdress" size="20" value="<?php echo $CFG['DatabaseAdress']; ?>">
      </td>
    </tr>
    <tr class='row1'>
      <td align='right'>
        <b>user:</b>
      </td>
      <td>
        <input type="text" name="DatabaseUser" size="25" value="<?php echo $CFG['DatabaseUser']; ?>">
	  </td>
    </tr>
    <tr class='row2'>
      <td align='right'>
        <b>password:</b>
      </td>
      <td>
        <input type="password" name="DatabasePass" size="25" value="<?php echo $CFG['DatabasePass']; ?>">
	  </td>
    </tr>
    <tr class='row1'>
      <td align='right'>
        <b>database:</b><br>(can be an existing one too, otherwise it will be created)
      </td>
      <td>
        <input type="text" name="DatabaseName" size="25" value="<?php echo $CFG['DatabaseName']; ?>">        	  
      </td>
    </tr>
<?php
}


function PrintListType($FullText=true, $CFG=array('ListType'=>0), $InConfig=false) {
?>
    <tr class='<?php if($InConfig) echo "row1"; else echo "row2"; ?>'>
      <td align='right'>
        <b>List-Type:</b>
      </td>
      <td>
        <select name="ListType"<?php if($InConfig) echo "onChange=\"document.forms[0].action='install.php".$GLOBALS['GlobalArg']."action=configsave&displayagain=1'; document.forms[0].submit();\"";

?>>
          <option value="0"<?php if($CFG['ListType']==0) echo " selected"; ?>>full-mode<?php if($FullText) echo " (the whole right-management and multiple users are activated)"; ?></option>
          <option value="1"<?php if($CFG['ListType']==1) echo " selected"; ?>>simple-mode<?php if($FullText) echo " (every user has moderator-rights for his list; right-management disabled)"; ?></option>
          <option value="2"<?php if($CFG['ListType']==2) echo " selected"; ?>>single-user-mode<?php if($FullText) echo " (only one list without right-management and users)"; ?></option>
        </select>
      </td>
    </tr>
<?php
}

function PrintGlobalOptions($ListType=0, $CFG=array('HttpPath'=>"", 'AdminEmail'=>"", 'EnableIndex'=>true, 'LinkListType'=>1, 'ShowRegisterUser'=>true, 'ShowRegisterList'=>true, 'UseActivate'=>true, 'EnableImportSettings'=>true, 'EnableCoverCreate'=>true, 'UseCache'=>true)) { 
?>
    <tr class='row2'>
      <td align="right">
        <b>URL of lists:</B><br>(absolute http-URL to access the List from the Web - where you installed it)
      </td>
      <td>
        <input type="text" name="HttpPath" size="35" value="<?php
if($CFG['HttpPath']=="")
	echo "http://".$_SERVER['SERVER_NAME'].substr($_SERVER['PHP_SELF'], 0, strrpos($_SERVER['PHP_SELF'],"/"))."/";
else
	echo $CFG['HttpPath'];
?>">
        </td>
    </tr>
    <tr class='row1'>
      <td align="right">
        <B>emailaddress of admin:</B><br>(used for outgoing email)
      </td>
      <td>
        <input type="text" name="AdminEmail" size="30" value="<?php
if($CFG['AdminEmail']=="")
	echo $_SERVER['SERVER_ADMIN'];
else
	echo $CFG['AdminEmail'];
?>">
        </td>
    </tr>

	<?php if($ListType<2) { ?>
        <tr class='row2'>
          <td align="right">
            <B>enable index-page:</B><br>(the newest entries are shown on this page)
          </td>
          <td>
            <INPUT TYPE="checkbox" NAME="EnableIndex" value="1"<?php if($CFG['EnableIndex']) echo " checked"; ?>>
            <font size=-3> </font>
          </td>
        </tr>
        <tr class='row1'>
          <td align="right">
            <B>show available lists:</B><br>(to select available lists)
          </td>
          <td>
            <select name="LinkListType">
                <option value="0"<?php if($CFG['LinkListType']==0) echo " selected"; ?>>don't display anything at all</option>
                <option value="1"<?php if($CFG['LinkListType']==1) echo " selected"; ?>>show selectbox with all lists (for small pages)</option>
                <option value="2"<?php if($CFG['LinkListType']==2) echo " selected"; ?>>show textbox to switch to a list (for huge pages)</option>
                <option value="3"<?php if($CFG['LinkListType']==3) echo " selected"; ?>>show favorites - each user can define his favorite lists</option>
                <option value="4"<?php if($CFG['LinkListType']==4) echo " selected"; ?>>show favorites and textbox to select other lists</option>            
            </select>
            <font size=-3>  </font>
          </td>
        </tr>
    <?php } else { ?>
        <?php if($CFG['EnableIndex']) { ?>
            <input type="hidden" name="EnableIndex" value="1">
        <?php } ?>
        <input type="hidden" name="LinkListType" value="<?php echo $CFG['LinkListType']; ?>">
    <?php } ?>

	<?php if($ListType==1) { ?>
        <tr class='row2'>
          <td align="right">
            <B>allow everybody to sign up for his own list:</B><br>
          </td>
          <td>
            <INPUT TYPE="checkbox" NAME="ShowRegisterList" value="1"<?php if($CFG['ShowRegisterList']) echo " checked"; ?>>
            <font size=-3> </font>
          </td>
        </tr>
        <tr class='row1'>
          <td align="right">
            <B>send user-activation-emails:</B><br>(if set, new users have to activate their account through email)
          </td>
          <td>
            <INPUT TYPE="checkbox" NAME="UseActivate" value="1"<?php if($CFG['UseActivate']) echo " checked"; ?>>
            <font size=-3> </font>
          </td>
        </tr>
        <?php if($CFG['ShowRegisterUser']) { ?>
            <input type="hidden" name="ShowRegisterUser" value="1">
        <?php } ?>
    <?php } ?>
	<?php if($ListType==0) { ?>
        <tr class='row2'>
          <td align="right">
            <B>allow guests to register:</B><br>(anyone can register a new account))
          </td>
          <td>
            <INPUT TYPE="checkbox" NAME="ShowRegisterUser" value="1"<?php if($CFG['ShowRegisterUser']) echo " checked"; ?>>
            <font size=-3> </font>
          </td>
        </tr>
        <tr class='row1'>
          <td align="right">
            <B>send user-activation-emails:</B><br>(if set, new users have to activate their account through email)
          </td>
          <td>
            <INPUT TYPE="checkbox" NAME="UseActivate" value="1"<?php if($CFG['UseActivate']) echo " checked"; ?>>
            <font size=-3> </font>
          </td>
        </tr>
        <tr class='row2'>
          <td align="right">
            <B>allow users to sign up for their own list:</B><br>
          </td>
          <td>
            <INPUT TYPE="checkbox" NAME="ShowRegisterList" value="1"<?php if($CFG['ShowRegisterList']) echo " checked"; ?>>
            <font size=-3> </font>
          </td>
        </tr>
    <?php } ?>
    <?php if($ListType==2) { ?>
        <?php if($CFG['ShowRegisterUser']) { ?>
            <input type="hidden" name="ShowRegisterUser" value="1">
        <?php } ?>
        <?php if($CFG['ShowRegisterList']) { ?>
            <input type="hidden" name="ShowRegisterList" value="1">
        <?php } ?>
        <?php if($CFG['UseActivate']) { ?>
            <input type="hidden" name="UseActivate" value="1">
        <?php } ?>
    <?php } ?>
    <tr class='row1'>
      <td align="right">
        <B>enable import settings-feature</B><br>(list-admins can import properties, images and templates - *.pmlset-files)
      </td>
      <td>
        <INPUT TYPE="checkbox" NAME="EnableImportSettings" value="1"<?php if($CFG['EnableImportSettings']) echo " checked"; ?>>
        <font size=-3> </font>
      </td>
    </tr>

    <tr class='row2'>
      <td align="right">
        <B>enable create-cover-feature:</B><br><?
if(!function_exists('imagecreatefrompng'))
	echo " <font color='red'>(you can't use this feature because gd for php is not installed)</font>";
else
	echo " (optional, you can create simple covers for printout)";
?>
      </td>
      <td>
        <INPUT TYPE="checkbox" NAME="EnableCoverCreate" value="1"<?php 
if($CFG['EnableCoverCreate']) echo " checked";
if(!function_exists('imagecreatefrompng')) echo " disabled";
?>>
        <font size=-3</font>
      </td>
    </tr>
    <tr class='row2'>
      <td align="right">
        <B>use smarty-caching:</B><br>(if set, the list and popups will be cached - so everything will be faster...)
      </td>
      <td>
        <INPUT TYPE="checkbox" NAME="UseCache" value="1"<?php if($CFG['UseCache']) echo " checked"; ?>>
        <font size=-3> </font>
      </td>
    </tr><?php
}


function WriteConfig($CFG, $Build=0)
{

//default values:
if(!isset($CFG['FetchCacheDir']))  $CFG['FetchCacheDir'] = "./fetch_cache/";
if(!isset($CFG['UseUserStatus'])) $CFG['UseUserStatus'] = false;
if(!isset($CFG['SmartyCacheHandler'])) $CFG['SmartyCacheHandler'] = "";
if(!isset($CFG['AllowCommentVoteGuest'])) $CFG['AllowCommentVoteGuest'] = true;
if(!isset($CFG['UseCounter'])) $CFG['UseCounter'] = true;
if(!isset($CFG['CacheLifetimeList'])) $CFG['CacheLifetimeList'] = 60*60*24;
if(!isset($CFG['CacheLifetimeIndex'])) $CFG['CacheLifetimeIndex'] = 60*15;
if(!isset($CFG['CacheClearOnChangeList'])) $CFG['CacheClearOnChangeList'] = true;
if(!isset($CFG['BadwordsFile'])) $CFG['BadwordsFile'] = "";
if(!isset($CFG['PopupBadwordsRedirect'])) $CFG['PopupBadwordsRedirect'] = "";
if(!isset($CFG['EMailBlackListFile'])) $CFG['EMailBlackListFile'] = "";
if(!isset($CFG['ShowUserDetails'])) $CFG['ShowUserDetails'] = true;
if(!isset($CFG['EnableSaveShowOnIndex'])) $CFG['EnableSaveShowOnIndex'] = false;
if(!isset($CFG['AddDownloadLinkFields'])) $CFG['AddDownloadLinkFields'] = array();
if(!isset($CFG['RemoveFromFilename'])) $CFG['RemoveFromFilename'] = array();
if(!isset($CFG['PrependToFilename'])) $CFG['PrependToFilename'] = "";

if($Build==0) $Build=$GLOBALS['VerBuild'];
$file = "<?php /* CONFIGURATION-FILE for PowerMovieList
You can edit the important values in your configuration-panel under global-config (as super-admin).
The other options you can only change directly here in this file.
*/
\n";
$file .= "//PATHs\n";
if(isset($CFG['HttpPath']))   $file .= "\$CFG['HttpPath'] = \"$CFG[HttpPath]\";\n";
if(isset($CFG['AdminEmail'])) $file .= "\$CFG['AdminEmail'] = \"$CFG[AdminEmail]\";\n";
$file .= "\n";
$file .= "//COVERS\n";
if(isset($CFG['EnableCoverCreate'])) $file .= "\$CFG['EnableCoverCreate'] = "; if($CFG['EnableCoverCreate']) $file.="true"; else $file.="false"; $file.= ";\n";
$file .= "\n";
$file .= "//Database\n";
if(isset($CFG['DatabaseAdress'])) $file .= "\$CFG['DatabaseAdress'] = \"$CFG[DatabaseAdress]\";\n";
if(isset($CFG['DatabaseName']))   $file .= "\$CFG['DatabaseName'] = \"$CFG[DatabaseName]\";\n";
if(isset($CFG['DatabaseUser']))   $file .= "\$CFG['DatabaseUser'] = \"$CFG[DatabaseUser]\";\n";
if(isset($CFG['DatabasePass']))   $file .= "\$CFG['DatabasePass'] = \"$CFG[DatabasePass]\";\n";
if(isset($CFG['Prefix']))         $file .= "\$CFG['Prefix'] = \"$CFG[Prefix]\";\n";
$file .= "\n";
$file .= "//Users\n";
if(isset($CFG['UseActivate']))      $file .= "\$CFG['UseActivate'] = "; if($CFG['UseActivate']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['UseUserStatus']))    $file .= "\$CFG['UseUserStatus'] = "; if($CFG['UseUserStatus']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['ShowRegisterUser'])) $file .= "\$CFG['ShowRegisterUser'] = "; if($CFG['ShowRegisterUser']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['ShowRegisterList'])) $file .= "\$CFG['ShowRegisterList'] = "; if($CFG['ShowRegisterList']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['ShowUserDetails']))  $file .= "\$CFG['ShowUserDetails'] = "; if($CFG['ShowUserDetails']) $file.="true"; else $file.="false"; $file.= ";\n";
$file .= "\n";
$file .= "//Lists\n";
if(isset($CFG['ListType']))              $file .= "\$CFG['ListType'] = $CFG[ListType];\n";
if(isset($CFG['LinkListType']))          $file .= "\$CFG['LinkListType'] = $CFG[LinkListType];\n";
if(isset($CFG['EnableIndex']))           $file .= "\$CFG['EnableIndex'] = "; if($CFG['EnableIndex']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['EnableImportSettings']))  $file .= "\$CFG['EnableImportSettings'] = "; if($CFG['EnableImportSettings']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['AllowCommentVoteGuest'])) $file .= "\$CFG['AllowCommentVoteGuest'] = "; if($CFG['AllowCommentVoteGuest']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['UseDloadLog']))           $file .= "\$CFG['UseDloadLog'] = "; if($CFG['UseDloadLog']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['UseStatistics']))           $file .= "\$CFG['UseStatistics'] = "; if($CFG['UseStatistics']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['UseCounter']))            $file .= "\$CFG['UseCounter'] = "; if($CFG['UseCounter']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['UseDloadCounter']))            $file .= "\$CFG['UseDloadCounter'] = "; if($CFG['UseDloadCounter']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['EnableSaveShowOnIndex'])) $file .= "\$CFG['EnableSaveShowOnIndex'] = "; if($CFG['EnableSaveShowOnIndex']) $file.="true"; else $file.="false"; $file.= ";\n";
$file .= "\n";
$file .= "//General\n";
if(isset($CFG['MaxExecutionTime'])) $file .= "\$CFG['MaxExecutionTime'] = $CFG[MaxExecutionTime];\n";
if(isset($CFG['Debug']))            $file .= "\$CFG['Debug'] = "; if($CFG['Debug']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['MaxUploadSize']))    $file .= "\$CFG['MaxUploadSize'] = $CFG[MaxUploadSize];\n";
if(isset($CFG['UploadExt']))        $file .= "\$CFG['UploadExt'] = \"$CFG[UploadExt]\";\n";

$file .= "
\$CFG['UserClass'] = \"$CFG[UserClass]\";
\$CFG['DisablePropTypes'] = array(". implode(", ", $CFG['DisablePropTypes']) .");  //disable some PropTypes globally (use id from definition in functions.php)
\$CFG['AddDownloadLinkFields'] = array(";
foreach($CFG['AddDownloadLinkFields'] as $i) {
	$file .= "'$i', ";
}
if(sizeof($CFG['AddDownloadLinkFields']))
	$file = substr($file, 0, -2);
$file .= ");\n";

$file .= "
//Directories
\$CFG['UploadDir'] = \"$CFG[UploadDir]\";  //for file-uploads
\$CFG['UploadDirHttp'] = \"$CFG[UploadDirHttp]\";
\$CFG['CacheDir'] = \"$CFG[CacheDir]\";   //for cached urls
\$CFG['CacheDirHttp'] = \"$CFG[CacheDirHttp]\";
\$CFG['FetchCacheDir'] = \"$CFG[FetchCacheDir]\";\n";

//Smarty-Config
$file .= "if(!defined('SMARTY_DIR')) ";
if(SMARTY_DIR==getcwd()."/smarty/")
	$file .= "define(\"SMARTY_DIR\", getcwd().\"/smarty/\");\n";
else
    $file .= "define(\"SMARTY_DIR\", \"". SMARTY_DIR ."\");\n";

if(isset($CFG['UseCache']))               $file .= "\$CFG['UseCache'] = "; if($CFG['UseCache']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['SmartyUseSubDirs']))       $file .= "\$CFG['SmartyUseSubDirs'] = "; if($CFG['SmartyUseSubDirs']) $file.="true"; else $file.="false"; $file.= ";\n";
if(isset($CFG['SmartyCacheDir']))         $file .= "\$CFG['SmartyCacheDir'] = \"$CFG[SmartyCacheDir]\";\n";
if(isset($CFG['CompileDir']))             $file .= "\$CFG['CompileDir'] = \"$CFG[CompileDir]\";\n";
if(isset($CFG['SmartySecurity']))         $file .= "\$CFG['SmartySecurity'] = "; if($CFG['SmartySecurity']) $file.="true"; else $file.="false"; $file.= ";   //warning: dont set SmartySecurity false and EnableImport true, hackers could import bad templates and execute any php code on them\n";
if(isset($CFG['SmartyCacheHandler']))     $file .= "\$CFG['SmartyCacheHandler'] = \"$CFG[SmartyCacheHandler]\";\n";
if(isset($CFG['CacheLifetimeList']))      $file .= "\$CFG['CacheLifetimeList'] = $CFG[CacheLifetimeList];\n";
if(isset($CFG['CacheLifetimeIndex']))     $file .= "\$CFG['CacheLifetimeIndex'] = $CFG[CacheLifetimeIndex];\n";
if(isset($CFG['CacheClearOnChangeList'])) $file .= "\$CFG['CacheClearOnChangeList'] = "; if($CFG['CacheClearOnChangeList']) $file.="true"; else $file.="false"; $file.= ";\n";
$file .= "\n";
$file .= "//additional settings\n";
if(isset($CFG['PopupBadwordsRedirect']))  $file .= "\$CFG['PopupBadwordsRedirect'] = \"$CFG[PopupBadwordsRedirect]\";\n";
if(isset($CFG['BadwordsFile']))           $file .= "\$CFG['BadwordsFile'] = \"$CFG[BadwordsFile]\";\n";
if(isset($CFG['EMailBlackListFile']))     $file .= "\$CFG['EMailBlackListFile'] = \"$CFG[EMailBlackListFile]\";\n";
if(isset($CFG['RemoveFromFilename']))     $file .= "\$CFG['RemoveFromFilename'] = array(\"". implode('", "', str_replace("'", "\\'", $CFG['RemoveFromFilename'])) ."\");\n";
if(isset($CFG['PrependToFilename']))      $file .= "\$CFG['PrependToFilename'] = \"$CFG[PrependToFilename]\";\n";
$file .= "\n";

if(isset($CFG['CustomPropTypes'])) {
	foreach($CFG['CustomPropTypes'] as $k=>$i) {
		foreach($i as $k1=>$i1) {
			$file .= "\$CFG['CustomPropTypes'][$k]['$k1'] = \"$i1\";\n";
		}
	}
}

$file .= "\n";
$file .= "//Version\n";
$file .= "\$ConfigVerBuild = $Build;  //don't change - used for update-installation\n";
$file .= "?" . ">";
	
	$fp = @fopen("config.inc.php","w");
	if(!$fp)
		ErrorExit("can't write config.inc.php<br>execute 'chown wwwrun <yourdir> or chmod 777 <yourdir>' that you can write new files into your dir");

	fwrite($fp, $file);
	fclose($fp);

}


function DoUpdate($Build) {
global $CFG, $pmldb, $UpdateMessage, $ActiveUser;
/*  > citical:
      print it out as citical-error, don't continue and write a notice about pml-board
    > warning:
      print it out as a error, continue and wirte a notice about pml-board
    > notice:
      just print it out

define("PML_Update_AllOK", 1);
define("PML_Update_Notice", 2);
define("PML_Update_Warning", 3);
define("PML_Update_Error", 4);


*/
    $ret = PML_Update_AllOK;
	switch($Build) {
		case 940: //version 0.10.1
			$UpdateMessage .= "upgrading to Version 0.10.1...<br>\n";
            $CFG['UserClass'] = "standalone.php";
			//nothing has to be done :D (till now at least)
			return(PML_Update_AllOK);			
        case 941: //version 0.10.1
            $UpdateMessage .= "upgrading to <b>Build 941</b>:<br>\n";
            $UpdateMessage .= "adding ShowOnIndex-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]lists ADD ShowOnIndex TINYINT NOT NULL DEFAULT '1'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding ShowOnIndex", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            return($ret);
        case 942: //version 0.10.1
            $UpdateMessage .= "upgrading to <b>Build 942</b>:<br>\n";
            $UpdateMessage .= "adding ShowLinkType-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]prop ADD ShowLinkType TINYINT NOT NULL DEFAULT '0'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding ShowLinkType", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 943: //version 0.10.1
            $UpdateMessage .= "upgrading to <b>Build 943</b>:<br>\n";
            $UpdateMessage .= "adding fetch-settings-fields...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]lists ADD UseFetching TINYINT NOT NULL DEFAULT '1'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding UseFetching", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            $strSql = "ALTER TABLE $CFG[Prefix]lists ADD FetchTextPropID INT NOT NULL DEFAULT '0'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding FetchTextPropID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            return($ret);
        case 944: //version 0.10.1
            $UpdateMessage .= "upgrading to <b>Build 944</b>:<br>\n";
            $UpdateMessage .= "adding RequiredRights-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]prop ADD RequiredRights TINYINT NOT NULL DEFAULT '0'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding RequiredRights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 945: //version 0.10.2
            $UpdateMessage .= "upgrading to <b>Build 945</b>:<br>\n";
            //no changes to do...
            return(PML_Update_AllOK);
        case 946: //version 0.10.2
            $UpdateMessage .= "upgrading to <b>Build 946</b>:<br>\n";
            $UpdateMessage .= "adding StdFilterPropValID-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]prop ADD StdFilterPropValID INT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding StdFilterPropValID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 947: //version 0.10.2
            $UpdateMessage .= "upgrading to <b>Build 947</b>:<br>\n";
            $UpdateMessage .= "removing UseFetching-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]lists DROP UseFetching";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> removing the field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "removing UseFetching", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            $UpdateMessage .= "removing showgraph-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]lists DROP showgraph";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> removing the field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "removing showgraph", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            $UpdateMessage .= "removing showstat-field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]lists DROP showstat";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> removing the field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "removing showstat", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            return($ret);
        case 948: //version 0.10.2
            $UpdateMessage .= "upgrading to <b>Build 948</b>:<br>\n";
            $UpdateMessage .= "write the .htaccess-file...<br>\n";
            $Dat = $_SERVER['REQUEST_URI']; //  = /powermovielist/install.php?action=install3
            $Pos=strpos($Dat, "install.php");
            $Dat = substr($Dat, 0, $Pos);
            $Dat .= "redirect.php";
            $Dat = "ErrorDocument 404 ".$Dat."\n";
            $WriteError=false;
            $fp = @fopen(".htaccess","w");
            if(!$fp) $WritError=true;
            if(!@fwrite($fp, $Dat)) $WriteError=true;
            @fclose($fp);
            if($WriteError) {
                $UpdateMessage .= "<b>WARNING:</b> can't update the .htaccess. Please open that file yourself and write that line in there: $Dat<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "error writing .htaccess");
                $ret = PML_Update_Warning;
            } else {
                $UpdateMessage .= ".htaccess written...<br>\n";
            }
            return($ret);
        case 949: //version 0.10.3
            //this upgrade doesn't have to be done anymore!
            //the download-link delemiter should stay at ~ (data will move to a new table)
            //and the delemiter for cached-urls will be | and in this version it is not used!
            return($ret);
        case 950: //version 0.10.3
            $UpdateMessage .= "upgrading to <b>Build 950</b>:<br>\n";
            $UpdateMessage .= "adding allowed-upload extensions to config-file<br>\n";           
            $CFG['UploadExt'] = ".jpg;.jepg;.gif;.png;.html;.htm;.txt;.doc;.torrent;.zip;.gz;.rar;.ace;.nfo";
            return($ret);
        case 951: //version 0.10.3
            $UpdateMessage .= "upgrading to <b>Build 951</b>:<br>\n";
            $UpdateMessage .= "adding announcement-table to database<br>\n";
            $strSql = "CREATE TABLE $CFG[Prefix]announcment (
                ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
                ListID INT UNSIGNED NOT NULL, 
                UserID INT UNSIGNED, 
                DateAdded DATETIME, 
                Text TEXT
            );";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the table failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding announcement-table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $UpdateMessage .= "moving list-messages to announcements<br>\n";
            $strSql = "SELECT ID,message FROM $CFG[Prefix]lists";
            if(!$query=@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> moving the list-message to announcements failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "moving the list-message to announcements", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            while($row=mysql_fetch_assoc($query)) {
                $strSql = "INSERT INTO $CFG[Prefix]announcment (ListID, UserID, DateAdded, Text) VALUES ('$row[ID]', '$ActiveUser[ID]', '".date("Y-m-d h:m:s")."', '".addslashes($row['message'])."')";                
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> moving the list-message to announcements failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "moving the list-message to announcements", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }

            $UpdateMessage .= "removing list-message field<br>\n";            
            $strSql = "ALTER TABLE $CFG[Prefix]lists DROP message";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> removing the message-field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "removing UseFetching", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            return($ret);
        case 952: //version 0.10.7
            $UpdateMessage .= "upgrading to <b>Build 952</b>:<br>\n";
            $UpdateMessage .= "adding new download-link table...<br>\n";
            $strSql = "CREATE TABLE pml_movielink (
                MovieID INT NOT NULL,
                PropID INT NOT NULL,
                Link TINYTEXT NOT NULL,
                Text TINYTEXT NOT NULL,
                Size SMALLINT NOT NULL,
                DloadCount INT NOT NULL,
                UNIQUE KEY Entry (MovieID,PropID)
            )";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the table failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding download-link-table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $UpdateMessage .= "moving all download-links into new table...<br>\n";
            //get all download-links:
            $strSql = "SELECT $CFG[Prefix]movieprop.*
            FROM $CFG[Prefix]movieprop, $CFG[Prefix]prop
            WHERE $CFG[Prefix]movieprop.PropID=$CFG[Prefix]prop.ID
            AND ($CFG[Prefix]prop.PropType=10 OR $CFG[Prefix]prop.PropType=16)";
            if(!$query=@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> Moving the download-links failed. All your links may be broken now. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "moving downloadlinks into new table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            while($row=mysql_fetch_assoc($query)) {
                $row['Property'] = addslashes($row['Property']);
				if(!strstr($row['Property'],"~")) {
					$row['Property'] = str_replace('|', '~', $row['Property']);  //the old-was used in some versions.. convert it
					$row['Property'] = str_replace('{}', '~', $row['Property']); //was used in some cvs-version.. convert this too
				}
                $x = explode("~",$row['Property']."~~");
                $Dat["Url"] = $x[0];
                $Dat["Text"] = $x[1];
                $Dat["Size"] = $x[2];                                
                $strSql = "INSERT INTO $CFG[Prefix]movielink SET MovieID=$row[MovieID], PropID=$row[PropID], Link='$Dat[Url]', Text='$Dat[Text]', Size='$Dat[Size]'";
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> moving a download-link into the new table failed... (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "moving a download-link into the new table", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
                $strSql = "DELETE FROM $CFG[Prefix]movieprop WHERE MovieID=$row[MovieID] AND PropID=$row[PropID]";
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> deleteing the old download-link failed... (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "deleteing the old download-link", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }
            return($ret);
		case 953:
			//nothing to do, just some new config-vars...
			$CFG['UseDloadLog'] = true;
			$CFG['DisablePropTypes'] = array();
			return($ret);
		case 954:
			//noting to do, just some new config-vars...
			$CFG['UploadDir'] = $CFG['CacheDir'];
			$CFG['UploadDirHttp'] = $CFG['CacheDirHttp'];
			return($ret);
        case 955:
			//nothing to do...
			return($ret);
		case 956:
            $UpdateMessage .= "upgrading to <b>Build 956</b>:<br>\n";
            $UpdateMessage .= "creating PropFetch-Table...<br>\n";
			$strSql = "CREATE TABLE $CFG[Prefix]propfetch (
							ID INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,    
							PropID INT NOT NULL,
							FetchScript CHAR(30) NOT NULL,
							SortOrder INT NOT NULL,
							Settings TINYTEXT
						);";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> creating the table failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding PropFetch-Table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $UpdateMessage .= "adding ShowAdd-Field...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]prop ADD ShowAdd TINYINT NOT NULL DEFAULT '1'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding ShowAdd-Field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }			

            $UpdateMessage .= "moving all FetchScript-Settings into the new table...<br>\n";
            //get all download-links:
            $strSql = "SELECT $CFG[Prefix]prop.*
            FROM $CFG[Prefix]prop";
            if(!$query=@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> Moving the FetchScript-Fields failed.. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "moving FetchSCriptFields into new table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            while($row=mysql_fetch_assoc($query)) {
				$SortOrder=1;
				if($row['FetchScript']!="") {
					$strSql = "INSERT INTO $CFG[Prefix]propfetch (PropID, FetchScript, SortOrder) VALUES ('$row[ID]', '$row[FetchScript]', '$SortOrder');";
	                if(!@pml_mysql_query($strSql, $pmldb)) {
						$UpdateMessage .= "<b>WARNING:</b> adding FetchScript-Field failed... (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
						WriteUpdateError($Build, PML_Update_Warning, "adding fetchscriptfield failed", $strSql, mysql_error($pmldb));
						$ret = PML_Update_Warning;
					}
					$strSql = "UPDATE $CFG[Prefix]prop SET ShowAdd='0' WHERE ID='$row[ID]'";
	                if(!@pml_mysql_query($strSql, $pmldb)) {
						$UpdateMessage .= "<b>WARNING:</b> setting ShowAdd failed... (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
						WriteUpdateError($Build, PML_Update_Warning, "setting ShowAdd failed", $strSql, mysql_error($pmldb));
						$ret = PML_Update_Warning;
					}
					$SortOrder++;
				}
				if(isset($row['FetchScriptAlt']) && $row['FetchScriptAlt']!="") {
					$strSql = "INSERT INTO $CFG[Prefix]propfetch (PropID, FetchScript, SortOrder) VALUES ('$row[ID]', '$row[FetchScriptAlt]', '$SortOrder');";
	                if(!@pml_mysql_query($strSql, $pmldb)) {
						$UpdateMessage .= "<b>WARNING:</b> adding FetchScript-Field failed... (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
						WriteUpdateError($Build, PML_Update_Warning, "adding fetchscriptfield failed", $strSql, mysql_error($pmldb));
						$ret = PML_Update_Warning;
					}
                }				
			}
            
			if($ret==PML_Update_AllOK) {
				$UpdateMessage .= "removing the old FetchScript-Field...<br>\n";
				$strSql = "ALTER TABLE $CFG[Prefix]prop DROP FetchScript";
				if(!@pml_mysql_query($strSql, $pmldb)) {
					$UpdateMessage .= "<b>WARNING:</b> removing the field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
					WriteUpdateError($Build, PML_Update_Warning, "removing old FechScript-Field", $strSql, mysql_error($pmldb));
					$ret = PML_Update_Warning;
				}            

				//here ignore any errors, it just might exist but does'nt have to
				$strSql = "ALTER TABLE $CFG[Prefix]prop DROP FetchScriptAlt";
				@pml_mysql_query($strSql, $pmldb);

			}			
			return($ret);

        case 957: //version 0.12
            $UpdateMessage .= "upgrading to <b>Build 957</b>:<br>\n";
            $UpdateMessage .= "adding view-rights to index-list for all users<br>\n";
            $strSql = "SELECT ID FROM $CFG[Prefix]lists WHERE name='index'";
            if(!$query=@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> getting all users failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "getting all users failed", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            $IndexID = mysql_fetch_assoc($query);
            $IndexID = $IndexID['ID'];
            $strSql = "SELECT ID FROM $CFG[Prefix]users";
            if(!$query=@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> getting all users failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "getting all users failed", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            while($row=mysql_fetch_assoc($query)) {
                $strSql = "REPLACE INTO $CFG[Prefix]userrights (ListID, UserID, Permissions) VALUES ('$IndexID', '$row[ID]', '1')";
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> adding view-rights for index-list failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "adding view-rights for index-list", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }
            //rights for new users
            $strSql = "REPLACE INTO $CFG[Prefix]userrights (ListID, UserID, Permissions) VALUES ('$IndexID', '0', '1')";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding view-rights for index-list failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding view-rights for index-list", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 958: //version 0.12
            $UpdateMessage .= "upgrading to <b>Build 958</b>:<br>\n";
            $UpdateMessage .= "new smarty-version...<br>\n";
            return($ret);
        case 959: //version 0.12 RC1
            $UpdateMessage .= "upgrading to <b>Build 959</b>:<br>\n";
            $UpdateMessage .= "adding DateOn/DateOff for announcements...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]announcment ADD DateOn DATE NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding DateOn-Field for Announcements", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }			
            $strSql = "ALTER TABLE $CFG[Prefix]announcment ADD DateOff DATE NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding DateOff-Field for Announcements", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            $strSql = "ALTER TABLE $CFG[Prefix]announcment ADD UseDate TINYINT NOT NULL DEFAULT '0'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding UseDate-Field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 960: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 960</b>:<br>\n";
            $UpdateMessage .= "new loan-right, upgrading old ones...<br>\n";
            $strSql="UPDATE $CFG[Prefix]userrights SET Permissions = Permissions+1 WHERE Permissions>1";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing Permissions failed. Some Users now have less rights. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing Permissions", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql="UPDATE $CFG[Prefix]prop SET RequiredRights = RequiredRights+1 WHERE RequiredRights>1";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing RequiredRights for properties/fields failed. Some Properties now probably need less rights to view them. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing RequiredRights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 961: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 961</b>:<br>\n";
            $UpdateMessage .= "Adding EnableLoan-property for lists...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]lists ADD EnableLoan TINYINT NOT NULL DEFAULT '0'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding EnableLoan-Field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 962: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 962</b>:<br>\n";
            $UpdateMessage .= "Changing Date-Field for User-Comments...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]comment CHANGE Date Date DATETIME NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing user-comments date-field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 963: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 963</b>:<br>\n";
            $UpdateMessage .= "changeing all Text-Fields to varchar-fields - will be faster...<br>\n";
            
            $arSql = array();
            $arSql[] = "ALTER TABLE $CFG[Prefix]linklist CHANGE Url Url VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]linklist CHANGE Text Text VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]comment CHANGE Date Date DATETIME NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]comment CHANGE Text Text VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE name name VARCHAR(32) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE pass pass VARCHAR(32) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE email email VARCHAR(100) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE icq icq VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE aim aim VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE userhp userhp VARCHAR(100) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE location location VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE work work VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE gender gender TINYINT NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE birthdate birthdate DATE NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE regdate regdate DATE NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]users CHANGE admin admin TINYINT NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE name name VARCHAR(32) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE title title VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE urlname urlname VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE url url VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE image image VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE lang lang VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE designcss designcss VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE showpass showpass VARCHAR(15) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE showpasstext showpasstext VARCHAR(200) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE closetext closetext VARCHAR(200) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE popuptpl popuptpl VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]lists CHANGE listtpl listtpl VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]prop CHANGE InTitle InTitle VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]prop CHANGE InProp InProp VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]prop CHANGE ListHeader ListHeader VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]prop CHANGE ListProperties ListProperties VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]prop CHANGE Url Url VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]propval CHANGE DisplayText DisplayText VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]propval CHANGE DisplayTextShort DisplayTextShort VARCHAR(20) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]propval CHANGE DisplayTextHtml DisplayTextHtml VARCHAR(50) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]propval CHANGE FetchText FetchText VARCHAR(30) NOT NULL";
            $arSql[] = "ALTER TABLE $CFG[Prefix]propfetch CHANGE Settings Settings VARCHAR(50) NOT NULL";
            foreach($arSql as $strSql) {            
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> changing text-fields to varchar-fields failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br> SQL-String: $strSql<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "changing text-fields to varchar-fields", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }
            return($ret);
        case 964: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 964</b>:<br>\n";
            $UpdateMessage .= "adding new LinkListType-Setting to global config...<br>\n";
            if(!$CFG['ShowLinkList'])
                $CFG['LinkListType']=0;
            else
                $CFG['LinkListType']=1;

            $UpdateMessage .= "creating list-favorites-table...<br>\n";
            $strSql = "CREATE TABLE $CFG[Prefix]fav (
                          ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                          UserID INT NOT NULL,
                          ListID INT NOT NULL,
                          SortOrder INT NOT NULL);";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> creating the list-favorites-table failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "creating fav-table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }			

            return($ret);
        case 965: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 965</b>:<br>\n";
            $UpdateMessage .= "Adding SortText-Field for Listbox...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]propval ADD SortText VARCHAR(20) NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding sorttext-field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 966: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 966</b>:<br>\n";
            $UpdateMessage .= "creating LoanStatus table...<br>\n";
            $strSql = "CREATE TABLE $CFG[Prefix]loanstatus (
                          UserID INT NOT NULL default '0',
                          MovieID INT NOT NULL default '0',
                          status TINYINT NOT NULL default '0',
                          date DATE NOT NULL default '0000-00-00',
                          Duration SMALLINT NOT NULL default '7'
                        )";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> creating the table failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "creating loanstatus-table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 967: //version 0.12 cvs
            $UpdateMessage .= "upgrading to <b>Build 967</b>:<br>\n";
            $CFG['SmartyCacheDir'] = "./smarty_cache/";            
            if(ini_get("safe_mode")=="1")
                $CFG['SmartyUseSubDirs'] = false;
            else {
                $UpdateMessage .= "Switched On use_sub_dirs for smarty. If you have troubles with that edit config.inc.php and set SmartyUseSubDirs to false.<br>";
                $CFG['SmartyUseSubDirs'] = true;
            }
            $UpdateMessage .= "new Smarty-Cache-Directory: $CFG[SmartyCacheDir]. Make sure wwwrun has write-rights.<br>\n";
            
            return($ret);
        case 968: //version 0.13
            $UpdateMessage .= "upgrading to <b>Build 968</b>:<br>\n";
            $UpdateMessage .= "checking cache-dirs...<br>\n";
            if($CFG['UploadDir']=="./jpgraph_cache/") {
                $CFG['UploadDir']="./cache/";
                $UpdateMessage .= "changed UploadDir. Check config.inc.php if uploads don't work anymore...<br>\n";
            }
            if($CFG['CacheDir']=="./jpgraph_cache/") {
                $CFG['CacheDir']="./cache/";
                $UpdateMessage .= "changed CacheDir. Check config.inc.php if uploads don't work anymore...<br>\n";
            }
        	return($ret);
        case 969: //version 0.13
            $UpdateMessage .= "upgrading to <b>Build 969</b>:<br>\n";
            $UpdateMessage .= "adding fetch-cache-dir to config...<br>\n";

            if(!IsWriteable($CFG['FetchCacheDir'])) {
                $UpdateMessage .= "<b>NOTICE:</b> $CFG[FetchCacheDir] is not writeable. Make it writeable for wwwrun or the Fetch-Script cache won't work.<br>\n";
                WriteUpdateError($Build, PML_Update_Notice, "setting fetch-cache-dir", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Notice;
            }

            return($ret);
        case 970: //version 0.13
            $UpdateMessage .= "upgrading to <b>Build 970</b>:<br>\n";
            $UpdateMessage .= "adding IndexType-Field...<br>\n";              
            $strSql = "ALTER TABLE $CFG[Prefix]lists ADD IndexType TINYINT NOT NULL DEFAULT '0'";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding IndexType", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }            
            return($ret);
        case 971: //version 0.13
            $UpdateMessage .= "upgrading to <b>Build 971</b>:<br>\n";
            $UpdateMessage .= "creating IndexItems table...<br>\n";
            $strSql = "CREATE TABLE $CFG[Prefix]indexitems (
                          ID INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,    
                          Name VARCHAR(20) NOT NULL,
                          SortOrder INT NOT NULL,
                          ListHeader VARCHAR(30) NOT NULL,
                          LoadOnly TINYINT NOT NULL default '0'
                        )";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> creating the table failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "creating indexitems-table", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $UpdateMessage .= "adding default indexitems...<br>\n";
            $strSql = array();
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Poster', 1, 'Poster', 1)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Title', 2, 'Title', 1)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Year', 3, 'Year', 1)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Genre', 4, 'Genre', 0)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Starring', 5, 'Starring', 0)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('DateAdded', 6, 'Added', 0)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Comment', 7, 'Comment', 0)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('UserName', 8, 'Added By', 0)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('ListName', 9, 'ListName', 1)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('ListTitle', 10, 'ListTitle', 1)";
            $strSql[] = "INSERT INTO $CFG[Prefix]indexitems (Name, SortOrder, ListHeader, LoadOnly) VALUES ('Plot', 11, 'Plot', 1)";
            foreach($strSql as $i) {
                if(!@pml_mysql_query($i, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> adding defaultitems failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "creating indexitems-table", $i, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }
            return($ret);
        case 972: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 972</b>:<br>\n";
            $UpdateMessage .= "adding Comment for Loanings...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]loanstatus ADD Comment VARCHAR(100) NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the new field failed, you probably did the update allready. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding Comment-Field for Loanings", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 973: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 973</b>:<br>\n";
            $UpdateMessage .= "changing comment-text Field (to 255 Chars length)...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]comment CHANGE Text Text VARCHAR(255) NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of comments", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 974: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 974</b>:<br>\n";
            $UpdateMessage .= "changeing the size of MovieID...<br>\n";

            $strSql = "ALTER TABLE $CFG[Prefix]dloadlog CHANGE movieID movieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]comment CHANGE MovieID MovieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]votes CHANGE MovieID MovieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]movieprop CHANGE MovieID MovieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]movielink CHANGE MovieID MovieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]moviepropval CHANGE MovieID MovieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]loanstatus CHANGE MovieID MovieID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]movies CHANGE ID ID BIGINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 975: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 975</b>:<br>\n";
            $UpdateMessage .= "bugfix for MovieID...<br>\n";

            $strSql = "ALTER TABLE $CFG[Prefix]movies CHANGE ID ID BIGINT NOT NULL AUTO_INCREMENT";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "bugfix for MovieID", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 976: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 976</b>:<br>\n";
            $UpdateMessage .= "adding Status for user...<br>\n";

            $strSql = "ALTER TABLE $CFG[Prefix]users ADD status TINYINT NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding status for user", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            
            $strSql = "UPDATE $CFG[Prefix]users SET status=1";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> setting user-status failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding status for user", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            
            //on some installations it may be at 100 (from build 973)
            $UpdateMessage .= "changing comment-text Field (to 255 Chars length)...<br>\n";
            $strSql = "ALTER TABLE $CFG[Prefix]comment CHANGE Text Text VARCHAR(255) NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing the field failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing size of comments", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            return($ret);
        case 977: //version 0.13+
            //$UpdateMessage .= "upgrading to <b>Build 977</b>:<br>\n";     
			//only some new CFG-variables
            return($ret);

        case 978: //version 0.13+
            //$UpdateMessage .= "upgrading to <b>Build 978</b>:<br>\n";
			//only some new CFG-variables
			return($ret);
            
        case 979: //version 0.13+
            //$UpdateMessage .= "upgrading to <b>Build 979</b>:<br>\n";
			//only some new CFG-variables
            return($ret);
            
        case 980: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 980</b>:<br>\n";

            $strSql = "ALTER TABLE $CFG[Prefix]userrights CHANGE Permissions Permissions TINYINT DEFAULT '0' NOT NULL";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing userrichts-permissions! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing userrichts-permissions", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $UpdateMessage .= "create usergroups-tables<br>\n";
            $sqls = array("CREATE TABLE $CFG[Prefix]usergroup (
                    UG_ID SMALLINT NOT NULL AUTO_INCREMENT ,
                    Name VARCHAR( 50 ) NOT NULL ,
                    IsDefault TINYINT NOT NULL ,
                    PRIMARY KEY ( UG_ID ) ,
                    INDEX ( IsDefault )
                    );",
                "CREATE TABLE $CFG[Prefix]user2group (
                    U_ID INT NOT NULL ,
                    UG_ID SMALLINT NOT NULL ,
                    UNIQUE (U_ID, UG_ID)
                    );",
                "CREATE TABLE $CFG[Prefix]group2list (
                    UG_ID SMALLINT NOT NULL ,
                    L_ID INT NOT NULL ,
                    Permissions TINYINT NOT NULL ,
                    UNIQUE (UG_ID, L_ID)
                    );",
                "INSERT INTO $CFG[Prefix]usergroup (Name, IsDefault)
                    VALUES ('Default', '1');");
            foreach($sqls as $strSql) {
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> creating usergroup-tables failed! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "creating usergroup-tables", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }

            //get UG_ID from default usergroup
            $strSql = "SELECT UG_ID FROM $CFG[Prefix]usergroup WHERE IsDefault=1";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_row($result);
            $DefaultUG_ID = $row[0];

            //check if there are lists that have other new-user-rights than view, if so create a new usergroup
            $strSql = "SELECT COUNT(l.ID) FROM $CFG[Prefix]lists l, $CFG[Prefix]userrights r WHERE l.ID=r.ListID AND r.UserID=0 AND Permissions!=1";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_row($result);
            if($row[0] > 0) {
                $strSql = "INSERT INTO $CFG[Prefix]usergroup (Name, IsDefault) VALUES ('View-Rights', '0');";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $strSql = "SELECT LAST_INSERT_ID()";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $row = mysql_fetch_row($result);
                $ViewUG_ID = $row[0];
            } else {
                $ViewUG_ID = $DefaultUG_ID;
            }

            //add default usergroup to all lists - with new-user-rights
            $strSql = "SELECT l.ID, r.Permissions FROM $CFG[Prefix]lists l, $CFG[Prefix]userrights r WHERE l.ID=r.ListID AND r.UserID=0";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            while($row = mysql_fetch_row($result)) {
				@set_time_limit(10);
                $ListID = $row[0];
                $Permissions = $row[1];
                $strSql = "REPLACE INTO $CFG[Prefix]group2list (UG_ID, L_ID, Permissions) VALUES ('$DefaultUG_ID', '$ListID', '$Permissions')";
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> can't add list to default-group! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "add list to default-group", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
                if($ViewUG_ID!=$DefaultUG_ID) {
                    $strSql = "REPLACE INTO $CFG[Prefix]group2list (UG_ID, L_ID, Permissions) VALUES ('$ViewUG_ID', '$ListID', '1')";
                    if(!@pml_mysql_query($strSql, $pmldb)) {
                        $UpdateMessage .= "<b>WARNING:</b> can't add list to view-group! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                        WriteUpdateError($Build, PML_Update_Warning, "add list to view-group", $strSql, mysql_error($pmldb));
                        $ret = PML_Update_Warning;
                    }
                }
            }


            //add all users with view-rights to view-group
            $strSql = "SELECT UserID FROM $CFG[Prefix]userrights WHERE Permissions='1' AND ListID='$ListID'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            while($row = mysql_fetch_row($result)) {
				@set_time_limit(10);
                $strSql = "REPLACE INTO $CFG[Prefix]user2group (U_ID, UG_ID) VALUES ('$row[0]', '$ViewUG_ID')";
                if(!@pml_mysql_query($strSql, $pmldb)) {
                    $UpdateMessage .= "<b>WARNING:</b> can't add user to default-group! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                    WriteUpdateError($Build, PML_Update_Warning, "add user to default-group", $strSql, mysql_error($pmldb));
                    $ret = PML_Update_Warning;
                }
            }

            //delete all entries from userrights with view-rights (added them to group) or no-rights (not needed)
            $strSql = "DELETE FROM $CFG[Prefix]userrights WHERE Permissions=1 OR Permissions=0";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> can't delete old userrights! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "deleteing old userrights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            return($ret);
            
        case 981: //version 0.13+
            $UpdateMessage .= "upgrading to <b>Build 981</b>:<br>\n";
            
            $strSql = "ALTER TABLE $CFG[Prefix]userrights ADD FetchRights TINYINT NOT NULL AFTER Permissions";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding fetch-rights! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding fetch-rights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            $strSql = "UPDATE $CFG[Prefix]userrights SET FetchRights=1 WHERE Permissions >= 3";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding fetch-rights! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding fetch-rights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

            $strSql = "ALTER TABLE $CFG[Prefix]group2list ADD FetchRights TINYINT NOT NULL AFTER Permissions";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding fetch-rights! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding fetch-rights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            
            $strSql = "UPDATE $CFG[Prefix]group2list SET FetchRights=1 WHERE Permissions >= 3";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding fetch-rights! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding fetch-rights", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
            
            return($ret);
		case 982: //version 0.14 Beta
			$UpdateMessage .= "<br>upgrading to <b>0.14</b> (Build 982):<br>\n";
			$UpdateMessage .= "<strong>Version 0.14 uses a improved database-structure, you need to convert you old entries to the new format. Use <a href=\"convert-structure.php\" target=\"_blank\">this convert-structure-script</a> to do the conversion.</strong><br>\n";
			return($ret);

		case 983: //version 0.14 Beta
            $UpdateMessage .= "upgrading to <b>Build 983</b>:<br>\n";
            $UpdateMessage .= "Adding UseStatistics-Setting to config...<br>\n";
            $CFG['UseStatistics'] = $CFG['UseDloadLog'];
			return($ret);

		case 984: //version 0.14 Beta
		
            $UpdateMessage .= "upgrading to <b>Build 984</b>:<br>\n";
            $UpdateMessage .= "Adding new Sql-Query-Property-Type...<br>\n";

			//DateAdded:
			$strSql = "UPDATE $CFG[Prefix]prop SET PropType='101' WHERE PropType='12';";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing PropType failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing proptype", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

			//Clicks:
			$strSql = "UPDATE $CFG[Prefix]prop SET PropType='102' WHERE PropType='14';";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing PropType failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing proptype", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

			//UserAdded:
			$strSql = "UPDATE $CFG[Prefix]prop SET PropType='103' WHERE PropType='17';";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing PropType failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing proptype", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }

			//Comments:
			$strSql = "UPDATE $CFG[Prefix]prop SET PropType='104' WHERE PropType='18';";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> changing PropType failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "changing proptype", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
			
			$CFG['CustomPropTypes'][101]['name'] = "Date Added";
			$CFG['CustomPropTypes'][101]['sqlFunc'] = "propTypeDateAddedSql";
			$CFG['CustomPropTypes'][102]['name'] = "Clicks";
			$CFG['CustomPropTypes'][102]['sqlFunc'] = "propTypeClicksSql";
			$CFG['CustomPropTypes'][103]['name'] = "User Added";
			$CFG['CustomPropTypes'][103]['sqlFunc'] = "propTypeUserAddedSql";
			$CFG['CustomPropTypes'][104]['name'] = "Number of Comments";
			$CFG['CustomPropTypes'][104]['sqlFunc'] = "propTypeCommentsSql";

            return($ret);

		case 985: //version 0.14 Beta
		
            $UpdateMessage .= "upgrading to <b>Build 985</b>:<br>\n";
            $UpdateMessage .= "Adding new ImageSize-field...<br>\n";

            $strSql = "ALTER TABLE $CFG[Prefix]prop ADD ImageSize VARCHAR(30) NOT NULL DEFAULT ''";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding imagesize-field! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding image-size-field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
			
			$strSql = "SELECT ID, ShowInList FROM $CFG[Prefix]prop WHERE ShowInList > 2;";
            $q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			while($row=mysql_fetch_assoc($q)) {
				if($row['ShowInList']==3) {
					$ImageSize = "95x130";
				} elseif($row['ShowInList']==4) {
					$ImageSize = "120x169";
				} elseif($row['ShowInList']==5) {
					$ImageSize = "94x136";
				}
				//ShowInList = 2: show url as image
				$strSql = "UPDATE $CFG[Prefix]prop SET ShowInList='2', ImageSize='$ImageSize' WHERE ID='$row[ID]';";
				if(!@pml_mysql_query($strSql, $pmldb)) {
					$UpdateMessage .= "<b>WARNING:</b> changing PropType failed. (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
					WriteUpdateError($Build, PML_Update_Warning, "changing proptype", $strSql, mysql_error($pmldb));
					$ret = PML_Update_Warning;
				}
			}
            
            $CFG['UseDloadCounter'] = true;
			return($ret);

		case 986: //version 0.14 Beta
		
            $UpdateMessage .= "upgrading to <b>Build 986</b>:<br>\n";
            $UpdateMessage .= "Adding new DisplayOptions-field...<br>\n";

            $strSql = "ALTER TABLE $CFG[Prefix]indexitems ADD DisplayOptions VARCHAR(20) NOT NULL DEFAULT ''";
            if(!@pml_mysql_query($strSql, $pmldb)) {
                $UpdateMessage .= "<b>WARNING:</b> adding DisplayOptions-field! (MySQL-Message: " . mysql_error($pmldb) . ")<br>\n";
                WriteUpdateError($Build, PML_Update_Warning, "adding DisplayOptions-field", $strSql, mysql_error($pmldb));
                $ret = PML_Update_Warning;
            }
			return($ret);


  	} //end select
} //end function

function getUpdateWarnings($oldBuild)
{
    $ret = "<ul style=\"margin-top: 0; padding-left: 2em;\">";
    if($oldBuild < 971) { //version 0.13
        $ret .= "<li>Build 971 uses a new System for loading Index-List-Data. If you have a custom Index-Template you might have to change the Index-Items config.</li>";
    }
    $ret .= "</ul>";

    return($ret);
}

function WriteUpdateError($Build, $ErrorType, $Item, $SqlString="", $SqlError="") {
global $ErrorFileCreateError;
    $fp = @fopen("updateerror", "a");
    if(!$fp) { $ErrorFileCreateError=true; return(false); }
    $ErrorTypeString[PML_Update_AllOK] = "AllOK";
    $ErrorTypeString[PML_Update_Notice] = "Notice";
    $ErrorTypeString[PML_Update_Warning] = "Warning";
    $ErrorTypeString[PML_Update_Error] = "Error";


    $Dat = date("Y-m-d") . ": " . $ErrorTypeString[$ErrorType] . " when upgrading to build $Build:\n$Item\n";
    if ($SqlString!="") $Dat .= "Sql-Query: $SqlString\nSql-Error: $SqlError\n";
    $Dat .= "\n";
    if(!@fwrite($fp, $Dat)) { $ErrorFileCreateError=true; return(false); }

    fclose($fp);

    return(true);
}

?>
