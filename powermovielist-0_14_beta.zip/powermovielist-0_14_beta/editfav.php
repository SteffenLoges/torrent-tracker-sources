<?php
/** powermovielist edit favorite lists for very user
 * $Id: editfav.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "editfav.php";
$LoadSmarty=true;
include_once("application.php");

$Title = $strfavoriteList;
$TitlePl = $strfavorites;


$Table = $CFG['Prefix'] . "fav";

$Filter = "UserID";
$FilterVal = $ActiveUser['ID'];

$SortOrderField = "SortOrder";

$SessionVar = "editfav";

$i=0;
$Show[$i]['name'] = "ListID";
$Show[$i]['type'] = "listbox";
$strSql = "SELECT ID,Title FROM $CFG[Prefix]lists";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
while($row=mysql_fetch_assoc($result)) {
    $ListIDs[] = $row['ID'];
    $ListTexts[] = $row['Title'];
}
$Show[$i]['values'] = implode(";",$ListIDs);
$Show[$i]['prop'] = implode(";",$ListTexts);
$Show[$i]['text'] = $strList;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";




if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

RequestLogin(PML_LoginStyle_NoGuestAllowed);

if($action=="addfav") {    
    $strSql = "SELECT COUNT(*) FROM $CFG[Prefix]fav WHERE UserID='$ActiveUser[ID]' AND ListID='$ActiveList[ID]'";
    $result=pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row=mysql_fetch_row($result);
    if($row[0]>0) {
        echo "$strActiveListAllreadyInFav<br>";
    } else {
        $strSql = "SELECT SortOrder FROM $CFG[Prefix]fav WHERE UserID='$ActiveUser[ID]' ORDER BY SortOrder ASC";
        $result=pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $row=mysql_fetch_assoc($result);
        $newSortOrder = $row['SortOrder']+1;

        $strSql = "INSERT INTO $CFG[Prefix]fav (UserID, ListID, SortOrder) VALUES ('$ActiveUser[ID]', '$ActiveList[ID]', '$newSortOrder')";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

        echo "$strAddedListToFav...<br>";
    }

    $_GET['action']=$action="";
}

if($action=="addsave") {
    $strSql = "SELECT COUNT(*) FROM $CFG[Prefix]fav WHERE UserID='$ActiveUser[ID]' AND ListID='$_POST[ListID]'";
    $result=pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row=mysql_fetch_row($result);
    if($row[0]>0) {
        echo "$strSelListAllreadyFav...<br>";
        $_GET['action']=$action="";
    }
}
if($action=="editsave") {
    $strSql = "SELECT COUNT(*) FROM $CFG[Prefix]fav WHERE UserID='$ActiveUser[ID]' AND ListID='$_POST[ListID]' AND ID!='$_GET[ID]'";
    $result=pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row=mysql_fetch_row($result);
    if($row[0]>0) {
        echo "$strSelListAllreadyFav...<br>";
        $_GET['action']=$action="";
    }
}

$DOC_TITLE = $strPropertyValues;
include("top.html");		

include("edit.php");

if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$action = "";
	$_GET['action'] = $action;
	include("edit.php");
}


include("bottom.html");


?>