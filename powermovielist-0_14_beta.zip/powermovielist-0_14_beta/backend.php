<?php
/** powermovielist xml/rss backend
 * $Id: backend.php,v 1.6 2005/11/02 18:19:32 niko Exp $
*/
$FILE_SELF = "backend.php";
include_once("application.php");

if($ActiveUser['admin']==1) //wenn admin ist, hat er view-rechte fr alle listen
	$strSql = "SELECT $CFG[Prefix]movies.* FROM $CFG[Prefix]movies,$CFG[Prefix]lists
	WHERE $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID ORDER BY $CFG[Prefix]movies.DateAdded DESC LIMIT 5";  
else
	//sonst nur listen anzeigen fr die auch view-rechte vorhanden sind:
$strSql = "SELECT $CFG[Prefix]movies.*
FROM $CFG[Prefix]movies,$CFG[Prefix]lists,$CFG[Prefix]userrights
WHERE $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID
AND $CFG[Prefix]userrights.ListID=$CFG[Prefix]lists.ID
AND $CFG[Prefix]userrights.UserID=$ActiveUser[ID]
AND $CFG[Prefix]userrights.Permissions > ".PML_Rights_None."
ORDER BY $CFG[Prefix]movies.DateAdded DESC LIMIT 5";  

$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$Data[$row['ID']][0] = $row;
}	


header("Content-Type: text/xml;charset=iso-8859-1");

$result = pml_mysql_query($strSql, $pmldb) or ErrorExit("can't execute $strSql (" . mysql_error($pmldb) . ")");

echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n\n";
echo "<!DOCTYPE rss PUBLIC \"-//Netscape Communications//DTD RSS 0.91//EN\"\n";
echo " \"http://my.netscape.com/publish/formats/rss-0.91.dtd\">\n\n";
echo "<rss version=\"0.91\">\n\n";
echo "<channel>\n";
echo "<title> PowerMovieList new entries </title>\n";
echo "<link>". $CFG['HttpPath'] ."</link>\n";
echo "<description> PowerMovieList Version". $Version . " XML backend </description>\n";
echo "<language>en</language>\n\n";


$ListData = array();
$i=0;
foreach($Data as $Movie) {
	$MovieID = $Movie[0]['ID'];
	$ListID = $Movie[0]['ListID'];
	if(!isset($ListData[$ListID])) {
		$strSql = "SELECT *
		FROM $CFG[Prefix]lists
		WHERE $CFG[Prefix]lists.ID=$ListID";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_array($result, MYSQL_ASSOC);
		$ListData[$ListID] = $row;
	}
	$ListName = $ListData[$ListID]['name'];
	$ListTitle = $ListData[$ListID]['title'];

    $Text = GetFetchText($MovieID, $ListID);
    echo "<item>\n";
    echo "<link>" .
    htmlspecialchars(  $CFG['HttpPath'] . "/popup.php?Active=" 
                     . $ListName   . "&ID=" . $MovieID) . "</link>\n";
    echo "<title>" .
    htmlspecialchars($ListTitle . ": " .  $Text). "</title>\n";
    echo "</item>\n\n";
}
echo "</channel>\n";
echo "</rss>";

?>
