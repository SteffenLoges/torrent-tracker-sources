<?php
/** powermovielist edit users
 * $Id: edituser.php,v 1.10 2005/10/21 16:30:59 niko Exp $
*/
$FILE_SELF = "edituser.php";
include_once("application.php");

if(!$usr->UseEditUser)
    ErrorExit("You can't use the pml-user-files, as they have been disabled.");


if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";


$Title = "member";
$TitlePl = "members";
$Table = $CFG['Prefix'] . "users";
$joinTable = "LEFT JOIN $CFG[Prefix]user2group u2g ON u2g.U_ID=$Table.ID";
$groupBy = "$Table.ID";
$SessionVar = "edituser";

if($CFG['UseUserStatus']) {
    $DisplayFormList = true;
}

$i=0;
$Show[$i]['name'] = "name";
$Show[$i]['type'] = "username";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = $strEditUserFldName;
$Show[$i]['comm'] = $strValidCharsUserName;
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = true;
$Show[$i]['newonly'] = true;
$Show[$i]['sortkey'] = "name";
$Show[$i]['sortdir'] = 0;
$Show[$i]['sortdef'] = true;
$Show[$i]['detaillink']=true;

$strSql="SELECT * FROM " . $CFG['Prefix'] . "users WHERE admin='1'";
if(mysql_num_rows(pml_mysql_query($strSql, $pmldb))==0) {
	$InstallMode = True;
	$i++;
	$Show[$i]['name'] = "admin";
	$Show[$i]['type'] = "hidden";
	$Show[$i]['def'] = "1";
	$Show[$i]['uniq'] = false;
	$Show[$i]['newonly'] = true;
} else {
	$InstallMode = False;
	if($ActiveUserRights>=PML_Rights_SuperAdmin) {
		$i++;
		$Show[$i]['name'] = "admin";
		$Show[$i]['type'] = "listbox";
		$Show[$i]['prop'] = $strEditUserFldRightsProp;
		$Show[$i]['values'] = "0;1";
		$Show[$i]['text'] = "User-Type";
		$Show[$i]['comm'] = "Administrator: All rights for all lists";
		$Show[$i]['main'] = true;
		$Show[$i]['def'] = "0";
		$Show[$i]['uniq'] = false;
	}
}
if($ActiveUserRights>=PML_Rights_ListAdmin) {
    $i++;
    $Show[$i]['name'] = "usergroups";
    $Show[$i]['type'] = "listboxmulti";
    $Show[$i]['text'] = "Usergroups";
    $strSql = "SELECT UG_ID, Name FROM $CFG[Prefix]usergroup";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $Show[$i]['prop'] = "";
    $Show[$i]['values'] = "";
    while($row = mysql_fetch_row($result)) {
        $Show[$i]['prop'] .= $row[1].";";
        $Show[$i]['values'] .=  $row[0].";";
    }
    $Show[$i]['prop'] = substr($Show[$i]['prop'], 0, -1);
    $Show[$i]['values'] = substr($Show[$i]['values'], 0, -1);
    $Show[$i]['comm'] = "";
    $Show[$i]['table'] = "$CFG[Prefix]user2group";
    $Show[$i]['fieldVal'] = "UG_ID";
    $Show[$i]['fieldKey'] = "U_ID";
    $Show[$i]['main'] = true;
    $Show[$i]['save'] = true;
}
$i++;
$Show[$i]['name'] = "pass";  
$Show[$i]['type'] = "pass";  
$Show[$i]['prop'] = "15";  
$Show[$i]['text'] = $strEditUserFldPass;  
$Show[$i]['comm'] = "";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
$Show[$i]['hidedetails']=true;
$i++;
$Show[$i]['name'] = "email";
$Show[$i]['type'] = "email";
$Show[$i]['prop'] = "";
$Show[$i]['text'] = $strEditUserFldMail;
if($CFG['UseActivate'])
	$Show[$i]['comm'] = "($strValidAdressRequiredToActivateTheAccount)";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = true;
if($ActiveUserRights<PML_Rights_SuperAdmin)
	$Show[$i]['showemailfld'] = "showemail";

if($CFG['ShowUserDetails'])
{
    $i++;
    $Show[$i]['name'] = "showemail";
    $Show[$i]['type'] = "checkbox";
    $Show[$i]['prop'] = "1;0";
    $Show[$i]['text'] = $strShowEmailAdress;
    $Show[$i]['comm'] = "";	
    $Show[$i]['def'] = "1";	
    $Show[$i]['main'] = false;
    $Show[$i]['hidedetails']=true;
    $i++;
    $Show[$i]['name'] = "icq";
    $Show[$i]['type'] = "icq";
    $Show[$i]['prop'] = "10";
    $Show[$i]['text'] = $strEditUserIcqNumber;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "";
    $Show[$i]['uniq'] = false;
    $i++;
    $Show[$i]['name'] = "aim";
    $Show[$i]['type'] = "aim";
    $Show[$i]['prop'] = "10";
    $Show[$i]['text'] = $strEditUserAimName;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "";
    $Show[$i]['uniq'] = false;
    $i++;
    $Show[$i]['name'] = "userhp";
    $Show[$i]['type'] = "link";
    $Show[$i]['prop'] = "35";
    $Show[$i]['text'] = $strEditUserHomepage;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = true;
    $Show[$i]['def'] = "";
    $Show[$i]['uniq'] = false;
    $i++;
    $Show[$i]['name'] = "location";
    $Show[$i]['type'] = "text";
    $Show[$i]['prop'] = "35";
    $Show[$i]['text'] = $strEditUserLocation;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "";
    $Show[$i]['uniq'] = false;
    $i++;
    $Show[$i]['name'] = "work";
    $Show[$i]['type'] = "text";
    $Show[$i]['prop'] = "35";	
    $Show[$i]['text'] = $strEditUserOccupation;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "";
    $Show[$i]['uniq'] = false;
    $i++;
    $Show[$i]['name'] = "gender";
    $Show[$i]['type'] = "listbox";
    $Show[$i]['prop'] = $strEditUserGenderProp;
    $Show[$i]['values'] = "0;1;2";
    $Show[$i]['text'] = $strEditUserGender;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "0";
    $Show[$i]['uniq'] = false;
    $i++;
    $Show[$i]['name'] = "birthdate";
    $Show[$i]['type'] = "date";
    $Show[$i]['prop'] = "";
    $Show[$i]['text'] = $strEditUserBirthDate;
    $Show[$i]['comm'] = $strEditOptional;
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "";
    $Show[$i]['uniq'] = false;
}


//fields only written when creating a new user
$i++;
$Show[$i]['name'] = "regdate";
$Show[$i]['type'] = "hidden";
$Show[$i]['prop'] = "";
$Show[$i]['text'] = "regdate";
$Show[$i]['comm'] = $strEditOptional;
$Show[$i]['main'] = true;
$Show[$i]['def'] = date("Y-m-d");
$Show[$i]['newonly'] = true;
$Show[$i]['sortkey'] = "regdate";
$Show[$i]['sortdir'] = 1;
$Show[$i]['sortdef'] = false;

//for the first admin-account, don't use the activate-feature
//and if admin is logged in don't use the activate-feature
if(!$InstallMode && !($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $CFG['UseActivate']) {
	$i++;
	$Show[$i]['name'] = "activate";
	$Show[$i]['type'] = "hidden";
	$Show[$i]['prop'] = "";
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = rand();
	$Show[$i]['newonly'] = true;
	$Show[$i]['hidedetails']=true;
}
if($InstallMode && $CFG['UseUserStatus']) {
    //set the status=1 when in installMode or SuperAdmin creates an account
    $i++;
    $Show[$i]['name'] = "status";
    $Show[$i]['type'] = "hidden";
    $Show[$i]['prop'] = "1";
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "1";
    $Show[$i]['newonly'] = true;
    $Show[$i]['hidedetails']=true;
}

if(($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $CFG['UseUserStatus']) {
    //if the user is enabled, only for super-admins!
    $i++;
    $Show[$i]['name'] = "status";
    $Show[$i]['type'] = "editcheckbox";
    $Show[$i]['prop'] = "1;0";
    $Show[$i]['text'] = "enabled";
    $Show[$i]['comm'] = ""; 
    $Show[$i]['def'] = "0"; 
    $Show[$i]['main'] = true;
    $Show[$i]['hidedetails']=true;
}

if(($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $CFG['UseActivate']) {
    //and in the list show if the user is activated, only for super-admins!
	$i++;
	$Show[$i]['name'] = "isactivated";
    $Show[$i]['text'] = "activated";
	$Show[$i]['type'] = "func";
	$Show[$i]['func'] = "getActivated";
	$Show[$i]['main'] = true;
	$Show[$i]['save'] = false;   
}


//statistic-data**********
$i++;
$Show[$i]['name'] = "lists";
$Show[$i]['text'] = "lists";
$Show[$i]['type'] = "func";
$Show[$i]['main'] = true; //show in main
$Show[$i]['func'] = "getUserLists";
$Show[$i]['save'] = false; 

//statistics for user-dateils:
$i++;
$Show[$i]['name'] = "comments";
$Show[$i]['save'] = false;
$Show[$i]['main'] = false;
$Show[$i]['type'] = "func";
$Show[$i]['text'] = $strCommentsPosted;
$Show[$i]['func'] = "GetCommentsPosted";
$i++;
$Show[$i]['name'] = "rating";
$Show[$i]['save'] = false;
$Show[$i]['main'] = false;
$Show[$i]['type'] = "func";
$Show[$i]['text'] = $strUserRatings;
$Show[$i]['func'] = "GetUserRatings";
$i++;
$Show[$i]['name'] = "added";
$Show[$i]['save'] = false;
$Show[$i]['main'] = false;
$Show[$i]['type'] = "func";
$Show[$i]['text'] = $strEntriesAdded;
$Show[$i]['func'] = "GetMoviesAdded";
$i++;
$Show[$i]['name'] = "dloadcount";
$Show[$i]['save'] = false;
$Show[$i]['main'] = false;
$Show[$i]['type'] = "hidden";
$Show[$i]['text'] = $strDownloads;
$Show[$i]['def'] = "0";


if($action=="add" && $CFG['ListType']==1) { //adding new user & new list in simple mode
//has to be written:
//UserID, name
//title, url, urlname, image, lang, presetting
	$i++;
	$Show[$i]['name'] = "title";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "20";
	$Show[$i]['text'] = $strEditUserFldTitle;
	$Show[$i]['comm'] = "";
	$Show[$i]['main'] = true;
	$Show[$i]['def'] = $strEditUserFldTitleDefault;
	$Show[$i]['uniq'] = true;
	$Show[$i]['sortdef'] = false;
	$Show[$i]['sortkey'] = "title";
	$Show[$i]['sortdir']=1;
	$Show[$i]['save'] = false;
	$i++;
	$Show[$i]['name'] = "url";
	$Show[$i]['type'] = "url";
	$Show[$i]['prop'] = "35";
	$Show[$i]['text'] = $strEditUserFldUrl;
	$Show[$i]['comm'] = $strEditUserFldUrlComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = $strEditUserFldUrlDefault;
	$Show[$i]['uniq'] = false;
	$Show[$i]['save'] = false;
	$i++;
	$Show[$i]['name'] = "urlname";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "35";
	$Show[$i]['text'] = $strEditUserFldUrlShown;
	$Show[$i]['comm'] = $strEditUserFldUrlShownComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = $strEditUserFldUrlShownDefault;
	$Show[$i]['uniq'] = false;
	$Show[$i]['save'] = false;
	$i++;
	$Show[$i]['name'] = "image";
	$Show[$i]['type'] = "file";
	$Show[$i]['prop'] = "image/logos/";
	$Show[$i]['text'] = $strEditUserFldPic;
	$Show[$i]['comm'] = "<a href='uploadimage.php$GlobalArg'>" . $strEditUserFldPicComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "standard.gif";
	$Show[$i]['uniq'] = false;
	$Show[$i]['save'] = false;	
	$i++;
	$Show[$i]['name'] = "lang";
	$Show[$i]['type'] = "file";
	$Show[$i]['prop'] = "lang/";
	$Show[$i]['filt'] = ".inc.php";  //only show files with .inc.php and don't display the .inc.php
	$Show[$i]['text'] = $strEditUserFldLang;
	$Show[$i]['comm'] = "";
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "english";
	$Show[$i]['uniq'] = false;
	$Show[$i]['save'] = false;
	$i++;
	$PropSettings=array();
	$d = dir("presettings");
	while($entry=$d->read()) {
		if(filetype("presettings/" . $entry)!="file") continue;
		if(strtolower(substr($entry, -6))!="pmlset") continue;
		$Dat=substr($entry,0,strlen($entry)-7);
		$Dat = str_replace("_", " ", $Dat);
		$PropSettings[$entry]=$Dat;
	}
	$d->close();
	$Show[$i]['name'] = "presetting";
	$Show[$i]['type'] = "listbox";
	$Show[$i]['prop'] = "1;0";
	$Show[$i]['text'] = $strPresettingToImport;
	$Show[$i]['comm'] = "($strWhatTypeOfListYouWantToHave)";
	$Show[$i]['main'] = false;
	$Show[$i]['prop'] = implode(";", $PropSettings);
	$Show[$i]['values'] = implode(";", array_keys($PropSettings));
	$Show[$i]['def'] = "Standard_Movie-List_with_imdb.pmlset";
	$Show[$i]['uniq'] = false;
	$Show[$i]['newonly'] = true;
	$Show[$i]['save'] = false; 

}




$DisplayFilterButton = "search";
$i=0;
$DisplayFilter[$i]['name'] = "name";
$DisplayFilter[$i]['text'] = $strSearchFor;
$DisplayFilter[$i]['type'] = "text";
$DisplayFilter[$i]['sql'] = "(name LIKE '%_Text%')";
if(($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $CFG['UseUserStatus']) {
    $i++;
    $DisplayFilter[$i]['name'] = "status";
    $DisplayFilter[$i]['type'] = "listbox";
    $DisplayFilter[$i]['item'] = array("", "no", "yes");
    $DisplayFilter[$i]['text'] = "enabled";
    $DisplayFilter[$i]['itemsql'] = array("1", "status=0", "status=1");
}
if(($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $CFG['UseActivate']) {
    $i++;
    $DisplayFilter[$i]['name'] = "activated";
    $DisplayFilter[$i]['type'] = "listbox";
    $DisplayFilter[$i]['item'] = array("", "no", "yes");
    $DisplayFilter[$i]['text'] = "activate";
    $DisplayFilter[$i]['itemsql'] = array("1", "activate!=0", "activate=0");
}
if($ActiveUserRights==PML_Rights_SuperAdmin) {
    $i++;
    $DisplayFilter[$i]['name'] = "admin";
    $DisplayFilter[$i]['type'] = "listbox";
    $DisplayFilter[$i]['item'] = array("all", "normal user", "all but normal users", "moderator", "user-admin", "super-admin");
    $DisplayFilter[$i]['text'] = "user-type";
    $DisplayFilter[$i]['itemsql'] = array("1", "admin=0", "admin!=0", "admin=3", "admin=2", "admin=1");
}
$i++;
$DisplayFilter[$i]['name'] = "usergroup";
$DisplayFilter[$i]['type'] = "listbox";
$DisplayFilter[$i]['text'] = "usergroup";
$strSql = "SELECT UG_ID, Name FROM $CFG[Prefix]usergroup";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$DisplayFilter[$i]['item'] = array("all", "no group");
$DisplayFilter[$i]['itemsql'] = array("1", "ISNULL(u2g.U_ID)");
while($row = mysql_fetch_row($result)) {
    $DisplayFilter[$i]['item'][] = $row[1];
    $DisplayFilter[$i]['itemsql'][] = "u2g.UG_ID='$row[0]'";
}

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

$Filter = "";
$FilterVal = "";

//User-Admins (admin==2) can only edit normal users
if($ActiveUser['admin']==2) {
    $Filter = "admin";
    $FilterVal = "0";
}

switch($action) {
	case "":
		RequestLogin(PML_LoginStyle_NoGuestAllowed);
		if(($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2)) {
			$ShowEditLinks=true;
		} else {
			$ShowEditLinks=false;
		}

		$DOC_TITLE = $strMemberList;
		include("top.html");
		break;
	case "addsave":	
		//nach dem hinzufgen des benutzers automatisch zur liste wechseln...
		//$DoRefresh=TRUE;
		if($CFG['ListType']>0)  //ListType = 0 all features with multiple users; 1&2 every user = one list
			$RefreshUrl = "editlist.php?action=add";
		else
			$RefreshUrl = $GLOBALS['ListUrl'];
		
        if($CFG['EMailBlackListFile']!="" && is_file($CFG['EMailBlackListFile'])) {
            $EMailBlackList = file($CFG['EMailBlackListFile']);
            foreach($EMailBlackList as $BlackEMail) {
                if(eregi(WildToReg($BlackEMail), $_POST['email'])) {
                    include("top.html");
                    ErrorExit($strInvalidEMailYouAreOnBlacklist);
                }
            }
        }
        
        if(!$InstallMode && $CFG['ListType'] >=2) {
            include("top.html");
            ErrorExit($strEditUserCantAddSingle);
        }


        if($CFG['ListType']==1) {
            if(!$InstallMode && !$CFG['ShowRegisterList'])
                 RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
        } else {
            if(!$InstallMode && !$CFG['ShowRegisterUser'])
                RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
        }
            
	case "add":
		if(!$InstallMode && $CFG['ListType'] >=2) {
			include("top.html");
			ErrorExit($strEditUserCantAddSingle);
		}


		if($CFG['ListType']==1) {
			if(!$InstallMode && !$CFG['ShowRegisterList'])
				 RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
		} else {
			if(!$InstallMode && !$CFG['ShowRegisterUser'])
				RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
		}

		$DOC_TITLE = $strEditUserAdd;
		include("top.html");
		if($CFG['ListType'] < 2) {
			if($InstallMode)
				echo $strEditUserFirstAccountSuperAdmin;
		}
		if($CFG['ListType'] > 0)  //ListType = 0 all features with multiple users; 1&2 every user = one list
			$SaveButtonText = $strContinue;  //continue um liste zu erstellen
		else
			$SaveButtonText = $strAddUser;  //user einfach hinzufgen...
		break;
    case "listsave":
	case "edit":
	case "editsave":
		RequestLogin(PML_LoginStyle_NoGuestAllowed);
		if(!($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $ActiveUser['ID']!=$ID) {
			ErrorExit("you can't edit this account, login as super-admin or with this account");
		}
		
        $DOC_TITLE = $ActiveUser['name'] . " - " . $strEditUserEdit;
		include("top.html");
		$SaveButtonText = $strEditSaveSettings;
        if($action=="editsave")
        {
            $strSql = "SELECT status,admin,name FROM " . $CFG['Prefix'] . "users WHERE ID='$ID'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_assoc($result);
            $statusBevoreSave[$ID] = $row['status'];
            
            //User-Admin (admin==2) can only edit normal users
            if($ActiveUser['admin']==2 && $row['admin']!=0) {
                ErrorExit("you can't edit this account as it has special rights. login as super-admin to edit this account.");
            }
            if($row['name']=="Guest") {
                ErrorExit("you can't edit the Guest-Account");
            }
        }
        else if($action=="listsave")
        {
            $ListEditID = $_POST['ListEditID'];
            
            $strSql = "SELECT ID,status,admin,name FROM " . $CFG['Prefix'] . "users WHERE ID IN ('".implode("', '", array_keys($ListEditID))."')";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            while($row = mysql_fetch_assoc($result))
            {
                $statusBevoreSave[$row['ID']] = $row['status'];
                
                //User-Admin (admin==2) can only edit normal users
                if($ActiveUser['admin']==2 && $row['admin']!=0) {
                    ErrorExit("you can't edit this account as it has special rights. login as super-admin to edit this account.");
                }
                if($row['name']=="Guest") {
                    //kann nicht bearbeitet werden
                    unset($_POST['ListEditID'][$row['ID']]);
                }
            }
        }
		break;
	case "delpass":
	case "del":
	case "delsave":
	case "delsavepass":
		if($CFG['ListType'] >=2) {
			include("top.html");
			echo $strEditUserCantDeleteUserSingle;
			exit;
		}
		RequestLogin(PML_LoginStyle_NoGuestAllowed);
		if(!($ActiveUserRights==PML_Rights_SuperAdmin || $ActiveUser['admin']==2) && $ActiveUser['ID']!=$ID) {
			ErrorExit("you can't edit this account, login as super-admin or with this account");
		}

        if(isset($_GET['ID'])) $ID = $_GET['ID'];
		$strSql = "SELECT name, email FROM " . $CFG['Prefix'] . "users WHERE ID='$ID'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_assoc($result);
		if($row['name']=="Guest") {
			include("top.html");
			ErrorExit("You can't delete the Guest-User.");
		}
        
        if($CFG['EMailBlackListFile']!="")
        {
            $fp = fopen($CFG['EMailBlackListFile'], "a");
            fwrite($fp, "\n".$row['email']);
            fclose($fp);
            echo "<br>Added E-Mail Adress to Blacklist.";
        }
        

		$DOC_TITLE = $ActiveUser['name'] . " - " . $strEditUserDel;
		include("top.html");
		break;
	case "details":
		RequestLogin(PML_LoginStyle_NoGuestAllowed);
		$DOC_TITLE = "details";
		include("top.html");
		break;
	default:
		ErrorExit("Invalid action! ($action)");
}

include("edit.php");

if(!isset($lastAction)) $lastAction="";

if($action=="editsave" || $lastAction=="listsave")
{
    if($action=="editsave")
    {
        $strSql = "SELECT status FROM " . $CFG['Prefix'] . "users WHERE ID='$ID'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $row = mysql_fetch_assoc($result);
        $statusAfterSave[$ID] = $row['status'];
    }
    else if($lastAction=="listsave")
    {
        $ListEditID = $_POST['ListEditID'];
        
        $strSql = "SELECT ID,status FROM " . $CFG['Prefix'] . "users WHERE ID IN ('".implode("', '", array_keys($ListEditID))."')";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        while($row = mysql_fetch_assoc($result)) {
            $statusAfterSave[$row['ID']] = $row['status'];
        }
    }
    if($CFG['UseUserStatus'])
    {
        foreach($statusAfterSave as $ID=>$status) {
            if($status && !$statusBevoreSave[$ID]) {
                $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE ID='$ID'";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $row = mysql_fetch_assoc($result);
                if($row['activate']!=0 && $CFG['UseActivate']) {
                    SendActivationMail($row);
                }
            }
        }
    }
}
else if($action=="addsave")
{
    $NewID = mysql_insert_id();

    //Nur wenn ListType = 0 !!! **************************************
    if($CFG['ListType']==0) { //ListType = 0 all features with multiple users; 1&2 every user = one list
        //add user to default usergroup
        $strSql = "SELECT UG_ID FROM $CFG[Prefix]usergroup WHERE IsDefault=1";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $row = mysql_fetch_row($result);
        $UG_ID = $row[0];
        $strSql = "INSERT INTO $CFG[Prefix]user2group (U_ID, UG_ID) VALUES ('$NewID', '$UG_ID')";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    }
    // ********************************************************************************************


    
    if($CFG['UseUserStatus'])
    {
        echo "$strUserAddedSucessfullyEMailWhenEnabled<br><br>";
    }
    else
    {
        if(($CFG['UseActivate'] && !$InstallMode) || $ActiveUserRights==PML_Rights_SuperAdmin)
        {
            //send activation-email:
            $_POST['ID'] = $ID;
            SendActivationMail($_POST);
        }
        else
        {
            if($ActiveUser['name']=="Guest") {
                //neuen benutzer einloggen: - wenn vorher als guest
                $LoggedIn = $_POST['name'];
                $_SESSION['LoggedIn'] = $LoggedIn;
            } else {
                echo $strNewUserNotLoggedIn."\n";
            }
        }
        
        echo $strUserAddedSucessfully."\n";
    }
    
    


    if($CFG['ListType']==1) { //adding new user & new list in simple mode
        //has to be written:
        //UserID, name
        //title, url, urlname, image, lang ..... presetting
        $strSql = "INSERT INTO $CFG[Prefix]lists (UserID, name, title, url, urlname, image, lang)
                   VALUES ('$ID', '$_POST[name]','$_POST[title]','$_POST[url]','$_POST[urlname]','$_POST[image]','$_POST[lang]')";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $ListID = mysql_insert_id();

        AddListActions(); //do the actions that has to be done when a new list is created...

    }

    if($CFG['ListType']==1) { //simple mode
        //print nothing out, this is allready done in AddListActions()
    } elseif($CFG['ListType']==2) { //single-list-mode
        echo $strEditUserClickHereContinueCreateList;
    } else { //full-mode
        echo $strEditUSerClickHereGoBackList;
    }
	
} elseif($action=="delsave" || $action=="delsavepass") {
    //userrights l�chen	
	$strSql = "DELETE FROM " . $CFG['Prefix'] . "userrights WHERE UserID=" .$ID;
	pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "user2group WHERE U_ID=" .$ID;
    pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
	echo "<br>$strEditUserUserrightsDeleted\n";

    //favoriten l�chen
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "fav WHERE UserID=" .$ID;
	pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    echo "<br>$strFavDeleted";

    //popup-cache l�schen wo kommentare abgegeben
    $strSql = "SELECT c.MovieID, l.name AS ListName
            FROM {$CFG['Prefix']}comment c,{$CFG['Prefix']}movies m,{$CFG['Prefix']}lists l
            WHERE l.ID = m.ListID
            AND m.ID=c.MovieID
            AND c.UserID=" .$ID;
    $result = pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    loadSmarty();
    while($row = mysql_fetch_assoc($result)) {
        $smarty->clear_cache(null,"popup|$row[ListName]|$row[MovieID]");
        $smarty->clear_cache(null,"comments|$row[ListName]|$row[MovieID]");
    }
    
    //kommentare l�schen
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "comment WHERE UserID=" .$ID;
    pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    echo "<br>User-Comments deleted...";

    //popup-cache l�schen wo votes abgegeben
    $strSql = "SELECT v.MovieID, l.name AS ListName
            FROM {$CFG['Prefix']}votes v,{$CFG['Prefix']}movies m,{$CFG['Prefix']}lists l
            WHERE l.ID = m.ListID
            AND m.ID=v.MovieID
            AND v.UserID=" .$ID;
    $result = pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    while($row = mysql_fetch_assoc($result)) {
        $smarty->clear_cache(null,"popup|$row[ListName]|$row[MovieID]");
    }
    //votes l�chen
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "votes WHERE UserID=" .$ID;
    pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    echo "<br>User-Votes deleted...";
    
    //log+counter l�chen
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "counter WHERE UserID=" .$ID;
    pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "dloadlog WHERE UserID=" .$ID;
    pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    
    
    
    
	
    if($ActiveUser['ID']==$ID) {
		$LoggedIn = ""; //eingeloggten benutzer l�chen...
		$_SESSION['LoggedIn'] = $LoggedIn;
	}

	if($CFG['ListType']==1) {
		//bei simple-mode die liste auch l�chen:

		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE UserID=$ID";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_array($result);


		$strSql = "DELETE FROM " . $CFG['Prefix'] . "movies WHERE ListID=$row[ID]";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		echo "<br>$strEditUserEntriesDeleted\n";


	//liste aus linkliste l�chen	
		$strSql = "DELETE FROM " . $CFG['Prefix'] . "linklist WHERE ListID=" .$row['ID'];
		pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
		echo "<br>$strEntriesInLinklistDeleted\n";
		
	//userrights l�chen	
		$strSql = "DELETE FROM " . $CFG['Prefix'] . "userrights WHERE ListID=" .$row['ID'];
		pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
        $strSql = "DELETE FROM " . $CFG['Prefix'] . "group2list WHERE L_ID=" .$row['ID'];
        pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
		echo "<br>$strEditUserUserrightsDeleted\n";
	}

    
    echo "<br><a href='edituser.php$GlobalArg'>$strContinue</a>\n";
        
} //endif action


//clear smarty-cache for all lists (linklist might be effected)
if($CFG['ListType']==1 && ($action=="addsave" || $action=="editsave" || $action=="delsave")) {
    loadSmarty();
	$smarty->clear_cache(null,"list"); //because of linklist
	$smarty->clear_cache(null,"popup|$Active");
}


include("bottom.html");


function getUserLists($ID) {
global $CFG, $pmldb;	
	$strSql = "SELECT name, title FROM " . $CFG['Prefix'] . "lists WHERE UserID=$ID AND name NOT LIKE 'index'";
	$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$num1 = mysql_num_rows($result1);
	$x = "<ul>";
	for($i1=0;$i1<$num1;$i1++) {
		$row1 = mysql_fetch_array($result1);		
		$x.= "<li><a href='list.php".$GLOBALS['GlobalArgWOActive']."Active=$row1[name]'>$row1[title]</a>";
	}
	$x .= "</ul>\n";
	return($x);
}

function GetCommentsPosted($ID) {
global $CFG, $pmldb;	
	$strSql = "SELECT COUNT(*) AS Cnt FROM " . $CFG['Prefix'] . "users," . $CFG['Prefix'] . "comment WHERE " . $CFG['Prefix'] . "users.ID=$ID AND " . $CFG['Prefix'] . "users.ID=" . $CFG['Prefix'] . "comment.UserID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
	return($row['Cnt']);
}

function GetUserRatings($ID) {
global $CFG, $pmldb;	
	$strSql = "SELECT COUNT(*) AS Cnt FROM " . $CFG['Prefix'] . "users," . $CFG['Prefix'] . "votes WHERE " . $CFG['Prefix'] . "users.ID=$ID AND " . $CFG['Prefix'] . "users.ID=" . $CFG['Prefix'] . "votes.UserID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
	return($row['Cnt']);
}

function GetMoviesAdded($ID) {
global $CFG, $pmldb;	
	$strSql = "SELECT COUNT(*) AS Cnt FROM " . $CFG['Prefix'] . "movies WHERE UserAddedID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
	return($row['Cnt']);
}

function getActivated($ID) {
global $CFG, $pmldb;
	$strSql = "SELECT activate FROM " . $CFG['Prefix'] . "users WHERE ID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
    if($row['activate']==0)
        return("yes");
    else
        return("no");	
}

global $CFG, $sqlStrings;
if($CFG['Debug']) {
    p($sqlStrings);
}

?>