<?php
/** powermovielist view loan information
 * $Id: loanmenu.php,v 1.10 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "loanmenu.php";
include("application.php");
RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Loan);

include("top.html");

echo "<TABLE border=3 cellpadding=3 cellspacing=3 width=100%>\n";
echo "<TR><TD><b>";
echo $ActiveUser['name'];
echo "'s&nbsp;";
echo $strLoanTitle;

if ($_GET['op'] == "cart")	{
echo "</b><br><b>$strshoppingcart</b><br><br>\n";
echo "<TABLE border=0 cellpadding=0 cellspacing=0>\n";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strCurrentlyLoggedInAs]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><font size=1><b>$ActiveUser[name]</b></font></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strAreas]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_loans' target=_top><font size=1><b>$GLOBALS[strViewLoans]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_borrowed' target=_top><font size=1><b>$GLOBALS[strborrowed]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_requests' target=_top><font size=1><b>$GLOBALS[strViewRequests]</b></font></a></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strCartControls]</b></font></TD></TR>";

$strSql = $strSql = "SELECT * FROM " . $CFG['Prefix'] . "loanstatus WHERE UserID=$ActiveUser[ID] AND status=1 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);
if ($num==""){
echo "<TR><TD align='center' height=20 colspan=2><font size=2>$strCartEmpty</font></TD></TR>";}else{

echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=empty_my_cart' target=_top><font size=1><b>$GLOBALS[strClearAll]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=reserve_all' target=_top><font size=1><b>$GLOBALS[strreserve_all_items]</b></font></a></TD></TR>";
}
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD align='center' height=20 colspan=2><a href='list.php{$GlobalArg}' target=_top><font size=1><b>$GLOBALS[strGoToTheList]</b></font></a></TD></TR>"; 
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
};

if ($_GET['op'] == "request")	{
echo "</b><br><b>$strMovieRequests</b><br><br>\n";
echo "<TABLE border=0 cellpadding=0 cellspacing=0>\n";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strCurrentlyLoggedInAs]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><font size=1><b>$ActiveUser[name]</b></font></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strAreas]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_loans' target=_top><font size=1><b>$GLOBALS[strViewLoans]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_borrowed' target=_top><font size=1><b>$GLOBALS[strborrowed]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=my_reserve_basket' target=_top><font size=1><b>$GLOBALS[strSeeCart]</b></font></a></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strLoanControl]</b></font></TD></TR>";

$strSql = "SELECT " . $CFG['Prefix'] . "loanstatus.* FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "loanstatus," . $CFG['Prefix'] . "lists WHERE " . $CFG['Prefix'] . "movies.ID=" . $CFG['Prefix'] . "loanstatus.MovieID AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=$ActiveUser[ID] AND status=2 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);
if ($num==""){
echo "<TR><TD align='center' height=20 colspan=2><font size=2>$strNoRequests</font></TD></TR>";}else{
	
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=clear_requests' target=_top><font size=1><b>$GLOBALS[strClearRequests]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=approve_all' target=_top><font size=1><b>$GLOBALS[strAproveAll]</b></font></a></TD></TR>";
}
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD align='center' height=20 colspan=2><a href='list.php{$GlobalArg}' target=_top><font size=1><b>$GLOBALS[strGoToTheList]</b></font></a></TD></TR>"; 
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
};

if ($_GET['op'] == "loans")	{
echo "</b><br><b>$strLoanedMovies</b><br><br>\n";
echo "<TABLE border=0 cellpadding=0 cellspacing=0>\n";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strCurrentlyLoggedInAs]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><font size=1><b>$ActiveUser[name]</b></font></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strAreas]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_requests' target=_top><font size=1><b>$GLOBALS[strViewRequests]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_borrowed' target=_top><font size=1><b>$GLOBALS[strborrowed]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=my_reserve_basket' target=_top><font size=1><b>$GLOBALS[strSeeCart]</b></font></a></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strLoanControl]</b></font></TD></TR>";

$strSql = "SELECT " . $CFG['Prefix'] . "loanstatus.* FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "loanstatus," . $CFG['Prefix'] . "lists WHERE " . $CFG['Prefix'] . "movies.ID=" . $CFG['Prefix'] . "loanstatus.MovieID AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=$ActiveUser[ID] AND status=3 ORDER BY date";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);
if ($num==""){
echo "<TR><TD align='center' height=20 colspan=2><font size=2>$strNoneLoaned</font></TD></TR>";}else{
	
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=clear_loans' target=_top><font size=1><b>$GLOBALS[strClearLoans]</b></font></a></TD></TR>";
}
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD align='center' height=20 colspan=2><a href='list.php{$GlobalArg}' target=_top><font size=1><b>$GLOBALS[strGoToTheList]</b></font></a></TD></TR>"; 
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
};

if ($_GET['op'] == "borrowed")	{
echo "</b><br><b>$strborrowed</b><br><br>\n";
echo "<TABLE border=0 cellpadding=0 cellspacing=0>\n";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strCurrentlyLoggedInAs]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><font size=1><b>$ActiveUser[name]</b></font></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD bgcolor='#FFFFFF' align='center' height=20 colspan=2><font size=2 color='#314477'><b>$GLOBALS[strAreas]</b></font></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_requests' target=_top><font size=1><b>$GLOBALS[strViewRequests]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=view_loans' target=_top><font size=1><b>$GLOBALS[strViewLoans]</b></font></a></TD></TR>";
echo "<TR><TD align='center' height=20 colspan=2><a href='loan.php{$GlobalArg}&op=my_reserve_basket' target=_top><font size=1><b>$GLOBALS[strSeeCart]</b></font></a></TD></TR>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
echo "<TR><TD align='center' height=20 colspan=2><a href='list.php{$GlobalArg}' target=_top><font size=1><b>$GLOBALS[strGoToTheList]</b></font></a></TD></TR>"; 
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>&nbsp;</td></tr>";
};

echo "</TABLE>\n";
?><p align="left"><font size="1">
<a href="http://www.powermovielist.com" target="_blank">PowerMovieList</a> <?php echo $Version ?><br>
 Copyright &copy; by Nikotto<br>
  </font></p>
</body>
</html><?php
?>