<?php
/** powermovielist loansystem
 * $Id: loan.php,v 1.11 2005/10/02 09:13:59 niko Exp $
*/

$FILE_SELF = "loan.php";

include("application.php");

include("loaningcart.php"); 
$cart = new Cart; 

if(isset($_GET['MovieID'])) $MovieID = $_GET['MovieID']; else $MovieID = "0";
if(isset($_GET['UserID'])) $UserID = $_GET['UserID']; else $UserID = "";
$date =date("Y-m-d");

if ($_GET['op'] == "add_to_cart") {
if ($MovieID==0) { echo "Error - No MovieID"; exit; }
	$status='1';
	$cart->add_to_cart($ActiveUser['ID'], $MovieID, $status, $date);
	echo"<META http-equiv=refresh content=\"0; URL=list.php{$GlobalArg}\">"
 ."";
}

if ($_GET['op'] == "reserve_all")	{
include("top.html");
	$status='2';
	SendMailRequest($ActiveUser['ID']);
	$cart->reserve_all($ActiveUser['ID'], $status);	
echo" 	<BR>
	<a href='list.php".$GlobalArg."' target=_top><B>$strReturnMovielist</B></a>  
	<BR>	
	<a href='loan.php".$GlobalArg."&op=my_reserve_basket' target=_top><B>$strReturnLoanCart</B></a> 
	<BR>
";
}

if ($_GET['op'] == "approve_all")	{
include("top.html");
	$status='3';
	SendMailLoan($ActiveUser['ID'], loanapproved, $UserID);
	$cart->approve_all($ActiveUser['ID'], $status);	
echo" 	<BR>
	<a href='list.php".$GlobalArg."' target=_top><B>$strReturnMovielist</B></a>  
	<BR>	
	<a href='loan.php".$GlobalArg."&op=view_requests' target=_top><B>$strReturnLoanRequest</B></a> 
	<BR>
";
}

if ($_GET['op'] == "reserve_item")	{
include("top.html");
	$status='2';
	SendMailRequest($ActiveUser['ID']);
	$cart->modify_status($ActiveUser['ID'], $MovieID, $status);	
echo" 	<BR>
	<a href='list.php".$GlobalArg."' target=_top><B>$strReturnMovielist</B></a>  
	<BR>	
	<a href='loan.php".$GlobalArg."&op=my_reserve_basket' target=_top><B>$strReturnLoanCart</B></a> 
	<BR>
";
}

if ($_GET['op'] == "approve_item")	{
include("top.html");
	$status='3';
	SendMailLoan($ActiveUser['ID'], loanapproved, $UserID);
	$cart->modify_status($UserID, $MovieID ,$status);	
echo" 	<BR>
	<a href='list.php".$GlobalArg."' target=_top><B>$strReturnMovielist</B></a>  
	<BR>	
	<a href='loan.php".$GlobalArg."&op=view_requests' target=_top><B>$strReturnLoanRequest</B></a> 
	<BR>
";
}

if ($_GET['op'] == "my_reserve_basket")	{
			$cart->display_cart($ActiveUser['ID']);
			?>
			<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
			<html>
			<head>
			<TITLE><?php echo $strLoanTitle?></TITLE>
<LINK REL="shortcut icon" HREF="image/divx.ico">
<meta http-equiv="Content-Type" content="text/html<?
if(isset($LngCharSet)) echo "; charset=$LngCharSet";
?>">
</HEAD>
<frameset cols="199,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
  <frame name="menu" scrolling="auto" noresize src="loanmenu.php<?php echo $GlobalArg ?>&op=cart">
  <frame name="main" scrolling="auto" noresize src="loanview.php<?php echo $GlobalArg ?>&op=cart">
</frameset>
<noframes><BODY>your browser doesn't support frames... wtf</body></noframes>
</HTML>
<?php
}

if ($_GET['op'] == "view_requests")	{
			$cart->display_cart($ActiveUser['ID']);
			?>
			<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
			<html>
			<head>
			<TITLE><?php echo $strLoanTitle?></TITLE>
<LINK REL="shortcut icon" HREF="image/divx.ico">
<meta http-equiv="Content-Type" content="text/html<?
if(isset($LngCharSet)) echo "; charset=$LngCharSet";
?>">
</HEAD>
<frameset cols="190,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
  <frame name="menu" scrolling="auto" noresize src="loanmenu.php<?php echo $GlobalArg ?>&op=request">
  <frame name="main" scrolling="auto" noresize src="loanview.php<?php echo $GlobalArg ?>&op=request">
</frameset>
<noframes><BODY>your browser doesn't support frames... wtf</body></noframes>
</HTML>
<?php
}

if ($_GET['op'] == "view_loans")	{
			$cart->display_cart($ActiveUser['ID']);
			?>
			<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
			<html>
			<head>
			<TITLE><?php echo $strLoanTitle?></TITLE>
<LINK REL="shortcut icon" HREF="image/divx.ico">
<meta http-equiv="Content-Type" content="text/html<?
if(isset($LngCharSet)) echo "; charset=$LngCharSet";
?>">
</HEAD>
<frameset cols="190,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
  <frame name="menu" scrolling="auto" noresize src="loanmenu.php<?php echo $GlobalArg ?>&op=loans">
  <frame name="main" scrolling="auto" noresize src="loanview.php<?php echo $GlobalArg ?>&op=loans">
</frameset>
<noframes><BODY>your browser doesn't support frames... wtf</body></noframes>
</HTML>
<?php
}

if ($_GET['op'] == "view_borrowed")	{
			?>
			<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
			<html>
			<head>
			<TITLE><?php echo $strLoanTitle?></TITLE>
<LINK REL="shortcut icon" HREF="image/divx.ico">
<meta http-equiv="Content-Type" content="text/html<?
if(isset($LngCharSet)) echo "; charset=$LngCharSet";
?>">
</HEAD>
<frameset cols="190,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
  <frame name="menu" scrolling="auto" noresize src="loanmenu.php<?php echo $GlobalArg ?>&op=borrowed">
  <frame name="main" scrolling="auto" noresize src="loanview.php<?php echo $GlobalArg ?>&op=borrowed">
</frameset>
<noframes><BODY>your browser doesn't support frames... wtf</body></noframes>
</HTML>
<?php
}

if ($_GET['op'] == "empty_my_cart")	{
	$status='1';
	$cart->delete_all($ActiveUser['ID'],$status);
	echo"<META http-equiv=refresh content=\"0; URL=list.php{$GlobalArg}\">"
 ."";
}	

if ($_GET['op'] == "delete_cart")	{
	$status='1';
	$cart->delete_item($ActiveUser['ID'],$MovieID,$status);
	echo"<META http-equiv=refresh content=\"0; URL=loan.php{$GlobalArg}&op=my_reserve_basket\">"
 ."";
}	

if ($_GET['op'] == "clear_requests")	{
	$status='2';
	SendMailLoan($ActiveUser['ID'], loanrefused, $UserID);
	$cart->delete_all2($ActiveUser['ID'],$status);
	echo"<META http-equiv=refresh content=\"0; URL=loan.php{$GlobalArg}&op=view_requests\">"
 ."";
}	

if ($_GET['op'] == "clear_loans")	{
	$status='3';
	$cart->delete_all2($ActiveUser['ID'],$status);
	echo"<META http-equiv=refresh content=\"0; URL=loan.php{$GlobalArg}&op=view_loans\">"
 ."";
}

if ($_GET['op'] == "delete_request")	{
	$status='2';
	SendMailLoan($ActiveUser['ID'], loanrefused, $UserID);
	$cart->delete_item($UserID,$MovieID,$status);
	echo"<META http-equiv=refresh content=\"0; URL=loan.php{$GlobalArg}&op=view_requests\">"
 ."";
}	

if ($_GET['op'] == "delete_loan")	{
	$status='3';
	$cart->delete_item($UserID,$MovieID,$status);
	echo"<META http-equiv=refresh content=\"0; URL=loan.php{$GlobalArg}&op=view_loans\">"
 ."";
}

if ($_GET['op'] == "DurationRequest")	{
	if (is_numeric($_POST['Duration'])){
			$cart->duration($_POST['Duration'], $MovieID, $ActiveUser['ID']);
			echo"<META http-equiv=refresh content=\"0; URL=loanview.php{$GlobalArg}&op=cart\">"
 ."";
} else {
	print "That is not a number!  Only numbers will work for the duration";
	echo "<br><A HREF=\"loanview.php{$GlobalArg}&op=cart\">$strReturnClick</A>"
 ."";
}
}

if ($_GET['op'] == "DurationApprove")	{
	if (is_numeric($_POST['Duration'])){
			$cart->duration($_POST['Duration'], $MovieID, $ActiveUser['ID']);
			echo"<META http-equiv=refresh content=\"0; URL=loanview.php{$GlobalArg}&op=request\">"
 ."";
} else {
	print "That is not a number!  Only numbers will work for the duration";
	echo "<br><A HREF=\"loanview.php{$GlobalArg}&op=request\">$strReturnClick</A>"
 ."";
}
}

if ($_GET['op'] == "Commentscart")	{
	$cart->comments($_POST['Comments'], $MovieID, $ActiveUser['ID']);
	echo"<META http-equiv=refresh content=\"0; URL=loanview.php{$GlobalArg}&op=cart\">"
 ."";
}

if ($_GET['op'] == "Commentsrequests")	{
	$cart->comments($_POST['Comments'], $MovieID, $ActiveUser['ID']);
	echo"<META http-equiv=refresh content=\"0; URL=loanview.php{$GlobalArg}&op=request\">"
 ."";
}

if ($_GET['op'] == "Commentsloans")	{
	$cart->comments($_POST['Comments'], $MovieID, $ActiveUser['ID']);
	echo"<META http-equiv=refresh content=\"0; URL=loanview.php{$GlobalArg}&op=loans\">"
 ."";
}
?>