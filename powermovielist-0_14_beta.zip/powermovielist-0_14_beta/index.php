<?php
/** powermovielist index-page display
 * $Id: index.php,v 1.31 2006/01/21 13:44:07 niko Exp $
*/

$FILE_SELF = "index.php";
$LoadSmarty = true;
include_once("application.php");

if($Active!="index") {
	//Header("Location: list.php$GlobalArg");
	//echo "the list moved to list.php...";
    include("list.php");
	exit;
}

$sDisplay['Page'] = 1;
if(isset($_GET['Page'])) {
    $sDisplay['Page'] = (int)$_GET['Page'];
}

if($sDisplay['Page']==1 || $ActiveList['IndexType']==0) {
    $smarty->cache_lifetime = $CFG['CacheLifetimeIndex']; //15 minutes
} else {
    $smarty->cache_lifetime = 24*60*60; //one day
}

$TplFile = $ActiveList['listtpl'];

if($TplFile=="") {
	$TplFile="index.tpl"; //default template file for index-page
}
$TplFile = "index/$TplFile";

if(!FileExists("templates/".$TplFile))
	$TplFile="index/index.tpl";

$CacheId = "list|index|$sDisplay[Page]";

$ListData = array();

//if favourite lists are used we ned a non-caching-block:
$smarty->register_block("NoCache", "function_NoCache", false); //not cached

//and for this none-caching-block we need some variables:
$smarty->assign("ActiveList",$ActiveList);
$smarty->assign("ActiveUser",$ActiveUser);
$smarty->assign("CFG",array("LinkListType"=>$CFG['LinkListType'], "ListType"=>$CFG['ListType'], "GlobalArg"=>$GlobalArg, "GlobalArgWOActive"=>$GlobalArgWOActive, "UseStatistics"=>$CFG['UseStatistics'], "UseDloadLog"=>$CFG['UseDloadLog']));
$smarty->assign("lang",      array("strManagefavorites"      => $strManagefavorites,
                                  "strAddActiveList"         => $strAddActiveList,
                                  "strYourFavLists"          => $strYourFavLists,
                                  "strGoToList"              => $strGoToList));

if(!$smarty->is_cached($TplFile,$CacheId)) {
	$Data = array();

	//select movies
    switch($ActiveList['IndexType']) {
        case 0: //the newest xx Entries
            $limitStart = ($sDisplay['Page']-1)*$ActiveList['StdPerPage'];
            $strSql = "SELECT $CFG[Prefix]movies.*,
            $CFG[Prefix]lists.Name AS ListName, $CFG[Prefix]lists.title AS ListTitle
            FROM $CFG[Prefix]movies
			LEFT JOIN $CFG[Prefix]lists ON $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID
            WHERE $CFG[Prefix]lists.ShowOnIndex='1'
            ORDER BY $CFG[Prefix]movies.DateAdded DESC
            LIMIT $limitStart,".$ActiveList['StdPerPage'];
        	break;
        case 1: //entries from the last xx days
            
            $strSql = "SELECT $CFG[Prefix]movies.*,
            $CFG[Prefix]lists.Name AS ListName, $CFG[Prefix]lists.title AS ListTitle
            FROM $CFG[Prefix]movies
			LEFT JOIN $CFG[Prefix]lists ON $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID
            WHERE $CFG[Prefix]lists.ShowOnIndex='1'\n";
            if($sDisplay['Page']==1) {
                $strSql .= "AND $CFG[Prefix]movies.DateAdded > '".date("Y-m-d", strtotime('-'.($ActiveList['StdPerPage']-1).' day'))." 00:00:00'\n";
            } else {
                $d = date("Y-m-d", strtotime("-".($sDisplay['Page']+1)." day"));
                $start = "$d 00:00:00";
                $end = "$d 23:59:59";
                $strSql .= "AND $CFG[Prefix]movies.DateAdded BETWEEN '$start' AND '$end'\n";
            }
            $strSql .= "ORDER BY $CFG[Prefix]movies.DateAdded DESC";
        	break;
        case 2: //entries from the last xx days ordered by list
            $strSql = "SELECT $CFG[Prefix]movies.*,
            $CFG[Prefix]lists.Name AS ListName, $CFG[Prefix]lists.title AS ListTitle
            FROM $CFG[Prefix]movies
			LEFT JOIN $CFG[Prefix]lists ON $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID
            WHERE $CFG[Prefix]lists.ShowOnIndex='1'\n";
            if($sDisplay['Page']==1) {
                $strSql .= "AND $CFG[Prefix]movies.DateAdded > '".date("Y-m-d", strtotime('-'.($ActiveList['StdPerPage']-1).' day'))." 00:00:00'\n";
            } else {
                $d = date("Y-m-d", strtotime("-".($sDisplay['Page']+1)." day"));
                $start = "$d 00:00:00";
                $end = "$d 23:59:59";
                $strSql .= "AND $CFG[Prefix]movies.DateAdded BETWEEN '$start' AND '$end'\n";
            }
            $strSql .= "ORDER BY DATE_FORMAT($CFG[Prefix]movies.DateAdded,'%Y%m%d') DESC, $CFG[Prefix]lists.name, $CFG[Prefix]movies.DateAdded DESC";
        	break;
        case 3: //entries from the last xx days ordered by linklist
            $strSql = "SELECT $CFG[Prefix]movies.*,
            $CFG[Prefix]lists.Name AS ListName, $CFG[Prefix]lists.title AS ListTitle
            FROM $CFG[Prefix]movies
			LEFT JOIN $CFG[Prefix]lists ON $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID
			LEFT JOIN $CFG[Prefix]linklist ON $CFG[Prefix]linklist.ListID=$CFG[Prefix]lists.ID
            WHERE $CFG[Prefix]lists.ShowOnIndex='1'\n";
            if($sDisplay['Page']==1) {
                $strSql .= "AND $CFG[Prefix]movies.DateAdded > '".date("Y-m-d", strtotime('-'.($ActiveList['StdPerPage']-1).' day'))." 00:00:00'\n";
            } else {
                $d = date("Y-m-d", strtotime("-".($sDisplay['Page']+1)." day"));
                $start = "$d 00:00:00";
                $end = "$d 23:59:59";
                $strSql .= "AND $CFG[Prefix]movies.DateAdded BETWEEN '$start' AND '$end'\n";
            }
            $strSql .= "ORDER BY DATE_FORMAT($CFG[Prefix]movies.DateAdded,'%Y%m%d') DESC, $CFG[Prefix]linklist.SortOrder, $CFG[Prefix]movies.DateAdded DESC";
        	break;
    }
    
    $DataList = array();
	$result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$Data[$row['ID']] = $row;
        $DataList[$row['ListID']][] = $row['ID'];
	}

    $strSql = "SELECT Name, ListHeader, LoadOnly, DisplayOptions FROM $CFG[Prefix]indexitems ORDER BY SortOrder";
	$result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $indexItems = $indexItemNames = array();
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$indexItems[] = $row;
        $indexItemNames[] = $row['Name'];
	}
    
    $smarty->assign("IndexItems", $indexItems);

    $strSql = "CREATE TEMPORARY TABLE temp_index (MovieID BIGINT";
    foreach($indexItems as $indexItem)
    {
        if(in_array($indexItem, array("TimeAdded", "DateAdded", "MovieID", "ListID", "ListName", "UserComments")))
            continue;
    
        $strSql .= ", $indexItem[Name] TEXT";
    }
    $strSql .= ")";
    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    
    $strSql = "SELECT ID, ListID, Name, PropType, RequiredRights FROM $CFG[Prefix]prop WHERE ListID IN ('".implode("', '", array_keys($DataList))."')";
    $result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $Props = array();
	$PropTypes = array();
    while ($prop = mysql_fetch_array($result, MYSQL_ASSOC))
	{
        $Props[$prop['ListID']][$prop['ID']] = $prop;
		if(in_array($prop['Name'], $indexItemNames) && !isset($PropTypes[$prop['Name']]))
		{
			$PropTypes[$prop['Name']] = $prop;
		}

    }

    foreach($DataList as $ListID=>$MovieIDs)
    {
        $sql = array();
        $sql['from'] = array("$CFG[Prefix]movies_".strtolower($Data[$MovieIDs[0]]['ListName'])." AS movies");
        $strSql = "INSERT INTO temp_index (MovieID, ";
        $sql['select'][] = "movies.MovieID";
        foreach($Props[$ListID] as $PropID=>$prop)
        {
            if($prop['RequiredRights'] > PML_Rights_View) continue; //only when view-rights exist
            if($prop['RequiredRights'] == -1) continue; //only to logged-in-users - continue
            
            if(in_array($prop['Name'], array("TimeAdded", "DateAdded", "MovieID", "ListID", "ListName", "UserComments")))
                continue;
                
            if(in_array($prop['Name'], $indexItemNames))
            {
				$indexItem = $indexItems[array_search($prop['Name'], $indexItemNames)];
				if($prop['PropType']>100) {
					$pSql = call_user_func($CFG['CustomPropTypes'][$prop['PropType']]['sqlFunc'], $prop, "sql");
					$sql['select'][] = $pSql['select'];
					unset($pSql['select']);
					foreach($pSql as $k=>$i) {
						$sql[$k] = array_merge($sql[$k], $i);
					}
                    $strSql .= $prop['Name'].", ";
					continue;
				}
                switch($prop['PropType']) {
                    case PML_PropType_Text:
                    case PML_PropType_Textfield:
                    case PML_PropType_Url:
                    case PML_PropType_UrlCached:
                    case PML_PropType_FileUpload:
                    case PML_PropType_UserRating:
                    case PML_PropType_AutoIncrement:
                        $sql['select'][] = "movies.".$prop['Name'];
                        $strSql .= $prop['Name'].", ";
                        break;
                    case PML_PropType_Date:
                        $sql['select'][] = "DATE_FORMAT(movies.`$prop[Name]`,'$GLOBALS[strDefaultDateFormat]')";
                        $strSql .= $prop['Name'].", ";
                        break;
                    case PML_PropType_Boolean:
                    case PML_PropType_ListBox:
						if($indexItem['DisplayOptions']=='short') {
	                        $sql['select'][] = "propval$prop[Name].DisplayTextShort";
						} else if($indexItem['DisplayOptions']=='html') {
	                        $sql['select'][] = "propval$prop[Name].DisplayTextHtml";
						} else {
	                        $sql['select'][] = "propval$prop[Name].DisplayText";
						}
                        $sql['left join']["$CFG[Prefix]propval AS propval".$prop['Name']] = "propval$prop[Name].ID = movies.`$prop[Name]` AND propval$prop[Name].PropID = $prop[ID]";
                        $strSql .= $prop['Name'].", ";
                        break;
                    case PML_PropType_ListBoxMulti:
                        $sql['select'][] = "movies.".$prop['Name'];
                        $strSql .= $prop['Name'].", ";
                        break;
                    case PML_PropType_DownloadLink:
                    case PML_PropType_DownloadLinkFileUpload:
                        //won't be used on index-page
                        break;
                    case PML_PropType_StaticText:
                        $sql['select'][] = "'$prop[InTitle]'";
                        $strSql .= $prop['Name'].", ";                        
                        break;
                    case PML_PropType_DisplayNr:
                        //won't be used on index-page
                        break;
                    default:
                        trigger_error("Unknown PropType", E_USER_ERROR);
                        break;
                }
            }
        }
        $strSql = substr($strSql, 0, -2);
        $strSql .= ") ";
        if($ActiveList['IndexType']==0) { //the newest xx Entries
            $sql['where'][] = "MovieID IN ('".implode("', '", $MovieIDs)."')";
        } else { //the last xx days
            if($sDisplay['Page']==1) {
                $sql['where'][] = "DateAdded > '".date("Y-m-d", strtotime('-'.($ActiveList['StdPerPage']-1).' day'))." 00:00:00'";
            } else {
                $d = date("Y-m-d", strtotime("-".($sDisplay['Page']+1)." day"));
                $start = "$d 00:00:00";
                $end = "$d 23:59:59";
                $sql['where'][] = "DateAdded BETWEEN '$start' AND '$end'";
            }
        }

        $strSql .= buildSqlString($sql);
        
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    }
    
    $strSql = "SELECT * FROM temp_index";
    $result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $MovieID = $row['MovieID'];
        $Data[$row['MovieID']] = array_merge($row, $Data[$row['MovieID']]);
        $Data[$row['MovieID']]['TimeAdded'] = substr($Data[$row['MovieID']]['DateAdded'], 11, 8);
        $Data[$row['MovieID']]['DateAdded'] = substr($Data[$row['MovieID']]['DateAdded'], 0, 10);

        //load User-Comments if needed
        if(in_array("UserComments", $indexItemNames)) {
            $strSql = "SELECT $CFG[Prefix]comment.Text, $CFG[Prefix]users.name
            FROM $CFG[Prefix]comment, $CFG[Prefix]users
            WHERE $CFG[Prefix]comment.MovieID=$MovieID
            AND $CFG[Prefix]comment.UserID=$CFG[Prefix]users.ID";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $Data[$MovieID]['UserComments'] = "";
            while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
                $Data[$MovieID]['UserComments'] .= "<b>by $row[name]:</b><br>\n$row[Text]<br>\n";
            }
        }
    }

	foreach($PropTypes as $propName=>$prop)
	{
		if($prop['PropType']==PML_PropType_ListBoxMulti) {
			$strSql2 = "SELECT ID, ";
			$strSql2 .= "IF(propval.DisplayTextHtml='', propval.DisplayTextShort, propval.DisplayTextHtml)";
			$strSql2 .= " FROM $CFG[Prefix]propval AS propval
						 WHERE PropID='$prop[ID]'";
			$query = pml_mysql_unbuffered_query($strSql2, $pmldb) or trigger_error("can't execute:<pre>$strSql2</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			while($row=mysql_fetch_row($query)) {
				$multiSelectPropVals[$prop['ID']][$row[0]] = $row[1];
			}
					
		}
	}

	foreach($Data as $MovieID=>$row)
	{
		foreach($PropTypes as $propName=>$prop)
		{
			if($prop['PropType']==PML_PropType_UrlCached)
			{
				//get the local-filename:
				//it is either the filename of the url
				//or when http://www.xxx.com/xxx.xxx.PML_PropertyDelem.localfilename.jpg  the added name
				$ret = GetFileNameDelem($Data[$MovieID][$propName], false); //false=be silent

				if(!@FileExists($CFG['CacheDir'].$MovieID."-".$prop['ID']."-".$ret)) { //check if url is allready cached
					if($ret=="" || !DownloadFile($Data[$MovieID][$propName], $CFG['CacheDir'].$MovieID."-".$prop['ID']."-".$ret)) {//if not download url again
						//download failed, use standard-value                    
						$stdValue = GetStandardValue($prop);
						$ret = GetFileName($stdValue); //error, return default-value
						if($ret!="" && !@FileExists($CFG['CacheDir']."0-".$prop['ID']."-".$ret)) {  //check if url is allready cached                    
							if(!DownloadFile($stdValue, $CFG['CacheDir']."0-".$prop['ID']."-".$ret)) { //download it again
								$ret = ""; //if download failed, return ""
							} else {
								resizeImage($CFG['CacheDir']."0-".$prop['ID']."-".$ret, $prop['ImageSize']);
							}
						}
						if($ret!="") { //if ret not empty return standard-value with movieid and propid                            
							$ret = $CFG['CacheDirHttp']."0-".$prop['ID']."-".$ret;
						}
					} else {
						resizeImage($CFG['CacheDir'].$MovieID."-".$prop['ID']."-".$ret, $prop['ImageSize']);
						//downloaded sucessfully, return now the url
						$ret = $CFG['CacheDirHttp'].$MovieID."-".$prop['ID']."-".$ret;
					}
				} else { 
					//file exists, use it
					$ret = $CFG['CacheDirHttp'].$MovieID."-".$prop['ID']."-".$ret;
				}

				$Data[$MovieID][$propName] = $ret;
			}
			elseif($prop['PropType']==PML_PropType_FileUpload)
			{
				if($DisplayText=="export") continue;

				$ret = $Data[$MovieID][$propName];
				if($ret!="" && !@FileExists($CFG['UploadDir'].$MovieID."-".$prop['ID']."-".$ret)) {
					//try getting the filename (if url...)
					$ret = GetFileName($ret,false);
					if($ret!="") {
						if(!@FileExists($CFG['UploadDir'].$MovieID."-".$prop['ID']."-".$ret)) {
							if(!DownloadFile($Movie[$PropID], $CFG['UploadDir'].$MovieID."-".$prop['ID']."-".$ret)) {//if not download url again						
								$ret = ""; //doesn't exist either...
							}
						}
					}
				}
				if($ret=="") {
					$ret = GetStandardValue($prop);
					$MovieID=0;
					if(!@FileExists($CFG['UploadDir'].$MovieID."-".$prop['ID']."-".$ret))
						$ret = "";
				}
				if($ret!="")
					$ret = $CFG['UploadDirHttp'].$MovieID."-".$prop['ID']."-".$ret;			

				$Data[$MovieID][$propName] = $ret;
			}
			elseif($prop['PropType']==PML_PropType_DownloadLinkFileUpload)
			{
				if($DisplayText=="export") continue;

				$ret = $CFG['UploadDir'].$MovieID."-".$prop['ID']."-".$Data[$MovieID][$propName."_link"];
                if(!@FileExists($ret)) {
                    $ret = "";
                }                
                $Data[$MovieID][$propName."_link"] = $ret;
                
			}
			elseif($prop['PropType']==PML_PropType_ListBoxMulti)
			{
				$PropVals = $multiSelectPropVals[$prop['ID']];
				$dat = substr($Data[$MovieID][$propName], 1, -1);
				$dat = explode("_", $dat);
				$Data[$MovieID][$propName] = "";
				foreach($dat as $PropValID) {
					if(isset($PropVals[$PropValID])) {
						$Data[$MovieID][$propName] .= $PropVals[$PropValID] . ", ";
					}
				}
				$Data[$MovieID][$propName] = substr($Data[$MovieID][$propName], 0, -2);
			}
		}
	}

    $smarty->assign("MovieData", $Data);
    $smarty->assign("PageNr", $sDisplay['Page']);

    if($sDisplay['Page'] > 1)
    {
        $smarty->assign("LastPageNr", $sDisplay['Page']-1);
        if($ActiveList['IndexType']!=0) {
            if($sDisplay['Page']==2) {
                $smarty->assign("LastPageDate", strtotime("-".($sDisplay['Page']-$ActiveList['StdPerPage']+1)." day"));
            } else {
                $smarty->assign("LastPageDate", strtotime("-".($sDisplay['Page'])." day"));
            }
        }
    }
    else
    {
        $smarty->assign("LastPageNr", 0);
    }

    if($ActiveList['IndexType']!=0) {
	    $smarty->assign("NextPageNr", $sDisplay['Page']+1);
	} else {
            $limitStart = ($sDisplay['Page']-1)*$ActiveList['StdPerPage'];
            $strSql = "SELECT COUNT($CFG[Prefix]movies.ID) FROM $CFG[Prefix]movies, $CFG[Prefix]lists
						WHERE $CFG[Prefix]movies.ListID=$CFG[Prefix]lists.ID
						AND $CFG[Prefix]lists.ShowOnIndex='1'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_row($result);
			if($row[0] > $sDisplay['Page']*$ActiveList['StdPerPage']) {
				$smarty->assign("NextPageNr", $sDisplay['Page']+1);
			}
	}


    if($ActiveList['IndexType']!=0) {
        $smarty->assign("NextPageDate", strtotime("-".($sDisplay['Page']+$ActiveList['StdPerPage']-1)." day"));
    }

	$smarty->assign("lang", array("LngCharSet"           => $LngCharSet,
		                          "strCounterTitle"      => $strCounterTitle,
                                  "strMenu"              => $strMenu,
                                  "strAvLists"           => $strAvLists,
                                  "strStatistics"        => $strStatistics,
                                  "strActiveList"        => $strActiveList,
                                  "strLoggedIn"          => $strLoggedIn,
                                  "strCounterTitle"      => $strCounterTitle,
                                  "strRights"            => $strRights,
                                  "strOnline"            => $strOnline,
                                  "strCounterOnlineNow"  => $strCounterOnlineNow,
                                  "strCounterRekord"     => $strCounterRekord,
                                  "strGuests"            => $strGuests,
                                  "strEntriesInAllLists" => $strEntriesInAllLists,
                                  "strAddedToday"        => $strAddedToday,
                                  "strAddedYesterday"    => $strAddedYesterday,
                                  "strSizeOfAllLinks"    => $strSizeOfAllLinks,
                                  "strDownloaded"        => $strDownloaded,
                                  "strUsers"             => $strUsers,
                                  "strLists"             => $strLists,
                                  "strNewEntries"        => $strNewEntries,
                                  "strGoToTheList"          => $strGoToTheList,
                                  "strInfo"              => $strInfo,
                                  "strPlot"              => $strPlot,
                                  "strCounterOnlineNow"  => $strCounterOnlineNow,
                                  "strManagefavorites"      => $strManagefavorites,
                                  "strAddActiveList"         => $strAddActiveList,
                                  "strYourFavLists"          => $strYourFavLists,
                                  "strGoToList"              => $strGoToList,
		                          "strNextPage"           => $strNextPage,
		                          "strPrevPage"           => $strPrevPage
                                    ));
    if($CFG['UseStatistics']) {
        //load statistics:
        $smarty->assign("Statistics",LoadStatistics());
    }

    if($CFG['LinkListType']==PML_LinkListType_Select) {
        $strSql = "SELECT " . $CFG['Prefix'] . "linklist.Type, " . $CFG['Prefix'] . "linklist.Url, " . $CFG['Prefix'] . "linklist.Text, LOWER(" . $CFG['Prefix'] . "lists.name) AS name FROM " . $CFG['Prefix'] . "linklist LEFT JOIN " . $CFG['Prefix'] . "lists ON (" . $CFG['Prefix'] . "linklist.ListID=" . $CFG['Prefix'] . "lists.ID) ORDER BY SortOrder";
        $result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);      
        while($row = mysql_fetch_assoc($result)) {
            $LinkListData[] = $row;
        }
        $smarty->assign("LinkListData",$LinkListData);
    }

    $smarty->assign("Announcments",GetAnnouncments());

}

if($CFG['LinkListType']==PML_LinkListType_Fav || $CFG['LinkListType']==PML_LinkListType_FavText) {
    $strSql = "SELECT l.title, l.name FROM $CFG[Prefix]fav f, $CFG[Prefix]lists l WHERE f.UserID='$ActiveUser[ID]' AND f.ListID=l.ID ORDER BY f.SortOrder";
    $query = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $FavLists=array();
    $ActiveListInFav=false;
    while($row=mysql_fetch_assoc($query)) {
        $FavLists[$row['name']]=$row['title'];
        if($row['name']==$ActiveList['name']) $ActiveListInFav=true;
    }    
    $smarty->assign("FavLists", $FavLists);
    $smarty->assign("ActiveListInFav", $ActiveListInFav);    
}

$smarty->display($TplFile,$CacheId);


include("bottom.html");

?>