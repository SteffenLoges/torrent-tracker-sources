<? 
/** powermovielist loansystem cart
 * $Id: loaningcart.php,v 1.17 2005/09/22 18:32:07 niko Exp $
*/
global $CFG, $pmldb;

    class Cart { 
        function check_item($UserID, $MovieID, $status) { 
            global $CFG, $pmldb;
        	$strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND MovieID=$MovieID AND status=$status "; 
            $result = pml_mysql_query($strSql,$pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
             
            if(!$result) { 
                return 0; 
            } 

            $numRows = mysql_num_rows($result); 

            if($numRows == 0) { 
                return 0; 
            } else { 
                $row = mysql_fetch_object($result); 
                return $row->status; 
            } 
        }
         

        function add_item($UserID, $MovieID, $status, $date) { 
            global $CFG, $pmldb;
        	$qty = $this->check_item($UserID, $MovieID, $status); 
            if($qty == 0) { 
                $strSql = "INSERT INTO $CFG[Prefix]loanstatus (UserID, MovieID, status, date) VALUES "; 
                $strSql .= "('$UserID', '$MovieID', '$status', '$date') "; 
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            } else {
            	$strSql = "UPDATE $CFG[Prefix]loanstatus SET status=$status AND date=$date WHERE UserID=$UserID AND MovieID=$MovieID ";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            }
        }

        function add_to_cart($UserID, $MovieID, $status, $date) { 
            global $CFG, $pmldb;
        	$qty = $this->check_item($UserID, $MovieID, $status); 
            if($qty == 0) { 
                $strSql = "INSERT INTO $CFG[Prefix]loanstatus (UserID, MovieID, status, date) VALUES "; 
                $strSql .= "('$UserID', '$MovieID', '$status', '$date') "; 
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            }
        }
        
        function delete_item($UserID, $MovieID, $status) { 
            global $CFG, $pmldb;
        	$strSql = "DELETE FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND MovieID=$MovieID AND status=$status "; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }


        function delete_all($UserID, $status) { 
            global $CFG, $pmldb;
        	$strSql = "DELETE FROM $CFG[Prefix]loanstatus WHERE status=$status AND UserID=$UserID "; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }

        function delete_all2($UserID, $status) { 
            global $CFG, $pmldb;
            $strSql = "DELETE FROM " . $CFG['Prefix'] . "loanstatus USING " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "loanstatus," . $CFG['Prefix'] . "lists WHERE " . $CFG['Prefix'] . "movies.ID=" . $CFG['Prefix'] . "loanstatus.MovieID AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=$UserID AND status=$status";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }
        
        
        function modify_status($UserID, $MovieID, $status) { 
            global $CFG, $pmldb;
        	$strSql = "UPDATE $CFG[Prefix]loanstatus SET status=$status WHERE UserID=$UserID AND MovieID=$MovieID "; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }


        function reserve_all($UserID) { 
            global $CFG, $pmldb;
        	$strSql = "UPDATE $CFG[Prefix]loanstatus SET status='2' WHERE status='1' AND UserID=$UserID "; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }
        
function duration ($Duration, $MovieID, $UserID) { 
            global $CFG, $pmldb;
        	$strSql = "UPDATE $CFG[Prefix]loanstatus SET Duration=$Duration WHERE MovieID=$MovieID AND UserID=$UserID "; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }

        
		function comments ($comments, $MovieID, $UserID) { 
            global $CFG, $pmldb;
        	$strSql = "UPDATE $CFG[Prefix]loanstatus SET Comment='$comments' WHERE MovieID=$MovieID AND UserID=$UserID "; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }

       
        function approve_all($UserID) { 
            global $CFG, $pmldb;
        	$strSql = "UPDATE ".$CFG[Prefix]."loanstatus, " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "lists SET ".$CFG[Prefix]."loanstatus.status='3' WHERE ".$CFG[Prefix]."loanstatus.status='2' AND " . $CFG['Prefix'] . "movies.ID=" . $CFG['Prefix'] . "loanstatus.MovieID AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=$UserID"; 
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
        }
        
        function clear_cart($UserID,$status) { 
            global $CFG, $pmldb;
            $strSql = "DELETE FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND status=$status "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysqlerror($pmldb)."</i>",E_USER_ERROR);
        }
        
         
		function loan_total($UserID) { 
            global $CFG, $pmldb;
			$strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND status='3' "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            $num_rows = mysql_num_rows($result); 
            return $num_rows; 
        }
        
        
        function display_loans($UserID) { 
            global $CFG, $pmldb;
        	$count = 0; 
            $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND status='3' ORDER BY date "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            while($row = mysql_fetch_object($result)) { 
                $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE MovieID='$row->MovieID' "; 
                $result_inv = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
                $row_inventory = mysql_fetch_object($result_inv); 
                $contents["MovieID"][$count] = $row_inventory->MovieID; 
                $contents["UserID"][$count] = $row_inventory->UserID; 
                $contents["date"][$count] = $row->date; 
                $contents["Duration"][$count] = $row_inventory->Duration; 
                
                $count++; 
            } 
            $total = $this->loan_total($UserID); 
            $contents["final"] = $total; 
            return $contents; 
        }
        

		function request_total($UserID) { 
            global $CFG, $pmldb;
			$quant = 0; 
            $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND status='2' "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            while($row = mysql_fetch_object($result)) { 
                $quant += $row->quantity; 
            } 
            return $quant; 
        }
        
                
        function display_requests($UserID) { 
            global $CFG, $pmldb;
        	$count = 0; 
            $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE status='2' ORDER BY date "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            while($row = mysql_fetch_object($result)) { 
                $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE MovieID='$row->MovieID' "; 
                $result_inv = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
                $row_inventory = mysql_fetch_object($result_inv); 
                $contents["MovieID"][$count] = $row_inventory->MovieID; 
                $contents["UserID"][$count] = $row_inventory->UserID; 
                $contents["date"][$count] = $row->date; 
                $contents["Duration"][$count] = $row_inventory->Duration; 
                
                $count++; 
            } 
            $total = $this->request_total($UserID); 
            $contents["final"] = $total; 
            return $contents; 
        }
        

        function cart_total($UserID) { 
            global $CFG, $pmldb;
        	$strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE UserID='$UserID' "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            $num_rows = mysql_num_rows($result); 
            return $num_rows;  
        }
        
        
        function display_cart($UserID) { 
            global $CFG, $pmldb;
        	$count = 0; 
            $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE UserID=$UserID AND status='1' ORDER BY date "; 
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
            while($row = mysql_fetch_object($result)) { 
                $strSql = "SELECT * FROM $CFG[Prefix]loanstatus WHERE MovieID='$row->MovieID' "; 
                $result_inv = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR); 
                $row_inventory = mysql_fetch_object($result_inv); 
                $contents["MovieID"][$count] = $row_inventory->MovieID; 
                $contents["UserID"][$count] = $row_inventory->UserID; 
                $contents["date"][$count] = $row->date; 
                $contents["Duration"][$count] = $row_inventory->Duration; 
                
                $count++; 
            }
            $total = $this->cart_total($UserID); 
            $contents["final"] = $total; 
            return $contents; 
        }
	}
	
function SendMailLoan($UserID,$MailFileName,$RequestorID) {
global $ActiveList, $ActiveUser, $CFG, $pmldb;

	if($RequestorID=="") {
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "loanstatus WHERE status=2";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row=mysql_fetch_assoc($result);
	}else{
 		$strSql = $strSql = "SELECT * FROM " . $CFG['Prefix'] . "loanstatus WHERE UserID=$RequestorID AND status=2";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row=mysql_fetch_assoc($result);
	}

	$strSql = "SELECT email FROM " . $CFG['Prefix'] . "users WHERE ID=$row[UserID]";
	$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$requestors=mysql_fetch_assoc($result1);

	$strSql = "SELECT name FROM " . $CFG['Prefix'] . "users WHERE ID=$row[UserID]";
	$result2 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$requestor=mysql_fetch_assoc($result2);

	if(FileExists("mail/$MailFileName.$ActiveList[lang].txt"))
		$MailFileName = "mail/$MailFileName.$ActiveList[lang].txt";
	else
		$MailFileName = "mail/$MailFileName.english.txt"; //use the default-file

	$MailSubject = "Loan Request Approval/Refusal"; //default Value
	$MailData = file($MailFileName);
	foreach($MailData as $k=>$Line) {
		$MailData[$k] = trim($MailData[$k]);
		$MailData[$k] = str_replace("_USERNAME_", "$ActiveUser[name]", $MailData[$k]);
        $MailData[$k] = str_replace("_REQUESTORNAME_", "$requestor[name]", $MailData[$k]);
		if($MailData[$k]!="" && strstr($MailData[$k],"Subject: ")==$MailData[$k]) {
            $MailSubject =  str_replace("Subject: ", "", $MailData[$k]);
			unset($MailData[$k]); //delete this line
		}
	}
	echo "$strSendLoanMail<br>\n";
	if($CFG['Debug']) {
		echo "<pre>";
		echo "To: $requestors[email]\nSubject: $MailSubject\nFrom: $ActiveUser[email]\n";
		echo "\n";
		echo implode("\n", $MailData);
		echo "</pre>";
	}
	if(!mail($requestors['email'], $MailSubject, implode("\n", $MailData),"From: $ActiveUser[email]")) {
		echo "$strLoanMailFailed<br>";
		return(false);
	}else{
		echo "$strSent";
	}
	return(true);
}
	
function SendMailRequest($UserID) {
global $ActiveList, $ActiveUser, $CFG, $pmldb, $GlobalArg;
	$MailFileName = "loanrequest";
	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "loanstatus WHERE UserID=$UserID AND status=1";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row=mysql_fetch_assoc($result);

	$strSql = "SELECT users.email FROM " . $CFG['Prefix'] . "movies AS movies," . $CFG['Prefix'] . "lists AS lists," . $CFG['Prefix'] . "users AS users WHERE movies.ID=" . $row['MovieID'] . " AND movies.ListID=lists.ID AND lists.UserID=users.ID";
	$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$owners=mysql_fetch_assoc($result1);

	$strSql = "SELECT " . $CFG['Prefix'] . "users.name FROM " . $CFG['Prefix'] . "movies," . $CFG['Prefix'] . "lists," . $CFG['Prefix'] . "users WHERE " . $CFG['Prefix'] . "movies.ID=" . $row['MovieID'] . " AND " . $CFG['Prefix'] . "movies.ListID=" . $CFG['Prefix'] . "lists.ID AND " . $CFG['Prefix'] . "lists.UserID=" . $CFG['Prefix'] . "users.ID";
	$result2 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$owner=mysql_fetch_assoc($result2);

	if(FileExists("mail/$MailFileName.$ActiveList[lang].txt"))
		$MailFileName = "mail/$MailFileName.$ActiveList[lang].txt";
	else
		$MailFileName = "mail/$MailFileName.english.txt"; //use the default-file

	$MailSubject = "Loan Request"; //default Value
	$MailData = file($MailFileName);
	foreach($MailData as $k=>$Line) {
		$MailData[$k] = trim($MailData[$k]);
		$MailData[$k] = str_replace("_LOANURL_", "$CFG[HttpPath]loan.php$GlobalArg&op=view_requests&owner=$owner[name]&requestor=$UserID", $MailData[$k]);
		$MailData[$k] = str_replace("_HTTPPATH_", "$CFG[HttpPath]", $MailData[$k]);
		$MailData[$k] = str_replace("_USERNAME_", "$owner[name]", $MailData[$k]);
        $MailData[$k] = str_replace("_REQUESTORNAME_", "$ActiveUser[name]", $MailData[$k]);
		if($MailData[$k]!="" && strstr($MailData[$k],"Subject: ")==$MailData[$k]) {
            $MailSubject =  str_replace("Subject: ", "", $MailData[$k]);
			unset($MailData[$k]); //delete this line
		}
	}
	echo "$strSendLoanMail<br>\n";
	if($CFG['Debug']) {
		echo "<pre>";
		echo "To: $owners[email]\nSubject: $MailSubject\nFrom: $ActiveUser[email]\n";
		echo "\n";
		echo implode("\n", $MailData);
		echo "</pre>";
	}
	if(!mail($owners['email'], $MailSubject, implode("\n", $MailData),"From: $ActiveUser[email]")) {
		echo "$strLoanMailFailed<br>";
		return(false);
	}else{
		echo "$strSent";
	}
	return(true);
}
?>
