<?php
/** powermovielist edit FetchScripts for property
 * $Id: editpropfetch.php,v 1.5 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "editpropfetch.php";
$LoadSmarty=true;
include_once("application.php");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

$Title = "FetchScript";
$TitlePl = "FetchScripts";

$Table = $CFG['Prefix'] . "propfetch";

$Filter = "PropID";
$FilterVal = $_GET['F'];

$SortOrderField = "SortOrder";

$SessionVar = "editpropfetch";

$i=0;
$Show[$i]['name'] = "FetchScript";
$Show[$i]['type'] = "listbox";
$Show[$i]['prop'] = "";
$Show[$i]['text'] = "FetchScript";
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
$Dat = GetFetchFields();
$Show[$i]['prop'] = $Show[$i]['values'] = implode(";",$Dat);
if($action=="edit" || $action=="editsave")
	$Show[$i]['tags'] = " onChange=\"document.forms.frmEdit.action='editpropfetch.php".$GlobalArg."F=$FilterVal&action=editsave&nextaction=edit&ID=$ID'; document.forms.frmEdit.submit();\"";
$i++;
unset($Show[$i]);
//Field-Settings:
if($action=="edit" || $action=="editsave") {
	include_once("fetch/fetch.php");	
	$strSql = "SELECT * FROM $CFG[Prefix]propfetch WHERE ID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row=mysql_fetch_array($result);
	if($row['FetchScript']!="") {		
		$Dat = explode("-", $row['FetchScript']);
		$Page = $Dat[0];
		$Field = $Dat[1];
		$ClassName = "pmlfetch_$Page";        
		include_once("fetch/fetch-$Page.php");
		if(class_exists($ClassName)) {
			$$ClassName = new $ClassName;
			if($$ClassName->getUseSettings($Field)) { //use settings for this field??								
				$Show[$i]['name'] = "Settings";
				$Show[$i]['type'] = "funcall";
				$Show[$i]['text'] = "Settings";
				$Show[$i]['comm'] = "";
				$Show[$i]['main'] = false;
				$Show[$i]['func'] = "printSettings";
			}
		}		
	}	
}


RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

$DOC_TITLE = "FetchScripts";
include("top.html");		

include("edit.php");

if(isset($_GET['nextaction'])) {
	$_GET['action'] = $_GET['nextaction'];
	$action = $_GET['nextaction'];
	unset($_GET['nextaction']);
	include("editpropfetch.php");
	exit;
}

if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$action = "";
	$_GET['action'] = $action;
	include("edit.php");
	include("bottom.html");
	exit;
}

include("bottom.html");

?>