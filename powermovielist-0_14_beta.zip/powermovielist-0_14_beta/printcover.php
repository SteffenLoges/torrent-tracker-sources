<?php
/** powermovielist cover-creation
 * $Id: printcover.php,v 1.7 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "printcover.php";
include_once("application.php");

//ABMESSUNGEN:
$Cover['back']['width'] = 570;
$Cover['back']['height'] = 445;
$Cover['back']['sidewidth'] = 25;    //Breite der Seite
$Cover['front']['width'] = 480;
$Cover['front']['height'] = 480;
$Cover['front']['sidewidth'] = 0;    //Breite der Seite
$LogoPath = "image/format/";
$LngPath = "image/lng/";

//** Pixel-Fonts
$FontSide = 3;      //schrifart auf der seite
$SpaceSide = 6;     //abstand von der seite
$SpaceSideTop = 10; //anstand von oben/unten fr Sprache/Format auf da seite
$FontBack = 2;      //schriftart fr hinten

//load GET-Vars:
$sCover['type'] = $_GET['type'];
$sCover['col'] = $_GET['col'];
$sCover['pic'] = isset($_GET['pic']);
$sCover['format'] = isset($_GET['format']);
$sCover['lng'] = isset($_GET['lng']);
$sCover['ucase'] = isset($_GET['ucase']);
$sCover['url'] = isset($_GET['url']);
$sCover['formatside'] = isset($_GET['formatside']);
$sCover['indexside'] = isset($_GET['indexside']);
$_SESSION['sCover'] = $sCover;

$Height = $Cover[$sCover['type']]['height'];
$Width = $Cover[$sCover['type']]['width'];
$SideWidth = $Cover[$sCover['type']]['sidewidth'];

$ID = $_GET['ID'];
if($ID=="") $ID=0;
if($ID==0) { echo "Error - No ID"; exit; }

LoadPropAll();
foreach($PropAll as $k=>$Prop) {	
    if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
    if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
	$PropAll[$k]['CoverShow'] = isset($_GET['shw'.$Prop['ID']]);
}

$ret = ReadMovieDataFromDb("popup", $ID, "short");
$Data = $ret['Data'];
unset($ret);


if(function_exists("ImageCreateTrueColor")) {
	//only for GD 2
	$image = ImageCreateTrueColor($Width, $Height);
} else {
	$image = ImageCreate($Width, $Height);
}

//White Background
$white = ImageColorAllocate($image,255,255,255);
ImageFilledRectangle($image, 0, 0, $Width-1, $Height-1, $white);

switch($sCover['col']) {
	case "blue":
		$Color = ImageColorAllocate($image,0,0,128);
		break;
	case "red":
		$Color = ImageColorAllocate($image,160,0,0);
		break;
	case "green":
		$Color = ImageColorAllocate($image,0,96,0);
		break;
	default:
		$Color = ImageColorAllocate($image,0,0,0);
		break;
}


if($sCover['pic']) {	
	$picPath = $Data[$ID][$PropAll[$_GET['pic']]['Name']];
	//small poster-image
	if(strstr(strtolower($picPath),".jpg")==".jpg" && function_exists("ImageCreateFromJPEG")) {		
		$pic = ImageCreateFromJPEG($picPath);
	} elseif (strstr(strtolower($picPath),".png")== ".png" && function_exists("ImageCreateFromPNG")) {
		$pic = ImageCreateFromPNG($picPath);
    } elseif (strstr(strtolower($picPath),".gif")== ".gif" && function_exists("ImageCreateFromGIF")) {
        $pic = ImageCreateFromGIF($picPath);
	}
        
		if($pic) {
            //zielgr?e: 96x140
		    //                  int dstX,                           int dstY, int srcX, int srcY, int dstW, int dstH, int srcW, int srcH)
			ImageCopyResized($image, $pic, $Width-96-$SideWidth-10, 20,       0,        0, 96, 140, ImageSX($pic), ImageSY($pic));
			ImageDestroy($pic);
		}
	}


// outside frame
ImageRectangle($image,0,0,$Width-1,$Height-1,$Color);
ImageLine($image,$SideWidth,0,$SideWidth,$Height-1,$Color);
ImageLine($image,$Width-$SideWidth-1,0,$Width-$SideWidth-1,$Height-1,$Color);




$LogoHeight = 0;
if($sCover['format']) {
	//Print format-logo:
	$Dat = strtolower($_GET['format']);
	if(FileExists($LogoPath . $Dat . ".png")) {
		$logo = ImageCreateFromPNG($LogoPath . $Dat . ".png");
		//        resource dst_im, resource src_im, int dst_x, int dst_y, int src_x, int src_y, int src_w, int src_h     
		ImageCopy($image,           $logo,          $Width-ImageSX($logo)-$SideWidth-10,         $Height-ImageSY($logo)-10,         0,         0,         ImageSX($logo), ImageSY($logo));
		$LogoHeight = ImageSY($logo);
		ImageDestroy($logo);
	}
}

if($SideWidth > 0) {

//**** Text on the side
//format - langauge - index-nr
/*
sprache unten
format oben

*/

//first count how many properties are shown on the side (additional to the title)
$SideShowCount=0;
$SideShowItems=array();
if($sCover['formatside']) {
    $SideShowCount++;
    $SideShowItems[] = $_GET['formatside'];
}
if($sCover['lng']) {
    $SideShowCount++;
    $SideShowItems[] = "[".$_GET['lng']."]";
}
if($sCover['indexside']) {
    $SideShowCount++;
    $SideShowItems[] = $_GET['indexside'];
}

switch($SideShowCount) {
    case 0:
        $Text1=$Text2="";        
        break;
    case 1:
        $Text1=$Text2= $SideShowItems[0];
        break;
    case 2:
        $Text1=$SideShowItems[0];
        $Text2=$SideShowItems[1];
        break;
    case 3:
        $Text1=$SideShowItems[0];
        $Text2=$SideShowItems[1]." ".$SideShowItems[2];
        break;

}

$ln = strlen($Text1);
$lnGes = $ln;
$Pos = $ln * ImageFontWidth($FontSide) + $SpaceSideTop;
ImageStringUp($image, $FontSide, $SpaceSide, $Pos,  $Text1, $Color);


$ln = strlen($Text2);
$lnGes = +$ln;
$Pos = $Height - $SpaceSideTop;
ImageStringUp($image, $FontSide, $SpaceSide, $Pos,  $Text2, $Color);


//Filmtitel:  
$PropID=0;
foreach($PropAll as $k=>$Prop) {
    if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
    if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
	if($Prop['ShowOnCover']==PML_Cover_SideTitle) {
		$PropID = $Prop['ID'];
		break;
	}
}
if($PropID==0) {
	$Text="no title found";
} else {
	$Text = $Data[$ID][$PropAll[$PropID]['Name']];
}
if($sCover['ucase'])
	$Text = StrToUpper($Text);

$NewText = $Text;
//maximale h?e die zur verfgung steht:
$MaxHeight = $Height - 2 - $SpaceSideTop*2 - $lnGes*ImageFontWidth($FontSide) - 40;
$ln = strlen($Text);
$Pos = $ln * ImageFontWidth($FontSide);
$i=strlen($Text)-2;

while($Pos > $MaxHeight) {
	$i--;
	$NewText = substr($Text,0,$i) . "...";
	$ln = strlen($NewText);
	$Pos = $ln * ImageFontWidth($FontSide);
} 

$Pos = (($Height-$Pos)/2) + $Pos;
ImageStringUp($image, $FontSide, $SpaceSide, $Pos,  $NewText, $Color);




//die rechte seite auch noch schreiben (die linke spiegeln)
$RightSide = ImageCreate($SideWidth, $Height);
for($i=0; $i<$SideWidth; $i++) {
	for($j=0; $j<$Height; $j++)
		ImageCopy($RightSide, $image, $i, $j, $SideWidth-1-$i, $Height-1-$j, 1, 1);
}
ImageCopy($image, $RightSide, $Width-$SideWidth, 0, 0, 0, $SideWidth, $Height);

} // SideWidth end


// movie properties list
$MaxTitleLen = 0;
foreach($PropAll as $k=>$Prop) {
    if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
    if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
    if(!$PropAll[$k]['CoverShow']) continue;
	if(strlen($Prop['InTitle'])>$MaxTitleLen)
		$MaxTitleLen = strlen($Prop['InTitle']);
}

$BackText = $BackData = array();
foreach($PropAll as $k=>$Prop) {
    if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
    if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
	if(!$PropAll[$k]['CoverShow']) continue;	
	$Text = $Data[$ID][$Prop['Name']];
	$BackText[]  = str_repeat(" ",$MaxTitleLen-strlen($Prop['InTitle'])) . $Prop['InTitle'] . ": ";
	$BackData[]  = strip_tags(html_decode($Text));
}

$num = SizeOf($BackText);

$j=0; //lines
for($i=0;$i<$num;$i++) {
	ImageString($image, $FontBack , $SideWidth + 15, $j*ImageFontHeight($FontBack) + 25, $BackText[$i], $Color);
	if($j<10) {
		$MaxWidth = $SideWidth + 375-ImageFontWidth($FontBack)*($MaxTitleLen+2);
	} else {
		$MaxWidth = $SideWidth + 475-ImageFontWidth($FontBack)*($MaxTitleLen+2);
	}
	$j += ImageStringMultiLine($image, $FontBack, 
		$SideWidth + 15 + strlen($BackText[$i])*ImageFontWidth($FontBack), //posx
		$j*ImageFontHeight($FontBack) + 25,                   //posy
		$BackData[$i],                                        //text
		$Color,                                               //color
		$MaxWidth,                                            //maxwidth
		$Height - ($j*ImageFontHeight($FontBack) + 25) - $LogoHeight-20); //maxheight
	
}

//ImageStringMultiLine($image, $Font, $PosX, $PosY, $Text, $Color, $MaxWidth, $MaxHeight=0)


if($sCover['url']) {
//Links unten der Titel der MOvie-List
ImageString($image, $FontBack, 40, $Height-20, $ActiveList['title'] . " - " . $ActiveList['urlname'], $Color);
}

//und natrlich noch ein Copyright fr mich ;-)
ImageString($image, 1, $Width-170+$SideWidth, 5,"www.powermovielist.com", $Color);





Header( "Content-type: image/png");
ImagePNG($image);

ImageDestroy($image);

?>
