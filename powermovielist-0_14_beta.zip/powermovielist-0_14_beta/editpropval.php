<?php
/** powermovielist edit property-values (ListBox and ListBoxMulti)
 * $Id: editpropval.php,v 1.9 2005/10/08 15:53:42 niko Exp $
*/
$FILE_SELF = "editpropval.php";
$LoadSmarty=true;
include_once("application.php");

$Title = $strPropertyValue;
$TitlePl = $strPropertyValues;


$Table = $CFG['Prefix'] . "propval";

$Filter = "PropID";
$FilterVal = $_GET['F'];

$SortOrderField = "SortOrder";

$SessionVar = "editpropval";

//read prop-settings
$strSql = "SELECT * FROM $CFG[Prefix]prop WHERE ID=$FilterVal";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$row=mysql_fetch_array($result);

$strSql = "SELECT COUNT(*) AS Count FROM $CFG[Prefix]propfetch WHERE PropID=$FilterVal";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$Dat = mysql_fetch_array($result);
$row['FetchCount'] = $Dat['Count'];

$SecondTitle="for <a href='editprop.php".$GlobalArg."action=edit&ID=$row[ID]'>$row[Name]</a>";

if($row['PropType']==PML_PropType_Boolean) {
	$HideAddLink = true;
	unset($SortOrderField);
	$HideDelLink = true;
}

$i=0;
if($row['PropType']==PML_PropType_Boolean) {
	$Show[$i]['name'] = "Value";
	$Show[$i]['type'] = "listbox";
	$Show[$i]['prop'] = $strCheckedUnchecked; //"checked;unchecked"; 
	$Show[$i]['text'] = "value";	
	$Show[$i]['values'] = "1;0"; 
	$Show[$i]['main'] = true;
	$Show[$i]['def'] = "";
	$Show[$i]['save'] = false;
	$i++;
}
$Show[$i]['name'] = "DisplayText";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = $strTextDisplayed;
$Show[$i]['comm'] = $strEdirPropDisplayTextComm; //"(displayed in the filters, popup and on covers)";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
$i++;
$Show[$i]['name'] = "DisplayTextShort";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "5";    //Text-Field-Width
$Show[$i]['text'] = $strShortTextDisplayed;
$Show[$i]['comm'] = $strEditPropShortTextComm; //"(displayed on the list itself)";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
$i++;
$Show[$i]['name'] = "DisplayTextHtml";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "10";    //Text-Field-Width
$Show[$i]['text'] = $strHtmlDisplayedOnList;
$Show[$i]['comm'] = $strPropValHtmlComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
$i++;
$Show[$i]['name'] = "SortText";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "5";    //Text-Field-Width
$Show[$i]['text'] = $strSortText;
$Show[$i]['comm'] = $strPropValSortingComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
if($row['FetchCount']) {
	$i++;
	$Show[$i]['name'] = "FetchText";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "12";
	$Show[$i]['text'] = $strFetchText;
	$Show[$i]['comm'] = $strEditPropFetchTextComm; //"(like the item is called on the page from where it is fetched)";
	$Show[$i]['main'] = true;
	$Show[$i]['def'] = "";
	$Show[$i]['uniq'] = false;
}

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);
$DOC_TITLE = $strPropertyValues;
include("top.html");		

include("edit.php");

//clear the smarty cache for this list
if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$smarty->clear_cache(null,"list|$Active");
	$smarty->clear_cache(null,"poup|$Active");    
}


if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$action = "";
	$_GET['action'] = $action;
	include("edit.php");
}


include("bottom.html");

?>