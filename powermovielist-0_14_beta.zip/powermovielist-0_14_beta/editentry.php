<?php
/** powermovielist edit entry
 * $Id: editentry.php,v 1.18 2005/12/13 19:32:05 niko Exp $
*/

$FILE_SELF = "editentry.php";
$LoadSmarty = TRUE;
include_once("application.php");
include_once("fetch/fetch.php");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];
switch($action) {
case "add":
case "edit":
    if($action=="add") {
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Add);  //add-rights
    } else {
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Moderator);  //moderator-rights
    }

	LoadPropAll();
	LoadPropFetchScripts();

	$LoadJavaScript = false;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['PropType']==PML_PropType_DownloadLink) 
			$LoadJavaScript = true;
	}
	if($LoadJavaScript) {
		$JavaScriptText = "
	function Link_Change(PropID) {
		var LinkUrl = document.frmEdit['in'+PropID].value;
		if(LinkUrl.indexOf('ed2k://|file|')!=0)
			return;  //not a edonkey-link
		LinkUrl = LinkUrl.substring(13); //cut off edk://...|
		var i=LinkUrl.indexOf('|');
		var LinkText = LinkUrl.substring(0,i);
		LinkUrl = LinkUrl.substring(i+1);
		document.frmEdit['inText'+PropID].value=LinkText;
		var i=LinkUrl.indexOf('|');
		var LinkSize = LinkUrl.substring(0,i);
		LinkSize = Math.round(LinkSize /= 1048576);
		document.frmEdit['inSize'+PropID].value=LinkSize;
	}
	";
	}

	if($action=="add") $DOC_TITLE = "PowerMovieList - $strAddEntry";
    else $DOC_TITLE = "PowerMovieList - $strEditEntry";
	include("top.html");
	echo "<form name='frmEdit' method='post' enctype='multipart/form-data' action='editentry.php$GlobalArg";
	if($action=="edit") echo "&ID=$ID";
	echo "&action=$action" . "save'>";
    if($action=="edit" && isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!="") {
        echo "<input type='hidden' name='RedirectUrl' value='$_SERVER[HTTP_REFERER]'>";        
    }
	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";	


	$cls=0;	
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_UserRating || $Prop['PropType']==PML_PropType_DisplayNr || in_array($Prop['PropType'], array_keys($CFG['CustomPropTypes']))) continue;
		if($action=="add" && !$Prop['ShowAdd']) continue; //don't display fetched-fields when adding new entry
        if($action=="add" && count($Prop['FetchScripts']) && $ActiveUserFetchRights) continue;
		echo "  <tr class='row";
		if($cls++%2) echo "1"; else echo "2";
		echo "'>\n";
		echo "<td align='right'>";
			echo "<b>" . $Prop['InTitle'] . ":</b>";		
		if($ActiveUserFetchRights && count($Prop['FetchScripts']))
			echo "<br><font size='-3'>($strFetched)</font>";
		echo "</td>\n";
		echo "<td>";

		if($action=="add") $ID=0; //0 for default-values!
		PrintEditEntryProp($Prop, $ID);

		echo "  </td>\n";
		echo "</tr>\n";
	} //end for

	echo "<tr class='row";
	if($cls++%2) echo "1"; else echo "2";
	echo "'>\n";
	echo "	<td></td>\n";
	echo "	<td><br><br><input type='submit' name='save' value='";
	if($action=="add")
		echo $strAddEntry;
	else
		echo $strSaveEntry;
	echo "'> &nbsp; <input type='reset' value='$strReset'></td><br><br>\n";
	echo "</tr>\n";
	if($action=="edit") {
        echo "<tr class='row";
        if($cls++%2) echo "1"; else echo "2";
        echo "'>\n";
        echo "  <td></td>\n";
        echo "  <td><input type='submit' name='fetch' value='$strFetchDataAgain'></td>\n";
        echo "</tr>\n";

        if($CFG['EnableSaveShowOnIndex']) {
            echo "<tr class='row";
            if($cls++%2) echo "1"; else echo "2";
            echo "'>\n";
            echo "  <td></td>\n";
            echo "  <td><input type='submit' name='saveShowIndex' value='$strSaveAndShowOnIndexPage'></td>\n";
            echo "</tr>\n";
        }
	}
	echo "</table>\n";
	echo "</form>";
	break;
case "addsave":
case "editsave":
    LoadPropAll();
	LoadPropFetchScripts();


    if($action=="addsave") {
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Add);  //add-rights
    } else {
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Moderator);  //moderator-rights
    }

    $UseFetching=false;
	if($ActiveUserFetchRights && ($action=="addsave" || ($action=="editsave" && isset($_POST['fetch'])))) {
        //if editsave and fetch-button clicked, fetch
        //check if a fetch-script is set, if not don't fetch
        foreach($PropAll as $Prop) {
            if(count($Prop['FetchScripts'])) {
                $UseFetching=true;
                break;
            }
        }
    }
       
    //for writein the conratulation-text when 50st 100st... movie was added
    if($action=="addsave") {
        $strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE ListID=$ActiveList[ID]";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);	
        $row = mysql_fetch_row($result);
        $NumOfMovies = $row[0]+1;
    }

	if(!$UseFetching) {        
		//if no fetching is used, refresh to the list-url		
        
        if($CFG['Debug'])
            $RefreshTime=3000;
        else
            $RefreshTime=1000;
        
        //when 50st or 100st entry added wait some time to read the concratiolation-msg
        if($action=="addsave") {
            if(!($NumOfMovies%50))
                $RefreshTime=5000;
        }

        $OnLoad="setTimeout('LoadListPage();',$RefreshTime);"; //meta-refresh won't work here because we have to refresh into the parent
        $JavaScriptText = "
        function LoadListPage(delay) {
            parent.location='list.php$GlobalArg';
        }";
    }
    

	$DOC_TITLE = "PowerMovieList - $strSaveEntry";
	include("top.html");

	if($action=="addsave") {
        $dateAdded = date("Y-m-d H:i:s");
		$strSql = "INSERT INTO $CFG[Prefix]movies (ListID, DateAdded, UserAddedID)
			VALUES ('$ActiveList[ID]','" . $dateAdded . "','$ActiveUser[ID]')";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);	
		$ID = mysql_insert_id();

		$strSql = "INSERT INTO $CFG[Prefix]movies_$ActiveList[name] (MovieID, DateAdded, UserAddedID)
			VALUES ('$ID', '" . $dateAdded . "','$ActiveUser[ID]')";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);	

		if(!($NumOfMovies%50)) {
			echo $strCongrat1." ";
			echo $NumOfMovies;
			echo " ".$strCongrat2;
			echo "<br>\n";
		}
	} 
	if($action=="editsave") {
		//$ID is allready set
		if(!isset($ID)) echo "error no ID";
	}

    if($action=="editsave" && isset($_POST['saveShowIndex'])) {
        $strSql = "UPDATE $CFG[Prefix]movies SET DateAdded=NOW() WHERE ID='$ID'";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);   

		$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET DateAdded=NOW() WHERE MovieID='$ID'";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);   
    } 

	$r=0;	
	foreach($PropAll as $Prop)
    {
		if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_UserRating || $Prop['PropType']==PML_PropType_DisplayNr || in_array($Prop['PropType'], array_keys($CFG['CustomPropTypes']))) continue;
        if((    $action=="addsave" && !$Prop['ShowAdd'])
            ||  $GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']
            || ($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest")
            || ($action=="addsave" && count($Prop['FetchScripts']) && $ActiveUserFetchRights)) {
            //save standard-value:
            SaveDefaultValueEditEntryProp($Prop, $ID);
        } else {
            //save POST-variables:
		    SaveEditEntryProp($Prop, $ID);
        }
	} //end foreach $PropAll
	
	if($action=="editsave") {
		$smarty->clear_cache(null,"popup|$Active|$ID");
        if($CFG['CacheClearOnChangeList']) {
            $smarty->clear_cache(null,"list|$Active");        
        }
	} else { //action=="addsave"
        if($CFG['CacheClearOnChangeList']) {
            $smarty->clear_cache(null,"list|$Active");        
        }
	}
    
    if(!$UseFetching) {
        if(file_exists("templates/editentry_aftersave.php")) {
            include("templates/editentry_aftersave.php");
        } else {
            echo " <table width='100%' height='100%'>\n";
            echo "  <tr valign='middle' align='center'>\n";
            echo "   <td><b>The edited entry was saved sucessfully.</b><br><a href='list.php$GlobalArg'>If the automatic redirection shouldn't work click here!</a></td>\n";
            echo "  </tr>\n";
            echo " </table>	\n";
        }
        break; //break switch
    }

    //continue with fetching when adding or fetch-button was clicked
case "fetch":
case "search":
case "fetchall";
    if($action=="editsave" || $action=="fetchall") {
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Moderator);  //moderator-rights
    } else {
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Add);  //add-rights
    }

    $smarty->clear_cache(null,"popup|$Active|$ID");
    if($CFG['CacheClearOnChangeList']) {
        $smarty->clear_cache(null,"list|$Active");
    }


    $DOC_TITLE = "PowerMovieList - $strSaveEntry";
	include_once("top.html");
    
    $cls = 0;
	$SearchText = GetFetchText($ID);
   	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
    echo "  <tr class='row".(($cls++%2)+1)."'><td><h1>fetching</h1></td></tr>\n";
    echo "  <tr class='row".(($cls++%2)+1)."'><td>$strFetchingDataFor: $SearchText\n";
    if($action!="fetch")
        echo " <a href='editentry.php".$GlobalArg."action=edit&ID=$ID'>$strSkipFetchingAndEditEntry</a><br><br>\n";
	flush();
    echo "</td></tr>\n";

	if(!isset($_GET['fsKey'])) {
		$ReachedFsKey = true;
	} else {
		$continueFsKey = $_GET['fsKey'];
		$ReachedFsKey = false;
	}

	LoadPropAll();
	LoadPropFetchScripts();

	$fetchIDargs="";
	//are there allread some fetchids?
	if(isset($_GET['fid'])) {
		if(is_array($_GET['fid'])) {
			foreach($_GET['fid'] as $k=>$i) {
				$fetchID[$k] = $i;
				$fetchIDargs .= "&".urlencode("fid[$k]")."=$i";
			}    
		}
	}

    foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;

        $fsCount = 0;
		foreach($Prop['FetchScripts'] as $fsKey => $fsItem) {
            $fsCount++;

			$FetchScript = $fsItem['FetchScript'];
			if($FetchScript=="") continue;

			//restart with continueFsKey
			if(!$ReachedFsKey) {
				if($continueFsKey!=$fsKey)
					continue;
				else {
					$ReachedFsKey = true;
				}
			}

			$Dat = explode("-", $FetchScript);
			$Page = $Dat[0];
			$Field = $Dat[1];
			$ClassName = "pmlfetch_$Page";        

            if(!FileExists("fetch/fetch-$Page.php")) {
                echo "<b>$GLOBALS[strErrError]:</b> $strFetchScript (fetch/fetch-$Page.php) $strNotFound<br>";
                continue;
            }
            include_once("fetch/fetch-$Page.php");

            if(!class_exists("pmlfetch_".$Page)) {
                echo "<b>$GLOBALS[strErrError]:</b> class pmlfetch_$Page $strNotDefinedIn fetch/fetch-$Page.php<br>";
                continue;
            }
            
            $fsClass = new $ClassName;
            flush();
        
            if(isset($fetchID[$Page]))
                $fsClass->setFetchID($fetchID[$Page]);

			if(isset($fetchID[$Page]) && $fetchID[$Page]=="skip")
				continue; //skip was clicked for this fetch-script

			if($action=="search") {
				if(!isset($_POST['Text'])) ErrorExit("Search-Text not set!");
				$SearchText = $_POST['Text'];
			}		

			if($fsClass->getFetchID()=="") {
				$out = "";
				$r = $fsClass->doSearch($out, $SearchText, "editentry.php".$GlobalArg."action=fetch&PropID=" . $Prop['ID'] . "&fsKey=$fsKey&ID=$ID{$fetchIDargs}");
				if($r==PML_FETCH_SEARCHERROR) exit;                                                                                                                     
				if($r==PML_FETCH_EXACTMATCH) {                
					//FetchID is set!!
					//continue below with the fetching of the first field
                    $fetchID[$Page] = $fsClass->getFetchID();
				} else { //the search-form is displayed...                                
					echo "<tr class='row".(($cls++%2)+1)."'><td>";
					echo "<b>searching on $Page:</b>";
					echo "</td></tr>\n";										
					echo "<tr class='row".(($cls++%2)+1)."'><td>";
					echo $out;
					echo "</td></tr>\n";					
					echo "<tr class='row".(($cls++%2)+1)."'><td>";
					echo "<a href=\"editentry.php".$GlobalArg."action=fetch&PropID=" . $Prop['ID'] . "&fsKey=$fsKey&ID=$ID{$fetchIDargs}&" . urlencode("fid[{$Page}]")."=skip\">no entry exists, skip this fetch-script</a>";
					echo "</td></tr>\n";					

					//Search-Form
					echo "<tr class='row".(($cls++%2)+1)."'><td>\n";
					$FormUrl = "editentry.php".$GlobalArg."action=search&PropID=" . $Prop['ID'] . "&fsKey=$fsKey&ID=$ID{$fetchIDargs}";
					echo "	<form name='form1' method='post' action='$FormUrl'>\n";
					echo "		your movie wasn't found, search for this string:<br>\n";
					echo "		<input type='text' name='Text' value='" . urldecode($SearchText) . "'>\n";
					echo "		<input type='submit' name='Submit' value='Search'>\n";
					echo "	</form>\n";
					echo "</td></tr>\n";
					echo "</table>\n";
					include("bottom.html");
					exit;
				}
			}
			echo "<tr class='row".(($cls++%2)+1)."'><td>";
			if($fsClass->getFetchID()!="") {
				
				echo "[$Page]: $Field ... ";

				//check if setting is uses
				if($fsClass->getUseSettings($Field)) {
					$fsClass->setSettings($Field, $fsItem['Settings']); //set the setting...
				}

				$FetchVal="";
				$FetchResult = $fsClass->DoFetch($FetchVal, $Field);
				
				if($FetchResult==PML_FETCH_OK) {
					echo "<font color=green>OK</font>";
				} elseif($FetchResult==PML_FETCH_ITEMNOTFOUND) {
					echo "<font color=red>Error, fetch-item doesn't exist</font>";
					continue;//nothing found, continue with next FetchScript for this property (if any)
				} else {
					echo "<font color=red>nothing found</font>";
					continue;//nothing found, continue with next FetchScript for this property (if any)
				}
				flush();
				
                if($FetchVal=="") { //nothing was fetched
                    if(sizeof($Prop['FetchScripts'])<=$fsCount) {
                        //save default-value
                        SaveDefaultValueEditEntryProp($Prop, $ID);
                    }
                    continue; //continue with next fetch-script for this property
                }							

				switch($Prop['PropType']) {
					case PML_PropType_Text: //Text
					case PML_PropType_Date: //Date				
					case PML_PropType_Textfield: //Textfield
					case PML_PropType_Url: //Url
					case PML_PropType_UrlCached: //cached Url
					case PML_PropType_FileUpload: //File-Upload					
					case PML_PropType_AutoIncrement:                
						if(is_array($FetchVal)) $FetchVal = implode(", ", $FetchVal);

						if($Prop['PropType']==PML_PropType_UrlCached || $Prop['PropType']==PML_PropType_FileUpload) { //cached Url, File Upload
							//get the filename for the cache                        
							if(isset($fsClass->OverrideFileName)) {
								//when OverrideFileName is set, this must be used for the file-name!
								$Dat=$fsClass->OverrideFileName;
							} else {
								//else get it from the FetchVal                                
								$Dat = GetFileName($FetchVal, true); //get the file-name of the URL and be verbose
							}
							//check if Dat has a valid extension:
							$Ext = substr($Dat, strrpos($Dat, "."));
							if(!in_array(strtolower($Ext), explode(";", $GLOBALS['CFG']['UploadExt']))) {
								echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidExtension] (" . $Dat . ")<br>\n";
								break;
							}
							//and create the file-name
							if ($Prop['PropType']==PML_PropType_UrlCached)
								$FileName = $CFG['CacheDir'] . $ID."-".$Prop['ID']."-".$Dat;
							else
								$FileName = $CFG['UploadDir'] . $ID."-".$Prop['ID']."-".$Dat;

							//download the url
							if(!DownloadFile($FetchVal, $FileName)) {
								//if download fails print error and set FetchVal to ""
								echo " <b>$GLOBALS[strErrError]:</b> $strCantDownloadUrl (" . $FetchVal . ")<br>\n";
								//$FetchVal = ""; //dont't set to "" if errors happen try to download again later...
							} else {
								resizeImage($FileName, $Prop['ImageSize']);
							}

							if($FetchVal!="" && $Prop['PropType']==PML_PropType_FileUpload) {
								//for file-uploads only the filename is saved, not the complete url
								$FetchVal = $Dat;
							}

							if($FetchVal!="" && isset($fsClass->OverrideFileName) && $Prop['PropType']==PML_PropType_UrlCached) {
								//only when OverrideFileName is set:
								//for cached urls the local-filename has to be saved additional to the complete url
								//...else the local-filename can be generated from the Url itself using the GetFileName function...
								$FetchVal = $FetchVal.PML_PropertyDelem.$Dat;
							}
						}

						$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$FetchVal."' WHERE MovieID='$ID'";
						pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

						break;
					case PML_PropType_ListBox: //ListBox
					case PML_PropType_ListBoxMulti: //ListBoxMulti	
					case PML_PropType_Boolean: //Boolean
						if(!is_array($FetchVal)) $FetchVal = array($FetchVal);

						$strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=" . $Prop['ID'];
						$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
						$PropVals = array();
						while($r = mysql_fetch_array($q, MYSQL_ASSOC)) {
							$PropVals[] = $r;
						}
						
						$PropValIDs = array();
						foreach($PropVals as $PropVal) {
							$k = array_search($PropVal['FetchText'], $FetchVal);
							if(is_int($k)) {								
								$PropValIDs[] = $PropVal['ID'];
								unset($FetchVal[$k]);
							}
						}

						if($Prop['PropType']==PML_PropType_ListBoxMulti) {
							$save = "_".implode("_", $PropValIDs)."_";
							$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$save."' WHERE MovieID='$ID'";
							pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
						} else {
							$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$PropValIDs[0]."' WHERE MovieID='$ID'";
							pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
						}


						if(count($FetchVal)) {
							echo "<b>$GLOBALS[strErrError]:</b> $strNotAllFetchedValuesExistInTheDatabase (" . implode(", ", $FetchVal) . ")<br>";
						}

						break;
				} //end swtich $Prop['PropType']
				echo "</td></tr>";
			} //end if $fsClass->getFetchID()!=""
			flush();
			break; //entry saved, break and continue with next Property (skip other fsKeys for this prop)
		} //end foreach $Prop[FetchScripts]
	} //end foreach $PropAll
    echo "<tr class='row".(($cls++%2)+1)."'><td>";
	echo "<b>$strFetchingDone!</b>\n";
    echo "</td></tr>\n";
    echo "<tr class='row".(($cls++%2)+1)."'><td>";

    if(file_exists("templates/editentry_afterfetch.php")) {
        include("templates/editentry_afterfetch.php");
    } else {
        echo "<a href='editentry.php".$GlobalArg."action=add'>$strAddNewEntry</a>\n";
        echo " - <a href='editentry.php".$GlobalArg."action=edit&ID=$ID'>$strEditEntry</a>\n";
        echo " - <a href='$GLOBALS[ListUrl]' target='_parent'>$strGoToTheList</a>\n";
    }
    echo "</td></tr>\n";
    echo "</table>";
	break;	
case "delete":
    RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Moderator);

	$DOC_TITLE = "PowerMovieList - $strDeleteEntry";
	$DoRefresh=true;
    if($_SERVER['HTTP_REFERER']!="") {
        $RefreshUrl = $_SERVER['HTTP_REFERER'];
    } else {
	    $RefreshUrl = "list.php$GlobalArg";
    }
	include("top.html");

	if($ID=="")
		ErrorExit($strErrNothingSelected);

	$strSql = "DELETE FROM " . $CFG['Prefix'] . "movies WHERE ID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    $strSql = "DELETE FROM " . $CFG['Prefix'] . "votes WHERE MovieID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    $strSql = "DELETE FROM " . $CFG['Prefix'] . "comment WHERE MovieID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    $strSql = "DELETE FROM " . $CFG['Prefix'] . "movies_{$Active} WHERE MovieID=$ID";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    $delDirs = array($CFG['UploadDir']);
    if($CFG['UploadDir']!=$CFG['CacheDir']) $delDirs[] = $CFG['CacheDir'];
    
    foreach($delDirs as $dir)
    {
        $handle = opendir($dir);
        while ($file = readdir ($handle)) {
            if(substr($file, 0, strlen("$ID-"))=="$ID-") {
                unlink($dir."/".$file);
            }
        }
        closedir($handle);
    }
    
    echo " <table width='100%' height='100%'>\n";
    echo "  <tr valign='middle' align='center'>\n";
    echo "   <td><b>The entry was deleted sucessfully.</b><br><a href='$RefreshUrl'>If the automatic redirection shouldn't work click here!</a></td>\n";
    echo "  </tr>\n";
    echo " </table>	\n";        

	$smarty->clear_cache(null,"popup|$Active|$ID");
    if($CFG['CacheClearOnChangeList']) {
        $smarty->clear_cache(null,"list|$Active");
    }
	break; //break switch
default:
	ErrorExit("Invalid action: $action");
} //end switch $action


include("bottom.html");	

?>
