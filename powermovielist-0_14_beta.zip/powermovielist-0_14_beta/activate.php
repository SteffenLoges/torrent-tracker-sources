<?php
/** powermovielist template
 * $Id: activate.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "activate.php";
include_once("application.php");

if(!$usr->UseEditUser)
    ErrorExit("You can't use the pml-user-files, as they have been disabled.");

if(isset($_GET['action'])) $action=$_GET['action']; else $action="";

if($action=="resend") {
	$DOC_TITLE = $strReSendActivationMail;
	include("top.html");
    echo "<form name=\"LoginForm\" method=\"post\" action=\"activate.php".$GlobalArg."action=resendsave";
	echo "\">
	<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='30%' align='center'>
			<tr class='row1'>
			  <td colspan='2' align='center'>
		  $strIfYouDidntGetMailReRequest
			  </td>
			</tr>
		<tr class='row1'>
			  <td align='right'>
					<b>$GLOBALS[strLoginUser]:</b>
			  </td>
			  <td>
				<input type=\"text\" name=\"ReSendUser\">
			  </td>
			</tr>
			<tr class='row2'>
			  <td align='right'>
					<b>$strEditUserFldMail:</b>
			  </td>
			  <td>
				<input type=\"text\" name=\"ReSendEmail\">
			  </td>
			</tr>
			<tr class='row1'>
			  <td>
		</td>
				<td>
			  <input type=\"submit\" name=\"Submit\" value=\"Request\">
				</td>
		</tr>
	</table>
	</form>
	<script language='Javascript'>
	self.document.LoginForm.LUser.focus();
	</script>";
	include "bottom.html";
	exit;
}

if($action=="resendsave") {
	$DOC_TITLE = $strSendActivationMail;
	include("top.html");

	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE name='$_POST[ReSendUser]' AND email='$_POST[ReSendEmail]'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
	if(mysql_num_rows($result)==0) {
		ErrorExit($strUserOrEmailNotFound); 
	}
	$row = mysql_fetch_array($result);

	SendActivationMail($row);

	echo $strEditUSerClickHereGoBackList;
	include("bottom.html");
	exit;
}

$DOC_TITLE = $strUserActivation;
include("top.html");

$a = (int)$_GET['a'];
$ID = (int)$_GET['ID'];

echo "<h1>$strUserActivation</h1>";
if($a == "0")
{
	echo "<b>$strErrError</b>\n";
	echo "$strInvalidCodePleasyCopy";
	include("bottom.html");
	exit;
}
$strSql = "SELECT * FROM " . $CFG['Prefix'] . "users 
           WHERE ID='$ID' AND activate='$a'";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$num = mysql_affected_rows();

if($num!=0) {
  $userRow = mysql_fetch_assoc($result);
  $strSql = "UPDATE " . $CFG['Prefix'] . "users SET activate=0 WHERE ID='$ID'";
  $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	echo "$strUserActivated<br>\n";
	if($ActiveUser['name']=="Guest") {
		//neuen benutzer einloggen: - wenn vorher als guest
		$LoggedIn = $userRow['name'];
		$_SESSION['LoggedIn'] = $LoggedIn;
		echo "$strUserLoggedIn<br>\n";
	} else {
		echo $strNewUserNotLoggedIn."\n";
	}

	echo "<br><br>$strClickHereToGoToIndex\n";
} else {
	echo "<b>$strErrError</b>\n";
	echo "$strInvalidCodePleasyCopy";
}


include("bottom.html");
?>
