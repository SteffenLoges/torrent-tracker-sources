<?php
/** powermovielist template
 * $Id: settings.php,v 1.14 2005/11/23 18:35:59 niko Exp $
*/
$FILE_SELF = "settings.php";
$LoadSmarty=true;
include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

switch($action) {
    case "import":
    case "import1":
        $DOC_TITLE = "import settings";
        include("top.html");
        if(!$CFG['EnableImportSettings'])
            ErrorExit("This feature is disabled for security reasons.<br><br>Users with Super-Admin-Rights can enable it in the global-config.");

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>import setting</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";
        
        echo "<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='settings.php".$GlobalArg."action=import2'>\n";
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
        echo "<tr class='top'><td colspan='2'>Information</td></tr>\n";
        echo "<tr class='row1'><td colspan='2'>\n";
        echo "With this script you can import designs (*.pmlset). You will find on <a href='http://www.powermovielist.com'>www.powermovielist.com</a> some to download<br>
        You can select what settings you want to import (if saved in the file):
        <ul>
            <li><b>property/field-settings:</b> Here you can define all the properties you want to enter for every movie. Located in the config->properties/fields.
            <li><b>list-settings:</b> The settings that are important for the design and not saved for every property.
            <li><b>css-file:</b> Minor changes to the design can be made here, like font settings, colours...
            <li><b>templates:</b> The whole layout of the list can be changed with template-files, create your own layout!
            <ul>
              <li><b>popup-tpl:</b> The template for the popup.
              <li><b>list-tpl:</b> The template for the list.
            </ul>
            <li><b>list-image:</b> the image on top of the list         
            <li><b>screenshot:</b> you could add a screenshot of your design - it will be listed at the design-download-page.
        </ul>
        <b>Note:</b> If you import the property/field-settings all your entries in the list will be lost!
        </td></tr>
        <tr class='top'><td colspan='2'>Step 1: File-Upload</td></tr>
          <tr class='row1'>
            <td align='right'>the .pmlset-file</td>
            <td>
        <!--      <INPUT TYPE='hidden' name='MAX_FILE_SIZE' value='1048576'> -->
              <INPUT NAME='userfile' TYPE='file' size='40'>
            </td>
          </tr>
          <tr class='row2'>
            <td>&nbsp;</td>
            <td><INPUT TYPE='submit' value='Upload'></td>
          </tr>
        </table>";
        break;
    case "import2":
        $DOC_TITLE = "import settings";
        include("top.html");
        if(!$CFG['EnableImportSettings'])
            ErrorExit("fuck off"); //only hackers would see that :D
        
        //generate temp-filename in cache-dir (should work for absolute AND relative CacheDir's
        $TempFileName = tempnam(getcwd().$CFG['CacheDir'], "ims");
        if(strstr($TempFileName, getcwd())=="") {
            $TempFileName = tempnam($CFG['CacheDir'], "ims");
        }

        //save the file somewhere
        if(!move_uploaded_file($_FILES['userfile']['tmp_name'], $TempFileName)) {
            @unlink($TempFileName);
            ErrorExit("the uploaded file can't be moved...");
        }
        @unlink($_FILES['userfile']['tmp_name']);
        
        $data = "";
        //$data = gzfile($TempFileName);
        //$data = implode("", $data);
//echo $data;
        $fp = fopen ($TempFileName, "rb");
        if(!$fp) {
            @unlink($TempFileName);
            ErrorExit("can't open presettings-file...");
        }
        
        while(!feof($fp))
            $data .= (fread($fp,1024));
        fclose ($fp);
        
        $InData = unserialize(trim($data));  //unserialize (unpack) it
        
        if(!$InData) {
            //try unpacking it
            $data = substr($data, 10);
            $data = gzinflate($data);
        }
        $InData = unserialize(trim($data));  //unserialize (unpack) it
        
        
        if(!$InData) {
            @unlink($TempFileName);
            ErrorExit("this is an invalid file, you can use only files exported by pml...");
        }       
        
        if(!isset($InData['ExportVersion'])) {
            @unlink($TempFileName);
            ErrorExit("this file doesn't include a ExportSettingsVersion-number!");
        }

        //check version compatibility
        if($InData['ExportVersion'] > $ExportSettingsVersion) {
            @unlink($TempFileName);
            ErrorExit("This file has been generated with version $InData[version] (Build $InData[VerBuild]). Please update to the most current version to use this file.");
        }

        $cls=1;
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>import setting</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";
        echo "<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='settings.php".$GlobalArg."action=import3'>\n";
        echo "<INPUT TYPE='hidden' name='TempFileName' value='" . $TempFileName . "'>\n";
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
        echo "<tr class='top'><td colspan='2'>Information</td></tr>\n";
        echo "<tr class='row1'><td colspan='2'>\n";
        echo "With this script you can import designs (*.pmlset). You will find on <a href='http://www.powermovielist.com'>www.powermovielist.com</a> some to download<br>
        You can select what settings you want to import (if saved in the file):
        <ul>
            <li><b>property/field-settings:</b> Here you can define all the properties you want to enter for every movie. Located in the config->properties/fields.
            <li><b>list-settings:</b> The settings that are important for the design and not saved for every property.
            <li><b>css-file:</b> Minor changes to the design can be made here, like font settings, colours...
            <li><b>templates:</b> The whole layout of the list can be changed with template-files, create your own layout!
            <ul>
              <li><b>popup-tpl:</b> The template for the popup.
              <li><b>list-tpl:</b> The template for the list.
            </ul>
            <li><b>list-image:</b> the image on top of the list         
            <li><b>screenshot:</b> you could add a screenshot of your design - it will be listed at the design-download-page.
        </ul>
        <b>Note:</b> If you import the property/field-settings all your entries in the list will be lost!
        </td></tr>      
        <tr class='top'><td colspan='2'>File-Info</td></tr>
        <tr class='row1'>
          <td colspan='2'>
            <ul>
              <li><b>Setting-Name:</b> $InData[Name]
              <li><b>Copyright:</b> $InData[Copy]
              <li><b>Description:</b> $InData[Desc]
            </ul>
          </td>
        </tr>\n";
        if($CFG['Debug']) {
            echo "      <tr class='top'><td colspan='2'>Debug-Data:</td></tr>\n";
            echo "      <tr class='row1'><td colspan='2'>
            <pre>
            ";
            print_r($InData);
            echo "</pre></td></tr>\n";
        }

        echo "      <tr class='top'><td colspan='2'>Step 2: Select Settings to Import</td></tr>\n";

        echo "      <tr class='";
        if($cls++%2) echo "row1"; else echo "row2";
        echo "'>\n";
        echo "    <td align='right'><b>import css-file:</b></td>\n";
        echo "    <td><input type='checkbox' name='impCss' ";
        if(isset($InData['css']))
            echo "checked>\n";
        else
            echo "disabled> <font color='red'>not included in this file</font>";
        echo "</td>\n";
        echo "  </tr>\n";

        echo "      <tr class='";
        if($cls++%2) echo "row1"; else echo "row2";
        echo "'>\n";
        echo "    <td align='right'><b>import list-image:</b></td>\n";
        echo "    <td><input type='checkbox' name='impImage' ";
        if(isset($InData['image']))
            echo "checked>\n";
        else
            echo "disabled> <font color='red'>not included in this file</font>";
        echo "</td>\n";
        echo "  </tr>\n";

        if($Active=="index") {
            echo "      <tr class='";
            if($cls++%2) echo "row1"; else echo "row2";
            echo "'>\n";
            echo "    <td align='right'><b>import index-template:</b></td>\n";
            echo "    <td><input type='checkbox' name='impIndexTpl' ";
            if(isset($InData['indextpl']))
                echo "checked>\n";
            else
                echo "disabled> <font color='red'>not included in this file</font>";
            echo "</td>\n";
            echo "  </tr>\n";
        } else {
            echo "      <tr class='";
            if($cls++%2) echo "row1"; else echo "row2";
            echo "'>\n";
            echo "    <td align='right'><b>import list-template:</b></td>\n";
            echo "    <td><input type='checkbox' name='impListTpl' ";
            if(isset($InData['listtpl']))
                echo "checked>\n";
            else
                echo "disabled> <font color='red'>not included in this file</font>";
            echo "</td>\n";
            echo "  </tr>\n";

            echo "  <tr class='";
            if($cls++%2) echo "row1"; else echo "row2";
            echo "'>\n";
            echo "    <td align='right'><b>import popup-template:</b></td>\n";
            echo "    <td><input type='checkbox' name='impPopUpTpl' ";
            if(isset($InData['popuptpl']))
                echo "checked>\n";
            else
                echo "disabled> <font color='red'>not included in this file</font>";
            echo "</td>\n";
            echo "</tr>\n";
        }

        echo "      <tr class='";
        if($cls++%2) echo "row1"; else echo "row2";
        echo "'>\n";
        echo "    <td align='right'><b>import list-settings:</b></td>\n";
        echo "    <td><input type='checkbox' name='impLists' ";
        if(isset($InData['lists']))
            echo "checked>\n";
        else
            echo "disabled> <font color='red'>none included in this file</font>";
        echo "</td>\n";
        echo "  </tr>\n";

        echo "      <tr class='";
        if($cls++%2) echo "row1"; else echo "row2";
        echo "'>\n";
        echo "    <td align='right'><b>import properties/fields:</b></td>\n";
        echo "    <td><input type='checkbox' name='impProp' ";      
        if(isset($InData['prop']))
            echo "> <font color='red'><b>ATTENTION:</b> all entries in your list will be lost! import properties only in EMPTY/NEW lists!</font>\n";
        else
            echo "disabled> <font color='red'>none included in this file</font>";
        echo "</td>\n";
        echo "  </tr>\n";

        echo "      <tr class='";
        if($cls++%2) echo "row1"; else echo "row2";
        echo "'>\n";
        echo "    <td>&nbsp;</td>\n";
        echo "    <td><INPUT TYPE='submit' value='import'></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        break;
    case "import3":
        $DOC_TITLE = "import settings";
        include("top.html");        
        if(!$CFG['EnableImportSettings'])
            ErrorExit("fuck off"); //only hackers would see that :D

        $TempFileName = $_POST['TempFileName'];
        if(isset($_POST['impProp'])) { //print out warning
            $strSql = "SELECT * FROM $CFG[Prefix]movies WHERE ListID=$ActiveList[ID]";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if(mysql_num_rows($result)>0) {         
                echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
                echo "  <tr class='top'>\n";
                echo "    <td colspan='2'><h1>import setting</h1></td>\n";
                echo "  </tr>\n";
                echo "</table>\n";
                echo "<br>\n";
                echo "<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='settings.php".$GlobalArg."action=import4'>\n";
                echo "<INPUT TYPE='hidden' name='TempFileName' value='" . $TempFileName . "'>\n";
                if(isset($_POST['impCss']))
                    echo "<input type='hidden' name='impCss' value'1'>\n";
                if(isset($_POST['impImage']))
                    echo "<input type='hidden' name='impImage' value'1'>\n";
                if(isset($_POST['impIndexTpl']))
                    echo "<input type='hidden' name='impIndexTpl' value'1'>\n";
                if(isset($_POST['impListTpl']))
                    echo "<input type='hidden' name='impListTpl' value'1'>\n";
                if(isset($_POST['impPopUpTpl']))
                    echo "<input type='hidden' name='impPopUpTpl' value'1'>\n";
                if(isset($_POST['impLists']))
                    echo "<input type='hidden' name='impLists' value'1'>\n";
                if(isset($_POST['impProp']))
                    echo "<input type='hidden' name='impProp' value'1'>\n";
                echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
                echo "<tr class='top'><td colspan='2' align='left'>Step 3: Warning!</td></tr>\n";
                echo "<tr class='row1'><td colspan='2'><b>WARNING:</b> All your entries (".mysql_num_rows($result).") will be deleted if you import new properties/fields!<br>Do You really want to continue?</td></tr>\n";
                echo "  <tr class='row2'>\n";
                echo "    <td>&nbsp;</td>\n";
                echo "    <td><INPUT TYPE='submit' value='continue'></td>\n";
                echo "  </tr>\n";
                echo "</table>\n";
                break; //quit the script                
            }
        } //else continue with the import
    case "import4":
        $DOC_TITLE = "import settings";
        include_once("top.html");       
        if(!$CFG['EnableImportSettings'])
            ErrorExit("fuck off"); //only hackers would see that :D

        $TempFileName = $_POST['TempFileName'];
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>import setting</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
        echo "<tr class='top'><td>Step ";
        if($action=="import4") echo "4"; else echo "3";
        echo ": importing...</td></tr>\n";
        echo "<tr class='row1'><td>";

        //open the file again...
        $data = "";
        $fp = gzopen ($TempFileName, "rb");     
        while(!gzeof($fp))
            $data .= (gzread($fp,1024));
        gzclose ($fp); 

        $InData = unserialize($data);  //unserialize (unpack) it

        //import css-file:
        if(isset($_POST['impCss']) && isset($InData['css'])) {
            $FileName = $InData['files']['css'];
            if(substr($FileName, -4) != ".css") {
                $FileName .= ".css";
            }
            $i=0;
            while(FileExists("css/".$FileName)) { //if file allready exists, add a number
                $i++;
                $FileName = substr($InData['files']['css'],0,-4).$i.".css";
            }
            $fp = @fopen("css/".$FileName, "w");
            if(!$fp) {
                echo "<b>ERROR:</b> can't open css/$FileName to write the css... file skipped...<br>\n";
            } else {
                if(!@fwrite($fp, $InData['css'])) {
                    echo "<b>ERROR:</b> can't write css-file...<br>\n";
                } else {
                    echo "css-file imported...<br>\n";
                    $strSql = "UPDATE $CFG[Prefix]lists SET designcss='".addslashes($FileName)."' WHERE ID=$ActiveList[ID]";
                    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            }
        }

        //import image-file:
        if(isset($_POST['impImage']) && isset($InData['image'])) {
            $FileName = $InData['files']['image'];
            $AllowedExt = array(".jpg", ".jpeg", ".gif", ".png");
            if(!in_array(substr($FileName, -4), $AllowedExt)) {
                echo "<b>ERROR:</b> the list-image doesn't have a valid extension (only jpg, jpeg, gif and png are allowed)... file skipped...<br>\n";
            } else {
                $i=0;
                while(FileExists("image/logos/".$FileName)) { //if file allready exists, add a number
                    $i++;
                    $FileName = substr($InData['files']['image'],0,-4).$i.substr($InData['files']['image'],-4);
                }
                $fp = @fopen("image/logos/".$FileName, "wb");
                if(!$fp) {
                    echo "<b>ERROR:</b> can't open image/logos/$FileName to write the image... file skipped...<br>\n";
                } else {
                    if(!@fwrite($fp, $InData['image'])) {
                        echo "<b>ERROR:</b> can't write image-file...<br>\n";
                    } else {
                        echo "image-file imported...<br>\n";
                        $strSql = "UPDATE $CFG[Prefix]lists SET image='".addslashes($FileName)."' WHERE ID=$ActiveList[ID]";
                        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    }
                }
            }
        }

        //import index-template-file:
        if($Active=="index" && isset($_POST['impIndexTpl']) && isset($InData['indextpl'])) {
            $FileName = $InData['files']['indextpl'];
            if(substr($FileName, -4) != ".tpl") {
                $FileName .= ".tpl";
            }
            $i=0;
            while(FileExists("templates/index/".$FileName)) { //if file allready exists, add a number
                $i++;
                $FileName = substr($InData['files']['indextpl'],0,-4).$i.substr($InData['files']['indextpl'],-4);
            }
            $fp = @fopen("templates/index/".$FileName, "w");
            if(!$fp) {
                echo "<b>ERROR:</b> can't open itemplates/index/$FileName to write the index-template... file skipped...<br>\n";
            } else {
                if(!@fwrite($fp, $InData['indextpl'])) {
                    echo "<b>ERROR:</b> can't write index-template-file...<br>\n";
                } else {
                    echo "index-template-file imported...<br>\n";
                    $strSql = "UPDATE $CFG[Prefix]lists SET listtpl='".addslashes($FileName)."' WHERE ID=$ActiveList[ID]";
                    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            }
        }

        //import list-template-file:
        if($Active!="index" && isset($_POST['impListTpl']) && isset($InData['listtpl'])) {
            $FileName = $InData['files']['listtpl'];
            if(substr($FileName, -4) != ".tpl") {
                $FileName .= ".tpl";
            }
            $i=0;
            while(FileExists("templates/list/".$FileName)) { //if file allready exists, add a number
                $i++;
                $FileName = substr($InData['files']['listtpl'],0,-4).$i.substr($InData['files']['listtpl'],-4);
            }
            $fp = @fopen("templates/list/".$FileName, "w");
            if(!$fp) {
                echo "<b>ERROR:</b> can't open itemplates/list/$FileName to write the list-template... file skipped...<br>\n";
            } else {
                if(!@fwrite($fp, $InData['listtpl'])) {
                    echo "<b>ERROR:</b> can't write list-template-file...<br>\n";
                } else {
                    echo "list-template-file imported...<br>\n";
                    $strSql = "UPDATE $CFG[Prefix]lists SET listtpl='".addslashes($FileName)."' WHERE ID=$ActiveList[ID]";
                    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            }
        }

        //import popup-template-file:
        if($Active!="index" && isset($_POST['impPopUpTpl']) && isset($InData['popuptpl'])) {
            $FileName = $InData['files']['popuptpl'];
            if(substr($FileName, -4) != ".tpl") {
                $FileName .= ".tpl";
            }
            $i=0;
            while(FileExists("templates/popup/".$FileName)) { //if file allready exists, add a number
                $i++;
                $FileName = substr($InData['files']['popuptpl'],0,-4).$i.substr($InData['files']['popuptpl'],-4);
            }
            $fp = @fopen("templates/popup/".$FileName, "w");
            if(!$fp) {
                echo "<b>ERROR:</b> can't open itemplates/popup/$FileName to write the popup-template... file skipped...<br>\n";
            } else {
                if(!@fwrite($fp, $InData['popuptpl'])) {
                    echo "<b>ERROR:</b> can't write popup-template-file...<br>\n";
                } else {
                    echo "popup-template-file imported...<br>\n";
                    $strSql = "UPDATE $CFG[Prefix]lists SET popuptpl='".addslashes($FileName)."' WHERE ID=$ActiveList[ID]";
                    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            }
        }
    
        //import lists-settings
        if(isset($_POST['impLists']) && isset($InData['lists'])) {
            $x = $InData['lists'];
            $strSql = "INSERT INTO $CFG[Prefix]lists (showcounter      , showprint      , showchars      , showsortlinks      , showsearch      , showfilter      , showperpage      , allowcomments      , marknew      , StdPerPage      , ShowOnIndex)
                                             VALUES ('$x[showcounter]', '$x[showprint]', '$x[showchars]',  '$x[showsortlinks]', '$x[showsearch]', '$x[showfilter]', '$x[showperpage]', '$x[allowcomments]', '$x[marknew]', '$x[StdPerPage]', '$x[ShowOnIndex]')";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            echo "list-settings imported...<br>\n";
        }

        if(isset($_POST['impProp']) && isset($InData['prop'])) {
            
            LoadPropAll();
            foreach($PropAll as $Prop) {
                $strSql = "DELETE FROM $CFG[Prefix]propval WHERE PropID=$Prop[ID]";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

				$fieldType = getFieldTypeByPropType($Prop['PropType']);
				if(is_array($fieldType)) {
					foreach($fieldType as $field=>$typ) {
						$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `{$Prop['Name']}_$field`";
						pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
					}
				} else if ($fieldType!="") {
					$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `{$Prop['Name']}`";
					pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				}
            }

            //delete movies
            $strSql = "DELETE FROM $CFG[Prefix]movies WHERE ListID=$ActiveList[ID]";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$strSql = "DELETE FROM $CFG[Prefix]movies_$ActiveList[name]";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            echo "all movies deleted...<br>\n";

            //delete prop's
            $strSql = "DELETE FROM $CFG[Prefix]prop WHERE ListID=$ActiveList[ID]";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            echo "old properties deleted...<br>\n";


            LoadPropPreSetting($ActiveList['ID'], $InData);
            echo "new properties/fields imported...<br>\n";
        }

        echo "<b>DONE!</b>\n";
        echo "</td></tr>\n";
        echo "</table>\n";

        //clear the smarty cache for this list
        $smarty->clear_cache(null,"list|$Active");
        $smarty->clear_cache(null,"poup|$Active");

        break;
    case "export":
        $DOC_TITLE = "export settings";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>export setting</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";
        echo "<form method='post' enctype='multipart/form-data' action='settings.php".$GlobalArg."action=exportsave'>\n";       
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
        echo "<tr class='top'><td colspan='2'>Information</td></tr>\n";
        echo "<tr class='row1'><td colspan='2'>\n";
        echo "This script will create a single file (*.pmlset) with all the selected settings stored. If you think you have good and usuable settings, you can upload them on <a href='http://www.powermovielist.com'>www.powermovielist.com</a>, where you also find other settings to download.<br>
        You can select what settings you want to export:
        <ul>
            <li><b>property/field-settings:</b> Here you can define all the properties you want to enter for every movie. Located in the config->properties/fields.
            <li><b>list-settings:</b> The settings that are important for the design and not saved for every property.
            <li><b>css-file:</b> Minor changes to the design can be made here, like font settings, colours...
            <li><b>templates:</b> The whole layout of the list can be changed with template-files, create your own layout!
            <ul>
              <li><b>popup-tpl:</b> The template for the popup.
              <li><b>list-tpl:</b> The template for the list.
            </ul>
            <li><b>list-image:</b> the image on top of the list         
            <li><b>screenshot:</b> you could add a screenshot of your design - it will be listed at the design-download-page.
        </ul>
        <b>Note:</b> You can only export files that are saved under a different name than the standard-files!
        </td></tr>";
        echo "  <tr class='top'><td colspan='2'>export-options</td></tr>\n";
        echo "  <tr class='row1'><td align='right'><b>name of the setting:</b></td><td><input type='text' name='exName'></td></tr>\n";
        echo "  <tr class='row2'><td align='right'><b>short description:</b><br>(optional)</td><td><textarea name='exDesc' rows='6' cols='40'></textarea></td></tr>\n";
        echo "  <tr class='row1'><td align='right'><b>copyright-notice:</b><br>(optional)</td><td><input type='text' name='exCopy'></td></tr>\n";
        echo "  <tr class='top'><td colspan='2'>settings to export</td></tr>\n";
        if($Active!="index") {
            echo "  <tr class='row1'><td align='right'>properties</td><td><input type='checkbox' name='exProp' checked></td></tr>\n";
            echo "  <tr class='row2'><td align='right'>list-settings</td><td><input type='checkbox' name='exList' checked></td></tr>\n";
        }

        echo "  <tr class='row1'><td align='right'>css-file</td><td><input type='checkbox' name='exCss'";
        $StdVal = array("black.css", "blue.css", "default.css", "grayblue.css", "print.css", "spring.css", "white.css", "");        
        if(in_array($ActiveList['designcss'], $StdVal)) {
            echo " disabled> <font color='red'>a standard-file used, if you modified it save it under a new filename</font>";
        } else {
            echo " checked>";
        }
        echo "</td></tr>\n";

        if($Active!="index") {
            echo "  <tr class='row2'><td align='right'>popup-template</td><td><input type='checkbox' name='exPopUpTpl'";
            $StdVal = array("popup.tpl","");
            if(in_array($ActiveList['popuptpl'], $StdVal)) {
                echo " disabled> <font color='red'>a standard-file used, if you modified it save it under a new filename</font>";
            } else {
                echo " checked>";
            }
            echo "</td></tr>\n";
        }

        if($Active!="index") {
            echo "  <tr class='row1'><td align='right'>list-template</td><td><input type='checkbox' name='exListTpl'";
            $StdVal = array("list.tpl","");
            if(in_array($ActiveList['listtpl'], $StdVal)) {
                echo " disabled> <font color='red'>a standard-file used, if you modified it save it under a new filename</font>";
            } else {
                echo " checked>";
            }
            echo "</td></tr>\n";
        } else {
            echo "  <tr class='row1'><td align='right'>index-page-template</td><td><input type='checkbox' name='exListTpl'";
            $StdVal = array("index.tpl","");
            if(in_array($ActiveList['listtpl'], $StdVal)) {
                echo " disabled> <font color='red'>a standard-file used, if you modified it save it under a new filename</font>";
            } else {
                echo " checked>";
            }
            echo "</td></tr>\n";
        }

        echo "  <tr class='row2'><td align='right'>list-image</td><td><input type='checkbox' name='exImage' ";
        $StdVal = array("standard.gif", "divxlogo_white.gif", "divxlogo_white-1.gif", "divxlogo_black.gif", "divxlogo_black-1.gif", "divx-list.gif", "divx_blue.gif", "DivX - Logo 02.jpg", "DivX - Logo 01.jpg", "christian_logo_big.jpg");
        if(in_array($ActiveList['image'], $StdVal)) {
            echo " disabled> <font color='red'>a standard-file used, if you modified it save it under a new filename</font>";
        } else {
            echo " checked>";
        }
        echo "</td></tr>\n";
    
        echo "  <tr class='row2'><td align='right'><b>screenshot:</b><br>(optional)</td><td><input type='file' name='exScreenshot'></td></tr>\n";
        echo "  <tr class='row1'><td>&nbsp;</td><td><input type='submit' value='export'></td></tr>\n";
        echo "</table>\n";
        echo "</form>\n";
        break;
    case "exportsave":
        $ExportData = array();
        if($_POST['exName']=="") {         
            ErrorExit("no name for this setting defined!");
        }
        $ExportData['ExportVersion'] = $ExportSettingsVersion;
        $ExportData['Name'] = $_POST['exName'];
        $ExportData['Desc'] = $_POST['exDesc'];
        $ExportData['Copy'] = $_POST['exCopy'];

        if(isset($_POST['exProp'])) {
            LoadPropAll();
            $kProp=0;
            $kMovieProp=0;
            $kPropVal=0;
            $kPropFetch=0;
            foreach($PropAll as $Prop) {        
                $ExportData['prop'][$kProp] = array("Name"           => $Prop['Name'],
                                                    "SortOrder"      => $kProp,
                                                    "PropType"       => $Prop['PropType'],
                                                    "InTitle"        => $Prop['InTitle'],
                                                    "InProp"         => $Prop['InProp'],
                                                    "ShowInList"     => $Prop['ShowInList'],
                                                    "ListHeader"     => $Prop['ListHeader'],
                                                    "UseSort"        => $Prop['UseSort'],
                                                    "ListProperties" => $Prop['ListProperties'],
                                                    "Url"            => $Prop['Url'],
                                                    "ShowInPopUp"    => $Prop['ShowInPopUp'],
                                                    "ShowFilter"     => $Prop['ShowFilter'],
                                                    "ShowOnCover"    => $Prop['ShowOnCover'],
                                                    "ShowLinkType"   => $Prop['ShowLinkType'],
                                                    "RequiredRights" => $Prop['RequiredRights'],
                                                    "ShowAdd"        => $Prop['ShowAdd']);

                $strSql = "SELECT FetchScript, Settings FROM $CFG[Prefix]propfetch WHERE PropID=$Prop[ID] ORDER BY SortOrder";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
                    $ExportData['propfetch'][$kPropFetch]['PropKey'] = $kProp;
                    $ExportData['propfetch'][$kPropFetch]['FetchScript'] = $row['FetchScript'];
                    $ExportData['propfetch'][$kPropFetch]['Settings'] = $row['Settings'];
                    $kPropFetch++;
                }
				if($Prop['PropType'] < 100)
				{
					switch($Prop['PropType'])
					{
						case PML_PropType_Text:
						case PML_PropType_Date:
						case PML_PropType_Textfield:
						case PML_PropType_Url:
						case PML_PropType_UrlCached:
							$strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID=0";
							$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
							while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
								$ExportData['movieprop'][$kMovieProp]['PropKey'] = $kProp;
								$ExportData['movieprop'][$kMovieProp]['Property'] = $row['Property'];
								$kMovieProp++;
							}
							break;

						case PML_PropType_FileUpload:
						case PML_PropType_UserRating:
						case PML_PropType_DownloadLink:
						case PML_PropType_StaticText:
						case PML_PropType_DisplayNr:
						case PML_PropType_AutoIncrement:
						case PML_PropType_DownloadLinkFileUpload:
							//nothing to do
							break;

						case PML_PropType_Boolean:
						case PML_PropType_ListBox:
						case PML_PropType_ListBoxMulti:

							$strSql = "SELECT *
								FROM $CFG[Prefix]propval
								WHERE $CFG[Prefix]propval.PropID=$Prop[ID] ORDER BY SortOrder";
							$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
							$so=0;
							$PropValIDs = array();
							while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {    
								$so++;
								$ExportData['propval'][$kPropVal] = array("DisplayText"      => $row['DisplayText'],
																		  "DisplayTextShort" => $row['DisplayTextShort'],
																		  "DisplayTextHtml"  => $row['DisplayTextHtml'],
																		  "FetchText"        => $row['FetchText'],
																		  "Value"            => $row['Value'],
																		  "SortText"         => $row['SortText'],
																		  "SortOrder"        => $so);
								$ExportData['propval'][$kPropVal]['PropKey'] = $kProp;
								
								if($row['ID']==$Prop['StdFilterPropValID']) {
									$ExportData['prop'][$kProp]['StdFilterPropValKey'] = $kPropVal;
								}
								$PropValIDs[$row['ID']] = $kPropVal;

								$kPropVal++;
							}

							//get default-values:
							$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID=0";
							$r = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
							$r = mysql_fetch_row($r);
							$r = $r[0];
							if($Prop['PropType']==PML_PropType_ListBoxMulti) {
								if(substr($r, 0, 1)=="_") $r = substr($r, 1);
								if(substr($r, -1)=="_") $r = substr($r, 0, -1);
								$r = explode("_", $r);
							} else {
								$r = array($r);
							}
							foreach($r as $PropValID) {
								if(isset($PropValIDs[$PropValID])) $ExportData['moviepropval'][]['PropValKey'] = $PropValIDs[$PropValID];                        
							}
							break;
					}
				}
                $kProp++;
            }
        }

        if(isset($_POST['exList'])) {
            $ExportData['lists'] = array("showcounter"   => $ActiveList['showcounter'],                                      
                                         "showprint"     => $ActiveList['showprint'],
                                         "showchars"     => $ActiveList['showchars'],                                        
                                         "showsortlinks" => $ActiveList['showsortlinks'],
                                         "showsearch"    => $ActiveList['showsearch'],
                                         "showfilter"    => $ActiveList['showfilter'],
                                         "showperpage"   => $ActiveList['showperpage'],
                                         "allowcomments" => $ActiveList['allowcomments'],
                                         "marknew"       => $ActiveList['marknew'],                                      
                                         "StdPerPage"    => $ActiveList['StdPerPage'],
                                         "ShowOnIndex"   => $ActiveList['ShowOnIndex']);
        }
        
        if(isset($_POST['exCss'])) {
            $filename = "css/".$ActiveList['designcss'];
            if(FileExists($filename)) {
                $data="";
                $fp = fopen ($filename, "r");
                while(!feof($fp))
                    $data .= (fread($fp,1024));
                fclose ($fp); 
                $ExportData['css'] = $data;             
                $ExportData['files']['css'] = $ActiveList['designcss'];
            }
        }

        if(isset($_POST['exPopUpTpl'])) {
            $filename = "templates/popup/".$ActiveList['popuptpl'];
            if(FileExists($filename)) {
                $data="";
                $fp = fopen ($filename, "r");
                while(!feof($fp))
                    $data .= (fread($fp,1024));
                fclose ($fp); 
                $ExportData['popuptpl'] = $data;
                $ExportData['files']['popuptpl'] = $ActiveList['popuptpl'];
            }
        }

        if(isset($_POST['exListTpl'])) {
            if($Active=="index")
                $filename = "templates/index/".$ActiveList['listtpl'];
            else
                $filename = "templates/list/".$ActiveList['listtpl'];
            if(FileExists($filename)) {
                $data="";
                $fp = fopen ($filename, "r");
                while(!feof($fp))
                    $data .= (fread($fp,1024));
                fclose ($fp); 
                if($Active=="index") {
                    $ExportData['indextpl'] = $data;
                    $ExportData['files']['indextpl'] = $ActiveList['listtpl'];
                } else {
                    $ExportData['listtpl'] = $data;
                    $ExportData['files']['listtpl'] = $ActiveList['listtpl'];
                }
            }
        }
        
        if(isset($_POST['exImage'])) {
            $filename = "image/logos/".$ActiveList['image'];
            if(FileExists($filename)) {
                $data="";
                $fp = fopen ($filename, "rb");
                while(!feof($fp))
                    $data .= (fread($fp,1024));
                fclose ($fp); 
                $ExportData['image'] = $data;
                $ExportData['files']['image'] = $ActiveList['image'];
            }
        }

        if(($_FILES['exScreenshot']['name']!="")) {
            $filename = $_FILES['exScreenshot']['tmp_name'];

            if(FileExists($filename)) {
                $data="";
                $fp = fopen ($filename, "rb");
                while(!feof($fp))
                    $data .= (fread($fp,1024));
                fclose ($fp); 
                unlink($filename);
                $ExportData['screenshot'] = $data;
            }
        }
        
        $ExportData['version'] = $Version;
        $ExportData['VerBuild'] = $VerBuild;
        
        $output = serialize($ExportData);
        //$output = gzencode($output);

        //get a better filename:
        $Dat = str_replace(" ", "_", $_POST['exName']);
        $Dat = preg_replace("([^a-zA-Z0-9\\-._]*)","",$Dat);

        //send the file
        SendDownloadFile($output, "$Dat.pmlset", true);
                
        exit;
        break;
    default:
        echo "invalid action";
        break;
}

include("bottom.html");
?>