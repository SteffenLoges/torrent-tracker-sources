<?php
/** powermovielist edit properties/fields
 * $Id: editprop.php,v 1.16 2005/12/16 13:43:18 niko Exp $
*/
$FILE_SELF = "editprop.php";
$LoadSmarty=true;
include_once("application.php");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

if($Active=="index") {
    ErrorExit("not avaliable for index-page");
}

$Title = $strProperty;
$TitlePl = $strProperties;
$Table = $CFG['Prefix'] . "prop";

$_GET['F'] = $ActiveList['ID'];
$Filter = "ListID";
$FilterVal = $_GET['F'];

$SortOrderField = "SortOrder";

$SessionVar = "editprop";

$EncType = "multipart/form-data"; //file-uploads can be used...

$i=0;
$Show[$i]['name'] = "Name";
$Show[$i]['type'] = "username";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = $strFieldname;
$Show[$i]['comm'] = $strUsedForTemplates . " - should not be translated!";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = true;
$Show[$i]['invalid'] = "ListName;ListTitle;ListID;DateAdded;TimeAdded;ID;UserID;UserName;UserComments";
$i++;
$Show[$i]['name'] = "PropType";
$Show[$i]['type'] = "listbox";
$PropTypeIDs = explode(";","0;15;1;2;3;4;5;6;7;8;9;10;16;-1;11;13");
$PropTypeTexts = explode(";","Text;Auto-Increment Number;Date;Boolean;ListBox;ListBoxMulti;Textfield;Url;cached Url;File-Upload;User-Rating;Download-Link;Download-Link with File-Upload;---;Static Text;Nr in List");

//add CustomPropTypes
foreach($CFG['CustomPropTypes'] as $k=>$prop) {
    $PropTypeIDs[] = $k;
	$PropTypeTexts[] = $prop['name'];
}

//delete all prop-types from the CFG['DisablePropTypes'] config
foreach($CFG['DisablePropTypes'] as $PropType) {
	$Pos = array_search($PropType, $PropTypeIDs);
	if($Pos!==false) {
		unset($PropTypeIDs[$Pos]);
		unset($PropTypeTexts[$Pos]);
	}
}
$Show[$i]['values'] = implode(";",$PropTypeIDs);
$Show[$i]['prop'] = implode(";",$PropTypeTexts);
$Show[$i]['text'] = $strPropertyType;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "0";
if($action=="edit" || $action=="editsave")
	$Show[$i]['tags'] = " onChange=\"document.forms.frmEdit.action='editprop.php".$GlobalArg."F=$FilterVal&action=editsave&nextaction=edit&ID=$ID'; document.forms.frmEdit.submit();\"";
$i++;
$Show[$i]['name'] = "InTitle";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "20";
$Show[$i]['text'] = $strFieldTitle;
$Show[$i]['comm'] = $strEditPropInTitleComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$i++;
$Show[$i]['name'] = "ShowAdd";
$Show[$i]['type'] = "checkbox";
$Show[$i]['prop'] = "1;0";
$Show[$i]['text'] = "Show when adding entry";
$Show[$i]['comm'] = "(when editing all properties are shown)";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "1";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_AutoIncrement.";".PML_PropType_DownloadLink.";".PML_PropType_DownloadLinkFileUpload;
$i++;
$Show[$i]['name'] = "InProp";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "20";
$Show[$i]['text'] = $strEditPropInProp;
$Show[$i]['comm'] = $strEditPropInPropComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_UserRating.";".PML_PropType_DownloadLink.";".PML_PropType_AutoIncrement.";".PML_PropType_DownloadLinkFileUpload;
$i++;
$Show[$i]['name'] = "RequiredRights";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = "0^1^2^3^4^5^6^-1";
$Show[$i]['prop'] = implode("^", $strUserRights)."^$strShowOnlyToLoggedInUsers";
$Show[$i]['delemiter'] = "^";
$Show[$i]['text'] = $strRequiredUserRightsToSeeProp; //"required user-rights to see and edit this property";
$Show[$i]['comm'] = "($strPropRequiredRightsComm)";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$i++;
$Show[$i]['name'] = "ShowInList";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = "0;1;2";
$Show[$i]['prop'] = "don't show;show;load only";
$Show[$i]['text'] = $strShowInList;
$Show[$i]['comm'] = $strEditPropShowInListComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$Show[$i]['tags'] = " onChange='EnableListItems();'";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_UserRating.";".PML_PropType_StaticText.";".PML_PropType_DisplayNr.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_AutoIncrement.";".implode(";", array_keys($CFG['CustomPropTypes']));
$i++;
$Show[$i]['name'] = "ListHeader";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "15";
$Show[$i]['text'] = $strEditPropHeaderText;
$Show[$i]['comm'] = $strEditPropHeaderTextComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_UserRating.";".PML_PropType_StaticText.";".PML_PropType_DisplayNr.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_AutoIncrement.";".implode(";", array_keys($CFG['CustomPropTypes']));
$i++;
$Show[$i]['name'] = "UseSort";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = "0;1;2";
$Show[$i]['prop'] = $strUseSortingStrings; //don\'t use;use, default ASC;use, default DESC
    if($action=="edit" || $action=="editsave") {
        $strSql = "SELECT PropType FROM $CFG[Prefix]prop WHERE ID=$ID";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $row = mysql_fetch_array($result, MYSQL_ASSOC);
        if($row['PropType']==PML_PropType_Text) { //only when text then add the sort-by-number
            $Show[$i]['values'] .= ";3;4";
            $Show[$i]['prop'] .=";".$strUseSortingByNumber; // sort by number, default ascending;sort by number, default descending
        }
    }
$Show[$i]['text'] = $strUseSorting;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_UserRating.";".PML_PropType_AutoIncrement.";".implode(";", array_keys($CFG['CustomPropTypes']));
$i++;
$Show[$i]['name'] = "ListProperties";
$Show[$i]['type'] = "text";
$Show[$i]['text'] = $strEditPropListProp;
$Show[$i]['comm'] = $strEditPropListPropComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['prop'] = "50";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_UserRating.";".PML_PropType_StaticText.";".PML_PropType_DisplayNr.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_AutoIncrement.";".implode(";", array_keys($CFG['CustomPropTypes']));
$i++;
$Show[$i]['name'] = "ShowLinkType";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = "0;1;2;3";
$Show[$i]['prop'] = "open url in same page;open url in new page;show url as image;show only url";
$Show[$i]['text'] = $strHowToShowTheUrlInTheList;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload;
$Show[$i]['hidenew'] = true;
$i++;
$Show[$i]['name'] = "ImageSize";
$Show[$i]['type'] = "imagesize";
$Show[$i]['text'] = "Image-Size";
$Show[$i]['comm'] = "(fetched/uploaded images will be resized)";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_UrlCached.";".PML_PropType_FileUpload;
$Show[$i]['hidenew'] = true;
$i++;
$Show[$i]['name'] = "Url";
$Show[$i]['type'] = "text";
$Show[$i]['text'] = $strUrlForLinkInList;
$Show[$i]['comm'] = $strEditPropUrlComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "";
$Show[$i]['prop'] = "40";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_UserRating.";".PML_PropType_StaticText.";".PML_PropType_DisplayNr.";".PML_PropType_AutoIncrement.";".implode(";", array_keys($CFG['CustomPropTypes']));
$i++;
$Show[$i]['name'] = "ShowFilter";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = "0;1;2;3;4";
$Show[$i]['prop'] = $strEditPropShowFilterStrings; //"don't show filter;show listbox;filter with search-text-function;use Chars on top of the list;use with search AND chars";
if($action=="edit") {
	$strSql = "SELECT PropType FROM $CFG[Prefix]prop WHERE ID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	if($row['PropType']!=PML_PropType_ListBox && $row['PropType']!=PML_PropType_ListBoxMulti && $row['PropType']!=PML_PropType_Boolean) {
		$Show[$i]['values'] = "0;2;3;4";
		$Show[$i]['prop'] = $strEditPropShowFilterStrings2; //"don\'t show filter;filter with search-text-function;use Chars on top of the list;use with search AND chars";
	}
}
$Show[$i]['text'] = $strShowFilterField;
$Show[$i]['comm'] = "($strEditPropFilterComm)";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_AutoIncrement;
if($action=="edit" || $action=="editsave") {
    $i++;
    $Show[$i]['name'] = "StdFilterPropValID";
    $Show[$i]['type'] = "listbox";
    $Show[$i]['values'] = "0;";
    $Show[$i]['prop'] = "all;";
    $strSql = "SELECT ID,DisplayText FROM $CFG[Prefix]propval WHERE PropID=$ID";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $Show[$i]['values'].="$row[ID];";
        $Show[$i]['prop'].=str_replace(';', '', $row['DisplayText']).";";
    }
    $Show[$i]['values'] = substr($Show[$i]['values'], 0, -1);
    $Show[$i]['prop'] = substr($Show[$i]['prop'], 0, -1);
    $Show[$i]['text'] = "standard-value for filter-listbox";
    $Show[$i]['comm'] = "";
    $Show[$i]['main'] = false;
    $Show[$i]['def'] = "0";
    $Show[$i]['showonlyfld'] = "ShowFilter";
    $Show[$i]['showonlyval']=PML_ShowFilter_Listbox;
}
$i++;
$Show[$i]['name'] = "ShowInPopUp";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = "0;1;2;3;4";
$Show[$i]['prop'] = $strEditPropPopUpStrings; //"don't show;displayed together with all the other properties;displayed as extra field like plot or user-rating;displayed with download-links;displayed with covers";
$Show[$i]['text'] = $strShowInPopUp;
$Show[$i]['comm'] = $strEditPropPopUpComm;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_UserRating.";".PML_PropType_DownloadLink.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_AutoIncrement.";".PML_PropType_DownloadLinkFileUpload.";".implode(";", array_keys($CFG['CustomPropTypes']));
if($CFG['EnableCoverCreate']) {
	$i++;
	$Show[$i]['name'] = "ShowOnCover";
	$Show[$i]['type'] = "listbox";
	$Show[$i]['values'] = "0;1;2;3;4;5;6;7";
	$Show[$i]['prop'] = $strEditPropCoverStrings.";show on the side as index-nr"; //"don't show;show as normal text;show on the side as title;shown on the side as langauge;show on the side as format;show as picture (url or file!);show as format-logo and on the side as text";
	$Show[$i]['text'] = $strShowOnCover;
	$Show[$i]['comm'] = "";
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "0";
	$Show[$i]['showonlyfld'] = "PropType";
	$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_UserRating.";".PML_PropType_AutoIncrement.";".implode(";", array_keys($CFG['CustomPropTypes']));	
}
$i++;
$Show[$i]['name'] = "PropVal";
$Show[$i]['type'] = "func";
$Show[$i]['text'] = $strValues;
$Show[$i]['comm'] = "";
$Show[$i]['func'] = "printEditPropVal";
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;
$Show[$i]['hide'] = true;
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Boolean;
$i++;
$Show[$i]['name'] = "Fetch";
$Show[$i]['type'] = "func";
$Show[$i]['text'] = "FetchScripts";
$Show[$i]['comm'] = "";
$Show[$i]['func'] = "printEditPropFetch";
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;
$Show[$i]['hide'] = true;
$Show[$i]['showonlyfld'] = "PropType";
$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload;
$i++;
if($action!="add" && $action!="addsave") {
	$Show[$i]['name'] = "Default";
	$Show[$i]['type'] = "funcall";
	$Show[$i]['func'] = "PrintDefault";
	$Show[$i]['main'] = true;
	if($action=="edit") {
		$strSql = "SELECT PropType FROM $CFG[Prefix]prop WHERE ID=$ID";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_array($result, MYSQL_ASSOC);
		switch($row['PropType']) {		
			case PML_PropType_Text: // Text
			case PML_PropType_Date: //Date
			case PML_PropType_Boolean: //Boolean
			case PML_PropType_ListBox: //ListBox
			case PML_PropType_ListBoxMulti: //ListBoxMulti
			case PML_PropType_Textfield: //Textfield
			case PML_PropType_Url: //Url
			case PML_PropType_UrlCached: //Url,Cached
			case PML_PropType_FileUpload: //File-Upload!
			case PML_PropType_UserRating: //User-Rating
			case PML_PropType_DownloadLink: //Download-Link			
            case PML_PropType_DownloadLinkFileUpload:
				$Show[$i]['text'] = $strDefaultValue;
				break;
			case PML_PropType_StaticText: //Static Text
				$Show[$i]['text'] = $strText;
				break;
		}
	} else {
		$Show[$i]['text'] = $strDefaultValue;
	}
	$Show[$i]['comm'] = "($strSelectedWhenAddingNewEntries)";	
	$Show[$i]['showonlyfld'] = "PropType";
	$Show[$i]['showonlyval']=PML_PropType_Text.";".PML_PropType_Date.";".PML_PropType_Boolean.";".PML_PropType_ListBox.";".PML_PropType_ListBoxMulti.";".PML_PropType_Textfield.";".PML_PropType_Url.";".PML_PropType_UrlCached.";".PML_PropType_FileUpload.";".PML_PropType_DownloadLink; //DownloadLinkFileUpload has no standard-value
}



RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

if($action=="add" || $action=="edit") {
$JavaScriptText = "
function EnableListItems() {
	if(document.forms.frmEdit.ShowInList.value==0) {//doN't show
        if(document.forms.frmEdit.ListHeader) document.forms.frmEdit.ListHeader.disabled = true;
        //if(document.forms.frmEdit.UseSort) document.forms.frmEdit.UseSort.disabled = true;
        if(document.forms.frmEdit.ListProperties) document.forms.frmEdit.ListProperties.disabled = true;
        if(document.forms.frmEdit.Url) document.forms.frmEdit.Url.disabled = true;
        //if(document.forms.frmEdit.ShowFilter) document.forms.frmEdit.ShowFilter.disabled = true;
        //if(document.forms.frmEdit.ShowLinkType) document.forms.frmEdit.ShowLinkType.disabled = true;
    } else if(document.forms.frmEdit.ShowInList.value==1) {//show
        if(document.forms.frmEdit.ListHeader) document.forms.frmEdit.ListHeader.disabled = false;
        //if(document.forms.frmEdit.UseSort) document.forms.frmEdit.UseSort.disabled = false;
        if(document.forms.frmEdit.ListProperties) document.forms.frmEdit.ListProperties.disabled = false;
        if(document.forms.frmEdit.Url) document.forms.frmEdit.Url.disabled = false;
        //if(document.forms.frmEdit.ShowFilter) document.forms.frmEdit.ShowFilter.disabled = false;
        //if(document.forms.frmEdit.ShowLinkType) document.forms.frmEdit.ShowLinkType.disabled = false;
    } else if(document.forms.frmEdit.ShowInList.value==2) {//load only
		if(document.forms.frmEdit.ListHeader) document.forms.frmEdit.ListHeader.disabled = true;
		//if(document.forms.frmEdit.UseSort) document.forms.frmEdit.UseSort.disabled = true;
		if(document.forms.frmEdit.ListProperties) document.forms.frmEdit.ListProperties.disabled = true;
		if(document.forms.frmEdit.Url) document.forms.frmEdit.Url.disabled = true;
		//if(document.forms.frmEdit.ShowFilter) document.forms.frmEdit.ShowFilter.disabled = true;
        //if(document.forms.frmEdit.ShowLinkType) document.forms.frmEdit.ShowLinkType.disabled = true;
	}
}
";

$OnLoad = "EnableListItems();";

}


if($action=="editsave" || $action=="addsave") {
	if(in_array($_POST['PropType'], $CFG['DisablePropTypes'])) {
		ErrorExit("This PropType is disabled!");
	}
}


$DOC_TITLE = $strPropertiesFields;
include("top.html");		

if($action=="editsave" || $action=="delsave")
{
	$strSql = "SELECT ID, PropType, Name FROM $CFG[Prefix]prop WHERE ID='$_GET[ID]'";
	$query = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$oldProp = mysql_fetch_assoc($query);
}

include("edit.php");

if($action=="addsave") {
	if($_POST['PropType']==PML_PropType_Boolean) {
		$strSql = "INSERT INTO $CFG[Prefix]propval (PropID, DisplayText, DisplayTextShort, Value, SortOrder) VALUES ($ID, 'yes','yes', 1, 1)";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

		$strSql = "INSERT INTO $CFG[Prefix]propval (PropID, DisplayText, DisplayTextShort, Value, SortOrder) VALUES ($ID, 'no','no', 0, 2)";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}
}

//new db-structure
if($action=="addsave")
{
	LoadPropAll();
	$fieldType = getFieldTypeByPropType($PropAll[$ID]['PropType']);
    $name = $_POST['Name'];
	if(is_array($fieldType)) {
		foreach($fieldType as $field=>$typ) {
			$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] ADD `{$name}_{$field}` $typ NOT NULL";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		}
	} else if($fieldType!="") {
		$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] ADD `$name` $fieldType NOT NULL";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}

}
elseif($action=="editsave")
{
	LoadPropAll();
	$fieldType = getFieldTypeByPropType($PropAll[$ID]['PropType']);
	$oldFieldType = getFieldTypeByPropType($oldProp['PropType']);
	$oldName = $oldProp['Name'];
    $name = $_POST['Name'];

	if($PropAll[$ID]['PropType']!=$oldProp['PropType'] || $oldName!=$PropAll[$ID]['Name'])
	{
		if(is_array($fieldType) && $PropAll[$ID]['PropType']==$oldProp['PropType']) {
			//fieldType is array (DownloadLink) and PropType didn't change
			//just rename fields:
			foreach($fieldType as $field=>$typ) {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] CHANGE `$oldName_$field` `{$name}_{$field}` $typ NOT NULL"; 
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			}
		} elseif (is_array($fieldType)) {
			//fieldType is array (DownloadLink) and PropType changed too
			//delete old fields and add new fields
			if(is_array($oldFieldType)) {
				foreach($oldFieldType as $field=>$typ) {
					$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `$oldName_$field`";
					pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				}
			} else if($oldFieldType!="") {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `$oldName`";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			}
			foreach($fieldType as $field=>$typ) {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] ADD `{$name}_{$field}` $typ NOT NULL";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			}
		} elseif(is_array($oldFieldType)) {
			//oldFieldType is array and fieldType NOT
			//dlete old fields and add new one
			foreach($oldFieldType as $field=>$typ) {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `$oldName_$field`";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			}
			$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] ADD `$name` $fieldType NOT NULL"; 
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		} else {
			//no arrays anywhere, just rename the field
			if($name=="" && $oldName=="") {
			} else if($name=="") {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `$oldName`"; 
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			} else if($oldName=="") {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] ADD `$name` $fieldType NOT NULL"; 
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			} else {
				$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] CHANGE `$oldName` `$name` $fieldType NOT NULL"; 
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			}
		}
	}
}
elseif($action=="delsave")
{
	$oldFieldType = getFieldTypeByPropType($oldProp['PropType']);
	$oldName = $oldProp['Name'];
	if(is_array($oldFieldType)) {
		foreach($oldFieldType as $field=>$typ) {
			$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `$oldName_$field`";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		}
	} else if($oldFieldType!="") {
		$strSql = "ALTER TABLE $CFG[Prefix]movies_$ActiveList[name] DROP `$oldName`";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}
}

//clear the smarty cache for this list
if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$smarty->clear_cache(null,"list|$Active");
	$smarty->clear_cache(null,"poup|$Active");    
}

//delete the propval entries:
if($action=="delsave") {
	$strSql = "DELETE FROM $CFG[Prefix]propval WHERE PropID=$ID";
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
}


if(isset($_GET['nextaction'])) {
	$_GET['action'] = $_GET['nextaction'];
	$action = $_GET['nextaction'];
	include("edit.php");
	include("bottom.html");
	exit;
}

if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$action = "";
	$_GET['action'] = $action;
	include("edit.php");
	include("bottom.html");
	exit;
}

include("bottom.html");

function PrintDefault($PropID,$action="") {
global $CFG, $pmldb, $FilterVal, $ActiveList;
	switch($action) {
		case "":
			$strSql = "SELECT * FROM $CFG[Prefix]prop WHERE ID=$PropID";
			$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$Prop = mysql_fetch_array($result, MYSQL_ASSOC);

			if($Prop['PropType']==PML_PropType_ListBox || $Prop['PropType']==PML_PropType_Boolean) {
				$strSql = "SELECT pv.DisplayText FROM $CFG[Prefix]movies_$ActiveList[name] m, $CFG[Prefix]propval pv WHERE pv.ID=m.`$Prop[Name]` AND m.MovieID=0";
				$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$row = mysql_fetch_array($result, MYSQL_ASSOC);
				$Dat = $row['DisplayText'];
				return($Dat);
			} elseif($Prop['PropType']==PML_PropType_ListBoxMulti) {
				$strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID=0";
				$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$row = mysql_fetch_array($result, MYSQL_ASSOC);
				$Sel = $row['Property'];
				if(substr($Sel, 0, 1)=="_") $Sel = substr($Sel, 1);
				if(substr($Sel, -1)=="_") $Sel = substr($Sel, 0, -1);
				$Sel = explode("_", $Sel);
				$strSql = "SELECT DisplayText FROM $CFG[Prefix]propval WHERE ID IN ('".implode("', '", $Sel)."')";
				$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$ret = "";
				while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
					$ret .= $row['DisplayText'].", ";
				}
				$ret = substr($ret, 0, -2);
				return($ret);
			
			} elseif($Prop['PropType']==PML_PropType_DownloadLinkFileUpload || $Prop['PropType']==PML_PropType_DownloadLink) {
				$strSql = "SELECT `$Prop[Name]_link` AS Link FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID=0";
				$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$row = mysql_fetch_array($result, MYSQL_ASSOC);
				return($row['Link']);                
            } else {
				$strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID=0";
				$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$row = mysql_fetch_array($result, MYSQL_ASSOC);
				return($row['Property']);
			}
		case "edit":
			$strSql = "SELECT * FROM $CFG[Prefix]prop WHERE ID=$PropID";
			$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$Prop = mysql_fetch_array($result, MYSQL_ASSOC);
			if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_UserRating || $Prop['PropType']==PML_PropType_DisplayNr || in_array($Prop['PropType'], array_keys($CFG['CustomPropTypes']))) continue;
			PrintEditEntryProp($Prop, 0); //0 for default-entry!!!
			break;
		case "editsave":
			$strSql = "SELECT *	FROM $CFG[Prefix]prop
				WHERE $CFG[Prefix]prop.ID = $PropID
				ORDER BY $CFG[Prefix]prop.SortOrder";
			$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$Prop = mysql_fetch_array($result, MYSQL_ASSOC);

			if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_UserRating  || $Prop['PropType']==PML_PropType_DisplayNr || in_array($Prop['PropType'], array_keys($CFG['CustomPropTypes']))) continue;
			SaveEditEntryProp($Prop, 0); //0 for default-entry!!!
			break;
		case "addsave":
		case "add":
			//don't display anything here!
			break;
	} //end swtich $action
}

function printEditPropFetch($ID) {
    global $GlobalArg,$CFG, $pmldb;
    $strSql = "SELECT * FROM $CFG[Prefix]propfetch WHERE PropID='$ID' ORDER BY SortOrder";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $fs="";
    while($row=mysql_fetch_assoc($result)) {
        $fs .= $row['FetchScript'].", ";
    }    
    if($fs=="")
        $fs="none";
    else
        $fs=substr($fs,0,-2); //trim the ", "
    if(strlen($fs)>20)
        $fs = substr($fs,0,20)."...";
    $fs = "(".$fs.")";
    echo "<a href=\"editpropfetch.php".$GlobalArg."action=&F=$ID\">FetchScripts</a> $fs";
}

function printEditPropVal($ID) {
    global $GlobalArg,$CFG, $pmldb;
    $strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID='$ID' ORDER BY SortOrder";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $fs="";
    while($row=mysql_fetch_assoc($result)) {
        $fs .= $row['DisplayTextShort'].", ";
    }    
    if($fs=="")
        $fs="none";
    else
        $fs=substr($fs,0,-2); //trim the ", "
    $fs = trim($fs);
    if(strlen($fs)>20)
        $fs = substr($fs,0,20)."...";
    $fs = "(".$fs.")";
    echo "<a href=\"editpropval.php".$GlobalArg."action=&F=$ID\">$GLOBALS[strValues]</a> $fs";
}

?>