<?php
/** powermovielist delold
 * $Id:

delete entries in your list that are older than 31 days
protect this file - it must not be called from any browser...
could be executed as a cronjob...
this script deletes from ALL lists!!

*/

die("you must first disable the die-line to activate this script"); //for security-reasons


include("functions.php");

//how old the entries can be maximal
$daysold = 31;

//location where the PowerMovieList is installed - ../ by default when script runs in scripts/
//relative path no absolute! without / at the end!
$PmlDir = "..";






include("$PmlDir/config.inc.php");
include("$PmlDir/lang/english.inc.php");
include("$PmlDir/functions.php");

ConnectDatabase();


$strSql = "SELECT * FROM $CFG[Prefix]movies WHERE DateAdded < NOW()-".(1000000*$daysold);
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
while($row=mysql_fetch_assoc($result)) {
	$ID = $row['ID'];

	$strSql = "DELETE FROM " . $CFG['Prefix'] . "movies WHERE ID=$ID";
	mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	$strSql = "DELETE FROM " . $CFG['Prefix'] . "movieprop WHERE MovieID=$ID";
	mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	$strSql = "DELETE FROM " . $CFG['Prefix'] . "moviepropval WHERE MovieID=$ID";
	mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	$strSql = "DELETE FROM $CFG[Prefix]movielink WHERE MovieID=$ID";
	mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	$strSql = "DELETE FROM " . $CFG['Prefix'] . "votes WHERE MovieID=$ID";
	mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	$strSql = "DELETE FROM " . $CFG['Prefix'] . "comment WHERE MovieID=$ID";
	mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
}

?>