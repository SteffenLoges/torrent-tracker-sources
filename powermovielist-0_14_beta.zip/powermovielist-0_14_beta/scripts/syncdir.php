<?php
/** powermovielist syncdir
 * $Id:

sync files with the database!
protect this file - it must not be called from any browser...
could be executed as a cronjob...

*/

die("you must first disable the die-line to activate this script"); //for security-reasons


//** standard-settings *************************************************************************************
//display messages? (false for cronjobs)
$Verbose = true;

//location where the PowerMovieList is installed - ../ by default when script runs in scripts/
//relative path no absolute! without / at the end!
$PmlDir = "..";

//use sub-directories?
$UseSubDirs = true;

//check if files are deleted and then set the deleted-flag
//the entries won't be removed by this script (too dangerous :D) - call deldir.php to do that...
$UseDeleteFlag = true;
$DeleteFlagField = "deleted"; //has to be a field with type "checkbox"!

//array of all directories that should be synced (only works for local files!!)
//note: on windoof you can use '/' or '\' but '\' must be written as '\\'
//      on unix just use '/'...
$DirList = array("D:\\Moviez");

//valid file-extensions (all other files will be ignored)
$FileExt = array(".avi", ".dat", ".mpg", ".mpeg");

//List that should be synced
$ListName = "testlist";

//property where the filename will be saved (has to be created in properties/fields config as a text-property)
$FileNameField = "FileName";

//** multipe files-settings **********************************************************************************
//when one entry _could_ consist of several files, the script can detect this. all files must be named in the same way
//this detection is done by a reg-expr. the one used here works for files named "filename CD 1.avi", "filename Cd 2.avi", "filename CD3.avi"
$MultipleFilesReg = "/([^\\\\\\/]+) CD ?[0-9]+\\.([^\\.]+)$/i";

//some properties about the MultipleFiles can be written into the db - will only be used if the defined fields exist in the db
$MultipleFilesFoundField = "CDs"; //number of files found
$MultipleFileNamesFields = array("Link1", "Link2", "Link3", "Link4"); //every file will be written into one field ONLY WORKS FOR DOWNLOAD-LINKS!
$MultipleFileNamesPrefix = array("\\\\Niko-mobile\Moviez"=>"file:\\\\Niko-mobile\\Moviez"); //if the urls should be clickable you can here redefine the used prefix
                                                                    //you can use windows-share-style (file:\\Server\) or http-paths
                                                                    //remember: \ must be written as \\ - but in most cases / will work too...

//** additional properties/fields ****************************************************************************
//to write additional properties/fields into the database define here a regular expression:
//you could write our own reg-expr. to fetch items like language, format, quality etc...
//to disable set $WritePropFields = array();

//standard-reg-expr: 
//get the just file-name: (when all files in ONE directory)
$WritePropReg = "/[\\\\|\\/]([^\\/\\\\]+)\\.[^\\.]+$/";

//alternative reg-exppr (uncomment line to aktivate):
//gets the file-name without extension, and without ' CD 1'
//this one has to be enabled ADDITIONAL to another $WritePropReg
//it will be used when more than one file was found, else the WritePropReg will be used
$WritePropRegMultiFiles = "/[\\\\|\\/]([^\\\\\\/]+) CD ?[0-9]+\\.[^\\.]+$/i";

//alternative reg-exppr (uncomment line to aktivate):
//get the name of the directory (the highest level!): (when every entry is in one sub-directory)
//$WritePropReg = "/[\\\\|\\/]([^\\/\\\\]+)[\\\\|\\/][^\\/\\\\]+$/";

//in what field will there items from the reg-expr. filled in?
//the key equal to the key of the result of the reg-expr will be used
$WritePropFields = array(1=>"Title");

/*******************************************************************************************************/
//normally you don't have to modify anything below this line...
//perhaps you just have to adept the 3 include-lines



if($Verbose) {
    $StartTime = microtime();
    $DirPrefix = $PmlDir."/";
    $DOC_TITLE = "SyncDir";
    include("$PmlDir/top.html");
    echo "PowerMovieList - SyncDir<br>";
    echo "Sync the list with your harddisk!<br>";
    echo "for configuration open syncdir.php<br><br>";
}

$Active=$ListName;
include("$PmlDir/config.inc.php");
include("$PmlDir/lang/english.inc.php");
include("$PmlDir/functions.php");

ConnectDatabase();

set_time_limit(0);

//get FileNameField-PropID and ListID
$strSql = "SELECT $CFG[Prefix]prop.ID as PropID, $CFG[Prefix]lists.ID as ListID
        FROM $CFG[Prefix]prop, $CFG[Prefix]lists
        WHERE $CFG[Prefix]prop.ListID=$CFG[Prefix]lists.ID
        AND $CFG[Prefix]lists.Name='$ListName'
        AND $CFG[Prefix]prop.Name='$FileNameField'
        AND $CFG[Prefix]prop.PropType=0"; //Text-Field
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
if(!mysql_num_rows($result)) die("ERROR: invalid FileNameField or ListName check config-section of this script");
$row = mysql_fetch_assoc($result);
$ListID = $row['ListID'];
$FileNamePropID = $row['PropID'];

if($UseDeleteFlag) {
    $strSql = "SELECT $CFG[Prefix]prop.ID
    FROM $CFG[Prefix]prop, $CFG[Prefix]lists
    WHERE $CFG[Prefix]lists.Name='$ListName'
    AND $CFG[Prefix]prop.Name='$DeleteFlagField'
    AND $CFG[Prefix]prop.PropType=2"; //PML_PropType_Boolean
    $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    if(!mysql_num_rows($result)) die("ERROR: UseDeletedFlag ist activated, but the field 'DeleteFlagField' ist not found or not a checkbox");
    $row = mysql_fetch_assoc($result);
    $DeleteFlagPropID = $row['ID'];

    $strSql = "SELECT pml_propval.ID FROM pml_propval WHERE Value=0 AND PropID=$DeleteFlagPropID";
    $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    if(!mysql_num_rows($result)) die("ERROR: UseDeletedFlag ist activated, but the field 'DeleteFlagField' doesn't have the right values for a checkbox (Value has to be 0 and 1)");
    $row = mysql_fetch_assoc($result);
    $DeleteFlagPropValID0 = $row['ID'];

    $strSql = "SELECT pml_propval.ID FROM pml_propval WHERE Value=1 AND PropID=$DeleteFlagPropID";
    $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    if(!mysql_num_rows($result)) die("ERROR: UseDeletedFlag ist activated, but the field 'DeleteFlagField' doesn't have the right values for a checkbox (Value has to be 0 and 1)");
    $row = mysql_fetch_assoc($result);
    $DeleteFlagPropValID1 = $row['ID'];
}

//read in all FileNames from the database
$strSql = "SELECT Property, MovieID
    FROM $CFG[Prefix]movieprop
    WHERE PropID=$FileNamePropID";
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$FileNames = array();
while($row=mysql_fetch_assoc($result)) {
    if($row['MovieID']==0) continue; //default value    
    $FileNames[$row['MovieID']] = $row['Property'];
}

//read in the deleted flags, if it is activated
if($UseDeleteFlag) {
    $strSql = "SELECT pml_moviepropval.MovieID, pml_propval.Value
    FROM pml_propval,pml_moviepropval
    WHERE pml_moviepropval.PropValID=pml_propval.ID
    AND pml_propval.PropID='$DeleteFlagPropID'";
    $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $FileNamesDelFlag = array();
    while($row=mysql_fetch_assoc($result)) {
        if($row['MovieID']==0) continue; //default value        
        $FileNamesDelFlag[$row['MovieID']] = $row['Value'];
    }
}

$FileCount=0;
$Files = array();
$MultipleFileRegRes = array();
$AllFilesMultipleFileRegRes = array();
foreach($DirList as $Dir) {    
    $Dat = getDirList($Dir, $UseSubDirs);
    foreach($Dat as $File) {
        if(is_dir($File)) continue; //skip directories
        $Found=false;
        foreach($FileExt as $Ext) {
            if($Ext==substr($File, -1*strlen($Ext))) {
                $Found=true;
                break;
            }
        }
               
        if(!$Found) continue; //invalid extension, skip

        $FileCount++;

        //in $AllFiles ALL found files will be saved
        $AllFiles[$FileCount] = $File;

        //here the AllFiles-multiple-ones are deleted again - if the first file
        //was allready read in (saved in $AllFilesMultipleFileRegRes are the resulsts from the preg_mtach)
        if(preg_match($MultipleFilesReg, $File, $x)) {
            unset($x[0]);
            if(in_array($x, $AllFilesMultipleFileRegRes)) {
                unset($AllFiles[$FileCount]);
            } else {
                $AllFilesMultipleFileRegRes[] = $x;
            }
        }                    
        
        //same as above, but ONLY for the files FOUND in the database (so the others belonging to the one found can be removed too)
        if(in_array($File, $FileNames)) {
            if(preg_match($MultipleFilesReg, $File, $x)) {
                unset($x[0]);
                $MultipleFileRegRes[] = $x;
            }
            continue; //allready in database, skip
        }

        //in $Files only the new ones will be saved (the ones who are not in the database...)
        $Files[$FileCount] = $File;
    }
}

//delete the multiple-files that are allready read in with the others
foreach($Files as $k=>$i) {    
    if(preg_match($MultipleFilesReg, $i, $x)) {
        unset($x[0]);        
        foreach($MultipleFileRegRes as $Dat) {            
            if($Dat==$x) {
                unset($Files[$k]);                
            }
        }
    }
}

$DeleteFlagResetCount=0;
if($UseDeleteFlag) {
    foreach($AllFiles as $k=>$i) {
        $MovieID=array_search($i, $FileNames);
        if($MovieID!=0) {
            if($FileNamesDelFlag[$MovieID]==1) { //deleted-flag is set- unset it now
                $strSql = "DELETE FROM pml_moviepropval WHERE MovieID='$MovieID' AND (PropValID='$DeleteFlagPropValID0' OR PropValID='$DeleteFlagPropValID1')";
                mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $strSql = "INSERT INTO pml_moviepropval (PropValID, MovieID) VALUES ('$DeleteFlagPropValID0', '$MovieID')";
                mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $DeleteFlagResetCount++;
                echo "reset deleted-flag for $MovieID<br>\n";
                continue; //allreay in database - skip
            }
        }
    }
}

$DeleteFlagSetCount=0;
if($UseDeleteFlag) {        
    foreach($FileNames as $MovieID=>$Dat) {                
        if(in_array($Dat, $Files)) continue; //this file isn't in the database, skip it (will be added within this script-run)        
        if(!in_array($Dat, $AllFiles)) {
            if($FileNamesDelFlag[$MovieID]) continue; //flag allready set
            //set the deleted flag...      
            $strSql = "DELETE FROM pml_moviepropval WHERE MovieID='$MovieID' AND (PropValID='$DeleteFlagPropValID0' OR PropValID='$DeleteFlagPropValID1')";
            mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);            
            $strSql = "INSERT INTO pml_moviepropval (PropValID, MovieID) VALUES ('$DeleteFlagPropValID1', '$MovieID')";
            mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $DeleteFlagSetCount++;
            echo "set deleted-flag for $MovieID<br>\n";
        }
    }
}

if($Verbose) {
    echo $FileCount . " Files found...<br>\n";
    if(count($Files)) {
        echo count($Files) . " new ones...<br>\n";
    } else {
        echo "no new ones...<br>\n";
    }
    if($DeleteFlagResetCount) {
        echo "delete-flag reseted $DeleteFlagResetCount times...<br>\n";
    }
    if($DeleteFlagSetCount) {
        echo "$DeleteFlagSetCount files from the database not found, set the delete-flag...<br>\n";
    }
}

while(count($Files)) {    
    $File = reset($Files);
    $FileKey = key($Files);

    $AddFiles = array();
    //serach for multiple files
    if(preg_match($MultipleFilesReg, $File, $x)) {
        unset($x[0]);
        foreach($Files as $k=>$i) {
            if($FileKey==$k) continue; //skip current file
            preg_match($MultipleFilesReg, $i, $y);
            unset($y[0]);
            if($x!=$y) continue;
            $AddFiles[] = $Files[$k];
            unset($Files[$k]);
        }
    }


    //insert the new file into the database:
    $strSql = "INSERT INTO $CFG[Prefix]movies (ListID, DateAdded) VALUES ($ListID, '" .date("Y-m-d h:m:s")."')";
    mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $MovieID = mysql_insert_id();

    LoadPropAll($ListID);

    //load stndard-values for ALL fields (some will be overwritten later on)
    foreach($PropAll as $Prop) {
        switch($Prop['PropType']) {
            case PML_PropType_Text: //Text
            case PML_PropType_Date: //Date
            case PML_PropType_DownloadLink: //Download-Link	
            case PML_PropType_Textfield: //Textfield
            case PML_PropType_Url: //Url
            case PML_PropType_UrlCached: //cached Url
            case PML_PropType_FileUpload: //File-Upload
            case PML_PropType_AutoIncrement:
            case PML_PropType_DownloadLinkFileUpload:
                $Val = GetStandardValue($Prop);

                if($Prop['PropType']==PML_PropType_UrlCached) { //cached Url
                    $Dat = GetFileName($Val,true);
                    if($Dat!="") {            			
                        $FileName = $CFG['CacheDir'] . $MovieID."-".$Prop['ID']."-".$Dat;
                        if(!DownloadFile($Val, $FileName)) {
                            echo "<b>ERROR:</b> can't download url (" . $Val . ")<br>\n";
                            $Val =  "";
                        }
                    }
                }

                if($Prop['PropType']==PML_PropType_FileUpload) {
                    $Val = "";
                }

                if($Prop['PropType']==PML_PropType_DownloadLinkFileUpload) {
                    $Val = "||";
                }

                if($Prop['PropType']==PML_PropType_AutoIncrement) {
                    $strSql = "SELECT Property+0 AS Property FROM $CFG[Prefix]movieprop WHERE PropID=" . $Prop['ID'] . " ORDER BY Property DESC";
                    $q = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    $r = mysql_fetch_assoc($q);
                    $Val = $r['Property']+1;
                }

                $strSql = "REPLACE INTO $CFG[Prefix]movieprop (MovieID, PropID, Property)
                    VALUES ('$MovieID','".$Prop['ID']."','" . $Val . "')";
                mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                
                break;
            case PML_PropType_ListBox: //ListBox
            case PML_PropType_Boolean: //Boolean
            case PML_PropType_ListBoxMulti: //ListBoxMulti
                $strSql = "SELECT $CFG[Prefix]propval.ID FROM $CFG[Prefix]moviepropval,$CFG[Prefix]propval
                    WHERE $CFG[Prefix]moviepropval.MovieID=0
                    AND $CFG[Prefix]propval.PropID=$Prop[ID]
                    AND $CFG[Prefix]moviepropval.PropValID=$CFG[Prefix]propval.ID";
                $q = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $Val = array();
                while($row=mysql_fetch_assoc($q)) {
                    $Val[] = $row['ID'];
                }

                $strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=" . $Prop['ID'];
                $q = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                $PropVals = array();
                $PropValIDs = array();
                while($r = mysql_fetch_array($q, MYSQL_ASSOC)) {                        
                    $PropValIDs[] = $r['ID'];
                }
                
                if(count($PropValIDs)) {
                    $strSql = "DELETE FROM $CFG[Prefix]moviepropval WHERE MovieID=$MovieID AND (PropValID=". implode(" OR PropValID=", $PropValIDs) .")";
                    mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            
                //insert the new ones...
                foreach($Val as $Dat) {
                    $strSql = "REPLACE INTO $CFG[Prefix]moviepropval (MovieID, PropValID)
                        VALUES ('$MovieID', '$Dat')";
                    mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
                break;
        } //end swtich
    } //end foreach
    //...end loading standandard-values
   
    //insert filename-field        
    $strSql = "REPLACE INTO $CFG[Prefix]movieprop (MovieID, PropID, Property) VALUES ($MovieID, $FileNamePropID, '" . addslashes($File) . "')";
    mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    if($UseDeleteFlag) {
        //insert delete-flag FALSE
        $strSql = "DELETE FROM pml_moviepropval WHERE MovieID='$MovieID' AND (PropValID='$DeleteFlagPropValID0' OR PropValID='$DeleteFlagPropValID1')";
        mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);            
        $strSql = "INSERT INTO pml_moviepropval (PropValID, MovieID) VALUES ('$DeleteFlagPropValID0', '$MovieID')";
        mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    }

    //insert number of files found
    if(isset($PropNames[$MultipleFilesFoundField])) { //does this field exist?
        if($PropAll[$PropNames[$MultipleFilesFoundField]]!=0) { //textfiled?
            trigger_error("can't insert number of files - as the field $MultipleFilesFoundField isn't from the type Textfield", E_USER_NOTICE);
        } else {
            $strSql = "REPLACE INTO $CFG[Prefix]movieprop (MovieID, PropID, Property) VALUES ($MovieID, ".$PropNames[$MultipleFilesFoundField].", '" . (sizeof($AddFiles)+1) . "')";
            mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }
    }

    //insert multiple files - names
    $x = array();
    $x[] = $File;
    foreach($AddFiles as $i) {
        $x[] = $i;
    }
    foreach($x as $k=>$i) {
        if(!isset($MultipleFileNamesFields[$k])) continue; //field not defined in $MultipleFileNamesFields (too much links/files)
        if(!isset($PropNames[$MultipleFileNamesFields[$k]])) continue; //field does not exist in db
        $Val['Url'] = $i;
        $Val['Size'] = round(filesize($i)/1024/1024);
        $Val['Text'] = basename($i);        
        foreach($MultipleFileNamesPrefix as $Repl=>$Pre) {
            if(substr($i, 0, strlen($Repl))==$Repl) {
                //replace prefix
                $Val['Url'] = $Pre . substr($i, strlen($Repl));
            }
        }        
        $Val['Url'] = addslashes($Val['Url']);

        $strSql = "REPLACE INTO $CFG[Prefix]movieprop (MovieID, PropID, Property) VALUES ($MovieID, ".$PropNames[$MultipleFileNamesFields[$k]].", '" . EncodeLink($Val) . "')";
        mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);        
    }
        

    //and now insert the other additional properties got by the reg-expr in $WritePropReg    

    //first select the right reg
    if(isset($WritePropRegMultiFiles)) {
        if(sizeof($AddFiles)) //when multiple files exit, use the other reg-expr
            $Reg = $WritePropRegMultiFiles;
        else
            $Reg = $WritePropReg;
    } else {
        //always use the $WritePropReg:
        $Reg = $WritePropReg;
    }
    preg_match($Reg, $File, $x);
    foreach($WritePropFields as $k=>$i) {
        if(!isset($x[$k])) continue; //not found in reg-expr
        if(!isset($PropNames[$i])) continue; //property doesn't exist in db
        $PropType = $PropAll[$PropNames[$i]]['PropType'];
        if($PropType==PML_PropType_Boolean || $PropType==PML_PropType_ListBox || $PropType==PML_PropType_ListBoxMulti) {
            $strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=$PropNames[$i] AND (DisplayText LIKE '$x[$k]' OR DisplayTextShort LIKE '$x[$k]')";
            $q=mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);        
            if(mysql_num_rows($q)) {
                //First delete standard-values
                $strSql = "DELETE FROM $CFG[Prefix]moviepropval WHERE MovieID=$MovieID";
                mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);    
                //then insert all found values
                while($row = mysql_fetch_assoc($q)) {
                    $strSql = "REPLACE INTO $CFG[Prefix]moviepropval (MovieID, PropValID) VALUES ('$MovieID', '$row[ID]')";
                    mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            }

        } else {
            $strSql = "REPLACE INTO $CFG[Prefix]movieprop (MovieID, PropID, Property) VALUES ($MovieID, ".$PropNames[$i].", '" . $x[$k] . "')";
            mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);        
        }
    }

    if($Verbose) {
        echo "inserted $File into Database";
        if(count($AddFiles)) echo " with " . count($AddFiles) . " additional files that belong to this one...";
        echo "<br>\n";
    }

    unset($Files[$FileKey]);
}


if($Verbose)
    include("$PmlDir/bottom.html");


function getDirList($dirName, $SubDirs=true) {
$ret = array();
    $d = dir($dirName);
    while($entry = $d->read()) {
        if ($entry != "." && $entry != "..") {
            $ret[] = $dirName."/".$entry;                
            if ($SubDirs && is_dir($dirName."/".$entry)) {
                $x=getDirList($dirName."/".$entry);
                foreach($x as $i) $ret[] = $i;
            }
        }
    }
    $d->close();
    return($ret);
}




?>