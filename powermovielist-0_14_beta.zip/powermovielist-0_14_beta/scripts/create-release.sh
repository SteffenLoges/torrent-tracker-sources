#!/bin/sh
#
# $Id: create-release.sh,v 1.1 2003/12/31 14:03:33 niko Exp $
#
# thx to phpMyAdmin for this script :D
# although i changed/improved/removed a lot...


if [ $# == 1 ]
then
  branch=''
fi
if [ $# == 2 ]
then
  branch="-r $1"
fi


cat <<END

Please ensure you have:
  1. updated docs/CHANGES:
     - all changes...
     - release-date for the new version
  2. version.php has the right-version (non cvs!)
  3. you tagged this version (when creating a new version)
  4. synchronized the language files:
       all language-files are correct & nothing is missing
       editlang.php

END

echo "Continue (y/n)?"
printf "\a"
read do_release

if [ "$do_release" != 'y' ]; then
  exit
fi

# Move old cvs dir
if [ -e cvs ];
then
    mv cvs cvs-`date +%Y-%m-%d--%s`
fi
# Do CVS checkout
mkdir cvs
cd cvs
echo "Press [ENTER]!"
if [ $? -ne 0 ] ; then
    echo "CVS login failed, bailing out"
    exit 1
fi
cvs -z3 -d:local:/usr/local/cvsroot co -P $branch powermovielist
if [ $? -ne 0 ] ; then
    echo "CVS checkout failed, bailing out"
    exit 2
fi


# read Version and Build from version.php:
versionFileStr=`egrep -o 'Version[ ]*=[ ]*"[^"]*"' powermovielist/version.php`
versionFileStr=`expr match "$versionFileStr" 'Version[ ]*=[ ]*"\([^"]*\)"'`
echo $versionFileStr

versionFileBuild=`egrep -o 'VerBuild[ ]*=[ ]*[0-9]*' powermovielist/version.php`
versionFileBuild=`expr match "$versionFileBuild" 'VerBuild[ ]*=[ ]*\([0-9]*\)'`
echo $versionFileBuild


# replace . and ' ' with _
version="$versionFileStr"
version="${version//./_}"
version="${version// /_}"

echo ""
echo ""
echo ""
echo "Version-Info"
echo "--------"
echo "Version: $versionFileStr"
echo "Build: $versionFileBuild"
echo "Filename: $version"
echo ""
echo "Attention: any existing releases will be overwritten!"
echo "to use another branch call ./create-release.sh branch"
echo "Continue (y/n)?"
printf "\a"
read do_release

if [ "$do_release" != 'y' ]; then
  exit
fi


# Cleanup release dir
LC_ALL=C date -u > powermovielist/docs/RELEASE-DATE-$version
find powermovielist \( -name .cvsignore -o -name CVS \) -print0 | xargs -0 rm -rf 
find powermovielist -type d -print0 | xargs -0 chmod 755
find powermovielist -type f -print0 | xargs -0 chmod 644
find powermovielist \( -name '*.sh' -o -name '*.pl' \) -print0 | xargs -0 chmod 755
mv powermovielist powermovielist-$version

# create files
zip -9 -r powermovielist-$version.zip powermovielist-$version
tar cvf powermovielist-$version.tar powermovielist-$version
bzip2 -9kv powermovielist-$version.tar
gzip -9v powermovielist-$version.tar

# copy to appz
cp powermovielist-$version.zip /home/powermovielist/www/appz/
cp powermovielist-$version.tar.gz /home/powermovielist/www/appz/
cp powermovielist-$version.tar.bz2 /home/powermovielist/www/appz/

# upload to sf.net
curl -T powermovielist-$version.tar.gz -u anonymous:niko@powermovielist.com ftp://upload.sf.net/incoming/
curl -T powermovielist-$version.tar.bz2 -u anonymous:niko@powermovielist.com ftp://upload.sf.net/incoming/
curl -T powermovielist-$version.zip -u anonymous:niko@powermovielist.com ftp://upload.sf.net/incoming/


# insert entry into the database:
echo ""
echo ""
echo ""
echo "adding entry ind database"
echo "--------"
echo "you probalby have to enter the password for user 'pml'"
sql="INSERT INTO hp_download SET ShowName='PowerMovieList $versionFileStr', Datum='`date +%Y-%m-%d`', DownloadZip='appz/powermovielist-$version.zip', DownloadGzip='appz/powermovielist-$version.tar.gz', DownloadBzip2='appz/powermovielist-$version.tar.bz2',VersionStr='$versionFileStr', VersionBuild='$versionFileBuild'"
echo $sql | mysql -upml -p pml


echo ""
echo ""
echo ""
echo "Files:"
echo "------"

ls -la *.gz *.zip *.bz2

cd ..
find cvs -type d -print0 | xargs -0 chmod 775
find cvs -type f -print0 | xargs -0 chmod 664





cat <<END


Todo now:
---------
 1. tag the cvs tree with the new revision number for a plain release or a
    release candidate
 3. add files to SF files page (cut and paste changelog since last release)
 4. add SF news item
 5. send a short newsletter-mail (with list of major changes)
        http://www.powermovielist.com/secret/newsletter.php
 6. the end :-)

END
