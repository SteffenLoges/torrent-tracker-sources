<?php
//--------------------------------------------------------------------
// phpNuke scrolling block for PowerMovieList  v.0.10.1 Alpha - 
// by Nikotto  http://www.powermovielist.com 
// created by Stas Edward - Friends-Forum http://www.friends-forum.com
// database has to be on the same server - but can be a different database than the nuke-db
//--------------------------------------------------------------------


die("you must first disable the die-line to activate this script"); //for security-reasons

if (eregi("block-last5video.php", $_SERVER['PHP_SELF'])) {
    Header("Location: index.php");
    die();
}

//  CONFIGURATION:::
$MovieDataBase = "movie";   // your PML data base
$ListName = "testlist";
$PMLPath = "movie";   //  Path to you PML directory
$NukeDB = "nuke";
//******************************************************

include("$PMLPath/config.inc.php");

$count = 1;
$content = "<A name= \"scrollingCode\"></A>";
$content .="<MARQUEE behavior= \"scroll\" align= \"center\" direction= \"up\" height=\"220\" scrollamount= \"2\" scrolldelay= \"100\" onmouseover='this.stop()' onmouseout='this.start()'>";
mysql_select_db($CFG['DatabaseName']) or die(mysql_error($pmldb));

//get PosterID
$strSql = "SELECT * FROM $CFG[Prefix]prop, $CFG[Prefix]lists
WHERE $CFG[Prefix]prop.ListID=$CFG[Prefix]lists.ID
AND $CFG[Prefix]lists.name='$ListName'
AND $CFG[Prefix]prop.Name='Poster'";
$result1 = mysql_query($strSql, $pmldb) or die(mysql_error($pmldb));
if(mysql_num_rows($result1)==0) die("ERROR: no field 'Poster' defined in PowerMovieList (list $ListName)");
$row = mysql_fetch_assoc($result1);
$PosterID = $row['ID'];

//get TitleID
$strSql = "SELECT * FROM $CFG[Prefix]prop, $CFG[Prefix]lists
WHERE $CFG[Prefix]prop.ListID=$CFG[Prefix]lists.ID
AND $CFG[Prefix]lists.name='$ListName'
AND $CFG[Prefix]prop.Name='Title'";
$result1 = mysql_query($strSql, $pmldb) or die(mysql_error($pmldb));
if(mysql_num_rows($result1)==0) die("ERROR: no field 'Title' defined in PowerMovieList (list $ListName)");
$row = mysql_fetch_assoc($result1);
$TitleID = $row['ID'];

$result1 = "SELECT $CFG[Prefix]movieprop.Property
FROM $CFG[Prefix]movieprop, $CFG[Prefix]movies
WHERE $CFG[Prefix]movies.ID = $CFG[Prefix]movieprop.MovieID AND $CFG[Prefix]movieprop.PropID=$PosterID
ORDER BY $CFG[Prefix]movies.DateAdded DESC 
LIMIT 5";
$result1 = mysql_query($result1) or die(mysql_error($pmldb));

$result = "SELECT  *  FROM $CFG[Prefix]movieprop, $CFG[Prefix]movies WHERE $CFG[Prefix]movies.ID = $CFG[Prefix]movieprop.MovieID 
	AND $CFG[Prefix]movieprop.PropID = $TitleID ORDER  BY $CFG[Prefix]movies.DateAdded DESC  LIMIT 5 ";
$result = mysql_query($result) or die(mysql_error($pmldb));

$content .= "<br>";
while((list($myName, $MovieID, $Property, $ID, $ListID, $DateAdded) = mysql_fetch_row($result)) and (list($myName1, $MovieID1, $Cover) = mysql_fetch_row($result1))) {
	$content .= "<center><a href=\"javascript:void(open('$PMLPath/popup.php?Active=$ListName&ID=$myName', 'windowName', 'scrollbars=yes,resizable=yes,width=400,height=500'));\"><img src=$myName1 width=\"100\" height=\"150\" border=\"0\"
alt=\"\"></center><center><a href=\"javascript:void(open('$PMLPath/popup.php?Active=$ListName&ID=$myName', 'windowName', 'scrollbars=yes,resizable=yes,width=400,height=500'));\"><b>$Property</b></a></center><br>
<center><font color=\"#FFF729\"><i> $DateAdded </i></font></center><br><br>";
$count = $count + 1;
}
mysql_select_db($NukeDB, $pmldb) or die(mysql_error($pmldb));
?>