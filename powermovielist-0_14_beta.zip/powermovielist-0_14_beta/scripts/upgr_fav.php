<?php
/** powermovielist upgrate to favorite lists
 * $Id:

This script helps you upgrading the script to user-favorites
so that not every user has the whole linklist displayed - only his "favorites"

and this script adds favorites for every user where he has more than view-rights

execute this script only ONCE!

*/

die("you must first disable the die-line to activate this script"); //for security-reasons


include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

$strSql = "SELECT ID FROM $CFG[Prefix]lists WHERE name='index'";
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$row=mysql_fetch_assoc($result);
$IndexID=$row['ID'];
$strSql = "SELECT ID,name FROM $CFG[Prefix]users";
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$num = mysql_num_rows($result);
$i=1;
while($row=mysql_fetch_assoc($result)) {
    echo ($i++)."/".$num." ($row[name])...<br>\n";
    flush();

    //index-seite:
    $so=1;
    $strSql = "REPLACE INTO $CFG[Prefix]fav (UserID, ListID, SortOrder) VALUES ($row[ID], $IndexID, $so)";
    mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    //resteliche seiten:
    $strSql = "SELECT ListID FROM $CFG[Prefix]userrights WHERE UserID=$row[ID] AND Permissions > 2";
    $result1 = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    while($row1=mysql_fetch_assoc($result1)) {
        $so++;
        $strSql = "REPLACE INTO $CFG[Prefix]fav (UserID, ListID, SortOrder) VALUES ($row[ID], $row1[ListID], $so)";
        mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    }
}

?>