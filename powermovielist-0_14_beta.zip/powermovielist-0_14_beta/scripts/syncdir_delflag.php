<?php
/** powermovielist syncdir_delflag
 * $Id:

- delete entries marked with the delete-flag
- the syncdir.php-script marks the files as deleted if the file on the dist isn't found anymore
  and with this script you delete these marked files finally

...this is a very good feature, because your whole database won't be deleted if for some
reason the files are not found at one script-run - the syncdir-script can also reset the deleted-flag
if the file is found again

*/

//die("you must first disable the die-line to activate this script"); //for security-reasons


//** standard-settings *************************************************************************************

//location where the PowerMovieList is installed - ../ by default when script runs in scripts/
//relative path no absolute! without / at the end!
$PmlDir = "..";

//the property used as deleted-flag
//has to be type boolean (checkbox)
$DeleteFlagField = "deleted"; //has to be a field with type "checkbox"!

//List that should be synced
$ListName = "testlist";


/*******************************************************************************************************/
//normally you don't have to modify anything below this line...


chdir($PmlDir);

$_GET['Active']=$ListName;

$LoadSmarty = true;
include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Moderator);


$DirPrefix = $PmlDir."/";
$DOC_TITLE = "SyncDir";
include("top.html");


echo "<form method=post action='syncdir_delflag.php'>
<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>
<tr class='top'><td colspan=2><h1>PowerMovieList - SyncDir - Delete entries</h1></td></tr>
<tr class='row1'><td colspan=2>remove as deleted marked entries from the database (the entries get marked when syncdir.php doesn't find a file)
<br>for configuration open syncdir_delflag.php and syncdir.php</td></tr>\n";
$cls=0;

if(isset($_POST['delID'])) {
    foreach($_POST['delID'] as $ID=>$x) {
        $strSql = "DELETE FROM " . $CFG['Prefix'] . "movies WHERE ID=$ID";
        $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

        $strSql = "DELETE FROM " . $CFG['Prefix'] . "movieprop WHERE MovieID=$ID";
        $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        
        $strSql = "DELETE FROM " . $CFG['Prefix'] . "moviepropval WHERE MovieID=$ID";
        $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

        $strSql = "DELETE FROM " . $CFG['Prefix'] . "votes WHERE MovieID=$ID";
        $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

        $strSql = "DELETE FROM " . $CFG['Prefix'] . "comment WHERE MovieID=$ID";
        $result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

        $smarty->clear_cache(null,"popup|$Active|$ID");
    }
    $smarty->clear_cache(null,"list|$Active");
    echo "<tr class='";        
    if($cls++%2) echo "row1"; else echo "row2";    
    echo "'><td colspan=2>entries deleted...</td></tr>\n";

}

$strSql = "SELECT $CFG[Prefix]prop.ID
FROM $CFG[Prefix]prop, $CFG[Prefix]lists
WHERE $CFG[Prefix]lists.Name='$ListName'
AND $CFG[Prefix]prop.Name='$DeleteFlagField'
AND $CFG[Prefix]prop.PropType=2"; //PML_PropType_Boolean
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
if(!mysql_num_rows($result)) die("ERROR: UseDeletedFlag ist activated, but the field 'DeleteFlagField' ist not found or not a checkbox");
$row = mysql_fetch_assoc($result);
$DeleteFlagPropID = $row['ID'];

$strSql = "SELECT pml_propval.ID FROM pml_propval WHERE Value=0 AND PropID=$DeleteFlagPropID";
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
if(!mysql_num_rows($result)) die("ERROR: UseDeletedFlag ist activated, but the field 'DeleteFlagField' doesn't have the right values for a checkbox (Value has to be 0 and 1)");
$row = mysql_fetch_assoc($result);
$DeleteFlagPropValID0 = $row['ID'];

$strSql = "SELECT pml_propval.ID FROM pml_propval WHERE Value=1 AND PropID=$DeleteFlagPropID";
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
if(!mysql_num_rows($result)) die("ERROR: UseDeletedFlag ist activated, but the field 'DeleteFlagField' doesn't have the right values for a checkbox (Value has to be 0 and 1)");
$row = mysql_fetch_assoc($result);
$DeleteFlagPropValID1 = $row['ID'];


$strSql = "SELECT pml_movies.ID
FROM pml_movies,pml_moviepropval
WHERE pml_moviepropval.MovieID=pml_movies.ID
AND pml_moviepropval.PropValID=$DeleteFlagPropValID1";
$result = mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
if(mysql_num_rows($result)==0) {
    echo "<tr class='row2'><td colspan=2><b>nothing is marked as deleted!</td></tr></table>";
    include("bottom.html");
    exit;
}
while($row=mysql_fetch_assoc($result)) {
    echo "<tr class='";
    if($cls++%2) echo "row1"; else echo "row2";
    echo "'>\n";
    echo "  <td>";
    echo "<a href='$PmlDir"."/dload.php".$GlobalArg."ID=$row[ID]' onClick=\"var popup=window.open(this.href,'infopopup','scrollbars=yes,resizable=yes,width=400,height=500'); popup.focus(); return false\">".GetFetchText($row['ID'])."</a>";
    echo "</td>\n";
    echo "  <td><input type='checkbox' name='delID[$row[ID]]' checked></td>\n";
    echo "</tr>\n";
}
echo "<tr class='";
if($cls++%2) echo "row1"; else echo "row2";
echo "'>\n";
echo "  <td>&nbsp;</td>\n";
echo "  <td><input type='submit' value='delete marked entries'></td>\n";
echo "</tr>";
echo "</table>\n";
echo "</form>\n";

include("bottom.html");