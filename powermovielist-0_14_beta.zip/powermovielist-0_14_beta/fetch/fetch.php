<?php
/** 
 * FetchScripts BaseClass
 *
 * Generic functions for FetchScripts
 * $Id: fetch.php,v 1.7 2005/02/17 07:11:28 niko Exp $
 *
 * @package fetch
 */

/**#@+
 * search-return-constant
 *
 * @access public
 * @static fetch-search-return
 */
define("PML_FETCH_SEARCHERROR",0);
define("PML_FETCH_SEARCHDONE",1);
define("PML_FETCH_EXACTMATCH",2);
/**#@-*/


/**#@+
 * fetch-return-constant
 *
 * @access public
 * @static fetch-return
 */
define("PML_FETCH_ERROR",0);
define("PML_FETCH_OK",1);
define("PML_FETCH_ITEMNOTFOUND",2);
/**#@-*/

/**
 * Include Cache-Functions
 */
require_once('cachelite.php');

class pml_fetch {
	/**
	 * Returns all FieldNames avaliable for this FetchScript
	 *
	 * sets a unique string whith that the fetch script can
	 * specify from what page it should download the data
	 * eg. on imdb this is a number like 0153517
	 *
	 * @access public
	 * @var string
	 */
    function getFieldNames() {
		return($this->FieldNames);
	}

	/**
	 * Returns the currenlty set FetchID for this FetchScript
	 *
	 * if not yet defined, it returns ""
	 *
	 * @access public
	 * @return string the fetch-id
	 */
	function getFetchID() {
		return($this->FetchID);
	}

	/**
	 * Sets the FetchID for this fetch-script
	 *
	 * sets a unique string whith that the fetch script can
	 * specify from what page it should download the data
	 * eg. on imdb this is a number like 0153517
	 *
	 * @access public
	 * @param string [$FetchID] the fetch-id
	 */
	function setFetchID($FetchID) {
		$this->FetchID = $FetchID;
	}

	/**
	 * FetchID
	 *
	 * @access private
	 * @var string
	 */
	var $FetchID="";
	
	/**
	 * downloads the data from a url, cache used
	 *
	 * Downloads a Url and returns the HTML-Code.
	 * The file will be cached in the cache-folder.
	 * if there exists allready a cache it will be returned
	 *
	 * @todo delete the cache regulary
	 * @access public
	 * @param string URL of data to fetch
	 * @param string Host where to download the site (host:port)
	 * @param string Referer to send
	 * @return string the fetched HTML-code
	 */
    function fetchCachedUrl($Url, $Host, $Referer)
	{
		global $CFG;        

        $CacheId = preg_replace("#([^a-z0-9]*)#","",$Url);;
        $options = array(
            'cacheDir' => $CFG['FetchCacheDir'],
            'lifeTime' => 3600
        );

        $Cache = new Cache_Lite($options);

        if ($Dat = $Cache->get($CacheId)) {            
            // Cache hit !
            return($Dat);
        } else {
            // Cache miss !
            $data = "GET $Url HTTP/1.0\r\n";
            $data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0)\r\n";
            $data .= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, */*\r\n";
            $data .= "Accept-Language: en\r\n";
            $data .= "Referer: $Referer\r\n";  //with given referer		
            $data .= "Host: $Host\r\n";
            $data .= "Connection: Keep-Alive\r\n";
            $data .= "Cache-Control: no-cache\r\n";
            $data .= "\r\n";
            
            $Dat = $this->FetchPage($data, $Host);

            //save tinto Cache:
            $Cache->save($Dat);

            return($Dat);
        }
    }

	/**
	 * send a request-header to a server and return the returned data
	 *	 
	 * @access private
	 * @param string the request-header
	 * @param string Host where to download the site (host:port)	 
	 * @return string the fetched HTML-code
	 */
	function FetchPage($RequestHeader, $Server)
	{	
		$psplit = split(":",$Server);
		$pserver = $psplit[0];
        if(isset($psplit[1]))
		    $pport = $psplit[1];
        else
            $pport = 80; //default-http-port
        
		$fp = @fsockopen($pserver, $pport);

		if (!$fp) {
			echo "Error connecting to $pserver:$pport";
            return("");
		}
		fputs ($fp, $RequestHeader);
		$site = "";
		while (!feof($fp)) {
			$site .= fgets ($fp, 1024);
		}
		fclose ($fp);
		return($site);
	}

	function ReplaceUnicodeChars($Dat) {
        while(ereg("&#([0-9]{3});", $Dat, $x)) {
            $Dat = str_replace("&#".$x[1].";", chr($x[1]), $Dat);
        }
        return($Dat);
    }	

	/**
	 * getUseSettings - standard-method used if FetchScript doesn't have it
	 *
	 * returns if this field has additional settings
	 *
	 * @access public	 
	 * @param string $field the field
	 * @return boolean
	 **/
	function getUseSettings($field) {
		return(false);		
	}

	/**
	 * printSettings - standard-method used if FetchScript doesn't have it
	 *
	 * print out here the HTML-code for your custom settings
	 *
	 * @access public
	 * @param string the current setting from the database
	 * @param string the field
	 * @return the HTML-code
	 **/
	function printSettings($set, $field) {		
		return("");
	}
	/**
	 * saveSettings - standard-method used if FetchScript doesn't have it
	 *
	 * processes the $_GET-stuff and validates it and then moves it into
	 * one string that will be saved in the database (only one field is
	 * avaliable for saving the data!
	 *
	 * @access public
	 * @param  string  the field
	 * @return string  the string that will be saved in the db
	 **/
	function saveSettings($field) {		
		return("");
	}

	/**
	 * setSetting - standard-method used if FetchScript doesn't have it
	 *
	 * will be called from editentry.php bevore calling DoFetch
	 * (only if $set is not empty)
	 * There shoud the setting be processed and saved into some
	 * class-vars...
	 *
	 * @access public
	 * @param  string  the field
	 * @param  string  the setting
	 **/
	function setSettings($field, $set) {
		return;
	}


}

?>