<?php
/** 
 * fetch-script: daprogger.mine.nu
 *
 * $Id: fetch-daprogger.php,v 1.2 2004/11/10 21:29:39 mloeffen Exp $ 
 * 
 * @version 0.1
 * @author mloeffen
 * @package fetch
 */

//first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_daprogger")) return;

class pmlfetch_daprogger extends pml_fetch {
    
    /**
     * FieldNames
     * IMPORTANT: Add new fields here and in function DoFetch
     *
     * @access private   
     **/
    var $FieldNames = array("box",
                            "cd");

// mloeffen: some copied code from the net to decode encoded html-pages

/**
     * decode a string that is encoded w/ "chunked' transfer encoding
      * as defined in RFC2068 19.4.6
     *
     * @param    string $buffer
     * @returns    string
     * @access   public
     */
     function decodeChunked($buffer){
         $length = 0;
         $new = "";
         
         // read chunk-size, chunk-extension (if any) and CRLF
         // get the position of the linebreak
         $chunkend = strpos($buffer,"\r\n") + 2;
         $temp = substr($buffer,0,$chunkend);
         $chunk_size = hexdec( trim($temp) );
         $chunkstart = $chunkend;
         // while (chunk-size > 0) {
         while ($chunk_size > 0) {
             
             $chunkend = strpos( $buffer, "\r\n", $chunkstart + $chunk_size);
               
             // Just in case we got a broken connection
               if ($chunkend == FALSE) {
                   $chunk = substr($buffer,$chunkstart);
                 // append chunk-data to entity-body
                 $new .= $chunk;
                   $length += strlen($chunk);
                   break;
             }
             
               // read chunk-data and CRLF
               $chunk = substr($buffer,$chunkstart,$chunkend-$chunkstart);
               // append chunk-data to entity-body
               $new .= $chunk;
               // length := length + chunk-size
               $length += strlen($chunk);
               // read chunk-size and CRLF
               $chunkstart = $chunkend + 2;
             
               $chunkend = strpos($buffer,"\r\n",$chunkstart)+2;
             if ($chunkend == FALSE) {
                 break; //Just in case we got a broken connection
             }
             $temp = substr($buffer,$chunkstart,$chunkend-$chunkstart);
             $chunk_size = hexdec( trim($temp) );
             $chunkstart = $chunkend;

         }
         return $new;
     }

    /**
     * doSearch - perform the search on the page to fetch from
     *
     * @param &$out return-string: the HTML-code displayed when searching
     * @param $SearchString string: the string sent to the page to search for
     * @param $EntryUrl string: url used for links in HTML-code
     * @access public
     * @return const PML_FETCH_SEARCHERROR, PML_FETCH_SEARCHDONE or PML_FETCH_EXACTMATCH
     **/
    function doSearch(&$out, $SearchString, $EntryUrl) {                
        $Name = rawurlencode($SearchString);

        $protocol = "http://";
//        $host = "localhost";
        $host = "daprogger.mine.nu";
        $port = "80";
        $referer = "daprogger.mine.nu";

        $data = "GET /coverse.php?title=$Name&covertype=&work=&region=&language=&creator=&Submit=Search HTTP/1.1\r\n";
        $data .= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, */*\r\n";
        $data .= "Referer: " . $protocol . $host . "/coverse.php?title=$SearchString&covertype=&work=&region=&language=&creator=&Submit=Search\r\n";
        $data .= "Accept-Language: nl\r\n";     
        $data .= "Accept-Encoding: gzip, deflate\r\n";
        $data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)\r\n";
        $data .= "Host: $host\r\n";
        $data .= "Connection: Keep-Alive\r\n";
        $data .= "\r\n";
        $data = $this->FetchPage($data, $host . ":" . $port);

        // is html encoded?
        $htmlencoded = (strpos(strtolower($data), "transfer-encoding: chunked") !== false);

        // remove HTTP headers
        if( $pos = strpos($data,"\r\n\r\n") ){
        } elseif( $pos = strpos($data,"\n\n") ){
        } else {
            $out.= "HTTP ERROR: no proper separation of headers and document";
            return(PML_FETCH_ERROR);
        }
        $data = ltrim(substr($data,$pos));

        // decode html if encoded
        if ($htmlencoded) $site = $this->decodeChunked($data);

        // remove tabs and crlf
        $site = str_replace(array("\t","\r","\n"),"",$site);

        // remove double spaces
        $site = ereg_replace("[ ]+[ ]+"," ",$site);

        // remove spaces between tags
        $site = str_replace("> <","><",$site);

        $nrhits = 0;
        $extract = array();
        $nrhits = preg_match("/Creator<\/th><\/tr>(<tr[^>]*?><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><td[^>]*?>(.+?)<\/td><\/tr>)+<tr[^>]*?><td[^>]*?>\d+ covers found.<\/td><\/tr>/i", $site, $site);

        if ($nrhits == 0){
            $out .= $GLOBALS['strErrNothingFoundEnterNewString'];            
            return(PML_FETCH_SEARCHDONE);
        }
        else{
            $nrhits = preg_match_all("/<tr[^>]*?><td[^>]*?><img src=images\/([^\.]*)?\.gif><\/td><td[^>]*?><a href=\"[^\d]*?(\d+)[^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><td[^>]*?><a [^>]*?>(.+?)<\/a><\/td><\/tr>/", $site[0], $site);
            switch($nrhits){
                case 0:
                     $out.= "ERROR: Unable to parse document successfully";
                     return(PML_FETCH_ERROR);
                     break;
                case 1:
                     $out .= $GLOBALS['strExactMatch'];
                     //save the id in $FetchID
                     $this->FetchID = $site[2][0] . "|" . $site[1][0];
                     return(PML_FETCH_EXACTMATCH);
                     break;
               }
        }

        // More than one hit found

        // Save results in a new array
        $sortedHits = Array();
        foreach($site as $keymaster => $value)
        {
            // Do not process array 0, because it contains the entire match (no need for that)
            // Instead, I use indice 0 to store the select-links
            if ($keymaster>0){
               foreach( $value as $key => $element){
                   if ($keymaster==2){
                       $element = $element . "|" . $site[1][$key] . "^";
                       $sortedHits[$key][0] = $element;
                   }
                   else{
                       if ($keymaster>2)
                           $sortedHits[$key][$keymaster-1] = $element;
                       else
                           $sortedHits[$key][$keymaster] = $element;
                   }
               }
            }
        }

        // sort the results-array on key basis
        foreach($sortedHits as $indice => $sortedHit){
            ksort($sortedHits[$indice]);
        }
        //sort array by contents, keeping relation within each array intact
        $sortedHits = $this->SortArray($sortedHits,1,"ASC",2,"ASC",3,"ASC");

        //print out all the movies found:

        // Javascript to select multiple covers in this page
        $Page = basename(__FILE__);
        $Page = substr($Page, 6);
        $Page = substr($Page, 0, -4);

        $jsUrl = $EntryUrl . "&" . urlencode("fid[{$Page}]") . "=";
        $js = "<script type=\"text/javascript\">\r\n" .
              "<!--\r\n" .
              "function go(){\r\n" .
              " s = '/';\r\n" .
              " jsUrl = '" . $jsUrl . "';\r\n" .
              " res = '' + radval('optbox') + radval('optcd');\r\n" .
              " p = location.protocol;\r\n" .
              " h = location.hostname;\r\n" .
              " path = location.pathname.substr(0,(location.pathname.lastIndexOf('/') + 1));\r\n" .
              " link = '' + p+s+s+h+path+jsUrl;\r\n" .
              " if (res != '')\r\n" .
              " {res = res.substr(0,(res.length - 1));}\r\n" .
              " location.href=link+res;\r\n" .
              "}\r\n" .
              "function radval(name){\r\n" .
              " var x = document.forms['select'].elements[name];\r\n" .
              " if (x == undefined) {return '';}\r\n" .
              " for (i = 0;  i < x.length;  i++) {\r\n" .
              "  if (x[i].checked)\r\n" .
              "   return x[i].value;\r\n" .
              " }\r\n" .
              " return '';\r\n" .
              "}\r\n" .
              "-->\r\n" .
              "</script>";
        $out.= $js;

        // print out the html-table
        $out.= "<form name=\"select\">";
        $out.= "<table>\n";

        // loop through available cover types (currently only 'box' and 'cd')
        foreach(array_unique($site[1]) as $type){
            $out.= "<tr><td colspan=\"9\"><h2>$type</h2>* " . $GLOBALS['strFoundMore'] . "<br />&nbsp;</td></tr>";
            $out.= "<tr><th width=\"10%\">Select</th><th width=\"26%\">Title</td><th width=\"7%\">Region</th><th width=\"7%\">Work</th><th width=\"10%\">Language</th><th width=\"10%\">Resolution</th><th width=\"10%\">Size</th><th width=\"10%\">Added</th><th width=\"10%\">Creator</th></tr>\n";
            $rowcounter = 0;
            foreach($sortedHits as $x){
                 // try to find a match
                if ($type == $x[1]){
                    $rownr = $rowcounter++ % 2 + 1;
                    // make a nice option button
                    $x[1] = "<input type=\"radio\" name=\"opt$type\" id=\"" . $type . $x[0] . "\" value=\"$x[0]\" />";
                    // make a label around the title
                    $x[2] = "<label for=\"" . $type . $x[0] . "\">" . $x[2] . "</label>";
                    // remove first column (holds id)
                    array_shift($x);
                    $out.= "<tr class=\"row$rownr\"><td align=\"center\">" . implode("</td><td>",$x) . "</td></tr>";
                }
            }
            
            $out.= "<tr><td colspan=\"9\"><br /><input type=\"button\" value=\"&gt;&gt; " . $GLOBALS['strOK'] . " &lt;&lt;\" onclick=\"go();\" /></td></tr>";
        }
        $out.=  "</form></table>";     
        return(PML_FETCH_SEARCHDONE);

    }

    // credits for this function go to Raveler.telenet.be
    function SortArray() {
        $arguments = func_get_args();
        $array = $arguments[0];
        $code = '';
        for ($c = 1; $c < count($arguments); $c += 2) {
            if (in_array($arguments[$c + 1], array("ASC", "DESC"))) {
                $code .= 'if ($a["'.$arguments[$c].'"] != $b["'.$arguments[$c].'"]) {';
                if ($arguments[$c + 1] == "ASC") {
                    $code .= 'return ($a["'.$arguments[$c].'"] < $b["'.$arguments[$c].'"] ? -1 : 1); }';
                }
                else {
                    $code .= 'return ($a["'.$arguments[$c].'"] < $b["'.$arguments[$c].'"] ? 1 : -1); }';
                }
            }
        }
        $code .= 'return 0;';
        $compare = create_function('$a,$b', $code);
        usort($array, $compare);
        return $array;
    }

    /**
     * GetCachedPage
     *
     * downloaded a given url with a given referrer, uses caching from fetch-class
     *
     * @param string the url to fetch
     * @param string the Referrer (default-value is set here)
     **/
    function GetCachedPage($Url, $Referer="http://daprogger.mine.nu/") {
        return($this->fetchCachedUrl($Url, "daprogger.mine.nu", $Referer));
    }

    /**
     * DoFetch - perform the search on the page to fetch from
     *
     * IMPORTANT if you want to add some fields:
     * if you add new fields, add them to var $FieldNames on top of this file
     *
     * @param string the fetched value (return-string)
     * @param string the FieldName
     * @access public
     * @return const PML_FETCH_ERROR, PML_FETCH_OK or PML_FETCH_ITEMNOTFOUND
     **/
    function DoFetch(&$ret, $FieldName) {

        // $choices[0] = coverid | 'cd' oder 'box'
        $choices = explode("^", $this->FetchID, count($this->getFieldNames()));
        $acceptedChoice = ''; // will contain the needed coverid later on

        // check the requested covers v.s. the possible fieldnames
        foreach($choices as $choice){
            $choice = explode("|" , $choice , 2);
            if ($choice[1] == $FieldName){
                $acceptedChoice = $choice[0];
                break;
            }
        }
        
        if ($acceptedChoice == ''){
            // no box or cd requested?
            return(PML_FETCH_ITEMNOTFOUND);
        }
        
        $site = $this->GetCachedPage("/showcover.php?showid=". $acceptedChoice, "http://daprogger.mine.nu");
        
        if(!preg_match("/<a href=\'([^\']+)\'>/", $site, $match)) {
            // could not find target image
            return(PML_FETCH_ERROR);
        }

        $ret = $match[1];
        return(PML_FETCH_OK);

    }//end function DoFetch

} //end class

?>