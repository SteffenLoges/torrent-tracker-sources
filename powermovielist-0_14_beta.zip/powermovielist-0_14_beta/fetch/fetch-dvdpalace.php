<?php
/** 
 * fetch-script: dvd-palace.de
 *
 * $Id: fetch-dvdpalace.php,v 1.2 2005/10/02 09:13:59 niko Exp $ 
 * 
 * @version 0.2
 * @author RaMIReZ
 * @author nikotto
 * @package fetch
 */

//first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_dvdpalace")) return;

class pmlfetch_dvdpalace extends pml_fetch {
	
	/**
	 * FieldNames
	 * IMPORTANT: Add new fields here and in function DoFetch
	 *
	 * @access private	 
	 **/
	var $FieldNames = array("Origtitle",
  		                    "Year",
    	                    "Poster",
  		                    "Director",
	                        "Genre",
							"Starring",
	                        "Plot",
  		                    "FSK",
							"dvdpalid");
	/**
	 * actorLimit
	 *
	 * @access private
	 * @var int
	 **/
	var $actorLimit;

	/**
	 * doSerach - perform the search on the page to fetch from
	 *
	 * @param &$out return-string: the HTML-code displayed when searching
	 * @param $SearchString string: the string sent to the page to search for
	 * @param $EntryUrl string: url used for links in HTML-code
	 * @access public
	 * @return const PML_FETCH_SEARCHERROR, PML_FETCH_SEARCHDONE or PML_FETCH_EXACTMATCH
	 **/
	function doSearch(&$out, $SearchString, $EntryUrl) {				
		$Name = rawurlencode($SearchString);

		$data = "GET /dvddatabase/dbsearch.php?action=1&suchbegriff=$Name HTTP/1.0\r\n";
		$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
		$data .= "Referer: http://www.dvd-palace.de\r\n";
		$data .= "Accept-Language: de\r\n";		
		$data .= "Accept-Encoding: gzip, deflate, x-gzip, identity, *;q=0\r\n";
		$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
        $data .= "Host: www.dvd-palace.de\r\n";		
		$data .= "Connection: Close\r\n";
		$data .= "Cache-Control: no-cache\r\n";
		$data .= "\r\n";
		$site = $this->FetchPage($data, "www.dvd-palace.de:80");

        if(ereg("window.clipboardData.setData\\('Text','http://www.dvd-palace.de/\\?dvddatabase/getinfo.php\\?dvdcode=([a-z]-[0-9]{4})'\\);", $site, $x)) {
            $this->FetchID=$x[1];
            return(PML_FETCH_EXACTMATCH);
        }
		
		$anz=0;
		$SearchData = array();
		
			while(ereg('<a href=\"\/dvddatabase/getinfo.php\?dvdcode=([^\<]*)\" style=\"color: #aa0000;\">([^\<]*)</a>', $site, $x)) {
				$anz++;
				$site = substr($site,strpos($site,$x[0])+strlen($x[0]));
				$rest = substr($site,0,strpos($site,"</LI>"));

				$help = str_replace("...aka","<br>&nbsp;&nbsp;&nbsp;&nbsp;",strip_tags($rest));
				$SearchData[] = array("id"   => $x[1],
					                  "name" => $x[2],
					                  "help" => $help);
			}
		

		if($anz==0) {
			$out.= $GLOBALS['strErrNothingFoundEnterNewString'];			
			return(PML_FETCH_SEARCHDONE);
		}

		$out.= $GLOBALS['strFoundMore'];
		//print out all the movies found:
		$out.=  "<table>";
	
		$Page = basename(__FILE__);
		$Page = substr($Page, 6);
		$Page = substr($Page, 0, -4);

		foreach($SearchData as $Dat) {
			if (!ereg('lesen',$Dat['name'])) {
				$out.=  "<tr class='row";
				if($j++%2) $out.= "1"; $out.= "2";
				$out.=  "'><td width='20'>&nbsp;</td><td>";
				$out.=  "<a href=\"$EntryUrl&" . urlencode("fid[{$Page}]")."=$Dat[id]\">$Dat[name]</a>";				
				$out.=  " - <a href=\"http://www.dvd-palace.de/dvddatabase/getinfo.php?dvdcode=$Dat[id]\" target=_blank>$GLOBALS[strInfo]</a>\n";
			
				if(strlen($Dat['help'])>2) $out.=  $Dat['help'];
				$out.=  "</td></tr>\n";
			}
		}
		$out.=  "</table>";		

		return(PML_FETCH_SEARCHDONE);
	}

    /**
     * GetCachedPage
     *
     * downloaded a given url with a given referrer, uses caching from fetch-class
     *
     * @param string the url to fetch
     * @param string the Referrer (default-value is set here)
     **/
	function GetCachedPage($Url, $Referer) {
        return($this->fetchCachedUrl($Url, "www.dvd-palace.de", $Referer));
	}

	/**
	 * DoFetch - perform the search on the page to fetch from
	 *
	 * IMPORTANT if you want to add some feilds:
	 * if you add new fields, add them to var $FieldNames on top of this file
	 *
	 * @param string the fetched value (return-string)
	 * @param string the FieldName
	 * @access public
	 * @return const PML_FETCH_ERROR, PML_FETCH_OK or PML_FETCH_ITEMNOTFOUND
	 **/
    function DoFetch(&$ret, $FieldName) {
		global $CFG;
		
		switch($FieldName) {
			case "Origtitle":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");

                if(!preg_match('/Originaltitel<\/td>\n\t\t<td VALIGN=\"TOP\" COLSPAN=4 BGCOLOR=\"#FFFFFF\" class=\"DETAILTEXT\">(.*) \(.* ([0-9]{4})\)&nbsp;<\/td>/mi', $site, $x)) {			        
					return(PML_FETCH_ERROR);
				}
                $ret = addslashes($x[1]);			    
				break;
			case "Year":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");

                if(!preg_match('/Originaltitel<\/td>\n\t\t<td VALIGN=\"TOP\" COLSPAN=4 BGCOLOR=\"#FFFFFF\" class=\"DETAILTEXT\">(.*) \(.* ([0-9]{4})\)&nbsp;<\/td>/mi', $site, $x)) {			        
					return(PML_FETCH_ERROR);
				}
                $ret = $x[2];			    
				break;
			case "Poster":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");
                if(!preg_match('/\<img src="\/cover.php([^"]+)" border=1 alt="Cover.*"\>/', $site, $x)) {					
					return(PML_FETCH_ERROR);
				}
                if($x[1]=="?nocover") {					
					return(PML_FETCH_ERROR);
                }
				$dvdurl = "http://www.dvd-palace.de/cover.php";
				
                $ret = "$dvdurl$x[1]";
                $ret= addslashes($ret);				
				break;
			case "Director":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");
                if(!preg_match('/Regie:&nbsp;&nbsp;\<a href="\/dvddatabase\/dbsearch.php(.+)" style="color: #eeeeee;"\>(.+)\<\/a\>/', $site, $x)) {					
					return(PML_FETCH_ERROR);
				}			
                $ret = $x[2];
                $ret = addslashes($ret);				
                break;
			case "Genre":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");
                if(!preg_match('/\<TD CLASS="FILMNAME" align="center" nowrap\>\n\t\t(.*) ?\n\t\t&nbsp;\<\/TD\>\n?\n\t\t\<td CLASS="FILMNAME" align="center" nowrap\>\n\t\t[0-9]* Views/im', $site, $x)) {					
					return(PML_FETCH_ERROR);
					
				}				
                $ret = addslashes($x[1]);										
				break;
			case "Starring":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");
                if(!preg_match('/\<td VALIGN="TOP" COLSPAN=1 BGCOLOR="#C0C0C0" class="DETAILTEXT"\>Darsteller \/ Sprecher\<\/td\>\n\t\t\<td VALIGN="TOP" COLSPAN=4 BGCOLOR="#FFFFFF" class="DETAILTEXT"\>(.*)&nbsp;\<\/td\>\n\n?\t\<\/tr\>/im', $site, $x)) {					
					return(PML_FETCH_ERROR);					
				}				
                $ret = $x[1];
                $ret = strip_tags($ret);
                $ret = explode(', ', $ret, $this->actorLimit+1);
                unset($ret[$this->actorLimit]);
                $ret = implode(', ', $ret);
                $ret = addslashes($ret);			
				break;
			case "Plot":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");
				if(!preg_match('/Label"\>\<\/div\>\<br\>(.+)&nbsp;/im', $site, $x)) {    				
					return(PML_FETCH_ERROR);
				}
                $ret = preg_replace ("/\<em\>.{2}\<\/em\>/", " ", $x[1]);
                $ret = strip_tags($ret);
                $ret = trim($ret);
                $ret = addslashes($ret);										
				break;
            case "FSK":
				$site = $this->GetCachedPage("/dvddatabase/getinfo.php?dvdcode=". $this->FetchID, "http://www.dvd-palace.de");
                if(!preg_match('/FSK: (.+)\n[	\t]*&nbsp;\<\/td\>/', $site, $x)) {					
					return(PML_FETCH_ERROR);
				}
			
                $ret = $x[1];
                $ret = addslashes($ret);				
                break;
			case "dvdpalid":
				$ret = $this->FetchID;				
				break;
			default:
				return(PML_FETCH_ITEMNOTFOUND);
		}//end switch $FieldName
		return(PML_FETCH_OK);
	}//end function DoFetch


	/**
	 * getUseSettings
	 *
	 * returns if this field has additional settings
	 *
	 * @access public	 
	 * @param string the field
	 * @return boolean
	 **/
	function getUseSettings($field) {
		switch($field) {
			case "Starring":
				return(true);
			default:
				return(false);
		}
	}

	/**
	 * printSettings
	 *
	 * print out here the HTML-code for your custom settings
	 *
	 * @access public
	 * @param string the field
	 * @param string the current setting from the database	 
	 * @return the HTML-code
	 **/
	function printSettings($field, $set) {

		switch($field) {
			case "Starring":
				if($set=="") $set="3";
				$out = "<input type=\"text\" name=\"set{$field}\" size=\"3\" value=\"$set\"> Actors to fetch\n";
				return($out);
		}
	}
	/**
	 * saveSettings
	 *
	 * processes the $_GET-stuff and validates it and then moves it into
	 * one string that will be saved in the database (only one field is
	 * avaliable for saving the data!
	 *
	 * @access public
	 * @param  string the field
	 * @return string the string that will be saved in the db
	 **/
	function saveSettings($field) {

		switch($field) {
			case "Starring":
				return($_POST['set'.$field]);
			default:
				return("");
		}
	}

	/**
	 * setSetting
	 *
	 * will be called from editentry.php bevore calling DoFetch
	 * (only if $set is not empty)
	 * There shoud the setting be processed and saved into some
	 * class-vars...
	 *
	 * @access public
	 * @param  string 
	 * @param  string the field
	 **/
	function setSettings($field, $set) {
		switch($field) {
			case "Starring":
				if($set=="") $set="3";
				$this->actorLimit = $set;
				break;
		}
	}
} //end class

?>
