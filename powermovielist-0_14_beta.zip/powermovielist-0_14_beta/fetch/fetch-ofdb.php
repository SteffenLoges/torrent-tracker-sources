<?php
/** 
 * fetch-script: ofdb.de
 *
 * $Id: fetch-ofdb.php,v 1.6 2005/02/17 07:11:28 niko Exp $
 *
 * @author Michael Schneider <mail@michasch-web.de> 
 * @package fetch
 */

//first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_ofdb")) return;

class pmlfetch_ofdb extends pml_fetch {
	
	//IMPORTANT: Add new fields here and in function DoFetch	
	var $FieldNames = array("Origtitle",
		                    "Year",
		                    "Poster",
		                    "Director",
		                    "FSK",
	                            "Genre",
				    "Starring",
				    "Plot",
				    "imdbid",
				    "Country");

	var $maxStarring = 5; // Maximale Anzahl der Darsteller die ermittelt werden sollen; 0 f�r unbegrenzt

	function doSearch(&$out, $SearchString, $EntryUrl) {		
		$Name = rawurlencode($SearchString);
		$Name = str_replace("%20", "+", $SearchString);

		$request = "page=suchergebnis&Kat=DTitel&SText=$Name";

		$data = "POST http://www.ofdb.de/view.php HTTP/1.0\r\n";
		$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
		$data .= "Referer: http://www.ofdb.de\r\n";
		$data .= "Accept-Language: de\r\n";
		$data .= "Content-type: application/x-www-form-urlencoded\r\n";
		$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
		$data .= "Host: www.ofdb.de\r\n";
		$data .= "Content-length: ".strlen($request)."\r\n";
		$data .= "Connection: Keep-Alive\r\n";
		$data .= "Cache-Control: no-cache\r\n";
		$data .= "\r\n";
		$data .= $request;

        // Seite abrufen
        $site = $this->FetchPage($data, "www.ofdb.de:80");
        
        // exaktes Ergebnis gefunden
        if(strstr($site, "HTTP/1.0 302") || strstr($site, "HTTP/1.1 302")) { //exact match?
			$out.= $GLOBALS['strExactMatch'];
			preg_match("/Location: view\.php\?page=film&fid=(\d+)/", $site, $x);
            //ereg("Location: http://us.imdb.com/title/tt([0-9]*)/, $site, $x);
			$this->FetchID = $x[1];	      //save the id in $FetchID
			return(PML_FETCH_EXACTMATCH); //return to editentry that it can fetch now the data - search is allready done
		}
        
        // Den Titelblock separieren
        preg_match("/<b>Deutscher Titel:<\/b><br><br>(.*?)<\/tr>/msi", $site, $erg);
        // einzelne Titel aus Titelblock auslesen
        preg_match_all("/(\d+). <a href='view\.php\?page=film&fid=(\d+?)'>(.+?)<\/a>/msi", $erg[0], $ofdb_filme);

		// Anzahl der gefundenen Filme
        $anz = count($ofdb_filme[0]);
				
		if($anz==0) {
			$out.= $GLOBALS['strErrNothingFoundEnterNewString'];			
			return(PML_FETCH_SEARCHDONE);
		}

		$out.= $GLOBALS['strFoundMore'];
        $out.= "<br>";

		$Page = basename(__FILE__);
		$Page = substr($Page, 6);
		$Page = substr($Page, 0, -4);

        // Ergebnisse anzeigen
        for($i = 0; $i < $anz; $i++) {
		    $out.= "<li><a href=\"$EntryUrl&" . urlencode("fid[{$Page}]")."={$ofdb_filme[2][$i]}\">{$ofdb_filme[3][$i]}</a><br>\n";
		}		

		return(PML_FETCH_SEARCHDONE);
	}

	function GetCachedPage($Url, $Referer="http://www.ofdb.de/") {
        return($this->fetchCachedUrl($Url, "www.ofdb.de", $Referer));
	}

	/*this function is called once for every field, so it is very important
	* to use the GetCachedPage-function - the page will be loaded just once...
    *
	* IMPORTANT (if you want to add some vars)a:
	* if you add new fields, add them to var $FieldNames on top of this file
	*/
    function DoFetch(&$ret, $FieldName) {
		global $CFG;
		
		switch($FieldName) {
			case "Origtitle": // Orginaltitel
			    $site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
			    if(preg_match("/Originaltitel:<\/font><\/td>.*?<td>&nbsp;&nbsp;<\/td>.*?<td><fon.*?t face=\"Arial,Helvetica,sans-serif\" size=\"2\" class=\"Daten\"><b>(.+?)<\/b>/msi", $site, $titel)) {
			        $ret = $titel[1];
			        $ret = addslashes($ret);
			        $ret = preg_replace("/(ffb|136|ef9|f35|f20|f49)/", "", $ret);
			    } else {			    	
					return(PML_FETCH_ERROR);
				}
				break;
			case "Year":
                $site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
                if(!preg_match("/Erscheinungsjahr:.*?<\/font><\/td>.*?<td>&nbsp;&nbsp;<\/td>.*?<td><font face=\"Arial,Helvetica,sans-serif\" size=\"2\" class=\"Daten\"><b><a href=\".+?\">(\d+?)<\/a>/msi", $site, $x)) {					
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                if($ret=="") $ret=0;				
				break;
			case "Poster":
				$site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
                if(!preg_match("/<img src=\"(images\/film\/\d+?\/\d+?.jpg)\"/msi", $site, $x)) {					
					return(PML_FETCH_ERROR);
				}
                $ret = "http://www.ofdb.de/".$x[1];
                $ret= addslashes($ret);				
				break;
			case "Director":
				$site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
                if(!preg_match("/Regie:.*?<\/font><\/td>.*?<td>&nbsp;&nbsp;<\/td>.*?<td><font face=\"Arial,Helvetica,sans-serif\" size=\"2\" class=\"Daten\"><b>(.+?)<\/b><\/font><\/td>.+?<\/tr>/msi", $site, $regie)) {                    
					return(PML_FETCH_ERROR);
				}
				$regie = str_replace("</a><br><a", ",<a", $regie[1]);
				$regie = strip_tags($regie);
                $regisseure = explode(",", $regie);
                foreach($regisseure as $regisseur) $ret[] = addslashes(trim($regisseur));				
                break;
			case "Genre":
				$site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
                if(!preg_match("/Genre\(s\):<\/font><\/td>.*?<td>&nbsp;&nbsp;<\/td>.*?<td nowrap><font face=\"Arial,Helvetica,sans-serif\" size=\"2\" class=\"Daten\"><b>(.+?)<\/b>/msi", $site, $gen)) {					
					return(PML_FETCH_ERROR);
				}
				preg_match_all("/<a .+?>(.+?)<\/a>/", $gen[1], $genres);
                foreach($genres[1] as $genre) {
                    $ret[] = addslashes(trim($genre));
                }
				if(sizeof($ret)==0) {					
					return(PML_FETCH_ERROR);
				}				
				break;
			case "Starring":
				$site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
				if(!preg_match("/Darsteller:.*?<\/font><\/td>.*?<td>&nbsp;&nbsp;<\/td>.*?<td><font face=\"Arial,Helvetica,sans-serif\" size=\"2\" class=\"Daten\"><b>(.+?)<\/b><\/font><\/td>.+?<\/tr>/msi", $site, $darsteller)) {
                    
					return(PML_FETCH_ERROR);
				}
                $darsteller_array = explode("<br>", $darsteller[1], 4);
                for($i=0; $i<3; $i++) $ret[] = strip_tags(addslashes(trim($darsteller_array[$i])));				
				break;
			case "Plot":
	    		$mainsite = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
	    		preg_match("/view\.php\?page=inhalt&fid=\d+&sid=(\d+)/", $mainsite, $sid);
	    		$site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=inhalt&fid=" . $this->FetchID . "&sid=" . $sid[1]);
				if(preg_match("/Eine Inhaltsangabe von .*?<br><br>\n?(.*?)<\/font><\/p>/msi", $site, $x)) {
					//plot exists:
					$ret = addslashes(trim(strip_tags($x[1])));
				}
                if(!$ret) {
					return(PML_FETCH_ERROR);
    			}				
				break;
  			case "imdbid":
                $site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
                preg_match("/http:\/\/german\.imdb\.com\/Title\?(\d+)/", $site, $x);
				$ret = $x[1];				
				break;
		case "Country":
				$site = $this->GetCachedPage("http://www.ofdb.de/view.php?page=film&fid=". $this->FetchID);
                if(!preg_match("/Herstellungsland:.*?<\/font><\/td>.*?<td>&nbsp;&nbsp;<\/td>.*?<td><font face=\"Arial,Helvetica,sans-serif\" size=\"2\" class=\"Daten\"><b>(.+?)<\/b><\/font><\/td>.+?<\/tr>/msi", $site, $count)) {                    
					return(PML_FETCH_ERROR);
				}
				$count = str_replace("</a><br><a", ",<a", $count[1]);
				$count = strip_tags($count);
                $countries = explode(",", $count);
                foreach($countries as $country) $ret[] = addslashes(trim($country));				
                break;
        	default:
				return(PML_FETCH_ITEMNOTFOUND);								
		}//end switch $FieldName
        if(is_array($ret)) {
            foreach($ret as $k=>$i) {
                $ret[$k] = $this->ReplaceUnicodeChars($i);
            }
        } else {
            $ret = $this->ReplaceUnicodeChars($ret);
        }
		return(PML_FETCH_OK);
	}//end function DoFetch

} //end class

?>
