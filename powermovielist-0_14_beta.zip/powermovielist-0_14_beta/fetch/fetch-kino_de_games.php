<?php
/**
 * fetch-script: kino.de Games
 *
 * $Id: fetch-kino_de_games.php,v 1.2 2004/04/18 09:41:48 niko Exp $
 *
 * @author Michael Schneider <mail@michasch-web.de>
 * @author Erik Gross <powermoviez@ddls-only.com>
 * @package fetch
 */

 //first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_kino_de_games")) return;

class pmlfetch_kino_de_games extends pml_fetch {

	//IMPORTANT: Add new fields here and in function DoFetch
	var $FieldNames = array("Poster",
		                    "System",
		                    "USK",
	                        "Genre",
							"Entwic",
							"Plot",
							"Releas",
                            "CDs",
                            "SysVor",
                            "Sprach",
							"Publis");

	var $maxStarring = 3; // Maximale Anzahl der Darsteller die ermittelt werden sollen; 0 f�r unbegrenzt

	function doSearch(&$out, $SearchString, $EntryUrl) {
		$Name = rawurlencode($SearchString);
		$Name = str_replace("%20", "+", $SearchString);

		$request = "typ=archiv&game=$Name";

		$data = "POST http://www.kino.de/gamestarts.php4 HTTP/1.0\r\n";
		$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
		$data .= "Referer: http://us.imdb.com/Find\r\n";
		$data .= "Accept-Language: de\r\n";
		$data .= "Content-type: application/x-www-form-urlencoded\r\n";
		$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
		$data .= "Host: us.imdb.com\r\n";
		$data .= "Content-length: ".strlen($request)."\r\n";
		$data .= "Connection: Keep-Alive\r\n";
		$data .= "Cache-Control: no-cache\r\n";
		$data .= "\r\n";
		$data .= $request;

        // Seite abrufen
        $site = $this->FetchPage($data, "www.kino.de:80");

        // ermitteln wieviele Ergebnisseiten es gibt, bzw. alle abrufen
        $curr_page = 1;
        preg_match("/Game \d+ bis (\d+) von (\d+)/", $site, $ergebnisseiten);
        while($ergebnisseiten[1] < $ergebnisseiten[2]) {
            $fp = fopen("http://www.kino.de/gamestarts.php4?typ=archiv&imhandel=&game=$Name");
            while($fp && !feof($fp)) {
                $site .= fread($fp, 1024);
            }
            $ergebnisseiten[1] += 8;
        }
        $site = str_replace("SRC=\"", "SRC=\"http://www.kino.de", $site);
		preg_match_all("#<table[^>]*?><tr[^>]*?><td[^>]*?><span[^>]*?><a href=\"/?game\.php4\?nr=(\d+)[^>]*?\">.*?</span></td></tr></table>#i", $site, $suchergebnisse);
		$anz = count($suchergebnisse[0]);

		if($anz==0) {
			$out .= $GLOBALS['strErrNothingFoundEnterNewString'];
			return(PML_FETCH_SEARCHDONE);
		}

		$out .= $GLOBALS['strFoundMore'];
        $out .= "<br>";

		$Page = basename(__FILE__);
		$Page = substr($Page, 6);
		$Page = substr($Page, 0, -4);

        // Ergebnisse anzeigen
        for($i = 0; $i < $anz; $i++) {
		    $suchergebnisse[0][$i] = preg_replace("/<a href=\"[^\"]+?\">mehr<\/a>/i", "...", $suchergebnisse[0][$i]);
		    $suchergebnisse[0][$i] = preg_replace("/<A HREF=\"\/?game\.php4\?nr=" . $suchergebnisse[1][$i] . ".+?\">/", "<a href=\"$EntryUrl&" . urlencode("fid[{$Page}]")."={$suchergebnisse[1][$i]}\">", $suchergebnisse[0][$i]);
		    $out.= $suchergebnisse[0][$i] . "<br>";
		}

		return(PML_FETCH_SEARCHDONE);
	}

	function GetCachedPage($Url, $Referer="http://www.kino.de/") {
		return($this->fetchCachedUrl($Url, "www.kino.de", $Referer));
	}

	/*this function is called once for every field, so it is very important
	* to use the GetCachedPage-function - the page will be loaded just once...
    *
	* IMPORTANT (if you want to add some vars)a:
	* if you add new fields, add them to var $FieldNames on top of this file
	*/
    function DoFetch(&$ret, $FieldName) {
		global $CFG;

		switch($FieldName){
			case "Poster":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?nr=". $this->FetchID);
                if(!preg_match("/<TR><TD><TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" align=\"left\"><TR><TD width=\".+?\"><IMG SRC=\"(.+?)\" align=\"left\" width=\"\d+?\" height=\"\d+?\" ALT=/msi", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = "http://www.kino.de".$x[1];
                $ret= addslashes($ret);
				break;
			case "System":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/System<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "SysVor":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Systemvoraussetzungen<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "Genre":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Genre<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "Sprach":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Sprache<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "Publis":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Publisher<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "CDs":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Datentr�ger<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "USK":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Altersbeschr�nkung<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "Releas":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Auslieferung<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "Entwic":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?typ=features&nr=". $this->FetchID);
                if(!preg_match("/Entwickler<\/b>&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                $ret = addslashes($ret);
				break;
			case "Plot":
				$site = $this->GetCachedPage("http://www.kino.de/game.php4?nr=". $this->FetchID);
				if(preg_match("/<img src=\"\/pix\/clear\.gif\" width=\"2\" height=\"100%\"><\/TD><\/TR>.*?<\/TABLE>(.+?)(<br \/>|<\/TD>)/msi", $site, $x)) {
					//plot exists:
					$ret = addslashes(strip_tags($x[1]));
				}
                if(!$ret) {
					return(PML_FETCH_ERROR);
    			}
				break;
			default:
				return(PML_FETCH_ITEMNOTFOUND);
		}//end switch $FieldName

        if(is_array($ret)) {
            foreach($ret as $k=>$i) {
                $ret[$k] = $this->ReplaceUnicodeChars($i);
            }
        } else {
            $ret = $this->ReplaceUnicodeChars($ret);
        }
		return(PML_FETCH_OK);
	}//end function DoFetch


} //end class

?>
