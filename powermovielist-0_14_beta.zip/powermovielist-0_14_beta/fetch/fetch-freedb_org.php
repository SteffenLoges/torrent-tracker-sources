<?php
/** 
 * fetch-script: freedb.org
 * based on fetch-kino_de.php by michasch
 *
 * $Id: fetch-freedb_org.php,v 1.3 2005/02/17 07:11:28 niko Exp $
 *
 * @author Ronald Schaten <ronald@schatenseite.de>
 * @package fetch
 */

//first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_freedb_org")) return;

class pmlfetch_freedb_org extends pml_fetch {

	//IMPORTANT: Add new fields here and in function DoFetch	
	var $FieldNames = array("Artist",
	                        "Title",
		                "TotalTime",
		                "Year",
		                "Genre",
		                "Category",
				"Tracks",
				"freedbid");

	function doSearch(&$out, $SearchString, $EntryUrl) {		
		$Name = str_replace(" ", "+", $SearchString);
		$Name = rawurlencode($SearchString);

		$request = "words=$Name&allfields=NO&fields=artist&fields=title&allcats=YES&grouping=none&x=0&y=0";

		$data = "GET /freedb_search.php?$request HTTP/1.0\r\n";
		$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
		$data .= "Referer: http://www.freedb.org/\r\n";
		$data .= "Accept-Language: de\r\n";
		$data .= "Content-type: application/x-www-form-urlencoded\r\n";
		$data .= "Accept-Encoding: gzip, deflate, x-gzip, identity, *;q=0\r\n";
		$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
		$data .= "Host: www.freedb.org\r\n";
		$data .= "Connection: Keep-Alive\r\n";
		$data .= "Cache-Control: no-cache\r\n";
		$data .= "\r\n";

        	// fetch page
        	$site = $this->FetchPage($data, "www.freedb.org:80");

		// search for the results
		$site = preg_replace("#.*<h2>all categories</h2>.<table border=0>#msi", "", $site);
		$site = preg_replace("#</table>.*#msi", "", $site);

		preg_match_all("#<tr><td>(.*)</tr>#Umsi", $site, $results);

		$anz = count($results[0]);

		// got any results?
		if($anz==0) {
			$out .= $GLOBALS['strErrNothingFoundEnterNewString'];			
			return(PML_FETCH_SEARCHDONE);
		}

		$out .= $GLOBALS['strFoundMore'];
        	$out .= "<br>";

		$Page = basename(__FILE__);
		$Page = substr($Page, 6);
		$Page = substr($Page, 0, -4);

        	// show results, first the album names...
        	for($i = 0; $i < $anz; $i++) {
			$result = $results[1][$i];
			$result = preg_replace("#<br>#msi", "", $result);
			$result = preg_replace("#&nbsp;#msi", "", $result);
			$result = preg_replace("#</?font[^>]*>#msi", "", $result);
			preg_match_all("#<a href=\"[^\"]*cat=(.*)&id=(.*)\">(.*)</a>#Umsi", $result, $links);
			$name = $links[3][0];
			$links[3][0] = "1";
			$out .= $name."<ul>";
			// ... then a list of the variants
        		for($j = 0; $j < count($links[1]); $j++) {
				$cat = $links[1][$j];
				$id = $links[2][$j];
				$number = $links[3][$j];
				$link_pml = $EntryUrl."&".urlencode("fid[{$Page}]")."=".$cat."_".$id;
				$link_freedb = "http://www.freedb.org/freedb_search_fmt.php?cat=$cat&id=$id";
				$out .= "<li><a href=\"$link_pml\">Version $number</a> - ";
				$out .= "<a href=\"$link_freedb\">info</a></li>";
			}
			$out .= "</ul>";
		}

		return(PML_FETCH_SEARCHDONE);
	}

	function GetCachedPage($Url, $Referer="http://www.freedb.org/") {
        return($this->fetchCachedUrl($Url, "www.freedb.org", $Referer));
	}

	/*this function is called once for every field, so it is very important
	* to use the GetCachedPage-function - the page will be loaded just once...
	*
	* IMPORTANT (if you want to add some vars)a:
	* if you add new fields, add them to var $FieldNames on top of this file
	*/
	function DoFetch(&$ret, $FieldName) {
		global $CFG;
		$cat = preg_replace("#_.*#", "", $this->FetchID);
		$id = preg_replace("#.*_#", "", $this->FetchID);
		switch($FieldName) {
			case "Artist":
				$site = $this->GetCachedPage("http://www.freedb.org/freedb/$cat/$id");
				preg_match("#^DTITLE=(.*) / .*$#mi", $site, $match);
			        $ret = $match[1];
			        $ret = addslashes($ret);
			        break;
			case "Title":
				$site = $this->GetCachedPage("http://www.freedb.org/freedb/$cat/$id");
				preg_match("#^DTITLE=.* / (.*)$#mi", $site, $match);
			        $ret = $match[1];
			        $ret = addslashes($ret);
			        break;
			case "TotalTime":
				$site = $this->GetCachedPage("http://www.freedb.org/freedb/$cat/$id");
				preg_match("#^. Disc Length: (\d+) seconds$#mi", $site, $match);
			        $ret = $match[1];
				$ret = sprintf("%02d:%02d", floor($ret / 60), ($ret % 60));
			        $ret = addslashes($ret);
			        break;
			case "Year":
				$site = $this->GetCachedPage("http://www.freedb.org/freedb/$cat/$id");
				preg_match("#^DYEAR=(\d+)$#mi", $site, $match);
			        $ret = $match[1];
			        $ret = addslashes($ret);
			        break;
			case "Genre":
				$site = $this->GetCachedPage("http://www.freedb.org/freedb/$cat/$id");
				preg_match("#^DGENRE=(.+)$#mi", $site, $match);
			        $ret = $match[1];
			        $ret = addslashes($ret);
			        break;
			case "Tracks":
				$site = $this->GetCachedPage("http://www.freedb.org/freedb/$cat/$id");
				preg_match_all("#^TTITLE(\d+)=(.*)$#mi", $site, $titles);
				preg_match_all("#^EXTT(\d+)=(.*)$#mi", $site, $exttitles);
				preg_match_all("/^#\s+(\d+)$/mi", $site, $lengths);
				preg_match("#^. Disc Length: (\d+) seconds$#mi", $site, $match);
			        $totaltime = $match[1];
				$prevlength = $lengths[1][0];
        			for($i = 0; $i < count($titles[1]); $i++) {
				        $number = $titles[1][$i]+1;
					$name = $titles[2][$i];
					$info = $exttitles[2][$i];
					if ($info != "") {
					  $name .= " ($info)";
					}
					if ($i < count($titles[1])-1) {
			        		$length = floor(($lengths[1][$i+1] - $prevlength) / 75);
						$prevlength = $lengths[1][$i+1];
					} else {
			        		$length = $totaltime - floor($prevlength / 75);
					}
					$length = sprintf("%d:%02d", floor($length / 60), ($length % 60));
					$track = sprintf("%02d. %s (%s)", $number, $name, $length);
                    			#$ret[] = addslashes(trim($track));
                    			$ret .= addslashes(trim($track)."\n");
				}
				if(sizeof($ret)==0) {					
					return(PML_FETCH_ERROR);
				}				
			        break;
			case "Category":
			        $ret = $cat;
			        $ret = addslashes($ret);
			        break;
			case "freedbid":
			        $ret = $id;
			        $ret = addslashes($ret);
			        break;
			default:
				return(PML_FETCH_ITEMNOTFOUND);								
		}//end switch $FieldName
        	if(is_array($ret)) {
            		foreach($ret as $k=>$i) {
                		$ret[$k] = $this->ReplaceUnicodeChars($i);
            		}
        	} else {
            		$ret = $this->ReplaceUnicodeChars($ret);
        	}
		return(PML_FETCH_OK);
	}//end function DoFetch


} //end class

?>
