<?php
/** 
 * fetch-script: kino.de
 *
 * $Id: fetch-kino_de.php,v 1.13 2005/10/03 18:10:29 niko Exp $
 *
 * @author Michael Schneider <mail@michasch-web.de> 
 * @package fetch
 */

//first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_kino_de")) return;

class pmlfetch_kino_de extends pml_fetch {

	//IMPORTANT: Add new fields here and in function DoFetch	
	var $FieldNames = array("Title",
		                    "Origtitle",
		                    "Country",
		                    "Year",
		                    "Poster",
		                    "Director",
		                    "FSK",
	                        "Genre",
							"Starring",
							"Plot",
							"Release",
                            "Runtime",
							"kinoid");

	/**
	 * actorLimit
	 *
	 * @access private
	 * @var int
	 **/
	var $actorLimit;

	function doSearch(&$out, $SearchString, $EntryUrl) {		
		$Name = rawurlencode($SearchString);
		$Name = str_replace("%20", "+", $SearchString);

		$request = "typ=film&suchtext=$Name&suchkontext=filmtitel";

		$data = "POST http://www.kino.de/kdsuche.php4 HTTP/1.0\r\n";
		$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
		$data .= "Referer: http://www.kino.de/megasuche.php4\r\n";
		$data .= "Accept-Language: de\r\n";
		$data .= "Content-type: application/x-www-form-urlencoded\r\n";
		$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
		$data .= "Host: www.kino.de\r\n";
		$data .= "Content-length: ".strlen($request)."\r\n";
		$data .= "Connection: Keep-Alive\r\n";
		$data .= "Cache-Control: no-cache\r\n";
		$data .= "\r\n";
		$data .= $request;

        // Seite abrufen
        $site = $this->FetchPage($data, "www.kino.de:80");

        // ermitteln wieviele Ergebnisseiten es gibt, bzw. alle abrufen
        $curr_page = 1;
        preg_match("/Film \d+ bis (\d+) von (\d+)/", $site, $ergebnisseiten);
        while($ergebnisseiten[1] < $ergebnisseiten[2]) {
            $fp = fopen("http://www.kino.de/kdsuche.php4?typ=film&suchtext=$Name&suchkontext=filmtitel&page=" . ++$curr_page, "r");
            while($fp && !feof($fp)) {
                $site .= fread($fp, 1024);
            }
            $ergebnisseiten[1] += 8;
        }
     	$site = str_replace("SRC=\"", "SRC=\"http://www.kino.de", $site);
		//preg_match_all("/<table BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH=\"100%\"><tr><td VALIGN=\"top\" ALIGN=\"left\" ><A HREF=\"kinofilm.php4\?nr=\d+?\">.+?<\/A><\/A> <span CLASS=\"standardsmall\"><br>.*?<\/SPAN><br><span class=\"standardsmall\">.*?<\/span><br>.*?<span class=\"standardsmall\"><BR>.*?<\/span><\/TD><\/tr><\/table>/msi", $site, $suchergebnisse);
		preg_match_all("#<table[^>]*?><tr[^>]*?><td[^>]*?><a href=\"/?kinofilm\.php4\?nr=(\d+)[^>]*?\"><img[^>]*?>.*?</span></td></tr></table>#i", $site, $suchergebnisse);
		$anz = count($suchergebnisse[0]);
                         
		if($anz==0) {
			$out .= $GLOBALS['strErrNothingFoundEnterNewString'];			
			return(PML_FETCH_SEARCHDONE);
		}

		$out .= $GLOBALS['strFoundMore'];
        $out .= "<br>";

		$Page = basename(__FILE__);
		$Page = substr($Page, 6);
		$Page = substr($Page, 0, -4);

        // Ergebnisse anzeigen
        for($i = 0; $i < $anz; $i++) {
		    $suchergebnisse[0][$i] .= "</td></tr></table>";
			$suchergebnisse[0][$i] = preg_replace("/<a href=\"[^\"]+?\">mehr<\/a>/i", "...", $suchergebnisse[0][$i]);
		    $suchergebnisse[0][$i] = preg_replace("/<A HREF=\"\/?kinofilm\.php4\?nr=" . $suchergebnisse[1][$i] . ".+?\">/", "<a href=\"$EntryUrl&".urlencode("fid[{$Page}]")."={$suchergebnisse[1][$i]}\">", $suchergebnisse[0][$i]);
		    $out.= $suchergebnisse[0][$i] . "<br>";
		}     	
		
		return(PML_FETCH_SEARCHDONE);
	}

	function GetCachedPage($Url, $Referer="http://www.kino.de/") {
        return($this->fetchCachedUrl($Url, "www.kino.de", $Referer));
	}

	/*this function is called once for every field, so it is very important
	* to use the GetCachedPage-function - the page will be loaded just once...
    *
	* IMPORTANT (if you want to add some vars)a:
	* if you add new fields, add them to var $FieldNames on top of this file
	*/
    function DoFetch(&$ret, $FieldName) {
		global $CFG;		
		switch($FieldName) {
			case "Origtitle": // Orginaltitel
			    $site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
			    if(preg_match("#/kinofilm\.php4\?nr=.+?\">.+?</A></span></A> <span CLASS=\"standardsmall\"><br>\((.+?)\)</SPAN>#msi", $site, $titel)) {
				
			        $ret = $titel[1];
			        $ret = addslashes($ret);
			        			        
			        // and break...
			        break;
			    }
			    // else --> kein Break --> ermittelt den "Titel" als "Orginaltitel" !!!
            case "Title": //fetch Title

				//get this url, cached if allready used:
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);

				//regular-expresstion to filter out the field
                if(!preg_match("/<span class=\"headline2\"><A HREF=\"\/kinofilm\.php4\?nr=.+?\">(.+)<\/A><\/span>/", $site, $x)) {
					//if preg_match fails return error					
					return(PML_FETCH_ERROR);
				}

				//else set $ret (will be returned)
                $ret = $x[1];
                $ret = addslashes($ret);

				//and break...
				break;
			case "Year":
                $site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/- <b>[A-Za-z\/\.]+\s+(\d{4})<\/b>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
                if($ret=="") $ret=0;				
				break;
			case "Country":
                $site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/- <b>([A-Za-z\/\.]+)\s+\d{4}<\/b>/", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = $x[1];
				break;
			case "Poster":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/<TR><TD><TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" align=\"left\"><TR><TD width=\".+?\"><IMG SRC=\"(.+?)\" align=\"left\" width=\"\d+?\" height=\"\d+?\" ALT=/msi", $site, $x)) {
					return(PML_FETCH_ERROR);
				}
                $ret = "http://www.kino.de".$x[1];
                $ret= addslashes($ret);
				break;
			case "Director":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?typ=credits&nr=". $this->FetchID);
                if(!preg_match("/Regie&nbsp;<\/TD><TD CLASS=\"[^\"]+?\" WIDTH=\"50%\">(.+?)<\/TD>/", $site, $regie)) {
					return(PML_FETCH_ERROR);
				}
				$regie = strip_tags($regie[1]);
                $regisseure = explode(",", $regie);
                foreach($regisseure as $regisseur) $ret[] = addslashes(trim($regisseur));
                break;
			case "Genre":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/<b>(.+?)<\/b> - <b>[A-Za-z\/\.]+\s+\d{4}<\/b>/msi", $site, $gen)) {
					return(PML_FETCH_ERROR);
				}
				$genres = explode("/", $gen[1]);
                foreach($genres as $genre) {
                    $ret[] = addslashes(trim($genre));
                }
				if(sizeof($ret)==0) {
					return(PML_FETCH_ERROR);
				}
				
				break;
			case "FSK":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/(Freigegeben ab (\d+?) Jahren)|(Ohne Altersbeschr�nkung)|(Nicht geeignet u. 18 J.)/", $site, $x)) {					
					return(PML_FETCH_ERROR);					
				}
                if(count($x) == 3) {
                    $ret = "ab " . $x[2];
                } elseif($x[0] == "Nicht geeignet u. 18 J.") {
                    $ret = "ab 18";
                } else {
                    $ret = "frei";
                }				
				break;
			case "Starring":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?typ=credits&nr=". $this->FetchID);
				
				preg_match("/<TD colspan=2 CLASS=\"headlinewhite\">Cast<br>(.+?)<TD colspan=2 CLASS=\"headlinewhite\">Crew<br>/msi", $site, $cast);
				preg_match_all("/<TR  CLASS=\".+?\"><TD  CLASS=\".+?\" WIDTH=\"50%\">.+?<\/TD><TD CLASS=\".+?\" WIDTH=\"50%\"><a href=\"mitwirk\.php4\?nr=.+?\">(.+?)<\/a><\/TD><\/TR>/msi", $cast[1], $x);
				$counter = 0;
                foreach($x[1] as $darsteller) {
                    $ret[] = addslashes(trim($darsteller));
                    $counter++;
                    if($this->actorLimit != 0 && $counter >= $this->actorLimit) break;
				}
				
				if(sizeof($ret)==0) {					
					return(PML_FETCH_ERROR);
				}				
				break;
			case "Plot":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
				if(preg_match("/<TR>\s*<TD><TABLE width=\"100%\" CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" align=\"left\" ><TR><TD>(?:<TABLE.*<\/TABLE>)??(.*)<\/TD><\/TR>/Umsi", $site, $x)) {
					//plot exists:
					$ret = addslashes(strip_tags($x[1]));
				}
                if(!$ret) {
					return(PML_FETCH_ERROR);
    			}				
				break;
			case "Release":
				$site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/<B>Start: (\d{2}).(\d{2}).(\d{4})<\/B>/msi", $site, $x)) {					
					return(PML_FETCH_ERROR);
				}
				// Format: YYYY-MM-DD
                $ret = $x[3] . "-" . $x[2] . "-" . $x[1];				
				break;
			case "kinoid":
				$ret = $this->FetchID;				
				break;
            case "Runtime":
                $site = $this->GetCachedPage("http://www.kino.de/kinofilm.php4?nr=". $this->FetchID);
                if(!preg_match("/<b>(\d+) Min.<\/b>/msi", $site,$x)) {                    
                    return(PML_FETCH_ERROR);
                }
                $ret = addslashes($x[1]) . " Min.";                
                break;
			default:
				return(PML_FETCH_ITEMNOTFOUND);								
		}//end switch $FieldName
        if(is_array($ret)) {
            foreach($ret as $k=>$i) {
                $ret[$k] = $this->ReplaceUnicodeChars($i);
            }
        } else {
            $ret = $this->ReplaceUnicodeChars($ret);
        }
		return(PML_FETCH_OK);
	}//end function DoFetch

	/**
	 * getUseSettings
	 *
	 * returns if this field has additional settings
	 *
	 * @access public	 
	 * @param string the field
	 * @return boolean
	 **/
	function getUseSettings($field) {
		switch($field) {
			case "Starring":
				return(true);
			default:
				return(false);
		}
	}

	/**
	 * printSettings
	 *
	 * print out here the HTML-code for your custom settings
	 *
	 * @access public
	 * @param string the field
	 * @param string the current setting from the database	 
	 * @return the HTML-code
	 **/
	function printSettings($field, $set) {

		switch($field) {
			case "Starring":
				if($set=="") $set="3";
				$out = "<input type=\"text\" name=\"set{$field}\" size=\"3\" value=\"$set\"> Actors to fetch\n";
				return($out);
		}
	}
	/**
	 * saveSettings
	 *
	 * processes the $_GET-stuff and validates it and then moves it into
	 * one string that will be saved in the database (only one field is
	 * avaliable for saving the data!
	 *
	 * @access public
	 * @param  string the field
	 * @return string the string that will be saved in the db
	 **/
	function saveSettings($field) {

		switch($field) {
			case "Starring":
				return($_POST['set'.$field]);
			default:
				return("");
		}
	}

	/**
	 * setSetting
	 *
	 * will be called from editentry.php bevore calling DoFetch
	 * (only if $set is not empty)
	 * There shoud the setting be processed and saved into some
	 * class-vars...
	 *
	 * @access public
	 * @param  string 
	 * @param  string the field
	 **/
	function setSettings($field, $set) {
		switch($field) {
			case "Starring":
				if($set=="" || $set==0) $set="3";
				$this->actorLimit = $set;
				break;
		}
	}

} //end class

?>
