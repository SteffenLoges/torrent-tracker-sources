<?php
/** 
 * fetch-script: kino.de
 *
 * $Id: fetch-cdcovers_cc.php,v 1.2 2005/03/15 19:52:29 niko Exp $ 
 * 
 * @author Michael Schneider <mail@michasch-web.de>
 * @package fetch
 */

//first check if the class exists allready, if so return and don't include it again
if(class_exists("pmlfetch_cdcovers_cc")) return;

class pmlfetch_cdcovers_cc extends pml_fetch {

	//IMPORTANT: Add new fields here and in function DoFetch	
	var $FieldNames = array("front",
	                        "back",
		                    "cd",
		                    "cd2",
                            "cd3",
                            "cd4",
                            "inside",
                            "inlay");

    var $OverrideFileName = "cover.jpg";

	function doSearch(&$out, $SearchString, $EntryUrl) {		
		$Name = rawurlencode($SearchString);
		$Name = str_replace("%20", "+", $SearchString);

        $sections = array(
                          "vcd" => "Vcd Covers",
                          "dvd" => "Dvd Covers",
                          "vhs" => "Vhs Covers",
#                          "audio" => "Audio Covers",
#                          "cdi" => "CDi Covers",
#                          "dreamcast" => "Dreamcast Covers",
#                          "gamecube" => "Gamecube Covers",
#                          "gba" => "Gameboy Advance",
#                          "pc" => "Pc Covers",
#                          "psx" => "Psx Covers",
#                          "psx2" => "Psx2 Covers",
#                          "xbox" => "Xbox Covers"
                          );

        foreach($sections as $code => $descr) {
            $request = "group=$code&terms=$Name&boolean=AND&Button=Search";

    		$data = "POST http://www.cdcovers.cc/search.php HTTP/1.0\r\n";
    		$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
    		$data .= "Referer: http://www.cdcovers.cc/search.php\r\n";
    		$data .= "Accept-Language: de\r\n";
    		$data .= "Content-type: application/x-www-form-urlencoded\r\n";
    		$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
    		$data .= "Host: www.cdcovers.cc\r\n";
    		$data .= "Content-length: ".strlen($request)."\r\n";
    		$data .= "Connection: Keep-Alive\r\n";
    		$data .= "Cache-Control: no-cache\r\n";
    		$data .= "\r\n";
    		$data .= $request;

            // Seite abrufen
            $site = $this->FetchPage($data, "www.cdcovers.cc:80");
            
            $subsite=array();
            preg_match("/<TR><TD><B><U>Title<\/U><\/B><\/TD><TD><B><U>Cover Parts<\/U><\/B><\/TD><TD><\/TD><\/TR>(<tr valign=top><td><a href=\".+?\">.+?<\/a><\/td><td>.+?<\/td><\/tr>)+/", $site, $subsite);
            preg_match_all("/<tr valign=top><td><a href=\".+?\">(.+?)<\/a><\/td><td>(.+?)<\/td><\/tr>/", $subsite[0], $erg);

            // Ergebnisse in einem gro�en Array sammeln...
            for($i = 0; $i < count($erg[1]); $i++)
                $glob_erg[$code][] = array("titel" => $erg[1][$i], "available" => str_replace("[", "", str_replace("]", "", str_replace("]&nbsp;[", " - ", strip_tags($erg[2][$i])))));
        }

		$Page = basename(__FILE__);
		$Page = substr($Page, 6);
		$Page = substr($Page, 0, -4);

        if(count($glob_erg) > 0) {
            // Ende der Suche nach Covern, Ergebnisse ausgeben...
            $out= "<table>\n";
            foreach($glob_erg as $code => $data) {
                $rowcounter = 0;
                $out.= "<tr><td colspan=3><h3>Ergebnisse aus \"" . $sections[$code] . "\"</h3></td></tr>\n";
                $out.= "\n<tr><th>Title</th><th>available covers</th><th>&nbsp;</th></tr>\n";
                foreach($data as $datarow) {
                    $rownr = $rowcounter++ % 2 + 1;
                    $out.= "<tr class=\"row" . $rownr . "\"><td>" . $datarow["titel"] . "</td><td>" . $datarow["available"] . "</td><td>
							<a href=\"$EntryUrl&" . urlencode("fid[{$Page}]")."=" . $code . "|" . urlencode($datarow["titel"]) . "\">select</a>
							</td></tr>\n";					
                }
            }
            $out.= "</table>\n";
        } else {
    		$out.=$GLOBALS['strErrNothingFoundEnterNewString'];    		
    		return(PML_FETCH_SEARCHDONE);
    	}
    	
        $out.= "<br>\n";
    	$out.= $GLOBALS['strFoundMore'];		

		return(PML_FETCH_SEARCHDONE);
	}

	function GetCachedPage($Url, $Referer="http://www.cdcovers.cc/") {
        return($this->fetchCachedUrl($Url, "www.cdcovers.cc", $Referer));
	}

	/*this function is called once for every field, so it is very important
	* to use the GetCachedPage-function - the page will be loaded just once...
    *
	* IMPORTANT (if you want to add some vars)a:
	* if you add new fields, add them to var $FieldNames on top of this file
	*/
    function DoFetch(&$ret, $FieldName) {
		global $CFG;		
		
		// Fetch-ID entschl�sseln, vorarbeiten, etc...
		$this->FetchID = urldecode($this->FetchID);
		$data = explode("|", $this->FetchID, 2);
		// $data[0] = section | $data[1] = titel
		// Anfangsbuchstabe des Titels:
		$beg = strtolower(substr($data[1], 0, 1));
		if($beg == 1 || $beg == 2 || $beg == 3 || $beg == 4 || $beg == 5 || $beg == 6 || $beg == 7 || $beg == 8 || $beg == 9) $beg = 0;
		
		// entsprechende Seite laden
        $site = $this->GetCachedPage("http://www.cdcovers.cc/$data[0]_$beg.php");
		preg_match("/<OPTION value=(\d+)>$data[1]/", $site, $status);
#		preg_match("/strText;decode\(strValue\);\">(.+?)<option value=\"\">-------------------------------/msi", $site, $titelliste);
#		$titellistenteil = explode("$data[1]\n", $titelliste[1], 2);
		$available = true;
		switch($FieldName) {
			case "front":
                if(! $status[1]&1 << 0) $available = false;
                $part = 0;
                break;
            case "back":
                if(! $status[1]&1 << 1) $available = false;
                $part = 1;
                break;
			case "cd":
                if(! $status[1]&1 << 2) $available = false;
                $part = 2;
                break;			
			case "cd2":
                if(! $status[1]&1 << 3) $available = false;
                $part = 3;
                break;			
			case "cd3":
                if(! $status[1]&1 << 4) $available = false;
                $part = 4;
                break;			
			case "cd4":
                if(! $status[1]&1 << 5) $available = false;
                $part = 5;
                break;			
			case "inside":
                if(! $status[1]&1 << 6) $available = false;
                $part = 6;
                break;			
			case "inlay":
                if(! $status[1]&1 << 7) $available = false;
                $part = 7;
                break;
            default:				
				return(PML_FETCH_ITEMNOTFOUND);
				break;
        };
        if(!$available) {            
			return(PML_FETCH_ERROR);
		}

        $request = str_replace(" ", "+", "part=$FieldName&cname=$data[1]&type=$data[0]&letter=$beg&submit=Download Cover");

        $data = "POST /download.php HTTP/1.0\r\n";
       	$data .= "Accept: text/html, image/png, image/x-xbitmap, image/gif, image/jpeg, */*\r\n";
    	$data .= "Referer: http://www.cdcovers.cc/$data[0]_$beg.php\r\n";
    	$data .= "Accept-Language: de\r\n";
    	$data .= "Content-type: application/x-www-form-urlencoded\r\n";
    	$data .= "User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows 98; Win 9x 4.90)\r\n";
    	$data .= "Host: www.cdcovers.cc\r\n";
    	$data .= "Content-length: ".strlen($request)."\r\n";
    	$data .= "Connection: Keep-Alive\r\n";
    	$data .= "Cache-Control: no-cache\r\n";
    	$data .= "\r\n";
    	$data .= $request;


        $site = $this->FetchPage($data, "www.cdcovers.cc:80");
        preg_match("/document\.the_cover\.src=\"(http:\/\/covers\.cdcovers\.cc\/show\.php\?.+?)\"',/", $site, $url);
   		
   		$ret = $url[1];

		return(PML_FETCH_OK);		
	}//end function DoFetch

} //end class

?>
