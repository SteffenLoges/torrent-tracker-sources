<?php
/** powermovielist application.php
 * $Id: application.php,v 1.15 2005/12/08 12:19:04 niko Exp $
*/
$StartTime = microtime();
include("version.php");
$ExportSettingsVersion = 1;

require_once("functions.php");

if(!FileExists("config.inc.php")) {
	include("top.html");
	echo "You have first to install PowerMovieList!<br>";
	echo "Open <a href='install.php'>install.php</a> for installation...<br><br>
	If you have any questions or you found a bug visit <a href='http://www.powermovielist.com/'>www.powermovielist.com</a>";
	include("bottom.html");
	exit;
}

include("config.inc.php");
if(!isset($CFG['CustomPropTypes'])) $CFG['CustomPropTypes'] = array();
if(!isset($ConfigVerBuild)) {
	include("top.html");
	echo "<b>ERROR:</b> ";
	echo "There is something wrong with your config.inc.php.";
	include("bottom.html");
	exit;
}

if($CFG['Debug'])
	error_reporting(E_ALL);
else
	error_reporting (E_ALL ^ E_NOTICE);



$phpversion=(int)(str_replace(".","",phpversion()));

@set_time_limit($CFG['MaxExecutionTime']);

//check if update was done
if(!isset($CheckNewVersion)) $CheckNewVersion=true;

if($ConfigVerBuild<$VerBuild && $CheckNewVersion) {
	include("top.html");
	echo "You installed a new version of the PowerMovieList!<br>";
	echo "Open <a href=install.php>install.php</a> to do the update...<br><br>
	If you have any questions or you found a bug, visit <a href='http://www.powermovielist.com/'>www.powermovielist.com</a>";
	include("bottom.html");
	exit;
}

if($ConfigVerBuild>$VerBuild && $CheckNewVersion) {
	include("top.html");
	echo "<b>ERROR:</b> The version of your config-file is HIGHER then the version of the PowerMovieList you have installed!<br>";
	echo "Something seems to be very wrong :( Visit <a href='http://www.powermovielist.com/'>www.powermovielist.com</a> and ask for help...";
	include("bottom.html");
	exit;
}

include("print.php");
include("customproptypes.php");

session_name("pml");
session_start();

ConnectDatabase();

if(!isset($FILE_SELF)) $FILE_SELF="";

if(isset($_GET['Active'])) $Active = $_GET['Active']; else $Active="";

//wird nimma verwendet, aber in den alten /unterordnern/ is noch ein SetActive-Link drinnen...
if(isset($_GET['SetActive'])) {
	if(!isset($_GET['Active']))
		$Active = $_GET['SetActive'];
}

if($CFG['ListType']==2) {	
	//***********************************************************
	//Single-User-Mode, immer die erste verfgbare liste ausw?len
	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name <> 'index'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$ActiveList = mysql_fetch_assoc($result);
    $ActiveList['name'] = strtolower($ActiveList['name']);
	$Active = $ActiveList['name'];

} else {
	//***********************************************************
	//Full-Mode - alle Funktionen Aktiv!
	//Simple-Mode - es gibt kein right-management, das mit den Active-Listen und so ist gleich
	if(!$CFG['EnableIndex'] && $Active=="index") $Active="";

	if($Active!="") {
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name='$Active'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		if($result) {  //if not a valid result don't do anything with it
			$ActiveList = mysql_fetch_assoc($result);
            $ActiveList['name'] = strtolower($ActiveList['name']);
			$Active = $ActiveList['name'];
		} else {
			$Active = "";
		}
	}

	if($Active=="") {   //if no list selected
		if($CFG['EnableIndex']) {
			//Index-Seite ist aktiviert!
			$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name='index'";
			$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			if(mysql_num_rows($result)==0) {
				if($FILE_SELF != "install.php" && $FILE_SELF != "login.php") {
					include("top.html");
					die("<br><b>Error:</b> no Index-List found! execute <a href='install.php'>install-script</a>!");
				}
			}
			$row = mysql_fetch_assoc($result);
			$ActiveList = $row;
			$ActiveList['name'] = "index";
			$Active = "index";
		} else {

			//Index-Seite deaktivierit, erste verfgbare liste ausw?len:
			$strSql = "SELECT lists.* FROM " . $CFG['Prefix'] . "lists AS lists, " . $CFG['Prefix'] . "linklist AS linklist
			WHERE lists.name <> 'index'
			AND linklist.ListID=lists.ID
			ORDER BY linklist.SortOrder";
			$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$ActiveList = mysql_fetch_assoc($result);
            $ActiveList['name'] = strtolower($ActiveList['name']);
			$Active = $ActiveList['name'];
		}
	}//endif
}

$PassVar = "ViewPass" . $ActiveList['name'];

if(isset($_POST['SetViewPass'])) $_SESSION[$PassVar] = $_POST['SetViewPass'];
if(!isset($_SESSION[$PassVar])) $_SESSION[$PassVar]= "";

if(!isset($CFG['UserClass'])) $CFG['UserClass']="standalone.php";
if(!file_exists(getcwd()."/userclass/$CFG[UserClass]"))
    $CFG['UserClass'] = "standalone.php";

require("userclass/".$CFG['UserClass']); //include user-class-file

//global variable that is added to EVERY URL used within the script
//$Active is submitted here, and a session-id could be submitted too (like wbb does it!)
$GlobalArg = "?Active=$Active&";
$GlobalArgWOActive = "?"; //GlobalArg WithOut Active

if(isset($CFG['ListUrl'])) {  //<- set this setting in cfg when you use another page for displaying...
    $ListUrl = $CFG['ListUrl'];
} else {
    if($Active=="index")
        $ListUrl = "index.php$GlobalArg";
    else
        $ListUrl = "list.php$GlobalArg";
}

if(FileExists("lang/" . $ActiveList['lang'].".inc.php")) {
	include("lang/". $ActiveList['lang'] .".inc.php");
} else {
	include("lang/english.inc.php");
}

$usr = new pml_user();

if(!$usr->GetUserLoggedIn()) {
    $usr->DoAutoLogin(); //check if autologin-cookies are set and process them
}

$ActiveUser = $usr->GetActiveUser();

if(isset($_GET['Login'])) { //Show Login-Window
	RequestLogin(PML_LoginStyle_LoginForm);
}

include("counter.php");

$rights = GetRightsCode();
$ActiveUserRights = $rights['Permissions'];
$ActiveUserFetchRights = $rights['Fetch'];


//wenn edituser.php aufgerufen wird, rechte erlauben...
if($ActiveUserRights==PML_Rights_None && $FILE_SELF!="edituser.php" && $FILE_SELF!="login.php" && $FILE_SELF!="logout.php" && $FILE_SELF!="activate.php") {
    //nicht mal view-rechte vorhanden!!!
    RequestLogin(PML_LoginStyle_AccessDeniedList, PML_Rights_View);
}

if($Active=="index") {
    //prfen ob eine liste vorhanden ist, wenn nicht fehlermeldung ausgeben:
    $strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name NOT LIKE 'index'";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    if(mysql_num_rows($result)==0 && $FILE_SELF!="editlist.php" && $FILE_SELF!="install.php" && $FILE_SELF!="edituser.php" && $FILE_SELF!="login.php" && $FILE_SELF!="logout.php") {
        //wenn jedoch editlist.php?action=add aufgerufen wird, ist alles ok...
        $DOC_TITLE = "no list found";
        include("top.html");
        echo "<b>Error:</b> no lists found! Please create a new list <a href=\"editlist.php?action=add\">here</a>";
        include("bottom.html");
        exit;
    }
}

if($ActiveList['close'] && $ActiveUserRights<PML_Rights_Add && $FILE_SELF!="login.php") {
	$DOC_TITLE = $ActiveList['title'] . " - list closed";
	include("top.html");
	echo "<br><br>";

	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='30%' align='center'>
	<tr class='row2'>
	  <td align='center'>
        $ActiveList[closetext]
	  </td>
	</tr>
	<tr class='row1'>
	  <td align='center'>
        <a href='list.php".$GlobalArg."Login=1'>$strLogin</a>
	  </td>
	</tr>
	</table>";
		
		
	if($CFG['ListType'] < 2) {		
	//Bei Single-User-Mode nie die auswahl anzeigen

		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);        
		$num = mysql_num_rows($result);

		//wenn mehrere listen vorhanden auswahl anzeigen:		
		if($num>1) {
			echo "<br>
      <form name=\"ListForm\">
	  <table border='0' cellspacing='1' cellpadding='5' class='tblback' width='30%' align='center'>
		<tr class='top'>
		  <td align='center'>
		    $strSelectAnotherList:
		  </td>
		</tr>
		<tr class='row1'>
		  <td align='center'>";
echo PrintLinkList("");
echo "          </td>
		</tr>
	  </table>
	  </form>";
		}
	}
	include "bottom.html";
	exit;
}

//usepass - ob bei der liste das passwort aktiviert ist
//userrights<PML_Rights_Add - ob der benutzer nicht mehr als nur view-rechte hat (weil dann wird das pwd ignoriert)
//..!=$$passvar - ob das bereits eingegebene passwort dem tats?hlichen entspricht
if($ActiveList['usepass'] && $ActiveUserRights<PML_Rights_Add && $ActiveList['showpass']!=$_SESSION[$PassVar] && $FILE_SELF!="login.php") {
	$DOC_TITLE = $ActiveList['title'] . $strPassLogIn;
	include("top.html");
	echo "<br><br>";

	if($CFG['ListType'] < 2) {		
		//wenn nicht single-user-mode dann die liste anzeigen

		//aber auch nur wenn mehr als eine existieren
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);        
		$num = mysql_num_rows($result);
	
		if($num>1) {
			//wenn mehr als eine liste existieren, die auwahl anezigen:
			echo "<br>
      <form name=\"ListForm\">
	  <table border='0' cellspacing='1' cellpadding='5' class='tblback' width='30%' align='center'>
		<tr class='top'>
		  <td align='center'>
		    $strActiveList:
		  </td>
		</tr>
		<tr class='row2'>
		  <td align='center'>";
     		echo PrintLinkList(""); 
		echo "          </td>
		</tr>
	  </table>
	  </form>";

		} //endif $num > 1
	} //endif $CFG['ListType'] < 2	
	
	echo "<form name='PassForm' method='post' action='";
	$Dat=$FILE_SELF."?".$_SERVER['QUERY_STRING'];
	if($Dat=="") $Dat="list.php".$GlobalArg;
	echo $Dat;
	echo "'>\n";
	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='30%' align='center'>
	<tr class='row1'>
	  <td colspan='2' align='center'>
        $ActiveList[showpasstext]
	  </td>
	</tr>
	<tr class='row2'> 
	  <td align='right'>
		<b>$strLoginPass:</b>
	  </td>
	  <td>
	    <input type='password' name='SetViewPass'>
	  </td>
	</tr>
	<tr class='row1'>
	  <td>[";

	if($ActiveUser['name']=="Guest")
		echo "<a href='list.php".$GlobalArg."Login=1'>$strLogin</a>";
	else
		echo "<a href='logout.php'>$strLogout</a>";

	echo "]</td>
	    <td>
          <input type=\"submit\" name=\"Submit\" value=\"$strLogin\">
	    </td>
    </tr>
</table>
</form>	
<script language='Javascript'>
self.document.PassForm.SetViewPass.focus();
</script>";
	include("bottom.html");
	exit;
}

if(isset($LoadSmarty) && $LoadSmarty) {
    loadSmarty();
}

//the session-var CsvInputData is set when importing CSV data, the whole file is saved there.
//if the user stops importing it won't be deleted, so this is some kind of a timeout:
if(isset($_SESSION['CsvInputData'])) {
	foreach($_SESSION['CsvInputData'] as $k=>$i) {
		if($i['time']+10*60 > time()) //10 minutes
			unset($_SESSION['CsvInput'][$k]);
	}
		
}

?>