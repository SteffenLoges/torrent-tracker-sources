<?php
/** powermovielist user-class standalone
 * $Id: standalone.php,v 1.8 2005/12/16 13:43:18 niko Exp $
*/

/*
* PowerMovieList User-Class - Standalone
* 
* ->use wbb, or phpnuke or whathever script you have - users for pml!
* look into DEVEL-DOC for more information on how this works
*
*
* !DO NOT MODIFY THIS FILE!
* if you want to create a new user-class you must save it under a different
* filename. Open config.inc.php to select the file then.
*/

/*require("../wbb2/acp/lib/functions.php");
require("../wbb2/acp/lib/config.inc.php");
require("../wbb2/acp/lib/class_db_mysql.php");
require("../wbb2/acp/lib/options.inc.php");
$phpversion=(int)(str_replace(".","",phpversion()));
$db = new db($sqlhost,$sqluser,$sqlpassword,$sqldb,$phpversion);
require("../wbb2/acp/lib/session.php");
*/

class pml_user {

    var $ActiveUser=array(); //the active user-data is stored here (filled when GetActiveUser or DoLogin is called)

    var $UseEditUser = true; //true if edituser.php should be avaliable (false if users aren't saved in pml_users)

    var $UserTable = ""; //used only in editrights.php - 2do: it should work over GetUserList

    function pml_user() { //constructor
    global $CFG, $pmldb;
        $this->UserTable = $CFG['Prefix']."users";
    }

    /* function GetUserLoggedIn
    *           Returns if a user is logged in - or if the guest is logged in...
    */
    function GetUserLoggedIn() {                       
        if(isset($_SESSION['LoggedIn'])) //logged in user saved here
            $LoggedIn = $_SESSION['LoggedIn'];
        else
            $LoggedIn = ""; //guest

        if($LoggedIn=="") return(false); else return(true);
    }
    

    /* function GetActiveUser
    *           Returns the current logged in user-data as assoc-array with all entries
    *           from the user-table.
    *           The logged in user is saved in the session-var $_SESSION['LoggedIn']
    */
    function GetActiveUser() {
        global $CFG, $pmldb;        
        
        if(count($this->ActiveUser)) return($this->ActiveUser); //allready loaded...

        if(isset($_SESSION['LoggedIn'])) //logged in user saved here
            $LoggedIn = $_SESSION['LoggedIn'];
        else
            $LoggedIn = ""; //guest

        if($LoggedIn!="") {
            $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE name='$LoggedIn'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if(mysql_num_rows($result)==0) {
                $LoggedIn="";
                $_SESSION['LoggedIn'] = "";
            } else {
                $this->ActiveUser = mysql_fetch_assoc($result);                 
            }
        }
        
        if($LoggedIn=="") {
            $this->ActiveUser = array("name"=>"Guest", "admin"=>0, "ID"=>1, "email"=>"");
        }
        
        return($this->ActiveUser);        
    }

    /*function GetUserList
    *          Returns a List of all users
    */
    function GetUserList() {
        global $CFG, $pmldb;
        static $Dat=array(); //caching!

        if(sizeof($Dat)) return($Dat);

        $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $Dat = array();
        while($row=mysql_fetch_assoc($result)) {
            $Dat[$row['ID']] = $row;
        }
        return($Dat);
    }
    
    /*function DoAutoLogin
    *          checks if a autologin-cookie is set and logs in the user...
    */
    function DoAutologin() {
        global $CFG, $pmldb;
        if(!isset($_COOKIE['pmluserid'])) return(false);
        if(!isset($_COOKIE['pmluserpass'])) return(false);
        $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE ID='" . $_COOKIE['pmluserid'] . "'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        if(mysql_num_rows($result)==0)
            return(false);        
        
        $this->ActiveUser = mysql_fetch_array($result);
        if($CFG['UseActivate'] && $this->ActiveUser['activate']!=0)
            return(false);
        if($CFG['UseUserStatus'] && $this->ActiveUser['status']==0)
            return(false);

        if($_COOKIE['pmluserpass']!=$this->ActiveUser['pass'])
            return(false);

        $_SESSION['LoggedIn'] = $this->ActiveUser['name'];

        return(true);
    }

    /*function DoLogin
    *          Process login - check the password, activation and save user in LoggedIn if it is correct
    */
    function DoLogin($User, $Pass) {
        global $CFG, $pmldb;
        
        $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE name='" . $User . "'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        if(mysql_num_rows($result)==0) {
            RequestLogin(PML_LoginStyle_UserNotFound);
            exit;
        }
        $this->ActiveUser = mysql_fetch_array($result);
        if($CFG['UseUserStatus'])
        {
            if($this->ActiveUser['status']==0)
            {
                $_SESSION['LoggedIn'] = "";
                $this->ActiveUser=array();
                RequestLogin(PML_LoginStyle_UserNoStatus);
                exit;
            }
        }
        if($CFG['UseActivate'])
        {
            if($this->ActiveUser['activate']!=0)
            {
                $_SESSION['LoggedIn'] = "";
                $this->ActiveUser=array();
                RequestLogin(PML_LoginStyle_UserNotActivated);
                exit;
            }
        }
        
        $Pass = md5($Pass);
        
        if($Pass!=$this->ActiveUser['pass']) {
            $_SESSION['LoggedIn'] = "";
            $this->ActiveUser=array();
            RequestLogin(PML_LoginStyle_WrongPass);
            exit;
        }
        
        $_SESSION['LoggedIn'] = $this->ActiveUser['name'];
        
        $x=parse_url($CFG['HttpPath']);
        if(isset($_POST['savelogin'])) { //save autologin-data in cookie?               
            setcookie("pmluserid", $this->ActiveUser['ID'], time()+60*60*24*14, "", ""); //set cookies for userid and userpass - only for valid host and path!
            setcookie("pmluserpass", $this->ActiveUser['pass'], time()+60*60*24*14, "", "");            
        } else {
            setcookie("pmluserid", "", time()-60*60, "", "");     //delete cookie
            setcookie("pmluserpass", "", time()-60*60, "", "");            
        }
    }
    
    /*function DoLogout
    *          Loggs out the user - clears the session-var and the cookie
    */
    function DoLogout() {
        global $CFG;
	    $_SESSION['LoggedIn'] = ""; //logout...

        $x=parse_url($CFG['HttpPath']);
        setcookie("pmluserid", "", time()-3600, "", "");     //delete autologin-cookies
        setcookie("pmluserpass", "", time()-3600, "", "");            
        return(true);
    }

    /*function DoLostPassword
    *          lost-password-function
    */
    function DoLostPassword($User, $EMail) {
        global $CFG, $pmldb;
        $DOC_TITLE = $GLOBALS['strLostPassword'];
        include("top.html");
        $strSql = "SELECT * FROM " . $CFG['Prefix'] . "users WHERE name='$User' AND email='$EMail'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);      
        if(mysql_num_rows($result)==0) {
            ErrorExit($GLOBALS['strUserOrMailNotFound']); 
        }
        $row = mysql_fetch_array($result);
        //the new password:
        $NewPass = substr(md5(rand(0,999999)),0,8);
        $strSql = "UPDATE " . $CFG['Prefix'] . "users Set pass='".md5($NewPass)."' WHERE ID=$row[ID]";

        
        $MailFileName = "lostpassword";

        if(FileExists("mail/$MailFileName.$ActiveList[lang].txt"))
            $MailFileName = "mail/$MailFileName.$ActiveList[lang].txt";
        else
            $MailFileName = "mail/$MailFileName.english.txt"; //use the default-file

        $MailSubject = $GLOBALS['strLostPassword']; //default Value
        $MailData = file($MailFileName);
        foreach($MailData as $k=>$Line) {
            $MailData[$k] = trim($MailData[$k]);
            $MailData[$k] = str_replace("_NEWNAME_", "$row[name]", $MailData[$k]);
            $MailData[$k] = str_replace("_USERNAME_", "$row[name]", $MailData[$k]);
            $MailData[$k] = str_replace("_NEWPASS_", "$NewPass", $MailData[$k]);
            $MailData[$k] = str_replace("_HTTPPATH_", "$CFG[HttpPath]", $MailData[$k]);
            if($MailData[$k]!="" && strstr($MailData[$k],"Subject: ")==$MailData[$k]) {
                $MailSubject =  str_replace("Subject: ", "", $MailData[$k]);
                unset($MailData[$k]); //delete this line
            }
        }

        if($CFG['Debug']) {
            echo "<pre>";
            echo "To: $row[email]\nSubject: $MailSubject\nFrom: $CFG[AdminEmail]\n";
            echo "\n";
            echo implode("\n", $MailData);
            echo "</pre>";
        }

        if(!mail($row['email'], $MailSubject, implode("\n", $MailData),"From: $CFG[AdminEmail]"))
            ErrorExit("can't send email!!");

        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    }

    /*function GetRegisterUserLink
    *          returns link where new users can register
    */
    function GetRegisterUserLink() {
        return("edituser.php".$GLOBALS['GlobalArg']."action=add");
    }

    /*function GetEditUserLink
    *          returns link the user with $ID can be edited
    */
    function GetEditUserLink($ID) {
        return("edituser.php".$GLOBALS['GlobalArg']."action=edit&ID=$ID");
    }

    /*function GetDeleteUserLink
    *          returns link where user with $ID can be deleted
    */
    function GetDeleteUserLink($ID) {
        return("edituser.php".$GLOBALS['GlobalArg']."action=delpass&ID=$ID");
    }

    /*function GetMemberListLink
    *          returns link for the member-list
    */
    function GetMemberListLink() {
        return("edituser.php".$GLOBALS['GlobalArg']."action=");
    }

    /*function GetUserDetailsLink
    *          returns link for the usersdetails user with $ID
    */
    function GetUserDetailsLink($ID) {
        return("edituser.php".$GLOBALS['GlobalArg']."action=details&ID=$ID");
    }

    /*function CountClick
    *          Counts a click for the active user
    */
    function CountClick() {
        global $CFG, $pmldb;
        if($this->ActiveUser['name']=="Guest") return;
        $strSql = "UPDATE " . $CFG['Prefix'] . "users SET dloadcount=dloadcount+1 WHERE ID=" . $this->ActiveUser['ID'];
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    }

    /*function GetUserCount
    *          returns how many users are in the database (without guest!)
    */
    function GetUserCount() {
        global $CFG, $pmldb;
        $strSql = "SELECT COUNT(*) FROM $CFG[Prefix]users WHERE name!='Guest'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);      
        $row = mysql_fetch_row($result);
        return($row[0]);
    }

};

?>