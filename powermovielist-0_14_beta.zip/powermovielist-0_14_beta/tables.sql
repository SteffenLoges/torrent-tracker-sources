CREATE TABLE pml_counter (
    ListID INT NOT NULL,
    IP INT NOT NULL,
    UserID INT NOT NULL,
    CountTime INT NOT NULL
);

CREATE TABLE pml_dloadlog (
  movieID BIGINT NOT NULL default '0',
  date datetime NOT NULL default '0000-00-00 00:00:00',
  ip INT(11) NOT NULL,
  UserID INT NOT NULL
);

CREATE TABLE pml_linklist (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Type ENUM('User','Url') NOT NULL,
    ListID INT NOT NULL,
    Url VARCHAR(50) NOT NULL,
    Text VARCHAR(30) NOT NULL,
    SortOrder INT NOT NULL
);

CREATE TABLE pml_comment (
  ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  MovieID BIGINT NOT NULL,
  Date DATETIME NOT NULL,
  IP INT(11) NOT NULL,
  Text VARCHAR(255) NOT NULL,
  UserID INT NOT NULL
);

CREATE TABLE pml_users (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(32) NOT NULL,
    pass VARCHAR(32) NOT NULL default '',
    email VARCHAR(100) NOT NULL default '',
    icq VARCHAR(30) NOT NULL default '',
    aim VARCHAR(30) NOT NULL default '',
    userhp VARCHAR(100) NOT NULL default '',
    location VARCHAR(50) NOT NULL default '',
    work VARCHAR(50) NOT NULL default '',
    gender TINYINT NOT NULL,
    birthdate DATE NOT NULL,
    regdate DATE NOT NULL,
    admin TINYINT NOT NULL,
    dloadcount INT NOT NULL,
    showemail TINYINT NOT NULL DEFAULT '0',
    activate INT NOT NULL,
    status TINYINT NOT NULL DEFAULT '0'
);

CREATE TABLE pml_userrights (
    UserID INT NOT NULL,
    ListID INT NOT NULL,
    Permissions INT NOT NULL,
    FetchRights TINYINT,
    UNIQUE KEY Entry (UserID,ListID)
);

CREATE TABLE pml_movies (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ListID int(11) NOT NULL default '0',
    DateAdded datetime NOT NULL default '0000-00-00 00:00:00',
    UserAddedID INT DEFAULT '0' NOT NULL
);

CREATE TABLE pml_votes (
  ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  PropID INT NOT NULL,
  MovieID BIGINT NOT NULL,
  Vote TINYINT NOT NULL,
  IP INT(11) NOT NULL,
  UserID INT NOT NULL
);

CREATE TABLE pml_lists (
  ID int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(32) NOT NULL,
  title VARCHAR(30) NOT NULL,
  urlname VARCHAR(50) NOT NULL,
  url VARCHAR(50) NOT NULL,
  image VARCHAR(30) NOT NULL,
  lang VARCHAR(30) NOT NULL,
  designcss VARCHAR(30) NOT NULL,
  usepass TINYINT NOT NULL DEFAULT '0',
  showpass VARCHAR(15) NOT NULL,
  showpasstext VARCHAR(200) NOT NULL,
  showcounter TINYINT NOT NULL DEFAULT '1',  
  showprint TINYINT NOT NULL DEFAULT '1',
  showchars TINYINT NOT NULL DEFAULT '1',  
  showsortlinks TINYINT NOT NULL DEFAULT '0',
  showsearch TINYINT NOT NULL DEFAULT '1',
  showfilter TINYINT NOT NULL DEFAULT '1',
  showperpage TINYINT NOT NULL DEFAULT '1',
  counter int(11) NOT NULL DEFAULT '0',
  maxonline int(11) NOT NULL DEFAULT '0',
  close TINYINT NOT NULL DEFAULT '0',
  closetext VARCHAR(200) NOT NULL,
  allowcomments TINYINT NOT NULL DEFAULT '0',
  marknew INT NOT NULL DEFAULT '0',  
  popuptpl VARCHAR(30) NOT NULL,
  listtpl VARCHAR(30) NOT NULL,
  stdsort INT NOT NULL DEFAULT '0',
  StdPerPage INT NOT NULL DEFAULT '50',
  ShowOnIndex TINYINT NOT NULL DEFAULT '1',
  FetchTextPropID INT NOT NULL DEFAULT '0',
  EnableLoan TINYINT NOT NULL DEFAULT '0',
  IndexType TINYINT NOT NULL DEFAULT '0',
  UserID INT NOT NULL
);



##########################################################
# here are all avaliable properties for every movie stored
CREATE TABLE pml_prop (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,

    ListID INT NOT NULL,                         # the pml_lists.ID-number
#FilterVal

    Name CHAR(20) NOT NULL,                      # name of this property, used for template-systems
#username

    SortOrder INT NOT NULL,                      # the propierties can be sorted
#SortOrder

    PropType TINYINT NOT NULL DEFAULT '0',       # avaliable Types:                                                
                                                 #      PML_PropType_Text                    0 Text   (zB Titel, Director etc...)
                                                 #      PML_PropType_Date                    1 Date   (zB Release-Date)
                                                 #      PML_PropType_Boolean                 2 Boolean (= checkbox, zB Watched, Burned)
                                                 #      PML_PropType_ListBox                 3 ListBox (zB Format, Quality - only one can be selected)
                                                 #      PML_PropType_ListBoxMulti            4 ListBoxMulti (zB Genre - multiple selections)
                                                 #      PML_PropType_Textfield               5 Textfield (zB Plot)                                                 
                                                 #      PML_PropType_Url                     6 Url (zB Picture)
                                                 #      PML_PropType_UrlCached               7 Url,Cached (zB Picture) (caching has to be activated in config)
                                                 #      PML_PropType_FileUpload              8 File-Upload! (allowed types defined in pml_propval WHERE MovieID=0(?))
                                                 #      PML_PropType_UserRating              9 User-Rating
                                                 #      PML_PropType_DownloadLink           10 Download-Link
                                                 #      PML_PropType_StaticText             11 Static Text (only displayed on List) -> text saved in pml_propval WHERE MovieID=0
                                                 #      PML_PropType_DisplayNr              13 Nr (of displaying, not index)
                                                 #      PML_PropType_AutoIncrement          15 Auto-Increment (normal text field)
                                                 #      PML_PropType_DownloadLinkFileUpload 16 Download-Link with FileUpload

#listbox

    InTitle VARCHAR(30) NOT NULL,                # text displayed when entering the propertie
#text

    InProp VARCHAR(30) NOT NULL,                 # properties for input-field
#text

    ShowInList TINYINT NOT NULL DEFAULT '1',     # if this property should be shown in list
#checkbox

    ImageSize VARCHAR(30) NOT NULL DEFAULT '',   # size of the image
#checkbox

    ListHeader VARCHAR(30) NOT NULL,             # Text displayed in the Header of the List
#text

    UseSort TINYINT NOT NULL,                    # if a sort link should be displayed
                                                 # 0 dont use
                                                 # 1 use, default ASC
                                                 # 2 use, default DESC
#listbox

    ListProperties VARCHAR(30) NOT NULL,         # properties like width and align
#listbox, text (?)

    Url VARCHAR(50) NOT NULL,                    # Url, when a link should be displayed in the list
#text
        
    ShowFilter TINYINT NOT NULL DEFAULT '1',     # if a filter should be shown on the list
                                                 # PML_ShowFilter_DontShow      0 dont show
                                                 # PML_ShowFilter_Listbox      1 show listbox
                                                 # PML_ShowFilter_Search      2 search through the search-text-function
                                                 # PML_ShowFilter_Chars          3 use the Chars on top of the list (if enabled)
                                                 # PML_ShowFilter_SearchChars 4 use Chars and search-text-function
#listbox

    StdFilterPropValID INT NOT NULL,             # the standard-value of the filter, only avaliable if ShowFilter=PML_ShowFilter_Listbox
#listbox

    ShowInPopUp TINYINT NOT NULL DEFAULT '1',    # if this property should be shown in the dload/info-popup
                                                 # PML_PopUp_DontShow    0 dont show
                                                 # PML_PopUp_Normal        1 displayed together with all the other properties
                                                 # PML_PopUp_ExtraField    2 displayed as extra field like plot or user-rating
                                                 # PML_PopUp_Dowload    3 displayed at download-links
                                                 # PML_PopUp_Cover        4 displayed at covers
#listbox

    ShowOnCover TINYINT NOT NULL DEFAULT '1',    # if this property should be shown on the cover
                                                 # PML_Cover_DontShow    0 dont show
                                                 # PML_Cover_Normal        1 show as normal text
                                                 # PML_Cover_SideTitle    2 show on the side as title
                                                 # PML_Cover_SideLang    3 show on the side as langauge
                                                 # PML_Cover_SideFormat    4 show on the side as format
                                                 # PML_Cover_Pic        5 show as picture (url!!)
                                                 # PML_Cover_Format        6 show as format-logo (image has to exist) AND on the side as format
                                                 # PML_Cover_Index      7 show on the side as index-nr
#listbox

    ShowLinkType TINYINT NOT NULL DEFAULT '1',   # how the link should be displayed on the list
                                                 # only for PML_PropType_Url, PML_PropType_UrlCached, PML_PropType_FileUpload
                                                 # PML_ShowLinkType_Normal     0 open url in same page
                                                 # PML_ShowLinkType_Newpage    1 open url in new page
                                                 # PML_ShowLinkType_Image      2 show url as image
#listbox (only when url or cached url)

    RequiredRights TINYINT NOT NULL DEFAULT '0', # what rights the logged in user must have to see this field
                                                 # 0: none, show to all
                                                 # 1: view-rights - should be anyone who sees the list
                                                 # 2: loan-rights and higher
                                                 # 3: add-rights and higher
                                                 # 4: moderator-rights and higher
                                                 # 5: list-admin-rights and higher
                                                 # 6: super-admin
                                                 #    ---
                                                 # -1: registered user (hide for guests)
#listbox

    ShowAdd TINYINT NOT NULL DEFAULT '1'         # should this property be displayed when adding a new entry
                                                 # 0: No
                                                 # 1: Yes
#checkbox

);


##########################################################
# here are all the avaliable property-values saved for ListBox and ListBoxMulti
CREATE TABLE pml_propval (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    PropID INT NOT NULL,                         # the pml_prop.ID-number
#Filter

    DisplayText VARCHAR(30) NOT NULL,            # the entry itself (this is displayed everywhere) - can be the translated version
#text

    DisplayTextShort VARCHAR(20) NOT NULL,       # short text displayed in the list - translated too...
#text

    DisplayTextHtml VARCHAR(50) NOT NULL,        # html-code displayed in the list - can be an image (mainly for langauge-flags used)
#text

    FetchText VARCHAR(30) NOT NULL,              # if imdb.com is used for this prop, the imdb.com-equal text (when DisplayText is translated)
#text

    SortText VARCHAR(20) NOT NULL,               # text used for sorting
#text
	
    Value TINYINT NOT NULL,                      # for booleans: 1 or 0 for checked or unchecked
#only for boolean, listbox

    SortOrder INT NOT NULL
#SortOrder
);

##########################################################
# here are the news/announcments saved that can be displayed on top of
# every list
# saved is too who added it and when...
CREATE TABLE pml_announcment (
    ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
    ListID INT UNSIGNED NOT NULL, 
    UserID INT UNSIGNED, 
    DateAdded DATETIME, 
    Text TEXT,
    UseDate TINYINT NOT NULL DEFAULT '0',
    DateOn DATE NOT NULL,
    DateOff DATE NOT NULL
);

##########################################################
# here are the news/announcments saved that can be displayed on top of
# every list
# saved is too who added it and when...
CREATE TABLE pml_propfetch (
    ID INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,    
    PropID INT NOT NULL,
    FetchScript CHAR(30) NOT NULL,
    SortOrder INT NOT NULL,
    Settings VARCHAR(50) NOT NULL
);

##########################################################
# here are the list-favorites for every user saved.
CREATE TABLE pml_fav (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    ListID INT NOT NULL,
    SortOrder INT NOT NULL,
    UNIQUE KEY Entry (UserID,ListID)
);

############################################################
# LoanStatus - by studeggle  
#status is an integer equal to one of the following values
#1-cart, 2-reserved, 3-loaned
#when status is 1 date will be when it was placed in the cart, 2 - when reserved, 3 - when loaned.
CREATE TABLE pml_loanstatus (
  UserID INT NOT NULL default '0',
  MovieID BIGINT NOT NULL default '0',
  status TINYINT NOT NULL default '0',
  date DATE NOT NULL default '0000-00-00',
  Duration SMALLINT NOT NULL default '7'
);

############################################################
# Index-Items - Properties shown on the Index-Page
CREATE TABLE pml_indexitems (
  ID INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,    
  Name VARCHAR(20) NOT NULL,         #name of the property
  SortOrder INT NOT NULL,
  ListHeader VARCHAR(30) NOT NULL,   #text displayed in the index-page
  LoadOnly TINYINT NOT NULL default '0',
  DisplayOptions VARCHAR(20) NOT NULL
);

CREATE TABLE pml_usergroup (
 UG_ID SMALLINT NOT NULL AUTO_INCREMENT ,
 Name VARCHAR( 50 ) NOT NULL ,
 IsDefault TINYINT NOT NULL ,
 PRIMARY KEY ( UG_ID ) ,
 INDEX ( IsDefault )
);

CREATE TABLE pml_user2group (
 U_ID INT NOT NULL ,
 UG_ID SMALLINT NOT NULL ,
 UNIQUE (U_ID, UG_ID)
);

CREATE TABLE pml_group2list (
 UG_ID SMALLINT NOT NULL ,
 L_ID INT NOT NULL ,
 Permissions TINYINT NOT NULL ,
 FetchRights TINYINT,
 UNIQUE (UG_ID, L_ID)
);