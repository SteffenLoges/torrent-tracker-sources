<?php
/** powermovielist edit users
 * $Id: editusergroups.php,v 1.3 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "editusergroups.php";
include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";


$Title = "usergroup";
$TitlePl = "usergroups";
$Table = $CFG['Prefix'] . "usergroup";

$SessionVar = "editusergroups";

$DisplayFormList = true;

$primaryKey = "UG_ID";

$i=0;
$Show[$i]['name'] = "Name";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = "Usergroup";
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = true;
$Show[$i]['sortkey'] = "name";
$Show[$i]['sortdir'] = 0;
$Show[$i]['sortdef'] = true;
$i++;
$Show[$i]['name'] = "IsDefault";
$Show[$i]['type'] = "editcheckbox";
$Show[$i]['prop'] = "1;0";
$Show[$i]['text'] = "Default";
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = true;
if($CFG['UserClass']=="standalone.php") {
    //only in standalone, else print nothing
    $i++;
    $Show[$i]['name'] = "users";
    $Show[$i]['type'] = "func";
    $Show[$i]['text'] = "Users";
    $Show[$i]['comm'] = "";
    $Show[$i]['func'] = "printUsers";
    $Show[$i]['main'] = true;
    $Show[$i]['save'] = false;
    $i++;
    $Show[$i]['name'] = "lists";
    $Show[$i]['type'] = "func";
    $Show[$i]['text'] = "Lists";
    $Show[$i]['comm'] = "";
    $Show[$i]['func'] = "printLists";
    $Show[$i]['main'] = true;
    $Show[$i]['save'] = false;

    
}
if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

$Filter = "";
$FilterVal = "";

$DOC_TITLE = $TitlePl;
include("top.html");


include("edit.php");

if($action=="editsave" || $action=="addsave" || $action=="delsave") {
    $action = "";
    $_GET['action'] = $action;
    include("edit.php");
    include("bottom.html");
    exit;
}


include("bottom.html");

function printUsers($ID) {
    global $GlobalArg,$CFG, $pmldb;
    $strSql = "SELECT COUNT(u2g.U_ID) FROM $CFG[Prefix]user2group u2g WHERE u2g.UG_ID='$ID'";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row = mysql_fetch_row($result);
    if($row[0] > 8) {
        echo $row[0]." users";
    } else {
        $strSql = "SELECT u.Name FROM $CFG[Prefix]user2group u2g, $CFG[Prefix]users u WHERE u2g.U_ID=u.ID AND u2g.UG_ID='$ID'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $fs="";
        while($row=mysql_fetch_row($result)) {
            $fs .= $row[0].", ";
        }
        if($fs=="")
            $fs="none";
        else
            $fs=substr($fs,0,-2); //trim the ", "
        echo $fs;
    }
}

function printLists($ID) {
    global $GlobalArg,$CFG, $pmldb;
    $strSql = "SELECT COUNT(g2l.L_ID) FROM $CFG[Prefix]group2list g2l WHERE g2l.UG_ID='$ID'";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row = mysql_fetch_row($result);
    if($row[0] > 8) {
        echo $row[0]." lists";
    } else {
        $strSql = "SELECT l.Name FROM $CFG[Prefix]group2list g2l, $CFG[Prefix]lists l WHERE g2l.L_ID=l.ID AND g2l.UG_ID='$ID'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $fs="";
        while($row=mysql_fetch_row($result)) {
            $fs .= $row[0].", ";
        }
        if($fs=="")
            $fs="none";
        else
            $fs=substr($fs,0,-2); //trim the ", "
        echo $fs;
    }
}
?>