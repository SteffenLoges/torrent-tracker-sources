<?php
/** powermovielist edit rights
 * $Id: editrights.php,v 1.8 2005/10/25 18:15:51 niko Exp $
*/
$FILE_SELF = "editrights.php";
include_once("application.php");

if($CFG['ListType'] >= 2) {
	include("top.html");
	echo "This feature is not enabled for this list. Please use another list-type.";
	exit;
}

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

$Title = $strUserRightsTitle;
$TitlePl = $strUserRightsTitle;

$Table = $usr->UserTable;
$SelectFrom = "$Table.ID, $Table.name, $Table.admin, $Table.regdate, IF(ISNULL($CFG[Prefix]userrights.Permissions), -1, $CFG[Prefix]userrights.Permissions) AS Permissions, $CFG[Prefix]userrights.FetchRights";
$joinTable = "LEFT JOIN $CFG[Prefix]userrights ON $CFG[Prefix]userrights.UserID=$Table.ID AND $CFG[Prefix]userrights.ListID=$ActiveList[ID] ";
$joinTable .= "LEFT JOIN $CFG[Prefix]user2group u2g ON u2g.U_ID=$Table.ID ";
$groupBy = "$Table.ID";

$Filter = "";
$FilterVal = "";

$SessionVar = "editrights";


$DisplayFilterButton = "search";
$i=0;
$DisplayFilter[$i]['name'] = "name";
$DisplayFilter[$i]['text'] = $strSearchFor;
$DisplayFilter[$i]['type'] = "text";
$DisplayFilter[$i]['sql'] = "(name LIKE '%_Text%')";
$i++;
$DisplayFilter[$i]['name'] = "usergroup";
$DisplayFilter[$i]['type'] = "listbox";
$DisplayFilter[$i]['text'] = "usergroup";
$strSql = "SELECT UG_ID, Name FROM $CFG[Prefix]usergroup";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
$DisplayFilter[$i]['item'] = array("all");
$DisplayFilter[$i]['itemsql'] = array("1");
while($row = mysql_fetch_row($result)) {
    $DisplayFilter[$i]['item'][] = $row[1];
    $DisplayFilter[$i]['itemsql'][] = "u2g.UG_ID='$row[0]'";
}
$i++;
$DisplayFilter[$i]['name'] = "specialrights";
$DisplayFilter[$i]['type'] = "listbox";
$DisplayFilter[$i]['text'] = "rights";
$DisplayFilter[$i]['item'] = array("all", "from group", "special rights");
$DisplayFilter[$i]['itemsql'] = array("1", "ISNULL($CFG[Prefix]userrights.Permissions)", "NOT ISNULL($CFG[Prefix]userrights.Permissions)");

$ShowEditLinks = false;
$DisplayFormList = true;
$HideAddLink = true;


$i=0;
$Show[$i]['name'] = "name";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = $strEditUserFldName;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;
$Show[$i]['sortkey'] = "name";
$Show[$i]['sortdir'] = 0;
$Show[$i]['sortdef'] = true;
$Show[$i]['url'] = $usr->GetUserDetailsLink("_ID");
$i++;
$Show[$i]['name'] = "usergroups";
$Show[$i]['type'] = "func";
$Show[$i]['text'] = "Usergroups";
$Show[$i]['comm'] = "";
$Show[$i]['func'] = "printUsergroups";
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;
$i++;
$Show[$i]['name'] = "regdate";
$Show[$i]['type'] = "hidden";
$Show[$i]['prop'] = "";
$Show[$i]['text'] = $strRegDate;
$Show[$i]['comm'] = $strEditOptional;
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['save'] = false;
$Show[$i]['sortkey'] = "regdate";
$Show[$i]['sortdir'] = 1;
$Show[$i]['sortdef'] = false;
$i++;
$Show[$i]['text'] = "Permissions";
$Show[$i]['name'] = "Permissions";
$Show[$i]['type'] = "func";
$Show[$i]['func'] = "printPermissions";
$Show[$i]['main'] = true;
if($Active!="index") {
    $i++;
    $Show[$i]['text'] = "Fetch-Rights";
    $Show[$i]['name'] = "FetchRights";
    $Show[$i]['type'] = "func";
    $Show[$i]['func'] = "printFetch";
    $Show[$i]['main'] = true;
}

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

if(!($action=="" || $action=="listsave"))
	ErrorExit("invalid action!");

$DOC_TITLE = $Title;
include("top.html");


if($action=="listsave")
{
    foreach($_POST['Permissions'] as $U_ID=>$Permissions) {
        if($Permissions==-1) { //use rights from group
            $strSql = "DELETE FROM $CFG[Prefix]userrights WHERE UserID=$U_ID AND ListID='$ActiveList[ID]'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        } else {
            if(isset($_POST['FetchRights'][$U_ID])) {
                $Fetch = 1;
            } else {
                $Fetch = 0;
            }
            $strSql = "REPLACE INTO $CFG[Prefix]userrights (UserID, ListID, Permissions, FetchRights) VALUES ('$U_ID', '$ActiveList[ID]', '$Permissions', '$Fetch')";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }
    }
    $action = "";
    $_GET['action'] = "";
}


include("edit.php");


include("bottom.html");


function printUsergroups($ID) {
    global $GlobalArg,$CFG, $pmldb;
    $strSql = "SELECT g.Name FROM $CFG[Prefix]user2group u2g, $CFG[Prefix]usergroup g WHERE u2g.U_ID='$ID' AND u2g.UG_ID=g.UG_ID";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $fs="";
    while($row=mysql_fetch_row($result)) {
        $fs .= $row[0].", ";
    }    
    if($fs=="")
        $fs="none";
    else
        $fs=substr($fs,0,-2); //trim the ", "
    $fs = trim($fs);
    if(strlen($fs)>20)
        $fs = substr($fs,0,20)."...";
    echo $fs;
}

function printPermissions($ID, $row)
{
    global $CFG, $pmldb, $strUserRights, $ActiveList;

    if($row['admin']==1) {
        echo "Super-Admin";
        return;
    }
    $groupPermissions = -2; //no rights at all
    $strSql = "SELECT Permissions, g.Name
                FROM $CFG[Prefix]user2group u2g,
                     $CFG[Prefix]usergroup g, $CFG[Prefix]group2list g2l
                WHERE u2g.UG_ID = g.UG_ID
                AND   g.UG_ID   = g2l.UG_ID
                AND   g2l.L_ID  = '$ActiveList[ID]'
                AND   u2g.U_ID    = '$ID'
                ORDER BY Permissions DESC
                LIMIT 1";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    if($r = mysql_fetch_row($result)) {
        $groupPermissions = $r[0];
        $groupName = $r[1];
    }
    
    $Sel = $row['Permissions'];
    if($groupPermissions==-2) {
        $prop[] = "from group (none defined)";
        $val[] = -1;
    } else {
        $prop[] = "from group $groupName (".$strUserRights[$groupPermissions].")";
        $val[] = -1;
    }
    $prop[] = $strUserRights[0];
    $val[] = 0;
    $prop[] = $strUserRights[1];
    $val[] = 1;
    if($ActiveList['name']!="index") {
        $prop[] = $strUserRights[2];
        $val[] = 2;
        $prop[] = $strUserRights[3];
        $val[] = 3;
        $prop[] = $strUserRights[4];
        $val[] = 4;
        $prop[] = $strUserRights[5];
        $val[] = 5;
    }
    
    echo "\n        <select name='Permissions[$ID]'>\n";
    for($x=0;$x<sizeof($prop);$x++) {
        echo "          <option value='" . $val[$x] . "'";
        if($Sel==$val[$x]) echo " selected";
        echo ">" . $prop[$x] . "</option>\n";
    }
    echo "      </select>\n";

}

function printFetch($ID, $row)
{
    if($row['Permissions']==-1) return;
    if($row['admin']) return;
    if($row['Permissions']<PML_Rights_Add) return;
    $Sel = $row['FetchRights'];
    echo "<INPUT TYPE='checkbox' NAME='FetchRights[" . $ID . "]' value='set'";
    if($Sel) echo " checked";
    echo ">";
}

?>