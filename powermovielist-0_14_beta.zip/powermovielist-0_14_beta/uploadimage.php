<?php
/** powermovielist upload image
 * $Id: uploadimage.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "uploadimage.php";
$LoadSmarty = true;
include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

$DOC_TITLE = $strUploadImageTitle;
include("top.html");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

if($action!="dosave") {
	echo "<h1>$strUploadImageTitle</h1>
	<p>$strUploadText</p>
	<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='uploadimage.php".$GlobalArg."action=dosave'>
		<INPUT TYPE='hidden' name='MAX_FILE_SIZE' value='1048576'>
		<INPUT NAME='userfile' TYPE='file'><br>
		<INPUT TYPE='submit'>
	</FORM><br><br>
	";

	include("bottom.html");
	exit;
}

if($action=="dosave") {
	if($_FILES['userfile']['name']=="" || $_FILES['userfile']['name']=="none")
		ErrorExit($strUploadNoImage);


	if(FileExists("image/logos/". $_FILES['userfile']['name']))
		ErrorExit($strUploadImageExists);

	if (!is_uploaded_file($_FILES['userfile']['tmp_name']))
		ErrorExit("$strNotAValidFile!");

    $ext = substr($_FILES['userfile']['name'],-4);
	if ($ext!=".jpg" && $ext!=".gif" && $ext!=".png")
		ErrorExit("$strNotAValidFile!");

	copy($_FILES['userfile']['tmp_name'], "image/logos/" . $_FILES['userfile']['name']);
	unlink($_FILES['userfile']['tmp_name']);
	echo $strUploadImageSaved;

	$strSql = "UPDATE " . $CFG['Prefix'] . "lists SET image='" . $_FILES['userfile']['name'] . "' WHERE ID=" . $ActiveList['ID'];
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	echo $strUploadConfigSaved;	

	//clear the smarty cache for this list
	$smarty->clear_cache(null,"list|$Active");

}

?>