<?php
/** powermovielist print-list
 * $Id: printlist.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "printlist.php";
include_once("application.php");

LoadPropAll();

if(isset($_GET['action'])) $action = $_GET['action']; else $action="";

if($action=="") {
	$DOC_TITLE = "$strPrintList";
	include("top.html");
	echo "<h1>$strPrintList</h1>\n";
	echo "<FORM METHOD=POST ACTION='printlist.php".$GlobalArg."action=print'>";
	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";	

	echo "<tr class='row1'><td align=right>$strSortBy:</td>\n<td>";
	echo "<select name='Sort'>\n";
	echo "  <option value='0'>$strDateAdded</option>\n";
	echo "  <option value='-1'>Clicks</option>\n";
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
        if(!$Prop['UseSort']) continue;
		echo "  <option value='$Prop[ID]'>$Prop[InTitle]</option>\n";
	}
	echo "</select>\n";
	echo "</td>\n</tr>\n";
	echo "<tr class='top'><td align='right'>$strFilters</td><td>&nbsp;</td>\n";	
	
	$cls=1;
	foreach($PropAll as $kProp=>$Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if(!$Prop['ShowInList']) continue; //don't show filter if fld not shown on list
		if($Prop['ShowFilter']!=1) continue; //1 = show listbox
		if($Prop['PropType']!=PML_PropType_ListBox && $Prop['PropType']!=PML_PropType_ListBoxMulti && $Prop['PropType']!=PML_PropType_Boolean) continue; //only listbox and listboxmulti
		$strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=$kProp ORDER BY SortOrder";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		echo "<tr class='";
		if($cls++%2) echo "row1"; else echo "row2";
		echo "'><td align='right'>$Prop[InTitle]:</td>\n<td>";
		echo "<select name='Filter[$kProp]'>\n";
		echo "  <option value='0'";
		if(!isset($sDisplay['Filter'][$kProp])) $sDisplay['Filter'][$kProp]=0;
		if($sDisplay['Filter'][$kProp]==0)
			echo " selected";
		echo ">$strAll</option\n";
		while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo "  <option value='$row[ID]'";
			if($sDisplay['Filter'][$kProp]==$row['ID'])
				echo " selected";
			echo ">$row[DisplayText]</option>\n";
		}
		echo "</select>\n";
		echo "</td></tr>\n";		
	}

	
    echo "<tr class='";
	if($cls++%2) echo "row1"; else echo "row2";
	echo "'><td align=right>Text-Filter:</td><td>";
	echo "<input type='text' name='Search' value=''></td></tr>\n";

	echo "<tr class='top'><td align=right>Fields to print</td><td>&nbsp;</td></tr>\n";
	$cls=1;
	foreach($PropAll as $Prop) {		
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
        if($Prop['PropType']==PML_PropType_DisplayNr || $Prop['PropType']==PML_PropType_Url || $Prop['PropType']==PML_PropType_UrlCached || $Prop['PropType']==PML_PropType_FileUpload || $Prop['PropType']==PML_PropType_DownloadLink || $Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_DownloadLinkFileUpload) continue;
		echo "<tr class='";
		if($cls++%2) echo "row1"; else echo "row2";
		echo "'><td align=right>";
		if($Prop['InTitle']=="") echo $Prop['Name']; else echo $Prop['InTitle'];
		echo "</td><td>";
		echo "<input type='checkbox' name='print$Prop[ID]'";
		if($Prop['ShowInList']) echo " checked";
		echo ">";
		echo "</td></tr>\n";
	}

		echo "<tr class='";
		if($cls++%2) echo "row1"; else echo "row2";
		echo "'><td>&nbsp;</td><td><INPUT TYPE='submit' value='$strGeneratePrintout'></TD></TR>";
	echo "	</TABLE>
</FORM>";


	include("bottom.html");
	exit;
}

if($action=="print") {

$PropAll[0] = array("UseSort"=>1,"ShowInList"=>0,"PropType"=>PML_PropType_DateAdded,"RequiredRights"=>-1, "Name"=>"DateAdded"); //for date, standard-sort-order
$PropAll[-1] = array("UseSort"=>1,"ShowInList"=>0,"PropType"=>PML_PropType_Clicks,"RequiredRights"=>-1, "Name"=>"DownloadCount"); //for downloaded

$sDisplay['SortPropID'] = abs(ceil($_POST['Sort']));
$sDisplay['SortDirection']=0;
$sDisplay['Char'] = "";
$sDisplay['Page'] = 1;
$sDisplay['SearchText'] = $_POST['Search'];
$sDisplay['PerPage'] = 0;
$sDisplay['Filter'] = array();
if(isset($_POST['Filter'])) {
    $sDisplay['Filter'] = $_POST['Filter'];
  	if(!is_array($sDisplay['Filter'])) $sDisplay['Filter']=array();
}
foreach($PropAll as $kProp=>$Prop) {
    if($Prop['PropType']==PML_PropType_Boolean || $Prop['PropType']==PML_PropType_ListBox || $Prop['PropType']==PML_PropType_ListBoxMulti) {
        if(!isset($sDisplay['Filter'][$kProp])) $sDisplay['Filter'][$kProp]=$Prop['StdFilterPropValID'];
    }
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title><?php echo $ActiveList['title']; ?></title>
<meta http-equiv="Content-Type" content="text/html<?php if(isset($LngCharSet)) echo "; charset=$LngCharSet"; ?>">
<link rel="stylesheet" href="css/print.css">
</head>
<body>
<?php

$ret = ReadMovieDataFromDb("printlist", $sDisplay, "html");
$Data = $ret['Data'];
$AnzGes = $ret['AnzGes'];
$AnzFound = $ret['AnzFound'];
unset($ret);


if($AnzFound==0) {
	echo $strSqlNothingFound;
	echo "</body></html>";
	exit;
}

echo "<p align='center'><font size=+2><b>$ActiveList[title]</b></font><br>". $AnzFound . " " . $strSqlFound . "</p>\n";
echo "<table  border='1' bordercolor='#000000' cellspacing='0' width='100%'>\n";
echo "<tr>\n";
$cnt=0;
foreach($PropAll as $kProp=>$Prop) {
    if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
    if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
	if($kProp<1) continue;    
	if(!isset($_POST["print$Prop[ID]"])) continue;
	if($Prop['PropType']==PML_PropType_Textfield) continue;
	echo "  <th>$Prop[InTitle]</th>\n";
	$cnt++;
}
echo "</tr>\n";

//print all movies
foreach($Data as $MovieID=>$row) {
	echo "<tr>\n";
	$Fields = "";
	foreach($PropAll as $kProp=>$Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
        if($kProp<1) continue;
		if(!isset($_POST["print$Prop[ID]"])) continue;
		if($Prop['PropType']==PML_PropType_Textfield) continue;
		$Text = $row[$Prop['Name']];
		if($Text=="") $Text = "&nbsp;";
		echo "  <td class=$Prop[Name]>$Text</td>\n";
	}
	echo "</tr>";
	foreach($PropAll as $kProp=>$Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
        if($kProp<1) continue;
		if(!isset($_POST["print$Prop[ID]"])) continue;
		if($Prop['PropType']!=PML_PropType_Textfield) continue;
		$Text = $row[$Prop['Name']];
		if($Text=="") continue;
		echo "  <tr><td colspan='$cnt'>$Text</td></tr>\n";
	}
}
echo "</table>\n";
echo "</body></html>";
}
?>