<?php
/** powermovielist PopUp
 * $Id: popup.php,v 1.14 2006/01/12 07:33:14 niko Exp $
*/

$FILE_SELF = "popup.php";

$ID = (int)$_GET['ID'];
if($ID==0) { echo "Error - No ID"; exit; }

$LoadSmarty = True;
include_once("application.php");

if($Active=="index")
	die("popup not avaliable for index-page");

$TplFile = $ActiveList['popuptpl'];

if($TplFile=="") {
	$TplFile="popup.tpl"; //default template file for index-page
}
$TplFile = "popup/$TplFile";

$CacheId = "popup|$Active|$ID|$ActiveUserRights";
$CacheIdComments = "comments|$Active|$ID";

$smarty->cache_lifetime = -1; //never expire, when something is changed cache is deleted by the script...

if(isset($_GET['action'])) $action = $_GET['action']; else $action="";
$IP = ip2long($_SERVER['REMOTE_ADDR']);

$StatusMessage = array();


switch($action) {
    case "delcomment":
        RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_Moderator);
        $strSql = "DELETE LOW_PRIORITY FROM " . $CFG['Prefix'] . "comment WHERE ID='" . $_GET['Comment']."'";

        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $StatusMessage[] = $strCommentDeleted;
        //und die restliche seite anzeigen....

        $smarty->clear_cache(null,"popup|$Active|$ID");
        $smarty->clear_cache(null,"comments|$Active|$ID");
        break;

    case "savecomment":
        
        if(!$CFG['AllowCommentVoteGuest']) {
            RequestLogin(PML_LoginStyle_NoGuestAllowed);
        }
        
        if($CFG['BadwordsFile']!="" && file_exists($CFG['BadwordsFile'])) {
            $badwords = file($CFG['BadwordsFile']);
            foreach($badwords as $word)
            {
                $word = trim($word);
                if($word=="") continue;
                if(eregi($word, $_POST['inpText'])) {
                    if($CFG['PopupBadwordsRedirect']!="") {
                        header("Location: $CFG[PopupBadwordsRedirect]");
                        exit;
                    } else {
                        $StatusMessage[] = "Can't save your comment as it contains some bad words...";
                        break;
                    }
                }
            }            
        }
    
        if($_POST['inpText']=="") {
            $StatusMessage[] = $strNoTextEntered;
            break;
        }
        $strSql = "SELECT ID FROM $CFG[Prefix]comment WHERE MovieID='$ID' AND UserID='$ActiveUser[ID]' AND Text='".(nl2br(htmlspecialchars($_POST['inpText'],HTML_ENTITIES)))."'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        if(mysql_num_rows($result)>0) {
            $StatusMessage[] = $strCantPostCommentTwice;
            break;
        }
        

        $strSql = "INSERT INTO " . $CFG['Prefix'] . "comment (MovieID, Date, IP, Text, UserID) VALUES('$ID', '" . date("Y-m-d H:i:s") . "', '" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . "', '" . (nl2br(htmlspecialchars($_POST['inpText'],HTML_ENTITIES))) . "', '$ActiveUser[ID]')";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $StatusMessage[] = $strDloadCommentSaved;

        $smarty->clear_cache(null,"popup|$Active|$ID");
        $smarty->clear_cache(null,"comments|$Active|$ID");
        break;

    case "addcomment":
    
        if(!$CFG['AllowCommentVoteGuest']) {
            RequestLogin(PML_LoginStyle_NoGuestAllowed);
        } 
        //get the text that is used for fetching too - this should be the title of the entry...
        $EntryTitle = GetFetchText($ID);

        $smarty->cache_lifetime = 0; //no cache - this site isn't too complicated
        
        $TplFile = "comment_add.tpl";
        
        $smarty->assign("MovieTitle", $EntryTitle);
        $smarty->assign("CFG",array("LinkListType"=>$CFG['LinkListType'], "ListType"=>$CFG['ListType'], "GlobalArg"=>$GlobalArg, "GlobalArgWOActive"=>$GlobalArgWOActive));
        $smarty->assign("lang", array("strDloadAddComment"          => $strDloadAddComment,
                                "strDloadAddCommentFor" => $strDloadAddCommentFor,
                                "strDloadYourComment"               => $strDloadYourComment,
                                "strDloadNoHtmlAllowed"          => $strDloadNoHtmlAllowed,
                                "LngCharSet"            => $LngCharSet));
        $smarty->assign("ActiveUserRights", $ActiveUserRights);
        $smarty->assign("ActiveList", $ActiveList);
        $smarty->assign("ID", $ID);
        
        $smarty->display($TplFile);
        include("bottom.html");
        exit;

    case "showcomments":
    
        $EntryTitle = GetFetchText($ID);

        $DOC_TITLE = "$EntryTitle - $strUserComments";
        include("top.html");
        
        $TplFile = "comments.tpl";

        if(!$smarty->is_cached($TplFile,$CacheIdComments)) {
        
            $smarty->assign("MovieTitle", $EntryTitle);
        	$smarty->assign("CFG",array("LinkListType"=>$CFG['LinkListType'], "ListType"=>$CFG['ListType'], "GlobalArg"=>$GlobalArg, "GlobalArgWOActive"=>$GlobalArgWOActive));
            $smarty->assign("lang", array("strBack"          => $strBack,
								  "strUserComments" => $strUserComments,
								  "strDloadBy"               => $strDloadBy,
								  "strNoCommentsFound"          => $strNoCommentsFound,
								  "strDloadAddComment"           => $strDloadAddComment));
            $smarty->assign("ActiveUserRights", $ActiveUserRights);
            $smarty->assign("ID", $ID);

            //user-comments
            $CommentData = array();
            if($CFG['UserClass']!="standalone.php") {
                $UserData = $GLOBALS['usr']->GetUserList();
                $strSql = "SELECT " . $CFG['Prefix'] . "comment.ID," . $CFG['Prefix'] . "comment.Date,  " . $CFG['Prefix'] . "comment.Text, $CFG[Prefix]comment.UserID      
                FROM " . $CFG['Prefix'] . "comment
                WHERE " . $CFG['Prefix'] . "comment.MovieID='$ID'
                ORDER BY Date DESC";
            } else {
                $strSql = "SELECT comment.ID, comment.Date, comment.Text, comment.UserID, users.name
                FROM " . $CFG['Prefix'] . "comment comment, $CFG[Prefix]users users
                WHERE comment.MovieID='$ID'
                AND users.ID=comment.UserID
                ORDER BY comment.Date DESC";
            }
            $result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            while($row1 = mysql_fetch_assoc($result)) {
                if(!isset($row1['name'])) $row1['name'] = $UserData[$row1['UserID']]['name'];
                $CommentData[] = $row1;			
            }
            $smarty->assign("CommentData", $CommentData);
            
        }

        $smarty->display($TplFile,$CacheIdComments);
        include("bottom.html");

        exit;
}

$get_vote=array();
if(isset($_GET['vote'])) $get_vote = $_GET['vote'];
if(count($get_vote)) {
	LoadPropAll();
}

foreach($get_vote as $kvote=>$vote)
{
    if(!$CFG['AllowCommentVoteGuest']) {
        RequestLogin(PML_LoginStyle_NoGuestAllowed);
    }
	if($PropAll[$kvote]['PropType']!=PML_PropType_UserRating) continue;
	if(!is_numeric($vote)) continue;
	if($vote<1 || $vote>10) continue;
	$VoteVal = $vote;

	$SaveVote = true;
	if($ActiveUser['name']=="Guest") { //bei guest IP beprfen:
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "votes WHERE IP='$IP' AND PropID='$kvote' AND MovieID='$ID'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		if(mysql_num_rows($result) > 0) {
			$StatusMessage[] = "$strDloadVotedAllready!\n";
			$SaveVote = false;
		}
	} else {
		$strSql = "DELETE FROM " . $CFG['Prefix'] . "votes WHERE UserID='$ActiveUser[ID]' AND PropID='$kvote' AND MovieID='$ID'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$num = mysql_affected_rows();
		if($num)
			$StatusMessage[] = "$strOldVoteDeleted...";
	}
	if($SaveVote) {
		$strSql = "INSERT INTO " . $CFG['Prefix'] . "votes (MovieID, PropID, Vote, IP, UserID) VALUES ('$ID','$kvote','$VoteVal','$IP', '$ActiveUser[ID]')";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);      
		$StatusMessage[] = "$strDloadVoteSaved...\n";	

        //new db-structure
        $strSql = "SELECT AVG(votes.Vote) AS Vote
            FROM $CFG[Prefix]votes AS votes
            WHERE votes.PropID='$kvote'
            AND votes.MovieID='$ID'
            GROUP BY votes.PropID";
        $query = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $row = mysql_fetch_row($query);
        $row[0] = sprintf("%01.1f", $row[0]);
        $strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET {$PropAll[$kvote]['Name']} = '$row[0]' WHERE MovieID='$ID'";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                

		$smarty->clear_cache(null,$CacheId);
	}
}

if(!$smarty->is_cached($TplFile,$CacheId)) {	
	LoadPropAll();
	
    $ret = ReadMovieDataFromDb("popup", $ID, "long");
	$Data = $ret['Data'];

	$PropOutMain = array();
	$PropOutLink = array();
	$PropOutCover = array();
	$PropOutExtra = array();
	$PropOut = array();
	foreach($PropAll as $Prop)
	{
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;

		$Text = $Data[$ID][$Prop['Name']];

		$PropOut[$Prop['Name']] = $Text;

		if($Prop['ShowInPopUp']==PML_PopUp_DontShow) continue; //not displayed in popup
		if($Text=="" && $Prop['PropType']!=PML_PropType_UserRating) continue;
        if($Prop['ShowInPopUp']!=PML_PopUp_Dowload) {
            if(is_array($Text))
                $Text = implode(", ", $Text);
        } else {
            if(!is_array($Text))
                $Text['Link'] = $Text;
        }

		switch($Prop['ShowInPopUp']) {
			case PML_PopUp_Normal: // displayed together with all the other properties
                switch($Prop['PropType']) {
                    case PML_PropType_FileUpload:
                    case PML_PropType_Url:
                    case PML_PropType_UrlCached:
                        switch($Prop['ShowLinkType']) {
                            case PML_ShowLinkType_Normal:
                                $Text = "<a href='$Text'>" . $Prop['InTitle'] . "</a>";
                                break;
                            case PML_ShowLinkType_Newpage:
                                $Text = "<a href='$Text' target='_blank'>" . $Prop['InTitle'] . "</a>";
                                break;
                            case PML_ShowLinkType_Image:
                                if(preg_match('#^([0-9]+)x([0-9]+)([a-z]*)$#', $Prop['ImageSize'], $m)) {
                                    $Text = "<img src='" . $Text . "' width='$m[1]' height='$m[2]' border='0'>";
                                } else {
                                    $Text = "<img src='" . $Text . "' border='0'>";
                                }
                                break;
                            case PML_ShowLinkType_Link:
                                break;
                        }
                        break;
                    default:
                        //text is fine allready
                        break;
                }
				$PropOutMain[$Prop['ID']] = array($Prop['InTitle'], $Text);
                if(!isset($FirstPropID)) $FirstPropID = $Prop['ID'];
				break;
			case PML_PopUp_ExtraField: // displayed as extra field like plot or user-rating
                $PropTextRound = "";
				if($Prop['PropType']==PML_PropType_UserRating) { //user-rating
                  if($Text=="-") {
                    $PropText = $GLOBALS['strNoVotes'];
                    $PropTextRound = 0;
                  } else {
                    $PropText = $Text;
                    $PropTextRound = round($Text);;
                  }
                  
                  $PropText2 =  "<select name='$Prop[ID]' onChange=\"window.location='popup.php".$GlobalArg."ID={$ID}&vote[$Prop[ID]]=' + this.value\">
					<option value='-' selected>$strDloadVoteSelect</option>
					<option value='1'> 1 - $strWorst</option>
					<option value='2'> 2</option>
					<option value='3'> 3</option>
					<option value='4'> 4</option>
					<option value='5'> 5</option>
					<option value='6'> 6</option>
					<option value='7'> 7</option>
					<option value='8'> 8</option>
					<option value='9'> 9</option>
					<option value='10'>10 - $strBest</option>
				  </select>";
				} elseif($Prop['PropType']==PML_PropType_Textfield) { //textfield
				  $PropText = "<textarea rows='10' Cols='60'>" . $Text . "</textarea>";
                  $PropText2 = "";
				} else {
				  $PropText = $Text;
                  $PropText2 = "";
				}
				$PropOutExtra[$Prop['ID']] = array("Title"=>$Prop['InTitle'], "Data"=>$PropText, "Data2"=>$PropText2, "Type"=>$Prop['PropType'], "Round"=>$PropTextRound);
				break;
			case PML_PopUp_Dowload: // displayed at download-links
                if($Text['Link']=="") break;
                $PropOutLink[$Prop['ID']] = $Text;
				break;
			case PML_PopUp_Cover: // displayed at covers
				if($Text=="") break;
				$PropOutCover[$Prop['ID']] = array("Text"=>$Prop['InTitle'], "Url"=>$Text);
				break;
		}
	}

	if(sizeof($PropOutLink)) {
		$JavaScriptText = "
	filearray=new Array;
	n=0; \n";

		$j=0;
		foreach($PropOutLink as $Dat) {
			$JavaScriptText .= "filearray[" . $j . "]='$Dat[Link]';\n";
			$j++;
		}

		$JavaScriptText .= "\niv=false;
	function addfile() {
		top.document.location=filearray[n];
		n++;
		if(n==filearray.length && iv) {
			top.clearInterval(iv);
			n=0;
		}
		return true;
	}

	function addall() {
		if(window.confirm(\"$strDloadAddAllReally\")) {
			iv=top.setInterval('addfile()',50);
		}
	}
	";
	} else $JavaScriptText = "";

	$smarty->assign("JavaScriptText", $JavaScriptText);
	$smarty->assign("PropOutMain", $PropOutMain);	
	$smarty->assign("PropOutExtra", $PropOutExtra);	
	$smarty->assign("PropOutLink",$PropOutLink);
	$smarty->assign("PropOutCover",$PropOutCover);
	$smarty->assign("PropOut", $PropOut);	
    $smarty->assign("FirstPropID", $FirstPropID);
	
    //user-comments
	$CommentData = array();
    $CommentCount = 0;
	if($ActiveList['allowcomments'])
	{
		$strSql = "SELECT c.ID, c.Date,  c.Text, c.UserID, u.name
		FROM " . $CFG['Prefix'] . "comment c
		LEFT JOIN $CFG[Prefix]users AS u ON c.UserID=u.ID
		WHERE c.MovieID='$ID'
        ORDER BY c.Date DESC
        LIMIT 5"; //display only 5
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		for($i=0;$i<mysql_num_rows($result);$i++) {
			$row1 = mysql_fetch_assoc($result);
			$CommentData[] = $row1;			
		}
        $strSql = "SELECT COUNT(ID) FROM $CFG[Prefix]comment WHERE MovieID='$ID'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        $row1 = mysql_fetch_row($result);
        $MoreCommentsCount = $row1[0]-5;

        $smarty->assign("MoreCommentsCount",$MoreCommentsCount);
	}

    $smarty->assign("DisplayComments",$ActiveList['allowcomments']);
    $smarty->assign("CommentData",$CommentData);


	$smarty->assign("lang", array("strDloadAddAll"          => $strDloadAddAll,
								  "strDloadClickToDownload" => $strDloadClickToDownload,
								  "strCovers"               => $strCovers,
								  "strCreateCover"          => $strCreateCover,
								  "strUserRating"           => $strUserRating,
								  "strDloadVoteSelect"      => $strDloadVoteSelect,
								  "strWorst"                => $strWorst,
								  "strBest"                 => $strBest,
								  "strDloadShortPlot"       => $strDloadShortPlot,
								  "strUserComments"         => $strUserComments,
								  "strDloadAddComment"      => $strDloadAddComment,
								  "strDloadBy"              => $strDloadBy,
								  "strNoCommentsFound"      => $strNoCommentsFound,
								  "strInfoLinks"            => $strInfoLinks,
								  "strDownload"             => $strDownload,
								  "strCovers"               => $strCovers,
								  "strHeadUserRating"       => $strHeadUserRating,
								  "strPlot"                 => $strPlot,
								  "strComments"             => $strComments,
								  "strInfo"                 => $strInfo,
                                  "strDloadMoreComments"    => $strDloadMoreComments,
								  "LngCharSet"              => $LngCharSet,
                                  "strYourRating"           => $strYourRating));


	$smarty->assign("DisplayCoverCreate",$CFG['EnableCoverCreate']);

	$InfoLinks = array();
	if(isset($PropNames['imdbid'])) {
		$imdbid = $Data[$ID]['imdbid'];
		$imdbid = str_repeat("0",7-strlen($imdbid)).$imdbid;
		if($imdbid!=0) {
			$InfoLinks[] = array("http://us.imdb.com/Title?$imdbid", $strInfo, "");
			$InfoLinks[] = array("http://us.imdb.com/Trailers?$imdbid", $strTrailer, "");
		}
	}
	$smarty->assign("InfoLinks",$InfoLinks);

	$smarty->assign("ActiveUserRights", $GLOBALS['ActiveUserRights']);

	$smarty->assign("ID",$ID);
	$smarty->assign("ActiveList",$ActiveList);
	$smarty->assign("CFG",array("LinkListType"=>$CFG['LinkListType'], "ListType"=>$CFG['ListType'], "GlobalArg"=>$GlobalArg, "GlobalArgWOActive"=>$GlobalArgWOActive));

    $smarty->register_modifier('filesize', 'GetPrettyFileSize');
}

$smarty->display($TplFile,$CacheId);

if(!isset($vote))
{
    if($CFG['UseDloadCount'])
    {
        //Download-Count z?len...
        $strSql = "UPDATE LOW_PRIORITY " . $CFG['Prefix'] . "movies_$Active SET DownloadCount=DownloadCount+1 WHERE MovieID='$ID'";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    
        //download-count fr user z?len:
        $usr->CountClick();
    }

	if($CFG['UseDloadLog']) {
		$gestern = date("Y-m-d H:i:s", time() - 60*60*24*1);
		//berpfen ob bereits gecounted wurde:
		if($ActiveUser['name']=="Guest") //bei guest IP beprfen:
			$strSql = "SELECT * FROM " . $CFG['Prefix'] . "dloadlog WHERE ip='$IP' AND movieID='$ID' AND date > '$gestern'";
		else //sonst die UserID
			$strSql = "SELECT * FROM " . $CFG['Prefix'] . "dloadlog WHERE UserID='$ActiveUser[ID]' AND movieID='$ID' AND date > '$gestern'";

		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		if(!mysql_num_rows($result)>0)
		{
			//eintrag in log-datei speichern...
			$strSql = "INSERT INTO " . $CFG['Prefix'] . "dloadlog (movieID, ip, date, UserID) VALUES ('$ID', '" . $IP . "', '" . date("Y-m-d H:i:s") . "','$ActiveUser[ID]')";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

			//alle log-eintrage die ?ter als 31 tage sind l?chen
			$strSql = "DELETE LOW_PRIORITY FROM " . $CFG['Prefix'] . "dloadlog WHERE date < '" . date("Y-m-d", time()-60*60*24*31) . "'";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		}
	}
}

include("bottom.html");

function insert_StatusMessage($params) {
global $StatusMessage;
if(sizeof($StatusMessage)==0) return("");
$ret = "<table width='100%' border='0' cellpadding='3' cellspacing='1' class='tblback'>
  <tr class='row1'>
    <td>";
foreach($StatusMessage as $k=>$stat) {
	if($k != 0) $ret .= "<br>\n";
	$ret .= $stat;
}
$ret .= "    </td>
  </tr>
</table>
<br>";
return($ret);
}


?>