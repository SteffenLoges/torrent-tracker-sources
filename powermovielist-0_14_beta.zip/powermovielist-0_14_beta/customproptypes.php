<?
function propTypeDateAddedSql($prop, $role) {
	if($role=="sql") {
		$sql = array();
		$sql['select'] = "DATE_FORMAT(movies.DateAdded, '$GLOBALS[strDefaultDateFormat]') AS `$prop[Name]`";
		return($sql);
	} else if($role=="order") {
		return("movies.DateAdded");
	}
}

function propTypeClicksSql($prop, $role) {
	if($role=="sql") {
		$sql = array();
		$sql['select'] = "movies.DownloadCount AS `$prop[Name]`";
		return($sql);
	} else if($role=="order") {
		return("`$prop[Name]`");
	}
}

function propTypeUserAddedSql($prop, $role) {
	global $CFG;
	if($role=="sql") {
		$sql = array();
		$sql['select'] = "users.name AS `$prop[Name]`";
		$sql['left join']["$CFG[Prefix]users AS users"] = "users.ID=movies.UserAddedID";
		return($sql);
	} else if($role=="order") {
		return("`$prop[Name]`");
	}
}

function propTypeCommentsSql($prop, $role) {
	global $CFG;
	if($role=="sql") {
		$sql['select'] = "COUNT(comment.ID) AS `$prop[Name]`";
		$sql['left join']["$CFG[Prefix]comment AS comment"] = "comment.MovieID=movies.MovieID";
		$sql['group'][] = "movies.MovieID";
		return($sql);
	} else if($role=="order") {
		return("`$prop[Name]`");
	}
}

if(file_exists('localproptypes.php')) {
	include('localproptypes.php');
}
?>