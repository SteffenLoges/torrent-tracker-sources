<?php
/** powermovielist edit announcements
 * $Id: editannounc.php,v 1.4 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "editannounc.php";
$LoadSmarty=true;
include_once("application.php");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];


$Title = $strEditAnnouncementSmall;
$TitlePl = $strEditAnnouncementTitle;
$Table = $CFG['Prefix'] . "announcment";

$_GET['F'] = $ActiveList['ID'];
$Filter = "ListID";
$FilterVal = $_GET['F'];

$SessionVar = "editannounc";

$i=0;
$Show[$i]['name'] = "Text";
$Show[$i]['type'] = "textfield";
$Show[$i]['prop'] = "50";    //Text-Field-Width
$Show[$i]['text'] = $strEditAnnouncement;
$Show[$i]['comm'] = $strEditAnnouncementComment;
$Show[$i]['main'] = true;
$Show[$i]['tags'] = " cols='80' rows='10'";
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = false;
$i++;
$Show[$i]['name'] = "UseDate";
$Show[$i]['type'] = "checkbox";
$Show[$i]['prop'] = "1;0";
$Show[$i]['values'] = $strEditAnnouncementUseDatesChoices;
$Show[$i]['text'] = $strEditAnnouncementUseDates;
$Show[$i]['comm'] = $strEditAnnouncementUseDatesComment;
$Show[$i]['main'] = true;
$Show[$i]['def'] = "0";
$Show[$i]['uniq'] = false;
$Show[$i]['tags'] = " onClick='EnableDate();'";
$i++;
$Show[$i]['name'] = "DateOn";
$Show[$i]['type'] = "date";
$Show[$i]['prop'] = "";
$Show[$i]['text'] = $strEditAnnouncementDateOn;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = date("Y-m-d");
$Show[$i]['uniq'] = false;
$i++;
$Show[$i]['name'] = "DateOff";
$Show[$i]['type'] = "date";
$Show[$i]['prop'] = "";
$Show[$i]['text'] = $strEditAnnouncementDateOff;
$Show[$i]['comm'] = "";
$Show[$i]['main'] = true;
$Show[$i]['def'] = date("Y-m-d", mktime (0,0,0,date("m")+1,date("d"),  date("Y"))); //next month
$Show[$i]['uniq'] = false;
$i++;
//UserID only for saving when adding new announcment
$Show[$i]['name'] = "UserID";
$Show[$i]['type'] = "hidden";
$Show[$i]['main'] = false;
$Show[$i]['def'] = $ActiveUser['ID'];
$i++;
//Username for displaying in list
$Show[$i]['name'] = "UserID";
$Show[$i]['type'] = "sqlfunc";
$Show[$i]['text'] = $strEditAnnouncementUserID;
$Show[$i]['main'] = true;
$Show[$i]['save'] = false;
$Show[$i]['hide'] = true;
$Show[$i]['sqlstr'] = "SELECT $CFG[Prefix]users.Name FROM $CFG[Prefix]users, $CFG[Prefix]announcment WHERE $CFG[Prefix]announcment.UserID=$CFG[Prefix]users.ID";
$Show[$i]['sortkey'] = "UserID";
$Show[$i]['sortdir'] = 1;
$Show[$i]['sortdef'] = false;
$i++;
//the date when it was added (for saving & displaying in list)
$Show[$i]['name'] = "DateAdded";
$Show[$i]['type'] = "hidden";
$Show[$i]['text'] = $strEditAnnouncementDateAdded;
$Show[$i]['def'] = date("Y-m-d h:m:s");
$Show[$i]['main'] = true;
$Show[$i]['sortkey'] = "DateAdded";
$Show[$i]['sortdir'] = 0;
$Show[$i]['sortdef'] = true;


RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);


if($action=="add" || $action=="edit") {
$JavaScriptText = "
function EnableDate() {
	if(document.forms.frmEdit.UseDate.checked) {
		document.forms.frmEdit.DateOnMon.disabled = false;
        document.forms.frmEdit.DateOnDay.disabled = false;
        document.forms.frmEdit.DateOnYear.disabled = false;
		document.forms.frmEdit.DateOffMon.disabled = false;
        document.forms.frmEdit.DateOffDay.disabled = false;
        document.forms.frmEdit.DateOffYear.disabled = false;
	} else {
		document.forms.frmEdit.DateOnMon.disabled = true;
        document.forms.frmEdit.DateOnDay.disabled = true;
        document.forms.frmEdit.DateOnYear.disabled = true;
		document.forms.frmEdit.DateOffMon.disabled = true;
        document.forms.frmEdit.DateOffDay.disabled = true;
        document.forms.frmEdit.DateOffYear.disabled = true;
        //Mon Day Year
	}
}
";

$OnLoad = "EnableDate();";

}

$DOC_TITLE = $strEditAnnouncement;
include("top.html");
include("edit.php");

//clear the smarty cache for this list
if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$smarty->clear_cache(null,"list|$Active");
	$smarty->clear_cache(null,"poup|$Active");    
}

//show the list again
if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$action = "";
	$_GET['action'] = $action;
	include("edit.php");
}

include("bottom.html");

?>