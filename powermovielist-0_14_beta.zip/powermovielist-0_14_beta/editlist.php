<?php
/** powermovielist edit lists
 * $Id: editlist.php,v 1.13 2005/12/14 15:31:07 niko Exp $
*/
$FILE_SELF = "editlist.php";
$LoadSmarty = true;
include_once("application.php");


if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

if($action=="flushlist") {
    RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

    $DOC_TITLE = "flush list";
    include("top.html");

    echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
    echo "  <tr class='top'>\n";
    echo "    <td colspan='2'><h1>flush list</h1></td>\n";
    echo "  </tr>\n";
    echo "</table>\n";
    echo "<br>\n";
    
    echo "<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='editlist.php".$GlobalArg."action=flushlist2'>\n";
    echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
    echo "<tr class='top'><td colspan='2'>flush the complete list</td></tr>\n";
    echo "<tr class='row1'><td colspan='2'>\n";
    echo "<b><font color='red'>WARNING:</font> With this function you can delete your whole list.</b> So please only use it if you are really sure :D You can backup the list using the export-function, or as Super-Admin you can backup the whole database.<br>
    So, do you really want to delete all entries in your list?\n";
    echo "</td></tr>\n";
    echo "<tr class='row2'><td colspan='2'>\n";
    echo "<INPUT TYPE='submit' value='continue'>\n";
    echo "</td></tr>\n";
    echo "</table\n";
    include("bottom.html");
    exit;
}

if($action=="flushlist2") {
    RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

    $DOC_TITLE = "flush list";
    include("top.html");

    echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
    echo "  <tr class='top'>\n";
    echo "    <td colspan='2'><h1>flush list</h1></td>\n";
    echo "  </tr>\n";
    echo "</table>\n";
    echo "<br>\n";
    
    echo "<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='editlist.php".$GlobalArg."action=flushlist2'>\n";
    echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
    echo "<tr class='top'><td colspan='2'>flush the complete list</td></tr>\n";
    echo "<tr class='row1'><td colspan='2'>\n";
    echo "deleting all entries...<br>\n";

    //delete votes's
    LoadPropAll();
    foreach($PropAll as $Prop) {
        $strSql = "DELETE FROM $CFG[Prefix]votes WHERE PropID=$Prop[ID]";
        pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    }	

    //delete movies
    $strSql = "DELETE FROM $CFG[Prefix]movies WHERE ListID=$ActiveList[ID]";
    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $strSql = "DELETE FROM $CFG[Prefix]movies_$ActiveList[name]";
    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    echo "<b>done!</b><br>\nall entries deleted...<br>whyever you did that :D\n";

    echo "</td></tr>\n";
    echo "</table\n";

    include("bottom.html");
    exit;
}

$Title = $strEditListTitle;
$TitlePl = $strEditListTitlePl;
$Table = $CFG['Prefix'] . "lists";

$SessionVar = "editlist";

if(isset($_GET['Display'])) 
	$Display = $_GET['Display'];
else
	$Display = "main";

if($Display=="") $Display="main";

if($Display=="main") {
	$SecondTitle=$strMainConfiguration;
	$i=0;
	$Show[$i]['name'] = "UserID";
	$Show[$i]['type'] = "hidden";
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = $ActiveUser['ID'];
	$Show[$i]['newonly'] = true;

	
	if($CFG['ListType'] > 0) {
		//List-Name ist gleich Benutzername
		$i++;
		$Show[$i]['name'] = "name";
		$Show[$i]['type'] = "hidden";
		$Show[$i]['def'] = $ActiveUser['name'];
		$Show[$i]['newonly'] = true;
	} else {
		$i++;
		$Show[$i]['name'] = "name";
		$Show[$i]['type'] = "username";
		$Show[$i]['prop'] = "12";    //Text-Field-Width
		$Show[$i]['text'] = $strListName;
		$Show[$i]['comm'] = $strValidCharsUserName;
		$Show[$i]['main'] = true;
		$Show[$i]['def'] = "";
		$Show[$i]['uniq'] = true;
		$Show[$i]['newonly'] = true;
		$Show[$i]['sortdef'] = true;
		$Show[$i]['sortkey'] = "name";
		$Show[$i]['sortdir']=1;

	//	$Show[$i]['invalid'] = "";  
	}

	$i++;
	$Show[$i]['name'] = "title";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "20";
	$Show[$i]['text'] = $strEditUserFldTitle;
	$Show[$i]['comm'] = "";
	$Show[$i]['main'] = true;
	$Show[$i]['def'] = $strEditUserFldTitleDefault;
	$Show[$i]['uniq'] = true;
	$Show[$i]['sortdef'] = false;
	$Show[$i]['sortkey'] = "title";
	$Show[$i]['sortdir']=1;
	$i++;
	$Show[$i]['name'] = "entries";
	$Show[$i]['text'] = "entries";
	$Show[$i]['type'] = "func";
	$Show[$i]['main'] = true; //show in main
	$Show[$i]['func'] = "getSumEntries";
	$Show[$i]['save'] = false; 
	$Show[$i]['hide'] = true; 

	$i++;
	$Show[$i]['name'] = "url";
	$Show[$i]['type'] = "url";
	$Show[$i]['prop'] = "35";
	$Show[$i]['text'] = $strEditUserFldUrl;
	$Show[$i]['comm'] = $strEditUserFldUrlComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = $strEditUserFldUrlDefault;
	$Show[$i]['uniq'] = false;
	$i++;
	$Show[$i]['name'] = "urlname";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "35";
	$Show[$i]['text'] = $strEditUserFldUrlShown;
	$Show[$i]['comm'] = $strEditUserFldUrlShownComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = $strEditUserFldUrlShownDefault;
	$Show[$i]['uniq'] = false;
	$i++;
	$Show[$i]['name'] = "image";
	$Show[$i]['type'] = "file";
	$Show[$i]['prop'] = "image/logos/";
	$Show[$i]['text'] = $strEditUserFldPic;
	$Show[$i]['comm'] = "<a href='uploadimage.php$GlobalArg'>" . $strEditUserFldPicComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "standard.gif";
	$Show[$i]['uniq'] = false;
	
	$i++;
	$Show[$i]['name'] = "lang";
	$Show[$i]['type'] = "file";
	$Show[$i]['prop'] = "lang/";
	$Show[$i]['filt'] = ".inc.php";  //only show files with .inc.php and don't display the .inc.php
	$Show[$i]['text'] = $strEditUserFldLang;
	$Show[$i]['comm'] = "";
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "english";
	$Show[$i]['uniq'] = false;

	$i++;
	$PropSettings=array();
	$d = dir("presettings");
	while($entry=$d->read()) {
		if(filetype("presettings/" . $entry)!="file") continue;
		if(strtolower(substr($entry, -6))!="pmlset") continue;
		$Dat=substr($entry,0,strlen($entry)-7);
		$Dat = str_replace("_", " ", $Dat);
		$PropSettings[$entry]=$Dat;
	}
	$d->close();
	$Show[$i]['name'] = "presetting";
	$Show[$i]['type'] = "listbox";
	$Show[$i]['text'] = $strPresettingToImport;
	$Show[$i]['comm'] = "($strWhatTypeOfListYouWantToHave)";
	$Show[$i]['main'] = false;
	$Show[$i]['prop'] = implode(";", $PropSettings);
	$Show[$i]['values'] = implode(";", array_keys($PropSettings));
	$Show[$i]['def'] = "Standard_Movie-List_with_imdb.pmlset";
	$Show[$i]['uniq'] = false;
	$Show[$i]['newonly'] = true;
	$Show[$i]['save'] = false;
    if($action!="add" && $action!="addsave" && $Active!="index") {
        $i++;
        $Show[$i]['name'] = "ShowOnIndex";
        $Show[$i]['type'] = "checkbox";
        $Show[$i]['prop'] = "1;0";
        $Show[$i]['text'] = "Show new items on index-page";
        $Show[$i]['comm'] = "";
        $Show[$i]['main'] = false;
        $Show[$i]['def'] = "1";
        $Show[$i]['uniq'] = false;
        
        //only when GET-$ID is set - not when action=""
        if(isset($_GET['ID'])) {
            $i++;
            $Show[$i]['name'] = "FetchTextPropID";
            $Show[$i]['type'] = "listbox";
            $Show[$i]['prop'] = "";
            $Show[$i]['values'] = "";

            //now populate prop and values with all avaliable properties
            //and check if the FetchTextPropID exists - if not UPDATE FetchTextPropID to the FIRST PML_PropType_Text
            $strSql = "SELECT FetchTextPropID FROM $CFG[Prefix]lists WHERE ID=$_GET[ID]";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_assoc($result);
            LoadPropAll();
            $FoundFetchTextPropID = false;
            foreach($PropAll as $Prop) {
                if($row['FetchTextPropID']==$Prop['ID']) $FoundFetchTextPropID=true;
                $Show[$i]['prop'] .= $Prop['Name'] . ";";
                $Show[$i]['values'] .= $Prop['ID'] . ";";
                if($Prop['PropType']==PML_PropType_Text && !isset($FirstTextID)) {
                    $FirstTextID = $Prop['ID'];
                }
            }
            if(!$FoundFetchTextPropID) {
                $strSql = "UPDATE $CFG[Prefix]lists SET FetchTextPropID='$FirstTextID' WHERE ID=$_GET[ID]";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            }

            $Show[$i]['prop'] = substr($Show[$i]['prop'], 0, -1);
            $Show[$i]['values'] = substr($Show[$i]['values'], 0, -1);
            $Show[$i]['text'] = "default property for search-text";
            $Show[$i]['comm'] = "(you can enter another serach text too if nothing was found)";
            $Show[$i]['main'] = false;
            $Show[$i]['def'] = "0";
            $Show[$i]['uniq'] = false;
        }
        $i++;
        $Show[$i]['name'] = "EnableLoan";
        $Show[$i]['type'] = "checkbox";
        $Show[$i]['prop'] = "1;0";
        $Show[$i]['text'] = "Enable Loaning";
        $Show[$i]['comm'] = "";
        $Show[$i]['main'] = false;
        $Show[$i]['def'] = "0";
        $Show[$i]['uniq'] = false; 

    }
}

if($Display=="pass") {
	$SecondTitle=$strPasswordConfig;
	$TitleInfo = $strEditListPassTitleInfo;  //If this feature is enabled, every user has to enter the password, even if he has view-rights for the list! (only the list-admins don\'t have to)
	$i=0;
	$Show[$i]['name'] = "usepass";
	$Show[$i]['type'] = "checkbox";
	$Show[$i]['prop'] = "1;0";
	$Show[$i]['text'] = $strEditUserFldUsePass;
	$Show[$i]['comm'] = $strEditUserFldUsePassComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "1";
	$Show[$i]['uniq'] = false;
	$i++;
	$Show[$i]['name'] = "showpass";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "10";
	$Show[$i]['text'] = $strEditUserFldShowPass;
	$Show[$i]['comm'] = $strEditUserFldShowPassComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "";
	$Show[$i]['uniq'] = false;
	$i++;
	$Show[$i]['name'] = "showpasstext";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "60";
	$Show[$i]['text'] = $strEditUserFldShowText;
	$Show[$i]['comm'] = $strEditUserFldShowTextComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = $strEditUserFldShowTextDefault;
	$Show[$i]['uniq'] = false;
}
if($Display=="design") {
	$SecondTitle=$strDesignConfig;
	$i=0;
	$Show[$i]['name'] = "designcss";
	$Show[$i]['type'] = "file";
	$Show[$i]['prop'] = "css/";
	$Show[$i]['text'] = $strEditUserFldCss;
	$Show[$i]['comm'] = "";
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "default.css";
	$Show[$i]['uniq'] = false;
	$i++;
	$Show[$i]['name'] = "listtpl";
	$Show[$i]['type'] = "file";
	if($Active=="index") {
		$Show[$i]['prop'] = "templates/index/";
		$Show[$i]['text'] = $strEditListIndexTpl;
		$Show[$i]['comm'] = $strEditListIndexTplComm;
	} else {
		$Show[$i]['prop'] = "templates/list/";
		$Show[$i]['text'] = $strEditListListTpl;
		$Show[$i]['comm'] = $strEditListListTplComm;
	}
	$Show[$i]['filt'] = "";  //only show all files and show the .tpl
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "list.tpl";
	$Show[$i]['uniq'] = false;
	$i++;
	if($Active!="index") {
		$Show[$i]['name'] = "popuptpl";
		$Show[$i]['type'] = "file";
		$Show[$i]['prop'] = "templates/popup/";
		$Show[$i]['filt'] = "";  //only show all files and show the .tpl
		$Show[$i]['text'] = $strEditListDloadTemplate;
		$Show[$i]['comm'] = $strEditListDloadTemplateComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "popup.tpl";
		$Show[$i]['uniq'] = false;
		$i++;
		$Show[$i]['name'] = "stdsort";
		$Show[$i]['type'] = "listbox";
		$Show[$i]['prop'] = "Date;Clicks";
		$Show[$i]['values'] = "0;-1";	
        LoadPropAll();
        foreach($PropAll as $Prop) {
            if(!$Prop['UseSort']) continue;
			$Show[$i]['prop'] .= ";".$Prop['Name'];
			$Show[$i]['values'] .= ";".$Prop['ID'];
		}
		$Show[$i]['text'] = $strStandardSortOrder;
		$Show[$i]['comm'] = "";
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "0";
		$Show[$i]['uniq'] = false;	
		$i++;
	}
    if($Active=="index") {
        $Show[$i]['name'] = "IndexType";
        $Show[$i]['text'] = $strIndexType;
        $Show[$i]['comm'] = "($strWhatEntriesShownIndex)";
        $Show[$i]['type'] = "listbox";
        $Show[$i]['values'] = "0;1;2;3";
        $Show[$i]['prop'] = "$strOrderedByDateNewestEntries;$strEntriesFromDays;$strEntriesFromDaysSortList;$strEntriesFromDaysSortLinkList";
        $Show[$i]['def'] = "0";
        $Show[$i]['main'] = false;
        $i++;
    }
	$Show[$i]['name'] = "StdPerPage";
	$Show[$i]['type'] = "text";
	$Show[$i]['prop'] = "3";
	if($Active!="index") {
		$Show[$i]['comm'] = "";
		$Show[$i]['text'] = $strEditListStdPerPage;
		$Show[$i]['def'] = "50";
	} else {
		$Show[$i]['text'] = $strNrItemsOnPage."/".$strDaysToDisplay;
		$Show[$i]['comm'] = "($strDontSetTooHighPerformance)";
		$Show[$i]['def'] = "5";
	}
	$i++;
	if($Active!="index") {
		$Show[$i]['name'] = "showchars";
		$Show[$i]['type'] = "checkbox";
		$Show[$i]['prop'] = "1;0";
		$Show[$i]['text'] = $strEditUserFldShowChars;
		$Show[$i]['comm'] = $strEditUserFldShowCharsComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "1";
		$Show[$i]['uniq'] = false;
		$i++;
		$Show[$i]['name'] = "showsearch";
		$Show[$i]['type'] = "checkbox";
		$Show[$i]['prop'] = "1;0";
		$Show[$i]['text'] = $strEditListFldShowSearch;
		$Show[$i]['comm'] = $strEditListFldShowSearchComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "1";
		$Show[$i]['uniq'] = false;
		$i++;
		$Show[$i]['name'] = "showfilter";
		$Show[$i]['type'] = "checkbox";
		$Show[$i]['prop'] = "1;0";
		$Show[$i]['text'] = $strEditListFldShowFilter ;
		$Show[$i]['comm'] = $strEditListFldShowFilterComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "1";
		$Show[$i]['uniq'] = false;
		$i++;
		$Show[$i]['name'] = "showperpage";
		$Show[$i]['type'] = "checkbox";
		$Show[$i]['prop'] = "1;0";
		$Show[$i]['text'] = $strEditListFldShowPerPage;
		$Show[$i]['comm'] = $strEditListFldShowPerPageComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "1";
		$Show[$i]['uniq'] = false;
		$i++;           
		$Show[$i]['name'] = "showsortlinks";
		$Show[$i]['type'] = "checkbox";
		$Show[$i]['prop'] = "1;0";
		$Show[$i]['text'] = $strShowSortLinks;
		$Show[$i]['comm'] = $strEditListShowSortLinksComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "1";
		$Show[$i]['uniq'] = false;
		$i++;

	}
	$Show[$i]['name'] = "showcounter";
	$Show[$i]['type'] = "checkbox";
	$Show[$i]['prop'] = "1;0";
	$Show[$i]['text'] = $strEditUserFldShowCounter;
	$Show[$i]['comm'] = $strEditUserFldShowCounterComm;
	$Show[$i]['main'] = false;
	$Show[$i]['def'] = "1";
	$Show[$i]['uniq'] = false;
	$i++;
	if($Active!="index") {
		$Show[$i]['name'] = "showprint";
		$Show[$i]['type'] = "checkbox";
		$Show[$i]['prop'] = "1;0";
		$Show[$i]['text'] = $strEditUserFldShowPrint;
		$Show[$i]['comm'] = "";
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "1";
		$Show[$i]['uniq'] = false;
		$i++;
		$Show[$i]['name'] = "marknew";
		$Show[$i]['type'] = "text";
		$Show[$i]['prop'] = "3";
		$Show[$i]['text'] = $strEditUserMark;
		$Show[$i]['comm'] = $strEditUserMarkComm;
		$Show[$i]['main'] = false;
		$Show[$i]['def'] = "0";
		$Show[$i]['uniq'] = false;
        $i++;
        $Show[$i]['name'] = "allowcomments";
        $Show[$i]['type'] = "checkbox";
        $Show[$i]['prop'] = "1;0";
        $Show[$i]['text'] = $strEditUserDloadAllowComments;
        $Show[$i]['comm'] = $strEditUserDloadAllowCommentsComm;
        $Show[$i]['main'] = false;
        $Show[$i]['def'] = "0";
        $Show[$i]['uniq'] = false;

	}
}




$Filter = "";
$FilterVal = "";


$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name NOT LIKE 'index'";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
if(mysql_num_rows($result)==0) 
	$InstallMode = TRUE;
else
	$InstallMode = FALSE;

/*
Mode = 1: view-rechte
Mode = 2: add-rechte
Mode = 3: Moderator rechte
Mode = 4: List-Admin rechte
Mode = 5: Super-Admin rechte
*/

switch($action) {
	case "add":
	case "addsave":
        if($CFG['ListType']==1) {
            include("top.html");
            ErrorExit("can't create new lists in simple-mode - create a new user and the list will be created too!");
        }
		if(!$InstallMode && $CFG['ListType'] ==2) {
			include("top.html");
			ErrorExit($strCantAddMoreInSingle);
		}
		$DOC_TITLE = $strAddList;
		include("top.html");
		$SaveButtonText = $strCreateList;

		if(!$InstallMode && !$CFG['ShowRegisterList'])
			 RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
		else
			 RequestLogin(PML_LoginStyle_NoGuestAllowed);

		if($CFG['ListType']==1) {
			$strSql = "SELECT * FROM " . $CFG['Prefix'] . "lists WHERE name='" . $ActiveUser['name'] . "'";
			$result = pml_mysql_query($strSql, $pmldb);
			if(mysql_num_rows($result) > 0)  {
				ErrorExit($strListsExistsAllreadyPleaseNewUser);
			}
		}
		break;
	case "edit":
	case "editsave":
		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);
		$DOC_TITLE = $ActiveList['title'] . " - $strEditList";
		include("top.html");
		$SaveButtonText = $strSaveSettings;
		break;
	case "del":
	case "delsave":
	case "delpass":
	case "delsavepass":
		if($CFG['ListType'] >=2) {
			include("top.html");
			ErrorExit($strCantDeleteListInSingle);
		}
		if($CFG['ListType']==1) {
			include("top.html");
			ErrorExit($strCantDeleteListSimpleDeleteUser);
		}

		if(isset($_GET['ID'])) $ID = $_GET['ID'];
		$strSql = "SELECT name FROM " . $CFG['Prefix'] . "lists WHERE ID='$ID'";
		$result = pml_mysql_query($strSql, $pmldb);
		$row = mysql_fetch_assoc($result);
		if($row['name']=="index") {		
			include("top.html");
			ErrorExit("You can't delete the index-page. You might disable it in the global-configuration.");
		}

		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);
		$DOC_TITLE = $ActiveList['title'] . " - $strDeleteList";
		include("top.html");
		break;
	case "":
		RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
		$DOC_TITLE = $strEditLists;
		include("top.html");
		break;
	default:
		ErrorExit("Invalid action! ($action)");
}

ConnectDatabase();

if($action=="delsave") {
    $strSql = "SELECT Name FROM $CFG[Prefix]lists WHERE ID=$ID";
    $query = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $row = mysql_fetch_row($query);
    $ListName = strtolower($row[0]);
}
if($action=="editsave" && $Display=="main") {
	$strSql = "SELECT title FROM $CFG[Prefix]lists WHERE ID='$ID'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
	$titleBevoreSave = $row['title'];
}

include("edit.php");




if($action=="addsave") {
    AddListActions();
} elseif($action=="delsave") {
	
	LoadPropAll($ID);
	foreach($PropAll as $Prop) {
		$strSql = "DELETE FROM $CFG[Prefix]propval WHERE PropID=$Prop[ID]";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}

	//delete movies
	$strSql = "DELETE FROM $CFG[Prefix]movies WHERE ListID=$ID";
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

    $strSql = "DROP TABLE " . $CFG['Prefix'] . "movies_{$ListName}";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	
	echo "<br>$strAllMoviesDeleted...<br>\n";

	//delete prop's
	$strSql = "DELETE FROM $CFG[Prefix]prop WHERE ListID=$ID";
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	echo "$strPropertiesDeleted...<br>\n";

    //liste aus linkliste l?chen	
	$strSql = "DELETE FROM " . $CFG['Prefix'] . "linklist WHERE ListID=" .$ID;
	pml_mysql_query($strSql, $pmldb) or trigger_error("<br>can't execute $strSql ".mysql_error($pmldb));
	echo "$strEditUserEntriesDeleted\n";
	
    //userrights l?chen	
	$strSql = "DELETE FROM " . $CFG['Prefix'] . "userrights WHERE ListID=" .$ID;
	pml_mysql_query($strSql, $pmldb) or trigger_error("<br>can't execute $strSql ".mysql_error($pmldb));
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "group2list WHERE L_ID=" .$ID;
    pml_mysql_query($strSql, $pmldb) or trigger_error("<br>can't execute $strSql ".mysql_error($pmldb));
	echo "<br>$strEditUserUserrightsDeleted\n";

    //favoriten l?chen
    $strSql = "DELETE FROM " . $CFG['Prefix'] . "fav WHERE ListID=" .$ID;
	pml_mysql_query($strSql, $pmldb) or ("<br>can't execute $strSql ".mysql_error($pmldb));
    echo "<br>$strFavDeleted\n";
	
    //delete announcments
	$strSql = "DELETE FROM " . $CFG['Prefix'] . "announcment WHERE ListID=" .$ID;
	pml_mysql_query($strSql, $pmldb) or trigger_error("<br>can't execute $strSql ".mysql_error($pmldb));
	echo "<br>announcments deleted...\n";

	echo "<br><a href='index.php' target='_parent'>$strContinue</a>\n";
	
} elseif($action=="editsave") {
	if($Display=="main") {
		//wenn titel der liste ge?dert wurde und der titel in der linkliste dem alten entspricht, so 
		//muss der text in der linkliste auch ge?dert werden
		$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist WHERE ListID='$ID'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_array($result);

		if($row['Text']==$titleBevoreSave && $titleBevoreSave!=$_POST['title']) { //titel wurde ge?dert
			$strSql = "UPDATE " . $CFG['Prefix'] . "linklist SET Text='$_POST[title]' WHERE ID=$row[ID]";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		}
	}
} else {

}

//clear smarty-cache for all lists (linklist might be effected)
if($action=="addsave" || $action=="editsave" || $action=="delsave") {
	$smarty->clear_cache(null,"list"); //linklist might have changed...
	$smarty->clear_cache(null,"popup|$Active");    
}

include("bottom.html");



function getSumEntries($ID) {
global $CFG, $pmldb;
	$strSql = "SELECT COUNT(*) AS Summe FROM " . $CFG['Prefix'] . "movies WHERE ListID=$ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
	return($row['Summe']);	
}

?>
