<?php
/** powermovielist cover-creation - submit-form
 * $Id: cover.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "cover.php";
include_once("application.php");
$DOC_TITLE = "$strCoverCreation";
include("top.html");

if(!$CFG['EnableCoverCreate']) {
	echo "this feature has been disabled in the global configuration/installation. you need gd for php to create covers...";
	exit;
}

if(isset($_SESSION['sCover']))
	$sCover = $_SESSION['sCover'];
else {
	//load default values
	$sCover = array();
    $sCover['type']="back";
    $sCover['col']="black";
	$sCover['pic']=true;
	$sCover['format']=true;
	$sCover['lng']=true;
	$sCover['lngpic']=false;
	$sCover['ucase']=false;
	$sCover['url']=true;
	$sCover['formatside']=true;
    $sCover['indexside']=false;    
}

if(!isset($_GET['ID'])) ErrorExit("ID not set!");
$ID=$_GET['ID'];

LoadPropAll();

$ret = ReadMovieDataFromDb("popup", $ID, "short");
$Data = $ret['Data'];
unset($ret);

echo "<form name='form1' method='get' action='printcover.php'>
	<INPUT TYPE='hidden' name='ID' value='$ID'>\n";
parse_str(substr($GlobalArg,1),$x); //substr - without the ?
foreach($x as $k=>$Dat) {    
    echo "  <INPUT TYPE='hidden' name='$k' value='$Dat'>\n";
}

echo "
<br>
<table border='0' cellspacing='1' cellpadding='3' class='tblback' width='100%'>
<tr class=\"row1\"><td align='center' colspan=4>
	<i>$strCoverSimple</i>
	</td></tr>
<TR class=\"row2\">
    <TD align=right>$strCoverSelectType:</TD>
    <TD>
	    <SELECT NAME='type'>
		  <option value='front'"; if($sCover['type']=="front") echo " selected"; echo ">$strCoverTypeFront</option>
		  <option value='back'"; if($sCover['type']=="back") echo " selected"; echo ">$strCoverTypeBack</option>
	    </SELECT>
    </TD>
	<TD align=right>$strCoverSelectColor:</TD>
	<TD>
		<SELECT NAME='col'>
		  <option value='black'"; if($sCover['col']=="black") echo " selected"; echo ">$strCoverColorBlack</option>
		  <option value='blue'"; if($sCover['col']=="blue") echo " selected"; echo ">$strCoverColorBlue</option>
		  <option value='red'"; if($sCover['col']=="red") echo " selected"; echo ">$strCoverColorRed</option>
		  <option value='green'"; if($sCover['col']=="green") echo " selected"; echo ">$strCoverColorGreen</option>
		</SELECT>
	</TD>
	</TR><TR class=\"row1\">\n";

	$PropID=0;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['ShowOnCover']==PML_Cover_SideTitle) {
			$PropID = $Prop['ID'];
			break;
		}
	}
	$ErrorMessage = "";
	if($PropID==0) {
		$ErrorMessage = $strNoTitleForSideFound;
	}
	if($ErrorMessage!="") {
		echo "<td colspan='4' align='center'><font color='red'>$ErrorMessage</font></td></tr>\n<tr class='row1'>\n";
	}

	$PropID=0;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['ShowOnCover']==PML_Cover_Pic) {
			$PropID = $Prop['ID'];
			break;
		}
	}
		$ErrorMessage = "";
	if($PropID==0) {
		$ErrorMessage = "$strPicture - $strNoPropertyFound!";
	} else {
		$Dat = $Data[$ID][$PropAll[$PropID]['Name']];
		if($Dat=="") {
			$ErrorMessage = "$strPicture - $strNoEntryFound (" . $PropAll[$PropID]['Name'] .  ")";
		} else {
			$fp = @fopen ($Dat, "r");
			if(!$fp) {
				$ErrorMessage = "$strPicture - $strErrorOpening '$Dat'";
			}
			@fclose($fp);
		}
	}
	if($ErrorMessage!="") {
		echo "<TD align=right><font color='red'>$ErrorMessage</font></TD>
		<TD><INPUT TYPE='checkbox' disabled></TD>\n";
	} else {
		echo "<TD align=right>$strShowPictureOnTheRightTop:</TD>
		<TD><INPUT TYPE='checkbox' NAME='pic' value='$PropID'"; if($sCover['pic']) echo " checked"; echo "></TD>\n";
	}

	$PropID=0;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['ShowOnCover']==PML_Cover_Format) {
			$PropID = $Prop['ID'];
			break;
		}
	}
	$ErrorMessage = "";
	if($PropID==0) {
		$ErrorMessage = "$strCoverFormat - $strNoPropertyFound!";
	} else {
		$Dat = strtolower($Data[$ID][$PropAll[$PropID]['Name']]);
		if($Dat=="") {
			$ErrorMessage = "$strCoverFormat - $strNoEntryFound (" . $PropAll[$PropID]['Name'] .  ")";
		} else {
			if(!FileExists("image/format/$Dat.png")) {
				$ErrorMessage = "$strCoverFormat - '/image/format/$Dat.png' $strNotFound";
			}
		}
	}
	if($ErrorMessage!="") {
		echo "<TD align=right><font color='red'>$ErrorMessage</font></TD>
		<TD><INPUT TYPE='checkbox' disabled></TD>\n";
	} else {
		echo "<TD align=right>$strShowFormatLogoOnTheLeftBottom:</TD>
		<TD><INPUT TYPE='checkbox' NAME='format' value='".htmlentities($Dat)."'"; if($sCover['format']) echo " checked"; echo "></TD>\n";
	}

	$PropID=0;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['ShowOnCover']==PML_Cover_SideLang) {
			$PropID = $Prop['ID'];
			break;
		}
	}
	$ErrorMessage = "";
	if($PropID==0) {
		$ErrorMessage = "$strCoverLanguage - $strNoPropertyFound!";
	} else {
		$Dat = $Data[$ID][$PropAll[$PropID]['Name']];

	}
	if($ErrorMessage!="") {
		echo "</tr><tr class='row2'><TD align=right><font color='red'>$ErrorMessage</font></TD>
		<TD><INPUT TYPE='checkbox' disabled></TD>\n";
	} else {
		echo "</tr><tr class='row2'><TD align=right>$strShowLanguageOnTheSide:</TD>
		<TD><INPUT TYPE='checkbox' NAME='lng' value='".htmlentities($Dat)."'"; if($sCover['lng']) echo " checked"; echo "></TD>\n";
	}

	$PropID=0;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['ShowOnCover']==PML_Cover_SideFormat || $Prop['ShowOnCover']==PML_Cover_Format) {
			$PropID = $Prop['ID'];
			break;
		}
	}
	$ErrorMessage = "";
	if($PropID==0) {
		$ErrorMessage = "$strCoverFormat - $strNoPropertyFound!";
	} else {
		$Dat = $Data[$ID][$PropAll[$PropID]['Name']];
	}
	if($ErrorMessage!="") {
		echo "<TD align=right><font color='red'>$ErrorMessage</font></TD>
		<TD><INPUT TYPE='checkbox' disabled></TD>\n";
	} else {
		echo "<TD align=right>$strShowFormatOnTheSide:</TD>
		<TD><INPUT TYPE='checkbox' NAME='formatside' value='".htmlentities($Dat)."'"; if($sCover['formatside']) echo " checked"; echo "></TD>\n";
	}
	echo "</tr>\n";

	$PropID=0;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['ShowOnCover']==PML_Cover_Index) {
			$PropID = $Prop['ID'];
			break;
		}
	}
	$ErrorMessage = "";
	if($PropID==0) {
		$ErrorMessage = "index-nr - $strNoPropertyFound!";
	} else {
		$Dat = $Data[$ID][$PropAll[$PropID]['Name']];
	}
	if($ErrorMessage!="") {
		echo "<TR class='row1'><TD align=right><font color='red'>$ErrorMessage</font></TD>
		<TD><INPUT TYPE='checkbox' disabled></TD>\n";
	} else {
		echo "<TR class='row1'><TD align=right>show index-nr on the side</TD>
		<TD><INPUT TYPE='checkbox' NAME='indexside' value='".htmlentities($Dat)."'"; if($sCover['indexside']) echo " checked"; echo "></TD>\n";
	}

echo "
	<TD align=right>$strCapitalLettersForTitleOnTheSide:</TD>
	<TD><INPUT TYPE='checkbox' NAME='ucase' value='1'"; if($sCover['ucase']) echo " checked"; echo "></TD>
	<TR class='row2'><TD align=right>$strShowUrlOfTheList:</TD>
	<TD><INPUT TYPE='checkbox' NAME='url' value='1'"; if($sCover['url']) echo " checked"; echo "></TD>
    <td colspan=2>&nbsp;</td>
  </TR>
</TABLE>
<br>
<table border='0' cellspacing='1' cellpadding='3' class='tblback' width='100%'>
<tr class='top'><td colspan='6'>$strDisplayedFields:</td></tr>\n";

// movie properties fields

$i=0;
foreach($PropAll as $Prop) {
    if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
    if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
	if($Prop['ShowOnCover']!=PML_Cover_Normal && $Prop['ShowOnCover']!=PML_Cover_SideTitle && $Prop['ShowOnCover']!=PML_Cover_SideLang && $Prop['ShowOnCover']!=PML_Cover_Format) continue;
	$Dat = $Data[$ID][$Prop['Name']];
	if($i%3==0) {
		if($i!=0) echo "  </tr>\n";
		echo "  <tr class='row";
		echo (($i/3)%2)+1;
		echo "'>\n";
	}
	echo "    <td align='right'>$Prop[InTitle]";
	if($Dat=="") echo " <i>($strEmpty)</i>";
	"</td>\n";
	echo "    <td><input type='checkbox' name='shw$Prop[ID]' value='1'";
	if($Dat=="") echo " disabled"; else echo " checked";
	echo "></td>\n";
	$i++;

}
if($i%3) {
	echo "    <td colspan='".((($i%3)+1)*2)."'>&nbsp;</td>\n";
	$i+=($i%3)+1;
}
echo "  <tr class='row";
echo (($i/3)%2)+1;
echo "'>
	<TD colspan=6 align=\"center\"><INPUT TYPE='submit' value='$strCoverGenerate'></TD>
</TR>
</TABLE>
</form>";


include("bottom.html");
?>
