<?php
/** powermovielist edit index-items
 * $Id: editindexitems.php,v 1.4 2006/01/01 12:23:55 niko Exp $
*/
$FILE_SELF = "editindexitems.php";
$LoadSmarty=true;
include("application.php");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

if($Active!="index") {
    ErrorExit("only avaliable for index-page");
}

$Title = $strIndexItem;
$TitlePl = $strIndexItems;
$Table = $CFG['Prefix'] . "indexitems";

$SortOrderField = "SortOrder";

$SessionVar = "editindexitem";

$Filter = "";
$FilterVal = "";

$i=0;
$Show[$i]['name'] = "Name";
$Show[$i]['type'] = "username";
$Show[$i]['prop'] = "12";    //Text-Field-Width
$Show[$i]['text'] = $strFieldname;
$Show[$i]['comm'] = $strFieldInListSameNameAvaliableFields;
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$Show[$i]['uniq'] = true;
$i++;
$Show[$i]['name'] = "ListHeader";
$Show[$i]['type'] = "text";
$Show[$i]['prop'] = "15";
$Show[$i]['text'] = $strListText;
$Show[$i]['comm'] = "($strDisplayedOnThePage)";
$Show[$i]['main'] = true;
$Show[$i]['def'] = "";
$i++;
$Show[$i]['name'] = "LoadOnly";
$Show[$i]['type'] = "checkbox";
$Show[$i]['prop'] = "1;0";
$Show[$i]['text'] = $strLoadOnly;
$Show[$i]['comm'] = $strIfCheckedFileOnlyLoadedExamplePoster;
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";
$i++;
$Show[$i]['name'] = "DisplayOptions";
$Show[$i]['type'] = "listbox";
$Show[$i]['values'] = ";short;html";
$Show[$i]['prop'] = "normal Text;Short Text;Html-Code";
$Show[$i]['text'] = "Display Options";
$Show[$i]['comm'] = "(only for listbox and boolean fields)";
$Show[$i]['main'] = false;
$Show[$i]['def'] = "0";


RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);


$DOC_TITLE = $strIndexItems;
include("top.html");		

include("edit.php");


//clear the smarty cache for this list
if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$smarty->clear_cache(null,"list|$Active");
}

if(isset($_GET['nextaction'])) {
	$_GET['action'] = $_GET['nextaction'];
	$action = $_GET['nextaction'];
	include("edit.php");
}

if($action=="editsave" || $action=="addsave" || $action=="delsave") {
	$action = "";
	$_GET['action'] = $action;
	include("edit.php");
}

include("bottom.html");

?>