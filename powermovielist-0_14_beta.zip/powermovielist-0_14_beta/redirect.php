<?php
/** powermovielist redirect-script (from ErrorDocument)
 * $Id: redirect.php,v 1.5 2005/10/02 09:13:59 niko Exp $
 this script should only be called from the ErrorDocument - when a user goes to a list using the /listname
*/
include("config.inc.php");
include("functions.php");
ConnectDatabase();

preg_match("#/([^/]+)/?$#", $_SERVER['REQUEST_URI'], $erg);
$Dat=$erg[1];
$strSql = "SELECT * FROM $CFG[Prefix]lists WHERE name='$Dat'";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
if(mysql_num_rows($result)) {
    header("Location: $CFG[HttpPath]list.php?Active=$Dat");
    echo "going to $Dat";
} else {
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
The requested URL '.$_SERVER['REQUEST_URI'].' was not found on this server.<br>
PowerMovieList tried to locate a list called '.$Dat.' but didn\'t find it either.<p>
<hr>
'.$_SERVER['SERVER_SIGNATURE'].'
</body></html>';
}

?>