<?php
/** powermovielist login.php
 * $Id: lostpwd.php,v 1.3 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "lostpwd.php";
include_once("application.php");

if(!isset($_POST['PUser']) || !isset($_POST['PEmail'])) {
	$DOC_TITLE = $strLostPassword;
	include("top.html");
    echo "<form name=\"LoginForm\" method=\"post\" action=\"lostpwd.php\">
	<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='30%' align='center'>
			<tr class='row1'>
			  <td colspan='2' align='center'>
		  $strIfYouHaveForgottenYourPasswordRequestMail
			  </td>
			</tr>
		<tr class='row1'>
			  <td align='right'>
					<b>$GLOBALS[strLoginUser]:</b>
			  </td>
			  <td>
				<input type=\"text\" name=\"PUser\">
			  </td>
			</tr>
			<tr class='row2'>
			  <td align='right'>
					<b>$strEMail:</b>
			  </td>
			  <td>
				<input type=\"text\" name=\"PEmail\">
			  </td>
			</tr>
			<tr class='row1'>
			  <td>
		</td>
				<td>
			  <input type=\"submit\" name=\"Submit\" value=\"$strRequest\">
				</td>
		</tr>
	</table>
	</form>
	<script language='Javascript'>
	self.document.LoginForm.LUser.focus();
	</script>";
	include "bottom.html";
	exit;
}


//else call the usrclass-function:
$usr->DoLostPassword($_POST['PUser'], $_POST['PEmail']);

echo $strMailWasSentWithNewRandomPass;

echo "<br><br>$strClickHereToGoToIndex\n";

include("bottom.html");


?>