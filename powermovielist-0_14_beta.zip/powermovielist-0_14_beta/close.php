<?php
/** powermovielist close/open list
 * $Id: close.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "close.php";
include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);


$DOC_TITLE = $strCloseList;
include("top.html");

if(isset($_GET['action'])) $action = $_GET['action']; else $action="";

if($action=="") {
	echo "<h1>$strCloseList</h1>\n";
	$Dat = $ActiveList['closetext'];
	if($Dat=="")
		$Dat = $strCloseTextStd;

	echo "$strCloseTextAbout
	<FORM METHOD=POST ACTION='close.php".$GLOBALS['GlobalArg']."action=Close'>
		<INPUT TYPE='text' NAME='DisplayText' size=60 value='" .  $Dat . "'><br><br>
		<INPUT TYPE='submit' value='$strCloseList'>
	</FORM>
	";	
}

if($action=="Close") {
	$strSql = "UPDATE " . $CFG['Prefix'] . "lists SET close=1, closetext='$_POST[DisplayText]' WHERE ID=" . $ActiveList['ID'];
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	echo $strListClosed;
}




if($action=="Open") {
	$strSql = "UPDATE " . $CFG['Prefix'] . "lists SET close=0 WHERE ID=" . $ActiveList['ID'];
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	echo $strListIsBackAgain;
}
	include("bottom.html");
?>