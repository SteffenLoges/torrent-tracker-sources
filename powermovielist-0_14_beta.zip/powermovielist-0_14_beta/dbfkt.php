<?php
/** powermovielist database-functions
 * $Id: dbfkt.php,v 1.11 2006/02/11 05:37:06 niko Exp $
*/

$FILE_SELF = "dbfkt.php";
$CheckNewVersion=false;
include_once("application.php");
if($ActiveUserRights<PML_Rights_ListAdmin) {
	include("top.html");
	RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);
}


if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";


$pml_Tables = array("$CFG[Prefix]counter",
    "$CFG[Prefix]dloadlog",
    "$CFG[Prefix]linklist",
    "$CFG[Prefix]comment",
    "$CFG[Prefix]users",
    "$CFG[Prefix]userrights",
    "$CFG[Prefix]movies",
    "$CFG[Prefix]votes",
    "$CFG[Prefix]lists",
    "$CFG[Prefix]prop",
    "$CFG[Prefix]propfetch",
    "$CFG[Prefix]propval",
    "$CFG[Prefix]loanstatus",
    "$CFG[Prefix]announcment",
    "$CFG[Prefix]fav");
$strSql = "SELECT name FROM $CFG[Prefix]lists";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
while($row=mysql_fetch_assoc($result)) {
	if($row['name']=="index") continue;
	$pml_Tables[] = "$CFG[Prefix]movies_".strtolower($row['name']);
}


switch($action) {
    case "":
    case "menu":
        $DOC_TITLE = "Database-Functions";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>Database-Functions</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'>check/fix database entries</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>When a movie or a list gets deleted more than just one entry have to be deleted. This functions checks the database unused properties. You may also continue to fix them.<br><b>backup the database bevore using this functions!</b> (just to be sure :D)</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row2'>\n";        
        echo "    <td colspan='2'>\n";
        echo "      <form action='dbfkt.php".$GlobalArg."action=check' method='post'>\n";
        echo "        <input type='submit' value='check properties'>\n";
        echo "      </form>\n";
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'>check uploaded files</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>This function checks for uploaded/cached files for entries that don't exist anymore</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row2'>\n";        
        echo "    <td colspan='2'>\n";
        echo "      <form action='dbfkt.php".$GlobalArg."action=checkFiles' method='post'>\n";
        echo "        <input type='submit' value='check files'>\n";
        echo "      </form>\n";
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";
        
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'>check/analyze/optimize/repair tables</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>This function calls the CHECK, ANALYZE, OPTIMIZE or REPAIR functions from mysql. Read the MySql-reference for more information about them.</td>\n";
        echo "  </tr>\n";
        echo "  <form action='dbfkt.php".$GlobalArg."action=mysql_tblfkt' method='post'>\n";
        echo "  <tr class='row2'>\n";        
        echo "    <td width=10 nowrap align='right'>\n";
        echo "      <select name='tables[]' size='10' multiple>\n";
        foreach($pml_Tables as $Dat) {
            echo "        <option value='$Dat' selected>$Dat</option>\n";
        }
        echo "      </select>\n";
        echo "    </td>\n";
        echo "    <td>\n";        
        echo "      <input type='radio' name='mysqlaction' value='1' checked>CHECK<br>\n";        
        echo "      <input type='radio' name='mysqlaction' value='2'>ANALYZE<br>\n";        
        echo "      <input type='radio' name='mysqlaction' value='3'>OPTIMIZE<br>\n";        
        echo "      <input type='radio' name='mysqlaction' value='4'>REPAIR\n";                
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>\n";
        echo "        <input type='submit' value='execute'>\n";        
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "  </form>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'>execute sql-command</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>Only for experts! You can execute any sql-command here - no data will be returned!</td>\n";
        echo "  </tr>\n";
        echo "  <form action='dbfkt.php".$GlobalArg."action=executetext' method='post'>\n";
        echo "  <tr class='row2'>\n";        
        echo "    <td colspan='2'>\n";
        echo "      <textarea name='inpText' rows='10' cols='70' ></textarea><br>\n";
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>\n";
        echo "        <input type='submit' value='execute'>\n";        
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "  </form>\n";
        echo "</table>\n";

        echo "<br>\n";
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'>execute sql-command from .sql-file</td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>Only for experts! You can execute any sql-command here - no data will be returned!</td>\n";
        echo "  </tr>\n";
        echo "  <form action='dbfkt.php".$GlobalArg."action=executefile' method='post' enctype='multipart/form-data'>\n";
        echo "  <tr class='row2'>\n";        
        echo "    <td colspan='2'>\n";        
        echo "        <input name='inpFile' type='file' size='40'><br>\n";        
        echo "      </form>\n";
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>\n";
        echo "        <input type='submit' value='execute'>\n";        
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "  </form>\n";
        echo "</table>\n";

        include("bottom.html");        
        break;
    case "checkFiles":
    case "fixFiles":
    
        $DOC_TITLE = "Database-Functions";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>check files</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>working... please wait...</td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        flush();
    
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row2'>\n";
        echo "    <td colspan='2'>\n";
        
        $MovieIDs = array(0);
        $strSql = "SELECT ID FROM $CFG[Prefix]movies";
        $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        while($row=mysql_fetch_assoc($result)) {
            $MovieIDs[] = $row['ID'];
        }
        
        $checkDirs = array($CFG['UploadDir']);
        if($CFG['UploadDir']!=$CFG['CacheDir']) $checkDirs[] = $CFG['CacheDir'];
        
        $ErrNum = 0;
        foreach($checkDirs as $dir)
        {
            $handle = opendir($dir);
            while ($file = readdir ($handle)) {
            if ($file != "." && $file != "..") {
                if(preg_match('#^([0-9]+)-#', $file, $i)) {
                    if(!in_array($i[1], $MovieIDs)) {
                        $ErrNum++;
                        if($action=="checkFiles") {
                            echo "Entry $i[1] does not exist; file could be deleted: $file<br>";
                        } else {
                            unlink($dir."/".$file);
                            echo "Entry $i[1] does not exist; file deleted: $file<br>";
                        }
                    }
                } else {
                    if($action=="checkFiles") {
                        echo "Unknown File (ignored): $file<br>";
                    }
                }
                flush();
            }
            }
            closedir($handle);
        }
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>$action completed...</td>\n";
        echo "  </tr>\n";

        if($action=="checkFiles" && $ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'>$ErrNum files that don't belong to an entry where found!</td>\n";
            echo "  </tr>\n";
            echo "  <tr class='row1'>\n";
            echo "    <td colspan='2'>bevore fixing, make sure that your backup did work :D</td>\n";
            echo "  </tr>\n";

            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'>\n";
            echo "      <form action='dbfkt.php".$GlobalArg."action=fixFiles' method='post'>\n";
            echo "        <input type='submit' value='delete these files'>\n";
            echo "      </form>\n";
            echo "    </td>\n";
            echo "  </tr>\n";
        } elseif($action=="checkFiles" && !$ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'><b>No Errors were found!</b></td>\n";
            echo "  </tr>\n";
        } elseif($action=="fixFiles" && $ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'><b>$ErrNum files that don't belong to an entry where deleted!<br>Hopefully now everything works :D</b></td>\n";
            echo "  </tr>\n";
        } elseif($action=="fixFiles" && !$ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'><b>No Errors were found!</b></td>\n";
            echo "  </tr>\n";
        }
        echo "</table>\n";        
        break;
    case "mysql_tblfkt":
        $DOC_TITLE = "Database-Functions";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>database - MySQL-functions</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>working... please wait...</td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        flush();

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>\n";
        if(!is_array($_POST['tables'])) die("invalid post-data");
        foreach($_POST['tables'] as $Dat) {
            if(!in_array($Dat, $pml_Tables)) continue; //if not a table used by pml continue - hackers could post anything :D
            switch($_POST['mysqlaction']) {
                case 1: //Check
                    $strSql = "CHECK TABLE $Dat";
	                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    $row = mysql_fetch_assoc($result);
                    echo "CHECK TABLE $row[Table]: $row[Msg_type] <b>$row[Msg_text]</b><br>\n";
                    break;
                case 2: //Analyze
                    $strSql = "ANALYZE TABLE $Dat";
	                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    $row = mysql_fetch_assoc($result);
                    echo "ANALYZE TABLE $row[Table]: $row[Msg_type] <b>$row[Msg_text]</b><br>\n";
                    break;
                case 3: //Optimize
                    $strSql = "OPTIMIZE TABLE $Dat";
	                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    echo "OPTIMIZE TABLE $Dat <b>Ok</b><br>\n";
                    break;
                case 4: //Repair
                    $strSql = "REPAIR TABLE $Dat";
	                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    $row = mysql_fetch_assoc($result);
                    echo "REPAIR TABLE $row[Table]: $row[Msg_type] <b>$row[Msg_text]</b><br>\n";
                    break;
            } //end switch
        } //end foreach
        echo "<br><b>...completed\n";
        echo "    </td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        break;
    case "executefile":
    case "executetext":
        $DOC_TITLE = "Database-Functions";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>executeing sql-commands</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>the queryies will just be sent to the sql-server, nothing will be returned!<br><br>please wait...</td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        flush();

        if($action=="executetext") {
            $strSql = $_POST['inpText'];
        }
        if($actioni=="executefile") {
		    $strSql = implode(file($_FILES['inpFile']['tmp_name']),"");
        }
        $Dat = array();
        PMA_splitSqlFile($Dat, $strSql);
		
		foreach($Dat as $strSql) {
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
        }
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row2'>\n";
        echo "    <td colspan='2'><b>done!</b></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        break;

    case "checkfinished":
    case "fixfinished":
        if(isset($_SESSION['ErrNum']))
            $ErrNum=$_SESSION['ErrNum'];
        else
            $ErrNum=0;
        
        if($action=="checkfinished") $strAction = "check"; else $strAction = "fix";

        $DOC_TITLE = "Database-Functions";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>$strAction database</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>$strAction completed...</td>\n";
        echo "  </tr>\n";

        if($action=="checkfinished" && $ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'>$ErrNum tables with errors where found!</td>\n";
            echo "  </tr>\n";
            echo "  <tr class='row1'>\n";
            echo "    <td colspan='2'>bevore fixing, make sure that your backup did work :D</td>\n";
            echo "  </tr>\n";

            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'>\n";
            echo "      <form action='dbfkt.php".$GlobalArg."action=fix' method='post'>\n";
            echo "        <input type='submit' value='fix errors'>\n";
            echo "      </form>\n";
            echo "    </td>\n";
            echo "  </tr>\n";
        } elseif($action=="checkfinished" && !$ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'><b>No Errors were found!</b></td>\n";
            echo "  </tr>\n";
        } elseif($action=="fixfinished" && $ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'><b>$ErrNum tables with errors have been corrected.<br>Hopefully now everything works :D</b></td>\n";
            echo "  </tr>\n";
        } elseif($action=="fixfinished" && !$ErrNum) {
            echo "  <tr class='row2'>\n";
            echo "    <td colspan='2'><b>No Errors were found!</b></td>\n";
            echo "  </tr>\n";
        }
        echo "</table>\n";
        
        unset($_SESSION['ErrNum']);

        break;
    case "check":
    case "fix":
        $tables = array("prop_lists", "propval_prop", "movies_lists", "userrights_lists", "userrights_users", "dloadlog_movies", "comment_movies", "votes_movies", "announcments_lists", "favs_lists", "favs_users");
        
        @set_time_limit(0); //set the timelimit to 0 (deactivate) and ignore errors

        if(isset($_SESSION['ErrNum']))
            $ErrNum=$_SESSION['ErrNum'];
        else
            $ErrNum=0;

        if(!isset($_GET['table']))
            $table = $tables[0];
        else
            $table = $_GET['table'];

        if(!in_array($table, $tables))
            ErrorExit("Invalid Table specified!");
        if(isset($tables[array_search($table, $tables)+1])) {
            $nextTable = $tables[array_search($table, $tables)+1];
            $RefreshUrl = "dbfkt.php".$GlobalArg."action=".$action."&table=$nextTable";
        } else {
            $RefreshUrl = "dbfkt.php".$GlobalArg."action=".$action."finished";
        }
        $DoRefresh=true;
        	
        $DOC_TITLE = "Database-Functions";
        include("top.html");
        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='top'>\n";
        echo "    <td colspan='2'><h1>$action database</h1></td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        echo "<br>\n";

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'>working... please wait...<br>depending on your database-size this could take some time now...</td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        flush();
        
        $DoDelete = false;
        if($action=="fix") {
            $DoDelete = true;
            $FoundString = "deleted";
        } else {        
            $FoundString = "found";
        }

        echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>\n";
        echo "  <tr class='row1'>\n";
        echo "    <td colspan='2'><b>".$action."ing:</b><br>";

        switch($table) {
            case "prop_lists":
                //-> check for pml_prop for non existing list and delete them
                $Prop_ListIDsFound = 0;
                $Lists = checkdb_loadTable("lists");
                if($Prop_ListIDsFound == 0)
                    echo "$CFG[Prefix]prop: all ListIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]Prop: $Prop_ListIDsFound entries with invalid ListIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "propval_prop":
                //-> check for pml_propval for non existing prop and delete them
                $PropVal_PropIDsFound = 0;
                $Props = checkdb_loadTable("prop");
                $strSql = "SELECT PropID, ID FROM $CFG[Prefix]propval";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['PropID'], $Props)) {
                        $PropVal_PropIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]propval WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($PropVal_PropIDsFound == 0)
                    echo "$CFG[Prefix]propval: all PropIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]propval: $PropVal_PropIDsFound entries with invalid PropIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "movies_lists":
                //-> check for pml_movies for non existing list and delete tem
                $Movie_ListIDsFound = 0;
                $Lists = checkdb_loadTable("lists");
                $strSql = "SELECT ListID, ID FROM $CFG[Prefix]movies";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['ListID'], $Lists)) {
                        $Movie_ListIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]movies WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($Movie_ListIDsFound == 0)
                    echo "$CFG[Prefix]movies: all ListIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]movies: $Movie_ListIDsFound entries with invalid ListIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "userrights_lists":
                //-> check for pml_userrights for non existing lists and delete tem
                $UserRights_ListIDsFound = 0;
                $Lists = checkdb_loadTable("lists");
                $strSql = "SELECT ListID FROM $CFG[Prefix]userrights";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['ListID'], $Lists)) {
                        $UserRights_ListIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]userrights WHERE ListID=$row[ListID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($UserRights_ListIDsFound == 0)
                    echo "$CFG[Prefix]userrights: all ListIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]userrights: $UserRights_ListIDsFound entries with invalid ListIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "userrights_users":
                //-> check for pml_userrights for non existing users and delete tem
                $UsrList = $usr->GetUserList();
                $Users = array();
                foreach($UsrList as $Dat)
                    $Users[] = $Dat['ID'];
                $UserRights_UserIDsFound = 0;
                $strSql = "SELECT UserID FROM $CFG[Prefix]userrights";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['UserID'], $Users)) {
                        $UserRights_UserIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]userrights WHERE UserID=$row[UserID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($UserRights_ListIDsFound == 0)
                    echo "$CFG[Prefix]userrights: all UserIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]userrights: $UserRights_ListIDsFound entries with invalid UserIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "dloadlog_movies":
                //-> dloadlog - movie
                $DloadLog_MovieIDsFound = 0;
                $Movies = checkdb_loadTable("movies");
                $strSql = "SELECT MovieID FROM $CFG[Prefix]dloadlog";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['MovieID'], $Movies)) {
                        $DloadLog_MovieIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]dloadlog WHERE MovieID=$row[MovieID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($DloadLog_MovieIDsFound == 0)
                    echo "$CFG[Prefix]dloadlog: all MovieIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]dloadlog: $DloadLog_MovieIDsFound entries with invalid MovieIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "comment_movies":
                //-> comment - movie
                $Comment_MovieIDsFound = 0;
                $Movies = checkdb_loadTable("movies");
                $strSql = "SELECT ID,MovieID FROM $CFG[Prefix]comment";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['MovieID'], $Movies)) {
                        $Comment_MovieIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]comment WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($Comment_MovieIDsFound == 0)
                    echo "$CFG[Prefix]comment: all MovieIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]comment: $Comment_MovieIDsFound entries with invalid MovieIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "votes_movies":
                //-> votes - movie
                $Votes_MovieIDsFound = 0;
                $Movies = checkdb_loadTable("movies");
                $strSql = "SELECT ID,MovieID FROM $CFG[Prefix]votes";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['MovieID'], $Movies)) {
                        $Votes_MovieIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]votes WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($Votes_MovieIDsFound == 0)
                    echo "$CFG[Prefix]votes: all MovieIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]votes: $Votes_MovieIDsFound entries with invalid MovieIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "announcments_lists":
                //-> annoucments - lists
                $Anncouncment_ListIDsFound = 0;
                $Lists = checkdb_loadTable("lists");
                $strSql = "SELECT ID,ListID FROM $CFG[Prefix]announcment";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['ListID'], $Lists)) {
                        $Anncouncment_ListIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]announcment WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($Anncouncment_ListIDsFound == 0)
                    echo "$CFG[Prefix]annoucment: all ListIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]annoucment: $Anncouncment_ListIDsFound entries with invalid PropIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "favs_lists":
                //-> favs - lists
                $Fav_ListIDsFound = 0;
                $Lists = checkdb_loadTable("lists");
                $strSql = "SELECT ID,ListID FROM $CFG[Prefix]fav";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['ListID'], $Lists)) {
                        $Fav_ListIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]fav WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($Fav_ListIDsFound == 0)
                    echo "$CFG[Prefix]fav: all ListIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]fav: $Fav_ListIDsFound entries with invalid ListIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
            case "favs_users":
                //-> favs - users
                $Fav_UserIDsFound = 0;
                $UsrList = $usr->GetUserList();
                $Users = array();
                foreach($UsrList as $Dat)
                    $Users[] = $Dat['ID'];
                $strSql = "SELECT ID,UserID FROM $CFG[Prefix]fav";
                $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                while($row=mysql_fetch_assoc($result)) {
                    if(!in_array($row['UserID'], $Users)) {
                        $Fav_UserIDsFound++;
                        if($DoDelete) {
                            $strSql = "DELETE FROM $CFG[Prefix]fav WHERE ID=$row[ID]";
                            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                        }
                    }
                }
                if($Fav_UserIDsFound == 0)
                    echo "$CFG[Prefix]fav: all UserIDs exist<br>\n";
                else {
                    echo "<b>$CFG[Prefix]fav: $Fav_UserIDsFound entries with invalid UserIDs $FoundString</b><br>\n";
                    $ErrNum++;
                }
                break;
        }        
    
        $_SESSION['ErrNum'] = $ErrNum;
        echo "Click <a href=\"$RefreshUrl\">here</a> to continue with the next table if the Meta-Refresh doesn't work.\n";
        echo "</td>\n";
        echo "  </tr>\n";
        echo "</table>\n";
        include("bottom.html");
        break;
}

function checkdb_loadTable($TableName) {
    global $CFG, $pmldb;    
    $strSql = "SELECT ID FROM $CFG[Prefix]$TableName";
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $ret = array();
    while($row=mysql_fetch_assoc($result)) {
        $ret[] = $row['ID'];
    }
    return($ret);
}

?>