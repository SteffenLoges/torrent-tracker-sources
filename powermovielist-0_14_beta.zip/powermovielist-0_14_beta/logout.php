<?php
/** powermovielist logout.php - loggs the active user out
 * $Id: logout.php,v 1.2 2005/02/17 07:11:28 niko Exp $
*/
$FILE_SELF = "logout.php";
include_once("application.php");

//call logout-function
$usr->DoLogout();

$DoRefresh=true;
$RefreshUrl="index.php";
include("top.html");

echo " <table width='100%' height='100%'>\n";
echo "  <tr valign='middle' align='center'>\n";
//echo "   <td><b>Sie wurden erfolgreich abgemeldet.</b><br><a href='$RefreshUrl'>Falls die automatische Weiterleitung nicht funktioniert, klicken Sie bitte hier!</a></td>\n";
echo "   <td><b>You logged out sucessfully.</b><br><a href='$RefreshUrl'>If the automatic redirection shouldn't work click here!</a></td>\n";
echo "  </tr>\n";
echo " </table>	\n";

include("bottom.html");
?>