<?php
/** powermovielist frameset for config-menue
 * $Id: editconfig.php,v 1.3 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "editconfig.php";
include_once("application.php"); 

RequestLogin(PML_LoginStyle_NoGuestAllowed);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE><?php echo $strConfigTitle?></TITLE>
<LINK REL="shortcut icon" HREF="image/divx.ico">
<meta http-equiv="Content-Type" content="text/html<?
if(isset($LngCharSet)) echo "; charset=$LngCharSet";
?>">
</HEAD>
<frameset cols="190,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
  <frame name="menu" scrolling="auto" noresize src="cfgmenu.php<?php echo $GlobalArg ?>">
  <frame name="main" src="<?php 
if(!isset($_GET['ShowPage']))
	echo "about.php$GlobalArg";
else
	echo $_GET['ShowPage'];
?>">
</frameset>
<noframes><BODY>your browser doesn't support frames... wtf</body></noframes>
</HTML>