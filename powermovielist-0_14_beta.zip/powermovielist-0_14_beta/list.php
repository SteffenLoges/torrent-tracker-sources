<?php
/** powermovielist list-display and index-display
* $Id: list.php,v 1.28 2005/11/05 12:46:53 niko Exp $
*/
$FILE_SELF = "list.php";
$LoadSmarty = true;
include_once("application.php");

if($Active=="index") {
//	Header("Location: index.php$GlobalArg");
//	echo "the list moved to index.php...";
    include("index.php");
	exit;
}

$sDisplay['SortPropID']=$ActiveList['stdsort']; //load the standard-values
$sDisplay['SortDirection']=0;
$sDisplay['SearchText']="";
$sDisplay['PerPage']=$ActiveList['StdPerPage'];
$sDisplay['Page'] = 1;
$sDisplay['Char'] = "";
$sDisplay['Filter'] = array();
if(isset($_GET['Sort'])) {
    $sDisplay['SortPropID'] = ceil($_GET['Sort']);
}
if(isset($_GET['Dir'])) {
    $sDisplay['SortDirection'] = 1;
} else {
    $sDisplay['SortDirection']=0;
}
if(isset($_GET['Char'])) {
    $sDisplay['Char'] = $_GET['Char'];
}
if(isset($_GET['Page'])) {
    $sDisplay['Page'] = abs(ceil($_GET['Page']));
}
if(isset($_GET['Search'])) {
    $sDisplay['SearchText'] = $_GET['Search'];
}
if(isset($_GET['Display'])) {
    $sDisplay['PerPage'] = abs(ceil($_GET['Display']));
}
if(isset($_GET['Filter'])) {
    $sDisplay['Filter'] = $_GET['Filter'];
  	if(!is_array($sDisplay['Filter'])) $sDisplay['Filter']=array();
}
LoadPropAll();
foreach($PropAll as $kProp=>$Prop) {
    if($Prop['ShowFilter']==PML_ShowFilter_Listbox && ($Prop['PropType']==PML_PropType_Boolean || $Prop['PropType']==PML_PropType_ListBox || $Prop['PropType']==PML_PropType_ListBoxMulti)) {
        if(!isset($sDisplay['Filter'][$kProp])) $sDisplay['Filter'][$kProp]=$Prop['StdFilterPropValID'];
    }
}

/* Display-Session-Variable:
to be saved:
   session-name                 get/post	gp-name		desc
- $sDisplay['SortPropID']        get            Sort        SortPropID after that is sorted
- $sDisplay['SortDirection']    get            Dir            SortDirection (Standard-Dir or Nor)
- $sDisplay['Filter']            -            -            Filter-array    
- $sDisplay['SearchText']        get        Search        search-text
- $sDisplay['PerPage']            get        Display        display-per-page
- $sDisplay['Page']            get         Page        page displayed
- $sDisplay['Char']            get         Char        character displayed (filter)
*/


$TplFile = $ActiveList['listtpl'];

if($TplFile=="") {
	$TplFile="list.tpl"; //default template file
}
$TplFile = "list/$TplFile";

if(!FileExists("templates/".$TplFile))
	$TplFile="list/list.tpl";

$CacheId = "list|$Active";
$CacheId .= "|$sDisplay[SortPropID]|$sDisplay[SortDirection]|$sDisplay[PerPage]|$sDisplay[Page]|$sDisplay[Char]|$ActiveUserRights|";
foreach($sDisplay['Filter'] as $k=>$Flt) {
    $CacheId .= $k."=".$Flt."|";
}
$CacheId .= substr($sDisplay['SearchText'], 0, 1)."|"; //when more than 32.000 search-strings we have file-system-limitations
$CacheId .= $sDisplay['SearchText'];

$smarty->cache_lifetime = $CFG['CacheLifetimeList']; //24 hours

//if favourite lists are used we ned a non-caching-block:
$smarty->register_block("NoCache", "function_NoCache", false); //not cached

//and for this none-caching-block we need some variables:
$smarty->assign("ActiveList",$ActiveList);

$u = $ActiveUser;
unset($u['pass']);
$smarty->assign("ActiveUser",$u);

$smarty->assign("CFG",array("LinkListType"=>$CFG['LinkListType'], "ListType"=>$CFG['ListType'], "GlobalArg"=>$GlobalArg, "GlobalArgWOActive"=>$GlobalArgWOActive, "UseDloadLog"=>$CFG['UseDloadLog'], "UseStatistics"=>$CFG['UseStatistics']));
$smarty->assign("lang",      array("strManagefavorites"      => $strManagefavorites,
                                  "strAddActiveList"         => $strAddActiveList,
                                  "strYourFavLists"          => $strYourFavLists,
                                  "strGoToList"              => $strGoToList,
                                  "strLoanCartEmpty"         => $strLoanCartEmpty,
                                  "strLoanCartFound"         => $strLoanCartFound
                                 ));
//Retrieve value for items in the cart, added for the loan system;
//outside of is_cached - because it is withing a NoCache-block and won't be cached
if ($ActiveList['EnableLoan']) {
    $strSql = "SELECT MovieID FROM $CFG[Prefix]loanstatus WHERE UserID=$ActiveUser[ID] AND status='1' "; 
    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $smarty->assign("numCart", mysql_num_rows($result));
    $cartItems=array();
    while($row=mysql_fetch_assoc($result)) {
        $cartItems[$row['MovieID']] = 1;
    }
    //$cartItems will be used in function_cartIcon
}

//function-registers have to be done outside is_cached and outside ActiveList.EnableLoan
//else we would get a unknown tag error from smarty
$smarty->register_function("cartIcon", "function_cartIcon", false, array("MovieID"));
$smarty->register_function("GetMovieProp", "function_GetMovieProp");

if(!$smarty->is_cached($TplFile,$CacheId)) {
    $PropAll[0] = array("UseSort"=>1,"ShowInList"=>0,"PropType"=>PML_PropType_DateAdded,"RequiredRights"=>-1, "Name"=>"DateAdded"); //for date, standard-sort-order
    $PropAll[-1] = array("UseSort"=>1,"ShowInList"=>0,"PropType"=>PML_PropType_Clicks,"RequiredRights"=>-1, "Name"=>"DownloadCount"); //for downloaded


    $PropShown=0;
    foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
        if($Prop['ShowInList']) $PropShown++;
    }
    if($ActiveUserRights>PML_Rights_Moderator) $PropShown++; //for list-admins >

    $ret = ReadMovieDataFromDb("list", $sDisplay, "html");
	$Data = $ret['Data'];
	$AnzGes = $ret['AnzGes'];
	$AnzFound = $ret['AnzFound'];
	unset($ret);

    
    $smarty->assign("AnzFound", $AnzFound);
    $smarty->assign("AnzGes", $AnzGes);
    
    $smarty->assign("lang", array("LngCharSet"               => $LngCharSet,
		                          "strCounterTitle"          => $strCounterTitle,
								  "strMostClickedEntries"    => $strMostClickedEntries,
								  "strNewEntries"            => $strNewEntries,
								  "strAvLists"               => $strAvLists,
		                          "strMenu"                  => $strMenu,
								  "strStatistics"            => $strStatistics,
		                          "strLoggedIn"              => $strLoggedIn,
		                          "strRights"                => $strRights,
		                          "strCounterGesamt"         => $strCounterGesamt,
		                          "strCounterOnlineNow"      => $strCounterOnlineNow,
		                          "strCounterRekord"         => $strCounterRekord,
		                          "strCounterOnlineUsers"    => $strCounterOnlineUsers,
		                          "strGuests"                => $strGuests,
		                          "strAddedToday"            => $strAddedToday,
		                          "strEntriesInList"         => $strEntriesInList,
		                          "strAddedYesterday"        => $strAddedYesterday,
		                          "strSizeOfAllLinks"        => $strSizeOfAllLinks,
		                          "strDownloaded"            => $strDownloaded,
		                          "strShowOnly"              => $strShowOnly,		                          
		                          "strSqlPerPage"            => $strSqlPerPage,
		                          "strSearchFor"             => $strSearchFor,
		                          "strFilterButtonValue"     => $strFilterButtonValue,
                                    "strClearAll"       => $strClearAll,
                                    "strSeeCart"       => $strSeeCart,
                                    "strCartAdd"       => $strCartAdd,
                                    "strRequestItem"       => $strRequestItem,
                                    "strreserve_all_items"       => $strreserve_all_items,

                                  "strAll"                   => $strAll,
                                  "strSqlNothingFound"       => $strSqlNothingFound,
                                  "strSqlFound"              => $strSqlFound,
                                  "strSqlFrom"               => $strSqlFrom,
                                  "strFormatAll"             => $strFormatAll,
                                  "strDeleteEntrySure"       => $strDeleteEntrySure,
                                  "strManagefavorites"      => $strManagefavorites,
                                  "strAddActiveList"         => $strAddActiveList,
                                  "strYourFavLists"          => $strYourFavLists,
                                  "strGoToList"              => $strGoToList,
                                  "strLoanCartEmpty"         => $strLoanCartEmpty,
                                  "strLoanCartFound"         => $strLoanCartFound
								  ));
    if($CFG['UseStatistics']) {
        //Statisticsc:
        $smarty->assign("Statistics",LoadStatistics());
    }
    
    if($CFG['LinkListType']==PML_LinkListType_Select) {
        $strSql = "SELECT " . $CFG['Prefix'] . "linklist.Type, " . $CFG['Prefix'] . "linklist.Url, " . $CFG['Prefix'] . "linklist.Text, LOWER(" . $CFG['Prefix'] . "lists.name) AS name FROM " . $CFG['Prefix'] . "linklist LEFT JOIN " . $CFG['Prefix'] . "lists ON (" . $CFG['Prefix'] . "linklist.ListID=" . $CFG['Prefix'] . "lists.ID) ORDER BY SortOrder";
        $result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
        while($row = mysql_fetch_assoc($result)) {
            $LinkListData[] = $row;
        }
    	$smarty->assign("LinkListData",$LinkListData);
    }

	$Dat = $_SERVER['QUERY_STRING'];
	$pattern = array("/(Filter[^&]*)/", "/(Search[^&]*)/", "/(Display[^&]*)/", "/(Page[^&]*)/", "/(login[^&]*)/");
	$Dat = preg_replace($pattern,array("","","","",""),$Dat);
	while(strstr($Dat,"&&")) $Dat = str_replace("&&","&",$Dat);
	$Pos = strpos($Dat,"&");
	if(is_integer($Pos) && $Pos==0) 
		$Dat = substr($Dat,1);
	if(strrpos($Dat,"&")+1==strlen($Dat))
		$Dat = substr($Dat,0,-1);	
	$Dat=split('&', $Dat);
	$ret = "";    
	foreach($Dat as $x) {        
        if($x=="") continue;
		$x = split('=', $x);
        if(!isset($x[1]) || !isset($x[0])) continue;
		$ret .= "<input type='hidden' name='$x[0]' value='$x[1]'>\n";
   	}
    $smarty->assign("HiddenFields", $ret);


    //Load additional PropAll-values for the properties where the filters should be shown in the list...
    foreach($PropAll as $kProp=>$Prop) {        
        if($kProp<=0) continue;
		if($Prop['ShowFilter']!=PML_ShowFilter_Listbox) continue; //1 = show listbox
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['PropType']!=PML_PropType_ListBox && $Prop['PropType']!=PML_PropType_ListBoxMulti && $Prop['PropType']!=PML_PropType_Boolean) continue; //only listbox and listboxmulti
        if(!isset($sDisplay['Filter'][$Prop['ID']])) $sDisplay['Filter'][$Prop['ID']] = 0;
	}

	$strSql = "SELECT propval.*
				FROM $CFG[Prefix]propval propval, $CFG[Prefix]prop prop
				WHERE propval.PropID=prop.ID
				AND prop.ListID=$ActiveList[ID]
				AND prop.ShowFilter=".PML_ShowFilter_Listbox."
				AND prop.PropType IN (".PML_PropType_ListBox.",".PML_PropType_ListBoxMulti.",".PML_PropType_Boolean.")
				AND (prop.RequiredRights <= $GLOBALS[ActiveUserRights]";
	if($GLOBALS['ActiveUser']['name']!="Guest") {
		$strSql .= " OR prop.RequiredRights = -1";
	}
	$strSql .= ")";
	$strSql .= " ORDER BY prop.SortOrder, propval.SortOrder";
	$result = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);        
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {            
		if($sDisplay['Filter'][$row['PropID']]==$row['ID'])
			$row['selected'] = true;
		else
			$row['selected'] = false;
		$PropAll[$row['PropID']]['PropVals'][] = $row;
	}

    $smarty->assign("PropAll", $PropAll);
    $smarty->assign("PropNames", $PropNames);
    $smarty->assign("ActiveUserRights", $ActiveUserRights);
    $smarty->assign("sDisplay", $sDisplay);
    
    $Dat = array();
	for($i=0;$i<strlen($strFilterChars);$i++) {
		$Dat[] = substr($strFilterChars, $i, 1);
    }
    $smarty->assign("Chars", $Dat);

	$CharUrl = "list.php";
	$Dat = $_SERVER['QUERY_STRING'];
	$Dat = preg_replace(array("/(Char[^&]*)/","/(Page[^&]*)/"),array("",""),$Dat);
	$Dat.="&";
	while(strstr($Dat,"&&")) $Dat = str_replace("&&","&",$Dat);
	$Pos = strpos($Dat,"&");
	if(is_integer($Pos) && $Pos==0) 
		$Dat = substr($Dat,1);
	$CharUrl .= "?" . $Dat;
    $smarty->assign("CharUrl", $CharUrl);

	$NumUrl = "list.php";
	$Dat = $_SERVER['QUERY_STRING'];
	$Dat = preg_replace("/(Page[^&]*)/","",$Dat);
	while(strstr($Dat,"&&")) $Dat = str_replace("&&","&",$Dat);
	$Pos = strpos($Dat,"&");
	if(is_integer($Pos) && $Pos==0) 
		$Dat = substr($Dat,1);
	$NumUrl .= "?" . $Dat;
    $smarty->assign("NumUrl", $NumUrl);

    $Dat = array();    
    if($AnzFound > $sDisplay['PerPage']) {		
		if($sDisplay['Page'] > 1)            
            $Dat[] = array("page"=>$sDisplay['Page']-1, "text"=>"&lt;");
        else
            $Dat[] = array("page"=>-1, "text"=>"&lt;");
        $numStart = 0;
        $numEnd = $AnzFound/$sDisplay['PerPage'];
        if ($AnzFound/$sDisplay['PerPage'] > 10) {
            $numStart = $sDisplay['Page']-5;
            $numEnd = $sDisplay['Page']+5;
            if ($numStart < 0) {
                $i = $numStart;
                $numEnd = $numEnd - $i;
                $numStart = $numStart - $i;
            }
            if ($numEnd > $AnzFound/$sDisplay['PerPage']) {
                $i = $numEnd - ceil($AnzFound/$sDisplay['PerPage']);
                $numEnd = $numEnd - $i;
                $numStart = $numStart - $i;
            }
        }
        if ($numStart > 0) {
            $Dat[] = array("page"=>1, "text"=>"1");
            $Dat[] = array("page"=>-1, "text"=>" ... ");
        }
		for ($i = $numStart; $i < $numEnd; $i++) {
			if($i!=($sDisplay['Page']-1))
                $Dat[] = array("page"=>$i+1, "text"=>$i+1);
			else
                $Dat[] = array("page"=>-1, "text"=>$i+1);
		}
  
        if ($numEnd < $AnzFound/$sDisplay['PerPage']) {
            $Dat[] = array("page"=>-1, "text"=>" ... ");
            $Dat[] = array("page"=>ceil($AnzFound/$sDisplay['PerPage']), "text"=>ceil($AnzFound/$sDisplay['PerPage']));        
        }
  
		if(($sDisplay['Page']*$sDisplay['PerPage']) < $AnzFound)            
            $Dat[] = array("page"=>$sDisplay['Page']+1, "text"=>"&gt;");
        else            
            $Dat[] = array("page"=>-1, "text"=>"&gt;");
	}
    $smarty->assign("Nums", $Dat);
    $smarty->assign("PropShown", $PropShown);

	$SortUrl = "list.php";
	$Dat = $_SERVER['QUERY_STRING'];
	$Dat = preg_replace(array("/(Sort[^&]*)/","/(Dir[^&]*)/"),array("",""),$Dat);
	while(strstr($Dat,"&&")) $Dat = str_replace("&&","&",$Dat);
	$Pos = strpos($Dat,"&");
	if(is_integer($Pos) && $Pos==0) 
		$Dat = substr($Dat,1);
	$SortUrl .= "?" . $Dat;
    $smarty->assign("SortUrl", $SortUrl);


	$MovieIDs = array_keys($Data);
    $smarty->assign("MovieIDs", $MovieIDs);

    $MovieNr = array();
    $MovieRow = array();
    $kMovie = ($sDisplay['Page']-1)*$sDisplay['PerPage'];
    $cls = 0;
	foreach($MovieIDs as $MovieID)
	{
		$kMovie++;
		$MovieNr[] = $kMovie;

		if(($cls++ % 2)==0)
			$RowName="row1";
		else
			$RowName="row2";

		if($ActiveList['marknew']) {
            if($Data[$MovieID]['DateAdded']!="1900-01-01 00:00:00") {
                $diff = time()-strtotime($Data[$MovieID]['DateAdded']);
                $diff = $diff/60/60/24;
                if($diff<$ActiveList['marknew'])
                    $RowName = "rownew";				
            }
        }
        $MovieRow[] = $RowName;
	}
    
    $smarty->assign("MovieNrs", $MovieNr);
    $smarty->assign("MovieRow", $MovieRow);

    $smarty->assign("Announcments",GetAnnouncments());

}

//UserFavourites (if enabled)
//outside of is_cached - because it is withing a NoCache-block and won't be cached
if($CFG['LinkListType']==PML_LinkListType_Fav || $CFG['LinkListType']==PML_LinkListType_FavText) {
    $strSql = "SELECT l.title, l.name FROM $CFG[Prefix]fav f, $CFG[Prefix]lists l WHERE f.UserID='$ActiveUser[ID]' AND f.ListID=l.ID ORDER BY f.SortOrder";
    $query = pml_mysql_unbuffered_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    $FavLists=array();
    $ActiveListInFav=false;
    while($row=mysql_fetch_assoc($query)) {
        $FavLists[$row['name']]=$row['title'];
        if($row['name']==$ActiveList['name']) $ActiveListInFav=true;
    }    
    $smarty->assign("FavLists", $FavLists);
    $smarty->assign("ActiveListInFav", $ActiveListInFav);
}

$smarty->display($TplFile,$CacheId);

include("bottom.html");


function function_cartIcon($params) {
    if(!isset($params['MovieID'])) return("no MovieID set");
    if(!isset($GLOBALS['cartItems'][$params['MovieID']]))
        return("<a href=\"loan.php$GLOBALS[GlobalArg]&op=add_to_cart&MovieID=$params[MovieID]\" onclick=\"return confirm('$GLOBALS[strRequestItem]')\">
                <CENTER><img src='image/loan/cart.gif' width='13' height='13' border='0' alt='cart' title='request'></a></CENTER>\n");
    
    return("");
}

function function_GetMovieProp($params) {
global $Data, $PropAll;
    extract($params);
    if(!isset($MovieID)) return("no MovieID set");
    if(!isset($PropID)) return("no PropID set");
    if(!isset($Style)) $Style="html";
    switch($Style) {
        case "html":
			return($Data[$MovieID][$PropAll[$PropID]['Name']]);
        case "normal":
			return($Data[$MovieID][$PropAll[$PropID]['Name']]);
        case "link_text":
			return($Data[$MovieID][$PropAll[$PropID]['Name']]);
        case "link_url":
			return($Data[$MovieID][$PropAll[$PropID]['Name']."_link"]);
        case "link_size":
			return($Data[$MovieID][$PropAll[$PropID]['Name']."_size"]);
    }
}

?>