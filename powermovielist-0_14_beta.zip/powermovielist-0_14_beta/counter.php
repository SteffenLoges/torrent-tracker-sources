<?php
/** powermovielist counter
 * $Id: counter.php,v 1.6 2005/10/02 09:13:59 niko Exp $
*/

DoCount();

function DoCount() {
	global $Active, $CFG, $pmldb, $ActiveList, $ActiveUser, $Counter;

	if(!$CFG['UseCounter']) return;
    
    if($ActiveList['ID']=="") return;
    
    if(isset($_SERVER['REMOTE_ADDR']))
	    $IP = ip2long($_SERVER['REMOTE_ADDR']);
    else
        $IP = 0; //when calling from console (only debug)

	//alte eintr?e l?chen, bei jedem counter.php aufruf ausfhren:
	$strSql = "DELETE FROM $CFG[Prefix]counter WHERE CountTime < " . (time()- 300);
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);


	//delete all entries with actual ip for the active list
	$strSql = "DELETE FROM $CFG[Prefix]counter WHERE IP='$IP' AND ListID=$ActiveList[ID]";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	if(mysql_affected_rows()==0) {
		//no entries were deleted, so do a counter++
		$ActiveList['counter']++;
		$strSql = "UPDATE $CFG[Prefix]lists SET counter='$ActiveList[counter]' WHERE ID=$ActiveList[ID]";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}
	$Counter['Total'] = $ActiveList['counter'];

	//new entry in pml_counter
	$strSql = "INSERT INTO $CFG[Prefix]counter (ListID, IP, UserID, CountTime) VALUES ('$ActiveList[ID]', '$IP', '$ActiveUser[ID]', '".time()."')";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

	if($Active!="index") {
		//prfen ob neuer rekord bei maximum online:
		$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]counter WHERE ListID=$ActiveList[ID]";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_row($result);
		$Counter['Online'] = $row[0];
		if($row>$ActiveList['maxonline']) {		
			$ActiveList['maxonline']=$row[0];
			$strSql = "UPDATE $CFG[Prefix]lists SET maxonline='$ActiveList[maxonline]' WHERE ID=$ActiveList[ID]";
			$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		}
		$Counter['MaxOnline'] = $ActiveList['maxonline'];
	}

	//prfen ob neuer rekord bei maximum online fr index-page:
	$strSql = "SELECT maxonline FROM $CFG[Prefix]lists WHERE name='index'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$Counter['MaxOnlineAll'] = $row[0];
	$strSql = "SELECT * FROM $CFG[Prefix]counter GROUP BY IP";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_num_rows($result);
	$Counter['OnlineAll'] = $row;
	if($row>$Counter['MaxOnlineAll']) {
		$Counter['MaxOnlineAll']=$row;
		$strSql = "UPDATE $CFG[Prefix]lists SET maxonline='$Counter[MaxOnlineAll]' WHERE name='index'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}
	if($Active=="index") $Counter['MaxOnline'] = $Counter['MaxOnlineAll'];
	if($Active=="index") $Counter['Online'] = $Counter['OnlineAll'];
}


function GetOnlineUsers() {
global $CFG, $pmldb,$ActiveList;

    if(!$CFG['UseCounter']) return(array());

    $UserData = $GLOBALS['usr']->GetUserList();

    //guest-id
    foreach($UserData as $Dat) {
        if($Dat['name']=="Guest") {
            $GuestID = $Dat['ID'];
            break;
        }
    }

	//how often the guest?
	$strSql = "SELECT * FROM $CFG[Prefix]counter
	WHERE $CFG[Prefix]counter.UserID = $GuestID
	GROUP BY $CFG[Prefix]counter.IP";
	if($ActiveList['name']!="index") {
		$strSql .= " AND $CFG[Prefix]counter.ListID=$ActiveList[ID]";
	}
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_num_rows($result);
	$ret[] = array("name"=>"Guest","ID"=>0,"Count"=>$row);

	//all other users
	$strSql = "SELECT $CFG[Prefix]counter.UserID
	FROM $CFG[Prefix]counter
	WHERE $CFG[Prefix]counter.UserID!='$GuestID'";
	if($ActiveList['name']!="index") {
		$strSql .= " AND $CFG[Prefix]counter.ListID=$ActiveList[ID]";
	}
	$strSql .= " GROUP BY $CFG[Prefix]counter.UserID";

	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	while ($row = mysql_fetch_assoc($result)) {
		$ret[] = array("name"=>$UserData[$row['UserID']]['name'], "ID"=>$row['UserID']);
    }


	return($ret);
}

?>