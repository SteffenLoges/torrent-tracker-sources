<?php
/** powermovielist export
 * $Id: export.php,v 1.10 2005/11/03 18:49:33 niko Exp $
*/
$FILE_SELF = "export.php";
include_once("application.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";


switch($action) {
	case "":
	case "export":
	case "export1":
		$DOC_TITLE = "Export";
		include("top.html");
		LoadPropAll();
?>


<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>
  <tr class='top'>
    <td colspan='2'><h1>CSV-Export</h1></td>
  </tr>
  <tr class='row1'>
    <td colspan='2'>You can export all entries of your list as CSV-File. You can open CSV-Files with almost any application.</td>
  </tr>
</table>
<br>
<FORM METHOD=POST  ACTION='export.php<?php echo $GlobalArg; ?>action=export2'>
<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>
  <tr class='top'>
    <td colspan='2'>properties to export:</td>
  </tr>
<?php
	$cls=1;
	foreach($PropAll as $Prop) {
        if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
        if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
		if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_DisplayNr) continue;
		echo "  <tr class='";
		if($cls++%2) echo "row1"; else echo "row2";
		echo "'>\n";
		echo "    <td align='right'>$Prop[Name]</td>\n";
		echo "    <td>\n";
		echo "	  <input type='checkbox' name='fld[$Prop[ID]]' checked>\n";
		echo "	</td>\n";
		echo "  </tr>\n";
	}
?>
  <tr class='top'>
    <td colspan='2'>export-options:</td>
  </tr>
  <tr class='row1'>
    <td align='right'><b>column-separator:</b><br>should be ',' or ';'</td>
    <td>
	  <INPUT TYPE='text' name='delemiter' value=',' size='1'>
	</td>
  </tr>
  <tr class='row2'>
    <td align='right'><b>include Field-Names</b><br>writes in the first row the field names</td>
    <td>
	  <input type='checkbox' name='fieldnames' checked>
	</td>
  </tr>
  <tr class='row1'>
    <td align='right'><b>use export-file as a PML import-file later on:</b><br>when selected, dates will be formatted yyyy-mm-dd</td>
    <td>
	  <INPUT TYPE='checkbox' name='useforpmlimport'>
	</td>
  </tr>
  <tr class='row2'>
    <td>&nbsp;</td>
	<td><INPUT TYPE='submit' value='export'></td>
  </tr>
</table>
</form>
	<?php
		break;
	case "export2":
		$delem = $_POST['delemiter'];
		$useforpmlimport = isset($_POST['useforpmlimport']);
		
		LoadPropAll();

		$ret = ReadMovieDataFromDb("export", array(), "export");
		$Data = $ret['Data'];
		unset($ret);


		$ex = "";

		//export field-names (if activated)
		if(isset($_POST['fieldnames'])) {
			$i=0;
			foreach($PropAll as $kProp=>$Prop) {
                if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
                if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
				if($kProp==0) continue;
				$i++;
				if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_DisplayNr) continue;
				if(!isset($_POST['fld'][$Prop['ID']])) continue;
				if($i>2) $ex .= $delem;
				$ex .= $Prop['Name'];
			}
			$ex .= "\n"; //new line
		}
		
		if ($useforpmlimport) {
			// When using csv-files for PML import later on, dates should be exported using format %Y-%m-$d
			$GLOBALS['strDateFormat'] = '%Y-%m-%d';
			$GLOBALS['strDateFormatMySql'] = '%Y-%m-%d';
		}

		foreach($Data as $Movie) {
			$MovieID = $Movie['MovieID'];
			$i=0;
			foreach($PropAll as $kProp=>$Prop) {
                if($GLOBALS['ActiveUserRights'] < $Prop['RequiredRights']) continue;
                if($Prop['RequiredRights']==-1 && $GLOBALS['ActiveUser']['name'] == "Guest") continue;
				if($kProp==0) continue;
				if($Prop['PropType']==PML_PropType_StaticText || $Prop['PropType']==PML_PropType_DisplayNr) continue;
				if(!isset($_POST['fld'][$Prop['ID']])) continue;
				$i++;
				if($i>1) $ex .= $delem;				
				$Text = $Data[$MovieID][$Prop['Name']];
                if(is_array($Text)) {
                    $Text = implode($Text, PML_PropertyDelem);
                }
				$Text = str_replace('"', '""', $Text);
				$Text = str_replace("\n", "<br>", $Text);
				$Text = str_replace("\r", "", $Text);
				if (strpos($Text, $delem) !== FALSE) {
					$Text = '"' . $Text . '"';
				}

				$ex .= $Text;
			}
			$ex .= "\n"; //new line
		}

        //send the file
        $Dat = "export-$ActiveList[name].csv";		
        SendDownloadFile($ex, $Dat, false);
		exit();
		break;
} //end swtich	

include("bottom.html");
?>