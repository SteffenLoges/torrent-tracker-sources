<?php
/** powermovielist fetchall
 * $Id: fetchall.php,v 1.2 2005/12/13 19:32:05 niko Exp $
*/
$FILE_SELF = "fetchall.php";
$LoadSmarty=true;
include_once("application.php");
include_once("fetch/fetch.php");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_ListAdmin);

$DOC_TITLE = "Fetch All";
include("top.html");

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

switch($action) {
	case "":
?>
<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>
  <tr class='top'>
    <td colspan='2'><h1>fetch/update all entries</h1></td>
  </tr>
  <tr class='row1'>
    <td colspan='2'>You can update all entries in your list using this script.
	<ul>
	<li>You need a field where the unique-id of the entry is saved. (e.g. for imdb-fetch-scripts you need an imdbid-field)</li>
	<li>You can only fetch entries where the id-field is set (no search-function is avaliable!)</li>
	<li>If you use multiple fetch-scripts you need for every fetch-script an id-field. (or you can skip those who don't have an id-field)</li>
	</ul>
	<b>Attention: all values where a fetch-script is used will be overwritten!</b>
	</td>
  </tr>
</table>
<br>

<FORM METHOD=POST  ENCTYPE='multipart/form-data' ACTION='fetchall.php<?php echo $GlobalArg; ?>action=fetch'>
<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>
  <tr class='top'>
    <td colspan='3'>Step 1: Select fetch-scripts and fields</td>
  </tr>
  <tr class='top'>
    <td align='right' width='150'>Fetch-Script</td>
    <td align='left' width='200'>id-field</td>
    <td align='left'>fields to update</td>
  </tr>
  <?
	LoadPropAll();
	LoadPropFetchScripts();
	$allFetchPages = array();
	foreach($PropAll as $Prop) {
		foreach($Prop['FetchScripts'] as $FetchScript) {
			$Dat = explode("-", $FetchScript['FetchScript']);
			$Page = $Dat[0];
			$Field = $Dat[1];
			$allFetchPages[$Page][] = $Prop['ID'];
		}
	}
	$cls = 1;
	foreach($allFetchPages as $Page=>$PropIDs) {
		echo "<tr class=\"";
		if($cls++%2) echo "row1"; else echo "row2";
		echo "\">\n";
		echo "  <td align=\"right\" valign=\"top\">$Page</td>\n";
		echo "  <td valign=\"top\">";
		echo "<select name=\"page[$Page]\">\n";
		echo "  <option value=\"\">Don't use this script</option>\n";
		foreach($PropAll as $Prop) {
			echo "  <option value=\"$Prop[ID]\"";
			if(strtolower($Prop['Name'])==$Page.'id') echo " selected";
			echo ">$Prop[Name]</option>\n";
		}
		echo "</select>\n";
		echo "</td>\n";
		echo "  <td>";
		$out = "";
		foreach($PropIDs as $PropID) {
			$out .= "<input type=\"checkbox\" name=\"field[$Page][$PropID]\">".$PropAll[$PropID]['Name']."<br>";
		}
		echo substr($out, 0, -4);
		echo "</td>\n";
		echo "</tr>\n";
	}
  ?>
  <tr class='<?if($cls++%2) echo "row1"; else echo "row2";?>'>
    <td>&nbsp;</td>
	<td colspan="2"><INPUT TYPE='submit' value='start Fetching'></td>
  </tr>
  <tr class='<?if($cls++%2) echo "row1"; else echo "row2";?>'>
    <td>&nbsp;</td>
	<td colspan="2">Note: depending on your internet-connection and on the number of entries in your list this may take a long time.</td>
  </tr>
</table>
</form>

	<?php
		break;
	case "fetch":
		LoadPropAll();
		LoadPropFetchScripts();

		$Pages = array();
		if(isset($HTTP_POST_VARS['page']) && is_array($HTTP_POST_VARS['page'])) {
			foreach($HTTP_POST_VARS['page'] as $Page=>$PropID) {
				if($PropID!="") {
					$Pages[$Page]['IDPropID'] = $PropID;
					$Pages[$Page]['Page'] = $Page;
				}
			}
		} else if(isset($HTTP_GET_VARS['Pages']) && is_array($HTTP_GET_VARS['Pages'])) {
			foreach($HTTP_GET_VARS['Pages'] as $Page=>$PropID) {
				if($PropID!="") {
					$Pages[$Page]['IDPropID'] = $PropID;
					$Pages[$Page]['Page'] = $Page;
				}
			}
		}
		if(!sizeof($Pages)) {
			ErrorExit("No Fetch-Scripts selected");
		}

		foreach($Pages as $kPage=>$Page)
		{
			if(isset($HTTP_POST_VARS['field'][$kPage]) && is_array($HTTP_POST_VARS['field'][$kPage])) {
				$Pages[$kPage]['PropIDs'] = array_keys($HTTP_POST_VARS['field'][$kPage]);
			} else if(isset($HTTP_GET_VARS['PropIDs'][$kPage])) {
				$Pages[$kPage]['PropIDs'] = explode(";", $HTTP_GET_VARS['PropIDs'][$kPage]);
			} else {
				$Pages[$kPage]['PropIDs'] = array();
			}
			if(!sizeof($Pages[$kPage]['PropIDs'])) {
				ErrorExit("No Fields selected for $Page");
			}
			foreach($Pages[$kPage]['PropIDs'] as $id) {
				if(!isset($PropAll[$id])) {
					ErrorExit("Invalid PropID: $id");
				}
			}
			if(in_array($Page['IDPropID'], $Pages[$kPage]['PropIDs'])) {
				ErrorExit("Can't fetch field ".$PropAll[$Page['IDPropID']]['Name']." as it will be used as id");
			}
		}
		$nextUrl = "fetchall.php{$GlobalArg}action=fetch";
		foreach($Pages as $Page) {
			$nextUrl .= "&Pages[{$Page['Page']}]={$Page['IDPropID']}";
			$nextUrl .= "&PropIDs[{$Page['Page']}]=".implode(";",$Page['PropIDs']);
		}

		if(isset($_GET['ID'])) {
			$ID = $_GET['ID'];
		} else {
			$ID = "0";
		}
		$strSql = "SELECT MovieID FROM $CFG[Prefix]movies_$Active WHERE MovieID >= '$ID' AND MovieID!=0 ORDER BY MovieID LIMIT 2";
		$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		if(!$row = mysql_fetch_row($q)) {
			ErrorExit("Can't find MovieID $ID");
		} else {
			$ID = $row[0];
		}
		
		if(!$row = mysql_fetch_row($q)) {
			//this is the last entry!
			$nextUrl = "";
		} else {
			$nextUrl .= "&ID=$row[0]";
		}

		foreach($Pages as $kPage=>$Page) {
			$Dat = ReadMovieDataFromDb("prop", array("MovieID"=>$ID, "PropID"=>$Page['IDPropID']), "short");
			$Pages[$kPage]['fetchid'] = $Dat['Data'][$ID][$PropAll[$Page['IDPropID']]['Name']];
		}

		$strSql = "SELECT COUNT(MovieID) FROM $CFG[Prefix]movies_$Active WHERE MovieID!=0";
		$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_row($q);
		$countAll = $row[0];
		$strSql = "SELECT COUNT(MovieID) FROM $CFG[Prefix]movies_$Active WHERE MovieID!=0 AND MovieID <= '$ID'";
		$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_row($q);
		$countCurrent = $row[0];



		?>
<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%' align='center'>
  <tr class='top'>
    <td><h1>fetch/update all entries</h1></td>
  </tr>
  <tr class='row1'>
    <td>Updateing <?=$countCurrent?>/<?=$countAll?></td>
  </tr>
<?
		$cls = 0;
		foreach($PropAll as $Prop)
		{
			$fsCount = 0;
			foreach($Prop['FetchScripts'] as $fsKey => $fsItem)
			{
				$fsCount++;

				$FetchScript = $fsItem['FetchScript'];
				if($FetchScript=="") continue;

				$Dat = explode("-", $FetchScript);
				$Page = $Dat[0];
				$Field = $Dat[1];
				$ClassName = "pmlfetch_$Page";

				if(!isset($Pages[$Page])) continue; //this fetch-script was not selected
				if(!in_array($Prop['ID'], $Pages[$Page]['PropIDs'])) continue; //this field was not selected for this fetch-script

				if(!FileExists("fetch/fetch-$Page.php")) {
					echo "<b>$GLOBALS[strErrError]:</b> $strFetchScript (fetch/fetch-$Page.php) $strNotFound<br>";
					continue;
				}
				include_once("fetch/fetch-$Page.php");

				if(!class_exists("pmlfetch_".$Page)) {
					echo "<b>$GLOBALS[strErrError]:</b> class pmlfetch_$Page $strNotDefinedIn fetch/fetch-$Page.php<br>";
					continue;
				}
				
				$fsClass = new $ClassName;

				echo "<tr class='row".(($cls++%2)+1)."'><td>";
				echo "[$Page]: $Field ... ";
				flush();

				if($Pages[$Page]['fetchid']=="") {
					//fixme nicer message, this can happen quite often!
					echo $PropAll[$Pages[$Page]['IDPropID']]['Name']." is empty for this entry!";
					continue;
				}
				$fsClass->setFetchID($Pages[$Page]['fetchid']);

				//check if setting is uses
				if($fsClass->getUseSettings($Field)) {
					$fsClass->setSettings($Field, $fsItem['Settings']); //set the setting...
				}

				$FetchVal="";
				$FetchResult = $fsClass->DoFetch($FetchVal, $Field);
				
				if($FetchResult==PML_FETCH_OK) {
					echo "<font color=green>OK</font>";
				} elseif($FetchResult==PML_FETCH_ITEMNOTFOUND) {
					echo "<font color=red>Error, fetch-item doesn't exist</font>";
					continue;//nothing found, continue with next FetchScript for this property (if any)
				} else {
					echo "<font color=red>nothing found</font>";
					continue;//nothing found, continue with next FetchScript for this property (if any)
				}
				flush();
				
				if($FetchVal=="") { //nothing was fetched, continue
					continue; //continue with next fetch-script for this property
				}							

				switch($Prop['PropType']) {
					case PML_PropType_Text: //Text
					case PML_PropType_Date: //Date				
					case PML_PropType_Textfield: //Textfield
					case PML_PropType_Url: //Url
					case PML_PropType_UrlCached: //cached Url
					case PML_PropType_FileUpload: //File-Upload					
					case PML_PropType_AutoIncrement:                
						if(is_array($FetchVal)) $FetchVal = implode(", ", $FetchVal);

						if($Prop['PropType']==PML_PropType_UrlCached || $Prop['PropType']==PML_PropType_FileUpload) { //cached Url, File Upload
							//get the filename for the cache                        
							if(isset($fsClass->OverrideFileName)) {
								//when OverrideFileName is set, this must be used for the file-name!
								$Dat=$fsClass->OverrideFileName;
							} else {
								//else get it from the FetchVal                                
								$Dat = GetFileName($FetchVal, true); //get the file-name of the URL and be verbose
							}
							//check if Dat has a valid extension:
							$Ext = substr($Dat, strrpos($Dat, "."));
							if(!in_array(strtolower($Ext), explode(";", $GLOBALS['CFG']['UploadExt']))) {
								echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidExtension] (" . $Dat . ")<br>\n";
								break;
							}
							//and create the file-name
							if ($Prop['PropType']==PML_PropType_UrlCached)
								$FileName = $CFG['CacheDir'] . $ID."-".$Prop['ID']."-".$Dat;
							else
								$FileName = $CFG['UploadDir'] . $ID."-".$Prop['ID']."-".$Dat;

							//download the url
							if(!DownloadFile($FetchVal, $FileName)) {
								//if download fails print error and set FetchVal to ""
								echo " <b>$GLOBALS[strErrError]:</b> $strCantDownloadUrl (" . $FetchVal . ")<br>\n";
								//$FetchVal = ""; //dont't set to "" if errors happen try to download again later...
							} else {
								resizeImage($FileName, $Prop['ImageSize']);
							}

							if($FetchVal!="" && $Prop['PropType']==PML_PropType_FileUpload) {
								//for file-uploads only the filename is saved, not the complete url
								$FetchVal = $Dat;
							}

							if($FetchVal!="" && isset($fsClass->OverrideFileName) && $Prop['PropType']==PML_PropType_UrlCached) {
								//only when OverrideFileName is set:
								//for cached urls the local-filename has to be saved additional to the complete url
								//...else the local-filename can be generated from the Url itself using the GetFileName function...
								$FetchVal = $FetchVal.PML_PropertyDelem.$Dat;
							}
						}

						$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$FetchVal."' WHERE MovieID='$ID'";
						pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

						break;
					case PML_PropType_ListBox: //ListBox
					case PML_PropType_ListBoxMulti: //ListBoxMulti	
					case PML_PropType_Boolean: //Boolean
						if(!is_array($FetchVal)) $FetchVal = array($FetchVal);

						$strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=" . $Prop['ID'];
						$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
						$PropVals = array();
						while($r = mysql_fetch_array($q, MYSQL_ASSOC)) {
							$PropVals[] = $r;
						}
						
						$PropValIDs = array();
						foreach($PropVals as $PropVal) {
							$k = array_search($PropVal['FetchText'], $FetchVal);
							if(is_int($k)) {								
								$PropValIDs[] = $PropVal['ID'];
								unset($FetchVal[$k]);
							}
						}

						if($Prop['PropType']==PML_PropType_ListBoxMulti) {
							$save = "_".implode("_", $PropValIDs)."_";
							$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$save."' WHERE MovieID='$ID'";
							pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
						} else {
							$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$PropValIDs[0]."' WHERE MovieID='$ID'";
							pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
						}


						if(count($FetchVal)) {
							echo "<b>$GLOBALS[strErrError]:</b> $strNotAllFetchedValuesExistInTheDatabase (" . implode(", ", $FetchVal) . ")<br>";
						}

						break;
				} //end swtich $Prop['PropType']
				echo "</td></tr>";

				flush();
				break; //entry saved, break and continue with next Property (skip other fsKeys for this prop)
			} //end foreach $Prop[FetchScripts]
		} //end foreach $PropAll
		
		echo "<tr>";
		echo "<td class=\"top\">";
		if($nextUrl=="") {
			echo "<b>finished!!</b>";
		} else {
			echo "<a href=\"$nextUrl\">next entry</a>\n";
		}
		echo "</td>";
		echo "</tr>";
		echo "</table>";

		if($nextUrl!="") {
			echo "<meta http-equiv=\"refresh\" content=\"3;URL=$nextUrl\">";
		}

		$smarty->clear_cache(null,"list|$Active");
		$smarty->clear_cache(null,"popup|$ID");

		break;
}//end switch action
include("bottom.html");
?>
