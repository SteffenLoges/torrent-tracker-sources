<?php
/** powermovielist print-functions
 * $Id: print.php,v 1.17 2005/12/13 19:32:05 niko Exp $
*/

function PrintLinkList($Text="",$Size=0, $Style="", $InCfgMenu=false) {
	global $Active, $CFG, $pmldb, $FILE_SELF;
	$strSql = "SELECT * FROM " . $CFG['Prefix'] . "linklist ORDER BY SortOrder";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
	$num = mysql_num_rows($result);
	
	$OutPut = "$Text\n";
	$OutPut .= "<SELECT NAME=\"SetActiveList\" $Style";
	if($Size>0) $OutPut .= "size=\"$Size\" ";
	if($InCfgMenu)
		$OutPut .= "onChange=\"parent.location=this.options[this.selectedIndex].value;\">\n";
	else
		$OutPut .= "onChange=\"window.location=this.options[this.selectedIndex].value;\">\n";
for($i=0;$i<$num;$i++) {
	$OutPut .= "<option value=\"";
	$row = mysql_fetch_assoc($result);
	if($row['Type']=="User") {
		$strSql = "SELECT name FROM " . $CFG['Prefix'] . "lists WHERE ID=$row[ListID]";
		$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
		$row1=mysql_fetch_assoc($result1);
		if($InCfgMenu)
			$OutPut .= "editconfig.php".$GLOBALS['GlobalArgWOActive']."Active=";
		else {
			if($FILE_SELF=="index.php" || $FILE_SELF=="list.php") {
				if($row1['name']=="index")
					$OutPut .= "index.php";
				else
					$OutPut .= "list.php";
			} else
				$OutPut .= $FILE_SELF;
			$OutPut .= $GLOBALS['GlobalArgWOActive']."Active=";
		}
		$OutPut .= $row1['name'];
		$OutPut .= '"';

		if(strtolower($row1['name'])==$Active)
			$OutPut .= " selected";
	} else {
		$OutPut .= $row['Url'];
		$OutPut .= '"';
	}
	$OutPut .= '>' . $row['Text'] . "</option>\n";
}
$OutPut .= "</SELECT>\n";
return($OutPut);
}

/**
* PrintPrettyTable: print a nice formated table for the pml with the right
*                   class-tags to use with the css-files
*
* @param array	Fld			the fileds
*        int	cellpadding	the cellpadding-attribute for the table
*        bool	PrintTable	Print the table-tag or not
*
* @returns nothing...
*/
function PrintPrettyTable($Fld, $cellpadding=1,$PrintTable=true) {
	if($PrintTable) echo "<table width='100%' border='0' cellpadding='$cellpadding' cellspacing='1' class='tblback'>\n";
	if($PrintTable) $i=1; else $i=0;
	foreach($Fld as $Line) {
		$i++;
		echo "  <tr class='row" . ($i%2+1) . "'>\n";
		foreach($Line as $Row) {
			echo "    <td>$Row</td>\n";
		}
		echo "  </tr>\n";
	}
	if($PrintTable) echo "</table>\n";
}

/**
* PrintDateInput: prints 3 fields to input a date
*
* @param string	FieldName		The fields will be named $FileNameMon $FieldNameDay and $FieldNameYear
*        string	Sel				selected date in format yyyy-mm-dd - if invalid or empty nothing will be selected
*		 bool	ShowNames		if set, a caption for the fields will be printed
*        string	Title			if set, a title on top of the table
*
* @returns nothing...
*/
function PrintDateInput($FieldName, $Sel="", $ShowNames=true, $Title="") {

if (ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $Sel, $regs)) {
	$SelYear=(int)$regs[1];
	$SelMon=(int)$regs[2];
	$SelDay=(int)$regs[3];
} else {
	$SelDay=0;
	$SelMon=0;
	$SelYear=0;	
}
if($SelYear==0) $SelYear="";

echo "<table border=0 cellspacing=0 cellpadding=2>\n";
if($Title!="") {
	echo "<tr class='top'><td colspan='3' align='center'>$Title</td></tr>\n";
}
if($ShowNames) {
echo '  <tr>
    <td align="center">Month</td>
    <td align="center">Day</td>
    <td align="center">Year</td>
  </tr>
  ';
}
echo '  <tr>
    <td>
      <select NAME="' . $FieldName . 'Mon">';
echo "        <option value=\"0\"";
if(0==$SelMon) echo " selected";
echo "></option>\n";
foreach($GLOBALS['strMonthNames'] as $Key => $Val) {
	echo "        <option value=\"" . ($Key+1) . "\"";
	if($Key+1==$SelMon) echo " selected";
	echo ">$Val</option>\n";
}
echo '      </select>
    </td>
    <td>
      <select NAME="' . $FieldName . 'Day">
        ';
	    for($k=0;$k<=31;$k++) {
			echo "<option value=\"$k\"";
			if($k==$SelDay) echo " selected";
			echo ">";
			if($k!=0) echo $k;
			echo "</option>";
		}
echo '      </select>
    </td>
    <td><input class="input" TYPE="text" name="' . $FieldName . 'Year" value="' . $SelYear . '" size=4 maxlength=4></td>
  </tr>
  </table>';
}

/**
* PrintEditEntryProp
*
* Prints out the input field for a Propertie, when action=edit with the value
* of $MovieID, else with the default-value
*
* @param array pml_prop-entry that should be displayed (2-dimensional-array!)
* @param int the movie-id that should be displayed (when action=edit)
*/
function PrintEditEntryProp($Prop, $MovieID) {
global $CFG, $pmldb,$cls,$ActiveList;
	switch($Prop['PropType']) {
		case PML_PropType_Text: //Text
			$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];

			echo "<input type='text' name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . " value=\"";
			echo htmlspecialchars($Sel);
			echo "\">\n";
			break;
        case PML_PropType_AutoIncrement:
            if($MovieID>0) {
				$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
				$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$r = mysql_fetch_row($q);
				$Sel = $r[0];
            } else {  //default-value = auto-incremented value
				$Sel = GetStandardValue($Prop);
            }
			echo "<input type='text' name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . " value=\"";
			echo htmlspecialchars($Sel);
			echo "\">\n";
			break;
		case PML_PropType_Date: //Date
			$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];
			PrintDateInput("in" . $Prop['ID'], $Sel);
			break;
		case PML_PropType_Boolean: //Boolean
			$strSql = "SELECT pv.Value FROM $CFG[Prefix]movies_$ActiveList[name] m, $CFG[Prefix]propval pv WHERE m.`$Prop[Name]`=pv.ID AND m.MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];
			echo "<input type='checkbox' NAME='in" . $Prop['ID'] . "' value='1'";
			if($Sel) echo " checked";
			echo ">";
			break;
		case PML_PropType_ListBox: //ListBox
		case PML_PropType_ListBoxMulti: //ListBoxMulti
			$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];
			if($Prop['PropType']==PML_PropType_ListBoxMulti) {
				if(substr($Sel, 0, 1)=="_") $Sel = substr($Sel, 1);
				if(substr($Sel, -1)=="_") $Sel = substr($Sel, 0, -1);
				$Sel = explode("_", $Sel);
			} else {
				$Sel = array($Sel);
			}

			$strSql = "SELECT ID,DisplayText FROM $CFG[Prefix]propval WHERE PropID=" . $Prop['ID'] . " ORDER BY $CFG[Prefix]propval.SortOrder";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);									
			$Itm = array();
			while ($r = mysql_fetch_array($q, MYSQL_ASSOC)) {
				$Itm[] = $r;
			}

			if($Prop['PropType']==PML_PropType_ListBox) echo "<select name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . ">\n";
			if($Prop['PropType']==PML_PropType_ListBoxMulti) echo "<select name='in" . $Prop['ID'] . "[]' " . $Prop['InProp'] . " multiple>\n";
			
			foreach($Itm as $Dat) {
				echo "  <option value='" . $Dat['ID'] . "'";				
				if(in_array($Dat['ID'], $Sel))
					echo " selected";
				echo ">" . $Dat['DisplayText'] . "</option>\n";
			}
			echo "</select>\n";
			break;
		case PML_PropType_Textfield: //Textfield
			$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];
			echo "<textarea name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . " rows=8 cols=50>\n";
			echo htmlspecialchars($Sel);				
			echo "\n</textarea>\n";
			break;
		case PML_PropType_Url: //Url
		case PML_PropType_UrlCached: //cached Url
			$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];
			echo "<input type='text' name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . " value=\"";			
			echo htmlspecialchars($Sel);
			echo "\">\n";
			break;
		case PML_PropType_FileUpload: //File-Upload
			$strSql = "SELECT `$Prop[Name]` FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_row($q);
			$Sel = $r[0];
			if($Sel!="") { //check if the file exists:
				$Dat = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$Sel;
				if(!@FileExists($Dat)) $Sel = "";
			}
			echo "\n<table cellpadding='2' cellspacing='0'>\n";
			if($Sel!="") {
				$Dat = $CFG['UploadDirHttp'] . $MovieID."-".$Prop['ID']."-".$Sel;
				echo "  <tr>\n    <td valign='middle' nowrap>$GLOBALS[strCurrentlyUsedFile]: <a href='$Dat' target='_blank'>" . $Sel . "</a></td>\n";
				echo "    <td nowrap><input type='checkbox' name='inDel" . $Prop['ID'] . "'></td>\n";
				echo "    <td valign='middle' nowrap>$GLOBALS[strDelete]</td><td width=100%>&nbsp;</td>\n  </tr>\n";			
			}
			echo "  <tr>\n    <td colspan='4'>\n      <input type='hidden' name='MAX_FILE_SIZE' value='". $CFG['MaxUploadSize']. "'>\n";
			echo "      <input type='file' name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . ">\n    </td>\n  </tr>\n";
			echo "</table>\n";
			break;
		case PML_PropType_DownloadLink: //Download-Link
			$strSql = "SELECT `$Prop[Name]_text` AS Text, `$Prop[Name]_size` AS Size, `$Prop[Name]_link` AS Link FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$Sel = mysql_fetch_assoc($q);			
			echo "      <input type='text' name='in" . $Prop['ID'] . "' size='90' value=\"";
			echo htmlspecialchars($Sel['Link']);
			echo "\" onChange=\"Link_Change(" . $Prop['ID'] . ")\">\n";
			echo "    </td>\n";
			echo "  </tr>\n";
			echo "  <tr class='row";
			if($cls%2) echo "2"; else echo "1";
			echo "'><td>&nbsp;</td>\n";
			echo "    <td>\n";
			echo "      <font size=-3>$GLOBALS[strLinkText]: </font><input type='text' name='inText" . $Prop['ID'] . "' size='30' value=\"";
			echo htmlspecialchars($Sel['Text']);
			echo "\">\n";
			echo "      <font size=-3>$GLOBALS[strLinkSize]: </font><input type='text' name='inSize" . $Prop['ID'] . "' size='10' value=\"";
			echo htmlspecialchars($Sel['Size']);
			echo "\"><font size=-3> MB</font>\n";
			break;
		case PML_PropType_DownloadLinkFileUpload:
			$strSql = "SELECT `$Prop[Name]_text` AS Text, `$Prop[Name]_size` AS Size, `$Prop[Name]_link` AS Link FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$Sel = mysql_fetch_assoc($q);			
            if($Sel['Link']!="") { //check if the file eixsts:
				$Dat = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$Sel['Link'];
				if(!@FileExists($Dat)) { //wenn datei nicht existiert eintrag l?chen!
                    $Sel['Link'] = "";
					$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]_link`='' WHERE MovieID='$MovieID'";
                    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
            }
			echo "\n<table cellpadding='2' cellspacing='0'>\n";
			if($Sel['Link']!="") {
				$Dat = $CFG['UploadDirHttp'] . $MovieID."-".$Prop['ID']."-".$Sel['Link'];
				echo "  <tr>\n    <td valign='middle' nowrap>$GLOBALS[strCurrentlyUsedFile]: <a href='$Dat' target='_blank'>" . $Sel['Link'] . "</a></td>\n";
				echo "    <td nowrap><input type='checkbox' name='inDel" . $Prop['ID'] . "'></td>\n";
				echo "    <td valign='middle' nowrap>$GLOBALS[strDelete]</td><td width=100%>&nbsp;</td>\n  </tr>\n";			
			}
			echo "  <tr>\n    <td colspan='4'>\n      <input type='hidden' name='MAX_FILE_SIZE' value='". $CFG['MaxUploadSize']. "'>\n";
			echo "      <input type='file' name='in" . $Prop['ID'] . "' " . $Prop['InProp'] . ">\n    </td>\n  </tr>\n";
			
			echo "  <tr>\n";
			echo "    <td colspan='4'>\n";
			echo "      <font size=-3>$GLOBALS[strLinkText]: </font><input type='text' name='inText" . $Prop['ID'] . "' size='30' value=\"";
			echo htmlspecialchars($Sel['Text']);
			echo "\">\n";
			echo "      <font size=-3>$GLOBALS[strLinkSize]: </font><input type='text' name='inSize" . $Prop['ID'] . "' size='10' value=\"";
			echo htmlspecialchars($Sel['Size']);
			echo "\"><font size=-3> MB</font>\n";
            echo "    </td>\n";
            echo "  </tr>\n";
			echo "</table>\n";
			break;
		default:
			echo "invalid PropType";
			break;	
	} //end switch PropType
}

/**
* SaveEditEntryProp
* 
* Saves the POST-values for a entry with MovieID into the DB
*
* @param array pml_prop-entry that should be saved
* @param int the movie-id that should be saved
*/
function SaveEditEntryProp($Prop, $MovieID) {
global $CFG, $pmldb, $ActiveList;
	switch($Prop['PropType']) {        
		case PML_PropType_DownloadLink:
			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]_text`='".$_POST['inText'.$Prop['ID']]."', 
			                                                          `$Prop[Name]_size`='".$_POST['inSize'.$Prop['ID']]."', 
																      `$Prop[Name]_link`='".$_POST['in'.$Prop['ID']]."' WHERE MovieID='$MovieID'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            break;
        case PML_PropType_DownloadLinkFileUpload:
            //first get the OLD link
            $strSql = "SELECT `$Prop[Name]_link` AS Link FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
            $q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$r = mysql_fetch_assoc($q);
			$OldLink = $r['Link'];
            
			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]_text`='".$_POST['inText'.$Prop['ID']]."', 
			                                                           `$Prop[Name]_size`='".$_POST['inSize'.$Prop['ID']]."' WHERE MovieID='$MovieID'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			
			if(isset($_POST['inDel'.$Prop['ID']]) && $OldLink!="") { //delete checkbox aktivated, delete the entry...                
                $Dat = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$OldLink;
                @unlink($Dat); //delete file and ignore any errors

				$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]_link`='' WHERE MovieID='$MovieID'";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				
				break; //break, everything is saved allready
            }//end del-checkbox is set

            if($_FILES['in'.$Prop['ID']]['tmp_name']=="")//no file selected
                break;

            if(sizeof($_FILES['in'.$Prop['ID']]['tmp_name'])>$CFG['MaxUploadSize']) {
                echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strTheUploadFileIsTooBig]<br>\n";
                break;
            }

            if(!is_uploaded_file($_FILES['in'.$Prop['ID']]['tmp_name'])) {
                echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidUpload]!<br>\n";
                break;
            }
            
            $Ext = substr($_FILES['in'.$Prop['ID']]['name'], strrpos($_FILES['in'.$Prop['ID']]['name'], "."));
            if(!in_array(strtolower($Ext), explode(";", $GLOBALS['CFG']['UploadExt']))) {
                echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidExtension] (" . $_FILES['in'.$Prop['ID']]['name'] . ")<br>\n";
                break;
            }
            
            $_FILES['in'.$Prop['ID']]['name'] = preg_replace("([^a-zA-Z0-9\\-._\\[\\]]*)","",$_FILES['in'.$Prop['ID']]['name']);
            foreach($GLOBALS['CFG']['RemoveFromFilename'] as $i) {
                $_FILES['in'.$Prop['ID']]['name'] = str_replace($i, '', $_FILES['in'.$Prop['ID']]['name']);
            }
            $_FILES['in'.$Prop['ID']]['name'] = $GLOBALS['CFG']['PrependToFilename'].$_FILES['in'.$Prop['ID']]['name'];
            $FileName = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$_FILES['in'.$Prop['ID']]['name'];
                            
            if(!copy($_FILES['in'.$Prop['ID']]['tmp_name'], $FileName)) {
                echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strCantCopyUploadedFile]!<br>\n";
                break;
			}

            //then delete the old file:
            if($OldLink!="") {
                $Dat = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$OldLink;
                @unlink($Dat); //delete file and ignore any errors
            }

			//new db-structure
			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]_link`='".$_FILES['in'.$Prop['ID']]['name']."' WHERE MovieID='$MovieID'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

            break;
		case PML_PropType_UrlCached: //cached Url
            //the url is saved in the db, and the file is saved local in Cache/$MovieID."-".$Prop['ID']."-".urlfilename
            $_POST['in'.$Prop['ID']] = urldecode($_POST['in'.$Prop['ID']]);

            $Url = $_POST['in'.$Prop['ID']];
            $Dat = GetFileNameDelem($Url,true); //true=be verbose

            if($Dat=="") //error
                $_POST['in'.$Prop['ID']] =  "";				

            //check dat for valid extension
            //(Dat has to be checked, because under this name it will be saved on the disk)
            if($_POST['in'.$Prop['ID']]!="") {
                $Ext = substr($Dat, strrpos($Dat, "."));
                if(!in_array(strtolower($Ext), explode(";", $GLOBALS['CFG']['UploadExt']))) {
                    echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidExtension] (" . $Dat . ")<br>\n";
                    $_POST['in'.$Prop['ID']] = "";
                }
            }

            //download the file
            if($_POST['in'.$Prop['ID']]!="") {
                $FileName = $CFG['CacheDir'] . $MovieID."-".$Prop['ID']."-".$Dat;
                if(!DownloadFile($Url, $FileName)) {
                    echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strCantDownloadUrl] (" . $_POST['in'.$Prop['ID']] . ")<br>\n";
                    $_POST['in'.$Prop['ID']] = "";
                } else {
					resizeImage($FileName, $Prop['ImageSize']);
				}
            }
			


            //then delete the old file:			
            $strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
            $q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if(mysql_num_rows($q)) {
                $r = mysql_fetch_assoc($q);
                $Sel = $r['Property'];
                if($Sel!="" && $Sel!=$_POST['in'.$Prop['ID']]) { //delete the file, only if changed                    
                    $Sel = GetFileNameDelem($Sel);
                    $Dat = $CFG['CacheDir'] . $MovieID."-".$Prop['ID']."-".$Sel;
                    @unlink($Dat); //delete file and ignore any errors
                }
            }

			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$_POST['in'.$Prop['ID']]."' WHERE MovieID='$MovieID'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

            break;
        case PML_PropType_FileUpload:
            if(isset($_POST['inDel'.$Prop['ID']])) { //delete checkbox aktivated, delete the entry...
                $strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
                $q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$r = mysql_fetch_assoc($q);
				$Sel = $r['Property'];
				if($Sel!="") { //delete the file:
					$Dat = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$Sel;
					@unlink($Dat); //delete file and ignore any errors
				}

				$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='' WHERE MovieID='$MovieID'";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

                break; //don't use the upload-file-code... quit the switch
            }

            if($_FILES['in'.$Prop['ID']]['tmp_name']=="") { //no file selected
                break; //don't save, just break;
            }

            if(sizeof($_FILES['in'.$Prop['ID']]['tmp_name'])>$CFG['MaxUploadSize']) {
                echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strTheUploadFileIsTooBig]<br>\n";
                $_POST['in'.$Prop['ID']] = "";					
            } else {
                $_FILES['in'.$Prop['ID']]['name'] = preg_replace("([^a-zA-Z0-9\\-._\\[\\]]*)","",$_FILES['in'.$Prop['ID']]['name']);
                foreach($GLOBALS['CFG']['RemoveFromFilename'] as $i) {
                    $_FILES['in'.$Prop['ID']]['name'] = str_replace($i, '', $_FILES['in'.$Prop['ID']]['name']);
                }
                $_FILES['in'.$Prop['ID']]['name'] = $GLOBALS['CFG']['PrependToFilename'].$_FILES['in'.$Prop['ID']]['name'];
                $_POST['in'.$Prop['ID']] = $_FILES['in'.$Prop['ID']]['name'];
                $FileName = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$_FILES['in'.$Prop['ID']]['name'];

                if (!is_uploaded_file($_FILES['in'.$Prop['ID']]['tmp_name'])) {
                    echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidUpload]!<br>\n";
                    $_POST['in'.$Prop['ID']] = "";
                }

                if($_POST['in'.$Prop['ID']]!="") {
                    $Ext = substr($_POST['in'.$Prop['ID']], strrpos($_POST['in'.$Prop['ID']], "."));
                    if(!in_array(strtolower($Ext), explode(";", $GLOBALS['CFG']['UploadExt']))) {
                        echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strInvalidExtension] (" . $_POST['in'.$Prop['ID']] . ")<br>\n";
                        $_POST['in'.$Prop['ID']] =  "";
                    }
                }

                if($_POST['in'.$Prop['ID']]!="") {
                    if(!copy($_FILES['in'.$Prop['ID']]['tmp_name'], $FileName)) {
                        echo "<b>$GLOBALS[strErrError]:</b> $GLOBALS[strCantCopyUploadedFile]!<br>\n";
                        $_POST['in'.$Prop['ID']] = "";
                    } else {
						resizeImage($FileName, $Prop['ImageSize']);
					}
                }

                @unlink($_FILES['in'.$Prop['ID']]['tmp_name']);					
            }

            //then delete the old file:			
            if($_POST['in'.$Prop['ID']]!="") {                
                $strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='$MovieID'";
                $q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$r = mysql_fetch_assoc($q);
				$Sel = $r['Property'];
				if($Sel!="") { //delete the file, only if changed
					$Dat = $CFG['UploadDir'] . $MovieID."-".$Prop['ID']."-".$Sel;
					@unlink($Dat); //delete file and ignore any errors
				}
            }

			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$_POST['in'.$Prop['ID']]."' WHERE MovieID='$MovieID'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

			break;
        case PML_PropType_Text:
		case PML_PropType_Date:
		case PML_PropType_Textfield:
		case PML_PropType_Url:
        case PML_PropType_AutoIncrement:
			if($Prop['PropType']==PML_PropType_Date) {
                $_POST['in'.$Prop['ID']] = sprintf("%04d-%02d-%02d", $_POST['in'.$Prop['ID'].'Year'], $_POST['in'.$Prop['ID'].'Mon'], $_POST['in'.$Prop['ID'].'Day']);
			}
			if($Prop['PropType']==PML_PropType_Url) {
                $_POST['in'.$Prop['ID']] = urldecode($_POST['in'.$Prop['ID']]);
            }
                        
			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$_POST['in'.$Prop['ID']]."' WHERE MovieID='$MovieID'";
            pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

			break;
		case PML_PropType_ListBox: //ListBox
		case PML_PropType_Boolean: //Boolean
		case PML_PropType_ListBoxMulti: //ListBoxMulti
			if($Prop['PropType']==PML_PropType_ListBox)
			{
				$_POST['in'.$Prop['ID']] = array($_POST['in'.$Prop['ID']]);
			}
			else if($Prop['PropType']==PML_PropType_Boolean)
			{
				if(isset($_POST['in'.$Prop['ID']])) {
					$strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=$Prop[ID] AND Value='1'";
				} else {
					$strSql = "SELECT * FROM $CFG[Prefix]propval WHERE PropID=$Prop[ID] AND Value='0'";
				}				
				$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				if(mysql_num_rows($q)==0) {
					echo "<b>ERROR:</b> invalid propval-entries!<br>\n";
					break;
				}
				$r = mysql_fetch_assoc($q);				
				$_POST['in'.$Prop['ID']] = array($r['ID']);								
			}

			$strSql = "SELECT ID FROM $CFG[Prefix]propval WHERE PropID=" . $Prop['ID'];
			$q = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			$PropVals = array();
			$PropValIDs = array();
			while($r = mysql_fetch_array($q, MYSQL_ASSOC)) {
				$PropValIDs[] = $r['ID'];
			}

			if(!isset($_POST['in'.$Prop['ID']]))
                $_POST['in'.$Prop['ID']] = array();  //empty array
            else
                $_POST['in'.$Prop['ID']] = array_unique($_POST['in'.$Prop['ID']]); //eliminate the doublet ID from the array
			
			foreach($_POST['in'.$Prop['ID']] as $k=>$i) {
				if(!in_array($i, $PropValIDs)) unset($_POST['in'.$Prop['ID']][$k]);
			}

			if($Prop['PropType']==PML_PropType_ListBoxMulti) {
				$save = "_".implode("_", $_POST['in'.$Prop['ID']])."_";
				$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$save."' WHERE MovieID='$MovieID'";
			    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			} else {
				$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$_POST['in'.$Prop['ID']][0]."' WHERE MovieID='$MovieID'";
			    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			}

			break;
	} //end swtich
}

/**
* SaveDefaultValueEditEntryProp
*
* Saves the Default-Value for a Property into the DB.
* Called when ShowAdding=false and action=addsave
*
* @param array pml_prop-entry that should be saved
* @param int the movie-id that should be saved
*/
function SaveDefaultValueEditEntryProp($Prop, $MovieID) {
global $CFG, $pmldb, $ActiveList;
    switch($Prop['PropType']) {
        case PML_PropType_DownloadLink:
			$strSql = "SELECT `$Prop[Name]_text` AS Text, `$Prop[Name]_size` AS Size, `$Prop[Name]_link` AS Link FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='0'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if($Dat = mysql_fetch_assoc($result)) {
				$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]_text`='$Dat[Text]',
				                                                           `$Prop[Name]_size`='$Dat[Size]',
																		   `$Prop[Name]_link`='$Dat[Link] WHERE MovieID='$MovieID'";
			    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            }
            break;
        case PML_PropType_DownloadLinkFileUpload:
            //can't have a Standard-Value, so break
            break;
        case PML_PropType_UrlCached: //cached Url
        case PML_PropType_FileUpload:
            //no default-value saved here.. if field is empty readMoveDataFromDb uses the standard-value
            break;
        case PML_PropType_Text:
        case PML_PropType_Date:
        case PML_PropType_Textfield:
        case PML_PropType_Url:
            $strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='0'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if($Dat = mysql_fetch_assoc($result)) {                        
				$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$Dat['Property']."' WHERE MovieID='$MovieID'";
			    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

            }
            break;
        case PML_PropType_AutoIncrement:
            $strSql = "SELECT MAX(`$Prop[Name]`) AS Property FROM $CFG[Prefix]movies_$ActiveList[name]";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            if($Dat = mysql_fetch_assoc($result)) {
                $Dat = $Dat['Property']+1;
            } else
                $Dat = "1";

			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$Dat."' WHERE MovieID='$MovieID'";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);

            break;
        case PML_PropType_ListBox: //ListBox
        case PML_PropType_Boolean: //Boolean
        case PML_PropType_ListBoxMulti: //ListBoxMulti
            $strSql = "SELECT `$Prop[Name]` AS Property FROM $CFG[Prefix]movies_$ActiveList[name] WHERE MovieID='0'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_assoc($result);
			$Sel = $row['Property'];
			$strSql = "UPDATE $CFG[Prefix]movies_$ActiveList[name] SET `$Prop[Name]`='".$Sel."' WHERE MovieID='$MovieID'";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            break;
    } //end swtich
}



/**
* GetUserMenu: returns the user-menu - all the avaliable options for the current user, list and rights
*
* @param string	 design         the design - should be set in the template
*
* @returns string the menu-html-code
*/
function GetUserMenu($design) {
global $Active,$ActiveUser,$ActiveList,$CFG,$ActiveUserRights,$FILE_SELF;
$MenuItems = array();

	// Login
	if($ActiveUser['name'] == "Guest") {
	  $MenuItems['login'] = array("Url"  => $FILE_SELF.$GLOBALS['GlobalArg']."Login=1",
						   "Text" => $GLOBALS['strLogin']);
	}
	// register for full-mode*}
	if($ActiveUser['name'] == "Guest" && $CFG['ListType'] == 0 && $CFG['ShowRegisterUser']) {
	  $MenuItems['register'] = array("Url"  => $GLOBALS['usr']->GetRegisterUserLink(),
						   "Text" => $GLOBALS['strUsrMenuRegister']);
	}
	// newlist for simple-mode*}
	if($ActiveUser['name'] == "Guest" && $CFG['ListType'] == 1 && $CFG['ShowRegisterList']) {
	  $MenuItems['newlist'] = array("Url"  => $GLOBALS['usr']->GetRegisterUserLink(),
						   "Text" => $GLOBALS['strUsrMenuNewList']);
	}
	// Logout
	if($ActiveUser['name'] != "Guest") {
	  $MenuItems['logout'] = array("Url"  => "logout.php",
						   "Text" => $GLOBALS['strUsrMenuLogout']);
	}
	// edit config
	if($ActiveUser['name'] != "Guest") {
	  $MenuItems['config'] = array("Url"  => "editconfig.php".$GLOBALS['GlobalArg'],
						   "Text" => $GLOBALS['strUsrMenuConfig']);
	}
	// new list
	if($ActiveUser['name'] != "Guest" && $CFG['ShowRegisterList'] && $CFG['ListType']==0) {      
	  $MenuItems['newlist'] = array("Url"  => "editlist.php?action=add",
						   "Text" => $GLOBALS['strUsrMenuNewList']);
	}
	// print list
	if($ActiveList['showprint'] && $Active!="index") {
	  $MenuItems['printlist'] = array("Url"  => "printlist.php".$GLOBALS['GlobalArg'],
						   "Text" => $GLOBALS['strUsrMenuPrintList']);
	}
	// loan center
	if($ActiveUserRights >= PML_Rights_ListAdmin && $Active!="index" && $ActiveList['EnableLoan']) {// 5 = ListAdmin-rights
	  $MenuItems['loancenter'] = array("Url"  => "loan.php".$GLOBALS['GlobalArg']."&op=view_loans",
						   "Text" => $GLOBALS['strLoanControl']);
	}
	// add new movie
	if($ActiveUserRights >= PML_Rights_Add && $Active!="index") {// 2 = add-rights
	  $MenuItems['newentry'] = array("Url"  => "editconfig.php".$GLOBALS['GlobalArg']."ShowPage=" . urlencode("editentry.php".$GLOBALS['GlobalArg']."action=add"),
						   "Text" => $GLOBALS['strUsrMenuAddEntry']);
	}
	// member-list
	if($CFG['ListType'] == 0 && $CFG['ShowRegisterUser']) {
	  $MenuItems['members'] = array("Url"  => $GLOBALS['usr']->GetMemberListLink(),
						   "Text" => $GLOBALS['strUsrMenuMembers']);
	}
 
	$i=0;
	$ret = "";
	foreach($MenuItems as $k=>$Dat) {
		$i++;
		$out = str_replace("_Url",$Dat['Url'],$design);
		$out = str_replace("_Text",$Dat['Text'],$out);
        $out = str_replace("_Item",$k,$out);
		$ret .= str_replace("_row","row".($i%2+1),$out);
	}
    return($ret);
}

function p($Dat) {
    echo "<pre>";
    print_r($Dat);
    echo "</pre>\n";
}

function printSettings($ID, $action) {
	global $ClassName, $Page, $Field, $CFG, $pmldb;
	global $$ClassName, $row;
	if($action=="edit") {
		echo $$ClassName->printSettings($Field, $row['Settings']);
	} elseif($action=="editsave") {
		$Dat = $$ClassName->saveSettings($Field);
		$strSql = "UPDATE $CFG[Prefix]propfetch SET Settings='$Dat' WHERE ID=$ID";
		pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	}
}

function function_NoCache($param, $content, &$smarty) {
    return $content;
}

?>