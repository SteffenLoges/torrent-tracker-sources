<?php
/** powermovielist configuration-menue
 * $Id: cfgmenu.php,v 1.7 2006/02/11 05:45:35 niko Exp $
*/
$FILE_SELF = "cfgmenu.php";
include_once("application.php");
RequestLogin(PML_LoginStyle_NoGuestAllowed);
$DOC_TITLE = "menu";
include("top.html");
echo "<b>";
echo $ActiveList['title'];
echo "</b><br><b>$strConfigurationTitle</b><br><br>\n";
echo "<TABLE border=0 cellpadding=0 cellspacing=0 width=170>\n";
if($CFG['ListType'] < 2) {
	//Bei Single-User-Mode nie die auswahl anzeigen
	cfgPrintActiveList();
}
cfgPrintGotoList();
cfgPrintActiveUser();
cfgPrintUserConfig();
if($CFG['LinkListType'] == PML_LinkListType_Fav || $CFG['LinkListType'] == PML_LinkListType_FavText)
    cfgPrintUserFav();
if($CFG['ListType'] < 2)
	cfgPrintDeleteUser();
echo "<tr><td>&nbsp;</td></tr>\n";
/*
Mode = 1: view-rechte
Mode = 2: add-rechte
Mode = 3: Moderator rechte
Mode = 4: List-Admin rechte
Mode = 5: Super-Admin rechte
*/
if($Active!="index") { //bei index-liste k?nen keine filme hinzugefgt/bearbeitet werden...
	if($ActiveUserRights>=PML_Rights_Add) {
		cfgPrintListModerationHeader();
		cfgPrintListModerationAdd();
		if($ActiveUserRights>=PML_Rights_Moderator) { //moderator-rechte
			cfgPrintListModerationEdit();
		}
		echo "<tr><td>&nbsp;</td></tr>\n";
	}
}
//**************** list-Administration
if($ActiveUserRights>=PML_Rights_ListAdmin) {  //list-admin rechte
    cfgPrintListAdminHeader();
	if( $Active!="index") { //bei index-liste k?nen keine list-administation-einstellungen gemacht werden
		cfgPrintExportImport();
		
		if($CFG['ListType'] < 1)
			cfgPrintDeleteList();

        cfgPrintFlushList();
	}

    if($ActiveList['close']) {
        cfgPrintOpenList();
    } else {
        cfgPrintCloseList();
    }
    if($CFG['ListType']==0)  //user-rights nur bei ListType=0 aktivieren!!
        cfgPrintUserRights();
    echo "<tr><td>&nbsp;</td></tr>\n";

	cfgPrintListConfigHeader();
	cfgPrintListConfigMain();
	if($Active!="index")
		cfgPrintListConfigProp();
    else
        cfgPrintListConfigIndexItems();
	if($Active!="index")
		cfgPrintListConfigPass();
	cfgPrintListConfigDesign();
    cfgPrintListAnnouncment();
	cfgPrintListConfigExportImport();
	echo "<tr><td>&nbsp;</td></tr>\n";
}
if($ActiveUserRights>=PML_Rights_SuperAdmin) {  //super-admin
    cfgPrintSuperAdminHead();
	cfgPrintSuperAdmin();
	if($CFG['ListType'] < 2)
		cfgPrintLinkList();
	echo "<tr><td>&nbsp;</td></tr>";
	if($CFG['ListType'] < 2) {
		cfgPrintSuperAdminEdit();
        cfgPrintSuperAdminEditUser();
		echo "<tr><td>&nbsp;</td></tr>";
	}
}
if($ActiveUser['admin']==2 && $CFG['ListType'] < 2) {  //user-admin
    cfgPrintSuperAdminHead();
    cfgPrintSuperAdminEditUser();
}


echo "</TABLE>\n";
?><p align="left"><font size="1">
<a href="http://www.powermovielist.com" target="_blank">PowerMovieList</a> <?php echo $Version ?><br>
 Copyright &copy; by Nikotto<br>
  </font></p>
</body>
</html><?
function cfgPrintActiveList() {
global $CFG;
echo '<TR>
	<TD bgcolor="#FFFFFF" align="center" height=20 colspan=2><font size=2 color="#314477"><b>'.$GLOBALS['strActiveList'].'</b></font></TD>
</TR>
<TR>
   <TD colspan=2>
';
	echo PrintLinkList("",0,"style='width: 170px;'",true);
	echo "  </TD>
</TR>\n";
}
function cfgPrintGotoList() {
global $GlobalArg;
echo '<TR>
	<td valign=top> </td>
	<TD><a href="'.$GLOBALS['ListUrl'].'" target="_parent">' . $GLOBALS['strGoToTheList'] . '</a></TD>
</TR>
<TR height="20">
  <TD colspan=2>&nbsp;</TD>
</TR>';
}
function cfgPrintActiveUser() {
global $ActiveUser, $GlobalArg;
echo '<TR>
	<TD bgcolor="#FFFFFF" align="center" height=20 colspan=2><font size=2 color="#314477"><b>'.$GLOBALS['strActiveUser'].'</b></font></TD>
</TR>
<tr>
<td colspan=2 align=center>'.$GLOBALS['strLoggedIn'].': ' . $ActiveUser['name'] . '</td>
</tr>
<tr>
<td colspan=2 align=center>'.$GLOBALS['strUserRights'][$GLOBALS['ActiveUserRights']]. '</td>
</tr>
<tr><td valign=top> </td>
<td><a href="logout.php" target="_parent">' . $GLOBALS['strLogout'] . '</a></td></tr>
<tr><td>&nbsp;</td><tr>';
}
function cfgPrintUserConfig() {
global $ActiveUser, $GlobalArg;
echo "<TR>
	<TD bgcolor=\"#FFFFFF\" align=\"center\" height=20 colspan=2><font size=2 color=\"#314477\"><b>$GLOBALS[strUserConfig]</b></font></TD>
</TR>
<TR>
	<td valign=top> </td>
	<TD><a href=\"" . $GLOBALS['usr']->GetEditUserLink($ActiveUser['ID']) . "\" target=\"main\">$GLOBALS[strUserData]</a></TD>
</TR>
";
}
function cfgPrintUserFav() {
global $GlobalArg;
echo "<TR>
	<td valign=top> </td>
	<TD><a href=\"editfav.php".$GlobalArg."\" target=\"main\">$GLOBALS[strfavoriteLists]</a></TD>
</TR>
";
}
function cfgPrintDeleteUser() {
global $ActiveUser, $GlobalArg, $strDeleteAccount;
echo "<TR>
	<td valign=top> </td>
	<TD><a href=\"" . $GLOBALS['usr']->GetDeleteUserLink($ActiveUser['ID']) . "\" target=\"main\">$strDeleteAccount</a></TD>
</TR>\n";
}
function cfgPrintListModerationHeader() {
	echo "<TR>
	<TD bgcolor=\"#FFFFFF\" align=\"center\" height=20 colspan=2><font size=2 color=\"#314477\"><b>$GLOBALS[strListModeration]</b></font></TD>
</TR>\n";
}
function cfgPrintListModerationAdd() {
global $GlobalArg;
echo "<TR>
	<td valign=top> </td>
	<TD><a href=\"editentry.php".$GlobalArg."action=add\" target=\"main\">$GLOBALS[strAddNewMovie]</a></TD>
</TR>\n";
}
function cfgPrintListModerationEdit() {
global $GlobalArg;
echo "<TR>
	<td valign=top> </td>
	<TD><a href=\"$GLOBALS[ListUrl]\" target=\"_parent\">$GLOBALS[strEditDelMovies]</a></TD>
</TR>\n";
}
function cfgPrintListAdminHeader() {
echo '<TR>
	<TD bgcolor="#FFFFFF" align="center" height=20 colspan=2><font size=2 color="#314477"><b>'.$GLOBALS['strListAdministration'].'</b></font></TD>
</TR>
';
}
function cfgPrintExportImport() {
global $GlobalArg;
?><TR>
	<td valign=top> </td>
	<TD><a href="export.php<?php echo $GlobalArg ?>" target="main"><?php echo $GLOBALS['strExportList'] ?></a></TD>
</TR>
<TR>
	<td valign=top> </td>
	<TD><a href="import.php<?php echo $GlobalArg ?>" target="main"><?php echo $GLOBALS['strImportList'] ?></a></TD>
</TR>
<TR>
	<td valign=top> </td>
	<TD><a href="fetchall.php<?php echo $GlobalArg ?>" target="main">fetch/update all Entries</a></TD>
</TR>
<?
}
function cfgPrintDeleteList() {
global $GlobalArg, $ActiveList, $strDeleteList;
?>	<TR>
		<td valign=top> </td>
		<TD><a href="editlist.php<?php echo $GlobalArg; ?>Display=main&action=del&ID=<?php echo $ActiveList['ID'] ?>" target="main"><?php echo $strDeleteList ?></a></TD>
	</TR><?
}
function cfgPrintFlushList() {
global $GlobalArg, $ActiveList, $strDeleteList;
?>	<TR>
		<td valign=top> </td>
		<TD><a href="editlist.php<?php echo $GlobalArg; ?>Display=main&action=flushlist&ID=<?php echo $ActiveList['ID'] ?>" target="main"><?php echo $GLOBALS['strCfgMenuFlushList'] ?></a></TD>
	</TR><?
}
function cfgPrintOpenList() {
global $GlobalArg, $strOpenList;
	echo "<tr><td valign=top> </td>\n";
	echo "<td><a href=\"close.php".$GlobalArg."action=Open\" target=\"main\">$strOpenList</a><br></td></tr>\n";
}
function cfgPrintCloseList() {
global $GlobalArg, $strCloseList;
	echo "<tr><td valign=top> </td>\n";
	echo "<td><a href=\"close.php$GlobalArg\" target=\"main\">$strCloseList</a><br></td></tr>\n";
}
function cfgPrintUserRights() {
global $GlobalArg;
	echo "<TR>
	<td valign=top> </td>
	<TD><a href=\"editrights.php$GlobalArg\" target=\"main\">$GLOBALS[strConfigUserRights]</a></TD>
</TR>\n";
    echo "<TR>
    <td valign=top> </td>
    <TD><a href=\"editgrouprights.php$GlobalArg\" target=\"main\">group-rights</a></TD>
</TR>\n";
}
function cfgPrintListConfigHeader() {
echo '<TR>
	<TD bgcolor="#FFFFFF" align="center" height=20 colspan=2><font size=2 color=\"#314477\"><b>'.$GLOBALS['strListConfiguration'].'</b></font></TD>
</TR>
';
}
function cfgPrintListConfigMain() {
global $ActiveList, $GlobalArg;
?>	
<TR>
	<td valign=top> </td>
	<TD><a href="editlist.php<?php echo $GlobalArg; ?>Display=main&action=edit&ID=<?php echo $ActiveList['ID'] ?>" target="main"><?php echo $GLOBALS['strCfgMenuMain'] ?></a></TD>
</TR><?php
}
function cfgPrintListConfigProp() {
global $ActiveList, $GlobalArg;
?>
<TR>
	<td valign=top> </td>
	<TD><a href="editprop.php<?php echo $GlobalArg; ?>" target="main"><?php echo $GLOBALS['strPropertiesFields']; ?></a></TD>
</TR><?php
}

function cfgPrintListConfigIndexItems() {
global $ActiveList, $GlobalArg;
?>
<TR>
	<td valign=top> </td>
	<TD><a href="editindexitems.php<?php echo $GlobalArg; ?>" target="main"><?php echo $GLOBALS['strIndexItems']; ?></a></TD>
</TR><?php
}

function cfgPrintListConfigPass() {
global $ActiveList, $GlobalArg;
?>
<TR>
	<td valign=top> </td>
	<TD><a href="editlist.php<?php echo $GlobalArg; ?>Display=pass&action=edit&ID=<?php echo $ActiveList['ID'] ?>" target="main"><?php echo $GLOBALS['strPassword']; ?></a></TD>
</TR><?php
}
function cfgPrintListConfigDesign() {
global $ActiveList, $GlobalArg;
?>
<TR>
	<td valign=top> </td>
	<TD><a href="editlist.php<?php echo $GlobalArg; ?>Display=design&action=edit&ID=<?php echo $ActiveList['ID'] ?>" target="main"><?php echo $GLOBALS['strCfgMenuDesign'] ?></a></TD>
</TR><?php
}
function cfgPrintListConfigExportImport() {
global $ActiveList, $GlobalArg;
?>
<TR>
	<td colspan='2'>&nbsp;</td>	
</TR>
<TR>
	<td valign=top> </td>
	<TD><a href="settings.php<?php echo $GlobalArg; ?>action=export" target="main"><?php echo $GLOBALS['strExportSettings']; ?></a></TD>
</TR>
<TR>
	<td valign=top> </td>
	<TD><a href="settings.php<?php echo $GlobalArg; ?>action=import" target="main"><?php echo $GLOBALS['strImportSettings']; ?></a></TD>
</TR>
<?php }

function cfgPrintSuperAdminHead() {
global $GlobalArg;
?><TR>
        <TD bgcolor="#FFFFFF" align="center" height=20 colspan=2><font size=2 color="#314477"><b><?php echo $GLOBALS['strSuperAdminMenu']; ?></b></font></TD>
    </TR>
<?
}

function cfgPrintSuperAdmin() {
global $GlobalArg;
?>
	<TR>
		<td valign=top> </td>
		<TD><a href="install.php<?php echo $GlobalArg; ?>" target="main"><?php echo $GLOBALS['strChangeGlobal'] ?></a></TD>
	</TR>
	<TR>
		<td valign=top> </td>
		<TD><a href="dbfkt.php<?php echo $GlobalArg; ?>" target="main">database-functions</a></TD>
	</TR>	
<?
}
function cfgPrintLinkList() {
global $GlobalArg;
?>
	<TR>
		<td valign=top> </td>
		<TD><a href="linklist.php<?php echo $GlobalArg; ?>" target="main"><?php echo $GLOBALS['strCfgMenuLinkList'] ?></a></TD>
	</TR>
<?
}
function cfgPrintSuperAdminEdit() {
global $GlobalArg, $usr, $CFG;
?>
	<TR>
		<td valign=top> </td>
		<TD><a href="editlist.php<?php echo $GlobalArg; ?>action=add" target="main"><?php echo $GLOBALS['strAddList']; ?></a></TD>
	</TR>
	<TR>
		<td valign=top> </td>
		<TD><a href="editlist.php<?php echo $GlobalArg; ?>" target="main"><?php echo $GLOBALS['strEditLists']; ?></a></TD>
	</TR>
    <TR>
        <td valign=top> </td>
        <TD><a href="editusergroups.php<?php echo $GlobalArg; ?>" target="main">usergroups</a></TD>
    </TR>
<?
}
function cfgPrintSuperAdminEditUser() {
global $GlobalArg, $usr, $CFG;
?>  <TR>
        <td valign=top> </td>
        <TD><a href="<?php echo $usr->GetRegisterUserLink(); ?>" target="main"><?php echo $GLOBALS['strAddUser']; ?></a></TD>
    </TR>
    <TR>
        <td valign=top> </td>
        <TD><a href="<?php echo $usr->GetMemberListLink(); ?>&fltstatus=0" target="main"><?php echo $GLOBALS['strEditUsers']; ?></a></TD>
    </TR>
    <?php if($CFG['UseUserStatus']) { ?>
    <TR>
        <td valign=top> </td>
        <TD><a href="<?php echo $usr->GetMemberListLink(); ?>&fltstatus=1" target="main">unenabeld users</a></TD>
    </TR>
    <?php } ?>
<?
}

function cfgPrintListAnnouncment() {
global $GlobalArg;
?>	<TR>
		<td valign=top> </td>
		<TD><a href="editannounc.php<?php echo $GlobalArg; ?>" target="main"><?php echo $GLOBALS['strCfgMenuAnnouncement']?></a></TD>
	</TR>
<?

}