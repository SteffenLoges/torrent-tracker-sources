<?php
/** powermovielist list-display and index-display
 * $Id: showlinklist.php,v 1.5 2005/09/22 18:32:07 niko Exp $
*/
$FILE_SELF = "showlinklist.php";
include_once("application.php");


$OnLoad = "opener.name='opener'";

$DOC_TITLE = "all lists";
include("top.html");

?>

<table cellpadding="5" cellspacing="1" class="tblback" width="100%">
<tr class="top">
    <td>avaliable lists:</td>
</tr>
<?php
$strSql = "SELECT " . $CFG['Prefix'] . "linklist.Type, " . $CFG['Prefix'] . "linklist.Url, " . $CFG['Prefix'] . "linklist.Text, " . $CFG['Prefix'] . "lists.name FROM " . $CFG['Prefix'] . "linklist LEFT JOIN " . $CFG['Prefix'] . "lists ON (" . $CFG['Prefix'] . "linklist.ListID=" . $CFG['Prefix'] . "lists.ID) ORDER BY SortOrder";
$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
$num = mysql_num_rows($result);
for($i=0;$i<$num;$i++) {
    $row = mysql_fetch_assoc($result);	
    if($row['Type']=="Url")
        $url = $row['Url'];
    else
        $url = "list.php".$GlobalArgWOActive."Active=".$row['name'];
    if($i%2) $cls="row2"; else $cls="row1";
    echo "<tr class=\"$cls\" style=\"cursor: pointer;\" onmouseover=\"this.className='$cls rowpoint'\" onmouseout=\"this.className='$cls'\">
        <td onclick=\"opener.location.href='$url'\">
         <a href=\"$url\" target=\"opener\">$row[Text]</a>
        </td>
        </tr>";
}

echo '</table>
<p style="text-align: center; margin: 0px; padding-top: 3px;">[ <a href="javascript: window.close();">close window</a> ]</p>';




include("bottom.html");

?>