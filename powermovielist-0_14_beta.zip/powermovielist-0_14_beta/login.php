<?php
/** powermovielist login.php
 * $Id: login.php,v 1.4 2006/01/01 12:23:55 niko Exp $
*/
$FILE_SELF = "login.php";
$CheckNewVersion=false;
include_once("application.php");

if(!isset($_POST['LUser']) || !isset($_POST['LPass'])) {
    ErrorExit("you can't call this script directly");
}
//call login-function - if login fails, it does exit
$usr->DoLogin($_POST['LUser'], $_POST['LPass']);
$ActiveUser=$usr->GetActiveUser();

$DoRefresh=true;
if(isset($_POST['RedirectUrl'])) $RefreshUrl=$_POST['RedirectUrl']; else $RefreshUrl="index.php";
include("top.html");

echo " <table width='100%' height='100%'>\n";
echo "  <tr valign='middle' align='center'>\n";
//echo "   <td><b>".$ActiveUser['name'].", Sie wurden erfolgreich abgemeldet.</b><br><a href='$RefreshUrl'>Falls die automatische Weiterleitung nicht funktioniert, klicken Sie bitte hier!</a></td>\n";
echo "   <td><b>".$ActiveUser['name'].", you logged in sucessfully.</b><br><a href='$RefreshUrl'>If the automatic redirection shouldn't work click here!</a></td>\n";
echo "  </tr>\n";
echo " </table>	\n";

include("bottom.html");
?>