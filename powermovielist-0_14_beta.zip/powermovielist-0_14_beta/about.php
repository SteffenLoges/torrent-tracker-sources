<?php
/** powermovielist about for config-page
 * $Id: about.php,v 1.5 2005/09/22 18:32:07 niko Exp $
*/
$FILE_SELF = "about.php";
$LoadSmarty = true;
include_once("application.php");
$DOC_TITLE = "About";
include("top.html");


$TplFile = "about.tpl";
$CacheId = "about|$ActiveList[name]";
$smarty->cache_lifetime = 60*15; //15 minutes


if(!$smarty->is_cached($TplFile,$CacheId)) {    
	$smarty->assign("lang", array("LngCharSet"                   => $LngCharSet,
		                          "strSomeStatisticsForThisList" => $strSomeStatisticsForThisList,
		                          "strSomeStatisticsForAllLists" => $strSomeStatisticsForAllLists));
	$smarty->assign("Version", $Version." Build ". $VerBuild);
	$smarty->assign("Active", $Active);


	if($Active!="index")
		$sqlWhere = "$CFG[Prefix]movies.ListID=$ActiveList[ID]";
	else
		$sqlWhere = "1";

    if($CFG['UserClass']!="standalone.php") {
        $UserData = $GLOBALS['usr']->GetUserList();
    }

	$TableOut = array();

	//anzahl eintr?e
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strEntries, $row[0]);

	//added today
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere AND DateAdded BETWEEN '".date("Y-m-d")." 00:00:00' AND '".date("Y-m-d H:i:s")."'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strAddedToday, $row[0]);

	//added yesterday
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere AND DateAdded BETWEEN '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-1,date("Y")))." 00:00:00' AND '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-1,date("Y")))." 23:59:59'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strAddedYesterday, $row[0]);

	//added this week
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere AND
	DateAdded BETWEEN '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-date("w"),date("Y")))."'
	AND '".date("Y-m-d")." 23:59:59'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strAddedThisWeek, $row[0]);

	//added last week
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere AND
	DateAdded BETWEEN '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-date("w")-7,date("Y")))."'
	AND '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-date("w"),date("Y")))."'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strAddedLastWeek, $row[0]);

	//added this month
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere AND
	DateAdded BETWEEN '".date("Y-m-d H:i:s",mktime (0,0,0,date("m")  ,1,date("Y")))."'
	AND '".date("Y-m-d H:i:s",mktime (0,0,0,date("m")  ,31,date("Y")))."'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strAddedThisMonth, $row[0]);

	//added last month
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies WHERE $sqlWhere AND
	DateAdded BETWEEN '".date("Y-m-d H:i:s",mktime (0,0,0,date("m")-1  ,1,date("Y")))."'
	AND '".date("Y-m-d H:i:s",mktime (0,0,0,date("m")-1  ,31,date("Y")))."'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strAddedLastMonth, $row[0]);

	//user comments added
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies, $CFG[Prefix]comment WHERE
	$sqlWhere AND
	$CFG[Prefix]comment.MovieID = $CFG[Prefix]movies.ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strUserCommentsAdded, $row[0]);

	//user votes registered
	$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]movies, $CFG[Prefix]votes WHERE
	$sqlWhere AND
	$CFG[Prefix]votes.MovieID = $CFG[Prefix]movies.ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strUserVotesRegistered, $row[0]);

	//user votes average
	$strSql = "SELECT AVG($CFG[Prefix]votes.Vote) FROM $CFG[Prefix]movies, $CFG[Prefix]votes WHERE
	$sqlWhere AND
	$CFG[Prefix]votes.MovieID = $CFG[Prefix]movies.ID";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strVoteAverage, round($row[0],1));

    //clicked today
	$strSql = "SELECT COUNT(*)
	FROM $CFG[Prefix]dloadlog, $CFG[Prefix]movies
	WHERE $CFG[Prefix]movies.ID=$CFG[Prefix]dloadlog.MovieID
	AND $sqlWhere
	AND $CFG[Prefix]dloadlog.date BETWEEN '".date("Y-m-d")." 00:00:00' AND '".date("Y-m-d H:i:s")."'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strClickedToday, $row[0]);

    //clicked yesterday
	$strSql = "SELECT COUNT(*)
	FROM $CFG[Prefix]dloadlog, $CFG[Prefix]movies
	WHERE $CFG[Prefix]movies.ID=$CFG[Prefix]dloadlog.MovieID
	AND $sqlWhere
	AND $CFG[Prefix]dloadlog.date BETWEEN '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-1,date("Y")))." 00:00:00' AND '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-1,date("Y")))." 23:59:59'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strClickedYesterday, $row[0]);
    
    //clicks/day last 31 days
	$strSql = "SELECT COUNT(*)
	FROM $CFG[Prefix]dloadlog, $CFG[Prefix]movies
	WHERE $CFG[Prefix]movies.ID=$CFG[Prefix]dloadlog.MovieID
	AND $sqlWhere";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_row($result);
	$TableOut[] = array($strClicksDayLast31Days, round($row[0]/31,1));

	//top 5 active today
	$strSql = "SELECT COUNT(*) AS Cnt, $CFG[Prefix]movies.ID, $CFG[Prefix]movies.ListID, $CFG[Prefix]lists.Name as ListName
		FROM $CFG[Prefix]dloadlog,$CFG[Prefix]movies,$CFG[Prefix]lists
		WHERE $CFG[Prefix]dloadlog.MovieID=$CFG[Prefix]movies.ID
		AND $CFG[Prefix]lists.ID=$CFG[Prefix]movies.ListID
		AND $sqlWhere
		AND $CFG[Prefix]dloadlog.date BETWEEN '".date("Y-m-d")." 00:00:00' AND '".date("Y-m-d H:i:s")."'
		GROUP BY $CFG[Prefix]movies.ID
		ORDER BY Cnt DESC
		LIMIT 5";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$Dat = "";
	while($row = mysql_fetch_assoc($result)) {
		if($Dat!="") $Dat .= "<br>\n";
		$Title = GetMovieTitle($row['ID'], $row['ListID']);
		$Dat .= "<a href='popup.php".$GLOBALS['GlobalArgWOActive']."Active=$row[ListName]&ID=$row[ID]' onclick=\"window.open(this.href,'dload','scrollbars=yes,resizable=yes,width=400,height=500');return false\">$Title</a> ($row[Cnt])";
	}
	if($Dat!="")
		$TableOut[] = array($strMostClicksToday, $Dat);

	//top 5 active yesterday
	$strSql = "SELECT COUNT(*) AS Cnt, $CFG[Prefix]movies.ID, $CFG[Prefix]movies.ListID, $CFG[Prefix]lists.Name as ListName
		FROM $CFG[Prefix]dloadlog,$CFG[Prefix]movies,$CFG[Prefix]lists
		WHERE $CFG[Prefix]dloadlog.MovieID=$CFG[Prefix]movies.ID
		AND $CFG[Prefix]lists.ID=$CFG[Prefix]movies.ListID
		AND $sqlWhere
		AND $CFG[Prefix]dloadlog.date BETWEEN '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-1,date("Y")))." 00:00:00' AND '".date("Y-m-d",mktime (0,0,0,date("m")  ,date("d")-1,date("Y")))." 23:59:59'
		GROUP BY $CFG[Prefix]movies.ID
		ORDER BY Cnt DESC
		LIMIT 5";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$Dat = "";
	while($row = mysql_fetch_assoc($result)) {
		if($Dat!="") $Dat .= "<br>\n";
		$Title = GetMovieTitle($row['ID'], $row['ListID']);
		$Dat .= "<a href='popup.php".$GLOBALS['GlobalArgWOActive']."Active=$row[ListName]&ID=$row[ID]' onclick=\"window.open(this.href,'dload','scrollbars=yes,resizable=yes,width=400,height=500');return false\">$Title</a> ($row[Cnt])";
	}
	if($Dat!="")
		$TableOut[] = array($strMostClicksYesterday, $Dat);

		
	//top 5 active last 31 days
	$strSql = "SELECT COUNT(*) AS Cnt, $CFG[Prefix]movies.ID, $CFG[Prefix]movies.ListID, $CFG[Prefix]lists.Name as ListName
		FROM $CFG[Prefix]dloadlog,$CFG[Prefix]movies,$CFG[Prefix]lists
		WHERE $CFG[Prefix]dloadlog.MovieID=$CFG[Prefix]movies.ID			
		AND $CFG[Prefix]lists.ID=$CFG[Prefix]movies.ListID
		AND $sqlWhere
		GROUP BY $CFG[Prefix]movies.ID
		ORDER BY Cnt DESC
		LIMIT 5";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$Dat = "";
	while($row = mysql_fetch_assoc($result)) {
		if($Dat!="") $Dat .= "<br>\n";
		$Title = GetMovieTitle($row['ID'], $row['ListID']);
		$Dat .= "<a href='popup.php".$GLOBALS['GlobalArgWOActive']."Active=$row[ListName]&ID=$row[ID]' onclick=\"window.open(this.href,'dload','scrollbars=yes,resizable=yes,width=400,height=500');return false\">$Title</a> ($row[Cnt])";
	}
	if($Dat!="")
		$TableOut[] = array($strMostClicksLast31Days, $Dat);

	if($Active!="index") {
		//list-administratoren
        if($CFG['UserClass']=="standalone.php") {
            $strSql = "SELECT ur.UserID, u.name
            FROM $CFG[Prefix]userrights ur, $CFG[Prefix]users u
            WHERE ur.ListID=$ActiveList[ID]
            AND ur.UserID = u.ID
            AND ur.Permissions='".PML_Rights_ListAdmin."'";
        } else {
            $strSql = "SELECT $CFG[Prefix]userrights.UserID
            FROM $CFG[Prefix]userrights
            WHERE $CFG[Prefix]userrights.ListID=$ActiveList[ID]
            AND Permissions='".PML_Rights_ListAdmin."'";
        }
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$Dat = "";
		if(mysql_num_rows($result)>20 || mysql_num_rows($result)==0) {
			$Dat .= mysql_num_rows($result);
			$TableOut[] = array($strUsersWithListAdminRights, $Dat);
		} else {
			for($i=0;$i<mysql_num_rows($result);$i++) {
				$row = mysql_fetch_assoc($result);
				if($i>0)
					$Dat .= "<br>\n";
                if(!isset($row['name'])) $row['name'] = $UserData[$row['UserID']]['name'];
				$Dat .= "<a href='" . $usr->GetUserDetailsLink($row['UserID']) . "'>" . $row['name'] . "</a>";
			}
			$TableOut[] = array($strListAdmins, $Dat);
		}

		//moderators
        if($CFG['UserClass']=="standalone.php") {
            $strSql = "SELECT ur.UserID, u.name
            FROM $CFG[Prefix]userrights ur, $CFG[Prefix]users u
            WHERE ur.ListID=$ActiveList[ID]
            AND ur.UserID = u.ID
            AND ur.Permissions='".PML_Rights_Moderator."'";
        } else {
            $strSql = "SELECT $CFG[Prefix]userrights.UserID
            FROM $CFG[Prefix]userrights
            WHERE $CFG[Prefix]userrights.ListID=$ActiveList[ID]
            AND Permissions='".PML_Rights_Moderator."'";
        }
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$Dat = "";
		if(mysql_num_rows($result)>20 || mysql_num_rows($result)==0) {
			$Dat .= mysql_num_rows($result);
			$TableOut[] = array($strUsersWithModeratorRights, $Dat);
		} else {
			for($i=0;$i<mysql_num_rows($result);$i++) {
				$row = mysql_fetch_assoc($result);
				if($i>0)
					$Dat .= "<br>\n";
                if(!isset($row['name'])) $row['name'] = $UserData[$row['UserID']]['name'];
                $Dat .= "<a href='" . $usr->GetUserDetailsLink($row['UserID']) . "'>" . $row['name'] . "</a>";
			}
			$TableOut[] = array($strModeratorRights, $Dat);
		}

		//add-rights
        if($CFG['UserClass']=="standalone.php") {
            $strSql = "SELECT ur.UserID, u.name
            FROM $CFG[Prefix]userrights ur, $CFG[Prefix]users u
            WHERE ur.ListID=$ActiveList[ID]
            AND ur.UserID = u.ID
            AND ur.Permissions='".PML_Rights_Add."'";
        } else {
            $strSql = "SELECT $CFG[Prefix]userrights.UserID
            FROM $CFG[Prefix]userrights
            WHERE $CFG[Prefix]userrights.ListID=$ActiveList[ID]
            AND Permissions='".PML_Rights_Add."'";
        }
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$Dat = "";
		if(mysql_num_rows($result)>20 || mysql_num_rows($result)==0) {
			$Dat .= mysql_num_rows($result);
			$TableOut[] = array($strUsersWithAddRights, $Dat);
		} else {
			for($i=0;$i<mysql_num_rows($result);$i++) {
				$row = mysql_fetch_assoc($result);
				if($i>0)
					$Dat .= "<br>\n";
                if(!isset($row['name'])) $row['name'] = $UserData[$row['UserID']]['name'];
                $Dat .= "<a href='" . $usr->GetUserDetailsLink($row['UserID']) . "'>" . $row['name'] . "</a>";
			}
			$TableOut[] = array($strAddRights, $Dat);
		}

		//loan-rights
        if($CFG['UserClass']=="standalone.php") {
            $strSql = "SELECT ur.UserID, u.name
            FROM $CFG[Prefix]userrights ur, $CFG[Prefix]users u
            WHERE ur.ListID=$ActiveList[ID]
            AND ur.UserID = u.ID
            AND ur.Permissions='".PML_Rights_Loan."'";
        } else {
            $strSql = "SELECT $CFG[Prefix]userrights.UserID
            FROM $CFG[Prefix]userrights
            WHERE $CFG[Prefix]userrights.ListID=$ActiveList[ID]
            AND Permissions='".PML_Rights_Loan."'";
        }
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$Dat = "";
		if(mysql_num_rows($result)>20 || mysql_num_rows($result)==0) {
			$Dat .= mysql_num_rows($result);
			$TableOut[] = array($strUsersWithLoanRights, $Dat);
		} else {
			for($i=0;$i<mysql_num_rows($result);$i++) {
				$row = mysql_fetch_assoc($result);
				if($i>0)
					$Dat .= "<br>\n";
                if(!isset($row['name'])) $row['name'] = $UserData[$row['UserID']]['name'];
                $Dat .= "<a href='" . $usr->GetUserDetailsLink($row['UserID']) . "'>" . $row['name'] . "</a>";
			}
			$TableOut[] = array($strLoanRights, $Dat);
		}

		//nr view-rights
		$strSql = "SELECT COUNT(*) FROM $CFG[Prefix]userrights WHERE
		$CFG[Prefix]userrights.ListID=$ActiveList[ID] AND		
		Permissions='".PML_Rights_View."'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_row($result);
		$TableOut[] = array($strUsersWithViewRights, $row[0]);

        //guest-rights
        if($CFG['UserClass']!="standalone.php") { //deaktivated for now...
            foreach($UserData as $Dat) {
                if($Dat['name']=="Guest") {
                    $GuestID = $Dat['ID'];
                    break;
                }
            }
            $strSql = "SELECT $CFG[Prefix]userrights.Permissions FROM $CFG[Prefix]userrights WHERE
            $CFG[Prefix]userrights.ListID=$ActiveList[ID] AND
            $CFG[Prefix]userrights.UserID='$GuestID'";
            $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
            $row = mysql_fetch_row($result);
            if(!is_numeric($row[0]))
                $row[0]=0;
            $TableOut[] = array($strGuestRights, $strUserRights[$row[0]]);
        }

		//new-user-rights
		$strSql = "SELECT $CFG[Prefix]userrights.Permissions FROM $CFG[Prefix]userrights WHERE
		$CFG[Prefix]userrights.ListID=$ActiveList[ID] AND
		$CFG[Prefix]userrights.UserID = 0";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$row = mysql_fetch_row($result);
		if(!is_numeric($row[0]))
			$row[0]=0;
		$TableOut[] = array($strNewUserRights, $strUserRights[$row[0]]);

	} //endif $Active!=index

	$smarty->assign("AboutData",$TableOut);
}

$smarty->display($TplFile,$CacheId);

include("bottom.html");
?>