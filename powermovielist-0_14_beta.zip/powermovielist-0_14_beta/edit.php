<?php
/** powermovielist edit.php
 * $Id: edit.php,v 1.8 2005/12/16 13:43:18 niko Exp $
*/

if(!isset($Display)) $Display="";
if(!isset($GlobalArg)) $GlobalArg="?";

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";
if(isset($_GET['ID'])) $ID = $_GET['ID'];

if(!isset($DisplayFilter)) $DisplayFilter=array();
if(!isset($ShowEditLinks)) $ShowEditLinks = true;
if(!isset($DisplayFormList)) $DisplayFormList = false;
if(!isset($HideAddLink)) $HideAddLink = false;
if(!isset($HideDelLink)) $HideDelLink = false;

//load default-values:
for($i=0;$i<sizeof($Show);$i++) {	
	if(!isset($Show[$i]['hide']))
		$Show[$i]['hide']=false;
	if(!isset($Show[$i]['sortdef']))
		$Show[$i]['sortdef']=false;
	if(!isset($Show[$i]['sortkey']))
		$Show[$i]['sortkey']="";
	if(!isset($Show[$i]['comm']))
		$Show[$i]['comm']="";
	if(!isset($Show[$i]['detaillink']))
		$Show[$i]['detaillink']=false;
	if(!isset($Show[$i]['newonly']))
		$Show[$i]['newonly']=false;
	if(!isset($Show[$i]['text']))
		$Show[$i]['text']=$Show[$i]['name'];
	if(!isset($Show[$i]['def']))
		$Show[$i]['def']="";
	if(!isset($Show[$i]['uniq']))
		$Show[$i]['uniq']=false;
	if(!isset($Show[$i]['save']))
		$Show[$i]['save']=true;
	if(!isset($Show[$i]['hidedetails']))
		$Show[$i]['hidedetails']=false;
	if(!isset($Show[$i]['main']))
		$Show[$i]['main']=false;
	if(!isset($Show[$i]['tags']))
		$Show[$i]['tags']="";
    if(!isset($Show[$i]['hidenew']))
        $Show[$i]['hidenew'] = false;
}
if(!isset($SaveButtonText)) $SaveButtonText = "Save";
if(!isset($DisplayFilterButton)) $DisplayFilterButton = "filter";

if(!isset($FILE_SELF)) $FILE_SELF = $_SERVER['PHP_SELF'];



if(isset($_SESSION[$SessionVar]))
	$SessVar = $_SESSION[$SessionVar];
else
	$SessVar = array("Start"=>1, "SortKey"=>-1, "SortDir"=>0); //load default values for session-variable


if(isset($_GET['Start']))
	$SessVar['Start'] = ceil($_GET['Start']);

if(isset($_GET['SortKey'])) 
	$SessVar['SortKey'] = ceil($_GET['SortKey']);

if(isset($_GET['SortDir'])) 
	$SessVar['SortDir'] = ceil($_GET['SortDir']);


foreach($DisplayFilter as $k=>$DFilt) {
	$Dat = "flt" . $DFilt['name'];
    if(isset($_GET[$Dat])) {
        $SessVar['Filter'][$k] = $_GET[$Dat];
    }
	if(isset($_POST[$Dat])) {
		$SessVar['Filter'][$k] = $_POST[$Dat];
	}
}

if(!isset($SessVar['Filter'])) {
	$SessVar['Filter']=array();
	foreach($DisplayFilter as $key=>$Dat) {
		switch($Dat['type']) {
			case "listbox":
				$SessVar['Filter'][$key]=0;
				break;
			default:   //no default selection
				break;
		}
	}
}

if(!isset($primaryKey)) $primaryKey = "ID";

//echo "<pre>";
//print_r($SessVar);
//echo "</pre>";

switch($action) {
case "listsave":
	$ListEditID = $_POST['ListEditID'];
	foreach($ListEditID as $Key=>$x) {		
		$strSql = "UPDATE $Table SET ";
		for($i=0;$i<count($Show);$i++) {
			if($Show[$i]['newonly']) //dieses eine berspringenw wenn im edit-modus
				continue;
			if(!$Show[$i]['save'])
				continue;			
			switch($Show[$i]['type']) {
				case "edittext":
				case "editlistbox":
					$strSql .= $Show[$i]['name'] . "='" . ($_POST[$Show[$i]['name']][$Key]) . "', ";
					break;
                case "editcheckbox":
                    $val=array();
                    $val=explode(";",$Show[$i]['prop']);
                    if(!isset($_POST[$Show[$i]['name']][$Key]))
                        $_POST[$Show[$i]['name']][$Key] = "";
                    if($_POST[$Show[$i]['name']][$Key]=="set")
                        $_POST[$Show[$i]['name']][$Key] = $val[0];
                    else
                        $_POST[$Show[$i]['name']][$Key] = $val[1];               
                    
                    $strSql .= $Show[$i]['name'] . "='" . ($_POST[$Show[$i]['name']][$Key]) . "', ";
                    break;
			}
		} //end for
		if($strSql!="UPDATE $Table SET ") {
			$strSql = substr($strSql, 0, -2);
			$strSql .= " WHERE $primaryKey=$Key";
			pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		}
	}
	for($i=0;$i<count($Show);$i++) {
		if($Show[$i]['type']=="funcall") {
			echo call_user_func($Show[$i]['func'], 0,$action);
		}
	}
    $lastAction = $action;
	$_GET['action']="";
	include("edit.php");
	break;
case "up":
case "down":
	if(!isset($SortOrderField)) break;
	$strSql = "SELECT * FROM $Table";
	if($Filter!="")
		$strSql .= " WHERE $Filter=$FilterVal";
	$strSql .= " ORDER BY $SortOrderField";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
	$num = mysql_num_rows($result);
	for($i=0;$i<$num;$i++) {
		$row = mysql_fetch_assoc($result);
		if($action=="up") {
			if($row[$primaryKey]==$ID) {
				if($i==0) //ist bereits ganz oben...
					break;
				$strSql = "UPDATE $Table SET $SortOrderField='$lastorderid' WHERE $primaryKey='$ID'";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$strSql = "UPDATE $Table SET $SortOrderField='$row[$SortOrderField]' WHERE $primaryKey='$lastid'";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
				break;
			}
			$lastorderid=$row[$SortOrderField];
			$lastid=$row[$primaryKey];
		}

		if($action=="down") {
			if($row[$primaryKey]==$ID) {
				if($i==$num-1) //ist bereits ganz oben...
					break;
				$lastorderid=$row[$SortOrderField];
				$lastid=$row[$primaryKey];
				$row=mysql_fetch_assoc($result);
				$strSql = "UPDATE $Table SET $SortOrderField='$lastorderid' WHERE $primaryKey='{$row[$primaryKey]}'";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
				$strSql = "UPDATE $Table SET $SortOrderField='$row[$SortOrderField]' WHERE $primaryKey='$lastid'";
				pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);		
				break;
			}
		}
	}
	//no break, display the new list
case "":
	echo "<h1>$TitlePl</h1>\n";
	if(isset($SecondTitle))
		echo "<h2>$SecondTitle</h2>\n";
	if(isset($TitleInfo))
		echo "<p>$TitleInfo</p>\n";

$i=0;
	foreach($DisplayFilter as $FiltKey=>$DFilt) {
		$i++;
		if($i==1)
			echo "<form method='post' action='$FILE_SELF".$GlobalArg."Display=$Display&action=&F=$FilterVal'>\n";
		echo $DFilt['text'] .":";
		switch($DFilt['type']) {
			case "listbox":
				echo "  <select name='flt$DFilt[name]'>\n";
				foreach($DFilt['item'] as $key=>$dat) {
					echo "    <option value='$key'";
					if(isset($SessVar['Filter'][$FiltKey])) {
						if($SessVar['Filter'][$FiltKey]==$key)
							echo "selected ";
					}
					echo ">$dat</option>\n";
				}
				echo "  </select>\n";
				break;
			case "text":
				echo "  <input type='text' name='flt$DFilt[name]' value='";
				if(isset($SessVar['Filter'][$FiltKey]))
					echo $SessVar['Filter'][$FiltKey];
				echo "'>\n";
				break;
		}
	}
if($i>0) {
	echo "  <input type='submit' value='$DisplayFilterButton'>";
	echo "</form>\n";
}

    if(!isset($SelectFrom)) $SelectFrom = "*";
	$strSql = "SELECT $SelectFrom FROM $Table";
    if(isset($joinTable)) $strSql .= " $joinTable";
	if($FilterVal!="")
		$strSql .= " WHERE $Filter=$FilterVal";
	else
		$strSql .= " WHERE 1";
	
	foreach($SessVar['Filter'] as $k=>$dat) {		
		switch($DisplayFilter[$k]['type']) {
			case "listbox":
				if(isset($DisplayFilter[$k]['itemsql'][$dat]) && $DisplayFilter[$k]['itemsql'][$dat]!="1") {
					$strSql .= " AND ".$DisplayFilter[$k]['itemsql'][$dat];
				}				
				break;
			case "text":
				$strSql .= " AND ".str_replace("_Text",$dat,$DisplayFilter[$k]['sql']);
				break;
		}
	}
    if(isset($groupBy)) {
        $strSql .= " GROUP BY $groupBy";
    }

	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$AnzFound = mysql_num_rows($result);
	
	if(isset($DataAlwaysDisplayed)) {				
		$AnzFound += count($DataAlwaysDisplayed);
	}


	if($SessVar['SortKey']==-1) { //load default sort-order
		foreach($Show as $k=>$x) {
			if($x['sortdef']) {
				$SessVar['SortKey'] = $k;
				$SessVar['SortDir'] = $x['sortdir'];					
				break;
			}			
		}
	}

	if($SessVar['SortKey']>=0 && $SessVar['SortKey']<sizeof($Show)) {
		$SortKeyString = $Show[$SessVar['SortKey']]['sortkey'];
	} else {		
		$SortKeyString = "";
	}

	if($SortKeyString!="") { //if sortstring is set append order-by-clause
		$strSql .= " ORDER BY " . $SortKeyString;
		if($SessVar['SortDir']==1)
			$strSql .= " DESC";
		else
			$strSql .= " ASC";
	} else {
		if(isset($SortOrderField)) { //use the sortorderfield
			$strSql .= " ORDER BY $SortOrderField";
		}
	}

	$DisplayPerPage = 50;

	if(isset($DataAlwaysDisplayed)) {				
		if($SessVar['Start']==1)
			$strSql .= " LIMIT ". (($SessVar['Start']-1)*$DisplayPerPage) . "," . ($DisplayPerPage-count($DataAlwaysDisplayed));
		else
			$strSql .= " LIMIT ". (($SessVar['Start']-1)*$DisplayPerPage - count($DataAlwaysDisplayed)) . ",$DisplayPerPage";
	} else {
		$strSql .= " LIMIT ". (($SessVar['Start']-1)*$DisplayPerPage) . ",$DisplayPerPage";
	}

	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$num = mysql_num_rows($result);

	if(isset($CFG['Debug'])) {
		if($CFG['Debug'])
			echo $strSql . "<br>";
	}


	if($AnzFound==0)
		echo $strSqlNothingFound;
	else {
		echo "  " . $AnzFound . " " . $strSqlFound;
	}
	echo "<br>\n";

	if($AnzFound > $DisplayPerPage) {

		echo "displaying " . (($SessVar['Start']-1)*$DisplayPerPage+1) . " to ";
		if($SessVar['Start']*$DisplayPerPage > $AnzFound)
			echo $AnzFound;
		else
			echo $SessVar['Start']*$DisplayPerPage;
		echo "<br>";

		//remove the Start=xx from REQUEST_URI
		$location = $_SERVER['REQUEST_URI'];
		$location = ereg_replace("Start=([0-9]*)","",$location);
		$location = str_replace("&&","&",$location);
		$location = str_replace("?&","?",$location);
		if(substr($location,-1)=="&")
			$location = substr($location,0,-1);
		if(strstr($location,"?")) $location .= "&"; else $location .= "?";

		$NumText = "<div align=center><b><font size=+1>\n";
		if($SessVar['Start'] > 1) {
			$NumText .= " <a href=\"" .$location . "&Start=";
			$NumText .= $SessVar['Start']+-1;
			$NumText .= "\">&lt;</a> \n";
		} else $NumText .= "&lt;\n";
        
        $numStart = 0;
        $numEnd = $AnzFound/$DisplayPerPage;
        if ($AnzFound/$DisplayPerPage > 10) {
            $numStart = $SessVar['Start']-5;
            $numEnd = $SessVar['Start']+5;
            if ($numStart < 0) {
                $i = $numStart;
                $numEnd = $numEnd - $i;
                $numStart = $numStart - $i;
            }
            if ($numEnd > $AnzFound/$DisplayPerPage) {
                $i = $numEnd - ceil($AnzFound/$DisplayPerPage);
                $numEnd = $numEnd - $i;
                $numStart = $numStart - $i;
            }
        }

        if ($numStart > 0) {
            $NumText .= "<a href=\"" .$location . "&Start=1\">1</a>\n";
            $NumText .= " ... \n";
        }
        for ($i = $numStart; $i < $numEnd; $i++) {
            if($i!=($SessVar['Start']-1))
                $NumText .= "<a href=\"" .$location . "&Start=".($i+1)."\">".($i+1)."</a>\n";
            else
                $NumText .= " <b>".($i+1)."</b> ";
        }
  
        if ($numEnd < $AnzFound/$DisplayPerPage) {
            $NumText .= " ... \n";
            $NumText .= "<a href=\"" .$location . "&Start=".ceil($AnzFound/$DisplayPerPage)."\">".ceil($AnzFound/$DisplayPerPage)."</a>\n";
        }

		if(($SessVar['Start']*$DisplayPerPage) < $AnzFound) {
			$NumText .= " <a href=\"" .$location . "&Start=";
			$NumText .= $SessVar['Start']+1;
			$NumText .= "\">&gt;</a>"; }
		else $NumText .= " &gt;";
		$NumText .= "</a></font></b></div>";
	} else {
		//everything displayed on the first page
		$NumText = "<br>";
	}

	echo $NumText;

	//remove the SortKey=xx and SortDir=xx and action= from REQUEST_URI
	$location = $_SERVER['REQUEST_URI'];
	$location = ereg_replace("SortKey=([0-9]*)","",$location);
	$location = ereg_replace("SortDir=([0-9]*)","",$location);
	$location = ereg_replace("action=([a-zA-Z0-9]*)","",$location);
	$location = str_replace("&&","&",$location);
	$location = str_replace("?&","?",$location);
	if(substr($location,-1)=="&")
		$location = substr($location,0,-1);
	if(strstr($location,"?")) $location .= "&"; else $location .= "?";
	$location .= "action=&";

	if($DisplayFormList)
		echo "<form method=post action='$FILE_SELF".$GlobalArg."Display=$Display&action=listsave&F=$FilterVal'>\n";

	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";	
	echo "<tr class='top'>\n";
	echo "	<td>Nr</td>\n";
	$numfld = sizeof($Show);
	for($i=0;$i<$numfld;$i++) {		
		if($Show[$i]['main']) {
			echo "	<td>";
			if($Show[$i]['sortkey']!="") {				
				echo "<a href='" .$location . "SortKey=" . $i . "&SortDir=";
				if($SessVar['SortKey']==$i) { //if selected, invert sort-order
					if($SessVar['SortDir']==1)
						echo "0";
					else
						echo "1";
				} else {
					echo $Show[$i]['sortdir'];
				}
				echo "'>".$Show[$i]['text'] ."</a>";
				if($SessVar['SortKey']==$i) { //if selected, print image
					echo " <img border=0 src='image/sort/";
					if($SessVar['SortDir']==1)
						echo "asc_order.gif";
					else
						echo "desc_order.gif";
					echo "'>";
				}

			} else
				echo $Show[$i]['text'];
			echo "</td>\n";
		}
	} //end for
	if($ShowEditLinks)
		echo "	<td><b>$strEdit</b></td>\n";
	echo "</tr>\n";
	

    $DisplayColCount = 0;
    
	//DataAlwaysDisplayed, is shown on the first page
	$i=-1;
	if($SessVar['Start']==1) {	
		$iDataAlwaysDisplayed=0;
		if(isset($DataAlwaysDisplayed)) {
			reset($DataAlwaysDisplayed);
			$DataAlwaysDisplayedFinished = false;
		} else {
			$DataAlwaysDisplayedFinished = true;
		}
	} else {
		$iDataAlwaysDisplayed = 0;
		$DataAlwaysDisplayedFinished = true;
	}
	while(1) {
		$i++;
		if($DataAlwaysDisplayedFinished) {
			if(($i-$iDataAlwaysDisplayed)>$num-1) break;
			$row = mysql_fetch_array($result);
		} else {
			$iDataAlwaysDisplayed++;
			$row = current($DataAlwaysDisplayed);
			if(!next($DataAlwaysDisplayed))
				$DataAlwaysDisplayedFinished=true;
		}		
		echo "<tr class='";
		if($i%2) echo "row2";
		else echo "row1";
		echo "'>\n";
		echo "	<td>".($i+$DisplayPerPage*($SessVar['Start']-1)+1);
		if($DisplayFormList) {
			echo "    <input type='hidden' name='ListEditID[{$row[$primaryKey]}]' value='1'>\n";
		}
		echo "</td>\n";
		if($i==0) { if(!isset($DisplayColCount)) $DisplayColCount=0; }
		for($j=0;$j<$numfld;$j++) {
			if(!$Show[$j]['main']) continue;
			if($i==0) { $DisplayColCount++; }
			if(!isset($Show[$j]['hidemaintd'])) echo "	<td>";
			if($Show[$j]['detaillink']) {
				echo "<a href='$FILE_SELF".$GlobalArg."Display=$Display&action=details&ID={$row[$primaryKey]}&F=$FilterVal'>";
			} elseif(isset($Show[$j]['url'])) {
				$Dat = $Show[$j]['url'];
				$Dat = str_replace("_ID", $row[$primaryKey], $Dat);
				echo "<a href='" . $Dat . "'>";
			}
			$ShowType = $Show[$j]['type'];
			if(isset($Show[$j]['showonlyfld'])) {
				$Dat = explode(";",$Show[$j]['showonlyval']);
				if(!in_array($row[$Show[$j]['showonlyfld']],$Dat)) $ShowType="";
			}
			switch($ShowType) {
				case "sqlfunc":
					$strSql = $Show[$j]['sqlstr'];
					$strSql = str_replace("_ID", $row[$primaryKey], $strSql);
					$resultfunc = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
					$x=mysql_fetch_row($resultfunc);
					echo $x[0];
					break;
				case "func":
					echo call_user_func($Show[$j]['func'], $row[$primaryKey], $row);
					break;
				case "funcall":
					echo call_user_func($Show[$j]['func'], $row[$primaryKey],$action);
					break;
				case "email":
					if(isset($Show[$j]['showemailfld'])) {
						if(!$row[$Show[$j]['showemailfld']]) {
							echo "(hidden)";
							break;
						}
					}
					if($row[$Show[$j]['name']]!="")
						echo "<a href='mailto:" . $row[$Show[$j]['name']] . "'>" . $row[$Show[$j]['name']] . "</a>";
					else
						echo "&nbsp;";
					break;
				case "icq":
					if($row[$Show[$j]['name']]!="")
						echo "<a href='http://wwp.icq.com/scripts/search.dll?to=" . $row[$Show[$j]['name']] . "'><img src='http://wwp.icq.com/scripts/online.dll?icq=" . $row[$Show[$j]['name']] . "&img=5' WIDTH='18' HEIGHT='18' border=0 alt='Add to contact list'></a>";
					else
						echo "&nbsp;";
					break;
				case "aim":
					if($row[$Show[$j]['name']]!="")
						echo "<a href='aim:goim?screenname=" . $row[$Show[$j]['name']] . "&message=Hi.+Are+you+there?'><img src='image/aim.gif' border=0 alt='AIM Screenname: " . $row[$Show[$j]['name']] . "'>";
					else
						echo "&nbsp;";
					break;
				case "listbox":
					if(isset($Show[$j]['delemiter']))
						$delem = $Show[$j]['delemiter'];
					else 
						$delem = ";";						
					$prop = explode($delem, $Show[$j]['prop']);
					$val = explode($delem, $Show[$j]['values']);
					for($l=0;$l<sizeof($prop);$l++) {
						if($row[$Show[$j]['name']]==$val[$l]) {
							echo $prop[$l];
							break;
						}
					}
					break;
				case "link":
					if($row[$Show[$j]['name']]!="")
						echo "<a href='" . $row[$Show[$j]['name']] . "'>" . $row[$Show[$j]['name']] . "</a>";
					else
						echo "&nbsp;";
					break;
				case "select":						
					$strSql = $Show[$j]['selectsqlsel'];
					$strSql = str_replace("_ID", $row[$Show[$j]['name']], $strSql);
					$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
					$row1 = mysql_fetch_array($result1);
					echo $row1['Display'];
					break;
				case "staticlink":
					$Dat = str_replace("_ID",$row[$primaryKey],$Show[$j]['prop']);
					echo "<a href='$Dat' " . $Show[$j]['tags'] . ">" . $Show[$j]['text'] . "</a>\n";
					break;
				case "edittext":
					echo "<input type='text' name='" . $Show[$j]['name'] ."[". $row[$primaryKey] . "]' size='" . $Show[$j]['prop'] . "' value='";
					echo htmlspecialchars($row[$Show[$j]['name']]);
					echo "'>";
					break;
				case "editlistbox":
					$Sel = $row[$Show[$j]['name']];
					
					if(isset($Show[$j]['delemiter']))
						$delem = $Show[$j]['delemiter'];
					else 
						$delem = ";";

					echo "\n		<select name='" . $Show[$j]['name'] . "[" . $row[$primaryKey] . "]'>\n";
					$prop = explode($delem, $Show[$j]['prop']);
					$val = explode($delem, $Show[$j]['values']);
					for($x=0;$x<sizeof($prop);$x++) {
						echo "			<option value='" . $val[$x] . "'";
						if($Sel==$val[$x]) echo " selected";
						echo ">" . $prop[$x] . "</option>\n";
					}
					echo "		</select>\n";
					break;
                case "editcheckbox":
                    $Sel = $row[$Show[$j]['name']];
                    $val=explode(";",$Show[$j]['prop']);
                    echo "<INPUT TYPE='checkbox' NAME='" . $Show[$j]['name'] . "[" . $row[$primaryKey] . "]' value='set'" . $Show[$j]['tags'] . "";
                    if($Sel==$val[0]) echo " checked";
                    echo ">";
                    break;
				case "":
					break;
                case "editcheckbox":
                case "checkbox":
					if(isset($Show[$j]['delemiter']))
						$delem = $Show[$j]['delemiter'];
					else 
						$delem = ";";						
					$prop = explode($delem, $Show[$j]['prop']);
					$val = explode($delem, $Show[$j]['values']);
					for($l=0;$l<sizeof($prop);$l++) {
						if($row[$Show[$j]['name']]==$prop[$l]) {
							echo $val[$l];
							break;
						}
					}
                    break;
                case "listboxmulti":
                    if(isset($Show[$j]['delemiter']))
                        $delem = $Show[$j]['delemiter'];
                    else 
                        $delem = ";";                       
                    $prop = explode($delem, $Show[$j]['prop']);
                    $val = explode($delem, $Show[$j]['values']);
                    $strSql = "SELECT {$Show[$j]['fieldVal']} FROM {$Show[$j]['table']} WHERE {$Show[$j]['fieldKey']}='{$row[$primaryKey]}'";
                    $q1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    $Sel = array();
                    $fs = "";
                    while($r1=mysql_fetch_row($q1)) {
                        $fs .= $prop[array_search($r1[0], $val)].", ";
                    }
                    echo substr($fs, 0, -2);
                    break;
				default:
					echo $row[$Show[$j]['name']];
			}
			if(isset($Show[$j]['detaillink']) || isset($Show[$j]['url'])) {
				echo "</a>";
			}
			if(!isset($Show[$j]['hidemaintd'])) echo "</td>\n";
		}
		if($ShowEditLinks) {
			echo "	<td><a href='$FILE_SELF".$GlobalArg."Display=$Display&action=edit&ID={$row[$primaryKey]}&F=$FilterVal'><img src='image/edit/edit.png' border='0' alt='edit'></a>\n";
			if(!$HideDelLink) {
				echo "  <a href='$FILE_SELF".$GlobalArg."Display=$Display&action=delsave&ID={$row[$primaryKey]}&F=$FilterVal'  onclick=\"return confirm('Are you sure to delete this entry?')\"><img src='image/edit/del.png' border='0' alt='delete'></a>\n";
			}
			if(isset($SortOrderField)) {  //up-down-links
				echo "	<a href='$FILE_SELF".$GlobalArg."Display=$Display&action=up&ID={$row[$primaryKey]}&F=$FilterVal'><img src='image/edit/up.png' width='16' height='16' border='0' alt='move up'></a>\n";
				echo "  <a href='$FILE_SELF".$GlobalArg."Display=$Display&action=down&ID={$row[$primaryKey]}&F=$FilterVal'><img src='image/edit/down.png' width='16' height='16' border='0' alt='move down'></a>\n";
			}
			echo "</td>";
		}
		echo "</tr>\n";
	} //end for


	if($DisplayFormList) {
		$i++;
		echo "<tr class='";
		if($i%2) echo "row1";
		else echo "row2";
        $colspan = $DisplayColCount+1;
        if(!$ShowEditLinks) $colspan--;
		echo "'><td colspan='".$colspan."'></td><td><input type='submit' value='$SaveButtonText'></td></tr>\n";
	}

	echo "</table>\n";
	if($DisplayFormList)
		echo "</form>\n";


	if(!$HideAddLink)
		echo "<br><a href='$FILE_SELF".$GlobalArg."Display=$Display&action=add&F=$FilterVal'>" . str_replace("%title%", $Title, $strEditAdd). "</a>\n";
	break;
case "details":
	echo "<h1>$Title-details</h1>";
	$strSql = "SELECT * FROM $Table WHERE $primaryKey='$ID'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);
	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
	$i=1;
	for($j=0;$j<count($Show);$j++) {
		if($Show[$j]['type']=="pass")
			continue;
		if($Show[$j]['hidedetails'])
			continue;
		if(isset($Show[$j]['showonlyfld'])) {
			$Dat = explode(";",$Show[$j]['showonlyval']);
			if(!in_array($row[$Show[$j]['showonlyfld']],$Dat)) continue;
		}
		$i++;
		echo "<tr class='";
		if($i%2) echo "row1";
		else echo "row2";
		echo "'>\n";
		echo "    <td align='right'><b>".$Show[$j]['text'].":</b></td>\n";
		echo "    <td>";		
		switch($Show[$j]['type']) {
			case "sqlfunc":
				$strSql = $Show[$j]['sqlstr'];
				$strSql = str_replace("_ID", $row[$primaryKey], $strSql);
				$resultfunc = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$x=mysql_fetch_row($resultfunc);
				echo $x[0];
				break;
			case "func":
				echo call_user_func($Show[$j]['func'], $row[$primaryKey]);
				break;
			case "funcall":
				echo call_user_func($Show[$j]['func'], $row[$primaryKey],$action);
				break;
			case "email":
				if(isset($Show[$j]['showemailfld'])) {
					if(!$row[$Show[$j]['showemailfld']]) {
						echo "(hidden)";
						break;
					}
				}
				if($row[$Show[$j]['name']]!="")
					echo "<a href='mailto:" . $row[$Show[$j]['name']] . "'>" . $row[$Show[$j]['name']] . "</a>";
				else
					echo "&nbsp;";
				break;
			case "icq":							
				if($row[$Show[$j]['name']]!="")
					echo "<a href='http://wwp.icq.com/scripts/search.dll?to=" . $row[$Show[$j]['name']] . "'>" . $row[$Show[$j]['name']] . " <img src='http://wwp.icq.com/scripts/online.dll?icq=" . $row[$Show[$j]['name']] . "&img=5' WIDTH='18' HEIGHT='18' border=0 alt='Add to contact list'></a>";
				else
					echo "&nbsp;";
				break;
			case "aim":
				if($row[$Show[$j]['name']]!="")
					echo "<a href='aim:goim?screenname=" . $row[$Show[$j]['name']] . "&message=Hi.+Are+you+there?'><img src='image/aim.gif' border=0 alt='AIM Screenname: " . $row[$Show[$j]['name']] . "'>";
				else
					echo "&nbsp;";
				break;
			case "listbox":
			case "editlistbox":
				if(isset($Show[$j]['delemiter']))
					$delem = $Show[$j]['delemiter'];
				else 
					$delem = ";";						
				$prop = explode($delem, $Show[$j]['prop']);
				$val = explode($delem, $Show[$j]['values']);
				for($l=0;$l<sizeof($prop);$l++) {
					if($row[$Show[$j]['name']]==$val[$l]) {
						echo $prop[$l];
						break;
					}
				}
				break;
			case "link":
				if($row[$Show[$j]['name']]!="")
					echo "<a href='" . $row[$Show[$j]['name']] . "'>" . $row[$Show[$j]['name']] . "</a>";
				else
					echo "&nbsp;";
				break;
			case "select":						
				$strSql = $Show[$j]['selectsqlsel'];
				$strSql = str_replace("_ID", $row[$Show[$j]['name']], $strSql);
				$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$row1 = mysql_fetch_array($result1);
				echo $row1['Display'];
				break;
			case "staticlink":
				$Dat = str_replace("_ID",$row[$primaryKey],$Show[$j]['prop']);
				echo "<a href='$Dat' " . $Show[$j]['tags'] . ">" . $Show[$j]['text'] . "</a>\n";
				break;
			default:
				echo $row[$Show[$j]['name']];
		}
		echo "</td>\n";
		echo "  </tr>\n";
	}
	echo "</table>\n";
	break;
case "add":
case "edit":
	if($action=="edit") {
        if($Title!="") {
		  echo "<h1>" . str_replace("%title%", $Title, $strEditEdit). "</h1>\n";
        }
		$strSql = "SELECT * FROM $Table WHERE $primaryKey='$ID'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$num = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
	} else {
        if($Title!="") {
		  echo "<h1>" . str_replace("%title%", $Title, $strEditAdd). "</h1>\n";
        }
	}
	if(isset($SecondTitle))
		echo "<h2>$SecondTitle</h2>\n";
	if(isset($TitleInfo))
		echo "<p>$TitleInfo</p>\n";
	echo "<form name='frmEdit' ";
	if(isset($EncType))
		echo "enctype='$EncType' ";
	echo "method=post action='$FILE_SELF".$GlobalArg."Display=$Display&";
	if($action=="edit") echo "ID=$ID";
	echo "&action=$action" . "save&F=$FilterVal'>";
	echo "<table border='0' cellspacing='1' cellpadding='5' class='tblback' width='100%'>\n";
	$cls=0;
	for($i=0;$i<count($Show);$i++) {
		if($Show[$i]['newonly'] && $action=="edit") //dieses eine berspringenw wenn im edit-modus
			continue;
		if($Show[$i]['hide'])
			continue;
		if($Show[$i]['type']=="hidden")
			continue;
		if($action=="add") {
			if($Show[$i]['type']=="func" || $Show[$i]['type']=="sqlfunc")
				continue;
            if($Show[$i]['hidenew'])
                continue;
		}
		if($action=="edit") {
			if(isset($Show[$i]['showonlyfld'])) {
				$Dat = explode(";",$Show[$i]['showonlyval']);
				if(!in_array($row[$Show[$i]['showonlyfld']],$Dat)) continue;
			}
		}
		echo "<tr class='";
		if($cls++%2) echo "row1"; else echo "row2";
		echo "'>\n";
		echo "	<td align='right'>";
		if(isset($Show[$i]['html'])) {
			echo $Show[$i]['html'];
		} else {
			if($Show[$i]['text'] != "") echo "<b>" . $Show[$i]['text'] . ": </b>";		
			if($Show[$i]['comm']!="") echo "<br><font size=-3> " . $Show[$i]['comm'] . "</font>\n";
		}
		echo "</td>\n";
		echo "	<td>";
		switch($Show[$i]['type']) {
			case "select":
				if(!isset($row[$Show[$i]['name']])) $row[$Show[$i]['name']]="";
				if($row[$Show[$i]['name']]==0) $row[$Show[$i]['name']]="";
				if(isset($_POST[$Show[$i]['name'] . "Search"]))
					$SearchString = $_POST[$Show[$i]['name'].'Search'];
				else {
					$SearchString = "";
					if($action=="edit") {

					}
				}
				echo "<input type='text' name='" . $Show[$i]['name'] . "Search' value='$SearchString'" . $Show[$i]['tags'] . ">
				<input type='submit' name='search' value='suche'>
				<br>
				<br>\n";
				echo "<select name='" . $Show[$i]['name'] . "' size='8'>\n";
				
				if($row[$Show[$i]['name']]!="") {
					$strSql = $Show[$i]['selectsqlsel'];
					$strSql = str_replace("_ID", $row[$Show[$i]['name']], $strSql);
					$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
					$row1 = mysql_fetch_array($result1);
					echo "<option value='$row1[ID]' selected>$row1[Display]</option>\n";
				}			
				if($SearchString!="") {
					$strSql = $Show[$i]['selectsql'];
					$strSql = str_replace("_Search", $SearchString, $strSql);
					if($row[$Show[$i]['name']]!="")
						$strSql .= " AND $primaryKey!='".$row[$Show[$i]['name']]."'";
					
					$result1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
					$num1 = mysql_num_rows($result1);
					if($num1!=0) {
						if($row[$Show[$i]['name']]=="") {
							echo "<option value='0' selected>(bitte ausw&auml;hlen)</option>";
						}
						for($j=0;$j<$num1;$j++) {
							$row1 = mysql_fetch_array($result1);
							echo "<option value='$row1[ID]'>$row1[Display]</option>\n";
						}
					} else {
						echo "<option value='0' selected>(nichts gefunden)</option>";
					}					
				} else {
					if($row[$Show[$i]['name']]=="")
						echo "<option value='0' selected>(bitte such-funktion starten)</option>";
				}
				echo "</select>
				<script language='Javascript'>
				self.document.frmEdit." . $Show[$i]['name'] . "Search.focus();
				</script>";				
				break;
			case "icq":
			case "aim":
			case "link":
			case "text":
			case "edittext":
			case "username":
			case "email":
			case "url":
				echo "<input type='text' name='" . $Show[$i]['name'] . "' size='" . $Show[$i]['prop'] . "' value=\"";
				if($action=="edit") echo htmlspecialchars($row[$Show[$i]['name']]);
				if($action=="add") echo htmlspecialchars($Show[$i]['def']);
				echo "\"" . $Show[$i]['tags'] . ">\n";
				break;
			case "static";				
				if($action=="edit") echo htmlspecialchars($row[$Show[$i]['name']]);
				break;
			case "sqlfunc":
				$strSql = $Show[$i]['sqlstr'];
				$strSql = str_replace("_ID", $row[$primaryKey], $strSql);
				$resultfunc = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$x=mysql_fetch_row($resultfunc);
				echo $x[0];
				break;
			case "func";
				echo call_user_func($Show[$i]['func'], $row[$primaryKey]);
				break;
			case "funcall":
				echo call_user_func($Show[$i]['func'], $row[$primaryKey],$action);
				break;
			case "textfield":
				echo "<textarea name='" . $Show[$i]['name'] . "' " . $Show[$i]['prop'] . "" . $Show[$i]['tags'] . ">";
				if($action=="edit") echo htmlspecialchars($row[$Show[$i]['name']]);
				if($action=="add") echo htmlspecialchars($Show[$i]['def']);
				echo "</textarea>";
				break;
			case "pass":			
                if($action=="edit") {
                    echo "      <input type='radio' name='change" . $Show[$i]['name'] . "' value='0' checked>$strEditDontChange<br>\n";
                    echo "      <input type='radio' name='change" . $Show[$i]['name'] . "' value='1'>$strEditChange<br>\n";
                    echo "\n        <table>\n";
                    echo "          <tr>\n";
                    echo "              <td align='right'>$strEditPass:</td>\n";
                    echo "              <td><input type='password' name='" . $Show[$i]['name'] . "' size='" . $Show[$i]['prop'] . "' value=''" . $Show[$i]['tags'] . ">\n";
                    echo "          </tr>\n";
                    echo "          <tr>\n";
                    echo "              <td align='right'>$strEdirRepPass:</td>\n";
                    echo "              <td><input type='password' name='" . $Show[$i]['name'] . "rep' size='" . $Show[$i]['prop'] . "' value=''>\n";
                    echo "          </tr>\n";
                    echo "      </table>\n";
                    echo "  </td>\n";
                    echo "</tr>\n";
                } else {
                    echo "<input type='password' name='" . $Show[$i]['name'] . "' size='" . $Show[$i]['prop'] . "' value=''" . $Show[$i]['tags'] . ">\n";
                    echo "  </td>\n";
                    echo "</tr>\n";
                    echo "<tr class='";
                    if($cls++%2) echo "row1"; else echo "row2";
                    echo "'>\n";
                    echo "  <td align='right'>";
                    echo "<b>$strEdirRepPass: </b>";      
                    echo "</td>\n";
                    echo "  <td>";
                    echo "<input type='password' name='" . $Show[$i]['name'] . "rep' size='" . $Show[$i]['prop'] . "' value=''>\n";
                }
				break;
			case "imagesize":
				if($action=="edit") $val = $row[$Show[$i]['name']];
				if($action=="add") $val = $Show[$i]['def'];
				if(preg_match('#^([0-9]+)x([0-9]+)([a-z]*)$#', $val, $m)) {
					$val = array();
					$val['width'] = $m[1];
					$val['height'] = $m[2];
					if($m[3]=='crop') {
						$val['crop'] = true;
					} else {
						$val['crop'] = false;
					}
				} else {
					$val = array();
					$val['width'] = "";
					$val['height'] = "";
					$val['crop'] = false;
				}
				echo "      <input type='text' name='width" . $Show[$i]['name'] . "' value='$val[width]' size='2'> x ";
				echo "      <input type='text' name='height" . $Show[$i]['name'] . "' value='$val[height]' size='2'> px<br>\n";
				echo "      <input type='checkbox' name='crop" . $Show[$i]['name'] . "' value='1' ";
				if($val['crop']) echo " checked";
				echo "> Crop Image (if wrong aspect ratio)\n";
				break;
			case "file":
				if($action=="edit")
					$Sel = $row[$Show[$i]['name']];
				else
					$Sel = $Show[$i]['def'];
				if($Sel=="") $Sel = $Show[$i]['def'];
				
				if(!isset($Show[$i]['filt']))
					$Filt = "";
				else
					$Filt = $Show[$i]['filt'];

				echo "<SELECT NAME='" . $Show[$i]['name'] . "'" . $Show[$i]['tags'] . ">\n";
				$d = dir($Show[$i]['prop']);
				while($entry=$d->read()) {
					if(filetype($Show[$i]['prop'] . $entry)!="file") continue;
					if($Filt!="") {
						if(strstr($entry,$Filt)!=$Filt) continue;
						$entry = substr($entry, 0, strlen($entry)-strlen($Filt));
					}
					if(isset($Show[$i]['hideval']))
						if(in_array($entry, $Show[$i]['hideval'])) continue;

					echo "<option value=\"" . $entry . "\"";
					if($Sel==$entry) echo " selected";
					echo ">";
					echo $entry;
					echo "</option>\n";
				}
				$d->close();
				echo "</SELECT>\n";
				break;
			case "listbox":
			case "editlistbox":
				$Sel="";
				if($action=="edit")
					$Sel = $row[$Show[$i]['name']];
				else {					
					$Sel = $Show[$i]['def'];
				}	
				
				if(isset($Show[$i]['delemiter']))
					$delem = $Show[$i]['delemiter'];
				else 
					$delem = ";";

				echo "\n		<select name='" . $Show[$i]['name'] . "'" . $Show[$i]['tags'] . ">\n";
				$prop = explode($delem, $Show[$i]['prop']);
				$val = explode($delem, $Show[$i]['values']);
				for($j=0;$j<sizeof($prop);$j++) {
					echo "			<option value='" . $val[$j] . "'";
					if($Sel==$val[$j]) echo " selected";
					echo ">" . $prop[$j] . "</option>\n";
				}
				echo "		</select>\n";
				break;
            case "listboxmulti":
                $Sel="";
                if($action=="edit") {
                    $strSql = "SELECT {$Show[$i]['fieldVal']} FROM {$Show[$i]['table']} WHERE {$Show[$i]['fieldKey']}='$ID'";
                    $q1 = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    $Sel = array();
                    while($r1=mysql_fetch_row($q1)) {
                      $Sel[] = $r1[0];
                    }
                } else {                  
                    $Sel = $Show[$i]['def'];
                }
                if(!is_array($Sel)) $Sel = array($Sel);

                if(isset($Show[$i]['delemiter']))
                    $delem = $Show[$i]['delemiter'];
                else 
                    $delem = ";";

                echo "\n        <select multiple size=5 name='" . $Show[$i]['name'] . "[]'" . $Show[$i]['tags'] . ">\n";
                $prop = explode($delem, $Show[$i]['prop']);
                $val = explode($delem, $Show[$i]['values']);
                for($j=0;$j<sizeof($prop);$j++) {
                    echo "          <option value='" . $val[$j] . "'";
                    if(in_array($val[$j], $Sel)) echo " selected";
                    echo ">" . $prop[$j] . "</option>\n";
                }
                echo "      </select>\n";
                break;
            case "editcheckbox":
			case "checkbox":
				if($action=="edit")
					$Sel = $row[$Show[$i]['name']];
				else
					$Sel = $Show[$i]['def'];
				if($Sel=="") $Sel = $Show[$i]['def'];

				$val=explode(";",$Show[$i]['prop']);
				echo "<INPUT TYPE='checkbox' NAME='" . $Show[$i]['name'] . "' value='set'" . $Show[$i]['tags'] . "";
				if($Sel==$val[0]) echo " checked";
				echo ">";
				break;
			case "date":  //im format yyyy-mm-dd (wie in mysql..)
				if($action=="edit")
					$Sel = $row[$Show[$i]['name']];
				else
					$Sel = $Show[$i]['def'];
				PrintDateInput($Show[$i]['name'], $Sel);
				break;
			case "staticlink":
				$Dat = str_replace("_ID",$row[$primaryKey],$Show[$i]['prop']);
				echo "<a href='$Dat' " . $Show[$i]['tags'] . ">" . $Show[$i]['text'] . "</a>\n";
				break;
			case "sqlfunc":
				$strSql = $Show[$i]['sqlstr'];
				$strSql = str_replace("_ID", $row[$primaryKey], $strSql);
				$resultfunc = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
				$x=mysql_fetch_row($resultfunc);
				echo $x[0];
				break;
			case "func":
				echo call_user_func($Show[$i]['func'], $row[$primaryKey]);
				break;
			default:
				echo "ERROR: invalid Show-typ (" . $Show[$i]['type'] . ")";
		} //end switch type
		echo "</td>\n";
		echo "</tr>\n";
	} //end for
	echo "<tr class='row1'>\n";
	echo "	<td></td>\n";
	echo "	<td><INPUT TYPE='submit' value='";
	echo $SaveButtonText;
	echo "'>";
    //echo " &nbsp; <INPUT TYPE='reset'>";
    echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";
	echo "</form>";
	break;
case "delpass":
	echo "<h1>$strEditDelete $Title</h1>\n";
	echo $strEditDeleteReally."<br><br>
	<FORM METHOD=POST ACTION='$FILE_SELF".$GlobalArg."Display=$Display&action=delsavepass&ID=$ID&F=$FilterVal'>
		$strEnterYourPassword<br>
		<INPUT TYPE='password' NAME='pass'>
		<INPUT TYPE='submit'>
	</FORM>";
	break;
case "del":
	echo "<h1>$strEditDelete $Title</h1>\n";
	echo "$strEditDelSure<br>\n";
	echo "<a href='$FILE_SELF".$GlobalArg."Display=$Display&action=delsave&ID=$ID&F=$FilterVal'>$strYes</a> - <a href='$FILE_SELF".$GlobalArg."Display=$Display&action=&F=$FilterVal'>$strNo</a>";
	break;
case "delsavepass":
case "delsave":
	$strSql = "SELECT * FROM $Table WHERE $primaryKey='$ID'";
	$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
	$row = mysql_fetch_array($result);

	if($action=="delsavepass") {
		if(md5($pass) != $row['pass'])
			ErrorExit($strWrongPasswordEntered);
	}

	$strSql = "DELETE FROM $Table WHERE $primaryKey='$ID'";
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);	
    echo "$Title $strDelSucc";
	break;
case "editsave":
case "addsave":
	if($action=="editsave") {
		$strSql = "SELECT * FROM $Table WHERE $primaryKey='$ID'";
		$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
		$num = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
	}
	for($i=0;$i<count($Show);$i++) {
		if($Show[$i]['newonly'] && $action=="editsave") //dieses eine berspringenw wenn im edit-modus
			continue;
        if($Show[$i]['hidenew'] && $action=="addsave")
            continue;
		if(!isset($_POST[$Show[$i]['name']])) $_POST[$Show[$i]['name']]=$Show[$i]['def'];
		switch($Show[$i]['type']) {
			case "username":
				if($_POST[$Show[$i]['name']]=="")					
					ErrorExit(str_replace("%field%", $Show[$i]['text'], $strEditNoEntry));
				eregi("[a-zA-Z0-9]+", $_POST[$Show[$i]['name']], $Dat);
				if($_POST[$Show[$i]['name']]!=$Dat[0])
					ErrorExit(str_replace("%field%", $Show[$i]['text'], $strEditInvalidEntry));
			case "icq":
			case "aim":
			case "link":
			case "text":
			case "edittext":
			case "textfield":
				if(isset($Show[$i]['invalid'])) {
					$Dat = explode(";",strtolower($Show[$i]['invalid']));
                    if(in_array(strtolower($_POST[$Show[$i]['name']]), $Dat))
                        ErrorExit($Show[$i]['text'] . ": " . $strEditInvalidText);
				}
                if($Show[$i]['uniq']) { //check if unique
                    if($Filter!="")
                        $strSql = "SELECT * FROM $Table WHERE $Filter=$FilterVal AND ";
                    else
                        $strSql = "SELECT * FROM $Table WHERE ";
                    $strSql .= $Show[$i]['name'] . " LIKE '" . $_POST[$Show[$i]['name']] . "'";
                    if($action=="editsave")
                        $strSql .= " AND $primaryKey!='$ID'";
                    $result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                    if(mysql_num_rows($result)>0)
                        ErrorExit(str_replace("%user%", $Show[$i]['text'], $strEditUniqueError));
                }
				break;
			case "email":
                
				if($Show[$i]['uniq']) { //check if unique            
					if($Filter!="")
						$strSql = "SELECT * FROM $Table WHERE $Filter=$FilterVal AND ";
					else
						$strSql = "SELECT * FROM $Table WHERE ";
					$strSql .= $Show[$i]['name'] . " LIKE '" . $_POST[$Show[$i]['name']] . "'";
					if($action=="editsave")
						$strSql .= " AND NOT ($primaryKey = '{$row[$primaryKey]}')";
					$result = pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
					if(mysql_num_rows($result)>0)
						ErrorExit(str_replace("%user%", $Show[$i]['text'], $strEditUniqueError));
				}
				if(!CheckIfEmail($_POST[$Show[$i]['name']]))
					ErrorExit($strEditInvalidEmail);
				break;
			case "url":
				//2do CHECK IF VALID URL
				break;
			case "pass":
				$var = "change" . $Show[$i]['name'];
				if($action!="addsave" && $_POST[$var]!="1") { //don't change pass adress
					$_POST[$Show[$i]['name']]=$row[$Show[$i]['name']];
				} else {
					$var = $Show[$i]['name'] . "rep";
					if($_POST[$Show[$i]['name']]!=$_POST[$var])
						ErrorExit($strEditPassMatch);
					if($_POST[$Show[$i]['name']]=="")
						ErrorExit($strEditNoPass);
					if(strlen($_POST[$Show[$i]['name']])<5)
						ErrorExit($strEditShortPass);
					$_POST[$Show[$i]['name']] = md5($_POST[$Show[$i]['name']]);
				}
				break;
			case "imagesize":
				if($_POST['width'.$Show[$i]['name']]!="" && !is_numeric($_POST['width'.$Show[$i]['name']])) {
					$_POST['width'.$Show[$i]['name']] = 0;
				}
				if($_POST['height'.$Show[$i]['name']]!="" && !is_numeric($_POST['height'.$Show[$i]['name']])) {
					$_POST['height'.$Show[$i]['name']] = 0;
				}
				if($_POST['height'.$Show[$i]['name']]!="" && $_POST['width'.$Show[$i]['name']]!="")
				{
					$Dat = $_POST['width'.$Show[$i]['name']]."x".$_POST['height'.$Show[$i]['name']];
					if(isset($_POST['crop'.$Show[$i]['name']])) {
						$Dat .= "crop";
					}
				} else {
					$Dat = "";
				}
				$_POST[$Show[$i]['name']] = $Dat;
				break;
			case "file":
				break;
			case "listbox":
			case "editlistbox":
				break;
            case "listboxmulti":
                $strSql = "DELETE FROM {$Show[$i]['table']} WHERE {$Show[$i]['fieldKey']}='$ID'";
                pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                foreach($_POST[$Show[$i]['name']] as $val) {
                    $strSql = "INSERT INTO {$Show[$i]['table']} ({$Show[$i]['fieldKey']}, {$Show[$i]['fieldVal']}) VALUES ('$ID', '$val')";
                    pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
                }
                break;
            case "editcheckbox":
			case "checkbox":
				$val=array();
				$val=explode(";",$Show[$i]['prop']);
				if(!isset($_POST[$Show[$i]['name']]))
					$_POST[$Show[$i]['name']] = "";
				if($_POST[$Show[$i]['name']]=="set")
					$_POST[$Show[$i]['name']] = $val[0];
				else
					$_POST[$Show[$i]['name']] = $val[1];				
				break;
			case "hidden":
				$_POST[$Show[$i]['name']] = $Show[$i]['def'];
				break;
			case "date":
				$Dat = $Show[$i]['name']."Year";
                if(!isset($_POST[$Dat])) $_POST[$Dat]="0000";
				$_POST[$Show[$i]['name']] = $_POST[$Dat] . "-";
				$Dat = $Show[$i]['name']."Mon";
                if(!isset($_POST[$Dat])) $_POST[$Dat]="00";
				$_POST[$Show[$i]['name']] .= $_POST[$Dat] . "-";
				$Dat = $Show[$i]['name']."Day";
                if(!isset($_POST[$Dat])) $_POST[$Dat]="00";
				$_POST[$Show[$i]['name']] .= $_POST[$Dat];
				break;
			case "funcall":
				echo call_user_func($Show[$i]['func'], $row[$primaryKey],$action);
				break;
			case "func":
			case "static":
			case "staticlink":
			case "sqlfunc":
			case "select":			
				break; //ignore
			default:
				echo "ERROR: invalid Show-typ (" . $Show[$i]['type'] . ")";
		}
	} //end for
	if($action=="editsave") {
		$strSql = "UPDATE $Table SET ";
		for($i=0;$i<sizeof($Show);$i++) {
			if($Show[$i]['newonly']) //dieses eine berspringenw wenn im edit-modus
				continue;
			if(!$Show[$i]['save'])
				continue;
            if($Show[$i]['type']=="funcall")
				continue;
            if($Show[$i]['type']=="listboxmulti")
                continue;
			$strSql .= $Show[$i]['name'] . "='" . ($_POST[$Show[$i]['name']]) . "', ";
		}
		$strSql = substr($strSql, 0, -2);
		$strSql .= " WHERE $primaryKey='$ID'";
	} else {  //endif
		$strSql = "INSERT INTO $Table (";
		for($i=0;$i<sizeof($Show);$i++) {			
			if(!$Show[$i]['save'])
				continue;
			if($Show[$i]['type']=="funcall")
				continue;
            if($Show[$i]['type']=="listboxmulti")
                continue;
			$strSql .= $Show[$i]['name'] . ", ";
		}
		if($Filter!="")
			$strSql .= $Filter;
		else
			$strSql = substr($strSql, 0, -2);		
		if(isset($SortOrderField))
			$strSql .= ", $SortOrderField";

		$strSql .= ") VALUES (";
		for($i=0;$i<sizeof($Show);$i++) {
			if(!$Show[$i]['save'])
				continue;			
			if($Show[$i]['type']=="funcall")
				continue;
            if($Show[$i]['type']=="listboxmulti")
                continue;
			$strSql .= "'" . ($_POST[$Show[$i]['name']]) . "', ";
		}
		if($Filter!="")
			$strSql .= "'" . $FilterVal . "'";
		else
			$strSql = substr($strSql, 0, -2);

		if(isset($SortOrderField)) {
			$strSql1 = "SELECT $SortOrderField FROM $Table";
			if($Filter!="")
				$strSql1 .= " WHERE $Filter=$FilterVal";
			$strSql1 .= " ORDER BY $SortOrderField DESC LIMIT 1";
			$q=pml_mysql_query($strSql1, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
			if(mysql_num_rows($q)==0)
				$NewSortOrder = 1;
			else {
				$row = mysql_fetch_row($q);
				$NewSortOrder = $row[0] + 1;
			}
			$strSql .= ",'$NewSortOrder'";
		}
		$strSql .= ")";
	
	} //end else
	//echo $strSql;
	pml_mysql_query($strSql, $pmldb) or trigger_error("can't execute:<pre>$strSql</pre><i>".mysql_error($pmldb)."</i>",E_USER_ERROR);
    if($CFG['Debug']) echo $strSql."<br>\n";
	if($action=="addsave") {
		$ID = mysql_insert_id();
	}

	if(isset($_POST['search'])) {
		$_GET['action']="edit";
		if($action=="addsave")
			$_GET['ID']=mysql_insert_id();
		else
			$_GET['ID']=$ID;
		include("edit.php");		
	} else {
		echo "$strEditSaved<br>\n";
	}
	//echo "<br><a href='$FILE_SELF".$GlobalArg."Display=$Display&action=&F=$FilterVal'>continue</a>\n";
	//echo "<br><a href='$FILE_SELF".$GlobalArg."Display=$Display&action=add&F=$FilterVal'>neuen $Title hinzuf&uuml;gen</a>\n";
	break;
default:
	ErrorExit("invalid action");
	break;
}

$_SESSION[$SessionVar] = $SessVar; //save the session-variable

?>