<?php
/** powermovielist Edit Language-Files
 * $Id: editlang.php,v 1.3 2005/10/02 09:13:59 niko Exp $
*/
$FILE_SELF = "editlang.php";
include_once("application.php");

//header("Content-Type: text/plain");

RequestLogin(PML_LoginStyle_AccessDenied, PML_Rights_SuperAdmin);

if(isset($_GET['action'])) $action = $_GET['action']; else $action = "";

$DOC_TITLE = "LanguageFileEditor";
include("top.html");



//ReadLangaugeFiles:
$i=0;
$d = dir("lang/");
while($entry=$d->read()) {
	if(filetype("lang/" . $entry)!="file") continue;
	if(substr($entry,-8)!=".inc.php") continue;
	$LngLines[$entry] = ReadLanguageFile("lang/" . $entry);
	$i++;

}
$d->close();

//ReadCodeFiles:
ReadLangStringsFromDir("./");
ReadLangStringsFromDir("fetch/");
ReadLangStringsFromDir("userclass/");

if($action=="checksyntax") {
    echo "<h1>checking syntax for all langauge files</h1>\n";
    ini_set("track_errors", 1);
    foreach($LngLines as $Dat=>$x) {
        if(!@include("lang/$Dat")) {
            echo "<br><font color='red'><b>ERROR in $Dat:</b></font> $php_errormsg\n";
        } else {
            echo "<br>$Dat is OK...\n";
        }
    }    
}


if($action=="lnginfo") {
	$MailInfo = array();
	foreach($LngLines as $key1=>$File) {		
		//$LngFileInfos[$key1] = array();
		foreach($File as $key2=>$Line) {
			if($Line['type']==1) {
				$LngFileInfos[$key1][key($Line['info'])] = current($Line['info']);
				if(key($Line['info'])=="Mail") {
					$MailInfo[] = current($Line['info']);
				}
			}
		}
	}
	echo "Translator-emails: " . implode($MailInfo, ", ");
	echo "<pre>";
	print_r($LngFileInfos);
	echo "</pre>";
}

if($action=="checklinedata") {
	echo "checking internal variables... please wait<br><br>"; flush();
	foreach($LngLines as $key1=>$File) {		
		foreach($File as $key2=>$Line) {
			if(!is_numeric($Line['line']))
				echo "error found! (LngLines[$key1][$key2]): $Line[line]<br>";
		}
	}
}


if($action=="searchentry") {
	echo "searching for '$_POST[inSearch]'...<br>\n";
	$found=false;
	foreach($LngLines['english.inc.php'] as $Line) {
		if(eregi($_POST['inSearch'],$Line['data'])) {
			echo "$Line[line]: $Line[data]<br>\n";
			$found=true;
		}
	}
	if(!$found)
		echo "nothing found :(<br>";

	$action=""; //display menu
}


if($action=="addentry") {
	foreach($LngLines['english.inc.php'] as $Line) {
		if($Line['type']==3) {
			if($Line['name']==$_POST['inStringName'])
				ErrorExit("this string-name exists allerady (line $Line[line] english.inc.php)<br>".$Line['data']);
		}

	}

	$Dat = "\$str" . $_POST['inStringName']. " = '". $_POST['inText'] ."';	//to translate";
	echo "new line: $Dat<br>";
	foreach($LngLines as $key=>$File) {
		end($LngLines[$key]);
		$LngLines[$key][]['data'] = $Dat;
	}
	WriteLanguageFiles($LngLines);
	echo "new entry written...<br>";
	$action=""; //display menu
}


if($action=="delentry") {
	if(isset($_POST['inStringName'])) $inStringName = $_POST['inStringName'];
	if(isset($_GET['inStringName'])) $inStringName = $_GET['inStringName'];

	foreach($LngLines as $key1=>$File) {
		$found=0;
		foreach($File as $key2=>$Line) {
			if($Line['type']==3) {
				if($Line['name']==$inStringName) {
					unset($LngLines[$key1][$key2]);
					$found++;
				}
			}
		}
		echo "$key1: $found times removed<br>\n";
	}
	WriteLanguageFiles($LngLines);
	echo "new files written...<br>";
	$action=""; //display menu

}

if($action=="addtext") {
	$Dat = split("\n",stripslashes($_POST['inText']));
	foreach($LngLines as $key=>$File) {
		end($LngLines[$key]);
		foreach($Dat as $x) {
			$LngLines[$key][]['data'] = trim($x,"\n\r");
		}
	}
	WriteLanguageFiles($LngLines);
	echo "new text written...<br>";
	$action=""; //display menu

}

if($action=="checkdouble") {
	echo "checking for double-entries... please wait<br>";
	flush();
	foreach($LngLines as $File) {
		echo "<br><br><b>checking file: " . $File[0]['filename'] . "</b><br><br>"; flush();
		foreach($File as $Line) {
			if($Line['type']==3) {
				foreach($File as $x) {
					if($x['type']==3) {
						if($x['name']==$Line['name'] && $x['line']!=$Line['line'] && substr($Line['name'],-2)!="[]") {
							echo "double-entry: str$x[name] in line $x[line] and $Line[line]<br>\n"; flush();
						}
					}
				}
			}
		}
	}
}

if($action=="checkextra") {
	echo "checking for extra-lines... (english.inc.php is the master-file)<br><br>"; flush();
	foreach($LngLines as $File) {
		if($File[0]['filename']=="lang/english.inc.php") continue;
		echo "<br><br><b>checking file: " . $File[0]['filename'] . "</b><br>"; flush();
		foreach($File as $Line) {
			if($Line['type']==3) {
				$Found=false;
				foreach($LngLines['english.inc.php'] as $x) {
					if($x['type']!=3) continue;
					if($x['name']==$Line['name']) {
						$Found=true;
						break;
					}
				}
				if(!$Found) {
					echo "str$Line[name] (line $Line[line]) was not found in english.inc.php!<br>\n"; flush();
				}

			}
		}
	}
}


if($action=="checkmissing") {
	echo "checking for missing-lines... (english.inc.php is the master-file)<br><br>"; flush();
	foreach($LngLines as $File) {
		if($File[0]['filename']=="lang/english.inc.php") continue;
		echo "<br><br><b>checking file: " . $File[0]['filename'] . "</b><br>"; flush();
		foreach($LngLines['english.inc.php'] as $x) {
			if($x['type']!=3) continue;
			$Found=false;
			foreach($File as $Line) {
				if($Line['type']!=3) continue;
				if($x['name']==$Line['name']) {
					$Found=true;
					break;
				}
			}
			if(!$Found) {
				echo "str$x[name] (line $x[line] (english.inc.php)) was not found!<br>\n"; flush();
			}			
		}
	}
}


if($action=="checkunused") {
	echo "checking for unused entries... (only english.inc.php)<br><br>"; flush();
	foreach($LngLines['english.inc.php'] as $x) {
		if($x['type']==3) {
			$Found=false;
			foreach($CodeLines as $File) {			
				foreach($File as $Line) {
					if(!isset($Line['name']))
						continue;
					if($x['name']==$Line['name']) {
						$Found=true;
						break;
					}
					if(isset($x['arrayname'])) {
						if($x['arrayname']==$Line['name']) {
							$Found=true;
							break;
						}
					}
				}
			}
			if(!$Found) {
				echo "str$x[name] (line $x[line] (english.inc.php)) was never used! <a href='editlang.php?action=delentry&inStringName=$x[name]'>remove</a><br>\n"; flush();
			}

		}
	}
}



if($action=="checkmissingcode") {
	echo "checking for missing strings... (only english.inc.php)<br><br>"; flush();
	foreach($CodeLines as $File) {			
		foreach($File as $Line) {
			$Found=false;
			reset($LngLines['english.inc.php']);
			foreach($LngLines['english.inc.php'] as $x) {
				if($x['type']==3) {
					if(!isset($Line['name']))
						continue;
					if($x['name']==$Line['name']) {
						$Found=true;
						break;
					}
					if(isset($x['arrayname'])) {
						if($x['arrayname']==$Line['name']) {
							$Found=true;
							break;
						}
					}
				}
			}
			if(!$Found && isset($Line['name'])) {
				echo $File[0]['filename'] . ": str$Line[name] (line $Line[line]) was not defiend in english.inc.php!<br>\n"; flush();
			}
		}
	}
}



if($action!="") {
	echo "<br><br><a href='editlang.php'>LanguageFileEditor menu</a><br><br>\n";
} else {
echo "<h1>LanguageFileEditor</h1>
<h2>last 10 lines from english.inc.php</h2>
";

$out="";

end($LngLines['english.inc.php']);
for($i=0;$i<10;$i++) 
	prev($LngLines['english.inc.php']);

for($i=0;$i<10;$i++) {
	$x = next($LngLines['english.inc.php']);
	$out .= $x['data']."\n";
}
highlight_string("<?php $out?>");

echo "
<h2>search for entry (in english.inc.php)</h2>
<FORM METHOD=POST ACTION='editlang.php".$GlobalArg."action=searchentry'>
<table>
<tr class=row1>
	<td align=right>Search-Text</td>
	<td><INPUT TYPE='text' NAME='inSearch'></td>
</tr>
<tr class=row2>
	<td>&nbsp;</td>
	<td><INPUT TYPE='submit' value='search entry'> <INPUT TYPE='reset'></td>
</tr>
</table>
</FORM>
<h2>add entry to all language-files</h2>
<FORM METHOD=POST ACTION='editlang.php".$GlobalArg."action=addentry'>
<table>
<tr class=row1>
	<td align=right>String-Name</td>
	<td>\$str<INPUT TYPE='text' NAME='inStringName'></td>
</tr>
<tr class=row2>
	<td align=right>Text</td>
	<td><INPUT TYPE='text' NAME='inText' size=100></td>
</tr>
<tr class=row1>
	<td>&nbsp;</td>
	<td><INPUT TYPE='submit' value='add entry'> <INPUT TYPE='reset'></td>
</tr>
</table>
</FORM>

<h2>add text to all language-files</h2>
<FORM METHOD=POST ACTION='editlang.php".$GlobalArg."action=addtext'>
<table>
<tr class=row1>
	<td align=right>Text</td>
	<td><TEXTAREA NAME='inText' ROWS='10' COLS='100'></TEXTAREA></td>
</tr>
<tr class=row2>
	<td>&nbsp;</td>
	<td><INPUT TYPE='submit' value='add text'> <INPUT TYPE='reset'></td>
</tr>
</table>
</FORM>

<h2>remove entry from all language-files</h2>
<FORM METHOD=POST ACTION='editlang.php".$GlobalArg."action=delentry'>
<table>
<tr class=row1>
	<td align=right>String-Name</td>
	<td>\$str<INPUT TYPE='text' NAME='inStringName'></td>
</tr>
<tr class=row2>
	<td>&nbsp;</td>
	<td><INPUT TYPE='submit' value='remove entry'> <INPUT TYPE='reset'></td>
</tr>
</table>
</FORM>

<h2>translate</h2>
to translate the files, just open them with a text editor and translate everything that is still in english...

<h2>file-check-functions</h2>
<a href='editlang.php".$GlobalArg."action=checkdouble'>check for doubles (entries with the same name in one langauge-file)</a><br>
<a href='editlang.php".$GlobalArg."action=checkextra'>check extra strings (all files compared with english.inc.php)</a><br>
<a href='editlang.php".$GlobalArg."action=checkmissing'>check missing strings (all files compared with english.inc.php)</a><br>
<a href='editlang.php".$GlobalArg."action=checkunused'>check for unused strings (only english.inc.php)</a><br>
<a href='editlang.php".$GlobalArg."action=checkmissingcode'>check for missing strings in langauge-file (only english.inc.php)</a><br>
<a href='editlang.php".$GlobalArg."action=checklinedata'>check internal used line-data</a><br>
<a href='editlang.php".$GlobalArg."action=lnginfo'>print additional langauge-file-infos</a><br>
<a href='editlang.php".$GlobalArg."action=checksyntax'>check syntax for all files</a><br>
";
}









include("bottom.html");





function ReadLanguageFile($FileName) {
	$Dat=file($FileName) or ErrorExit("can't open $FileName");
	$i=0;
	$Line[0]['filename']=$FileName;
	$EndFound=false;
	foreach($Dat as $x) {
		$x=trim($x,"\n\r");
		if($EndFound && trim($x)!="")
			ErrorExit("lines below ?&gt; found! you can use only one at the end of the file...");
		if($EndFound)
			continue;
		if(strstr($x,"?>")) {
			$EndFound=true;
		} else {
			$Line[$i]['data'] = $x;
			$Line[$i]['line'] = $i+1;
			if(ereg("\\\$str([^=]+)=",$x,$reg)) {
//				$Line[$i]['val'] = $reg[3];
				$Line[$i]['name'] = trim($reg[1]);
//				$Line[$i]['comment'] = $reg[5];
				$Line[$i]['type'] = 3;
				if(ereg("([^[]*)\\[",$Line[$i]['name'],$reg)) {
					$Line[$i]['arrayname']=$reg[1];			
				}
			} else {
				if(ereg("\\\$Lng([^=]+)= ?('|\")([^'^\"]*)('|\");",$x,$reg)) {
					$Line[$i]['info'][trim($reg[1])] = $reg[3];
					$Line[$i]['type'] = 1;
				} else
					$Line[$i]['type'] = 2;
			}
			$i++;
		}
	}
	return($Line);
}


function WriteLanguageFiles($LngFiles) {
	foreach($LngFiles as $File) {
		$Content = "";
		foreach($File as $Line) {
			$Content .= $Line['data'] . "\n";
		}
		$Content .= "?>";
		$fp = fopen ($File[0]['filename']."", "w");
			fwrite($fp, $Content);
		fclose($fp);
	}
}



function ReadLangStrings($FileName) {
	$Dat=file($FileName) or ErrorExit("can't open $FileName");
	$i=0;
	$linec=1;
	$Line[0]['filename']=$FileName;
	foreach($Dat as $x) {
		$lin = $x;
		while(ereg("\\\$str([a-zA-Z0-9]+)",$lin,$reg)) {
			$lin = substr($lin,strpos($lin, "\$str$reg[1]")+strlen($reg[1])+4);
			if($reg[1]=="Sql") continue;
			$Line[$i]['line'] = $linec;
			$Line[$i]['name'] = $reg[1];			
			$i++;
		}
		$lin = $x;
		while(ereg("GLOBALS\[\'?str([a-zA-Z0-9]+)\'?\]",$lin,$reg)) {
			$lin = substr($lin,strpos($lin, "GLOBALS['str$reg[1]']")+strlen($reg[1])+4);
			$lin = substr($lin,strpos($lin, "GLOBALS[str$reg[1]]")+strlen($reg[1])+4);
			$Line[$i]['line'] = $linec;
			$Line[$i]['name'] = $reg[1];
			$i++;
		}
		$linec++;
	}
	return($Line);
}


function ReadLangStringsFromDir($Dir) {
global $CodeLines;
    $i=0;
    $d = dir($Dir);
    while($entry=$d->read()) {
        if(filetype($Dir.$entry)!="file") continue;
        if(substr($Dir.$entry,-3)!="php") continue;
        $CodeLines[$Dir.$entry] = ReadLangStrings($Dir.$entry);
        $i++;

    }
    $d->close();
}

?>