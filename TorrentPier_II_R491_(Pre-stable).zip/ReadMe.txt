********************
**   Установка    **
********************

Распаковываем на сервер содержимое папки upload.
Заходим в phpmyadmin, открываем или создаём новую базу, потом импортируем дамп (install/sql/mysql.sql)
Правим файл конфигурации config.php (изменяем данные входа в БД, остальное по усмотрению)

* Файлы favicon.ico (меняем на свою иконку, если есть), robots.txt(допуск или запрет ботам поисковиков к серверу, блокирует не все, меняем адреса в строках Host: и Sitemap: на свои адреса)

************************************
** Права доступа на папки и файлы **
************************************

Устанавливаем права доступа на данные папки 777, на файлы внутри этих папок (кроме .htaccess) 666:
- ajax
- ajax/html 
- images
- images/avatars
- images/avatars/gallery
- images/captcha
- images/logo
- images/ranks
- images/smiles
- cache
- cache/filecache
- cache/filecache/bb_cache
- cache/filecache/datastore
- cache/filecache/session_cache
- files
- files/thumbs
- log
- pictures
- triggers

************************************
** Необходимые значения в php.ini **
************************************

mbstring.internal_encoding = UTF-8
magic_quotes_gpc = Off

************************************
** Необходимые модули для php **
************************************

php5-tidy
php5-sqlite

************************************
** Необходимый запуск cron.php    **
************************************

Подробнее в теме http://torrentpier.me/threads/Отвязка-запуск-крона.52/