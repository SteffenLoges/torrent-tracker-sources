#include "stdafx.h"
#include "stream_writer.h"
