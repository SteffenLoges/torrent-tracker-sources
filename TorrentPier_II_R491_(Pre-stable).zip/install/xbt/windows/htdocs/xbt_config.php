<?php
	$mysql_host = 'localhost';
	$mysql_user = 'user';
	$mysql_pass = 'user';
	$mysql_db = 'forum';
?>
