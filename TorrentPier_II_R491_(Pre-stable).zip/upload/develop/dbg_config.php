<?php

// Open file in Editor
$bb_cfg['dbg']['interpreter'] = 'cmd.exe /c START';
$bb_cfg['dbg']['editor_path'] = 'D:\Programs\TextPad\TextPad.exe';
$bb_cfg['dbg']['editor_args'] = '%s(%s)'; // %s - file_to_open path, %s - line number

