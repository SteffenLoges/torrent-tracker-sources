<?php

define('START_CRON', true);
define('BB_ROOT', dirname ( __FILE__ ) . '/');

require(BB_ROOT. 'common.php');