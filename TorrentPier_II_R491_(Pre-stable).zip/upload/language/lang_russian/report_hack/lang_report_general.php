<?php

//
// Module information
//
$lang['MODULE_TITLE'] = 'Общие нарушения';
$lang['MODULE_EXPLAIN'] = 'Этот модуль позволяет отправлять команде администраторов и модераторов сообщения о нарушениях в свободной форме.';

//
// Language variables
//
$lang['REPORT_LIST_TITLE'] = 'Общие нарушения';
$lang['REPORT_TYPE'] = 'Общие нарушения';

$lang['WRITE_REPORT'] = 'Сообщить о нарушении';
$lang['WRITE_REPORT_EXPLAIN'] = 'Используйте эту форму для отправки сообщения команде администраторов и модераторов.';
$lang['AUTH_WRITE_ERROR'] = 'У вас нет прав для отправки сообщений о нарушениях.';

?>