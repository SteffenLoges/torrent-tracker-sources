<?php

$lang['CALLSEED_SUBJ'] = 'Download help %s';
$lang['CALLSEED_TEXT'] = 'Hello!<br><br>Your help is needed in the release <a href="viewtopic.php?t=%s" target=_blank>%s :: %s </a><br>If you decide to help, but already deleted the torrent file, you can download it <a href="download.php?id=%s">this</a><br><br>I hope for your help!';

$lang['CALLSEED_MSG_OK']   = '<b>Message (PM) has been sent to all those who downloaded this release</b>';
$lang['CALLSEED_MSG_SPAM'] = '<b><font color=red>Request has already been once successfully sent</b> (Probably not you)</font>
			<br><br>The next opportunity to send a request to be <b>%s</b> hours<!-- <b>%s</b> minute -->. <br>
			Call you can download it only once in <b>day</b>';
$lang['CALLSEED_MSG_MSG']  = 'Error sending message';
$lang['CALLSEED_MSG_MSG_TEXT']  = 'Error saving text messages';
$lang['CALLSEED_MSG_POPUP']     = 'Error of popup';
$lang['CALLSEED_MSG_TIME']      = 'Unable to set the last query';
$lang['CALLSEED_HAVE_SEED']    = 'Topic does not require help (<b>Seeders:</b> %d, <b>Leechers:</b> %d)';

$lang['CALLSEED_RETURN'] = '<br><br> <a href="viewtopic.php?t=%s"><b>Back to the topic</b></a>';
