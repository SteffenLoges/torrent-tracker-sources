<?php

require('./announce.php');