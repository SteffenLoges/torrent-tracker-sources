<?php

$lang['TPL']['GUIDE'] = array(
#	LANG_VAR_NAME (that point to $lang['TPL'][LANG_VAR_NAME]) => POST_ID (with guide)
	'title'       => 330880,
	'picture'     => 330951,
	'country'     => 330955,
	'director'    => 330959,
	'genre'       => 330965,
	'playtime'    => 330966,
	'year'        => 330969,
	'translation' => 330970,
	'casting'     => 330972,
	'description' => 330974,
	'moreinfo'    => 330978,
	'format'      => 330980,
	'video'       => 330982,
	'audio'       => 330984,
	'torrent'     => 330985,
);
$lang['TPL']['GUIDE'] = array();