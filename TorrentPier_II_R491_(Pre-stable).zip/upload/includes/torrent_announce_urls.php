<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));

$announce_urls = array();

//
// Here you can define additional allowed announce urls
//
// For example, if you want to add http://site.com/announce.php
// add this line:
// $announce_urls[] = 'http://site.com/announce.php';
//

// $announce_urls[] = 'http://somesite.com/announce';