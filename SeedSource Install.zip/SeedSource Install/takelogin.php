<?

require_once("include/bittorrent.php");

if (!mkglobal("username:password"))
	die();

dbconn();

failedloginscheck ();
function bark($text = " Username or password are incorrect<br>If you don't remember your password <b><a href=recover.php>Recover</a></b> it!")
{
  stderr("Login failed!", $text);
}

$res = mysql_query("SELECT id, passhash, secret, enabled FROM users WHERE username = " . sqlesc($username) . " AND status = 'confirmed'");

$row = mysql_fetch_array($res);

if (!$row)
	failedlogins();

if ($row["passhash"] != md5($row["secret"] . $password . $row["secret"]))
	failedlogins();

if ($row["enabled"] == "no")
 bark("This account has been disabled.");

logincookie($row["id"], $row["passhash"]);


if (!empty($_POST["returnto"]))
	header("Location: $BASEURL$_POST[returnto]");
else
	header("Location: $BASEURL/index.php");

?>