<?
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();
if (get_user_class() < UC_ADMINISTRATOR)
stderr("Sorry", "Access denied.");
$action = (isset($_GET['action']) ? $_GET['action'] : 'showlist');
$id = (isset($_GET['id']) ? $_GET['id'] : '');
function check ($id) {	
	if (!is_valid_id($id))
		return stderr("Error","Invalid ID");
	else
		return true;
}
function safe_query ($query,$id) {
	$query = sprintf("$query WHERE id ='%s'",
	mysql_real_escape_string($id));
	$result = mysql_query($query);
	if (!$result)
		return sqlerr(__FILE__,__LINE__);
	else
		redirect('maxlogin.php');
}
function redirect($url)
{
	if(!headers_sent())
		 header("Location : $url");
	else
		echo "<script language=\"Javascript\">window.location.href = '$url';</script>";
	exit;
} 
if ($action == 'showlist') {
stdhead ("Max. Login Attemps - Show List");
print("<table border=1 cellspacing=0 cellpadding=5 width=737>\n");
$res = mysql_query("SELECT * FROM  loginattempts ORDER BY added DESC") or sqlerr(__FILE__,__LINE__);
if (mysql_num_rows($res) == 0)
	  print("<tr><td colspan=2><b>Nothing found</b></td></tr>\n");
else
{  
  print("<tr><td class=colhead>ID</td><td class=colhead align=left>Ip Address</td><td class=colhead align=left>Action Time</td>".
	"<td class=colhead align=left>Attempts</td><td class=colhead align=left>Status</td></tr>\n");

  while ($arr = mysql_fetch_assoc($res))
  {
	  $r2 = mysql_query("SELECT id,username FROM users WHERE ip=".sqlesc($arr[ip])) or sqlerr(__FILE__,__LINE__);
	  $a2 = mysql_fetch_assoc($r2);	
 	  print("<tr><td align=>$arr[id]</td><td align=left>$arr[ip] " . ($a2[id] ? "<a href=userdetails.php?id=$a2[id]>" : "" ) . " " . ( $a2[username] ? "($a2[username])</a>" : "" ) . "</td><td align=left>$arr[added]</td><td align=left>$arr[attempts]</td><td align=left>".($arr[banned] == "yes" ? "<font color=red><b>banned</b></font> <a href=maxlogin.php?action=unban&id=$arr[id]><font color=green>[<b>unban</b>]</font></a>" : "<font color=green><b>not banned</b></font> <a href=maxlogin.php?action=ban&id=$arr[id]><font color=red>[<b>ban</b>]</font></a>")."  <a onclick=\"return confirm('Are you wish to delete this attempt?');\" href=maxlogin.php?action=delete&id=$arr[id]>[<b>delete</b>]</a></td></tr>\n");
  }
  
}
print("</table>\n");
}elseif ($action == 'ban') {
	check($id);
	stdhead ("Max. Login Attemps - BAN");	
	safe_query("UPDATE loginattempts SET banned = 'yes'",$id);
}elseif ($action == 'unban') {
	check($id);
	stdhead ("Max. Login Attemps - UNBAN");
	safe_query("UPDATE loginattempts SET banned = 'no'",$id);
}elseif ($action == 'delete') {
	check($id);
	stdhead ("Max. Login Attemps - DELETE");
	safe_query("DELETE FROM loginattempts",$id);
	
}else
	stderr("Error","Invalid Action");