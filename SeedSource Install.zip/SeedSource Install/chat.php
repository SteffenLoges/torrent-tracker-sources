<?
require "include/bittorrent.php";
dbconn();
stdhead("Chat");
begin_main_frame();
?>
             <table border="1" cellpadding="5" width="100%">
<tr>
<td class="tablehead">
<font color=white><b>&#187; ShoutBox</b></font>
</td></tr></table>
<script language=javascript>
function winop()
{
windop = window.open("moresmiles.php?form=shbox&text=shbox_text","mywin","height=400,width=450,resizable=yes,scrollbars=yes");
}
</script>
 <script language=javascript>
function SmileIT(smile,form,text){
   document.forms[form].elements[text].value = document.forms[form].elements[text].value+" "+smile+" ";
   document.forms[form].elements[text].focus();
}
function setColor(Color)
			{
				TSInsert('[color='+Color+']', '[/color]', 'shbox', 'shbox_text');
				TSShow_panel('show_colors');
			}

			function TSShow_panel(PanelID)
			{
				if (TSGetID(PanelID).style.display == "none")
				{		
					TSGetID(PanelID).style.display = "inline";
				}
				else
				{
					TSGetID(PanelID).style.display = "none";
				}
			}
			
			

</script>
<table width='100%' border='0' cellspacing='0' cellpadding='5'><tr><td class=text>
<iframe src='shoutbox.php' width='100%' height='330' frameborder='0' name='sbox' marginwidth='0' marginheight='0'></iframe><br><br>
<form action='shoutbox.php' method='get' target='sbox' name='shbox' onsubmit="mySubmit()">
<a href="javascript: SmileIT('[b][/b]','shbox','shbox_text')"><img src=pic/bbcode/text_bold.png width="16" height="16" title="Bold" border=0></a> <a href="javascript: SmileIT('[i][/i]','shbox','shbox_text')"><img src=pic/bbcode/text_italic.png width="16" height="16" title="Italic" border=0></a> <a href="javascript: SmileIT('[u][/u]','shbox','shbox_text')"><img src=pic/bbcode/text_underline.png width="16" height="16" title="Underline" border=0></a>
&nbsp;&nbsp;&nbsp;<a href="javascript: SmileIT('[url][/url]','shbox','shbox_text')"><img src=pic/bbcode/world_go.png width="16" height="16" title="Insert Url" border=0></a> <a href="javascript: SmileIT('[img][/img]','shbox','shbox_text')"><img src=pic/bbcode/picture.png width="16" height="16" title="Insert Picture" border=0></a> <a href="javascript: SmileIT('[quote][/quote]','shbox','shbox_text')"><img src=pic/bbcode/quote.png width="16" height="16" title="Insert Quote" border=0></a> 
<a href="javascript:winop();"><img src=pic/bbcode/emoticon.png width="16" height="16" title="Emoticons" border=0></a>
<br/>
<center>Message: <input type='text' maxlength=180 name='shbox_text' size='100'>  <input type='submit' value='<?="" . Shout . ""?>'> <input type='hidden' name='sent' value='yes'></center>
</td></tr></table></form>   

<?
end_main_frame();
stdfoot();
?>