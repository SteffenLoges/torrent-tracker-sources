<?

require_once("include/bittorrent.php");

dbconn(false);

loggedinorreturn();
parked();

stdhead("Upload Torrent");

if (get_user_class() < UC_UPLOADER)
{
  stdmsg("Sorry...", "You are not authorized to upload torrents.  (You can apply for a <a href=\"uploadapp.php\">Uploader</a> post.)");
  stdfoot();
  exit;
}

if (strlen($CURUSER['passkey']) != 32) {

$CURUSER['passkey'] = md5($CURUSER['username'].get_date_time().$CURUSER['passhash']);

mysql_query("UPDATE users SET passkey='$CURUSER[passkey]' WHERE id=$CURUSER[id]");

}

?>
<div align=Center>
<form name=upload enctype="multipart/form-data" action="takeupload.php" method="post">
<input type="hidden" name="MAX_FILE_SIZE" value="<?=$max_torrent_size?>" />
<table border="1" cellpadding="6" width="716">
<tr>
<td class="tablehead">
<font color=white><b>&#187; <?="" . Title . ""?></b></font>
</td></tr></table>
<table border="1" cellpadding="6" width="716">
<tr>
<td align="center" class="nobottomborder">
After you UPLOAD the TORRENT file please DOWNLOAD it for SEEDING!
<br><?="" . Announce . ""?> URL IS <br/>
<br><?= $announce_urls[0] ?>?passkey=<?= $CURUSER['passkey'] ?> <br/>
</td></tr></table>
<table width="716" border="1" cellspacing="0" cellpadding="10">
<?
tr("" . Torrent . "", "<input type=file name=file size=80>\n", 1);
tr("" . Name . "", "<input type=\"text\" name=\"name\" size=\"80\" /><br />(Taken from filename if not specified. <b>Please use descriptive names.</b>)\n", 1);
tr("" . Description . "", "<input type=\"text\" name=\"description\" size=\"80\" /><b></b><br>Small Description for the uploaded file (Example: A good movie!!!)<br>This Description is shown in browse.php under the Torrent name.", 1);
print("</td></tr>\n");

print("<tr><td class=rowhead style='padding: 3px'>" . Description . "</td><td>");
textbbcode("upload","descr",($quote?(("[quote=".htmlspecialchars($arr["username"])."]".htmlspecialchars(unesc($arr["body"]))."[/quote]")):""));
print("</td></tr>\n");

$s = "<select name=\"type\">\n<option value=\"0\">" . Category . "</option>\n";

$cats = genrelist();
foreach ($cats as $row)
        $s .= "<option value=\"" . $row["id"] . "\">" . htmlspecialchars($row["name"]) . "</option>\n";

$s .= "</select>\n";
tr("" . Type . "", $s, 1);

?>
<tr><td align="center" colspan="2"><input type="submit" class=btn value="<?="" . UPLOAD . ""?>" /></td></tr>
</table>
</form>
<?

stdfoot();

?>