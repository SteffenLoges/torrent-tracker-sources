<?

$FUNDS = $config['funds'];
$max_torrent_size = 1000000;
$announce_interval = 60 * 30;
$signup_timeout = 86400 * 3;
$minvotes = 1;
$max_dead_torrent_time = 6 * 3600;

// Max users on site
$maxusers = 5000;
$autoclean_interval = 900;
$maxloginattempts = 6; 
$PEERLIMIT = $config['peerlimit'];
$pic_base_url = "/pic/";
$imgdir = "/pic/";



?>