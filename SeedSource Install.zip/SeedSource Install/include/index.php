<?
if(!ob_start("ob_gzhandler")) ob_start();

require "include/bittorrent.php";
dbconn(true);
loggedinorreturn();


$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$result = mysql_query("SELECT SUM(last_access >= $dt) AS totalol FROM users") or sqlerr(__FILE__, __LINE__);

while ($row = mysql_fetch_array ($result))
{
$totalonline          = $row["totalol"];
}

$dt = gmtime() - 180;
$dt = sqlesc(get_date_time($dt));
$res = mysql_query("SELECT id, username, class, donor, warned FROM users WHERE last_access >= $dt ORDER BY username") or print(mysql_error());
while ($arr = mysql_fetch_assoc($res))

{
if ($activeusers) $activeusers .= ",\n";
switch ($arr["class"])
{
 case UC_SYSOP:
   $arr["username"] = "<font color=#FF0000>" . $arr["username"] . "</font>";
   break;
case UC_ADMINISTRATOR:
   $arr["username"] = "<font color=#FF0000>" . $arr["username"] . "</font>";
   break;
case UC_MODERATOR:
   $arr["username"] = "<font color=#0000FF>" . $arr["username"] . "</font>";
   break;
case UC_UPLOADER:
   $arr["username"] = "<font color=#9900CC>" . $arr["username"] . "</font>";
   break;
case UC_VIP:
   $arr["username"] = "<font color=#FF6600>" . $arr["username"] . "</font>";
   break;
case UC_POWER_USER:
   $arr["username"] = "<font color=#009900>" . $arr["username"] . "</font>";
   break;

}



$donator = $arr["donor"] === "yes";
if ($donator)
 $activeusers .= "<nobr>";
$warned = $arr["warned"] === "yes";
if ($warned)
 $activeusers .= "<nobr>";
if ($CURUSER)
$activeusers .= "<a href='userdetails.php?id={$arr["id"]}' title='{$arr["class"]}'><b>{$arr["username"]}</b></a>";
else
$activeusers .= "<b>{$arr["username"]}</b>";
if ($donator)
$activeusers .= "<img src={$pic_base_url}star.gif alt='Donated {$$arr["donor"]}'></nobr>";
if ($warned)
$activeusers .= "<img src={$pic_base_url}warned.gif alt='Warned {$$arr["warned"]}'></nobr>";
}
if (!$activeusers)
$activeusers = "" . Active . "";

stdhead("Welcome");

print("<table valign=\"top\" width=720 class=main border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>");


  if ($CURUSER)
  {
    $ss_a = @mysql_fetch_array(@mysql_query("select uri from stylesheets where id=" . $CURUSER["stylesheet"]));
    if ($ss_a) $ss_uri = $ss_a["uri"];
  }
  if (!$ss_uri)
  {
    ($r = mysql_query("SELECT uri FROM stylesheets WHERE id=1")) or die(mysql_error());
    ($a = mysql_fetch_array($r)) or die(mysql_error());
    $ss_uri = $a["uri"];
  }
  
  $style = explode(".css", $ss_uri);

include "style/$style[0]/center.php";

stdfoot();

?>