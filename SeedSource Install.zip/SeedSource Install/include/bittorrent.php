<?
include "ctracker.php";

error_reporting(E_ALL ^ E_NOTICE); 

require_once("secrets.php");
require_once("cleanup.php");
require_once("config.php");

if( !defined("TB_INSTALLED") )
{
	header("Location: ./install/index.php");
	exit;
}   
if (file_exists('install'))
{
	die('Delete the install directory');
}   

// PHP5 with register_long_arrays off?
if (!isset($HTTP_POST_VARS) && isset($_POST))
{
	$HTTP_POST_VARS = $_POST;
	$HTTP_GET_VARS = $_GET;
	$HTTP_SERVER_VARS = $_SERVER;
	$HTTP_COOKIE_VARS = $_COOKIE;
	$HTTP_ENV_VARS = $_ENV;
	$HTTP_POST_FILES = $_FILES;
}

function strip_magic_quotes($arr)
{
foreach ($arr as $k => $v)
{
 if (is_array($v))
  { $arr[$k] = strip_magic_quotes($v); }
 else
  { $arr[$k] = stripslashes($v); }
}

return $arr;
}

if (get_magic_quotes_gpc())
{
if (!empty($_GET))    { $_GET    = strip_magic_quotes($_GET);    }
if (!empty($_POST))   { $_POST   = strip_magic_quotes($_POST);   }
if (!empty($_COOKIE)) { $_COOKIE = strip_magic_quotes($_COOKIE); }
}



// addslashes to vars if magic_quotes_gpc is off
// this is a security precaution to prevent someone
// trying to break out of a SQL statement.
//
if( !get_magic_quotes_gpc() )
{
	if( is_array($HTTP_GET_VARS) )
	{
		while( list($k, $v) = each($HTTP_GET_VARS) )
		{
			if( is_array($HTTP_GET_VARS[$k]) )
			{
				while( list($k2, $v2) = each($HTTP_GET_VARS[$k]) )
				{
					$HTTP_GET_VARS[$k][$k2] = addslashes($v2);
				}
				@reset($HTTP_GET_VARS[$k]);
			}
			else
			{
				$HTTP_GET_VARS[$k] = addslashes($v);
			}
		}
		@reset($HTTP_GET_VARS);
	}

	if( is_array($HTTP_POST_VARS) )
	{
		while( list($k, $v) = each($HTTP_POST_VARS) )
		{
			if( is_array($HTTP_POST_VARS[$k]) )
			{
				while( list($k2, $v2) = each($HTTP_POST_VARS[$k]) )
				{
					$HTTP_POST_VARS[$k][$k2] = addslashes($v2);
				}
				@reset($HTTP_POST_VARS[$k]);
			}
			else
			{
				$HTTP_POST_VARS[$k] = addslashes($v);
			}
		}
		@reset($HTTP_POST_VARS);
	}

	if( is_array($HTTP_COOKIE_VARS) )
	{
		while( list($k, $v) = each($HTTP_COOKIE_VARS) )
		{
			if( is_array($HTTP_COOKIE_VARS[$k]) )
			{
				while( list($k2, $v2) = each($HTTP_COOKIE_VARS[$k]) )
				{
					$HTTP_COOKIE_VARS[$k][$k2] = addslashes($v2);
				}
				@reset($HTTP_COOKIE_VARS[$k]);
			}
			else
			{
				$HTTP_COOKIE_VARS[$k] = addslashes($v);
			}
		}
		@reset($HTTP_COOKIE_VARS);
	}
}

function local_user()
{
  global $HTTP_SERVER_VARS;

  return $HTTP_SERVER_VARS["SERVER_ADDR"] == $HTTP_SERVER_VARS["REMOTE_ADDR"];
}

dbconn();
$sql = "SELECT *
	FROM config";
if( !($result = mysql_query($sql)) )
{
	die("Could not query config information");
}

while ( $row = mysql_fetch_assoc($result) )
{
	$config[$row['name']] = $row['value'];
}

//$FUNDS = $config['funds'];

$SITE_ONLINE = $config['siteonline'];
//$SITE_ONLINE = local_user();
//$SITE_ONLINE = false;

$torrent_dir = "torrents";    # must be writable for httpd user

# the first one will be displayed on the pages
$announce_urls = array();
$announce_urls[] = $config['announce_url'];

if ($HTTP_SERVER_VARS["HTTP_HOST"] == "")
  $HTTP_SERVER_VARS["HTTP_HOST"] = $HTTP_SERVER_VARS["SERVER_NAME"];
$BASEURL = "http://" . $HTTP_SERVER_VARS["HTTP_HOST"];

//set this to true to make this a tracker that only registered users may use
$MEMBERSONLY = true;

//maximum number of peers (seeders+leechers) allowed before torrents starts to be deleted to make room...
//set this to something high if you don't require this feature
$PEERLIMIT = $config['peerlimit'];

//
//
// Email for sender/return path.
$SITEEMAIL = $config['sitemail'];

$SITENAME = $config['sitename'];
// Invite Only
$TBDEV['openreg'] = $config['signupclosed']; //==true=open, false = closed 

// Set this to your site URL... No ending slash!
$DEFAULTBASEURL = $config['domain'];



//Do not modify -- versioning system
//This will help identify code for support issues at tbdev.net
define ('SEEDsource','SEEDsource v1.0');

/**** validip/getip courtesy of manolete ****/

// IP Validation
function validip($ip)
{
        if (!empty($ip) && $ip == long2ip(ip2long($ip)))
        {
                // reserved IANA IPv4 addresses
                // http://www.iana.org/assignments/ipv4-address-space
                $reserved_ips = array (
                                array('0.0.0.0','2.255.255.255'),
                                array('10.0.0.0','10.255.255.255'),
                                array('127.0.0.0','127.255.255.255'),
                                array('169.254.0.0','169.254.255.255'),
                                array('172.16.0.0','172.31.255.255'),
                                array('192.0.2.0','192.0.2.255'),
                                array('192.168.0.0','192.168.255.255'),
                                array('255.255.255.0','255.255.255.255')
                );

                foreach ($reserved_ips as $r)
                {
                                $min = ip2long($r[0]);
                                $max = ip2long($r[1]);
                                if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
                }
                return true;
        }
        else return false;
}

// Patched function to detect REAL IP address if it's valid
function getip() {
   if (isset($_SERVER)) {
     if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && validip($_SERVER['HTTP_X_FORWARDED_FOR'])) {
       $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
     } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && validip($_SERVER['HTTP_CLIENT_IP'])) {
       $ip = $_SERVER['HTTP_CLIENT_IP'];
     } else {
       $ip = $_SERVER['REMOTE_ADDR'];
     }
   } else {
     if (getenv('HTTP_X_FORWARDED_FOR') && validip(getenv('HTTP_X_FORWARDED_FOR'))) {
       $ip = getenv('HTTP_X_FORWARDED_FOR');
     } elseif (getenv('HTTP_CLIENT_IP') && validip(getenv('HTTP_CLIENT_IP'))) {
       $ip = getenv('HTTP_CLIENT_IP');
     } else {
       $ip = getenv('REMOTE_ADDR');
     }
   }

   return $ip;
 }

function dbconn($autoclean = false)
{
    global $mysql_host, $mysql_user, $mysql_pass, $mysql_db;

    if (!@mysql_connect($mysql_host, $mysql_user, $mysql_pass))
    {
          switch (mysql_errno())
          {
                case 1040:
                case 2002:
                        if ($_SERVER[REQUEST_METHOD] == "GET")
                                die("<html><head><meta http-equiv=refresh content=\"5 $_SERVER[REQUEST_URI]\"></head><body><table border=0 width=100% height=100%><tr><td><h3 align=center>The server load is very high at the moment. Retrying, please wait...</h3></td></tr></table></body></html>");
                        else
                                die("Too many users. Please press the Refresh button in your browser to retry.");
        default:
                die("[" . mysql_errno() . "] dbconn: mysql_connect: " . mysql_error());
      }
    }
    mysql_select_db($mysql_db)
        or die('dbconn: mysql_select_db: ' + mysql_error());

    userlogin();

    if ($autoclean)
        register_shutdown_function("autoclean");
}

function userlogin() {
 global $SITE_ONLINE;


    unset($GLOBALS["CURUSER"]);

    $ip = getip();
        $nip = ip2long($ip);
    $res = mysql_query("SELECT * FROM bans WHERE $nip >= first AND $nip <= last") or sqlerr(__FILE__, __LINE__);
    if (mysql_num_rows($res) > 0)
    {
      header("HTTP/1.0 403 Forbidden");
      print("<html><body><h1>403 Forbidden</h1>Unauthorized IP address.</body></html>\n");
      die;
    }

    if (!$SITE_ONLINE || empty($_COOKIE["uid"]) || empty($_COOKIE["pass"]))
        return;
    $id = 0 + $_COOKIE["uid"];
    if (!$id || strlen($_COOKIE["pass"]) != 32)
        return;
    $res = mysql_query("SELECT * FROM users WHERE id = $id AND enabled='yes' AND status = 'confirmed'");// or die(mysql_error());
    $row = mysql_fetch_array($res);
    if (!$row)
        return;
    $sec = hash_pad($row["secret"]);
    if ($_COOKIE["pass"] !== $row["passhash"])
        return;
	
    mysql_query("UPDATE users SET last_access='" . get_date_time() . "', ip=".sqlesc($ip)." WHERE id=" . $row["id"]);// or die(mysql_error());
    $row['ip'] = $ip;
    $GLOBALS["CURUSER"] = $row;
}

function autoclean() {
    global $autoclean_interval;

    $now = time();
    $docleanup = 0;

    $res = mysql_query("SELECT value_u FROM avps WHERE arg = 'lastcleantime'");
    $row = mysql_fetch_array($res);
    if (!$row) {
        mysql_query("INSERT INTO avps (arg, value_u) VALUES ('lastcleantime',$now)");
        return;
    }
    $ts = $row[0];
    if ($ts + $autoclean_interval > $now)
        return;
    mysql_query("UPDATE avps SET value_u=$now WHERE arg='lastcleantime' AND value_u = $ts");
    if (!mysql_affected_rows())
        return;

    docleanup();
}

function unesc($x) {
    if (get_magic_quotes_gpc())
        return stripslashes($x);
    return $x;
}

function mksize($bytes)
{
        if ($bytes < 1000 * 1024)
                return number_format($bytes / 1024, 2) . " kB";
        elseif ($bytes < 1000 * 1048576)
                return number_format($bytes / 1048576, 2) . " MB";
        elseif ($bytes < 1000 * 1073741824)
                return number_format($bytes / 1073741824, 2) . " GB";
        else
                return number_format($bytes / 1099511627776, 2) . " TB";
}

function mksizeint($bytes)
{
        $bytes = max(0, $bytes);
        if ($bytes < 1000)
                return floor($bytes) . " B";
        elseif ($bytes < 1000 * 1024)
                return floor($bytes / 1024) . " kB";
        elseif ($bytes < 1000 * 1048576)
                return floor($bytes / 1048576) . " MB";
        elseif ($bytes < 1000 * 1073741824)
                return floor($bytes / 1073741824) . " GB";
        else
                return floor($bytes / 1099511627776) . " TB";
}

function deadtime() {
    global $announce_interval;
    return time() - floor($announce_interval * 1.3);
}

function mkprettytime($s) {
    if ($s < 0)
        $s = 0;
    $t = array();
    foreach (array("60:sec","60:min","24:hour","0:day") as $x) {
        $y = explode(":", $x);
        if ($y[0] > 1) {
            $v = $s % $y[0];
            $s = floor($s / $y[0]);
        }
        else
            $v = $s;
        $t[$y[1]] = $v;
    }

    if ($t["day"])
        return $t["day"] . "d " . sprintf("%02d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
    if ($t["hour"])
        return sprintf("%d:%02d:%02d", $t["hour"], $t["min"], $t["sec"]);
//    if ($t["min"])
        return sprintf("%d:%02d", $t["min"], $t["sec"]);
//    return $t["sec"] . " secs";
}

function mkglobal($vars) {
    if (!is_array($vars))
        $vars = explode(":", $vars);
    foreach ($vars as $v) {
        if (isset($_GET[$v]))
            $GLOBALS[$v] = unesc($_GET[$v]);
        elseif (isset($_POST[$v]))
            $GLOBALS[$v] = unesc($_POST[$v]);
        else
            return 0;
    }
    return 1;
}

function tr($x,$y,$noesc=0) {
    if ($noesc)
        $a = $y;
    else {
        $a = htmlspecialchars($y);
        $a = str_replace("\n", "<br />\n", $a);
    }
    print("<tr><td class=\"heading\" valign=\"top\" align=\"right\">$x</td><td valign=\"top\" align=left>$a</td></tr>\n");
}

function validfilename($name) {
    return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
}

function validemail($email) {
    return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
}

function sqlesc($x) {
    return "'".mysql_real_escape_string($x)."'";
}

function sqlwildcardesc($x) {
    return str_replace(array("%","_"), array("\\%","\\_"), mysql_real_escape_string($x));
}

function urlparse($m) {
    $t = $m[0];
    if (preg_match(',^\w+://,', $t))
        return "<a href=\"$t\">$t</a>";
    return "<a href=\"http://$t\">$t</a>";
}

function parsedescr($d, $html) {
    if (!$html)
    {
      $d = htmlspecialchars($d);
      $d = str_replace("\n", "\n<br>", $d);
    }
    return $d;
}

function stdhead($title = "", $msgalert = true) {
    global $CURUSER, $SITE_ONLINE, $FUNDS, $SITENAME;

  if (!$SITE_ONLINE)
    die("Site is down for maintenance, please check back again later... thanks<br>");
	
	if ($CURUSER)
 {
 $lng_a = @mysql_fetch_array(@mysql_query("select uri from languages where id=" . $CURUSER["language"]));
 if ($lng_a) $lang_uri = $lng_a["uri"];
 }
 if (!$lang_uri)
 {
 ($z = mysql_query("SELECT uri FROM languages WHERE id=1")) or die(mysql_error());
 ($b = mysql_fetch_array($z)) or die(mysql_error());
 $lang_uri = $b["uri"];
 }
	require_once("languages/" . $lang_uri . "");

header("Cache-Control: no-cache");
    if ($title == "")
        $title = $SITENAME .(isset($_GET['tbv'])?" (".TBVERSION.")":'');
    else
        $title = $SITENAME .(isset($_GET['tbv'])?" (".TBVERSION.")":''). " :: " . htmlspecialchars($title);
  if ($CURUSER)
  {
    $ss_a = @mysql_fetch_array(@mysql_query("select uri from stylesheets where id=" . $CURUSER["stylesheet"]));
    if ($ss_a) $ss_uri = $ss_a["uri"];
  }
  if (!$ss_uri)
  {
    ($r = mysql_query("SELECT uri FROM stylesheets WHERE id=1")) or die(mysql_error());
    ($a = mysql_fetch_array($r)) or die(mysql_error());
    $ss_uri = $a["uri"];
  }
  if ($msgalert && $CURUSER)
  {
    $res = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " && unread='yes'") or die("OopppsY!");
    $arr = mysql_fetch_row($res);
    $unread = $arr[0];
  }
?>
<html><head>
<title><?= $title ?></title>
<link rel="stylesheet" href="style/default/<?=$ss_uri?>" type="text/css">
<link rel="alternate" type="application/rss+xml" title="Latest Torrents" href="<?=$DEFAULTBASEURL?>/rss.php">
<meta http-equiv="Content-Type" content="noindex,nofollow,noarchive" name="robots" charset="utf-8">
<!-- Block Errors start-->
<script language="javascript">
<!--
function blockError()
{
return true;
}
window.onerror = blockError;
-->
</script>
<!-- Block Errors end-->

<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />
<script type="text/javascript" src="js/java_klappe.js"></script>
<script type="text/javascript" src="js/prototype/prototype.js"></script>
<script type="text/javascript" src="js/bramus/jsProgressBarHandler.js"></script>
</head>
<body>

<table align="center" width=1000 cellspacing=0 cellpadding=0 style='background: transparent'>
<tr>
<td class=noborder>
<a href=/><img style=border:none alt=Home title=Home src=pic/logo.png></a>
</td>
</tr></table>
<!-- /////// some vars for the statusbar;o) //////// -->
<? if ($CURUSER) { ?>
<?
$datum = getdate();
$datum[hours] = sprintf("%02.0f", $datum[hours]);
$datum[minutes] = sprintf("%02.0f", $datum[minutes]);
$uped = mksize($CURUSER['uploaded']);
$downed = mksize($CURUSER['downloaded']);
if ($CURUSER["downloaded"] > 0)
{
$ratio = $CURUSER['uploaded'] / $CURUSER['downloaded'];
$ratio = number_format($ratio, 3);
$color = get_ratio_color($ratio);
if ($color)
$ratio = "<font color=$color>$ratio</font>";
}
else
if ($CURUSER["uploaded"] > 0)
$ratio = "Inf.";
else
$ratio = "---";

if ($CURUSER['donor'] == "yes")
$medaldon = "<img src=pic/star.gif alt=donor title=donor>";

if ($CURUSER['warned'] == "yes")
$warn = "<img src=pic/warned.gif alt=warned title=warned>";

//// check for messages //////////////////
$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location IN ('in', 'both')") or print(mysql_error());
$arr1 = mysql_fetch_row($res1);
$messages = $arr1[0];
$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " AND location IN ('in', 'both') AND unread='yes'") or print(mysql_error());
$arr1 = mysql_fetch_row($res1);
$unread = $arr1[0];
$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE sender=" . $CURUSER["id"] . " AND location IN ('out', 'both')") or print(mysql_error());
$arr1 = mysql_fetch_row($res1);
$outmessages = $arr1[0];
$res1 = mysql_query("SELECT COUNT(*) FROM messages WHERE receiver=" . $CURUSER["id"] . " && unread='yes'") or die("OopppsY!");
$arr1 = mysql_fetch_row($res1);
$unread = $arr1[0];
if ($unread)
$inboxpic = "<img height=14px style=border:none alt=inbox title='inbox (new messages)' src=pic/pn_inboxnew.gif>";
else
$inboxpic = "<img height=14px style=border:none alt=inbox title='inbox (no new messages)' src=pic/pn_inbox.gif>";

//// check active torrents ///////////////////////
$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='yes'") or print(mysql_error());
$row = mysql_fetch_row($res2);
$activeseed = $row[0];
$res2 = mysql_query("SELECT COUNT(*) FROM peers WHERE userid=" . $CURUSER["id"] . " AND seeder='no'") or print(mysql_error());
$row = mysql_fetch_row($res2);
$activeleech = $row[0];
//// end

// check if user is connectable or not
$res3 = mysql_query("SELECT connectable FROM peers WHERE userid=" . sqlesc($CURUSER["id"]) . " LIMIT 1") or print(mysql_error());
if($row = mysql_fetch_row($res3)){
       $connect = $row[0];
       if($connect == "yes"){
         $connectable = "<b><font color=green><a title='Connectable = Yes'>Yes</a></font></b>";
       }else{
         $connectable = "<b><font color=red><a title='Connectable = No'>No</a></font></b>";
       }
}else{
$connectable ="<b><a title='Unknow'>---</a></b>";
}
// end
?>



<? } 

//if ($_SERVER["REMOTE_ADDR"] == $_SERVER["SERVER_ADDR"]) $w = "width=984";

if($CURUSER){
?>
<table align="center" class=mainouter border="1" cellpadding="5" width="984" height="80">
<tr>
<td class="nobottomborder">
<table align="center">
<td align="center" border="1" width="80" height="70"><a href="index.php"><img src="pic/pradi.png" border="0" alt="Home"/><br />Home</a></td>
<td align="center" border="1" width="80" height="70"><a href="browse.php"><img src="pic/torre.png" border="0" alt="Torrents"/><br />Torrents</a></td>
<td align="center" border="1" width="80" height="70"><a href="upload.php"><img src="pic/upleo.png" border="0" alt="Upload Torrent"/><br />Upload</a></td>
<td align="center" border="1" width="80" height="70"><a href="chat.php"><img src="pic/chat.png" border="0" alt="Chat"/><br />Chat</a></td>
<td align="center" border="1" width="80" height="70"><a href="forums.php"><img src="pic/frm.png" border="0" alt="Forum"/><br />Forum</a></td>
<td align="center" border="1" width="80" height="70"><a href="faq.php"><img src="pic/duka.png" border="0" alt="FAQ"/><br />FAQ</a></td>
<td align="center" border="1" width="80" height="70"><a href="my.php"><img src="pic/nustat.png" border="0" alt="My Profile"/><br />Profile</a></td>
<td align="center" border="1" width="80" height="70"><a href="staff.php"><img src="pic/staf.png" border="0" alt="Contact Staff"/><br />Staff</a></td>
<td align="center" border="1" width="80" height="70"><a href="donate.php"><img src="pic/param.png" border="0" alt="Donate"/><br />Donate</a></td>
</table>
</td></tr></table> 
<? } else { ?>
<table align="center" class=mainouter border="1" cellpadding="5" width="984" height="80">
<tr>
<td class="nobottomborder">
<table align="center">
<td align="center" border="1" width="160" height="70"><a href="index.php"><img src="pic/logi.png" border="0" alt="Login"/><br />Login</a></td>
<td align="center" border="1" width="160" height="70"><a href="signup.php"><img src="pic/regis.png" border="0" alt="Signup"/><br />Signup</a></td>
</table>
</td></tr></table> 
<? }
?>
<table align="center" class=mainouter width="984" border="0" cellspacing="0" cellpadding="5">
<tr><td>
<table align="center" class=mainouter width="964" border="0" cellspacing="0" cellpadding="5">
<tr>
<? if($CURUSER){
?>
<td class="noborder" valign="top" align=center style="padding-top: 0px; padding-left: 6px; padding-bottom: 0px">
<br />
<br />
<table border="1" cellpadding="5" width="100%">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; Menu</b></font><br />
</td></tr></table>
<table width="100%" border="1" cellpadding="5">
 <tr>
    <td>
	Welcome, <b><a href="userdetails.php?id=<?=$CURUSER['id']?>"><?=$CURUSER['username']?></a></b><?=$medaldon?><?=$warn?><br> <br/>
	<br><? if($CURUSER["avatar"] == ""){ ?>
	&nbsp;<a href="my.php"><img src="../pic/no-avatar.gif" alt="<?=$CURUSER['username']?>" border="0" title="<?=$CURUSER['username']?>"/></a><br/> 
	<? } else { ?>
	&nbsp;<a href="my.php"><img src="<?=$CURUSER['avatar']?>" alt="<?=$CURUSER['username']?>" border="0" title="<?=$CURUSER['username']?>"/></a><br/> 
	<? } ?>
	<br/>
	<font color=lightblue><b>Ratio:    <?=$ratio?>
	<br>PM :
	<?
	if ($messages){
print("<span class=smallfont><a href=inbox.php>$inboxpic</a> $messages ($unread Unread)</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0</span>");
}
else
{
print("<span class=smallfont><a href=inbox.php><img height=14px style=border:none alt=inbox title=inbox src=pic/pn_inbox.gif></a> 0</span>");
if ($outmessages)
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> $outmessages</span>");
else
print("<span class=smallfont>&nbsp;&nbsp;<a href=inbox.php?out=1><img height=14px style=border:none alt=sentbox title=sentbox src=pic/pn_sentbox.gif></a> 0</span>");
}
	?>
	<br />
	Bonus: <a href="mybonus.php"><?=$CURUSER['seedbonus']?></a><br />
	<font color=green>Uploaded:</font> <font color=green><?=$uped?></font><br />
	<font color=darkred>Downloaded:</font> <font color=darkred><?=$downed?></font><br />
	<font color=1900D1>Active:&nbsp;</font></span> <img alt="Torrents seeding" title="Torrents seeding" src="pic/arrowup.gif">&nbsp;<font color=green><span class="smallfont"><?=$activeseed?></span></font>&nbsp;&nbsp;<img alt="Torrents leeching" title="Torrents leeching" src="pic/arrowdown.gif">&nbsp;<font color=darkred><span class="smallfont"><?=$activeleech?></span></font>
    <br />
	<br />	
	<a href="invite.php">&#187; Invites</a><br />
	<a href="friends.php">&#187; Friends</a><br />
	<a href="logout.php">&#187; Logout</a><br />
	<? if (get_user_class() > UC_MODERATOR) { ?>
<a href=/staffpanel.php>&#187; CPanel</a>
<? } else { ?>
<? } ?>
	</td>
  </tr>
</table>
<br/>
<table border="1" cellpadding="5" width="100%">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; Donations</b></font><br />
</td></tr></table>
<table width="100%" border="1" cellpadding="5">
 <tr>
    <td>
	
	<?
	
	 $query = "SELECT * FROM funds";
$result = mysql_query($query) or die ("Can't connect to mysql.");
while ($row = mysql_fetch_array($result))
{
				$done = $row["done"];
				$need = $row["need"];}
				

    $percents = $done/$need*100;
	?>
	        <center>
			<b>Progress :</b><br />
			<span class="progressBar" id="element6"><?=$percents?></span><br />
		    <br/>
			<b>Donate <a href="donate.php">&#187; HERE &#187;</a><br />
			</center>
			
			
			<script type="text/javascript">
				document.observe('dom:loaded', function() {

					// first manuale progressbar : different bar (width, height, images) and no animation
					manualPB = new JS_BRAMUS.jsProgressBar(
								$('element5'),
								75,
								{
									showText	: false,
									animate		: false,
									width		: 154,
									height		: 11,
									boxImage	: 'pic/bramus/custom1_box.gif',
									barImage	: 'pic/bramus/custom1_bar.gif'
								}
							);

					// second manual example : multicolor (and take all other default paramters)
					manualPB2 = new JS_BRAMUS.jsProgressBar(
								$('element6'),
								52,
								{

									barImage	: Array(
										'pic/bramus/percentImage_back4.png',
										'pic/bramus/percentImage_back3.png',
										'pic/bramus/percentImage_back2.png',
										'pic/bramus/percentImage_back1.png'
									),

									onTick : function(pbObj) {

										switch(pbObj.getPercentage()) {

											case 98:
												alert('Hey, we\'re at 98!');
											break;

											case 100:
												alert('Progressbar full at 100% ... maybe do a redirect or sth like that here?');
											break;

										}

										return true;
									}
								}
							);
				}, false);
			</script>
  </td>
  </tr>
</table>
</td>
<? } ?>

<td class="noborder" width="650" valign="top" align=center style="padding-top: 13px; padding-bottom: 13px">
<?

}

function stdfoot() {
include "style/default/footer.php";
}

function genbark($x,$y) {
    stdhead($y);
    print("<h2>" . htmlspecialchars($y) . "</h2>\n");
    print("<p>" . htmlspecialchars($x) . "</p>\n");
    stdfoot();
    exit();
}

function mksecret($len = 20) {
    $ret = "";
    for ($i = 0; $i < $len; $i++)
        $ret .= chr(mt_rand(0, 255));
    return $ret;
}


function gmtime()
{
    return strtotime(get_date_time());
}

function logincookie($id, $passhash, $updatedb = 1, $expires = 0x7fffffff)
{
 setcookie("uid", $id, $expires, "/");
 setcookie("pass", $passhash, $expires, "/");

 if ($updatedb)
 mysql_query("UPDATE users SET last_login = NOW() WHERE id = $id");
}


function logoutcookie() {
 setcookie("uid", "", 0x7fffffff, "/");
 setcookie("pass", "", 0x7fffffff, "/");
}

function loggedinorreturn() {
    global $CURUSER;
    if (!$CURUSER) {
        dbconn(false);

stdhead("Welcome");
               
			
?>
<table cellpadding="5" width="400">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; Note</b></font><br />
</td></tr></table>
<table width="400" border="1" cellpadding="5">
 <tr>
    <td>
Login   
Attempts <b><?=Remaining ();?>.
</td>
 </tr>
  </table>


<br />
<table cellpadding="5" width="400">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; Login</b></font><br />
</td></tr></table>
<form method="post" action="takelogin.php">
<table width="400" border="1" cellpadding="5">
 <tr>
    <td>
		<br />
	<b>Username:</b><br />
    <input type="text" style="width: 98%;" size="40" name="username" /><br/>
    <b>Password:</b><br />
    <input type="password" style="width: 98%;" size="40" name="password" /><br />
		<br />
      <input type="submit" value="Submit" class='btn' />
	  <br /><br /> 
	  <i>Cookies must be enabled in order to LOGIN.</i>
	  <br /><br />
	  <p align=center>
<a href="http://www.copyright.com/Services/copyrightoncampus/other/index.html"><img border="0" alt="P2P Defense!" title="Support FileSharing" src=pic/supportfilesharing.gif /></a>
    </td>
	

  </tr>
</table>
<br/>
<?


stdfoot();

        exit();
    }
}

function deletetorrent($id) {
    global $torrent_dir;
    mysql_query("DELETE FROM torrents WHERE id = $id");
    foreach(explode(".","peers.files.comments.ratings") as $x)
        mysql_query("DELETE FROM $x WHERE torrent = $id");
    unlink("$torrent_dir/$id.torrent");
}

function pager($rpp, $count, $href, $opts = array()) {
    $pages = ceil($count / $rpp);

    if (!$opts["lastpagedefault"])
        $pagedefault = 0;
    else {
        $pagedefault = floor(($count - 1) / $rpp);
        if ($pagedefault < 0)
            $pagedefault = 0;
    }

    if (isset($_GET["page"])) {
        $page = 0 + $_GET["page"];
        if ($page < 0)
            $page = $pagedefault;
    }
    else
        $page = $pagedefault;

    $pager = "";

    $mp = $pages - 1;
    $as = "<b>&lt;&lt;&nbsp;Prev</b>";
    if ($page >= 1) {
        $pager .= "<a href=\"{$href}page=" . ($page - 1) . "\">";
        $pager .= $as;
        $pager .= "</a>";
    }
    else
        $pager .= $as;
    $pager .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    $as = "<b>Next&nbsp;&gt;&gt;</b>";
    if ($page < $mp && $mp >= 0) {
        $pager .= "<a href=\"{$href}page=" . ($page + 1) . "\">";
        $pager .= $as;
        $pager .= "</a>";
    }
    else
        $pager .= $as;

    if ($count) {
        $pagerarr = array();
        $dotted = 0;
        $dotspace = 3;
        $dotend = $pages - $dotspace;
        $curdotend = $page - $dotspace;
        $curdotstart = $page + $dotspace;
        for ($i = 0; $i < $pages; $i++) {
            if (($i >= $dotspace && $i <= $curdotend) || ($i >= $curdotstart && $i < $dotend)) {
                if (!$dotted)
                    $pagerarr[] = "...";
                $dotted = 1;
                continue;
            }
            $dotted = 0;
            $start = $i * $rpp + 1;
            $end = $start + $rpp - 1;
            if ($end > $count)
                $end = $count;
            $text = "$start&nbsp;-&nbsp;$end";
            if ($i != $page)
                $pagerarr[] = "<a href=\"{$href}page=$i\"><b>$text</b></a>";
            else
                $pagerarr[] = "<b>$text</b>";
        }
        $pagerstr = join(" | ", $pagerarr);
        $pagertop = "<p align=\"center\">$pager<br />$pagerstr</p>\n";
        $pagerbottom = "<p align=\"center\">$pagerstr<br />$pager</p>\n";
    }
    else {
        $pagertop = "<p align=\"center\">$pager</p>\n";
        $pagerbottom = $pagertop;
    }

    $start = $page * $rpp;

    return array($pagertop, $pagerbottom, "LIMIT $start,$rpp");
}

function downloaderdata($res) {
    $rows = array();
    $ids = array();
    $peerdata = array();
    while ($row = mysql_fetch_assoc($res)) {
        $rows[] = $row;
        $id = $row["id"];
        $ids[] = $id;
        $peerdata[$id] = array(downloaders => 0, seeders => 0, comments => 0);
    }

    if (count($ids)) {
        $allids = implode(",", $ids);
        $res = mysql_query("SELECT COUNT(*) AS c, torrent, seeder FROM peers WHERE torrent IN ($allids) GROUP BY torrent, seeder");
        while ($row = mysql_fetch_assoc($res)) {
            if ($row["seeder"] == "yes")
                $key = "seeders";
            else
                $key = "downloaders";
            $peerdata[$row["torrent"]][$key] = $row["c"];
        }
        $res = mysql_query("SELECT COUNT(*) AS c, torrent FROM comments WHERE torrent IN ($allids) GROUP BY torrent");
        while ($row = mysql_fetch_assoc($res)) {
            $peerdata[$row["torrent"]]["comments"] = $row["c"];
        }
    }

    return array($rows, $peerdata);
}

function commenttable($rows)
{
        global $CURUSER;
        begin_main_frame();
        begin_frame();
        $count = 0;
        foreach ($rows as $row)
        {
                print("<p class=sub>#" . $row["id"] . " by ");
    if (isset($row["username"]))
                {
                        $title = $row["title"];
                        if ($title == "")
                                $title = get_user_class_name($row["class"]);
                        else
                                $title = htmlspecialchars($title);
        print("<a name=comm". $row["id"] .
                " href=userdetails.php?id=" . $row["user"] . "><b>" .
                htmlspecialchars($row["username"]) . "</b></a>" . ($row["donor"] == "yes" ? "<img src=pic/star.gif alt='Donor'>" : "") . ($row["warned"] == "yes" ? "<img src=".
                            "/pic/warned.gif alt=\"Warned\">" : "") . " ($title)\n");
                }
                else
                   print("<a name=\"comm" . $row["id"] . "\"><i>(orphaned)</i></a>\n");

                print(" at " . $row["added"] . " GMT" .
                        ($row["user"] == $CURUSER["id"] || get_user_class() >= UC_MODERATOR ? "- [<a href=comment.php?action=edit&amp;cid=$row[id]>Edit</a>]" : "") .
                        (get_user_class() >= UC_MODERATOR ? "- [<a href=comment.php?action=delete&amp;cid=$row[id]>Delete</a>]" : "") .
                        ($row["editedby"] && get_user_class() >= UC_MODERATOR ? "- [<a href=comment.php?action=vieworiginal&amp;cid=$row[id]>View original</a>]" : "") . "</p>\n");
                $avatar = ($CURUSER["avatars"] == "yes" ? htmlspecialchars($row["avatar"]) : "");
                if (!$avatar)
                        $avatar = "/pic/default_avatar.gif";
                $text = format_comment($row["text"]);
    if ($row["editedby"])
            $text .= "<p><font size=1 class=small>Last edited by <a href=userdetails.php?id=$row[editedby]><b>$row[username]</b></a> at $row[editedat] GMT</font></p>\n";
                begin_table(true);
                print("<tr valign=top>\n");
                print("<td align=center width=150 style='padding: 0px'><img width=150 src=$avatar></td>\n");
                print("<td class=text>$text</td>\n");
                print("</tr>\n");
     end_table();
  }
        end_frame();
        end_main_frame();
}

function searchfield($s) {
    return preg_replace(array('/[^a-z0-9]/si', '/^\s*/s', '/\s*$/s', '/\s+/s'), array(" ", "", "", " "), $s);
}

function genrelist() {
    $ret = array();
    $res = mysql_query("SELECT id, name FROM categories ORDER BY name");
    while ($row = mysql_fetch_array($res))
        $ret[] = $row;
    return $ret;
}

function linkcolor($num) {
    if (!$num)
        return "red";
//    if ($num == 1)
//        return "yellow";
    return "green";
}

function ratingpic($num) {
    global $pic_base_url;
    $r = round($num * 2) / 2;
    if ($r < 1 || $r > 5)
        return;
    return "<img src=\"$pic_base_url$r.gif\" border=\"0\" alt=\"rating: $num / 5\" />";
}

function torrenttable($res, $variant = "index") {
        global $pic_base_url, $CURUSER;
        /*$browse_res = mysql_query("SELECT last_browse FROM users WHERE id='".$CURUSER['id']."'");

        $browse_arr = mysql_fetch_row($browse_res);

        $last_browse = $browse_arr[0];*/

        $last_browse = $CURUSER['last_browse'];

        $time_now = gmtime();

        if ($last_browse > $time_now) {

         $last_browse=$time_now;

}

        if ($CURUSER["class"] < UC_VIP)
  {
          $gigs = $CURUSER["uploaded"] / (1024*1024*1024);
          $ratio = (($CURUSER["downloaded"] > 0) ? ($CURUSER["uploaded"] / $CURUSER["downloaded"]) : 0);
          if ($ratio < 0.5 || $gigs < 5) $wait = 24;
          elseif ($ratio < 0.65 || $gigs < 6.5) $wait = 12;
          elseif ($ratio < 0.8 || $gigs < 8) $wait = 6;
          elseif ($ratio < 0.95 || $gigs < 9.5) $wait = 3;
          else $wait = 0;
  }
?>
<table border="1" width="720" cellspacing=0 cellpadding=5>
<tr>

<td class="colhead" align="center"><?="" . Category . ""?></td>
<td class="colhead" align=left><?="" . Name . ""?></td>
<?
        if ($wait)
        {
                print("<td class=\"colhead\" align=\"center\"><img src=/pic/warned0.gif border=none alt=Wait></td>\n");
        }

        if ($variant == "mytorrents")
  {
          print("<td class=\"colhead\" align=\"center\">" . Edit . "</td>\n");
    print("<td class=\"colhead\" align=\"center\">" . Visible . "</td>\n");
        }

?>
<td class="colhead" align=right><img src=/pic/multipage.gif border=none alt=Files></td>
<td class="colhead" align=right><?="" . Comments . ""?></td>
<td class="colhead" align="center"><?="" . Added . ""?></td>
<td class="colhead" align="center">TTL</td>
<td class="colhead" align="center"><?="" . Size . ""?></td>
<td class="colhead" align="center"><img src=/pic/top.gif border=none alt=Snatched></td>
<td class="colhead" align=right><img src=/pic/arrowup.gif border=none alt=Seeders></td>
<td class="colhead" align=right><img src=/pic/arrowdown.gif border=none alt=Leechers></td>
<?

    if ($variant == "index")
        print("<td class=\"colhead\" align=center>" . Upped . "</td>\n");

    print("</tr>\n");

    while ($row = mysql_fetch_assoc($res)) {
        $id = $row["id"];
        print("<tr>\n");

        print("<td align=center style='padding: 0px'>");
        if (isset($row["cat_name"])) {
            print("<a href=\"browse.php?cat=" . $row["category"] . "\">");
            if (isset($row["cat_pic"]) && $row["cat_pic"] != "")
                print("<img border=\"0\" src=\"$pic_base_url" . $row["cat_pic"] . "\" alt=\"" . $row["cat_name"] . "\" />");
            else
                print($row["cat_name"]);
            print("</a>");
        }
        else
            print("-");
        print("</td>\n");

        $dispname = htmlspecialchars($row["name"]);
        if (!empty($row['description'])) {
        $description = "(" . htmlspecialchars($row["description"]) . ")";
        }

        else {
        $description = "";
        }

        

        $char = 50; //Max long...
        print("<td align=left><a href=\"details.php?");
        if ($variant == "mytorrents")
        print("returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;");
        print("id=$id");
        if ($variant == "index")
        print("&amp;hit=1");
        if (sql_timestamp_to_unix_timestamp($row["added"]) >= $last_browse)

        print("\" title=\"" . $dispname . "\"><b>" . $dispname . " <b><img src=/pic/new.png border=none alt=NEW></b><br>$description\n");

        else

        print("\" title=\"" . $dispname ."\"><b>" . $dispname . "</b></a><br>$description\n");

                                if ($wait)
                                {
                                  $elapsed = floor((gmtime() - strtotime($row["added"])) / 3600);
                if ($elapsed < $wait)
                {
                  $color = dechex(floor(127*($wait - $elapsed)/48 + 128)*65536);
                  print("<td align=center><nobr><font color=\"$color\">" . number_format($wait - $elapsed) . " h</font></a></nobr></td>\n");
                }
                else
                  print("<td align=center><nobr>None</nobr></td>\n");
        }


    /*    if ($row["nfoav"] && get_user_class() >= UC_POWER_USER)
          print("<a href=viewnfo.php?id=$row[id]><img src=pic/viewnfo.gif border=0 alt='View NFO'></a>\n");
        if ($variant == "index")
            print("<a href=\"download.php/$id/" . rawurlencode($row["filename"]) . "\"><img src=pic/download.gif border=0 alt=Download></a>\n");

        else*/if ($variant == "mytorrents")
            print("<td align=\"center\"><a href=\"edit.php?returnto=" . urlencode($_SERVER["REQUEST_URI"]) . "&amp;id=" . $row["id"] . "\">edit</a>\n");
print("</td>\n");
        if ($variant == "mytorrents") {
            print("<td align=\"right\">");
            if ($row["visible"] == "no")
                print("<b>no</b>");
            else
                print("yes");
            print("</td>\n");
        }

        if ($row["type"] == "single")
            print("<td align=\"right\">" . $row["numfiles"] . "</td>\n");
        else {
            if ($variant == "index")
                print("<td align=\"right\"><b><a href=\"details.php?id=$id&amp;hit=1&amp;filelist=1\">" . $row["numfiles"] . "</a></b></td>\n");
            else
                print("<td align=\"right\"><b><a href=\"details.php?id=$id&amp;filelist=1#filelist\">" . $row["numfiles"] . "</a></b></td>\n");
        }

        if (!$row["comments"])
            print("<td align=\"right\">" . $row["comments"] . "</td>\n");
        else {
            if ($variant == "index")
                print("<td align=\"right\"><b><a href=\"details.php?id=$id&amp;hit=1&amp;tocomm=1\">" . $row["comments"] . "</a></b></td>\n");
            else
                print("<td align=\"right\"><b><a href=\"details.php?id=$id&amp;page=0#startcomments\">" . $row["comments"] . "</a></b></td>\n");
        }

/*
        print("<td align=\"center\">");
        if (!isset($row["rating"]))
            print("---");
        else {
            $rating = round($row["rating"] * 2) / 2;
            $rating = ratingpic($row["rating"]);
            if (!isset($rating))
                print("---");
            else
                print($rating);
        }
        print("</td>\n");
*/
        print("<td align=center><nobr>" . str_replace(" ", "<br />", $row["added"]) . "</nobr></td>\n");
                $ttl = (28*24) - floor((gmtime() - sql_timestamp_to_unix_timestamp($row["added"])) / 3600);
                if ($ttl == 1) $ttl .= "<br>hour"; else $ttl .= "<br>hours";
        print("<td align=center>$ttl</td>\n");
        print("<td align=center>" . str_replace(" ", "<br>", mksize($row["size"])) . "</td>\n");
//        print("<td align=\"right\">" . $row["views"] . "</td>\n");
//        print("<td align=\"right\">" . $row["hits"] . "</td>\n");
        $_s = "";
        if ($row["times_completed"] != 1)
          $_s = "s";
        print("<td align=center>" . number_format($row["times_completed"]) . "<br>time$_s</td>\n");

        if ($row["seeders"]) {
            if ($variant == "index")
            {
               if ($row["leechers"]) $ratio = $row["seeders"] / $row["leechers"]; else $ratio = 1;
                print("<td align=right><b><a href=details.php?id=$id&amp;hit=1&amp;toseeders=1><font color=" .
                  get_slr_color($ratio) . ">" . $row["seeders"] . "</font></a></b></td>\n");
            }
            else
                print("<td align=\"right\"><b><a class=\"" . linkcolor($row["seeders"]) . "\" href=\"details.php?id=$id&amp;dllist=1#seeders\">" .
                  $row["seeders"] . "</a></b></td>\n");
        }
        else
            print("<td align=\"right\"><span class=\"" . linkcolor($row["seeders"]) . "\">" . $row["seeders"] . "</span></td>\n");

        if ($row["leechers"]) {
            if ($variant == "index")
                print("<td align=right><b><a href=details.php?id=$id&amp;hit=1&amp;todlers=1>" .
                   number_format($row["leechers"]) . ($peerlink ? "</a>" : "") .
                   "</b></td>\n");
            else
                print("<td align=\"right\"><b><a class=\"" . linkcolor($row["leechers"]) . "\" href=\"details.php?id=$id&amp;dllist=1#leechers\">" .
                  $row["leechers"] . "</a></b></td>\n");
        }
        else
            print("<td align=\"right\">0</td>\n");

        if ($variant == "index")
            print("<td align=center>" . (isset($row["username"]) ? ("<a href=userdetails.php?id=" . $row["owner"] . "><b>" . htmlspecialchars($row["username"]) . "</b></a>") : "<i>(unknown)</i>") . "</td>\n");

        print("</tr>\n");
    }

    print("</table>\n");

    return $rows;
}

function hash_pad($hash) {
    return str_pad($hash, 20);
}

function hash_where($name, $hash) {
    $shhash = preg_replace('/ *$/s', "", $hash);
    return "($name = " . sqlesc($hash) . " OR $name = " . sqlesc($shhash) . ")";
}

function get_user_icons($arr, $big = false)
{
        if ($big)
        {
                $donorpic = "starbig.gif";
                $warnedpic = "warnedbig.gif";
                $disabledpic = "disabledbig.gif";
                $style = "style='margin-left: 4pt'";
        }
        else
        {
                $donorpic = "star.gif";
                $warnedpic = "warned.gif";
                $disabledpic = "disabled.gif";
                $style = "style=\"margin-left: 2pt\"";
        }
        $pics = $arr["donor"] == "yes" ? "<img src=pic/$donorpic alt='Donor' border=0 $style>" : "";
        if ($arr["enabled"] == "yes")
                $pics .= $arr["warned"] == "yes" ? "<img src=pic/$warnedpic alt=\"Warned\" border=0 $style>" : "";
        else
                $pics .= "<img src=pic/$disabledpic alt=\"Disabled\" border=0 $style>\n";
        return $pics;
}

function parked()
{
       global $CURUSER;
       if ($CURUSER["parked"] == "yes")
 stderr("Error", "Your account is parked.");
}

 function Failedloginscheck () { global $maxloginattempts; $total = 0; $ip = sqlesc(getip()); $Query = mysql_query("SELECT SUM(attempts) FROM loginattempts WHERE ip=$ip") or sqlerr(__FILE__, __LINE__); list($total) = mysql_fetch_array($Query); if ($total >= $maxloginattempts) { 	 mysql_query("UPDATE loginattempts SET banned = 'yes' WHERE ip=$ip") or sqlerr(__FILE__, __LINE__); 	 stderr("Login Locked!", "You have been <b>exceed maximum login attempts</b>, therefore your ip address <b>(".htmlspecialchars($ip).")</b> has been banned."); } } function failedlogins () { $ip = sqlesc(getip()); $added = sqlesc(get_date_time()); $a = (@mysql_fetch_row(@mysql_query("select count(*) from loginattempts where ip=$ip"))) or sqlerr(__FILE__, __LINE__); if ($a[0] == 0) mysql_query("INSERT INTO loginattempts (ip, added, attempts) VALUES ($ip, $added, 1)") or sqlerr(__FILE__, __LINE__); else mysql_query("UPDATE loginattempts SET attempts = attempts + 1 where ip=$ip") or sqlerr(__FILE__, __LINE__); stderr("Login failed!","<b>Error</b>: Username or password incorrect<br>Don't remember your password? <b><a href=recover.php>Recover</a></b> your password!"); } function remaining () { global $maxloginattempts; $total = 0; $ip = sqlesc(getip()); $Query = mysql_query("SELECT SUM(attempts) FROM loginattempts WHERE ip=$ip") or sqlerr(__FILE__, __LINE__); list($total) = mysql_fetch_array($Query); $remaining = $maxloginattempts - $total; if ($remaining <= 2 ) $remaining = "<font color=red size=4>".$remaining."</font>"; else $remaining = "<font color=green size=4>".$remaining."</font>"; return $remaining; }

require "global.php";

?>