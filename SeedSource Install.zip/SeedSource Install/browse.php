<?

ob_start("ob_gzhandler");

require_once("include/bittorrent.php");


dbconn(false);

loggedinorreturn();
parked();


$cats = genrelist();

$searchstr = unesc($_GET["search"]);
$cleansearchstr = searchfield($searchstr);
if (empty($cleansearchstr))
        unset($cleansearchstr);

$orderby = "ORDER BY torrents.id DESC";

$addparam = "";
$wherea = array();
$wherecatina = array();

if ($_GET["incldead"] == 1)
{
        $addparam .= "incldead=1&amp;";
        if (!isset($CURUSER) || get_user_class() < UC_ADMINISTRATOR)
                $wherea[] = "banned != 'yes'";
}
elseif ($_GET["incldead"] == 2)
{
        $addparam .= "incldead=2&amp;";
                $wherea[] = "visible = 'no'";
}
        else
                $wherea[] = "visible = 'yes'";

$category = (int)$_GET["cat"];

$all = $_GET["all"];

if (!$all)
        if (!$_GET && $CURUSER["notifs"])
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $cat[id];
            if (strpos($CURUSER["notifs"], "[cat" . $cat[id] . "]") !== False)
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }
        elseif ($category)
        {
          if (!is_valid_id($category))
            stderr("Error", "Invalid category ID $category");
          $wherecatina[] = $category;
          $addparam .= "cat=$category&amp;";
        }
        else
        {
          $all = True;
          foreach ($cats as $cat)
          {
            $all &= $_GET["c$cat[id]"];
            if ($_GET["c$cat[id]"])
            {
              $wherecatina[] = $cat[id];
              $addparam .= "c$cat[id]=1&amp;";
            }
          }
        }

if ($all)
{
        $wherecatina = array();
  $addparam = "";
}

if (count($wherecatina) > 1)
        $wherecatin = implode(",",$wherecatina);
elseif (count($wherecatina) == 1)
        $wherea[] = "category = $wherecatina[0]";

$wherebase = $wherea;

if (isset($cleansearchstr))
{
        $wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
        //$wherea[] = "0";
        $addparam .= "search=" . urlencode($searchstr) . "&amp;";
        $orderby = "";
}

$where = implode(" AND ", $wherea);
if ($wherecatin)
        $where .= ($where ? " AND " : "") . "category IN(" . $wherecatin . ")";

if ($where != "")
        $where = "WHERE $where";

$res = mysql_query("SELECT COUNT(*) FROM torrents $where") or die(mysql_error());
$row = mysql_fetch_array($res);
$count = $row[0];

if (!$count && isset($cleansearchstr)) {
        $wherea = $wherebase;
        $orderby = "ORDER BY id DESC";
        $searcha = explode(" ", $cleansearchstr);
        $sc = 0;
        foreach ($searcha as $searchss) {
                if (strlen($searchss) <= 1)
                        continue;
                $sc++;
                if ($sc > 5)
                        break;
                $ssa = array();
                foreach (array("search_text", "ori_descr") as $sss)
                        $ssa[] = "$sss LIKE '%" . sqlwildcardesc($searchss) . "%'";
                $wherea[] = "(" . implode(" OR ", $ssa) . ")";
        }
        if ($sc) {
                $where = implode(" AND ", $wherea);
                if ($where != "")
                        $where = "WHERE $where";
                $res = mysql_query("SELECT COUNT(*) FROM torrents $where");
                $row = mysql_fetch_array($res);
                $count = $row[0];
        }
}

$torrentsperpage = $CURUSER["torrentsperpage"];
if (!$torrentsperpage)
        $torrentsperpage = 15;

if ($count)
{
        list($pagertop, $pagerbottom, $limit) = pager($torrentsperpage, $count, "browse.php?" . $addparam);
        $query = "SELECT torrents.id, torrents.poster, torrents.descr, torrents.category, torrents.leechers, torrents.seeders, torrents.name, torrents.times_completed, torrents.size, torrents.added, torrents.comments,torrents.numfiles,torrents.filename,torrents.description,torrents.owner,IF(torrents.nfo <> '', 1, 0) as nfoav," .
//        "IF(torrents.numratings < $minvotes, NULL, ROUND(torrents.ratingsum / torrents.numratings, 1)) AS rating, categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
        "categories.name AS cat_name, categories.image AS cat_pic, users.username FROM torrents LEFT JOIN categories ON category = categories.id LEFT JOIN users ON torrents.owner = users.id $where $orderby $limit";
        $res = mysql_query($query) or die(mysql_error());
}
else
        unset($res);
if (isset($cleansearchstr))
        stdhead("Search results for \"$searchstr\"");
else
        stdhead("Browse Torrents");

?>

<STYLE TYPE="text/css" MEDIA=screen>

  a.catlink:link, a.catlink:visited{
                text-decoration: none;
        }

        a.catlink:hover {
                color: #A83838;
        }

</STYLE>

<form method="get" action="browse.php">

<table border="1" cellpadding="5" width="100%">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; <?="" . Search . ""?></b></font><br />
</td></tr></table>
<table width="100%" border="1">
<tr><td>
<br />
		<?
		$query = mysql_query("SELECT searchedfor, howmuch FROM searchcloud ORDER BY id DESC LIMIT 50");
		while ($arr = mysql_fetch_array($query)) {
			if ($arr["howmuch"] < 5)
				$size = 5;
			elseif ($arr["howmuch"] > 25)
				$size = 25;
			else
				$size = $arr["howmuch"];
			$size = $size / 5; ?>
			
			&nbsp;<a href="browse.php?search=<?=urlencode($arr["searchedfor"])?>&amp;cat=0" title="<?=$arr["howmuch"]?> hits"><span style="font-size: <?=$size?>em;"><?=htmlspecialchars($arr["searchedfor"])?></span></a>
		<?
		}
		?>
		<br /><br />
	</tr></td></table>
<br />
<table border="1" cellpadding="5" width="100%">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; <?="" . Categories . ""?></b></font><br />
</td></tr></table>
<table border="1">
<tr><td>

</form>



<table width=716 border=0 cellspacing=0 cellpadding=0><tr><td class=embedded>
<form method="get" action=browse.php>
<p align="center">
<?="" . Search . ""?>:
<input type="text" name="search" size="40" value="<?= htmlspecialchars($searchstr) ?>" />
<?="" . In . ""?>
<select name="cat">
<option value="0"><?="" . ALL . ""?></option>
<?


$cats = genrelist();
$catdropdown = "";
foreach ($cats as $cat) {
$catdropdown .= "<option value=\"" . $cat["id"] . "\"";
if ($cat["id"] == $_GET["cat"])
$catdropdown .= " selected=\"selected\"";
$catdropdown .= ">" . htmlspecialchars($cat["name"]) . "</option>\n";
}

$deadchkbox = "<input type=\"checkbox\" name=\"incldead\" value=\"1\"";
if ($_GET["incldead"])
$deadchkbox .= " checked=\"checked\"";
$deadchkbox .= " /> " . Dead . "\n";

?>
<?= $catdropdown ?>
</select>
<?= $deadchkbox ?>
<input type="submit" value="<?="" . Search . ""?>" />
</p>
</form>
</td></tr></table>

</tr></td></table>
<?

if (isset($cleansearchstr))
print("<h2>" . Results . " \"" . htmlspecialchars($searchstr) . "\"</h2>\n");

if ($count) {
        print($pagertop);

        torrenttable($res);

        print($pagerbottom);
}
else {
if (isset($cleansearchstr)) {
	$wherea[] = "MATCH (search_text, ori_descr) AGAINST (" . sqlesc($searchstr) . ")";
	//$wherea[] = "0";
	$addparam .= "search=" . urlencode($searchstr) . "&amp;";
	$orderby = "";
	
	// Searchcloud mod by bokli
	$searchcloud = sqlesc($searchstr);
	$r = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM searchcloud WHERE searchedfor = $searchcloud"));
	$a = $r[0];
	if ($a)
		mysql_query("UPDATE searchcloud SET howmuch = howmuch + 1 WHERE searchedfor = $searchcloud");
	else
		mysql_query("INSERT INTO searchcloud (searchedfor, howmuch) VALUES ($searchcloud, 1)");
}
        else {
                print("<h2>" . NO . "</h2>\n");
                print("<h2>" . Torrents . "</h2>\n");
        }
}



if ($CURUSER)
// Torrents Needing Seeds mod
$need = mysql_query("SELECT id, name, leechers FROM torrents WHERE seeders = 0 AND leechers > 0 ORDER BY leechers DESC") or sqlerr();
if(mysql_num_rows($need))
{
echo("<h2>Torrents Needing Seeds: $num</h2><table width=100% border=1 cellspacing=0 cellpadding=10><td align=left>");
while($res = mysql_fetch_assoc($need))
{
 echo("<a href=details.php?id=$res[id]><b>$res[name]</a> -<font color=red> ($res[leechers] leecher" . ($res[leechers] > 1 ? "s" : "") . ")</font></b><br>");
}
echo("</td></table>");
}

?>
<br>
<?

stdfoot();

mysql_query("UPDATE users SET last_browse=".gmtime()." where id=".$CURUSER['id']);

?>