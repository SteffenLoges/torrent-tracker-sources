<?

require "include/bittorrent.php";


dbconn();


loggedinorreturn();


$id = 0 + $_GET["id"];

$type = unesc($_GET["type"]);

$invite = $_GET["invite"];


stdhead("Invites");

function bark($msg) {

//  stdhead();

stdmsg("Invite Error", $msg);

  stdfoot();

  exit;

}

if ($id == 0){

  $id = $CURUSER["id"];

}


$res = mysql_query("SELECT invites FROM users WHERE id = $id") or sqlerr();

$inv = mysql_fetch_assoc($res);


if ($inv["invites"] != 1){

$_s = "s";

} else {

$_s = "";

}


if ($type == 'new'){

print("<form method=post action=takeinvite.php?id=$id>".

"<table border=1 width=750 cellspacing=0 cellpadding=5>".

"<tr class=tabletitle><td colspan=2><b>Create a new invite code ($inv[invites] invitation$_s left)</b></td></tr>".

"<tr class=tableb><td align=center colspan=2><input type=submit value=Create style='height: 20px'></td></tr>".

"</form></table>");

} 

else if ($type == 'del'){

$ret = mysql_query("SELECT * FROM invites WHERE invite = '$invite'") or sqlerr();

$num = mysql_fetch_assoc($ret);  

if ($num[inviter]==$id){

  print("You are allowed to delete $num[invitee]\n\n");

  mysql_query("DELETE FROM invites WHERE invite = '$invite'")or sqlerr();

  print("<table width=\"200\" border=\"0\"><tr><td align=center><b>Invite deleted</b></td></tr>");

  mysql_query("UPDATE users SET invites = ($CURUSER[invites]+1) WHERE id = $CURUSER[id]") or sqlerr();

  print("<tr><td align=center><b>Your number of invites has been updated</b></td></tr></table>");

} else 

  print("You are not allowed to delete this invite or this invite does not exist");

}

else {

if (get_user_class() <= UC_UPLOADER && !($id == $CURUSER["id"]))

{

bark("You have no right to view that users Invites! !");

}



$rel = mysql_query("SELECT COUNT(*) FROM users WHERE invitedby = $id") or sqlerr();

$arro = mysql_fetch_row($rel);

$number = $arro[0];



$ret = mysql_query("SELECT id, username, email, uploaded, downloaded, status, warned, enabled, donor, email FROM users WHERE invitedby = $id") or sqlerr();

$num = mysql_num_rows($ret);


print("<form method=post action=takeconfirm.php?id=$id><table border=1 width=750 cellspacing=0 cellpadding=5>".

"<tr class=tabletitle><td colspan=7><b>Current status of invitees</b> ($number)</td></tr>");


if(!$num){

print("<tr class=tableb><td colspan=7>No invitees yet.</tr>");

} else {



print("<tr class=tableb><td><b>Username</b></td><td><b>Email</b></td><td><b>Uploaded</b></td><td><b>Downloaded</b></td><td><b>Ratio</b></td><td><b>Status</b></td>");

if ($CURUSER[id] == $id || get_user_class() >= UC_SYSOP)

print("<td align=center><b>Confirm</b></td>");


print("</tr>");

for ($i = 0; $i < $num; ++$i)

{

  $arr = mysql_fetch_assoc($ret);

  if ($arr[status] == 'pending')

  $user = "<td align=left><a href=checkuser.php?id=$arr[id]>$arr[username]</a></td>";

  else

  $user = "<td align=left><a href=userdetails.php?id=$arr[id]>$arr[username]</a>" .($arr["warned"]  == "yes" ? "&nbsp;<img src=pic/warned.gif border=0 alt='Warned'>" : "")."&nbsp;" .($arr["enabled"]  == "no" ? "&nbsp;<img src=pic/disabled.gif border=0 alt='Disabled'>" : "")."&nbsp;" .($arr["donor"]  == "yes" ? "<img src=pic/star.gif border=0 alt='Donor'>" : "")."</td>";


  if ($arr["downloaded"] > 0) {

      $ratio = number_format($arr["uploaded"] / $arr["downloaded"], 3);

      $ratio = "<font color=" . get_ratio_color($ratio) . ">$ratio</font>";

      } else {

      if ($arr["uploaded"] > 0) {

      $ratio = "Inf.";

      }

      else {

      $ratio = "---";

      }

   }

  if ($arr["status"] == 'confirmed')

      $status = "<a href=userdetails.php?id=$arr[id]><font color=#1f7309>Confirmed</font></a>";

      else

      $status = "<a href=checkuser.php?id=$arr[id]><font color=#ca0226>Pending</font></a>";        

   

print("<tr class=tableb>$user<td>$arr[email]</td><td>" . mksize($arr[uploaded]) . "</td><td>" . mksize($arr[downloaded]) . "</td><td>$ratio</td><td>$status</td>");

if ($CURUSER[id] == $id || get_user_class() >= UC_SYSOP){

print("<td align=center>");

if ($arr[status] == 'pending')

print("<input type=\"checkbox\" name=\"conusr[]\" value=\"" . $arr[id] . "\" />");

print("</td>");

}


print("</tr>");  

} 

}

if ($CURUSER[id] == $id || get_user_class() >= UC_SYSOP){  

print("<input type=hidden name=email value=$arr[email]>");

print("<tr class=tableb><td colspan=7 align=right><input type=submit value='Confirm Users' style='height: 20px'></form></td></tr>");

}

print("</table><br>");


$rul = mysql_query("SELECT COUNT(*) FROM invites WHERE inviter = $id") or sqlerr();

$arre = mysql_fetch_row($rul);

$number1 = $arre[0];


$rer = mysql_query("SELECT inviteid, invite, time_invited FROM invites WHERE inviter = $id AND confirmed='no'") or sqlerr();

$num1 = mysql_num_rows($rer);

print("<table border=1 width=750 cellspacing=0 cellpadding=5>".

"<tr class=tabletitle><td colspan=6><b>Current status of created codes</b> ($number1)</td></tr><br/><font color=red>Every user has 4 Invites!");


if(!$num1){

print("<tr class=tableb><td colspan=6>No invitation codes created at the moment.</tr>");

} else {


print("<tr class=tableb><td><b>Invite Code</b></td><td><b>Created Date</b></td><td></td></tr>");

for ($i = 0; $i < $num1; ++$i)

{

  $arr1 = mysql_fetch_assoc($rer);

  print("<tr class=tableb><td>$arr1[invite]</td><td>$arr1[time_invited]</td>");

//  print("<td><input type=\"checkbox\" name=\"conusr[]\" value=\"" . $arr[id] . "\" /></td></tr>");

  print ("<td><a href=\"invite.php?invite=$arr1[invite]&type=del\">Delete Invitecode</a></td></tr>");

}

}

print("<tr class=tableb><td colspan=7 align=center><form method=post action=invite.php?id=$id&type=new><input type=submit value='Create Invite Code' style='height: 20px'></form></td></tr>");

print("</table>");


}


stdfoot();


die;


?>