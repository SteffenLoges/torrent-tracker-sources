<?

require_once("include/bittorrent.php");


dbconn();


stdhead("Login");

unset($returnto);
if (!empty($_GET["returnto"])) {
	$returnto = $_GET["returnto"];
	if (!$_GET["nowarn"]) {
		print("<h1>Not logged in!</h1>\n");
		print("<p><b>Error:</b> The page you tried to view can only be used when you're logged in.</p>\n");
	}
}

?>
<table cellpadding="5" width="400">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; Note</b></font><br />
</td></tr></table>
<table width="400" border="1" cellpadding="5">
 <tr>
    <td>
Login   
Attempts <b><?=Remaining ();?>.
</td>
 </tr>
  </table>


<br />
<table cellpadding="5" width="400">
<tr>
<td class="tablehead">
<font color="white"><b>&#187; Login</b></font><br />
</td></tr></table>
<form method="post" action="takelogin.php">
<table width="400" border="1" cellpadding="5">
 <tr>
    <td>
		<br />
	<b>Username:</b><br />
    <input type="text" style="width: 98%;" size="40" name="username" /><br/>
    <b>Password:</b><br />
    <input type="password" style="width: 98%;" size="40" name="password" /><br />
		<br />
      <input type="submit" value="Submit" class='btn' />
	  <br /><br /> 
	  <i>Cookies must be enabled in order to LOGIN.</i>
    </td>
	

  </tr>
</table>
<?

stdfoot();


?>
