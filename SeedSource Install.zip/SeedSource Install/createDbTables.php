<?

/* 	This is the SQL that creates the default tables used in the poller script from www.dhtmlgoodies.com	*/

//SQL that creates the tables needed in this demo

require "include/bittorrent.php";
dbconn();
	
loggedinorreturn();
if (get_user_class() < UC_SYSOP){
	echo "Access Denied!";
	die;
}

mysql_query("DROP TABLE IF EXISTS poller, poller_vote, poller_option;");
print("Dropping table poller, poller_vote, poller_option IF already EXISTS .. done!<br/>");

mysql_query("create table poller(ID int auto_increment not null primary key,
pollerTitle varchar(255))") or die(mysql_error());

print("Creating table poller .. done!<br/>");

mysql_query("create table poller_vote(
ID int auto_increment not null primary key,
optionID int(11), userID int(11), pollerID int(11),
ipAddress varchar(255))") or die(mysql_error());

print("Creating table poller_vote .. done!<br/>");

mysql_query("create table poller_option(
ID int auto_increment not null primary key,
pollerID int(11),
optionText varchar(255),
pollerOrder int,
defaultChecked char(1) default 0)") or die(mysql_error());
print("Creating table poller_option .. done!<br/>");

mysql_query("insert into poller(ID,pollerTitle)values('1','How would you rate this script?')");

print("Populating table poller with  \"'How would you rate this script?\" .. done! <br/>");

mysql_query("insert into poller_option(pollerID,optionText,pollerOrder,defaultChecked)values('1','Excellent','1','1')");
mysql_query("insert into poller_option(pollerID,optionText,pollerOrder)values('1','Very good','2')");
mysql_query("insert into poller_option(pollerID,optionText,pollerOrder)values('1','Good','3')");
mysql_query("insert into poller_option(pollerID,optionText,pollerOrder)values('1','Fair','3')");
mysql_query("insert into poller_option(pollerID,optionText,pollerOrder)values('1','Poor','4')");

print("Populating table poller_option with  dummy poll.. done!");

