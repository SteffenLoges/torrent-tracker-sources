<?
require_once("include/bittorrent.php");

dbconn();
$id = 0 + $_GET["id"];

mysql_query("UPDATE users SET status = 'confirmed' WHERE id IN (" . implode(", ", $_POST[conusr]) . ") AND status='pending'");
mysql_query("UPDATE invites SET confirmed='yes' WHERE inviteid IN (" . implode(", ", $_POST[conusr]) . ") AND confirmed='no'"); 

header("Refresh: 0; url=invite.php?id=$id");

?>