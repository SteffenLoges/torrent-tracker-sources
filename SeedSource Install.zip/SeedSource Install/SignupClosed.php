<?
require "include/bittorrent.php";
dbconn();

if (get_user_class() < UC_SYSOP)
stderr("Error", "Permission denied.");

if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
	mysql_query("REPLACE INTO config (name,value) VALUES ('signupclosed','".$var=$_POST['signupclosed']."')");
	if (mysql_affected_rows() != 1)
 stderr("Success", "The You Did IT.");
	
}

stdhead("Signup Closed");
?>
<h1>Signup Closed?</h1>
<table border=1 cellspacing=0 cellpadding=5>
<form method=post action=SignupClosed.php>
<tr><td><b>TRUE =====> OPEN<b><td/><tr/>
<tr><td><b>FALSE =====> CLOSED<b><td/><tr/>
<tr><td><input size=25 name=signupclosed></td><tr/>
<tr><td colspan=2><input type=submit class=btn value='Submit'></td></tr>
</form>
</table>
<?
stdfoot();
?>