<?php
require "include/bittorrent.php";

dbconn();
loggedinorreturn();

if (get_user_class() < UC_SYSOP)
        stderr("Error", "Permission denied.");
stdhead('Mass invite');
function select_class () {
?>
Class: <select name="class" style="width: 145px;">
<option value="-" style="color: gray;">( any class )</option>
<?
for ($i = 0; $i < 12; $i++) // We have total 12 class numbers as Defined. 
{
        if ($c = get_user_class_name($i))
                print("<option value=$i" . ($class && $class == $i ? " selected" : "") . ">$c</option>\n");
        else
          break;
}
?>
</select>
<?
}
if ($_POST['doit'] == 'yes') {
        $amount = 0+$_POST['amount'];
        $type = $_POST['type'];
        $allowed_type = array("-","+");
        if (!in_array($type, $allowed_type))
                $type = '+';
        $query = "enabled='yes' AND status='confirmed'";
        $class = $_POST['class'];
        if ($class == '-' || !is_valid_id($class))
        $class = '';
    if ($class)
        $query .= " AND class=$class";
        mysql_query("UPDATE users SET invites = invites $type $amount WHERE $query") or sqlerr(__FILE__, __LINE__);
        stdmsg("Message","Done...",true,'success');
        stdfoot();
        die;
}
?>
<h2>Give all users X invites?</h2>
<form action="massinvite.php" method="post">
<table border=1 cellspacing=0 cellpadding=5 width=100%>
<tr><td class="rowhead">
<input type = "hidden" name = "doit" value = "yes" />
Invite amount? <input type="text" name="amount" value="5" size="5" id="specialboxes">
</td>
<td class="rowhead">
<?=select_class();?>
</td>
<td class="rowhead">
Type <select name=type>
<option value="0" style="color: gray;">(Select invite type - / +)</option>
<option value="+">+</option>
<option value="-">-</option>
</select></td>
<td class="rowhead">
<input type="submit" value="Update Users" class=btn />
</td></tr></table>
</form>
<?
stdfoot();
?>