<?
ob_start("ob_gzhandler");
require "include/bittorrent.php";
dbconn();
stdhead("Rules");
//print("<td valign=top style=\"padding: 10px;\" colspan=2 align=center>");
begin_main_frame();
?>
<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>
<b>Welcome to <?=$SITENAME?>!</b><br><br>
Read this rules carefully, and you wont get banned/disabled.<br>
</td></tr></table>
<? $res = mysql_query("select * from rules order by id");
while ($arr=mysql_fetch_assoc($res)){
if ($arr["public"]=="yes"){
print("<br><table width=100% border=1 cellspacing=0 cellpadding=10>");
print("<tr><td class=colhead>:: $arr[title]</td></tr><tr><td><ul>\n");
print(format_comment($arr["text"]));
print("</td></tr>");
end_frame(); }
elseif($arr["public"]=="no" && $arr["class"]<=$CURUSER["class"]){
print("<br><table width=100% border=1 cellspacing=0 cellpadding=10>");
print("<tr><td class=colhead>:: $arr[title]</td></tr><tr><td><ul>\n");
print(format_comment($arr["text"]));
print("</td></tr>");
end_frame();
}
}
end_main_frame();
stdfoot(); ?>