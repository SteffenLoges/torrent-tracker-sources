<?
require "include/bittorrent.php";
dbconn(false);

$pic_base_url = "http://start.bounceme.net/pic/finger.jpg";

stdhead("Error 404");
print("Object not found!");
stdfoot();
?>