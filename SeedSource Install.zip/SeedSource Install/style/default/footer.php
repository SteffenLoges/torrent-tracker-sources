<?php
print("</td></tr></table></td></tr></table><center><br>\n");

?>
</br>
<span style="color:white"><b>Copyright 2011 � SEEDsource</b></span>
<?
print("</td></tr></table></center><br><br><br>\n");
print("</body></head></html>\n");