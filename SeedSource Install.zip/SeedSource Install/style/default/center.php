﻿<?php
?>
<script language=javascript>
function winop()
{
windop = window.open("moresmiles.php?form=shbox&text=shbox_text","mywin","height=400,width=450,resizable=yes,scrollbars=yes");
}
</script>



<table border="1" cellpadding="5" width="100%">
<tr>
<td class="tablehead">
<?
print("<font color=white><b>&#187; " . News . "</b> ");if (get_user_class() >= UC_ADMINISTRATOR)
print("<font class=small>[<a class=altlink href=news.php><font color=white>" . Modify . "</font></a>]</font>"); print("</font>");
?>
</td></tr></table> <?
$res = mysql_query("SELECT * FROM news WHERE ADDDATE(added, INTERVAL 45 DAY) > NOW() ORDER BY added DESC LIMIT 10") or sqlerr(__FILE__, __LINE__);
if (mysql_num_rows($res) > 0)
{
print("<table width=100% border=1 cellspacing=0 cellpadding=10><tr><td class=text>\n<ul>");
$news_flag = 0;

while($array = mysql_fetch_array($res))
{
$user = mysql_fetch_assoc(mysql_query("SELECT username FROM users WHERE id = $array[userid]")) or sqlerr(); 
if ($news_flag < 2) {

print("<a href=\"javascript: klappe_news('a".$array['id']."')\"><br><img border=\"0\" src=\"pic/minus.gif\" style=\"vertical-align: middle; padding-bottom: 2px;\" id=\"pica".$array['id']."\" alt=\"Show/Hide\">" . " - " . gmdate("M-d-y",strtotime($array['added'])) . " - " ."<b>". $array['title'] . " - " . "</b><font color=#ff0532> ($user[username]) </font></a>");
print("<div id=\"ka".$array['id']."\" style=\"display: block;\"> ".format_comment($array["body"],0)." </div><br> ");

$news_flag = ($news_flag + 1);
}
else {

print("<a href=\"javascript: klappe_news('a".$array['id']."')\"><br><img border=\"0\" src=\"pic/plus.gif\" style=\"vertical-align: middle; padding-bottom: 2px;\" id=\"pica".$array['id']."\" alt=\"Show/Hide\">" . gmdate("M-d-y",strtotime($array['added'])) . " - " ."<b>". $array['title'] . "</b> <!--($user[username])--> </a>");
print("<div id=\"ka".$array['id']."\" style=\"display: none;\"> ".format_comment($array["body"],0)." </div><br> ");
}

  
  if (get_user_class() >= UC_ADMINISTRATOR)
   {
	print(" <font size=\"-2\"><a class=altlink href=news.php?action=edit&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><img src=\"pic/editn.png\" alt=\"Edit News\" border=\"0\" title=\"Edit News\"/></a></font>");
	print(" <font size=\"-2\"><a class=altlink href=news.php?action=delete&newsid=" . $array['id'] . "&returnto=" . urlencode($_SERVER['PHP_SELF']) . "><img src=\"pic/ntrash.gif\" alt=\"Delete Item\" border=\"0\" title=\"Delete Item\"/></a></font>");
	}
	print("<div id=\"ka".$array['id']."\" style=\"display: none;\"> ".format_comment($array["body"],0)."</div>");
	print("</li>");
  }
  print("</ul></td></tr></table>\n");

}
?>
<br />

<table border="1" cellpadding="6" width="100%">
<tr>
<td class="tablehead">
<font color=white><b>&#187; Online - <font color="red"><?=$totalonline?></font></b></font>
</td></tr></table>
<table width=100% border=1 cellspacing=0 cellpadding=5><tr>
  <td class=text>
<?=$activeusers;?><br /></td>
</tr></table>
<br/>


<br />

<table border="1" cellpadding="6" width="100%">
<tr>
<td class="tablehead">
<font color=white><b>&#187; Disclaimer</b></font>
</td></tr></table>
<table width=100% border=1 cellspacing=0 cellpadding=5><tr>
  <td class=text>
  <p><font class=Large>None of the files shown here are actually hosted on this server. The links are provided solely by this site's users.
The administrator of this site <?=$BASEURL?> cannot be held responsible for what its users post, or any other actions of its users.
You may not use this site to distribute or download any material when you do not have the legal rights to do so.
It is your own responsibility to adhere to these terms.</font></p>

<p align=center>
<a href="http://getfirefox.com"><img border="0" alt="Get Firefox!" title="Get Firefox!" src=pic/firefox.png /></a>
<a href="http://utorrent.com"><img border="0" alt="Get uTorrent!" title="Get Utorrent!" src=pic/utorrent.png /></a>
<a href="http://azureus.sourceforge.net"><img border="0" alt="Get Azureus!" title="Get Azureus!" src=pic/azureus.png /></a>
</p>
</td>
</tr></table>



</td>
</tr></table>
</td></tr></table>