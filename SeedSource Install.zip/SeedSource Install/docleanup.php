<?

require_once("include/bittorrent.php");

dbconn();
loggedinorreturn();

if (get_user_class() < UC_SYSOP)
        stderr("Error", "Access denied.");

stdhead("Do cleanup");

docleanup();

print("Done");
print("<p>Back to <a href=staffpanel.php><b>CPanel</b></a></p>");

stdfoot();

?>