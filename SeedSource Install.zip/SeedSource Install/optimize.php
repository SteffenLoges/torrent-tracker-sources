<?
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();
if (get_user_class() < UC_SYSOP) {
die("Access denied.");
}
stdhead("Optimize DB");

        // optimize database
        mysql_query("OPTIMIZE TABLE `addedrequests` , `adminpanel` , `announcement` , `avps` , `bans` , `blocks` , `bonus` , `categories` , `cheaters` , `comments` , `countries` , `faq` , `files` , `forums` , `friends` , `messages` , `modpanel` , `news` , `offers` , `offervotes` , `peers` , `pollanswers` , `polls` , `posts` , `readposts` , `requests` , `rules` , `sitelog` , `stylesheets` , `sysoppanel` , `topics` , `torrents` , `users`");

        print("Done!");
stdfoot();
?>