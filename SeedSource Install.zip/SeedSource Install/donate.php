<?
require "include/bittorrent.php";
dbconn(false);
loggedinorreturn();

stdhead();
?>

<b><a href=sendmessage.php?receiver=8>SEND US</a> a pm if you wish to make a donation. Only send a pm if you are serious about donating! Thanks</b>
<p>
<? begin_main_frame(); begin_frame(); ?>
<table border=0 cellspacing=0 cellpadding=0><tr valign=top>
<td class=embedded>
<img src=pic/flag/romania.gif style='margin-right: 10px'>
</td>
<td class=embedded>
Thank you for the donation.<br/> It will help keep Start.Bounceme.net up and running. <br/>Donating over $20.00 will get your class bumped to VIP. <br/>You are still encouraged to keep a proper ratio but are immune to automatic demotion and account deletion. <br/>Your account can still be manually deleted but it is rare. <br/>I almost forgot, you get a pretty star next to your name too. 
<br><br>
There are no other ways to donate at this moment. <br/>This is very easy to use and no one should have any problems.<br>
<br>
</td>
</tr></table>
<? end_frame(); end_main_frame(); ?>
</p>

<b>After you have donated -- make sure to <a href=sendmessage.php?receiver=8>SEND US</a> the <font color=red>transaction id</font> so we can give you credit. thx!</b>
<?
stdfoot();
?>