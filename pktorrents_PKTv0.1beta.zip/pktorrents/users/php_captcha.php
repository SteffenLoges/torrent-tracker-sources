<?php
session_start();
$RandomStr = md5(microtime());// md5 to generate the random string
$ResultStr = substr($RandomStr,0,5);//trim 5 digit
$NewImage =imagecreatefromjpeg("img.jpg");//image create by existing image and as back ground
$LineColor = imagecolorallocate($NewImage, 175,157,213);//line color
$LineColor2 = imagecolorallocate($NewImage, 153,165,123);//line color
$TextColor = imagecolorallocate($NewImage, 000, 000, 000);//text color-white
imageline($NewImage,1,1,40,40,$LineColor);//create line 1 on image
imageline($NewImage,1,100,60,0,$LineColor);//create line 2 on image
imageline($NewImage,35,1,75,20,$LineColor2);//create line 3 on image
imageline($NewImage,1,15,75,5,$LineColor2);//create line 4 on image
for ($i = 0; $i <= 256; $i++) {
$point_color = imagecolorallocate ($NewImage, rand(0,255), rand(0,255), rand(0,255));
imagesetpixel($NewImage, rand(2,64), rand(2,38), $point_color);
}
$str_array=array();
$len=strlen($ResultStr);
for($i=0;$i<$len;$i++) $str_array[]=$ResultStr{$i};
imagestring($NewImage, 5, rand(2,10), rand(2,11), $str_array[0], $TextColor);// Draw a random string horizontally
imagestring($NewImage, 5, rand(18,25), rand(2,11), $str_array[1], $TextColor);// Draw a random string horizontally
imagestring($NewImage, 5, rand(33,40), rand(2,11), $str_array[2], $TextColor);// Draw a random string horizontally
imagestring($NewImage, 5, rand(47,55), rand(2,11), $str_array[3], $TextColor);// Draw a random string horizontally
imagestring($NewImage, 5, rand(61,68), rand(2,11), $str_array[4], $TextColor);// Draw a random string horizontally
$_SESSION['key'] = $ResultStr;// carry the data through session
header("Content-type: jpeg");// out out the image
imagejpeg($NewImage);//Output image to browser
?>
