<?php
session_start();

if(isset($_REQUEST['Submit'])){
      $key=substr($_SESSION['key'],0,5);
      $number = $_REQUEST['number'];
      if($number!=$key){
          echo '<center><font face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000">
		   Validation string not valid! Please try again!</font></center>';}

      else{ }
          }
?>


<form name="entryform" method="post" action="<?=$CFG->wwwroot?>/users/index.php?mode=register" onSubmit="return check()"; >
<table >
<tr><td width="300" class="normal">
<p class="normal"><br>Please fill out the registration form. <br>*Note that all fields are mandatory.
</p>
</td>
<td><br><br>
<table bgcolor="#242424">
<tr>
	<td class="label">*Username:</td>
	<td><input type="text" name="username" size="25" value="<? pv($frm["username"]) ?>">
		<?err($errors->username)?>
	</td>
</tr>


<tr>
	<td class="label">*Password:</td>
	<td><input type="password" name="password" size="25">
		<?err($errors->password)?>
	</td>
</tr>
<tr>
	<td class="label">*Password:(confirm)</td>
	<td><input type="password" name="password2" size="25">
		<?err($errors->password)?>
	</td>
</tr>

<tr>
	<td class="label">*Email:</td>
	<td><input type="text" name="email" size="25" value="<? pv($frm["email"]) ?>">
		<?err($errors->email)?>
	</td>
</tr>
   <tr>
   <td class="label"> Please enter the code shown in the image.</td>
  <td><img src="php_captcha.php"><input name="number" size="25" type="text" id=\&quot;number\&quot;></td>
<td></td>
</tr>

<tr><td colspan="2"><hr></td></tr>
<tr>
	<td colspan="2" align="left"><input  name="Submit" type="submit" value="Register"/></td>
</tr>
</table>
</td></tr>
</table>
</form>
