<p class="normal">
Your password has been sent to your email address, you should receive it
shortly. 
</p>
