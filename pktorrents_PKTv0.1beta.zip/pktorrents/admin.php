<?php

/*
SBT1 - SqrtBoy's Bittorrent Tracker v1 (GPL)
Based on FBT2 from Flippy
Website: http://www.phpsoft.org
Email: sqrtboy@phpsoft.org
*/

session_start();

if (isset($_POST['keycode']))
	$_SESSION['keycode'] = (string)$_POST['keycode'] ;


if ($_SESSION['keycode'] != "yourneedtochangethis" )
{
?>
  <b>Please enter your personal keycode to enter website:</b>
	  <br /><br />
	  <form name="submit" method="POST">
		<input type="text" name="keycode">
		<input type="submit" value="Enter Site">
	  </form>
<?
}
else
{





function getstat($hash)
{
	global $time;
	$handle = fopen('tracked/'.$hash, 'rb+');
	flock($handle, LOCK_EX);
	$length = filesize('tracked/'.$hash);
	
	if ($length)
	{
		$x = fread($handle, $length);
	}
	
	flock($handle, LOCK_UN);
	fclose($handle);
	
	$complete	= 0;
	$incomplete	= 0;
	$no_peers = $length / 7;
	
	for ($j=0;$j<$no_peers;$j++)
	{
		$t_peer_seed = implode('', unpack('C', substr($x, $j * 7, 1)));
		
		if ($t_peer_seed >= 128)
		{
			$complete++;
		}
		else
		{
			$incomplete++;
		}
	}
	
	return '<tr><td><a href="./admin.php?info_hash='.$hash.'">'.$hash.'</a></td><td align="right">'.number_format($complete).'</td><td align="right">'.number_format($incomplete).'</td></tr>';
}

ob_start('ob_gzhandler');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head><title>Bittorrent-Support.com Tracker</title><link type="text/css" rel="stylesheet" href="style.css" /></head><body><div align="center"><?php

if (!empty($_GET['info_hash']) and file_exists('tracked/'.$_GET['info_hash']))
{
	echo '<table width="400" cellspacing="1" cellpadding="2"><tr><th width="30%">IP</th><th width="20%">Status</th><th width="20%">Port</th><th width="30%">Last Action</th></tr>';
	
	$handle = fopen('tracked/'.$_GET['info_hash'], 'rb+');
	flock($handle, LOCK_EX);
	$length = filesize('tracked/'.$_GET['info_hash']);
	
	if ($length)
	{
		$x = fread($handle, $length);
	}
	
	flock($handle, LOCK_UN);
	fclose($handle);
	
	$complete = 0;
	$imcomplete = 0;
	$no_peers = $length / 7;
	
	for ($j=0; $j<$no_peers; $j++)
	{
		$ip			 = unpack('C*', substr($x, $j * 7 + 1, 4));
		$ip			 = $ip[1].'.'.$ip[2].'.'.$ip[3].'.'.$ip[4];
		$port		 = implode('', unpack('n*', substr($x, $j * 7 + 5, 2)));
		$t_peer_seed = implode('', unpack('C', substr($x, $j * 7, 1)));
		
		if ($t_peer_seed >= 128)
		{
			$what = '<span class="seeder">Seeder</span>';
			$t_time = $t_peer_seed-128 ;
		}
		else
		{
			$what = 'Leecher';
			$t_time = $t_peer_seed;
		}
		
		$time = time() % 7680 / 60;
		echo '<tr><td>'.$ip.'</td><td>'.$what.'</td><td align="right">'.$port.'</td><td align="right">'.((round($time - $t_time)<0) ? (128 + round($time - $t_time)) : round($time - $t_time)).' min ago</td></tr>';
	}
	echo '</table>';
	//echo '<table cellspacing="10" cellpadding="0"><tr><tr><a href="http://www.google.com/search?q=site%3A+www.torrentz.com+'.$_GET['info_hash'].'">Search for this torrent</a></tr></tr></table>';
}
else
{
?><table width="400" cellspacing="1" cellpadding="2"><tr><th width="80%">Hash</th><th width="10%">UL</th><th width="10%">DL</th></tr><?php

$handle = opendir('tracked');
while (($file = readdir($handle)) !== false)
{
	if ($file != '.' and $file != '..' and $file != '.htaccess')
	{
	    echo getstat($file);
	}
}
closedir($handle);
?></table><?php
}
?><br /><a href="./admin.php">Reload</a></div></body></html>
<?
}
?>
