<?
function ratetor($name)
{
        if  (is_logged_in()){
          if (file_exists("votes/$name.txt")) {

        $fp = fopen("votes/$name.txt", "r");
        $line = fgets($fp,4096);



        $t_votes = strrchr($line, "|");
        $t_votes = str_replace("|", "", $t_votes);
        $t_votes = trim($t_votes);

        $line = strrev($line);
        $x_votes = strrchr($line, "|");
        $x_votes = strrev($x_votes);
        $x_votes = str_replace("|", "", $x_votes);
        $x_votes = trim($x_votes);

        fclose($fp);



        if (($t_votes == 0) AND ($x_votes == 0))
        {

            $stars_oui = 0;
            $note = "0.00";
        }
        else
        {
            $round_votes = $t_votes/$x_votes;
            $stars = round($round_votes);
            $note = round($round_votes, 2);
        }

        $Result = "<table border='0' width='100%' ><tr><td width='70%'>";

        if ($x_votes > 0)
        {
            $Result .="<img src=\"rating/".$stars."stars.gif\" border=\"0\" alt=\"Rate\">";
            $Result .="  (Ratings: ".$note."  /  5";
            $Result.=" - Votes:  ".$x_votes.")";
        }
        else $Result .="No votes yet";

        if (!isset($_COOKIE[$name]))
        {
            $Result.="</td>";
            $Result.="<td width=\"30%\" align=left>
            <form action=\"takerate.php?name=$name\" method=\"post\"   onSubmit=\"alert('Thank you for rating!');\" ><select name=\"note\">";
            $Result.="<option value =\"5\">5 - Excellent !</option>";
            $Result.="<option value =\"4\">4 - Very Good !</option>";
            $Result.="<option value =\"3\">3 - Fair !</option>";
            $Result.="<option value =\"2\">2 - Ok !</option>";
            $Result.="<option value =\"1\">1 - Poor !</option>";
            $Result.="<option value =\"0\">0 - Awful !</option>";
            $Result.="</select>";
            $Result.=" <input type=\"submit\" value=\"Rate\"></form>";
        }
        else $Result.=" - You have already rated this torrent.";

        $Result.="</td></tr></table>";
    }
    else
    {
        $Result = "<table border='0' width='100%'><tr><td width=\"20%\">";
        $Result.="No votes yet<br></td>";
        $Result.="<td width=\"80%\" align=left><form name=\"rate\" action=\"takerate.php?name=$name\" method=\"post\"   onSubmit=\"alert('Thank you for voting!');\" > <select name=\"note\" style=\"margin: 0; font-size: 6 pt; font-family: Verdana; border: 0\">";
        $Result.="<option value =\"5\">5 - Excellent !</option>";
        $Result.="<option value =\"4\">4 - Very Good !</option>";
        $Result.="<option value =\"3\">3 - Fair !</option>";
        $Result.="<option value =\"2\">2 - Ok !</option>";
        $Result.="<option value =\"1\">1 - Poor !</option>";
        $Result.="<option value =\"0\">0 - Awful !</option>";
        $Result.="</select>";
        $Result.=" <input type=\"submit\" value=\"Rate\">";
        $Result.="</form></td></tr></table>";
    }

    return $Result;
       }else{
         if (file_exists("votes/$name.txt")) {

        $fp = fopen("votes/$name.txt", "r");
        $line = fgets($fp,4096);

        //we retrieve variables

        $t_votes = strrchr($line, "|");
        $t_votes = str_replace("|", "", $t_votes);
        $t_votes = trim($t_votes);

        $line = strrev($line);
        $x_votes = strrchr($line, "|");
        $x_votes = strrev($x_votes);
        $x_votes = str_replace("|", "", $x_votes);
        $x_votes = trim($x_votes);

        fclose($fp);

        // Calculs :

        if (($t_votes == 0) AND ($x_votes == 0))
        {
            // Si fichier vide
            $starsyes = 0;
            $note = "0.00";
        }
        else
        {
            $round_votes = $t_votes/$x_votes;
            $stars = round($round_votes);
            $note = round($round_votes, 2);
        }

        $Result = "";

        if ($x_votes > 0)
        {

            $Result .="<img src=\"rating/".$stars."stars.gif\" border=\"0\" alt=\"Rate\">";
            $Result .="  (Ratings: ".$note."  /  5";
            $Result.=" - Votes:  ".$x_votes.")";

        }
        else $Result .="No votes yet";

        if (!isset($_COOKIE[$name]))
        {

            $Result.="";

        }
        else $Result.="";

        $Result.="";
    }
    else
    {

        $Result .="Unrated";


    }

    return $Result;
       }
}
////////////////////////


//for frontpage missing all info apart from stars
function smallrate($name)
{

    if (file_exists("votes/$name.txt")) {

        $fp = fopen("votes/$name.txt", "r");
        $line = fgets($fp,4096);

        //we retrieve variables

        $t_votes = strrchr($line, "|");
        $t_votes = str_replace("|", "", $t_votes);
        $t_votes = trim($t_votes);

        $line = strrev($line);
        $x_votes = strrchr($line, "|");
        $x_votes = strrev($x_votes);
        $x_votes = str_replace("|", "", $x_votes);
        $x_votes = trim($x_votes);

        fclose($fp);

        // Calculs :

        if (($t_votes == 0) AND ($x_votes == 0))
        {
            // Si fichier vide
            $starsyes = 0;
            $note = "0.00";
        }
        else
        {
            $round_votes = $t_votes/$x_votes;
            $stars = round($round_votes);
            $note = round($round_votes, 2);
        }

        $Result = "";

        if ($x_votes > 0)
        {
            $Result .="<img src=\"rating/".$stars."stars.gif\" border=\"0\" alt=\"Rate\">";

        }
        else $Result .="No votes yet";

        if (!isset($_COOKIE[$name]))
        {
          $Result.="";
        }
     else $Result.="";
          $Result.="";
    }else{

          $Result .="Unrated";
        }

   return $Result;
}

?>
