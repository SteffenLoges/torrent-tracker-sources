-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 19, 2007 at 09:20 PM
-- Server version: 5.0.18
-- PHP Version: 5.1.2
-- 
-- Database: `pktorrents`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `ban`
-- 

CREATE TABLE IF NOT EXISTS `ban` (
  `ip` varchar(60) NOT NULL default '',
  `reason` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `ban`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `categories`
-- 

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `weight` int(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `categories`
-- 

INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (4, 'Movies', '4', 4);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (3, 'Games', '3', 3);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (2, 'Ebooks', '2', 2);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (1, 'Anime', '1', 1);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (5, 'Music', '5', 5);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (6, 'Softwere / Apps', '6', 6);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (7, 'TV', '7', 7);
INSERT INTO `categories` (`id`, `name`, `image`, `weight`) VALUES (8, 'Other', '8', 8);

-- --------------------------------------------------------

-- 
-- Table structure for table `comments`
-- 

CREATE TABLE IF NOT EXISTS `comments` (
  `id` varchar(50) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  `post` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `name` varchar(60) NOT NULL default '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `comments`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `downloads`
-- 

CREATE TABLE IF NOT EXISTS `downloads` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `path` varchar(255) NOT NULL default '',
  `count` int(5) NOT NULL default '0',
  `date` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

-- 
-- Table structure for table `links`
-- 

CREATE TABLE IF NOT EXISTS `links` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `button1` varchar(255) NOT NULL default '0',
  `button2` varchar(255) NOT NULL default '0',
  `link` varchar(255) NOT NULL default '0',
  `weight` int(3) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `links`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `log`
-- 

CREATE TABLE IF NOT EXISTS `log` (
  `ip` varchar(255) NOT NULL default '',
  `date` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `log`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `namemap`
-- 

CREATE TABLE IF NOT EXISTS `namemap` (
  `info_hash` varchar(40) NOT NULL default '',
  `filename` varchar(250) NOT NULL default 'ERROR IN YOUR SETUP',
  `filename2` varchar(40) NOT NULL default 'ERROR IN YOUR SET UP',
  `url` varchar(250) NOT NULL default 'ERROR UN YOUR SETUP',
  `info` varchar(250) NOT NULL default '',
  `data` datetime NOT NULL default '0000-00-00 00:00:00',
  `size` bigint(20) NOT NULL default '0',
  `comment` text,
  `category` int(10) unsigned NOT NULL default '6',
  `subcategory` int(11) NOT NULL default '0',
  `announce_url` varchar(100) NOT NULL default '',
  `uploader` varchar(40) NOT NULL default 'Guest',
  `lastupdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `anonymous` enum('true','false') NOT NULL default 'false',
  `autoupdater` varchar(100) NOT NULL default '0',
  `seeds` int(11) NOT NULL default '0',
  `leechers` int(10) default '0',
  `finished` int(10) default '0',
  `registration` enum('true','false') NOT NULL default 'false',
  `download` varchar(10) NOT NULL default '0',
  `magnet` text NOT NULL,
  `site_id` int(11) NOT NULL default '0',
  `site` varchar(50) NOT NULL default '',
  `submitter` varchar(45) NOT NULL default '3',
  PRIMARY KEY  (`info_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `namemap`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `news`
-- 

CREATE TABLE IF NOT EXISTS `news` (
  `news_id` mediumint(8) unsigned NOT NULL auto_increment,
  `title` tinytext NOT NULL,
  `content` text NOT NULL,
  `author` varchar(16) NOT NULL default '',
  `email` varchar(50) default NULL,
  `date` varchar(10) NOT NULL default '',
  `time` varchar(8) NOT NULL default '',
  PRIMARY KEY  (`news_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `news`
-- 

INSERT INTO `news` (`news_id`, `title`, `content`, `author`, `email`, `date`, `time`) VALUES (8, 'Proxykills Torrenthoster PKT-0.1beta', '\r\n<p>PKT-0.1beta is hugely based on torrenthoster, the open-source torrent lister...<br>\r\n<br>\r\nChanges in Pr0xyk1LLs version:<br>\r\n*Changed Layout and added the functionality of changing the layout and \r\ncolour/theme in the config file.<br>\r\n<br>\r\n* Added Torrent Rating<br>\r\n<br>\r\n* Added Torrent Update<br>\r\n<br>\r\n* Added Ajax For Torrent details<br>\r\n<br>\r\n* Added Copyright section<br>\r\n<br>\r\n* Added Ibitzy Torrent Spider WITH STATS! Into Admin<br>\r\n<br>\r\n* Added Files popup on main<br>\r\n<br>\r\n* Added Global downloads<br>\r\n<br>\r\n* Changed Admin Layout<br>\r\n<br>\r\n* Added BB Code for Torrent Descriptions<br>\r\n<br>\r\n*Added SBTv1 Tracker (Still in Beta, But it works) Next version will have better \r\nstats on each torrent<br>\r\n&nbsp;</p>\r\n', 'Admin', NULL, '2007-01-23', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `subcategories`
-- 

CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(10) NOT NULL auto_increment,
  `catid` int(10) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `subcategories`
-- 

INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (34, 5, 'Rap');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (35, 5, 'Rock');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (32, 5, 'Punk');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (33, 5, 'R&B');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (31, 5, 'Pop');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (30, 5, 'Hip Hop');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (27, 4, 'Wallpapers');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (26, 4, 'Other');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (25, 3, 'Religion');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (24, 3, 'Other');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (23, 3, 'Manuals');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (22, 3, 'Funny clips');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (21, 3, 'Flash/Shockwave');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (20, 3, 'Comics');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (19, 3, 'Articles');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (18, 2, 'Soundtracks');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (17, 2, 'Rock');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (16, 2, 'Rap');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (15, 2, 'R&B');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (14, 2, 'Punk');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (13, 2, 'Pop');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (12, 2, 'Hip Hop');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (11, 2, 'Classic');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (10, 2, 'Alternative');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (9, 1, 'Thriller');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (8, 1, 'Romance');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (7, 1, 'Martial Arts');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (6, 1, 'Horror');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (5, 1, 'Family');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (4, 1, 'Drama');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (1, 1, 'Action');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (2, 1, 'Adventure');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (3, 1, 'Comedy');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (29, 5, 'Classic');
INSERT INTO `subcategories` (`id`, `catid`, `name`) VALUES (28, 5, 'Alternative');

-- --------------------------------------------------------

-- 
-- Table structure for table `un_processed`
-- 

CREATE TABLE IF NOT EXISTS `un_processed` (
  `id` int(5) NOT NULL auto_increment,
  `url` text NOT NULL,
  `tid` int(10) NOT NULL,
  `site` varchar(255) NOT NULL,
  `date` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL default 'new',
  `cat` varchar(100) default NULL,
  `subcat` varchar(100) default NULL,
  `stamp` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `date` (`date`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `un_processed`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userName` varchar(40) NOT NULL default '',
  `password` varchar(40) NOT NULL default '0',
  `privilege` varchar(10) NOT NULL default '',
  `email` varchar(30) NOT NULL default '',
  `joined` datetime NOT NULL default '0000-00-00 00:00:00',
  `lastconnect` datetime NOT NULL default '0000-00-00 00:00:00',
  `showemail` tinyint(3) unsigned NOT NULL default '0',
  `totalpost` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userName` (`userName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`id`, `userName`, `password`, `privilege`, `email`, `joined`, `lastconnect`, `showemail`, `totalpost`) VALUES (3, 'Admin', '1844156d4166d94387f1a4ad031ca5fa', 'admin', 'admin@yourdomain.com', '2007-01-06 21:12:46', '2007-01-06 21:12:46', 0, 0);
