<?php
/*
SBT1 - SqrtBoy's Bittorrent Tracker v1 (GPL)
Based on FBT2 from Flippy
Website: http://www.phpsoft.org
Email: sqrtboy@phpsoft.org
*/

function getstat($hash) {
	global $time;
	
	if (!file_exists('tracked/'.$hash))
		touch('tracked/'.$hash);
		
	$handle = fopen('tracked/'.$hash, 'rb+');
	flock($handle, LOCK_EX);
	$length = filesize('tracked/'.$hash);
	
	if (!$length)
	{
		flock($handle, LOCK_UN);
		fclose($handle);
		return;
	}
	
	$x = fread($handle, $length);
	$no_peers = $length / 7;
	
	$complete	= 0;
	$incomplete	= 0;
	
	for ($j=0; $j<$no_peers; $j++)
	{
		$t_peer_seed = implode('', unpack('C', substr($x, $j * 7, 1)));
		
		if ($t_peer_seed >= 128)
		{
			$complete++;
			$t_time = $t_peer_seed - 128;
		}
		else
		{
			$incomplete++;
			$t_time = $t_peer_seed;	
		}
		
		if ($time - 40 <= $t_time and $time >= $t_time or $time + 88 < $t_time)
		{
			$new_data .= substr($x, $j * 7, 7);
		}
	}

	if ($complete + $incomplete > 0)
	{
		echo '20:'.pack('H*', $hash).'d8:completei'.$complete.'e10:incompletei'.$incomplete.'ee';
	}
	
	rewind($handle);
	ftruncate($handle, 0);
	fwrite($handle, $new_data);
	flock($handle, LOCK_UN);
	fclose($handle);
}

$time = intval((time() % 7680) / 60);
header('Content-type: text/plain');

if ($_GET['info_hash'])
{
	// On-the-fly compression, use lowest level to save CPU
	ini_set('zlib.output_compression_level', 9);
	ob_start('ob_gzhandler');
	
	echo 'd5:filesd';
	
	if (get_magic_quotes_gpc())
	{
		$_GET['info_hash'] = stripslashes($_GET['info_hash']);
	}
	
	if (strlen($info_hash) != 20)
	{
		exit('d14:failure reason14:Invalid info_hashe');
	}
	
	getstat(bin2hex($_GET['info_hash']));
	echo 'ee';
}
else
{
	if (strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false)
	{
		header('Content-Encoding: gzip');
		$gzip = true;
	}
	
	if ( file_exists('scrape') && @filemtime('scrape') > (time() - 60))
	{
		if ($gzip)
		{
			readfile('scrape');
		}
		else
		{
			
			// DUH!
			$handle = fopen('scrape', 'rb');
			echo gzuncompress(fread($handle, filesize('scrape')));
			fclose($handle);
		}
	}
	else
	{
		ob_start("gz_handler");
		echo 'd5:filesd';
		
		$handle = opendir('data');
		
		while (($file = readdir($handle)) !== false)
		{
			if ($file != '.' and $file != '..' and $file != '.htaccess')
			{
				getstat($file);
			}
		}
		
		closedir($handle);
		echo 'ee';
		
		if ($gzip)
		{
			// ob_get_contents + ob_end_clean for PHP < 4.3
			$output = "\x1f\x8b\x08\x00\x00\x00\x00\x00".gzcompress(ob_get_clean(), 9);
			echo $output;
		}
		else
		{
			$output = "\x1f\x8b\x08\x00\x00\x00\x00\x00".gzcompress(ob_get_contents(), 9);
			ob_flush();
			flush();
		}
		
		$handle = fopen('scrape', 'wb');
		flock($handle, LOCK_EX);
		fwrite($handle, $output);
		flock($handle, LOCK_UN);
		fclose($handle);
	}
}
?>
