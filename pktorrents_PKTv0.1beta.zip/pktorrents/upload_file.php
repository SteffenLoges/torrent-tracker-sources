<?php
include("config.php");
include "validator.php";

switch (nvl($_REQUEST["mode"]))

{
	case "upload" :
		upload($_REQUEST["id"]);
		break;
}

function upload($id){
// if file type gif or jpg or png and under 100kb then do.
 if (($_FILES["file"]["type"] == "image/gif")|| ($_FILES["file"]["type"] == "image/jpeg") || ($_FILES["file"]["type"] == "image/png") && ($_FILES["file"]["size"] < 100000))

    { if ($_FILES["file"]["error"] > 0)
      {
      echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
      }
      else
      {

      echo "Upload: " . $_FILES["file"]["name"] . "<br />";
      echo "Type: " . $_FILES["file"]["type"] . "<br />";
      echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";


               if ($_FILES["file"]["type"] == "image/jpeg"){
               
                  if (file_exists("upload/$id.jpg" . $_FILES["file"]["name"])){
                  
                  echo $_FILES["file"]["name"] . " already exists. ";
                  }

                   else{
                         move_uploaded_file($_FILES["file"]["tmp_name"],
                         "upload/$id.jpg");
                         echo "Uploaded. <br />Please refresh to see the new screenshot.";
                        }
}else{
                     if (file_exists("upload/$id.gif" . $_FILES["file"]["name"])){
	             echo $_FILES["file"]["name"] . " already exists. ";
	             }
                     else{
                         move_uploaded_file($_FILES["file"]["tmp_name"],
	                 "upload/$id.gif");
	                 echo "Uploaded. <br />Please refresh to see the new screenshot.";
                          }
                      }
}
}

  else
    {
    echo "Invalid file";
    }



}
?>
