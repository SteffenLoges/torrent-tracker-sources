<link rel="stylesheet" href="./templates/colours.php" type="text/css" />

<?php
    while ($r = db_fetch_object($qid))
{
	$ip=$_SERVER['REMOTE_ADDR'];
	if(isset($_POST['submitted']))
	{
	$commentid = strip_tags(trim($_GET['id']));
	$name = $_SESSION['userName'];
	$comment = trim($_POST['comment']);

	$date = date('YmdHis');
	if ($comment == '')
		{
	stheader('Comment failed!');
	echo '<div id="commeror" class="fade-FFBFBF" style="padding:.2em"><br /><h3>Error. Please check again.</h3></div>';
	echo "</div><div id=\"footer\"><p>Rendertime: 0</p>";


  	die;
		}

	stheader('Comment submitted');
	mysql_query("INSERT INTO comments (id,ip,date,name,post) VALUES ('$commentid','$ip','$date','$name','$comment')");
	echo '<div id="commplete" class="fade-DAFF9F" style="padding:.2em"><br /><h3>Comment posted! Thanks.</h3></div>';
}


// Fetch comments from sql
$result = mysql_query("SELECT * FROM comments WHERE id ='".strip_tags(trim($_GET['id']))."'");
$comment_count = mysql_num_rows($result);

// div colors
$color1 = 'class="light"';
$color2 = 'class="dark"';
$row_count = 0;
  ?> <div >
<p><span><font size="5"><?= pv($r->filename) ?></font></span></p>

<div>
<table width="100%" border="0">
  <tr>
    <?
echo '<h3>Comments ('.$comment_count.')</h3>';
if (!$comment_count == 0)
{
echo ' ';
while ($row = mysql_fetch_array($result))

{
extract($row);
$row_color = ($row_count % 2) ? $color1 : $color2;


echo '<div '.$row_color.'><strong><a href="'.$CFG->wwwroot.'/users/index.php?mode=userinfo&username='.htmlentities($name).'">'.htmlentities($name).'</a></strong> On <strong>'.$date.'</strong><br /><br />'.nl2br(htmlentities($post)).'</div><hr>';
$row_count++;
}
}
 ?>

  </tr></table>

</div>
</div><?
//echo '<h3>Comments ('.$comment_count.')</h3>';
if (!$comment_count == 0)
{
echo '<div class="commentwrapper">';
while ($row = mysql_fetch_array($result))

{
extract($row);
$row_color = ($row_count % 2) ? $color1 : $color2;


echo '<div '.$row_color.'><strong><a href="'.$CFG->wwwroot.'/users/index.php?mode=userinfo&username='.htmlentities($name).'">'.htmlentities($name).'</a></strong> On <strong>'.$date.'</strong><br /><br />'.nl2br(htmlentities($post)).'</div><hr>';
$row_count++;
}
}


if (is_logged_in()) {

$result = mysql_query("SELECT * FROM ban WHERE ip = '$_SERVER[REMOTE_ADDR]'");

if (mysql_num_rows($result) == 1)
{
echo '<br /><br /><h3>You cant add any comments!</h3>You cant add any comments because you where banned for some reason.';
die;
}

echo '<br /><form id="comment" action="torrents.php?mode=comment_detail&id='.strip_tags(trim($_GET['id'])).'" method="post">';

echo '<textarea name="comment" value="Comment" cols="50" rows="7"></textarea><br />';
echo '<input type="submit" name="submitted" value="submit" /></form>';
echo "<br>Please do not flood your comments. Your IP Address is being logged. ($ip)<br></div>";
}
}
?>
 </div>
