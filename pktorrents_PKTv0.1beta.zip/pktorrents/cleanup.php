<?php

/*
SBT1 - SqrtBoy's Bittorrent Tracker v1 (GPL)
Based on FBT2 from Flippy
Website: http://www.phpsoft.org
Email: sqrtboy@phpsoft.org
*/


if (!isset($_GET['secure']) || $_GET['secure'] != 'doitnow')
	exit("Unauthorized access") ;

function getstat($hash)
{
	global $time;
	$handle = fopen('tracked/'.$hash, 'rb+');
	flock($handle, LOCK_EX);
	$length = filesize('tracked/'.$hash);
	
	if ($length)
	{
		$x = fread($handle, $length);
	}
	
	flock($handle, LOCK_UN);
	fclose($handle);
	
	$complete	= 0;
	$incomplete	= 0;
	$no_peers = $length / 7;
	
	for ($j=0;$j<$no_peers;$j++)
	{
		$t_peer_seed = implode('', unpack('C', substr($x, $j * 7, 1)));
		
		if ($t_peer_seed >= 128)
		{
			$complete++;
		}
		else
		{
			$incomplete++;
		}
	}
	
	return array("seeders" => number_format($complete), "leechers" => number_format($incomplete));
}

$torrents = 0;
$seeders = 0;
$leechers = 0;

$handle = opendir('tracked');
while (($file = readdir($handle)) !== false)
{
	if ($file != '.' and $file != '..' and $file != '.htaccess')
	{
		$torrents++;
		$peers = getstat($file);
		$seeders += $peers['seeders'];
		$leechers += $peers['leechers'];
	}
}
closedir($handle);

$handle = fopen('history.log', 'ab');
flock($handle, LOCK_EX);
fwrite($handle, $torrents.",".$seeders.",".$leechers.";");
flock($handle, LOCK_UN);
fclose($handle);
?>
