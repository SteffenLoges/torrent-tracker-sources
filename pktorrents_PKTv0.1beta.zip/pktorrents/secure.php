<?php
global $_SESSION;

if( ($_SESSION['userName'] == "admin") || ($_SESSION['privilege'] == "admin") ) {
include_once("login.php");
exit;
}else{?>
<?php }?>
