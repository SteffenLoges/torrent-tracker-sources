<?php
/*This file destroys all $_SESSION superglobals and redirects to the main page*/

//include config file
include "config.php";

//reinitialize the $_SESSION superglobal
$_SESSION = array();
//destroy session
session_destroy();

//redirect to homepage after destoying session
redirect("$CFG->wwwroot", "<body bgcolor=\"#000000\"><div align=\"center\"><center><table border=\"3\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"54%\" id=\"AutoNumber1\" bordercolor=\"#EBB80C\" height=\"162\" bgcolor=\"#262626\"><tr><td width=\"100%\" align=\"center\" height=\"162\"><p align=\"center\">&nbsp;</p><p align=\"center\">&nbsp;</p><p align=\"center\"><font color=\"#808080\" size=\"6\">LOGGING OUT</font></p><p align=\"center\">&nbsp;</p><p>&nbsp;</td></tr></table></center></div>
", 1);


?>
