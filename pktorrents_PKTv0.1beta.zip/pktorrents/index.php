<?
include "config.php";

$DOC_TITLE = "$CFG->webname.";

include "$CFG->templatedir/header.php";

if(file_exists("install.php")) {
ECHO "<center><strong><font color=\"red\">SECURITY WARNING: install.php Detected!!! Please delete it NOW</font></strong></center><b>";
}
if(file_exists("database.sql")) {
ECHO "<center><strong><font color=\"red\">SECURITY WARNING: database.sql Detected!!! Please delete it NOW</font></strong></center><b>";
}

switch (nvl($_REQUEST["mode"])) {

	case "faq" :
		include("$CFG->templatedir/faq.php");
		break;

	case "stats" :
		echo "<div align=\"center\" class=\"navbar\"><font size=\"7\">Total Torrent Stats</font></div>";

		global_stats();
		break;

	case "copyright" :
		include("$CFG->templatedir/copyright.php");
		break;
		

		
	case "directory" :
	   list_cat();
   		break;

	case "news" :
	    printnews(50);
		break;
		
	case "source" :
    	include("$CFG->templatedir/source.php");
		break;
		
	case "forumhacking" :
    	include("$CFG->templatedir/forumhack.php");
		break;

	case "latesttorrents" :
		echo "<div ><h3>Latest Torrents</h3></div>";
		printlasttorrents("$CFG->maintorrents");
		echo "<div ><h3>Most Downloaded Torrents</h3></div>";
		printmosttorrents("$CFG->maintorrents");
		break;

	default :
	echo "<center>";
	$fcontents = join ('', file ('./ads/ad_top.txt'));
        $s_con = split("~",$fcontents);
        $banner_no = rand(0,(count($s_con)-1));
        echo $s_con[$banner_no];
        echo "</center>";
		echo "<div class=\"navbar\"><h3>Latest Torrents</h3></div>";
		printlasttorrents("$CFG->maintorrents");
		echo "<div class=\"navbar\"><h3>Most Downloaded Torrents</h3></div>";
		printmosttorrents("$CFG->maintorrents");

	//if ("$CFG->mainnews" != 0)
	//	printnews2("$CFG->mainnews");
	
		break;
}
include "$CFG->templatedir/footer.php";


function global_stats()
{
global $ME,$CFG;

$qid=db_query("SELECT SUM(seeds) AS seeds, SUM(leechers) AS leechers,SUM(finished) AS finished,COUNT(DISTINCT announce_url) AS trackers, COUNT(*) AS torrents, SUM(size) AS size FROM namemap");

include("$CFG->templatedir/stats.php");

}//end of global_stats


function list_cat(){
  global $CFG, $ME;

  $qid= db_query("SELECT * FROM categories ORDER BY weight, name ASC");
  include ("$CFG->templatedir/directory.php");
}


?>

