<? include "config.php";
include "validator.php";



switch (nvl($_REQUEST["mode"])) {

	case "upload" :
		upload($_REQUEST["id"]);
		break;

	case "no" :
		no();
		break;
}

function upload($id)
{
require_login();

?>
<link rel="stylesheet" href="./templates/colours.php" type="text/css" title="Default"/>
<html>
<body  bgcolor="<?=$CFG->bgcolour?>">
 <div  class="main_table">
<form method="post" action="upload_file.php?mode=upload&id=<? p($id) ?>" enctype="multipart/form-data">
</form>
 </div>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="100%"><div  class="main_table">
<p align="center" style="margin-top: 0; margin-bottom: 0"><b><font size="4">
UPLOAD SCREENSHOT</font></b></p>
<form method="post" action="upload_file.php?mode=upload&id=<? p($id) ?>" enctype="multipart/form-data">
<font>
<p align="center"><font size="2">Please note that you are only allowed to upload one screenshot per torrent.<br>
If the torrent already has an existing screenshot, it will automatically be replaced by the uploaded one.<br><br>
Allowed image types : jpg, jpeg, gif, png<br>
Max Size : 100kb</font><br>
</p>

<p align="center">

<label for="file"><font size="2">Filename:</font> </label>
<input type="file" name="file" id="file" size="20" />

<!-- br /><br />
<label for="torrent">Torrent:</label>
<input type="text" value="<? p($id) ?>" name="torrent" id="torrent" / -->
<br /><br />
<input type="submit" name="submit" value="Submit" />
</font>
</p>
</form>
</div>
</td>
</tr>
</table>
</body>
</html>

<?
}

function no()
{
?>
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/colours.php" type="text/css" title="Default"/>
<html>
<body>
<font size="2" face="Trebuchet MS">
<p>You are not authorize to upload screenshot. Only the person who uploaded this torrent can upload screenshot.<br><br>
If you are the uploader, please login to upload the screenshot for this torrent<p>
</font>
</body>
</html>


<?
}
?>
