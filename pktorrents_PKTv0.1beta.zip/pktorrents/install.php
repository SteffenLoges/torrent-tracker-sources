<HTML>
<HEAD>
<TITLE>PK-Torrents Installer</TITLE>
</HEAD>
<BODY>
<!--
////////////////////////////////////////////
//   PK TORRENTS INSTALLER VERSION v0.1   //
//           for PKTv0.1beta              //
//  If you find any bugs let me know at   //
//           Filesoup.co.uk               //
////////////////////////////////////////////
-->
<CENTER>
<FONT FACE="verdana">
<?php

   //setup folders
@ $configsite = ".";
@ $configibitzy = "./admin";
@ $configtemplate = "./templates";
   //DataBase Setup
@ $sqlhost = $_POST['sqlhost'];
@ $sqldb = $_POST['sqldb'];
@ $sqlusr = $_POST['sqlusr'];
@ $sqlpass = $_POST['sqlpass'];
   //Site Setup
@ $webroot = $_POST['webroot'];
@ $forumroot = $_POST['forumroot'];
@ $serverroot = dirname(__FILE__);
@ $webname = $_POST['webname'];
@ $support = $_POST['support'];
@ $rssnum = $_POST['rssname'];
@ $mainnews = $_POST['mainnews'];
@ $maintorrents = $_POST['maintorrents'];
@ $usesub = $_POST['usesub'];
@ $usephpbb = $_POST['usephpbb'];
@ $regdownload = $_POST['regdownload'];
@ $regupload = $_POST['regupload'];
   //Ibitzy Setup
@ $ibitzyhost = $_POST['sqlhost'];
@ $ibitzydb = $_POST['sqldb'];
@ $ibitzyusr = $_POST['sqlusr'];
@ $ibitzypass = $_POST['sqlpass'];

@chmod("./config.php", 0777);
@chmod("./admin/conf.php", 0777);
@chmod("./templates/header.php", 0777);


if(empty($sqlhost) || empty($sqldb) || empty($sqlusr) || empty($sqlpass)) {
?>
<script>
var DH = 0;var an = 0;var al = 0;var ai = 0;if (document.getElementById) {ai = 1; DH = 1;}else {if (document.all) {al = 1; DH = 1;} else { browserVersion = parseInt(navigator.appVersion); if ((navigator.appName.indexOf('Netscape') != -1) && (browserVersion == 4)) {an = 1; DH = 1;}}} function fd(oi, wS) {if (ai) return wS ? document.getElementById(oi).style:document.getElementById(oi); if (al) return wS ? document.all[oi].style: document.all[oi]; if (an) return document.layers[oi];}
function pw() {return window.innerWidth != null? window.innerWidth: document.body.clientWidth != null? document.body.clientWidth:null;}
function mouseX(evt) {if (evt.pageX) return evt.pageX; else if (evt.clientX)return evt.clientX + (document.documentElement.scrollLeft ?  document.documentElement.scrollLeft : document.body.scrollLeft); else return null;}
function mouseY(evt) {if (evt.pageY) return evt.pageY; else if (evt.clientY)return evt.clientY + (document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop); else return null;}
function popUp(evt,oi) {if (DH) {var wp = pw(); ds = fd(oi,1); dm = fd(oi,0); st = ds.visibility; if (dm.offsetWidth) ew = dm.offsetWidth; else if (dm.clip.width) ew = dm.clip.width; if (st == "visible" || st == "show") { ds.visibility = "hidden"; } else {tv = mouseY(evt) + 20; lv = mouseX(evt) - (ew/4); if (lv < 2) lv = 2; else if (lv + ew > wp) lv -= ew/2; if (!an) {lv += 'px';tv += 'px';} ds.left = lv; ds.top = tv; ds.visibility = "visible";}}}
function hide(evt,oi) {if (DH) {var wp = pw(); ds = fd(oi,1); dm = fd(oi,0); st = ds.visibility; if (dm.offsetWidth) ew = dm.offsetWidth; else if (dm.clip.width) ew = dm.clip.width; if (st == "hidden" || st == "hidden") { ds.visibility = "hidden"; } else {tv = mouseY(evt) + 20; lv = mouseX(evt) - (ew/4); if (lv < 2) lv = 2; else if (lv + ew > wp) lv -= ew/2; if (!an) {lv += 'px';tv += 'px';} ds.left = lv; ds.top = tv; ds.visibility = "hidden";}}}
</script>
<style>
.tip {font:10px/12px Arial,Helvetica,sans-serif;
      border:solid 1px #666666;
      width:270px;
      padding:1px;
      position:absolute;
      z-index:100;
      visibility:hidden;
      color:#333333;
      top:20px;
      left:90px;
      background-color:#ffffcc;
      layer-background-color:#ffffcc;
      }
</style>
 <div id="t1" class="tip">Enter SQL Hostname E.G: localhost</div>
  <div id="t2" class="tip">Name of database where you dumped the .sql</div>
   <div id="t3" class="tip">Username Used to access the database</div>
    <div id="t4" class="tip">Password Used to access the database</div>
     <div id="t5" class="tip">E.G http://yoursite.com/PKtorrents NOTE: Dont put a trailing slash</div>
      <div id="t6" class="tip">The URL to your forum</div>
       <div id="t7" class="tip">The Name of the site</div>
        <div id="t8" class="tip">E.G me[at]hotmail[dot]com Shown in Copyright page!!!</div>
         <div id="t9" class="tip">Number of torrents to show on the RSS Page</div>
        <div id="t10" class="tip">Number of News Posts to show</div>
       <div id="t11" class="tip">Number of torrents to show on main page</div>
      <div id="t12" class="tip">yes or no</div>
     <div id="t13" class="tip">yes or no</div>
    <div id="t14" class="tip">yes or no ONLY Registered users can download torrents</div>
   <div id="t15" class="tip">yes or no ONLY Registered users can Upload torrents</div>

<p align="center"><font size="6" color="#008080">PK-Torrents Installer</font></p>
<br><center><small>Version PKT-0.1beta</small></center><br>

<FORM ACTION="install.php" METHOD="post">

<strong>DataBase Setup</strong><BR>
SQL Hostname: <INPUT onmouseover="popUp(event,'t1')" onmouseout="hide(event,'t1')" onclick="return false" TYPE="text" NAME="sqlhost"><BR>
Database Name: <INPUT onmouseover="popUp(event,'t2')" onmouseout="hide(event,'t2')" onclick="return false" TYPE="text" NAME="sqldb"><BR>
Datadase User: <INPUT onmouseover="popUp(event,'t3')" onmouseout="hide(event,'t3')" onclick="return false" TYPE="text" NAME="sqlusr"><BR>
Datadase Pass: <INPUT onmouseover="popUp(event,'t4')" onmouseout="hide(event,'t4')" onclick="return false" TYPE="password" NAME="sqlpass"><BR><BR>

<strong>Site Setup</strong><BR>

Web ROOT: <INPUT onmouseover="popUp(event,'t5')" onmouseout="hide(event,'t5')" onclick="return false" TYPE="text" NAME="webroot"><BR>
Forum ROOT: <INPUT onmouseover="popUp(event,'t6')" onmouseout="hide(event,'t6')" onclick="return false" TYPE="text" NAME="forumroot"><BR>
Site Name: <INPUT onmouseover="popUp(event,'t7')" onmouseout="hide(event,'t7')" onclick="return false" TYPE="text" NAME="webname"><BR>
Support Email: <INPUT onmouseover="popUp(event,'t8')" onmouseout="hide(event,'t8')" onclick="return false" TYPE="text" NAME="support"><BR>
Rss Number: <INPUT onmouseover="popUp(event,'t9')" onmouseout="hide(event,'t9')" onclick="return false" TYPE="text" NAME="rssname"><BR>
Main News: <INPUT onmouseover="popUp(event,'t10')" onmouseout="hide(event,'t10')" onclick="return false" TYPE="text" NAME="mainnews"><BR>
Main Torrents: <INPUT onmouseover="popUp(event,'t11')" onmouseout="hide(event,'t11')" onclick="return false" TYPE="text" NAME="maintorrents"><BR>
Use Sub Categoies: <INPUT onmouseover="popUp(event,'t12')" onmouseout="hide(event,'t12')" onclick="return false" TYPE="text" NAME="usesub"><BR>
Use phpBB: <INPUT onmouseover="popUp(event,'t13')" onmouseout="hide(event,'t13')" onclick="return false" TYPE="text" NAME="usephpbb"><BR>
Reg Download: <INPUT onmouseover="popUp(event,'t14')" onmouseout="hide(event,'t14')" onclick="return false" TYPE="text" NAME="regdownload"><BR>
Reg Upload: <INPUT onmouseover="popUp(event,'t15')" onmouseout="hide(event,'t15')" onclick="return false" TYPE="text" NAME="regupload"><BR>

<INPUT TYPE="submit" VALUE="Install PK-Torrents!">
</FORM>

<?php
exit;
}
@chmod(".", 0777);
@ mkdir($configsite, 0777);
@ mkdir($configibitzy, 0777);
@ mkdir($configtemplate, 0777);
//////////////////////////////////////////////
$config = <<<AMFRCONFIG
<?php
//////////////////////////////////////////////
//              PK-TORRENTS                 //
//   By Proxykill Based on torrenthoster    //
//          Version PKT-0.1beta             //
//////////////////////////////////////////////
/* check if file is being accessed directly */
if (eregi("config.php",\$_SERVER['PHP_SELF']))
{
Header("Location: \$CFG->wwwroot");
die();
}
//rename this file to config.php
  /* turn on verbose error reporting (15) to see all warnings and errors */
  error_reporting(15);

//include "forumdb.php";

  //define a generic object to hold all the configuration variables
  class object {};

  //declare an instance of the generic object
  \$CFG = new object;
  //declare root directory
  \$CFG->dirroot = dirname(__FILE__);

  //Edit This For TORRENT HOSTER Database
  //database configuration
  \$CFG->host = "$sqlhost";
  \$CFG->dbName = "$sqldb";
  \$CFG->dbUserName = "$sqlusr";
  \$CFG->dbPassword = "$sqlpass";



/* directory configuration, if all your files are in one directory
 * you probably only need to set the wwwroot variable.  valid examples are:
 *
 * \$CFG->wwwroot = "http://myserver.com/webtorrent";
 * \$CFG->wwwroot = "http://localhost/webtorrent";
 * \$CFG->wwwroot = "http://myserver.com";
 *
 * do not include the trailing slash. dirroot is the physical path on your
 * server where the application can find it's files. for more security, it is
 * recommended that you move the libraries and templates ($CFG->libdir
 * and $CFG->templatedir) outside of your web directories.
 */


  /* Edit below this */

  \$CFG->wwwroot      = "$webroot";
  \$CFG->forumroot    = "$forumroot";
  \$CFG->webname      = "$webname";
  \$CFG->support      = "$support"; //shows in COPYRIGHT page
  \$CFG->rssnum       = "$rssnum"; //number of rss to show
  \$CFG->mainnews     = "$mainnews"; //number of news on the main page, use 0 to not print news on main page
  \$CFG->maintorrents = "$maintorrents";//number of torrents in the main page
  \$CFG->torrents     = "\$CFG->dirroot/torrents"; //torrent folder repect to your wwwroot
  \$CFG->usesub	      = "$usesub"; //Do you want to use Subcategories? "yes" or "no"
  \$CFG->usephpbb    = "$usephpbb"; //put "yes" if you want to connect with phpbb users. "yes" or "no"
  \$CFG->regdownload  = "$regdownload"; //only registered users can download torrents. "yes" or "no"
  \$CFG->regupload    = "$regupload"; //only registered users can upload torrents. "yes" or "no"

  //////////////////////////////////////////////////
  //              --LAYOUT OPTIONS--              //
  //////////////////////////////////////////////////
  // A good place to find out if your             //
  // colours will work good together is @         //
  // http://slayeroffice.com/tools/color_palette  //
  //////////////////////////////////////////////////
  //MAIN
   \$CFG->bgcolour           = "#000000";
   \$CFG->maincolour         = "#262626";
   \$CFG->mainfont           = "Trebuchet MS, Arial, Helvetica, sans-serif";
   \$CFG->mainfontsize       = "10pt";
   \$CFG->mainfontweight     = "bolder";
   \$CFG->searchboxtxtcolour = "#EBB80C";
   //
   //BODY
   \$CFG->bodycolour   = "#EBB80C";
   \$CFG->bodyborder   = "#ffffff";
   //
   //HEADINGS
   //h1, h2, h3, h4, h5, h6
    \$CFG->headingcolour      = "#EBB80C";
    \$CFG->headingfontweight  = "bold";
   //
   //BOX h3
   \$CFG->boxhead3bgcolour  = "#CCCCCC";
   \$CFG->boxhead3colour    = "#FFFFFF";
   //
   //BOX h4
   \$CFG->boxhead4bgcolour  = "#404040";
   \$CFG->boxhead4colour    = "#FFFFFF";
   //
   //CONTENT h3, h1
   \$CFG->contentcolour     = "#000000";
   //
   //NAV BAR
   \$CFG->navcolour          = "#EBB80C";
   \$CFG->navbgcolour        = "#EBB80C";
   //NAV CAT
   //
   \$CFG->navcatcolour       = "#EBB80C";
   \$CFG->navcatbgcolour     = "#EBB80C";
   //
   //FORM IMPUTS
   \$CFG->buttonbgcolour      = "#EBB80C";
   \$CFG->buttontxtcolour     = "#000000";
   \$CFG->buttonbordercolour  = "#000000";
   \$CFG->imputcolour = \$CFG->buttonbgcolour;
   //
   //LINK STYLES
   \$CFG->linkcolour      = "silver";
   \$CFG->linkhover       = "#EBB80C";
   \$CFG->linkdecor       = "underline";
   //
   //WARNINGS
   \$CFG->warnings = "0000CC";
   /////////////////////////////////
   //PAGE LAYOUT                  //
   // Menu Left OR right,         //
   // make sure there opposit     //
   \$CFG->layoutmenu = "left";     //
   \$CFG->layoutcontent = "right"; //
   /////////////////////////////////

   //Code For admin Stats
   function sitestats (){
define("_BBCLONE_DIR", "./bbclone/");
define("COUNTER", _BBCLONE_DIR."mark_page.php");
if (is_readable(COUNTER)) include_once(COUNTER);
   }


  /*
      nothing to change below this (i think)
  */

  \$CFG->templatedir  = "\$CFG->dirroot/templates";
  \$CFG->libdir       = "\$CFG->dirroot/lib";
  \$CFG->imagedir     = "\$CFG->wwwroot/images";
  \$CFG->health       = "\$CFG->wwwroot/health";
  \$CFG->icondir      = "\$CFG->imagedir/icons";
  \$CFG->version      = "PKT-0.1beta";

  //\$CFG->sessionname = " ";

  /* define database error handling behavior, since we are in development stages
  * we will turn on all the debugging messages to help us troubleshoot */
  \$DB_DEBUG = true;
  \$DB_DIE_ON_FAIL = true;


  //start session to hold username and password when linking from page to page
  session_start();
  header("Cache-control: private"); // IE 6 Bug Fix.

  //load up libraries
  require "lib/dblib.php";
  require "lib/stdlib.php";
  require "lib/webtorrent.php";

  /* setup some global variables */
  \$ME = qualified_me();

  /* connect to the database */
  db_connect(\$CFG->host, \$CFG->dbName, \$CFG->dbUserName, \$CFG->dbPassword);

/*
  	Print out header
  *******************************************/
  function stheader(\$title)
  {//stheader from t-xore not used in this version
  }

// Get microtime
function get_micro_time()
{
  list(\$usec, \$sec) = explode(' ', microtime());
  return ((float)\$usec + (float)\$sec);
}
//connect db if using edit user in members area
function connect_forum(\$fdbhost, \$fdbuser, \$fdbpass, \$fdatabase)
{
\$errormes = 'The sql server has encountered a problem, we are trying to fix it as soon as possible';
@\$connection = mysql_connect(\$fdbhost, \$fdbuser, \$fdbpass);
@mysql_select_db(\$fdatabase) or die(\$errormes);
}
//get torrent size for stats
function torsize (\$size)
{
if (\$size >= 1099511627776) 	{\$size = round(\$size / 1024 / 1024 / 1024 / 1024, 2).' TerraBytes';}
elseif (\$size >= 1073741824) 	{\$size = round(\$size / 1024 / 1024 / 1024, 2).' GiggaBytes';}
elseif (\$size >= 1048576) 	{\$size = round(\$size / 1024 / 1024, 2).' MegaBytes';}
elseif (\$size >= 1024) 		{\$size = round(\$size / 1024, 2).' KillerBytes';}
else 				{\$size = \$size.' Bytes';}
return \$size;
}



// show files contained in a torrent
function showfiles(\$hash)
{
\$filename2 = \$hash;
//global \$CFG->torrents;
include_once("lib/BDecode.php") ;
include_once("lib/BEncode.php") ;
include_once("config.php") ;

\$filename = "torrents/\$filename2.btf";

\$stream = @file_get_contents("\$filename");


if (\$stream == FALSE)
{
echo 'No details availiable... 1 ';
}
if(!isset(\$stream))
{
echo 'No details availiable... 2 ';
break;
}
else
{

\$array = BDecode(\$stream);
if (\$array === FALSE)

{
echo 'No details availiable... 3 ';
break;
}
else
{
if(array_key_exists("info", \$array) === FALSE){
echo 'No details availiable... 4 ';
break;
}
else
{
\$infovariable = \$array["info"];
if (isset(\$infovariable["files"]))
{

\$filecount = "";
foreach (\$infovariable["files"] as \$file)
{

\$row_color = (\$row_count % 2) ? \$color1 : \$color2;

\$filecount += "1";
\$multiname = \$file['path'];
\$multitorrentsize = torsize (\$file['length']);
\$torrentsize += \$file['length'];
\$combinedsize = torsize(\$torrentsize);
\$strname = strip_tags (\$multiname[0]);

\$strname = htmlentities(\$strname);
\$strname = strip_tags(\$strname);

echo "<tr><td width=\"50%\">\$strname</td><td> \$multitorrentsize</td></tr>";
\$row_count++;
}
}
else
{
\$singletf = \$infovariable['name'] ;
\$singletf  = strip_tags(\$singletf );
\$torrentsize = torsize(\$infovariable['length']);

\$singletf = htmlentities(\$singletf);
\$singletf = strip_tags(\$singletf);

echo "<tr><td width=\"50%\">\$torrentsize</td><td> \$singletf</td></tr>";
}
}
}
}
}

function showfiles_small(\$hash)
{
\$filename2 = \$hash;
//global \$CFG->torrents;
include_once("lib/BDecode.php") ;
include_once("lib/BEncode.php") ;
include_once("config.php") ;

\$filename = "torrents/\$filename2.btf";

\$stream = @file_get_contents("\$filename");


if (\$stream == FALSE)
{
echo 'No details availiable... 1 ';
}
if(!isset(\$stream))
{
echo 'No details availiable... 2 ';
break;
}
else
{

\$array = BDecode(\$stream);
if (\$array === FALSE)

{
echo 'No details availiable... 3 ';
break;
}
else
{
if(array_key_exists("info", \$array) === FALSE){
echo 'No details availiable... 4 ';
break;
}
else
{
\$infovariable = \$array["info"];
if (isset(\$infovariable["files"]))
{

\$filecount = "";
foreach (\$infovariable["files"] as \$file)
{

\$row_color = (\$row_count % 2) ? \$color1 : \$color2;

\$filecount += "1";
\$multiname = \$file['path'];
\$multitorrentsize = torsize (\$file['length']);
\$torrentsize += \$file['length'];
\$combinedsize = torsize(\$torrentsize);
\$strname = strip_tags (\$multiname[0]);

\$strname = htmlentities(\$strname);
\$strname = strip_tags(\$strname);

echo "<tr>\$strname</tr>";
\$row_count++;
}
}
else
{
\$singletf = \$infovariable['name'] ;
\$singletf  = strip_tags(\$singletf );
\$torrentsize = torsize(\$infovariable['length']);

\$singletf = htmlentities(\$singletf);
\$singletf = strip_tags(\$singletf);

echo "<tr>\$singletf</tr>";
}
}
}
}
}
?>

AMFRCONFIG;

$write = fopen("config.php", "wb");
fwrite($write, $config);
fclose($write);

@chmod("./admin", 0777);

$configcrawler = <<<AMFRIBITZY
<?
////////////////////////////////////////////////
//IBITZY FOR TORRENTHOSTER MODDED by Pr0XyK1ll//
////////////////////////////////////////////////

\$CONF['SERVER'] = '$sqlhost';
\$CONF['DB'] = '$sqldb';
\$CONF['USER'] = '$sqlusr';
\$CONF['PASS'] = '$sqlpass';


//TORRENT DIRECTORY
\$CONF['torrent_dir'] = '../torrents/';


 //////DO NOT EDIT BELOW THIS LINE!!!!!///
 ////ALL REQUIRED STUFF IS ALREADY DONE///

/**
* TORRENT FORMAT
*
* torrent_format = enter the format you wish the .torrent to bee saved,
* SYNTAX - <option><option>.extention ie <id><date>.torrent
* VARIABLES - <info_hash>, <id> (this is the insert id given off by mysql), <date> (unix-timestamp), <torrent_name> (the filename saved in the database) --- (DEFAULT = <id>.torrent)
*/

\$CONF['torrent_format'] = "<info_hash>.btf";
/**
* LOCK_TIMEOUT
*
* lock_timeout = Time (in seconds) after witch the "locked" statement in the cached file should bee ignored (note if you set this too low it could lead to duplicate torrents downloaded) --- (DEFAULT = 1800)
*/

\$CONF['lock_timeout'] = 1800;

//DEBUG_MODE
//debug_mode = When set to 1 it will display debug messages to the browser so you can find any errors in the script, IT SHOULD BEE SET TO 0 WHEN RUNNING AS CRON!
\$CONF['debug_mode'] = 1;


//TRIES
//tries = Maximum amount of tries to access a site (DEFAULT = 3)
\$CONF['tries'] = 3;


//PROCESSES
//processes = Amount of unprocessed rows to execute each time script is run or automaticly refreshed (DEFAULT = 1)
//NOTE: best to keep to 1 till you know its working 100% or want to reduce sql load
\$CONF['processes'] = 1;


//MAX_UNPROCESSED
//max_unprocessed = Maximum unprocessed rows to store before data is executed and torrents are retrieved (DEFAULT = 1)
\$CONF['max_unprocessed'] = 1;

//
//intval = How long to wait after last gathering of data from a site before new data can be gathered (DEFAULT = 1)
\$CONF['interval'] = 1;



//SUBMITTER
//submitter = the uid/username you would like the spider to upload its torrents under
//

\$CONF['submitter'] = 1;

/**
* SQL PREFIX's
*
* tbl_name = Name of table to store torrents in (DEFAULT = torrents)
* torrent_name = Name of field where torrent name is stored (DEFAULT = name)
* announce = Name of field where announce url of torrent is stored (DEFAULT = announce)
* cat = Name of field where category id's are stored of torrents (DEFAULT = cat)
* size = Name of field where size of torrent is store (DEFAULT = size)
* magnet = Name of field where magnet link is stored (DEFAULT = magnet)
* info_hash = Name of field where info hash of torrent is stored, these are stored in 40char sha1 format (DEFAULT = info_hash)
* site_tid = Name of field where site torrent id is stored, this can be used to track down the exact torrent on a site (DEFAULT = site_tid)
* site = Name of field where the site the torrent was taken from is stored (DEFAULT = site)
* data = Unixtimestamp of time the torrent was added to the database (DEFAULT = date)
* dl_name = Some site softwere require the name of the .torrent to bee stored seperatly, this variable is for that (DEFAULT = dl_name)
* submitter = uid/name of the user the spider will upload torrents under (DEFAULT = submitter)
*/


//THERE IS NO NEED TO CHANGE THESE IF YOUR INSTALLING FOR TORRENTHOSTER
\$CONF['sql']['tbl_name'] = 'namemap';
\$CONF['sql']['torrent_name'] = 'filename';
//added to make w0rk with torrenthoster
\$CONF['sql']['torrent_name2'] = 'filename2';
\$CONF['sql']['announce'] = 'announce_url';
\$CONF['sql']['cat'] = 'category';
\$CONF['sql']['subcat'] = 'subcategory';
\$CONF['sql']['size'] = 'size';
\$CONF['sql']['magnet'] = 'magnet';
\$CONF['sql']['info_hash'] = 'info_hash';
\$CONF['sql']['site_tid'] = 'site_id';
\$CONF['sql']['site'] = 'site';
\$CONF['sql']['date'] = 'data';
\$CONF['sql']['lastupdate'] = 'lastupdate';
\$CONF['sql']['dl_name'] = 'url';
\$CONF['sql']['submitter'] = 'submitter';
\$CONF['sql']['seeds'] = 'seeds';
\$CONF['sql']['peers'] = 'leechers';

/**
* Categories Array
*
* cats = This is the categories array to match up id's of data gathered from sites,
* theres a similar one in each plugin which completes the match up.
* PLEASE BE WARNED THAT INCORRECT EDITING THIS CAN COUSE PLUGGINS TO STOP WORKING RIGHT.
* you should change the CATEGORY ID to match the id's of the matching categorys on your site
* DO NOT EDIT THE "usage id" OR "category name" AS THIS WOULD BREAK COMPATABILITY WITH THE PLUGGINS.
*/
//============================================================================================
//  Usage id => 'category id', 'category name(no functional use)' ),
//============================================================================================



\$CONF['cats'] = array(
				1 => array('1','Anime'),
				2 => array('2','Books'),
				3 => array('3','Games'),
				4 => array('4','Movies'),
				5 => array('5','Music'),
				6 => array('6','Softwere / Apps'),
				7 => array('7','TV'),
				8 => array('8','Other'),
				);

///////////////////////END OF CONFIG

///Added for Stats while crawling
function connect (\$dbhost, \$dbuser, \$dbpass, \$database)
{
\$errormes = 'The sql server has encountered a problem, we are trying to fix it as soon as possible';
@\$connection = mysql_connect(\$dbhost, \$dbuser, \$dbpass);
@mysql_select_db(\$database) or die(\$errormes);

}
function torsize (\$size)
{
if (\$size >= 1099511627776) 	{\$size = round(\$size / 1024 / 1024 / 1024 / 1024, 2).' TB';}
elseif (\$size >= 1073741824) 	{\$size = round(\$size / 1024 / 1024 / 1024, 2).' GB';}
elseif (\$size >= 1048576) 		{\$size = round(\$size / 1024 / 1024, 2).' MB';}
elseif (\$size >= 1024) 			{\$size = round(\$size / 1024, 2).' KB';}
else 							{\$size = \$size.' Byte';}
return \$size;
}
?>
AMFRIBITZY;


$write = fopen("./admin/conf.php", "wb");
fwrite($write, $configcrawler);
fclose($write);

$template = <<<AMFRTEMPLATE
<?
//if (extension_loaded('zlib')) {
//@ob_start("ob_gzhandler");
//}
global \$time_begin;
\$time_begin = get_micro_time();

echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>";
\$side=true;
\$microtime = microtime();
\$split = explode(" ", \$microtime);
\$exact = \$split[0];
\$secs = date("U");
\$bgtm = \$exact + \$secs;
error_reporting(E_ALL ^ E_NOTICE);
?>
<?
/* check if file is being accessed directly */
if (eregi("header.php",\$_SERVER['PHP_SELF']))
{
  Header("Location: \$CFG->wwwroot");
  die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--
///////////////////////////////////
//PK-TORRENTS Version:<?=\$CFG->version?>//
///////////////////////////////////
-->
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="<?=\$CFG->wwwroot?>/templates/layout.php" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?=\$CFG->wwwroot?>/js/ajaxtabs.css" />
<link rel="stylesheet" href="<?=\$CFG->wwwroot?>/templates/colours.php" type="text/css" title="Default"/>
<link rel="stylesheet" href="<?=\$CFG->wwwroot;?>/css/lightbox.css" type="text/css" media="screen" />
<link rel="alternate" type="application/xml" title="<? pv(\$DOC_TITLE) ?> RSS feed" href="<?=\$CFG->wwwroot?>/rss.php"/>
<link rel="shortcut icon" href="<?=\$CFG->wwwroot?>/favicon.ico" />
<script src="<?=\$CFG->wwwroot;?>/js/site.js" type="text/javascript"></script>
<script src="<?=\$CFG->wwwroot;?>/js/prototype.js" type="text/javascript"></script>
<script src="<?=\$CFG->wwwroot;?>/js/scriptaculous.js?load=effects" type="text/javascript"></script>
<script src="<?=\$CFG->wwwroot;?>/sorttable.js" type="text/javascript"></script>
<script type="text/javascript" src="<?=\$CFG->wwwroot;?>/hide.js"></script>
<script type="text/javascript" src="<?=\$CFG->wwwroot;?>/js/preload.js"></script>
<script type="text/javascript" src="<?=\$CFG->wwwroot;?>/js/ajaxtabs.js"></script>
<title><? pv(\$DOC_TITLE) ?></title>
<script src="../js/lightbox.js"></script>
</head>
<!--
///////////////////////////////////
//PK-TORRENTS Version:<?=\$CFG->version?>//
///////////////////////////////////
-->
<body bgcolor="<?=\$CFG->bgcolour?>">

 <? //Code For Stats

  define("_BBCLONE_DIR", "$serverroot/admin/bbclone/"); define("COUNTER", _BBCLONE_DIR."mark_page.php"); if (is_readable(COUNTER)) include_once(COUNTER);
  ?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="950" height="" style="border-collapse:collapse;" bgcolor="<?=\$CFG->maincolour?>">
<tr>
<td width="100%" height="100%" style="border-width:1px; border-style:solid;"><br>
<? if (is_logged_in()) { ?>
    <div align="right" valign="top">
	    <? if (\$_SESSION['privilege'] == "admin") { ?>
	    <a href="<?=\$CFG->wwwroot?>/admin/index.php" OnMouseOut="na_restore_img_src('image11', 'document')"
		OnMouseOver="na_change_img_src('image11', 'document', '<?=\$CFG->imagedir?>/adminmode2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/adminmode.gif" width="154" height="20" border="0" name="image11"></a>

	    <a href="<?=\$CFG->wwwroot?>/update_stats.php" OnMouseOut="na_restore_img_src('image12', 'document')"
		OnMouseOver="na_change_img_src('image12', 'document', '<?=\$CFG->imagedir?>/updatestats2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/updatestats.gif" width="154" height="20" border="0" name="image12"></a>

	    <? } ?>
	    <a href="<?=\$CFG->wwwroot?>/users/index.php" OnMouseOut="na_restore_img_src('image7', 'document')"
		OnMouseOver="na_change_img_src('image7', 'document', '<?=\$CFG->imagedir?>/userhome2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/userhome.gif" width="154" height="20" border="0" name="image7"></a>

	    <a href="<?=\$CFG->forumroot?>/profile.php?mode=editprofile" OnMouseOut="na_restore_img_src('image8', 'document')"
		OnMouseOver="na_change_img_src('image8', 'document', '<?=\$CFG->imagedir?>/changeprofile2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/changeprofile.gif" width="154" height="20" border="0" name="image8"></a>

		<a href="<?=\$CFG->wwwroot?>/users/index.php" OnMouseOut="na_restore_img_src('image9', 'document')"
		OnMouseOver="na_change_img_src('image9', 'document', '<?=\$CFG->imagedir?>/mytorrents2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/mytorrents.gif" width="154" height="20" border="0" name="image9"></a>

		<a href="<?=\$CFG->wwwroot?>/logout.php" OnMouseOut="na_restore_img_src('image10', 'document')"
		OnMouseOver="na_change_img_src('image10', 'document', '<?=\$CFG->imagedir?>/logout2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/logout.gif" width="154" height="20" border="0" name="image10"></a>
	<br>
	<br>
	</div>

	<? } else { ?>

	<div align="right" valign="top">
	    <a href="<?=\$CFG->wwwroot?>/login.php" OnMouseOut="na_restore_img_src('image13', 'document')"
		OnMouseOver="na_change_img_src('image13', 'document', '<?=\$CFG->imagedir?>/login2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/login.gif" width="154" height="20" border="0" name="image13"></a>

	    <a href="<?=\$CFG->wwwroot?>/users/index.php?mode=register" OnMouseOut="na_restore_img_src('image15', 'document')"
		OnMouseOver="na_change_img_src('image15', 'document', '<?=\$CFG->imagedir?>/register2.gif', true)">
		<img src="<?=\$CFG->imagedir?>/register.gif" width="154" height="20" border="0" name="image15"></a>
	<br>
	<br>
    </div>

	<? } ?>



<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" height="60" background="<?=\$CFG->imagedir?>/bannerbg.gif">
   <tr>
   <td width="50%" height="60">
   <div>

</div></td>
<td width="50%" height="60" align="right">

<div class="right">

<form action="<?=\$CFG->wwwroot?>/torrents.php" method="post" enctype="multipart/form-data">
<div><font color="<?=\$CFG->searchboxtxtcolour?>">Search Torrents: <input type="text" name="name" id="search" /></font>
<input type="hidden" name="mode" value="search"/>
<input class="button" type="submit" value="Go!" />
</div>
</form>
</div>
</td>
</tr>
</table>
<!-- END HEADER-TOP -->

<? if (nvl(\$side)) {?>

<!-- BEGIN SIDEBAR -->
    <div id="sidebar">

<? if (\$CFG->usephpbb != "yes") {

    if (is_logged_in()) { ?>

	<div class="box">
	<h4>User Menu</h4>
	<br>
<!-- LOGGED IN Menu -->
<div align="center" valign="top">
<a href="<?=\$CFG->wwwroot?>/users/index.php?mode=changepassword" OnMouseOut="na_restore_img_src('image18', 'document')"
OnMouseOver="na_change_img_src('image18', 'document', '<?=\$CFG->imagedir?>/changepass2.gif', true)">
<img src="<?=\$CFG->imagedir?>/changepass.gif" width="154" height="20" border="0" name="image18"></a>
</div>
</div>

<? }  } ?>


    <div class="box">
    <h4>Menu</h4>
<br>
<!-- NEW Menu -->
<div align="center" valign="top">

<a href="<?=\$CFG->wwwroot?>/index.php" OnMouseOut="na_restore_img_src('image1', 'document')"
OnMouseOver="na_change_img_src('image1', 'document', '<?=\$CFG->imagedir?>/home2.gif', true)">
<img src="<?=\$CFG->imagedir?>/home.gif" width="154" height="20" border="0" name="image1"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/index.php?mode=latesttorrents" OnMouseOut="na_restore_img_src('image19', 'document')"
OnMouseOver="na_change_img_src('image19', 'document', '<?=\$CFG->imagedir?>/latesttorrents2.gif', true)">
<img src="<?=\$CFG->imagedir?>/latesttorrents.gif" width="154" height="20" border="0" name="image19"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/index.php?mode=directory" OnMouseOut="na_restore_img_src('image14', 'document')"
OnMouseOver="na_change_img_src('image14', 'document', '<?=\$CFG->imagedir?>/directory2.gif', true)">
<img src="<?=\$CFG->imagedir?>/directory.gif" width="154" height="20" border="0" name="image14"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/torrents.php?mode=upload" OnMouseOut="na_restore_img_src('image17', 'document')"
OnMouseOver="na_change_img_src('image17', 'document', '<?=\$CFG->imagedir?>/uploadtorrent2.gif', true)">
<img src="<?=\$CFG->imagedir?>/uploadtorrent.gif" width="154" height="20" border="0" name="image17"></a>
<br>
<a href="<?=\$CFG->forumroot?>" OnMouseOut="na_restore_img_src('image6', 'document')"
OnMouseOver="na_change_img_src('image6', 'document', '<?=\$CFG->imagedir?>/forum2.gif', true)">
<img src="<?=\$CFG->imagedir?>/forum.gif" width="154" height="20" border="0" name="image6"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/index.php?mode=stats" OnMouseOut="na_restore_img_src('image2', 'document')"
OnMouseOver="na_change_img_src('image2', 'document', '<?=\$CFG->imagedir?>/stats2.gif', true)">
<img src="<?=\$CFG->imagedir?>/stats.gif" width="154" height="20" border="0" name="image2"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/index.php?mode=news" OnMouseOut="na_restore_img_src('image3', 'document')"
OnMouseOver="na_change_img_src('image3', 'document', '<?=\$CFG->imagedir?>/news2.gif', true)">
<img src="<?=\$CFG->imagedir?>/news.gif" width="154" height="20" border="0" name="image3"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/index.php?mode=faq" OnMouseOut="na_restore_img_src('image5', 'document')"
OnMouseOver="na_change_img_src('image5', 'document', '<?=\$CFG->imagedir?>/faq2.gif', true)">
<img src="<?=\$CFG->imagedir?>/faq.gif" width="154" height="20" border="0" name="image5"></a>
<br>
<a href="<?=\$CFG->wwwroot?>/index.php?mode=copyright" OnMouseOut="na_restore_img_src('image4', 'document')"
OnMouseOver="na_change_img_src('image4', 'document', '<?=\$CFG->imagedir?>/about2.gif', true)">
<img src="<?=\$CFG->imagedir?>/about.gif" width="154" height="20" border="0" name="image4"></a>
<br>
<?php
\$fcontents = join ('', file ('./ads/ad_left.txt'));
\$s_con = split("~",\$fcontents);
\$banner_no = rand(0,(count(\$s_con)-1));
echo \$s_con[\$banner_no];
?>


</div>

</div>

</div>

	<!-- END USER MENU -->

<div id="content">
   <?}else {?>
 <div id="contentfull">
    <?
    }
?>
AMFRTEMPLATE;
@chmod("./templates", 0777);
$write = fopen("./templates/header.php", "wb");
fwrite($write, $template);
fclose($write);
@chmod("./templates/header.php", 0777);


$write = fopen("count.thisisprivate", "w+");
fwrite($write, '0');
fclose($write);
@chmod("./count.thisisprivate", 0777);
@chmod("./config.php", 0777);
@chmod("./admin/conf.php", 0777);
@chmod("./admin/class_spider.php", 0777);
@chmod("./admin/indexspider.php", 0777);
@chmod("./torrents", 0777);
@chmod("./admin/cachefix.php", 0777);
@chmod("./admin/shell.php", 0777);
@chmod("./admin/uda.php", 0777);
@chmod("./admin/cached.php", 0777);
@chmod("./ads/ad_left.txt", 0777);
@chmod("./ads/ad_top.txt", 0777);
@chmod("./ads/ad_torrent.txt", 0777);
@chmod("./votes", 0777);
@chmod("./rate.php", 0777);
@chmod("./tracked", 0777);



echo "<TITLE>PK-Torrents Installer For PKTv0.1beta</TITLE>\n";
echo"<p align=\"center\"><font size=\"6\" color=\"#008080\">PK-Torrents Installer For PKTv0.1beta</font></p>";
echo "<center><font color=\"red\"><strong>Config files has been created and site has been setup!!! please now delete the install.php file</strong></font></center>\n";
echo "<center><font><strong><a href=\"index.php\">Goto your site<a></strong></font></center>\n";

?>
