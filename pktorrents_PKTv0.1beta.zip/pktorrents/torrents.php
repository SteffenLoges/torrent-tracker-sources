<?php
include("config.php");
include "validator.php";

switch (nvl($_REQUEST["mode"])) {
	case "addone" :
		add_one($_REQUEST["path"],$_REQUEST["name"]);
		break;
}


$DOC_TITLE = "$CFG->webname - Torrents";

if (nvl($_REQUEST["mode"]) != "download")
include("$CFG->templatedir/blank.php");
switch (nvl($_REQUEST["mode"])) {

	case "upload" :
	include("$CFG->templatedir/header.php");
	if ($CFG->regupload  == "yes"){
	require_login();
	$userUpload = $_SESSION["userName"];
		include("upload.php");
		include("$CFG->templatedir/footer.php");
		break;
	} else {
	include("$CFG->templatedir/header.php");
		$userUpload = $_SESSION["userName"];
		include("upload.php");
		include("$CFG->templatedir/footer.php");
// 	print_add_torrent_form($something = "");
		break;
		}

	case "details" :
	include("$CFG->templatedir/header.php");
		torrent_details($_REQUEST["id"]);
		include("$CFG->templatedir/footer.php");
		break;
		
	case "files" :
	include("$CFG->templatedir/files_header.php");
		files($_REQUEST["id"]);
                break;
                
        case "files_detail" :
	include("$CFG->templatedir/files_header.php");
		files_detail($_REQUEST["id"]);
                break;
                


       case "comment_detail" :
         $hash = $_REQUEST["id"];
	comment_details($_REQUEST["id"]);
        redirect("$CFG->wwwroot/torrents.php?mode=details&id=$hash","",0);
                break;
                
       case "screen_detail" :
         $hash = $_REQUEST["id"];
         screen_details($_REQUEST["id"]);

                break;





	case "updatedata" :
	$announce = $_REQUEST["announce"];
	$hash = $_REQUEST["id"];
	include("$CFG->templatedir/header.php");
        require_once("lib/getscrape.php");
        scrape($announce,$hash);
	echo "<br><br><div>Update success...thank you!</div>";
	include("$CFG->templatedir/footer.php");
	redirect("$CFG->wwwroot/torrents.php?mode=details&id=$hash","Update complete",0);
	
		break;

	case "download" :
	
	if ($CFG->regdownload  == "yes"){
	require_login();
	torrent_download($_REQUEST["id"]);
		break;
	} else {
		torrent_download($_REQUEST["id"]);

                break;
               }

	case "insert" :
	include("$CFG->templatedir/header.php");
		$frm = $_POST;
		$errormsg = validate_form($frm, $errors);
		if (empty($errormsg)) {
		insert_torrent($frm);
		print_torrent_list();
		}
		else {
		include("$CFG->templatedir/form_header.php");
		print_add_torrent_form($frm);
		}
		include("$CFG->templatedir/footer.php");
		break;


	case "category" :
	include("$CFG->templatedir/header.php");
		print_torrent_subcategory($_REQUEST["cat"]);
                include("$CFG->templatedir/footer.php");
		//include("templates/user_password_reset.php");
		//print_user_list();
		break;
	case "subcategory" :
	include("$CFG->templatedir/header.php");
		print_torrent_list($_REQUEST["sub"]);
                include("$CFG->templatedir/footer.php");
		//include("templates/user_password_reset.php");
		//print_user_list();
		break;

	case "search" :
	include("$CFG->templatedir/header.php");
		$searchArray = $_POST;
		print_search_list($searchArray);
 		include("$CFG->templatedir/footer.php");
		break;


	default :

              include("$CFG->templatedir/header.php");
		if(isset($_GET['priv']))
		  print_admin_list();
		else
		  printlasttorrents(30);
		  include("$CFG->templatedir/footer.php");
		break;
}
if (nvl($_REQUEST["mode"]) != "download")
include("$CFG->templatedir/blank.php");

/******************************************************************************
 * FUNCTIONS
 *****************************************************************************/
  function updatetorrent($result){

  $result=db_query("SELECT * FROM namemap WHERE info_hash='$infohash'");

while($row= db_fetch_array($result))
{
extract ($row);
scrape(urldecode($announce_url),$info_hash);
echo "<br>$announce_url done<br>";

 
}
 }

function print_search_list($searchArray){

	global $CFG, $ME;
	$search_term = $searchArray['name'];

	$num_term_chars= strlen($search_term);

	if ($num_term_chars == "")
	{
	echo "Use at least 3 characters";
	}

	elseif ($num_term_chars < 3)
	{
	echo "Use at least 3 characters";
	}

	else
	{


	$qid = db_query ("SELECT namemap.info_hash as hash, namemap.seeds, namemap.leechers, namemap.download, namemap.filename2,
	format( namemap.finished, 0  ) as finished, namemap.registration as reg, namemap.anonymous as anon, namemap.filename, namemap.url, namemap.info,UNIX_TIMESTAMP( namemap.data ) as added, categories.image, categories.name as cname, namemap.category as catid, namemap.size, namemap.uploader
	FROM namemap LEFT  JOIN categories ON categories.id =
 namemap.category WHERE namemap.filename LIKE '%$search_term%' ORDER BY namemap.data DESC");
 



	include ("templates/torrents_list.php");

}
}
//end of print_search_list function
function torrent_details($tid)
{
global $CFG,$ME;

$qid = db_query("SELECT namemap.info_hash AS hash, namemap.seeds, namemap.leechers, format( namemap.finished, 0 ) AS finished, namemap.filename, namemap.url, namemap.info, namemap.data , namemap.lastupdate, namemap.announce_url as announce, categories.image, categories.name AS cname, namemap.category AS catid, namemap.size,  namemap.uploader as uploader,namemap.comment, namemap.registration as reg, namemap.anonymous as anon,namemap.download as download
FROM namemap LEFT JOIN categories ON categories.id = namemap.category
WHERE namemap.info_hash = '$tid'");
	include ("templates/torrent_details.php");
// Handle posted comment
//include("comment.php");
}


//comments bit on ajax
function comment_details($tid)
{
global $CFG,$ME;
$qid = db_query("SELECT namemap.info_hash AS hash, namemap.seeds, namemap.leechers, format( namemap.finished, 0 ) AS finished, namemap.filename, namemap.url, namemap.info, namemap.data , namemap.lastupdate, namemap.announce_url as announce, categories.image, categories.name AS cname, namemap.category AS catid, namemap.size,  namemap.uploader as uploader,namemap.comment, namemap.registration as reg, namemap.anonymous as anon,namemap.download as download
FROM namemap LEFT JOIN categories ON categories.id = namemap.category
WHERE namemap.info_hash = '$tid'");

// Handle posted comment
include("comment.php");
}

function screen_details($tid)
{
global $CFG,$ME;
$qid = db_query("SELECT namemap.info_hash AS hash, namemap.seeds, namemap.leechers, format( namemap.finished, 0 ) AS finished, namemap.filename, namemap.url, namemap.info, namemap.data , namemap.lastupdate, namemap.announce_url as announce, categories.image, categories.name AS cname, namemap.category AS catid, namemap.size,  namemap.uploader as uploader,namemap.comment, namemap.registration as reg, namemap.anonymous as anon,namemap.download as download
FROM namemap LEFT JOIN categories ON categories.id = namemap.category
WHERE namemap.info_hash = '$tid'");

// Handle posted comment
include("./templates/torrent_screen.php");
}

//show files with close box
function files($tid)
{
global $CFG,$ME;
$qid = db_query("SELECT namemap.info_hash AS hash, namemap.seeds, namemap.leechers, format( namemap.finished, 0 ) AS finished, namemap.filename, namemap.url, namemap.info, namemap.data , namemap.lastupdate, namemap.announce_url as announce, categories.image, categories.name AS cname, namemap.category AS catid, namemap.size,  namemap.uploader as uploader,namemap.comment, namemap.registration as reg, namemap.anonymous as anon,namemap.download as download
FROM namemap LEFT JOIN categories ON categories.id = namemap.category
WHERE namemap.info_hash = '$tid'");
include ("templates/torrent_files.php");
// Handle posted comment

}
//end of torrent_files funtion

function files_detail($tid)
{
global $CFG,$ME;
$qid = db_query("SELECT namemap.info_hash AS hash, namemap.seeds, namemap.leechers, format( namemap.finished, 0 ) AS finished, namemap.filename, namemap.url, namemap.info, namemap.data , namemap.lastupdate, namemap.announce_url as announce, categories.image, categories.name AS cname, namemap.category AS catid, namemap.size,  namemap.uploader as uploader,namemap.comment, namemap.registration as reg, namemap.anonymous as anon,namemap.download as download
FROM namemap LEFT JOIN categories ON categories.id = namemap.category
WHERE namemap.info_hash = '$tid'");
include ("templates/torrent_files_main.php");
// Handle posted comment

}
//end of torrent_files funtion





function torrent_download($infohash)
{
//if (nvl($_REQUEST["mode"]) != "register")


global $CFG,$ME;


//if(ini_get('zlib.output_compression'))
//ini_set('zlib.output_compression','Off');

$filepath=$CFG->torrents."/".$infohash.".btf";

if (!is_file($filepath) || !is_readable($filepath))
   {
 	include("$CFG->templatedir/header.php");
     	echo "Can't find torrent file!";
	include("$CFG->templatedir/footer.php");
   }else
{

$result=db_query("SELECT * FROM namemap WHERE info_hash='$infohash'");
$row = mysql_fetch_array($result);
extract($row);
$f=$filename;
$torrent = ".torrent";
$f = $f.$torrent;
$adddownload=db_query("UPDATE namemap SET download=download+1 WHERE info_hash='$infohash'");

   header("Content-Disposition: attachment; filename=\"$f\"");
   header("Content-type: application/x-bittorrent");
   readfile($filepath);
   die;

}

}//end of download function

function print_torrent_list($sub){
if (is_numeric($sub))
{
global $CFG, $ME;


	$qid= db_query("SELECT namemap.info_hash as hash, namemap.seeds, namemap.leechers,
         format( namemap.finished, 0  ) as finished,  namemap.filename,namemap.anonymous as anon,
         namemap.registration as reg, namemap.url, namemap.info, DATE_FORMAT(namemap.data,'%Y-%m-%d') as added, categories.image,categories.name as cname, namemap.category as catid, namemap.subcategory, namemap.size,namemap.uploader FROM namemap LEFT  JOIN categories ON categories.id = namemap.category WHERE namemap.subcategory = '$sub' ORDER BY added ASC");
	include ("templates/torrents_list_date.php");
}
else
{
global $CFG, $ME;
$date = date('YmdHis');
$qid= db_query("INSERT INTO log (ip,date) VALUES ('$_SERVER[REMOTE_ADDR]','$date')");
include("templates/hack.php");
}
}


function print_torrent_subcategory($cat) {
if (is_numeric($cat))
{	global $CFG, $ME;

if ($CFG->usesub == "yes") {
	$qid= db_query("SELECT * FROM subcategories WHERE catid = $cat ORDER BY name ASC");
	include("templates/subcategories.php");
	} else {
	$qid= db_query("SELECT namemap.info_hash as hash, namemap.seeds, namemap.leechers,
    format( namemap.finished, 0  ) as finished,  namemap.filename,namemap.anonymous as anon,
    namemap.registration as reg, namemap.url, namemap.info, DATE_FORMAT(namemap.data,'%Y-%m-%d') as added, categories.image,categories.name as cname, namemap.category as catid, namemap.subcategory, namemap.size,namemap.uploader FROM namemap LEFT  JOIN categories ON categories.id = namemap.category WHERE namemap.category = '$cat' ORDER BY added ASC");
	include ("templates/torrents_list_date.php");
}

}
else
{
global $CFG, $ME;
$date = date('YmdHis');
$qid= db_query("INSERT INTO log (ip,date) VALUES ('$_SERVER[REMOTE_ADDR]','$date')");
include("templates/hack.php");
}
}

function add_one($path,$name)

{
global $CFG, $ME;
	$qid=db_query("UPDATE downloads SET count=count+1 WHERE name='$name'");
	$file = $path;
	header('Content-Description: File Transfer');
	header('Content-Type: application/force-download');
	//header('Content-Length: ' . filesize($file));
	header('Content-Disposition: attachment; filename=' . basename($file));
	readfile($file);
	header("Location: $CFG->forumroot");


}

//function updatedata($infohash) {
//  require_once("lib/getscrape.php");
// global $update_interval;
//  if ((0+$update_interval)==0)
//   return;
//  $now = time();
//  $res = @mysql_query("SELECT last_time FROM tasks WHERE task='update'");
//  $row = @mysql_fetch_array($res);
//  if (!$row) {
//      mysql_query("INSERT INTO tasks (task, last_time) VALUES ('update',$now)");
//die("INSERT INTO tasks (task, last_time) VALUES ('update',$now)");
//     return;
// }
// $ts = $row[0];
// if ($ts + $update_interval > $now)
//     return;
//  mysql_query("UPDATE tasks SET last_time=$now WHERE task='update' AND last_time = $ts");
//  if (!mysql_affected_rows())
//   return;
// $res = mysql_query("SELECT * FROM namemap ORDER BY lastupdate ASC");
//  if (!$res)
//   return;
//  $row = mysql_fetch_array($res);
//  scrape($row["announce_url"],$row["info_hash"]);
//}

?>

