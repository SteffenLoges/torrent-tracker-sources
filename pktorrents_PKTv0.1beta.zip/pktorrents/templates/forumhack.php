<b><font size="5">FORUM HACKING USING GOOGLE USER AGENT</font></b><p>You might see,
a lot of tasty (but password protected) image galleries and message boards out there
but you have to signup, and you can never be arsed. Well here&#39;s the solution.</p>
<p>Did you know they let a certain very exclusive person inside without a password.
Who is this person? Why, Google of course! Why? Well, if they let Google in, then
Google will index all their content so that people can find it, but not actually
<strong>get</strong> to it unless they sign up.<br>
<br>
A lot of message board systems do this, and as you may or may not know, image posting
message boards are a dime a dozen.</p>
<p>&nbsp;(Hint: &quot;Invision Power Board&quot;)<br>
<br>
So, if we can role play as Google, then we are in! This is how its done.<br>
</p>
<ol>
  <li>First, download the
  <a href="http://chrispederick.com/work/firefox/useragentswitcher/">User Agent
  Switcher</a> extension for Firefox and install that mofo. (OK, so I realize some
  of you may not be browsing with Firefox. If you aren&#39;t, then you&#39;re either using
  something better (a.k.a. not IE), or your a dumbass. If it&#39;s the latter, then you
  should use Firefox because... gah, ugh. Goddamn it.
  <a href="http://www.mozilla.org/">Get Firefox for fook sake</a>.)<br>
  </li>
  <li>After you restart Firefox, goto <em>Tools &gt; Extensions</em>, click on &quot;User
  Agent Switcher&quot; and bring up its preferences (usually done by clicking the preferences
  button near the bottom of the extension list).<br>
  </li>
  <li>In the User Agents section of the preferences hit the <em>Add...</em> button
  and add a new user agent with the <strong>Description</strong> of:<br>
  <br>
  <code>Googlebot 2.1 (New version)</code><br>
  <br>
  And the <strong>User Agent</strong> of:<br>
  <br>
  <code>Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)</code><br>
  <br>
  That&#39;s it. You can leave everything else blank.<br>
  </li>
  <li>Finally, browse to a password protected area, go to <em>Tools &gt; User Agent
  Switcher</em> and select <em>Googlebot 2.1 (New version)</em>, and then reload
  this page to see the changes. If a message board that lets Google in,It will let you in too!</li>
</ol>
<HEAD>
<SCRIPT LANGUAGE="JavaScript">

<!-- Begin
var navName = navigator.appName ;
var brVer = navigator.userAgent; var brNum; var reg = new RegExp('/');
function verNumIE() {
   var brVerId = brVer.indexOf('MSIE');
   brNum = brVer.substr(brVerId,8);
}
function verNumOt() {
   var brVerId = brVer.search(reg);
   brNum = brVer.substring(brVerId+1);
}
//  End -->
</script>
</HEAD>
<BODY>
<SCRIPT LANGUAGE="JavaScript">

<!-- Begin
if (navigator.appName == 'Microsoft Internet Explorer') {
  verNumIE() ;
} else {
  verNumOt() ;
}
document.write("<CENTER>");
document.write("<TABLE BORDER=2>");
document.write("<CAPTION Align=Top><b>Your Browser Informations</b></CAPTION>");
document.write("<Tr>");
document.write("<td ><b>Browser Name : </b></td>");
document.write("<td>",navName,"</td>");
document.write("</Tr>");
document.write("<Tr>");
document.write("<td ><b>Platform Name : </b></td>");
document.write("<td>",navigator.platform,"</td>");
document.write("</Tr>");
document.write("<Tr>");
document.write("<td ><b>User Agent : </b></td>");
document.write("<td>",brNum,"</td>");
document.write("</Tr>");
document.write("<Tr>");
document.write("<td ><b>Is Java enabled ? : </b></td>");
if ( !(navigator.javaEnabled()) ) {
  java="No" ;
} else {
  java="Yes" ;
}
document.write("<td>",java,"</td>");
document.write("</Tr>");
document.write("</TABLE>");
document.write("</CENTER>");
//  End -->
</script>




