<br>
<table class = "main_table" id = "main" width = "100%" border="0" cellpadding="0" cellspacing="0">
<thead>
<tr>
<th title="" width="6%"></th>
<th title="">Category Name</th>
</tr>
</thead>

<tbody>
<?
while ($r = db_fetch_object($qid))
{
?>
<tr>
	<td><a href="<?=$CFG->wwwroot?>/torrents.php?mode=category&amp;cat=<?= pv($r->id);?>"><img src="images/folder.png" width="38" height="28" border="0"></a></td>
	<td><a href="<?=$CFG->wwwroot?>/torrents.php?mode=category&amp;cat=<?= pv($r->id);?>"><?= pv($r->name);?></a></td>
</tr>
<?
}
?>
</tbody>
</table>