<?$DOC_TITLE = "$CFG->webname - Source Code";?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-gb">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

</head>

<body>

<p><font size="6">DEVELOPMENT & SOURCECODE</font></p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0"><font size="2">Once I have finished the
site and made it perfecto! You will see the source code of this site for download
on this page, That you can install on a server running PHP4/5 and mySQL4/5</font></p>
<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1" bgcolor="#000000">
  <tr>
    <td width="100%">
    <p align="center"><font size="2" color="#FF0000">
    <span style="font-weight: 700"><span style="background-color: #FFFFFF">NOTE:</span>
    Many webhosts don't allow torrent files because many/most torrent files
    spread copyrighted data, check with you host before hand! I hold no
    responsibility for you getting kicked from your webhost because you broke
    there TOS.</span></font></td>
  </tr>
</table>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0">
<a href="http://proxykill.9999mb.com/phpBB2/">Discussion Forum</a></p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0"><font size="2">These are some features
I want to add before I release it: </font></p>
<ul>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">Rating torrents...<font color="#00FF00">DONE</font></font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">Update Single
  Torrent...<font color="#00FF00">DONE</font></font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">Inbuilt forum.</font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">Mended ibitzy torrent
  spider integrated into admin...<font color="#00FF00">DONE</font></font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">BB code in descriptions...<font color="#00FF00">DONE</font></font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">Better torrent health
  always shows an image...<font color="#00FF00">DONE</font> Also mouse over will
  display a explanation. </font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">CAPTCHA for registration...<font color="#00FF00">DONE</font></font></p>
  </li>
  <li>
  <p style="margin-top: 0; margin-bottom: 0"><font size="2">AD System or an AD
  include on every page.</font></p>
  </li>
</ul>
<p style="margin-top: 0; margin-bottom: 0"><font size="2">DOWNLOAD SOURCE</font></p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<p style="margin-top: 0; margin-bottom: 0">Dont want to signup to any forums? <a href="<?=$CFG->wwwroot?>/index.php?mode=forumhacking">Change User Agent</a></p>

</body>

</html>
