<div class="navbar">
<h3>What is BitTorrent?</h3>
<p>BitTorrent is a relatively new sort of p2p network, more information and background can be found <a onclick="window.open(this.href,'_blank');return false;" href="http://dessent.net/btfaq/">here.</a> </p>
<h3>How can I download these files?</h3>
<p>In order to download files you need a BitTorrent download client. Here are the ones we recommend:</p>
<ul>
  <li><a onclick="window.open(this.href,'_blank');return false;" href="http://www.utorrent.com/"><b>uTorrent (Most Recommend)</b></a></li>
  <li><a onclick="window.open(this.href,'_blank');return false;" href="http://www.bittornado.com">Bittornado </a></li>
  <li><a onclick="window.open(this.href,'_blank');return false;" href="http://pingpong-abc.sourceforge.net/">ABC</a></li>
  <li><a onclick="window.open(this.href,'_blank');return false;" href="http://azureus.sourceforge.net/">Azureus</a></li>
  </ul>
<h3>Do you have step-by-step tutorial?</h3>
<p>Yes. Here is the link <a onclick="window.open(this.href,'_blank');return false;" href="http://www.poromenos.org/tutorials/bittorrent/download//">http://www.poromenos.org/tutorials/bittorrent/download/</a></p>
<h3>What are seeds and peers?</h3>
<p>Someone is called a seeder when he or she is uploading a file, a peer/leecher is someone who has yet to finish the download.</p>
<h3>How can I create my own torrent file?</h3>
<p>Here is a tutorial how to create your torrent file. <a onclick="window.open(this.href,'_blank');return false;" href="http://torrentfreak.com/how-to-create-a-torrent//">http://torrentfreak.com/how-to-create-a-torrent/</a> </p>
<p>also most Bit-torrent clients have an in-built function for making your own
torrents</p>
<h3>What does this icon mean (<img src="<?=$CFG->imagedir?>/regb.gif" alt="[R]" />)?</h3>
<p>This indicates that the tracker requires some sort of registration (mostly done to prevent leeching). Check out the tracker url for more details.</p>
</div>
<h3>How can I stay up-to-date with <?=$CFG->webname?>?</h3>
<br>
We offer an RSS feed to stay up-to-date with <?=$CFG->webname?>. You need an RSS reader to use this. In Mozilla Firefox, just click the RSS icon in the bottom right corner of your browser window. In Opera the newsfeeds will automatically be subscribed when you click this <a href="<?=$CFG->wwwroot?>/rss.php">link</a>, the feed will show up under "Newsfeeds" at the bottom of your "Mail" panel. Users with other browsers have to download a RSS reader, you can find a list <a href="http://blogspace.com/rss/readers">here.</a>
<br>The feed URL is<b> <?=$CFG->wwwroot?>/rss.php</b>


