<? //////////////////////////////////////
   //         Colours file             //
   //    Implamented by proxykill      //
   //////////////////////////////////////
   //                                  //
   // THERES NO NEED TO EDIT THIS FILE //
   //CHANGE THE COLOURS VIA CONFIG.PHP //
   //////////////////////////////////////
include "../config.php";
header("Content-type: text/css");

?>

body {
	color:<?=$CFG->bodycolour?>;
	border-color:<?=$CFG->bodyborder?>;
        font-size:<?=$CFG->mainfontsize?>;
        font-family:<?=$CFG->mainfont?>;
}

.notice   {  font-family:<?=$CFG->mainfont?>;
             font-size:<?=$CFG->mainfontsize?>;
             color:<?=$CFG->warnings?>;
}

h1, h2, h3, h4, h5, h6 {
	color:<?=$CFG->headingcolour?>;
	font-family:<?=$CFG->mainfont?>;
	font-weight:<?=$CFG->headingfontweight?>;
}

h1, h2, h3{
        font-size:<?=$CFG->mainfontsize?>;
	font-weight:<?=$CFG->mainfontweight?>;
}

#banner p {
        font-family:<?=$CFG->mainfont?>;
	font-size:<?=$CFG->mainfontsize?>;
}

.box h3 {
	background-color:<?=$CFG->boxhead3bgcolour?>;
	color:<?=$CFG->boxhead3colour?>;
}

.box h4 {
	background-color:<?=$CFG->boxhead4bgcolour?>;
	color:<?=$CFG->boxhead4colour?>;
}

#contentfull h3,h1{
	color:<?=$CFG->contentcolour?>;
}

#footer {
	font-size: smaller;
}

#navigation {
	color:<?=$CFG->navcolour?>;
	background-color:<?=$CFG->navbgcolour?>;
        font-family:<?=$CFG->mainfont?>;
        font-weight:<?=$CFG->mainfontweight?>;
}

#navigationcat {
        color:<?=$CFG->navcatcolour?>;
	background-color:<?=$CFG->navcatbgcolour?>;
        font-family:<?=$CFG->mainfont?>;
        font-weight:<?=$CFG->mainfontweight?>;
}
/* Form widgets */
.button {
	background-color:<?=$CFG->buttonbgcolour?>;
	color:<?=$CFG->buttontxtcolour?>;
        font-weight:<?=$CFG->mainfontweight?>;
}

input {
	background-color:<?=$CFG->imputcolour?>;
	border-color:<?=$CFG->buttonbordercolour?>;
        font-weight:<?=$CFG->mainfontweight?>;
}

#navigation a, #navigation a:active, #navigation a:visited {
	color:<?=$CFG->linkcolour?>;
}

a, a:active {
	color:<?=$CFG->linkcolour?>;
	text-decoration:<?=$CFG->linkdecor?>;
}

a:hover, a:active:hover, a:visited:hover {
	color:<?=$CFG->linkhover?>;
}
.warning {
color:<?=$CFG->warnings?>;
}

