<?
while ($r = db_fetch_object($qid))
{
?>

<table align="center" class="main_table" border="0">
<tr>
<td>Total Seeds</td>
<td><div class="b"><?= pv($r->seeds)?></div></td>
</tr>

<tr>
<td>Total Peers</td>
<td><div class="b"><?= pv($r->leechers)?></div></td>
</tr>

<tr>
<td>Finished Downloads</td>
<td><div class="b"><?= pv($r->finished)?></div></td>
</tr>

<tr>
<td>Total Trackers</td>
<td><div class="b"><?= pv($r->trackers)?></div></td>
</tr>

<tr>
<td>Total Torrents</td>
<td><div class="b"><?= pv($r->torrents)?></div></td>
</tr>

<tr>
<td>Total Size</td>
<td><div class="b"><?= makesize($r->size)?></div></td>
</tr>







<?
}
?>
</table>


