<?
while ($r = db_fetch_object($qid))
{
  if ($r->anon == 'true') $r->uploader='Guest';
?>


<p><span><font size="5"><?= pv($r->filename) ?></font></span></p>
<div class="main_table">
<table width="100%" border="0" >
 <tr>
    <td width="18%">Screenshot</td>
    <td>

    <? if (file_exists("upload/$r->hash.jpg")) { ?>

    <img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.jpg&maxw=500" /></a>

	<? } elseif (file_exists("upload/$r->hash.gif")) { ?>

	    <img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.gif&maxw=500" /></a>

	<? } elseif (file_exists("upload/$r->hash.jpeg")) { ?>

	    <img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.jpeg&maxw=500" /></a>

	<? } else { ?>

	    <img src="./thumbnail.php?gd=2&src=./images/noss.png&maxw=500" /></a>

	 <? } ?>


    </td>
  </tr>

<?  if (is_logged_in()) {

 if ( $r->uploader == $_SESSION['userName'] ) { ?>

 <tr>
 <td width="18%">Upload Screenshots</td>
 <td>
 <a href="" onClick="window.open('./uploadss.php?mode=upload&amp;id=<?= pv($r->hash)?>','Upload screenshot for <?= pv($r->filename) ?>','width=400,height=300')"><img src="./images/uploadss.jpg" width="120" height="18" border="0"></a>
</td>
</tr>
<? } ?>

<? if ( $r->uploader <> $_SESSION['userName'] ) { ?>

 <tr>
</tr>
<? }
} ?>

</table>

</div>

<?
}
?>

</div>






