<?
while ($r = db_fetch_object($qid))
{
  if ($r->anon == 'true') $r->uploader='Guest';
?>
<h2><?= pv($r->filename) ?></h2>

<?include ("./lib/getscrape.php");?>
<? require_once("./rate.php"); ?>

<a href="torrents.php?mode=download&amp;id=<?= pv($r->hash)?>"><img alt="Download Torrent" width="120" height="28" border="0" src="<?=$CFG->wwwroot?>/images/download.jpg"></a>

<?if ($CFG->regdownload == "yes") {
	 if (is_logged_in()) {
         } else {
	echo "<br>You need to login to download our torrents.&#160;<a href=\"$CFG->wwwroot/login.php\">Login.</a> Not got an account yet? &#160;<a href=\"$CFG->wwwroot/users/index.php?mode=register\">Register.</a> ";
	} ?>
	


<?

	}
?>

<!-- SHOW FILES -->
<div >
<h3 onclick="expandcontent(this, 'openfiles')" style="cursor:pointer"><span class="showstate"></span>View Files</h3>


<div id="openfiles" class="switchcontent">
<table width="100%" border="0" class="infotable">
  <tr>
    <? @showfiles($r->hash); ?>

  </tr></table>

</div>
</div>

<!-- SHOW SCREENSHOTS -->
<script src="./js/lightbox.js"></script>
<h3>Screenshot</h3>
<div class="main_table">
<table width="100%" border="0" >
 <tr>
    <td width="18%">Screenshot</td>
    <td>

    <? if (file_exists("upload/$r->hash.jpg")) { ?>

    <a href="./upload/<?= pv($r->hash)?>.jpg" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.jpg&maxw=200" width="200"/></a>

	<? } elseif (file_exists("upload/$r->hash.gif")) { ?>

	    <a href="./upload/<?= pv($r->hash)?>.gif" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.gif&maxw=200"width="200" /></a>

	<? } elseif (file_exists("upload/$r->hash.jpeg")) { ?>

	    <a href="./upload/<?= pv($r->hash)?>.jpeg" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.jpeg&maxw=200" width="200"/></a>

	<? } else { ?>

	    <a href="./images/noss.png" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./images/noss.png&maxw=200" width="200"/></a>

	 <? } ?>


    </td>
  </tr>







<? if ( $r->uploader == $_SESSION['userName'] ) { ?>

 <tr>
 <td width="18%">Upload Screenshots</td>
 <td>
 <a href="" onClick="window.open('./uploadss.php?mode=upload&amp;id=<?= pv($r->hash)?>','Upload screenshot for <?= pv($r->filename) ?>','width=400,height=300')"><img src="./images/uploadss.jpg" width="120" height="18" border="0"></a>
</td>
</tr>
<? } ?>

<? if ( $r->uploader <> $_SESSION['userName'] ) { ?>

 <tr>
</tr>
<? } ?>

</table>

</div>

<?
}
?>
