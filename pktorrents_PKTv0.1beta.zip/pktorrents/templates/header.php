<?
//if (extension_loaded('zlib')) {
//@ob_start("ob_gzhandler");
//}
global $time_begin;
$time_begin = get_micro_time();

echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>";
$side=true;
$microtime = microtime();
$split = explode(" ", $microtime);
$exact = $split[0];
$secs = date("U");
$bgtm = $exact + $secs;
error_reporting(E_ALL ^ E_NOTICE);
?>
<?
/* check if file is being accessed directly */
if (eregi("header.php",$_SERVER['PHP_SELF']))
{
  Header("Location: $CFG->wwwroot");
  die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--
///////////////////////////////////
//PK-TORRENTS Version:<?=$CFG->version?>//
///////////////////////////////////
-->
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/layout.php" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?=$CFG->wwwroot?>/js/ajaxtabs.css" />
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/colours.php" type="text/css" title="Default"/>
<link rel="stylesheet" href="<?=$CFG->wwwroot;?>/css/lightbox.css" type="text/css" media="screen" />
<link rel="alternate" type="application/xml" title="<? pv($DOC_TITLE) ?> RSS feed" href="<?=$CFG->wwwroot?>/rss.php"/>
<link rel="shortcut icon" href="<?=$CFG->wwwroot?>/favicon.ico" />
<script src="<?=$CFG->wwwroot;?>/js/site.js" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/js/prototype.js" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/js/scriptaculous.js?load=effects" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/sorttable.js" type="text/javascript"></script>
<script type="text/javascript" src="<?=$CFG->wwwroot;?>/hide.js"></script>
<script type="text/javascript" src="<?=$CFG->wwwroot;?>/js/preload.js"></script>
<script type="text/javascript" src="<?=$CFG->wwwroot;?>/js/ajaxtabs.js"></script>
<title><? pv($DOC_TITLE) ?></title>
<script src="../js/lightbox.js"></script>
</head>
<!--
///////////////////////////////////
//PK-TORRENTS Version:<?=$CFG->version?>//
///////////////////////////////////
-->
<body bgcolor="<?=$CFG->bgcolour?>">

 <? //Code For Stats

  define("_BBCLONE_DIR", "$serverroot/admin/bbclone/"); define("COUNTER", _BBCLONE_DIR."mark_page.php"); if (is_readable(COUNTER)) include_once(COUNTER);
  ?>
<table align="center" border="1" cellpadding="0" cellspacing="0" width="950" height="" style="border-collapse:collapse;" bgcolor="<?=$CFG->maincolour?>">
<tr>
<td width="100%" height="100%" style="border-width:1px; border-style:solid;"><br>
<? if (is_logged_in()) { ?>
    <div align="right" valign="top">
	    <? if ($_SESSION['privilege'] == "admin") { ?>
	    <a href="<?=$CFG->wwwroot?>/admin/index.php" OnMouseOut="na_restore_img_src('image11', 'document')"
		OnMouseOver="na_change_img_src('image11', 'document', '<?=$CFG->imagedir?>/adminmode2.gif', true)">
		<img src="<?=$CFG->imagedir?>/adminmode.gif" width="154" height="20" border="0" name="image11"></a>

	    <a href="<?=$CFG->wwwroot?>/update_stats.php" OnMouseOut="na_restore_img_src('image12', 'document')"
		OnMouseOver="na_change_img_src('image12', 'document', '<?=$CFG->imagedir?>/updatestats2.gif', true)">
		<img src="<?=$CFG->imagedir?>/updatestats.gif" width="154" height="20" border="0" name="image12"></a>

	    <? } ?>
	    <a href="<?=$CFG->wwwroot?>/users" OnMouseOut="na_restore_img_src('image7', 'document')"
		OnMouseOver="na_change_img_src('image7', 'document', '<?=$CFG->imagedir?>/userhome2.gif', true)">
		<img src="<?=$CFG->imagedir?>/userhome.gif" width="154" height="20" border="0" name="image7"></a>

	    <a href="<?=$CFG->forumroot?>/profile.php?mode=editprofile" OnMouseOut="na_restore_img_src('image8', 'document')"
		OnMouseOver="na_change_img_src('image8', 'document', '<?=$CFG->imagedir?>/changeprofile2.gif', true)">
		<img src="<?=$CFG->imagedir?>/changeprofile.gif" width="154" height="20" border="0" name="image8"></a>

		<a href="<?=$CFG->wwwroot?>/users" OnMouseOut="na_restore_img_src('image9', 'document')"
		OnMouseOver="na_change_img_src('image9', 'document', '<?=$CFG->imagedir?>/mytorrents2.gif', true)">
		<img src="<?=$CFG->imagedir?>/mytorrents.gif" width="154" height="20" border="0" name="image9"></a>

		<a href="<?=$CFG->wwwroot?>/logout.php" OnMouseOut="na_restore_img_src('image10', 'document')"
		OnMouseOver="na_change_img_src('image10', 'document', '<?=$CFG->imagedir?>/logout2.gif', true)">
		<img src="<?=$CFG->imagedir?>/logout.gif" width="154" height="20" border="0" name="image10"></a>
	<br>
	<br>
	</div>
	
	<? } else { ?>
	
	<div align="right" valign="top">
	    <a href="<?=$CFG->wwwroot?>/login.php" OnMouseOut="na_restore_img_src('image13', 'document')"
		OnMouseOver="na_change_img_src('image13', 'document', '<?=$CFG->imagedir?>/login2.gif', true)">
		<img src="<?=$CFG->imagedir?>/login.gif" width="154" height="20" border="0" name="image13"></a>

	    <a href="<?=$CFG->wwwroot?>/users/index.php?mode=register" OnMouseOut="na_restore_img_src('image15', 'document')"
		OnMouseOver="na_change_img_src('image15', 'document', '<?=$CFG->imagedir?>/register2.gif', true)">
		<img src="<?=$CFG->imagedir?>/register.gif" width="154" height="20" border="0" name="image15"></a>
	<br>
	<br>
    </div>
    
	<? } ?>



<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" height="60" background="<?=$CFG->imagedir?>/bannerbg.gif">
   <tr>
   <td width="50%" height="60">
   <div>
  
</div></td>
<td width="50%" height="60" align="right">

<div class="right">

<form action="<?=$CFG->wwwroot?>/torrents.php" method="post" enctype="multipart/form-data">
<div><font color="<?=$CFG->searchboxtxtcolour?>">Search Torrents: <input type="text" name="name" id="search" /></font>
<input type="hidden" name="mode" value="search"/>
<input class="button" type="submit" value="Go!" />
</div>
</form>
</div>
</td>
</tr>
</table>
<!-- END HEADER-TOP -->

<? if (nvl($side)) {?>

<!-- BEGIN SIDEBAR -->
    <div id="sidebar">

<? if ($CFG->usephpbb != "yes") {

    if (is_logged_in()) { ?>

	<div class="box">
	<h4>User Menu</h4>
	<br>
<!-- LOGGED IN Menu -->
<div align="center" valign="top">
<a href="<?=$CFG->wwwroot?>/users/index.php?mode=changepassword" OnMouseOut="na_restore_img_src('image18', 'document')"
OnMouseOver="na_change_img_src('image18', 'document', '<?=$CFG->imagedir?>/changepass2.gif', true)">
<img src="<?=$CFG->imagedir?>/changepass.gif" width="154" height="20" border="0" name="image18"></a>
</div>
</div>

<? }  } ?>


    <div class="box">
    <h4>Menu</h4>
<br>
<!-- NEW Menu -->
<div align="center" valign="top">

<a href="<?=$CFG->wwwroot?>/index.php" OnMouseOut="na_restore_img_src('image1', 'document')"
OnMouseOver="na_change_img_src('image1', 'document', '<?=$CFG->imagedir?>/home2.gif', true)">
<img src="<?=$CFG->imagedir?>/home.gif" width="154" height="20" border="0" name="image1"></a>
<br>
<a href="<?=$CFG->wwwroot?>/index.php?mode=latesttorrents" OnMouseOut="na_restore_img_src('image19', 'document')"
OnMouseOver="na_change_img_src('image19', 'document', '<?=$CFG->imagedir?>/latesttorrents2.gif', true)">
<img src="<?=$CFG->imagedir?>/latesttorrents.gif" width="154" height="20" border="0" name="image19"></a>
<br>
<a href="<?=$CFG->wwwroot?>/index.php?mode=directory" OnMouseOut="na_restore_img_src('image14', 'document')"
OnMouseOver="na_change_img_src('image14', 'document', '<?=$CFG->imagedir?>/directory2.gif', true)">
<img src="<?=$CFG->imagedir?>/directory.gif" width="154" height="20" border="0" name="image14"></a>
<br>
<a href="<?=$CFG->wwwroot?>/torrents.php?mode=upload" OnMouseOut="na_restore_img_src('image17', 'document')"
OnMouseOver="na_change_img_src('image17', 'document', '<?=$CFG->imagedir?>/uploadtorrent2.gif', true)">
<img src="<?=$CFG->imagedir?>/uploadtorrent.gif" width="154" height="20" border="0" name="image17"></a>
<br>
<a href="<?=$CFG->forumroot?>" OnMouseOut="na_restore_img_src('image6', 'document')"
OnMouseOver="na_change_img_src('image6', 'document', '<?=$CFG->imagedir?>/forum2.gif', true)">
<img src="<?=$CFG->imagedir?>/forum.gif" width="154" height="20" border="0" name="image6"></a>
<br>
<a href="<?=$CFG->wwwroot?>/index.php?mode=stats" OnMouseOut="na_restore_img_src('image2', 'document')"
OnMouseOver="na_change_img_src('image2', 'document', '<?=$CFG->imagedir?>/stats2.gif', true)">
<img src="<?=$CFG->imagedir?>/stats.gif" width="154" height="20" border="0" name="image2"></a>
<br>
<a href="<?=$CFG->wwwroot?>/index.php?mode=news" OnMouseOut="na_restore_img_src('image3', 'document')"
OnMouseOver="na_change_img_src('image3', 'document', '<?=$CFG->imagedir?>/news2.gif', true)">
<img src="<?=$CFG->imagedir?>/news.gif" width="154" height="20" border="0" name="image3"></a>
<br>
<a href="<?=$CFG->wwwroot?>/index.php?mode=faq" OnMouseOut="na_restore_img_src('image5', 'document')"
OnMouseOver="na_change_img_src('image5', 'document', '<?=$CFG->imagedir?>/faq2.gif', true)">
<img src="<?=$CFG->imagedir?>/faq.gif" width="154" height="20" border="0" name="image5"></a>
<br>
<a href="<?=$CFG->wwwroot?>/index.php?mode=copyright" OnMouseOut="na_restore_img_src('image4', 'document')"
OnMouseOver="na_change_img_src('image4', 'document', '<?=$CFG->imagedir?>/about2.gif', true)">
<img src="<?=$CFG->imagedir?>/about.gif" width="154" height="20" border="0" name="image4"></a>
<br>
<?php
$fcontents = join ('', file ('./ads/ad_left.txt'));
$s_con = split("~",$fcontents);
$banner_no = rand(0,(count($s_con)-1));
echo $s_con[$banner_no];
?>


</div>

</div>

</div>

	<!-- END USER MENU -->

<div id="content">
   <?}else {?>
 <div id="contentfull">
    <?
    }
?>
