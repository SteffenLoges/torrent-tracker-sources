<?
while ($r = db_fetch_object($qid))
{
  if ($r->anon == 'true') $r->uploader='Guest';
?>
<h2><?= pv($r->filename) ?></h2>

<?include ("./lib/getscrape.php");?>
<? require_once("./rate.php"); ?>

<a href="torrents.php?mode=download&amp;id=<?= pv($r->hash)?>"><img alt="Download Torrent" width="120" height="28" border="0" src="<?=$CFG->wwwroot?>/images/download.jpg"></a>

<?if ($CFG->regdownload == "yes") {
	 if (is_logged_in()) {
         } else {
	echo "<br>You need to login to download our torrents.&#160;<a href=\"$CFG->wwwroot/login.php\">Login.</a> Not got an account yet? &#160;<a href=\"$CFG->wwwroot/users/index.php?mode=register\">Register.</a> ";
	} ?>
	

                

<br><br>
<div class="main_table">
<table width="694" border="0" >
  <tr>
    <td width="137">Download</td>
    <td width="99"><a href="torrents.php?mode=download&amp;id=<?= pv($r->hash)?>"><?= pv($r->filename) ?></a> </td>
  </tr>
<tr>
    <td width="137">Uploaded By</td>
<?///Only View Uploader when logged in added by proxykill?>
<?if  (is_logged_in()){?>
<td width="99"><a href="<?=$CFG->wwwroot?>/users/index.php?mode=userinfo&amp;username=<?= p($r->uploader) ?>"><?= p($r->uploader) ?></a>
</td>
  <?}else{?><td width="143">Hidden (Must be logged in!)</td><?}
  ////END?>
  </tr>

  <tr>
    <td width="137">Category</td>
    <td width="99"><a href="torrents.php?mode=category&amp;cat=<?= $r->catid ?>"><?= pv($r->cname);?></a></td>
  </tr>
  <tr>
    <td width="137">Size</td>
    <td width="99"><?= makesize($r->size) ?></td>

  </tr>

  <tr>
    <td width="137">Peers</td>
    <td width="99"><?if ($r->leechers == 0) {?><div class="rr"><?}else{?> <div class="rb"><?}?><?= $r->leechers ?></div></td>
  </tr>
  <tr>
    <td width="137">Seeds</td>
    <td width="99"><?if ($r->seeds == 0) {?><div class="lr"><?}else{?> <div class="lg"><?}?><?= $r->seeds ?></div></td>
</tr>
 <tr>
 <td width="137">Update torrent Stats                                       </td>
   <?if  (is_logged_in()){?><td width="99"><a href="torrents.php?mode=updatedata&amp;id=<?= pv($r->hash)?>&amp;announce=<?= pv($r->announce)  ?>">Do It</a></td>


  <?}else{?><td width="143">Hidden (Must be logged in!)</td><?}
  ////END?>

  </tr>
<tr>
<td width="137">Torrent Health</td>
<? if ($r->seeds >= 5){?>
<td width="99" ><div class="lr"><img alt="5" src="<?=$CFG->health;?>/5.gif" width="54" height="10"/><?}?></div></td>

<? if ($r->seeds == 4){?>
<td width="143" ><div class="lr"><img alt="4" src="<?=$CFG->health;?>/4.gif" width="54" height="10"/><?}?></div></td>

<? if ($r->seeds == 3){?>
<td width="56" ><div class="lr"><img alt="3" src="<?=$CFG->health;?>/3.gif" width="54" height="10"/><?}?></div></td>

<? if ($r->seeds == 2){?>
<td width="56" ><div class="lr"><img alt="2" src="<?=$CFG->health;?>/3.gif" width="54" height="10"/><?}?></div></td>

<? if ($r->seeds == 1){?>
<td width="56" ><div class="lr"><img alt="1" src="<?=$CFG->health;?>/2.gif" width="54" height="10"/><?}?></div></td>

<? if ($r->seeds == 0){?>
<td width="56" ><div class="lr"><img alt="0" src="<?=$CFG->health;?>/01.gif" width="54" height="10"/><?}?></td></div></td>
<? if ($r->seeds == -1){?>
<td width="57" ><div class="lr"><img alt="Error" src="<?=$CFG->health;?>/00.gif" width="54" height="10"/><?}?></td></div></td>
        </tr>
<tr>
    <td width="137">User Rating</td>
    <td width="99"><? echo ratetor("$r->hash");?></td>
  </tr>
    <tr>
    <td width="137">Completed Downloads</td>
    <td width="99"><?= ($r->finished) ?> Global</td>
  </tr>
  <tr>
   <td width="137">Times Downloaded</td>
    <td width="99"><?= $r->download ?> Local</td>
  </tr>


<tr>
    <td width="137">Tracked By</td>
    <td width="99"><?= pv($r->announce)  ?></td>
  </tr>
    <tr>
    <td width="137">Added</td>
    <td width="99"><?= pv($r->data) ?></td>
  </tr>
  <tr>
    <td width="137">Last Update</td>
    <td width="99"><?= pv($r->lastupdate) ?></td>
  </tr>
  <tr>
    <td width="137">Comment from uploader</td>

    <td width="99"><?= ($r->comment) ?></td>
    </tr>



</table>
</div>
<?

	}
?>

<!-- SHOW FILES -->
<div >
<h3 onclick="expandcontent(this, 'openfiles')" style="cursor:pointer"><span class="showstate"></span>View Files</h3>


<div id="openfiles" class="switchcontent">
<table width="100%" border="0" class="infotable">
  <tr>
    <? @showfiles($r->hash); ?>

  </tr></table>

</div>
</div>

<!-- SHOW SCREENSHOTS -->
<script src="./js/lightbox.js"></script>
<h3>Screenshot</h3>
<div class="main_table">
<table width="100%" border="0" >
 <tr>
    <td width="18%">Screenshot</td>
    <td>

    <? if (file_exists("upload/$r->hash.jpg")) { ?>

    <a href="./upload/<?= pv($r->hash)?>.jpg" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.jpg&maxw=200" width="200"/></a>

	<? } elseif (file_exists("upload/$r->hash.gif")) { ?>

	    <a href="./upload/<?= pv($r->hash)?>.gif" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.gif&maxw=200"width="200" /></a>

	<? } elseif (file_exists("upload/$r->hash.jpeg")) { ?>

	    <a href="./upload/<?= pv($r->hash)?>.jpeg" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./upload/<?= pv($r->hash)?>.jpeg&maxw=200" width="200"/></a>

	<? } else { ?>

	    <a href="./images/noss.png" rel="lightbox" title="<?= pv($r->filename) ?>"><img src="./thumbnail.php?gd=2&src=./images/noss.png&maxw=200" width="200"/></a>

	 <? } ?>


    </td>
  </tr>







<? if ( $r->uploader == $_SESSION['userName'] ) { ?>

 <tr>
 <td width="18%">Upload Screenshots</td>
 <td>
 <a href="" onClick="window.open('./uploadss.php?mode=upload&amp;id=<?= pv($r->hash)?>','Upload screenshot for <?= pv($r->filename) ?>','width=400,height=300')"><img src="./images/uploadss.jpg" width="120" height="18" border="0"></a>
</td>
</tr>
<? } ?>

<? if ( $r->uploader <> $_SESSION['userName'] ) { ?>

 <tr>
</tr>
<? } ?>

</table>

</div>

<?
}
?>
