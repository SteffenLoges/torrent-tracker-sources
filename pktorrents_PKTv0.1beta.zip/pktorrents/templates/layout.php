<? //////////////////////////////////////
   //         Layout file             //
   //    Implamented by proxykill      //
   //////////////////////////////////////
   //                                  //
   // THERES NO NEED TO EDIT THIS FILE //
   // CHANGE THE LAYOUT VIA CONFIG.PHP //
   //////////////////////////////////////
include "../config.php";
header("Content-type: text/css");
?>
body {
	width: 95%;
	margin: auto;
	margin-bottom: 10px;
	margin-top: 10px;
}


/* Page Banner Styles */
#banner {
	padding: 1.5%;
	clear: both;
}

#banner h1 {
	margin: 0px;
	margin-top: 5px;
	padding: -1px;
	border-width: 2px;
	border-style: solid;
	border-color: #EBB80C;
	margin: auto;
	margin-bottom: 0px;
	margin-top: 0px;
}

/* Sidebar */

#sidebar {
	/* if you want this on the left change the float and clear attributes to left. 
		Also change the float and clear attributes to right on #content  */
	float:<?=$CFG->layoutmenu?>;
	clear:<?=$CFG->layoutmenu?>;
	padding: 0px;
	width: 17.5%;
	margin: 0.5px;
	margin-bottom: 0%;
	margin-top: 0%;
}

.box {
	padding: -1px;
	border-width: 1px;
	border-style: solid;
	border-color: #EBB80C;
	margin: -1px;
	margin-bottom: -1px;
	margin-top: -1px;
}


.box h3 {
	text-align: center;
	margin: 0px;       
}

.box h4 {
	text-align: center;
	margin: 0px;       
}

.box p {
	text-align: justify;
}	
.box .c {
	text-align: center;
}
/* Content */

#content {
	/* if you want this on the right change the float and clear attributes to right. 
		Also change the float and clear attributes to left on #sidebar  */
	float:<?=$CFG->layoutcontent?>;
	clear:<?=$CFG->layoutcontent?>;
	padding: 13px;
	width: 78%;
	margin-bottom: 0%;
	margin-top: 0%;
	border-right-width: 0px;
	border-right-style: solid;
	border-left-width: 0px;
	border-left-style: solid;
}
#contentfull {
	/* if you want this on the right change the float and clear attributes to right. 
		Also change the float and clear attributes to left on #sidebar  */
	float:<?=$CFG->layoutcontent?>;
	clear:<?=$CFG->layoutcontent?>;
	padding: 0px;
	width: 100%;
	margin-bottom: 1.5%;
	margin-top: 1.5%;
}


img {
	border: 0;
}




#content p {
	text-indent: 0pc;
	text-align: justify;
	padding: 2px;
	padding-right: 10px;
}

#content h3 {
	margin-top: 15px;
	margin-bottom: 5px;
}

/* Navigation Bar */
#navigation {
	clear: both;
	text-align: right;
	padding: 5px;
}

#navigationcat {
	clear: both;
	text-align: left;
	padding: 5px;
}
#navigation a, #navigation a:visited #navigationcat a, #navigationcat a:visited {
	text-decoration: none;
	padding: 2px;
	border-width: 1px;
	border-style: solid;
}

#navigation a:hover, #navigation a:visited:hover #navigationcat a:hover, #navigationcat a:visited:hover {
	border-width: 1px;
	border-style: solid;
}

/* footer styles */
#footer {
	clear: both;
	padding: 5px;
	border-top-width: 1px;
	border-top-style: solid;
	text-align: center;
}

#footer p {
	margin: 0px;
}
#footer img { border: 0px solid #000000; }

/* Other styles */
.left {
	float: left;
	clear: left;
	padding: 0px;
}

.right {
	float: right;
	clear: right;
	padding: 0px;
}


.button {
	padding: -1px;
	padding-left: -1px;
	padding-right: -1px;
	border-width: -1px;
	border-style: solid;

	cursor: pointer;
}


input {
	border-width: 1px;
	border-style: solid;
}

a, a:active {
	cursor: pointer;
}

ul {
	margin-bottom: 5px;
	margin-top: 5px;
} 

acronym {
	cursor: help;
}




.main_table {
	border-bottom: 0px solid #ccc;
	border-left: 0px solid #ccc;
}

.main_table tr:hover {
	margin: 0;
	background-color: #262626;
}

.main_table th {
	text-align: left;
	background-color: #404040;
	border-top: 0px solid #ccc;
	border-right: 0px solid #ccc;
}

.main_table td {
	border-top: 0px solid #ccc;
	border-right: 0px solid #ccc;
}

.main_table a {
	text-decoration: none;
}

.main_table a:hover {
	text-decoration: underline;
}

.main_table img {
	float: right;
	margin: 0.4em 0.2em 0 0;
}
.main_table .rd {
	color: green;
	text-align: left;
}

.main_table .zd {
	color: white;
	text-align: left;
}
.main_table .bd {
	color: blue;
	text-align: left;
}
.main_table .g {
	color: green;
	text-align: right;
}

.main_table .r {
	color: red;
	text-align: right;
}
.main_table .b {
	color: #0066FF;
	text-align: right;
}

.main_table img {
	float: left;
	margin: .4em .2em 0 .2em;
}


.main_table img.reg{
		float: right;
		margin: .4em .2em 0 0;
		}
 

.infotable {
	border: 1px solid #ccc;
	border-collapse: collapse;
}
#news {
	padding: 0 0.5em;
        margin: 1em 0 1em 0;
        background-color: #242424;
        border: 1px solid #ccc;
}

#news2 {
	padding: 0 0.5em;
        margin: 1em 0 1em 0;
        background-color: #fffff;
        border: 1px solid #EEEEEE;
}

#files {
	padding: 0 0.5em;
        margin: 2em 0 0.5em 0;
        background-color: #404040;
        border: 1px solid #ccc;
        

}
