
<table class = "main_table" id = "main" width = "100%" border="0" cellpadding="0" cellspacing="0">
<thead>
<tr>
<th width="3%"></th>
<th title="click to sort by Category">Added</th>
<th title="click to sort by name">Filename</th>
<th title="click to sort by size">Size</th>
<th title="click to sort by seeds">Seeds</th>
<th title="click to sort by downloaders">Peers</th>
</tr>
</thead>

<tbody>
<?
while ($r = db_fetch_object($qid))
{
?>
<tr>
<td>
	<a href="<?=$CFG->wwwroot?>/torrents.php?mode=details&amp;id=<?= pv($r->hash);?>"><div align="center"><img src="images/details.png" width="16" height="16" border="0"></div></a>
	</td>
<td>
		<a href="<?=$CFG->wwwroot?>/torrents.php?mode=added&amp;cat=<?= $r->added ?>"><?= pv($r->added);?></a>
	</td>
	<td><? if ($r->added == 'true'){?><a href="<?=$CFG->wwwroot?>/index.php?mode=faq"><img class="reg" alt="Tracker Requires Registration" src="<?=$CFG->imagedir;?>/reg.gif"/></a><?}?>
		<a href="<?=$CFG->wwwroot?>/torrents.php?mode=details&amp;id=<?= pv($r->hash);?>"><?= pv($r->filename);?></a>
	</td>
	<td align = "center">
		<?= makesize($r->size);?>
	</td>
	<td	<?if ($r->seeds == 0) {?>class="r"><?}else{?> class="g"><?}?><?= $r->seeds ?></td>
	<td	<?if ($r->leechers == 0) {?>class="r"><?}else{?> class="b"><?}?><?= $r->leechers ?></td>

</tr>
<?
}
?>
</tbody>
</table>

