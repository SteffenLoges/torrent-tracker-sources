Hello $var->username,

Your new login information is:

username: $var->username
password: $var->newpassword

It is highly recommended that you log in and change your password
as soon as possible. If you have any questions
or concerns, please contact us at $var->support.

