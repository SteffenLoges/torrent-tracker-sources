<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/colours.php" type="text/css" title="Default"/>
<?
$DOC_TITLE = "Torrent Files";
while ($r = db_fetch_object($qid))
{
  if ($r->anon == 'true') $r->uploader='Guest';

ob_start();
$ax=$_GET["ax"];
?>
<h2><?= pv($r->filename2) ?></h2>

<?include ("./lib/getscrape.php");

?>



<!-- SHOW FILES -->

    <? showfiles($r->hash); ?>

  <form>
<p align="center">
&nbsp;<input type=button value="Close window" onClick="javascript:window.close();"></p>
</form>
<?}?>
