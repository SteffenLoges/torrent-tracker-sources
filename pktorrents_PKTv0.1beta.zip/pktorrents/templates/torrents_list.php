<SCRIPT LANGUAGE="JavaScript">
<!-- Begin popup
function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, \'" + id + "\', \'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=260,left = 412,top = 284\');");
}
// End -->
</SCRIPT>
<table class = "main_table" id = "main" width = "100%" border="0" cellpadding="0" cellspacing="0">
<thead>
<tr>
<th width="5%" title="click to sort by Category">Category</th>
<th width="5%" title="click to sort by Category">Files</th>
<th width="30%" title="click to sort by name">Filename</th>
<th width="10%" title="click to sort by size">Size</th>
<th width="5%" title="click to sort by seeds">Seeds</th>
<th width="5%" title="click to sort by downloaders">Peers</th>
<th width="1%" title="Downloads">Downloaded</th>
<th class="" width="5%" title="Health">Health</th>
<th class="" width="5%" title="Health">Rating</th>
</tr>
</thead>

<tbody>
  <? require_once("rate.php"); ?>
<?
while ($r = db_fetch_object($qid))
{
  ?>
<tr>
<td>
<a href="torrents.php?mode=category&amp;cat=<?= $r->catid ?>"><?= pv($r->cname);?></a>
</td>

<td>
<a href="#" onClick="javascript:popUp('torrents.php?mode=files&amp;id=<?= pv($r->hash);?>')">+</a>

</td>


<td>
<? if ($r->reg == 'true'){?><a href="<?=$CFG->wwwroot?>/index.php?mode=faq"><img class="reg" alt="Tracker Requires Registration" src="<?=$CFG->imagedir;?>/reg.gif"/></a><?}?>
<a href="torrents.php?mode=details&amp;id=<?= pv($r->hash);?>"><?= pv($r->filename2);?></a>
</td>

<td align = "center">
<?= makesize($r->size);?>
</td>
<td <?if ($r->seeds == 0) {?>class="r"><?}else{?> class="g"><?}?><?= $r->seeds ?></td>
<td <?if ($r->leechers == 0) {?>class="r"><?}else{?> class="b"><?}?><?= $r->leechers ?></td>
<td <?if ($r->finished == 0){?>class="r"><?}else{?> class="b"><?}?><?= ($r->finished) ?></td>

<? if ($r->seeds >= 5){?>
<td align="right">
<img alt="5" title="Torrent currently in an excellent condition, High speeds should be expected!" src="<?=$CFG->health;?>/5.gif" width="54" height="10"/><?}?></td>

<? if ($r->seeds == 4){?>
<td align="right">
<img alt="4" title="Torrent currently in good condition, High speeds should be expected!" src="<?=$CFG->health;?>/4.gif" width="54" height="10"/><?}?></td>

<? if ($r->seeds == 3){?>
<td align="right">
<img alt="3" title="Torrent currently in ok condition, Could do with more seeds!" src="<?=$CFG->health;?>/3.gif" width="54" height="10"/><?}?></td>

<? if ($r->seeds == 2){?>
<td align="right">
<img alt="2" title="Needs more seeders!" src="<?=$CFG->health;?>/2.gif" width="54" height="10"/><?}?></td>

<? if ($r->seeds == 1){?>
<td align="right">
<img alt="1" title="Needs more seeders!" src="<?=$CFG->health;?>/1.gif" width="54" height="10"/><?}?></td>

<? if ($r->seeds == 0){?>
<td align="right">
<img alt="0" title="Torrent is Dead!" src="<?=$CFG->health;?>/01.gif" width="54" height="10"/><?}?></td>

<? if ($r->seeds == -1){?>
<td align="right">
<img alt="Error" title="Error connecting to tracker!!!" src="<?=$CFG->health;?>/00.gif" width="54" height="10"/><?}?></td>
 <td><? echo smallrate("$r->hash");?></td>
  </tr>
  
  <?
}
?>
</tbody>
</table>


