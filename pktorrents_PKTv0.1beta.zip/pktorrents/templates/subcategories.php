<table class="main_table" id="main" width = "100%" cellpadding="0" cellspacing="0"border="0">
<tr>
<th width="6%"></th>
<th>Subcategories</th>

<? if ($_SESSION['privilege'] == "admin")

{ ?>

<th><div align="center">Remove<div></th>

<? } else { } ?>

</tr>

<?
while ($r = db_fetch_object($qid))
{
?>

<tr>
<td><a href="torrents.php?mode=subcategory&amp;sub=<?= $r->id ?>"><img src="images/folder2.png" width="38" height="28" border="0"></a></td>
<td><a href="torrents.php?mode=subcategory&amp;sub=<?= $r->id ?>"><?= $r->name ?></a></td>

<? if ($_SESSION['privilege'] == "admin")
{ ?>

<td><div align="center"><a href="admin/index.php?mode=removesubcat&amp;sub=<?= $r->id ?>">Remove</a></div></td>

<? } else { } ?>

</tr>

<?
}
?>
</table>
