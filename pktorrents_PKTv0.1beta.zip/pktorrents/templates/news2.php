<div id="news2">

<?
$num = 0;
while ($r = db_fetch_object($qid))
{
$num = $num +1;
?>
<table width="100%">
<tr>
<td width="50%"><h4><?= $r->title?><br /></h4>
</td>
<td width="50%" align="right"><b><?= $r->date?></b> Posted by <a href="<?=$CFG->wwwroot?>/users/index.php?mode=userinfo&amp;username=<?= $r->author ?>"><?= $r->author ?></a>.<br />
</td>
</tr>
<tr>
	<td colspan="2"><div id="dotted"></div></td>
</tr>
</table>

<?= $r->content ?>
<br />
<table width="100%">
<tr>
	<td colspan="2"><div id="line"></div></td>
</tr>
</table>
<br /><br />
<?
}
?>
</div>
