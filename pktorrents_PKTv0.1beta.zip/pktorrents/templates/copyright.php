
<div style="margin: 10px;">
  <p align="left"><font style="font-size: 14pt;"><b>COPYRIGHT POLICY</b></font></p>
  <p align="left"><?=$CFG->webname?> provides only meta files on its web site, and
  hosts no actual file for download. We are not supportive of copyrighted 
  materials here at <?=$CFG->webname?> and only wish to provide a searching tool for
  finding legal data.<br>
  <br>
  The information services contained in this web site are provided on an &quot;as is&quot; 
  basis with no warranty. To the maximum extent of permitted by applicable law, 
  <?=$CFG->webname?> disclaims all representation and warranties, express or implied,
  with respect to such information, services, products, and materials, including 
  without limitation any implied warranties of merchantability, fitness for a 
  particular purpose and non-infrigement. In addition, <?=$CFG->webname?> does not
  warrant that the information accessible via this web site is current, 
  complete, or error-free. In no event will <?=$CFG->webname?> be liable for any
  consequential, indirect, incidental, special, or punitive damages, however 
  caused and under any theory of liability (including negligence), arising from 
  your use of this site or the provision of the information, services, products, 
  and materials contained in this site, even if <?=$CFG->webname?> has been advised
  of the possibility of such damages.</p>
  <p align="left">If your copyrighted material is linked to by <?=$CFG->webname?> and
  you wish to have it removed, you must provide us with a notice that details 
  the information listed in the following section. Please be aware that you will 
  be liable for damages (including costs and attorneys' fees) if you 
  misrepresent information listed on our site that is infringing on your 
  copyrights. We suggest that you first contact an attorney for legal assistance 
  on this matter.<br>
  <br>
  The following elements must be included in your copyright infringement claim:
  </p>
  <ul>
    <li>Provide evidence of the authorized person to act on behalf of the owner 
    of an exclusive right that is allegedly infringed. </li>
    <li>Provide sufficient contact information so that we may contact you. You 
    must also include a valid email address. </li>
    <li>Provide the link(s) of they allegedly infringed entry(s). </li>
    <li>You must identify in sufficient detail the copyrighted work claimed to 
    have been infringed. </li>
    <li>A statement that the complaining party has a good faith belief that use 
    of the material in the manner complained of is not authorized by the 
    copyright owner, its agent, or the law. </li>
    <li>A statement that the information in the notification is accurate, and 
    under penalty of perjury, that the complaining party is authorized to act on 
    behalf of the owner of an exclusive right that is allegedly infringed. </li>
  </ul>
  <p align="left"><b>Send the infringement notice to the following e-mail 
  address: <?=$CFG->support?> </b></p>
  <p align="left"><b>Please allow 1-3 business days for a response. Note that 
  e-mailing your complaint to other parties such as our Internet Service 
  Provider will not expedite your request and may result in a delayed response 
  due to the complaint not properly being filed.</b></div>

