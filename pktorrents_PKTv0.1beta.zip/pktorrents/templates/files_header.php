<?
$DOC_TITLE = "Torrent Files";
echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>";
$side=true;
$microtime = microtime();
$split = explode(" ", $microtime);
$exact = $split[0];
$secs = date("U");
$bgtm = $exact + $secs;
error_reporting(E_ALL ^ E_NOTICE);
?>
<?
/* check if file is being accessed directly */
if (eregi("header.php",$_SERVER['PHP_SELF']))
{
  Header("Location: $CFG->wwwroot");
  die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--
///////////////////////////
//CHERONE.CO.UK TORRENTS //
///////////////////////////
-->
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/layout.css" type="text/css" />
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/colours.css" type="text/css" title="Default"/>
<script src="<?=$CFG->wwwroot;?>/js/site.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?=$CFG->wwwroot;?>/css/lightbox.css" type="text/css" media="screen" />
<script src="<?=$CFG->wwwroot;?>/js/prototype.js" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/js/scriptaculous.js?load=effects" type="text/javascript"></script>


<link rel="alternate" type="application/xml" title="<? pv($DOC_TITLE) ?> RSS feed" href="<?=$CFG->wwwroot?>/rss.php"/>
<link rel="shortcut icon" href="<?=$CFG->wwwroot?>/favicon.ico" />
<title><? pv($DOC_TITLE) ?></title>
<script src="<?=$CFG->wwwroot;?>/sorttable.js" type="text/javascript"></script>
<script type="text/javascript" src="<?=$CFG->wwwroot;?>/hide.js"></script>
</head>
<body bgcolor="#262626">
