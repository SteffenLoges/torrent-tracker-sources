<?
/* check if file is being accessed directly */
if (eregi("footer.php",$_SERVER['PHP_SELF']))
{
Header("Location: $CFG->wwwroot");
die();
}
?>

<?

global $time_begin;
global $time_end;
$time_end = get_micro_time();

echo "</td></tr></table>";
echo "<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" width=\"950\" height=\"\" style=\"border-collapse:collapse;\">
<tr><td width=\"100%\" height=\"100%\" style=\"border-width:0px; border-color:rgb(204,204,204); border-style:solid;\">
<p align=\"right\"><a href=\"$CFG->wwwroot/rss.php\" target=\"_blank\"><img alt=\"Feed\" src=\"$CFG->imagedir/feed.png\"/></a></p>";
?>
<p>
<CENTER>You are visitor number: <B>
<?php
$fp=fopen("count.thisisprivate","r");
$count=fgets($fp,1024);
fclose($fp);
$fw=fopen("count.thisisprivate","w");
$cnew=$count+1;
$countnew=fputs($fw,$count+1);
echo "$cnew";
fclose($fw);
?> </B>	to <a href="<?=$CFG->wwwroot?>"><?=$CFG->wwwroot?></a>
<?
echo "<b><div>Rendertime: ".round($time_end-$time_begin, 3)."</p></b>";
echo "<p><div><a href=\"http://www.spreadfirefox.com\" target=\"_blank\"><img alt=\"Get FireFox\" src=\"$CFG->imagedir/logo-firefox.png\"/></a> </p>";
echo "<p>Copyright � 2007 $CFG->webname All rights reserved. <a href=\"http://ccgi.proxykill.force9.co.uk/downloads/\">
SourceCode</a></p></div></td></tr></table></body></html>";
?>

