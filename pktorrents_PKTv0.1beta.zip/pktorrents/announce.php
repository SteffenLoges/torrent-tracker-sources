<?php
/*
SBT1 - SqrtBoy's Bittorrent Tracker v1 (GPL)
Based on FBT2 from Flippy
Website: http://www.phpsoft.org
Email: sqrtboy@phpsoft.org
*/

function error($txt,$browser=false)
{
	if ($browser == false)
		exit('d14:failure reason' . strlen($txt) . ':' . $txt . 'e');
	else exit('<br><br><center><b><font size=4></font></b><meta http-equiv="refresh" content="3;url=./index.php">');
}


if (ereg("^Mozilla\\/", $agent) || ereg("^Opera\\/", $agent) || ereg("^Links ", $agent) || ereg("^Lynx\\/", $agent))
	error("You are being redirect to main site, please wait !",true); 

if ($_GET['compact'] != 1)
{
	error('This tracker requires compact announce. Please update your client to the latest version-'.$_SERVER["QUERY_STRING"]);
}

if (get_magic_quotes_gpc())
{
	$_GET['info_hash'] = stripslashes($_GET['info_hash']);
}


if (strlen($_GET['info_hash']) != 20)
{
	error('Invalid info_hash submitted value');
}


$_GET['info_hash'] = bin2hex($_GET['info_hash']);


$peer_ip = pack('Nn', ip2long($_SERVER['REMOTE_ADDR']), $_GET['port']);
$time = time() % 7680 / 60;
$cur_time = $time;

if ($_GET['left'] == 0)
{
	$time += 128;
}


$time = pack('C', $time);
$peers = array();
$updated = false;

if (!file_exists('tracked/'.$_GET['info_hash']))
{
	if (file_exists('bans'))
	{
		$handle = fopen('bans', 'r');
		flock($handle, LOCK_EX);
		$bans = fread($handle, filesize('bans'));
		flock($handle, LOCK_UN);
		fclose($handle);
		
		if (strpos($bans, $_GET['info_hash']) === true)
		{
			error('This torrent is not authorized on this tracker.');
		}
	}
	
	touch('tracked/'.$_GET['info_hash']);
	
	$handle = fopen('tracked/'.$_GET['info_hash'], 'wb');
	flock($handle, LOCK_EX);
	$peer_num = 0;
}
else
{
	$handle = fopen('tracked/'.$_GET['info_hash'], 'rb+');
	flock($handle, LOCK_EX);
	$length = filesize('tracked/'.$_GET['info_hash']);
	
	if ($length)
	{
		$peer_num = $length / 7;
		$data = fread($handle, $length);
		

	
		for ($i=0; $i<$peer_num; $i++)
		{

			
			
			if ($peer_ip == substr($data, $i * 7 + 1, 6))
			{
				$updated = true;
				
				if ($_GET['event'] == 'stopped')
				{
					$peer_num--;
				}
				else
				{
					$peers[] = $time.$peer_ip;
				}
			}
			else
			{
				$t_peer_seed = implode('', unpack('C', substr($data, $i * 7, 1)));	
					
				if ($t_peer_seed >= 128)
				{
					$t_time = $t_peer_seed - 128;
				}
				else
				{
					$t_time = $t_peer_seed;
				}
				

				$peers[] = substr($data, $i * 7, 7);

			}
		}
	}
}

if ($updated == false)
{
	$peers[] = $time.$peer_ip;
	$peer_num++;
}

rewind($handle);
ftruncate($handle, 0);
fwrite($handle, implode('', $peers), $peer_num * 7);
flock($handle, LOCK_UN);
fclose($handle);

ob_start("gz_handler");

header('Content-Type: text/plain');
header('Pragma: no-cache');
    	
//echo 'd8:intervali1800e5:peers', ($peer_num * 6), ':';

if ($peer_num <= 50)
	echo 'd8:intervali1800e5:peers', ($peer_num * 6), ':';
else echo 'd8:intervali1800e5:peers300:';

if ($_GET['event'] != 'stopped' or $_GET['numwant'] !== 0)
{
	if ($peer_num > 50)
	{
		$keys = array_rand($peers, 50);
		
		foreach($keys as $key)
		{
			echo substr($peers[$key], 1, 6);
		}
	}
	else
	{
		for($i=0; $i<$peer_num; $i++)
		{
			echo substr($peers[$i], 1, 6);
		}
	}
}

echo 'e';



?>
