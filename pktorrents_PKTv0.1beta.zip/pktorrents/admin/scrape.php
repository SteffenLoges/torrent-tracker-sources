<?

// Escape url (for scraping)
function escape_url($url) 
{
$ret = '';
for($i = 0; $i < strlen($url); $i+=2)
$ret .= '%'.$url[$i].$url[$i + 1];
return $ret;
}


function torrent_scrape_url($scrape, $hash) 
{
require_once 'BDecode.php';
$fp = file_get_contents($scrape.'?info_hash='.escape_url($hash));
$ret = array();
if(!$fp) 
{
$ret['seeds'] = -1;
$ret['peers'] = -1;
}
else 
{
$stats = BDecode($fp);
$binhash = addslashes(pack("H*", $hash));

$ret['seeds'] = $stats['files'][$binhash]['complete'];
$ret['peers'] = $stats['files'][$binhash]['incomplete'];
}
return $ret;
}

?>