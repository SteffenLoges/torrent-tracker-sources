<?
include("../config.php");

require_login();
//require_priv("admin");
if ($_SESSION['privilege'] != "admin")
{
echo "You do not have permission to access this file";
die;
}
 error_reporting(1);
$uri = $_SERVER["PHP_SELF"];
$date = date("Ymd");
$realdate = date("Y.m.d");

preg_match ("/^.*?@(.*)$/",$_SERVER["SERVER_ADMIN"],$domain);
$curdomain = $domain;
@chmod("../ads/ad_left.txt", 0777);
@chmod("../ads/ad_top.txt", 0777);
@chmod("../ads/ad_torrent.txt", 0777);
@chmod("../config.php", 0777);
$ads_left = array ("Edit Your Left Side Ads","../ads/ad_left.txt","Seperate ads with ~");
$ads_top = array ("Edit Your Top Main Ads","../ads/ad_top.txt","Seperate ads with ~");
$ads_torrents = array ("Edit Your Torrent Details Ads","../ads/ad_torrent.txt","Seperate ads with ~");
$edit_config = array ("Edit PK-Torrents Config","../config.php","Be carefull when editing this file as it may mess up your site!!!");


@$load=$_GET['load'];
@$mesage = ${$load}[0];
@$file = ${$load}[1];
@$extra = ${$load}[2];

if($_POST['action'] == "Write to file"){
        $feed=stripslashes($_POST['feed']);
        $mesg = "Written modifications to $file";
        $fhw = fopen("$file", "wb");
        $ok = fwrite ($fhw,"$feed");
        fclose ($fhw);
}

function show_size($fname){
        $size = filesize($fname)+1 or die ("could not open $fname");
        if ($size >= 1073741824){ $size = round($size / 1073741824 * 100) / 100 . ' Gb'; }
        elseif ($size >= 1048576){ $size = round($size / 1048576 * 100) / 100 . ' Mb'; }
        elseif ($size >= 1024){        $size = round($size / 1024 * 100) / 100 . ' Kb'; }
        elseif ($size > 0){ $size = $size . ' b'; }
        else{ $size = 'NA'; }
        echo $size;
}

?>

<html>
<title>PK-Torrents Editor : <?php echo $mesage; ?></title>

<center>
<p><font size=6 color="#EBB80C"><?php echo $mesage; ?></font></p>
<p><font size=4 color="red"><B><?echo $extra;?></B></font> </p>
<font color=#EBB80C><?php if (isset($mesg)){echo $mesg;}else{echo "This allows for remote editing.";} ?></font><br>
<font color=#FFFFFF>You are editing : <b><?php echo $file; ?></b>&nbsp;<?php show_size($file); ?>&nbsp;<br></font>
<?php
if (filesize($file) > 1048576){
        die("File size is bigger than 1 megabyte , refusing to load it ");
}
?>
<form name="form" method="post" action="<?php echo "{$uri}?load={$load}"; ?>">
<textarea class=input name="feed" rows="31" wrap="OFF" style="width:101%"><?php echo file_get_contents($file); ?></textarea>
<br><input class=button type=submit name=action value="Refresh"> <input class=button type=submit name=action value="Write to file">
</form>



