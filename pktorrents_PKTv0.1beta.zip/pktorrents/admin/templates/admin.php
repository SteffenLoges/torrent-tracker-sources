
<div class=""><br/>
Myanmartorrents.com is a part of RedMyanmar group. This site is dedicated for Myanmar Torrents. You will be able to download Music, Movies, Music Videos, Pictures, and Others.
<br><br>
RM Group is established since 2003 with RedMyanmar.Net Web Portal. We had 8000+ forum posts and 1200+ members back in 2004 - 2005. Unfortunately, because of some reasons can not be told, RedMyanmar.NET has been shut down and until now. However we are trying to rebuild RM.net. Now we have GoldeGeeks.Com, PoemsCorner.Com, and MyanmarTorrents.Com. RM Group would like to thanks to everyone who participated in starting for RM Group.
<br><br>
Myanmar Torrents Team:
<br><br>
			DiEg0		- Singapore<br>
			Scooby	- Singapore<br>
			Andy		- U.S.<br>
			Sai Lone	- U.S.

</div>

