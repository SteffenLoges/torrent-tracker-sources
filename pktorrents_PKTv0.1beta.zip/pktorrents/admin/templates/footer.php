<?
/* check if file is being accessed directly */
if (eregi("footer.php",$_SERVER['PHP_SELF']))
{
Header("Location: $CFG->wwwroot");
die();
}
?>
<?

global $time_begin;
global $time_end;
$time_end = get_micro_time();

echo "</td></tr></table>";
echo "<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" width=\"950\" height=\"\" style=\"border-collapse:collapse;\">
<tr><td width=\"100%\" height=\"100%\" style=\"border-width:0px; border-color:rgb(204,204,204); border-style:solid;\">
<p align=\"right\"><a href=\"$CFG->wwwroot/rss.php\" target=\"_blank\"><img alt=\"Feed\" src=\"$CFG->imagedir/feed.png\"/></a></p>";
echo "<p><div id=\"footer\"><a href=\"http://www.spreadfirefox.com\" target=\"_blank\"><img alt=\"Get FireFox\" src=\"$CFG->imagedir/logo-firefox.png\"/></a> </p>";
echo "<p>Copyright � 2007 $CFG->webname All rights reserved. <a href=\"http://tracker.cherone.co.uk/nixtor/index.php?mode=source\">
SourceCode</a></p></div></td></tr></table></body></html>";
?>

