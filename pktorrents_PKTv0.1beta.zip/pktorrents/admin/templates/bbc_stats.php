<IFRAME
SRC="bbclone/index.php"
NAME="Site stats"
WIDTH=82% HEIGHT=935
SCROLLING=AUTO
FRAMEBORDER=0>

</IFRAME>

