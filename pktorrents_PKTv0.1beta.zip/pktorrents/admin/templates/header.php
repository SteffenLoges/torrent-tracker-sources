<?
if (extension_loaded('zlib')) {
@ob_start("ob_gzhandler");
}
echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>";

    $microtime = microtime();
    $split = explode(" ", $microtime);
    $exact = $split[0];
    $secs = date("U");
    $bgtm = $exact + $secs;
?>
<?
/* check if file is being accessed directly */
if (eregi("header.php",$_SERVER['PHP_SELF']))
{
Header("Location: $CFG->wwwroot");
die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--
///////////////////////////////////
//PK-TORRENTS Version:<?=$CFG->version?>//
///////////////////////////////////
-->
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/layout.php" type="text/css" />
<link rel="stylesheet" href="<?=$CFG->wwwroot?>/templates/colours.php" type="text/css" title="Default"/>
<link rel="stylesheet" href="<?=$CFG->wwwroot;?>/css/lightbox.css" type="text/css" media="screen" />
<link rel="alternate" type="application/xml" title="<? pv($DOC_TITLE) ?> RSS feed" href="<?=$CFG->wwwroot?>/rss.php"/>
<link rel="shortcut icon" href="<?=$CFG->wwwroot?>/favicon.ico" />
<script src="<?=$CFG->wwwroot;?>/js/site.js" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/js/prototype.js" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/js/scriptaculous.js?load=effects" type="text/javascript"></script>
<script src="<?=$CFG->wwwroot;?>/sorttable.js" type="text/javascript"></script>
<script type="text/javascript" src="<?=$CFG->wwwroot;?>/hide.js"></script>
<script type="text/javascript" src="<?=$CFG->wwwroot;?>/js/preload.js"></script>
<title><? pv($DOC_TITLE) ?></title>
</head>
<body bgcolor="<?=$CFG->bgcolour?>">
<table align="center" border="1" cellpadding="0" cellspacing="0" width="950" height="" style="border-collapse:collapse;" bgcolor="<?=$CFG->maincolour?>">
<tr>
<td width="100%" height="100%" style="border-width:1px; border-style:solid;">
<br>
    <? if (is_logged_in()) { ?>
    <div align="right" valign="top">
	    <? if ($_SESSION['privilege'] == "admin") { ?>
	    <a href="<?=$CFG->wwwroot?>/admin/index.php" OnMouseOut="na_restore_img_src('image11', 'document')"
		OnMouseOver="na_change_img_src('image11', 'document', '<?=$CFG->imagedir?>/adminmode2.gif', true)">
		<img src="<?=$CFG->imagedir?>/adminmode.gif" width="154" height="20" border="0" name="image11"></a>

	    <a href="<?=$CFG->wwwroot?>/update_stats.php" OnMouseOut="na_restore_img_src('image12', 'document')"
		OnMouseOver="na_change_img_src('image12', 'document', '<?=$CFG->imagedir?>/updatestats2.gif', true)">
		<img src="<?=$CFG->imagedir?>/updatestats.gif" width="154" height="20" border="0" name="image12"></a>

	    <? } ?>
	    <a href="<?=$CFG->wwwroot?>/users/index.php" OnMouseOut="na_restore_img_src('image7', 'document')"
		OnMouseOver="na_change_img_src('image7', 'document', '<?=$CFG->imagedir?>/userhome2.gif', true)">
		<img src="<?=$CFG->imagedir?>/userhome.gif" width="154" height="20" border="0" name="image7"></a>

	    <a href="<?=$CFG->forumroot?>/profile.php?mode=editprofile" OnMouseOut="na_restore_img_src('image8', 'document')"
		OnMouseOver="na_change_img_src('image8', 'document', '<?=$CFG->imagedir?>/changeprofile2.gif', true)">
		<img src="<?=$CFG->imagedir?>/changeprofile.gif" width="154" height="20" border="0" name="image8"></a>

		<a href="<?=$CFG->wwwroot?>/users/index.php" OnMouseOut="na_restore_img_src('image9', 'document')"
		OnMouseOver="na_change_img_src('image9', 'document', '<?=$CFG->imagedir?>/mytorrents2.gif', true)">
		<img src="<?=$CFG->imagedir?>/mytorrents.gif" width="154" height="20" border="0" name="image9"></a>

		<a href="<?=$CFG->wwwroot?>/logout.php" OnMouseOut="na_restore_img_src('image10', 'document')"
		OnMouseOver="na_change_img_src('image10', 'document', '<?=$CFG->imagedir?>/logout2.gif', true)">
		<img src="<?=$CFG->imagedir?>/logout.gif" width="154" height="20" border="0" name="image10"></a>
	<br>
		<br>
		</div>


    <? } else { ?>
    <div align="right" valign="top">
    <a href="<?=$CFG->wwwroot?>/login.php" OnMouseOut="na_restore_img_src('image13', 'document')"
	OnMouseOver="na_change_img_src('image13', 'document', '<?=$CFG->imagedir?>/login2.gif', true)">
	<img src="<?=$CFG->imagedir?>/login.gif" width="154" height="20" border="0" name="image13"></a>

    <a href="<?=$CFG->forumroot?>/profile.php?mode=register" OnMouseOut="na_restore_img_src('image15', 'document')"
	OnMouseOver="na_change_img_src('image15', 'document', '<?=$CFG->imagedir?>/register2.gif', true)">
	<img src="<?=$CFG->imagedir?>/register.gif" width="154" height="20" border="0" name="image15"></a>
	<br>
	<br>
    </div>

<? } ?>


<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" height="60" background="<?=$CFG->imagedir?>/bannerbg.gif">
<tr><td width="50%" height="60"><div></div></td>
<td width="50%" height="60" align="right">

	<div class="right">
        <form action="<?=$CFG->wwwroot?>/torrents.php" method="post" enctype="multipart/form-data">
	<div><font color="white">Search Torrents: <input type="text" name="name" id="search" /></font>
	<input type="hidden" name="mode" value="search"/>
	<input class="button" type="submit" value="Go!" />
        </div>
        </form>
	</div>
</td>
</tr>
</table>
<div id="sidebar">
		<div class="box" id="button">
			<h4>Admin Tools</h4>
			<ul>
				<li> <a href="<?=$CFG->wwwroot?>/admin/index.php">Admin Home</a></li>
				<li> <a href="<?=$CFG->wwwroot?>/admin/index.php?mode=editconfig">Edit Config</a></li>
				<li> <a href="<?=$CFG->wwwroot?>/admin/index.php?mode=shell">System Shell</a></li>
                                <li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=listtorrents">List Latest Torrents</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=list_cat">List All Categories</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=add_cat">Add Category</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=add_subcat">Add Subcategory</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=dead">Dead Torrents</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=users">List Users</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=comments">Manage Comments</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=ban">Manage Bans</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=hack">Hack Log</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=version">Version</a></li>
			</ul>
		</div>
		<div class="box" id="button">
			<h4>Crawlers</h4>
			<ul>
			        <li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=spider">Ibitzy</a></li>


			</ul>
		</div>
		<div class="box" id="button">
			<h4>Visitor Stats</h4>
			<ul>
			        <li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=advstat">BBClone</a></li>


			</ul>
		</div>
			<div class="box" id="button">
			<h4>Edit Ads</h4>
			<ul>
			        <li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=ads_left">Left Side</a></li>
			        <li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=ads_top">Main Top</a></li>
			        <li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=ads_torrents">Details Page</a></li>


			</ul>
		</div>
		<div class="box" id="button">
			<h4>News</h4>
			<ul>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=insert_news">Add News</a></li>
				<li><a href="<?=$CFG->wwwroot?>/admin/index.php?mode=news">Edit News</a></li>

			</ul>
		</div>

		<div class="box" id="button">
			<h4>Main Menu</h4>
			<ul>
                                <li><a href="<?=$CFG->wwwroot?>/index.php">Home</a></li>
				<li><a href="<?=$CFG->wwwroot?>/index.php?mode=directory">Directory</a></li>
				<li><a href="<?=$CFG->wwwroot?>/torrents.php?mode=upload">Upload Torrent</a></li>
				<li><a href="<?=$CFG->forumroot?>">Forum</a></li>
				<li><a href="<?=$CFG->wwwroot?>/index.php?mode=stats">Torrents Stats</a></li>
				<li><a href="<?=$CFG->wwwroot?>/index.php?mode=news">News</a></li>
				<li><a href="<?=$CFG->wwwroot?>/index.php?mode=faq">FAQ</a></li>
				<li><a href="<?=$CFG->wwwroot?>/index.php?mode=about">Copyright</a></li>
				<li><a href="http://proxykill.9999mb.com/phpBB2/">Development Forum</a></li>
                        </ul>
		</div>

</div>
