<IFRAME
SRC="edit.php?load=ads_torrents"
NAME="Site stats"
WIDTH=82% HEIGHT=690
SCROLLING=AUTO
FRAMEBORDER=0>

</IFRAME>

