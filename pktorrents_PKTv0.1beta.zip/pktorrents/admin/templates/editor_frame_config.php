<IFRAME
SRC="edit.php?load=edit_config"
NAME="Site stats"
WIDTH=82% HEIGHT=800
SCROLLING=AUTO
FRAMEBORDER=0>
</IFRAME>

