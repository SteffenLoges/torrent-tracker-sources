<p align="center"><font size="7">PK-Torrents</font></p>
<p align="center">Version: PKT-0.3beta</p>
<p align="center"><a target="_blank" href="http://proxykill.9999mb.com/phpBB2/">
Check for update</a></p>
<br>
<p align="center"><strong>If you find any bugs let me know on <a href="http://filesoup.co.uk/forum/proxykill-m422304.html">filesoup.co.uk</a></strong></p>

