<?php
if (is_readable("show_global.php")) include_once("show_global.php");
?>