<?php
$access =
  array(
    "time" =>
    array(
      "reset" => 1174048755, "last" => 1174337775, 
      "hour" =>
      array(
        0, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 14, 11, 0, 0, 0, 9, 3, 5, 43, 49, 34, 1, 1
      ),
      "wday" =>
      array(
        56, 149, 0, 0, 0, 73, 11
      ),
      "day" =>
      array(
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 11, 56, 149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ),
      "month" =>
      array(
        0, 0, 289, 0, 0, 0, 0, 0, 0, 0, 0, 0
      )
    ),
    "page" =>
    array(
      "Pktorrents -&gt; Test" =>
      array(
        "count" => 1, "uri" => "/pktorrents/test.php"
      ),
      "Pktorrents" =>
      array(
        "count" => 154, "uri" => "/pktorrents/"
      ),
      "Pktorrents -&gt; Torrents" =>
      array(
        "count" => 112, "uri" => "/pktorrents/torrents.php"
      ),
      "Pktorrents -&gt; Login" =>
      array(
        "count" => 20, "uri" => "/pktorrents/login.php"
      ),
      "Pktorrents -&gt; Users" =>
      array(
        "count" => 1, "uri" => "/pktorrents/users/"
      ),
      "Pktorrents -&gt; Update Stats" =>
      array(
        "count" => 1, "uri" => "/pktorrents/update_stats.php"
      )
    ),
    "stat" =>
    array(
      "totalvisits" => 289, "totalcount" => 15, 
      "ext" =>
      array(
        "unknown" => 1, "numeric" => 13, "uk" => 1
      ),
      "browser" =>
      array(
        "firefox" => 15
      ),
      "os" =>
      array(
        "windowsnt" => 14, "windowsxp" => 1
      )
    ),
    "referer" =>
    array(
      "not_specified" => 14, "filesoup.co.uk/forum/" => 1
    ),
    "host" =>
    array(
      "proxykill-pc" => 1, "127.0.0.&nbsp;-" => 13, "81.158.109.&nbsp;-" => 1
    ),
    "bugs" =>
    array(
      "ref_fix" => 1, "title_fix" => 1
    )
  );
?>