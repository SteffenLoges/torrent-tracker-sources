<?php
$last =
  array(
    "pages" =>
    array(
      "Pktorrents -&gt; Test", "Pktorrents", "Pktorrents -&gt; Torrents", "Pktorrents -&gt; Login", "Pktorrents -&gt; Users", "Pktorrents -&gt; Update Stats"
    ),
    "traffic" =>
    array(
      array(
        "time" => 1174052061, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "Proxykill-PC", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 14, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "unknown", "id" => 1, 
        "views" =>
        array(
          "1174048755|0|1", "1174048869|1|3", "1174048888|2|1", "1174048896|1|4", "1174049173|2|1", "1174049574|3|1", "1174049697|1|2", "1174052061|2|1"
        ),
        "search" => "-", "off" => 6
      ),
      array(
        "time" => 1174081248, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 29, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 2, 
        "views" =>
        array(
          "1174076585|1|1", "1174076596|2|1", "1174076671|1|1", "1174076675|2|5", "1174076867|3|2", "1174076907|1|17", "1174081232|3|1", "1174081248|2|1"
        ),
        "search" => "-", "off" => 21
      ),
      array(
        "time" => 1174083662, "prx_ip" => "unknown", "ip" => "81.158.109.167", "dns" => "81.158.109.167", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "http://filesoup.co.uk/forum/index.php?act=Msg&amp;CODE=03&amp;VID=in&amp;MSID=113107", "page" => 2, "visits" => 2, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsxp", "ext" => "uk", "id" => 3, 
        "views" =>
        array(
          "1174083611|1|1", "1174083662|2|1"
        ),
        "search" => "-", "off" => 0
      ),
      array(
        "time" => 1174087067, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 19, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 4, 
        "views" =>
        array(
          "1174084533|1|10", "1174086041|2|6", "1174086498|1|1", "1174086502|2|2"
        ),
        "search" => "-", "off" => 15
      ),
      array(
        "time" => 1174092270, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 17, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 5, 
        "views" =>
        array(
          "1174089097|1|1", "1174089106|2|2", "1174089196|1|5", "1174089471|2|1", "1174090718|1|2", "1174091967|2|1", "1174092018|1|1", "1174092025|2|1", "1174092235|1|1", "1174092240|2|2"
        ),
        "search" => "-", "off" => 7
      ),
      array(
        "time" => 1174158474, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 1, "visits" => 1, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 6, 
        "views" =>
        array(
          "1174158474|1|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1174163874, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 1, "visits" => 1, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 7, 
        "views" =>
        array(
          "1174163874|1|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1174168724, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 1, "visits" => 1, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 8, 
        "views" =>
        array(
          "1174168724|1|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1174255349, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 1, "visits" => 55, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 9, 
        "views" =>
        array(
          "1174249140|1|1", "1174249191|2|17", "1174250475|1|2", "1174251617|3|1", "1174251631|1|22", "1174253531|2|9", "1174254592|1|3"
        ),
        "search" => "-", "off" => 48
      ),
      array(
        "time" => 1174261240, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 1, "visits" => 1, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 10, 
        "views" =>
        array(
          "1174261240|1|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1174271784, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 15, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 11, 
        "views" =>
        array(
          "1174270431|1|2", "1174270519|3|2", "1174270550|1|1", "1174270558|2|1", "1174270563|1|3", "1174270943|2|1", "1174270961|1|4", "1174271784|2|1"
        ),
        "search" => "-", "off" => 7
      ),
      array(
        "time" => 1174309037, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 25, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 12, 
        "views" =>
        array(
          "1174302521|1|1", "1174304071|3|2", "1174304104|1|8", "1174305378|2|3", "1174306004|1|4", "1174307784|2|1", "1174308874|1|1", "1174308900|2|2", "1174309001|1|2", "1174309037|2|1"
        ),
        "search" => "-", "off" => 15
      ),
      array(
        "time" => 1174322956, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 4, "visits" => 9, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 13, 
        "views" =>
        array(
          "1174321323|1|1", "1174321339|3|1", "1174321351|1|3", "1174322939|2|3", "1174322956|4|1"
        ),
        "search" => "-", "off" => 4
      ),
      array(
        "time" => 1174327295, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 1, "visits" => 4, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 14, 
        "views" =>
        array(
          "1174325301|1|2", "1174326462|2|1", "1174327295|1|1"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1174337775, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "127.0.0.1", "agent" => "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.8.1.2) Gecko/20070219 Firefox/2.0.0.2", "referer" => "unknown", "page" => 2, "visits" => 96, "browser" => "firefox", "browser_note" => "2.0.0.2", "os" => "windowsnt", "ext" => "numeric", "id" => 15, 
        "views" =>
        array(
          "1174329100|1|11", "1174332851|2|2", "1174332940|1|1", "1174332956|2|1", "1174333483|1|1", "1174333489|2|2", "1174333628|1|1", "1174333636|2|2", "1174333722|1|1", "1174333726|2|1", "1174333737|3|2", "1174333758|1|1", "1174333763|2|4", "1174333921|1|1", "1174333929|2|1", "1174334066|1|1", "1174334071|2|1", "1174334284|1|1", "1174334290|2|1", "1174334300|1|2", "1174334307|2|2", "1174334333|1|5", "1174334371|2|2", "1174334432|1|1", "1174334439|3|1", "1174334451|1|2", "1174334613|5|1", "1174334740|2|1", "1174334954|1|1", "1174334963|2|1", "1174335243|1|2", "1174335798|2|4", "1174336135|1|1", "1174336142|2|1", "1174336259|1|1", "1174336268|2|2", "1174336367|1|1", "1174336373|2|4", "1174336731|1|1", "1174336767|2|8", "1174337174|1|1", "1174337179|2|2", "1174337221|3|2", "1174337450|2|1", "1174337452|3|1", "1174337459|1|1", "1174337640|3|1", "1174337650|2|2", "1174337709|3|2", "1174337748|1|1", "1174337758|3|1", "1174337775|2|1"
        ),
        "search" => "-", "off" => 44
      )
    )
  );
?>