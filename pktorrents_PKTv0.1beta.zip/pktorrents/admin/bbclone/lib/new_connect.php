<?php
/* This file is part of BBClone (The PHP web counter on steroids)
 *
 * $Header: /cvs/bbclone/lib/new_connect.php,v 1.22 2004/11/21 14:06:09 olliver Exp $
 *
 * Copyright (C) 2001-2004, the BBClone Team (see file doc/authors.txt
 * distributed with this library)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * See doc/copying.txt for details
 */

// fallback in case something can't be resolved
function bbc_legacy_ext($ext) {
  $gen_ext = array(
    "ac", "aero", "ag", "arpa", "as", "biz", "cc", "cd", "com", "coop", "cx", "edu", "eu", "gb", "gov", "gs", "info",
    "int", "mil", "ms", "museum", "name", "net", "nu", "org", "pro", "sc", "st", "su", "tk", "to", "tv", "vu", "ws"
  );

  if (preg_match(":^[0-9]+$:", $ext)) return "numeric";
  elseif (!in_array($ext, $gen_ext)) return "unknown";
  else return $ext;
}

function bbc_get_extension($host, $addr) {
  global $BBC_IP2EXT_PATH;

  // hosts with reliable country extension don't need to be looked up
  $cnt_ext = array(
    "ad", "ae", "af", "ai", "al", "am", "an", "ao", "aq", "ar", "at", "au", "aw", "az", "ba", "bb", "bd", "be", "bf",
    "bg", "bh", "bi", "bj", "bm", "bn", "bo", "br", "bs", "bt", "bv", "bw", "by", "bz", "ca", "cf", "cg", "ch", "ci",
    "ck", "cl", "cm", "cn", "co", "cr", "cs", "cu", "cv", "cy", "cz", "de", "dj", "dk", "dm", "do", "dz", "ec", "ee",
    "eg", "eh", "er", "es", "et", "fi", "fj", "fk", "fm", "fo", "fr", "ga", "gd", "ge", "gf", "gg", "gh", "gi", "gl",
    "gm", "gn", "gp", "gq", "gr", "gt", "gu", "gw", "gy", "hk", "hm", "hn", "hr", "ht", "hu", "id", "ie", "il", "im",
    "in", "io", "iq", "ir", "is", "it", "je", "jm", "jo", "jp", "ke", "kg", "kh", "ki", "km", "kn", "kp", "kr", "kw",
    "ky", "kz", "la", "lb", "lc", "li", "lk", "lr", "ls", "lt", "lu", "lv", "ly", "ma", "mc", "md", "mg", "mh", "mk",
    "ml", "mm", "mn", "mo", "mp", "mq", "mr", "mt", "mu", "mv", "mw", "mx", "my", "mz", "na", "nc", "ne", "nf", "ng",
    "ni", "nl", "no", "np", "nr", "nz", "om", "pa", "pe", "pf", "pg", "ph", "pk", "pl", "pm", "pn", "pr", "ps", "pt",
    "pw", "py", "qa", "re", "ro", "ru", "rw", "sa", "sb", "sd", "se", "sg", "sh", "si", "sj", "sk", "sl", "sm", "sn",
    "so", "sr", "sv", "sy", "sz", "tc", "td", "tf", "tg", "th", "tj", "tl", "tm", "tn", "tp", "tr", "tt", "tw", "tz",
    "ua", "ug", "uk", "um", "us", "uy", "uz", "va", "vc", "ve", "vg", "vi", "vn", "wf", "ye", "yt", "yu", "za", "zm",
    "zr", "zw"
  );

  $file = $BBC_IP2EXT_PATH.(substr($addr, 0, strpos($addr, ".")).".inc");
  $ext = strtolower(substr($host, (strrpos($host, ".") + 1)));

  // Don't look up if there's already a country extension
  if (in_array($ext, $cnt_ext)) return $ext;
  if (!is_readable($file)) return bbc_legacy_ext($ext);

  $long = ip2long($addr);
  $long = ($long < 0) ? sprintf("%u", $long) : $long;
  $fp = fopen($file, "rb");

  while (($range = fgetcsv($fp, 32, "|")) !== false) {
    if (($long >= $range[1]) && ($long <= ($range[1] + $range[2] - 1))) {
      // don't hose our stats if the database returns an unexpected extension
      $db_ext = (in_array($range[0], $cnt_ext) ? $range[0] : bbc_legacy_ext($ext));
      break;
    }
  }
  fclose($fp);
  return (!empty($db_ext) ? $db_ext : bbc_legacy_ext($ext));
}

function bbc_update_connect($connect) {
  global $BBC_LIB_PATH;

  // Sanity check has already been made in mark_page.php
  foreach (array("browser", "os", "robot") as $i) require($BBC_LIB_PATH.$i.".php");

  $connect['visits'] = 1;

  // Detecting robots, browsers and os
  foreach (array("robot", "browser", "os") as $rule) {
    reset($$rule);

    while (list(${$rule."_name"}, ${$rule."_elem"}) = each($$rule)) {
      reset(${$rule."_elem"}['rule']);

      while (list($pattern, $note) = each(${$rule."_elem"}['rule'])) {
        // eregi() is intentionally used because some php installations don't
        // know the "i" switch of preg_match() and would generate phony compile
        // error messages
        if (!eregi($pattern, $connect['agent'], $regs)) continue;

        $connect[$rule] = ${$rule."_name"};

        if (preg_match(":\\\\[0-9]{1}:" ,$note)) {
          $str = preg_replace(":\\\\([0-9]{1}):", "\$regs[\\1]", $note);

          eval("\$str = \"$str\";");

          $connect[$rule."_note"] = $str;
        }
        break 2;
      }
    }
    if (!empty($connect['robot'])) break;
  }
  return $connect;
}

function bbc_update_access($connect) {
  global $access;

  // Assign an identification number to the new connection
  $connect['id'] = isset($access['stat']['totalcount']) ? ($access['stat']['totalcount'] + 1) : 1;

  // Recording the detected extension in the global statistics
  $access['stat']['ext'][$connect['ext']] = !isset($access['stat']['ext'][$connect['ext']]) ? 1 :
                                            ++$access['stat']['ext'][$connect['ext']];

  foreach (array("robot", "browser", "os") as $type) {
    if (($type == "robot") && (empty($connect[$type]))) continue;

    if (isset($access['stat'][$type][$connect[$type]])) $access['stat'][$type][$connect[$type]]++;
    else $access['stat'][$type][$connect[$type]] = 1;

    if (($type == "robot") && (!empty($connect[$type]))) break;
  }
  return $connect;
}
?>