<?php

//-----------------------------------------
// Cache file
//-----------------------------------------

$cache['site']['mininova'] = 1174318992;
$cache['site']['torrentspy'] = 1839;
$cache['site']['piratebay'] = 1839;
$cache['site']['torrentportal'] = 1839;
$cache['site']['meganova'] = 1839;
$cache['unprocessed'] = 594;
$cache['locked'] = 'unlocked';
$cache['lock_time'] = 1174337840;
?>