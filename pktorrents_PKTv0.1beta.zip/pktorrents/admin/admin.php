<head>
<title>Admin Home</title>
</head>
<body>
<p></p>

<h2 class="main_table" align="center"><font size="7">ADMIN HOME</font></h2>
<?  $result = mysql_query("SELECT COUNT(info_hash) FROM namemap") or die (mysql_error());

list($torrent_total) = mysql_fetch_row($result);

echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Torrents in database: ';
echo "<b>$torrent_total</b>";
echo ' - ';

$result = mysql_query("SELECT SUM(size) FROM namemap") or die (mysql_error());
list($size) = mysql_fetch_row($result);
$size = torsize ($size);
echo 'Total data size: ';
echo "<b>$size</b>";
echo '</p>';

// seeds/leech'eeers
$result = mysql_query("SELECT SUM(seeds), SUM(leechers) FROM namemap") or die (mysql_error());
list($seeds_total, $peers_total) = mysql_fetch_row($result);

//seeds total
echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Total seeds: ';
echo "<b>$seeds_total</b>";
echo ' - ';


//Leechers Total
echo 'Total leechers: ';
echo "<b>$peers_total</b>";
echo ' - ';


// seeds/leechers ratio
echo 'Seeds/leechers ratio:<b> ';
echo round($seeds_total / $peers_total, 2);
echo '</b></p>';


// average peer count per torrent
$result = mysql_query("SELECT AVG(seeds), AVG(leechers) FROM namemap") or die (mysql_error());
list($avg_seeds, $avg_peers) = mysql_fetch_row($result);
echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Average seeders per
torrent:<b> ';
echo  round($avg_seeds);
echo '</b> - ';


echo 'Average leechers per torrent:<b> ';
echo round($avg_peers);
echo '</b></p>';

// total number of trackers
$result = mysql_query("SELECT COUNT(DISTINCT announce_url) FROM namemap") or die (mysql_error());
list($tracker_count) = mysql_fetch_row($result);
echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Total number of trackers: ';
echo "<b>$tracker_count</b>";
echo ' - ';



// queries per second
$status = explode('  ', mysql_stat());
list(, $query_second) = explode(': ', $status[7]);
echo 'Average SQL queries per second: ';
echo "<b>$query_second</b>";
echo '</p>';

//END STATS
?>

 <hr color="#EBB80C"><p style="margin-top: 0; margin-bottom: 0" align="center"><font size="5">-
<b>Admin Menu</b> -</font></p>
<div align="center">
  <center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="61%" bgcolor="#292929">
  <tr>
    <td width="33%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="../index.php?mode=directory">Directorys</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="33%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=listtorrents">List Torrents</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="34%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=dead">Dead Torrents</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="33%" bgcolor="#333333">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=users">Users</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="33%" bgcolor="#333333">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=comments">User Comments</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="34%" bgcolor="#333333">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=ban">User Bans</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="33%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=news">News</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="33%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=insert_news">Insert News</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="34%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="33%" bgcolor="#333333">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=list_cat">List Categories</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="33%" bgcolor="#333333">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=add_cat">Add Categories</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="34%" bgcolor="#333333">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=add_subcat">Add Subcats</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="33%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="./index.php?mode=hack">Hack Log</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="33%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">
<a href="../logout.php">Admin Logout</a></p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
    <td width="34%">
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>
    <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</td>
  </tr>
</table></center>
</div>
<hr color="#EBB80C">
<p align="center" style="margin-top: 0; margin-bottom: 0"><font size="5">- <b>User Menu</b> -</font></p>

  <div align="center">
    <center>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" bgcolor="#292929" width="61%">
      <tr>
        <td width="33%" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../index.php">Home</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
        <td width="33%" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../index.php?mode=directory">Directory</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
        <td width="34%" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../torrents.php?mode=upload">Upload Torrent</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
      </tr>
      <tr>
        <td width="33%" bgcolor="#333333" align="center">

        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
        <td width="33%" bgcolor="#333333" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../index.php?mode=stats">Stats</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
        <td width="34%" bgcolor="#333333" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../index.php?mode=news">News</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
      </tr>
      <tr>
        <td width="33%" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../index.php?mode=faq">FAQ</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
        <td width="33%" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="../index.php?mode=about">Copyright</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
        <td width="34%" align="center">
        <p style="margin-top: 0; margin-bottom: 0"><a href="http://proxykill.9999mb.com/phpBB2/">Proxykill's Development Forum</a></p>
        <p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
      </tr>
    </table>
    </center>
</div>


</body>

</html>
