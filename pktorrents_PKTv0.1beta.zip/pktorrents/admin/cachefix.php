<?
require_once( 'conf.php' );
require_once( 'benc.php' );
require_once( 'class_spider.php' );
require_once( 'cached.php' );
require_once( 'scrape.php');
require_once( 'BDecode.php');
$db = mysql_connect( $CONF['SERVER'],$CONF['USER'],$CONF['PASS'])
					 or die( mysql_error() );

$dbs = mysql_select_db($CONF['DB'],$db)
                                         or die( mysql_error() );
                                         
$plugin_arr = array
( 'mininova' =>
 array('site' => 'mininova',  'source' => 'mininova.php', 'class' => 'mininova'), 'torrentspy' =>
 array('site' => 'torrentspy', 'source' => 'torrentspy.php', 'class' => 'torrentspy'), 'piratebay' =>
 array('site' => 'piratebay', 'source' => 'piratebay.php', 'class' => 'piratebay'),'torrentportal'=>
 array('site' => 'torrentportal', 'source' => 'torrentportal.php', 'class' => 'torrentportal'),'meganova' =>
 array('site' => 'meganova', 'source' => 'meganova.php', 'class' => 'meganova'),
);


function recache( $pluggin, $cache )
{
	global $CONF;
	$spider = new spider;
	$spider->conf = $CONF;
	$file = fopen ( 'cached.php', w );
	$return = "<?php\n\n//-----------------------------------------\n// Cache file\n//-----------------------------------------\n\n";
	foreach( $pluggin as $k => $v )
	{
		$time = $cache['site'][ $k ]+1;
		$return .= '$cache[\'site\'][\''.$k.'\'] = ' . $time . ";\n";
	}
	$query = $spider->mysql_debug('SELECT COUNT(id) FROM un_processed');
	$count = mysql_fetch_array( $query );


	$return .= '$cache[\'unprocessed\'] = ' . $count[0] . ";\n";
	$return .= '$cache[\'locked\'] = \'unlocked\';'."\n";
	$return .= '$cache[\'lock_time\'] = '.time().";\n";
	fwrite ( $file, $return );
	$return .= '?>';
}
     	?>
	<? //go function
          recache( $plugin_arr, $cache );
          mysql_query("DELETE FROM un_processed WHERE status = 'in_process'");
        ?>
	

<p align="center"><font size="5" color="#FF0000"><b>.:ALL DONE:.</b></font></p>
<form>
<p align="center">
&nbsp;<input type=button value="Close window" onClick="javascript:window.close();"></p>
</form>
