<?
////////////////////////////////////////////////
//IBITZY FOR TORRENTHOSTER MODDED by Pr0XyK1ll//
////////////////////////////////////////////////

$CONF['SERVER'] = 'localhost';
$CONF['DB'] = '';
$CONF['USER'] = '';
$CONF['PASS'] = '';


//TORRENT DIRECTORY
$CONF['torrent_dir'] = '../torrents/';


 //////DO NOT EDIT BELOW THIS LINE!!!!!///
 ////ALL REQUIRED STUFF IS ALREADY DONE///

/**
* TORRENT FORMAT
*
* torrent_format = enter the format you wish the .torrent to bee saved,
* SYNTAX - <option><option>.extention ie <id><date>.torrent
* VARIABLES - <info_hash>, <id> (this is the insert id given off by mysql), <date> (unix-timestamp), <torrent_name> (the filename saved in the database) --- (DEFAULT = <id>.torrent)
*/

$CONF['torrent_format'] = "<info_hash>.btf";
/**
* LOCK_TIMEOUT
*
* lock_timeout = Time (in seconds) after witch the "locked" statement in the cached file should bee ignored (note if you set this too low it could lead to duplicate torrents downloaded) --- (DEFAULT = 1800)
*/

$CONF['lock_timeout'] = 1800;

//DEBUG_MODE
//debug_mode = When set to 1 it will display debug messages to the browser so you can find any errors in the script, IT SHOULD BEE SET TO 0 WHEN RUNNING AS CRON!
$CONF['debug_mode'] = 1;


//TRIES
//tries = Maximum amount of tries to access a site (DEFAULT = 3)
$CONF['tries'] = 3;


//PROCESSES
//processes = Amount of unprocessed rows to execute each time script is run or automaticly refreshed (DEFAULT = 1)
//NOTE: best to keep to 1 till you know its working 100% or want to reduce sql load
$CONF['processes'] = 1;


//MAX_UNPROCESSED
//max_unprocessed = Maximum unprocessed rows to store before data is executed and torrents are retrieved (DEFAULT = 1)
$CONF['max_unprocessed'] = 1;

//
//intval = How long to wait after last gathering of data from a site before new data can be gathered (DEFAULT = 1)
$CONF['interval'] = 1;



//SUBMITTER
//submitter = the uid/username you would like the spider to upload its torrents under
//

$CONF['submitter'] = 1;

/**
* SQL PREFIX's
*
* tbl_name = Name of table to store torrents in (DEFAULT = torrents)
* torrent_name = Name of field where torrent name is stored (DEFAULT = name)
* announce = Name of field where announce url of torrent is stored (DEFAULT = announce)
* cat = Name of field where category id's are stored of torrents (DEFAULT = cat)
* size = Name of field where size of torrent is store (DEFAULT = size)
* magnet = Name of field where magnet link is stored (DEFAULT = magnet)
* info_hash = Name of field where info hash of torrent is stored, these are stored in 40char sha1 format (DEFAULT = info_hash)
* site_tid = Name of field where site torrent id is stored, this can be used to track down the exact torrent on a site (DEFAULT = site_tid)
* site = Name of field where the site the torrent was taken from is stored (DEFAULT = site)
* data = Unixtimestamp of time the torrent was added to the database (DEFAULT = date)
* dl_name = Some site softwere require the name of the .torrent to bee stored seperatly, this variable is for that (DEFAULT = dl_name)
* submitter = uid/name of the user the spider will upload torrents under (DEFAULT = submitter)
*/


//THERE IS NO NEED TO CHANGE THESE IF YOUR INSTALLING FOR TORRENTHOSTER
$CONF['sql']['tbl_name'] = 'namemap';
$CONF['sql']['torrent_name'] = 'filename';
//added to make w0rk with torrenthoster
$CONF['sql']['torrent_name2'] = 'filename2';
$CONF['sql']['announce'] = 'announce_url';
$CONF['sql']['cat'] = 'category';
$CONF['sql']['subcat'] = 'subcategory';
$CONF['sql']['size'] = 'size';
$CONF['sql']['magnet'] = 'magnet';
$CONF['sql']['info_hash'] = 'info_hash';
$CONF['sql']['site_tid'] = 'site_id';
$CONF['sql']['site'] = 'site';
$CONF['sql']['date'] = 'data';
$CONF['sql']['lastupdate'] = 'lastupdate';
$CONF['sql']['dl_name'] = 'url';
$CONF['sql']['submitter'] = 'submitter';
$CONF['sql']['seeds'] = 'seeds';
$CONF['sql']['peers'] = 'leechers';

/**
* Categories Array
*
* cats = This is the categories array to match up id's of data gathered from sites,
* theres a similar one in each plugin which completes the match up.
* PLEASE BE WARNED THAT INCORRECT EDITING THIS CAN COUSE PLUGGINS TO STOP WORKING RIGHT.
* you should change the CATEGORY ID to match the id's of the matching categorys on your site
* DO NOT EDIT THE "usage id" OR "category name" AS THIS WOULD BREAK COMPATABILITY WITH THE PLUGGINS.
*/
//============================================================================================
//  Usage id => 'category id', 'category name(no functional use)' ),
//============================================================================================



$CONF['cats'] = array(
				1 => array('1','Anime'),
				2 => array('2','Books'),
				3 => array('3','Games'),
				4 => array('4','Movies'),
				5 => array('5','Music'),
				6 => array('6','Softwere / Apps'),
				7 => array('7','TV'),
				8 => array('8','Other'),
				);

///////////////////////END OF CONFIG

///Added for Stats while crawling
function connect ($dbhost, $dbuser, $dbpass, $database)
{
$errormes = 'The sql server has encountered a problem, we are trying to fix it as soon as possible';
@$connection = mysql_connect($dbhost, $dbuser, $dbpass);
@mysql_select_db($database) or die($errormes);

}
function torsize ($size)
{
if ($size >= 1099511627776) 	{$size = round($size / 1024 / 1024 / 1024 / 1024, 2).' TB';}
elseif ($size >= 1073741824) 	{$size = round($size / 1024 / 1024 / 1024, 2).' GB';}
elseif ($size >= 1048576) 		{$size = round($size / 1024 / 1024, 2).' MB';}
elseif ($size >= 1024) 			{$size = round($size / 1024, 2).' KB';}
else 							{$size = $size.' Byte';}
return $size;
}
?>
