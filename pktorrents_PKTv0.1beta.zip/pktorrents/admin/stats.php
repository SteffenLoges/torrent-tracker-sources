<?php
/*
+--------------------------------------------------------------------------
|   IBITZY V 0.3 Beta
|   =============================================
|   Web: http://www.ipbtracker.eu/index.php?showforum=26
|	By: jaggi
|	Created: 15/09/06
+---------------------------------------------------------------------------
| IBITZY stats file, Nice pretty stats :)
+--------------------------------------------------------------------------
*/


//--------------------------------
// Require the files
//--------------------------------

require_once( 'conf.php' );

//--------------------------------
// Setup DB connection
//--------------------------------

$db = mysql_connect( $CONF['SERVER'],
					 $CONF['USER'],
					 $CONF['PASS']) 
					 or die( mysql_error() );
					 
$dbs = mysql_select_db($CONF['DB'],
					   $db) 
					   or die( mysql_error() );

$stats = new stats;
$stats->conf = $CONF;
$stats->runstats();

class stats
{

	var $conf = array();
 	var $html = "";
	
	function runstats()
	{

		//-----------------------------------------
		// Count of sites torrents indexed from
		//-----------------------------------------	
			
		$this->html .= "<table width='50%' border='1'>
							<tr>
								<th width='50%' colspan='2'>Amount of Torrents Indexed from the following sites</th>
							</tr>";
		
		$sql = mysql_query("SELECT *, count(*) as count FROM {$this->conf['sql']['tbl_name']} GROUP BY {$this->conf['sql']['site']}");
		
		while ( $data = mysql_fetch_array( $sql ) )
		{
			$this->html .= "<tr>
								<td width='25%'>{$data['site']}</td>
								<td width='25%'>{$data['count']}</td>
							</tr>";
			
		}
		
		$this->html .= "</table>";
		
		//-----------------------------------------
		// Total Torrents
		// Size of data
		//-----------------------------------------		

		$sql = mysql_query("SELECT sum({$this->conf['sql']['size']}) AS size, count(*) AS count FROM {$this->conf['sql']['tbl_name']}");
		
		while ( $data = mysql_fetch_array( $sql ) )
		{
		
			$data['size'] = $this->get_size( $data['size'] );
			
			$this->html .= "<br />
							<table width='50%' border='1'>
								<tr>
									<th width='50%' colspan='2'>General Torrent Stats</th>
								</tr>
								<tr>
									<td width='25%'>Total Torrents</td>
									<td width='25%'>{$data['count']}</td>
								</tr>
								<tr>
									<td width='25%'>Total Size of torrents indexed</td>
									<td width='25%'>{$data['size']}</td>
								</tr>";
		}
		
		//-----------------------------------------
		// Torrents index'd today
		//-----------------------------------------	
		
		$time = time() - 86400;
		
		$sql = mysql_query("SELECT count(*) AS count FROM {$this->conf['sql']['tbl_name']} WHERE {$this->conf['sql']['date']} > {$time}");
		
		while ( $data = mysql_fetch_array( $sql ) )
		{		
			$this->html .= "	<tr>
									<td width='25%'>Torrents indexed in last 24hrs</td>
									<td width='25%'>{$data['count']}</td>
								</tr>
							<table>";
		}		
		
		//-----------------------------------------
		// Count of torrents on trackers
		//-----------------------------------------	
		
		$this->html .= "<br />
					  	<table width='80%' border='1'>
							<tr>
								<th width='80%' colspan='2'>Amount of Torrents Indexed from Tracker URLS</th>
							</tr>
							<tr>
								<th width='70%'>Tracker Urls</th>
								<th width='10%'>Torrents</th>
							</tr>";
			
							  
		$sql = mysql_query("SELECT {$this->conf['sql']['announce']}, count(*) AS count FROM {$this->conf['sql']['tbl_name']} GROUP BY {$this->conf['sql']['announce']} ORDER BY count DESC");
		
		while ( $data = mysql_fetch_array( $sql ) )
		{
			$this->html .= "	<tr>
									<td width='70%'>{$data['tracker']}</td>
									<td width='10%'>{$data['count']}</td>
								</tr>";				
		}
		
		$this->html .= "</table>";

		//-----------------------------------------
		// Send Output
		//-----------------------------------------	
		
		$this->output();		
	}
	
	function get_size( $bytes="" )
	{
		$value = "";
		
		if ( $bytes >= 125899906842624 ) 
		{
			$value = round( $bytes / 125899906842624 * 100) / 100 . ' PB';
		}
		else if ( $bytes >= 1099511627776 )
		{
			$value = round( $bytes / 1099511627776 * 100 ) / 100 . ' TB';
		}		
		else if ( $bytes >= 1073741824 )
		{
			$value = round( $bytes / 1073741824 * 100 ) / 100 . ' GB';
		}		
		else if ( $bytes >= 1048576 )
		{
			$value = round( $bytes / 1048576 * 100 ) / 100 . ' MB';
		}
		
		return $value;
	}
	
	function output()
	{
		echo "<!DOCTYPE html 'PUBLIC -//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
			  <html xmlns='http://www.w3.org/1999/xhtml'>
              <head>
			  <meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
			  <title>IBITZY Statistics Page</title>
			  </head>
			  <body>";
			  
		echo $this->html;
		
		echo "</body>
			  </html>";
	}

}