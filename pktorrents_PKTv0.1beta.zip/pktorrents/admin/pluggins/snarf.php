<?
/*
+--------------------------------------------------------------------------
|   IBITZY Mininova Plugin
|   =============================================
|   Web: http://www.ipbtracker.eu/index.php?showforum=26
|	By: beeman
|	Created: 15/09/06
+---------------------------------------------------------------------------
| Setup various parts of the plugin for the site
+--------------------------------------------------------------------------
*/

//--------------------------------
// Start class
//--------------------------------

class snarfit
{
	/**
	* SETUP VARS
	*
	* to_spider = URL to page you wish to index
	* tinfo = the details page of the torrent
	* tinfo_url = full url of site to torrent details page
	* dl_link = full download url to torrent
	* dl_extra = some sites require trailing slashes or .torrent after the url, here u can do that
	* conf = this loads the conf class, don't edit
	*/
	
	var $to_spider	= 'http://www.snarf-it.org/view/today.html?cat=Anime';
	var $tinfo		= '';
	var $tinfo_url	= 'http://www.snarf-it.org/viewTorrent/';
	var $dl_link	= 'http://www.snarf-it.org/downloadTorrent/';
	var $dl_extra	= '-snarf.torrent';
	var $conf		= '';
	
	/*-------------------------------------------------------------------------*/
	// Main Match
	// > Get full url and torrent id 
	/*-------------------------------------------------------------------------*/ 	
	
	function main_match( $file )
	{
		$data[1] = $file;
		$data[2] = @file_get_contents('http://www.snarf-it.org/view/today.html?cat=Games');
		$data[4] = @file_get_contents('http://www.snarf-it.org/view/today.html?cat=Movies');
		$data[5] = @file_get_contents('http://www.snarf-it.org/view/today.html?cat=Music');
		$data[6] = @file_get_contents('http://www.snarf-it.org/view/today.html?cat=Software');
		$data[7] = @file_get_contents('http://www.snarf-it.org/view/today.html?cat=Television');
		$data[8]= @file_get_contents('http://www.snarf-it.org/view/today.html?cat=Misc');
		
		$return = $this->snarf_main_match( $data );
		return  $return;
	}
	
	function snarf_main_match( $data )
	{
		foreach( $data as $k => $v )
		{
			preg_match_all( "#<td class=\"list-name\"><a href=\"/viewTorrent/(.+?)-(.+?).html\">#ise", $v, $out );
			
			$count =0;
			foreach ( $out['1'] as $key )
			{
				$return[ $out[1][ $count ] ] = array( 'url' => $this->tinfo_url . $out[1][ $count ] . '-' .$out[2][ $count ] .'.html', 'cat' => $k, 'id' => $out[1][$count], 'subcat' => $subcat ); 
				$count++;
			}
		}
		return $return;
	}

	/*-------------------------------------------------------------------------*/
	// Match Name
	// > Get torrent name
	/*-------------------------------------------------------------------------*/ 
	
	function match_name( $file )
	{
		preg_match( "#<a href=\"/downloadTorrent/(.+?)\">(.+?)</a>#" , $file,	$out );
		return $out[2];
	}

	/*-------------------------------------------------------------------------*/
	// Process Cat
	// > Get category on site
	/*-------------------------------------------------------------------------*/ 
		
	function process_cat( $file )
	{
		return;
	}

	/*-------------------------------------------------------------------------*/
	// Process sub
	// > Get torrent sub category
	/*-------------------------------------------------------------------------*/ 
	
	function process_sub( $file )
	{
		return;
	}

	/*-------------------------------------------------------------------------*/
	// Process Magnet
	// > Get magnet link
	/*-------------------------------------------------------------------------*/ 
		
	function process_magnet( $file )
	{
		return;
	}

	/*-------------------------------------------------------------------------*/
	// Cat Code Extra
	// > Process and match site category with global categories
	/*-------------------------------------------------------------------------*/ 
		
	function cat_code_extra( $cat="", $sub="" )
	{
		return array( 'cat' => $row['cat'], 'sub' => '' );
	}

	/*-------------------------------------------------------------------------*/
	// Process Download
	// > Setup the download url from where the torrents are downloaded
	/*-------------------------------------------------------------------------*/
	
	function process_download( $dlurl, $tinfo )
	{
		//-----------------------------------------
		// Construct and return url
		//-----------------------------------------
		
		$dlurl = $this->dl_link . $tinfo . $this->dl_extra;
		return $dlurl;
	}
}
?>