<?php
/*
+--------------------------------------------------------------------------
|   IBITZY Piratebay Plugin
|   =============================================
|   Web: http://www.ipbtracker.eu/index.php?showforum=26
|	By: jaggi
|	Created: 15/09/06 
+---------------------------------------------------------------------------
| Setup various parts of the plugin for the site
+--------------------------------------------------------------------------
*/

//--------------------------------
// Start class
//--------------------------------

class piratebay
{
	/**
	* SETUP VARS
	*
	* to_spider = URL to page you wish to index
	* tinfo = the details page of the torrent
	* tinfo_url = full url of site to torrent details page
	* dl_link = full download url to torrent
	* dl_extra = some sites require trailing slashes or .torrent after the url, here u can do that
	* conf = this loads the conf class, don't edit
	*/
	
	var $to_spider	= 'http://thepiratebay.org/recent';
	var $tinfo		= '/tor/';
	var $tinfo_url	= 'http://thepiratebay.org/tor/';
	var $dl_link	= 'http://torrents.thepiratebay.org/hashtorrent/';
	var $dl_extra 	= '.torrent/';
	var $conf		= '';
	
	/**
	* VARS for proxy mode or if cookies required
	*
	* direct_connect = is it needed (1) or not (0)
	* spider_root_addr = Path to root of site
	* spider_path = path to page to index
	* cookies = cookie to send to site
	*/
	
	var $direct_connect = 1;
	var $spider_root_addr = 'thepiratebay.org';
	var $spider_path = '/recent';
	var $cookies = "Cookie: language=en_EN\r\n";

	/*-------------------------------------------------------------------------*/
	// Main Match
	// > Get full url and torrent id 
	/*-------------------------------------------------------------------------*/ 
		
	function main_match( $file )
	{
		//-------------------------------------------------
		// Piratebay doesn't have category on details page
		// so get from index and store for later
		//-------------------------------------------------
		
		preg_match_all( "#<a href=\".+?>(.+?) > .+?</a></td>\n<td><a href=\"{$this->tinfo}(\d+)/.*?\">(.+?)</a>#", $file, $out );
		$count = 0;
		foreach ( $out[1] as $k )
		{					
			$return[ $out[2][$count] ] = array( 'url' => $this->tinfo_url . $out[2][$count], 'cat' => $out[1][$count], 'id' => $out[2][$count], 'subcat' => $subcat ); 
			$count++;
		}	
		return $return;
	}
	
	/*-------------------------------------------------------------------------*/
	// Match Name
	// > Get torrent name
	/*-------------------------------------------------------------------------*/ 
		
	function match_name( $file )
	{
		@preg_match( "#<div id=\"title\">(.*?)</div>#" , $file,	$out ); 
		return $out[1];
	}

	/*-------------------------------------------------------------------------*/
	// Process Cat
	// > Get category on site
	/*-------------------------------------------------------------------------*/ 
		
	function process_cat( $file )
	{
		@preg_match( "#<dd>(.*?)</dd>#", $file,	$out );
		return $out[1];
	}

	/*-------------------------------------------------------------------------*/
	// Process sub
	// > Get torrent sub category
	/*-------------------------------------------------------------------------*/
		
	function process_sub( $file )
	{
		return;
	}

	/*-------------------------------------------------------------------------*/
	// Process Magnet
	// > Get magnet link
	/*-------------------------------------------------------------------------*/ 
		
	function process_magnet( $file )
	{
		return;
	}

	/*-------------------------------------------------------------------------*/
	// Cat Code Extra
	// > Process and match site category with global categories
	/*-------------------------------------------------------------------------*/ 
		
	function cat_code_extra( $cat="", $sub="", $row )
	{

		//-----------------------------------------
		// Make category all low caps
		//-----------------------------------------
				
		$cat = strtolower( $row['cat'] );
				
		//-----------------------------------------
		// Match Array
		//-----------------------------------------
		//============================================================================================
		//  PIRATEBAY CAT NAME => 'category name(no functional use)', main category array, 
		//============================================================================================

		$pluggin_cats = array( 
								'audio'  		=> array( 'Music',  $this->conf['cats'][5][0] ),
								'video' 		=> array( 'Movies', $this->conf['cats'][4][0] ),
								'applications'  => array( 'Apps', 	 $this->conf['cats'][6][0] ),
								'games' 		=> array( 'Games', $this->conf['cats'][3][0] ),
								'porn'	 		=> array( 'Adult', $this->conf['cats'][9][0] ),
								'other' 		=> array( 'Other',  $this->conf['cats'][8][0] ),
							  );
	
		//-----------------------------------------
		// Check if we have match or set as other
		//  > Return cat id to class
		//-----------------------------------------
										
		$return_cat = !$pluggin_cats[ $cat ] ? $this->conf['cats'][8][0] : $pluggin_cats[ $cat ][1];
		return array( 'cat' => $return_cat, 'sub' => '' );
	}

	/*-------------------------------------------------------------------------*/
	// Process Download
	// > Setup the download url from where the torrents are downloaded
	/*-------------------------------------------------------------------------*/
		
	function process_download( $dlurl, $tinfo )
	{
		//-----------------------------------------
		// Construct and return url
		//-----------------------------------------
		
		$dlurl = $this->dl_link . $tinfo . $this->dl_extra;
		return $dlurl;
	}
	
	function set_cookie()
	{
		setcookie( "language", "nl_NL", time()+31536000, "/", ".thepiratebay.org", 0);
	}
}
?>