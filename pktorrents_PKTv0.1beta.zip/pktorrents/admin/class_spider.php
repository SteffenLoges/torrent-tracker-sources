<link rel="stylesheet" href="../templates/colours.php" type="text/css" title="Default"/>
<?php
/*
+--------------------------------------------------------------------------
|   IBITZY V 0.4 Beta
|   =============================================
|   Web: http://www.ipbtracker.eu/index.php?showforum=26
|	By: beeman
|	Created: 15/09/06
|	Last Edited: 24/02/07
+---------------------------------------------------------------------------
|   > Class for gather torrent data
|   > processing torrent data
|   > Writing data into database
|	> Getting torrents from multiple sites
+--------------------------------------------------------------------------
*/

/**
* Spider Class
*
*/

class spider
{
	/**
	* Load vars for use in class
	*
	*/
	
	var $pluggin_arr = array();
	var $vars = array();
	var $site = '';
	var $conf = array();
	var $lib = array();
	var $cache = array();
	var $delete = "";
	var $failed = "";

	/*-------------------------------------------------------------------------*/
	// Run and process the sites list
	/*-------------------------------------------------------------------------*/
		
	function process_site()
	{
		//-----------------------------------------
		// Get the sites data
		//-----------------------------------------
		
		if( $this->vars->direct_connect == 1 )
		{
			$file = $this->direct_connect();
		}
		else 
		{
			$file = $this->file_get_content( $this->vars->to_spider );
		}
		
		//-----------------------------------------
		// Check if recache is needed
		//-----------------------------------------
		
		if( $file[1] == FALSE )
		{
			recache( $this->plugin_arr, $this->cache );
			$this->debug_output( 'Cant Connect to external site to receive torrents! Check that the site is not currently down.' );
			exit;
		}

		$out = $this->vars->main_match( $file[2] );
		
		$this->debug_output( '
		<script>
        document.write(\'<p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr><p style="margin-top: 0; margin-bottom: 0" align="center"><font color="#FF0000" size="5">PROCESSING TORRENTS</font></p><p style="margin-top: 0; margin-bottom: 0" align="center">Please Wait...</p>\');
	    </script>' );

		//-----------------------------------------
		// Check where we left off 
		// Check if data exists, and skip
		//-----------------------------------------
		
		$time = time() - 86400;
		
		$data = $this->mysql_debug("SELECT {$this->conf['sql']['info_hash']}
							 		FROM {$this->conf['sql']['tbl_name']} 
							 		WHERE {$this->conf['sql']['date']} > {$time} 
							 		AND {$this->conf['sql']['site']} = '{$this->site}'
									");
							
		while( $res = mysql_fetch_array( $data ) )
		{
			$existing[ $res['site_tid'] ] = $res['site_tid'];
		}
		
		$data = $this->mysql_debug("SELECT tid 
							 		FROM un_processed 
							 		WHERE date > {$time} 
							 		AND site = '{$this->site}'
									");
		
		while( $res = mysql_fetch_array( $data ) )
		{
			$existing[ $res['info_hash'] ] = $res['info_hash'];
		}
		
		//--------------------------------------------------
		// If all is good, gather data ready for processing. 
		//--------------------------------------------------
		
		$this->debug_output( 'Gathered data ready for processing.<meta http-equiv="refresh" content="2">' );
		foreach( $out as $k )
		{
			if( $existing[ $k['id'] ] == '' )
			{
				$this->mysql_debug("INSERT INTO un_processed (tid, url, site, date, cat, subcat, stamp) 
							 		VALUES ('{$k['id']}',
							 		 '".mysql_real_escape_string($k['url'])."',
									 '{$this->site}',
									 '".time()."',
									 '".mysql_real_escape_string($k['cat'])."',
									 '".mysql_real_escape_string($k['subcat'])."',
									 '0')
							 		");
			}

		}

		$this->debug_output( '
                <b>Successfull! Ref</b>
               <p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr><p style="margin-top: 0; margin-bottom: 0" align="center"><font color="#FF0000" size="5">PROCESSING TORRENTS</font></p><p style="margin-top: 0; margin-bottom: 0" align="center">Please Wait...</p>
' );

	}                                
	/*-------------------------------------------------------------------------*/
	// mysql_debug
	/*-------------------------------------------------------------------------*/
	
	function debug_output( $output )
	{
		if( $this->conf['debug_mode'] == 1 )
		{
			echo $output."<br />\n";
			return;
		}
		else 
		{
			return;
		}
	}
	
	/*-------------------------------------------------------------------------*/
	// mysql_debug
	/*-------------------------------------------------------------------------*/
	
	function mysql_debug( $sql )
	{
		if( $this->conf['debug_mode'] == 1 )
		{
			$return = mysql_query( $sql ) or die( $sql ."<br />\n<br />\n". mysql_error());
		}
		else 
		{
			$return = mysql_query( $sql );
		}
		
		return $return;
	}
	
	/*-------------------------------------------------------------------------*/
	// Direct Connect
	/*-------------------------------------------------------------------------*/
		
	function direct_connect()
	{
		$fp = @fsockopen ( $this->vars->spider_root_addr, 80, $errno, $errstr, 30 );
		if( !$fp ) 
		{
			return array(1 => FALSE, 2 => ''); 
		} 
		else 
		{
			@fwrite( $fp, "POST {$this->vars->spider_path} HTTP/1.1\r\nHost: {$this->vars->spider_root_addr}\r\n{$this->vars->cookies}Connection: Keep-Alive\r\n\r\n" );
 			$data = '';
   			while( !feof( $fp ) ) 
   			{
       			$data .= @fread( $fp, 4096 );
       			if( substr( $data, -9 )== "\r\n\r\n0\r\n\r\n" ) 
       			{
       				return array( 1 => FALSE, 2 => '' ); 
      			}
   			}
		}
		return array( 1 => TRUE, 2 => $data );
	}

	
	/*-------------------------------------------------------------------------*/
	// Get file content
	/*-------------------------------------------------------------------------*/
	
	function file_get_content( $url )
	{
		for( $i = 1; $c <= $this->conf['tries']; $c++ )
		{
			$file = @file_get_contents( $url );
			if( $file != FALSE )
			{
				return array( 1 => TRUE, 2 => $file );
				break;
			}
		}
		return array( 1 => FALSE, 2 => '' ); 
	}

	/*-------------------------------------------------------------------------*/
	// Process data into gathering torrents and torrent data
	/*-------------------------------------------------------------------------*/
		
	function process()
	{

		//-----------------------------------------
		// Is the process locked?
		//-----------------------------------------
		
		if( $this->cache['locked'] == 'locked' && $this->cache['lock_time'] > time() - $this->conf['lock_timeout'] )
		{
			$this->debug_output( '<p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr><br><meta http-equiv="refresh" content="3"><p align="center"><b>The file is presently locked, try again in a few minuites!</b></p>

<script language="JavaScript">
<!--
	// DATE PRINT
	document.write(\'<p style="margin-top: 0; margin-bottom: 0" align="center">\' + (new Date).toLocaleString() + \'</p>\');
//-->
</script>

<p align="center"><SCRIPT LANGUAGE="JavaScript">
<!-- Begin popup
function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, \'" + id + "\', \'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=250,height=100,left = 412,top = 284\');");
}
// End -->
</script>
<p align="center">
<input type=button value="Fix Lockfile" onClick="javascript:popUp(\'cachefix.php\')">
<font color="#FF0000"><b>Not Recommended!!! - Use ONLY if you think theres an error! </b></font>
</font></p></p>

</form>

' );
			exit;
		}

		$this->lock_file( $this->pluggin_arr, $this->cache );

		//-----------------------------------------
		// Load benc class
		//-----------------------------------------
		
		$this->lib = new lib_benc;		
		
		//-----------------------------------------
		// Load each pluggin
		//-----------------------------------------
		foreach ( $this->pluggin_arr as $k => $v )
		{
			@include( 'pluggins/'. $v['source'] );
			$this->pluggin[ $k ] = new $v['class'];
			$this->pluggin[ $k ]->conf = $this->conf;
		}
		
		//-----------------------------------------
		// Prevent backlog of stale "in_process" torrents
		//-----------------------------------------	
		
		$this->mysql_debug( "DELETE FROM un_processed WHERE status = 'in_process' AND stamp > ".time()." - {$this->conf['interval']} AND stamp != 0");
		
		
		//-----------------------------------------
		// Gather unprocessed data to process
		//-----------------------------------------		
		
		$data = $this->mysql_debug("SELECT * 
							 		FROM un_processed 
							 		WHERE status != 'in_process' 
									LIMIT {$this->conf['processes']}
									");
							
		while ( $row = mysql_fetch_array( $data ) )
		{
			//-----------------------------------------
			// If theres nothing to do exit. 
			//-----------------------------------------
			
			if ( $row['tid'] == '' )
			{
				$this->debug_output( '<p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr>No files to process' );
				exit;
			}	
			
			//--------------------------------------------
			// Gather id's to set all "in_process" 
			// in 1 query.
			//--------------------------------------------
			
			$in .= $row['tid'].', ';
			
			$each[ $row['tid'] ] = $row;
		}
		
		//--------------------------------------------
		// Update data being processed to "in_process"
		// so its not processed twice. 
		//--------------------------------------------
			
		$in = substr($in, 0, -2);	
		
		if( $in != '' )
		{
			$this->mysql_debug("UPDATE un_processed 
						  		SET status='in_process', stamp='".time()."' 
						  		WHERE tid IN({$in})
						 		");
		}
		
		//--------------------------------------------
		// Process torrents
		//--------------------------------------------
		if( is_array( $each ) )
		{
			foreach( $each as $row )
			{
				$this->process_torrent( $row['tid'], $row['site'], $row['url'], $row );
			}
		}
		
		//--------------------------------------------
		// Success now delete!
		//--------------------------------------------
		
		if( $this->delete != "" )
		{
			$delete = substr($this->delete, 0, -2);
			$this->mysql_debug( "DELETE FROM un_processed WHERE tid IN({$delete})" );
		}
		
		//--------------------------------------------
		// You total failer :P
		//--------------------------------------------
		
		if( $this->failed != "" )
		{
			$failed = substr( $this->failed, 0, -2 );
			$this->mysql_debug( "UPDATE un_processed SET status='failed' WHERE tid IN({$failed})" );
		}



$result = mysql_query("SELECT COUNT(info_hash) FROM namemap") or die (mysql_error());

list($torrent_total) = mysql_fetch_row($result);

echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Torrents in database: ';
echo "<b>$torrent_total</b>";
echo ' - ';

$result = mysql_query("SELECT SUM(size) FROM namemap") or die (mysql_error());
list($size) = mysql_fetch_row($result);
$size = torsize ($size);
echo 'Total data size: ';
echo "<b>$size</b>";
echo '</p>';

// seeds/leech'eeers
$result = mysql_query("SELECT SUM(seeds), SUM(leechers) FROM namemap") or die (mysql_error());
list($seeds_total, $peers_total) = mysql_fetch_row($result);

//seeds total
echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Total seeds: ';
echo "<b>$seeds_total</b>";
echo ' - ';


//Leechers Total
echo 'Total leechers: ';
echo "<b>$peers_total</b>";
echo ' - ';


// seeds/leechers ratio
echo 'Seeds/leechers ratio:<b> ';
echo round($seeds_total / $peers_total, 2);
echo '</b></p>';


// average peer count per torrent
$result = mysql_query("SELECT AVG(seeds), AVG(leechers) FROM namemap") or die (mysql_error());
list($avg_seeds, $avg_peers) = mysql_fetch_row($result);
echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Average seeders per
torrent:<b> ';
echo  round($avg_seeds);
echo '</b> - ';


echo 'Average leechers per torrent:<b> ';
echo round($avg_peers);
echo '</b></p>';

// total number of trackers
$result = mysql_query("SELECT  COUNT(DISTINCT announce_url) FROM namemap") or die (mysql_error());
list($tracker_count) = mysql_fetch_row($result);
echo '<p style="margin-top: 0; margin-bottom: 0" align="center">Total number of trackers: ';
echo "<b>$tracker_count</b>";
echo ' - ';



// queries per second
$status = explode('  ', mysql_stat());
list(, $query_second) = explode(': ', $status[7]);
echo 'Average SQL queries per second: ';
echo "<b>$query_second</b>";
echo '</p>';

//END STATS



		
		$this->debug_output( '<meta http-equiv="refresh" content="2"><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr><p align="center"><font color=\"#FF0000\">Time since complete process: </font>

    <script language="JavaScript">
<!--
	// DATE PRINT
	document.write(\'\' + (new Date).toLocaleString() + \'\');
//-->
</script></p>



        ' );

	}
	
	
	/*-------------------------------------------------------------------------*/
	// Finally process the torrent, gather torrent data and torrents
	/*-------------------------------------------------------------------------*/	
	
	function process_torrent( $tinfo, $site, $url, $row )
	{
		//-----------------------------------------
		// Get the file 
		//-----------------------------------------
		
		$file = $this->file_get_content( $url );
		
		//-----------------------------------------
		// If sucessful, continue
		//-----------------------------------------		
		
		if ( $file[1] == TRUE )
		{
			//-----------------------------------------
			// Gather torrent details from site
			//-----------------------------------------

			$torrent['name'] = htmlentities( $this->pluggin[ $site ]->match_name( $file[2] ) );
			$torrent['name2'] = htmlentities( $this->pluggin[ $site ]->match_name( $file[2] ) );
			$torrent['cat'] = $this->pluggin[ $site ]->process_cat( $file[2] );
			$torrent['sub'] = $this->pluggin[ $site ]->process_sub( $file[2] );
			$cat_extra = $this->pluggin[ $site ]->cat_code_extra( $torrent['cat'], $torrent['sub'], $row );
			$torrent['cat'] = $cat_extra['cat'];
			$torrent['sub'] = $cat_extra['sub'];
			$torrent['magnet'] = $this->pluggin[ $site ]->process_magnet( $file[2] );
			$torrent['dlurl'] = $this->pluggin[ $site ]->process_download( $file[2], $tinfo );
			$torrent['dl_name'] = str_replace(' ','_',$torrent['name']);
			$torrent['dl_name'] = $torrent['dl_name'] . '.torrent';

			//-----------------------------------------
			// Finally decode the .torrent
			//-----------------------------------------
			
			$t['file'] = $this->file_get_content( $torrent['dlurl'] );
			
			if ( $t['file'][1] == TRUE )
			{
				$t_file = $this->lib->bdec( $t['file'][2] );
				$torrent['info_hash'] = sha1( $this->lib->benc( $t_file['value']['info'] ) );
				$torrent['pcount'] = $t_file['value']['info']['value']['pieces']['strlen'] / 20;
				$torrent['plength'] = $t_file['value']['info']['value']['piece length']['value'];
				$torrent['size'] = $torrent['pcount'] * $torrent['plength'];
				$torrent['announce'] = $t_file['value']['announce']['value'];
				
				if ( $torrent['announce'] == '' )
				{	
					$this->debug_output( '<p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr>This torrent dosnt look right, cant find an announce url' );
					$this->delete .= $tinfo.', ';
					return;
				}
				
				//-----------------------------------------
				// Do we already have this torrent?
				//-----------------------------------------
				
				$sql = $this->mysql_debug("SELECT count(*) 
											FROM {$this->conf['sql']['tbl_name']} 
											WHERE {$this->conf['sql']['info_hash']}='{$torrent['info_hash']}' 
											AND {$this->conf['sql']['announce']}='{$torrent['announce']}'"
								   			);
								   
				$count = mysql_fetch_array( $sql );

				//-----------------------------------------
				// If yes delete it
				//-----------------------------------------	
							
				if ( $count[0] > 0 )
				{
					$this->debug_output( '<p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><p style="margin-top: 0; margin-bottom: 0" align="center"><b><font size="5">Ibitzy</font><font size="5"> torrent crawler V0.4 BETA</font></b></p><p style="margin-top: 0; margin-bottom: 0" align="center">Modded for PK-Torrents & Stats By Pr0xyKi11</p><p style="margin-top: 0; margin-bottom: 0" align="center"><a href="http://www.ipbtracker.eu/index.php?showtopic=294" target="_blank">http://www.ipbtracker.eu</a><b><font size="4">|</font></b> <a href="http://cherone.co.uk">http://cherone.co.uk</a></p><p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p><hr>We already seem to have this torrent!' );
					$this->delete .= $tinfo.', ';
					return;
				}
				else 
				{
					//-----------------------------------------
					// Sucessful, construct the query
					//-----------------------------------------
					
		                    $tracker 		= strip_tags($torrent['announce']);
                                    $tracker 		= strip_tags(str_replace('announce', 'scrape', $tracker));
				    $stats 		= torrent_scrape_url($tracker, $torrent['info_hash']);
				    $seeds 		= strip_tags($stats['seeds']);
				    $peers 		= strip_tags($stats['peers']);
				    $torrentname 	= trim(strip_tags($torrent['name']));
				    $torrentname        = addslashes($torrentname);

				    //proxykill's mods
                                    //origanaly added for visual perpose in torrent details page
                                    $tracker2 = $tracker;
	                            $tracker2 		= strip_tags($torrent['announce']);
                                    $tracker2 		= strip_tags(str_replace('scrape', 'announce', $tracker2));
				    //added for extra filename in db
				    $torrentname2 = $torrentname;
				    $torrentname2 	= trim(strip_tags($torrent['name']));
				    $torrentname2       = addslashes($torrentname);
					
					$time = time();
					
					$q = "INSERT IGNORE INTO {$this->conf['sql']['tbl_name']} 
                                                          (
                                                          {$this->conf['sql']['torrent_name']},
                                                          {$this->conf['sql']['torrent_name2']},
							  {$this->conf['sql']['cat']},
							  {$this->conf['sql']['subcat']},
							  {$this->conf['sql']['size']},
							  {$this->conf['sql']['info_hash']},
							  {$this->conf['sql']['site_tid']},
							  {$this->conf['sql']['site']},
							  {$this->conf['sql']['date']},
                                                          {$this->conf['sql']['announce']},
							  {$this->conf['sql']['seeds']},
							  {$this->conf['sql']['peers']})
						  VALUES ('".mysql_real_escape_string( $torrent['name'] ) ."',
                                                          '".mysql_real_escape_string( $torrent['name2'] ) ."',
						  		   '".intval( $torrent['cat'] ) ."',
			          		                   '{$subcat}',
						                   '{$torrent['size']}',
						                   '". mysql_real_escape_string( $torrent['info_hash'] ) ."',
						                   '{$tinfo}',
						                   '". mysql_real_escape_string( $site ) ."',
						                   '". date('YmdHis')."',
						                   '". mysql_real_escape_string( $tracker ) ."',
						                   '".$seeds."',
						                   '".$peers."')
						        	";
							
					//-----------------------------------------
					// Run the query or error
					//-----------------------------------------	
											
					$this->mysql_debug( $q );
					$id = mysql_insert_id();
					
					//-----------------------------------------
					// What format are we saving the torrent in?
					//-----------------------------------------
					if( !$this->conf['torrent_format'] || $this->conf['torrent_format'] ==  '' )
					{
						$this->debug_output( '<b>NO torrent_format set please check your config file</b>' );
						exit;
					}
					
					$torrent['save_name'] = str_replace( '<id>', $id, $this->conf['torrent_format'] );
					$torrent['save_name'] = str_replace( '<date>', $time, $torrent['save_name'] );
					$torrent['save_name'] = str_replace( '<info_hash>', $torrent['info_hash'], $torrent['save_name'] );
					$torrent['save_name'] = str_replace( '<torrent_name>', $torrent['torrent_name'], $torrent['save_name'] );
					
					//-----------------------------------------
					// Save the torrent in torrent directory
					//-----------------------------------------
					
					$file_put =  fopen( $this->conf['torrent_dir'] . $torrent['info_hash'] . '.btf', 'x' );
					$this->delete .= $tinfo.',';
					fwrite ( $file_put, $t['file'][2] );
					fclose ( $file_put );
					$this->delete .= $tinfo.',';
					$this->debug_output( ' ' );
					return;
				}
			}
			
			//-------------------------------------------------
			// oOps got tinfo but not torrent so lets update DB
			//-------------------------------------------------
			
			$this->debug_output( '<center>Cant get the .torrent</center>' );
			$this->failed .= $tinfo.', ';
			return;
		}

		//-----------------------------------------
		// Total failure, update DB 
		//-----------------------------------------
		
		$this->debug_output( '<center>Cant find the tinfo page :S</center>' );
		
		$this->failed .= $tinfo.', ';
		return;
	}

	/*-------------------------------------------------------------------------*/
	// Lock file function 
	/*-------------------------------------------------------------------------*/	
		
 function lock_file($pluggin, $cache )
	{
		//-----------------------------------------
		// Lock file to stop dupes and multiple
		// executions of script
		//-----------------------------------------

		$file = fopen( 'cached.php', w );
		$return = "<?php\n\n//-----------------------------------------\n// Cache file\n//-----------------------------------------\n\n";
		foreach( $pluggin as $k => $v )
		{
			$time = $cache['site'][ $k ]+1;
			$return .= '$cache[\'site\'][\''.$k.'\'] = ' . intval( $time ) . ";\n";
		}
		$query = $this->mysql_debug('SELECT COUNT(id) FROM un_processed') or die( mysql_error() );
		$count = mysql_fetch_array( $query );
		$return .= '$cache[\'unprocessed\'] = ' . intval( $count[0] ) . ";\n";
		$return .= '$cache[\'locked\'] = \'locked\';' . "\n";
		$return .= '$cache[\'lock_time\'] = ' . time() . ";\n";
		$return .= '?>';
		fwrite( $file, $return );
	}

}	
?>	
