<?php
/*
+--------------------------------------------------------------------------
|   IBITZY V 0.3 Beta
|   =============================================
|   Web: http://www.ipbtracker.eu/index.php?showforum=26
|	By: beeman
|	Created: 15/09/06
+---------------------------------------------------------------------------
|   > Its the index, wot else?
|	> Pluggin array for adding new pluggin files to execution
|	> Create global classes
|	> Process Torrents
|	> Rewrite Cache
+--------------------------------------------------------------------------
*/

//--------------------------------
// Require the files
//--------------------------------

require_once( 'conf.php' );
require_once( 'benc.php' );
require_once( 'class_spider.php' );
require_once( 'cached.php' );
require_once( 'scrape.php');
require_once( 'BDecode.php');


//--------------------------------
// Setup DB connection
//--------------------------------

$db = mysql_connect( $CONF['SERVER'],
					 $CONF['USER'],
					 $CONF['PASS']) 
					 or die( mysql_error() );
					 
$dbs = mysql_select_db($CONF['DB'],
					   $db) 
					   or die( mysql_error() );

//---------------------------------
// Plug it in?
// > Array for adding pluggin files
//---------------------------------
//============================================================================================
//  Usage Name => 'site' => 'sitename', 'source' => 'filename.php', 'class' => 'class name' ), 
//============================================================================================

$plugin_arr = array
( 'mininova' =>
 array('site' => 'mininova',  'source' => 'mininova.php', 'class' => 'mininova'), 'torrentspy' =>
 array('site' => 'torrentspy', 'source' => 'torrentspy.php', 'class' => 'torrentspy'), 'piratebay' =>
 array('site' => 'piratebay', 'source' => 'piratebay.php', 'class' => 'piratebay'),'torrentportal'=>
 array('site' => 'torrentportal', 'source' => 'torrentportal.php', 'class' => 'torrentportal'),'meganova' =>
 array('site' => 'meganova', 'source' => 'meganova.php', 'class' => 'meganova'),
);

//-----------------------------------------
// Check cache and unprocessed is more 
// than max unprocessed in conf
//-----------------------------------------

if ( $cache['unprocessed'] > $CONF['max_unprocessed'] )
{
	//-----------------------------------------
	// Prevent backlog of unprocessed torrents
	//-----------------------------------------
	$int['do'] = 0;
}
else 
{
	//-----------------------------------------
	// Check if torrents need processing
	//-----------------------------------------

	foreach ( $cache['site'] as $k => $v )
	{
		if( time() - $CONF['interval'] > $v )
		{
			$int['do'] =1;
			$int['spid'] = $k;
			$cache['site'][ $k ] = time();
			break;
		}
		else
		{
			$int['do'] = 0;
		}
	}
}

//-----------------------------------------
// They do so process site already
//-----------------------------------------

if ( $int['do'] == '1' )
{
	//-----------------------------------------
	// Check pluggins array and recache
	//-----------------------------------------
	if( !$plugin_arr[ $int['spid'] ] )
	{
		recache( $plugin_arr, $cache );
		exit;
	}
	if( !file_exists( 'pluggins/' . $plugin_arr[ $int['spid'] ]['source'] ) )
	{
		recache( $plugin_arr, $cache );
		exit;
	}
	
	//-----------------------------------------
	// If successful require pluggin file
	//-----------------------------------------	
	
	require_once( 'pluggins/' . $plugin_arr[ $int['spid'] ]['source'] );

	//--------------------------------
	// Setup global class
	//--------------------------------
	
	$spider = new spider;

	//--------------------------------
	// Load conf into new class
	//--------------------------------
	
	$spider->conf = $CONF;

	//--------------------------------
	// Load cache into new class
	//--------------------------------
	
	$spider->cache = $cache;
	
	//--------------------------------
	// Load pluggins into new class
	//--------------------------------	
	
	$spider->pluggin_arr = $plugin_arr;
	$spider->site = $int['spid']; 

	//--------------------------------
	// Load vars into class
	//--------------------------------
	
	$spider->vars = new $plugin_arr[ $int['spid'] ]['class'];
	
	//----------------------------------
	// Process site and data into class
	// Run cache
	//----------------------------------
	
	$spider->process_site();
	recache( $plugin_arr, $cache );
	
}
else 
{
//-----------------------------------------
// No need to process site so lets process
// data already and get torrents
//-----------------------------------------
	
	//--------------------------------
	// Setup global class
	//--------------------------------
	
	$spider = new spider;
	
	//--------------------------------
	// Load conf into class
	//--------------------------------
	
	$spider->conf = $CONF;

	//--------------------------------
	// Load pluggins into new class
	//--------------------------------	
	
	$spider->pluggin_arr = $plugin_arr;

	//--------------------------------
	// Load cache into new class
	//--------------------------------

	$spider->cache = $cache;

	//------------------------------------
	// Process torrents and cleanup cache
	//------------------------------------
	
	$spider->process();
	$spider->mysql_debug('UPDATE un_processed 
				  SET status=\'failed\' 
				  WHERE status=\'in_process\''
				 );
	recache( $plugin_arr, $cache );
}

//-----------------------------------------
// Close DB connection
//-----------------------------------------
@mysql_close($db);
exit;

/*-------------------------------------------------------------------------*/
// Rewrite cache function(cache.php)
/*-------------------------------------------------------------------------*/ 

function recache( $pluggin, $cache )
{
	global $CONF;
	$spider = new spider;
	$spider->conf = $CONF;
	$file = fopen ( 'cached.php', w );
	$return = "<?php\n\n//-----------------------------------------\n// Cache file\n//-----------------------------------------\n\n";
	foreach( $pluggin as $k => $v ) 
	{
		$time = $cache['site'][ $k ]+1;
		$return .= '$cache[\'site\'][\''.$k.'\'] = ' . $time . ";\n";
	}
	$query = $spider->mysql_debug('SELECT COUNT(id) FROM un_processed');
	$count = mysql_fetch_array( $query );
	$return .= '$cache[\'unprocessed\'] = ' . $count[0] . ";\n";
	$return .= '$cache[\'locked\'] = \'unlocked\';'."\n";
	$return .= '$cache[\'lock_time\'] = '.time().";\n";
	$return .= '?>';
	fwrite ( $file, $return );
}
?>
