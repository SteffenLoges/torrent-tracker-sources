/////////////////////////////////////////////////////////////////////////
//                              PK-TORRENTS                            //
//                   By Proxykill Based on torrenthoster               //
//                          Version PKT-0.1beta                        //
/////////////////////////////////////////////////////////////////////////
//                                                                     //
//Install Clean:                                                       //
// 1. Put all the files from the zip into a directory/root             //
//    on your server.                                                  //
//                                                                     //
// 1.1 Chmod all files to 777                                          //
//                                                                     //
// 2. Install database.sql onto your DB                                //
//                                                                     //
// 3. goto http://yoursite.com/install.php                             //
//                                                                     //
// 4. enter all required info then click install                       //
//                                                                     //
// 5. Login to the site using USR:admin PWD:admin12                    //
//                                                                     //
// 6. Change Your Admin password                                       //
//                                                                     //
// 7. DELETE install.php and database.sql                              //
//                                                                     //
// 8. Add torrent manualy or run ibitzy from admin                     //
/////////////////////////////////////////////////////////////////////////
//                                                                     //
//Bugs:                                                                //
// Let me know of ANY bugs ya find!!                                   //
// report them to the email below or on filesoup.                      //
/////////////////////////////////////////////////////////////////////////
//  Released 19thMar2007                     pktorrents@cherone.co.uk  //
///////////////////////////////////////////////////////////////////////// 