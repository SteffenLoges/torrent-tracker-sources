 <?
 $info="<center><h2>Please wait!</h2></center>";
 $info2="<center><p>This process may take upto <b>30seconds</b> but will redirect you back when complete!</p></center>";
 echo "$info";
 echo "$info2";
 ;?>
 <script type="text/javascript">
<!--
function delayer(){
    javascript:history.go(-1)
}
//-->
</script>
</head>
<body onLoad="setTimeout('delayer()', 500)">
</body>


<?

/*
I still need to make this one faster
If you know a way let me know
*/
//include ("./x/include/functions.php");

include ("config.php");
include ("./lib/getscrape.php");
include("$CFG->templatedir/header.php");
?>

<?

   require_login();


$result= db_query("SELECT * FROM namemap ORDER BY data ASC");

while($row= db_fetch_array($result))
{
extract ($row);
scrape(urldecode($announce_url),$info_hash);
echo "<br>$announce_url done<br>";

}


include("$CFG->templatedir/footer.php");

?>
