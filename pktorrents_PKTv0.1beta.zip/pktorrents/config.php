<?php
//////////////////////////////////////////////
//              PK-TORRENTS                 //
//   By Proxykill Based on torrenthoster    //
//          Version PKT-0.1beta             //
//////////////////////////////////////////////
/* check if file is being accessed directly */
if (eregi("config.php",$_SERVER['PHP_SELF']))
{
Header("Location: $CFG->wwwroot");
die();
}
//rename this file to config.php
  /* turn on verbose error reporting (15) to see all warnings and errors */
  error_reporting(15);

//include "forumdb.php";

  //define a generic object to hold all the configuration variables
  class object {};

  //declare an instance of the generic object
  $CFG = new object;
  //declare root directory
  $CFG->dirroot = dirname(__FILE__);

  //Edit This For TORRENT HOSTER Database
  //database configuration
  $CFG->host = "localhost";
  $CFG->dbName = "";
  $CFG->dbUserName = "";
  $CFG->dbPassword = "";



/* directory configuration, if all your files are in one directory
 * you probably only need to set the wwwroot variable.  valid examples are:
 *
 * $CFG->wwwroot = "http://myserver.com/webtorrent";
 * $CFG->wwwroot = "http://localhost/webtorrent";
 * $CFG->wwwroot = "http://myserver.com";
 *
 * do not include the trailing slash. dirroot is the physical path on your
 * server where the application can find it's files. for more security, it is
 * recommended that you move the libraries and templates (
 * and ) outside of your web directories.
 */


  /* Edit below this */

  $CFG->wwwroot      = "http://yoursite.com";
  $CFG->forumroot    = "http://yoursite.com/forum";
  $CFG->webname      = "PK-Torrents";
  $CFG->support      = "pktorrents[at]cherone dot co dot uk"; //shows in COPYRIGHT page
  $CFG->rssnum       = "25"; //number of rss to show
  $CFG->mainnews     = "10"; //number of news on the main page, use 0 to not print news on main page
  $CFG->maintorrents = "50";//number of torrents in the main page
  $CFG->torrents     = "$CFG->dirroot/torrents"; //torrent folder repect to your wwwroot
  $CFG->usesub	      = "no"; //Do you want to use Subcategories? "yes" or "no"
  $CFG->usephpbb    = "no"; //put "yes" if you want to connect with phpbb users. "yes" or "no"
  $CFG->regdownload  = "no"; //only registered users can download torrents. "yes" or "no"
  $CFG->regupload    = "no"; //only registered users can upload torrents. "yes" or "no"

  //////////////////////////////////////////////////
  //              --LAYOUT OPTIONS--              //
  //////////////////////////////////////////////////
  // A good place to find out if your             //
  // colours will work good together is @         //
  // http://slayeroffice.com/tools/color_palette  //
  //////////////////////////////////////////////////
  //MAIN
   $CFG->bgcolour           = "#000000";
   $CFG->maincolour         = "#262626";
   $CFG->mainfont           = "Trebuchet MS, Arial, Helvetica, sans-serif";
   $CFG->mainfontsize       = "10pt";
   $CFG->mainfontweight     = "bolder";
   $CFG->searchboxtxtcolour = "#EBB80C";
   //
   //BODY
   $CFG->bodycolour   = "#EBB80C";
   $CFG->bodyborder   = "#ffffff";
   //
   //HEADINGS
   //h1, h2, h3, h4, h5, h6
    $CFG->headingcolour      = "#EBB80C";
    $CFG->headingfontweight  = "bold";
   //
   //BOX h3
   $CFG->boxhead3bgcolour  = "#CCCCCC";
   $CFG->boxhead3colour    = "#FFFFFF";
   //
   //BOX h4
   $CFG->boxhead4bgcolour  = "#404040";
   $CFG->boxhead4colour    = "#FFFFFF";
   //
   //CONTENT h3, h1
   $CFG->contentcolour     = "#000000";
   //
   //NAV BAR
   $CFG->navcolour          = "#EBB80C";
   $CFG->navbgcolour        = "#EBB80C";
   //NAV CAT
   //
   $CFG->navcatcolour       = "#EBB80C";
   $CFG->navcatbgcolour     = "#EBB80C";
   //
   //FORM IMPUTS
   $CFG->buttonbgcolour      = "#EBB80C";
   $CFG->buttontxtcolour     = "#000000";
   $CFG->buttonbordercolour  = "#000000";
   $CFG->imputcolour = $CFG->buttonbgcolour;
   //
   //LINK STYLES
   $CFG->linkcolour      = "silver";
   $CFG->linkhover       = "#EBB80C";
   $CFG->linkdecor       = "underline";
   //
   //WARNINGS
   $CFG->warnings = "0000CC";
   /////////////////////////////////
   //PAGE LAYOUT                  //
   // Menu Left OR right,         //
   // make sure there opposit     //
   $CFG->layoutmenu = "left";     //
   $CFG->layoutcontent = "right"; //
   /////////////////////////////////

   //Code For admin Stats
   function sitestats (){
define("_BBCLONE_DIR", "./bbclone/");
define("COUNTER", _BBCLONE_DIR."mark_page.php");
if (is_readable(COUNTER)) include_once(COUNTER);
   }


  /*
      nothing to change below this (i think)
  */

  $CFG->templatedir  = "$CFG->dirroot/templates";
  $CFG->libdir       = "$CFG->dirroot/lib";
  $CFG->imagedir     = "$CFG->wwwroot/images";
  $CFG->health       = "$CFG->wwwroot/health";
  $CFG->icondir      = "$CFG->imagedir/icons";
  $CFG->version      = "PKT-0.1beta";

  //$CFG->sessionname = " ";

  /* define database error handling behavior, since we are in development stages
  * we will turn on all the debugging messages to help us troubleshoot */
  $DB_DEBUG = true;
  $DB_DIE_ON_FAIL = true;


  //start session to hold username and password when linking from page to page
  session_start();
  header("Cache-control: private"); // IE 6 Bug Fix.

  //load up libraries
  require "lib/dblib.php";
  require "lib/stdlib.php";
  require "lib/webtorrent.php";

  /* setup some global variables */
  $ME = qualified_me();

  /* connect to the database */
  db_connect($CFG->host, $CFG->dbName, $CFG->dbUserName, $CFG->dbPassword);

/*
  	Print out header
  *******************************************/
  function stheader($title)
  {//stheader from t-xore not used in this version
  }

// Get microtime
function get_micro_time()
{
  list($usec, $sec) = explode(' ', microtime());
  return ((float)$usec + (float)$sec);
}
//connect db if using edit user in members area
function connect_forum($fdbhost, $fdbuser, $fdbpass, $fdatabase)
{
$errormes = 'The sql server has encountered a problem, we are trying to fix it as soon as possible';
@$connection = mysql_connect($fdbhost, $fdbuser, $fdbpass);
@mysql_select_db($fdatabase) or die($errormes);
}
//get torrent size for stats
function torsize ($size)
{
if ($size >= 1099511627776) 	{$size = round($size / 1024 / 1024 / 1024 / 1024, 2).' TerraBytes';}
elseif ($size >= 1073741824) 	{$size = round($size / 1024 / 1024 / 1024, 2).' GiggaBytes';}
elseif ($size >= 1048576) 	{$size = round($size / 1024 / 1024, 2).' MegaBytes';}
elseif ($size >= 1024) 		{$size = round($size / 1024, 2).' KillerBytes';}
else 				{$size = $size.' Bytes';}
return $size;
}



// show files contained in a torrent
function showfiles($hash)
{
$filename2 = $hash;
//global $CFG->torrents;
include_once("lib/BDecode.php") ;
include_once("lib/BEncode.php") ;
include_once("config.php") ;

$filename = "torrents/$filename2.btf";

$stream = @file_get_contents("$filename");


if ($stream == FALSE)
{
echo 'No details availiable... 1 ';
}
if(!isset($stream))
{
echo 'No details availiable... 2 ';
break;
}
else
{

$array = BDecode($stream);
if ($array === FALSE)

{
echo 'No details availiable... 3 ';
break;
}
else
{
if(array_key_exists("info", $array) === FALSE){
echo 'No details availiable... 4 ';
break;
}
else
{
$infovariable = $array["info"];
if (isset($infovariable["files"]))
{

$filecount = "";
foreach ($infovariable["files"] as $file)
{

$row_color = ($row_count % 2) ? $color1 : $color2;

$filecount += "1";
$multiname = $file['path'];
$multitorrentsize = torsize ($file['length']);
$torrentsize += $file['length'];
$combinedsize = torsize($torrentsize);
$strname = strip_tags ($multiname[0]);

$strname = htmlentities($strname);
$strname = strip_tags($strname);

echo "<tr><td width=\"50%\">$strname</td><td> $multitorrentsize</td></tr>";
$row_count++;
}
}
else
{
$singletf = $infovariable['name'] ;
$singletf  = strip_tags($singletf );
$torrentsize = torsize($infovariable['length']);

$singletf = htmlentities($singletf);
$singletf = strip_tags($singletf);

echo "<tr><td width=\"50%\">$torrentsize</td><td> $singletf</td></tr>";
}
}
}
}
}

function showfiles_small($hash)
{
$filename2 = $hash;
//global $CFG->torrents;
include_once("lib/BDecode.php") ;
include_once("lib/BEncode.php") ;
include_once("config.php") ;

$filename = "torrents/$filename2.btf";

$stream = @file_get_contents("$filename");


if ($stream == FALSE)
{
echo 'No details availiable... 1 ';
}
if(!isset($stream))
{
echo 'No details availiable... 2 ';
break;
}
else
{

$array = BDecode($stream);
if ($array === FALSE)

{
echo 'No details availiable... 3 ';
break;
}
else
{
if(array_key_exists("info", $array) === FALSE){
echo 'No details availiable... 4 ';
break;
}
else
{
$infovariable = $array["info"];
if (isset($infovariable["files"]))
{

$filecount = "";
foreach ($infovariable["files"] as $file)
{

$row_color = ($row_count % 2) ? $color1 : $color2;

$filecount += "1";
$multiname = $file['path'];
$multitorrentsize = torsize ($file['length']);
$torrentsize += $file['length'];
$combinedsize = torsize($torrentsize);
$strname = strip_tags ($multiname[0]);

$strname = htmlentities($strname);
$strname = strip_tags($strname);

echo "<tr>$strname</tr>";
$row_count++;
}
}
else
{
$singletf = $infovariable['name'] ;
$singletf  = strip_tags($singletf );
$torrentsize = torsize($infovariable['length']);

$singletf = htmlentities($singletf);
$singletf = strip_tags($singletf);

echo "<tr>$singletf</tr>";
}
}
}
}
}
?>
