// ----------------------------------------------------------------------------
// markItUp!
// ----------------------------------------------------------------------------
// Copyright (C) 2008 Jay Salvat
// http://markitup.jaysalvat.com/
// ----------------------------------------------------------------------------
// BBCode tags example
// http://en.wikipedia.org/wiki/Bbcode
// ----------------------------------------------------------------------------
// Feel free to add more tags
// ----------------------------------------------------------------------------
mySettings = {
	nameSpace:          "bbcode", // Useful to prevent multi-instances CSS conflict
	previewParserPath:	'~/preview.php', // path to your BBCode parser
	markupSet: [
		{name:'Bold', key:'B', openWith:'[b]', closeWith:'[/b]'},
		{name:'Italic', key:'I', openWith:'[i]', closeWith:'[/i]'},
		{name:'Underline', key:'U', openWith:'[u]', closeWith:'[/u]'},
		{separator:'---------------' },
		{name:'Left', openWith:'[align=left]', closeWith:'[/align]'},
		{name:'Center', openWith:'[align=center]', closeWith:'[/align]'},
		{name:'Right', openWith:'[align=right]', closeWith:'[/align]'},
		{separator:'---------------' },
		{name:'Picture', key:'P', replaceWith:'[img][![Url]!][/img]'},
		{name:'Link', key:'L', openWith:'[url=[![Url]!]]', closeWith:'[/url]',placeHolder:"Link Name"},
		{separator:'---------------' },
		{name:'Fonts', key:'F', openWith:'[font=[![Text Font]!]]', closeWith:'[/font]',
		dropMenu :[
			{name:'Arial', openWith:'[font=arial]', closeWith:'[/font]' },
			{name:'Arial black', openWith:'[font=arial black]', closeWith:'[/font]' },
			{name:'Arial narrow', openWith:'[font=arial narrow]', closeWith:'[/font]' },
			{name:'Book antiqua', openWith:'[font=book antiqua]', closeWith:'[/font]' },
			{name:'Century gothic', openWith:'[font=century gothic]', closeWith:'[/font]' },
			{name:'Comic sans ms', openWith:'[font=comic sans ms]', closeWith:'[/font]' },
			{name:'Courier new', openWith:'[font=courier new]', closeWith:'[/font]' },
			{name:'Fixedsys', openWith:'[font=fixedsys]', closeWith:'[/font]' },
			{name:'Garamond', openWith:'[font=garamond]', closeWith:'[/font]' },
			{name:'Georgia', openWith:'[font=georgia]', closeWith:'[/font]' },
			{name:'Impact', openWith:'[font=impact]', closeWith:'[/font]' },
			{name:'Lucida console', openWith:'[font=lucida console]', closeWith:'[/font]' },
			{name:'Lucida sans unicode', openWith:'[font=lucida sans unicode]', closeWith:'[/font]' },
			{name:'Microsoft sans serif', openWith:'[font=microsoft sans serif]', closeWith:'[/font]' },
			{name:'Palatino linotype', openWith:'[font=palatino linotype]', closeWith:'[/font]' },
			{name:'System', openWith:'[font=system]', closeWith:'[/font]' },
			{name:'Tahoma', openWith:'[font=tahoma]', closeWith:'[/font]' },
			{name:'Times new roman', openWith:'[font=times new roman]', closeWith:'[/font]' },
			{name:'Trebuchet ms', openWith:'[font=trebuchet ms]', closeWith:'[/font]' },
			{name:'Verdana', openWith:'[font=verdana]', closeWith:'[/font]' }
		]},
		
		{name:'Size', key:'S', openWith:'[size=[![Text size]!]]', closeWith:'[/size]',
		dropMenu :[
			{name:'Size 1', openWith:'[size=1]', closeWith:'[/size]' },
			{name:'Size 2', openWith:'[size=2]', closeWith:'[/size]' },
			{name:'Size 3', openWith:'[size=3]', closeWith:'[/size]' },
			{name:'Size 4', openWith:'[size=4]', closeWith:'[/size]' },
			{name:'Size 5', openWith:'[size=5]', closeWith:'[/size]' },
			{name:'Size 6', openWith:'[size=6]', closeWith:'[/size]' },
			{name:'Size 7', openWith:'[size=7]', closeWith:'[/size]' }
		]},
		{name:'Stroke', key:'D', openWith:'[del]', closeWith:'[/del]'},
		{name:'Colors', openWith:'[color=[![Color]!]]', closeWith:'[/color]', 
		dropMenu: [
				{name:'Yellow', openWith:'[color=yellow]', closeWith:'[/color]', className:"col1-1" },
				{name:'Orange', openWith:'[color=orange]', closeWith:'[/color]', className:"col1-2" },
				{name:'Red', openWith:'[color=red]', closeWith:'[/color]', className:"col1-3" },
				{name:'Blue', openWith:'[color=blue]', closeWith:'[/color]', className:"col2-1" },
				{name:'Purple', openWith:'[color=purple]', closeWith:'[/color]', className:"col2-2" },
				{name:'Green', openWith:'[color=green]', closeWith:'[/color]', className:"col2-3" },
				{name:'White', openWith:'[color=white]', closeWith:'[/color]', className:"col3-1" },
				{name:'Gray', openWith:'[color=gray]', closeWith:'[/color]', className:"col3-2" },
				{name:'Black', openWith:'[color=black]', closeWith:'[/color]', className:"col3-3" }
		]},
		
		{separator:'---------------' },
		{name:'Bulleted list', openWith:'[list]\n', closeWith:'\n[/list]'},
		{name:'Numeric list', openWith:'[list=[![Starting number]!]]\n', closeWith:'\n[/list]'}, 
		{name:'List item', openWith:'[*] '},
		{separator:'---------------' },
		{name:'Quotes', openWith:'[quote]', closeWith:'[/quote]'},
		{name:'Youtube', openWith:'[youtube]', closeWith:'[/youtube]'},
		{separator:'---------------' },
		{name:'Preview', className:"preview", call:'preview' }
	]
}

