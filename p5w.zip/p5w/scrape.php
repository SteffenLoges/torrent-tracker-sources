<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/benc.php");
require_once("inc/config.php");
# Connect Database
function dbconn()
{
    global $mysql_host, $mysql_user, $mysql_pass, $mysql_db, $dbconn;

    $dbconn = mysql_connect($mysql_host, $mysql_user, $mysql_pass);

    mysql_select_db($mysql_db) or die('dbconn: mysql_select_db: ' + mysql_error());

  register_shutdown_function("dbclose");
} 

# Close Database
function dbclose()
{
global $dbconn;
  if($dbconn){
	 mysql_close($dbconn);
	}
}

# ERROR MESSAGE
function err($msg)
{
    benc_resp(array("failure reason" => array("type" => "string", "value" => $msg)));
    die();
}



 if(isset($_GET["userkey"])){$userkey=htmlchar($_GET["userkey"]);}else{$userkey="";}
 if(isset($_GET["info_hash"])){$info_hash=htmlchar($_GET["info_hash"],0);}else{$info_hash="";}

 $info_hashmd5 = md5($info_hash);

 $user = apc_fetch("us_$userkey");
 $torrent = apc_fetch("tor_$info_hashmd5");

 if(!$info_hash || strlen($info_hash) != 20){
      err("Ungültige Info Hash");
    }

 if(!$user){
      err("Ungültige Userkey");
    }

 if(!$torrent){
      err("Torrent Existiert Nicht");
    }

 dbconn();

 $res = mysql_query("SELECT info_hash, seeders, leechers, times_completed FROM torrents WHERE tid = " . $torrent["tid"]);

 $row = mysql_fetch_row($res);

    $sendclires = "d" . benc_str("files") . "d";

		$sendclires .= "20:" . str_pad($row[0], 20) . "d" .
			benc_str("complete") . "i" . $row[1] . "e" .
			benc_str("downloaded") . "i" . $row[3] . "e" .
			benc_str("incomplete") . "i" . $row[2] . "e" .
			"e";
	
    $sendclires .= "ee";

    header("Content-Type: text/plain");
    header("Pragma: no-cache");
    echo $sendclires;


?>