<?php
require_once("inc/func.php");
dbconn();
  title(btlng516,btlng517);

  mkglobal("uid","int");
  mkglobal("act:email:secret:save:passwd:passwd2");

?>
    <script>
    function pact(act){
	$.get("<?php echo $GLOBALS["BASEURL"];?>/recover.php", 
		{ act: act, email: $('#email').val(), secret: '<?php echo $secret;?>', uid: '<?php echo $uid;?>', save: "pass", passwd: $('#passwd').val(), passwd2: $('#passwd2').val() }, function(data){
		  $("#info").html(data);
		});

    }
    </script>
<?php

 if($act=="sendmail"){

	    if(!$email){
		infoerr(btlng520);
	      }

	      $res = mysql_query("SELECT uid, passhash, email FROM users WHERE email=" . sqlesc($email) . " LIMIT 1") or sqlerr(__FILE__, __LINE__);
	      $arr = mysql_fetch_row($res);
	  
	      if(!$arr[0]){
		infoerr(str_replace("%email%",$email,btlng521));
		}

		$sec = mksecret();

		mysql_query("UPDATE users SET editsecret=" . sqlesc($sec) . ", editsecrettime = ".sqlesc($time)." WHERE uid=" . $arr[0])  or sqlerr(__FILE__, __LINE__);

		if(!mysql_affected_rows()){
		      errmsg(btlng32,btlng522);
		    }

		$hash = md5($sec . $email . $arr[1] . $sec);

		$url = $GLOBALS["BASEURL"]."/#recover?act=change&uid=".$arr[0]."&secret=$hash";

		$body = str_replace(array("%email%","%ip%","%url%"),array($email,getip(),$url),btlng523);

		mail($arr[2], $GLOBALS["SITENAME"]." ".btlng524, $body, "From: ".$GLOBALS["SITEEMAIL"]) or errmsg(btlng32,btlng525);

		okmsg(btlng32_2,str_replace("%email%",$email,btlng526));

  }

  elseif($act=="change"){


    if(!is_valid_id($uid)){
	errmsg(btlng32,btlng485);
      }
	
	$res = mysql_query("SELECT uid, username, email, passhash, editsecret FROM users WHERE uid = ".sqlesc($uid));
	$arr = mysql_fetch_row($res) or sqlerr(__FILE__, __LINE__);

	$usid = $arr[0];
	$username = $arr[1];
	$email = $arr[2];
	$passhash = $arr[3];
	$editsecret = $arr[4];

	$sec = $editsecret;

	$sec2 = hash_pad($editsecret);

	if(preg_match('/^ *$/s', $sec2)){
	      errmsg(btlng32,btlng527);
	  }

	  if($secret != md5($sec . $email . $passhash . $sec)){
	      errmsg(btlng32,btlng527);
	    }

      if($save == "pass"){

	      if(!$passwd){
		   infoerr(btlng15);
		}

		if($passwd != $passwd2){
		infoerr(btlng17);
		}

		if(strlen($passwd) < 6){
		infoerr(btlng18);
		}

		if(strlen($passwd) > 40){
		infoerr(btlng19);
		}

		    $passsec = mksecret();
		    $newpasshash = md5($passsec . $passwd . $passsec);
		    mysql_query("UPDATE users SET secret=" . sqlesc($passsec) . ", editsecret='', editsecrettime='', passhash=" . sqlesc($newpasshash) . " WHERE uid=$usid AND editsecret=" . sqlesc($editsecret));

		if(!mysql_affected_rows()){
			errmsg(btlng32,btlng522);
		    }

		    okmsg(btlng32_2,btlng528);

	 }
		else{
			?>
			<br>
			<div class="shadow recovertable" style="width:500px;">
			    <div class="table">
				<div class="tr">
				    <div class="td"><?php echo "<br><b>".btlng7."</b><br>";?></div><div class="td"><br><input type="password" size="30" id="passwd" name="email"><br><br></div>
				</div>
				<div class="tr recpasswd">
				    <div class="td"><?php echo "<br><b>".btlng8."</b><br>";?></div><div class="td"><br><input type="password" size="30" id="passwd2" name="email"><br><br></div>
				</div>
			    </div>
				    <center class="recpasswd"><br><a href="javascript:pact('change');" id="recpasswd" class="buttonsilver"><?php echo btlng529;?></a><br><br></center>
			</div>
			  <?php
		}

   }

  else{
?> 

  <br>

<div class="shadow recovertable">
	    <p><center><?php echo btlng518;?></center></p>
    <div class="table">
	<div class="tr recpasswd">
	    <div class="td"><?php echo "<br>".btlng519."<br>";?></div><div class="td"><br><input type="text" size="40" id="email" name="email"><br><br></div>
	</div>
    </div>
	    <center class="recpasswd"><br><a href="javascript:pact('sendmail');" id="recpasswd" class="buttonsilver"><?php echo btlng516;?></a><br><br></center>
</div>

<?php
  }
?>
