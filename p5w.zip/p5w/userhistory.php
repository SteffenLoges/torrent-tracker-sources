<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();


if(isset($_GET["uid"])){$uid = 0+$_GET["uid"];}else{$uid=0;}
if(isset($_GET["act"])){$act=$_GET["act"];}else{$act="";}
if(isset($_GET["pno"])){$page=0+$_GET["pno"];}else{$page=1;}
$perpage=$GLOBALS["USERHISTORY_PER_PAGE"];

if (get_user_class() < UC_POWER_USER || ($CURUSER["uid"] != $uid && get_user_class() < UC_MODERATOR)){
    errmsg(btlng32,btlng26_2);
}

?>
<script type="text/javascript" src="/js/jquery.pager.js"></script>
<?php

if($act == "viewcomments") {

    $query = "SELECT COUNT(*) FROM comments AS c LEFT JOIN torrents as t ON c.tid = t.tid WHERE c.cuid = ".sqlesc($uid)." ORDER BY c.comid DESC";
    $res = mysql_query($query) or sqlerr(__FILE__, __LINE__);
    $arr = mysql_fetch_row($res);

    if(!$arr){
	  errmsg(btlng32,btlng162);
      }

      $pages = ceil($arr[0] / $perpage);

		    if($page > $pages){
			    $page=$pages;
			    }else{
				$page=$page;
				}


			    $start = ($page - 1) * $perpage;
			    $start = " LIMIT $start, $perpage ";

?>
<script>

        PageClick = function(pageclickednumber) {
            $("#pager").pager({ pagenumber: pageclickednumber, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
		$.get("<?php echo $GLOBALS["BASEURL"];?>/userhistory.php", { act: "<?php echo $act;?>", pno: pageclickednumber, uid: "<?php echo $uid;?>"},
   		function(data){
    		 $('#comres').html(data);

   		});
        }

  $("#pager").pager({ pagenumber: <?php echo $page;?>, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
</script>
<?php

   // ------ Get user data
	  $udatares = mysql_query("SELECT username FROM users WHERE uid=".sqlesc($uid)) or sqlerr(__FILE__, __LINE__);

        $udatarow = mysql_fetch_row($udatares);
	title(btlng163,$udatarow[0]." ".btlng163);

    $query = "SELECT t.name, c.tid , c.comid, c.added, c.text, u.avatar FROM comments AS c LEFT JOIN torrents as t ON c.tid = t.tid LEFT JOIN users as u ON c.cuid = u.uid WHERE c.cuid = ".sqlesc($uid)." ORDER BY c.comid DESC $start";
    $res = mysql_query($query) or sqlerr(__FILE__, __LINE__);

    echo "<br><div id=\"pager\"></div>
          <div id=\"comres\"><br><br>
          <br><div class=\"userdetails\"><br>";

    while($arr = mysql_fetch_row($res)) {

        $torrentname = $arr[0];
	$comm_tid=$arr[1];
        $commentid = $arr[2];
	$cadded=gdate($arr[3]);
	$ctext=format_comment($arr[4]);
	$uavatar=$arr[5];
 

        if(strlen($torrentname) > 64){ $torrentname = substr($torrentname, 0, 62) . "...";}


        $subres = mysql_query("SELECT COUNT(*) FROM comments WHERE tid = $comm_tid AND comid <= $commentid")or sqlerr(__FILE__, __LINE__);
        $subrow = mysql_fetch_row($subres);
	$count = $subrow[0];
        $comm_page = ceil($count / $GLOBALS["COMMENTS_PERPAGE"]);
        $page_url = $comm_page?"&pno=$comm_page":"";


      if($torrentname){
       $torrent="#$commentid <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$comm_tid".$page_url."#com$commentid\">$torrentname</a>";
      }else{
	    $torrent=btlng168;
	    }

      if($uavatar){
	$avatarsrc=htmlchar($uavatar);
	}else{
	      $avatarsrc="images/default_avatar.png";
	      }

      echo "<div id=\"c$commentid\"><div class=\"tablemsg\" style=\"width:720px;margin: 6px auto;\">
	    <div class=\"trmsgreadtit\"><div class=\"tdmsgread\">$torrent</b></div></div>

            <div class=\"tr\"><div class=\"tdmsgread\"><img class=\"imgborder\" style=\"width: 60px;\" src=\"$avatarsrc\"></div></div>
            <div class=\"tr\"><div class=\"tdmsgread\"><b>".btlng115." : </b> $cadded</div></div>
	    <div class=\"tr\"><div class=\"tdmsgread\">$ctext</div></div>

           </div></div>\n";
   }
}else{

    errmsg(btlng32,btlng169);

}

  echo "</div></div><br></div>";


?> 