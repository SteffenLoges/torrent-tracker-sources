<?php
require_once("inc/func.php");
dbconn();
if($CURUSER){
   $langst = btlng530;
  }else{
      $langst =  "Style";
  }

  title($langst,$langst);

  mkglobal("style");

  if($style){
          setcookie("p5w_csstyle", $style, 0x7fffffff, "/");
	  go_to("style");
    }

?> 
<br>
<div class="shadow">
<center><p>
<a href="<?php echo $GLOBALS["BASEURL"];?>/#style?style=default"><img src="/images/default.png" title="Default"></a>
</p></center>
</div>