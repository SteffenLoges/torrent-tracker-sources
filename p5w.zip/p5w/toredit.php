<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

 $alang="";$slang="";

 if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}

 if(!$tid){
	  errmsg(btlng32,btlng295);
     }

 $sqlcatsaud="";
 $sqlcatssub="";
  foreach($torrentlang as $key => $val){
     $sqlcatsaud .= ",torrents.audlang_$key ";
     $sqlcatssub .= ",torrents.sublang_$key ";
  }

 $restor = mysql_query("SELECT torrents.tid, torrents.toruid, torrents.catid, torrents.name, torrents.descr, torrents.seedspeed $sqlcatsaud $sqlcatssub, torrents.activated, 
			    torrents.banned, torrents.visible, torrents.vip, users.class FROM torrents LEFT JOIN users ON torrents.toruid=users.uid WHERE torrents.tid = ".sqlesc($tid));

 $rowtor = mysql_fetch_row($restor);

 if(!$rowtor){
	  errmsg(btlng32,btlng295);
     }

 $ti=0;

 $tid=$rowtor[$ti++];
 $tuid=$rowtor[$ti++];
 $tcatid=$rowtor[$ti++];
 $tname=$rowtor[$ti++];
 $descr=$rowtor[$ti++];
 $seedspeed=$rowtor[$ti++];

		$audimg = "";
		$subimg = "";
            
		foreach($torrentlang as $key => $val){
                       $alang["$key"]=$rowtor[$ti];
		  $ti++;
		}


		foreach($torrentlang as $key => $val){
	                       $slang["$key"]=$rowtor[$ti];
		  $ti++;
		}

 $activated=$rowtor[$ti++];
 $banned=$rowtor[$ti++];
 $visible=$rowtor[$ti++];
 $vip=$rowtor[$ti++];
 $userclass=$rowtor[$ti++];



 if(!isset($CURUSER) || !($CURUSER["uid"] == $tuid || get_user_class() >= UC_MODERATOR || (!$activated && get_user_class() == UC_GUTEAM && $userclass < UC_UPLOADER))) {
    	  errmsg(btlng32,btlng405);
 }


 title($tname." ".btlng389,$tname." ".btlng389);

?>
<script type="text/javascript" src="js/jquery.upload.js"></script>
<script>
    $(function() {
        $('#savetedit').click(function() {
            $('#files').upload('<?php echo $GLOBALS["BASEURL"];?>/toreditt.php', function(res) {
	    $('#info').html(res);
	      window.location.replace("<?php echo $GLOBALS["BASEURL"]."/#details?tid=$tid";?>");
            }, 'html');
        });
    });
  </script>
<?php

 echo "<br><div id=\"files\"><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\" id=\"toredit_td2\">";
# NAME
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng404."</b></div> <div class=\"td\" id=\"toredit_td2\">
		<input name=\"torname\" type=\"text\" value=\"".$tname."\" size=\"64\">
                <input type=\"hidden\" name=\"tid\" value=\"$tid\">
          </div>\n
         </div>\n";

# NFO
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng406."</b></div> 
	    <div class=\"td\" id=\"toredit_td2\"><input name=\"nfo\" type=\"file\" value=\"".$tname."\" size=\"46\"> <a href=\"".$GLOBALS["BASEURL"]."/#viewnfo?tid=$tid\" style=\"padding-left:50px;\"><img src=\"$stylelink/view.png\"></a>
	    </div>\n
         </div>\n";


# PICTURES
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng406_2."</b></div> <div class=\"td\" id=\"toredit_td2\">
                <input type=\"checkbox\" name=\"picchange\" value=\"1\"/> ".btlng419."<br><br>

	      <input type=\"file\" name=\"pic1\" size=\"46\">"; 
	    if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/$tid-1-f.jpg")){
		  echo "<script type=\"text/javascript\" src=\"/min/?b=js&amp;f=FancyZoomHTML.js,FancyZoom.js\"></script>
			<script>setupZoom();</script>
	         &nbsp;&nbsp; &nbsp;&nbsp; <a href=\"".$GLOBALS["BASEURL"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/$tid-1-f.jpg\" title=\"$tname\"><img src=\"$stylelink/view.png\"></a>";
	      }

          echo "<br><br><div class=\"divbottom\"></div><br><input type=\"file\" name=\"pic2\" size=\"46\">"; 
	    if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/$tid-2-f.jpg")){
	         echo " &nbsp;&nbsp; &nbsp;&nbsp; <a href=\"".$GLOBALS["BASEURL"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/$tid-2-f.jpg\" title=\"$tname\"><img src=\"$stylelink/view.png\"></a>";
	      }
       echo "</div>\n
         </div>\n";







 $audcheckbox="";
 $subcheckbox="";

  foreach($torrentlang as $key => $val){
    if($alang["$key"]){
      $achk=" checked=\"checked\"";
      }else{$achk="";}

    if($slang["$key"]){
      $schk=" checked=\"checked\"";
      }else{$schk="";}

  $audcheckbox .= "<input name=\"alang_$key\" value=\"$key\" type=\"checkbox\"$achk> <img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\"> $val\n";
  $subcheckbox .= "<input name=\"slang_$key\" value=\"$key\" type=\"checkbox\"$schk> <img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\"> $val\n";
  }


# AUDIO CHECKBOX
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng407."</b></div> <div class=\"td\" id=\"toredit_td2\">$audcheckbox</div>\n
         </div>\n";


# SUBTITLE CHECKBOX
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng408."</b></div> <div class=\"td\" id=\"toredit_td2\">$subcheckbox</div>\n
         </div>\n";


# DESCR
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng409."</b></div> <div class=\"td\" id=\"toredit_td2\">";
           echo editor(htmlchar($descr),"",600,87);
         echo "</div></div>\n";


# CATEGORY
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng275."</b></div> <div class=\"td\" id=\"toredit_td2\">
	      <select name=\"cat\">";

	    $rescat=mysql_query("SELECT cid,name FROM categories ORDER BY name");
	    while ($rowcat = mysql_fetch_row($rescat)) {
	        if($rowcat["0"]==$tcatid){
                   $catchk=" selected=\"selected\"";
		  }else{$catchk="";}
	    echo "<option$catchk value=\"".$rowcat["0"]."\">".htmlchar($rowcat["1"])."</option>";
	    }

      echo "</select></div>\n
         </div>\n";


# VISIBLE
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng410."</b></div> <div class=\"td\" id=\"toredit_td2\">
	      <input type=\"checkbox\" name=\"visible\"" . (($visible) ? " checked=\"checked\"" : "" ) ." value=\"1\"/> ".btlng412."
		<br><br>".btlng411."</div>\n
         </div>\n";


  if(get_user_class() >= UC_MODERATOR){

# BANNNED
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng413."</b></div> <div class=\"td\" id=\"toredit_td2\">
	      <input type=\"checkbox\" name=\"banned\"" . (($banned) ? " checked=\"checked\"" : "" ) . " value=\"1\" /> ".btlng414."
		 </div>\n
         </div>\n";
   
# BANNNED
    echo "<div class=\"tr\" id=\"toredit_tr\">
           <div class=\"td\" id=\"toredit_td1\"><b>".btlng415."</b></div> <div class=\"td\" id=\"toredit_td2\">
	      <input type=\"checkbox\" name=\"vip\"" . (($vip) ? " checked=\"checked\"" : "" ) . " value=\"1\" /> ".btlng416."
		 </div>\n
         </div>\n";

  }





 echo "</div>
         <center><br><a href=\"javascript:;\" id=\"savetedit\" class=\"buttonsilver\">".btlng204."</a><br><br></center>
    </div></div>";



?> 