<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

$maxfilesize = $GLOBALS["MAX_XIMGDEPOT_UPLOAD_SIZE"]; echo "1";// Do Not Delete This ECHO

 if(isset($_POST["avatar"])){$avatar=1;}else{$avatar="";}
 if(isset($_POST["public"])){$public=1;}else{$public=0;}


 if($CURUSER["class"]>=UC_UPLOADER) {
    $max_imgdepotsize = $GLOBALS["MAX_XIMGDEPOT_SIZE_UPLOADER"];
 } else {
    $max_imgdepotsize = $GLOBALS["MAX_XIMGDEPOT_SIZE_USER"];
  }

 $image=$_FILES["imgfile"];

 $imgext = strtolower(fext($image["name"]));
 $newimgname = md5($CURUSER["uid"].$image["name"]).".$imgext";
 $orgname=htmlchar($image["name"]);

# CHECK IMAGE NAME AND SIZE
   if(!isset($image["name"]) || $image["size"] < 1){
      infoerr(btlng377);
    }

 $imgtype = exif_imagetype($image["tmp_name"]);

# CHECK IMAGE TYPE
   if($imgtype != IMAGETYPE_GIF && $imgtype != IMAGETYPE_JPEG && $imgtype != IMAGETYPE_PNG){
		infoerr(btlng378);
           }

      if($imgext != "png" && $imgext != "jpg" && $imgext != "jpeg" && $imgext != "gif"){
		    infoerr(btlng381.$imgext);
	      }

# AVATAR
 if($avatar){
	$avatardest=$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($CURUSER["uid"].$CURUSER["added"]).".jpg";
        $img = resize_image($image["name"], $image["tmp_name"], $avatardest,"",$GLOBALS["USER_AVATAR_WIDTH"]);

	      if(!$img){
		  infoerr(btlng383);
		}

	       imagedestroy($img);
    
		infok(btlng385);



	    }else{

		  # CHECK IMAGE EXISTS

		      if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/".$newimgname)){
			    infoerr(str_replace("%imgname%","( $orgname )",btlng382));
			}


			      # CHECK MAX IMAGE SIZE
			      if($image["size"] > $maxfilesize){
					      infoerr(btlng379." Max. (".mksize($maxfilesize).")");
				      }

			      # CHECK XIMGDEPOT SIZE
				  $sql_imgdepotsize = mysql_result(mysql_query("SELECT SUM(size) FROM ximgdepot WHERE imguid=".$CURUSER["uid"]),0);

				    if(($sql_imgdepotsize + $image["size"]) > $max_imgdepotsize){
					  infoerr(btlng380);
					}

			mysql_query("INSERT INTO ximgdepot (imguid, filename, size, orgname, public) VALUES ( ".$CURUSER["uid"].", '$newimgname', '".$image["size"]."', ".sqlesc($orgname).", $public)") or sqlerr(__FILE__, __LINE__);

			move_uploaded_file($image["tmp_name"], $GLOBALS["XIMGDEPOT_DIR"]."/$newimgname") or infoerr(btlng384);

		infok(btlng388);
	    }





?>