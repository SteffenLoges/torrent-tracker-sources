<?php
require_once('inc/func.php');
global $CURUSER,$csstyle,$stylelink;?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex, nofollow, noarchive">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="600">
<meta http-equiv="cache-control" content="private">
<link type="text/css" rel="stylesheet" href="min/?f=<?php echo $stylelink;?>/<?php echo $csstyle;?>.css">
<script type="text/javascript" src="/min/?b=js&amp;f=<?php echo $GLOBALS["JQUERY"];?>,jqhistory.js,hisfile.js,jquery.MyDigitClock.js"></script>
<script type="text/javascript" src="/js/jquery.pager.js"></script>
<title id="pagetitle"><?php echo $GLOBALS["SITENAME"];?></title>
</head>
<body>
<div id="info"></div>
<a href="<?php echo $GLOBALS["BASEURL"];?>"><div><img title="<?php echo $GLOBALS["SITENAME"];?>" src="<?php echo $stylelink;?>/logo.gif"></div></a>
<div id="headborder">
    <p>
	<div id="message" class="message"></div>
	<div id="msgwarn" class="msgwarn"></div>
    </p>

<div style="width: 100%;">

<noscript><div class="errmsg"><?php echo btlng0_1;?></div></noscript>
<!-- EDIT Navi.php -->
<div id="navi" class="navi"><center><img align="middle" src="<?php echo $GLOBALS["IMAGES_DIR"];?>loading.png"></center></div>

<div id="container" class="container">

<div id="contenttitle" class="contenttitle"></div>

<div id="content" class="content">
<center><img align="middle" src="<?php echo $GLOBALS["IMAGES_DIR"];?>loading.png"></center>
</div>
</div>
<div style="clear: both;"></div>
<br>
</div>
</div>
<br>
<div class="footer" align="center"> &copy; <?php echo date("Y",time());?>..:: <?php echo $GLOBALS["SITENAME"];?>::..</div>
<br>
</body>
</html>