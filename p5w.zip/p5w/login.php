<?php
require_once("inc/func.php");

$returnto ="";
mkglobal("returnto");
title(btlng39,btlng39);
?>
<script>
$("#username").focus();

  $('#loginbutton').click(function() {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/logint.php", { username: $('#username').val(), passwd: $('#passwd').val(), returnto: $('#returnto').val() }, function(data){
	$("#info").html(data);
	});
  });


    $('#passwd').keypress(function(e) {
    if(e.which == 13) {
        $.get("<?php echo $GLOBALS["BASEURL"];?>/logint.php", { username: $('#username').val(), passwd: $('#passwd').val(), returnto: $('#returnto').val() }, function(data){
	$("#info").html(data);
	});
     }
    });

</script>
<p align="center"><?php echo btlng40;?></p><br>
<div class="signup" style="width: 400px;">
<div class="divbottom"><dl><dt><?php echo btlng6;?></dt><dd><input type="text" id="username" name="username" size="26" maxlength="12"></dd></dl></div>
<div class="divbottom"><dl><dt><?php echo btlng7;?></dt><dd><input type="password" id="passwd" name="passwd" size="26"></dd></dl></div>
<?php
if($returnto){
	echo ("<input type=\"hidden\" id=\"returnto\" name=\"returnto\" value=\"" . str_replace("/","",$returnto) . "\" />\n");
}
?>
<br>
<a id="loginbutton" class="buttonsilver"><?php echo btlng41;?></a>
</div>
<br>
<p align="center"><?php echo str_replace("%signup%", $GLOBALS["BASEURL"]."/#signup", btlng42);?></p>
<p align="center"><?php echo str_replace("%recover%", $GLOBALS["BASEURL"]."/#recover", btlng42_2);?></p>