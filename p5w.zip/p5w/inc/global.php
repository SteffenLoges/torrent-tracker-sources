<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */

function get_ratio_color($ratio)
{
    if($ratio < 0.1){ return "#ff0000";}
    if($ratio < 0.2){ return "#ee0000";}
    if($ratio < 0.3){ return "#dd0000";}
    if($ratio < 0.4){ return "#cc0000";}
    if($ratio < 0.5){ return "#bb0000";}
    if($ratio < 0.6){ return "#aa0000";}
    if($ratio < 0.7){ return "#990000";}
    if($ratio < 0.8){ return "#880000";}
    if($ratio < 0.9){ return "#770000";}
    if($ratio < 1){ return "#660000";}
    return "#000000";
} 

function get_slr_color($seedleech)
{
    if ($seedleech < 1){ return "#ff0000";}
    if ($seedleech < 4){ return "#9F6501";}
    return "#2B6C00";
} 

function get_class_color($class)
{
    switch ($class) {
        case UC_ROOT:
            return "#FF3338";
        case UC_ADMIN:
            return "#E57700";
        case UC_MODERATOR:
            return "#348534";
        case UC_GUTEAM:
            return "#4343ac";
        case UC_UPLOADER:
            return "#4040C0";
        case UC_VIP:
            return "#B244D9";
        case UC_POWER_USER:
            return "#000000";
        case UC_USER:
            return "#000000";
    } 
}

# User iCons
        function get_user_icons($donor,$warnpoints,$enabled,$added)
        {
	  $pics="";

	if(!$enabled){
		$pics .= "<img src=\"".$GLOBALS["IMAGES_DIR"]."disabled.png\" title=\"".btlng166."\">";
	     }
	      else{

	  if($donor){
		$pics .= "<img src=\"".$GLOBALS["IMAGES_DIR"]."donor.png\" title=\"".btlng164."\">";
	    }

	      if($warnpoints){

		      $warnpercent = round(($warnpoints * 100) / $GLOBALS["MAX_USER_WARN_POINTS"],0);

		if($warnpercent < 20 ){
			  $warnimg="warned.png";
		        }
		if($warnpercent > 20){
			  $warnimg="warned2.png";
			}
		if($warnpercent > 40){
			  $warnimg="warned3.png";
			}
		if($warnpercent > 60){
			  $warnimg="warned4.png";
			}
		if($warnpercent > 80){
			  $warnimg="warned5.png";
			}

		  $pics .= "<img src=\"".$GLOBALS["IMAGES_DIR"]."$warnimg\" title=\"".str_replace("%warnpoints%",$warnpoints,btlng165)."\">";
		}

			$timeadded = $added;

			if($timeadded > 0 && (time() - $timeadded) < 604800){
			  $pics .= "<img src=\"".$GLOBALS["IMAGES_DIR"]."pacifier.png\" title=\"".btlng167."\">";
			  }
	      }
            return $pics;
        }


function redir_url($url,$urlname=""){

$txtstring = $url;

$findthis  = $GLOBALS["BASEURL"];

$pos = strpos($txtstring, $findthis);


      if($pos === false) {
	  
	  return "<a href=\"http://anonym.to/?$url\" target=\"_blank\">$url</a>";
      } else {
	  return "<a href=\"$url\">$url</a>";
      }

}


function format_urls($s)
{
    return preg_replace("/(\A|[^=\]'\"a-zA-Z0-9])((http|ftp|https|ftps|irc):\/\/[^()<>\s]+)/ies","\\1 redir_url( '\\2' ) ", $s);
} 



function format_shout($text=""){

  global $smilies;

  $text = str_replace(";)", ":wink:", $text); 

  $text = htmlchar($text);
       
    $search = array("/\[b\]((\s|.)+?)\[\/b\]/", 
		    "/\[i\]((\s|.)+?)\[\/i\]/", 
		    "/\[u\]((\s|.)+?)\[\/u\]/i",
		    "/\[center\]((\s|.)+?)\[\/center\]/i",
		    "/\[img\](http:\/\/[^\s'\"<>]+(\.(jpg|gif|png|jpeg)))\[\/img\]/i",
		    "/\[url\]([^()<>\s]+?)\[\/url\]/ies"
		  );

                
   $replace = array("<b>\\1</b>",
		    "<i>\\1</i>",
		    "<u>\\1</u>",
		    "<center>\\1</center>",
		    "<img src=\" \\1\" style=\"max-width:85%;max-height:480px;\">",
		    "format_urls('\\1')"
               );
                
  $text = format_urls($text); 

  $text = preg_replace($search, $replace, $text);

  reset($smilies);

    foreach($smilies as $key => $value){
	$text = str_replace($key, "<img src=\"images/smilies/$value\" title=\"$key\">", $text);
    }
                
  return $text;
        
}

function format_quotes($s)
{
$old_s="";
    while ($old_s != $s) {
        $old_s = $s; 
        // [quote]Text[/quote]
        $s = preg_replace("/\[quote\](.+?)\[\/quote\]/is",
            		"<div style=\"width:90%;font-style: italic;font-size: 12px;\"><b>".btlng59." : </b><div style=\"width:auto;border:dotted 1px #666; margin-left:50px;font: 12px/16px normal helvetica, sans-serif;padding:4px; background-color:#F4F4F4;\">\\1</div></div>", $s); 

        // [quote=Author]Text[/quote]
        $s = preg_replace("/\[quote=(.+?)\](.+?)\[\/quote\]/is",
            		"<div style=\"width:90%;font-style: italic;font-size: 12px;\"><b>\\1 ".btlng60." </b><br><div style=\"width:auto;border:dotted 1px #666; margin-left:50px;font: 12px/16px normal helvetica, sans-serif;padding:4px; background-color:#F4F4F4;\">\\2</div></div>",$s);
    } 

    return $s;
}


function format_comment($text=""){

  global $smilies;

  $text = str_replace(";)", ":wink:", $text); 

  $text = htmlchar($text);
       
  $search = array("/\[b\]((\s|.)+?)\[\/b\]/", 
                  "/\[i\]((\s|.)+?)\[\/i\]/", 
                  "/\[u\]((\s|.)+?)\[\/u\]/i",
		  "/\[center\]((\s|.)+?)\[\/center\]/i",
		  "/\[list\]((\s|.)+?)\[\/list\]/",     
		  "/\[list=(disc|circle|square)\]((\s|.)+?)\[\/list\]/",
		  "/\[list=(1|a|A|i|I)\]((\s|.)+?)\[\/list\]/",
		  "/\[\*\]/",
		  "/\[img\](http:\/\/[^\s'\"<>]+(\.(jpg|gif|png|jpeg)))\[\/img\]/i",
		  "/\[img=(http:\/\/[^\s'\"<>]+(\.(gif|jpg|png|jpeg)))\]/i",
		  "/\[imgl=(http:\/\/[^\s'\"<>]+(\.(gif|jpg|png|jpeg)))\]/i",
		  "/\[color=([a-zA-Z]+)\]((\s|.)+?)\[\/color\]/i",
		  "/\[color=(#[a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9][a-f0-9])\]((\s|.)+?)\[\/color\]/i",
		  "/\[url=([^()<>\s]+?)\](.+?)\[\/url\]/i",
		  "/\[url\]([^()<>\s]+?)\[\/url\]/i",
		  "#\[size=([1-7])\](.+?)\[/size\]#si",
		  "/\[youtube][^\s'\"<>]*youtube.com.*v=([^\s'\"<>]+)\[\/youtube\]/ims",
		  "/\[font=([a-zA-Z ,]+)\](.+?)\[\/font\]/i",
		  "/\[del\]((\s|.)+?)\[\/del\]/i",
		  "/\[align=([a-zA-Z]+)\]((\s|.)+?)\[\/align\]/i",
		  "/\[pre\]((\s|.)+?)\[\/pre\]/i",
		  "/\[br]/i",
		  "/\[scroll=([a-zA-Z ,]+)\]((\s|.)+?)\[\/scroll\]/i",
		  "/\[scroll\]((\s|.)+?)\[\/scroll\]/i"
                 );

                
  $replace = array("<b>\\1</b>",
                "<i>\\1</i>",
                "<u>\\1</u>",
		"<center>\\1</center>",
		"<ul>\\1</ul>",
		"<ul type=\"\\1\">\\2</ul>",
		"<ol type=\"\\1\">\\2</ol>",
		"<li>",
		"<img src=\"\\1\" width=\"620px\" class=\"imgborder\">",
		"<img src=\"\\1\">",
		"<img src=\"\\1\"  class=\"imgborder\">",
		"<font color=\"\\1\">\\2</font>",
		"<font color=\"\\1\">\\2</font>",
		"<a href=\"\\1\">\\2</a>",
		"<a href=\"\\1\">\\1</a>",
		"<span style='font-size:\\1em;line-height:100%'>\\2</span>",
		"<object><param name=\"movie\" name=\"wmode\" value=\"transparent\" value=\"http://www.youtube.com/v/\\1\"></param><embed wmode=\"transparent\" width=\"520\" height=\"350\" src=\"http://www.youtube.com/v/\\1\" type=\"application/x-shockwave-flash\"></embed></object>",
		"<span style='font-family:\\1;'>\\2</span>",
		"<del>\\1</del>",
		"<div style=\"text-align:\\1;\">\\2</div>",
		"<tt><span style=\"white-space: nowrap;\">\\1</span></tt>",
		"<br>",
		"<marquee direction=\"\\1\" scrollamount=\"2\" scrolldelay=\"2\">\\2</marquee>",
		"<marquee direction=\"left\" scrollamount=\"2\" scrolldelay=\"2\">\\1</marquee>"
               );
                
  $text = format_quotes($text);
  $text = format_urls($text); 
  $text = preg_replace($search, $replace, $text);
  $text = nl2br($text);

  reset($smilies);

    foreach($smilies as $key => $value){
	$text = str_replace($key, "<img src=\"images/smilies/$value\" title=\"$key\">", $text);
    }
                
  return $text;
        
}



function is_valid_user_class($class)
{
    return is_numeric($class) && floor($class) == $class && $class >= UC_USER && $class <= UC_ROOT;
} 


function is_valid_id($id)
{
    return is_numeric($id) && ($id > 0) && (floor($id) == $id);
} 


function resize_image($origfn, $tmpfile, $target_filename, $quality="", $xwidth="")
{
      if(!$xwidth){
	  $xwidth = $GLOBALS["TOR_THUMB_WIDTH"];
	}
	 else{
	   $xwidth = $xwidth;
	    }

	  if(!$quality){
	      $quality = 92;
	    }
	    else{
	      $quality = $quality;
		}

	// Bild laden
	if (preg_match("/(jp(e|eg|g))$/i", $origfn)) {
   		$img_pic = imagecreatefromjpeg($tmpfile);
	}
	if (preg_match("/png$/i", $origfn)) {
   		$img_pic = imagecreatefrompng($tmpfile);
	}
	if (preg_match("/gif$/i", $origfn)) {
   		$img_pic = imagecreatefromgif($tmpfile);
	}
    	
	if (!$img_pic)
        return FALSE;
        
    $size_x = imagesx($img_pic);
    $size_y = imagesy($img_pic);				
    
    $tn_size_x = $xwidth;
    $tn_size_y = (int)((float)$size_y / (float)$size_x * (float)$tn_size_x);
    
    // Thumbnail erzeugen
    $img_tn = imagecreatetruecolor($tn_size_x, $tn_size_y);
    imagecopyresampled($img_tn, $img_pic, 0, 0, 0, 0, $tn_size_x, $tn_size_y, $size_x, $size_y);		
    
    // Bild speichern
    $dummy = imagejpeg($img_tn, $target_filename, $quality);
    
    imagedestroy($img_tn);
    
    return $img_pic;
}

function torrent_image_upload($file, $id, $picnum, $check = 0)
{
global $imginfo;

    if(!$file["name"] || $file["size"] < 1) {
        $imginfo=str_replace("%imgname%",$file["name"],btlng92);
        return false;
    }
    
    if($file["size"] > $GLOBALS["MAX_XIMGDEPOT_UPLOAD_SIZE"]) {
	$imginfo=str_replace("%imgname%",$file["name"],btlng93);
        return false;
    }

    $it = exif_imagetype($file["tmp_name"]);
    if($it != IMAGETYPE_GIF && $it != IMAGETYPE_JPEG && $it != IMAGETYPE_PNG) {
	$imginfo=str_replace("%imgname%",$file["name"],btlng94);
        return false;
    }

      $i = strrpos($file["name"], ".");
	if ($i !== false)
	{
	    $ext = strtolower(substr($file["name"], $i));
	    if(($it == IMAGETYPE_GIF  && $ext != ".gif") || ($it == IMAGETYPE_JPEG && $ext != ".jpg") || ($it == IMAGETYPE_PNG  && $ext != ".png")) {
	      	$imginfo=str_replace("%ext%",$ext,btlng95);
            return false;
	   }
	}
	else {
	    $imginfo=str_replace("%imgname%",$file["name"],btlng96);
	  return false;
    }
    
    
    if(!$check){

    # Create Thumbnail Image
        $img = resize_image($file["name"], $file["tmp_name"], $GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$id-$picnum-t.jpg", 100); 

    if ($img === false) {
	$imginfo=str_replace("%imgname%",$file["name"],btlng97);
        return false;
    }
	# Write Original Image
        $ret = imagejpeg($img, $GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$id-$picnum-f.jpg", 90);

    if(!$ret) {
	 $imginfo=str_replace("%imgname%",$file["name"],btlng98);
        return false;
    } else {
        return true;
    }
  }

}



function gen_nfo_pic($nfotext, $target_filename)
{
    // Make array of NFO lines and break lines at 80 chars
    $nfotext = preg_replace('/\r\n/', "\n", $nfotext);
    $lines = explode("\n", $nfotext);
    for ($I=0;$I<count($lines);$I++) {
        $lines[$I] = chop($lines[$I]);
        $lines[$I] = wordwrap($lines[$I], 82, "\n", 1);
    }
    $lines = explode("\n", implode("\n", $lines));
    
    // Get longest line
    $cols = 0;
    for ($I=0;$I<count($lines);$I++) {
        
        $lines[$I] = chop($lines[$I]);
        if (strlen($lines[$I]) > $cols)
            $cols = strlen($lines[$I]);
    }
    
    // Allow a maximum of 500 lines of text
    $lines = array_slice($lines, 0, 500);
    
    // Get line count
    $linecnt = count($lines);
    
    // Load font
    $font = imageloadfont("fonts/terminal.gdf");
    if($font < 5){
        infoerr(btlng99);
      }
    
    $imagewidth = $cols * imagefontwidth($font) + 1;
    $imageheight = $linecnt * imagefontheight($font) + 1;
    
    $nfoimage = imagecreate($imagewidth, $imageheight);
    $white = imagecolorallocate($nfoimage, 255, 255, 255);
    $black = imagecolorallocate($nfoimage, 0, 0, 0);
    
    for ($I=0;$I<$linecnt;$I++){
        imagestring($nfoimage, $font, 0, $I*imagefontheight($font), $lines[$I], $black);
	}
    return imagepng($nfoimage, $target_filename);
}




function delete_acct($id)
{ 
    # GET USER E-MAIL 
    $userinfo = mysql_fetch_row(mysql_query("SELECT email,username,confirmed,userkey,added FROM users WHERE uid=$id"));
    $userkey=$userinfo[3];
    if ($userinfo[0] && $userinfo[2] == "1") {
        $mailbody = str_replace(array("%sitename%"),array($GLOBALS["SITENAME"]),btlng421);

        mail("\"" . $userinfo[1] . "\" <" . $userinfo[0] . ">",btlng421_2." ".$GLOBALS["SITENAME"], $mailbody);
    } 

    $res = mysql_query("DELETE FROM users WHERE uid=$id") or sqlerr(__FILE__, __LINE__); 
 
    # DELETE XIMGDEPOT FILES
    $ximgdepotfiles = mysql_query("SELECT filename FROM ximgdepot WHERE imguid = $id AND public = 0");

    while ($imginfo = mysql_fetch_row($ximgdepotfiles)){
            unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/" . $imginfo[0]);
        }

    mysql_query("DELETE FROM ximgdepot WHERE imguid = $id AND public = 0");
    
    # DELETE USER TORRENT TRAFFIC
    mysql_query("DELETE FROM traffic WHERE uid = $id");

    # DELETE USER MODCOMMENTS
    mysql_query("DELETE FROM modcomments WHERE cuid = $id");

    # DELETE USER COMPLETED
    mysql_query("DELETE FROM completed WHERE user_id = $id");

    # DELETE USER FRIENDS
    mysql_query("DELETE FROM friends WHERE fuid =$id OR friendid =$id");

    # DELETE USER BLOCKS
    mysql_query("DELETE FROM blocks WHERE buid =$id OR blockid =$id");

    # DELETE USER IP LOGS
    mysql_query("DELETE FROM log_ip WHERE uid =$id");

    # DELETE USERAVATAR
    if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($id.$userinfo[4]).".jpg")){
	unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($id.$userinfo[4]).".jpg");
      } 
    
    # DELETE USER MESSAGES
    $res = mysql_query("SELECT mid FROM messages WHERE receiver = $id OR sender = $id");
    $msgids = array();

    while ($msg = mysql_fetch_row($res)){
        $msgids[] = $msg[0];
       }

    $msgids = implode(",", $msgids);

	  # RECEIVER
	  mysql_query("UPDATE messages SET inbox=0 WHERE mid IN ($msgids) AND (inbox=1 OR inbox=2 OR inbox=3 OR inbox=4) AND receiver=".$id);
	  mysql_query("DELETE FROM messages WHERE mid IN ($msgids) AND outbox=0 AND inbox=0 AND receiver=".$id);
	  # SENDER
	  mysql_query("UPDATE messages SET outbox=0 WHERE mid IN ($msgids) AND (outbox=1 OR outbox=2) AND sender=".$id);
	  mysql_query("DELETE FROM messages WHERE mid IN ($msgids) AND inbox=0 AND outbox=0 AND sender=".$id);

    $log_msg = str_replace(array("%username%","%uid%"),array($userinfo[1],$id),btlng422);

  # DELETE USER FROM RAM
    apc_delete("us_$userkey");

    write_log("accdeleted", $log_msg);
} 





function deletetorrent($id, $owner = 0, $comment = "")
{
    global $CURUSER,$time;

    $torrent = mysql_fetch_row(mysql_query("SELECT name,numpics,info_hash FROM torrents WHERE tid = $id")); 

    // Delete pictures associated with torrent
    if ($torrent[1] > 0) {
        for($I = 1; $I <= $torrent[1]; $I++) {
            unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$id-$I-t.jpg");
            unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$id-$I-f.jpg");
        } 
    } 

    # Delete NFO image
    if(file_exists($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/nfo/nfo-".md5($id.$torrent[2]).".png")){
     unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/nfo/nfo-".md5($id.$torrent[2]).".png");
    }

    mysql_query("DELETE FROM peers WHERE ptid = $id");
    mysql_query("DELETE FROM completed WHERE tor_id = $id");
    mysql_query("DELETE FROM files WHERE filestid = $id");

    foreach(explode(".", "torrents.traffic.comments") as $x){
      mysql_query("DELETE FROM $x WHERE tid = $id");
    }

     unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["TORRENT_DIR"] . "/$id.torrent"); 

    # DELETE TORRENT FROM RAM
    $tormd5=md5($torrent[2]);
    apc_delete("tor_$tormd5");
    apc_delete("peers_tid_$id");

    # Send notification to owner if someone else deleted the torrent
    if ($CURUSER && $owner > 0 && $CURUSER["uid"] != $owner) {
        $msg = str_replace(array("%torname%","%uid%","%username%","%comment%"),array($torrent[0],$CURUSER["uid"],$CURUSER["username"],$comment),btlng434);

	  # SEND USER PM
	    mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
		    ".implode(",", array_map("sqlesc", array(
		    0, 
		    $owner, 
		    4,  
		    $time,
		    btlng435,
		    $msg))).")") or sqlerr(__FILE__, __LINE__);

    } 
} 


$smilies = array(":-)" => "smile1.gif",
    ":smile:" => "smile2.gif",
    ":-D" => "grin.gif",
    ":lol:" => "laugh.gif",
    ":w00t:" => "w00t.gif",
    ":-P" => "tongue.gif",
    ";-)" => "wink.gif",
    ":-|" => "noexpression.gif",
    ":-/" => "confused.gif",
    ":-(" => "sad.gif",
    ":'-(" => "cry.gif",
    ":weep:" => "weep.gif",
    ":-O" => "ohmy.gif",
    ":o)" => "clown.gif",
    "8-)" => "cool1.gif",
    "|-)" => "sleeping.gif",
    ":innocent:" => "innocent.gif",
    ":whistle:" => "whistle.gif",
    ":unsure:" => "unsure.gif",
    ":closedeyes:" => "closedeyes.gif",
    ":cool:" => "cool2.gif",
    ":fun:" => "fun.gif",
    ":thumbsup:" => "thumbsup.gif",
    ":thumbsdown:" => "thumbsdown.gif",
    ":blush:" => "blush.gif",
    ":unsure:" => "unsure.gif",
    ":yes:" => "yes.gif",
    ":no:" => "no.gif",
    ":love:" => "love.gif",
    ":?:" => "question.gif",
    ":!:" => "excl.gif",
    ":idea:" => "idea.gif",
    ":arrow:" => "arrow.gif",
    ":arrow2:" => "arrow2.gif",
    ":hmm:" => "hmm.gif",
    ":hmmm:" => "hmmm.gif",
    ":huh:" => "huh.gif",
    ":geek:" => "geek.gif",
    ":look:" => "look.gif",
    ":rolleyes:" => "rolleyes.gif",
    ":kiss:" => "kiss.gif",
    ":shifty:" => "shifty.gif",
    ":blink:" => "blink.gif",
    ":smartass:" => "smartass.gif",
    ":sick:" => "sick.gif",
    ":crazy:" => "crazy.gif",
    ":wacko:" => "wacko.gif",
    ":alien:" => "alien.gif",
    ":wizard:" => "wizard.gif",
    ":wave:" => "wave.gif",
    ":wavecry:" => "wavecry.gif",
    ":baby:" => "baby.gif",
    ":angry:" => "angry.gif",
    ":ras:" => "ras.gif",
    ":sly:" => "sly.gif",
    ":devil:" => "devil.gif",
    ":evil:" => "evil.gif",
    ":evilmad:" => "evilmad.gif",
    ":sneaky:" => "sneaky.gif",
    ":axe:" => "axe.gif",
    ":slap:" => "slap.gif",
    ":wall:" => "wall.gif",
    ":rant:" => "rant.gif",
    ":jump:" => "jump.gif",
    ":yucky:" => "yucky.gif",
    ":nugget:" => "nugget.gif",
    ":smart:" => "smart.gif",
    ":shutup:" => "shutup.gif",
    ":shutup2:" => "shutup2.gif",
    ":crockett:" => "crockett.gif",
    ":zorro:" => "zorro.gif",
    ":snap:" => "snap.gif",
    ":beer:" => "beer.gif",
    ":beer2:" => "beer2.gif",
    ":drunk:" => "drunk.gif",
    ":strongbench:" => "strongbench.gif",
    ":weakbench:" => "weakbench.gif",
    ":dumbells:" => "dumbells.gif",
    ":music:" => "music.gif",
    ":bumbum:" => "bumbum.gif",
    ":stupid:" => "stupid.gif",
    ":dots:" => "dots.gif",
    ":offtopic:" => "offtopic.gif",
    ":spam:" => "spam.gif",
    ":oops:" => "oops.gif",
    ":lttd:" => "lttd.gif",
    ":please:" => "please.gif",
    ":sorry:" => "sorry.gif",
    ":hi:" => "hi.gif",
    ":yay:" => "yay.gif",
    ":cake:" => "cake.gif",
    ":hbd:" => "hbd.gif",
    ":band:" => "band.gif",
    ":punk:" => "punk.gif",
    ":rofl:" => "rofl.gif",
    ":bounce:" => "bounce.gif",
    ":mbounce:" => "mbounce.gif",
    ":thankyou:" => "thankyou.gif",
    ":gathering:" => "gathering.gif",
    ":hang:" => "hang.gif",
    ":chop:" => "chop.gif",
    ":rip:" => "rip.gif",
    ":whip:" => "whip.gif",
    ":judge:" => "judge.gif",
    ":chair:" => "chair.gif",
    ":tease:" => "tease.gif",
    ":box:" => "box.gif",
    ":boxing:" => "boxing.gif",
    ":guns:" => "guns.gif",
    ":shoot:" => "shoot.gif",
    ":shoot2:" => "shoot2.gif",
    ":flowers:" => "flowers.gif",
    ":wub:" => "wub.gif",
    ":lovers:" => "lovers.gif",
    ":kissing:" => "kissing.gif",
    ":kissing2:" => "kissing2.gif",
    ":console:" => "console.gif",
    ":group:" => "group.gif",
    ":hump:" => "hump.gif",
    ":hooray:" => "hooray.gif",
    ":happy2:" => "happy2.gif",
    ":clap:" => "clap.gif",
    ":clap2:" => "clap2.gif",
    ":weirdo:" => "weirdo.gif",
    ":yawn:" => "yawn.gif",
    ":bow:" => "bow.gif",
    ":dawgie:" => "dawgie.gif",
    ":cylon:" => "cylon.gif",
    ":book:" => "book.gif",
    ":fish:" => "fish.gif",
    ":mama:" => "mama.gif",
    ":pepsi:" => "pepsi.gif",
    ":medieval:" => "medieval.gif",
    ":rambo:" => "rambo.gif",
    ":ninja:" => "ninja.gif",
    ":hannibal:" => "hannibal.gif",
    ":party:" => "party.gif",
    ":snorkle:" => "snorkle.gif",
    ":evo:" => "evo.gif",
    ":king:" => "king.gif",
    ":chef:" => "chef.gif",
    ":mario:" => "mario.gif",
    ":pope:" => "pope.gif",
    ":fez:" => "fez.gif",
    ":cap:" => "cap.gif",
    ":cowboy:" => "cowboy.gif",
    ":pirate:" => "pirate.gif",
    ":pirate2:" => "pirate2.gif",
    ":rock:" => "rock.gif",
    ":cigar:" => "cigar.gif",
    ":icecream:" => "icecream.gif",
    ":oldtimer:" => "oldtimer.gif",
    ":trampoline:" => "trampoline.gif",
    ":banana:" => "bananadance.gif",
    ":smurf:" => "smurf.gif",
    ":yikes:" => "yikes.gif",
    ":osama:" => "osama.gif",
    ":saddam:" => "saddam.gif",
    ":santa:" => "santa.gif",
    ":indian:" => "indian.gif",
    ":pimp:" => "pimp.gif",
    ":nuke:" => "nuke.gif",
    ":jacko:" => "jacko.gif",
    ":ike:" => "ike.gif",
    ":greedy:" => "greedy.gif",
    ":super:" => "super.gif",
    ":wolverine:" => "wolverine.gif",
    ":spidey:" => "spidey.gif",
    ":spider:" => "spider.gif",
    ":bandana:" => "bandana.gif",
    ":construction:" => "construction.gif",
    ":sheep:" => "sheep.gif",
    ":police:" => "police.gif",
    ":detective:" => "detective.gif",
    ":bike:" => "bike.gif",
    ":fishing:" => "fishing.gif",
    ":clover:" => "clover.gif",
    ":horse:" => "horse.gif",
    ":shit:" => "shit.gif",
    ":soldiers:" => "soldiers.gif",
    ":)" => "smile1.gif", 
    ":wink:" => "wink.gif",
    ":D" => "grin.gif",
    ":P" => "tongue.gif",
    ":(" => "sad.gif",
    ":'(" => "cry.gif",
    ":|" => "noexpression.gif", 
    // "8-)" => "cool1.gif",
    ":Boozer:" => "alcoholic.gif",
    ":deadhorse:" => "deadhorse.gif",
    ":spank:" => "spank.gif",
    ":yoji:" => "yoji.gif",
    ":locked:" => "locked.gif",
    ":grrr:" => "angry.gif", // legacy
    "O:-" => "innocent.gif", // legacy
    ":sleeping:" => "sleeping.gif", // legacy
    "-_-" => "unsure.gif", // legacy
    ":clown:" => "clown.gif",
    ":mml:" => "mml.gif",
    ":rtf:" => "rtf.gif",
    ":morepics:" => "morepics.gif",
    ":rb:" => "rb.gif",
    ":rblocked:" => "rblocked.gif",
    ":maxlocked:" => "maxlocked.gif",
    ":hslocked:" => "hslocked.gif",
    ":dancat:" => "dancat.gif"
    );



?>