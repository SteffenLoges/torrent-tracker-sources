<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/config.php");
require_once("inc/cleandb.php");


#Cookie Language And Style
if(isset($_COOKIE["p5w_csstyle"])){$csstyle=htmlchar($_COOKIE["p5w_csstyle"]);}else{$csstyle="default";}
if(isset($_COOKIE["p5w_lang"])){$clanguage=htmlchar($_COOKIE["p5w_lang"]);}else{$clanguage="";}
if(isset($_COOKIE["p5w_catimg"])){$stylecatimg=htmlchar($_COOKIE["p5w_catimg"]);}else{$stylecatimg=$csstyle;}

$stylelink="style/$csstyle";
$stylecatimg = "style/$stylecatimg";

  if($clanguage && file_exists("lang/".$clanguage.".php"))
      {
	require_once("lang/".$clanguage.".php");
      }
	else
      {
	 $slanguage = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
	  switch($slanguage) {
	  case 'de': require_once('lang/de.php');break;
	  default: require_once('lang/de.php');
	  }
      }

// IP Validation Minimum PHP version >= 5.2.0 //
function validip($ip)
{
	if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
	      return true;
	}
	else {
	      return false;
	}
}

// Patched function to detect REAL IP address if it's valid
function getip() {
   if (isset($_SERVER)) {
     if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && validip($_SERVER['HTTP_X_FORWARDED_FOR'])) {
       $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
     } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && validip($_SERVER['HTTP_CLIENT_IP'])) {
       $ip = $_SERVER['HTTP_CLIENT_IP'];
     } else {
       $ip = $_SERVER['REMOTE_ADDR'];
     }
   } else {
     if (getenv('HTTP_X_FORWARDED_FOR') && validip(getenv('HTTP_X_FORWARDED_FOR'))) {
       $ip = getenv('HTTP_X_FORWARDED_FOR');
     } elseif (getenv('HTTP_CLIENT_IP') && validip(getenv('HTTP_CLIENT_IP'))) {
       $ip = getenv('HTTP_CLIENT_IP');
     } else {
       $ip = getenv('REMOTE_ADDR');
     }
   }

   return $ip;
 }


# ENCODE IP
  function ipe($ipe){
      return inet_pton($ipe);
  }

# DECODE IP
  function ipd($ipd){
      return inet_ntop($ipd);
  }

$ip=getip();
$ipencode=ipe($ip);
$time=time();


# Connect Database
function dbconn()
{
    global $mysql_host, $mysql_user, $mysql_pass, $mysql_db, $_SERVER, $dbconn;

    $dbconn = mysql_connect($mysql_host, $mysql_user, $mysql_pass);

    mysql_select_db($mysql_db) or die('dbconn: mysql_select_db: ' + mysql_error());
	
    userlogin();

  register_shutdown_function("clean_db");
  register_shutdown_function("dbclose");
} 

# Close Database Connection
function dbclose()
{
global $dbconn;
  if($dbconn){
	 mysql_close($dbconn);
	}
}

# User Login
function userlogin()
{

    global $ipencode,$ip,$time,$csstyle,$stylelink;

    unset($GLOBALS["CURUSER"]);

    $GLOBALS["CURUSER"]="";

    $check_ram_values = apc_fetch('check_ram_values');

    if(isset($_COOKIE["p5w_uid"])){$uid = 0 + $_COOKIE["p5w_uid"];}else{$uid = 0;}


	  $bannsqlwhe="";

	  if($uid){
	      $bannsqlwhe=" OR banuid =".sqlesc($uid);
	    }

	#Banned IP
	$resban = mysql_query("SELECT comment FROM bans WHERE ('$ipencode' >= ip AND '$ipencode' <= iplast) OR ip ='$ipencode' $bannsqlwhe") or sqlerr(__FILE__, __LINE__);
	
	if($rowban = mysql_fetch_row($resban)) {
	  if($_SERVER["REQUEST_URI"] != "/"){go_to();}
	  ?>
	    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
	    <html><head>
	    <link type="text/css" rel="stylesheet" href="min/?f=<?php echo $stylelink;?>/<?php echo $csstyle;?>.css" />
	    <script type="text/javascript" src="/min/?f=js/<?php echo $GLOBALS["JQUERY"];?>"></script>
	    <title id="pagetitle"><?php echo $GLOBALS["SITENAME"];?></title>
	    </head><body>
	    <a href="<?php echo $GLOBALS["BASEURL"];?>"><div><img title="<?php echo $GLOBALS["SITENAME"];?>" src="<?php echo $stylelink;?>/logo.gif"></div></a>
	    <div id="headborder"><br>
	    <div style="width: 100%;">
	    <noscript><div class="errmsg"><?php echo btlng0_1;?></div></noscript>
	    <div id="container" class="container" style="width: 99%;">
	    <div id="contenttitle" class="contenttitle" ></div>
	    <div id="content" class="content"></div>
	    </div>
	    <div style="clear: both;"></div>
	    <br></div></div><br>
	    <div class="footer" align="center"> &copy; <?php echo date("Y",time());?>..:: <?php echo $GLOBALS["SITENAME"];?>::..</div>
	    </body></html>
	  <?php
	    if(!$rowban["0"]){
	      $banncomment=btlng0;
	      }else{
	      $banncomment=$rowban["0"];
	      }
	    errmsg(btlng0,$banncomment,1);
	} 
    

session_start();

    if (!isset($_SESSION["udata"]) && (empty($_COOKIE["p5w_uid"]) || empty($_COOKIE["p5w_pass"]))){
        return;
      }

    if(isset($_SESSION["udata"])) {
        $enabled = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM users WHERE uid = " . $_SESSION["udata"]["uid"] . " AND enabled = 1 AND confirmed = 1"));
	  if(!$enabled[0] || $_SESSION["udata"]["ip"] != $ip) {
	      logoutcookie();
	      return;
	    } 
        $GLOBALS["CURUSER"] = $_SESSION["udata"];
       }
      else{

        if (!$uid || strlen($_COOKIE["p5w_pass"]) != 32){
             return;
	   }

        $res = mysql_query("SELECT * FROM users WHERE uid = ".sqlesc($uid)." AND enabled = 1 AND confirmed = 1") or sqlerr(__FILE__, __LINE__);
        $row = mysql_fetch_assoc($res);

	  if (!$row){
	      return;
	      }

	    if ($_COOKIE["p5w_pass"] != $row["passhash"]){
	      return;
	      }

        $row["ip"]=$ip;
        $GLOBALS["CURUSER"] = $row;
        $_SESSION["udata"] = $row;
        $_SESSION["udata"]["lastaccess2"]=$time;
	    $_SESSION["udata"]["unreadedmsgs"]=0;
	    $_SESSION["udata"]["unreadedsysmsgs"]=0;
	    $_SESSION["udata"]["unreadedtotmsgs"]=0;

   }

    # SITE OFFLINE
    if(!$GLOBALS["SITE_ONLINE"] && $GLOBALS["CURUSER"]["class"] < UC_ADMIN){
      if($_SERVER["REQUEST_URI"] != "/"){go_to();}
              ?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
	<html><head>
	<link type="text/css" rel="stylesheet" href="min/?f=<?php echo $stylelink;?>/<?php echo $csstyle;?>.css" />
	<script type="text/javascript" src="/min/?f=js/<?php echo $GLOBALS["JQUERY"];?>"></script>
	<title id="pagetitle"><?php echo $GLOBALS["SITENAME"];?></title>
	</head><body>
	<a href="<?php echo $GLOBALS["BASEURL"];?>"><div><img title="<?php echo $GLOBALS["SITENAME"];?>" src="<?php echo $stylelink;?>/logo.gif"></div></a>
	<div id="headborder"><br>
	<div style="width: 100%;">
	<noscript><div class="errmsg"><?php echo btlng0_1;?></div></noscript>
	<div id="container" class="container" style="width: 99%;">
	<div id="contenttitle" class="contenttitle" ></div>
	<div id="content" class="content"></div>
	</div>
	<div style="clear: both;"></div>
	<br></div></div><br>
	<div class="footer" align="center"> &copy; <?php echo date("Y",time());?>..:: <?php echo $GLOBALS["SITENAME"];?>::..</div>
	</body></html>
      <?php
        errmsg(btlng0_0,btlng0_2);
      }


        # DELETE EDITSECRET AND TIME
	if($_SESSION["udata"]["editsecrettime"] && $time > $_SESSION["udata"]["editsecrettime"]+3600 || $_SESSION["udata"]["editsecret"] && !$_SESSION["udata"]["editsecrettime"]){
	    mysql_query("UPDATE users SET editsecret='', editsecrettime='' WHERE uid=" . $GLOBALS["CURUSER"]["uid"]) or sqlerr(__FILE__, __LINE__);
		$_SESSION["udata"]["editsecrettime"]="";
		$_SESSION["udata"]["editsecret"]="";
	}

        # UPDATE USER LASTACCESS EVERY 60 SEC.
	if($time > $_SESSION["udata"]["lastaccess2"]+60){
	  $_SESSION["udata"]["lastaccess2"]=$time;
	  mysql_query("UPDATE users SET lastaccess='$time', ip='$ipencode' WHERE uid=" . $GLOBALS["CURUSER"]["uid"]) or sqlerr(__FILE__, __LINE__); 
	      
		# UPDATE COUNTRY CODE
		if(validip(getip())){
		      $countrycode = strtolower(geoip_country_code_by_name(getip()));
			  if($_SESSION["udata"]["country"] != $countrycode){
				    mysql_query("UPDATE users SET country=".sqlesc($countrycode)." WHERE uid=" . $GLOBALS["CURUSER"]["uid"]) or sqlerr(__FILE__, __LINE__); 
				$_SESSION["udata"]["country"] = $countrycode;
				}
		    }
       }

	# LOG USER IP
	if(!isset($_SESSION["udata"]["log_ip_time"])){
		mysql_query("INSERT INTO log_ip (uid,ip) VALUES (".$GLOBALS["CURUSER"]["uid"].",'$ipencode')");
		$_SESSION["udata"]["log_ip_time"]=$time;

	      }else{
		      if($time > ($_SESSION["udata"]["log_ip_time"] + 300)){
			  mysql_query("INSERT INTO log_ip (uid,ip) VALUES (".$GLOBALS["CURUSER"]["uid"].",'$ipencode')");
			  $_SESSION["udata"]["log_ip_time"]=$time;
		      }
	    }

####################################################################################################

    # ADD USER TO RAM IF RAM VALUES NOT EXISTS
      $ckhuser=$GLOBALS["CURUSER"]["userkey"];
      $chkuserramvals=apc_fetch("us_$ckhuser");
      
      if(!$chkuserramvals){
	    add_user_to_ram($GLOBALS["CURUSER"]["uid"]);
	}

      # ADD ALL USERS AND TORRENTS TO RAM IF $check_ram_values NOT EXISTS
	  if(!$check_ram_values){
	    # USERS
		  $ramures=mysql_query("SELECT uid FROM users");
		  while($ramurow = mysql_fetch_row($ramures)){
		      add_user_to_ram($ramurow[0]);
		  }
	    # TORRENTS
		  $ramtres=mysql_query("SELECT tid FROM torrents");
		  while($ramtrow = mysql_fetch_row($ramtres)){
		      add_torrent_to_ram($ramtrow[0]);
		  }
            # CLIENTS
                      add_clients_to_ram();

		apc_store("check_ram_values","1");
	      }

####################################################################################################


      # UPDATE USER RAM VALUES
	  if($GLOBALS["CURUSER"]["flags"] && $GLOBALS["CURUSER"]["enabled"]){
		      add_user_to_ram($GLOBALS["CURUSER"]["uid"]);
			mysql_query("UPDATE users SET flags = 0 WHERE uid=".$GLOBALS["CURUSER"]["uid"]);
		      $_SESSION["udata"]["flags"]=0;
		  }


}


function infok($text=""){
?>
<script>
	$("#info").css('background', 'url(<?php echo $GLOBALS["IMAGES_DIR"];?>info.png)');
        $("#info").text('<?php echo htmlchar($text);?>');
	$("#info").slideToggle("normal");
	setTimeout("$('#info').fadeOut();",3000);
</script>
<?php
}


function infoerr($text=""){
?>
<script>
$("#info").css('background', 'url(<?php echo $GLOBALS["IMAGES_DIR"];?>infoerr.png)');
$("#info").text('<?php echo htmlchar($text);?>');
$("#info").slideToggle("normal");
setTimeout("$('#info').fadeOut();",4000);

</script>
<?php
die();
}


function okmsg($heading, $text, $fcomment=0, $idname="content")
{
if(!$fcomment){
$text=htmlchar($text);
 }else{
      $text=format_comment($text);
      }
$heading=htmlchar($heading);
?>
<script>
	var html = '<div class="okmsg">';
        html +=    '<table cellpadding="4" cellspacing="1" border="0" style="width:100%">';
        html +=    '<tr><td width="100%"><?php echo $text;?></td></tr></table></div>';
$("#pagetitle").text('<?php echo $GLOBALS["SITENAME"]." :: ".$heading;?>');
$("#contenttitle").text('<?php echo $heading;?>');
$("#<?php echo $idname;?>").html(html);
</script>
<?php
}


function errmsg($heading, $text, $fcomment=0, $idname="content")
{
if(!$fcomment){
$text=htmlchar($text);
 }else{
      $text=format_comment($text);
      }
$heading=htmlchar($heading);
?>
	<script>
	var html = '<div class="errmsg">';
        html +=    '<table cellpadding="4" cellspacing="1" border="0" style="width:100%">';
        html +=    '<tr><td width="100%"><?php echo $text;?></td></tr></table></div>';
	$("#pagetitle").text('<?php echo $GLOBALS["SITENAME"]." :: ".$heading;?>');
	$('#contenttitle').text('<?php echo $heading;?>');
	$("#<?php echo $idname;?>").html(html);
	</script>
<?php
die();
}


# Login Coockie
function logincookie($uid, $passhash, $updatedb = 1, $expires = 0x7fffffff)
{
 global $time,$ipencode;
    setcookie("p5w_uid", $uid, $expires, "/");
    setcookie("p5w_pass", $passhash, $expires, "/");

    mysql_query("UPDATE users SET lastaccess=$time, ip='$ipencode' WHERE uid=$uid") or sqlerr(__FILE__, __LINE__);
} 

# Logout Coockie
function logoutcookie()
{
    setcookie("p5w_uid", "", 0x7fffffff, "/");
    setcookie("p5w_pass", "", 0x7fffffff, "/");
    session_unset();
    session_destroy();
} 


# Forwarding
function go_to($page="")
{
     if($page){
	$arrsea=array(":",".");
	$arrrep=array("?","&");
	$page="#".str_replace($arrsea,$arrrep,$page);
      }

      $gotourl=$GLOBALS["BASEURL"]."/".$page;
	    ?>
	    <script>
	    window.location.replace("<?php echo $gotourl;?>");
	    </script>
	    <?php
    die();
}


function loggedinorreturn()
{
    global $CURUSER;

    if(!$CURUSER) {
	$arrsea=array(".php","%3F","?","/","&");
	$arrrep=array("",":",":","",".");
	$urlreq=str_replace($arrsea,$arrrep,$_SERVER["REQUEST_URI"]);

	$gurl=$GLOBALS["BASEURL"]."/#login?returnto=$urlreq";
	  ?>
		  <script type="text/javascript" src="/min/?f=js/<?php echo $GLOBALS["JQUERY"];?>"></script>
	  <script>
	  window.location.replace("<?php echo $gurl;?>");
	  </script>
	  <?php
     die();
    } 

    # ACCEPT NEW RULES
	if($CURUSER["acceptrules"] == "1" && $CURUSER["rules_accepted"] == "0") {
	      go_to("rules:act=new_rules");
	      die();
	    }
}


function mksecret($len = 12)
{
    $ret = "";
    for ($i = 0; $i < $len; $i++){
        $ret .= chr(mt_rand(0, 255));
      }
    return $ret;
}


# Generate Announce UserKey
function userkey($len = 14)
{
    $userkey="";$lastchrrand="";
    for ($i=1; $i<=$len; $i++)
    {
      $chrrand=mt_rand(1,3);

      if($chrrand==1){
	  $newkey = chr(mt_rand(97, 122));
	   }
	    elseif($chrrand==2)
		  {
	           $newkey = chr(mt_rand(48, 57));
		    }
		    elseif($chrrand==3)
		    {
			  $newkey = chr(mt_rand(65, 90));
		      }

	if($i <= 20){
	  $pos = strpos($userkey, $newkey);
	  if($pos !== false || $lastchrrand==$chrrand){
	    $newkey="";
	    $i=$i-1;
	  }
	}

    $lastchrrand=$chrrand;
    $userkey .= $newkey;
    }
    return $userkey;
}


function mkglobal($vars,$typ="string")
{
    if (!is_array($vars)){
        $vars = explode(":", $vars);
	}

	  foreach($vars as $v) {
	      if (isset($_GET[$v])){
		    if($typ == "string"){
			 $GLOBALS[$v] = htmlchar($_GET[$v]);
		      }
		    if($typ == "int"){
			 $GLOBALS[$v] = 0 + htmlchar($_GET[$v]);
		      }
	      }
	      elseif(isset($_POST[$v])){
		    if($typ == "string"){
			 $GLOBALS[$v] = htmlchar($_POST[$v]);
		      }
		    if($typ == "int"){
			 $GLOBALS[$v] = 0 + htmlchar($_POST[$v]);
		      }
	      }
	      else{
		    if($typ == "string"){
		        $GLOBALS[$v]="";
		      }
		    if($typ == "int"){
		        $GLOBALS[$v]="0";
		      }
	      }
	  } 

    return 1;
}


function hash_pad($hash, $len=20)
{
return str_pad($hash, $len);
}


function validemail($email)
{
    return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
} 

function validfilename($name)
{
    return preg_match('/^[^\0-\x1f:\\\\\/?*\xff#<>|]+$/si', $name);
} 

function sqlerr($file = '', $line = '')
{
infoerr(str_replace(chr(13), "",mysql_error() . ($file != '' && $line != '' ? " in $file, line $line " : "")));
}



# Bbcode Editor
function editor($text="",$h="260",$w="667",$cols="96"){
?>
<style type="text/css">

.markItUp * {
	margin:0px; padding:0px;
	outline:none;
}
.markItUp a:link,
.markItUp a:visited {
	color:#000;
	text-decoration:none;
}

.markItUp  {
	width:<?php echo $w+34;?>px;
	margin:0px;
	border:0px solid #F5F5F5;	
}
.markItUpContainer  {
	border:1px solid #DEA300;	
	background:#FFF url(editor/skins/images/bg-container.png) repeat-x top left;
	padding:6px 5px 2px 5px;
	font:11px Verdana, Arial, Helvetica, sans-serif;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
	border-radius: 6px 6px;
}
.markItUpEditor {
	font:12px 'Courier New', Courier, monospace;
	padding:10px;
	border:1px solid #CCA846;
	width:<?php echo $w;?>px;
	height:<?php echo $h;?>px;
	background:#FFF url(editor/skins/images/bg-editor.png) no-repeat;
	clear:both;
	line-height:18px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	 border-radius: 5px 5px;

}
.markItUpPreviewFrame	{
	background:#FFF url(editor/skins/images/bg-editor.png) no-repeat;
	overflow:auto;
	background-color:#FFFFFF;
	border:1px solid #CCA846;
	width:99.7%;
	height:340px;
	margin:0px 0;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	border-radius: 5px 5px;
}

.markItUpFooter {
	width:100%;
	cursor:n-resize;
}
.markItUpResizeHandle {
	overflow:hidden;
	width:22px; height:5px;
	margin-left:auto;
	margin-right:auto;
	background-image:url(editor/skins/images/handle.png);
	cursor:n-resize;
}

</style>
<!-- markItUp! -->
<script type="text/javascript" src="/min/?b=editor&amp;f=jquery.markitup.js,set.js"></script>
<link type="text/css" rel="stylesheet" href="/min/?b=editor&amp;f=skins/style.css,style.css" />

<script>
 $('#markItUp').markItUp(mySettings);

  $('#smilieslink').click(function() {
    $('#smilies').load("smilies.php");
    $('#smilies').show();
    $('#markItUp').focus();
  });
  </script>
  <!-- Smilies -->
  <div id="smilies" class="smilies"></div>
<div style="text-align:right;"><a id="smilieslink" href="javascript:;"><img style="text-align:center;" src="<?php echo $GLOBALS["IMAGES_DIR"];?>smiles.gif" title="Smilies"></a></div><center><textarea id="markItUp" name="descr" cols="<?php echo $cols;?>" rows="20"><?php echo $text;?></textarea></center>
<?php
}



function searchfield($s)
{
    return preg_replace(array('/\./', '/\[/', '/\]/', '/^\s*/s', '/\s*$/s', '/\s+/s'), array(" ", " ", " ", "", "", " "), strtolower($s));
}  

function fileext($name) 
{ 
  return (false === ( $p = strrpos($name, '.') ) ? '' : substr($name, ++$p));
}


function mksize($bytes, $decimals=2, $format=99){
	$byte_size = 1024;
	$byte_type = array(" KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");

	$bytes /= $byte_size;
	$i = 0;

	if($format == 99 || $format > 7){
		while($bytes > $byte_size){
			$bytes /= $byte_size;
			$i++;
		}
	}
	else{
		while($i < $format){
			$bytes /= $byte_size;
			$i++;
		}
	}

	$bytes = sprintf("%1.".$decimals."f", $bytes);
	$bytes .= $byte_type[$i];


	return $bytes;
			
}

function gdate($xtime){
return date("H:i:s - d.m.Y",$xtime);
}


function title($pagetitle,$contitle){
?>
  <script type="text/javascript">
  $("#pagetitle").text('<?php echo $GLOBALS["SITENAME"]." :: ".$pagetitle;?>');
  $('#contenttitle').html('<?php echo format_comment($contitle);?>');
  </script>
<?php
}

function write_log($typ, $text)
{
    $typ = sqlesc($typ);
    $text = sqlesc($text);
    $added = time();
    mysql_query("INSERT INTO `log_site` (`typ`, `added`, `text`) VALUES($typ, $added, $text)") or sqlerr(__FILE__, __LINE__);
}

function write_modcomment($uid, $moduid, $text)
{
global $time;

    $text = htmlchar($text);
    $text = sqlesc($text);
    mysql_query("INSERT INTO modcomments (added, cuid, moduid, txt) VALUES ($time, $uid, $moduid, $text)");
}


function fext($name) 
{ 
  return (false === ( $p = strrpos($name, '.') ) ? '' : substr($name, ++$p));
} 



function multiexplode ($delimiters,$string) {
    $ary = explode($delimiters[0],$string);
    array_shift($delimiters);
    if($delimiters != NULL) {
        foreach($ary as $key => $val) {
             $ary[$key] = multiexplode($delimiters, $val);
        }
    }
    return  $ary;
}



function add_user_to_ram($uid){
 if($uid){
 $ramres=mysql_query("SELECT uid, userkey, class, tmaxleechs, tmaxseeds FROM users WHERE uid=".sqlesc($uid)." AND enabled=1");
 $ramrow = mysql_fetch_row($ramres);
    if($ramrow){
	 $uskey=$ramrow[1];
         apc_store("us_$uskey",array(
				    "uid" => $ramrow[0],
				    "class" => $ramrow[2],
				    "tmaxleechs" => $ramrow[3],
				    "tmaxseeds" => $ramrow[4]
				    ));
       }
 }
}


function del_user_from_ram($userkey){
         apc_delete("us_$userkey");
}


function add_torrent_to_ram($tid){
 if($tid){
 $ramres=mysql_query("SELECT tid, info_hash, onlyup, doubleup, vip, name, catid, toruid FROM torrents WHERE tid=".sqlesc($tid)." AND banned= 0 AND activated = 1");
 $ramrow = mysql_fetch_row($ramres);
    if($ramrow){
	 $infohash=md5($ramrow[1]);
         apc_store("tor_$infohash",array(
				    "tid" => $ramrow[0],
				    "onlyup" => $ramrow[2],
				    "doubleup" => $ramrow[3],
				    "vip" => $ramrow[4],
				    "name" => $ramrow[5],
				    "catid" => $ramrow[6],
				    "toruid" => $ramrow[7]
				    ));
       }
   }
}

function del_torrent_from_ram($infohash){
	$infohash=md5($infohash);
         apc_delete("tor_$infohash");
}


function add_clients_to_ram(){

 $ramrescli=mysql_query("SELECT agent, banned FROM clients");

$clients=array();
    while($ramrowcli = mysql_fetch_row($ramrescli)){
	 $clientname=$ramrowcli[0];
         $clients[$clientname] = $ramrowcli[1];
       }
         apc_delete('clients');
         apc_store("clients",$clients);
   }



require_once("inc/global.php");

?>