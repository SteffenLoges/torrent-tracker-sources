<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/config.php");

  $time=time();

// IP Validation //
function validip($ip)
{
	if (!empty($ip) && $ip == long2ip(ip2long($ip)))
	{
		// reserved IANA IPv4 addresses
		// http://www.iana.org/assignments/ipv4-address-space
		$reserved_ips = array (
				array('0.0.0.0','2.255.255.255'),
				array('10.0.0.0','10.255.255.255'),
				array('127.0.0.0','127.255.255.255'),
				array('169.254.0.0','169.254.255.255'),
				array('172.16.0.0','172.31.255.255'),
				array('192.0.2.0','192.0.2.255'),
				array('192.168.0.0','192.168.255.255'),
				array('255.255.255.0','255.255.255.255')
		);

		foreach ($reserved_ips as $r)
		{
				$min = ip2long($r[0]);
				$max = ip2long($r[1]);
				if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
		}
		return true;
	}
	else return false;
}

// Patched function to detect REAL IP address if it's valid
function getip() {
   if (isset($_SERVER)) {
     if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && validip($_SERVER['HTTP_X_FORWARDED_FOR'])) {
       $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
     } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && validip($_SERVER['HTTP_CLIENT_IP'])) {
       $ip = $_SERVER['HTTP_CLIENT_IP'];
     } else {
       $ip = $_SERVER['REMOTE_ADDR'];
     }
   } else {
     if (getenv('HTTP_X_FORWARDED_FOR') && validip(getenv('HTTP_X_FORWARDED_FOR'))) {
       $ip = getenv('HTTP_X_FORWARDED_FOR');
     } elseif (getenv('HTTP_CLIENT_IP') && validip(getenv('HTTP_CLIENT_IP'))) {
       $ip = getenv('HTTP_CLIENT_IP');
     } else {
       $ip = getenv('REMOTE_ADDR');
     }
   }

   return $ip;
 }



# Connect Database
function dbconn()
{
    global $mysql_host, $mysql_user, $mysql_pass, $mysql_db, $_SERVER, $dbconn;

    $dbconn = mysql_connect($mysql_host, $mysql_user, $mysql_pass);

    mysql_select_db($mysql_db) or die('dbconn: mysql_select_db: ' + mysql_error());

  register_shutdown_function("dbclose");
} 

# Close Database
function dbclose()
{
global $dbconn;
  if($dbconn){
	 mysql_close($dbconn);
	}
}


function err($msg)
{
    benc_resp(array("failure reason" => array("type" => "string", "value" => $msg)));
    dbclose();
    die();
}


function benc_resp($d)
{
    benc_resp_raw(benc(array("type" => "dictionary", "value" => $d)));
}


function benc_resp_raw($x)
{
    header('Content-Type: text/plain');
    header("Pragma: no-cache");
    echo $x;
}



function portblacklisted($port)
{
    // direct connect
    if ($port >= 411 && $port <= 413) return true;

    // bittorrent
    if ($port >= 6881 && $port <= 6889) return true;

    // kazaa
    if ($port == 1214) return true;

    // gnutella
    if ($port >= 6346 && $port <= 6347) return true;

    // emule
    if ($port == 4662) return true;

    // winmx
    if ($port == 6699) return true;

    return false;
}


  function hash_pad($hash, $len=20)
  {
  return str_pad($hash, $len);
  }

# ENCODE IP
  function ipe($ipe){
      return inet_pton($ipe);
  }

# DECODE IP
  function ipd($ipd){
      return inet_ntop($ipd);
  }


function add_clients_to_ram(){

 $ramrescli=mysql_query("SELECT agent, banned FROM clients");


    while($ramrowcli = mysql_fetch_row($ramrescli)){
	 $clientname=$ramrowcli[0];
         $clients[$clientname] = $ramrowcli[1];
       }
         apc_delete('clients');
         apc_store("clients",$clients);
   }

?>