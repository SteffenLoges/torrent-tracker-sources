<?php
function clean_db(){ 
    set_time_limit(0);
    ignore_user_abort(1);


 $time = time();

  $clean_time1 = apc_fetch("clean_time1");

  $clean_time2 = apc_fetch("clean_time2");

# CLEANTIME1
 if(!$clean_time1 || $time > $clean_time1){


	# UPDATE CLEANTIME1 TIME
	  apc_store("clean_time1",($time+$GLOBALS["CLEAN_TIME1"]));

	# DELETE OLD PEERS
	  $del_peer_time = $time - round($GLOBALS["DEL_PEERS_TIME"]);
	  mysql_query("DELETE FROM peers WHERE lastaction < $del_peer_time");

	# UPDATE TORRENT STATS (LEECHERS, SEEDERS, COMMENTS)
	  $upstatres=mysql_query("SELECT torrents.tid, torrents.seeders, torrents.leechers, torrents.comments ,SUM(IF(peers.tleft=0, 1, 0)), SUM(IF(peers.tleft > 0, 1, 0)), COALESCE(c.comid, 0) 
	    FROM torrents
	      LEFT JOIN (SELECT tid, COUNT(*) AS comid FROM comments) AS c ON torrents.tid = c.tid 
		LEFT JOIN peers ON torrents.tid = peers.ptid  
		  GROUP BY tid") or sqlerr(__FILE__, __LINE__);

	  while($uprow = mysql_fetch_row($upstatres)) {
		   $tid = $uprow[0];
		   $update = array();

		     # UPDATE SEEDERS
		     if($uprow[1] != $uprow[4]){
			   $update[] = "seeders = " . $uprow[4];
		       }

		     # UPDATE LEECHERS
		     if($uprow[2] != $uprow[5]){
			   $update[] = "leechers = " . $uprow[5];
		       }

		     # UPDATE COMMENTS
		     if($uprow[3] != $uprow[6]){
			   $update[] = "comments = " . $uprow[6];
		       }

		       # UPDATE TORRENTS DATEBASE
			if(count($update)){
			    mysql_query("UPDATE torrents SET " . implode(",", $update) . " WHERE tid = $tid");
			  }
	     } 

	# DELETE OLD SHOUTBOX ENTRIES
	    $shres=mysql_query("SELECT MAX(shid) FROM shoutbox");
	    $shrow=mysql_fetch_row($shres);
	    $delshids=max(0,$shrow[0]-150);
	    if($delshids){
		mysql_query("DELETE FROM shoutbox WHERE shid < $delshids") or sqlerr(__FILE__, __LINE__);
	    }

 }


# CLEANTIME2
 if(!$clean_time2 || $time > $clean_time2){

	# UPDATE CLEANTIME2 TIME
	  apc_store("clean_time2",($time+$GLOBALS["CLEAN_TIME2"]));


	# MARK INACTIVE TORRENTS DEAD
	  $max_tor_dead_time = $time - round($GLOBALS["MAX_DEAD_TORRENT_TIME"]);
	  mysql_query("UPDATE torrents SET visible='0' WHERE visible='1' AND lastaction < $max_tor_dead_time");

	# DELETE NEWLY REGISTERED USER ACCOUNTS WHICH WERE NOT ACTIVATED
	  $del_not_conf_user_time = $time - $GLOBALS["SIGNUP_TIMEOUT"];
	  mysql_query("DELETE FROM users WHERE confirmed = '0' AND added < $del_not_conf_user_time");


	# DELETE DISABLED AND INACTIVE USER ACCOUNTS
	  $inactive_time = $time - $GLOBALS["INACTIVE_TIMEOUT"];
	  $disabled_time = $time - $GLOBALS["DISABLED_TIMEOUT"];
	  $maxclass = UC_POWER_USER;
	  $res = mysql_query("SELECT uid FROM users WHERE confirmed='1' AND ((enabled='1' AND class <= $maxclass AND lastaccess < $inactive_time) OR (enabled='0' AND lastaccess < $disabled_time))");

	  while($arr = mysql_fetch_row($res)){
		delete_acct($arr[0]); 
	    }


	# REMOVE EXPIRED WARNINGS
	  $delwarntime = $time - $GLOBALS["DEL_WARN_TIME"];
	  $warnres = mysql_query("SELECT uid,username FROM users WHERE warnpoints > 0 AND lastwarned < $delwarntime") or sqlerr(__FILE__, __LINE__);
	  if (mysql_num_rows($warnres) > 0) {

	      $msgsubject = btlng423;
	      $msg = btlng424;

		while ($arr = mysql_fetch_row($warnres)) {

		    $wuid = $arr[0];
		    $wusername = $arr[1];

		      mysql_query("UPDATE users SET warnpoints = 'warnpoints - 1', lastwarned = '".time()."' WHERE uid = $wuid") or sqlerr(__FILE__, __LINE__);

			  # SEND USER PM
			    mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
			    ".implode(",", array_map("sqlesc", array(
			      0, 
			      $wuid, 
			      4,  
			      $time,
			      $msgsubject,
			      $msg))).")") or sqlerr(__FILE__, __LINE__);

		    $log_msg = str_replace(array("%uid%","%username%"),array($wuid,$wusername),btlng425);

		    write_log("delwarn", $log_msg);
		    write_modcomment($wuid, 0, $msgsubject);
		} 
	  }


       # DISABLE ACCOUNTS WHERE warnpoints >= $GLOBALS["MAX_USER_WARN_POINTS"]
	$maxpoint=$GLOBALS["MAX_USER_WARN_POINTS"];
	$selpoints = mysql_query("SELECT uid FROM users WHERE warnpoints >= $maxpoint AND enabled = 1") or sqlerr(__FILE__, __LINE__);

	  $disaccids=array();

	    while($pointsrow=mysql_fetch_row($selpoints)){
		  $disuid=$pointsrow[0];
		  $disaccids[]=$disuid;
	      }

        if(count($disaccids)){
             mysql_query("UPDATE users SET enabled = 0 WHERE uid IN (" . join(",", $disaccids) . ")") or sqlerr(__FILE__, __LINE__);
	    } 


       # PROMOTE POWER USERS
	$prolimit = $GLOBALS["PRO_POWER_USERS_LIMIT"];
	$minratio = $GLOBALS["PRO_POWER_USERS_RATIO"];
	$maxdt = time() - (86400 * 31);
	$pres = mysql_query("SELECT uid,username FROM users WHERE class = ".sqlesc(UC_USER)." AND uploaded >= $prolimit AND (uploaded / downloaded) >= $minratio AND added < $maxdt") or sqlerr(__FILE__, __LINE__);
	if (mysql_num_rows($pres) > 0) {

	    $msgsubject = btlng426;
	    $msg = btlng427;

	      while ($arr = mysql_fetch_row($pres)) {

		  $prouid=$arr[0];
		  $prousername=$arr[1];

		     mysql_query("UPDATE users SET class = ".sqlesc(UC_POWER_USER)." WHERE uid = $prouid") or sqlerr(__FILE__, __LINE__);

			  # SEND USER PM
			    mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
			    ".implode(",", array_map("sqlesc", array(
			      0, 
			      $prouid, 
			      4,  
			      $time,
			      $msgsubject,
			      $msg))).")") or sqlerr(__FILE__, __LINE__);

		    $log_msg = str_replace(array("%uid%","%username%"),array($prouid,$prousername),btlng428);

		  write_log("promotion", $log_msg);
		  write_modcomment($prouid, 0, btlng429);
	      } 
	} 



      # DEMOTE POWER USERS
      $minratio = $GLOBALS["DEMOTE_POWER_USERS_RATIO"];
      $dres = mysql_query("SELECT uid,username FROM users WHERE class = ".sqlesc(UC_POWER_USER)." AND (uploaded / downloaded) < $minratio") or sqlerr(__FILE__, __LINE__);
      if (mysql_num_rows($dres) > 0) {

	    $msgsubject = btlng430;
	    $msg = str_replace(array("%minratio%"),array($minratio),btlng431);

	      while ($arr = mysql_fetch_row($dres)) {

		    $duid=$arr[0];
		    $dusername=$arr[1];

		      mysql_query("UPDATE users SET class = ".sqlesc(UC_USER)." WHERE uid = $duid") or sqlerr(__FILE__, __LINE__);

			    # SEND USER PM
			      mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
			      ".implode(",", array_map("sqlesc", array(
				0, 
				$duid, 
				4,  
				$time,
				$msgsubject,
				$msg))).")") or sqlerr(__FILE__, __LINE__);

		      $log_msg = str_replace(array("%uid%","%username%"),array($prouid,$prousername),btlng432);

		  write_log("demotion", $log_msg);
		  write_modcomment($duid, 0, btlng433);
	      } 
         } 



     # UPDATE SITE STATS
	$peerstats_res=mysql_query("SELECT SUM(IF(tleft=0, 1, 0)), SUM(IF(tleft > 0, 1, 0)) FROM peers");
	$peerstats_row=mysql_fetch_row($peerstats_res);

	  if(!$peerstats_row[0]){
	  $peerstats_row[0]=0;
	  }
	  if(!$peerstats_row[1]){
	  $peerstats_row[1]=0;
	  }

	$total_size_res=mysql_query("SELECT SUM(downloaded), SUM(uploaded) FROM users WHERE enabled = 1");
	$total_size_row=mysql_fetch_row($total_size_res);

	$total_userx_res=mysql_query("SELECT COUNT(*), SUM(IF(confirmed=0, 1, 0)), SUM(IF(enabled=0, 1, 0)) FROM users");
	$total_userx_row=mysql_fetch_row($total_userx_res);

	$total_torr_res=mysql_query("SELECT COUNT(*), SUM(IF(visible=0, 1, 0)) FROM torrents");
	$total_torr_row=mysql_fetch_row($total_torr_res);

	mysql_query("INSERT INTO site_info (seeders, leechers, downloaded, uploaded,registered, unverified, disabled, torrents, dead) VALUES (".$peerstats_row[0].",".$peerstats_row[1].",".$total_size_row[0].",".$total_size_row[1].", 
		      ".$total_userx_row[0].", ".$total_userx_row[1].", ".$total_userx_row[2].", ".$total_torr_row[0].", ".$total_torr_row[1].")
		    on duplicate key update
		      seeders = values(seeders), 
		      leechers = values(leechers), 
		      downloaded = values(downloaded), 
		      uploaded = values(uploaded),
		      registered = values(registered),
		      unverified = values(unverified),
		      disabled = values(disabled),
		      torrents = values(torrents),
		      dead = values(dead)") or sqlerr(__FILE__, __LINE__);


    # DELETE OLD / DEAD AND NOT ACTIVATED TORRENTS
           if($GLOBALS["MAX_TORRENT_TTL"]) {
		$delete_time = time() - $GLOBALS["MAX_TORRENT_TTL"];
                $max_nactivated_time = time() - $GLOBALS["MAX_NOTACTIVATED_TOR_TIME"];
                $res = mysql_query("SELECT tid, name, toruid FROM torrents WHERE (added < $max_nactivated_time AND activated=0) OR (lastaction < $delete_time AND activated=1)");
		  $days= round($GLOBALS["MAX_TORRENT_TTL"] / 86400);
		while ($arr = mysql_fetch_row($res)) {
		    deletetorrent($arr[0]);
			$msg = str_replace(array("%torname%","%days%"),array($arr[1],$days),btlng436);

				# SEND USER PM
				  mysql_query("INSERT INTO messages (sender, receiver, inbox, added, subject, msg) VALUES (
				  ".implode(",", array_map("sqlesc", array(
				    0, 
				    $arr[2], 
				    4,  
				    $time,
				    btlng435,
				    $msg))).")") or sqlerr(__FILE__, __LINE__);

		    write_log("torrentdelete", str_replace(array("%tid%","%torname%","%days%"),array($arr[0],$arr[1],$days),btlng437));
		} 

	    } 
  




        while (1) {
        // Collect all torrent ids from database
        $res = mysql_query("SELECT tid FROM torrents") or sqlerr(__FILE__, __LINE__);
        $all_torrents = array();
        while ($row = mysql_fetch_row($res)) {
            $id = $row[0];
            $all_torrents[$id] = 1;
	apc_fetch("peers_tid_$id");
        }
    
        // Open torrent directory for scanning
        $dp = opendir($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["TORRENT_DIR"]);
        if (!$dp){
            break;
	  }
    
        // Collect all .torrent files matching "id.torrent" filename pattern
        $all_files = array();
        while (($file = readdir($dp)) !== false) {
            if (!preg_match('/^(\d+)\.torrent$/', $file, $m))
                continue;
            $id = $m[1];
            $all_files[$id] = 1;
            
            // If no database entry exists, delete the orphaned file
            if (!isset($all_torrents[$id]) || $all_torrents[$id] == 0){
                unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["TORRENT_DIR"] . "/$file");
	      }
        }
        closedir($dp);

        
        // No torrents or files to consider
        if (!count($all_torrents) && !count($all_files)){
            break;
	  }
    
        // Enumerate and delete torrents which have no according .torrent file
        $delids = array();

        foreach (array_keys($all_torrents) as $k) {
            if (isset($all_files[$k]) && $all_files[$k]){
                continue;
	      }
            $delids[] = $k;
            unset($all_torrents[$k]);
        }

        if (count($delids)){
            mysql_query("DELETE FROM torrents WHERE tid IN (" . join(",", $delids) . ")");
           }
    
        // Enumerate and delete peers which have no according torrent in the DB
        $res = mysql_query("SELECT ptid FROM peers GROUP BY ptid") or sqlerr(__FILE__, __LINE__);
        $delids = array();

        while ($row = mysql_fetch_row($res)) {
            $id = $row[0];
            if (isset($all_torrents[$id]) && $all_torrents[$id]){
                continue;
	      }
            $delids[] = $id;
        }

        if(count($delids)){
            mysql_query("DELETE FROM peers WHERE ptid IN (" . join(",", $delids) . ")");
          }
    
        // Enumerate and delete file entries which have no according torrent in the DB
        $res = mysql_query("SELECT filestid FROM files GROUP BY filestid") or sqlerr(__FILE__, __LINE__);
        $delids = array();

        while ($row = mysql_fetch_row($res)) {
            $id = $row[0];
            if ($all_torrents[$id]){
                continue;
		}
            $delids[] = $id;
        }

        if(count($delids)){
             mysql_query("DELETE FROM files WHERE filestid IN (" . join(",", $delids) . ")");
	    }    
        break;
    }



 }
















}

?>