<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}
if(isset($_GET["dl"])){$dl=0+$_GET["dl"];}else{$dl="";}


if (!is_valid_id($tid)){
    errmsg(btlng32,btlng328);
 }



$rnfo = mysql_query("SELECT name, info_hash FROM torrents WHERE tid=".sqlesc($tid)) or sqlerr(__FILE__, __LINE__);
$anfo = mysql_fetch_row($rnfo) or errmsg(btlng32,btlng328);


if ($dl=="1") {
       $nfop=$GLOBALS["XIMGDEPOT_DIR"]."/nfo/nfo-".md5($tid.$anfo[1]).".png";
      header("Content-type: image/png");
      header("Content-Disposition: attachment; filename=".$anfo[0].".png");
      header("Content-Length: ".filesize($nfop));
      readfile($nfop);
    die();
}

  title(btlng329." ".$anfo[0],btlng329." ".$anfo[0]);

  echo "<br><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\" >";

    echo "<div class=\"tr\" ><div class=\"td\" style=\"border-bottom:1px solid #ABABAB;background:#fff url($stylelink/h40.png) repeat-x;padding:10px;\"><center><a href=\"".$GLOBALS["BASEURL"]."/viewnfo.php?tid=$tid&dl=1\" title=\"".btlng330." ".$anfo[0]."\"><b>".btlng330."</b></a></center></div></div>\n";

    echo "<div class=\"tr\"><div class=\"td\"><br><center><img class=\"imgborder\" src=\"".$GLOBALS["XIMGDEPOT_DIR"]."/nfo/nfo-".md5($tid.$anfo[1]).".png\" title=\"".btlng329." ".$anfo[0]."\"></center><br></div></div>\n";

  echo "</div></div>";


?>