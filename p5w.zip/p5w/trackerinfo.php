<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();
  title(btlng4_11,btlng4_11);

    $percent = min(100, round(exec('ps ax | grep -c apache2') / 150 * 100));

    if($percent >= 89){
	    $backgclr="#ff0000";
	 }
    elseif($percent >= 80){
	    $backgclr="#FF5E01";
	 }
    elseif($percent >= 65){
	    $backgclr="#FF9705";
	 }
    elseif($percent >= 50){
	    $backgclr="#FFDD00";
	 }
    else{
	    $backgclr="#88FF00";
	 }

    $width = $percent * 4;

 $statres = mysql_query("SELECT * FROM site_info") or sqlerr(__FILE__, __LINE__);
  $statrow = mysql_fetch_row($statres);

?>


<div class="shadow trackerinfo1">
  <center><b>Tracker Stats</b></center>
</div>
<div class="shadow trackerinfo2">
    <div style="-moz-border-radius:3px;-webkit-border-radius:3px;">
	  <div class="table">
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5" ><?php echo btlng451;?></div><div class="td trackerinfo6"><?php echo $statrow[1];?></div>
	      </div>
	      <div class="tr trackerinfo4" >
		  <div class="td trackerinfo5"><?php echo btlng452;?></div><div class="td trackerinfo6"><?php echo $statrow[2];?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5"><?php echo btlng453;?></div><div class="td trackerinfo6"><?php echo mksize($statrow[3]);?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5"><?php echo btlng454;?></div><div class="td trackerinfo6"><?php echo mksize($statrow[4]);?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5"><?php echo btlng455;?></div><div class="td trackerinfo6"><?php echo $statrow[5];?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo btlng456;?></div><div class="td trackerinfo6"><?php echo $statrow[6];?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo btlng457;?></div><div class="td trackerinfo6"><?php echo $statrow[7];?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5"><?php echo btlng4_1;?></div><div class="td trackerinfo6"><?php echo $statrow[8];?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo btlng458;?></div><div class="td trackerinfo6"><?php echo $statrow[8] - $statrow[9];?></div>
	      </div>
	      <div class="tr trackerinfo4">
		  <div class="td trackerinfo5"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo btlng459;?></div><div class="td trackerinfo6"><?php echo $statrow[9];?></div>
	      </div>
	  </div>
    </div>
</div>


<br>


<div class="shadow trackerinfo7">
  <center><b>Webserver-Prozesse</b></center>
</div>

<div class="shadow trackerinfo8">
    <div style="-moz-border-radius:3px;-webkit-border-radius:3px;width:<?php echo $width?>px;background:<?php echo $backgclr?> repeat-x scroll 0 0;">
	  <center><?php echo $percent?>%</center>
    </div>
</div>


<br>


<div class="shadow trackerinfo7">
  <center><b>Systemauslastung (Durchschnittswerte)</b></center>
</div>

<div class="shadow trackerinfo8">
<div><center> 
  <?php
      $loadavg = explode(" ", exec("cat /proc/loadavg"));
      echo $loadavg[0]*100, "% (1min) - ", $loadavg[1]*100, "% (5min) - ", $loadavg[2]*100, "% (15min)";
  ?>
</center></div>
</div>