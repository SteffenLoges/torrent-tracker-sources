<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

title(btlng4_9,btlng4_9." [img=".$GLOBALS["BASEURL"]."/$stylelink/users.png] ");

$limit = "";$count="";$pages="";

if(isset($_GET["letter"])){$letter=htmlchar($_GET["letter"]);}else{$letter="";}
if(isset($_GET["search"])){$search=htmlchar($_GET["search"]);}else{$search="";}
if(isset($_GET["class"])){$class=0+$_GET["class"];}else{$class="";}
if(isset($_GET["ppage"])){$perpage=0+$_GET["ppage"];}else{$perpage=15;}
if(isset($_GET["pno"])){$page=0+$_GET["pno"];}else{$page=1;}
if(isset($_GET["hidehead"])){$hidehead=0+$_GET["hidehead"];}else{$hidehead=0;}

  if($class == '-' || !is_valid_id($class)){
    $class = '';
  }

 if($search != '' && !$class){

      $query = "username LIKE '%".sqlwildcardesc($search)."%' AND confirmed='1'";

        }elseif(!$search  && $class){

	        $query = "class = ".sqlesc($class)." AND confirmed='1'";

	    }elseif($search  && $class){

		    $query = "username LIKE '%".sqlwildcardesc($search)."%' AND class = ".sqlesc($class)." AND confirmed = '1'";

		}else{
			if(strlen($letter) > 1){
			      errmsg(btlng32,btlng263);
			      }

			      if($letter == "" || strpos("abcdefghijklmnopqrstuvwxyz", $letter) === false){
					$letter = "a";
				      }
					  $query = "username LIKE '".sqlwildcardesc($letter)."%' AND confirmed='1'";
		      }


	    # PAGER
		    $res = mysql_query("SELECT COUNT(*) FROM users WHERE $query");
		    $row = mysql_fetch_row($res);
		    $count = $row[0];
		if($count){
		  $pages = ceil($count / $perpage);
		    if($page > $pages){
			    $page=$pages;
			    }else{
				$page=$page;
				}

			    $limit = ($page - 1) * $perpage;
			    $limit = " LIMIT $limit, $perpage ";
			 }


?>

<script>

        PageClick = function(pageclickednumber) {
            $("#pager").pager({ pagenumber: pageclickednumber, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
		$.get("<?php echo $GLOBALS["BASEURL"];?>/users.php", { letter: "<?php echo $letter;?>", search: "<?php echo $search;?>", pno: pageclickednumber, ppage: "<?php echo $perpage;?>", hidehead: 1},
   		function(data){
    		 $('#userres').html(data);
   		});
        }

  $("#pager").pager({ pagenumber: <?php echo $page;?>, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });


	$('#usersearch').click(function() {
	  $.get("<?php echo $GLOBALS["BASEURL"];?>/users.php", { search: $('#search').val(), class:$('#sclass option:selected').val(), hidehead: 1}, function(data){
	      $('#userres').html(data);
	      });
	});

</script>
<?php



# USERS
$resuser = mysql_query("SELECT username, added, lastaccess, class, country, uid FROM users WHERE $query ORDER BY username $limit") or sqlerr(__FILE__, __LINE__);

if(!$hidehead){
  echo "<div class=\"shadow\">
        <div class=\"table\" style=\"margin: 0 auto;\">

        <div class=\"divbottom\"><div class=\"tr\"><div class=\"td\">".btlng261." : <input type=\"text\" size=\"30\" id=\"search\">
	  <select id=\"sclass\">\n
	  <option value=\"-\">".btlng262."</option>\n";

      for ($i = 0;$i<=UC_ROOT;++$i)
      {
	if($c = get_user_class_name($i)){
	           echo "<option value=\"$i\"" . ($class && $class == $i ? " selected" : "") . ">$c</option>\n";
	       }
       }

    echo "</select> 
	  <a href=\"javascript:;\" id=\"usersearch\" class=\"buttonsilver\">".btlng261."</a>
          </div></div></div>\n


          <br><div class=\"divbottom\"><div class=\"tr\"><div class=\"td\">";

	  for ($i = 97; $i < 123; ++$i)
	  {
		  $l = chr($i);
		  $L = chr($i - 32);

		  if ($l == $letter){
		      echo "<a class=\"lettercurrent\"><b>$L</b></a>\n";
		  }else{
		      echo "<a class=\"letter\" href=\"".$GLOBALS["BASEURL"]."/#users?letter=$l\"><b>$L</b></a>\n";
		      }
	  }
     echo "<br><br></div></div></div>\n";

# PAGER
  if($pages > 1){
     echo "<div class=\"divbottom\"><div class=\"tr\"><div class=\"td\"><div id=\"pager\"></div><br></div>
           </div></div>\n";
   }
}

echo "<div id=\"userres\" >";

# USER RESULTS HEADER

    $tdstyle=" border-left:1px solid #ccc;padding:8px;vertical-align:top; ";
     echo "<div class=\"divbottom\"><div class=\"tr\" style=\"background:#fff url($stylelink/h40.png) repeat-x;\">
	   <div class=\"td\" style=\"$tdstyle width: 138px;border-left:0px solid #ccc;\"><b><i>".btlng264."</i></b></div>
	   <div class=\"td\" style=\"$tdstyle width: 160px;\"><b><i>".btlng265."</b></i></div>
	   <div class=\"td\" style=\"$tdstyle width: 160px;\"><b><i>".btlng266."</b></i></div>
	   <div class=\"td\" style=\"$tdstyle width: 130px;\"><b><i>".btlng189."</b></i></div>
	   <div class=\"td\" style=\"$tdstyle width: 90px;\"><center><b><i>".btlng267."</b></i></center></div>
           </div></div>\n";

# USER RESULTS

      while($rowuser = mysql_fetch_row($resuser)) {
	  if($rowuser[4]){
	      $flagimg="<center><img  src=\"".$GLOBALS["IMAGES_DIR"]."flags/".$rowuser[4].".png\"></center>";
	    }else{$flagimg="";}
	echo "<div class=\"divbottom\"><div class=\"tr\">
	      <div class=\"td\" style=\"$tdstyle width: 138px;border-left:0px solid #ccc;\"><a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=".$rowuser[5]."\"><font color=\"".get_class_color($rowuser[3])."\"><b>".$rowuser[0]."</b></font></a></div>
	      <div class=\"td\" style=\"$tdstyle width: 160px;\">".gdate($rowuser[1])."</div>
	      <div class=\"td\" style=\"$tdstyle width: 160px;\">".gdate($rowuser[2])."</div>
	      <div class=\"td\" style=\"$tdstyle width: 130px;\"><font color=\"".get_class_color($rowuser[3])."\"><b>".get_user_class_name($rowuser[3])."</b></font></div>
	      <div class=\"td\" style=\"$tdstyle width: 90px;\">$flagimg</div>
	      </div></div>\n";
	}
     echo "</div>

     </div>";


?>