<?php
require_once('inc/func.php');
echo format_comment($_POST["data"]);
?>  
