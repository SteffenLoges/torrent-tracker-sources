<?php
require_once("inc/func.php");
dbconn(); 

 function trckurls($img,$link,$name){
    global $stylelink;
    echo "<a style=\"background:url($stylelink/$img) no-repeat;padding: 2px 20px;\" title=\"$name\" href=\"".$GLOBALS["BASEURL"]."/#$link\" id=\"historylink\">$name</a>";
  }


?>
  <script>
	$(function(){
		$("#clock1").MyDigitClock({
			fontSize:21,  
			fontColor: "#000", 
			fontWeight:"bold", 
			background:'transparent',
			bShowHeartBeat:true
			});

	});
	</script>
<?php

  if($CURUSER){

    # Site Offline Message for Root and Admin
    if (!$GLOBALS["SITE_ONLINE"] && $CURUSER["class"] >= UC_ADMIN){
?>
	<script>
        $("#message").text('<?php echo btlng0_0;?>');
	$("#message").css('display','block');
	</script>
<?php
}
	if(!isset($_SESSION["udata"]["unreadmsgchktime"]) || $time > $_SESSION["udata"]["unreadmsgchktime"]){
	      $_SESSION["udata"]["unreadmsgchktime"] = $time + 30;
		$cnttotmsgres=mysql_query("SELECT COUNT(*) FROM messages WHERE unread=1 AND receiver=".$CURUSER["uid"]);
		$cnttotmsgrow = mysql_fetch_row($cnttotmsgres);
		    $_SESSION["udata"]["unreadedtotmsgs"]=$cnttotmsgrow[0];
	}

      $unreadedtotmsgs=$_SESSION["udata"]["unreadedtotmsgs"];

if($unreadedtotmsgs){

    $totmsg=str_replace("%totmsg%","<font color=\"#EA0000\">".$unreadedtotmsgs."</font>",btlng141);

	echo "	<script>
		var html = '<a href=\"".$GLOBALS["BASEURL"]."/#messages\">$totmsg</a>';
		html +=    '';
		  $(\"#msgwarn\").html(html);
		  $(\"#msgwarn\").css('display','block');
		</script>";
}else{
	echo "	<script>
		  $(\"#msgwarn\").css('display','none');
		</script>";
}

?>

<div class="navibar"><a href="<?php echo $GLOBALS["BASEURL"];?>/#userdetails?uid=<?php echo $CURUSER["uid"];?>"><font color="black">.:<?php echo ucfirst($CURUSER["username"]);?>:.</font></a></div>

<div class="table">

    <div class="tr">
      <div class="td"><font color="green"><b><?php echo btlng153;?> : </b></font></div>
      <div class="td"><?php echo mksize($CURUSER["downloaded"]);?></div>
    </div>

    <div class="tr">
      <div class="td"><font color="red"><b><?php echo btlng152;?> : </b></font></div>
      <div class="td"><?php echo mksize($CURUSER["uploaded"]);?></div>
    </div>
<?php
	  if($CURUSER["downloaded"]){

	  $ratio = $CURUSER["uploaded"] / $CURUSER["downloaded"];

	  if($ratio >= 10){$ratioimg = "pirate2";}
	  else if ($ratio >= 7.5){$ratioimg = "bow";}
	  else if ($ratio >= 5){$ratioimg = "yikes";}
	  else if ($ratio >= 3.5){$ratioimg = "w00t";}
	  else if ($ratio >= 2){$ratioimg = "grin";}
	  else if ($ratio >= 1){$ratioimg = "smile1";}
	  else if ($ratio >= 0.9){$ratioimg = "innocent";}
	  else if ($ratio >= 0.5){$ratioimg = "noexpression";}
	  else if ($ratio >= 0.25){$ratioimg = "sad";}
	  else if ($ratio >= 0.1){$ratioimg = "cry";}
	  else{$ratioimg = "shit";}
	  }
	  else{
	      $ratioimg="empty";
	      $ratio=0;
            }

?>
    <div class="tr">
      <div class="td"><b><?php echo btlng4_7;?> : </b></div>
      <div class="td"><font color="<?php echo get_ratio_color($ratio);?>"> <?php echo number_format($ratio, 2);?></font> &nbsp; <img src="<?php echo $GLOBALS["IMAGES_DIR"]."smilies/$ratioimg.gif";?>" width="14" title="<?php echo $ratioimg;?>"></div>
    </div>

    <div class="tr navi_in">
      <div class="td"><b><?php echo btlng4_8;?> : </b></div>
      <div class="td"><?php echo getip();?></div>
    </div>

</div>


	
<div class="navibar">.:<?php echo btlng1;?>:.</div>
<div class="navi_in"><?php trckurls("home.png", "home",btlng2);?></div>
<div class="navi_in"><?php trckurls("info.png", "trackerinfo",btlng4_11);?></div>
<div class="navi_in"><?php trckurls("torrent.png", "torrents",btlng4_1);?></div>
<div class="navi_in"><?php trckurls("my.png", "torrents?incldead=2&my=1",btlng273_2);?></div>
<div class="navi_in"><?php trckurls("torrentup.png", "upload",btlng4_2);?></div>
<div class="navi_in"><?php trckurls("message.png", "messages",btlng4_3);?></div>
<div class="navi_in"><?php trckurls("users.png", "users",btlng4_9);?></div>
<div class="navi_in"><?php trckurls("friends.png", "friends",btlng4_5);?></div>
<div class="navi_in"><?php trckurls("profile.png", "profile",btlng4_10);?></div>
<div class="navi_in"><?php trckurls("ximgdepot.png", "ximgdepot",btlng372);?></div>
<div class="navi_in"><?php trckurls("public.png", "ximgdepotpub",btlng372_2);?></div>
<div class="navi_in"><?php trckurls("language.png", "language",btlng531);?></div>
<div class="navi_in"><?php trckurls("stylesheet.png", "style",btlng530);?></div>
<div class="navi_in"><?php trckurls("rules.png", "rules",btlng4_17);?></div>
<div class="navi_in"><?php trckurls("logout.png", "logout",btlng4_4);?></div>

<?php 
 if(get_user_class() >= UC_MODERATOR){
?>

<div class="navibar">.:Moderator:.</div>
<div class="navi_in"><?php trckurls("bann.png", "bannx",btlng4_14);?></div>
<div class="navi_in"><?php trckurls("bann.png", "bannx?act=user",btlng4_15);?></div>
<div class="navi_in"><?php trckurls("bann.png", "bannx?act=ip",btlng4_16);?></div>
<div class="navi_in"><?php trckurls("polls.png", "polls",btlng504);?></div>
<?php 
 }
?>

<?php 
 if(get_user_class() >= UC_ADMIN){
?>

<div class="navibar">.:RooT:.</div>
<div class="navi_in"><?php trckurls("apc.png", "apc",btlng4_12);?></div>
<div class="navi_in"><?php trckurls("clients.png", "tclients",btlng4_13);?></div>

<?php 
 }
?>



<!-- CLOCK http://www.kfsoft.info/home/digitClockDemo.php  -->
<div style="padding:2px;position:fixed;bottom:3px;right:0px;margin:0px;">
<div class="imgborder" style="background:url(<?php echo $stylelink;?>/clockbg.png);">
<div id="clock1" style="text-align:center;"></div><div style="text-align:center;"><font style="font-size:12px;font-weight:bold;font-family:Century gothic;"><?php echo date("d.m.Y",$time);?></font></div>
</div>
</div>

<?php
  }else{
?>
<div class="navibar"><?php echo btlng1;?></div>
<div class="navi_in"><?php trckurls("signup.png", "signup",btlng3);?></div>
<div class="navi_in"><?php trckurls("login.png", "login",btlng4);?></div>
<div class="navi_in"><?php trckurls("language.png", "language","Language");?></div>
<div class="navi_in"><?php trckurls("stylesheet.png", "style","Style");?></div>
<div class="navi_in"><?php trckurls("rules.png", "rules",btlng4_17);?></div>
<?php 
 }


?>