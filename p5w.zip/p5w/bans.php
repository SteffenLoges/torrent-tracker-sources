<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(get_user_class() < UC_MODERATOR){
      errmsg(btlng26_2,btlng26_2);
}

mkglobal("banuid:bannid:wuid","int");
mkglobal("act:comment:fip:lip"); 

 if($act=="bannuser"){

	  if(!is_valid_id($banuid)){
		infoerr(btlng485);
	      }

	  if(!$comment){
		infoerr(btlng486);
	      }

	  if($banuid == $CURUSER["uid"]){
		infoerr(btlng488);
	      }

	    $banuserres=mysql_query("SELECT * FROM log_ip WHERE uid=".sqlesc($banuid)) or sqlerr(__FILE__, __LINE__);

	      if(!mysql_num_rows($banuserres)){
		infoerr(btlng33);
	      }

    	    $banuserres2=mysql_query("SELECT userkey,class, username FROM users WHERE uid=".sqlesc($banuid)) or sqlerr(__FILE__, __LINE__);
	    $banuserrow2=mysql_fetch_row($banuserres2);

	      if($banuserrow2[1] >= UC_MODERATOR){
		    infoerr(btlng489);
	      }

	    $banvals="";

	      while($banuserrow=mysql_fetch_row($banuserres)){
		  $banvals .= "('".$banuserrow[1]."', '".$banuserrow[1]."', ".sqlesc($comment).", ".$CURUSER["uid"].", ".$banuserrow[0].", $time),";
		}

	    $banvals=trim($banvals,",");

	    if($banvals){
		mysql_query("INSERT INTO bans (ip, iplast, comment, addedby, banuid, added) VALUES $banvals ") or sqlerr(__FILE__, __LINE__);
	      }

	   write_log("addbann",str_replace(array("%buid%","%busername%","%uid%","%username%"),array($banuid, $banuserrow2[2],$CURUSER["uid"], $CURUSER["username"]),btlng501));

	    del_user_from_ram($banuserrow2[0]);


	  infok(btlng487);

	go_to("bannx");

    }

 elseif($act=="delbann"){

	  if($wuid){
	      if(!is_valid_id($wuid)){
		    infoerr(btlng485);
		  }
		mysql_query("DELETE FROM bans WHERE banuid=".sqlesc($wuid)) or sqlerr(__FILE__, __LINE__);
		infok(btlng494);
	    }else{
		  if(!is_valid_id($bannid)){
			infoerr(btlng485);
		      }
		  mysql_query("DELETE FROM bans WHERE bannid=".sqlesc($bannid)) or sqlerr(__FILE__, __LINE__);
		  infok(btlng495);
	      }
		write_log("delbann",str_replace(array("%bid%","%uid%","%username%"),array($bannid,$CURUSER["uid"],$CURUSER["username"]),btlng499));
	go_to("bannx");

  }

  elseif($act=="bannip"){

	  if(!$fip || !ipe($fip)){
		infoerr(btlng497);
	      }

	  if(!$lip || !ipe($lip)){
		infoerr(btlng497);
	      }

	  if(!$comment){
		infoerr(btlng486);
	      }

    $rootres=mysql_query("SELECT * FROM log_ip WHERE ip=".sqlesc($banuid)) or sqlerr(__FILE__, __LINE__);

	      mysql_query("INSERT INTO bans (ip, iplast, comment, addedby, added) VALUES (".sqlesc(ipe($fip)).", ".sqlesc(ipe($lip)).", ".sqlesc($comment).", ".$CURUSER["uid"].", $time) ") or sqlerr(__FILE__, __LINE__);

	    infok(btlng495);

	   write_log("addbann",str_replace(array("%fip%","%lip%","%uid%","%username%"),array($fip, $lip, $CURUSER["uid"], $CURUSER["username"]),btlng500));

	  go_to("bannx");
    }

  else{
      errmsg(btlng498,btlng498);
  }

?>