<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["recuid"])){$reciveruid=0+$_GET["recuid"];}else{$reciveruid=0;}
if(isset($_GET["act"])){$act=$_GET["act"];}else{$act="";}

 if(!$reciveruid || !is_valid_id($reciveruid)){
    errmsg(btlng32,btlng146." ($reciveruid) ");
    }

    $res = mysql_query("SELECT username, class, email, acceptemail FROM users WHERE uid=".sqlesc($reciveruid)) or sqlerr(__FILE__, __LINE__);
    $arr = mysql_fetch_row($res) or errmsg(btlng32,btlng147);
    
    $username = $arr[0];
    $class = $arr[1];
    $email = $arr[2];
    $acceptemail = $arr[3];

	if($reciveruid == $CURUSER["uid"]){
	    errmsg(btlng32,btlng251);
	  }


// Moderators, and higher user can always send and receive mail!
if ($class < UC_MODERATOR && $CURUSER["class"] < UC_MODERATOR) {
# Accept Email ( 1 = yes , 2 = Friends, 0 = No)
    if($acceptemail ==  "0"){
	   errmsg(btlng32,btlng252);
	}

	if($acceptemail ==  "2") {
	    $friendres = mysql_query("SELECT COUNT(*) FROM friends WHERE fuid=".sqlesc($reciveruid)." AND friendid=".$CURUSER["uid"]) or sqlerr(__FILE__,__LINE__);
	     $friendrow = mysql_fetch_row($friendres);
		if(!$friendrow[0]){
		        errmsg(btlng32,btlng253);
		      }
	}
    
		$blockres = mysql_query("SELECT COUNT(*) FROM blocks WHERE buid=".sqlesc($reciveruid)." AND blockid=".$CURUSER["uid"]) or sqlerr(__FILE__,__LINE__);
		  $blockrow = mysql_fetch_row($blockres);
		    if($blockrow[0]){
			      errmsg(btlng32,btlng254);
			    }
}


# SEND EMAIL

   if($act == "sendmail"){
      mkglobal("from:from_email:subject:message");
# FROM

	$from = substr($from, 0, 90);
	if($from == ""){
		$from = "Anonym";
	      }
# FROM EMAIL

	if($from_email == ""){
		$from_email = $GLOBALS["NOREPLY_SITEEMAIL"];
	      }
	if(!validemail($from_email)){
			infoerr(btlng255);
		}

	$from = "$from  (".$GLOBALS["SITENAME"].") <$from_email>";

# SUBJECT

	$subject = substr($subject, 0, 80);

	if ($subject == ""){
	      $subject = btlng256;
	    }

	$subject = "FW: $subject";

# MESSAGE

	if($message == ""){
		infoerr(btlng257);
             }
      $message = str_replace(array("%ip%","%date%","%message%","%sitename%"),array(getip(),gdate($time),$message,$GLOBALS["SITENAME"]),btlng258);

# SEND EMAIL

	$success = mail($email, $subject, $message, "From: $from");

	if ($success){
		okmsg(btlng32_2,btlng259);
	  } else{
		errmsg(btlng32,btlng260);
	     }
die();
   }


title(btlng9_2,str_replace("%username%",ucfirst($username) ,btlng246_2));

?>
  <script>
	// POST EMAIL
	$("#sendmailbut").click(function(){
	      $.get("<?php echo $GLOBALS["BASEURL"];?>/sendemail.php", {act : 'sendmail', recuid: "<?php echo $reciveruid;?>", from: $('#from').val(), from_email: $('#from_email').val(), subject: $('#subject').val(), message: $('#emessage').val() }, function(data) {
		$("#info").html(data);
	      });
      	});
  </script>
<?php

  $tdleft=" style=\"width: 132px;padding:10px;vertical-align:top;\"";
  $tdright=" style=\"border-left:1px solid #ccc;padding:10px;vertical-align:top;\"";

echo " <br><div class=\"shadow\">";
echo " <div class=\"table\" style=\"margin: 0px;\">";


    echo "<div class=\"divbottom\"><div class=\"tr\"><div class=\"td\" $tdleft><b>".btlng247." : </b></div><div class=\"td\" $tdright><input type=\"text\" name=\"from\" id=\"from\" value=\"".ucfirst($CURUSER["username"])."\" size=\"40\"></div></div></div>";

    echo "<div class=\"divbottom\"><div class=\"tr\"><div class=\"td\" $tdleft><b>".btlng248." : </b></div><div class=\"td\" $tdright><input type=\"text\" name=\"from_email\" id=\"from_email\" value=\"".$CURUSER["email"]."\" size=\"40\"></div></div></div>";

    echo "<div class=\"divbottom\"><div class=\"tr\"><div class=\"td\" $tdleft><b>".btlng249." : </b></div><div class=\"td\" $tdright><input type=\"text\" name=\"subject\" id=\"subject\" size=\"40\"></div></div></div>";

    echo "<div class=\"divbottom\"><div class=\"tr\"><div class=\"td\" $tdleft><b>".btlng250." : </b></div><div class=\"td\" $tdright><textarea name=\"message\" id=\"emessage\" cols=\"78\" rows=\"18\"></textarea></div></div></div>";

      echo "<div class=\"tr\" ><center><br><a href=\"javascript:;\" id=\"sendmailbut\" class=\"buttonsilver\">".btlng246."</a><br><br></center></div>\n";

echo "</div></div><br>";


?>