<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

$pages = 0;$limit="";$addparam="";

if(isset($_GET["search"])){$search=htmlchar($_GET["search"]); $addparam .="&search=$search";}else{$search="";}
if(isset($_GET["cat"])){$category=htmlchar($_GET["cat"]); $addparam .="&cat=$category";}else{$category="";}
if(isset($_GET["orderby"])){$gorderby=htmlchar($_GET["orderby"]); $addparam .="&orderby=$gorderby";}else{$gorderby="";}
if(isset($_GET["sort"])){$sort=htmlchar($_GET["sort"]); $addparam .="&sort=$sort";}else{$sort="";}
if(isset($_GET["incldead"])){$incldead=0+$_GET["incldead"];  $addparam .="&incldead=$incldead";}else{$incldead=0;}
if(isset($_GET["pno"])){$page=0+$_GET["pno"];}else{$page=1;}
if(isset($_GET["hidehead"])){$hidehead=0+$_GET["hidehead"];}else{$hidehead=0;}
if(isset($_GET["my"])){$getmy=0+$_GET["my"];}else{$getmy=0;}

 if(isset($_GET["ppage"])){
	  $perpage=0+htmlchar($_GET["ppage"]);
	  setcookie("p5w_ppage", $perpage, 0x7fffffff, "/");
	}else{
	      if(isset($_COOKIE["p5w_ppage"])){$perpage=0+htmlchar($_COOKIE["p5w_ppage"]);}else{$perpage=$GLOBALS["TORRENTS_PERPAGE"];}
	    }


# MAX TORRENTS PERPAGE
  if($perpage > $GLOBALS["MAX_TORRENTS_PERPAGE"]){
	  $perpage = $GLOBALS["MAX_TORRENTS_PERPAGE"];
	    setcookie("p5w_ppage", $GLOBALS["MAX_TORRENTS_PERPAGE"], 0x7fffffff, "/");
      }


# MY TORRENTS
if($getmy){
         $mytors=1; $mytorparam="&my=1"; $searchsel=" selected=\"selected\""; $showdownbut=1;
    }else{
        $mytors="";$mytorparam=""; $searchsel="";$showdownbut=1;
      }


# TITLE
  if($search){
    title(btlng286." $search",btlng286." \"$search\" ");
      } 
      else if($mytors){
	  title(btlng273_2,btlng273_2);
      } else{
	  title(btlng4_1,btlng4_1);
	}



  if($mytors){
      $wherea = array();
        }else{
	     if(get_user_class() >= UC_GUTEAM){
                $wherea = array("activated >= 0");
	      }else{
                $wherea = array("activated = 1");
	       }
           }


if($incldead == 0) {

	  $wherea[] = "visible = 1";

      } elseif($incldead == 1) {

	      $wherea[] = "visible = 0";

	    } elseif($incldead == 2) {

		  if(!isset($CURUSER) || get_user_class() < UC_ADMIN){
			    $wherea[] = "banned = 0";
			  }
	     }

# VIP
  if(get_user_class() < UC_VIP){
	    $wherea[] = "vip = 0";
	}

	if(get_user_class() == UC_VIP){
                 $wherea[] = "vip >= 0";
                }

# MY TORRENTS

  if($mytors){
      $wherea[] = "toruid = ".$CURUSER["uid"];
    }

# CATEGORY
  if($category){
    $rescat=mysql_query("SELECT COUNT(*) FROM categories WHERE cid IN (".sqlwildcardesc($category).")");
      if(mysql_num_rows($rescat)){
            $wherea[] = "catid IN (".sqlwildcardesc($category).")";
	  }
    }



# ORDER BY
$orderby = "ORDER BY ";

	if($gorderby == "name"){

		    $orderby .= "torrents.name";
	}
	elseif($gorderby == "type"){

		    $orderby .= "categories.name";
	}
	elseif($gorderby == "files"){

		    $orderby .= "torrents.numfiles";
	}
	elseif($gorderby == "comments"){

		    $orderby .= "torrents.comments";
	}
	elseif($gorderby == "added"){

		    $orderby .= "torrents.added";
	}
	elseif($gorderby == "size"){

		    $orderby .= "torrents.size";
	}
	elseif($gorderby == "snatched"){

		    $orderby .= "torrents.times_completed";
	}
	elseif($gorderby == "seeds"){

		    $orderby .= "torrents.seeders";
	}
	elseif($gorderby == "leeches"){

		    $orderby .= "torrents.leechers";
	}
	elseif($gorderby == "uppedby"){

		    $orderby .= "users.username";
	}

	else{
		    $gorderby = "added";
		    $orderby .= "torrents.added";
	}

# SORT
	if($sort == "asc"){
		      $orderby .= " ASC";
	}
	else{
		      $orderby .= " DESC";
	}


# AUDIO AND SUBTITLE
 $cnta=0;
 $cnts=0;
 $alang="";
 $slang="";
    foreach($torrentlang as $key => $val){
	  if(isset($_GET["alang_$key"])){
		    if(!$cnta){
			  $alang .= "audlang_$key = '1' ";
			  }else{
			       $alang .= "OR audlang_$key = '1' ";
			        }
	    $cnta++;
	  }

	  if(isset($_GET["slang_$key"])){
		    if(!$cnts){
			  $slang .= "sublang_$key = '1' ";
			  }else{
			        $slang .= "OR sublang_$key = '1' ";
			        }
	    $cnts++;
	  }
       }

 $where_aud_sub="";

   if($cnta > 0){
      $where_aud_sub = " ($alang) ";
     }

  elseif($cnts > 0){
      $where_aud_sub= " ($slang) ";
     }

  elseif($cnta > 0 && $cnts > 0){
      $where_aud_sub  = "($alang) OR ($slang)";
    }


# SUBTITLE AND AUDIO SQL
  if($where_aud_sub){
	$wherea[] = $where_aud_sub;
      }


# SEARCH
 if($search){
	$wherea[] = "search_text LIKE '%" . sqlwildcardesc(strtolower($search)) . "%'";
 }



# SQL WHERE
 $where = implode(" AND ", $wherea);
  $where = "WHERE $where";


# COUNT
        $rescount = mysql_query("SELECT COUNT(*) FROM torrents LEFT JOIN users ON torrents.toruid=users.uid $where") or sqlerr(__FILE__, __LINE__);
        $rowcount = mysql_fetch_row($rescount);
        $count = $rowcount[0];

              # PAGER PERPAGE
		if($count){
		  $pages = ceil($count / $perpage);

		    if($page > $pages){
			    $page=$pages;
			    }else{
				$page=$page;
				}

			    $limit = ($page - 1) * $perpage;
			    $limit = " LIMIT $limit, $perpage ";
			 }

  $orderby_sel = array("name" => btlng274,
      "type" => btlng275,
      "files" => btlng276,
      "comments" => btlng277,
      "added" => btlng278,
      "size" => btlng279,
      "snatched" => btlng280,
      "seeds" => btlng281,
      "leeches" => btlng282,
      "uppedby" => btlng283
      );

?>
<script type="text/javascript" src="/js/jquery.pager.js"></script>
<script>

// PAGER
        PageClick = function(pageclickednumber) {
            $("#pager").pager({ pagenumber: pageclickednumber, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });
		$.get("<?php echo $GLOBALS["BASEURL"];?>/torrents.php", {  
		  search: "<?php echo $search;?>", cat: "<?php echo $category;?>", orderby: "<?php echo $gorderby;?>", pno: pageclickednumber, ppage: "<?php echo $perpage;?>", 
		  sort: "<?php echo $sort;?>", incldead: "<?php echo $incldead;?>",
		      <?php 
			$al ="";
			    $sl ="";

			  foreach($torrentlang as $key => $val){

			      if(isset($_GET["alang_$key"])){
				  $al .= " alang_$key: \"".htmlchar($_GET["alang_$key"])."\",";
				  }

				  if(isset($_GET["slang_$key"])){
				      $sl .= " slang_$key: \"".htmlchar($_GET["slang_$key"])."\",";
				      }
			    }

			    echo $al;
			    echo $sl;

			      if($mytors){
				      echo " my: 1,";
				    }
			?>
		   hidehead: 1
		  },
   		function(data){
    		 $('#torres').html(data);
   		});
        }

  $("#pager").pager({ pagenumber: <?php echo $page;?>, pagecount: <?php echo $pages;?>, buttonClickCallback: PageClick });


// SEARCH $_GET
       $('#search').keypress(function(e) {
	 if(e.which == 13) {
	    var catot = $("input[id='idcat']:checked").length - 1;
	    var catids="";

	    $("input[id='idcat']:checked").each(function(i){
	    if(catot == i){
		catids+=$(this).val();
	      }else{
		catids+=$(this).val() + ",";
		}
	      });
	  $.get("<?php echo $GLOBALS["BASEURL"];?>/torrents.php", { search: $('#search').val(), incldead: $('#incldead option:selected').val(), cat: catids,
	    <?php 
	        $al ="";
		 $sl = "";
		foreach($torrentlang as $key => $val){
	             $al .= " alang_$key: $(\"#alang_$key:checked\").val(),";
		      $sl .= " slang_$key: $(\"#slang_$key:checked\").val(),";
		  }

	           echo $al;
		   echo $sl;

			      if($mytors){
				      echo " my: 1,";
				    }
	      ?>
		orderby: $('#orderby option:selected').val(), sort: $('#sort option:selected').val(), hidehead: 1
		  }, function(data){
	      $('#torres').html(data);
	      });
           }
      	});

   $("#torsearch").click(function() {
	    var catot = $("input[id='idcat']:checked").length - 1;
	    var catids="";

	    $("input[id='idcat']:checked").each(function(i){
	    if(catot == i){
		catids+=$(this).val();
	      }else{
		catids+=$(this).val() + ",";
		}
	      });
	  $.get("<?php echo $GLOBALS["BASEURL"];?>/torrents.php", { search: $('#search').val(), incldead: $('#incldead option:selected').val(), cat: catids,
	    <?php 
	        $al ="";
		 $sl = "";
		foreach($torrentlang as $key => $val){
	             $al .= " alang_$key: $(\"#alang_$key:checked\").val(),";
		      $sl .= " slang_$key: $(\"#slang_$key:checked\").val(),";
		  }

	           echo $al;
		   echo $sl;

			      if($mytors){
				      echo " my: 1,";
				    }
	      ?>
		orderby: $('#orderby option:selected').val(), sort: $('#sort option:selected').val(), hidehead: 1
		  }, function(data){
	      $('#torres').html(data);
	      });
     });

                  // FILELIST
		      function filelist(tid){
			    $("#filelist").show();
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/torfiles.php", {tid: tid, showname:1 }, function(data) {
			      $("#filelist").html(data);
			    });
			}

                  // PEERLIST
		      function peerlist(tid){
			    $("#peerlist").show();
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/torleechseed.php", {tid: tid, showname:1 }, function(data) {
			      $("#peerlist").html(data);
			    });
			}





</script>
<?php

if(!$hidehead){

 echo "<div class=\"shadow\" style=\"width:650px;\"><div class=\"table\" style=\"margin:0 auto;\">";

# SEARCH
   echo "<div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\"><div class=\"td\" style=\"padding:8px;\">".btlng261." : <input type=\"text\" size=\"42\" id=\"search\"> ".btlng268." ";

	  echo "<select id=\"incldead\">
		<option value=\"0\">".btlng269."</option>
		<option value=\"1\">".btlng270."</option>
		<option value=\"2\" $searchsel>".btlng271."</option>
		</select> ".btlng268_2;
   echo "</div></div>\n";



# BROWSER CAT ROW
 $catbrowrow=$GLOBALS["BROWSE_CATS_PER_ROW"];

 if(!$catbrowrow){
      $catbrowrow=5;
   }

# CATEGORIES
    $rescaty = mysql_query("SELECT * FROM categories ORDER BY name");

   $i=0;
   echo "<div class=\"tr\"><div class=\"td\" style=\"padding:0px;\"><div class=\"table\"><div class=\"tr\">";

      while($rowcaty = mysql_fetch_row($rescaty)){
	if($category==$rowcaty[0]){
	    $catchecked=" checked=\"checked\"";
	   }else{
	       $catchecked="";
	      }
	  
	  if($i % $catbrowrow == 0){
	      echo "</div>\n<div class=\"tr\">";
	      }

	    echo "<div class=\"td\"><center><a style=\"text-decoration:none;\" href=\"".$GLOBALS["BASEURL"]."/#torrents?cat=".$rowcaty[0]."$mytorparam\" title=\"".$rowcaty[1]."\">
		  <img class=\"imgborder\" width=\"32\" src=\"$stylelink/cat/32px/".$rowcaty[2]."\"><br>
		  <b>".$rowcaty[1]."</b><br></a>
		  <input id=\"idcat\" $catchecked value=\"".$rowcaty[0]."\" type=\"checkbox\"></center></div>\n";

	  $i++;
	}
	    echo "<div class=\"td\" style=\"width:76px;\"><center>
		  <a style=\"text-decoration:none;\" href=\"".$GLOBALS["BASEURL"]."/#torrents?incldead=2$mytorparam\" title=\"".btlng273."\">
		  <img class=\"imgborder\" width=\"32\" height=\"32\" src=\"$stylelink/all.png\"><br>
		  <b>".btlng273."</b><br></a>
		  </center></div>";

   echo "</div></div></div></div><div class=\"divbottom\"></div>\n";



 $audcheckbox="";
 $subcheckbox="";

  foreach($torrentlang as $key => $val){
  $audcheckbox .= "<input id=\"alang_$key\" value=\"$key\" type=\"checkbox\"> <img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\"> $val\n";
  $subcheckbox .= "<input id=\"slang_$key\" value=\"$key\" type=\"checkbox\"> <img src=\"".$GLOBALS["IMAGES_DIR"]."flags16p/$key.png\" title=\"$val\"> $val\n";
  }

# AUDIO CHECKBOX
   echo "<div class=\"tr borderbottom\"><div class=\"td\" style=\"padding:8px;\"><b>".btlng53."</b><br>";
	echo $audcheckbox;
   echo "</div></div>\n";


# SUBTITLE CHECKBOX
   echo "<div class=\"tr borderbottom\"><div class=\"td\" style=\"padding:8px;\"><b>".btlng54."</b><br>";
     echo $subcheckbox;
   echo "</div></div>\n";


# ORDER BY AND SORT
   echo "<div class=\"tr borderbottom\"><div class=\"td\" style=\"padding:8px;\">".btlng272." : <select id=\"orderby\" size=\"1\">";

    foreach ($orderby_sel as $orderparam => $description) {
        echo "<option value=\"$orderparam\"";
        if ($orderparam == $gorderby){
              echo " selected=\"selected\"";
	    }
        echo ">$description</option> \n";
    } 

   echo "</select> ".btlng268." 
	 <select id=\"sort\" size=\"1\">
	 <option value=\"desc\">".btlng284."</option>
	 <option value=\"asc\">".btlng285."</option>
	 </select> ".btlng287."
   </div></div>\n";


# SEARCH BUTTON
  echo "<div class=\"tr\" ><center><br>
	      <a href=\"javascript:;\" id=\"torsearch\" class=\"buttonsilver\">".btlng261."</a><br><br></center>
	      </div>\n";



 echo "</div></div>";

if($pages>1){
 echo "<br><div id=\"pager\"></div><br><br>";
}
}


# RESULTS
 $sqlcatsaud="";
 $sqlcatssub="";
  foreach($torrentlang as $key => $val){
     $sqlcatsaud .= ",torrents.audlang_$key ";
     $sqlcatssub .= ",torrents.sublang_$key ";
  }

    

    $torquery = "SELECT torrents.tid, torrents.catid, torrents.leechers, torrents.seeders, torrents.name, torrents.times_completed, torrents.size, torrents.added, torrents.lastaction, torrents.comments,torrents.numfiles,torrents.toruid, torrents.banned, " . 
    "categories.name AS cat_name, categories.image AS cat_img, users.username, users.class AS uploaderclass $sqlcatsaud $sqlcatssub ,torrents.activated FROM torrents LEFT JOIN categories ON catid = categories.cid LEFT JOIN users ON torrents.toruid = users.uid $where $orderby $limit";
    $restor = mysql_query($torquery) or sqlerr(__FILE__, __LINE__);


 echo "<div id=\"torres\">
		  <div style=\"text-align:right;padding-right:1px;\">
		  <a href=\"".$GLOBALS["BASEURL"]."/#torrents?ppage=20$addparam\">20</a> | 
		  <a href=\"".$GLOBALS["BASEURL"]."/#torrents?ppage=25$addparam\">25</a> |  
		  <a href=\"".$GLOBALS["BASEURL"]."/#torrents?ppage=".$GLOBALS["MAX_TORRENTS_PERPAGE"]."$addparam\">".$GLOBALS["MAX_TORRENTS_PERPAGE"]."</a> 
		  </div>
 	  <br>
	    <div id=\"filelist\" class=\"filelist\"></div>
	    <div id=\"peerlist\" class=\"peerlist\"></div>
	    <div class=\"divbottom\"></div>
      <div class=\"table\">";

$icolor=0;

     while($rowtor=mysql_fetch_row($restor)){
$ti=-1;
$showdownbut=1;
	    $tor_tid=$rowtor[++$ti];
	    $tor_catid=$rowtor[++$ti];
	    $tor_leechers=$rowtor[++$ti];
	    $tor_seeders=$rowtor[++$ti];
	    $tor_name=$rowtor[++$ti];
	    $tor_times_completed=$rowtor[++$ti];
	    $tor_size=mksize($rowtor[++$ti]);
	    $tor_added=$rowtor[++$ti];
	    $tor_lastaction=gdate($rowtor[++$ti]);
	    $tor_comments=$rowtor[++$ti];
	    $tor_numfiles=$rowtor[++$ti];
	    $tor_uid=$rowtor[++$ti];
	    $tor_banned=$rowtor[++$ti];
	    $tor_cat_name=$rowtor[++$ti];
	    $tor_cat_img=$rowtor[++$ti];
	    $tor_username=$rowtor[++$ti];
	    $tor_uploaderclass=$rowtor[++$ti];

		$audimg = "";
		$subimg = "";

		foreach($torrentlang as $key => $val){
			if($rowtor[++$ti]){
				$audimg .= "<img src=\"".$GLOBALS["IMAGES_DIR"]."flags14p/$key.png\" title=\"$val\">";
			  }

		}


		foreach($torrentlang as $key => $val){
			    if($rowtor[++$ti]){
				$subimg .= "<img src=\"".$GLOBALS["IMAGES_DIR"]."flags14p/$key.png\" title=\"$val\">";
			    }
		}

		  if($audimg){
			    $audimg="Aud:".$audimg;
		        }

			if($subimg){
				 $subimg=" Sub:".$subimg;
				}
	     

	      # BACKGROUND COLOR ROW
	      if($icolor%2 == 0){
		  $bgcolor="#FFFFDD";
		 }else{
		    $bgcolor="#F7F7F7";
		  }


	     # IF TORRENT NOT ACTIVATED
		$tor_activated = $rowtor[++$ti];
	         if(!$tor_activated){
			  $showdownbut=0;
			  $bgcolor="#FFD7D7";
		      }

	     # BANNED TORRENT
	         if($tor_banned){
			  $showdownbut=0;
			  $bgcolor="#F5E7FF";
		      }


		    if($tor_seeders){
			$tor_seeders="<font color=\"".get_slr_color($tor_seeders)."\"><b>$tor_seeders</b></font> <a onclick=\"peerlist($tor_tid)\" href=\"javascript:;\">".btlng289."</a>";
			 }else{
			    $tor_seeders="<font color=\"".get_slr_color($tor_seeders)."\"><b>$tor_seeders</b></font> ".btlng289;
				}

		    if($tor_leechers){
			$tor_leechers="<font color=\"".get_slr_color($tor_leechers)."\"><b>$tor_leechers</b></font> <a onclick=\"peerlist($tor_tid)\" href=\"javascript:;\">".btlng290."</a>";
			 }else{
			    $tor_leechers="<font color=\"".get_slr_color($tor_leechers)."\"><b>$tor_leechers</b></font> ".btlng290;
				}

		    if($tor_comments){
			$tor_comments="<b>$tor_comments</b> x <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tor_tid#com\">".btlng292."</a>";
			 }else{
			    $tor_comments="<b>$tor_comments</b> x ".btlng292;
				}

			  $newtorent="";
			  if($tor_added > $CURUSER["lastaccess"]){
			     $newtorent = "<img src=\"$stylelink/new.png\" width=\"30\" height=\"16\" title=\"NEW\">";
			  }

        if($tor_username){
	   $usname="<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$tor_uid\" title=\"$tor_username\"><font color=\"".get_class_color($tor_uploaderclass)."\"><b>".ucfirst($tor_username)."</b></font></a>";	
         }else {
	      $usname="<del><i>(".btlng339.")</i></del>";
		}
			

		echo "<div class=\"tr borderbottom\">
		      <div class=\"td\" style=\"background-color:$bgcolor;padding:3px;\"><a href=\"".$GLOBALS["BASEURL"]."/#torrents?cat=$tor_catid\"><img class=\"imgborder\" src=\"$stylecatimg/cat/$tor_cat_img\" title=\"$tor_cat_name\"></a></div>
		      <div class=\"td torrents1\" style=\"background-color:$bgcolor;\">
			<div class=\"table\">
			  <div class=\"tr\">
			      <div class=\"td\">$audimg &nbsp; $subimg &nbsp; <a href=\"".$GLOBALS["BASEURL"]."/#details?tid=$tor_tid\" title=\"Torrent -> $tor_name\"><b>$tor_name</b></a> $newtorent </div>
			      <div class=\"td\" style=\"width:12%;\">".btlng293." : $usname </div>
			  </div>
			  <div class=\"tr\">
			      <div class=\"td\">
				  <div class=\"table\">
				    <div class=\"tr\">

					  <div class=\"td\" style=\"width:16%;\"><b>$tor_size</b> ".btlng268." <b>$tor_numfiles</b> <a onclick=\"filelist($tor_tid)\" href=\"javascript:;\">".btlng288."</a></div>
					  <div class=\"td\" style=\"width:16%;\"> $tor_seeders  & $tor_leechers </div>
					  <div class=\"td\" style=\"width:16%;\"><b>$tor_times_completed</b> x ".btlng291."</div>
					  <div class=\"td\" style=\"width:16%;\">$tor_comments</div>
					  <div class=\"td\" style=\"width:16%;\">".gdate($tor_added)."</div>
				      </div>
				  </div>
			      </div>
			  </div>
			</div>
		      </div>
		     <div class=\"td torrents2\" style=\"background-color:$bgcolor;\">";
		     if($showdownbut){
			    echo "<a href=\"".$GLOBALS["BASEURL"]."/download.php?tid=$tor_tid\"><img src=\"$stylelink/download.png\"  title=\"Download -> $tor_name\"></a>";
			} else{
				if(!$tor_activated){ $tittext = btlng294;}    
				if($tor_banned){ $tittext = btlng414_2;} 
			        echo "<a><img src=\"$stylelink/notactived.png\"  title=\"$tittext\"></a>";
				}

		echo "</div>
		    </div>";




   $icolor++;
    }


 echo "</div></div>";




?>