<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["avatar"])){$avatar=htmlchar($_GET["avatar"]);}else{$avatar="";}
if(isset($_GET["title"])){$title=htmlchar($_GET["title"]);}else{$title="";}
if(isset($_GET["acceptpms"])){$acceptpms=0+$_GET["acceptpms"];}else{$acceptpms=0;}
if(isset($_GET["deletepms"])){$deletepms=1;}else{$deletepms=0;}
if(isset($_GET["savepms"])){$savepms=1;}else{$savepms=0;}
if(isset($_GET["acceptemail"])){$acceptemail=0+$_GET["acceptemail"];}else{$acceptemail=0;}
if(isset($_GET["wget"])){$wget=1;}else{$wget=0;}
if(isset($_GET["email"])){$email=htmlchar($_GET["email"]);}else{$email="";}
if(isset($_GET["passwd"])){$passwd=htmlchar($_GET["passwd"]);}else{$passwd="";}
if(isset($_GET["passwdagain"])){$passwdagain=htmlchar($_GET["passwdagain"]);}else{$passwdagain="";}

$updateset = array();
$changedemail = 0;



  if($passwd != "") {
	  if(strlen($passwd) > 40){
		  infoerr(btlng19);
	      }
	  if($passwd != $passwdagain){
		  infoerr(btlng17);
	      }
	  $sec = mksecret();

	  $passhash = md5($sec . $passwd . $sec);

	  $updateset[] = "secret = " . sqlesc($sec);
	  $updateset[] = "passhash = " . sqlesc($passhash);
	  logincookie($CURUSER["uid"], $passhash);
  }
 

	if($email != $CURUSER["email"]) {
		if(!validemail($email)){
			infoerr(btlng21);
		      }
	  $r = mysql_query("SELECT uid FROM users WHERE email=".sqlesc($email)) or sqlerr(__FILE__, __LINE__);
		if(mysql_num_rows($r) > 0){
			  $emailerr=str_replace("%email%", $email, btlng24);
			  infoerr($emailerr);
		    }
		$changedemail = 1;
	}



$emailtext = "";

if ($changedemail) {
	$sec = mksecret();
	$hash = md5($sec . $email . $sec);
	$obemail = urlencode($email);
	$updateset[] = "editsecret = " . sqlesc($sec);
	$updateset[] = "editsecrettime = " . sqlesc($time);
	$body = str_replace(array("%username%","%email%","%ip%","%uid%","%hash%"),array($CURUSER["username"],$obemail,getip(),$CURUSER["uid"],$hash),btlng365);

	mail($CURUSER["email"], $GLOBALS["BASEURL"]." ".btlng366, $body, "From: ".$GLOBALS["SITEEMAIL"]);

	$emailtext = btlng367;
}

 $updateset[] = "avatar = " . sqlesc($avatar);
 $updateset[] = "title = " . sqlesc($title);
 $updateset[] = "acceptpms = " . sqlesc($acceptpms);
 $updateset[] = "deletepms = " . sqlesc($deletepms);
 $updateset[] = "savepms = " . sqlesc($savepms);
 $updateset[] = "acceptemail = " . sqlesc($acceptemail);
 $updateset[] = "wget = " . sqlesc($wget);

 mysql_query("UPDATE users SET " . implode(",", $updateset) . " WHERE uid = " . $CURUSER["uid"]) or sqlerr(__FILE__,__LINE__);


 session_unset();
 $_SESSION["udata"] = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE uid = " . $CURUSER["uid"]));
 $_SESSION["udata"]["ip"]=ipd($ipencode);
 $_SESSION["udata"]["lastaccess2"]=$time;

 infok(btlng242.$emailtext);


?>