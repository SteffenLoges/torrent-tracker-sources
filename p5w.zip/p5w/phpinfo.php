<?php

phpinfo(); 

?>