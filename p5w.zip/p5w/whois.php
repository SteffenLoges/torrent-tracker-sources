<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["ip"])){$getip=$_GET["ip"];}else{$getip="";}

if (get_user_class() < UC_MODERATOR){
    errmsg(btlng32,btlng26_2);
}
if (!preg_match("/^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$/", $getip)) {
      errmsg(btlng32,btlng172);

}


$parts = explode(".", $getip);
foreach($parts as $part) {
    if (intval($part)<0 || intval($part)>255) {
	errmsg(btlng32,btlng172);
    }
}

 title("$getip WHOIS Info","$getip WHOIS Info");
?>

<pre style="font-size:12px;">
<?php

system("whois ".escapeshellcmd($_GET["ip"]));


?>
</pre>
