<?php
require_once("inc/func.php");
dbconn();
title(btlng4_17,btlng4_17);
    mkglobal("act:acceptrules");

if($act=="new_rules" && $CURUSER){

	      ?>
	      <script>
		$('#accept').click(function() {
		      $.get("<?php echo $GLOBALS["BASEURL"];?>/rules.php", { act: "new_rules", acceptrules: "yes" }, function(data){
			  $("#info").html(data);
			  window.location.replace("<?php echo $GLOBALS["BASEURL"];?>/#home");
		      });
		});
	      </script>
	      <?php

		    if($acceptrules == "yes"){

			mysql_query("UPDATE users SET rules_accepted = 1 WHERE uid = ".$CURUSER["uid"]);
		      infok(btlng532);
		      $_SESSION["udata"]["rules_accepted"]=1;
		      die();
		    }


echo "<div class=\"shadow\" style=\"background:#fff url($stylelink/h28.png) repeat-x;\">
	<div class=\"table\">
	    <div class=\"tr\">
		<div class=\"td\" style=\"text-align:center\"><b style=\"color:red;\">NEUE REGELN</b></div>
	    </div>
	 </div>

";



echo "<p><center><a href=\"javascript:;\" id=\"accept\" class=\"buttonsilver\">".btlng533."</a></center></p>
    </div>";

}else{

?>

<div class="shadow" style="padding:1px;">
	<div class="table rules">


	    <div class="tr">
		<div class="td" style="background:#fff url(<?php echo $stylelink;?>/h28.png) repeat-x;text-align:center;"><b>§1 Grundlegende Regeln</b></div>
	    </div>

	    <div class="tr">
		<div class="td">
			<ol>
			<li><p>Gib die von hier heruntergeladenen Torrents weder weiter noch lade diese auf andere Tracker<!-- (<b>Ausnahme</b>: spezielle Werbetorrents)!--></p></li>
			</ol>
		 </div>
	    </div>



	    <div class="tr rulesline">
		<div class="td" style="background:#fff url(<?php echo $stylelink;?>/h28.png) repeat-x;text-align:center;"><b>§2 Download/Upload Regeln</b></div>
	    </div>

	    <div class="tr">
		<div class="td">
			<ol>
			<li><p>Beachte Deine Slot-Limits. Sollten diese Überschritten werden, wird jede einzelne Überschreitung mit Verwarnpunkten bestraft</p></li>
			</ol>
		 </div>
	    </div>





    </div>
</div>

<?php
}
?>  
  
