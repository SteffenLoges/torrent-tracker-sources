<?php
ini_set('display_errors', 0); 
require_once("inc/func.php");
dbconn();
loggedinorreturn();

    function downerr($text){
	return die("<br><div align=\"center\" style=\"margin: 0 auto;padding:16px;background:#D40000;font-size:18px;border:1px solid #A1A1A1;width:520px;	
			      -moz-border-radius:4px;-webkit-border-radius:4px;\">
			      <font color=\"#FFFFFF\"><b>$text</b></font>
			      </div>");
	  
      }

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}



 if(!$tid){
      downerr(btlng295);
    }

 $resdown = mysql_query("SELECT name,activated FROM torrents WHERE tid = ".sqlesc($tid)) or sqlerr(__FILE__, __LINE__);
 $rowdown = mysql_fetch_row($resdown);


 $fn = $GLOBALS["TORRENT_DIR"] ."/$tid.torrent";

 if(!$rowdown){
      downerr(btlng295);
    } 
	if(!is_file($fn)){
               downerr(btlng296);
	      } 

	      if(!is_readable($fn)){
                     downerr(btlng297);
	           } 

		    if(!$rowdown[1]){
                         downerr(btlng298);
	              }

 $tordownname=str_replace(array(" "),array("_"),$rowdown[0]);


    $resuser = mysql_query("SELECT userkey FROM users WHERE uid = ".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
    $rowuser = mysql_fetch_row($resuser);


    
     if($rowuser[0]){
            $userkey=$rowuser[0];
	  } else{
	     $userkey=userkey();
	      mysql_query("UPDATE users SET  userkey = '$userkey' WHERE uid = ".$CURUSER["uid"]) or sqlerr(__FILE__, __LINE__);
	      add_user_to_ram($CURUSER["uid"]);
	    }

    header("Content-Type: application/x-bittorrent");
    header("Content-Transfer-Encoding: binary");
    header("Pragma: private");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");            
    header("Content-Disposition: attachment; filename=\"$tordownname.torrent\"");

require_once("inc/benc.php");

    // Insert Userkey
    $announce_url =str_replace(array("%KEY%"),array("$userkey"),$GLOBALS["PASSKEY_ANNOUNCE_URL"]);

    // Load torrent
    $torrentfile = bdec_file($fn, filesize($fn));

    // Replace announce URL with bencoded string
    $torrentfile["value"]["announce"] = array("type" => "string", "value" => $announce_url);

    // Save user id
    $torrentfile["value"]["p5wtracker_uid"] = array("type" => "integer", "value" => $CURUSER["uid"]);

    $torrentdata = benc($torrentfile);

    header("Content-Length: ".strlen($torrentdata));
    
    // Write out re-encoded torrent
    echo $torrentdata;


?>