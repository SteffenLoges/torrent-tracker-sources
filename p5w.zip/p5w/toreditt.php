<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

echo "1";// Do Not Delete This ECHO
$imginfo=0;

mkglobal("tid:cat","int");
mkglobal("torname:descr:visible:banned:vip:picchange");

$nfofile = $_FILES['nfo'];

 if(!$tid){
    errmsg(btlng32,btlng295);
  }

 if(!$torname){
   infoerr(btlng418);
 }

 if(!$descr){
   infoerr(btlng63);
 }

 if(!$cat){
   infoerr(btlng64);
 }



$res = mysql_query("SELECT torrents.toruid, torrents.numpics, torrents.activated, users.class, torrents.info_hash, torrents.name FROM torrents LEFT JOIN users ON torrents.toruid=users.uid WHERE torrents.tid = $tid");
$row = mysql_fetch_row($res);


 if(!$row){
    errmsg(btlng32,btlng295);
  }


 if($CURUSER["uid"] != $row[0] && !(get_user_class() >= UC_MODERATOR || (!$row[2] && get_user_class() == UC_GUTEAM && $row[3] < UC_UPLOADER))){
    	  infoerr(btlng405);
  }


  # Check Image uploads
  if($_FILES["pic1"]["name"]) {
    torrent_image_upload($_FILES["pic1"], "", "", 1);
	}

  if($_FILES["pic2"]["name"]) {    
    torrent_image_upload($_FILES["pic2"], "", "", 1);
  }
  
  # Dispaly Image Upload Errors
  if($imginfo){
  infoerr($imginfo);
  }

 $updateset = array();
 $updatesetc = array();

 if($row[5] != $torname){
      $updateset[] = "name = " . sqlesc($torname);
      $updateset[] = "search_text = " . sqlesc(strtolower($torname));
      $updatesetc[] = "tor_name = " . sqlesc($torname);
  }

 $updateset[] = "descr = " . sqlesc($descr);
 $updateset[] = "catid = " . ($cat);


# LANG AND SUBTITLE

    foreach($torrentlang as $key => $val){

	  if(isset($_POST["alang_$key"])){ $updateset[] = "audlang_$key = '1'"; }else{ $updateset[] = "audlang_$key = '0'"; }
	  
	  if(isset($_POST["slang_$key"])){ $updateset[] = "sublang_$key = '1' ";}else{ $updateset[] = "sublang_$key = '0'";}
			        
	  }
       

# Only allow torrent to be visible/alive if activated
 if($row[2]){
    $updateset[] = "visible = '$visible'";
    $updateset[] = "lastaction = '$time'";
 }

# DELETE IMAGES

if($picchange){

    if($row[1] > 0 ) {
        for($I=1; $I<=$row[1]; $I++) {

		if(file_exists($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$tid-$I-t.jpg")){
                      unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$tid-$I-t.jpg");
		   }

		if(file_exists($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$tid-$I-f.jpg")){
                      unlink($GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"] . "/$tid-$I-f.jpg");
		   }
        }


    }

# SAVE IMAGES

  # Handle picture uploads
  $picnum = 0;
  if($_FILES["pic1"]["name"]) {
    if(torrent_image_upload($_FILES["pic1"], $tid, $picnum+1)){
        $picnum++;
	}
  } 

  if($_FILES["pic2"]["name"]) {    
    if(torrent_image_upload($_FILES["pic2"], $tid, $picnum+1)){
        $picnum++;
      }
  }

      $updateset[] = "numpics = " . $picnum;

}


# Create NFO image
 if($nfofile["name"] && $nfofile['tmp_name'] && $nfofile['size'] > 0){
  $nfo = str_replace("\x0d\x0d\x0a", "\x0d\x0a", file_get_contents($nfofile['tmp_name']));
  gen_nfo_pic($nfo, $GLOBALS["TRACKER_DIR"]."/".$GLOBALS["XIMGDEPOT_DIR"]."/nfo/nfo-".md5($tid.$row[4]).".png");
 }


  if(get_user_class() >= UC_MODERATOR){
    
# BANNED
     if($banned){
	        $updateset[] = "banned= '1'";
         del_torrent_from_ram($row[4]);
	}else{
	        $updateset[] = "banned= '0'";
	}

# VIP
     if($vip){
	        $updateset[] = "vip= '$vip'";
	}else{
	        $updateset[] = "vip= '0'";
	}

  }


 mysql_query("UPDATE torrents SET " . join(",", $updateset) . " WHERE tid = $tid");
 mysql_query("UPDATE completed SET " . join(",", $updatesetc) . " WHERE tor_id = $tid");

# UPDATE TORRENT RAM VALUES
  if(!$banned){
	add_torrent_to_ram($tid);
  }


write_log("torrentedit", str_replace(array("%tid%","%name%","%curid%","%curname%"),array($tid,$torname,$CURUSER["uid"],$CURUSER["username"]),btlng420));

infok(btlng242);
?>