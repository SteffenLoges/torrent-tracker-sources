<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}
if(isset($_GET["comid"])){$comid=0+$_GET["comid"];}else{$comid="";}
if(isset($_GET["comtxt"])){$comtxt=htmlchar($_GET["comtxt"]);}else{$comtxt="";}
if(isset($_GET["act"])){$act=$_GET["act"];}else{$act="";}
if(isset($_GET["saveedit"])){$saveedit=0+$_GET["saveedit"];}else{$saveedit="";}


if($act=="add"){
        if(!is_valid_id($tid)){
	      infoerr(btlng337);
	  }

	    if(!$comtxt){
		  infoerr(btlng338);
	      }
	

        $res = mysql_query("SELECT name FROM torrents WHERE tid = ".sqlesc($tid)) or sqlerr(__FILE__, __LINE__);
        $row = mysql_fetch_row($res);

	    if(!$row){
		  infoerr(btlng337);
	      }

       mysql_query("INSERT INTO comments (cuid, tid, added, text) VALUES (".$CURUSER["uid"].", $tid, $time, ".sqlesc($comtxt).")") or sqlerr(__FILE__, __LINE__);
        $newid = mysql_insert_id();

        mysql_query("UPDATE torrents SET comments = comments + 1 WHERE tid = ".sqlesc($tid)) or sqlerr(__FILE__, __LINE__);


		  $subres = mysql_query("SELECT COUNT(*) FROM comments WHERE tid = ".sqlesc($tid)." AND comid <= $newid") or sqlerr(__FILE__, __LINE__);
		  $subrow = mysql_fetch_row($subres);
		  $count = $subrow[0];
		  $comm_page = ceil($count / $GLOBALS["COMMENTS_PERPAGE"]);
		  $page_url = $comm_page?".pno=$comm_page":"";

      go_to("details:tid=$tid"."$page_url#com$newid");
}





if($act=="edit"){
        if(!is_valid_id($comid)){
	      errmsg(btlng32,btlng340);
	  }

    $res = mysql_query("SELECT c.*, t.name, t.tid FROM comments AS c JOIN torrents AS t ON c.tid = t.tid WHERE c.comid=".sqlesc($comid)) or sqlerr(__FILE__, __LINE__);
    $row = mysql_fetch_row($res);

        if(!$row){
	      errmsg(btlng32,btlng340);
	  }

	    if ($row[1] != $CURUSER["uid"] && get_user_class() < UC_MODERATOR){
		      errmsg(btlng32,btlng26_2);
		}


  $comtitle=str_replace("%comname%",$row[7],btlng341);

  title($comtitle,$comtitle);

	if($saveedit){

		if(!$comtxt){
		      infoerr(btlng342);
		  }
              mysql_query("UPDATE comments SET text=".sqlesc($comtxt).", editedat=$time, editedby=".$CURUSER["uid"]." WHERE comid=".sqlesc($comid)) or sqlerr(__FILE__, __LINE__);

		  $subres = mysql_query("SELECT COUNT(*) FROM comments WHERE tid = '".$row[8]."' AND comid <= ".sqlesc($comid))or sqlerr(__FILE__, __LINE__);
		  $subrow = mysql_fetch_row($subres);
		  $count = $subrow[0];
		  $comm_page = ceil($count / $GLOBALS["COMMENTS_PERPAGE"]);
		  $page_url = $comm_page?".pno=$comm_page":"";

                 go_to("details:tid=$tid"."$page_url#com$comid");
	      }
	      else{
		?>
		<script>
			    $('#saveedit').click(function() {
					    $.get("<?php echo $GLOBALS["BASEURL"];?>/comment.php", {act: "edit", saveedit: 1,comid: '<?php echo $comid;?>', comtxt: $('#markItUp').val(), tid: '<?php echo $row[8];?>' }, function(data) {
					      $("#info").html(data);
					    });
			    });
		</script>
		<?php

		    echo "<br><div class=\"shadow\"><div class=\"table\">";
			      echo "<div class=\"tr\"><div class=\"td\">".editor($row[4],320)."</div></div>";
			      echo "<div class=\"tr\"><div class=\"td\"><center><a href=\"javascript:;\" class=\"buttonsilver\" id=\"saveedit\">".btlng204."</a></center><br></div></div>";
			    echo "</div></div>";
      }

}




if($act=="del"){
$tid="";
	    if( get_user_class() < UC_MODERATOR){
		      errmsg(btlng32,btlng26_2);
		}

	      if(!is_valid_id($comid)){
		      errmsg(btlng32,btlng340);
		  }


    $res = mysql_query("SELECT tid FROM comments WHERE comid=".sqlesc($comid)) or sqlerr(__FILE__, __LINE__);
    $row = mysql_fetch_row($res);
    if($row){
        $tid = $row[0];
       }

    mysql_query("DELETE FROM comments WHERE comid=".sqlesc($comid)) or sqlerr(__FILE__, __LINE__);

    if($tid && mysql_affected_rows() > 0){
        mysql_query("UPDATE torrents SET comments = comments - 1 WHERE tid = $tid");
	      go_to("details:tid=$tid#com$time");
      }else{
          infoerr(btlng344);
	}


}




?>