<?php
require_once("inc/func.php");


if(isset($_GET["uid"])){$uid = 0 + $_GET["uid"];}else{$uid ="";}
if(isset($_GET["secret"])){$md5 = $_GET["secret"];}else{$md5 ="";}

if(!$uid){
errmsg(btlng32, btlng33);
}

dbconn();

$res = mysql_query("SELECT * FROM users WHERE uid = ".sqlesc($uid));
$row = mysql_fetch_array($res);

if(!$row){
errmsg(btlng32, btlng33);
}

 if($row["confirmed"]) {
  $confirmlang=str_replace("%login%", $GLOBALS["BASEURL"]."/#login", btlng34);
  errmsg(btlng32, $confirmlang,1);
 }

$sec = hash_pad($row["editsecret"],12);
 if($md5 != md5($sec)){
  errmsg(btlng32, btlng35);
 }

mysql_query("UPDATE users SET confirmed='1', editsecret='' WHERE uid=".sqlesc($uid)." AND confirmed='0'");


 if(!mysql_affected_rows()){
  errmsg(btlng32, btlng36);
 }


logincookie($uid, $row["passhash"]);

$_SESSION["udata"] = $row;
$_SESSION["udata"]["ip"] = $ip;

add_user_to_ram($uid);

  okmsg(btlng37, btlng38,1);

go_to();


?>