<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(isset($_GET["tid"])){$tid=0+$_GET["tid"];}else{$tid="";}


 if(!$tid || !is_valid_id($tid)){
	  errmsg(btlng32,btlng295);
       }

?>
<script>
	$('#peerlist').click(function() {
	   $("#peerlist").hide();
	});
</script>

<?php

  $shadowo = "<div class=\"shadow\" style=\"background:#fff url($stylelink/h28.png) repeat-x;width:880px;padding:1px;\">
	       <div class=\"table\">";

  $shadowu = "</div></div>";


# SEEDERS 
    $head_seeder = "<div class=\"tr\">
		         <div class=\"td\" style=\"text-align:left;\"><font color=\"#06BF00\"><b>SEEDERS</b></font></div>
                   </div>";

# LEECHERS
    $head_leecher = "<div class=\"tr\">
		        <div class=\"td\" style=\"text-align:left;\"><font color=\"#ff0000\"><b>LEECHERS</b></font></div>
                     </div>";


    $head = "<div class=\"tr\">
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:left;\"><b>Username</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>IP</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Port</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Hochgeladen</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Up Speed</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Runtergeladen</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Down Speed</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Ratio</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Fertig</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Verbunden</b></div>
		<div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>Untätig</b></div>
		<div class=\"td\" style=\"text-align:center;\"><b>Client</b></div>
             </div>";




$peersres = mysql_query("SELECT peers.puid, peers.ip, peers.agent, peers.tleft, peers.startdate, peers.lastaction, peers.connectable, 
			  traffic.uploaded, traffic.downloaded,
			    users.username, users.class, torrents.size, torrents.name, peers.upspeed, peers.downspeed FROM peers  
			      LEFT JOIN traffic ON peers.puid=traffic.uid AND peers.ptid=traffic.tid 
				LEFT JOIN users ON peers.puid=users.uid 
				  LEFT JOIN torrents ON peers.ptid=torrents.tid
				    WHERE ptid = ".sqlesc($tid)) or sqlerr();
  $seeders = "";
  $leechers = "";
  $ti=-1;
  $trstyle="";
  $torname = "";
   while ($peersrow = mysql_fetch_row($peersres)) {
	    $i=-1;
	    $uid=$peersrow[++$i];
	    $ip=ipd($peersrow[++$i]);
	    $agent=htmlchar($peersrow[++$i]);
	    $left=$peersrow[++$i];
	    $startdate=$peersrow[++$i];
	    $lastaction=$peersrow[++$i];
	    $connectable=$peersrow[++$i];
	    $uploaded=$peersrow[++$i];
	    $downloaded=$peersrow[++$i];
	    $username=$peersrow[++$i];
	    $class=$peersrow[++$i];
	    $torsize=$peersrow[++$i];
	    $torname=$peersrow[++$i];
	    $upspeed=mksize($peersrow[++$i],1);
	    $downspeed=mksize($peersrow[++$i],1);

	# USERNAME
	    $username = "<a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=$uid\"><font color=\"".get_class_color($class)."\"><b>$username</b></font></a>";

	# HIDE IP
	  $mod = 0;

	    if(get_user_class() >= UC_MODERATOR && ($class < UC_ROOT || get_user_class() == UC_ROOT)){
	      $mod = 1;
	      }

	      if($mod){
		    $ip = $ip;
		}else{
		    $v6 = preg_match("/^[0-9a-f]{1,4}:([0-9a-f]{0,4}:){1,6}[0-9a-f]{1,4}$/", $ip);
		    $v4 = preg_match("/^([0-9]{1,3}\.){3}[0-9]{1,3}$/", $ip);

		      if($v6 != 0){
			   $ip = preg_replace('/\:(\d+)(\w+)$/', ":xxxx", $ip);;
			}
			elseif($v4 != 0){
			    $ip = preg_replace('/\.\d+\.\d+$/', ".x.x", $ip);
			}

		}
      
	# CONNACTABLE
	      if($connectable){
		    $connectable = "<font color=\"#06BF00\"><b>".btlng438."</b></font>";
		 }else{
		      $connectable = "<font color=\"#ff0000\"><b>".btlng439."</b></font>";
		   }

	# RATIO
	  if($downloaded){
		$ratio = floor(($uploaded / $downloaded) * 1000) / 1000;
		$ratio = "<font color=\"" . get_ratio_color($ratio) . "\"><b>" . number_format($ratio, 3) . "</b></font>";
	    }else{
		  if($uploaded){
		      $ratio = "inf";
		     }else{
		      $ratio = "---";
		       }
		}

	# FINISHED %
          $totfinish = sprintf("%.1f%%", 100 * (1 - ($left / $torsize)));

	# CONNECTED
          $connecttime = $time - $startdate;
          $connecttime = gmdate("H:i:s", $connecttime);

	# IDLE
	  $idle = $time - $lastaction;
          $idle = gmdate("i:s", $idle);

	# SPLIT TR BORDER
	if($ti){
	  $trstyle="border-top:1px solid #ABABAB;";
	}

	# BACKGROUND COLOR ROW
	      if($ti % 2 ){
		  $bgcolor="#FFFFE5";
		 }else{$bgcolor="#F8F8F8";}

      
	  if(!$left){
	      $seeders .= "<div class=\"tr\" style=\"background-color:$bgcolor;$trstyle\">
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:left;\">$username</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$ip</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$connectable</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">".mksize($uploaded)."</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>$upspeed/s</b></div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">".mksize($downloaded)."</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">0.0 KB/s</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$ratio</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$totfinish</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$connecttime</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$idle</div>
			      <div class=\"td\" style=\"text-align:center;\">$agent</div>
			  </div>";
	  }

	  if($left){
	      $leechers .= "<div class=\"tr\" style=\"background-color:$bgcolor;$trstyle\">
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:left;\">$username</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$ip</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$connectable</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">".mksize($uploaded)."</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>$upspeed/s</b></div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">".mksize($downloaded)."</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\"><b>$downspeed/s</b></div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$ratio</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$totfinish</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$connecttime</div>
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;text-align:center;\">$idle</div>
			      <div class=\"td\" style=\"text-align:center;\">$agent</div>
			  </div>";
	  }
++$ti;
     } 

echo $shadowo."<div class=\"tr\">
		        <div class=\"td\" style=\"text-align:center;\"><b>".btlng440." $torname</b></div>
               </div>".
      $shadowu;

    # SEEDERS PEERLIST
      if($seeders){
      echo $head_seeder;
      echo $shadowo.$head.$seeders.$shadowu;
      }

	      if($seeders && $leechers){
	      echo "<br><br><div class=\"divbottom\"></div><br>";
	      }

    # LEECHERS PEERLIST
      if($leechers){
      echo $head_leecher;
      echo $shadowo.$head.$leechers.$shadowu;
      }








?>