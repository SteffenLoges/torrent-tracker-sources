<?php
require_once("inc/func.php");
session_start();
title(btlng3,btlng3);
?>
<script>
$("#username").focus();


  $('#regbut').click(function() {
    $.get("<?php echo $GLOBALS["BASEURL"];?>/signupt.php", { username: $('#username').val(), passwd: $('#passwd').val(), repasswd: $('#repasswd').val(), email: $('#email').val(), faqverify: $('#faqverify:checked').val(), ageverify: $('#ageverify:checked').val(), scode: $('#scode').val() }, function(data){
	$("#info").html(data);
	});
  });


  $('#captchalink').click(function() {
    var timestamp = new Date().getTime();
    $("#captcha").attr('src','<?php echo $GLOBALS["BASEURL"];?>/captcha.php?' +timestamp );
    });


</script>
<p align="center"><?php echo btlng5;?></p>
<div class="signup">
<div class="divbottom"><dl><dt><?php echo btlng6;?></dt><dd><input type="text" id="username" name="username" size="32" maxlength="16"></dd></dl></div>
<div class="divbottom"><dl><dt><?php echo btlng7;?></dt><dd><input type="password" id="passwd" name="passwd" size="32"></dd></dl></div>
<div class="divbottom"><dl><dt><?php echo btlng8;?></dt><dd><input type="password" id="repasswd" name="repasswd" size="32"></dd></dl></div>
<div class="divbottom"><dl><dt><?php echo btlng9;?></dt><dd><input type="text" id="email" name="email" size="32"></dd></dl></div>
<div><dl><dt><?php echo btlng9_1;?></dt><dd><a href="javascript:;" title="Reload Image" id="captchalink"><img id="captcha" class="imgborder" src="captcha.php" /></a></dd></dl></div>
<div class="divbottom"><dl><dt>&nbsp;</dt><dd><input type="text" id="scode" size="32"></dd></dl></div>


<div class="table">
    <div class="tr">
	<div class="td" style="text-align:right;"><input type="checkbox" id="faqverify" name="faqverify" value="yes"></div> <div class="td" style="text-align:left;"><?php echo btlng10;?></div>
    </div>
    <div class="tr">
	<div class="td" style="text-align:right;"><input type="checkbox" id="ageverify" name="ageverify" value="yes"></div> <div class="td" style="text-align:left;"><?php echo btlng11;?></div>
    </div>
</div>

<br>
<a id="regbut" class="buttonsilver"><?php echo btlng12;?></a>

</div>
