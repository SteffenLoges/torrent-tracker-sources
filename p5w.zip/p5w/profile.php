<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();
 
?>
<script>
 	     $('#saveprofile').click(function() {
			    $.get("<?php echo $GLOBALS["BASEURL"];?>/profilet.php", {
				avatar: $('#avatar').val(),  title: $('#title').val(), acceptpms: $('#acceptpms:checked').val(), deletepms: $('#deletepms:checked').val(), 
		                savepms: $('#savepms:checked').val(), acceptemail: $('#acceptemail:checked').val(), wget: $('#wget:checked').val(),
				email: $('#email').val(), passwd: $('#passwd').val(), passwdagain: $('#passwdagain').val()
				  }, function(data) {
			      $("#info").html(data);
	setTimeout("window.location.replace('<?php echo $GLOBALS["BASEURL"]."/#profile?$time";?>');",2000);
                              
			    });
             });

</script>
<?php

title(btlng346,btlng346);

   $tr = "border-bottom:1px solid #ABABAB;background-color:#FFFFDD;";
   $td1 = "border-right:1px solid #ABABAB;width:130px;padding:9px;vertical-align:middle;";
   $td2 = "padding:9px;vertical-align:middle;";


   echo "<br><div class=\"shadow\" style=\"padding:1px;\"><div class=\"table\">";

# AVATAR
      if($CURUSER["avatar"]){
	$avatarsrc=htmlchar($CURUSER["avatar"]);
	}else{
	      if(file_exists($GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($CURUSER["uid"].$CURUSER["added"]).".jpg")){
	              $avatarsrc=$GLOBALS["XIMGDEPOT_DIR"]."/useravatars/".md5($CURUSER["uid"].$CURUSER["added"]).".jpg";
			}else{
	                    $avatarsrc=$GLOBALS["IMAGES_DIR"]."default_avatar.png";
			  }
	      }
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng356."</b></div> 
		  <div class=\"td profiltd2\">
			  <img class=\"imgborder\" style=\"width:110px;\" src=\"$avatarsrc\">
                          <div style=\"padding-top:6px;\"><input id=\"avatar\" size=\"70\" value=\"" . htmlchar($CURUSER["avatar"]) ."\"></div>
		  </div>
	   </div>";


# TITLE
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng156."</b></div> 
		  <div class=\"td profiltd2\">
			  <input id=\"title\" size=\"70\" value=\"".$CURUSER["title"]."\">
		  </div>
	   </div>";

# ACCEPT PN'S
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng347."</b></div> 
		  <div class=\"td profiltd2\">
			  <input type=\"radio\" name=\"acceptpms\" id=\"acceptpms\"" . ($CURUSER["acceptpms"] == "1" ? " checked=\"checked\"" : "") . " value=\"1\">".btlng348."
			  <input type=\"radio\" name=\"acceptpms\" id=\"acceptpms\"" .  ($CURUSER["acceptpms"] == "2" ? " checked=\"checked\"" : "") . " value=\"2\">".btlng349."
			  <input type=\"radio\" name=\"acceptpms\" id=\"acceptpms\"" .  ($CURUSER["acceptpms"] == "0" ? " checked=\"checked\"" : "") . " value=\"0\">".btlng350."
		  </div>
	   </div>";

# DELETE PN'S
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng351."</b></div> 
		  <div class=\"td profiltd2\">
                          <input type=\"checkbox\" id=\"deletepms\"" . ($CURUSER["deletepms"] == "1" ? " checked=\"checked\"" : "") . "> ".btlng352."
		  </div>
	   </div>";

# SAVE PN'S
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng353."</b></div> 
		  <div class=\"td profiltd2\">
                          <input type=\"checkbox\" id=\"savepms\"" . ($CURUSER["savepms"] == "1" ? " checked=\"checked\"" : "") . "> ".btlng354."
		  </div>
	   </div>";

# ACCEPT EMAIL
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng355."</b></div> 
		  <div class=\"td profiltd2\">
                          <input type=\"radio\" name=\"acceptemail\" id=\"acceptemail\"" . ($CURUSER["acceptemail"] == "1" ? " checked=\"checked\"" : "") . " value=\"1\">".btlng348."
			  <input type=\"radio\" name=\"acceptemail\" id=\"acceptemail\"" .  ($CURUSER["acceptemail"] == "2" ? " checked=\"checked\"" : "") . " value=\"2\">".btlng349."
			  <input type=\"radio\" name=\"acceptemail\" id=\"acceptemail\"" .  ($CURUSER["acceptemail"] == "0" ? " checked=\"checked\"" : "") . " value=\"0\">".btlng350."
		  </div>
	   </div>";

# WGET COMMAND
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng357."</b></div> 
		  <div class=\"td profiltd2\">
                          <input type=\"checkbox\" id=\"wget\"" . ($CURUSER["wget"] == "1" ? " checked=\"checked\"" : "") . "> ".btlng358."
		  </div>
	   </div>";



# EMAIL-ADRESSE
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng359."</b></div> 
		  <div class=\"td profiltd2\" style=\"$td2\">
			  <input id=\"email\" size=\"70\" value=\"".$CURUSER["email"]."\"><div style=\"padding:4px;\"><font color=\"red\"><b>".btlng363."</b></font>".btlng364."</div>
		  </div>
	   </div>";



# PASSWORD
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng360."</b></div> 
		  <div class=\"td profiltd2\">
			  <input id=\"passwd\" size=\"70\" value=\"\">
		  </div>
	   </div>";


# PASSWORD AGAIN
     echo "<div class=\"tr profiltr\">
	    <div class=\"td profiltd1\"><b>".btlng361."</b></div> 
		  <div class=\"td profiltd2\">
			  <input id=\"passwdagain\" size=\"70\" value=\"\">
		  </div>
	   </div>";



echo "</div>

			  <center style=\"background-color:#FFFFDD\"><br>
		            <a href=\"javascript:;\" id=\"saveprofile\" class=\"buttonsilver\">".btlng204."</a>
			     <a href=\"javascript:;\" onclick=\"window.location.replace('".$GLOBALS["BASEURL"]."/#profile?$time')\" class=\"buttonsilver\">".btlng362."</a>
			    <br><br></center>\n
</div><br>";





?>