<?php
/*
// +--------------------------------------------------------------------------+
// | Project:    P5W - P5W BitTorrent Tracker  http://bt-technik.com          |
// +--------------------------------------------------------------------------+
// | Developer Orti1980       |						      |
// | P5WTracker is free software; you can redistribute it and/or modify       |
// | it under the terms of the GNU General Public License as published by     |
// | the Free Software Foundation; either version 3 of the License, or        |
// | (at your option) any later version.                                      |
// |                                                                          |
// | P5WTracker is distributed in the hope that it will be useful,            |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with NVTracker; if not, write to the Free Software Foundation,     |
// | Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA            |
// +--------------------------------------------------------------------------+
// | Obige Zeilen duerfen nicht entfernt werden!   Do not remove above lines! |
// +--------------------------------------------------------------------------+
 */
require_once("inc/func.php");
dbconn();
loggedinorreturn();

if(get_user_class() < UC_ADMIN){
errmsg(btlng26_2,btlng26_2);
}

if(isset($_GET["act"])){$act = $_GET["act"];}else{$act="";}
if(isset($_GET["nid"])){$nid = 0 + $_GET["nid"];}else{$nid=0;}
if(isset($_GET["ntitle"])){$ntitle = htmlchar($_GET["ntitle"]);}else{$ntitle="";}
if(isset($_GET["nbody"])){$nbody = htmlchar($_GET["nbody"]);}else{$nbody="";}
if(isset($_GET["del"])){$del = 0 + $_GET["del"];}else{$del=0;}


$ptitle=btlng473;

  if($act=="edit"){
      $ptitle=btlng471;
    }

  if($act=="del"){
      $ptitle=btlng472;
    }

  if($act=="editsave"){
      $ptitle=btlng471;
    }

  title($ptitle,$ptitle);

	?>
	<script>
	    function send(act) {
		$.get("<?php echo $GLOBALS["BASEURL"];?>/news.php", {act: act, nid: '<?php echo $nid;?>', ntitle: $('#ntitle').val(), nbody: $('#markItUp').val() }, function(data) {
		  $("#info").html(data);
		  setTimeout("window.location.replace('<?php echo $GLOBALS["BASEURL"];?>');",1500);
		});
             }
	</script>
	<?php

if($act=="edit"){

	  if(!$nid){
	    errmsg(btlng475,btlng475);
	  }
	    $newsres = mysql_query("SELECT title, body FROM news WHERE nid = ".sqlesc($nid)) or sqlerr(__FILE__, __LINE__);
	    $newsrow = mysql_fetch_row($newsres);
      
	     if(!$newsrow){
	        errmsg(btlng476,btlng476);
		}

	    echo "<div class=\"shadow\" style=\"padding:0px;width:50%;\">

		      <div class=\"table\">
			  <div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\">
			      <div class=\"td\" style=\"border-right:1px solid #ABABAB;\">Title : </div><div class=\"td\"><input type=\"text\" id=\"ntitle\" value=\"".$newsrow[0]."\" size=\"84\"></div>
			  </div>
			  <div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\">";
	    ?>
			      <div class="td" style="width:70px;border-right:1px solid #ABABAB;vertical-align:middle;">Body : </div><div class="td" style="float:left;"><?php editor($newsrow[1]);?></div>
	    <?php

	    echo "       </div>
		      </div>
		  <div><center><br><a href=\"javascript:send('editsave');\" id=\"savenews\" class=\"buttonsilver\">".btlng204."</a><br><br></center></div>\n
		  </div>";

}

elseif($act=="editsave"){

      if(!$nid){
	errmsg(btlng475,btlng475);
      }
	if(!$ntitle){
	      infoerr(btlng477);
	    }

	 if(!$nbody){
	      infoerr(btlng478);
	      }

		mysql_query("UPDATE news SET title=".sqlesc($ntitle).", body = ".sqlesc($nbody)." WHERE nid = ".sqlesc($nid)) or sqlerr(__FILE__, __LINE__);
	    infok(btlng448);	 
      
}

elseif($act=="del"){

      if(!$nid){
	errmsg(btlng475,btlng475);
      }
      
    echo "<div class=\"errmsg\">
		<center>".btlng120." <br><br>
		<a href=\"".$GLOBALS["BASEURL"]."/news.php?act=$act&nid=$nid&del=1\" class=\"buttonsilver\">".btlng472."</a>
		</center>
	  </div>";

      if($del=="1"){
	mysql_query("DELETE FROM news WHERE nid = ".sqlesc($nid));
	    infok(btlng479);
             go_to();
	}
}

elseif($act=="add"){
	  mysql_query("INSERT INTO news (title, body, added, nuid) VALUES (".sqlesc($ntitle).", ".sqlesc($nbody).", $time, ".$CURUSER["uid"].")") or sqlerr(__FILE__, __LINE__);
	    infok(btlng480);
}

else{

	echo "<div class=\"shadow\" style=\"padding:0px;width:50%;\">

		  <div class=\"table\">
		      <div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\">
			  <div class=\"td\" style=\"border-right:1px solid #ABABAB;\">Title : </div><div class=\"td\"><input type=\"text\" id=\"ntitle\" size=\"84\"></div>
		      </div>
		      <div class=\"tr\" style=\"border-bottom:1px solid #ABABAB;\">";
	?>
			  <div class="td" style="width:70px;border-right:1px solid #ABABAB;vertical-align:middle;">Body : </div><div class="td" style="float:left;"><?php editor();?></div>
	<?php

	echo "       </div>
		  </div>
	      <div><center><br><a href=\"javascript:send('add');\" id=\"savenews\" class=\"buttonsilver\">".btlng204."</a><br><br></center></div>\n
	      </div>";

}


?>