jQuery(document).ready(function($) {
        function load(num) {
		var str = num;
		var substr = str.split('?');
		num=substr[0];
		num2=substr[1];
		 if(!num2){
			num2="";
			}else{
			     num2="?"+num2;
				}
	      $.ajax({
    			url: num +".php",
    			type:'HEAD',
    		     error:
        		function(){
            			$('#content').load("home.php");
				$('#navi').load("navi.php");
        			},
                     success:
        		function(){
				$('#navi').load("navi.php");
				 if(num=="download"){
				   $('#content').load("torrents.php");
				   return false;
				 }
					$('#content').load(num +".php"+num2, function() {
					  var isFound = num2.toString().search(/#/i);
					  if(isFound > 0){
					  anchor = num2.replace(/^.*#/i, '');
					  anchor = "#"+anchor;
					  if ($(anchor).length > 0){
					  window.scrollTo(0, $(anchor).position().top);}
					  }
					}
				      );
        			}
		});
        }

        $.history.init(function(url) {
                load(url == "" ? "home" : url);
            });

        $('#historylink').live('click', function(e) {
                var url = $(this).attr('href');
                url = url.replace(/^.*#/, '');
                $.history.load(url);
                return false;
            });

    }); 
