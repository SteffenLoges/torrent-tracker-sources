<?php
require_once("inc/func.php");
dbconn();
loggedinorreturn();
  title(btlng2,btlng2);
  $_SESSION["shoutboxtime"]="empty";
?>

<script type="text/javascript">

$('#pollr').load('<?php echo $GLOBALS["BASEURL"];?>/poll.php');

  function expandCollapse(newsId)
  {
      var plusMinusImg = $("#plusminus"+newsId);
      var detailRow = $("#news"+newsId);

      if (detailRow.css("display") == "none") {
	plusMinusImg.attr("src","<?php echo "$stylelink/minus.png";?>");
	detailRow.css("display","block");
	}
	else{
	plusMinusImg.attr("src","<?php echo "$stylelink/plus.png";?>");
	detailRow.css("display","none");
      }
  }

</script>




<?php
# NEWS
  $newsres = mysql_query("SELECT news.*, users.username, users.class FROM news LEFT JOIN users ON news.nuid = users.uid ORDER BY added DESC LIMIT 3") or sqlerr(__FILE__, __LINE__);

  $first = TRUE;


    if(mysql_num_rows($newsres) > 0 || get_user_class() >= UC_ADMIN)
    {

	?>
	  <div class="shadow news1">
	    <center><b>News</b></center>
	  </div>
	  <div class="shadow news2">
	  <div id="newsadd" style="display:none;"></div>
	<?php

        if(get_user_class() >= UC_ADMIN)
        {
	    echo "<div class=\"shadow\" style=\"padding:4px;width:100px;\">
	    <a href=\"".$GLOBALS["BASEURL"]."/#news\"><center><img title=\"".btlng473."\"  src=\"$stylelink/newsadd.png\"></center></a>
	    </div><br>";
	}

	while($newsrow = mysql_fetch_row($newsres))
	{
	 $display="";
         if(!$first){
		$display="display:none;";
	      }

	    $newsdate = date("d.m.Y",$newsrow[2]);

	    $news_day = date("l",$newsrow[2]);

		  if($news_day == "Monday"){
		      $news_day=btlng464;
		      }
		  if($news_day == "Tuesday"){
		      $news_day=btlng465;
		      }
		  if($news_day == "Wednesday"){
		      $news_day=btlng466;
		      }
		  if($news_day == "Thursday"){
		      $news_day=btlng467;
		      }
		  if($news_day == "Friday"){
		      $news_day=btlng468;
		      }
		  if($news_day == "Saturday"){
		      $news_day=btlng469;
		      }
		  if($news_day == "Sunday"){
		      $news_day=btlng470;
		      }

		if($first){
		$pmimg="<a href=\"javascript:expandCollapse(".$newsrow[0].");\">&nbsp;<img id=\"plusminus".$newsrow[0]."\" src=\"$stylelink/minus.png\">&nbsp;</a>";
		}else{
		$pmimg="<a href=\"javascript:expandCollapse(".$newsrow[0].");\">&nbsp;<img id=\"plusminus".$newsrow[0]."\" src=\"$stylelink/plus.png\">&nbsp;</a>";
		}


		echo "<div class=\"shadow news3\">
		$pmimg
		      <b>".htmlchar($newsrow[3])."</b> ( <a href=\"".$GLOBALS["BASEURL"]."/#userdetails?uid=".$newsrow[1]."\" title=\"".get_user_class_name($newsrow[6])."\"><font color=".get_class_color($newsrow[6])."><b>".$newsrow[5]."</b></font></a> , $news_day $newsdate)
		      </div>

		<div class=\"shadow\" id=\"news".$newsrow[0]."\" style=\"padding:4px;width:99%;background-color:#FFFFDD;$display\">
		    <div class=\"table\">
			<div class=\"tr\">
			    <div class=\"td\">".format_comment($newsrow[4])."</div>";

		  if(get_user_class() >= UC_ADMIN)
		  {
		    echo "<div class=\"td newsadmin\"><a href=\"".$GLOBALS["BASEURL"]."/#news?act=edit&nid=".$newsrow[0]."\"><img title=\"".btlng389."\" src=\"$stylelink/edit.png\"></center></a></div>
			  <div class=\"td newsadmin\"><a href=\"".$GLOBALS["BASEURL"]."/#news?act=del&nid=".$newsrow[0]."\"><img title=\"".btlng117."\" src=\"$stylelink/deletet.png\"></a></div>";
		    }

		  echo "</div>
		    </div>
		</div>";


        $first = FALSE;
      }
    echo "</div>";
    }


# SHOUTBOX
if($GLOBALS["SHOUTBOX"]){

  ?>

<script type="text/javascript">

            setInterval(function() {
	      $.get('<?php echo $GLOBALS["BASEURL"];?>/shoutbox.php', { act: "show" }, function(data){
		  if(data != 0){
		    $("#shoutbox").html(data);
		  }
	      });
             },1500);


  $('#shadd').click(function() {
	      $.get('<?php echo $GLOBALS["BASEURL"];?>/shoutbox.php', { act: "add", shtext: $('#shtext').val() }, function(data){
		  if(data){
		    $("#info").html(data);
		  }
	      });
	      $('#shtext').val("");
  });

    $('#shtext').keypress(function(e) {
    if(e.which == 13 || e.which == 10) {
	       $.get('<?php echo $GLOBALS["BASEURL"];?>/shoutbox.php', { act: "add", shtext: $('#shtext').val() }, function(data){
		  if(data){
		    $("#info").html(data);
		  }
	      });
	      $('#shtext').val("");
     }
    });


  $('#shhohe').click(function() {
	var xval = $(this).attr("valx");
	if(xval == "on"){
	    $("#shoutbox").css("height","600");
	    $("#shtext").focus();
	    $(this).attr("valx", "off");
	} 
	if(xval == "off"){
	    $(this).attr("valx", "on");
	    $("#shoutbox").css("height","380");
	    $("#shtext").focus();
	}
  });


  $('#smilieslink').click(function() {
    $('#smilies').load("smilies.php?shout=1");
    $('#smilies').show();
  });


    function insert(aTag, eTag) {
      var input = document.getElementById("shtext");
      input.focus();

      if(typeof document.selection != 'undefined') {
	/* Einfügen des Formatierungscodes */
	var range = document.selection.createRange();
	var insText = range.text;

	  if(insText == ""){
	      alert("<?php echo btlng481;?>");
	      return false;
	      }

	range.text = aTag + insText + eTag;
	/* Anpassen der Cursorposition */
	range = document.selection.createRange();
	if (insText.length == 0) {
	  range.move('character', -eTag.length);
	} else {
	  range.moveStart('character', aTag.length + insText.length + eTag.length);      
	}
	range.select();
      }

      else if(typeof input.selectionStart != 'undefined')
      {
	/* Einfügen des Formatierungscodes */
	var start = input.selectionStart;
	var end = input.selectionEnd;
	var insText = input.value.substring(start, end);

	  if(insText == ""){
	      alert("<?php echo btlng481;?>");
	      return false;
	      }

	input.value = input.value.substr(0, start) + aTag + insText + eTag + input.value.substr(end);
	/* Anpassen der Cursorposition */
	var pos;
	if (insText.length == 0) {
	  pos = start + aTag.length;
	} else {
	  pos = start + aTag.length + insText.length + eTag.length;
	}
	input.selectionStart = pos;
	input.selectionEnd = pos;
      }

      else
      {

	var pos;
	var re = new RegExp('^[0-9]{0,3}$');
	while(!re.test(pos)) {
	  pos = prompt("Einfügen an Position (0.." + input.value.length + "):", "0");
	}
	if(pos > input.value.length) {
	  pos = input.value.length;
	}

	var insText = prompt("Bitte geben Sie den zu formatierenden Text ein:");
	input.value = input.value.substr(0, pos) + aTag + insText + eTag + input.value.substr(pos);
      }
    }
</script>
	    <br><br>

	    <div class="shadow shoutbox1">
	      <center><b>ShoutBoX</b></center>
	    </div>

	    <div class="shadow shoutbox2">
	    <div id="shouttxtedit" style="display:none;"></div>
		      <div class="shadow shoutbox3" id="shoutbox">
			  <center><img align="middle" src="<?php echo $GLOBALS["IMAGES_DIR"];?>loading.png"></center>
		      </div>
	    <br>
	    <center>
	      <div style="width:50%;">
		  <a href="javascript:;" id="shhohe" title="Height" valx="on" ><img src="/editor/images/height.png" class="imgborder"></a>
		  <a href="javascript:;" id="bold" title="Bold" onClick="insert('[b]', '[/b]');"><img src="/editor/images/bold.png" class="imgborder"></a>
		  <a href="javascript:;" id="italic" title="Italic" onClick="insert('[i]', '[/i]');"><img src="/editor/images/italic.png" class="imgborder"></a>
		  <a href="javascript:;" id="underline" title="Underline" onClick="insert('[u]', '[/u]');"><img src="/editor/images/underline.png" class="imgborder"></a>
		  <a href="javascript:;" id="center" title="Center" onClick="insert('[center]', '[/center]');"><img src="/editor/images/center.png" class="imgborder"></a>
		  <a href="javascript:;" id="center" title="Image" onClick="insert('[img]', '[/img]');"><img src="/editor/images/image.png" class="imgborder"></a>
		  <a href="javascript:;" id="center" title="Link" onClick="insert('[url]', '[\/url\]');"><img src="/editor/images/link.png" class="imgborder"></a>
		  <a id="smilieslink" href="javascript:;"><img style="text-align:center;" src="<?php echo $GLOBALS["IMAGES_DIR"];?>smiles.gif" title="Smilies"></a>
		  <!-- Smilies -->
		  <div id="smilies" class="smilies"></div>
	      </div>
	      <div style="width:50%;">
		  <input type="text" class="shoutinput" maxlength="255" name="shtext" id="shtext" size="70"> <input type="button" id="shadd" class="shoutinputbut" value="<?php echo btlng188;?>">
	      </div>
	    </center>
	    <br>
	    </div>
	    <br>
  <?php 

  } else{

      $shoutboxtime = apc_fetch("shoutboxtime");

      $shoutboxwvals = apc_fetch("shoutboxvals");
  
      if($shoutboxtime){
	  apc_delete("shoutboxtime");
	}

      if($shoutboxwvals){
	  apc_delete("shoutboxvals");
	}

}

?>


	    <br><br>

	    <div class="shadow poll1">
	      <center><b><?php echo btlng502;?></b></center>
	    </div>

	    <div class="shadow poll2"><br>
		      <div class="shadow pollcls"  id="pollr"> </div>
	    <br>
	    </div>
	    <br>
